// lib: , url: package:flutter/src/material/calendar_date_picker.dart

// class id: 1048860, size: 0x8
class :: {

  [closure] static void _reportAnnouncementError(dynamic, Object, StackTrace) {
    // ** addr: 0xdedff8, size: 0x34
    // 0xdedff8: EnterFrame
    //     0xdedff8: stp             fp, lr, [SP, #-0x10]!
    //     0xdedffc: mov             fp, SP
    // 0xdee000: CheckStackOverflow
    //     0xdee000: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdee004: cmp             SP, x16
    //     0xdee008: b.ls            #0xdee024
    // 0xdee00c: ldr             x1, [fp, #0x18]
    // 0xdee010: ldr             x2, [fp, #0x10]
    // 0xdee014: r0 = _reportAnnouncementError()
    //     0xdee014: bl              #0xdee02c  ; [package:flutter/src/material/calendar_date_picker.dart] ::_reportAnnouncementError
    // 0xdee018: LeaveFrame
    //     0xdee018: mov             SP, fp
    //     0xdee01c: ldp             fp, lr, [SP], #0x10
    // 0xdee020: ret
    //     0xdee020: ret             
    // 0xdee024: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdee024: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdee028: b               #0xdee00c
  }
  static void _reportAnnouncementError(Object, StackTrace) {
    // ** addr: 0xdee02c, size: 0x94
    // 0xdee02c: EnterFrame
    //     0xdee02c: stp             fp, lr, [SP, #-0x10]!
    //     0xdee030: mov             fp, SP
    // 0xdee034: AllocStack(0x18)
    //     0xdee034: sub             SP, SP, #0x18
    // 0xdee038: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xdee038: mov             x0, x1
    //     0xdee03c: stur            x1, [fp, #-8]
    //     0xdee040: stur            x2, [fp, #-0x10]
    // 0xdee044: CheckStackOverflow
    //     0xdee044: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdee048: cmp             SP, x16
    //     0xdee04c: b.ls            #0xdee0b8
    // 0xdee050: r1 = <List<Object>>
    //     0xdee050: ldr             x1, [PP, #0x860]  ; [pp+0x860] TypeArguments: <List<Object>>
    // 0xdee054: r0 = ErrorDescription()
    //     0xdee054: bl              #0x829ca4  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x2c)
    // 0xdee058: mov             x1, x0
    // 0xdee05c: r2 = "while sending semantics announcement"
    //     0xdee05c: add             x2, PP, #0x1c, lsl #12  ; [pp+0x1cc28] "while sending semantics announcement"
    //     0xdee060: ldr             x2, [x2, #0xc28]
    // 0xdee064: r3 = Instance_DiagnosticLevel
    //     0xdee064: ldr             x3, [PP, #0x868]  ; [pp+0x868] Obj!DiagnosticLevel@12c5f41
    // 0xdee068: stur            x0, [fp, #-0x18]
    // 0xdee06c: r0 = _ErrorDiagnostic()
    //     0xdee06c: bl              #0x829bec  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0xdee070: r0 = FlutterErrorDetails()
    //     0xdee070: bl              #0x829be0  ; AllocateFlutterErrorDetailsStub -> FlutterErrorDetails (size=0x20)
    // 0xdee074: mov             x1, x0
    // 0xdee078: ldur            x0, [fp, #-8]
    // 0xdee07c: StoreField: r1->field_7 = r0
    //     0xdee07c: stur            w0, [x1, #7]
    // 0xdee080: ldur            x0, [fp, #-0x10]
    // 0xdee084: StoreField: r1->field_b = r0
    //     0xdee084: stur            w0, [x1, #0xb]
    // 0xdee088: r0 = "material library"
    //     0xdee088: add             x0, PP, #0xad, lsl #12  ; [pp+0xadf68] "material library"
    //     0xdee08c: ldr             x0, [x0, #0xf68]
    // 0xdee090: StoreField: r1->field_f = r0
    //     0xdee090: stur            w0, [x1, #0xf]
    // 0xdee094: ldur            x0, [fp, #-0x18]
    // 0xdee098: StoreField: r1->field_13 = r0
    //     0xdee098: stur            w0, [x1, #0x13]
    // 0xdee09c: r0 = false
    //     0xdee09c: add             x0, NULL, #0x30  ; false
    // 0xdee0a0: StoreField: r1->field_1b = r0
    //     0xdee0a0: stur            w0, [x1, #0x1b]
    // 0xdee0a4: r0 = reportError()
    //     0xdee0a4: bl              #0x829a24  ; [package:flutter/src/foundation/assertions.dart] FlutterError::reportError
    // 0xdee0a8: r0 = Null
    //     0xdee0a8: mov             x0, NULL
    // 0xdee0ac: LeaveFrame
    //     0xdee0ac: mov             SP, fp
    //     0xdee0b0: ldp             fp, lr, [SP], #0x10
    // 0xdee0b4: ret
    //     0xdee0b4: ret             
    // 0xdee0b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdee0b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdee0bc: b               #0xdee050
  }
}

// class id: 3121, size: 0xc, field offset: 0x8
//   const constructor, 
class _YearPickerGridDelegate extends SliverGridDelegate {

  _ getLayout(/* No info */) {
    // ** addr: 0x12ff534, size: 0x1a8
    // 0x12ff534: EnterFrame
    //     0x12ff534: stp             fp, lr, [SP, #-0x10]!
    //     0x12ff538: mov             fp, SP
    // 0x12ff53c: AllocStack(0x28)
    //     0x12ff53c: sub             SP, SP, #0x28
    // 0x12ff540: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x12ff540: stur            x2, [fp, #-8]
    // 0x12ff544: CheckStackOverflow
    //     0x12ff544: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12ff548: cmp             SP, x16
    //     0x12ff54c: b.ls            #0x12ff6d4
    // 0x12ff550: LoadField: r0 = r1->field_7
    //     0x12ff550: ldur            w0, [x1, #7]
    // 0x12ff554: DecompressPointer r0
    //     0x12ff554: add             x0, x0, HEAP, lsl #32
    // 0x12ff558: mov             x1, x0
    // 0x12ff55c: r0 = textScalerOf()
    //     0x12ff55c: bl              #0xd16168  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::textScalerOf
    // 0x12ff560: r1 = LoadClassIdInstr(r0)
    //     0x12ff560: ldur            x1, [x0, #-1]
    //     0x12ff564: ubfx            x1, x1, #0xc, #0x14
    // 0x12ff568: mov             x16, x0
    // 0x12ff56c: mov             x0, x1
    // 0x12ff570: mov             x1, x16
    // 0x12ff574: d0 = 3.000000
    //     0x12ff574: fmov            d0, #3.00000000
    // 0x12ff578: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x12ff578: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x12ff57c: r0 = GDT[cid_x0 + -0xffa]()
    //     0x12ff57c: sub             lr, x0, #0xffa
    //     0x12ff580: ldr             lr, [x21, lr, lsl #3]
    //     0x12ff584: blr             lr
    // 0x12ff588: r1 = LoadClassIdInstr(r0)
    //     0x12ff588: ldur            x1, [x0, #-1]
    //     0x12ff58c: ubfx            x1, x1, #0xc, #0x14
    // 0x12ff590: mov             x16, x0
    // 0x12ff594: mov             x0, x1
    // 0x12ff598: mov             x1, x16
    // 0x12ff59c: d0 = 14.000000
    //     0x12ff59c: fmov            d0, #14.00000000
    // 0x12ff5a0: r0 = GDT[cid_x0 + -0x1000]()
    //     0x12ff5a0: sub             lr, x0, #1, lsl #12
    //     0x12ff5a4: ldr             lr, [x21, lr, lsl #3]
    //     0x12ff5a8: blr             lr
    // 0x12ff5ac: LoadField: d0 = r0->field_7
    //     0x12ff5ac: ldur            d0, [x0, #7]
    // 0x12ff5b0: d1 = 14.000000
    //     0x12ff5b0: fmov            d1, #14.00000000
    // 0x12ff5b4: fdiv            d2, d0, d1
    // 0x12ff5b8: d0 = 1.650000
    //     0x12ff5b8: add             x17, PP, #0xd1, lsl #12  ; [pp+0xd1e60] IMM: double(1.65) from 0x3ffa666666666666
    //     0x12ff5bc: ldr             d0, [x17, #0xe60]
    // 0x12ff5c0: fcmp            d2, d0
    // 0x12ff5c4: b.le            #0x12ff5d0
    // 0x12ff5c8: r1 = 2
    //     0x12ff5c8: mov             x1, #2
    // 0x12ff5cc: b               #0x12ff5d4
    // 0x12ff5d0: r1 = 3
    //     0x12ff5d0: mov             x1, #3
    // 0x12ff5d4: ldur            x0, [fp, #-8]
    // 0x12ff5d8: d3 = 1.000000
    //     0x12ff5d8: fmov            d3, #1.00000000
    // 0x12ff5dc: d1 = 8.000000
    //     0x12ff5dc: fmov            d1, #8.00000000
    // 0x12ff5e0: d0 = 0.000000
    //     0x12ff5e0: eor             v0.16b, v0.16b, v0.16b
    // 0x12ff5e4: stur            x1, [fp, #-0x10]
    // 0x12ff5e8: LoadField: d4 = r0->field_33
    //     0x12ff5e8: ldur            d4, [x0, #0x33]
    // 0x12ff5ec: sub             x2, x1, #1
    // 0x12ff5f0: scvtf           d5, x2
    // 0x12ff5f4: fmul            d6, d5, d1
    // 0x12ff5f8: fsub            d5, d4, d6
    // 0x12ff5fc: scvtf           d4, x1
    // 0x12ff600: fdiv            d6, d5, d4
    // 0x12ff604: fmax            v4.2d, v6.2d, v0.2d
    // 0x12ff608: stur            d4, [fp, #-0x28]
    // 0x12ff60c: fcmp            d2, d3
    // 0x12ff610: b.le            #0x12ff634
    // 0x12ff614: d5 = 9.000000
    //     0x12ff614: fmov            d5, #9.00000000
    // 0x12ff618: d0 = 52.000000
    //     0x12ff618: add             x17, PP, #0x22, lsl #12  ; [pp+0x22108] IMM: double(52) from 0x404a000000000000
    //     0x12ff61c: ldr             d0, [x17, #0x108]
    // 0x12ff620: fsub            d6, d2, d3
    // 0x12ff624: fmul            d2, d6, d5
    // 0x12ff628: fadd            d3, d2, d0
    // 0x12ff62c: mov             v0.16b, v3.16b
    // 0x12ff630: b               #0x12ff63c
    // 0x12ff634: d0 = 52.000000
    //     0x12ff634: add             x17, PP, #0x22, lsl #12  ; [pp+0x22108] IMM: double(52) from 0x404a000000000000
    //     0x12ff638: ldr             d0, [x17, #0x108]
    // 0x12ff63c: stur            d0, [fp, #-0x20]
    // 0x12ff640: fadd            d2, d4, d1
    // 0x12ff644: stur            d2, [fp, #-0x18]
    // 0x12ff648: LoadField: r2 = r0->field_3b
    //     0x12ff648: ldur            w2, [x0, #0x3b]
    // 0x12ff64c: DecompressPointer r2
    //     0x12ff64c: add             x2, x2, HEAP, lsl #32
    // 0x12ff650: r16 = Instance_AxisDirection
    //     0x12ff650: ldr             x16, [PP, #0x5ce8]  ; [pp+0x5ce8] Obj!AxisDirection@12c4a01
    // 0x12ff654: cmp             w2, w16
    // 0x12ff658: b.eq            #0x12ff668
    // 0x12ff65c: r16 = Instance_AxisDirection
    //     0x12ff65c: ldr             x16, [PP, #0x5cf8]  ; [pp+0x5cf8] Obj!AxisDirection@12c49c1
    // 0x12ff660: cmp             w2, w16
    // 0x12ff664: b.ne            #0x12ff670
    // 0x12ff668: r0 = true
    //     0x12ff668: add             x0, NULL, #0x20  ; true
    // 0x12ff66c: b               #0x12ff694
    // 0x12ff670: r16 = Instance_AxisDirection
    //     0x12ff670: ldr             x16, [PP, #0x5cf0]  ; [pp+0x5cf0] Obj!AxisDirection@12c49e1
    // 0x12ff674: cmp             w2, w16
    // 0x12ff678: b.eq            #0x12ff688
    // 0x12ff67c: r16 = Instance_AxisDirection
    //     0x12ff67c: ldr             x16, [PP, #0x5d00]  ; [pp+0x5d00] Obj!AxisDirection@12c49a1
    // 0x12ff680: cmp             w2, w16
    // 0x12ff684: b.ne            #0x12ff690
    // 0x12ff688: r0 = false
    //     0x12ff688: add             x0, NULL, #0x30  ; false
    // 0x12ff68c: b               #0x12ff694
    // 0x12ff690: r0 = Null
    //     0x12ff690: mov             x0, NULL
    // 0x12ff694: stur            x0, [fp, #-8]
    // 0x12ff698: r0 = SliverGridRegularTileLayout()
    //     0x12ff698: bl              #0x12ff528  ; AllocateSliverGridRegularTileLayoutStub -> SliverGridRegularTileLayout (size=0x34)
    // 0x12ff69c: ldur            x1, [fp, #-0x10]
    // 0x12ff6a0: StoreField: r0->field_7 = r1
    //     0x12ff6a0: stur            x1, [x0, #7]
    // 0x12ff6a4: ldur            d0, [fp, #-0x20]
    // 0x12ff6a8: StoreField: r0->field_f = d0
    //     0x12ff6a8: stur            d0, [x0, #0xf]
    // 0x12ff6ac: ldur            d1, [fp, #-0x18]
    // 0x12ff6b0: ArrayStore: r0[0] = d1  ; List_8
    //     0x12ff6b0: stur            d1, [x0, #0x17]
    // 0x12ff6b4: StoreField: r0->field_1f = d0
    //     0x12ff6b4: stur            d0, [x0, #0x1f]
    // 0x12ff6b8: ldur            d0, [fp, #-0x28]
    // 0x12ff6bc: StoreField: r0->field_27 = d0
    //     0x12ff6bc: stur            d0, [x0, #0x27]
    // 0x12ff6c0: ldur            x1, [fp, #-8]
    // 0x12ff6c4: StoreField: r0->field_2f = r1
    //     0x12ff6c4: stur            w1, [x0, #0x2f]
    // 0x12ff6c8: LeaveFrame
    //     0x12ff6c8: mov             SP, fp
    //     0x12ff6cc: ldp             fp, lr, [SP], #0x10
    // 0x12ff6d0: ret
    //     0x12ff6d0: ret             
    // 0x12ff6d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12ff6d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12ff6d8: b               #0x12ff550
  }
}

// class id: 3122, size: 0xc, field offset: 0x8
//   const constructor, 
class _DayPickerGridDelegate extends SliverGridDelegate {

  _ getLayout(/* No info */) {
    // ** addr: 0x12ff374, size: 0x1b4
    // 0x12ff374: EnterFrame
    //     0x12ff374: stp             fp, lr, [SP, #-0x10]!
    //     0x12ff378: mov             fp, SP
    // 0x12ff37c: AllocStack(0x20)
    //     0x12ff37c: sub             SP, SP, #0x20
    // 0x12ff380: SetupParameters(dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x12ff380: stur            x2, [fp, #-0x10]
    // 0x12ff384: CheckStackOverflow
    //     0x12ff384: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12ff388: cmp             SP, x16
    //     0x12ff38c: b.ls            #0x12ff520
    // 0x12ff390: LoadField: r0 = r1->field_7
    //     0x12ff390: ldur            w0, [x1, #7]
    // 0x12ff394: DecompressPointer r0
    //     0x12ff394: add             x0, x0, HEAP, lsl #32
    // 0x12ff398: mov             x1, x0
    // 0x12ff39c: stur            x0, [fp, #-8]
    // 0x12ff3a0: r0 = textScalerOf()
    //     0x12ff3a0: bl              #0xd16168  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::textScalerOf
    // 0x12ff3a4: r1 = LoadClassIdInstr(r0)
    //     0x12ff3a4: ldur            x1, [x0, #-1]
    //     0x12ff3a8: ubfx            x1, x1, #0xc, #0x14
    // 0x12ff3ac: mov             x16, x0
    // 0x12ff3b0: mov             x0, x1
    // 0x12ff3b4: mov             x1, x16
    // 0x12ff3b8: d0 = 3.000000
    //     0x12ff3b8: fmov            d0, #3.00000000
    // 0x12ff3bc: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x12ff3bc: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x12ff3c0: r0 = GDT[cid_x0 + -0xffa]()
    //     0x12ff3c0: sub             lr, x0, #0xffa
    //     0x12ff3c4: ldr             lr, [x21, lr, lsl #3]
    //     0x12ff3c8: blr             lr
    // 0x12ff3cc: r1 = LoadClassIdInstr(r0)
    //     0x12ff3cc: ldur            x1, [x0, #-1]
    //     0x12ff3d0: ubfx            x1, x1, #0xc, #0x14
    // 0x12ff3d4: mov             x16, x0
    // 0x12ff3d8: mov             x0, x1
    // 0x12ff3dc: mov             x1, x16
    // 0x12ff3e0: d0 = 14.000000
    //     0x12ff3e0: fmov            d0, #14.00000000
    // 0x12ff3e4: r0 = GDT[cid_x0 + -0x1000]()
    //     0x12ff3e4: sub             lr, x0, #1, lsl #12
    //     0x12ff3e8: ldr             lr, [x21, lr, lsl #3]
    //     0x12ff3ec: blr             lr
    // 0x12ff3f0: LoadField: d0 = r0->field_7
    //     0x12ff3f0: ldur            d0, [x0, #7]
    // 0x12ff3f4: d1 = 14.000000
    //     0x12ff3f4: fmov            d1, #14.00000000
    // 0x12ff3f8: fdiv            d2, d0, d1
    // 0x12ff3fc: ldur            x1, [fp, #-8]
    // 0x12ff400: stur            d2, [fp, #-0x18]
    // 0x12ff404: r0 = orientationOf()
    //     0x12ff404: bl              #0xd172a4  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::orientationOf
    // 0x12ff408: ldur            x1, [fp, #-8]
    // 0x12ff40c: stur            x0, [fp, #-8]
    // 0x12ff410: r0 = of()
    //     0x12ff410: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x12ff414: LoadField: r1 = r0->field_2f
    //     0x12ff414: ldur            w1, [x0, #0x2f]
    // 0x12ff418: DecompressPointer r1
    //     0x12ff418: add             x1, x1, HEAP, lsl #32
    // 0x12ff41c: tbnz            w1, #4, #0x12ff43c
    // 0x12ff420: ldur            x0, [fp, #-8]
    // 0x12ff424: r16 = Instance_Orientation
    //     0x12ff424: add             x16, PP, #0x14, lsl #12  ; [pp+0x143c8] Obj!Orientation@12c2ec1
    //     0x12ff428: ldr             x16, [x16, #0x3c8]
    // 0x12ff42c: cmp             w0, w16
    // 0x12ff430: b.ne            #0x12ff43c
    // 0x12ff434: d2 = 48.000000
    //     0x12ff434: ldr             d2, [PP, #0x5650]  ; [pp+0x5650] IMM: double(48) from 0x4048000000000000
    // 0x12ff438: b               #0x12ff444
    // 0x12ff43c: d2 = 42.000000
    //     0x12ff43c: add             x17, PP, #0x13, lsl #12  ; [pp+0x131f8] IMM: double(42) from 0x4045000000000000
    //     0x12ff440: ldr             d2, [x17, #0x1f8]
    // 0x12ff444: ldur            d0, [fp, #-0x18]
    // 0x12ff448: d1 = 1.300000
    //     0x12ff448: add             x17, PP, #0x1f, lsl #12  ; [pp+0x1f200] IMM: double(1.3) from 0x3ff4cccccccccccd
    //     0x12ff44c: ldr             d1, [x17, #0x200]
    // 0x12ff450: fcmp            d0, d1
    // 0x12ff454: b.le            #0x12ff470
    // 0x12ff458: d3 = 1.000000
    //     0x12ff458: fmov            d3, #1.00000000
    // 0x12ff45c: d1 = 30.000000
    //     0x12ff45c: fmov            d1, #30.00000000
    // 0x12ff460: fsub            d4, d0, d3
    // 0x12ff464: fmul            d0, d4, d1
    // 0x12ff468: fadd            d1, d0, d2
    // 0x12ff46c: b               #0x12ff474
    // 0x12ff470: mov             v1.16b, v2.16b
    // 0x12ff474: ldur            x0, [fp, #-0x10]
    // 0x12ff478: d0 = 7.000000
    //     0x12ff478: fmov            d0, #7.00000000
    // 0x12ff47c: LoadField: d2 = r0->field_33
    //     0x12ff47c: ldur            d2, [x0, #0x33]
    // 0x12ff480: fdiv            d3, d2, d0
    // 0x12ff484: stur            d3, [fp, #-0x20]
    // 0x12ff488: LoadField: d2 = r0->field_3f
    //     0x12ff488: ldur            d2, [x0, #0x3f]
    // 0x12ff48c: fdiv            d4, d2, d0
    // 0x12ff490: fmin            v0.2d, v1.2d, v4.2d
    // 0x12ff494: stur            d0, [fp, #-0x18]
    // 0x12ff498: LoadField: r1 = r0->field_3b
    //     0x12ff498: ldur            w1, [x0, #0x3b]
    // 0x12ff49c: DecompressPointer r1
    //     0x12ff49c: add             x1, x1, HEAP, lsl #32
    // 0x12ff4a0: r16 = Instance_AxisDirection
    //     0x12ff4a0: ldr             x16, [PP, #0x5ce8]  ; [pp+0x5ce8] Obj!AxisDirection@12c4a01
    // 0x12ff4a4: cmp             w1, w16
    // 0x12ff4a8: b.eq            #0x12ff4b8
    // 0x12ff4ac: r16 = Instance_AxisDirection
    //     0x12ff4ac: ldr             x16, [PP, #0x5cf8]  ; [pp+0x5cf8] Obj!AxisDirection@12c49c1
    // 0x12ff4b0: cmp             w1, w16
    // 0x12ff4b4: b.ne            #0x12ff4c0
    // 0x12ff4b8: r0 = true
    //     0x12ff4b8: add             x0, NULL, #0x20  ; true
    // 0x12ff4bc: b               #0x12ff4e4
    // 0x12ff4c0: r16 = Instance_AxisDirection
    //     0x12ff4c0: ldr             x16, [PP, #0x5cf0]  ; [pp+0x5cf0] Obj!AxisDirection@12c49e1
    // 0x12ff4c4: cmp             w1, w16
    // 0x12ff4c8: b.eq            #0x12ff4d8
    // 0x12ff4cc: r16 = Instance_AxisDirection
    //     0x12ff4cc: ldr             x16, [PP, #0x5d00]  ; [pp+0x5d00] Obj!AxisDirection@12c49a1
    // 0x12ff4d0: cmp             w1, w16
    // 0x12ff4d4: b.ne            #0x12ff4e0
    // 0x12ff4d8: r0 = false
    //     0x12ff4d8: add             x0, NULL, #0x30  ; false
    // 0x12ff4dc: b               #0x12ff4e4
    // 0x12ff4e0: r0 = Null
    //     0x12ff4e0: mov             x0, NULL
    // 0x12ff4e4: stur            x0, [fp, #-8]
    // 0x12ff4e8: r0 = SliverGridRegularTileLayout()
    //     0x12ff4e8: bl              #0x12ff528  ; AllocateSliverGridRegularTileLayoutStub -> SliverGridRegularTileLayout (size=0x34)
    // 0x12ff4ec: r1 = 7
    //     0x12ff4ec: mov             x1, #7
    // 0x12ff4f0: StoreField: r0->field_7 = r1
    //     0x12ff4f0: stur            x1, [x0, #7]
    // 0x12ff4f4: ldur            d0, [fp, #-0x18]
    // 0x12ff4f8: StoreField: r0->field_f = d0
    //     0x12ff4f8: stur            d0, [x0, #0xf]
    // 0x12ff4fc: ldur            d1, [fp, #-0x20]
    // 0x12ff500: ArrayStore: r0[0] = d1  ; List_8
    //     0x12ff500: stur            d1, [x0, #0x17]
    // 0x12ff504: StoreField: r0->field_1f = d0
    //     0x12ff504: stur            d0, [x0, #0x1f]
    // 0x12ff508: StoreField: r0->field_27 = d1
    //     0x12ff508: stur            d1, [x0, #0x27]
    // 0x12ff50c: ldur            x1, [fp, #-8]
    // 0x12ff510: StoreField: r0->field_2f = r1
    //     0x12ff510: stur            w1, [x0, #0x2f]
    // 0x12ff514: LeaveFrame
    //     0x12ff514: mov             SP, fp
    //     0x12ff518: ldp             fp, lr, [SP], #0x10
    // 0x12ff51c: ret
    //     0x12ff51c: ret             
    // 0x12ff520: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12ff520: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12ff524: b               #0x12ff390
  }
}

// class id: 5472, size: 0x1c, field offset: 0x14
class _YearPickerState extends State<dynamic> {

  [closure] Y0? <anonymous closure>(dynamic, DatePickerThemeData?) {
    // ** addr: 0xdf34e0, size: 0x9c
    // 0xdf34e0: EnterFrame
    //     0xdf34e0: stp             fp, lr, [SP, #-0x10]!
    //     0xdf34e4: mov             fp, SP
    // 0xdf34e8: AllocStack(0x18)
    //     0xdf34e8: sub             SP, SP, #0x18
    // 0xdf34ec: SetupParameters([dynamic _ /* r0 */])
    //     0xdf34ec: ldr             x0, [fp, #0x18]
    //     0xdf34f0: ldur            w1, [x0, #0x17]
    //     0xdf34f4: add             x1, x1, HEAP, lsl #32
    //     0xdf34f8: stur            x1, [fp, #-8]
    // 0xdf34fc: CheckStackOverflow
    //     0xdf34fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf3500: cmp             SP, x16
    //     0xdf3504: b.ls            #0xdf3574
    // 0xdf3508: LoadField: r0 = r1->field_f
    //     0xdf3508: ldur            w0, [x1, #0xf]
    // 0xdf350c: DecompressPointer r0
    //     0xdf350c: add             x0, x0, HEAP, lsl #32
    // 0xdf3510: ldr             x16, [fp, #0x10]
    // 0xdf3514: stp             x16, x0, [SP]
    // 0xdf3518: ClosureCall
    //     0xdf3518: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xdf351c: ldur            x2, [x0, #0x1f]
    //     0xdf3520: blr             x2
    // 0xdf3524: cmp             w0, NULL
    // 0xdf3528: b.ne            #0xdf3534
    // 0xdf352c: r0 = Null
    //     0xdf352c: mov             x0, NULL
    // 0xdf3530: b               #0xdf3568
    // 0xdf3534: ldur            x1, [fp, #-8]
    // 0xdf3538: LoadField: r2 = r1->field_13
    //     0xdf3538: ldur            w2, [x1, #0x13]
    // 0xdf353c: DecompressPointer r2
    //     0xdf353c: add             x2, x2, HEAP, lsl #32
    // 0xdf3540: r1 = LoadClassIdInstr(r0)
    //     0xdf3540: ldur            x1, [x0, #-1]
    //     0xdf3544: ubfx            x1, x1, #0xc, #0x14
    // 0xdf3548: mov             x16, x0
    // 0xdf354c: mov             x0, x1
    // 0xdf3550: mov             x1, x16
    // 0xdf3554: r0 = GDT[cid_x0 + 0x17c77]()
    //     0xdf3554: mov             x17, #0x7c77
    //     0xdf3558: movk            x17, #1, lsl #16
    //     0xdf355c: add             lr, x0, x17
    //     0xdf3560: ldr             lr, [x21, lr, lsl #3]
    //     0xdf3564: blr             lr
    // 0xdf3568: LeaveFrame
    //     0xdf3568: mov             SP, fp
    //     0xdf356c: ldp             fp, lr, [SP], #0x10
    // 0xdf3570: ret
    //     0xdf3570: ret             
    // 0xdf3574: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf3574: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf3578: b               #0xdf3508
  }
  [closure] Y0? resolve<Y0>(dynamic, (dynamic, DatePickerThemeData?) => WidgetStateProperty<Y0>?, Set<WidgetState>) {
    // ** addr: 0xdf357c, size: 0xe8
    // 0xdf357c: EnterFrame
    //     0xdf357c: stp             fp, lr, [SP, #-0x10]!
    //     0xdf3580: mov             fp, SP
    // 0xdf3584: AllocStack(0x30)
    //     0xdf3584: sub             SP, SP, #0x30
    // 0xdf3588: SetupParameters([dynamic _ /* r0 */])
    //     0xdf3588: ldr             x0, [fp, #0x20]
    //     0xdf358c: ldur            w1, [x0, #0x17]
    //     0xdf3590: add             x1, x1, HEAP, lsl #32
    //     0xdf3594: stur            x1, [fp, #-0x10]
    // 0xdf3598: LoadField: r2 = r4->field_f
    //     0xdf3598: ldur            w2, [x4, #0xf]
    // 0xdf359c: cbnz            w2, #0xdf35a8
    // 0xdf35a0: r2 = Null
    //     0xdf35a0: mov             x2, NULL
    // 0xdf35a4: b               #0xdf35b8
    // 0xdf35a8: ArrayLoad: r2 = r4[0]  ; List_4
    //     0xdf35a8: ldur            w2, [x4, #0x17]
    // 0xdf35ac: add             x3, fp, w2, sxtw #2
    // 0xdf35b0: ldr             x3, [x3, #0x10]
    // 0xdf35b4: mov             x2, x3
    // 0xdf35b8: LoadField: r3 = r0->field_f
    //     0xdf35b8: ldur            w3, [x0, #0xf]
    // 0xdf35bc: DecompressPointer r3
    //     0xdf35bc: add             x3, x3, HEAP, lsl #32
    // 0xdf35c0: ldr             x16, [THR, #0xb0]  ; THR::empty_type_arguments
    // 0xdf35c4: cmp             w3, w16
    // 0xdf35c8: b.ne            #0xdf35d0
    // 0xdf35cc: mov             x3, x2
    // 0xdf35d0: ldr             x2, [fp, #0x18]
    // 0xdf35d4: ldr             x0, [fp, #0x10]
    // 0xdf35d8: stur            x3, [fp, #-8]
    // 0xdf35dc: CheckStackOverflow
    //     0xdf35dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf35e0: cmp             SP, x16
    //     0xdf35e4: b.ls            #0xdf365c
    // 0xdf35e8: r1 = 2
    //     0xdf35e8: mov             x1, #2
    // 0xdf35ec: r0 = AllocateContext()
    //     0xdf35ec: bl              #0x13de838  ; AllocateContextStub
    // 0xdf35f0: mov             x1, x0
    // 0xdf35f4: ldur            x0, [fp, #-0x10]
    // 0xdf35f8: StoreField: r1->field_b = r0
    //     0xdf35f8: stur            w0, [x1, #0xb]
    // 0xdf35fc: ldr             x2, [fp, #0x18]
    // 0xdf3600: StoreField: r1->field_f = r2
    //     0xdf3600: stur            w2, [x1, #0xf]
    // 0xdf3604: ldr             x2, [fp, #0x10]
    // 0xdf3608: StoreField: r1->field_13 = r2
    //     0xdf3608: stur            w2, [x1, #0x13]
    // 0xdf360c: LoadField: r3 = r0->field_1b
    //     0xdf360c: ldur            w3, [x0, #0x1b]
    // 0xdf3610: DecompressPointer r3
    //     0xdf3610: add             x3, x3, HEAP, lsl #32
    // 0xdf3614: mov             x2, x1
    // 0xdf3618: stur            x3, [fp, #-0x18]
    // 0xdf361c: r1 = Function '<anonymous closure>':.
    //     0xdf361c: add             x1, PP, #0xd0, lsl #12  ; [pp+0xd06a0] AnonymousClosure: (0xdf34e0), in [package:flutter/src/material/calendar_date_picker.dart] _YearPickerState::_buildYearItem (0xdf3664)
    //     0xdf3620: ldr             x1, [x1, #0x6a0]
    // 0xdf3624: r0 = AllocateClosure()
    //     0xdf3624: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf3628: mov             x1, x0
    // 0xdf362c: ldur            x0, [fp, #-8]
    // 0xdf3630: StoreField: r1->field_b = r0
    //     0xdf3630: stur            w0, [x1, #0xb]
    // 0xdf3634: ldur            x16, [fp, #-0x18]
    // 0xdf3638: stp             x16, x0, [SP, #8]
    // 0xdf363c: str             x1, [SP]
    // 0xdf3640: ldur            x0, [fp, #-0x18]
    // 0xdf3644: ClosureCall
    //     0xdf3644: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0xdf3648: ldur            x2, [x0, #0x1f]
    //     0xdf364c: blr             x2
    // 0xdf3650: LeaveFrame
    //     0xdf3650: mov             SP, fp
    //     0xdf3654: ldp             fp, lr, [SP], #0x10
    // 0xdf3658: ret
    //     0xdf3658: ret             
    // 0xdf365c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf365c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf3660: b               #0xdf35e8
  }
  _ _buildYearItem(/* No info */) {
    // ** addr: 0xdf3664, size: 0xca4
    // 0xdf3664: EnterFrame
    //     0xdf3664: stp             fp, lr, [SP, #-0x10]!
    //     0xdf3668: mov             fp, SP
    // 0xdf366c: AllocStack(0xb0)
    //     0xdf366c: sub             SP, SP, #0xb0
    // 0xdf3670: SetupParameters(_YearPickerState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xdf3670: mov             x0, x1
    //     0xdf3674: stur            x1, [fp, #-8]
    //     0xdf3678: mov             x1, x2
    //     0xdf367c: stur            x2, [fp, #-0x10]
    //     0xdf3680: stur            x3, [fp, #-0x18]
    // 0xdf3684: CheckStackOverflow
    //     0xdf3684: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf3688: cmp             SP, x16
    //     0xdf368c: b.ls            #0xdf4278
    // 0xdf3690: r1 = 6
    //     0xdf3690: mov             x1, #6
    // 0xdf3694: r0 = AllocateContext()
    //     0xdf3694: bl              #0x13de838  ; AllocateContextStub
    // 0xdf3698: mov             x2, x0
    // 0xdf369c: ldur            x0, [fp, #-8]
    // 0xdf36a0: stur            x2, [fp, #-0x20]
    // 0xdf36a4: StoreField: r2->field_f = r0
    //     0xdf36a4: stur            w0, [x2, #0xf]
    // 0xdf36a8: ldur            x1, [fp, #-0x10]
    // 0xdf36ac: r0 = of()
    //     0xdf36ac: bl              #0xd0ff6c  ; [package:flutter/src/material/date_picker_theme.dart] DatePickerTheme::of
    // 0xdf36b0: ldur            x2, [fp, #-0x20]
    // 0xdf36b4: StoreField: r2->field_13 = r0
    //     0xdf36b4: stur            w0, [x2, #0x13]
    //     0xdf36b8: ldurb           w16, [x2, #-1]
    //     0xdf36bc: ldurb           w17, [x0, #-1]
    //     0xdf36c0: and             x16, x17, x16, lsr #2
    //     0xdf36c4: tst             x16, HEAP, lsr #32
    //     0xdf36c8: b.eq            #0xdf36d0
    //     0xdf36cc: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xdf36d0: ldur            x1, [fp, #-0x10]
    // 0xdf36d4: r0 = defaults()
    //     0xdf36d4: bl              #0xd0fd74  ; [package:flutter/src/material/date_picker_theme.dart] DatePickerTheme::defaults
    // 0xdf36d8: mov             x4, x0
    // 0xdf36dc: ldur            x3, [fp, #-0x20]
    // 0xdf36e0: stur            x4, [fp, #-0x28]
    // 0xdf36e4: ArrayStore: r3[0] = r0  ; List_4
    //     0xdf36e4: stur            w0, [x3, #0x17]
    //     0xdf36e8: ldurb           w16, [x3, #-1]
    //     0xdf36ec: ldurb           w17, [x0, #-1]
    //     0xdf36f0: and             x16, x17, x16, lsr #2
    //     0xdf36f4: tst             x16, HEAP, lsr #32
    //     0xdf36f8: b.eq            #0xdf3700
    //     0xdf36fc: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xdf3700: mov             x2, x3
    // 0xdf3704: r1 = Function 'effectiveValue':.
    //     0xdf3704: add             x1, PP, #0xd0, lsl #12  ; [pp+0xd0650] AnonymousClosure: (0xdf4aa8), in [package:flutter/src/material/calendar_date_picker.dart] _YearPickerState::_buildYearItem (0xdf3664)
    //     0xdf3708: ldr             x1, [x1, #0x650]
    // 0xdf370c: r0 = AllocateClosureGeneric()
    //     0xdf370c: bl              #0x13deb28  ; AllocateClosureGenericStub
    // 0xdf3710: ldur            x3, [fp, #-0x20]
    // 0xdf3714: StoreField: r3->field_1b = r0
    //     0xdf3714: stur            w0, [x3, #0x1b]
    //     0xdf3718: ldurb           w16, [x3, #-1]
    //     0xdf371c: ldurb           w17, [x0, #-1]
    //     0xdf3720: and             x16, x17, x16, lsr #2
    //     0xdf3724: tst             x16, HEAP, lsr #32
    //     0xdf3728: b.eq            #0xdf3730
    //     0xdf372c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xdf3730: mov             x2, x3
    // 0xdf3734: r1 = Function 'resolve':.
    //     0xdf3734: add             x1, PP, #0xd0, lsl #12  ; [pp+0xd0658] AnonymousClosure: (0xdf357c), in [package:flutter/src/material/calendar_date_picker.dart] _YearPickerState::_buildYearItem (0xdf3664)
    //     0xdf3738: ldr             x1, [x1, #0x658]
    // 0xdf373c: r0 = AllocateClosureGeneric()
    //     0xdf373c: bl              #0x13deb28  ; AllocateClosureGenericStub
    // 0xdf3740: ldur            x1, [fp, #-0x10]
    // 0xdf3744: stur            x0, [fp, #-0x30]
    // 0xdf3748: r0 = textScalerOf()
    //     0xdf3748: bl              #0xd16168  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::textScalerOf
    // 0xdf374c: r1 = LoadClassIdInstr(r0)
    //     0xdf374c: ldur            x1, [x0, #-1]
    //     0xdf3750: ubfx            x1, x1, #0xc, #0x14
    // 0xdf3754: mov             x16, x0
    // 0xdf3758: mov             x0, x1
    // 0xdf375c: mov             x1, x16
    // 0xdf3760: d0 = 3.000000
    //     0xdf3760: fmov            d0, #3.00000000
    // 0xdf3764: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xdf3764: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xdf3768: r0 = GDT[cid_x0 + -0xffa]()
    //     0xdf3768: sub             lr, x0, #0xffa
    //     0xdf376c: ldr             lr, [x21, lr, lsl #3]
    //     0xdf3770: blr             lr
    // 0xdf3774: r1 = LoadClassIdInstr(r0)
    //     0xdf3774: ldur            x1, [x0, #-1]
    //     0xdf3778: ubfx            x1, x1, #0xc, #0x14
    // 0xdf377c: mov             x16, x0
    // 0xdf3780: mov             x0, x1
    // 0xdf3784: mov             x1, x16
    // 0xdf3788: d0 = 14.000000
    //     0xdf3788: fmov            d0, #14.00000000
    // 0xdf378c: r0 = GDT[cid_x0 + -0x1000]()
    //     0xdf378c: sub             lr, x0, #1, lsl #12
    //     0xdf3790: ldr             lr, [x21, lr, lsl #3]
    //     0xdf3794: blr             lr
    // 0xdf3798: LoadField: d0 = r0->field_7
    //     0xdf3798: ldur            d0, [x0, #7]
    // 0xdf379c: d1 = 14.000000
    //     0xdf379c: fmov            d1, #14.00000000
    // 0xdf37a0: fdiv            d2, d0, d1
    // 0xdf37a4: ldur            x1, [fp, #-8]
    // 0xdf37a8: stur            d2, [fp, #-0x78]
    // 0xdf37ac: r0 = _itemCount()
    //     0xdf37ac: bl              #0xdf4308  ; [package:flutter/src/material/calendar_date_picker.dart] _YearPickerState::_itemCount
    // 0xdf37b0: cmp             x0, #0x12
    // 0xdf37b4: b.ge            #0xdf37dc
    // 0xdf37b8: ldur            x1, [fp, #-8]
    // 0xdf37bc: r0 = _itemCount()
    //     0xdf37bc: bl              #0xdf4308  ; [package:flutter/src/material/calendar_date_picker.dart] _YearPickerState::_itemCount
    // 0xdf37c0: mov             x1, x0
    // 0xdf37c4: r0 = 18
    //     0xdf37c4: mov             x0, #0x12
    // 0xdf37c8: sub             x2, x0, x1
    // 0xdf37cc: r0 = 2
    //     0xdf37cc: mov             x0, #2
    // 0xdf37d0: sdiv            x1, x2, x0
    // 0xdf37d4: mov             x4, x1
    // 0xdf37d8: b               #0xdf37e0
    // 0xdf37dc: r4 = 0
    //     0xdf37dc: mov             x4, #0
    // 0xdf37e0: ldur            x0, [fp, #-8]
    // 0xdf37e4: ldur            x3, [fp, #-0x18]
    // 0xdf37e8: ldur            x2, [fp, #-0x20]
    // 0xdf37ec: stur            x4, [fp, #-0x38]
    // 0xdf37f0: LoadField: r1 = r0->field_b
    //     0xdf37f0: ldur            w1, [x0, #0xb]
    // 0xdf37f4: DecompressPointer r1
    //     0xdf37f4: add             x1, x1, HEAP, lsl #32
    // 0xdf37f8: cmp             w1, NULL
    // 0xdf37fc: b.eq            #0xdf4280
    // 0xdf3800: LoadField: r5 = r1->field_f
    //     0xdf3800: ldur            w5, [x1, #0xf]
    // 0xdf3804: DecompressPointer r5
    //     0xdf3804: add             x5, x5, HEAP, lsl #32
    // 0xdf3808: mov             x1, x5
    // 0xdf380c: r0 = _parts()
    //     0xdf380c: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xdf3810: mov             x2, x0
    // 0xdf3814: LoadField: r0 = r2->field_b
    //     0xdf3814: ldur            w0, [x2, #0xb]
    // 0xdf3818: r1 = LoadInt32Instr(r0)
    //     0xdf3818: sbfx            x1, x0, #1, #0x1f
    // 0xdf381c: mov             x0, x1
    // 0xdf3820: r1 = 8
    //     0xdf3820: mov             x1, #8
    // 0xdf3824: cmp             x1, x0
    // 0xdf3828: b.hs            #0xdf4284
    // 0xdf382c: LoadField: r0 = r2->field_2f
    //     0xdf382c: ldur            w0, [x2, #0x2f]
    // 0xdf3830: DecompressPointer r0
    //     0xdf3830: add             x0, x0, HEAP, lsl #32
    // 0xdf3834: ldur            x1, [fp, #-0x18]
    // 0xdf3838: r2 = LoadInt32Instr(r1)
    //     0xdf3838: sbfx            x2, x1, #1, #0x1f
    //     0xdf383c: tbz             w1, #0, #0xdf3844
    //     0xdf3840: ldur            x2, [x1, #7]
    // 0xdf3844: r1 = LoadInt32Instr(r0)
    //     0xdf3844: sbfx            x1, x0, #1, #0x1f
    //     0xdf3848: tbz             w0, #0, #0xdf3850
    //     0xdf384c: ldur            x1, [x0, #7]
    // 0xdf3850: add             x0, x1, x2
    // 0xdf3854: ldur            x1, [fp, #-0x38]
    // 0xdf3858: sub             x2, x0, x1
    // 0xdf385c: ldur            x0, [fp, #-8]
    // 0xdf3860: stur            x2, [fp, #-0x40]
    // 0xdf3864: LoadField: r1 = r0->field_b
    //     0xdf3864: ldur            w1, [x0, #0xb]
    // 0xdf3868: DecompressPointer r1
    //     0xdf3868: add             x1, x1, HEAP, lsl #32
    // 0xdf386c: cmp             w1, NULL
    // 0xdf3870: b.eq            #0xdf4288
    // 0xdf3874: ArrayLoad: r3 = r1[0]  ; List_4
    //     0xdf3874: ldur            w3, [x1, #0x17]
    // 0xdf3878: DecompressPointer r3
    //     0xdf3878: add             x3, x3, HEAP, lsl #32
    // 0xdf387c: mov             x1, x3
    // 0xdf3880: r0 = _parts()
    //     0xdf3880: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xdf3884: mov             x2, x0
    // 0xdf3888: LoadField: r0 = r2->field_b
    //     0xdf3888: ldur            w0, [x2, #0xb]
    // 0xdf388c: r1 = LoadInt32Instr(r0)
    //     0xdf388c: sbfx            x1, x0, #1, #0x1f
    // 0xdf3890: mov             x0, x1
    // 0xdf3894: r1 = 8
    //     0xdf3894: mov             x1, #8
    // 0xdf3898: cmp             x1, x0
    // 0xdf389c: b.hs            #0xdf428c
    // 0xdf38a0: LoadField: r0 = r2->field_2f
    //     0xdf38a0: ldur            w0, [x2, #0x2f]
    // 0xdf38a4: DecompressPointer r0
    //     0xdf38a4: add             x0, x0, HEAP, lsl #32
    // 0xdf38a8: r1 = LoadInt32Instr(r0)
    //     0xdf38a8: sbfx            x1, x0, #1, #0x1f
    //     0xdf38ac: tbz             w0, #0, #0xdf38b4
    //     0xdf38b0: ldur            x1, [x0, #7]
    // 0xdf38b4: ldur            x2, [fp, #-0x40]
    // 0xdf38b8: cmp             x2, x1
    // 0xdf38bc: r16 = true
    //     0xdf38bc: add             x16, NULL, #0x20  ; true
    // 0xdf38c0: r17 = false
    //     0xdf38c0: add             x17, NULL, #0x30  ; false
    // 0xdf38c4: csel            x0, x16, x17, eq
    // 0xdf38c8: ldur            x3, [fp, #-8]
    // 0xdf38cc: stur            x0, [fp, #-0x18]
    // 0xdf38d0: LoadField: r1 = r3->field_b
    //     0xdf38d0: ldur            w1, [x3, #0xb]
    // 0xdf38d4: DecompressPointer r1
    //     0xdf38d4: add             x1, x1, HEAP, lsl #32
    // 0xdf38d8: cmp             w1, NULL
    // 0xdf38dc: b.eq            #0xdf4290
    // 0xdf38e0: LoadField: r4 = r1->field_b
    //     0xdf38e0: ldur            w4, [x1, #0xb]
    // 0xdf38e4: DecompressPointer r4
    //     0xdf38e4: add             x4, x4, HEAP, lsl #32
    // 0xdf38e8: mov             x1, x4
    // 0xdf38ec: r0 = _parts()
    //     0xdf38ec: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xdf38f0: mov             x2, x0
    // 0xdf38f4: LoadField: r0 = r2->field_b
    //     0xdf38f4: ldur            w0, [x2, #0xb]
    // 0xdf38f8: r1 = LoadInt32Instr(r0)
    //     0xdf38f8: sbfx            x1, x0, #1, #0x1f
    // 0xdf38fc: mov             x0, x1
    // 0xdf3900: r1 = 8
    //     0xdf3900: mov             x1, #8
    // 0xdf3904: cmp             x1, x0
    // 0xdf3908: b.hs            #0xdf4294
    // 0xdf390c: LoadField: r0 = r2->field_2f
    //     0xdf390c: ldur            w0, [x2, #0x2f]
    // 0xdf3910: DecompressPointer r0
    //     0xdf3910: add             x0, x0, HEAP, lsl #32
    // 0xdf3914: r1 = LoadInt32Instr(r0)
    //     0xdf3914: sbfx            x1, x0, #1, #0x1f
    //     0xdf3918: tbz             w0, #0, #0xdf3920
    //     0xdf391c: ldur            x1, [x0, #7]
    // 0xdf3920: ldur            x2, [fp, #-0x40]
    // 0xdf3924: cmp             x2, x1
    // 0xdf3928: r16 = true
    //     0xdf3928: add             x16, NULL, #0x20  ; true
    // 0xdf392c: r17 = false
    //     0xdf392c: add             x17, NULL, #0x30  ; false
    // 0xdf3930: csel            x0, x16, x17, eq
    // 0xdf3934: ldur            x3, [fp, #-0x20]
    // 0xdf3938: stur            x0, [fp, #-0x48]
    // 0xdf393c: StoreField: r3->field_1f = r0
    //     0xdf393c: stur            w0, [x3, #0x1f]
    // 0xdf3940: ldur            x4, [fp, #-8]
    // 0xdf3944: LoadField: r1 = r4->field_b
    //     0xdf3944: ldur            w1, [x4, #0xb]
    // 0xdf3948: DecompressPointer r1
    //     0xdf3948: add             x1, x1, HEAP, lsl #32
    // 0xdf394c: cmp             w1, NULL
    // 0xdf3950: b.eq            #0xdf4298
    // 0xdf3954: LoadField: r5 = r1->field_f
    //     0xdf3954: ldur            w5, [x1, #0xf]
    // 0xdf3958: DecompressPointer r5
    //     0xdf3958: add             x5, x5, HEAP, lsl #32
    // 0xdf395c: mov             x1, x5
    // 0xdf3960: r0 = _parts()
    //     0xdf3960: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xdf3964: mov             x2, x0
    // 0xdf3968: LoadField: r0 = r2->field_b
    //     0xdf3968: ldur            w0, [x2, #0xb]
    // 0xdf396c: r1 = LoadInt32Instr(r0)
    //     0xdf396c: sbfx            x1, x0, #1, #0x1f
    // 0xdf3970: mov             x0, x1
    // 0xdf3974: r1 = 8
    //     0xdf3974: mov             x1, #8
    // 0xdf3978: cmp             x1, x0
    // 0xdf397c: b.hs            #0xdf429c
    // 0xdf3980: LoadField: r0 = r2->field_2f
    //     0xdf3980: ldur            w0, [x2, #0x2f]
    // 0xdf3984: DecompressPointer r0
    //     0xdf3984: add             x0, x0, HEAP, lsl #32
    // 0xdf3988: r1 = LoadInt32Instr(r0)
    //     0xdf3988: sbfx            x1, x0, #1, #0x1f
    //     0xdf398c: tbz             w0, #0, #0xdf3994
    //     0xdf3990: ldur            x1, [x0, #7]
    // 0xdf3994: ldur            x2, [fp, #-0x40]
    // 0xdf3998: cmp             x2, x1
    // 0xdf399c: b.ge            #0xdf39a8
    // 0xdf39a0: r0 = true
    //     0xdf39a0: add             x0, NULL, #0x20  ; true
    // 0xdf39a4: b               #0xdf3a10
    // 0xdf39a8: ldur            x0, [fp, #-8]
    // 0xdf39ac: LoadField: r1 = r0->field_b
    //     0xdf39ac: ldur            w1, [x0, #0xb]
    // 0xdf39b0: DecompressPointer r1
    //     0xdf39b0: add             x1, x1, HEAP, lsl #32
    // 0xdf39b4: cmp             w1, NULL
    // 0xdf39b8: b.eq            #0xdf42a0
    // 0xdf39bc: LoadField: r3 = r1->field_13
    //     0xdf39bc: ldur            w3, [x1, #0x13]
    // 0xdf39c0: DecompressPointer r3
    //     0xdf39c0: add             x3, x3, HEAP, lsl #32
    // 0xdf39c4: mov             x1, x3
    // 0xdf39c8: r0 = _parts()
    //     0xdf39c8: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xdf39cc: mov             x2, x0
    // 0xdf39d0: LoadField: r0 = r2->field_b
    //     0xdf39d0: ldur            w0, [x2, #0xb]
    // 0xdf39d4: r1 = LoadInt32Instr(r0)
    //     0xdf39d4: sbfx            x1, x0, #1, #0x1f
    // 0xdf39d8: mov             x0, x1
    // 0xdf39dc: r1 = 8
    //     0xdf39dc: mov             x1, #8
    // 0xdf39e0: cmp             x1, x0
    // 0xdf39e4: b.hs            #0xdf42a4
    // 0xdf39e8: LoadField: r0 = r2->field_2f
    //     0xdf39e8: ldur            w0, [x2, #0x2f]
    // 0xdf39ec: DecompressPointer r0
    //     0xdf39ec: add             x0, x0, HEAP, lsl #32
    // 0xdf39f0: r1 = LoadInt32Instr(r0)
    //     0xdf39f0: sbfx            x1, x0, #1, #0x1f
    //     0xdf39f4: tbz             w0, #0, #0xdf39fc
    //     0xdf39f8: ldur            x1, [x0, #7]
    // 0xdf39fc: ldur            x2, [fp, #-0x40]
    // 0xdf3a00: cmp             x2, x1
    // 0xdf3a04: r16 = true
    //     0xdf3a04: add             x16, NULL, #0x20  ; true
    // 0xdf3a08: r17 = false
    //     0xdf3a08: add             x17, NULL, #0x30  ; false
    // 0xdf3a0c: csel            x0, x16, x17, gt
    // 0xdf3a10: ldur            d0, [fp, #-0x78]
    // 0xdf3a14: d2 = 36.000000
    //     0xdf3a14: add             x17, PP, #0x12, lsl #12  ; [pp+0x12ca0] IMM: double(36) from 0x4042000000000000
    //     0xdf3a18: ldr             d2, [x17, #0xca0]
    // 0xdf3a1c: d1 = 72.000000
    //     0xdf3a1c: add             x17, PP, #0x89, lsl #12  ; [pp+0x89030] IMM: double(72) from 0x4052000000000000
    //     0xdf3a20: ldr             d1, [x17, #0x30]
    // 0xdf3a24: stur            x0, [fp, #-0x50]
    // 0xdf3a28: fmul            d3, d0, d2
    // 0xdf3a2c: stur            d3, [fp, #-0x88]
    // 0xdf3a30: fmul            d2, d0, d1
    // 0xdf3a34: stur            d2, [fp, #-0x80]
    // 0xdf3a38: r1 = <WidgetState>
    //     0xdf3a38: add             x1, PP, #0x84, lsl #12  ; [pp+0x84a10] TypeArguments: <WidgetState>
    //     0xdf3a3c: ldr             x1, [x1, #0xa10]
    // 0xdf3a40: r0 = _Set()
    //     0xdf3a40: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0xdf3a44: mov             x3, x0
    // 0xdf3a48: r0 = _Uint32List
    //     0xdf3a48: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0xdf3a4c: stur            x3, [fp, #-0x58]
    // 0xdf3a50: StoreField: r3->field_1b = r0
    //     0xdf3a50: stur            w0, [x3, #0x1b]
    // 0xdf3a54: StoreField: r3->field_b = rZR
    //     0xdf3a54: stur            wzr, [x3, #0xb]
    // 0xdf3a58: r0 = const []
    //     0xdf3a58: ldr             x0, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0xdf3a5c: StoreField: r3->field_f = r0
    //     0xdf3a5c: stur            w0, [x3, #0xf]
    // 0xdf3a60: StoreField: r3->field_13 = rZR
    //     0xdf3a60: stur            wzr, [x3, #0x13]
    // 0xdf3a64: ArrayStore: r3[0] = rZR  ; List_4
    //     0xdf3a64: stur            wzr, [x3, #0x17]
    // 0xdf3a68: ldur            x0, [fp, #-0x50]
    // 0xdf3a6c: tbnz            w0, #4, #0xdf3a80
    // 0xdf3a70: mov             x1, x3
    // 0xdf3a74: r2 = Instance_WidgetState
    //     0xdf3a74: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xdf3a78: ldr             x2, [x2, #0xa70]
    // 0xdf3a7c: r0 = add()
    //     0xdf3a7c: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xdf3a80: ldur            x0, [fp, #-0x18]
    // 0xdf3a84: tbnz            w0, #4, #0xdf3a98
    // 0xdf3a88: ldur            x1, [fp, #-0x58]
    // 0xdf3a8c: r2 = Instance_WidgetState
    //     0xdf3a8c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xdf3a90: ldr             x2, [x2, #0x100]
    // 0xdf3a94: r0 = add()
    //     0xdf3a94: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xdf3a98: ldur            x0, [fp, #-0x48]
    // 0xdf3a9c: ldur            x2, [fp, #-0x20]
    // 0xdf3aa0: r1 = Function '<anonymous closure>':.
    //     0xdf3aa0: add             x1, PP, #0xd0, lsl #12  ; [pp+0xd0660] AnonymousClosure: (0xdf478c), in [package:flutter/src/material/calendar_date_picker.dart] _YearPickerState::_buildYearItem (0xdf3664)
    //     0xdf3aa4: ldr             x1, [x1, #0x660]
    // 0xdf3aa8: r0 = AllocateClosure()
    //     0xdf3aa8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf3aac: r16 = <Color?>
    //     0xdf3aac: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xdf3ab0: ldr             x16, [x16, #0xa40]
    // 0xdf3ab4: ldur            lr, [fp, #-0x30]
    // 0xdf3ab8: stp             lr, x16, [SP, #0x10]
    // 0xdf3abc: ldur            x16, [fp, #-0x58]
    // 0xdf3ac0: stp             x16, x0, [SP]
    // 0xdf3ac4: ldur            x0, [fp, #-0x30]
    // 0xdf3ac8: ClosureCall
    //     0xdf3ac8: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    //     0xdf3acc: ldur            x2, [x0, #0x1f]
    //     0xdf3ad0: blr             x2
    // 0xdf3ad4: ldur            x2, [fp, #-0x20]
    // 0xdf3ad8: r1 = Function '<anonymous closure>':.
    //     0xdf3ad8: add             x1, PP, #0xd0, lsl #12  ; [pp+0xd0668] AnonymousClosure: (0xdf460c), in [package:flutter/src/material/calendar_date_picker.dart] _YearPickerState::_buildYearItem (0xdf3664)
    //     0xdf3adc: ldr             x1, [x1, #0x668]
    // 0xdf3ae0: stur            x0, [fp, #-0x60]
    // 0xdf3ae4: r0 = AllocateClosure()
    //     0xdf3ae4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf3ae8: r16 = <Color?>
    //     0xdf3ae8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xdf3aec: ldr             x16, [x16, #0xa40]
    // 0xdf3af0: ldur            lr, [fp, #-0x30]
    // 0xdf3af4: stp             lr, x16, [SP, #0x10]
    // 0xdf3af8: ldur            x16, [fp, #-0x58]
    // 0xdf3afc: stp             x16, x0, [SP]
    // 0xdf3b00: ldur            x0, [fp, #-0x30]
    // 0xdf3b04: ClosureCall
    //     0xdf3b04: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    //     0xdf3b08: ldur            x2, [x0, #0x1f]
    //     0xdf3b0c: blr             x2
    // 0xdf3b10: ldur            x2, [fp, #-0x20]
    // 0xdf3b14: r1 = Function '<anonymous closure>':.
    //     0xdf3b14: add             x1, PP, #0xd0, lsl #12  ; [pp+0xd0670] AnonymousClosure: (0xdf4494), in [package:flutter/src/material/calendar_date_picker.dart] _YearPickerState::_buildYearItem (0xdf3664)
    //     0xdf3b18: ldr             x1, [x1, #0x670]
    // 0xdf3b1c: stur            x0, [fp, #-0x68]
    // 0xdf3b20: r0 = AllocateClosure()
    //     0xdf3b20: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf3b24: r16 = <Color?>
    //     0xdf3b24: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xdf3b28: ldr             x16, [x16, #0xa40]
    // 0xdf3b2c: stp             x0, x16, [SP]
    // 0xdf3b30: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdf3b30: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdf3b34: r0 = resolveWith()
    //     0xdf3b34: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xdf3b38: r1 = Function '<anonymous closure>':.
    //     0xdf3b38: add             x1, PP, #0xd0, lsl #12  ; [pp+0xd0678] AnonymousClosure: (0xdf4470), in [package:flutter/src/material/calendar_date_picker.dart] _YearPickerState::_buildYearItem (0xdf3664)
    //     0xdf3b3c: ldr             x1, [x1, #0x678]
    // 0xdf3b40: r2 = Null
    //     0xdf3b40: mov             x2, NULL
    // 0xdf3b44: stur            x0, [fp, #-0x70]
    // 0xdf3b48: r0 = AllocateClosure()
    //     0xdf3b48: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf3b4c: r16 = <OutlinedBorder?>
    //     0xdf3b4c: add             x16, PP, #0x7d, lsl #12  ; [pp+0x7d4a8] TypeArguments: <OutlinedBorder?>
    //     0xdf3b50: ldr             x16, [x16, #0x4a8]
    // 0xdf3b54: ldur            lr, [fp, #-0x30]
    // 0xdf3b58: stp             lr, x16, [SP, #0x10]
    // 0xdf3b5c: ldur            x16, [fp, #-0x58]
    // 0xdf3b60: stp             x16, x0, [SP]
    // 0xdf3b64: ldur            x0, [fp, #-0x30]
    // 0xdf3b68: ClosureCall
    //     0xdf3b68: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    //     0xdf3b6c: ldur            x2, [x0, #0x1f]
    //     0xdf3b70: blr             x2
    // 0xdf3b74: stur            x0, [fp, #-0x30]
    // 0xdf3b78: cmp             w0, NULL
    // 0xdf3b7c: b.eq            #0xdf42a8
    // 0xdf3b80: ldur            x1, [fp, #-0x48]
    // 0xdf3b84: tbnz            w1, #4, #0xdf3ca0
    // 0xdf3b88: ldur            x2, [fp, #-0x28]
    // 0xdf3b8c: r1 = LoadClassIdInstr(r2)
    //     0xdf3b8c: ldur            x1, [x2, #-1]
    //     0xdf3b90: ubfx            x1, x1, #0xc, #0x14
    // 0xdf3b94: r17 = 5167
    //     0xdf3b94: mov             x17, #0x142f
    // 0xdf3b98: cmp             x1, x17
    // 0xdf3b9c: b.ne            #0xdf3bac
    // 0xdf3ba0: LoadField: r1 = r2->field_4b
    //     0xdf3ba0: ldur            w1, [x2, #0x4b]
    // 0xdf3ba4: DecompressPointer r1
    //     0xdf3ba4: add             x1, x1, HEAP, lsl #32
    // 0xdf3ba8: b               #0xdf3c84
    // 0xdf3bac: r17 = 5168
    //     0xdf3bac: mov             x17, #0x1430
    // 0xdf3bb0: cmp             x1, x17
    // 0xdf3bb4: b.ne            #0xdf3c18
    // 0xdf3bb8: mov             x1, x2
    // 0xdf3bbc: LoadField: r0 = r1->field_b3
    //     0xdf3bbc: ldur            w0, [x1, #0xb3]
    // 0xdf3bc0: DecompressPointer r0
    //     0xdf3bc0: add             x0, x0, HEAP, lsl #32
    // 0xdf3bc4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf3bc8: cmp             w0, w16
    // 0xdf3bcc: b.ne            #0xdf3bdc
    // 0xdf3bd0: r2 = _colors
    //     0xdf3bd0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xdf3bd4: ldr             x2, [x2, #0x400]
    // 0xdf3bd8: r0 = InitLateFinalInstanceField()
    //     0xdf3bd8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf3bdc: LoadField: r1 = r0->field_b
    //     0xdf3bdc: ldur            w1, [x0, #0xb]
    // 0xdf3be0: DecompressPointer r1
    //     0xdf3be0: add             x1, x1, HEAP, lsl #32
    // 0xdf3be4: stur            x1, [fp, #-0x48]
    // 0xdf3be8: r0 = BorderSide()
    //     0xdf3be8: bl              #0x8a73bc  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0xdf3bec: mov             x1, x0
    // 0xdf3bf0: ldur            x0, [fp, #-0x48]
    // 0xdf3bf4: StoreField: r1->field_7 = r0
    //     0xdf3bf4: stur            w0, [x1, #7]
    // 0xdf3bf8: d0 = 1.000000
    //     0xdf3bf8: fmov            d0, #1.00000000
    // 0xdf3bfc: StoreField: r1->field_b = d0
    //     0xdf3bfc: stur            d0, [x1, #0xb]
    // 0xdf3c00: r0 = Instance_BorderStyle
    //     0xdf3c00: add             x0, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0xdf3c04: ldr             x0, [x0, #0xdc8]
    // 0xdf3c08: StoreField: r1->field_13 = r0
    //     0xdf3c08: stur            w0, [x1, #0x13]
    // 0xdf3c0c: d1 = -1.000000
    //     0xdf3c0c: fmov            d1, #-1.00000000
    // 0xdf3c10: ArrayStore: r1[0] = d1  ; List_8
    //     0xdf3c10: stur            d1, [x1, #0x17]
    // 0xdf3c14: b               #0xdf3c84
    // 0xdf3c18: r0 = Instance_BorderStyle
    //     0xdf3c18: add             x0, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0xdf3c1c: ldr             x0, [x0, #0xdc8]
    // 0xdf3c20: d0 = 1.000000
    //     0xdf3c20: fmov            d0, #1.00000000
    // 0xdf3c24: d1 = -1.000000
    //     0xdf3c24: fmov            d1, #-1.00000000
    // 0xdf3c28: ldur            x1, [fp, #-0x28]
    // 0xdf3c2c: LoadField: r0 = r1->field_b3
    //     0xdf3c2c: ldur            w0, [x1, #0xb3]
    // 0xdf3c30: DecompressPointer r0
    //     0xdf3c30: add             x0, x0, HEAP, lsl #32
    // 0xdf3c34: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf3c38: cmp             w0, w16
    // 0xdf3c3c: b.ne            #0xdf3c4c
    // 0xdf3c40: r2 = _colors
    //     0xdf3c40: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xdf3c44: ldr             x2, [x2, #0x410]
    // 0xdf3c48: r0 = InitLateFinalInstanceField()
    //     0xdf3c48: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf3c4c: LoadField: r1 = r0->field_b
    //     0xdf3c4c: ldur            w1, [x0, #0xb]
    // 0xdf3c50: DecompressPointer r1
    //     0xdf3c50: add             x1, x1, HEAP, lsl #32
    // 0xdf3c54: stur            x1, [fp, #-0x48]
    // 0xdf3c58: r0 = BorderSide()
    //     0xdf3c58: bl              #0x8a73bc  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0xdf3c5c: mov             x1, x0
    // 0xdf3c60: ldur            x0, [fp, #-0x48]
    // 0xdf3c64: StoreField: r1->field_7 = r0
    //     0xdf3c64: stur            w0, [x1, #7]
    // 0xdf3c68: d0 = 1.000000
    //     0xdf3c68: fmov            d0, #1.00000000
    // 0xdf3c6c: StoreField: r1->field_b = d0
    //     0xdf3c6c: stur            d0, [x1, #0xb]
    // 0xdf3c70: r0 = Instance_BorderStyle
    //     0xdf3c70: add             x0, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0xdf3c74: ldr             x0, [x0, #0xdc8]
    // 0xdf3c78: StoreField: r1->field_13 = r0
    //     0xdf3c78: stur            w0, [x1, #0x13]
    // 0xdf3c7c: d0 = -1.000000
    //     0xdf3c7c: fmov            d0, #-1.00000000
    // 0xdf3c80: ArrayStore: r1[0] = d0  ; List_8
    //     0xdf3c80: stur            d0, [x1, #0x17]
    // 0xdf3c84: ldur            x16, [fp, #-0x60]
    // 0xdf3c88: str             x16, [SP]
    // 0xdf3c8c: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0xdf3c8c: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0xdf3c90: ldr             x4, [x4, #0x7f0]
    // 0xdf3c94: r0 = copyWith()
    //     0xdf3c94: bl              #0xdf1d5c  ; [package:flutter/src/painting/borders.dart] BorderSide::copyWith
    // 0xdf3c98: mov             x2, x0
    // 0xdf3c9c: b               #0xdf3ca4
    // 0xdf3ca0: r2 = Null
    //     0xdf3ca0: mov             x2, NULL
    // 0xdf3ca4: ldur            x3, [fp, #-0x28]
    // 0xdf3ca8: ldur            x4, [fp, #-0x68]
    // 0xdf3cac: ldur            x1, [fp, #-0x30]
    // 0xdf3cb0: r0 = LoadClassIdInstr(r1)
    //     0xdf3cb0: ldur            x0, [x1, #-1]
    //     0xdf3cb4: ubfx            x0, x0, #0xc, #0x14
    // 0xdf3cb8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xdf3cb8: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xdf3cbc: r0 = GDT[cid_x0 + -0xff6]()
    //     0xdf3cbc: sub             lr, x0, #0xff6
    //     0xdf3cc0: ldr             lr, [x21, lr, lsl #3]
    //     0xdf3cc4: blr             lr
    // 0xdf3cc8: stur            x0, [fp, #-0x30]
    // 0xdf3ccc: r0 = ShapeDecoration()
    //     0xdf3ccc: bl              #0xb6e288  ; AllocateShapeDecorationStub -> ShapeDecoration (size=0x1c)
    // 0xdf3cd0: mov             x2, x0
    // 0xdf3cd4: ldur            x0, [fp, #-0x68]
    // 0xdf3cd8: stur            x2, [fp, #-0x48]
    // 0xdf3cdc: StoreField: r2->field_7 = r0
    //     0xdf3cdc: stur            w0, [x2, #7]
    // 0xdf3ce0: ldur            x0, [fp, #-0x30]
    // 0xdf3ce4: ArrayStore: r2[0] = r0  ; List_4
    //     0xdf3ce4: stur            w0, [x2, #0x17]
    // 0xdf3ce8: ldur            x1, [fp, #-0x28]
    // 0xdf3cec: r0 = LoadClassIdInstr(r1)
    //     0xdf3cec: ldur            x0, [x1, #-1]
    //     0xdf3cf0: ubfx            x0, x0, #0xc, #0x14
    // 0xdf3cf4: r17 = 5167
    //     0xdf3cf4: mov             x17, #0x142f
    // 0xdf3cf8: cmp             x0, x17
    // 0xdf3cfc: b.ne            #0xdf3d10
    // 0xdf3d00: LoadField: r0 = r1->field_4f
    //     0xdf3d00: ldur            w0, [x1, #0x4f]
    // 0xdf3d04: DecompressPointer r0
    //     0xdf3d04: add             x0, x0, HEAP, lsl #32
    // 0xdf3d08: mov             x1, x0
    // 0xdf3d0c: b               #0xdf3d70
    // 0xdf3d10: r17 = 5168
    //     0xdf3d10: mov             x17, #0x1430
    // 0xdf3d14: cmp             x0, x17
    // 0xdf3d18: b.ne            #0xdf3d48
    // 0xdf3d1c: LoadField: r0 = r1->field_b7
    //     0xdf3d1c: ldur            w0, [x1, #0xb7]
    // 0xdf3d20: DecompressPointer r0
    //     0xdf3d20: add             x0, x0, HEAP, lsl #32
    // 0xdf3d24: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf3d28: cmp             w0, w16
    // 0xdf3d2c: b.ne            #0xdf3d3c
    // 0xdf3d30: r2 = _textTheme
    //     0xdf3d30: add             x2, PP, #0x26, lsl #12  ; [pp+0x26418] Field <_DatePickerDefaultsM3@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0xdf3d34: ldr             x2, [x2, #0x418]
    // 0xdf3d38: r0 = InitLateFinalInstanceField()
    //     0xdf3d38: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf3d3c: LoadField: r1 = r0->field_2b
    //     0xdf3d3c: ldur            w1, [x0, #0x2b]
    // 0xdf3d40: DecompressPointer r1
    //     0xdf3d40: add             x1, x1, HEAP, lsl #32
    // 0xdf3d44: b               #0xdf3d70
    // 0xdf3d48: LoadField: r0 = r1->field_b7
    //     0xdf3d48: ldur            w0, [x1, #0xb7]
    // 0xdf3d4c: DecompressPointer r0
    //     0xdf3d4c: add             x0, x0, HEAP, lsl #32
    // 0xdf3d50: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf3d54: cmp             w0, w16
    // 0xdf3d58: b.ne            #0xdf3d68
    // 0xdf3d5c: r2 = _textTheme
    //     0xdf3d5c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26420] Field <_DatePickerDefaultsM2@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0xdf3d60: ldr             x2, [x2, #0x420]
    // 0xdf3d64: r0 = InitLateFinalInstanceField()
    //     0xdf3d64: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf3d68: LoadField: r1 = r0->field_2b
    //     0xdf3d68: ldur            w1, [x0, #0x2b]
    // 0xdf3d6c: DecompressPointer r1
    //     0xdf3d6c: add             x1, x1, HEAP, lsl #32
    // 0xdf3d70: ldur            x3, [fp, #-8]
    // 0xdf3d74: ldur            x0, [fp, #-0x50]
    // 0xdf3d78: ldur            d0, [fp, #-0x88]
    // 0xdf3d7c: ldur            d1, [fp, #-0x80]
    // 0xdf3d80: ldur            x2, [fp, #-0x60]
    // 0xdf3d84: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xdf3d84: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xdf3d88: r0 = apply()
    //     0xdf3d88: bl              #0x8acf20  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0xdf3d8c: ldur            x1, [fp, #-0x10]
    // 0xdf3d90: stur            x0, [fp, #-0x10]
    // 0xdf3d94: r0 = of()
    //     0xdf3d94: bl              #0xd0bbf8  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0xdf3d98: mov             x1, x0
    // 0xdf3d9c: ldur            x0, [fp, #-0x50]
    // 0xdf3da0: eor             x4, x0, #0x10
    // 0xdf3da4: ldur            x5, [fp, #-8]
    // 0xdf3da8: stur            x4, [fp, #-0x28]
    // 0xdf3dac: LoadField: r2 = r5->field_b
    //     0xdf3dac: ldur            w2, [x5, #0xb]
    // 0xdf3db0: DecompressPointer r2
    //     0xdf3db0: add             x2, x2, HEAP, lsl #32
    // 0xdf3db4: cmp             w2, NULL
    // 0xdf3db8: b.eq            #0xdf42ac
    // 0xdf3dbc: ldur            x2, [fp, #-0x40]
    // 0xdf3dc0: mov             x3, x1
    // 0xdf3dc4: r1 = Instance_GregorianCalendarDelegate
    //     0xdf3dc4: add             x1, PP, #0x28, lsl #12  ; [pp+0x28538] Obj!GregorianCalendarDelegate@129edd1
    //     0xdf3dc8: ldr             x1, [x1, #0x538]
    // 0xdf3dcc: r0 = formatYear()
    //     0xdf3dcc: bl              #0xdee440  ; [package:flutter/src/material/date.dart] CalendarDelegate::formatYear
    // 0xdf3dd0: stur            x0, [fp, #-0x30]
    // 0xdf3dd4: r0 = Text()
    //     0xdf3dd4: bl              #0x8a70a4  ; AllocateTextStub -> Text (size=0x50)
    // 0xdf3dd8: mov             x1, x0
    // 0xdf3ddc: ldur            x0, [fp, #-0x30]
    // 0xdf3de0: stur            x1, [fp, #-0x60]
    // 0xdf3de4: StoreField: r1->field_b = r0
    //     0xdf3de4: stur            w0, [x1, #0xb]
    // 0xdf3de8: ldur            x0, [fp, #-0x10]
    // 0xdf3dec: StoreField: r1->field_13 = r0
    //     0xdf3dec: stur            w0, [x1, #0x13]
    // 0xdf3df0: r0 = Semantics()
    //     0xdf3df0: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xdf3df4: stur            x0, [fp, #-0x10]
    // 0xdf3df8: ldur            x16, [fp, #-0x18]
    // 0xdf3dfc: ldur            lr, [fp, #-0x28]
    // 0xdf3e00: stp             lr, x16, [SP, #0x10]
    // 0xdf3e04: r16 = true
    //     0xdf3e04: add             x16, NULL, #0x20  ; true
    // 0xdf3e08: ldur            lr, [fp, #-0x60]
    // 0xdf3e0c: stp             lr, x16, [SP]
    // 0xdf3e10: mov             x1, x0
    // 0xdf3e14: r4 = const [0, 0x5, 0x4, 0x1, button, 0x3, child, 0x4, enabled, 0x2, selected, 0x1, null]
    //     0xdf3e14: add             x4, PP, #0xd0, lsl #12  ; [pp+0xd0680] List(13) [0, 0x5, 0x4, 0x1, "button", 0x3, "child", 0x4, "enabled", 0x2, "selected", 0x1, Null]
    //     0xdf3e18: ldr             x4, [x4, #0x680]
    // 0xdf3e1c: r0 = Semantics()
    //     0xdf3e1c: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xdf3e20: ldur            d0, [fp, #-0x88]
    // 0xdf3e24: r0 = inline_Allocate_Double()
    //     0xdf3e24: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xdf3e28: add             x0, x0, #0x10
    //     0xdf3e2c: cmp             x1, x0
    //     0xdf3e30: b.ls            #0xdf42b0
    //     0xdf3e34: str             x0, [THR, #0x60]  ; THR::top
    //     0xdf3e38: sub             x0, x0, #0xf
    //     0xdf3e3c: mov             x1, #0xe19c
    //     0xdf3e40: movk            x1, #3, lsl #16
    //     0xdf3e44: stur            x1, [x0, #-1]
    // 0xdf3e48: dmb             ishst
    // 0xdf3e4c: StoreField: r0->field_7 = d0
    //     0xdf3e4c: stur            d0, [x0, #7]
    // 0xdf3e50: ldur            d0, [fp, #-0x80]
    // 0xdf3e54: stur            x0, [fp, #-0x28]
    // 0xdf3e58: r1 = inline_Allocate_Double()
    //     0xdf3e58: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xdf3e5c: add             x1, x1, #0x10
    //     0xdf3e60: cmp             x2, x1
    //     0xdf3e64: b.ls            #0xdf42c0
    //     0xdf3e68: str             x1, [THR, #0x60]  ; THR::top
    //     0xdf3e6c: sub             x1, x1, #0xf
    //     0xdf3e70: mov             x2, #0xe19c
    //     0xdf3e74: movk            x2, #3, lsl #16
    //     0xdf3e78: stur            x2, [x1, #-1]
    // 0xdf3e7c: dmb             ishst
    // 0xdf3e80: StoreField: r1->field_7 = d0
    //     0xdf3e80: stur            d0, [x1, #7]
    // 0xdf3e84: stur            x1, [fp, #-0x18]
    // 0xdf3e88: r0 = Container()
    //     0xdf3e88: bl              #0x8a5af8  ; AllocateContainerStub -> Container (size=0x38)
    // 0xdf3e8c: stur            x0, [fp, #-0x30]
    // 0xdf3e90: ldur            x16, [fp, #-0x48]
    // 0xdf3e94: ldur            lr, [fp, #-0x28]
    // 0xdf3e98: stp             lr, x16, [SP, #0x18]
    // 0xdf3e9c: ldur            x16, [fp, #-0x18]
    // 0xdf3ea0: r30 = Instance_Alignment
    //     0xdf3ea0: add             lr, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xdf3ea4: ldr             lr, [lr, #0xb80]
    // 0xdf3ea8: stp             lr, x16, [SP, #8]
    // 0xdf3eac: ldur            x16, [fp, #-0x10]
    // 0xdf3eb0: str             x16, [SP]
    // 0xdf3eb4: mov             x1, x0
    // 0xdf3eb8: r4 = const [0, 0x6, 0x5, 0x1, alignment, 0x4, child, 0x5, decoration, 0x1, height, 0x2, width, 0x3, null]
    //     0xdf3eb8: add             x4, PP, #0xd0, lsl #12  ; [pp+0xd0688] List(15) [0, 0x6, 0x5, 0x1, "alignment", 0x4, "child", 0x5, "decoration", 0x1, "height", 0x2, "width", 0x3, Null]
    //     0xdf3ebc: ldr             x4, [x4, #0x688]
    // 0xdf3ec0: r0 = Container()
    //     0xdf3ec0: bl              #0x8a54e0  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0xdf3ec4: r0 = Center()
    //     0xdf3ec4: bl              #0xd0c898  ; AllocateCenterStub -> Center (size=0x1c)
    // 0xdf3ec8: mov             x2, x0
    // 0xdf3ecc: r0 = Instance_Alignment
    //     0xdf3ecc: add             x0, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xdf3ed0: ldr             x0, [x0, #0xb80]
    // 0xdf3ed4: stur            x2, [fp, #-0x10]
    // 0xdf3ed8: StoreField: r2->field_f = r0
    //     0xdf3ed8: stur            w0, [x2, #0xf]
    // 0xdf3edc: ldur            x0, [fp, #-0x30]
    // 0xdf3ee0: StoreField: r2->field_b = r0
    //     0xdf3ee0: stur            w0, [x2, #0xb]
    // 0xdf3ee4: ldur            x0, [fp, #-0x50]
    // 0xdf3ee8: tbz             w0, #4, #0xdf4268
    // 0xdf3eec: ldur            x0, [fp, #-8]
    // 0xdf3ef0: ldur            x3, [fp, #-0x20]
    // 0xdf3ef4: LoadField: r1 = r0->field_b
    //     0xdf3ef4: ldur            w1, [x0, #0xb]
    // 0xdf3ef8: DecompressPointer r1
    //     0xdf3ef8: add             x1, x1, HEAP, lsl #32
    // 0xdf3efc: cmp             w1, NULL
    // 0xdf3f00: b.eq            #0xdf42dc
    // 0xdf3f04: ArrayLoad: r4 = r1[0]  ; List_4
    //     0xdf3f04: ldur            w4, [x1, #0x17]
    // 0xdf3f08: DecompressPointer r4
    //     0xdf3f08: add             x4, x4, HEAP, lsl #32
    // 0xdf3f0c: mov             x1, x4
    // 0xdf3f10: r0 = _parts()
    //     0xdf3f10: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xdf3f14: mov             x2, x0
    // 0xdf3f18: LoadField: r0 = r2->field_b
    //     0xdf3f18: ldur            w0, [x2, #0xb]
    // 0xdf3f1c: r1 = LoadInt32Instr(r0)
    //     0xdf3f1c: sbfx            x1, x0, #1, #0x1f
    // 0xdf3f20: mov             x0, x1
    // 0xdf3f24: r1 = 7
    //     0xdf3f24: mov             x1, #7
    // 0xdf3f28: cmp             x1, x0
    // 0xdf3f2c: b.hs            #0xdf42e0
    // 0xdf3f30: LoadField: r0 = r2->field_2b
    //     0xdf3f30: ldur            w0, [x2, #0x2b]
    // 0xdf3f34: DecompressPointer r0
    //     0xdf3f34: add             x0, x0, HEAP, lsl #32
    // 0xdf3f38: r3 = LoadInt32Instr(r0)
    //     0xdf3f38: sbfx            x3, x0, #1, #0x1f
    //     0xdf3f3c: tbz             w0, #0, #0xdf3f44
    //     0xdf3f40: ldur            x3, [x0, #7]
    // 0xdf3f44: ldur            x2, [fp, #-0x40]
    // 0xdf3f48: r1 = Instance_GregorianCalendarDelegate
    //     0xdf3f48: add             x1, PP, #0x28, lsl #12  ; [pp+0x28538] Obj!GregorianCalendarDelegate@129edd1
    //     0xdf3f4c: ldr             x1, [x1, #0x538]
    // 0xdf3f50: r0 = getMonth()
    //     0xdf3f50: bl              #0xdedac8  ; [package:flutter/src/material/date.dart] GregorianCalendarDelegate::getMonth
    // 0xdf3f54: mov             x3, x0
    // 0xdf3f58: ldur            x2, [fp, #-0x20]
    // 0xdf3f5c: stur            x3, [fp, #-0x18]
    // 0xdf3f60: StoreField: r2->field_23 = r0
    //     0xdf3f60: stur            w0, [x2, #0x23]
    //     0xdf3f64: ldurb           w16, [x2, #-1]
    //     0xdf3f68: ldurb           w17, [x0, #-1]
    //     0xdf3f6c: and             x16, x17, x16, lsr #2
    //     0xdf3f70: tst             x16, HEAP, lsr #32
    //     0xdf3f74: b.eq            #0xdf3f7c
    //     0xdf3f78: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xdf3f7c: ldur            x0, [fp, #-8]
    // 0xdf3f80: LoadField: r1 = r0->field_b
    //     0xdf3f80: ldur            w1, [x0, #0xb]
    // 0xdf3f84: DecompressPointer r1
    //     0xdf3f84: add             x1, x1, HEAP, lsl #32
    // 0xdf3f88: cmp             w1, NULL
    // 0xdf3f8c: b.eq            #0xdf42e4
    // 0xdf3f90: LoadField: r4 = r1->field_f
    //     0xdf3f90: ldur            w4, [x1, #0xf]
    // 0xdf3f94: DecompressPointer r4
    //     0xdf3f94: add             x4, x4, HEAP, lsl #32
    // 0xdf3f98: mov             x1, x4
    // 0xdf3f9c: r0 = _parts()
    //     0xdf3f9c: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xdf3fa0: mov             x2, x0
    // 0xdf3fa4: LoadField: r0 = r2->field_b
    //     0xdf3fa4: ldur            w0, [x2, #0xb]
    // 0xdf3fa8: r1 = LoadInt32Instr(r0)
    //     0xdf3fa8: sbfx            x1, x0, #1, #0x1f
    // 0xdf3fac: mov             x0, x1
    // 0xdf3fb0: r1 = 8
    //     0xdf3fb0: mov             x1, #8
    // 0xdf3fb4: cmp             x1, x0
    // 0xdf3fb8: b.hs            #0xdf42e8
    // 0xdf3fbc: LoadField: r0 = r2->field_2f
    //     0xdf3fbc: ldur            w0, [x2, #0x2f]
    // 0xdf3fc0: DecompressPointer r0
    //     0xdf3fc0: add             x0, x0, HEAP, lsl #32
    // 0xdf3fc4: ldur            x2, [fp, #-8]
    // 0xdf3fc8: stur            x0, [fp, #-0x28]
    // 0xdf3fcc: LoadField: r1 = r2->field_b
    //     0xdf3fcc: ldur            w1, [x2, #0xb]
    // 0xdf3fd0: DecompressPointer r1
    //     0xdf3fd0: add             x1, x1, HEAP, lsl #32
    // 0xdf3fd4: cmp             w1, NULL
    // 0xdf3fd8: b.eq            #0xdf42ec
    // 0xdf3fdc: LoadField: r3 = r1->field_f
    //     0xdf3fdc: ldur            w3, [x1, #0xf]
    // 0xdf3fe0: DecompressPointer r3
    //     0xdf3fe0: add             x3, x3, HEAP, lsl #32
    // 0xdf3fe4: mov             x1, x3
    // 0xdf3fe8: r0 = _parts()
    //     0xdf3fe8: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xdf3fec: mov             x2, x0
    // 0xdf3ff0: LoadField: r0 = r2->field_b
    //     0xdf3ff0: ldur            w0, [x2, #0xb]
    // 0xdf3ff4: r1 = LoadInt32Instr(r0)
    //     0xdf3ff4: sbfx            x1, x0, #1, #0x1f
    // 0xdf3ff8: mov             x0, x1
    // 0xdf3ffc: r1 = 7
    //     0xdf3ffc: mov             x1, #7
    // 0xdf4000: cmp             x1, x0
    // 0xdf4004: b.hs            #0xdf42f0
    // 0xdf4008: LoadField: r0 = r2->field_2b
    //     0xdf4008: ldur            w0, [x2, #0x2b]
    // 0xdf400c: DecompressPointer r0
    //     0xdf400c: add             x0, x0, HEAP, lsl #32
    // 0xdf4010: ldur            x1, [fp, #-0x28]
    // 0xdf4014: r2 = LoadInt32Instr(r1)
    //     0xdf4014: sbfx            x2, x1, #1, #0x1f
    //     0xdf4018: tbz             w1, #0, #0xdf4020
    //     0xdf401c: ldur            x2, [x1, #7]
    // 0xdf4020: r3 = LoadInt32Instr(r0)
    //     0xdf4020: sbfx            x3, x0, #1, #0x1f
    //     0xdf4024: tbz             w0, #0, #0xdf402c
    //     0xdf4028: ldur            x3, [x0, #7]
    // 0xdf402c: r1 = Instance_GregorianCalendarDelegate
    //     0xdf402c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28538] Obj!GregorianCalendarDelegate@129edd1
    //     0xdf4030: ldr             x1, [x1, #0x538]
    // 0xdf4034: r0 = getMonth()
    //     0xdf4034: bl              #0xdedac8  ; [package:flutter/src/material/date.dart] GregorianCalendarDelegate::getMonth
    // 0xdf4038: ldur            x1, [fp, #-0x18]
    // 0xdf403c: mov             x2, x0
    // 0xdf4040: r0 = isBefore()
    //     0xdf4040: bl              #0xd183f0  ; [dart:core] DateTime::isBefore
    // 0xdf4044: tbnz            w0, #4, #0xdf40d4
    // 0xdf4048: ldur            x0, [fp, #-8]
    // 0xdf404c: ldur            x2, [fp, #-0x20]
    // 0xdf4050: LoadField: r1 = r0->field_b
    //     0xdf4050: ldur            w1, [x0, #0xb]
    // 0xdf4054: DecompressPointer r1
    //     0xdf4054: add             x1, x1, HEAP, lsl #32
    // 0xdf4058: cmp             w1, NULL
    // 0xdf405c: b.eq            #0xdf42f4
    // 0xdf4060: LoadField: r3 = r1->field_f
    //     0xdf4060: ldur            w3, [x1, #0xf]
    // 0xdf4064: DecompressPointer r3
    //     0xdf4064: add             x3, x3, HEAP, lsl #32
    // 0xdf4068: mov             x1, x3
    // 0xdf406c: r0 = _parts()
    //     0xdf406c: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xdf4070: mov             x2, x0
    // 0xdf4074: LoadField: r0 = r2->field_b
    //     0xdf4074: ldur            w0, [x2, #0xb]
    // 0xdf4078: r1 = LoadInt32Instr(r0)
    //     0xdf4078: sbfx            x1, x0, #1, #0x1f
    // 0xdf407c: mov             x0, x1
    // 0xdf4080: r1 = 7
    //     0xdf4080: mov             x1, #7
    // 0xdf4084: cmp             x1, x0
    // 0xdf4088: b.hs            #0xdf42f8
    // 0xdf408c: LoadField: r0 = r2->field_2b
    //     0xdf408c: ldur            w0, [x2, #0x2b]
    // 0xdf4090: DecompressPointer r0
    //     0xdf4090: add             x0, x0, HEAP, lsl #32
    // 0xdf4094: r3 = LoadInt32Instr(r0)
    //     0xdf4094: sbfx            x3, x0, #1, #0x1f
    //     0xdf4098: tbz             w0, #0, #0xdf40a0
    //     0xdf409c: ldur            x3, [x0, #7]
    // 0xdf40a0: ldur            x2, [fp, #-0x40]
    // 0xdf40a4: r1 = Instance_GregorianCalendarDelegate
    //     0xdf40a4: add             x1, PP, #0x28, lsl #12  ; [pp+0x28538] Obj!GregorianCalendarDelegate@129edd1
    //     0xdf40a8: ldr             x1, [x1, #0x538]
    // 0xdf40ac: r0 = getMonth()
    //     0xdf40ac: bl              #0xdedac8  ; [package:flutter/src/material/date.dart] GregorianCalendarDelegate::getMonth
    // 0xdf40b0: ldur            x3, [fp, #-0x20]
    // 0xdf40b4: StoreField: r3->field_23 = r0
    //     0xdf40b4: stur            w0, [x3, #0x23]
    //     0xdf40b8: ldurb           w16, [x3, #-1]
    //     0xdf40bc: ldurb           w17, [x0, #-1]
    //     0xdf40c0: and             x16, x17, x16, lsr #2
    //     0xdf40c4: tst             x16, HEAP, lsr #32
    //     0xdf40c8: b.eq            #0xdf40d0
    //     0xdf40cc: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xdf40d0: b               #0xdf4198
    // 0xdf40d4: ldur            x0, [fp, #-8]
    // 0xdf40d8: ldur            x3, [fp, #-0x20]
    // 0xdf40dc: LoadField: r1 = r3->field_23
    //     0xdf40dc: ldur            w1, [x3, #0x23]
    // 0xdf40e0: DecompressPointer r1
    //     0xdf40e0: add             x1, x1, HEAP, lsl #32
    // 0xdf40e4: LoadField: r2 = r0->field_b
    //     0xdf40e4: ldur            w2, [x0, #0xb]
    // 0xdf40e8: DecompressPointer r2
    //     0xdf40e8: add             x2, x2, HEAP, lsl #32
    // 0xdf40ec: cmp             w2, NULL
    // 0xdf40f0: b.eq            #0xdf42fc
    // 0xdf40f4: LoadField: r4 = r2->field_13
    //     0xdf40f4: ldur            w4, [x2, #0x13]
    // 0xdf40f8: DecompressPointer r4
    //     0xdf40f8: add             x4, x4, HEAP, lsl #32
    // 0xdf40fc: mov             x2, x4
    // 0xdf4100: r0 = isAfter()
    //     0xdf4100: bl              #0xd183d4  ; [dart:core] DateTime::isAfter
    // 0xdf4104: tbnz            w0, #4, #0xdf4194
    // 0xdf4108: ldur            x0, [fp, #-8]
    // 0xdf410c: ldur            x2, [fp, #-0x20]
    // 0xdf4110: LoadField: r1 = r0->field_b
    //     0xdf4110: ldur            w1, [x0, #0xb]
    // 0xdf4114: DecompressPointer r1
    //     0xdf4114: add             x1, x1, HEAP, lsl #32
    // 0xdf4118: cmp             w1, NULL
    // 0xdf411c: b.eq            #0xdf4300
    // 0xdf4120: LoadField: r3 = r1->field_13
    //     0xdf4120: ldur            w3, [x1, #0x13]
    // 0xdf4124: DecompressPointer r3
    //     0xdf4124: add             x3, x3, HEAP, lsl #32
    // 0xdf4128: mov             x1, x3
    // 0xdf412c: r0 = _parts()
    //     0xdf412c: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xdf4130: mov             x2, x0
    // 0xdf4134: LoadField: r0 = r2->field_b
    //     0xdf4134: ldur            w0, [x2, #0xb]
    // 0xdf4138: r1 = LoadInt32Instr(r0)
    //     0xdf4138: sbfx            x1, x0, #1, #0x1f
    // 0xdf413c: mov             x0, x1
    // 0xdf4140: r1 = 7
    //     0xdf4140: mov             x1, #7
    // 0xdf4144: cmp             x1, x0
    // 0xdf4148: b.hs            #0xdf4304
    // 0xdf414c: LoadField: r0 = r2->field_2b
    //     0xdf414c: ldur            w0, [x2, #0x2b]
    // 0xdf4150: DecompressPointer r0
    //     0xdf4150: add             x0, x0, HEAP, lsl #32
    // 0xdf4154: r3 = LoadInt32Instr(r0)
    //     0xdf4154: sbfx            x3, x0, #1, #0x1f
    //     0xdf4158: tbz             w0, #0, #0xdf4160
    //     0xdf415c: ldur            x3, [x0, #7]
    // 0xdf4160: ldur            x2, [fp, #-0x40]
    // 0xdf4164: r1 = Instance_GregorianCalendarDelegate
    //     0xdf4164: add             x1, PP, #0x28, lsl #12  ; [pp+0x28538] Obj!GregorianCalendarDelegate@129edd1
    //     0xdf4168: ldr             x1, [x1, #0x538]
    // 0xdf416c: r0 = getMonth()
    //     0xdf416c: bl              #0xdedac8  ; [package:flutter/src/material/date.dart] GregorianCalendarDelegate::getMonth
    // 0xdf4170: ldur            x3, [fp, #-0x20]
    // 0xdf4174: StoreField: r3->field_23 = r0
    //     0xdf4174: stur            w0, [x3, #0x23]
    //     0xdf4178: ldurb           w16, [x3, #-1]
    //     0xdf417c: ldurb           w17, [x0, #-1]
    //     0xdf4180: and             x16, x17, x16, lsr #2
    //     0xdf4184: tst             x16, HEAP, lsr #32
    //     0xdf4188: b.eq            #0xdf4190
    //     0xdf418c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xdf4190: b               #0xdf4198
    // 0xdf4194: ldur            x3, [fp, #-0x20]
    // 0xdf4198: ldur            x0, [fp, #-8]
    // 0xdf419c: ldur            x6, [fp, #-0x40]
    // 0xdf41a0: ldur            x5, [fp, #-0x70]
    // 0xdf41a4: ldur            x4, [fp, #-0x10]
    // 0xdf41a8: ArrayLoad: r7 = r0[0]  ; List_4
    //     0xdf41a8: ldur            w7, [x0, #0x17]
    // 0xdf41ac: DecompressPointer r7
    //     0xdf41ac: add             x7, x7, HEAP, lsl #32
    // 0xdf41b0: mov             x1, x7
    // 0xdf41b4: ldur            x2, [fp, #-0x58]
    // 0xdf41b8: stur            x7, [fp, #-0x18]
    // 0xdf41bc: r0 = value=()
    //     0xdf41bc: bl              #0xb68ce8  ; [package:flutter/src/foundation/change_notifier.dart] ValueNotifier::value=
    // 0xdf41c0: ldur            x2, [fp, #-0x40]
    // 0xdf41c4: r0 = BoxInt64Instr(r2)
    //     0xdf41c4: sbfiz           x0, x2, #1, #0x1f
    //     0xdf41c8: cmp             x2, x0, asr #1
    //     0xdf41cc: b.eq            #0xdf41d8
    //     0xdf41d0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xdf41d4: stur            x2, [x0, #7]
    // 0xdf41d8: r1 = <int>
    //     0xdf41d8: ldr             x1, [PP, #0x50]  ; [pp+0x50] TypeArguments: <int>
    // 0xdf41dc: stur            x0, [fp, #-8]
    // 0xdf41e0: r0 = ValueKey()
    //     0xdf41e0: bl              #0x8e283c  ; AllocateValueKeyStub -> ValueKey<X0> (size=0x10)
    // 0xdf41e4: mov             x1, x0
    // 0xdf41e8: ldur            x0, [fp, #-8]
    // 0xdf41ec: stur            x1, [fp, #-0x28]
    // 0xdf41f0: StoreField: r1->field_b = r0
    //     0xdf41f0: stur            w0, [x1, #0xb]
    // 0xdf41f4: r0 = InkWell()
    //     0xdf41f4: bl              #0xd0c57c  ; AllocateInkWellStub -> InkWell (size=0x94)
    // 0xdf41f8: mov             x3, x0
    // 0xdf41fc: ldur            x0, [fp, #-0x10]
    // 0xdf4200: stur            x3, [fp, #-8]
    // 0xdf4204: StoreField: r3->field_b = r0
    //     0xdf4204: stur            w0, [x3, #0xb]
    // 0xdf4208: ldur            x2, [fp, #-0x20]
    // 0xdf420c: r1 = Function '<anonymous closure>':.
    //     0xdf420c: add             x1, PP, #0xd0, lsl #12  ; [pp+0xd0690] AnonymousClosure: (0xdf43f8), in [package:flutter/src/material/calendar_date_picker.dart] _YearPickerState::_buildYearItem (0xdf3664)
    //     0xdf4210: ldr             x1, [x1, #0x690]
    // 0xdf4214: r0 = AllocateClosure()
    //     0xdf4214: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf4218: ldur            x1, [fp, #-8]
    // 0xdf421c: StoreField: r1->field_f = r0
    //     0xdf421c: stur            w0, [x1, #0xf]
    // 0xdf4220: r2 = true
    //     0xdf4220: add             x2, NULL, #0x20  ; true
    // 0xdf4224: StoreField: r1->field_47 = r2
    //     0xdf4224: stur            w2, [x1, #0x47]
    // 0xdf4228: r3 = Instance_BoxShape
    //     0xdf4228: add             x3, PP, #0x17, lsl #12  ; [pp+0x171f8] Obj!BoxShape@12c4921
    //     0xdf422c: ldr             x3, [x3, #0x1f8]
    // 0xdf4230: StoreField: r1->field_4b = r3
    //     0xdf4230: stur            w3, [x1, #0x4b]
    // 0xdf4234: ldur            x3, [fp, #-0x70]
    // 0xdf4238: StoreField: r1->field_67 = r3
    //     0xdf4238: stur            w3, [x1, #0x67]
    // 0xdf423c: StoreField: r1->field_73 = r2
    //     0xdf423c: stur            w2, [x1, #0x73]
    // 0xdf4240: r3 = false
    //     0xdf4240: add             x3, NULL, #0x30  ; false
    // 0xdf4244: StoreField: r1->field_77 = r3
    //     0xdf4244: stur            w3, [x1, #0x77]
    // 0xdf4248: StoreField: r1->field_87 = r2
    //     0xdf4248: stur            w2, [x1, #0x87]
    // 0xdf424c: StoreField: r1->field_7f = r3
    //     0xdf424c: stur            w3, [x1, #0x7f]
    // 0xdf4250: ldur            x2, [fp, #-0x18]
    // 0xdf4254: StoreField: r1->field_8b = r2
    //     0xdf4254: stur            w2, [x1, #0x8b]
    // 0xdf4258: ldur            x2, [fp, #-0x28]
    // 0xdf425c: StoreField: r1->field_7 = r2
    //     0xdf425c: stur            w2, [x1, #7]
    // 0xdf4260: mov             x0, x1
    // 0xdf4264: b               #0xdf426c
    // 0xdf4268: mov             x0, x2
    // 0xdf426c: LeaveFrame
    //     0xdf426c: mov             SP, fp
    //     0xdf4270: ldp             fp, lr, [SP], #0x10
    // 0xdf4274: ret
    //     0xdf4274: ret             
    // 0xdf4278: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf4278: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf427c: b               #0xdf3690
    // 0xdf4280: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf4280: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf4284: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdf4284: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdf4288: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf4288: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf428c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdf428c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdf4290: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf4290: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf4294: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdf4294: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdf4298: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf4298: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf429c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdf429c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdf42a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf42a0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf42a4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdf42a4: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdf42a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf42a8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf42ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf42ac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf42b0: SaveReg d0
    //     0xdf42b0: str             q0, [SP, #-0x10]!
    // 0xdf42b4: r0 = AllocateDouble()
    //     0xdf42b4: bl              #0x13df878  ; AllocateDoubleStub
    // 0xdf42b8: RestoreReg d0
    //     0xdf42b8: ldr             q0, [SP], #0x10
    // 0xdf42bc: b               #0xdf3e4c
    // 0xdf42c0: SaveReg d0
    //     0xdf42c0: str             q0, [SP, #-0x10]!
    // 0xdf42c4: SaveReg r0
    //     0xdf42c4: str             x0, [SP, #-8]!
    // 0xdf42c8: r0 = AllocateDouble()
    //     0xdf42c8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xdf42cc: mov             x1, x0
    // 0xdf42d0: RestoreReg r0
    //     0xdf42d0: ldr             x0, [SP], #8
    // 0xdf42d4: RestoreReg d0
    //     0xdf42d4: ldr             q0, [SP], #0x10
    // 0xdf42d8: b               #0xdf3e80
    // 0xdf42dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf42dc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf42e0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdf42e0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdf42e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf42e4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf42e8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdf42e8: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdf42ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf42ec: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf42f0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdf42f0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdf42f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf42f4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf42f8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdf42f8: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdf42fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf42fc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf4300: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf4300: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf4304: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdf4304: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  get _ _itemCount(/* No info */) {
    // ** addr: 0xdf4308, size: 0xf0
    // 0xdf4308: EnterFrame
    //     0xdf4308: stp             fp, lr, [SP, #-0x10]!
    //     0xdf430c: mov             fp, SP
    // 0xdf4310: AllocStack(0x10)
    //     0xdf4310: sub             SP, SP, #0x10
    // 0xdf4314: SetupParameters(_YearPickerState this /* r1 => r0, fp-0x8 */)
    //     0xdf4314: mov             x0, x1
    //     0xdf4318: stur            x1, [fp, #-8]
    // 0xdf431c: CheckStackOverflow
    //     0xdf431c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf4320: cmp             SP, x16
    //     0xdf4324: b.ls            #0xdf43e0
    // 0xdf4328: LoadField: r1 = r0->field_b
    //     0xdf4328: ldur            w1, [x0, #0xb]
    // 0xdf432c: DecompressPointer r1
    //     0xdf432c: add             x1, x1, HEAP, lsl #32
    // 0xdf4330: cmp             w1, NULL
    // 0xdf4334: b.eq            #0xdf43e8
    // 0xdf4338: LoadField: r2 = r1->field_13
    //     0xdf4338: ldur            w2, [x1, #0x13]
    // 0xdf433c: DecompressPointer r2
    //     0xdf433c: add             x2, x2, HEAP, lsl #32
    // 0xdf4340: mov             x1, x2
    // 0xdf4344: r0 = _parts()
    //     0xdf4344: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xdf4348: mov             x2, x0
    // 0xdf434c: LoadField: r0 = r2->field_b
    //     0xdf434c: ldur            w0, [x2, #0xb]
    // 0xdf4350: r1 = LoadInt32Instr(r0)
    //     0xdf4350: sbfx            x1, x0, #1, #0x1f
    // 0xdf4354: mov             x0, x1
    // 0xdf4358: r1 = 8
    //     0xdf4358: mov             x1, #8
    // 0xdf435c: cmp             x1, x0
    // 0xdf4360: b.hs            #0xdf43ec
    // 0xdf4364: LoadField: r0 = r2->field_2f
    //     0xdf4364: ldur            w0, [x2, #0x2f]
    // 0xdf4368: DecompressPointer r0
    //     0xdf4368: add             x0, x0, HEAP, lsl #32
    // 0xdf436c: ldur            x1, [fp, #-8]
    // 0xdf4370: stur            x0, [fp, #-0x10]
    // 0xdf4374: LoadField: r2 = r1->field_b
    //     0xdf4374: ldur            w2, [x1, #0xb]
    // 0xdf4378: DecompressPointer r2
    //     0xdf4378: add             x2, x2, HEAP, lsl #32
    // 0xdf437c: cmp             w2, NULL
    // 0xdf4380: b.eq            #0xdf43f0
    // 0xdf4384: LoadField: r1 = r2->field_f
    //     0xdf4384: ldur            w1, [x2, #0xf]
    // 0xdf4388: DecompressPointer r1
    //     0xdf4388: add             x1, x1, HEAP, lsl #32
    // 0xdf438c: r0 = _parts()
    //     0xdf438c: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xdf4390: mov             x2, x0
    // 0xdf4394: LoadField: r3 = r2->field_b
    //     0xdf4394: ldur            w3, [x2, #0xb]
    // 0xdf4398: r0 = LoadInt32Instr(r3)
    //     0xdf4398: sbfx            x0, x3, #1, #0x1f
    // 0xdf439c: r1 = 8
    //     0xdf439c: mov             x1, #8
    // 0xdf43a0: cmp             x1, x0
    // 0xdf43a4: b.hs            #0xdf43f4
    // 0xdf43a8: LoadField: r1 = r2->field_2f
    //     0xdf43a8: ldur            w1, [x2, #0x2f]
    // 0xdf43ac: DecompressPointer r1
    //     0xdf43ac: add             x1, x1, HEAP, lsl #32
    // 0xdf43b0: ldur            x2, [fp, #-0x10]
    // 0xdf43b4: r3 = LoadInt32Instr(r2)
    //     0xdf43b4: sbfx            x3, x2, #1, #0x1f
    //     0xdf43b8: tbz             w2, #0, #0xdf43c0
    //     0xdf43bc: ldur            x3, [x2, #7]
    // 0xdf43c0: r2 = LoadInt32Instr(r1)
    //     0xdf43c0: sbfx            x2, x1, #1, #0x1f
    //     0xdf43c4: tbz             w1, #0, #0xdf43cc
    //     0xdf43c8: ldur            x2, [x1, #7]
    // 0xdf43cc: sub             x1, x3, x2
    // 0xdf43d0: add             x0, x1, #1
    // 0xdf43d4: LeaveFrame
    //     0xdf43d4: mov             SP, fp
    //     0xdf43d8: ldp             fp, lr, [SP], #0x10
    // 0xdf43dc: ret
    //     0xdf43dc: ret             
    // 0xdf43e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf43e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf43e4: b               #0xdf4328
    // 0xdf43e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf43e8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf43ec: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdf43ec: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdf43f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf43f0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf43f4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdf43f4: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xdf43f8, size: 0x78
    // 0xdf43f8: EnterFrame
    //     0xdf43f8: stp             fp, lr, [SP, #-0x10]!
    //     0xdf43fc: mov             fp, SP
    // 0xdf4400: ldr             x0, [fp, #0x10]
    // 0xdf4404: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdf4404: ldur            w1, [x0, #0x17]
    // 0xdf4408: DecompressPointer r1
    //     0xdf4408: add             x1, x1, HEAP, lsl #32
    // 0xdf440c: CheckStackOverflow
    //     0xdf440c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf4410: cmp             SP, x16
    //     0xdf4414: b.ls            #0xdf4464
    // 0xdf4418: LoadField: r0 = r1->field_f
    //     0xdf4418: ldur            w0, [x1, #0xf]
    // 0xdf441c: DecompressPointer r0
    //     0xdf441c: add             x0, x0, HEAP, lsl #32
    // 0xdf4420: LoadField: r2 = r0->field_b
    //     0xdf4420: ldur            w2, [x0, #0xb]
    // 0xdf4424: DecompressPointer r2
    //     0xdf4424: add             x2, x2, HEAP, lsl #32
    // 0xdf4428: cmp             w2, NULL
    // 0xdf442c: b.eq            #0xdf446c
    // 0xdf4430: LoadField: r0 = r1->field_23
    //     0xdf4430: ldur            w0, [x1, #0x23]
    // 0xdf4434: DecompressPointer r0
    //     0xdf4434: add             x0, x0, HEAP, lsl #32
    // 0xdf4438: LoadField: r1 = r2->field_1b
    //     0xdf4438: ldur            w1, [x2, #0x1b]
    // 0xdf443c: DecompressPointer r1
    //     0xdf443c: add             x1, x1, HEAP, lsl #32
    // 0xdf4440: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xdf4440: ldur            w2, [x1, #0x17]
    // 0xdf4444: DecompressPointer r2
    //     0xdf4444: add             x2, x2, HEAP, lsl #32
    // 0xdf4448: mov             x1, x2
    // 0xdf444c: mov             x2, x0
    // 0xdf4450: r0 = _handleYearChanged()
    //     0xdf4450: bl              #0xded1cc  ; [package:flutter/src/material/calendar_date_picker.dart] _CalendarDatePickerState::_handleYearChanged
    // 0xdf4454: r0 = Null
    //     0xdf4454: mov             x0, NULL
    // 0xdf4458: LeaveFrame
    //     0xdf4458: mov             SP, fp
    //     0xdf445c: ldp             fp, lr, [SP], #0x10
    // 0xdf4460: ret
    //     0xdf4460: ret             
    // 0xdf4464: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf4464: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf4468: b               #0xdf4418
    // 0xdf446c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf446c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] WidgetStateProperty<OutlinedBorder?>? <anonymous closure>(dynamic, DatePickerThemeData?) {
    // ** addr: 0xdf4470, size: 0x24
    // 0xdf4470: ldr             x1, [SP]
    // 0xdf4474: cmp             w1, NULL
    // 0xdf4478: b.ne            #0xdf4484
    // 0xdf447c: r0 = Null
    //     0xdf447c: mov             x0, NULL
    // 0xdf4480: b               #0xdf4490
    // 0xdf4484: LoadField: r2 = r1->field_5f
    //     0xdf4484: ldur            w2, [x1, #0x5f]
    // 0xdf4488: DecompressPointer r2
    //     0xdf4488: add             x2, x2, HEAP, lsl #32
    // 0xdf448c: mov             x0, x2
    // 0xdf4490: ret
    //     0xdf4490: ret             
  }
  [closure] Color? <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xdf4494, size: 0x98
    // 0xdf4494: EnterFrame
    //     0xdf4494: stp             fp, lr, [SP, #-0x10]!
    //     0xdf4498: mov             fp, SP
    // 0xdf449c: AllocStack(0x28)
    //     0xdf449c: sub             SP, SP, #0x28
    // 0xdf44a0: SetupParameters([dynamic _ /* r0 */])
    //     0xdf44a0: ldr             x0, [fp, #0x18]
    //     0xdf44a4: ldur            w1, [x0, #0x17]
    //     0xdf44a8: add             x1, x1, HEAP, lsl #32
    //     0xdf44ac: stur            x1, [fp, #-8]
    // 0xdf44b0: CheckStackOverflow
    //     0xdf44b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf44b4: cmp             SP, x16
    //     0xdf44b8: b.ls            #0xdf4524
    // 0xdf44bc: r1 = 1
    //     0xdf44bc: mov             x1, #1
    // 0xdf44c0: r0 = AllocateContext()
    //     0xdf44c0: bl              #0x13de838  ; AllocateContextStub
    // 0xdf44c4: mov             x1, x0
    // 0xdf44c8: ldur            x0, [fp, #-8]
    // 0xdf44cc: StoreField: r1->field_b = r0
    //     0xdf44cc: stur            w0, [x1, #0xb]
    // 0xdf44d0: ldr             x2, [fp, #0x10]
    // 0xdf44d4: StoreField: r1->field_f = r2
    //     0xdf44d4: stur            w2, [x1, #0xf]
    // 0xdf44d8: LoadField: r3 = r0->field_1b
    //     0xdf44d8: ldur            w3, [x0, #0x1b]
    // 0xdf44dc: DecompressPointer r3
    //     0xdf44dc: add             x3, x3, HEAP, lsl #32
    // 0xdf44e0: mov             x2, x1
    // 0xdf44e4: stur            x3, [fp, #-0x10]
    // 0xdf44e8: r1 = Function '<anonymous closure>':.
    //     0xdf44e8: add             x1, PP, #0xd0, lsl #12  ; [pp+0xd0698] AnonymousClosure: (0xdf452c), in [package:flutter/src/material/calendar_date_picker.dart] _YearPickerState::_buildYearItem (0xdf3664)
    //     0xdf44ec: ldr             x1, [x1, #0x698]
    // 0xdf44f0: r0 = AllocateClosure()
    //     0xdf44f0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf44f4: r16 = <Color>
    //     0xdf44f4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xdf44f8: ldr             x16, [x16, #0xa90]
    // 0xdf44fc: ldur            lr, [fp, #-0x10]
    // 0xdf4500: stp             lr, x16, [SP, #8]
    // 0xdf4504: str             x0, [SP]
    // 0xdf4508: ldur            x0, [fp, #-0x10]
    // 0xdf450c: ClosureCall
    //     0xdf450c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0xdf4510: ldur            x2, [x0, #0x1f]
    //     0xdf4514: blr             x2
    // 0xdf4518: LeaveFrame
    //     0xdf4518: mov             SP, fp
    //     0xdf451c: ldp             fp, lr, [SP], #0x10
    // 0xdf4520: ret
    //     0xdf4520: ret             
    // 0xdf4524: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf4524: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf4528: b               #0xdf44bc
  }
  [closure] Color? <anonymous closure>(dynamic, DatePickerThemeData?) {
    // ** addr: 0xdf452c, size: 0xe0
    // 0xdf452c: EnterFrame
    //     0xdf452c: stp             fp, lr, [SP, #-0x10]!
    //     0xdf4530: mov             fp, SP
    // 0xdf4534: AllocStack(0x18)
    //     0xdf4534: sub             SP, SP, #0x18
    // 0xdf4538: SetupParameters([dynamic _ /* r0 */])
    //     0xdf4538: ldr             x0, [fp, #0x18]
    //     0xdf453c: ldur            w1, [x0, #0x17]
    //     0xdf4540: add             x1, x1, HEAP, lsl #32
    //     0xdf4544: stur            x1, [fp, #-8]
    // 0xdf4548: CheckStackOverflow
    //     0xdf4548: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf454c: cmp             SP, x16
    //     0xdf4550: b.ls            #0xdf4604
    // 0xdf4554: ldr             x0, [fp, #0x10]
    // 0xdf4558: cmp             w0, NULL
    // 0xdf455c: b.ne            #0xdf4568
    // 0xdf4560: r0 = Null
    //     0xdf4560: mov             x0, NULL
    // 0xdf4564: b               #0xdf45f8
    // 0xdf4568: r2 = LoadClassIdInstr(r0)
    //     0xdf4568: ldur            x2, [x0, #-1]
    //     0xdf456c: ubfx            x2, x2, #0xc, #0x14
    // 0xdf4570: r17 = 5167
    //     0xdf4570: mov             x17, #0x142f
    // 0xdf4574: cmp             x2, x17
    // 0xdf4578: b.eq            #0xdf45c8
    // 0xdf457c: r17 = 5168
    //     0xdf457c: mov             x17, #0x1430
    // 0xdf4580: cmp             x2, x17
    // 0xdf4584: b.ne            #0xdf45c8
    // 0xdf4588: r1 = 1
    //     0xdf4588: mov             x1, #1
    // 0xdf458c: r0 = AllocateContext()
    //     0xdf458c: bl              #0x13de838  ; AllocateContextStub
    // 0xdf4590: mov             x1, x0
    // 0xdf4594: ldr             x0, [fp, #0x10]
    // 0xdf4598: StoreField: r1->field_f = r0
    //     0xdf4598: stur            w0, [x1, #0xf]
    // 0xdf459c: mov             x2, x1
    // 0xdf45a0: r1 = Function '<anonymous closure>':.
    //     0xdf45a0: add             x1, PP, #0x26, lsl #12  ; [pp+0x26478] AnonymousClosure: (0xdf2558), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM3
    //     0xdf45a4: ldr             x1, [x1, #0x478]
    // 0xdf45a8: r0 = AllocateClosure()
    //     0xdf45a8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf45ac: r16 = <Color?>
    //     0xdf45ac: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xdf45b0: ldr             x16, [x16, #0xa40]
    // 0xdf45b4: stp             x0, x16, [SP]
    // 0xdf45b8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdf45b8: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdf45bc: r0 = resolveWith()
    //     0xdf45bc: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xdf45c0: mov             x1, x0
    // 0xdf45c4: b               #0xdf45d0
    // 0xdf45c8: LoadField: r1 = r0->field_5b
    //     0xdf45c8: ldur            w1, [x0, #0x5b]
    // 0xdf45cc: DecompressPointer r1
    //     0xdf45cc: add             x1, x1, HEAP, lsl #32
    // 0xdf45d0: cmp             w1, NULL
    // 0xdf45d4: b.ne            #0xdf45e0
    // 0xdf45d8: r1 = Null
    //     0xdf45d8: mov             x1, NULL
    // 0xdf45dc: b               #0xdf45f4
    // 0xdf45e0: ldur            x0, [fp, #-8]
    // 0xdf45e4: LoadField: r2 = r0->field_f
    //     0xdf45e4: ldur            w2, [x0, #0xf]
    // 0xdf45e8: DecompressPointer r2
    //     0xdf45e8: add             x2, x2, HEAP, lsl #32
    // 0xdf45ec: r0 = build()
    //     0xdf45ec: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xdf45f0: mov             x1, x0
    // 0xdf45f4: mov             x0, x1
    // 0xdf45f8: LeaveFrame
    //     0xdf45f8: mov             SP, fp
    //     0xdf45fc: ldp             fp, lr, [SP], #0x10
    // 0xdf4600: ret
    //     0xdf4600: ret             
    // 0xdf4604: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf4604: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf4608: b               #0xdf4554
  }
  [closure] WidgetStateProperty<Color?>? <anonymous closure>(dynamic, DatePickerThemeData?) {
    // ** addr: 0xdf460c, size: 0x180
    // 0xdf460c: EnterFrame
    //     0xdf460c: stp             fp, lr, [SP, #-0x10]!
    //     0xdf4610: mov             fp, SP
    // 0xdf4614: AllocStack(0x10)
    //     0xdf4614: sub             SP, SP, #0x10
    // 0xdf4618: SetupParameters([dynamic _ /* r0 */])
    //     0xdf4618: ldr             x0, [fp, #0x18]
    //     0xdf461c: ldur            w1, [x0, #0x17]
    //     0xdf4620: add             x1, x1, HEAP, lsl #32
    // 0xdf4624: CheckStackOverflow
    //     0xdf4624: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf4628: cmp             SP, x16
    //     0xdf462c: b.ls            #0xdf4784
    // 0xdf4630: LoadField: r0 = r1->field_1f
    //     0xdf4630: ldur            w0, [x1, #0x1f]
    // 0xdf4634: DecompressPointer r0
    //     0xdf4634: add             x0, x0, HEAP, lsl #32
    // 0xdf4638: tbnz            w0, #4, #0xdf46f8
    // 0xdf463c: ldr             x0, [fp, #0x10]
    // 0xdf4640: cmp             w0, NULL
    // 0xdf4644: b.ne            #0xdf4650
    // 0xdf4648: r0 = Null
    //     0xdf4648: mov             x0, NULL
    // 0xdf464c: b               #0xdf4778
    // 0xdf4650: r1 = LoadClassIdInstr(r0)
    //     0xdf4650: ldur            x1, [x0, #-1]
    //     0xdf4654: ubfx            x1, x1, #0xc, #0x14
    // 0xdf4658: r17 = 5167
    //     0xdf4658: mov             x17, #0x142f
    // 0xdf465c: cmp             x1, x17
    // 0xdf4660: b.ne            #0xdf4674
    // 0xdf4664: LoadField: r1 = r0->field_47
    //     0xdf4664: ldur            w1, [x0, #0x47]
    // 0xdf4668: DecompressPointer r1
    //     0xdf4668: add             x1, x1, HEAP, lsl #32
    // 0xdf466c: mov             x0, x1
    // 0xdf4670: b               #0xdf4778
    // 0xdf4674: r17 = 5168
    //     0xdf4674: mov             x17, #0x1430
    // 0xdf4678: cmp             x1, x17
    // 0xdf467c: b.ne            #0xdf46bc
    // 0xdf4680: r1 = 1
    //     0xdf4680: mov             x1, #1
    // 0xdf4684: r0 = AllocateContext()
    //     0xdf4684: bl              #0x13de838  ; AllocateContextStub
    // 0xdf4688: mov             x1, x0
    // 0xdf468c: ldr             x0, [fp, #0x10]
    // 0xdf4690: StoreField: r1->field_f = r0
    //     0xdf4690: stur            w0, [x1, #0xf]
    // 0xdf4694: mov             x2, x1
    // 0xdf4698: r1 = Function '<anonymous closure>':.
    //     0xdf4698: add             x1, PP, #0x26, lsl #12  ; [pp+0x26438] AnonymousClosure: (0xdf2bac), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM3
    //     0xdf469c: ldr             x1, [x1, #0x438]
    // 0xdf46a0: r0 = AllocateClosure()
    //     0xdf46a0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf46a4: r16 = <Color?>
    //     0xdf46a4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xdf46a8: ldr             x16, [x16, #0xa40]
    // 0xdf46ac: stp             x0, x16, [SP]
    // 0xdf46b0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdf46b0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdf46b4: r0 = resolveWith()
    //     0xdf46b4: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xdf46b8: b               #0xdf4778
    // 0xdf46bc: r1 = 1
    //     0xdf46bc: mov             x1, #1
    // 0xdf46c0: r0 = AllocateContext()
    //     0xdf46c0: bl              #0x13de838  ; AllocateContextStub
    // 0xdf46c4: mov             x1, x0
    // 0xdf46c8: ldr             x0, [fp, #0x10]
    // 0xdf46cc: StoreField: r1->field_f = r0
    //     0xdf46cc: stur            w0, [x1, #0xf]
    // 0xdf46d0: mov             x2, x1
    // 0xdf46d4: r1 = Function '<anonymous closure>':.
    //     0xdf46d4: add             x1, PP, #0x26, lsl #12  ; [pp+0x26440] AnonymousClosure: (0xdf2afc), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM2
    //     0xdf46d8: ldr             x1, [x1, #0x440]
    // 0xdf46dc: r0 = AllocateClosure()
    //     0xdf46dc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf46e0: r16 = <Color?>
    //     0xdf46e0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xdf46e4: ldr             x16, [x16, #0xa40]
    // 0xdf46e8: stp             x0, x16, [SP]
    // 0xdf46ec: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdf46ec: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdf46f0: r0 = resolveWith()
    //     0xdf46f0: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xdf46f4: b               #0xdf4778
    // 0xdf46f8: ldr             x0, [fp, #0x10]
    // 0xdf46fc: cmp             w0, NULL
    // 0xdf4700: b.ne            #0xdf470c
    // 0xdf4704: r1 = Null
    //     0xdf4704: mov             x1, NULL
    // 0xdf4708: b               #0xdf4774
    // 0xdf470c: r1 = LoadClassIdInstr(r0)
    //     0xdf470c: ldur            x1, [x0, #-1]
    //     0xdf4710: ubfx            x1, x1, #0xc, #0x14
    // 0xdf4714: r17 = 5167
    //     0xdf4714: mov             x17, #0x142f
    // 0xdf4718: cmp             x1, x17
    // 0xdf471c: b.eq            #0xdf476c
    // 0xdf4720: r17 = 5168
    //     0xdf4720: mov             x17, #0x1430
    // 0xdf4724: cmp             x1, x17
    // 0xdf4728: b.ne            #0xdf476c
    // 0xdf472c: r1 = 1
    //     0xdf472c: mov             x1, #1
    // 0xdf4730: r0 = AllocateContext()
    //     0xdf4730: bl              #0x13de838  ; AllocateContextStub
    // 0xdf4734: mov             x1, x0
    // 0xdf4738: ldr             x0, [fp, #0x10]
    // 0xdf473c: StoreField: r1->field_f = r0
    //     0xdf473c: stur            w0, [x1, #0xf]
    // 0xdf4740: mov             x2, x1
    // 0xdf4744: r1 = Function '<anonymous closure>':.
    //     0xdf4744: add             x1, PP, #0x26, lsl #12  ; [pp+0x26470] AnonymousClosure: (0xdf2bac), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM3
    //     0xdf4748: ldr             x1, [x1, #0x470]
    // 0xdf474c: r0 = AllocateClosure()
    //     0xdf474c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf4750: r16 = <Color?>
    //     0xdf4750: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xdf4754: ldr             x16, [x16, #0xa40]
    // 0xdf4758: stp             x0, x16, [SP]
    // 0xdf475c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdf475c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdf4760: r0 = resolveWith()
    //     0xdf4760: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xdf4764: mov             x1, x0
    // 0xdf4768: b               #0xdf4774
    // 0xdf476c: LoadField: r1 = r0->field_57
    //     0xdf476c: ldur            w1, [x0, #0x57]
    // 0xdf4770: DecompressPointer r1
    //     0xdf4770: add             x1, x1, HEAP, lsl #32
    // 0xdf4774: mov             x0, x1
    // 0xdf4778: LeaveFrame
    //     0xdf4778: mov             SP, fp
    //     0xdf477c: ldp             fp, lr, [SP], #0x10
    // 0xdf4780: ret
    //     0xdf4780: ret             
    // 0xdf4784: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf4784: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf4788: b               #0xdf4630
  }
  [closure] WidgetStateProperty<Color?>? <anonymous closure>(dynamic, DatePickerThemeData?) {
    // ** addr: 0xdf478c, size: 0x180
    // 0xdf478c: EnterFrame
    //     0xdf478c: stp             fp, lr, [SP, #-0x10]!
    //     0xdf4790: mov             fp, SP
    // 0xdf4794: AllocStack(0x10)
    //     0xdf4794: sub             SP, SP, #0x10
    // 0xdf4798: SetupParameters([dynamic _ /* r0 */])
    //     0xdf4798: ldr             x0, [fp, #0x18]
    //     0xdf479c: ldur            w1, [x0, #0x17]
    //     0xdf47a0: add             x1, x1, HEAP, lsl #32
    // 0xdf47a4: CheckStackOverflow
    //     0xdf47a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf47a8: cmp             SP, x16
    //     0xdf47ac: b.ls            #0xdf4904
    // 0xdf47b0: LoadField: r0 = r1->field_1f
    //     0xdf47b0: ldur            w0, [x1, #0x1f]
    // 0xdf47b4: DecompressPointer r0
    //     0xdf47b4: add             x0, x0, HEAP, lsl #32
    // 0xdf47b8: tbnz            w0, #4, #0xdf4878
    // 0xdf47bc: ldr             x0, [fp, #0x10]
    // 0xdf47c0: cmp             w0, NULL
    // 0xdf47c4: b.ne            #0xdf47d0
    // 0xdf47c8: r0 = Null
    //     0xdf47c8: mov             x0, NULL
    // 0xdf47cc: b               #0xdf48f8
    // 0xdf47d0: r1 = LoadClassIdInstr(r0)
    //     0xdf47d0: ldur            x1, [x0, #-1]
    //     0xdf47d4: ubfx            x1, x1, #0xc, #0x14
    // 0xdf47d8: r17 = 5167
    //     0xdf47d8: mov             x17, #0x142f
    // 0xdf47dc: cmp             x1, x17
    // 0xdf47e0: b.ne            #0xdf47f4
    // 0xdf47e4: LoadField: r1 = r0->field_43
    //     0xdf47e4: ldur            w1, [x0, #0x43]
    // 0xdf47e8: DecompressPointer r1
    //     0xdf47e8: add             x1, x1, HEAP, lsl #32
    // 0xdf47ec: mov             x0, x1
    // 0xdf47f0: b               #0xdf48f8
    // 0xdf47f4: r17 = 5168
    //     0xdf47f4: mov             x17, #0x1430
    // 0xdf47f8: cmp             x1, x17
    // 0xdf47fc: b.ne            #0xdf483c
    // 0xdf4800: r1 = 1
    //     0xdf4800: mov             x1, #1
    // 0xdf4804: r0 = AllocateContext()
    //     0xdf4804: bl              #0x13de838  ; AllocateContextStub
    // 0xdf4808: mov             x1, x0
    // 0xdf480c: ldr             x0, [fp, #0x10]
    // 0xdf4810: StoreField: r1->field_f = r0
    //     0xdf4810: stur            w0, [x1, #0xf]
    // 0xdf4814: mov             x2, x1
    // 0xdf4818: r1 = Function '<anonymous closure>':.
    //     0xdf4818: add             x1, PP, #0x26, lsl #12  ; [pp+0x26458] AnonymousClosure: (0xdf3294), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM3
    //     0xdf481c: ldr             x1, [x1, #0x458]
    // 0xdf4820: r0 = AllocateClosure()
    //     0xdf4820: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf4824: r16 = <Color?>
    //     0xdf4824: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xdf4828: ldr             x16, [x16, #0xa40]
    // 0xdf482c: stp             x0, x16, [SP]
    // 0xdf4830: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdf4830: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdf4834: r0 = resolveWith()
    //     0xdf4834: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xdf4838: b               #0xdf48f8
    // 0xdf483c: r1 = 1
    //     0xdf483c: mov             x1, #1
    // 0xdf4840: r0 = AllocateContext()
    //     0xdf4840: bl              #0x13de838  ; AllocateContextStub
    // 0xdf4844: mov             x1, x0
    // 0xdf4848: ldr             x0, [fp, #0x10]
    // 0xdf484c: StoreField: r1->field_f = r0
    //     0xdf484c: stur            w0, [x1, #0xf]
    // 0xdf4850: mov             x2, x1
    // 0xdf4854: r1 = Function '<anonymous closure>':.
    //     0xdf4854: add             x1, PP, #0x26, lsl #12  ; [pp+0x26460] AnonymousClosure: (0xdf3120), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM2
    //     0xdf4858: ldr             x1, [x1, #0x460]
    // 0xdf485c: r0 = AllocateClosure()
    //     0xdf485c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf4860: r16 = <Color?>
    //     0xdf4860: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xdf4864: ldr             x16, [x16, #0xa40]
    // 0xdf4868: stp             x0, x16, [SP]
    // 0xdf486c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdf486c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdf4870: r0 = resolveWith()
    //     0xdf4870: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xdf4874: b               #0xdf48f8
    // 0xdf4878: ldr             x0, [fp, #0x10]
    // 0xdf487c: cmp             w0, NULL
    // 0xdf4880: b.ne            #0xdf488c
    // 0xdf4884: r1 = Null
    //     0xdf4884: mov             x1, NULL
    // 0xdf4888: b               #0xdf48f4
    // 0xdf488c: r1 = LoadClassIdInstr(r0)
    //     0xdf488c: ldur            x1, [x0, #-1]
    //     0xdf4890: ubfx            x1, x1, #0xc, #0x14
    // 0xdf4894: r17 = 5167
    //     0xdf4894: mov             x17, #0x142f
    // 0xdf4898: cmp             x1, x17
    // 0xdf489c: b.eq            #0xdf48ec
    // 0xdf48a0: r17 = 5168
    //     0xdf48a0: mov             x17, #0x1430
    // 0xdf48a4: cmp             x1, x17
    // 0xdf48a8: b.ne            #0xdf48ec
    // 0xdf48ac: r1 = 1
    //     0xdf48ac: mov             x1, #1
    // 0xdf48b0: r0 = AllocateContext()
    //     0xdf48b0: bl              #0x13de838  ; AllocateContextStub
    // 0xdf48b4: mov             x1, x0
    // 0xdf48b8: ldr             x0, [fp, #0x10]
    // 0xdf48bc: StoreField: r1->field_f = r0
    //     0xdf48bc: stur            w0, [x1, #0xf]
    // 0xdf48c0: mov             x2, x1
    // 0xdf48c4: r1 = Function '<anonymous closure>':.
    //     0xdf48c4: add             x1, PP, #0x26, lsl #12  ; [pp+0x26468] AnonymousClosure: (0xdf490c), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM3
    //     0xdf48c8: ldr             x1, [x1, #0x468]
    // 0xdf48cc: r0 = AllocateClosure()
    //     0xdf48cc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf48d0: r16 = <Color?>
    //     0xdf48d0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xdf48d4: ldr             x16, [x16, #0xa40]
    // 0xdf48d8: stp             x0, x16, [SP]
    // 0xdf48dc: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdf48dc: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdf48e0: r0 = resolveWith()
    //     0xdf48e0: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xdf48e4: mov             x1, x0
    // 0xdf48e8: b               #0xdf48f4
    // 0xdf48ec: LoadField: r1 = r0->field_53
    //     0xdf48ec: ldur            w1, [x0, #0x53]
    // 0xdf48f0: DecompressPointer r1
    //     0xdf48f0: add             x1, x1, HEAP, lsl #32
    // 0xdf48f4: mov             x0, x1
    // 0xdf48f8: LeaveFrame
    //     0xdf48f8: mov             SP, fp
    //     0xdf48fc: ldp             fp, lr, [SP], #0x10
    // 0xdf4900: ret
    //     0xdf4900: ret             
    // 0xdf4904: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf4904: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf4908: b               #0xdf47b0
  }
  [closure] Y0? effectiveValue<Y0>(dynamic, (dynamic, DatePickerThemeData?) => Y0?) {
    // ** addr: 0xdf4aa8, size: 0x88
    // 0xdf4aa8: EnterFrame
    //     0xdf4aa8: stp             fp, lr, [SP, #-0x10]!
    //     0xdf4aac: mov             fp, SP
    // 0xdf4ab0: AllocStack(0x18)
    //     0xdf4ab0: sub             SP, SP, #0x18
    // 0xdf4ab4: SetupParameters([dynamic _ /* r0 */])
    //     0xdf4ab4: ldr             x0, [fp, #0x18]
    //     0xdf4ab8: ldur            w1, [x0, #0x17]
    //     0xdf4abc: add             x1, x1, HEAP, lsl #32
    //     0xdf4ac0: stur            x1, [fp, #-8]
    // 0xdf4ac4: CheckStackOverflow
    //     0xdf4ac4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf4ac8: cmp             SP, x16
    //     0xdf4acc: b.ls            #0xdf4b28
    // 0xdf4ad0: LoadField: r0 = r1->field_13
    //     0xdf4ad0: ldur            w0, [x1, #0x13]
    // 0xdf4ad4: DecompressPointer r0
    //     0xdf4ad4: add             x0, x0, HEAP, lsl #32
    // 0xdf4ad8: ldr             x16, [fp, #0x10]
    // 0xdf4adc: stp             x0, x16, [SP]
    // 0xdf4ae0: ldr             x0, [fp, #0x10]
    // 0xdf4ae4: ClosureCall
    //     0xdf4ae4: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xdf4ae8: ldur            x2, [x0, #0x1f]
    //     0xdf4aec: blr             x2
    // 0xdf4af0: cmp             w0, NULL
    // 0xdf4af4: b.ne            #0xdf4b1c
    // 0xdf4af8: ldur            x0, [fp, #-8]
    // 0xdf4afc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdf4afc: ldur            w1, [x0, #0x17]
    // 0xdf4b00: DecompressPointer r1
    //     0xdf4b00: add             x1, x1, HEAP, lsl #32
    // 0xdf4b04: ldr             x16, [fp, #0x10]
    // 0xdf4b08: stp             x1, x16, [SP]
    // 0xdf4b0c: ldr             x0, [fp, #0x10]
    // 0xdf4b10: ClosureCall
    //     0xdf4b10: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xdf4b14: ldur            x2, [x0, #0x1f]
    //     0xdf4b18: blr             x2
    // 0xdf4b1c: LeaveFrame
    //     0xdf4b1c: mov             SP, fp
    //     0xdf4b20: ldp             fp, lr, [SP], #0x10
    // 0xdf4b24: ret
    //     0xdf4b24: ret             
    // 0xdf4b28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf4b28: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf4b2c: b               #0xdf4ad0
  }
  [closure] Widget _buildYearItem(dynamic, BuildContext, int) {
    // ** addr: 0xdf4b30, size: 0x40
    // 0xdf4b30: EnterFrame
    //     0xdf4b30: stp             fp, lr, [SP, #-0x10]!
    //     0xdf4b34: mov             fp, SP
    // 0xdf4b38: ldr             x0, [fp, #0x20]
    // 0xdf4b3c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdf4b3c: ldur            w1, [x0, #0x17]
    // 0xdf4b40: DecompressPointer r1
    //     0xdf4b40: add             x1, x1, HEAP, lsl #32
    // 0xdf4b44: CheckStackOverflow
    //     0xdf4b44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf4b48: cmp             SP, x16
    //     0xdf4b4c: b.ls            #0xdf4b68
    // 0xdf4b50: ldr             x2, [fp, #0x18]
    // 0xdf4b54: ldr             x3, [fp, #0x10]
    // 0xdf4b58: r0 = _buildYearItem()
    //     0xdf4b58: bl              #0xdf3664  ; [package:flutter/src/material/calendar_date_picker.dart] _YearPickerState::_buildYearItem
    // 0xdf4b5c: LeaveFrame
    //     0xdf4b5c: mov             SP, fp
    //     0xdf4b60: ldp             fp, lr, [SP], #0x10
    // 0xdf4b64: ret
    //     0xdf4b64: ret             
    // 0xdf4b68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf4b68: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf4b6c: b               #0xdf4b50
  }
  _ build(/* No info */) {
    // ** addr: 0xdf4bf8, size: 0x1ec
    // 0xdf4bf8: EnterFrame
    //     0xdf4bf8: stp             fp, lr, [SP, #-0x10]!
    //     0xdf4bfc: mov             fp, SP
    // 0xdf4c00: AllocStack(0x38)
    //     0xdf4c00: sub             SP, SP, #0x38
    // 0xdf4c04: SetupParameters(_YearPickerState this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0xdf4c04: stur            x1, [fp, #-0x10]
    //     0xdf4c08: stur            x2, [fp, #-0x18]
    // 0xdf4c0c: CheckStackOverflow
    //     0xdf4c0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf4c10: cmp             SP, x16
    //     0xdf4c14: b.ls            #0xdf4dd8
    // 0xdf4c18: LoadField: r0 = r1->field_13
    //     0xdf4c18: ldur            w0, [x1, #0x13]
    // 0xdf4c1c: DecompressPointer r0
    //     0xdf4c1c: add             x0, x0, HEAP, lsl #32
    // 0xdf4c20: stur            x0, [fp, #-8]
    // 0xdf4c24: LoadField: r3 = r1->field_b
    //     0xdf4c24: ldur            w3, [x1, #0xb]
    // 0xdf4c28: DecompressPointer r3
    //     0xdf4c28: add             x3, x3, HEAP, lsl #32
    // 0xdf4c2c: cmp             w3, NULL
    // 0xdf4c30: b.eq            #0xdf4de0
    // 0xdf4c34: r0 = _YearPickerGridDelegate()
    //     0xdf4c34: bl              #0xdf50f0  ; Allocate_YearPickerGridDelegateStub -> _YearPickerGridDelegate (size=0xc)
    // 0xdf4c38: mov             x2, x0
    // 0xdf4c3c: ldur            x0, [fp, #-0x18]
    // 0xdf4c40: stur            x2, [fp, #-0x20]
    // 0xdf4c44: StoreField: r2->field_7 = r0
    //     0xdf4c44: stur            w0, [x2, #7]
    // 0xdf4c48: ldur            x1, [fp, #-0x10]
    // 0xdf4c4c: r0 = _itemCount()
    //     0xdf4c4c: bl              #0xdf4308  ; [package:flutter/src/material/calendar_date_picker.dart] _YearPickerState::_itemCount
    // 0xdf4c50: mov             x1, x0
    // 0xdf4c54: r0 = 18
    //     0xdf4c54: mov             x0, #0x12
    // 0xdf4c58: cmp             x1, x0
    // 0xdf4c5c: csel            x5, x0, x1, lt
    // 0xdf4c60: ldur            x2, [fp, #-0x10]
    // 0xdf4c64: stur            x5, [fp, #-0x28]
    // 0xdf4c68: r1 = Function '_buildYearItem@54260463':.
    //     0xdf4c68: add             x1, PP, #0xd0, lsl #12  ; [pp+0xd0640] AnonymousClosure: (0xdf4b30), in [package:flutter/src/material/calendar_date_picker.dart] _YearPickerState::_buildYearItem (0xdf3664)
    //     0xdf4c6c: ldr             x1, [x1, #0x640]
    // 0xdf4c70: r0 = AllocateClosure()
    //     0xdf4c70: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf4c74: stur            x0, [fp, #-0x10]
    // 0xdf4c78: r0 = GridView()
    //     0xdf4c78: bl              #0xdf0d24  ; AllocateGridViewStub -> GridView (size=0x64)
    // 0xdf4c7c: stur            x0, [fp, #-0x18]
    // 0xdf4c80: ldur            x16, [fp, #-8]
    // 0xdf4c84: r30 = Instance_EdgeInsets
    //     0xdf4c84: add             lr, PP, #0x26, lsl #12  ; [pp+0x26510] Obj!EdgeInsets@129cdb1
    //     0xdf4c88: ldr             lr, [lr, #0x510]
    // 0xdf4c8c: stp             lr, x16, [SP]
    // 0xdf4c90: mov             x1, x0
    // 0xdf4c94: ldur            x2, [fp, #-0x20]
    // 0xdf4c98: ldur            x3, [fp, #-0x10]
    // 0xdf4c9c: ldur            x5, [fp, #-0x28]
    // 0xdf4ca0: r4 = const [0, 0x6, 0x2, 0x4, controller, 0x4, padding, 0x5, null]
    //     0xdf4ca0: add             x4, PP, #0xd0, lsl #12  ; [pp+0xd0648] List(9) [0, 0x6, 0x2, 0x4, "controller", 0x4, "padding", 0x5, Null]
    //     0xdf4ca4: ldr             x4, [x4, #0x648]
    // 0xdf4ca8: r0 = GridView.builder()
    //     0xdf4ca8: bl              #0xdf4de4  ; [package:flutter/src/widgets/scroll_view.dart] GridView::GridView.builder
    // 0xdf4cac: r0 = Material()
    //     0xdf4cac: bl              #0x8a54b0  ; AllocateMaterialStub -> Material (size=0x44)
    // 0xdf4cb0: mov             x2, x0
    // 0xdf4cb4: r0 = Instance_MaterialType
    //     0xdf4cb4: add             x0, PP, #0x8c, lsl #12  ; [pp+0x8c618] Obj!MaterialType@12c5361
    //     0xdf4cb8: ldr             x0, [x0, #0x618]
    // 0xdf4cbc: stur            x2, [fp, #-8]
    // 0xdf4cc0: StoreField: r2->field_f = r0
    //     0xdf4cc0: stur            w0, [x2, #0xf]
    // 0xdf4cc4: ArrayStore: r2[0] = rZR  ; List_8
    //     0xdf4cc4: stur            xzr, [x2, #0x17]
    // 0xdf4cc8: r0 = true
    //     0xdf4cc8: add             x0, NULL, #0x20  ; true
    // 0xdf4ccc: StoreField: r2->field_33 = r0
    //     0xdf4ccc: stur            w0, [x2, #0x33]
    // 0xdf4cd0: r0 = Instance_Clip
    //     0xdf4cd0: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xdf4cd4: ldr             x0, [x0, #0x840]
    // 0xdf4cd8: StoreField: r2->field_37 = r0
    //     0xdf4cd8: stur            w0, [x2, #0x37]
    // 0xdf4cdc: r1 = Instance_Duration
    //     0xdf4cdc: add             x1, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xdf4ce0: ldr             x1, [x1, #0x318]
    // 0xdf4ce4: StoreField: r2->field_3b = r1
    //     0xdf4ce4: stur            w1, [x2, #0x3b]
    // 0xdf4ce8: ldur            x1, [fp, #-0x18]
    // 0xdf4cec: StoreField: r2->field_b = r1
    //     0xdf4cec: stur            w1, [x2, #0xb]
    // 0xdf4cf0: r1 = false
    //     0xdf4cf0: add             x1, NULL, #0x30  ; false
    // 0xdf4cf4: StoreField: r2->field_13 = r1
    //     0xdf4cf4: stur            w1, [x2, #0x13]
    // 0xdf4cf8: r1 = <FlexParentData>
    //     0xdf4cf8: add             x1, PP, #0x15, lsl #12  ; [pp+0x15878] TypeArguments: <FlexParentData>
    //     0xdf4cfc: ldr             x1, [x1, #0x878]
    // 0xdf4d00: r0 = Expanded()
    //     0xdf4d00: bl              #0x8a5b10  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0xdf4d04: mov             x3, x0
    // 0xdf4d08: r0 = 1
    //     0xdf4d08: mov             x0, #1
    // 0xdf4d0c: stur            x3, [fp, #-0x10]
    // 0xdf4d10: StoreField: r3->field_13 = r0
    //     0xdf4d10: stur            x0, [x3, #0x13]
    // 0xdf4d14: r0 = Instance_FlexFit
    //     0xdf4d14: add             x0, PP, #0x15, lsl #12  ; [pp+0x15880] Obj!FlexFit@12c4641
    //     0xdf4d18: ldr             x0, [x0, #0x880]
    // 0xdf4d1c: StoreField: r3->field_1b = r0
    //     0xdf4d1c: stur            w0, [x3, #0x1b]
    // 0xdf4d20: ldur            x0, [fp, #-8]
    // 0xdf4d24: StoreField: r3->field_b = r0
    //     0xdf4d24: stur            w0, [x3, #0xb]
    // 0xdf4d28: r1 = Null
    //     0xdf4d28: mov             x1, NULL
    // 0xdf4d2c: r2 = 6
    //     0xdf4d2c: mov             x2, #6
    // 0xdf4d30: r0 = AllocateArray()
    //     0xdf4d30: bl              #0x13df928  ; AllocateArrayStub
    // 0xdf4d34: stur            x0, [fp, #-8]
    // 0xdf4d38: r16 = Instance_Divider
    //     0xdf4d38: add             x16, PP, #0x28, lsl #12  ; [pp+0x288a0] Obj!Divider@12b6931
    //     0xdf4d3c: ldr             x16, [x16, #0x8a0]
    // 0xdf4d40: StoreField: r0->field_f = r16
    //     0xdf4d40: stur            w16, [x0, #0xf]
    // 0xdf4d44: ldur            x1, [fp, #-0x10]
    // 0xdf4d48: StoreField: r0->field_13 = r1
    //     0xdf4d48: stur            w1, [x0, #0x13]
    // 0xdf4d4c: r16 = Instance_Divider
    //     0xdf4d4c: add             x16, PP, #0x28, lsl #12  ; [pp+0x288a0] Obj!Divider@12b6931
    //     0xdf4d50: ldr             x16, [x16, #0x8a0]
    // 0xdf4d54: ArrayStore: r0[0] = r16  ; List_4
    //     0xdf4d54: stur            w16, [x0, #0x17]
    // 0xdf4d58: r1 = <Widget>
    //     0xdf4d58: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xdf4d5c: r0 = AllocateGrowableArray()
    //     0xdf4d5c: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xdf4d60: mov             x1, x0
    // 0xdf4d64: ldur            x0, [fp, #-8]
    // 0xdf4d68: stur            x1, [fp, #-0x10]
    // 0xdf4d6c: StoreField: r1->field_f = r0
    //     0xdf4d6c: stur            w0, [x1, #0xf]
    // 0xdf4d70: r0 = 6
    //     0xdf4d70: mov             x0, #6
    // 0xdf4d74: StoreField: r1->field_b = r0
    //     0xdf4d74: stur            w0, [x1, #0xb]
    // 0xdf4d78: r0 = Column()
    //     0xdf4d78: bl              #0x8a5b1c  ; AllocateColumnStub -> Column (size=0x38)
    // 0xdf4d7c: r1 = Instance_Axis
    //     0xdf4d7c: ldr             x1, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xdf4d80: StoreField: r0->field_f = r1
    //     0xdf4d80: stur            w1, [x0, #0xf]
    // 0xdf4d84: r1 = Instance_MainAxisAlignment
    //     0xdf4d84: add             x1, PP, #0x15, lsl #12  ; [pp+0x15820] Obj!MainAxisAlignment@12c4541
    //     0xdf4d88: ldr             x1, [x1, #0x820]
    // 0xdf4d8c: StoreField: r0->field_13 = r1
    //     0xdf4d8c: stur            w1, [x0, #0x13]
    // 0xdf4d90: r1 = Instance_MainAxisSize
    //     0xdf4d90: add             x1, PP, #0x15, lsl #12  ; [pp+0x15828] Obj!MainAxisSize@12c4621
    //     0xdf4d94: ldr             x1, [x1, #0x828]
    // 0xdf4d98: ArrayStore: r0[0] = r1  ; List_4
    //     0xdf4d98: stur            w1, [x0, #0x17]
    // 0xdf4d9c: r1 = Instance_CrossAxisAlignment
    //     0xdf4d9c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15888] Obj!CrossAxisAlignment@12c44a1
    //     0xdf4da0: ldr             x1, [x1, #0x888]
    // 0xdf4da4: StoreField: r0->field_1b = r1
    //     0xdf4da4: stur            w1, [x0, #0x1b]
    // 0xdf4da8: r1 = Instance_VerticalDirection
    //     0xdf4da8: add             x1, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xdf4dac: ldr             x1, [x1, #0x838]
    // 0xdf4db0: StoreField: r0->field_23 = r1
    //     0xdf4db0: stur            w1, [x0, #0x23]
    // 0xdf4db4: r1 = Instance_Clip
    //     0xdf4db4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xdf4db8: ldr             x1, [x1, #0x840]
    // 0xdf4dbc: StoreField: r0->field_2b = r1
    //     0xdf4dbc: stur            w1, [x0, #0x2b]
    // 0xdf4dc0: StoreField: r0->field_2f = rZR
    //     0xdf4dc0: stur            xzr, [x0, #0x2f]
    // 0xdf4dc4: ldur            x1, [fp, #-0x10]
    // 0xdf4dc8: StoreField: r0->field_b = r1
    //     0xdf4dc8: stur            w1, [x0, #0xb]
    // 0xdf4dcc: LeaveFrame
    //     0xdf4dcc: mov             SP, fp
    //     0xdf4dd0: ldp             fp, lr, [SP], #0x10
    // 0xdf4dd4: ret
    //     0xdf4dd4: ret             
    // 0xdf4dd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf4dd8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf4ddc: b               #0xdf4c18
    // 0xdf4de0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf4de0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf6d250, size: 0x134
    // 0xf6d250: EnterFrame
    //     0xf6d250: stp             fp, lr, [SP, #-0x10]!
    //     0xf6d254: mov             fp, SP
    // 0xf6d258: AllocStack(0x20)
    //     0xf6d258: sub             SP, SP, #0x20
    // 0xf6d25c: SetupParameters(_YearPickerState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xf6d25c: mov             x4, x1
    //     0xf6d260: mov             x3, x2
    //     0xf6d264: stur            x1, [fp, #-8]
    //     0xf6d268: stur            x2, [fp, #-0x10]
    // 0xf6d26c: CheckStackOverflow
    //     0xf6d26c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6d270: cmp             SP, x16
    //     0xf6d274: b.ls            #0xf6d370
    // 0xf6d278: mov             x0, x3
    // 0xf6d27c: r2 = Null
    //     0xf6d27c: mov             x2, NULL
    // 0xf6d280: r1 = Null
    //     0xf6d280: mov             x1, NULL
    // 0xf6d284: r4 = 60
    //     0xf6d284: mov             x4, #0x3c
    // 0xf6d288: branchIfSmi(r0, 0xf6d294)
    //     0xf6d288: tbz             w0, #0, #0xf6d294
    // 0xf6d28c: r4 = LoadClassIdInstr(r0)
    //     0xf6d28c: ldur            x4, [x0, #-1]
    //     0xf6d290: ubfx            x4, x4, #0xc, #0x14
    // 0xf6d294: r17 = 6488
    //     0xf6d294: mov             x17, #0x1958
    // 0xf6d298: cmp             x4, x17
    // 0xf6d29c: b.eq            #0xf6d2b4
    // 0xf6d2a0: r8 = YearPicker
    //     0xf6d2a0: add             x8, PP, #0xd0, lsl #12  ; [pp+0xd06a8] Type: YearPicker
    //     0xf6d2a4: ldr             x8, [x8, #0x6a8]
    // 0xf6d2a8: r3 = Null
    //     0xf6d2a8: add             x3, PP, #0xd0, lsl #12  ; [pp+0xd06b0] Null
    //     0xf6d2ac: ldr             x3, [x3, #0x6b0]
    // 0xf6d2b0: r0 = YearPicker()
    //     0xf6d2b0: bl              #0xdecff4  ; IsType_YearPicker_Stub
    // 0xf6d2b4: ldur            x3, [fp, #-8]
    // 0xf6d2b8: LoadField: r2 = r3->field_7
    //     0xf6d2b8: ldur            w2, [x3, #7]
    // 0xf6d2bc: DecompressPointer r2
    //     0xf6d2bc: add             x2, x2, HEAP, lsl #32
    // 0xf6d2c0: ldur            x0, [fp, #-0x10]
    // 0xf6d2c4: r1 = Null
    //     0xf6d2c4: mov             x1, NULL
    // 0xf6d2c8: cmp             w2, NULL
    // 0xf6d2cc: b.eq            #0xf6d2f0
    // 0xf6d2d0: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf6d2d0: ldur            w4, [x2, #0x17]
    // 0xf6d2d4: DecompressPointer r4
    //     0xf6d2d4: add             x4, x4, HEAP, lsl #32
    // 0xf6d2d8: r8 = X0 bound StatefulWidget
    //     0xf6d2d8: add             x8, PP, #0x12, lsl #12  ; [pp+0x12498] TypeParameter: X0 bound StatefulWidget
    //     0xf6d2dc: ldr             x8, [x8, #0x498]
    // 0xf6d2e0: LoadField: r9 = r4->field_7
    //     0xf6d2e0: ldur            x9, [x4, #7]
    // 0xf6d2e4: r3 = Null
    //     0xf6d2e4: add             x3, PP, #0xd0, lsl #12  ; [pp+0xd06c0] Null
    //     0xf6d2e8: ldr             x3, [x3, #0x6c0]
    // 0xf6d2ec: blr             x9
    // 0xf6d2f0: ldur            x1, [fp, #-8]
    // 0xf6d2f4: LoadField: r0 = r1->field_b
    //     0xf6d2f4: ldur            w0, [x1, #0xb]
    // 0xf6d2f8: DecompressPointer r0
    //     0xf6d2f8: add             x0, x0, HEAP, lsl #32
    // 0xf6d2fc: cmp             w0, NULL
    // 0xf6d300: b.eq            #0xf6d378
    // 0xf6d304: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xf6d304: ldur            w2, [x0, #0x17]
    // 0xf6d308: DecompressPointer r2
    //     0xf6d308: add             x2, x2, HEAP, lsl #32
    // 0xf6d30c: ldur            x0, [fp, #-0x10]
    // 0xf6d310: ArrayLoad: r3 = r0[0]  ; List_4
    //     0xf6d310: ldur            w3, [x0, #0x17]
    // 0xf6d314: DecompressPointer r3
    //     0xf6d314: add             x3, x3, HEAP, lsl #32
    // 0xf6d318: stp             x3, x2, [SP]
    // 0xf6d31c: r0 = ==()
    //     0xf6d31c: bl              #0x124eecc  ; [dart:core] DateTime::==
    // 0xf6d320: tbz             w0, #4, #0xf6d360
    // 0xf6d324: ldur            x1, [fp, #-8]
    // 0xf6d328: LoadField: r0 = r1->field_b
    //     0xf6d328: ldur            w0, [x1, #0xb]
    // 0xf6d32c: DecompressPointer r0
    //     0xf6d32c: add             x0, x0, HEAP, lsl #32
    // 0xf6d330: cmp             w0, NULL
    // 0xf6d334: b.eq            #0xf6d37c
    // 0xf6d338: LoadField: r3 = r1->field_13
    //     0xf6d338: ldur            w3, [x1, #0x13]
    // 0xf6d33c: DecompressPointer r3
    //     0xf6d33c: add             x3, x3, HEAP, lsl #32
    // 0xf6d340: stur            x3, [fp, #-0x10]
    // 0xf6d344: cmp             w3, NULL
    // 0xf6d348: b.eq            #0xf6d380
    // 0xf6d34c: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xf6d34c: ldur            w2, [x0, #0x17]
    // 0xf6d350: DecompressPointer r2
    //     0xf6d350: add             x2, x2, HEAP, lsl #32
    // 0xf6d354: r0 = _scrollOffsetForYear()
    //     0xf6d354: bl              #0xf6d384  ; [package:flutter/src/material/calendar_date_picker.dart] _YearPickerState::_scrollOffsetForYear
    // 0xf6d358: ldur            x1, [fp, #-0x10]
    // 0xf6d35c: r0 = jumpTo()
    //     0xf6d35c: bl              #0x86b934  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::jumpTo
    // 0xf6d360: r0 = Null
    //     0xf6d360: mov             x0, NULL
    // 0xf6d364: LeaveFrame
    //     0xf6d364: mov             SP, fp
    //     0xf6d368: ldp             fp, lr, [SP], #0x10
    // 0xf6d36c: ret
    //     0xf6d36c: ret             
    // 0xf6d370: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6d370: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6d374: b               #0xf6d278
    // 0xf6d378: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6d378: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6d37c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6d37c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6d380: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6d380: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _scrollOffsetForYear(/* No info */) {
    // ** addr: 0xf6d384, size: 0x118
    // 0xf6d384: EnterFrame
    //     0xf6d384: stp             fp, lr, [SP, #-0x10]!
    //     0xf6d388: mov             fp, SP
    // 0xf6d38c: AllocStack(0x18)
    //     0xf6d38c: sub             SP, SP, #0x18
    // 0xf6d390: SetupParameters(_YearPickerState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1 */)
    //     0xf6d390: mov             x0, x1
    //     0xf6d394: stur            x1, [fp, #-8]
    //     0xf6d398: mov             x1, x2
    // 0xf6d39c: CheckStackOverflow
    //     0xf6d39c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6d3a0: cmp             SP, x16
    //     0xf6d3a4: b.ls            #0xf6d488
    // 0xf6d3a8: r0 = _parts()
    //     0xf6d3a8: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xf6d3ac: mov             x2, x0
    // 0xf6d3b0: LoadField: r0 = r2->field_b
    //     0xf6d3b0: ldur            w0, [x2, #0xb]
    // 0xf6d3b4: r1 = LoadInt32Instr(r0)
    //     0xf6d3b4: sbfx            x1, x0, #1, #0x1f
    // 0xf6d3b8: mov             x0, x1
    // 0xf6d3bc: r1 = 8
    //     0xf6d3bc: mov             x1, #8
    // 0xf6d3c0: cmp             x1, x0
    // 0xf6d3c4: b.hs            #0xf6d490
    // 0xf6d3c8: LoadField: r0 = r2->field_2f
    //     0xf6d3c8: ldur            w0, [x2, #0x2f]
    // 0xf6d3cc: DecompressPointer r0
    //     0xf6d3cc: add             x0, x0, HEAP, lsl #32
    // 0xf6d3d0: ldur            x2, [fp, #-8]
    // 0xf6d3d4: stur            x0, [fp, #-0x10]
    // 0xf6d3d8: LoadField: r1 = r2->field_b
    //     0xf6d3d8: ldur            w1, [x2, #0xb]
    // 0xf6d3dc: DecompressPointer r1
    //     0xf6d3dc: add             x1, x1, HEAP, lsl #32
    // 0xf6d3e0: cmp             w1, NULL
    // 0xf6d3e4: b.eq            #0xf6d494
    // 0xf6d3e8: LoadField: r3 = r1->field_f
    //     0xf6d3e8: ldur            w3, [x1, #0xf]
    // 0xf6d3ec: DecompressPointer r3
    //     0xf6d3ec: add             x3, x3, HEAP, lsl #32
    // 0xf6d3f0: mov             x1, x3
    // 0xf6d3f4: r0 = _parts()
    //     0xf6d3f4: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xf6d3f8: mov             x2, x0
    // 0xf6d3fc: LoadField: r0 = r2->field_b
    //     0xf6d3fc: ldur            w0, [x2, #0xb]
    // 0xf6d400: r1 = LoadInt32Instr(r0)
    //     0xf6d400: sbfx            x1, x0, #1, #0x1f
    // 0xf6d404: mov             x0, x1
    // 0xf6d408: r1 = 8
    //     0xf6d408: mov             x1, #8
    // 0xf6d40c: cmp             x1, x0
    // 0xf6d410: b.hs            #0xf6d498
    // 0xf6d414: LoadField: r0 = r2->field_2f
    //     0xf6d414: ldur            w0, [x2, #0x2f]
    // 0xf6d418: DecompressPointer r0
    //     0xf6d418: add             x0, x0, HEAP, lsl #32
    // 0xf6d41c: ldur            x1, [fp, #-0x10]
    // 0xf6d420: r2 = LoadInt32Instr(r1)
    //     0xf6d420: sbfx            x2, x1, #1, #0x1f
    //     0xf6d424: tbz             w1, #0, #0xf6d42c
    //     0xf6d428: ldur            x2, [x1, #7]
    // 0xf6d42c: r1 = LoadInt32Instr(r0)
    //     0xf6d42c: sbfx            x1, x0, #1, #0x1f
    //     0xf6d430: tbz             w0, #0, #0xf6d438
    //     0xf6d434: ldur            x1, [x0, #7]
    // 0xf6d438: sub             x0, x2, x1
    // 0xf6d43c: r1 = 3
    //     0xf6d43c: mov             x1, #3
    // 0xf6d440: sdiv            x2, x0, x1
    // 0xf6d444: sub             x0, x2, #2
    // 0xf6d448: ldur            x1, [fp, #-8]
    // 0xf6d44c: stur            x0, [fp, #-0x18]
    // 0xf6d450: r0 = _itemCount()
    //     0xf6d450: bl              #0xdf4308  ; [package:flutter/src/material/calendar_date_picker.dart] _YearPickerState::_itemCount
    // 0xf6d454: cmp             x0, #0x12
    // 0xf6d458: b.ge            #0xf6d464
    // 0xf6d45c: d0 = 0.000000
    //     0xf6d45c: eor             v0.16b, v0.16b, v0.16b
    // 0xf6d460: b               #0xf6d47c
    // 0xf6d464: ldur            x0, [fp, #-0x18]
    // 0xf6d468: d1 = 52.000000
    //     0xf6d468: add             x17, PP, #0x22, lsl #12  ; [pp+0x22108] IMM: double(52) from 0x404a000000000000
    //     0xf6d46c: ldr             d1, [x17, #0x108]
    // 0xf6d470: scvtf           d2, x0
    // 0xf6d474: fmul            d3, d2, d1
    // 0xf6d478: mov             v0.16b, v3.16b
    // 0xf6d47c: LeaveFrame
    //     0xf6d47c: mov             SP, fp
    //     0xf6d480: ldp             fp, lr, [SP], #0x10
    // 0xf6d484: ret
    //     0xf6d484: ret             
    // 0xf6d488: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6d488: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6d48c: b               #0xf6d3a8
    // 0xf6d490: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xf6d490: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xf6d494: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6d494: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6d498: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xf6d498: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0xf907e4, size: 0xe0
    // 0xf907e4: EnterFrame
    //     0xf907e4: stp             fp, lr, [SP, #-0x10]!
    //     0xf907e8: mov             fp, SP
    // 0xf907ec: AllocStack(0x20)
    //     0xf907ec: sub             SP, SP, #0x20
    // 0xf907f0: SetupParameters(_YearPickerState this /* r1 => r0, fp-0x8 */)
    //     0xf907f0: mov             x0, x1
    //     0xf907f4: stur            x1, [fp, #-8]
    // 0xf907f8: CheckStackOverflow
    //     0xf907f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf907fc: cmp             SP, x16
    //     0xf90800: b.ls            #0xf908a8
    // 0xf90804: LoadField: r1 = r0->field_b
    //     0xf90804: ldur            w1, [x0, #0xb]
    // 0xf90808: DecompressPointer r1
    //     0xf90808: add             x1, x1, HEAP, lsl #32
    // 0xf9080c: cmp             w1, NULL
    // 0xf90810: b.eq            #0xf908b0
    // 0xf90814: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xf90814: ldur            w2, [x1, #0x17]
    // 0xf90818: DecompressPointer r2
    //     0xf90818: add             x2, x2, HEAP, lsl #32
    // 0xf9081c: mov             x1, x0
    // 0xf90820: r0 = _scrollOffsetForYear()
    //     0xf90820: bl              #0xf6d384  ; [package:flutter/src/material/calendar_date_picker.dart] _YearPickerState::_scrollOffsetForYear
    // 0xf90824: r0 = inline_Allocate_Double()
    //     0xf90824: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xf90828: add             x0, x0, #0x10
    //     0xf9082c: cmp             x1, x0
    //     0xf90830: b.ls            #0xf908b4
    //     0xf90834: str             x0, [THR, #0x60]  ; THR::top
    //     0xf90838: sub             x0, x0, #0xf
    //     0xf9083c: mov             x1, #0xe19c
    //     0xf90840: movk            x1, #3, lsl #16
    //     0xf90844: stur            x1, [x0, #-1]
    // 0xf90848: dmb             ishst
    // 0xf9084c: StoreField: r0->field_7 = d0
    //     0xf9084c: stur            d0, [x0, #7]
    // 0xf90850: stur            x0, [fp, #-0x10]
    // 0xf90854: r0 = ScrollController()
    //     0xf90854: bl              #0x86d97c  ; AllocateScrollControllerStub -> ScrollController (size=0x40)
    // 0xf90858: stur            x0, [fp, #-0x18]
    // 0xf9085c: ldur            x16, [fp, #-0x10]
    // 0xf90860: str             x16, [SP]
    // 0xf90864: mov             x1, x0
    // 0xf90868: r4 = const [0, 0x2, 0x1, 0x1, initialScrollOffset, 0x1, null]
    //     0xf90868: add             x4, PP, #0xcd, lsl #12  ; [pp+0xcd568] List(7) [0, 0x2, 0x1, 0x1, "initialScrollOffset", 0x1, Null]
    //     0xf9086c: ldr             x4, [x4, #0x568]
    // 0xf90870: r0 = ScrollController()
    //     0xf90870: bl              #0x86d884  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::ScrollController
    // 0xf90874: ldur            x0, [fp, #-0x18]
    // 0xf90878: ldur            x1, [fp, #-8]
    // 0xf9087c: StoreField: r1->field_13 = r0
    //     0xf9087c: stur            w0, [x1, #0x13]
    //     0xf90880: ldurb           w16, [x1, #-1]
    //     0xf90884: ldurb           w17, [x0, #-1]
    //     0xf90888: and             x16, x17, x16, lsr #2
    //     0xf9088c: tst             x16, HEAP, lsr #32
    //     0xf90890: b.eq            #0xf90898
    //     0xf90894: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf90898: r0 = Null
    //     0xf90898: mov             x0, NULL
    // 0xf9089c: LeaveFrame
    //     0xf9089c: mov             SP, fp
    //     0xf908a0: ldp             fp, lr, [SP], #0x10
    // 0xf908a4: ret
    //     0xf908a4: ret             
    // 0xf908a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf908a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf908ac: b               #0xf90804
    // 0xf908b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf908b0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf908b4: SaveReg d0
    //     0xf908b4: str             q0, [SP, #-0x10]!
    // 0xf908b8: r0 = AllocateDouble()
    //     0xf908b8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xf908bc: RestoreReg d0
    //     0xf908bc: ldr             q0, [SP], #0x10
    // 0xf908c0: b               #0xf9084c
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10e5a44, size: 0x5c
    // 0x10e5a44: EnterFrame
    //     0x10e5a44: stp             fp, lr, [SP, #-0x10]!
    //     0x10e5a48: mov             fp, SP
    // 0x10e5a4c: AllocStack(0x8)
    //     0x10e5a4c: sub             SP, SP, #8
    // 0x10e5a50: SetupParameters(_YearPickerState this /* r1 => r0, fp-0x8 */)
    //     0x10e5a50: mov             x0, x1
    //     0x10e5a54: stur            x1, [fp, #-8]
    // 0x10e5a58: CheckStackOverflow
    //     0x10e5a58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e5a5c: cmp             SP, x16
    //     0x10e5a60: b.ls            #0x10e5a98
    // 0x10e5a64: LoadField: r1 = r0->field_13
    //     0x10e5a64: ldur            w1, [x0, #0x13]
    // 0x10e5a68: DecompressPointer r1
    //     0x10e5a68: add             x1, x1, HEAP, lsl #32
    // 0x10e5a6c: cmp             w1, NULL
    // 0x10e5a70: b.eq            #0x10e5a7c
    // 0x10e5a74: r0 = dispose()
    //     0x10e5a74: bl              #0x10ef540  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::dispose
    // 0x10e5a78: ldur            x0, [fp, #-8]
    // 0x10e5a7c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x10e5a7c: ldur            w1, [x0, #0x17]
    // 0x10e5a80: DecompressPointer r1
    //     0x10e5a80: add             x1, x1, HEAP, lsl #32
    // 0x10e5a84: r0 = dispose()
    //     0x10e5a84: bl              #0x10ef878  ; [dart:mixin_deduplication] _MixinApplication276&Object&ChangeNotifier::dispose
    // 0x10e5a88: r0 = Null
    //     0x10e5a88: mov             x0, NULL
    // 0x10e5a8c: LeaveFrame
    //     0x10e5a8c: mov             SP, fp
    //     0x10e5a90: ldp             fp, lr, [SP], #0x10
    // 0x10e5a94: ret
    //     0x10e5a94: ret             
    // 0x10e5a98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e5a98: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e5a9c: b               #0x10e5a64
  }
}

// class id: 5473, size: 0x18, field offset: 0x14
class _DayState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0xdf11c4, size: 0x9ac
    // 0xdf11c4: EnterFrame
    //     0xdf11c4: stp             fp, lr, [SP, #-0x10]!
    //     0xdf11c8: mov             fp, SP
    // 0xdf11cc: AllocStack(0xa0)
    //     0xdf11cc: sub             SP, SP, #0xa0
    // 0xdf11d0: SetupParameters(_DayState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xdf11d0: mov             x0, x1
    //     0xdf11d4: stur            x1, [fp, #-8]
    //     0xdf11d8: mov             x1, x2
    //     0xdf11dc: stur            x2, [fp, #-0x10]
    // 0xdf11e0: CheckStackOverflow
    //     0xdf11e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf11e4: cmp             SP, x16
    //     0xdf11e8: b.ls            #0xdf1b38
    // 0xdf11ec: r1 = 4
    //     0xdf11ec: mov             x1, #4
    // 0xdf11f0: r0 = AllocateContext()
    //     0xdf11f0: bl              #0x13de838  ; AllocateContextStub
    // 0xdf11f4: mov             x2, x0
    // 0xdf11f8: ldur            x0, [fp, #-8]
    // 0xdf11fc: stur            x2, [fp, #-0x18]
    // 0xdf1200: StoreField: r2->field_f = r0
    //     0xdf1200: stur            w0, [x2, #0xf]
    // 0xdf1204: ldur            x1, [fp, #-0x10]
    // 0xdf1208: r0 = defaults()
    //     0xdf1208: bl              #0xd0fd74  ; [package:flutter/src/material/date_picker_theme.dart] DatePickerTheme::defaults
    // 0xdf120c: mov             x3, x0
    // 0xdf1210: ldur            x2, [fp, #-0x18]
    // 0xdf1214: stur            x3, [fp, #-0x20]
    // 0xdf1218: StoreField: r2->field_13 = r0
    //     0xdf1218: stur            w0, [x2, #0x13]
    //     0xdf121c: ldurb           w16, [x2, #-1]
    //     0xdf1220: ldurb           w17, [x0, #-1]
    //     0xdf1224: and             x16, x17, x16, lsr #2
    //     0xdf1228: tst             x16, HEAP, lsr #32
    //     0xdf122c: b.eq            #0xdf1234
    //     0xdf1230: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xdf1234: ldur            x1, [fp, #-0x10]
    // 0xdf1238: r0 = of()
    //     0xdf1238: bl              #0xd0ff6c  ; [package:flutter/src/material/date_picker_theme.dart] DatePickerTheme::of
    // 0xdf123c: ldur            x2, [fp, #-0x18]
    // 0xdf1240: ArrayStore: r2[0] = r0  ; List_4
    //     0xdf1240: stur            w0, [x2, #0x17]
    //     0xdf1244: ldurb           w16, [x2, #-1]
    //     0xdf1248: ldurb           w17, [x0, #-1]
    //     0xdf124c: and             x16, x17, x16, lsr #2
    //     0xdf1250: tst             x16, HEAP, lsr #32
    //     0xdf1254: b.eq            #0xdf125c
    //     0xdf1258: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xdf125c: ldur            x0, [fp, #-0x20]
    // 0xdf1260: r3 = LoadClassIdInstr(r0)
    //     0xdf1260: ldur            x3, [x0, #-1]
    //     0xdf1264: ubfx            x3, x3, #0xc, #0x14
    // 0xdf1268: stur            x3, [fp, #-0x28]
    // 0xdf126c: r17 = 5167
    //     0xdf126c: mov             x17, #0x142f
    // 0xdf1270: cmp             x3, x17
    // 0xdf1274: b.ne            #0xdf128c
    // 0xdf1278: LoadField: r1 = r0->field_2f
    //     0xdf1278: ldur            w1, [x0, #0x2f]
    // 0xdf127c: DecompressPointer r1
    //     0xdf127c: add             x1, x1, HEAP, lsl #32
    // 0xdf1280: mov             x4, x1
    // 0xdf1284: mov             x0, x2
    // 0xdf1288: b               #0xdf1304
    // 0xdf128c: r17 = 5168
    //     0xdf128c: mov             x17, #0x1430
    // 0xdf1290: cmp             x3, x17
    // 0xdf1294: b.ne            #0xdf12d0
    // 0xdf1298: mov             x1, x0
    // 0xdf129c: LoadField: r0 = r1->field_b7
    //     0xdf129c: ldur            w0, [x1, #0xb7]
    // 0xdf12a0: DecompressPointer r0
    //     0xdf12a0: add             x0, x0, HEAP, lsl #32
    // 0xdf12a4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf12a8: cmp             w0, w16
    // 0xdf12ac: b.ne            #0xdf12bc
    // 0xdf12b0: r2 = _textTheme
    //     0xdf12b0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26418] Field <_DatePickerDefaultsM3@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0xdf12b4: ldr             x2, [x2, #0x418]
    // 0xdf12b8: r0 = InitLateFinalInstanceField()
    //     0xdf12b8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf12bc: LoadField: r1 = r0->field_2b
    //     0xdf12bc: ldur            w1, [x0, #0x2b]
    // 0xdf12c0: DecompressPointer r1
    //     0xdf12c0: add             x1, x1, HEAP, lsl #32
    // 0xdf12c4: mov             x4, x1
    // 0xdf12c8: ldur            x0, [fp, #-0x18]
    // 0xdf12cc: b               #0xdf1304
    // 0xdf12d0: ldur            x1, [fp, #-0x20]
    // 0xdf12d4: LoadField: r0 = r1->field_b7
    //     0xdf12d4: ldur            w0, [x1, #0xb7]
    // 0xdf12d8: DecompressPointer r0
    //     0xdf12d8: add             x0, x0, HEAP, lsl #32
    // 0xdf12dc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf12e0: cmp             w0, w16
    // 0xdf12e4: b.ne            #0xdf12f4
    // 0xdf12e8: r2 = _textTheme
    //     0xdf12e8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26420] Field <_DatePickerDefaultsM2@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0xdf12ec: ldr             x2, [x2, #0x420]
    // 0xdf12f0: r0 = InitLateFinalInstanceField()
    //     0xdf12f0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf12f4: LoadField: r1 = r0->field_33
    //     0xdf12f4: ldur            w1, [x0, #0x33]
    // 0xdf12f8: DecompressPointer r1
    //     0xdf12f8: add             x1, x1, HEAP, lsl #32
    // 0xdf12fc: mov             x4, x1
    // 0xdf1300: ldur            x0, [fp, #-0x18]
    // 0xdf1304: ldur            x3, [fp, #-8]
    // 0xdf1308: mov             x2, x0
    // 0xdf130c: stur            x4, [fp, #-0x30]
    // 0xdf1310: r1 = Function 'effectiveValue':.
    //     0xdf1310: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4228] AnonymousClosure: (0xdf4b70), in [package:flutter/src/material/calendar_date_picker.dart] _DayState::build (0xdf11c4)
    //     0xdf1314: ldr             x1, [x1, #0x228]
    // 0xdf1318: r0 = AllocateClosureGeneric()
    //     0xdf1318: bl              #0x13deb28  ; AllocateClosureGenericStub
    // 0xdf131c: ldur            x3, [fp, #-0x18]
    // 0xdf1320: StoreField: r3->field_1b = r0
    //     0xdf1320: stur            w0, [x3, #0x1b]
    //     0xdf1324: ldurb           w16, [x3, #-1]
    //     0xdf1328: ldurb           w17, [x0, #-1]
    //     0xdf132c: and             x16, x17, x16, lsr #2
    //     0xdf1330: tst             x16, HEAP, lsr #32
    //     0xdf1334: b.eq            #0xdf133c
    //     0xdf1338: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xdf133c: mov             x2, x3
    // 0xdf1340: r1 = Function 'resolve':.
    //     0xdf1340: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4230] AnonymousClosure: (0xdf33f8), in [package:flutter/src/material/calendar_date_picker.dart] _DayState::build (0xdf11c4)
    //     0xdf1344: ldr             x1, [x1, #0x230]
    // 0xdf1348: r0 = AllocateClosureGeneric()
    //     0xdf1348: bl              #0x13deb28  ; AllocateClosureGenericStub
    // 0xdf134c: ldur            x1, [fp, #-0x10]
    // 0xdf1350: stur            x0, [fp, #-0x38]
    // 0xdf1354: r0 = of()
    //     0xdf1354: bl              #0xd0bbf8  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0xdf1358: mov             x3, x0
    // 0xdf135c: ldur            x0, [fp, #-8]
    // 0xdf1360: stur            x3, [fp, #-0x40]
    // 0xdf1364: LoadField: r1 = r0->field_b
    //     0xdf1364: ldur            w1, [x0, #0xb]
    // 0xdf1368: DecompressPointer r1
    //     0xdf1368: add             x1, x1, HEAP, lsl #32
    // 0xdf136c: cmp             w1, NULL
    // 0xdf1370: b.eq            #0xdf1b40
    // 0xdf1374: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xdf1374: ldur            w2, [x1, #0x17]
    // 0xdf1378: DecompressPointer r2
    //     0xdf1378: add             x2, x2, HEAP, lsl #32
    // 0xdf137c: tbnz            w2, #4, #0xdf13fc
    // 0xdf1380: r1 = Null
    //     0xdf1380: mov             x1, NULL
    // 0xdf1384: r2 = 4
    //     0xdf1384: mov             x2, #4
    // 0xdf1388: r0 = AllocateArray()
    //     0xdf1388: bl              #0x13df928  ; AllocateArrayStub
    // 0xdf138c: mov             x2, x0
    // 0xdf1390: stur            x2, [fp, #-0x48]
    // 0xdf1394: r16 = ", "
    //     0xdf1394: ldr             x16, [PP, #0xe80]  ; [pp+0xe80] ", "
    // 0xdf1398: StoreField: r2->field_f = r16
    //     0xdf1398: stur            w16, [x2, #0xf]
    // 0xdf139c: ldur            x3, [fp, #-0x40]
    // 0xdf13a0: r0 = LoadClassIdInstr(r3)
    //     0xdf13a0: ldur            x0, [x3, #-1]
    //     0xdf13a4: ubfx            x0, x0, #0xc, #0x14
    // 0xdf13a8: mov             x1, x3
    // 0xdf13ac: r0 = GDT[cid_x0 + 0x16ee9]()
    //     0xdf13ac: mov             x17, #0x6ee9
    //     0xdf13b0: movk            x17, #1, lsl #16
    //     0xdf13b4: add             lr, x0, x17
    //     0xdf13b8: ldr             lr, [x21, lr, lsl #3]
    //     0xdf13bc: blr             lr
    // 0xdf13c0: ldur            x1, [fp, #-0x48]
    // 0xdf13c4: ArrayStore: r1[1] = r0  ; List_4
    //     0xdf13c4: add             x25, x1, #0x13
    //     0xdf13c8: str             w0, [x25]
    //     0xdf13cc: tbz             w0, #0, #0xdf13e8
    //     0xdf13d0: ldurb           w16, [x1, #-1]
    //     0xdf13d4: ldurb           w17, [x0, #-1]
    //     0xdf13d8: and             x16, x17, x16, lsr #2
    //     0xdf13dc: tst             x16, HEAP, lsr #32
    //     0xdf13e0: b.eq            #0xdf13e8
    //     0xdf13e4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdf13e8: ldur            x16, [fp, #-0x48]
    // 0xdf13ec: str             x16, [SP]
    // 0xdf13f0: r0 = _interpolate()
    //     0xdf13f0: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xdf13f4: mov             x2, x0
    // 0xdf13f8: b               #0xdf1400
    // 0xdf13fc: r2 = ""
    //     0xdf13fc: ldr             x2, [PP, #0x900]  ; [pp+0x900] ""
    // 0xdf1400: ldur            x0, [fp, #-8]
    // 0xdf1404: stur            x2, [fp, #-0x48]
    // 0xdf1408: r1 = <WidgetState>
    //     0xdf1408: add             x1, PP, #0x84, lsl #12  ; [pp+0x84a10] TypeArguments: <WidgetState>
    //     0xdf140c: ldr             x1, [x1, #0xa10]
    // 0xdf1410: r0 = _Set()
    //     0xdf1410: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0xdf1414: mov             x3, x0
    // 0xdf1418: r0 = _Uint32List
    //     0xdf1418: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0xdf141c: stur            x3, [fp, #-0x50]
    // 0xdf1420: StoreField: r3->field_1b = r0
    //     0xdf1420: stur            w0, [x3, #0x1b]
    // 0xdf1424: StoreField: r3->field_b = rZR
    //     0xdf1424: stur            wzr, [x3, #0xb]
    // 0xdf1428: r0 = const []
    //     0xdf1428: ldr             x0, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0xdf142c: StoreField: r3->field_f = r0
    //     0xdf142c: stur            w0, [x3, #0xf]
    // 0xdf1430: StoreField: r3->field_13 = rZR
    //     0xdf1430: stur            wzr, [x3, #0x13]
    // 0xdf1434: ArrayStore: r3[0] = rZR  ; List_4
    //     0xdf1434: stur            wzr, [x3, #0x17]
    // 0xdf1438: ldur            x0, [fp, #-8]
    // 0xdf143c: LoadField: r1 = r0->field_b
    //     0xdf143c: ldur            w1, [x0, #0xb]
    // 0xdf1440: DecompressPointer r1
    //     0xdf1440: add             x1, x1, HEAP, lsl #32
    // 0xdf1444: cmp             w1, NULL
    // 0xdf1448: b.eq            #0xdf1b44
    // 0xdf144c: LoadField: r2 = r1->field_f
    //     0xdf144c: ldur            w2, [x1, #0xf]
    // 0xdf1450: DecompressPointer r2
    //     0xdf1450: add             x2, x2, HEAP, lsl #32
    // 0xdf1454: tbnz            w2, #4, #0xdf1468
    // 0xdf1458: mov             x1, x3
    // 0xdf145c: r2 = Instance_WidgetState
    //     0xdf145c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xdf1460: ldr             x2, [x2, #0xa70]
    // 0xdf1464: r0 = add()
    //     0xdf1464: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xdf1468: ldur            x0, [fp, #-8]
    // 0xdf146c: LoadField: r1 = r0->field_b
    //     0xdf146c: ldur            w1, [x0, #0xb]
    // 0xdf1470: DecompressPointer r1
    //     0xdf1470: add             x1, x1, HEAP, lsl #32
    // 0xdf1474: cmp             w1, NULL
    // 0xdf1478: b.eq            #0xdf1b48
    // 0xdf147c: LoadField: r2 = r1->field_13
    //     0xdf147c: ldur            w2, [x1, #0x13]
    // 0xdf1480: DecompressPointer r2
    //     0xdf1480: add             x2, x2, HEAP, lsl #32
    // 0xdf1484: tbnz            w2, #4, #0xdf1498
    // 0xdf1488: ldur            x1, [fp, #-0x50]
    // 0xdf148c: r2 = Instance_WidgetState
    //     0xdf148c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xdf1490: ldr             x2, [x2, #0x100]
    // 0xdf1494: r0 = add()
    //     0xdf1494: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xdf1498: ldur            x0, [fp, #-8]
    // 0xdf149c: ldur            x3, [fp, #-0x28]
    // 0xdf14a0: LoadField: r4 = r0->field_13
    //     0xdf14a0: ldur            w4, [x0, #0x13]
    // 0xdf14a4: DecompressPointer r4
    //     0xdf14a4: add             x4, x4, HEAP, lsl #32
    // 0xdf14a8: mov             x1, x4
    // 0xdf14ac: ldur            x2, [fp, #-0x50]
    // 0xdf14b0: stur            x4, [fp, #-0x58]
    // 0xdf14b4: r0 = value=()
    //     0xdf14b4: bl              #0xb68ce8  ; [package:flutter/src/foundation/change_notifier.dart] ValueNotifier::value=
    // 0xdf14b8: ldur            x2, [fp, #-0x18]
    // 0xdf14bc: r1 = Function '<anonymous closure>':.
    //     0xdf14bc: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4238] AnonymousClosure: (0xdf2c5c), in [package:flutter/src/material/calendar_date_picker.dart] _DayState::build (0xdf11c4)
    //     0xdf14c0: ldr             x1, [x1, #0x238]
    // 0xdf14c4: r0 = AllocateClosure()
    //     0xdf14c4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf14c8: r16 = <Color?>
    //     0xdf14c8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xdf14cc: ldr             x16, [x16, #0xa40]
    // 0xdf14d0: ldur            lr, [fp, #-0x38]
    // 0xdf14d4: stp             lr, x16, [SP, #0x10]
    // 0xdf14d8: ldur            x16, [fp, #-0x50]
    // 0xdf14dc: stp             x16, x0, [SP]
    // 0xdf14e0: ldur            x0, [fp, #-0x38]
    // 0xdf14e4: ClosureCall
    //     0xdf14e4: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    //     0xdf14e8: ldur            x2, [x0, #0x1f]
    //     0xdf14ec: blr             x2
    // 0xdf14f0: ldur            x2, [fp, #-0x18]
    // 0xdf14f4: r1 = Function '<anonymous closure>':.
    //     0xdf14f4: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4240] AnonymousClosure: (0xdf2920), in [package:flutter/src/material/calendar_date_picker.dart] _DayState::build (0xdf11c4)
    //     0xdf14f8: ldr             x1, [x1, #0x240]
    // 0xdf14fc: stur            x0, [fp, #-0x60]
    // 0xdf1500: r0 = AllocateClosure()
    //     0xdf1500: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf1504: r16 = <Color?>
    //     0xdf1504: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xdf1508: ldr             x16, [x16, #0xa40]
    // 0xdf150c: ldur            lr, [fp, #-0x38]
    // 0xdf1510: stp             lr, x16, [SP, #0x10]
    // 0xdf1514: ldur            x16, [fp, #-0x50]
    // 0xdf1518: stp             x16, x0, [SP]
    // 0xdf151c: ldur            x0, [fp, #-0x38]
    // 0xdf1520: ClosureCall
    //     0xdf1520: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    //     0xdf1524: ldur            x2, [x0, #0x1f]
    //     0xdf1528: blr             x2
    // 0xdf152c: ldur            x2, [fp, #-0x18]
    // 0xdf1530: r1 = Function '<anonymous closure>':.
    //     0xdf1530: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4248] AnonymousClosure: (0xdf1fd4), in [package:flutter/src/material/calendar_date_picker.dart] _DayState::build (0xdf11c4)
    //     0xdf1534: ldr             x1, [x1, #0x248]
    // 0xdf1538: stur            x0, [fp, #-0x68]
    // 0xdf153c: r0 = AllocateClosure()
    //     0xdf153c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf1540: r16 = <Color?>
    //     0xdf1540: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xdf1544: ldr             x16, [x16, #0xa40]
    // 0xdf1548: stp             x0, x16, [SP]
    // 0xdf154c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdf154c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdf1550: r0 = resolveWith()
    //     0xdf1550: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xdf1554: r1 = Function '<anonymous closure>':.
    //     0xdf1554: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4250] AnonymousClosure: (0xdf1fb0), in [package:flutter/src/material/calendar_date_picker.dart] _DayState::build (0xdf11c4)
    //     0xdf1558: ldr             x1, [x1, #0x250]
    // 0xdf155c: r2 = Null
    //     0xdf155c: mov             x2, NULL
    // 0xdf1560: stur            x0, [fp, #-0x70]
    // 0xdf1564: r0 = AllocateClosure()
    //     0xdf1564: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf1568: r16 = <OutlinedBorder?>
    //     0xdf1568: add             x16, PP, #0x7d, lsl #12  ; [pp+0x7d4a8] TypeArguments: <OutlinedBorder?>
    //     0xdf156c: ldr             x16, [x16, #0x4a8]
    // 0xdf1570: ldur            lr, [fp, #-0x38]
    // 0xdf1574: stp             lr, x16, [SP, #0x10]
    // 0xdf1578: ldur            x16, [fp, #-0x50]
    // 0xdf157c: stp             x16, x0, [SP]
    // 0xdf1580: ldur            x0, [fp, #-0x38]
    // 0xdf1584: ClosureCall
    //     0xdf1584: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    //     0xdf1588: ldur            x2, [x0, #0x1f]
    //     0xdf158c: blr             x2
    // 0xdf1590: stur            x0, [fp, #-0x38]
    // 0xdf1594: cmp             w0, NULL
    // 0xdf1598: b.eq            #0xdf1b4c
    // 0xdf159c: ldur            x1, [fp, #-0x28]
    // 0xdf15a0: r17 = 5167
    //     0xdf15a0: mov             x17, #0x142f
    // 0xdf15a4: cmp             x1, x17
    // 0xdf15a8: b.ne            #0xdf15bc
    // 0xdf15ac: ldur            x2, [fp, #-0x20]
    // 0xdf15b0: LoadField: r1 = r2->field_4b
    //     0xdf15b0: ldur            w1, [x2, #0x4b]
    // 0xdf15b4: DecompressPointer r1
    //     0xdf15b4: add             x1, x1, HEAP, lsl #32
    // 0xdf15b8: b               #0xdf1698
    // 0xdf15bc: ldur            x2, [fp, #-0x20]
    // 0xdf15c0: r17 = 5168
    //     0xdf15c0: mov             x17, #0x1430
    // 0xdf15c4: cmp             x1, x17
    // 0xdf15c8: b.ne            #0xdf162c
    // 0xdf15cc: mov             x1, x2
    // 0xdf15d0: LoadField: r0 = r1->field_b3
    //     0xdf15d0: ldur            w0, [x1, #0xb3]
    // 0xdf15d4: DecompressPointer r0
    //     0xdf15d4: add             x0, x0, HEAP, lsl #32
    // 0xdf15d8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf15dc: cmp             w0, w16
    // 0xdf15e0: b.ne            #0xdf15f0
    // 0xdf15e4: r2 = _colors
    //     0xdf15e4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xdf15e8: ldr             x2, [x2, #0x400]
    // 0xdf15ec: r0 = InitLateFinalInstanceField()
    //     0xdf15ec: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf15f0: LoadField: r1 = r0->field_b
    //     0xdf15f0: ldur            w1, [x0, #0xb]
    // 0xdf15f4: DecompressPointer r1
    //     0xdf15f4: add             x1, x1, HEAP, lsl #32
    // 0xdf15f8: stur            x1, [fp, #-0x50]
    // 0xdf15fc: r0 = BorderSide()
    //     0xdf15fc: bl              #0x8a73bc  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0xdf1600: mov             x1, x0
    // 0xdf1604: ldur            x0, [fp, #-0x50]
    // 0xdf1608: StoreField: r1->field_7 = r0
    //     0xdf1608: stur            w0, [x1, #7]
    // 0xdf160c: d0 = 1.000000
    //     0xdf160c: fmov            d0, #1.00000000
    // 0xdf1610: StoreField: r1->field_b = d0
    //     0xdf1610: stur            d0, [x1, #0xb]
    // 0xdf1614: r0 = Instance_BorderStyle
    //     0xdf1614: add             x0, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0xdf1618: ldr             x0, [x0, #0xdc8]
    // 0xdf161c: StoreField: r1->field_13 = r0
    //     0xdf161c: stur            w0, [x1, #0x13]
    // 0xdf1620: d1 = -1.000000
    //     0xdf1620: fmov            d1, #-1.00000000
    // 0xdf1624: ArrayStore: r1[0] = d1  ; List_8
    //     0xdf1624: stur            d1, [x1, #0x17]
    // 0xdf1628: b               #0xdf1698
    // 0xdf162c: r0 = Instance_BorderStyle
    //     0xdf162c: add             x0, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0xdf1630: ldr             x0, [x0, #0xdc8]
    // 0xdf1634: d0 = 1.000000
    //     0xdf1634: fmov            d0, #1.00000000
    // 0xdf1638: d1 = -1.000000
    //     0xdf1638: fmov            d1, #-1.00000000
    // 0xdf163c: mov             x1, x2
    // 0xdf1640: LoadField: r0 = r1->field_b3
    //     0xdf1640: ldur            w0, [x1, #0xb3]
    // 0xdf1644: DecompressPointer r0
    //     0xdf1644: add             x0, x0, HEAP, lsl #32
    // 0xdf1648: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf164c: cmp             w0, w16
    // 0xdf1650: b.ne            #0xdf1660
    // 0xdf1654: r2 = _colors
    //     0xdf1654: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xdf1658: ldr             x2, [x2, #0x410]
    // 0xdf165c: r0 = InitLateFinalInstanceField()
    //     0xdf165c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf1660: LoadField: r1 = r0->field_b
    //     0xdf1660: ldur            w1, [x0, #0xb]
    // 0xdf1664: DecompressPointer r1
    //     0xdf1664: add             x1, x1, HEAP, lsl #32
    // 0xdf1668: stur            x1, [fp, #-0x20]
    // 0xdf166c: r0 = BorderSide()
    //     0xdf166c: bl              #0x8a73bc  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0xdf1670: mov             x1, x0
    // 0xdf1674: ldur            x0, [fp, #-0x20]
    // 0xdf1678: StoreField: r1->field_7 = r0
    //     0xdf1678: stur            w0, [x1, #7]
    // 0xdf167c: d0 = 1.000000
    //     0xdf167c: fmov            d0, #1.00000000
    // 0xdf1680: StoreField: r1->field_b = d0
    //     0xdf1680: stur            d0, [x1, #0xb]
    // 0xdf1684: r0 = Instance_BorderStyle
    //     0xdf1684: add             x0, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0xdf1688: ldr             x0, [x0, #0xdc8]
    // 0xdf168c: StoreField: r1->field_13 = r0
    //     0xdf168c: stur            w0, [x1, #0x13]
    // 0xdf1690: d0 = -1.000000
    //     0xdf1690: fmov            d0, #-1.00000000
    // 0xdf1694: ArrayStore: r1[0] = d0  ; List_8
    //     0xdf1694: stur            d0, [x1, #0x17]
    // 0xdf1698: ldur            x0, [fp, #-8]
    // 0xdf169c: ldur            x16, [fp, #-0x60]
    // 0xdf16a0: str             x16, [SP]
    // 0xdf16a4: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0xdf16a4: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0xdf16a8: ldr             x4, [x4, #0x7f0]
    // 0xdf16ac: r0 = copyWith()
    //     0xdf16ac: bl              #0xdf1d5c  ; [package:flutter/src/painting/borders.dart] BorderSide::copyWith
    // 0xdf16b0: ldur            x3, [fp, #-8]
    // 0xdf16b4: LoadField: r1 = r3->field_b
    //     0xdf16b4: ldur            w1, [x3, #0xb]
    // 0xdf16b8: DecompressPointer r1
    //     0xdf16b8: add             x1, x1, HEAP, lsl #32
    // 0xdf16bc: cmp             w1, NULL
    // 0xdf16c0: b.eq            #0xdf1b50
    // 0xdf16c4: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xdf16c4: ldur            w2, [x1, #0x17]
    // 0xdf16c8: DecompressPointer r2
    //     0xdf16c8: add             x2, x2, HEAP, lsl #32
    // 0xdf16cc: tbnz            w2, #4, #0xdf1724
    // 0xdf16d0: ldur            x5, [fp, #-0x68]
    // 0xdf16d4: ldur            x4, [fp, #-0x38]
    // 0xdf16d8: r1 = LoadClassIdInstr(r4)
    //     0xdf16d8: ldur            x1, [x4, #-1]
    //     0xdf16dc: ubfx            x1, x1, #0xc, #0x14
    // 0xdf16e0: mov             x2, x0
    // 0xdf16e4: mov             x0, x1
    // 0xdf16e8: mov             x1, x4
    // 0xdf16ec: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xdf16ec: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xdf16f0: r0 = GDT[cid_x0 + -0xff6]()
    //     0xdf16f0: sub             lr, x0, #0xff6
    //     0xdf16f4: ldr             lr, [x21, lr, lsl #3]
    //     0xdf16f8: blr             lr
    // 0xdf16fc: stur            x0, [fp, #-0x20]
    // 0xdf1700: r0 = ShapeDecoration()
    //     0xdf1700: bl              #0xb6e288  ; AllocateShapeDecorationStub -> ShapeDecoration (size=0x1c)
    // 0xdf1704: mov             x1, x0
    // 0xdf1708: ldur            x0, [fp, #-0x68]
    // 0xdf170c: StoreField: r1->field_7 = r0
    //     0xdf170c: stur            w0, [x1, #7]
    // 0xdf1710: ldur            x0, [fp, #-0x20]
    // 0xdf1714: ArrayStore: r1[0] = r0  ; List_4
    //     0xdf1714: stur            w0, [x1, #0x17]
    // 0xdf1718: mov             x5, x1
    // 0xdf171c: ldur            x0, [fp, #-0x38]
    // 0xdf1720: b               #0xdf1748
    // 0xdf1724: ldur            x0, [fp, #-0x68]
    // 0xdf1728: ldur            x1, [fp, #-0x38]
    // 0xdf172c: r0 = ShapeDecoration()
    //     0xdf172c: bl              #0xb6e288  ; AllocateShapeDecorationStub -> ShapeDecoration (size=0x1c)
    // 0xdf1730: mov             x1, x0
    // 0xdf1734: ldur            x0, [fp, #-0x68]
    // 0xdf1738: StoreField: r1->field_7 = r0
    //     0xdf1738: stur            w0, [x1, #7]
    // 0xdf173c: ldur            x0, [fp, #-0x38]
    // 0xdf1740: ArrayStore: r1[0] = r0  ; List_4
    //     0xdf1740: stur            w0, [x1, #0x17]
    // 0xdf1744: mov             x5, x1
    // 0xdf1748: ldur            x2, [fp, #-8]
    // 0xdf174c: ldur            x3, [fp, #-0x40]
    // 0xdf1750: ldur            x4, [fp, #-0x30]
    // 0xdf1754: stur            x5, [fp, #-0x20]
    // 0xdf1758: LoadField: r1 = r2->field_b
    //     0xdf1758: ldur            w1, [x2, #0xb]
    // 0xdf175c: DecompressPointer r1
    //     0xdf175c: add             x1, x1, HEAP, lsl #32
    // 0xdf1760: cmp             w1, NULL
    // 0xdf1764: b.eq            #0xdf1b54
    // 0xdf1768: LoadField: r6 = r1->field_b
    //     0xdf1768: ldur            w6, [x1, #0xb]
    // 0xdf176c: DecompressPointer r6
    //     0xdf176c: add             x6, x6, HEAP, lsl #32
    // 0xdf1770: mov             x1, x6
    // 0xdf1774: r0 = _parts()
    //     0xdf1774: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xdf1778: mov             x2, x0
    // 0xdf177c: LoadField: r0 = r2->field_b
    //     0xdf177c: ldur            w0, [x2, #0xb]
    // 0xdf1780: r1 = LoadInt32Instr(r0)
    //     0xdf1780: sbfx            x1, x0, #1, #0x1f
    // 0xdf1784: mov             x0, x1
    // 0xdf1788: r1 = 5
    //     0xdf1788: mov             x1, #5
    // 0xdf178c: cmp             x1, x0
    // 0xdf1790: b.hs            #0xdf1b58
    // 0xdf1794: LoadField: r0 = r2->field_23
    //     0xdf1794: ldur            w0, [x2, #0x23]
    // 0xdf1798: DecompressPointer r0
    //     0xdf1798: add             x0, x0, HEAP, lsl #32
    // 0xdf179c: r2 = LoadInt32Instr(r0)
    //     0xdf179c: sbfx            x2, x0, #1, #0x1f
    //     0xdf17a0: tbz             w0, #0, #0xdf17a8
    //     0xdf17a4: ldur            x2, [x0, #7]
    // 0xdf17a8: ldur            x3, [fp, #-0x40]
    // 0xdf17ac: r0 = LoadClassIdInstr(r3)
    //     0xdf17ac: ldur            x0, [x3, #-1]
    //     0xdf17b0: ubfx            x0, x0, #0xc, #0x14
    // 0xdf17b4: mov             x1, x3
    // 0xdf17b8: r0 = GDT[cid_x0 + 0x15dc4]()
    //     0xdf17b8: mov             x17, #0x5dc4
    //     0xdf17bc: movk            x17, #1, lsl #16
    //     0xdf17c0: add             lr, x0, x17
    //     0xdf17c4: ldr             lr, [x21, lr, lsl #3]
    //     0xdf17c8: blr             lr
    // 0xdf17cc: ldur            x1, [fp, #-0x30]
    // 0xdf17d0: stur            x0, [fp, #-0x50]
    // 0xdf17d4: cmp             w1, NULL
    // 0xdf17d8: b.ne            #0xdf17e4
    // 0xdf17dc: r1 = Null
    //     0xdf17dc: mov             x1, NULL
    // 0xdf17e0: b               #0xdf17f8
    // 0xdf17e4: ldur            x2, [fp, #-0x60]
    // 0xdf17e8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xdf17e8: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xdf17ec: r0 = apply()
    //     0xdf17ec: bl              #0x8acf20  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0xdf17f0: mov             x1, x0
    // 0xdf17f4: ldur            x0, [fp, #-0x50]
    // 0xdf17f8: stur            x1, [fp, #-0x30]
    // 0xdf17fc: r0 = Text()
    //     0xdf17fc: bl              #0x8a70a4  ; AllocateTextStub -> Text (size=0x50)
    // 0xdf1800: mov             x1, x0
    // 0xdf1804: ldur            x0, [fp, #-0x50]
    // 0xdf1808: stur            x1, [fp, #-0x60]
    // 0xdf180c: StoreField: r1->field_b = r0
    //     0xdf180c: stur            w0, [x1, #0xb]
    // 0xdf1810: ldur            x0, [fp, #-0x30]
    // 0xdf1814: StoreField: r1->field_13 = r0
    //     0xdf1814: stur            w0, [x1, #0x13]
    // 0xdf1818: r0 = Center()
    //     0xdf1818: bl              #0xd0c898  ; AllocateCenterStub -> Center (size=0x1c)
    // 0xdf181c: mov             x1, x0
    // 0xdf1820: r0 = Instance_Alignment
    //     0xdf1820: add             x0, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xdf1824: ldr             x0, [x0, #0xb80]
    // 0xdf1828: stur            x1, [fp, #-0x30]
    // 0xdf182c: StoreField: r1->field_f = r0
    //     0xdf182c: stur            w0, [x1, #0xf]
    // 0xdf1830: ldur            x0, [fp, #-0x60]
    // 0xdf1834: StoreField: r1->field_b = r0
    //     0xdf1834: stur            w0, [x1, #0xb]
    // 0xdf1838: r0 = Ink()
    //     0xdf1838: bl              #0xdf1d50  ; AllocateInkStub -> Ink (size=0x20)
    // 0xdf183c: stur            x0, [fp, #-0x50]
    // 0xdf1840: ldur            x16, [fp, #-0x20]
    // 0xdf1844: str             x16, [SP]
    // 0xdf1848: mov             x1, x0
    // 0xdf184c: ldur            x2, [fp, #-0x30]
    // 0xdf1850: r4 = const [0, 0x3, 0x1, 0x2, decoration, 0x2, null]
    //     0xdf1850: add             x4, PP, #0x84, lsl #12  ; [pp+0x84a40] List(7) [0, 0x3, 0x1, 0x2, "decoration", 0x2, Null]
    //     0xdf1854: ldr             x4, [x4, #0xa40]
    // 0xdf1858: r0 = Ink()
    //     0xdf1858: bl              #0xdf1b7c  ; [package:flutter/src/material/ink_decoration.dart] Ink::Ink
    // 0xdf185c: ldur            x1, [fp, #-0x10]
    // 0xdf1860: r0 = orientationOf()
    //     0xdf1860: bl              #0xd172a4  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::orientationOf
    // 0xdf1864: ldur            x1, [fp, #-0x10]
    // 0xdf1868: stur            x0, [fp, #-0x10]
    // 0xdf186c: r0 = of()
    //     0xdf186c: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xdf1870: LoadField: r1 = r0->field_2f
    //     0xdf1870: ldur            w1, [x0, #0x2f]
    // 0xdf1874: DecompressPointer r1
    //     0xdf1874: add             x1, x1, HEAP, lsl #32
    // 0xdf1878: tbnz            w1, #4, #0xdf18c0
    // 0xdf187c: ldur            x0, [fp, #-0x10]
    // 0xdf1880: r16 = Instance_Orientation
    //     0xdf1880: add             x16, PP, #0x14, lsl #12  ; [pp+0x143c8] Obj!Orientation@12c2ec1
    //     0xdf1884: ldr             x16, [x16, #0x3c8]
    // 0xdf1888: cmp             w0, w16
    // 0xdf188c: b.ne            #0xdf18b8
    // 0xdf1890: ldur            x0, [fp, #-0x50]
    // 0xdf1894: r0 = Padding()
    //     0xdf1894: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xdf1898: mov             x1, x0
    // 0xdf189c: r0 = Instance_EdgeInsets
    //     0xdf189c: add             x0, PP, #0x8c, lsl #12  ; [pp+0x8c9b0] Obj!EdgeInsets@129cde1
    //     0xdf18a0: ldr             x0, [x0, #0x9b0]
    // 0xdf18a4: StoreField: r1->field_f = r0
    //     0xdf18a4: stur            w0, [x1, #0xf]
    // 0xdf18a8: ldur            x0, [fp, #-0x50]
    // 0xdf18ac: StoreField: r1->field_b = r0
    //     0xdf18ac: stur            w0, [x1, #0xb]
    // 0xdf18b0: mov             x3, x1
    // 0xdf18b4: b               #0xdf18c8
    // 0xdf18b8: ldur            x0, [fp, #-0x50]
    // 0xdf18bc: b               #0xdf18c4
    // 0xdf18c0: ldur            x0, [fp, #-0x50]
    // 0xdf18c4: mov             x3, x0
    // 0xdf18c8: ldur            x2, [fp, #-8]
    // 0xdf18cc: ldur            x0, [fp, #-0x40]
    // 0xdf18d0: stur            x3, [fp, #-0x10]
    // 0xdf18d4: LoadField: r1 = r2->field_b
    //     0xdf18d4: ldur            w1, [x2, #0xb]
    // 0xdf18d8: DecompressPointer r1
    //     0xdf18d8: add             x1, x1, HEAP, lsl #32
    // 0xdf18dc: cmp             w1, NULL
    // 0xdf18e0: b.eq            #0xdf1b5c
    // 0xdf18e4: LoadField: r4 = r1->field_b
    //     0xdf18e4: ldur            w4, [x1, #0xb]
    // 0xdf18e8: DecompressPointer r4
    //     0xdf18e8: add             x4, x4, HEAP, lsl #32
    // 0xdf18ec: mov             x1, x4
    // 0xdf18f0: r0 = _parts()
    //     0xdf18f0: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xdf18f4: mov             x2, x0
    // 0xdf18f8: LoadField: r0 = r2->field_b
    //     0xdf18f8: ldur            w0, [x2, #0xb]
    // 0xdf18fc: r1 = LoadInt32Instr(r0)
    //     0xdf18fc: sbfx            x1, x0, #1, #0x1f
    // 0xdf1900: mov             x0, x1
    // 0xdf1904: r1 = 5
    //     0xdf1904: mov             x1, #5
    // 0xdf1908: cmp             x1, x0
    // 0xdf190c: b.hs            #0xdf1b60
    // 0xdf1910: LoadField: r0 = r2->field_23
    //     0xdf1910: ldur            w0, [x2, #0x23]
    // 0xdf1914: DecompressPointer r0
    //     0xdf1914: add             x0, x0, HEAP, lsl #32
    // 0xdf1918: r2 = LoadInt32Instr(r0)
    //     0xdf1918: sbfx            x2, x0, #1, #0x1f
    //     0xdf191c: tbz             w0, #0, #0xdf1924
    //     0xdf1920: ldur            x2, [x0, #7]
    // 0xdf1924: ldur            x3, [fp, #-0x40]
    // 0xdf1928: r0 = LoadClassIdInstr(r3)
    //     0xdf1928: ldur            x0, [x3, #-1]
    //     0xdf192c: ubfx            x0, x0, #0xc, #0x14
    // 0xdf1930: mov             x1, x3
    // 0xdf1934: r0 = GDT[cid_x0 + 0x15dc4]()
    //     0xdf1934: mov             x17, #0x5dc4
    //     0xdf1938: movk            x17, #1, lsl #16
    //     0xdf193c: add             lr, x0, x17
    //     0xdf1940: ldr             lr, [x21, lr, lsl #3]
    //     0xdf1944: blr             lr
    // 0xdf1948: r1 = Null
    //     0xdf1948: mov             x1, NULL
    // 0xdf194c: r2 = 8
    //     0xdf194c: mov             x2, #8
    // 0xdf1950: stur            x0, [fp, #-0x20]
    // 0xdf1954: r0 = AllocateArray()
    //     0xdf1954: bl              #0x13df928  ; AllocateArrayStub
    // 0xdf1958: mov             x4, x0
    // 0xdf195c: ldur            x0, [fp, #-0x20]
    // 0xdf1960: stur            x4, [fp, #-0x30]
    // 0xdf1964: StoreField: r4->field_f = r0
    //     0xdf1964: stur            w0, [x4, #0xf]
    // 0xdf1968: r16 = ", "
    //     0xdf1968: ldr             x16, [PP, #0xe80]  ; [pp+0xe80] ", "
    // 0xdf196c: StoreField: r4->field_13 = r16
    //     0xdf196c: stur            w16, [x4, #0x13]
    // 0xdf1970: ldur            x0, [fp, #-8]
    // 0xdf1974: LoadField: r1 = r0->field_b
    //     0xdf1974: ldur            w1, [x0, #0xb]
    // 0xdf1978: DecompressPointer r1
    //     0xdf1978: add             x1, x1, HEAP, lsl #32
    // 0xdf197c: cmp             w1, NULL
    // 0xdf1980: b.eq            #0xdf1b64
    // 0xdf1984: LoadField: r2 = r1->field_b
    //     0xdf1984: ldur            w2, [x1, #0xb]
    // 0xdf1988: DecompressPointer r2
    //     0xdf1988: add             x2, x2, HEAP, lsl #32
    // 0xdf198c: ldur            x3, [fp, #-0x40]
    // 0xdf1990: r1 = Instance_GregorianCalendarDelegate
    //     0xdf1990: add             x1, PP, #0x28, lsl #12  ; [pp+0x28538] Obj!GregorianCalendarDelegate@129edd1
    //     0xdf1994: ldr             x1, [x1, #0x538]
    // 0xdf1998: r0 = formatFullDate()
    //     0xdf1998: bl              #0xdedfac  ; [package:flutter/src/material/date.dart] GregorianCalendarDelegate::formatFullDate
    // 0xdf199c: ldur            x1, [fp, #-0x30]
    // 0xdf19a0: ArrayStore: r1[2] = r0  ; List_4
    //     0xdf19a0: add             x25, x1, #0x17
    //     0xdf19a4: str             w0, [x25]
    //     0xdf19a8: tbz             w0, #0, #0xdf19c4
    //     0xdf19ac: ldurb           w16, [x1, #-1]
    //     0xdf19b0: ldurb           w17, [x0, #-1]
    //     0xdf19b4: and             x16, x17, x16, lsr #2
    //     0xdf19b8: tst             x16, HEAP, lsr #32
    //     0xdf19bc: b.eq            #0xdf19c4
    //     0xdf19c0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdf19c4: ldur            x1, [fp, #-0x30]
    // 0xdf19c8: ldur            x0, [fp, #-0x48]
    // 0xdf19cc: ArrayStore: r1[3] = r0  ; List_4
    //     0xdf19cc: add             x25, x1, #0x1b
    //     0xdf19d0: str             w0, [x25]
    //     0xdf19d4: tbz             w0, #0, #0xdf19f0
    //     0xdf19d8: ldurb           w16, [x1, #-1]
    //     0xdf19dc: ldurb           w17, [x0, #-1]
    //     0xdf19e0: and             x16, x17, x16, lsr #2
    //     0xdf19e4: tst             x16, HEAP, lsr #32
    //     0xdf19e8: b.eq            #0xdf19f0
    //     0xdf19ec: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdf19f0: ldur            x16, [fp, #-0x30]
    // 0xdf19f4: str             x16, [SP]
    // 0xdf19f8: r0 = _interpolate()
    //     0xdf19f8: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xdf19fc: mov             x1, x0
    // 0xdf1a00: ldur            x0, [fp, #-8]
    // 0xdf1a04: stur            x1, [fp, #-0x40]
    // 0xdf1a08: LoadField: r2 = r0->field_b
    //     0xdf1a08: ldur            w2, [x0, #0xb]
    // 0xdf1a0c: DecompressPointer r2
    //     0xdf1a0c: add             x2, x2, HEAP, lsl #32
    // 0xdf1a10: cmp             w2, NULL
    // 0xdf1a14: b.eq            #0xdf1b68
    // 0xdf1a18: LoadField: r3 = r2->field_13
    //     0xdf1a18: ldur            w3, [x2, #0x13]
    // 0xdf1a1c: DecompressPointer r3
    //     0xdf1a1c: add             x3, x3, HEAP, lsl #32
    // 0xdf1a20: stur            x3, [fp, #-0x30]
    // 0xdf1a24: LoadField: r4 = r2->field_f
    //     0xdf1a24: ldur            w4, [x2, #0xf]
    // 0xdf1a28: DecompressPointer r4
    //     0xdf1a28: add             x4, x4, HEAP, lsl #32
    // 0xdf1a2c: eor             x2, x4, #0x10
    // 0xdf1a30: stur            x2, [fp, #-0x20]
    // 0xdf1a34: r0 = Semantics()
    //     0xdf1a34: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xdf1a38: stur            x0, [fp, #-0x48]
    // 0xdf1a3c: ldur            x16, [fp, #-0x40]
    // 0xdf1a40: r30 = true
    //     0xdf1a40: add             lr, NULL, #0x20  ; true
    // 0xdf1a44: stp             lr, x16, [SP, #0x20]
    // 0xdf1a48: ldur            x16, [fp, #-0x30]
    // 0xdf1a4c: ldur            lr, [fp, #-0x20]
    // 0xdf1a50: stp             lr, x16, [SP, #0x10]
    // 0xdf1a54: r16 = true
    //     0xdf1a54: add             x16, NULL, #0x20  ; true
    // 0xdf1a58: ldur            lr, [fp, #-0x10]
    // 0xdf1a5c: stp             lr, x16, [SP]
    // 0xdf1a60: mov             x1, x0
    // 0xdf1a64: r4 = const [0, 0x7, 0x6, 0x1, button, 0x2, child, 0x6, enabled, 0x4, excludeSemantics, 0x5, label, 0x1, selected, 0x3, null]
    //     0xdf1a64: add             x4, PP, #0xd4, lsl #12  ; [pp+0xd4258] List(17) [0, 0x7, 0x6, 0x1, "button", 0x2, "child", 0x6, "enabled", 0x4, "excludeSemantics", 0x5, "label", 0x1, "selected", 0x3, Null]
    //     0xdf1a68: ldr             x4, [x4, #0x258]
    // 0xdf1a6c: r0 = Semantics()
    //     0xdf1a6c: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xdf1a70: ldur            x0, [fp, #-8]
    // 0xdf1a74: LoadField: r1 = r0->field_b
    //     0xdf1a74: ldur            w1, [x0, #0xb]
    // 0xdf1a78: DecompressPointer r1
    //     0xdf1a78: add             x1, x1, HEAP, lsl #32
    // 0xdf1a7c: cmp             w1, NULL
    // 0xdf1a80: b.eq            #0xdf1b6c
    // 0xdf1a84: LoadField: r0 = r1->field_f
    //     0xdf1a84: ldur            w0, [x1, #0xf]
    // 0xdf1a88: DecompressPointer r0
    //     0xdf1a88: add             x0, x0, HEAP, lsl #32
    // 0xdf1a8c: tbz             w0, #4, #0xdf1b28
    // 0xdf1a90: ldur            x4, [fp, #-0x58]
    // 0xdf1a94: ldur            x3, [fp, #-0x70]
    // 0xdf1a98: ldur            x2, [fp, #-0x38]
    // 0xdf1a9c: ldur            x0, [fp, #-0x48]
    // 0xdf1aa0: LoadField: r5 = r1->field_1f
    //     0xdf1aa0: ldur            w5, [x1, #0x1f]
    // 0xdf1aa4: DecompressPointer r5
    //     0xdf1aa4: add             x5, x5, HEAP, lsl #32
    // 0xdf1aa8: stur            x5, [fp, #-8]
    // 0xdf1aac: r0 = InkResponse()
    //     0xdf1aac: bl              #0xdf1b70  ; AllocateInkResponseStub -> InkResponse (size=0x94)
    // 0xdf1ab0: mov             x3, x0
    // 0xdf1ab4: ldur            x0, [fp, #-0x48]
    // 0xdf1ab8: stur            x3, [fp, #-0x10]
    // 0xdf1abc: StoreField: r3->field_b = r0
    //     0xdf1abc: stur            w0, [x3, #0xb]
    // 0xdf1ac0: ldur            x2, [fp, #-0x18]
    // 0xdf1ac4: r1 = Function '<anonymous closure>':.
    //     0xdf1ac4: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4260] AnonymousClosure: (0xdf1f40), in [package:flutter/src/material/calendar_date_picker.dart] _DayState::build (0xdf11c4)
    //     0xdf1ac8: ldr             x1, [x1, #0x260]
    // 0xdf1acc: r0 = AllocateClosure()
    //     0xdf1acc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf1ad0: ldur            x1, [fp, #-0x10]
    // 0xdf1ad4: StoreField: r1->field_f = r0
    //     0xdf1ad4: stur            w0, [x1, #0xf]
    // 0xdf1ad8: r2 = true
    //     0xdf1ad8: add             x2, NULL, #0x20  ; true
    // 0xdf1adc: StoreField: r1->field_47 = r2
    //     0xdf1adc: stur            w2, [x1, #0x47]
    // 0xdf1ae0: r3 = Instance_BoxShape
    //     0xdf1ae0: add             x3, PP, #0x1a, lsl #12  ; [pp+0x1abf0] Obj!BoxShape@12c4941
    //     0xdf1ae4: ldr             x3, [x3, #0xbf0]
    // 0xdf1ae8: StoreField: r1->field_4b = r3
    //     0xdf1ae8: stur            w3, [x1, #0x4b]
    // 0xdf1aec: ldur            x3, [fp, #-0x38]
    // 0xdf1af0: StoreField: r1->field_57 = r3
    //     0xdf1af0: stur            w3, [x1, #0x57]
    // 0xdf1af4: ldur            x3, [fp, #-0x70]
    // 0xdf1af8: StoreField: r1->field_67 = r3
    //     0xdf1af8: stur            w3, [x1, #0x67]
    // 0xdf1afc: StoreField: r1->field_73 = r2
    //     0xdf1afc: stur            w2, [x1, #0x73]
    // 0xdf1b00: r3 = false
    //     0xdf1b00: add             x3, NULL, #0x30  ; false
    // 0xdf1b04: StoreField: r1->field_77 = r3
    //     0xdf1b04: stur            w3, [x1, #0x77]
    // 0xdf1b08: ldur            x4, [fp, #-8]
    // 0xdf1b0c: StoreField: r1->field_83 = r4
    //     0xdf1b0c: stur            w4, [x1, #0x83]
    // 0xdf1b10: StoreField: r1->field_87 = r2
    //     0xdf1b10: stur            w2, [x1, #0x87]
    // 0xdf1b14: StoreField: r1->field_7f = r3
    //     0xdf1b14: stur            w3, [x1, #0x7f]
    // 0xdf1b18: ldur            x2, [fp, #-0x58]
    // 0xdf1b1c: StoreField: r1->field_8b = r2
    //     0xdf1b1c: stur            w2, [x1, #0x8b]
    // 0xdf1b20: mov             x0, x1
    // 0xdf1b24: b               #0xdf1b2c
    // 0xdf1b28: ldur            x0, [fp, #-0x48]
    // 0xdf1b2c: LeaveFrame
    //     0xdf1b2c: mov             SP, fp
    //     0xdf1b30: ldp             fp, lr, [SP], #0x10
    // 0xdf1b34: ret
    //     0xdf1b34: ret             
    // 0xdf1b38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf1b38: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf1b3c: b               #0xdf11ec
    // 0xdf1b40: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf1b40: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf1b44: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf1b44: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf1b48: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf1b48: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf1b4c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf1b4c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf1b50: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf1b50: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf1b54: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf1b54: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf1b58: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdf1b58: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdf1b5c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf1b5c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf1b60: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdf1b60: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdf1b64: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf1b64: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf1b68: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf1b68: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf1b6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf1b6c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xdf1f40, size: 0x70
    // 0xdf1f40: EnterFrame
    //     0xdf1f40: stp             fp, lr, [SP, #-0x10]!
    //     0xdf1f44: mov             fp, SP
    // 0xdf1f48: ldr             x0, [fp, #0x10]
    // 0xdf1f4c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdf1f4c: ldur            w1, [x0, #0x17]
    // 0xdf1f50: DecompressPointer r1
    //     0xdf1f50: add             x1, x1, HEAP, lsl #32
    // 0xdf1f54: CheckStackOverflow
    //     0xdf1f54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf1f58: cmp             SP, x16
    //     0xdf1f5c: b.ls            #0xdf1fa4
    // 0xdf1f60: LoadField: r0 = r1->field_f
    //     0xdf1f60: ldur            w0, [x1, #0xf]
    // 0xdf1f64: DecompressPointer r0
    //     0xdf1f64: add             x0, x0, HEAP, lsl #32
    // 0xdf1f68: LoadField: r1 = r0->field_b
    //     0xdf1f68: ldur            w1, [x0, #0xb]
    // 0xdf1f6c: DecompressPointer r1
    //     0xdf1f6c: add             x1, x1, HEAP, lsl #32
    // 0xdf1f70: cmp             w1, NULL
    // 0xdf1f74: b.eq            #0xdf1fac
    // 0xdf1f78: LoadField: r2 = r1->field_b
    //     0xdf1f78: ldur            w2, [x1, #0xb]
    // 0xdf1f7c: DecompressPointer r2
    //     0xdf1f7c: add             x2, x2, HEAP, lsl #32
    // 0xdf1f80: LoadField: r0 = r1->field_1b
    //     0xdf1f80: ldur            w0, [x1, #0x1b]
    // 0xdf1f84: DecompressPointer r0
    //     0xdf1f84: add             x0, x0, HEAP, lsl #32
    // 0xdf1f88: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdf1f88: ldur            w1, [x0, #0x17]
    // 0xdf1f8c: DecompressPointer r1
    //     0xdf1f8c: add             x1, x1, HEAP, lsl #32
    // 0xdf1f90: r0 = _handleDateSelected()
    //     0xdf1f90: bl              #0xdf02bc  ; [package:flutter/src/material/calendar_date_picker.dart] _MonthPickerState::_handleDateSelected
    // 0xdf1f94: r0 = Null
    //     0xdf1f94: mov             x0, NULL
    // 0xdf1f98: LeaveFrame
    //     0xdf1f98: mov             SP, fp
    //     0xdf1f9c: ldp             fp, lr, [SP], #0x10
    // 0xdf1fa0: ret
    //     0xdf1fa0: ret             
    // 0xdf1fa4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf1fa4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf1fa8: b               #0xdf1f60
    // 0xdf1fac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf1fac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] WidgetStateProperty<OutlinedBorder?>? <anonymous closure>(dynamic, DatePickerThemeData?) {
    // ** addr: 0xdf1fb0, size: 0x24
    // 0xdf1fb0: ldr             x1, [SP]
    // 0xdf1fb4: cmp             w1, NULL
    // 0xdf1fb8: b.ne            #0xdf1fc4
    // 0xdf1fbc: r0 = Null
    //     0xdf1fbc: mov             x0, NULL
    // 0xdf1fc0: b               #0xdf1fd0
    // 0xdf1fc4: LoadField: r2 = r1->field_3f
    //     0xdf1fc4: ldur            w2, [x1, #0x3f]
    // 0xdf1fc8: DecompressPointer r2
    //     0xdf1fc8: add             x2, x2, HEAP, lsl #32
    // 0xdf1fcc: mov             x0, x2
    // 0xdf1fd0: ret
    //     0xdf1fd0: ret             
  }
  [closure] Color? <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xdf1fd4, size: 0x98
    // 0xdf1fd4: EnterFrame
    //     0xdf1fd4: stp             fp, lr, [SP, #-0x10]!
    //     0xdf1fd8: mov             fp, SP
    // 0xdf1fdc: AllocStack(0x28)
    //     0xdf1fdc: sub             SP, SP, #0x28
    // 0xdf1fe0: SetupParameters([dynamic _ /* r0 */])
    //     0xdf1fe0: ldr             x0, [fp, #0x18]
    //     0xdf1fe4: ldur            w1, [x0, #0x17]
    //     0xdf1fe8: add             x1, x1, HEAP, lsl #32
    //     0xdf1fec: stur            x1, [fp, #-8]
    // 0xdf1ff0: CheckStackOverflow
    //     0xdf1ff0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf1ff4: cmp             SP, x16
    //     0xdf1ff8: b.ls            #0xdf2064
    // 0xdf1ffc: r1 = 1
    //     0xdf1ffc: mov             x1, #1
    // 0xdf2000: r0 = AllocateContext()
    //     0xdf2000: bl              #0x13de838  ; AllocateContextStub
    // 0xdf2004: mov             x1, x0
    // 0xdf2008: ldur            x0, [fp, #-8]
    // 0xdf200c: StoreField: r1->field_b = r0
    //     0xdf200c: stur            w0, [x1, #0xb]
    // 0xdf2010: ldr             x2, [fp, #0x10]
    // 0xdf2014: StoreField: r1->field_f = r2
    //     0xdf2014: stur            w2, [x1, #0xf]
    // 0xdf2018: LoadField: r3 = r0->field_1b
    //     0xdf2018: ldur            w3, [x0, #0x1b]
    // 0xdf201c: DecompressPointer r3
    //     0xdf201c: add             x3, x3, HEAP, lsl #32
    // 0xdf2020: mov             x2, x1
    // 0xdf2024: stur            x3, [fp, #-0x10]
    // 0xdf2028: r1 = Function '<anonymous closure>':.
    //     0xdf2028: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4268] AnonymousClosure: (0xdf206c), in [package:flutter/src/material/calendar_date_picker.dart] _DayState::build (0xdf11c4)
    //     0xdf202c: ldr             x1, [x1, #0x268]
    // 0xdf2030: r0 = AllocateClosure()
    //     0xdf2030: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf2034: r16 = <Color>
    //     0xdf2034: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xdf2038: ldr             x16, [x16, #0xa90]
    // 0xdf203c: ldur            lr, [fp, #-0x10]
    // 0xdf2040: stp             lr, x16, [SP, #8]
    // 0xdf2044: str             x0, [SP]
    // 0xdf2048: ldur            x0, [fp, #-0x10]
    // 0xdf204c: ClosureCall
    //     0xdf204c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0xdf2050: ldur            x2, [x0, #0x1f]
    //     0xdf2054: blr             x2
    // 0xdf2058: LeaveFrame
    //     0xdf2058: mov             SP, fp
    //     0xdf205c: ldp             fp, lr, [SP], #0x10
    // 0xdf2060: ret
    //     0xdf2060: ret             
    // 0xdf2064: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf2064: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf2068: b               #0xdf1ffc
  }
  [closure] Color? <anonymous closure>(dynamic, DatePickerThemeData?) {
    // ** addr: 0xdf206c, size: 0x124
    // 0xdf206c: EnterFrame
    //     0xdf206c: stp             fp, lr, [SP, #-0x10]!
    //     0xdf2070: mov             fp, SP
    // 0xdf2074: AllocStack(0x18)
    //     0xdf2074: sub             SP, SP, #0x18
    // 0xdf2078: SetupParameters([dynamic _ /* r0 */])
    //     0xdf2078: ldr             x0, [fp, #0x18]
    //     0xdf207c: ldur            w1, [x0, #0x17]
    //     0xdf2080: add             x1, x1, HEAP, lsl #32
    //     0xdf2084: stur            x1, [fp, #-8]
    // 0xdf2088: CheckStackOverflow
    //     0xdf2088: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf208c: cmp             SP, x16
    //     0xdf2090: b.ls            #0xdf2188
    // 0xdf2094: ldr             x0, [fp, #0x10]
    // 0xdf2098: cmp             w0, NULL
    // 0xdf209c: b.ne            #0xdf20a8
    // 0xdf20a0: r0 = Null
    //     0xdf20a0: mov             x0, NULL
    // 0xdf20a4: b               #0xdf217c
    // 0xdf20a8: r2 = LoadClassIdInstr(r0)
    //     0xdf20a8: ldur            x2, [x0, #-1]
    //     0xdf20ac: ubfx            x2, x2, #0xc, #0x14
    // 0xdf20b0: r17 = 5167
    //     0xdf20b0: mov             x17, #0x142f
    // 0xdf20b4: cmp             x2, x17
    // 0xdf20b8: b.ne            #0xdf20cc
    // 0xdf20bc: LoadField: r2 = r0->field_3b
    //     0xdf20bc: ldur            w2, [x0, #0x3b]
    // 0xdf20c0: DecompressPointer r2
    //     0xdf20c0: add             x2, x2, HEAP, lsl #32
    // 0xdf20c4: mov             x1, x2
    // 0xdf20c8: b               #0xdf2154
    // 0xdf20cc: r17 = 5168
    //     0xdf20cc: mov             x17, #0x1430
    // 0xdf20d0: cmp             x2, x17
    // 0xdf20d4: b.ne            #0xdf2118
    // 0xdf20d8: r1 = 1
    //     0xdf20d8: mov             x1, #1
    // 0xdf20dc: r0 = AllocateContext()
    //     0xdf20dc: bl              #0x13de838  ; AllocateContextStub
    // 0xdf20e0: mov             x1, x0
    // 0xdf20e4: ldr             x0, [fp, #0x10]
    // 0xdf20e8: StoreField: r1->field_f = r0
    //     0xdf20e8: stur            w0, [x1, #0xf]
    // 0xdf20ec: mov             x2, x1
    // 0xdf20f0: r1 = Function '<anonymous closure>':.
    //     0xdf20f0: add             x1, PP, #0x26, lsl #12  ; [pp+0x26448] AnonymousClosure: (0xdf2558), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM3
    //     0xdf20f4: ldr             x1, [x1, #0x448]
    // 0xdf20f8: r0 = AllocateClosure()
    //     0xdf20f8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf20fc: r16 = <Color?>
    //     0xdf20fc: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xdf2100: ldr             x16, [x16, #0xa40]
    // 0xdf2104: stp             x0, x16, [SP]
    // 0xdf2108: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdf2108: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdf210c: r0 = resolveWith()
    //     0xdf210c: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xdf2110: mov             x1, x0
    // 0xdf2114: b               #0xdf2154
    // 0xdf2118: r1 = 1
    //     0xdf2118: mov             x1, #1
    // 0xdf211c: r0 = AllocateContext()
    //     0xdf211c: bl              #0x13de838  ; AllocateContextStub
    // 0xdf2120: mov             x1, x0
    // 0xdf2124: ldr             x0, [fp, #0x10]
    // 0xdf2128: StoreField: r1->field_f = r0
    //     0xdf2128: stur            w0, [x1, #0xf]
    // 0xdf212c: mov             x2, x1
    // 0xdf2130: r1 = Function '<anonymous closure>':.
    //     0xdf2130: add             x1, PP, #0x26, lsl #12  ; [pp+0x26450] AnonymousClosure: (0xdf2190), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM2
    //     0xdf2134: ldr             x1, [x1, #0x450]
    // 0xdf2138: r0 = AllocateClosure()
    //     0xdf2138: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf213c: r16 = <Color?>
    //     0xdf213c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xdf2140: ldr             x16, [x16, #0xa40]
    // 0xdf2144: stp             x0, x16, [SP]
    // 0xdf2148: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdf2148: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdf214c: r0 = resolveWith()
    //     0xdf214c: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xdf2150: mov             x1, x0
    // 0xdf2154: cmp             w1, NULL
    // 0xdf2158: b.ne            #0xdf2164
    // 0xdf215c: r1 = Null
    //     0xdf215c: mov             x1, NULL
    // 0xdf2160: b               #0xdf2178
    // 0xdf2164: ldur            x0, [fp, #-8]
    // 0xdf2168: LoadField: r2 = r0->field_f
    //     0xdf2168: ldur            w2, [x0, #0xf]
    // 0xdf216c: DecompressPointer r2
    //     0xdf216c: add             x2, x2, HEAP, lsl #32
    // 0xdf2170: r0 = build()
    //     0xdf2170: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xdf2174: mov             x1, x0
    // 0xdf2178: mov             x0, x1
    // 0xdf217c: LeaveFrame
    //     0xdf217c: mov             SP, fp
    //     0xdf2180: ldp             fp, lr, [SP], #0x10
    // 0xdf2184: ret
    //     0xdf2184: ret             
    // 0xdf2188: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf2188: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf218c: b               #0xdf2094
  }
  [closure] WidgetStateProperty<Color?>? <anonymous closure>(dynamic, DatePickerThemeData?) {
    // ** addr: 0xdf2920, size: 0x1dc
    // 0xdf2920: EnterFrame
    //     0xdf2920: stp             fp, lr, [SP, #-0x10]!
    //     0xdf2924: mov             fp, SP
    // 0xdf2928: AllocStack(0x10)
    //     0xdf2928: sub             SP, SP, #0x10
    // 0xdf292c: SetupParameters([dynamic _ /* r0 */])
    //     0xdf292c: ldr             x0, [fp, #0x18]
    //     0xdf2930: ldur            w1, [x0, #0x17]
    //     0xdf2934: add             x1, x1, HEAP, lsl #32
    // 0xdf2938: CheckStackOverflow
    //     0xdf2938: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf293c: cmp             SP, x16
    //     0xdf2940: b.ls            #0xdf2af0
    // 0xdf2944: LoadField: r0 = r1->field_f
    //     0xdf2944: ldur            w0, [x1, #0xf]
    // 0xdf2948: DecompressPointer r0
    //     0xdf2948: add             x0, x0, HEAP, lsl #32
    // 0xdf294c: LoadField: r1 = r0->field_b
    //     0xdf294c: ldur            w1, [x0, #0xb]
    // 0xdf2950: DecompressPointer r1
    //     0xdf2950: add             x1, x1, HEAP, lsl #32
    // 0xdf2954: cmp             w1, NULL
    // 0xdf2958: b.eq            #0xdf2af8
    // 0xdf295c: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xdf295c: ldur            w0, [x1, #0x17]
    // 0xdf2960: DecompressPointer r0
    //     0xdf2960: add             x0, x0, HEAP, lsl #32
    // 0xdf2964: tbnz            w0, #4, #0xdf2a24
    // 0xdf2968: ldr             x0, [fp, #0x10]
    // 0xdf296c: cmp             w0, NULL
    // 0xdf2970: b.ne            #0xdf297c
    // 0xdf2974: r0 = Null
    //     0xdf2974: mov             x0, NULL
    // 0xdf2978: b               #0xdf2ae4
    // 0xdf297c: r1 = LoadClassIdInstr(r0)
    //     0xdf297c: ldur            x1, [x0, #-1]
    //     0xdf2980: ubfx            x1, x1, #0xc, #0x14
    // 0xdf2984: r17 = 5167
    //     0xdf2984: mov             x17, #0x142f
    // 0xdf2988: cmp             x1, x17
    // 0xdf298c: b.ne            #0xdf29a0
    // 0xdf2990: LoadField: r1 = r0->field_47
    //     0xdf2990: ldur            w1, [x0, #0x47]
    // 0xdf2994: DecompressPointer r1
    //     0xdf2994: add             x1, x1, HEAP, lsl #32
    // 0xdf2998: mov             x0, x1
    // 0xdf299c: b               #0xdf2ae4
    // 0xdf29a0: r17 = 5168
    //     0xdf29a0: mov             x17, #0x1430
    // 0xdf29a4: cmp             x1, x17
    // 0xdf29a8: b.ne            #0xdf29e8
    // 0xdf29ac: r1 = 1
    //     0xdf29ac: mov             x1, #1
    // 0xdf29b0: r0 = AllocateContext()
    //     0xdf29b0: bl              #0x13de838  ; AllocateContextStub
    // 0xdf29b4: mov             x1, x0
    // 0xdf29b8: ldr             x0, [fp, #0x10]
    // 0xdf29bc: StoreField: r1->field_f = r0
    //     0xdf29bc: stur            w0, [x1, #0xf]
    // 0xdf29c0: mov             x2, x1
    // 0xdf29c4: r1 = Function '<anonymous closure>':.
    //     0xdf29c4: add             x1, PP, #0x26, lsl #12  ; [pp+0x26438] AnonymousClosure: (0xdf2bac), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM3
    //     0xdf29c8: ldr             x1, [x1, #0x438]
    // 0xdf29cc: r0 = AllocateClosure()
    //     0xdf29cc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf29d0: r16 = <Color?>
    //     0xdf29d0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xdf29d4: ldr             x16, [x16, #0xa40]
    // 0xdf29d8: stp             x0, x16, [SP]
    // 0xdf29dc: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdf29dc: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdf29e0: r0 = resolveWith()
    //     0xdf29e0: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xdf29e4: b               #0xdf2ae4
    // 0xdf29e8: r1 = 1
    //     0xdf29e8: mov             x1, #1
    // 0xdf29ec: r0 = AllocateContext()
    //     0xdf29ec: bl              #0x13de838  ; AllocateContextStub
    // 0xdf29f0: mov             x1, x0
    // 0xdf29f4: ldr             x0, [fp, #0x10]
    // 0xdf29f8: StoreField: r1->field_f = r0
    //     0xdf29f8: stur            w0, [x1, #0xf]
    // 0xdf29fc: mov             x2, x1
    // 0xdf2a00: r1 = Function '<anonymous closure>':.
    //     0xdf2a00: add             x1, PP, #0x26, lsl #12  ; [pp+0x26440] AnonymousClosure: (0xdf2afc), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM2
    //     0xdf2a04: ldr             x1, [x1, #0x440]
    // 0xdf2a08: r0 = AllocateClosure()
    //     0xdf2a08: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf2a0c: r16 = <Color?>
    //     0xdf2a0c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xdf2a10: ldr             x16, [x16, #0xa40]
    // 0xdf2a14: stp             x0, x16, [SP]
    // 0xdf2a18: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdf2a18: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdf2a1c: r0 = resolveWith()
    //     0xdf2a1c: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xdf2a20: b               #0xdf2ae4
    // 0xdf2a24: ldr             x0, [fp, #0x10]
    // 0xdf2a28: cmp             w0, NULL
    // 0xdf2a2c: b.ne            #0xdf2a38
    // 0xdf2a30: r1 = Null
    //     0xdf2a30: mov             x1, NULL
    // 0xdf2a34: b               #0xdf2ae0
    // 0xdf2a38: r1 = LoadClassIdInstr(r0)
    //     0xdf2a38: ldur            x1, [x0, #-1]
    //     0xdf2a3c: ubfx            x1, x1, #0xc, #0x14
    // 0xdf2a40: r17 = 5167
    //     0xdf2a40: mov             x17, #0x142f
    // 0xdf2a44: cmp             x1, x17
    // 0xdf2a48: b.ne            #0xdf2a58
    // 0xdf2a4c: LoadField: r1 = r0->field_37
    //     0xdf2a4c: ldur            w1, [x0, #0x37]
    // 0xdf2a50: DecompressPointer r1
    //     0xdf2a50: add             x1, x1, HEAP, lsl #32
    // 0xdf2a54: b               #0xdf2ae0
    // 0xdf2a58: r17 = 5168
    //     0xdf2a58: mov             x17, #0x1430
    // 0xdf2a5c: cmp             x1, x17
    // 0xdf2a60: b.ne            #0xdf2aa4
    // 0xdf2a64: r1 = 1
    //     0xdf2a64: mov             x1, #1
    // 0xdf2a68: r0 = AllocateContext()
    //     0xdf2a68: bl              #0x13de838  ; AllocateContextStub
    // 0xdf2a6c: mov             x1, x0
    // 0xdf2a70: ldr             x0, [fp, #0x10]
    // 0xdf2a74: StoreField: r1->field_f = r0
    //     0xdf2a74: stur            w0, [x1, #0xf]
    // 0xdf2a78: mov             x2, x1
    // 0xdf2a7c: r1 = Function '<anonymous closure>':.
    //     0xdf2a7c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26438] AnonymousClosure: (0xdf2bac), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM3
    //     0xdf2a80: ldr             x1, [x1, #0x438]
    // 0xdf2a84: r0 = AllocateClosure()
    //     0xdf2a84: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf2a88: r16 = <Color?>
    //     0xdf2a88: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xdf2a8c: ldr             x16, [x16, #0xa40]
    // 0xdf2a90: stp             x0, x16, [SP]
    // 0xdf2a94: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdf2a94: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdf2a98: r0 = resolveWith()
    //     0xdf2a98: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xdf2a9c: mov             x1, x0
    // 0xdf2aa0: b               #0xdf2ae0
    // 0xdf2aa4: r1 = 1
    //     0xdf2aa4: mov             x1, #1
    // 0xdf2aa8: r0 = AllocateContext()
    //     0xdf2aa8: bl              #0x13de838  ; AllocateContextStub
    // 0xdf2aac: mov             x1, x0
    // 0xdf2ab0: ldr             x0, [fp, #0x10]
    // 0xdf2ab4: StoreField: r1->field_f = r0
    //     0xdf2ab4: stur            w0, [x1, #0xf]
    // 0xdf2ab8: mov             x2, x1
    // 0xdf2abc: r1 = Function '<anonymous closure>':.
    //     0xdf2abc: add             x1, PP, #0x26, lsl #12  ; [pp+0x26440] AnonymousClosure: (0xdf2afc), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM2
    //     0xdf2ac0: ldr             x1, [x1, #0x440]
    // 0xdf2ac4: r0 = AllocateClosure()
    //     0xdf2ac4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf2ac8: r16 = <Color?>
    //     0xdf2ac8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xdf2acc: ldr             x16, [x16, #0xa40]
    // 0xdf2ad0: stp             x0, x16, [SP]
    // 0xdf2ad4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdf2ad4: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdf2ad8: r0 = resolveWith()
    //     0xdf2ad8: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xdf2adc: mov             x1, x0
    // 0xdf2ae0: mov             x0, x1
    // 0xdf2ae4: LeaveFrame
    //     0xdf2ae4: mov             SP, fp
    //     0xdf2ae8: ldp             fp, lr, [SP], #0x10
    // 0xdf2aec: ret
    //     0xdf2aec: ret             
    // 0xdf2af0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf2af0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf2af4: b               #0xdf2944
    // 0xdf2af8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf2af8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] WidgetStateProperty<Color?>? <anonymous closure>(dynamic, DatePickerThemeData?) {
    // ** addr: 0xdf2c5c, size: 0x1dc
    // 0xdf2c5c: EnterFrame
    //     0xdf2c5c: stp             fp, lr, [SP, #-0x10]!
    //     0xdf2c60: mov             fp, SP
    // 0xdf2c64: AllocStack(0x10)
    //     0xdf2c64: sub             SP, SP, #0x10
    // 0xdf2c68: SetupParameters([dynamic _ /* r0 */])
    //     0xdf2c68: ldr             x0, [fp, #0x18]
    //     0xdf2c6c: ldur            w1, [x0, #0x17]
    //     0xdf2c70: add             x1, x1, HEAP, lsl #32
    // 0xdf2c74: CheckStackOverflow
    //     0xdf2c74: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf2c78: cmp             SP, x16
    //     0xdf2c7c: b.ls            #0xdf2e2c
    // 0xdf2c80: LoadField: r0 = r1->field_f
    //     0xdf2c80: ldur            w0, [x1, #0xf]
    // 0xdf2c84: DecompressPointer r0
    //     0xdf2c84: add             x0, x0, HEAP, lsl #32
    // 0xdf2c88: LoadField: r1 = r0->field_b
    //     0xdf2c88: ldur            w1, [x0, #0xb]
    // 0xdf2c8c: DecompressPointer r1
    //     0xdf2c8c: add             x1, x1, HEAP, lsl #32
    // 0xdf2c90: cmp             w1, NULL
    // 0xdf2c94: b.eq            #0xdf2e34
    // 0xdf2c98: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xdf2c98: ldur            w0, [x1, #0x17]
    // 0xdf2c9c: DecompressPointer r0
    //     0xdf2c9c: add             x0, x0, HEAP, lsl #32
    // 0xdf2ca0: tbnz            w0, #4, #0xdf2d60
    // 0xdf2ca4: ldr             x0, [fp, #0x10]
    // 0xdf2ca8: cmp             w0, NULL
    // 0xdf2cac: b.ne            #0xdf2cb8
    // 0xdf2cb0: r0 = Null
    //     0xdf2cb0: mov             x0, NULL
    // 0xdf2cb4: b               #0xdf2e20
    // 0xdf2cb8: r1 = LoadClassIdInstr(r0)
    //     0xdf2cb8: ldur            x1, [x0, #-1]
    //     0xdf2cbc: ubfx            x1, x1, #0xc, #0x14
    // 0xdf2cc0: r17 = 5167
    //     0xdf2cc0: mov             x17, #0x142f
    // 0xdf2cc4: cmp             x1, x17
    // 0xdf2cc8: b.ne            #0xdf2cdc
    // 0xdf2ccc: LoadField: r1 = r0->field_43
    //     0xdf2ccc: ldur            w1, [x0, #0x43]
    // 0xdf2cd0: DecompressPointer r1
    //     0xdf2cd0: add             x1, x1, HEAP, lsl #32
    // 0xdf2cd4: mov             x0, x1
    // 0xdf2cd8: b               #0xdf2e20
    // 0xdf2cdc: r17 = 5168
    //     0xdf2cdc: mov             x17, #0x1430
    // 0xdf2ce0: cmp             x1, x17
    // 0xdf2ce4: b.ne            #0xdf2d24
    // 0xdf2ce8: r1 = 1
    //     0xdf2ce8: mov             x1, #1
    // 0xdf2cec: r0 = AllocateContext()
    //     0xdf2cec: bl              #0x13de838  ; AllocateContextStub
    // 0xdf2cf0: mov             x1, x0
    // 0xdf2cf4: ldr             x0, [fp, #0x10]
    // 0xdf2cf8: StoreField: r1->field_f = r0
    //     0xdf2cf8: stur            w0, [x1, #0xf]
    // 0xdf2cfc: mov             x2, x1
    // 0xdf2d00: r1 = Function '<anonymous closure>':.
    //     0xdf2d00: add             x1, PP, #0x26, lsl #12  ; [pp+0x26458] AnonymousClosure: (0xdf3294), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM3
    //     0xdf2d04: ldr             x1, [x1, #0x458]
    // 0xdf2d08: r0 = AllocateClosure()
    //     0xdf2d08: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf2d0c: r16 = <Color?>
    //     0xdf2d0c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xdf2d10: ldr             x16, [x16, #0xa40]
    // 0xdf2d14: stp             x0, x16, [SP]
    // 0xdf2d18: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdf2d18: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdf2d1c: r0 = resolveWith()
    //     0xdf2d1c: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xdf2d20: b               #0xdf2e20
    // 0xdf2d24: r1 = 1
    //     0xdf2d24: mov             x1, #1
    // 0xdf2d28: r0 = AllocateContext()
    //     0xdf2d28: bl              #0x13de838  ; AllocateContextStub
    // 0xdf2d2c: mov             x1, x0
    // 0xdf2d30: ldr             x0, [fp, #0x10]
    // 0xdf2d34: StoreField: r1->field_f = r0
    //     0xdf2d34: stur            w0, [x1, #0xf]
    // 0xdf2d38: mov             x2, x1
    // 0xdf2d3c: r1 = Function '<anonymous closure>':.
    //     0xdf2d3c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26460] AnonymousClosure: (0xdf3120), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM2
    //     0xdf2d40: ldr             x1, [x1, #0x460]
    // 0xdf2d44: r0 = AllocateClosure()
    //     0xdf2d44: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf2d48: r16 = <Color?>
    //     0xdf2d48: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xdf2d4c: ldr             x16, [x16, #0xa40]
    // 0xdf2d50: stp             x0, x16, [SP]
    // 0xdf2d54: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdf2d54: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdf2d58: r0 = resolveWith()
    //     0xdf2d58: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xdf2d5c: b               #0xdf2e20
    // 0xdf2d60: ldr             x0, [fp, #0x10]
    // 0xdf2d64: cmp             w0, NULL
    // 0xdf2d68: b.ne            #0xdf2d74
    // 0xdf2d6c: r1 = Null
    //     0xdf2d6c: mov             x1, NULL
    // 0xdf2d70: b               #0xdf2e1c
    // 0xdf2d74: r1 = LoadClassIdInstr(r0)
    //     0xdf2d74: ldur            x1, [x0, #-1]
    //     0xdf2d78: ubfx            x1, x1, #0xc, #0x14
    // 0xdf2d7c: r17 = 5167
    //     0xdf2d7c: mov             x17, #0x142f
    // 0xdf2d80: cmp             x1, x17
    // 0xdf2d84: b.ne            #0xdf2d94
    // 0xdf2d88: LoadField: r1 = r0->field_33
    //     0xdf2d88: ldur            w1, [x0, #0x33]
    // 0xdf2d8c: DecompressPointer r1
    //     0xdf2d8c: add             x1, x1, HEAP, lsl #32
    // 0xdf2d90: b               #0xdf2e1c
    // 0xdf2d94: r17 = 5168
    //     0xdf2d94: mov             x17, #0x1430
    // 0xdf2d98: cmp             x1, x17
    // 0xdf2d9c: b.ne            #0xdf2de0
    // 0xdf2da0: r1 = 1
    //     0xdf2da0: mov             x1, #1
    // 0xdf2da4: r0 = AllocateContext()
    //     0xdf2da4: bl              #0x13de838  ; AllocateContextStub
    // 0xdf2da8: mov             x1, x0
    // 0xdf2dac: ldr             x0, [fp, #0x10]
    // 0xdf2db0: StoreField: r1->field_f = r0
    //     0xdf2db0: stur            w0, [x1, #0xf]
    // 0xdf2db4: mov             x2, x1
    // 0xdf2db8: r1 = Function '<anonymous closure>':.
    //     0xdf2db8: add             x1, PP, #0x26, lsl #12  ; [pp+0x26428] AnonymousClosure: (0xdf2fac), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM3
    //     0xdf2dbc: ldr             x1, [x1, #0x428]
    // 0xdf2dc0: r0 = AllocateClosure()
    //     0xdf2dc0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf2dc4: r16 = <Color?>
    //     0xdf2dc4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xdf2dc8: ldr             x16, [x16, #0xa40]
    // 0xdf2dcc: stp             x0, x16, [SP]
    // 0xdf2dd0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdf2dd0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdf2dd4: r0 = resolveWith()
    //     0xdf2dd4: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xdf2dd8: mov             x1, x0
    // 0xdf2ddc: b               #0xdf2e1c
    // 0xdf2de0: r1 = 1
    //     0xdf2de0: mov             x1, #1
    // 0xdf2de4: r0 = AllocateContext()
    //     0xdf2de4: bl              #0x13de838  ; AllocateContextStub
    // 0xdf2de8: mov             x1, x0
    // 0xdf2dec: ldr             x0, [fp, #0x10]
    // 0xdf2df0: StoreField: r1->field_f = r0
    //     0xdf2df0: stur            w0, [x1, #0xf]
    // 0xdf2df4: mov             x2, x1
    // 0xdf2df8: r1 = Function '<anonymous closure>':.
    //     0xdf2df8: add             x1, PP, #0x26, lsl #12  ; [pp+0x26430] AnonymousClosure: (0xdf2e38), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM2
    //     0xdf2dfc: ldr             x1, [x1, #0x430]
    // 0xdf2e00: r0 = AllocateClosure()
    //     0xdf2e00: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf2e04: r16 = <Color?>
    //     0xdf2e04: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xdf2e08: ldr             x16, [x16, #0xa40]
    // 0xdf2e0c: stp             x0, x16, [SP]
    // 0xdf2e10: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdf2e10: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdf2e14: r0 = resolveWith()
    //     0xdf2e14: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xdf2e18: mov             x1, x0
    // 0xdf2e1c: mov             x0, x1
    // 0xdf2e20: LeaveFrame
    //     0xdf2e20: mov             SP, fp
    //     0xdf2e24: ldp             fp, lr, [SP], #0x10
    // 0xdf2e28: ret
    //     0xdf2e28: ret             
    // 0xdf2e2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf2e2c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf2e30: b               #0xdf2c80
    // 0xdf2e34: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf2e34: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Y0? resolve<Y0>(dynamic, (dynamic, DatePickerThemeData?) => WidgetStateProperty<Y0>?, Set<WidgetState>) {
    // ** addr: 0xdf33f8, size: 0xe8
    // 0xdf33f8: EnterFrame
    //     0xdf33f8: stp             fp, lr, [SP, #-0x10]!
    //     0xdf33fc: mov             fp, SP
    // 0xdf3400: AllocStack(0x30)
    //     0xdf3400: sub             SP, SP, #0x30
    // 0xdf3404: SetupParameters([dynamic _ /* r0 */])
    //     0xdf3404: ldr             x0, [fp, #0x20]
    //     0xdf3408: ldur            w1, [x0, #0x17]
    //     0xdf340c: add             x1, x1, HEAP, lsl #32
    //     0xdf3410: stur            x1, [fp, #-0x10]
    // 0xdf3414: LoadField: r2 = r4->field_f
    //     0xdf3414: ldur            w2, [x4, #0xf]
    // 0xdf3418: cbnz            w2, #0xdf3424
    // 0xdf341c: r2 = Null
    //     0xdf341c: mov             x2, NULL
    // 0xdf3420: b               #0xdf3434
    // 0xdf3424: ArrayLoad: r2 = r4[0]  ; List_4
    //     0xdf3424: ldur            w2, [x4, #0x17]
    // 0xdf3428: add             x3, fp, w2, sxtw #2
    // 0xdf342c: ldr             x3, [x3, #0x10]
    // 0xdf3430: mov             x2, x3
    // 0xdf3434: LoadField: r3 = r0->field_f
    //     0xdf3434: ldur            w3, [x0, #0xf]
    // 0xdf3438: DecompressPointer r3
    //     0xdf3438: add             x3, x3, HEAP, lsl #32
    // 0xdf343c: ldr             x16, [THR, #0xb0]  ; THR::empty_type_arguments
    // 0xdf3440: cmp             w3, w16
    // 0xdf3444: b.ne            #0xdf344c
    // 0xdf3448: mov             x3, x2
    // 0xdf344c: ldr             x2, [fp, #0x18]
    // 0xdf3450: ldr             x0, [fp, #0x10]
    // 0xdf3454: stur            x3, [fp, #-8]
    // 0xdf3458: CheckStackOverflow
    //     0xdf3458: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf345c: cmp             SP, x16
    //     0xdf3460: b.ls            #0xdf34d8
    // 0xdf3464: r1 = 2
    //     0xdf3464: mov             x1, #2
    // 0xdf3468: r0 = AllocateContext()
    //     0xdf3468: bl              #0x13de838  ; AllocateContextStub
    // 0xdf346c: mov             x1, x0
    // 0xdf3470: ldur            x0, [fp, #-0x10]
    // 0xdf3474: StoreField: r1->field_b = r0
    //     0xdf3474: stur            w0, [x1, #0xb]
    // 0xdf3478: ldr             x2, [fp, #0x18]
    // 0xdf347c: StoreField: r1->field_f = r2
    //     0xdf347c: stur            w2, [x1, #0xf]
    // 0xdf3480: ldr             x2, [fp, #0x10]
    // 0xdf3484: StoreField: r1->field_13 = r2
    //     0xdf3484: stur            w2, [x1, #0x13]
    // 0xdf3488: LoadField: r3 = r0->field_1b
    //     0xdf3488: ldur            w3, [x0, #0x1b]
    // 0xdf348c: DecompressPointer r3
    //     0xdf348c: add             x3, x3, HEAP, lsl #32
    // 0xdf3490: mov             x2, x1
    // 0xdf3494: stur            x3, [fp, #-0x18]
    // 0xdf3498: r1 = Function '<anonymous closure>':.
    //     0xdf3498: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4270] AnonymousClosure: (0xdf34e0), in [package:flutter/src/material/calendar_date_picker.dart] _YearPickerState::_buildYearItem (0xdf3664)
    //     0xdf349c: ldr             x1, [x1, #0x270]
    // 0xdf34a0: r0 = AllocateClosure()
    //     0xdf34a0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf34a4: mov             x1, x0
    // 0xdf34a8: ldur            x0, [fp, #-8]
    // 0xdf34ac: StoreField: r1->field_b = r0
    //     0xdf34ac: stur            w0, [x1, #0xb]
    // 0xdf34b0: ldur            x16, [fp, #-0x18]
    // 0xdf34b4: stp             x16, x0, [SP, #8]
    // 0xdf34b8: str             x1, [SP]
    // 0xdf34bc: ldur            x0, [fp, #-0x18]
    // 0xdf34c0: ClosureCall
    //     0xdf34c0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0xdf34c4: ldur            x2, [x0, #0x1f]
    //     0xdf34c8: blr             x2
    // 0xdf34cc: LeaveFrame
    //     0xdf34cc: mov             SP, fp
    //     0xdf34d0: ldp             fp, lr, [SP], #0x10
    // 0xdf34d4: ret
    //     0xdf34d4: ret             
    // 0xdf34d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf34d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf34dc: b               #0xdf3464
  }
  [closure] Y0? effectiveValue<Y0>(dynamic, (dynamic, DatePickerThemeData?) => Y0?) {
    // ** addr: 0xdf4b70, size: 0x88
    // 0xdf4b70: EnterFrame
    //     0xdf4b70: stp             fp, lr, [SP, #-0x10]!
    //     0xdf4b74: mov             fp, SP
    // 0xdf4b78: AllocStack(0x18)
    //     0xdf4b78: sub             SP, SP, #0x18
    // 0xdf4b7c: SetupParameters([dynamic _ /* r0 */])
    //     0xdf4b7c: ldr             x0, [fp, #0x18]
    //     0xdf4b80: ldur            w1, [x0, #0x17]
    //     0xdf4b84: add             x1, x1, HEAP, lsl #32
    //     0xdf4b88: stur            x1, [fp, #-8]
    // 0xdf4b8c: CheckStackOverflow
    //     0xdf4b8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf4b90: cmp             SP, x16
    //     0xdf4b94: b.ls            #0xdf4bf0
    // 0xdf4b98: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xdf4b98: ldur            w0, [x1, #0x17]
    // 0xdf4b9c: DecompressPointer r0
    //     0xdf4b9c: add             x0, x0, HEAP, lsl #32
    // 0xdf4ba0: ldr             x16, [fp, #0x10]
    // 0xdf4ba4: stp             x0, x16, [SP]
    // 0xdf4ba8: ldr             x0, [fp, #0x10]
    // 0xdf4bac: ClosureCall
    //     0xdf4bac: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xdf4bb0: ldur            x2, [x0, #0x1f]
    //     0xdf4bb4: blr             x2
    // 0xdf4bb8: cmp             w0, NULL
    // 0xdf4bbc: b.ne            #0xdf4be4
    // 0xdf4bc0: ldur            x0, [fp, #-8]
    // 0xdf4bc4: LoadField: r1 = r0->field_13
    //     0xdf4bc4: ldur            w1, [x0, #0x13]
    // 0xdf4bc8: DecompressPointer r1
    //     0xdf4bc8: add             x1, x1, HEAP, lsl #32
    // 0xdf4bcc: ldr             x16, [fp, #0x10]
    // 0xdf4bd0: stp             x1, x16, [SP]
    // 0xdf4bd4: ldr             x0, [fp, #0x10]
    // 0xdf4bd8: ClosureCall
    //     0xdf4bd8: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xdf4bdc: ldur            x2, [x0, #0x1f]
    //     0xdf4be0: blr             x2
    // 0xdf4be4: LeaveFrame
    //     0xdf4be4: mov             SP, fp
    //     0xdf4be8: ldp             fp, lr, [SP], #0x10
    // 0xdf4bec: ret
    //     0xdf4bec: ret             
    // 0xdf4bf0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf4bf0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf4bf4: b               #0xdf4b98
  }
}

// class id: 5474, size: 0x18, field offset: 0x14
class _DayPickerState extends State<dynamic> {

  late List<FocusNode> _dayFocusNodes; // offset: 0x14

  _ build(/* No info */) {
    // ** addr: 0xdf049c, size: 0x888
    // 0xdf049c: EnterFrame
    //     0xdf049c: stp             fp, lr, [SP, #-0x10]!
    //     0xdf04a0: mov             fp, SP
    // 0xdf04a4: AllocStack(0xa8)
    //     0xdf04a4: sub             SP, SP, #0xa8
    // 0xdf04a8: SetupParameters(_DayPickerState this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xdf04a8: mov             x0, x2
    //     0xdf04ac: stur            x2, [fp, #-0x10]
    //     0xdf04b0: mov             x2, x1
    //     0xdf04b4: stur            x1, [fp, #-8]
    // 0xdf04b8: CheckStackOverflow
    //     0xdf04b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf04bc: cmp             SP, x16
    //     0xdf04c0: b.ls            #0xdf0cb4
    // 0xdf04c4: mov             x1, x0
    // 0xdf04c8: r0 = of()
    //     0xdf04c8: bl              #0xd0bbf8  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0xdf04cc: ldur            x1, [fp, #-0x10]
    // 0xdf04d0: stur            x0, [fp, #-0x18]
    // 0xdf04d4: r0 = of()
    //     0xdf04d4: bl              #0xd0ff6c  ; [package:flutter/src/material/date_picker_theme.dart] DatePickerTheme::of
    // 0xdf04d8: ldur            x1, [fp, #-0x10]
    // 0xdf04dc: r0 = defaults()
    //     0xdf04dc: bl              #0xd0fd74  ; [package:flutter/src/material/date_picker_theme.dart] DatePickerTheme::defaults
    // 0xdf04e0: stur            x0, [fp, #-0x20]
    // 0xdf04e4: r1 = LoadClassIdInstr(r0)
    //     0xdf04e4: ldur            x1, [x0, #-1]
    //     0xdf04e8: ubfx            x1, x1, #0xc, #0x14
    // 0xdf04ec: r17 = 5167
    //     0xdf04ec: mov             x17, #0x142f
    // 0xdf04f0: cmp             x1, x17
    // 0xdf04f4: b.ne            #0xdf0508
    // 0xdf04f8: LoadField: r1 = r0->field_2b
    //     0xdf04f8: ldur            w1, [x0, #0x2b]
    // 0xdf04fc: DecompressPointer r1
    //     0xdf04fc: add             x1, x1, HEAP, lsl #32
    // 0xdf0500: mov             x2, x1
    // 0xdf0504: b               #0xdf0620
    // 0xdf0508: r17 = 5168
    //     0xdf0508: mov             x17, #0x1430
    // 0xdf050c: cmp             x1, x17
    // 0xdf0510: b.ne            #0xdf0584
    // 0xdf0514: mov             x1, x0
    // 0xdf0518: LoadField: r0 = r1->field_b7
    //     0xdf0518: ldur            w0, [x1, #0xb7]
    // 0xdf051c: DecompressPointer r0
    //     0xdf051c: add             x0, x0, HEAP, lsl #32
    // 0xdf0520: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf0524: cmp             w0, w16
    // 0xdf0528: b.ne            #0xdf0538
    // 0xdf052c: r2 = _textTheme
    //     0xdf052c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26418] Field <_DatePickerDefaultsM3@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0xdf0530: ldr             x2, [x2, #0x418]
    // 0xdf0534: r0 = InitLateFinalInstanceField()
    //     0xdf0534: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf0538: LoadField: r2 = r0->field_2b
    //     0xdf0538: ldur            w2, [x0, #0x2b]
    // 0xdf053c: DecompressPointer r2
    //     0xdf053c: add             x2, x2, HEAP, lsl #32
    // 0xdf0540: ldur            x1, [fp, #-0x20]
    // 0xdf0544: stur            x2, [fp, #-0x28]
    // 0xdf0548: LoadField: r0 = r1->field_b3
    //     0xdf0548: ldur            w0, [x1, #0xb3]
    // 0xdf054c: DecompressPointer r0
    //     0xdf054c: add             x0, x0, HEAP, lsl #32
    // 0xdf0550: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf0554: cmp             w0, w16
    // 0xdf0558: b.ne            #0xdf0568
    // 0xdf055c: r2 = _colors
    //     0xdf055c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xdf0560: ldr             x2, [x2, #0x400]
    // 0xdf0564: r0 = InitLateFinalInstanceField()
    //     0xdf0564: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf0568: LoadField: r2 = r0->field_7f
    //     0xdf0568: ldur            w2, [x0, #0x7f]
    // 0xdf056c: DecompressPointer r2
    //     0xdf056c: add             x2, x2, HEAP, lsl #32
    // 0xdf0570: ldur            x1, [fp, #-0x28]
    // 0xdf0574: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xdf0574: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xdf0578: r0 = apply()
    //     0xdf0578: bl              #0x8acf20  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0xdf057c: mov             x2, x0
    // 0xdf0580: b               #0xdf0620
    // 0xdf0584: ldur            x1, [fp, #-0x20]
    // 0xdf0588: LoadField: r0 = r1->field_b7
    //     0xdf0588: ldur            w0, [x1, #0xb7]
    // 0xdf058c: DecompressPointer r0
    //     0xdf058c: add             x0, x0, HEAP, lsl #32
    // 0xdf0590: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf0594: cmp             w0, w16
    // 0xdf0598: b.ne            #0xdf05a8
    // 0xdf059c: r2 = _textTheme
    //     0xdf059c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26420] Field <_DatePickerDefaultsM2@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0xdf05a0: ldr             x2, [x2, #0x420]
    // 0xdf05a4: r0 = InitLateFinalInstanceField()
    //     0xdf05a4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf05a8: LoadField: r2 = r0->field_33
    //     0xdf05a8: ldur            w2, [x0, #0x33]
    // 0xdf05ac: DecompressPointer r2
    //     0xdf05ac: add             x2, x2, HEAP, lsl #32
    // 0xdf05b0: stur            x2, [fp, #-0x28]
    // 0xdf05b4: cmp             w2, NULL
    // 0xdf05b8: b.ne            #0xdf05c4
    // 0xdf05bc: r0 = Null
    //     0xdf05bc: mov             x0, NULL
    // 0xdf05c0: b               #0xdf061c
    // 0xdf05c4: ldur            x1, [fp, #-0x20]
    // 0xdf05c8: LoadField: r0 = r1->field_b3
    //     0xdf05c8: ldur            w0, [x1, #0xb3]
    // 0xdf05cc: DecompressPointer r0
    //     0xdf05cc: add             x0, x0, HEAP, lsl #32
    // 0xdf05d0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf05d4: cmp             w0, w16
    // 0xdf05d8: b.ne            #0xdf05e8
    // 0xdf05dc: r2 = _colors
    //     0xdf05dc: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xdf05e0: ldr             x2, [x2, #0x410]
    // 0xdf05e4: r0 = InitLateFinalInstanceField()
    //     0xdf05e4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf05e8: LoadField: r1 = r0->field_7f
    //     0xdf05e8: ldur            w1, [x0, #0x7f]
    // 0xdf05ec: DecompressPointer r1
    //     0xdf05ec: add             x1, x1, HEAP, lsl #32
    // 0xdf05f0: r0 = LoadClassIdInstr(r1)
    //     0xdf05f0: ldur            x0, [x1, #-1]
    //     0xdf05f4: ubfx            x0, x0, #0xc, #0x14
    // 0xdf05f8: d0 = 0.600000
    //     0xdf05f8: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c88] IMM: double(0.6) from 0x3fe3333333333333
    //     0xdf05fc: ldr             d0, [x17, #0xc88]
    // 0xdf0600: r0 = GDT[cid_x0 + -0x1000]()
    //     0xdf0600: sub             lr, x0, #1, lsl #12
    //     0xdf0604: ldr             lr, [x21, lr, lsl #3]
    //     0xdf0608: blr             lr
    // 0xdf060c: ldur            x1, [fp, #-0x28]
    // 0xdf0610: mov             x2, x0
    // 0xdf0614: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xdf0614: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xdf0618: r0 = apply()
    //     0xdf0618: bl              #0x8acf20  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0xdf061c: mov             x2, x0
    // 0xdf0620: ldur            x0, [fp, #-8]
    // 0xdf0624: ldur            x1, [fp, #-0x10]
    // 0xdf0628: stur            x2, [fp, #-0x20]
    // 0xdf062c: r0 = orientationOf()
    //     0xdf062c: bl              #0xd172a4  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::orientationOf
    // 0xdf0630: r16 = Instance_Orientation
    //     0xdf0630: add             x16, PP, #0x14, lsl #12  ; [pp+0x143c0] Obj!Orientation@12c2ee1
    //     0xdf0634: ldr             x16, [x16, #0x3c0]
    // 0xdf0638: cmp             w0, w16
    // 0xdf063c: r16 = true
    //     0xdf063c: add             x16, NULL, #0x20  ; true
    // 0xdf0640: r17 = false
    //     0xdf0640: add             x17, NULL, #0x30  ; false
    // 0xdf0644: csel            x2, x16, x17, eq
    // 0xdf0648: ldur            x0, [fp, #-8]
    // 0xdf064c: stur            x2, [fp, #-0x28]
    // 0xdf0650: LoadField: r1 = r0->field_b
    //     0xdf0650: ldur            w1, [x0, #0xb]
    // 0xdf0654: DecompressPointer r1
    //     0xdf0654: add             x1, x1, HEAP, lsl #32
    // 0xdf0658: cmp             w1, NULL
    // 0xdf065c: b.eq            #0xdf0cbc
    // 0xdf0660: LoadField: r3 = r1->field_1f
    //     0xdf0660: ldur            w3, [x1, #0x1f]
    // 0xdf0664: DecompressPointer r3
    //     0xdf0664: add             x3, x3, HEAP, lsl #32
    // 0xdf0668: mov             x1, x3
    // 0xdf066c: r0 = _parts()
    //     0xdf066c: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xdf0670: mov             x2, x0
    // 0xdf0674: LoadField: r0 = r2->field_b
    //     0xdf0674: ldur            w0, [x2, #0xb]
    // 0xdf0678: r1 = LoadInt32Instr(r0)
    //     0xdf0678: sbfx            x1, x0, #1, #0x1f
    // 0xdf067c: mov             x0, x1
    // 0xdf0680: r1 = 8
    //     0xdf0680: mov             x1, #8
    // 0xdf0684: cmp             x1, x0
    // 0xdf0688: b.hs            #0xdf0cc0
    // 0xdf068c: LoadField: r0 = r2->field_2f
    //     0xdf068c: ldur            w0, [x2, #0x2f]
    // 0xdf0690: DecompressPointer r0
    //     0xdf0690: add             x0, x0, HEAP, lsl #32
    // 0xdf0694: ldur            x2, [fp, #-8]
    // 0xdf0698: stur            x0, [fp, #-0x30]
    // 0xdf069c: LoadField: r1 = r2->field_b
    //     0xdf069c: ldur            w1, [x2, #0xb]
    // 0xdf06a0: DecompressPointer r1
    //     0xdf06a0: add             x1, x1, HEAP, lsl #32
    // 0xdf06a4: cmp             w1, NULL
    // 0xdf06a8: b.eq            #0xdf0cc4
    // 0xdf06ac: LoadField: r3 = r1->field_1f
    //     0xdf06ac: ldur            w3, [x1, #0x1f]
    // 0xdf06b0: DecompressPointer r3
    //     0xdf06b0: add             x3, x3, HEAP, lsl #32
    // 0xdf06b4: mov             x1, x3
    // 0xdf06b8: r0 = _parts()
    //     0xdf06b8: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xdf06bc: mov             x2, x0
    // 0xdf06c0: LoadField: r0 = r2->field_b
    //     0xdf06c0: ldur            w0, [x2, #0xb]
    // 0xdf06c4: r1 = LoadInt32Instr(r0)
    //     0xdf06c4: sbfx            x1, x0, #1, #0x1f
    // 0xdf06c8: mov             x0, x1
    // 0xdf06cc: r1 = 7
    //     0xdf06cc: mov             x1, #7
    // 0xdf06d0: cmp             x1, x0
    // 0xdf06d4: b.hs            #0xdf0cc8
    // 0xdf06d8: LoadField: r4 = r2->field_2b
    //     0xdf06d8: ldur            w4, [x2, #0x2b]
    // 0xdf06dc: DecompressPointer r4
    //     0xdf06dc: add             x4, x4, HEAP, lsl #32
    // 0xdf06e0: ldur            x5, [fp, #-8]
    // 0xdf06e4: stur            x4, [fp, #-0x48]
    // 0xdf06e8: LoadField: r0 = r5->field_b
    //     0xdf06e8: ldur            w0, [x5, #0xb]
    // 0xdf06ec: DecompressPointer r0
    //     0xdf06ec: add             x0, x0, HEAP, lsl #32
    // 0xdf06f0: cmp             w0, NULL
    // 0xdf06f4: b.eq            #0xdf0ccc
    // 0xdf06f8: r2 = LoadInt32Instr(r4)
    //     0xdf06f8: sbfx            x2, x4, #1, #0x1f
    //     0xdf06fc: tbz             w4, #0, #0xdf0704
    //     0xdf0700: ldur            x2, [x4, #7]
    // 0xdf0704: cmp             x2, #2
    // 0xdf0708: b.ne            #0xdf0764
    // 0xdf070c: ldur            x3, [fp, #-0x30]
    // 0xdf0710: r0 = LoadInt32Instr(r3)
    //     0xdf0710: sbfx            x0, x3, #1, #0x1f
    //     0xdf0714: tbz             w3, #0, #0xdf071c
    //     0xdf0718: ldur            x0, [x3, #7]
    // 0xdf071c: tst             x0, #3
    // 0xdf0720: b.ne            #0xdf073c
    // 0xdf0724: r1 = 100
    //     0xdf0724: mov             x1, #0x64
    // 0xdf0728: sdiv            x7, x0, x1
    // 0xdf072c: msub            x6, x7, x1, x0
    // 0xdf0730: cmp             x6, xzr
    // 0xdf0734: b.lt            #0xdf0cd0
    // 0xdf0738: cbnz            x6, #0xdf0754
    // 0xdf073c: r1 = 400
    //     0xdf073c: mov             x1, #0x190
    // 0xdf0740: sdiv            x7, x0, x1
    // 0xdf0744: msub            x6, x7, x1, x0
    // 0xdf0748: cmp             x6, xzr
    // 0xdf074c: b.lt            #0xdf0cd8
    // 0xdf0750: cbnz            x6, #0xdf075c
    // 0xdf0754: r0 = 29
    //     0xdf0754: mov             x0, #0x1d
    // 0xdf0758: b               #0xdf07a0
    // 0xdf075c: r0 = 28
    //     0xdf075c: mov             x0, #0x1c
    // 0xdf0760: b               #0xdf07a0
    // 0xdf0764: ldur            x3, [fp, #-0x30]
    // 0xdf0768: r6 = const [0x1f, 0xffffffffffffffff, 0x1f, 0x1e, 0x1f, 0x1e, 0x1f, 0x1f, 0x1e, 0x1f, 0x1e, 0x1f]
    //     0xdf0768: add             x6, PP, #0xa3, lsl #12  ; [pp+0xa3fb0] List<int>(12)
    //     0xdf076c: ldr             x6, [x6, #0xfb0]
    // 0xdf0770: sub             x7, x2, #1
    // 0xdf0774: mov             x1, x7
    // 0xdf0778: r0 = 12
    //     0xdf0778: mov             x0, #0xc
    // 0xdf077c: cmp             x1, x0
    // 0xdf0780: b.hs            #0xdf0ce0
    // 0xdf0784: ArrayLoad: r0 = r6[r7]  ; Unknown_4
    //     0xdf0784: add             x16, x6, x7, lsl #2
    //     0xdf0788: ldur            w0, [x16, #0xf]
    // 0xdf078c: DecompressPointer r0
    //     0xdf078c: add             x0, x0, HEAP, lsl #32
    // 0xdf0790: r1 = LoadInt32Instr(r0)
    //     0xdf0790: sbfx            x1, x0, #1, #0x1f
    //     0xdf0794: tbz             w0, #0, #0xdf079c
    //     0xdf0798: ldur            x1, [x0, #7]
    // 0xdf079c: mov             x0, x1
    // 0xdf07a0: stur            x0, [fp, #-0x40]
    // 0xdf07a4: r6 = LoadInt32Instr(r3)
    //     0xdf07a4: sbfx            x6, x3, #1, #0x1f
    //     0xdf07a8: tbz             w3, #0, #0xdf07b0
    //     0xdf07ac: ldur            x6, [x3, #7]
    // 0xdf07b0: mov             x1, x6
    // 0xdf07b4: ldur            x3, [fp, #-0x18]
    // 0xdf07b8: stur            x6, [fp, #-0x38]
    // 0xdf07bc: r0 = firstDayOffset()
    //     0xdf07bc: bl              #0xdf10a4  ; [package:flutter/src/material/date.dart] DateUtils::firstDayOffset
    // 0xdf07c0: ldur            x1, [fp, #-8]
    // 0xdf07c4: ldur            x2, [fp, #-0x20]
    // 0xdf07c8: ldur            x3, [fp, #-0x18]
    // 0xdf07cc: stur            x0, [fp, #-0x50]
    // 0xdf07d0: r0 = _dayHeaders()
    //     0xdf07d0: bl              #0xdf0ea0  ; [package:flutter/src/material/calendar_date_picker.dart] _DayPickerState::_dayHeaders
    // 0xdf07d4: mov             x3, x0
    // 0xdf07d8: ldur            x0, [fp, #-0x50]
    // 0xdf07dc: stur            x3, [fp, #-0x20]
    // 0xdf07e0: neg             x1, x0
    // 0xdf07e4: LoadField: r4 = r3->field_7
    //     0xdf07e4: ldur            w4, [x3, #7]
    // 0xdf07e8: DecompressPointer r4
    //     0xdf07e8: add             x4, x4, HEAP, lsl #32
    // 0xdf07ec: stur            x4, [fp, #-0x18]
    // 0xdf07f0: mov             x0, x1
    // 0xdf07f4: ldur            x5, [fp, #-8]
    // 0xdf07f8: ldur            x6, [fp, #-0x40]
    // 0xdf07fc: CheckStackOverflow
    //     0xdf07fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf0800: cmp             SP, x16
    //     0xdf0804: b.ls            #0xdf0ce4
    // 0xdf0808: cmp             x0, x6
    // 0xdf080c: b.ge            #0xdf0b44
    // 0xdf0810: add             x7, x0, #1
    // 0xdf0814: stur            x7, [fp, #-0x50]
    // 0xdf0818: cmp             x7, #1
    // 0xdf081c: b.ge            #0xdf08ac
    // 0xdf0820: mov             x2, x4
    // 0xdf0824: r0 = Instance_SizedBox
    //     0xdf0824: ldr             x0, [PP, #0x4f58]  ; [pp+0x4f58] Obj!SizedBox@12b70e1
    // 0xdf0828: r1 = Null
    //     0xdf0828: mov             x1, NULL
    // 0xdf082c: cmp             w2, NULL
    // 0xdf0830: b.eq            #0xdf0850
    // 0xdf0834: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xdf0834: ldur            w4, [x2, #0x17]
    // 0xdf0838: DecompressPointer r4
    //     0xdf0838: add             x4, x4, HEAP, lsl #32
    // 0xdf083c: r8 = X0
    //     0xdf083c: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xdf0840: LoadField: r9 = r4->field_7
    //     0xdf0840: ldur            x9, [x4, #7]
    // 0xdf0844: r3 = Null
    //     0xdf0844: add             x3, PP, #0xd2, lsl #12  ; [pp+0xd28d8] Null
    //     0xdf0848: ldr             x3, [x3, #0x8d8]
    // 0xdf084c: blr             x9
    // 0xdf0850: ldur            x0, [fp, #-0x20]
    // 0xdf0854: LoadField: r1 = r0->field_b
    //     0xdf0854: ldur            w1, [x0, #0xb]
    // 0xdf0858: LoadField: r2 = r0->field_f
    //     0xdf0858: ldur            w2, [x0, #0xf]
    // 0xdf085c: DecompressPointer r2
    //     0xdf085c: add             x2, x2, HEAP, lsl #32
    // 0xdf0860: LoadField: r3 = r2->field_b
    //     0xdf0860: ldur            w3, [x2, #0xb]
    // 0xdf0864: r2 = LoadInt32Instr(r1)
    //     0xdf0864: sbfx            x2, x1, #1, #0x1f
    // 0xdf0868: stur            x2, [fp, #-0x58]
    // 0xdf086c: r1 = LoadInt32Instr(r3)
    //     0xdf086c: sbfx            x1, x3, #1, #0x1f
    // 0xdf0870: cmp             x2, x1
    // 0xdf0874: b.ne            #0xdf0880
    // 0xdf0878: mov             x1, x0
    // 0xdf087c: r0 = _growToNextCapacity()
    //     0xdf087c: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xdf0880: ldur            x2, [fp, #-0x20]
    // 0xdf0884: ldur            x0, [fp, #-0x58]
    // 0xdf0888: add             x1, x0, #1
    // 0xdf088c: lsl             x3, x1, #1
    // 0xdf0890: StoreField: r2->field_b = r3
    //     0xdf0890: stur            w3, [x2, #0xb]
    // 0xdf0894: LoadField: r1 = r2->field_f
    //     0xdf0894: ldur            w1, [x2, #0xf]
    // 0xdf0898: DecompressPointer r1
    //     0xdf0898: add             x1, x1, HEAP, lsl #32
    // 0xdf089c: add             x3, x1, x0, lsl #2
    // 0xdf08a0: r16 = Instance_SizedBox
    //     0xdf08a0: ldr             x16, [PP, #0x4f58]  ; [pp+0x4f58] Obj!SizedBox@12b70e1
    // 0xdf08a4: StoreField: r3->field_f = r16
    //     0xdf08a4: stur            w16, [x3, #0xf]
    // 0xdf08a8: b               #0xdf0b34
    // 0xdf08ac: mov             x2, x3
    // 0xdf08b0: mov             x3, x5
    // 0xdf08b4: mov             x4, x7
    // 0xdf08b8: LoadField: r0 = r3->field_b
    //     0xdf08b8: ldur            w0, [x3, #0xb]
    // 0xdf08bc: DecompressPointer r0
    //     0xdf08bc: add             x0, x0, HEAP, lsl #32
    // 0xdf08c0: cmp             w0, NULL
    // 0xdf08c4: b.eq            #0xdf0cec
    // 0xdf08c8: r0 = BoxInt64Instr(r4)
    //     0xdf08c8: sbfiz           x0, x4, #1, #0x1f
    //     0xdf08cc: cmp             x4, x0, asr #1
    //     0xdf08d0: b.eq            #0xdf08dc
    //     0xdf08d4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xdf08d8: stur            x4, [x0, #7]
    // 0xdf08dc: stur            x0, [fp, #-0x30]
    // 0xdf08e0: r0 = DateTime()
    //     0xdf08e0: bl              #0x8174b8  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0xdf08e4: stur            x0, [fp, #-0x60]
    // 0xdf08e8: ldur            x16, [fp, #-0x48]
    // 0xdf08ec: ldur            lr, [fp, #-0x30]
    // 0xdf08f0: stp             lr, x16, [SP]
    // 0xdf08f4: mov             x1, x0
    // 0xdf08f8: ldur            x2, [fp, #-0x38]
    // 0xdf08fc: r4 = const [0, 0x4, 0x2, 0x4, null]
    //     0xdf08fc: ldr             x4, [PP, #0x1388]  ; [pp+0x1388] List(5) [0, 0x4, 0x2, 0x4, Null]
    // 0xdf0900: r0 = DateTime()
    //     0xdf0900: bl              #0xaf09e4  ; [dart:core] DateTime::DateTime
    // 0xdf0904: ldur            x0, [fp, #-8]
    // 0xdf0908: LoadField: r1 = r0->field_b
    //     0xdf0908: ldur            w1, [x0, #0xb]
    // 0xdf090c: DecompressPointer r1
    //     0xdf090c: add             x1, x1, HEAP, lsl #32
    // 0xdf0910: cmp             w1, NULL
    // 0xdf0914: b.eq            #0xdf0cf0
    // 0xdf0918: LoadField: r2 = r1->field_1b
    //     0xdf0918: ldur            w2, [x1, #0x1b]
    // 0xdf091c: DecompressPointer r2
    //     0xdf091c: add             x2, x2, HEAP, lsl #32
    // 0xdf0920: ldur            x4, [fp, #-0x60]
    // 0xdf0924: LoadField: r3 = r4->field_b
    //     0xdf0924: ldur            x3, [x4, #0xb]
    // 0xdf0928: LoadField: r5 = r2->field_b
    //     0xdf0928: ldur            x5, [x2, #0xb]
    // 0xdf092c: cmp             x3, x5
    // 0xdf0930: b.gt            #0xdf0948
    // 0xdf0934: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xdf0934: ldur            w2, [x1, #0x17]
    // 0xdf0938: DecompressPointer r2
    //     0xdf0938: add             x2, x2, HEAP, lsl #32
    // 0xdf093c: LoadField: r5 = r2->field_b
    //     0xdf093c: ldur            x5, [x2, #0xb]
    // 0xdf0940: cmp             x3, x5
    // 0xdf0944: b.ge            #0xdf0950
    // 0xdf0948: r8 = true
    //     0xdf0948: add             x8, NULL, #0x20  ; true
    // 0xdf094c: b               #0xdf0954
    // 0xdf0950: r8 = false
    //     0xdf0950: add             x8, NULL, #0x30  ; false
    // 0xdf0954: ldur            x5, [fp, #-0x20]
    // 0xdf0958: ldur            x6, [fp, #-0x50]
    // 0xdf095c: r7 = Instance_GregorianCalendarDelegate
    //     0xdf095c: add             x7, PP, #0x28, lsl #12  ; [pp+0x28538] Obj!GregorianCalendarDelegate@129edd1
    //     0xdf0960: ldr             x7, [x7, #0x538]
    // 0xdf0964: stur            x8, [fp, #-0x30]
    // 0xdf0968: LoadField: r2 = r1->field_b
    //     0xdf0968: ldur            w2, [x1, #0xb]
    // 0xdf096c: DecompressPointer r2
    //     0xdf096c: add             x2, x2, HEAP, lsl #32
    // 0xdf0970: mov             x1, x7
    // 0xdf0974: mov             x3, x4
    // 0xdf0978: r0 = isSameDay()
    //     0xdf0978: bl              #0xc00af4  ; [package:flutter/src/material/date.dart] CalendarDelegate::isSameDay
    // 0xdf097c: mov             x4, x0
    // 0xdf0980: ldur            x0, [fp, #-8]
    // 0xdf0984: stur            x4, [fp, #-0x68]
    // 0xdf0988: LoadField: r1 = r0->field_b
    //     0xdf0988: ldur            w1, [x0, #0xb]
    // 0xdf098c: DecompressPointer r1
    //     0xdf098c: add             x1, x1, HEAP, lsl #32
    // 0xdf0990: cmp             w1, NULL
    // 0xdf0994: b.eq            #0xdf0cf4
    // 0xdf0998: LoadField: r2 = r1->field_f
    //     0xdf0998: ldur            w2, [x1, #0xf]
    // 0xdf099c: DecompressPointer r2
    //     0xdf099c: add             x2, x2, HEAP, lsl #32
    // 0xdf09a0: ldur            x3, [fp, #-0x60]
    // 0xdf09a4: r1 = Instance_GregorianCalendarDelegate
    //     0xdf09a4: add             x1, PP, #0x28, lsl #12  ; [pp+0x28538] Obj!GregorianCalendarDelegate@129edd1
    //     0xdf09a8: ldr             x1, [x1, #0x538]
    // 0xdf09ac: r0 = isSameDay()
    //     0xdf09ac: bl              #0xc00af4  ; [package:flutter/src/material/date.dart] CalendarDelegate::isSameDay
    // 0xdf09b0: r1 = <DateTime>
    //     0xdf09b0: add             x1, PP, #0x14, lsl #12  ; [pp+0x14b10] TypeArguments: <DateTime>
    //     0xdf09b4: ldr             x1, [x1, #0xb10]
    // 0xdf09b8: stur            x0, [fp, #-0x70]
    // 0xdf09bc: r0 = ValueKey()
    //     0xdf09bc: bl              #0x8e283c  ; AllocateValueKeyStub -> ValueKey<X0> (size=0x10)
    // 0xdf09c0: mov             x3, x0
    // 0xdf09c4: ldur            x2, [fp, #-0x60]
    // 0xdf09c8: stur            x3, [fp, #-0x88]
    // 0xdf09cc: StoreField: r3->field_b = r2
    //     0xdf09cc: stur            w2, [x3, #0xb]
    // 0xdf09d0: ldur            x4, [fp, #-8]
    // 0xdf09d4: LoadField: r0 = r4->field_b
    //     0xdf09d4: ldur            w0, [x4, #0xb]
    // 0xdf09d8: DecompressPointer r0
    //     0xdf09d8: add             x0, x0, HEAP, lsl #32
    // 0xdf09dc: cmp             w0, NULL
    // 0xdf09e0: b.eq            #0xdf0cf8
    // 0xdf09e4: LoadField: r5 = r0->field_13
    //     0xdf09e4: ldur            w5, [x0, #0x13]
    // 0xdf09e8: DecompressPointer r5
    //     0xdf09e8: add             x5, x5, HEAP, lsl #32
    // 0xdf09ec: stur            x5, [fp, #-0x80]
    // 0xdf09f0: LoadField: r6 = r4->field_13
    //     0xdf09f0: ldur            w6, [x4, #0x13]
    // 0xdf09f4: DecompressPointer r6
    //     0xdf09f4: add             x6, x6, HEAP, lsl #32
    // 0xdf09f8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf09fc: cmp             w6, w16
    // 0xdf0a00: b.eq            #0xdf0cfc
    // 0xdf0a04: ldur            x7, [fp, #-0x50]
    // 0xdf0a08: sub             x8, x7, #1
    // 0xdf0a0c: LoadField: r0 = r6->field_b
    //     0xdf0a0c: ldur            w0, [x6, #0xb]
    // 0xdf0a10: r1 = LoadInt32Instr(r0)
    //     0xdf0a10: sbfx            x1, x0, #1, #0x1f
    // 0xdf0a14: mov             x0, x1
    // 0xdf0a18: mov             x1, x8
    // 0xdf0a1c: cmp             x1, x0
    // 0xdf0a20: b.hs            #0xdf0d08
    // 0xdf0a24: LoadField: r0 = r6->field_f
    //     0xdf0a24: ldur            w0, [x6, #0xf]
    // 0xdf0a28: DecompressPointer r0
    //     0xdf0a28: add             x0, x0, HEAP, lsl #32
    // 0xdf0a2c: ArrayLoad: r1 = r0[r8]  ; Unknown_4
    //     0xdf0a2c: add             x16, x0, x8, lsl #2
    //     0xdf0a30: ldur            w1, [x16, #0xf]
    // 0xdf0a34: DecompressPointer r1
    //     0xdf0a34: add             x1, x1, HEAP, lsl #32
    // 0xdf0a38: stur            x1, [fp, #-0x78]
    // 0xdf0a3c: r0 = _Day()
    //     0xdf0a3c: bl              #0xdf0e70  ; Allocate_DayStub -> _Day (size=0x28)
    // 0xdf0a40: mov             x3, x0
    // 0xdf0a44: ldur            x0, [fp, #-0x60]
    // 0xdf0a48: stur            x3, [fp, #-0x90]
    // 0xdf0a4c: StoreField: r3->field_b = r0
    //     0xdf0a4c: stur            w0, [x3, #0xb]
    // 0xdf0a50: ldur            x0, [fp, #-0x30]
    // 0xdf0a54: StoreField: r3->field_f = r0
    //     0xdf0a54: stur            w0, [x3, #0xf]
    // 0xdf0a58: ldur            x0, [fp, #-0x68]
    // 0xdf0a5c: StoreField: r3->field_13 = r0
    //     0xdf0a5c: stur            w0, [x3, #0x13]
    // 0xdf0a60: ldur            x0, [fp, #-0x70]
    // 0xdf0a64: ArrayStore: r3[0] = r0  ; List_4
    //     0xdf0a64: stur            w0, [x3, #0x17]
    // 0xdf0a68: ldur            x0, [fp, #-0x80]
    // 0xdf0a6c: StoreField: r3->field_1b = r0
    //     0xdf0a6c: stur            w0, [x3, #0x1b]
    // 0xdf0a70: ldur            x0, [fp, #-0x78]
    // 0xdf0a74: StoreField: r3->field_1f = r0
    //     0xdf0a74: stur            w0, [x3, #0x1f]
    // 0xdf0a78: r4 = Instance_GregorianCalendarDelegate
    //     0xdf0a78: add             x4, PP, #0x28, lsl #12  ; [pp+0x28538] Obj!GregorianCalendarDelegate@129edd1
    //     0xdf0a7c: ldr             x4, [x4, #0x538]
    // 0xdf0a80: StoreField: r3->field_23 = r4
    //     0xdf0a80: stur            w4, [x3, #0x23]
    // 0xdf0a84: ldur            x0, [fp, #-0x88]
    // 0xdf0a88: StoreField: r3->field_7 = r0
    //     0xdf0a88: stur            w0, [x3, #7]
    // 0xdf0a8c: mov             x0, x3
    // 0xdf0a90: ldur            x2, [fp, #-0x18]
    // 0xdf0a94: r1 = Null
    //     0xdf0a94: mov             x1, NULL
    // 0xdf0a98: cmp             w2, NULL
    // 0xdf0a9c: b.eq            #0xdf0abc
    // 0xdf0aa0: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xdf0aa0: ldur            w4, [x2, #0x17]
    // 0xdf0aa4: DecompressPointer r4
    //     0xdf0aa4: add             x4, x4, HEAP, lsl #32
    // 0xdf0aa8: r8 = X0
    //     0xdf0aa8: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xdf0aac: LoadField: r9 = r4->field_7
    //     0xdf0aac: ldur            x9, [x4, #7]
    // 0xdf0ab0: r3 = Null
    //     0xdf0ab0: add             x3, PP, #0xd2, lsl #12  ; [pp+0xd28e8] Null
    //     0xdf0ab4: ldr             x3, [x3, #0x8e8]
    // 0xdf0ab8: blr             x9
    // 0xdf0abc: ldur            x0, [fp, #-0x20]
    // 0xdf0ac0: LoadField: r1 = r0->field_b
    //     0xdf0ac0: ldur            w1, [x0, #0xb]
    // 0xdf0ac4: LoadField: r2 = r0->field_f
    //     0xdf0ac4: ldur            w2, [x0, #0xf]
    // 0xdf0ac8: DecompressPointer r2
    //     0xdf0ac8: add             x2, x2, HEAP, lsl #32
    // 0xdf0acc: LoadField: r3 = r2->field_b
    //     0xdf0acc: ldur            w3, [x2, #0xb]
    // 0xdf0ad0: r2 = LoadInt32Instr(r1)
    //     0xdf0ad0: sbfx            x2, x1, #1, #0x1f
    // 0xdf0ad4: stur            x2, [fp, #-0x58]
    // 0xdf0ad8: r1 = LoadInt32Instr(r3)
    //     0xdf0ad8: sbfx            x1, x3, #1, #0x1f
    // 0xdf0adc: cmp             x2, x1
    // 0xdf0ae0: b.ne            #0xdf0aec
    // 0xdf0ae4: mov             x1, x0
    // 0xdf0ae8: r0 = _growToNextCapacity()
    //     0xdf0ae8: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xdf0aec: ldur            x2, [fp, #-0x20]
    // 0xdf0af0: ldur            x3, [fp, #-0x58]
    // 0xdf0af4: add             x0, x3, #1
    // 0xdf0af8: lsl             x1, x0, #1
    // 0xdf0afc: StoreField: r2->field_b = r1
    //     0xdf0afc: stur            w1, [x2, #0xb]
    // 0xdf0b00: LoadField: r1 = r2->field_f
    //     0xdf0b00: ldur            w1, [x2, #0xf]
    // 0xdf0b04: DecompressPointer r1
    //     0xdf0b04: add             x1, x1, HEAP, lsl #32
    // 0xdf0b08: ldur            x0, [fp, #-0x90]
    // 0xdf0b0c: ArrayStore: r1[r3] = r0  ; List_4
    //     0xdf0b0c: add             x25, x1, x3, lsl #2
    //     0xdf0b10: add             x25, x25, #0xf
    //     0xdf0b14: str             w0, [x25]
    //     0xdf0b18: tbz             w0, #0, #0xdf0b34
    //     0xdf0b1c: ldurb           w16, [x1, #-1]
    //     0xdf0b20: ldurb           w17, [x0, #-1]
    //     0xdf0b24: and             x16, x17, x16, lsr #2
    //     0xdf0b28: tst             x16, HEAP, lsr #32
    //     0xdf0b2c: b.eq            #0xdf0b34
    //     0xdf0b30: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdf0b34: ldur            x0, [fp, #-0x50]
    // 0xdf0b38: mov             x3, x2
    // 0xdf0b3c: ldur            x4, [fp, #-0x18]
    // 0xdf0b40: b               #0xdf07f4
    // 0xdf0b44: mov             x2, x3
    // 0xdf0b48: ldur            x1, [fp, #-0x10]
    // 0xdf0b4c: r0 = of()
    //     0xdf0b4c: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xdf0b50: LoadField: r1 = r0->field_2f
    //     0xdf0b50: ldur            w1, [x0, #0x2f]
    // 0xdf0b54: DecompressPointer r1
    //     0xdf0b54: add             x1, x1, HEAP, lsl #32
    // 0xdf0b58: tbnz            w1, #4, #0xdf0b6c
    // 0xdf0b5c: ldur            x0, [fp, #-0x28]
    // 0xdf0b60: tbz             w0, #4, #0xdf0b70
    // 0xdf0b64: d0 = 12.000000
    //     0xdf0b64: fmov            d0, #12.00000000
    // 0xdf0b68: b               #0xdf0b74
    // 0xdf0b6c: ldur            x0, [fp, #-0x28]
    // 0xdf0b70: d0 = 8.000000
    //     0xdf0b70: fmov            d0, #8.00000000
    // 0xdf0b74: stur            d0, [fp, #-0x98]
    // 0xdf0b78: r0 = EdgeInsets()
    //     0xdf0b78: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xdf0b7c: ldur            d0, [fp, #-0x98]
    // 0xdf0b80: stur            x0, [fp, #-8]
    // 0xdf0b84: StoreField: r0->field_7 = d0
    //     0xdf0b84: stur            d0, [x0, #7]
    // 0xdf0b88: StoreField: r0->field_f = rZR
    //     0xdf0b88: stur            xzr, [x0, #0xf]
    // 0xdf0b8c: ArrayStore: r0[0] = d0  ; List_8
    //     0xdf0b8c: stur            d0, [x0, #0x17]
    // 0xdf0b90: StoreField: r0->field_1f = rZR
    //     0xdf0b90: stur            xzr, [x0, #0x1f]
    // 0xdf0b94: ldur            x1, [fp, #-0x28]
    // 0xdf0b98: tbnz            w1, #4, #0xdf0ba4
    // 0xdf0b9c: d0 = 1.500000
    //     0xdf0b9c: fmov            d0, #1.50000000
    // 0xdf0ba0: b               #0xdf0ba8
    // 0xdf0ba4: d0 = 2.000000
    //     0xdf0ba4: fmov            d0, #2.00000000
    // 0xdf0ba8: ldur            x1, [fp, #-0x10]
    // 0xdf0bac: stur            d0, [fp, #-0x98]
    // 0xdf0bb0: r0 = _DayPickerGridDelegate()
    //     0xdf0bb0: bl              #0xdf0e64  ; Allocate_DayPickerGridDelegateStub -> _DayPickerGridDelegate (size=0xc)
    // 0xdf0bb4: mov             x1, x0
    // 0xdf0bb8: ldur            x0, [fp, #-0x10]
    // 0xdf0bbc: stur            x1, [fp, #-0x18]
    // 0xdf0bc0: StoreField: r1->field_7 = r0
    //     0xdf0bc0: stur            w0, [x1, #7]
    // 0xdf0bc4: r0 = SliverChildListDelegate()
    //     0xdf0bc4: bl              #0xdf0e58  ; AllocateSliverChildListDelegateStub -> SliverChildListDelegate (size=0x28)
    // 0xdf0bc8: stur            x0, [fp, #-0x10]
    // 0xdf0bcc: r16 = false
    //     0xdf0bcc: add             x16, NULL, #0x30  ; false
    // 0xdf0bd0: str             x16, [SP]
    // 0xdf0bd4: mov             x1, x0
    // 0xdf0bd8: ldur            x2, [fp, #-0x20]
    // 0xdf0bdc: r4 = const [0, 0x3, 0x1, 0x2, addRepaintBoundaries, 0x2, null]
    //     0xdf0bdc: add             x4, PP, #0x19, lsl #12  ; [pp+0x19490] List(7) [0, 0x3, 0x1, 0x2, "addRepaintBoundaries", 0x2, Null]
    //     0xdf0be0: ldr             x4, [x4, #0x490]
    // 0xdf0be4: r0 = SliverChildListDelegate()
    //     0xdf0be4: bl              #0xdf0d30  ; [package:flutter/src/widgets/scroll_delegate.dart] SliverChildListDelegate::SliverChildListDelegate
    // 0xdf0be8: r0 = GridView()
    //     0xdf0be8: bl              #0xdf0d24  ; AllocateGridViewStub -> GridView (size=0x64)
    // 0xdf0bec: mov             x1, x0
    // 0xdf0bf0: ldur            x0, [fp, #-0x18]
    // 0xdf0bf4: StoreField: r1->field_5b = r0
    //     0xdf0bf4: stur            w0, [x1, #0x5b]
    // 0xdf0bf8: ldur            x0, [fp, #-0x10]
    // 0xdf0bfc: StoreField: r1->field_5f = r0
    //     0xdf0bfc: stur            w0, [x1, #0x5f]
    // 0xdf0c00: r0 = Instance_Axis
    //     0xdf0c00: ldr             x0, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xdf0c04: StoreField: r1->field_b = r0
    //     0xdf0c04: stur            w0, [x1, #0xb]
    // 0xdf0c08: r0 = false
    //     0xdf0c08: add             x0, NULL, #0x30  ; false
    // 0xdf0c0c: StoreField: r1->field_f = r0
    //     0xdf0c0c: stur            w0, [x1, #0xf]
    // 0xdf0c10: StoreField: r1->field_23 = r0
    //     0xdf0c10: stur            w0, [x1, #0x23]
    // 0xdf0c14: StoreField: r1->field_2b = rZR
    //     0xdf0c14: stur            xzr, [x1, #0x2b]
    // 0xdf0c18: r0 = Instance_SliverPaintOrder
    //     0xdf0c18: add             x0, PP, #0x15, lsl #12  ; [pp+0x15c00] Obj!SliverPaintOrder@12c4141
    //     0xdf0c1c: ldr             x0, [x0, #0xc00]
    // 0xdf0c20: StoreField: r1->field_3f = r0
    //     0xdf0c20: stur            w0, [x1, #0x3f]
    // 0xdf0c24: r0 = Instance_DragStartBehavior
    //     0xdf0c24: ldr             x0, [PP, #0x5360]  ; [pp+0x5360] Obj!DragStartBehavior@12c5c61
    // 0xdf0c28: StoreField: r1->field_43 = r0
    //     0xdf0c28: stur            w0, [x1, #0x43]
    // 0xdf0c2c: r0 = Instance_Clip
    //     0xdf0c2c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xdf0c30: ldr             x0, [x0, #0x850]
    // 0xdf0c34: StoreField: r1->field_4f = r0
    //     0xdf0c34: stur            w0, [x1, #0x4f]
    // 0xdf0c38: r0 = Instance_HitTestBehavior
    //     0xdf0c38: add             x0, PP, #0x15, lsl #12  ; [pp+0x155c0] Obj!HitTestBehavior@12c43c1
    //     0xdf0c3c: ldr             x0, [x0, #0x5c0]
    // 0xdf0c40: StoreField: r1->field_53 = r0
    //     0xdf0c40: stur            w0, [x1, #0x53]
    // 0xdf0c44: r0 = Instance_ClampingScrollPhysics
    //     0xdf0c44: add             x0, PP, #0x8c, lsl #12  ; [pp+0x8c758] Obj!ClampingScrollPhysics@129b591
    //     0xdf0c48: ldr             x0, [x0, #0x758]
    // 0xdf0c4c: StoreField: r1->field_1b = r0
    //     0xdf0c4c: stur            w0, [x1, #0x1b]
    // 0xdf0c50: ldur            d0, [fp, #-0x98]
    // 0xdf0c54: r0 = inline_Allocate_Double()
    //     0xdf0c54: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xdf0c58: add             x0, x0, #0x10
    //     0xdf0c5c: cmp             x2, x0
    //     0xdf0c60: b.ls            #0xdf0d0c
    //     0xdf0c64: str             x0, [THR, #0x60]  ; THR::top
    //     0xdf0c68: sub             x0, x0, #0xf
    //     0xdf0c6c: mov             x2, #0xe19c
    //     0xdf0c70: movk            x2, #3, lsl #16
    //     0xdf0c74: stur            x2, [x0, #-1]
    // 0xdf0c78: dmb             ishst
    // 0xdf0c7c: StoreField: r0->field_7 = d0
    //     0xdf0c7c: stur            d0, [x0, #7]
    // 0xdf0c80: str             x0, [SP]
    // 0xdf0c84: r4 = const [0, 0x2, 0x1, 0x1, maxScaleFactor, 0x1, null]
    //     0xdf0c84: add             x4, PP, #0x90, lsl #12  ; [pp+0x90d70] List(7) [0, 0x2, 0x1, 0x1, "maxScaleFactor", 0x1, Null]
    //     0xdf0c88: ldr             x4, [x4, #0xd70]
    // 0xdf0c8c: r0 = withClampedTextScaling()
    //     0xdf0c8c: bl              #0xd16294  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::withClampedTextScaling
    // 0xdf0c90: stur            x0, [fp, #-0x10]
    // 0xdf0c94: r0 = Padding()
    //     0xdf0c94: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xdf0c98: ldur            x1, [fp, #-8]
    // 0xdf0c9c: StoreField: r0->field_f = r1
    //     0xdf0c9c: stur            w1, [x0, #0xf]
    // 0xdf0ca0: ldur            x1, [fp, #-0x10]
    // 0xdf0ca4: StoreField: r0->field_b = r1
    //     0xdf0ca4: stur            w1, [x0, #0xb]
    // 0xdf0ca8: LeaveFrame
    //     0xdf0ca8: mov             SP, fp
    //     0xdf0cac: ldp             fp, lr, [SP], #0x10
    // 0xdf0cb0: ret
    //     0xdf0cb0: ret             
    // 0xdf0cb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf0cb4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf0cb8: b               #0xdf04c4
    // 0xdf0cbc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf0cbc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf0cc0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdf0cc0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdf0cc4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf0cc4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf0cc8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdf0cc8: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdf0ccc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf0ccc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf0cd0: add             x6, x6, x1
    // 0xdf0cd4: b               #0xdf0738
    // 0xdf0cd8: add             x6, x6, x1
    // 0xdf0cdc: b               #0xdf0750
    // 0xdf0ce0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdf0ce0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdf0ce4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf0ce4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf0ce8: b               #0xdf0808
    // 0xdf0cec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf0cec: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf0cf0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf0cf0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf0cf4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf0cf4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf0cf8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf0cf8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf0cfc: r9 = _dayFocusNodes
    //     0xdf0cfc: add             x9, PP, #0xd2, lsl #12  ; [pp+0xd28f8] Field <_DayPickerState@54260463._dayFocusNodes@54260463>: late (offset: 0x14)
    //     0xdf0d00: ldr             x9, [x9, #0x8f8]
    // 0xdf0d04: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdf0d04: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdf0d08: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdf0d08: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdf0d0c: SaveReg d0
    //     0xdf0d0c: str             q0, [SP, #-0x10]!
    // 0xdf0d10: SaveReg r1
    //     0xdf0d10: str             x1, [SP, #-8]!
    // 0xdf0d14: r0 = AllocateDouble()
    //     0xdf0d14: bl              #0x13df878  ; AllocateDoubleStub
    // 0xdf0d18: RestoreReg r1
    //     0xdf0d18: ldr             x1, [SP], #8
    // 0xdf0d1c: RestoreReg d0
    //     0xdf0d1c: ldr             q0, [SP], #0x10
    // 0xdf0d20: b               #0xdf0c7c
  }
  _ _dayHeaders(/* No info */) {
    // ** addr: 0xdf0ea0, size: 0x204
    // 0xdf0ea0: EnterFrame
    //     0xdf0ea0: stp             fp, lr, [SP, #-0x10]!
    //     0xdf0ea4: mov             fp, SP
    // 0xdf0ea8: AllocStack(0x38)
    //     0xdf0ea8: sub             SP, SP, #0x38
    // 0xdf0eac: SetupParameters(dynamic _ /* r2 => r3, fp-0x8 */, dynamic _ /* r3 => r0, fp-0x10 */)
    //     0xdf0eac: mov             x0, x3
    //     0xdf0eb0: stur            x3, [fp, #-0x10]
    //     0xdf0eb4: mov             x3, x2
    //     0xdf0eb8: stur            x2, [fp, #-8]
    // 0xdf0ebc: CheckStackOverflow
    //     0xdf0ebc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf0ec0: cmp             SP, x16
    //     0xdf0ec4: b.ls            #0xdf1088
    // 0xdf0ec8: r1 = <Widget>
    //     0xdf0ec8: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xdf0ecc: r2 = 0
    //     0xdf0ecc: mov             x2, #0
    // 0xdf0ed0: r0 = _GrowableList()
    //     0xdf0ed0: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xdf0ed4: mov             x3, x0
    // 0xdf0ed8: ldur            x2, [fp, #-0x10]
    // 0xdf0edc: stur            x3, [fp, #-0x18]
    // 0xdf0ee0: r0 = LoadClassIdInstr(r2)
    //     0xdf0ee0: ldur            x0, [x2, #-1]
    //     0xdf0ee4: ubfx            x0, x0, #0xc, #0x14
    // 0xdf0ee8: mov             x1, x2
    // 0xdf0eec: r0 = GDT[cid_x0 + 0x15e3b]()
    //     0xdf0eec: mov             x17, #0x5e3b
    //     0xdf0ef0: movk            x17, #1, lsl #16
    //     0xdf0ef4: add             lr, x0, x17
    //     0xdf0ef8: ldr             lr, [x21, lr, lsl #3]
    //     0xdf0efc: blr             lr
    // 0xdf0f00: mov             x5, x0
    // 0xdf0f04: ldur            x3, [fp, #-0x18]
    // 0xdf0f08: ldur            x4, [fp, #-8]
    // 0xdf0f0c: ldur            x2, [fp, #-0x10]
    // 0xdf0f10: stur            x5, [fp, #-0x20]
    // 0xdf0f14: CheckStackOverflow
    //     0xdf0f14: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf0f18: cmp             SP, x16
    //     0xdf0f1c: b.ls            #0xdf1090
    // 0xdf0f20: LoadField: r0 = r3->field_b
    //     0xdf0f20: ldur            w0, [x3, #0xb]
    // 0xdf0f24: r1 = LoadInt32Instr(r0)
    //     0xdf0f24: sbfx            x1, x0, #1, #0x1f
    // 0xdf0f28: cmp             x1, #7
    // 0xdf0f2c: b.ge            #0xdf1074
    // 0xdf0f30: r0 = LoadClassIdInstr(r2)
    //     0xdf0f30: ldur            x0, [x2, #-1]
    //     0xdf0f34: ubfx            x0, x0, #0xc, #0x14
    // 0xdf0f38: mov             x1, x2
    // 0xdf0f3c: r0 = GDT[cid_x0 + 0x170ae]()
    //     0xdf0f3c: mov             x17, #0x70ae
    //     0xdf0f40: movk            x17, #1, lsl #16
    //     0xdf0f44: add             lr, x0, x17
    //     0xdf0f48: ldr             lr, [x21, lr, lsl #3]
    //     0xdf0f4c: blr             lr
    // 0xdf0f50: mov             x2, x0
    // 0xdf0f54: LoadField: r0 = r2->field_b
    //     0xdf0f54: ldur            w0, [x2, #0xb]
    // 0xdf0f58: r1 = LoadInt32Instr(r0)
    //     0xdf0f58: sbfx            x1, x0, #1, #0x1f
    // 0xdf0f5c: mov             x0, x1
    // 0xdf0f60: ldur            x1, [fp, #-0x20]
    // 0xdf0f64: cmp             x1, x0
    // 0xdf0f68: b.hs            #0xdf1098
    // 0xdf0f6c: ldur            x0, [fp, #-0x20]
    // 0xdf0f70: ArrayLoad: r1 = r2[r0]  ; Unknown_4
    //     0xdf0f70: add             x16, x2, x0, lsl #2
    //     0xdf0f74: ldur            w1, [x16, #0xf]
    // 0xdf0f78: DecompressPointer r1
    //     0xdf0f78: add             x1, x1, HEAP, lsl #32
    // 0xdf0f7c: stur            x1, [fp, #-0x28]
    // 0xdf0f80: r0 = Text()
    //     0xdf0f80: bl              #0x8a70a4  ; AllocateTextStub -> Text (size=0x50)
    // 0xdf0f84: mov             x1, x0
    // 0xdf0f88: ldur            x0, [fp, #-0x28]
    // 0xdf0f8c: stur            x1, [fp, #-0x30]
    // 0xdf0f90: StoreField: r1->field_b = r0
    //     0xdf0f90: stur            w0, [x1, #0xb]
    // 0xdf0f94: ldur            x0, [fp, #-8]
    // 0xdf0f98: StoreField: r1->field_13 = r0
    //     0xdf0f98: stur            w0, [x1, #0x13]
    // 0xdf0f9c: r0 = Center()
    //     0xdf0f9c: bl              #0xd0c898  ; AllocateCenterStub -> Center (size=0x1c)
    // 0xdf0fa0: mov             x1, x0
    // 0xdf0fa4: r0 = Instance_Alignment
    //     0xdf0fa4: add             x0, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xdf0fa8: ldr             x0, [x0, #0xb80]
    // 0xdf0fac: stur            x1, [fp, #-0x28]
    // 0xdf0fb0: StoreField: r1->field_f = r0
    //     0xdf0fb0: stur            w0, [x1, #0xf]
    // 0xdf0fb4: ldur            x2, [fp, #-0x30]
    // 0xdf0fb8: StoreField: r1->field_b = r2
    //     0xdf0fb8: stur            w2, [x1, #0xb]
    // 0xdf0fbc: r0 = ExcludeSemantics()
    //     0xdf0fbc: bl              #0x86a6ac  ; AllocateExcludeSemanticsStub -> ExcludeSemantics (size=0x14)
    // 0xdf0fc0: mov             x2, x0
    // 0xdf0fc4: r0 = true
    //     0xdf0fc4: add             x0, NULL, #0x20  ; true
    // 0xdf0fc8: stur            x2, [fp, #-0x30]
    // 0xdf0fcc: StoreField: r2->field_f = r0
    //     0xdf0fcc: stur            w0, [x2, #0xf]
    // 0xdf0fd0: ldur            x1, [fp, #-0x28]
    // 0xdf0fd4: StoreField: r2->field_b = r1
    //     0xdf0fd4: stur            w1, [x2, #0xb]
    // 0xdf0fd8: ldur            x3, [fp, #-0x18]
    // 0xdf0fdc: LoadField: r1 = r3->field_b
    //     0xdf0fdc: ldur            w1, [x3, #0xb]
    // 0xdf0fe0: LoadField: r4 = r3->field_f
    //     0xdf0fe0: ldur            w4, [x3, #0xf]
    // 0xdf0fe4: DecompressPointer r4
    //     0xdf0fe4: add             x4, x4, HEAP, lsl #32
    // 0xdf0fe8: LoadField: r5 = r4->field_b
    //     0xdf0fe8: ldur            w5, [x4, #0xb]
    // 0xdf0fec: r4 = LoadInt32Instr(r1)
    //     0xdf0fec: sbfx            x4, x1, #1, #0x1f
    // 0xdf0ff0: stur            x4, [fp, #-0x38]
    // 0xdf0ff4: r1 = LoadInt32Instr(r5)
    //     0xdf0ff4: sbfx            x1, x5, #1, #0x1f
    // 0xdf0ff8: cmp             x4, x1
    // 0xdf0ffc: b.ne            #0xdf1008
    // 0xdf1000: mov             x1, x3
    // 0xdf1004: r0 = _growToNextCapacity()
    //     0xdf1004: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xdf1008: ldur            x2, [fp, #-0x18]
    // 0xdf100c: ldur            x4, [fp, #-0x20]
    // 0xdf1010: ldur            x3, [fp, #-0x38]
    // 0xdf1014: r6 = 7
    //     0xdf1014: mov             x6, #7
    // 0xdf1018: add             x5, x3, #1
    // 0xdf101c: lsl             x7, x5, #1
    // 0xdf1020: StoreField: r2->field_b = r7
    //     0xdf1020: stur            w7, [x2, #0xb]
    // 0xdf1024: LoadField: r1 = r2->field_f
    //     0xdf1024: ldur            w1, [x2, #0xf]
    // 0xdf1028: DecompressPointer r1
    //     0xdf1028: add             x1, x1, HEAP, lsl #32
    // 0xdf102c: ldur            x0, [fp, #-0x30]
    // 0xdf1030: ArrayStore: r1[r3] = r0  ; List_4
    //     0xdf1030: add             x25, x1, x3, lsl #2
    //     0xdf1034: add             x25, x25, #0xf
    //     0xdf1038: str             w0, [x25]
    //     0xdf103c: tbz             w0, #0, #0xdf1058
    //     0xdf1040: ldurb           w16, [x1, #-1]
    //     0xdf1044: ldurb           w17, [x0, #-1]
    //     0xdf1048: and             x16, x17, x16, lsr #2
    //     0xdf104c: tst             x16, HEAP, lsr #32
    //     0xdf1050: b.eq            #0xdf1058
    //     0xdf1054: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdf1058: add             x1, x4, #1
    // 0xdf105c: sdiv            x3, x1, x6
    // 0xdf1060: msub            x5, x3, x6, x1
    // 0xdf1064: cmp             x5, xzr
    // 0xdf1068: b.lt            #0xdf109c
    // 0xdf106c: mov             x3, x2
    // 0xdf1070: b               #0xdf0f08
    // 0xdf1074: mov             x2, x3
    // 0xdf1078: mov             x0, x2
    // 0xdf107c: LeaveFrame
    //     0xdf107c: mov             SP, fp
    //     0xdf1080: ldp             fp, lr, [SP], #0x10
    // 0xdf1084: ret
    //     0xdf1084: ret             
    // 0xdf1088: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf1088: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf108c: b               #0xdf0ec8
    // 0xdf1090: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf1090: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf1094: b               #0xdf0f20
    // 0xdf1098: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdf1098: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdf109c: add             x5, x5, x6
    // 0xdf10a0: b               #0xdf106c
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0xef4310, size: 0x134
    // 0xef4310: EnterFrame
    //     0xef4310: stp             fp, lr, [SP, #-0x10]!
    //     0xef4314: mov             fp, SP
    // 0xef4318: AllocStack(0x18)
    //     0xef4318: sub             SP, SP, #0x18
    // 0xef431c: SetupParameters(_DayPickerState this /* r1 => r0, fp-0x8 */)
    //     0xef431c: mov             x0, x1
    //     0xef4320: stur            x1, [fp, #-8]
    // 0xef4324: CheckStackOverflow
    //     0xef4324: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef4328: cmp             SP, x16
    //     0xef432c: b.ls            #0xef4420
    // 0xef4330: LoadField: r1 = r0->field_f
    //     0xef4330: ldur            w1, [x0, #0xf]
    // 0xef4334: DecompressPointer r1
    //     0xef4334: add             x1, x1, HEAP, lsl #32
    // 0xef4338: cmp             w1, NULL
    // 0xef433c: b.eq            #0xef4428
    // 0xef4340: r0 = maybeOf()
    //     0xef4340: bl              #0xef4444  ; [package:flutter/src/material/calendar_date_picker.dart] _FocusedDate::maybeOf
    // 0xef4344: stur            x0, [fp, #-0x10]
    // 0xef4348: cmp             w0, NULL
    // 0xef434c: b.eq            #0xef4410
    // 0xef4350: ldur            x4, [fp, #-8]
    // 0xef4354: LoadField: r1 = r4->field_b
    //     0xef4354: ldur            w1, [x4, #0xb]
    // 0xef4358: DecompressPointer r1
    //     0xef4358: add             x1, x1, HEAP, lsl #32
    // 0xef435c: cmp             w1, NULL
    // 0xef4360: b.eq            #0xef442c
    // 0xef4364: LoadField: r2 = r1->field_1f
    //     0xef4364: ldur            w2, [x1, #0x1f]
    // 0xef4368: DecompressPointer r2
    //     0xef4368: add             x2, x2, HEAP, lsl #32
    // 0xef436c: mov             x3, x0
    // 0xef4370: r1 = Instance_GregorianCalendarDelegate
    //     0xef4370: add             x1, PP, #0x28, lsl #12  ; [pp+0x28538] Obj!GregorianCalendarDelegate@129edd1
    //     0xef4374: ldr             x1, [x1, #0x538]
    // 0xef4378: r0 = isSameMonth()
    //     0xef4378: bl              #0xdef958  ; [package:flutter/src/material/date.dart] CalendarDelegate::isSameMonth
    // 0xef437c: tbnz            w0, #4, #0xef4410
    // 0xef4380: ldur            x0, [fp, #-8]
    // 0xef4384: LoadField: r2 = r0->field_13
    //     0xef4384: ldur            w2, [x0, #0x13]
    // 0xef4388: DecompressPointer r2
    //     0xef4388: add             x2, x2, HEAP, lsl #32
    // 0xef438c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xef4390: cmp             w2, w16
    // 0xef4394: b.eq            #0xef4430
    // 0xef4398: ldur            x1, [fp, #-0x10]
    // 0xef439c: stur            x2, [fp, #-0x18]
    // 0xef43a0: r0 = _parts()
    //     0xef43a0: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xef43a4: mov             x2, x0
    // 0xef43a8: LoadField: r0 = r2->field_b
    //     0xef43a8: ldur            w0, [x2, #0xb]
    // 0xef43ac: r1 = LoadInt32Instr(r0)
    //     0xef43ac: sbfx            x1, x0, #1, #0x1f
    // 0xef43b0: mov             x0, x1
    // 0xef43b4: r1 = 5
    //     0xef43b4: mov             x1, #5
    // 0xef43b8: cmp             x1, x0
    // 0xef43bc: b.hs            #0xef443c
    // 0xef43c0: LoadField: r0 = r2->field_23
    //     0xef43c0: ldur            w0, [x2, #0x23]
    // 0xef43c4: DecompressPointer r0
    //     0xef43c4: add             x0, x0, HEAP, lsl #32
    // 0xef43c8: r1 = LoadInt32Instr(r0)
    //     0xef43c8: sbfx            x1, x0, #1, #0x1f
    //     0xef43cc: tbz             w0, #0, #0xef43d4
    //     0xef43d0: ldur            x1, [x0, #7]
    // 0xef43d4: sub             x2, x1, #1
    // 0xef43d8: ldur            x3, [fp, #-0x18]
    // 0xef43dc: LoadField: r0 = r3->field_b
    //     0xef43dc: ldur            w0, [x3, #0xb]
    // 0xef43e0: r1 = LoadInt32Instr(r0)
    //     0xef43e0: sbfx            x1, x0, #1, #0x1f
    // 0xef43e4: mov             x0, x1
    // 0xef43e8: mov             x1, x2
    // 0xef43ec: cmp             x1, x0
    // 0xef43f0: b.hs            #0xef4440
    // 0xef43f4: LoadField: r0 = r3->field_f
    //     0xef43f4: ldur            w0, [x3, #0xf]
    // 0xef43f8: DecompressPointer r0
    //     0xef43f8: add             x0, x0, HEAP, lsl #32
    // 0xef43fc: ArrayLoad: r1 = r0[r2]  ; Unknown_4
    //     0xef43fc: add             x16, x0, x2, lsl #2
    //     0xef4400: ldur            w1, [x16, #0xf]
    // 0xef4404: DecompressPointer r1
    //     0xef4404: add             x1, x1, HEAP, lsl #32
    // 0xef4408: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xef4408: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xef440c: r0 = requestFocus()
    //     0xef440c: bl              #0x83e7b8  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::requestFocus
    // 0xef4410: r0 = Null
    //     0xef4410: mov             x0, NULL
    // 0xef4414: LeaveFrame
    //     0xef4414: mov             SP, fp
    //     0xef4418: ldp             fp, lr, [SP], #0x10
    // 0xef441c: ret
    //     0xef441c: ret             
    // 0xef4420: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef4420: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef4424: b               #0xef4330
    // 0xef4428: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef4428: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef442c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef442c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef4430: r9 = _dayFocusNodes
    //     0xef4430: add             x9, PP, #0xd2, lsl #12  ; [pp+0xd28f8] Field <_DayPickerState@54260463._dayFocusNodes@54260463>: late (offset: 0x14)
    //     0xef4434: ldr             x9, [x9, #0x8f8]
    // 0xef4438: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xef4438: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xef443c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xef443c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xef4440: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xef4440: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0xf90534, size: 0x2b0
    // 0xf90534: EnterFrame
    //     0xf90534: stp             fp, lr, [SP, #-0x10]!
    //     0xf90538: mov             fp, SP
    // 0xf9053c: AllocStack(0x40)
    //     0xf9053c: sub             SP, SP, #0x40
    // 0xf90540: SetupParameters(_DayPickerState this /* r1 => r0, fp-0x8 */)
    //     0xf90540: mov             x0, x1
    //     0xf90544: stur            x1, [fp, #-8]
    // 0xf90548: CheckStackOverflow
    //     0xf90548: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf9054c: cmp             SP, x16
    //     0xf90550: b.ls            #0xf907ac
    // 0xf90554: LoadField: r1 = r0->field_b
    //     0xf90554: ldur            w1, [x0, #0xb]
    // 0xf90558: DecompressPointer r1
    //     0xf90558: add             x1, x1, HEAP, lsl #32
    // 0xf9055c: cmp             w1, NULL
    // 0xf90560: b.eq            #0xf907b4
    // 0xf90564: LoadField: r2 = r1->field_1f
    //     0xf90564: ldur            w2, [x1, #0x1f]
    // 0xf90568: DecompressPointer r2
    //     0xf90568: add             x2, x2, HEAP, lsl #32
    // 0xf9056c: mov             x1, x2
    // 0xf90570: r0 = _parts()
    //     0xf90570: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xf90574: mov             x2, x0
    // 0xf90578: LoadField: r0 = r2->field_b
    //     0xf90578: ldur            w0, [x2, #0xb]
    // 0xf9057c: r1 = LoadInt32Instr(r0)
    //     0xf9057c: sbfx            x1, x0, #1, #0x1f
    // 0xf90580: mov             x0, x1
    // 0xf90584: r1 = 8
    //     0xf90584: mov             x1, #8
    // 0xf90588: cmp             x1, x0
    // 0xf9058c: b.hs            #0xf907b8
    // 0xf90590: LoadField: r0 = r2->field_2f
    //     0xf90590: ldur            w0, [x2, #0x2f]
    // 0xf90594: DecompressPointer r0
    //     0xf90594: add             x0, x0, HEAP, lsl #32
    // 0xf90598: ldur            x2, [fp, #-8]
    // 0xf9059c: stur            x0, [fp, #-0x10]
    // 0xf905a0: LoadField: r1 = r2->field_b
    //     0xf905a0: ldur            w1, [x2, #0xb]
    // 0xf905a4: DecompressPointer r1
    //     0xf905a4: add             x1, x1, HEAP, lsl #32
    // 0xf905a8: cmp             w1, NULL
    // 0xf905ac: b.eq            #0xf907bc
    // 0xf905b0: LoadField: r3 = r1->field_1f
    //     0xf905b0: ldur            w3, [x1, #0x1f]
    // 0xf905b4: DecompressPointer r3
    //     0xf905b4: add             x3, x3, HEAP, lsl #32
    // 0xf905b8: mov             x1, x3
    // 0xf905bc: r0 = _parts()
    //     0xf905bc: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xf905c0: mov             x2, x0
    // 0xf905c4: LoadField: r0 = r2->field_b
    //     0xf905c4: ldur            w0, [x2, #0xb]
    // 0xf905c8: r1 = LoadInt32Instr(r0)
    //     0xf905c8: sbfx            x1, x0, #1, #0x1f
    // 0xf905cc: mov             x0, x1
    // 0xf905d0: r1 = 7
    //     0xf905d0: mov             x1, #7
    // 0xf905d4: cmp             x1, x0
    // 0xf905d8: b.hs            #0xf907c0
    // 0xf905dc: LoadField: r0 = r2->field_2b
    //     0xf905dc: ldur            w0, [x2, #0x2b]
    // 0xf905e0: DecompressPointer r0
    //     0xf905e0: add             x0, x0, HEAP, lsl #32
    // 0xf905e4: r1 = LoadInt32Instr(r0)
    //     0xf905e4: sbfx            x1, x0, #1, #0x1f
    //     0xf905e8: tbz             w0, #0, #0xf905f0
    //     0xf905ec: ldur            x1, [x0, #7]
    // 0xf905f0: cmp             x1, #2
    // 0xf905f4: b.ne            #0xf90654
    // 0xf905f8: ldur            x0, [fp, #-0x10]
    // 0xf905fc: r1 = LoadInt32Instr(r0)
    //     0xf905fc: sbfx            x1, x0, #1, #0x1f
    //     0xf90600: tbz             w0, #0, #0xf90608
    //     0xf90604: ldur            x1, [x0, #7]
    // 0xf90608: tst             x1, #3
    // 0xf9060c: b.ne            #0xf90628
    // 0xf90610: r0 = 100
    //     0xf90610: mov             x0, #0x64
    // 0xf90614: sdiv            x3, x1, x0
    // 0xf90618: msub            x2, x3, x0, x1
    // 0xf9061c: cmp             x2, xzr
    // 0xf90620: b.lt            #0xf907c4
    // 0xf90624: cbnz            x2, #0xf90640
    // 0xf90628: r0 = 400
    //     0xf90628: mov             x0, #0x190
    // 0xf9062c: sdiv            x3, x1, x0
    // 0xf90630: msub            x2, x3, x0, x1
    // 0xf90634: cmp             x2, xzr
    // 0xf90638: b.lt            #0xf907cc
    // 0xf9063c: cbnz            x2, #0xf90648
    // 0xf90640: r0 = 29
    //     0xf90640: mov             x0, #0x1d
    // 0xf90644: b               #0xf9064c
    // 0xf90648: r0 = 28
    //     0xf90648: mov             x0, #0x1c
    // 0xf9064c: mov             x2, x0
    // 0xf90650: b               #0xf9068c
    // 0xf90654: r2 = const [0x1f, 0xffffffffffffffff, 0x1f, 0x1e, 0x1f, 0x1e, 0x1f, 0x1f, 0x1e, 0x1f, 0x1e, 0x1f]
    //     0xf90654: add             x2, PP, #0xa3, lsl #12  ; [pp+0xa3fb0] List<int>(12)
    //     0xf90658: ldr             x2, [x2, #0xfb0]
    // 0xf9065c: sub             x3, x1, #1
    // 0xf90660: mov             x1, x3
    // 0xf90664: r0 = 12
    //     0xf90664: mov             x0, #0xc
    // 0xf90668: cmp             x1, x0
    // 0xf9066c: b.hs            #0xf907d4
    // 0xf90670: ArrayLoad: r0 = r2[r3]  ; Unknown_4
    //     0xf90670: add             x16, x2, x3, lsl #2
    //     0xf90674: ldur            w0, [x16, #0xf]
    // 0xf90678: DecompressPointer r0
    //     0xf90678: add             x0, x0, HEAP, lsl #32
    // 0xf9067c: r1 = LoadInt32Instr(r0)
    //     0xf9067c: sbfx            x1, x0, #1, #0x1f
    //     0xf90680: tbz             w0, #0, #0xf90688
    //     0xf90684: ldur            x1, [x0, #7]
    // 0xf90688: mov             x2, x1
    // 0xf9068c: r1 = <FocusNode>
    //     0xf9068c: ldr             x1, [PP, #0x1cd0]  ; [pp+0x1cd0] TypeArguments: <FocusNode>
    // 0xf90690: r0 = _GrowableList()
    //     0xf90690: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xf90694: stur            x0, [fp, #-0x10]
    // 0xf90698: r3 = 0
    //     0xf90698: mov             x3, #0
    // 0xf9069c: stur            x3, [fp, #-0x18]
    // 0xf906a0: CheckStackOverflow
    //     0xf906a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf906a4: cmp             SP, x16
    //     0xf906a8: b.ls            #0xf907d8
    // 0xf906ac: LoadField: r1 = r0->field_b
    //     0xf906ac: ldur            w1, [x0, #0xb]
    // 0xf906b0: r2 = LoadInt32Instr(r1)
    //     0xf906b0: sbfx            x2, x1, #1, #0x1f
    // 0xf906b4: cmp             x3, x2
    // 0xf906b8: b.ge            #0xf90774
    // 0xf906bc: r1 = Null
    //     0xf906bc: mov             x1, NULL
    // 0xf906c0: r2 = 4
    //     0xf906c0: mov             x2, #4
    // 0xf906c4: r0 = AllocateArray()
    //     0xf906c4: bl              #0x13df928  ; AllocateArrayStub
    // 0xf906c8: r16 = "Day "
    //     0xf906c8: add             x16, PP, #0xd2, lsl #12  ; [pp+0xd2908] "Day "
    //     0xf906cc: ldr             x16, [x16, #0x908]
    // 0xf906d0: StoreField: r0->field_f = r16
    //     0xf906d0: stur            w16, [x0, #0xf]
    // 0xf906d4: ldur            x1, [fp, #-0x18]
    // 0xf906d8: add             x3, x1, #1
    // 0xf906dc: stur            x3, [fp, #-0x20]
    // 0xf906e0: lsl             x2, x3, #1
    // 0xf906e4: StoreField: r0->field_13 = r2
    //     0xf906e4: stur            w2, [x0, #0x13]
    // 0xf906e8: str             x0, [SP]
    // 0xf906ec: r0 = _interpolate()
    //     0xf906ec: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xf906f0: stur            x0, [fp, #-0x28]
    // 0xf906f4: r0 = FocusNode()
    //     0xf906f4: bl              #0xd4952c  ; AllocateFocusNodeStub -> FocusNode (size=0x68)
    // 0xf906f8: stur            x0, [fp, #-0x30]
    // 0xf906fc: r16 = true
    //     0xf906fc: add             x16, NULL, #0x20  ; true
    // 0xf90700: ldur            lr, [fp, #-0x28]
    // 0xf90704: stp             lr, x16, [SP]
    // 0xf90708: mov             x1, x0
    // 0xf9070c: r4 = const [0, 0x3, 0x2, 0x1, debugLabel, 0x2, skipTraversal, 0x1, null]
    //     0xf9070c: add             x4, PP, #0xd2, lsl #12  ; [pp+0xd2910] List(9) [0, 0x3, 0x2, 0x1, "debugLabel", 0x2, "skipTraversal", 0x1, Null]
    //     0xf90710: ldr             x4, [x4, #0x910]
    // 0xf90714: r0 = FocusNode()
    //     0xf90714: bl              #0x83cf84  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::FocusNode
    // 0xf90718: ldur            x2, [fp, #-0x10]
    // 0xf9071c: LoadField: r3 = r2->field_b
    //     0xf9071c: ldur            w3, [x2, #0xb]
    // 0xf90720: r0 = LoadInt32Instr(r3)
    //     0xf90720: sbfx            x0, x3, #1, #0x1f
    // 0xf90724: ldur            x1, [fp, #-0x18]
    // 0xf90728: cmp             x1, x0
    // 0xf9072c: b.hs            #0xf907e0
    // 0xf90730: LoadField: r1 = r2->field_f
    //     0xf90730: ldur            w1, [x2, #0xf]
    // 0xf90734: DecompressPointer r1
    //     0xf90734: add             x1, x1, HEAP, lsl #32
    // 0xf90738: ldur            x0, [fp, #-0x30]
    // 0xf9073c: ldur            x3, [fp, #-0x18]
    // 0xf90740: ArrayStore: r1[r3] = r0  ; List_4
    //     0xf90740: add             x25, x1, x3, lsl #2
    //     0xf90744: add             x25, x25, #0xf
    //     0xf90748: str             w0, [x25]
    //     0xf9074c: tbz             w0, #0, #0xf90768
    //     0xf90750: ldurb           w16, [x1, #-1]
    //     0xf90754: ldurb           w17, [x0, #-1]
    //     0xf90758: and             x16, x17, x16, lsr #2
    //     0xf9075c: tst             x16, HEAP, lsr #32
    //     0xf90760: b.eq            #0xf90768
    //     0xf90764: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xf90768: ldur            x3, [fp, #-0x20]
    // 0xf9076c: mov             x0, x2
    // 0xf90770: b               #0xf9069c
    // 0xf90774: ldur            x1, [fp, #-8]
    // 0xf90778: mov             x2, x0
    // 0xf9077c: mov             x0, x2
    // 0xf90780: StoreField: r1->field_13 = r0
    //     0xf90780: stur            w0, [x1, #0x13]
    //     0xf90784: ldurb           w16, [x1, #-1]
    //     0xf90788: ldurb           w17, [x0, #-1]
    //     0xf9078c: and             x16, x17, x16, lsr #2
    //     0xf90790: tst             x16, HEAP, lsr #32
    //     0xf90794: b.eq            #0xf9079c
    //     0xf90798: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf9079c: r0 = Null
    //     0xf9079c: mov             x0, NULL
    // 0xf907a0: LeaveFrame
    //     0xf907a0: mov             SP, fp
    //     0xf907a4: ldp             fp, lr, [SP], #0x10
    // 0xf907a8: ret
    //     0xf907a8: ret             
    // 0xf907ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf907ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf907b0: b               #0xf90554
    // 0xf907b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf907b4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf907b8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xf907b8: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xf907bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf907bc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf907c0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xf907c0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xf907c4: add             x2, x2, x0
    // 0xf907c8: b               #0xf90624
    // 0xf907cc: add             x2, x2, x0
    // 0xf907d0: b               #0xf9063c
    // 0xf907d4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xf907d4: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xf907d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf907d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf907dc: b               #0xf906ac
    // 0xf907e0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xf907e0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10e594c, size: 0xf8
    // 0x10e594c: EnterFrame
    //     0x10e594c: stp             fp, lr, [SP, #-0x10]!
    //     0x10e5950: mov             fp, SP
    // 0x10e5954: AllocStack(0x20)
    //     0x10e5954: sub             SP, SP, #0x20
    // 0x10e5958: CheckStackOverflow
    //     0x10e5958: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e595c: cmp             SP, x16
    //     0x10e5960: b.ls            #0x10e5a28
    // 0x10e5964: LoadField: r0 = r1->field_13
    //     0x10e5964: ldur            w0, [x1, #0x13]
    // 0x10e5968: DecompressPointer r0
    //     0x10e5968: add             x0, x0, HEAP, lsl #32
    // 0x10e596c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10e5970: cmp             w0, w16
    // 0x10e5974: b.eq            #0x10e5a30
    // 0x10e5978: stur            x0, [fp, #-0x20]
    // 0x10e597c: LoadField: r1 = r0->field_b
    //     0x10e597c: ldur            w1, [x0, #0xb]
    // 0x10e5980: r2 = LoadInt32Instr(r1)
    //     0x10e5980: sbfx            x2, x1, #1, #0x1f
    // 0x10e5984: stur            x2, [fp, #-0x18]
    // 0x10e5988: r1 = 0
    //     0x10e5988: mov             x1, #0
    // 0x10e598c: CheckStackOverflow
    //     0x10e598c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e5990: cmp             SP, x16
    //     0x10e5994: b.ls            #0x10e5a3c
    // 0x10e5998: LoadField: r3 = r0->field_b
    //     0x10e5998: ldur            w3, [x0, #0xb]
    // 0x10e599c: r4 = LoadInt32Instr(r3)
    //     0x10e599c: sbfx            x4, x3, #1, #0x1f
    // 0x10e59a0: cmp             x2, x4
    // 0x10e59a4: b.ne            #0x10e5a0c
    // 0x10e59a8: cmp             x1, x4
    // 0x10e59ac: b.ge            #0x10e59fc
    // 0x10e59b0: LoadField: r3 = r0->field_f
    //     0x10e59b0: ldur            w3, [x0, #0xf]
    // 0x10e59b4: DecompressPointer r3
    //     0x10e59b4: add             x3, x3, HEAP, lsl #32
    // 0x10e59b8: ArrayLoad: r4 = r3[r1]  ; Unknown_4
    //     0x10e59b8: add             x16, x3, x1, lsl #2
    //     0x10e59bc: ldur            w4, [x16, #0xf]
    // 0x10e59c0: DecompressPointer r4
    //     0x10e59c0: add             x4, x4, HEAP, lsl #32
    // 0x10e59c4: stur            x4, [fp, #-0x10]
    // 0x10e59c8: add             x3, x1, #1
    // 0x10e59cc: stur            x3, [fp, #-8]
    // 0x10e59d0: LoadField: r1 = r4->field_5b
    //     0x10e59d0: ldur            w1, [x4, #0x5b]
    // 0x10e59d4: DecompressPointer r1
    //     0x10e59d4: add             x1, x1, HEAP, lsl #32
    // 0x10e59d8: cmp             w1, NULL
    // 0x10e59dc: b.eq            #0x10e59e4
    // 0x10e59e0: r0 = detach()
    //     0x10e59e0: bl              #0xf72a78  ; [package:flutter/src/widgets/focus_manager.dart] FocusAttachment::detach
    // 0x10e59e4: ldur            x1, [fp, #-0x10]
    // 0x10e59e8: r0 = dispose()
    //     0x10e59e8: bl              #0x10ef878  ; [dart:mixin_deduplication] _MixinApplication276&Object&ChangeNotifier::dispose
    // 0x10e59ec: ldur            x1, [fp, #-8]
    // 0x10e59f0: ldur            x0, [fp, #-0x20]
    // 0x10e59f4: ldur            x2, [fp, #-0x18]
    // 0x10e59f8: b               #0x10e598c
    // 0x10e59fc: r0 = Null
    //     0x10e59fc: mov             x0, NULL
    // 0x10e5a00: LeaveFrame
    //     0x10e5a00: mov             SP, fp
    //     0x10e5a04: ldp             fp, lr, [SP], #0x10
    // 0x10e5a08: ret
    //     0x10e5a08: ret             
    // 0x10e5a0c: r0 = ConcurrentModificationError()
    //     0x10e5a0c: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x10e5a10: mov             x1, x0
    // 0x10e5a14: ldur            x0, [fp, #-0x20]
    // 0x10e5a18: StoreField: r1->field_b = r0
    //     0x10e5a18: stur            w0, [x1, #0xb]
    // 0x10e5a1c: mov             x0, x1
    // 0x10e5a20: r0 = Throw()
    //     0x10e5a20: bl              #0x13ddb2c  ; ThrowStub
    // 0x10e5a24: brk             #0
    // 0x10e5a28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e5a28: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e5a2c: b               #0x10e5964
    // 0x10e5a30: r9 = _dayFocusNodes
    //     0x10e5a30: add             x9, PP, #0xd2, lsl #12  ; [pp+0xd28f8] Field <_DayPickerState@54260463._dayFocusNodes@54260463>: late (offset: 0x14)
    //     0x10e5a34: ldr             x9, [x9, #0x8f8]
    // 0x10e5a38: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x10e5a38: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x10e5a3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e5a3c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e5a40: b               #0x10e5998
  }
}

// class id: 5475, size: 0x38, field offset: 0x14
class _MonthPickerState extends State<dynamic> {

  late DateTime _currentMonth; // offset: 0x1c
  late MaterialLocalizations _localizations; // offset: 0x24
  late FocusNode _dayGridFocus; // offset: 0x30
  late PageController _pageController; // offset: 0x20

  _ build(/* No info */) {
    // ** addr: 0xdee4b8, size: 0x82c
    // 0xdee4b8: EnterFrame
    //     0xdee4b8: stp             fp, lr, [SP, #-0x10]!
    //     0xdee4bc: mov             fp, SP
    // 0xdee4c0: AllocStack(0xa8)
    //     0xdee4c0: sub             SP, SP, #0xa8
    // 0xdee4c4: SetupParameters(_MonthPickerState this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xdee4c4: mov             x0, x2
    //     0xdee4c8: stur            x2, [fp, #-0x10]
    //     0xdee4cc: mov             x2, x1
    //     0xdee4d0: stur            x1, [fp, #-8]
    // 0xdee4d4: CheckStackOverflow
    //     0xdee4d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdee4d8: cmp             SP, x16
    //     0xdee4dc: b.ls            #0xdeec8c
    // 0xdee4e0: mov             x1, x0
    // 0xdee4e4: r0 = of()
    //     0xdee4e4: bl              #0xd0ff6c  ; [package:flutter/src/material/date_picker_theme.dart] DatePickerTheme::of
    // 0xdee4e8: ldur            x1, [fp, #-0x10]
    // 0xdee4ec: r0 = defaults()
    //     0xdee4ec: bl              #0xd0fd74  ; [package:flutter/src/material/date_picker_theme.dart] DatePickerTheme::defaults
    // 0xdee4f0: r1 = LoadClassIdInstr(r0)
    //     0xdee4f0: ldur            x1, [x0, #-1]
    //     0xdee4f4: ubfx            x1, x1, #0xc, #0x14
    // 0xdee4f8: r17 = 5167
    //     0xdee4f8: mov             x17, #0x142f
    // 0xdee4fc: cmp             x1, x17
    // 0xdee500: b.ne            #0xdee514
    // 0xdee504: LoadField: r1 = r0->field_a7
    //     0xdee504: ldur            w1, [x0, #0xa7]
    // 0xdee508: DecompressPointer r1
    //     0xdee508: add             x1, x1, HEAP, lsl #32
    // 0xdee50c: mov             x0, x1
    // 0xdee510: b               #0xdee5b4
    // 0xdee514: r17 = 5168
    //     0xdee514: mov             x17, #0x1430
    // 0xdee518: cmp             x1, x17
    // 0xdee51c: b.ne            #0xdee56c
    // 0xdee520: mov             x1, x0
    // 0xdee524: LoadField: r0 = r1->field_b3
    //     0xdee524: ldur            w0, [x1, #0xb3]
    // 0xdee528: DecompressPointer r0
    //     0xdee528: add             x0, x0, HEAP, lsl #32
    // 0xdee52c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdee530: cmp             w0, w16
    // 0xdee534: b.ne            #0xdee544
    // 0xdee538: r2 = _colors
    //     0xdee538: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xdee53c: ldr             x2, [x2, #0x400]
    // 0xdee540: r0 = InitLateFinalInstanceField()
    //     0xdee540: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdee544: LoadField: r1 = r0->field_7f
    //     0xdee544: ldur            w1, [x0, #0x7f]
    // 0xdee548: DecompressPointer r1
    //     0xdee548: add             x1, x1, HEAP, lsl #32
    // 0xdee54c: r0 = LoadClassIdInstr(r1)
    //     0xdee54c: ldur            x0, [x1, #-1]
    //     0xdee550: ubfx            x0, x0, #0xc, #0x14
    // 0xdee554: d0 = 0.600000
    //     0xdee554: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c88] IMM: double(0.6) from 0x3fe3333333333333
    //     0xdee558: ldr             d0, [x17, #0xc88]
    // 0xdee55c: r0 = GDT[cid_x0 + -0x1000]()
    //     0xdee55c: sub             lr, x0, #1, lsl #12
    //     0xdee560: ldr             lr, [x21, lr, lsl #3]
    //     0xdee564: blr             lr
    // 0xdee568: b               #0xdee5b4
    // 0xdee56c: mov             x1, x0
    // 0xdee570: LoadField: r0 = r1->field_b3
    //     0xdee570: ldur            w0, [x1, #0xb3]
    // 0xdee574: DecompressPointer r0
    //     0xdee574: add             x0, x0, HEAP, lsl #32
    // 0xdee578: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdee57c: cmp             w0, w16
    // 0xdee580: b.ne            #0xdee590
    // 0xdee584: r2 = _colors
    //     0xdee584: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xdee588: ldr             x2, [x2, #0x410]
    // 0xdee58c: r0 = InitLateFinalInstanceField()
    //     0xdee58c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdee590: LoadField: r1 = r0->field_7f
    //     0xdee590: ldur            w1, [x0, #0x7f]
    // 0xdee594: DecompressPointer r1
    //     0xdee594: add             x1, x1, HEAP, lsl #32
    // 0xdee598: r0 = LoadClassIdInstr(r1)
    //     0xdee598: ldur            x0, [x1, #-1]
    //     0xdee59c: ubfx            x0, x0, #0xc, #0x14
    // 0xdee5a0: d0 = 0.600000
    //     0xdee5a0: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c88] IMM: double(0.6) from 0x3fe3333333333333
    //     0xdee5a4: ldr             d0, [x17, #0xc88]
    // 0xdee5a8: r0 = GDT[cid_x0 + -0x1000]()
    //     0xdee5a8: sub             lr, x0, #1, lsl #12
    //     0xdee5ac: ldr             lr, [x21, lr, lsl #3]
    //     0xdee5b0: blr             lr
    // 0xdee5b4: ldur            x1, [fp, #-0x10]
    // 0xdee5b8: stur            x0, [fp, #-0x18]
    // 0xdee5bc: r0 = maybeSupportsAnnounceOf()
    //     0xdee5bc: bl              #0xd19758  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::maybeSupportsAnnounceOf
    // 0xdee5c0: cmp             w0, NULL
    // 0xdee5c4: b.ne            #0xdee5cc
    // 0xdee5c8: r0 = false
    //     0xdee5c8: add             x0, NULL, #0x30  ; false
    // 0xdee5cc: eor             x2, x0, #0x10
    // 0xdee5d0: stur            x2, [fp, #-0x28]
    // 0xdee5d4: tbz             w0, #4, #0xdee5e0
    // 0xdee5d8: r3 = Instance_AccessibilityFocusBlockType
    //     0xdee5d8: ldr             x3, [PP, #0x2a88]  ; [pp+0x2a88] Obj!AccessibilityFocusBlockType@12c3ee1
    // 0xdee5dc: b               #0xdee5e4
    // 0xdee5e0: r3 = Instance_AccessibilityFocusBlockType
    //     0xdee5e0: ldr             x3, [PP, #0x2978]  ; [pp+0x2978] Obj!AccessibilityFocusBlockType@12c3ec1
    // 0xdee5e4: stur            x3, [fp, #-0x20]
    // 0xdee5e8: tbz             w0, #4, #0xdee600
    // 0xdee5ec: ldur            x0, [fp, #-8]
    // 0xdee5f0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdee5f0: ldur            w1, [x0, #0x17]
    // 0xdee5f4: DecompressPointer r1
    //     0xdee5f4: add             x1, x1, HEAP, lsl #32
    // 0xdee5f8: mov             x4, x1
    // 0xdee5fc: b               #0xdee608
    // 0xdee600: ldur            x0, [fp, #-8]
    // 0xdee604: r4 = Null
    //     0xdee604: mov             x4, NULL
    // 0xdee608: mov             x1, x0
    // 0xdee60c: stur            x4, [fp, #-0x10]
    // 0xdee610: r0 = _isDisplayingFirstMonth()
    //     0xdee610: bl              #0xdef1cc  ; [package:flutter/src/material/calendar_date_picker.dart] _MonthPickerState::_isDisplayingFirstMonth
    // 0xdee614: tbnz            w0, #4, #0xdee650
    // 0xdee618: ldur            x2, [fp, #-8]
    // 0xdee61c: LoadField: r1 = r2->field_23
    //     0xdee61c: ldur            w1, [x2, #0x23]
    // 0xdee620: DecompressPointer r1
    //     0xdee620: add             x1, x1, HEAP, lsl #32
    // 0xdee624: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdee628: cmp             w1, w16
    // 0xdee62c: b.eq            #0xdeec94
    // 0xdee630: r0 = LoadClassIdInstr(r1)
    //     0xdee630: ldur            x0, [x1, #-1]
    //     0xdee634: ubfx            x0, x0, #0xc, #0x14
    // 0xdee638: r0 = GDT[cid_x0 + 0x15eb2]()
    //     0xdee638: mov             x17, #0x5eb2
    //     0xdee63c: movk            x17, #1, lsl #16
    //     0xdee640: add             lr, x0, x17
    //     0xdee644: ldr             lr, [x21, lr, lsl #3]
    //     0xdee648: blr             lr
    // 0xdee64c: b               #0xdee654
    // 0xdee650: r0 = Null
    //     0xdee650: mov             x0, NULL
    // 0xdee654: stur            x0, [fp, #-0x30]
    // 0xdee658: r0 = Icon()
    //     0xdee658: bl              #0xd0fd5c  ; AllocateIconStub -> Icon (size=0x40)
    // 0xdee65c: mov             x2, x0
    // 0xdee660: r0 = Instance_IconData
    //     0xdee660: add             x0, PP, #0xd0, lsl #12  ; [pp+0xd06d0] Obj!IconData@128a811
    //     0xdee664: ldr             x0, [x0, #0x6d0]
    // 0xdee668: stur            x2, [fp, #-0x38]
    // 0xdee66c: StoreField: r2->field_b = r0
    //     0xdee66c: stur            w0, [x2, #0xb]
    // 0xdee670: ldur            x0, [fp, #-0x30]
    // 0xdee674: StoreField: r2->field_2b = r0
    //     0xdee674: stur            w0, [x2, #0x2b]
    // 0xdee678: ldur            x1, [fp, #-8]
    // 0xdee67c: r0 = _isDisplayingFirstMonth()
    //     0xdee67c: bl              #0xdef1cc  ; [package:flutter/src/material/calendar_date_picker.dart] _MonthPickerState::_isDisplayingFirstMonth
    // 0xdee680: tbnz            w0, #4, #0xdee68c
    // 0xdee684: r0 = Null
    //     0xdee684: mov             x0, NULL
    // 0xdee688: b               #0xdee6c0
    // 0xdee68c: ldur            x2, [fp, #-8]
    // 0xdee690: LoadField: r1 = r2->field_23
    //     0xdee690: ldur            w1, [x2, #0x23]
    // 0xdee694: DecompressPointer r1
    //     0xdee694: add             x1, x1, HEAP, lsl #32
    // 0xdee698: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdee69c: cmp             w1, w16
    // 0xdee6a0: b.eq            #0xdeeca0
    // 0xdee6a4: r0 = LoadClassIdInstr(r1)
    //     0xdee6a4: ldur            x0, [x1, #-1]
    //     0xdee6a8: ubfx            x0, x0, #0xc, #0x14
    // 0xdee6ac: r0 = GDT[cid_x0 + 0x15eb2]()
    //     0xdee6ac: mov             x17, #0x5eb2
    //     0xdee6b0: movk            x17, #1, lsl #16
    //     0xdee6b4: add             lr, x0, x17
    //     0xdee6b8: ldr             lr, [x21, lr, lsl #3]
    //     0xdee6bc: blr             lr
    // 0xdee6c0: ldur            x1, [fp, #-8]
    // 0xdee6c4: stur            x0, [fp, #-0x30]
    // 0xdee6c8: r0 = _isDisplayingFirstMonth()
    //     0xdee6c8: bl              #0xdef1cc  ; [package:flutter/src/material/calendar_date_picker.dart] _MonthPickerState::_isDisplayingFirstMonth
    // 0xdee6cc: tbnz            w0, #4, #0xdee6d8
    // 0xdee6d0: r3 = Null
    //     0xdee6d0: mov             x3, NULL
    // 0xdee6d4: b               #0xdee6ec
    // 0xdee6d8: ldur            x2, [fp, #-8]
    // 0xdee6dc: r1 = Function '_handlePreviousMonth@54260463':.
    //     0xdee6dc: add             x1, PP, #0xd0, lsl #12  ; [pp+0xd06d8] AnonymousClosure: (0xdf03f0), in [package:flutter/src/material/calendar_date_picker.dart] _MonthPickerState::_handlePreviousMonth (0xdf0428)
    //     0xdee6e0: ldr             x1, [x1, #0x6d8]
    // 0xdee6e4: r0 = AllocateClosure()
    //     0xdee6e4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdee6e8: mov             x3, x0
    // 0xdee6ec: ldur            x1, [fp, #-0x38]
    // 0xdee6f0: ldur            x0, [fp, #-0x30]
    // 0xdee6f4: ldur            x2, [fp, #-0x18]
    // 0xdee6f8: stur            x3, [fp, #-0x40]
    // 0xdee6fc: r0 = IconButton()
    //     0xdee6fc: bl              #0xd16288  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0xdee700: mov             x2, x0
    // 0xdee704: ldur            x0, [fp, #-0x18]
    // 0xdee708: stur            x2, [fp, #-0x48]
    // 0xdee70c: StoreField: r2->field_2b = r0
    //     0xdee70c: stur            w0, [x2, #0x2b]
    // 0xdee710: ldur            x1, [fp, #-0x40]
    // 0xdee714: StoreField: r2->field_3b = r1
    //     0xdee714: stur            w1, [x2, #0x3b]
    // 0xdee718: r3 = false
    //     0xdee718: add             x3, NULL, #0x30  ; false
    // 0xdee71c: StoreField: r2->field_4f = r3
    //     0xdee71c: stur            w3, [x2, #0x4f]
    // 0xdee720: ldur            x1, [fp, #-0x30]
    // 0xdee724: StoreField: r2->field_53 = r1
    //     0xdee724: stur            w1, [x2, #0x53]
    // 0xdee728: ldur            x1, [fp, #-0x38]
    // 0xdee72c: StoreField: r2->field_1f = r1
    //     0xdee72c: stur            w1, [x2, #0x1f]
    // 0xdee730: r4 = Instance__IconButtonVariant
    //     0xdee730: add             x4, PP, #0x17, lsl #12  ; [pp+0x177a8] Obj!_IconButtonVariant@12c57a1
    //     0xdee734: ldr             x4, [x4, #0x7a8]
    // 0xdee738: StoreField: r2->field_6f = r4
    //     0xdee738: stur            w4, [x2, #0x6f]
    // 0xdee73c: ldur            x1, [fp, #-8]
    // 0xdee740: r0 = _isDisplayingLastMonth()
    //     0xdee740: bl              #0xdef09c  ; [package:flutter/src/material/calendar_date_picker.dart] _MonthPickerState::_isDisplayingLastMonth
    // 0xdee744: tbnz            w0, #4, #0xdee780
    // 0xdee748: ldur            x2, [fp, #-8]
    // 0xdee74c: LoadField: r1 = r2->field_23
    //     0xdee74c: ldur            w1, [x2, #0x23]
    // 0xdee750: DecompressPointer r1
    //     0xdee750: add             x1, x1, HEAP, lsl #32
    // 0xdee754: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdee758: cmp             w1, w16
    // 0xdee75c: b.eq            #0xdeecac
    // 0xdee760: r0 = LoadClassIdInstr(r1)
    //     0xdee760: ldur            x0, [x1, #-1]
    //     0xdee764: ubfx            x0, x0, #0xc, #0x14
    // 0xdee768: r0 = GDT[cid_x0 + 0x159bc]()
    //     0xdee768: mov             x17, #0x59bc
    //     0xdee76c: movk            x17, #1, lsl #16
    //     0xdee770: add             lr, x0, x17
    //     0xdee774: ldr             lr, [x21, lr, lsl #3]
    //     0xdee778: blr             lr
    // 0xdee77c: b               #0xdee784
    // 0xdee780: r0 = Null
    //     0xdee780: mov             x0, NULL
    // 0xdee784: stur            x0, [fp, #-0x30]
    // 0xdee788: r0 = Icon()
    //     0xdee788: bl              #0xd0fd5c  ; AllocateIconStub -> Icon (size=0x40)
    // 0xdee78c: mov             x2, x0
    // 0xdee790: r0 = Instance_IconData
    //     0xdee790: add             x0, PP, #0xd0, lsl #12  ; [pp+0xd06e0] Obj!IconData@128a7f1
    //     0xdee794: ldr             x0, [x0, #0x6e0]
    // 0xdee798: stur            x2, [fp, #-0x38]
    // 0xdee79c: StoreField: r2->field_b = r0
    //     0xdee79c: stur            w0, [x2, #0xb]
    // 0xdee7a0: ldur            x0, [fp, #-0x30]
    // 0xdee7a4: StoreField: r2->field_2b = r0
    //     0xdee7a4: stur            w0, [x2, #0x2b]
    // 0xdee7a8: ldur            x1, [fp, #-8]
    // 0xdee7ac: r0 = _isDisplayingLastMonth()
    //     0xdee7ac: bl              #0xdef09c  ; [package:flutter/src/material/calendar_date_picker.dart] _MonthPickerState::_isDisplayingLastMonth
    // 0xdee7b0: tbnz            w0, #4, #0xdee7bc
    // 0xdee7b4: r0 = Null
    //     0xdee7b4: mov             x0, NULL
    // 0xdee7b8: b               #0xdee7f0
    // 0xdee7bc: ldur            x2, [fp, #-8]
    // 0xdee7c0: LoadField: r1 = r2->field_23
    //     0xdee7c0: ldur            w1, [x2, #0x23]
    // 0xdee7c4: DecompressPointer r1
    //     0xdee7c4: add             x1, x1, HEAP, lsl #32
    // 0xdee7c8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdee7cc: cmp             w1, w16
    // 0xdee7d0: b.eq            #0xdeecb8
    // 0xdee7d4: r0 = LoadClassIdInstr(r1)
    //     0xdee7d4: ldur            x0, [x1, #-1]
    //     0xdee7d8: ubfx            x0, x0, #0xc, #0x14
    // 0xdee7dc: r0 = GDT[cid_x0 + 0x159bc]()
    //     0xdee7dc: mov             x17, #0x59bc
    //     0xdee7e0: movk            x17, #1, lsl #16
    //     0xdee7e4: add             lr, x0, x17
    //     0xdee7e8: ldr             lr, [x21, lr, lsl #3]
    //     0xdee7ec: blr             lr
    // 0xdee7f0: ldur            x1, [fp, #-8]
    // 0xdee7f4: stur            x0, [fp, #-0x30]
    // 0xdee7f8: r0 = _isDisplayingLastMonth()
    //     0xdee7f8: bl              #0xdef09c  ; [package:flutter/src/material/calendar_date_picker.dart] _MonthPickerState::_isDisplayingLastMonth
    // 0xdee7fc: tbnz            w0, #4, #0xdee808
    // 0xdee800: r5 = Null
    //     0xdee800: mov             x5, NULL
    // 0xdee804: b               #0xdee81c
    // 0xdee808: ldur            x2, [fp, #-8]
    // 0xdee80c: r1 = Function '_handleNextMonth@54260463':.
    //     0xdee80c: add             x1, PP, #0xd0, lsl #12  ; [pp+0xd06e8] AnonymousClosure: (0xdf0344), in [package:flutter/src/material/calendar_date_picker.dart] _MonthPickerState::_handleNextMonth (0xdf037c)
    //     0xdee810: ldr             x1, [x1, #0x6e8]
    // 0xdee814: r0 = AllocateClosure()
    //     0xdee814: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdee818: mov             x5, x0
    // 0xdee81c: ldur            x2, [fp, #-8]
    // 0xdee820: ldur            x4, [fp, #-0x48]
    // 0xdee824: ldur            x1, [fp, #-0x38]
    // 0xdee828: ldur            x0, [fp, #-0x30]
    // 0xdee82c: ldur            x3, [fp, #-0x18]
    // 0xdee830: stur            x5, [fp, #-0x40]
    // 0xdee834: r0 = IconButton()
    //     0xdee834: bl              #0xd16288  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0xdee838: mov             x3, x0
    // 0xdee83c: ldur            x0, [fp, #-0x18]
    // 0xdee840: stur            x3, [fp, #-0x50]
    // 0xdee844: StoreField: r3->field_2b = r0
    //     0xdee844: stur            w0, [x3, #0x2b]
    // 0xdee848: ldur            x0, [fp, #-0x40]
    // 0xdee84c: StoreField: r3->field_3b = r0
    //     0xdee84c: stur            w0, [x3, #0x3b]
    // 0xdee850: r0 = false
    //     0xdee850: add             x0, NULL, #0x30  ; false
    // 0xdee854: StoreField: r3->field_4f = r0
    //     0xdee854: stur            w0, [x3, #0x4f]
    // 0xdee858: ldur            x1, [fp, #-0x30]
    // 0xdee85c: StoreField: r3->field_53 = r1
    //     0xdee85c: stur            w1, [x3, #0x53]
    // 0xdee860: ldur            x1, [fp, #-0x38]
    // 0xdee864: StoreField: r3->field_1f = r1
    //     0xdee864: stur            w1, [x3, #0x1f]
    // 0xdee868: r1 = Instance__IconButtonVariant
    //     0xdee868: add             x1, PP, #0x17, lsl #12  ; [pp+0x177a8] Obj!_IconButtonVariant@12c57a1
    //     0xdee86c: ldr             x1, [x1, #0x7a8]
    // 0xdee870: StoreField: r3->field_6f = r1
    //     0xdee870: stur            w1, [x3, #0x6f]
    // 0xdee874: r1 = Null
    //     0xdee874: mov             x1, NULL
    // 0xdee878: r2 = 6
    //     0xdee878: mov             x2, #6
    // 0xdee87c: r0 = AllocateArray()
    //     0xdee87c: bl              #0x13df928  ; AllocateArrayStub
    // 0xdee880: stur            x0, [fp, #-0x18]
    // 0xdee884: r16 = Instance_Spacer
    //     0xdee884: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1ee78] Obj!Spacer@12b5c01
    //     0xdee888: ldr             x16, [x16, #0xe78]
    // 0xdee88c: StoreField: r0->field_f = r16
    //     0xdee88c: stur            w16, [x0, #0xf]
    // 0xdee890: ldur            x1, [fp, #-0x48]
    // 0xdee894: StoreField: r0->field_13 = r1
    //     0xdee894: stur            w1, [x0, #0x13]
    // 0xdee898: ldur            x1, [fp, #-0x50]
    // 0xdee89c: ArrayStore: r0[0] = r1  ; List_4
    //     0xdee89c: stur            w1, [x0, #0x17]
    // 0xdee8a0: r1 = <Widget>
    //     0xdee8a0: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xdee8a4: r0 = AllocateGrowableArray()
    //     0xdee8a4: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xdee8a8: mov             x1, x0
    // 0xdee8ac: ldur            x0, [fp, #-0x18]
    // 0xdee8b0: stur            x1, [fp, #-0x30]
    // 0xdee8b4: StoreField: r1->field_f = r0
    //     0xdee8b4: stur            w0, [x1, #0xf]
    // 0xdee8b8: r0 = 6
    //     0xdee8b8: mov             x0, #6
    // 0xdee8bc: StoreField: r1->field_b = r0
    //     0xdee8bc: stur            w0, [x1, #0xb]
    // 0xdee8c0: r0 = Row()
    //     0xdee8c0: bl              #0x8a5b04  ; AllocateRowStub -> Row (size=0x38)
    // 0xdee8c4: mov             x1, x0
    // 0xdee8c8: r0 = Instance_Axis
    //     0xdee8c8: ldr             x0, [PP, #0x49c8]  ; [pp+0x49c8] Obj!Axis@12c4a61
    // 0xdee8cc: stur            x1, [fp, #-0x18]
    // 0xdee8d0: StoreField: r1->field_f = r0
    //     0xdee8d0: stur            w0, [x1, #0xf]
    // 0xdee8d4: r0 = Instance_MainAxisAlignment
    //     0xdee8d4: add             x0, PP, #0x15, lsl #12  ; [pp+0x15820] Obj!MainAxisAlignment@12c4541
    //     0xdee8d8: ldr             x0, [x0, #0x820]
    // 0xdee8dc: StoreField: r1->field_13 = r0
    //     0xdee8dc: stur            w0, [x1, #0x13]
    // 0xdee8e0: r2 = Instance_MainAxisSize
    //     0xdee8e0: add             x2, PP, #0x15, lsl #12  ; [pp+0x15828] Obj!MainAxisSize@12c4621
    //     0xdee8e4: ldr             x2, [x2, #0x828]
    // 0xdee8e8: ArrayStore: r1[0] = r2  ; List_4
    //     0xdee8e8: stur            w2, [x1, #0x17]
    // 0xdee8ec: r3 = Instance_CrossAxisAlignment
    //     0xdee8ec: add             x3, PP, #0x15, lsl #12  ; [pp+0x15888] Obj!CrossAxisAlignment@12c44a1
    //     0xdee8f0: ldr             x3, [x3, #0x888]
    // 0xdee8f4: StoreField: r1->field_1b = r3
    //     0xdee8f4: stur            w3, [x1, #0x1b]
    // 0xdee8f8: r4 = Instance_VerticalDirection
    //     0xdee8f8: add             x4, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xdee8fc: ldr             x4, [x4, #0x838]
    // 0xdee900: StoreField: r1->field_23 = r4
    //     0xdee900: stur            w4, [x1, #0x23]
    // 0xdee904: r5 = Instance_Clip
    //     0xdee904: add             x5, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xdee908: ldr             x5, [x5, #0x840]
    // 0xdee90c: StoreField: r1->field_2b = r5
    //     0xdee90c: stur            w5, [x1, #0x2b]
    // 0xdee910: StoreField: r1->field_2f = rZR
    //     0xdee910: stur            xzr, [x1, #0x2f]
    // 0xdee914: ldur            x6, [fp, #-0x30]
    // 0xdee918: StoreField: r1->field_b = r6
    //     0xdee918: stur            w6, [x1, #0xb]
    // 0xdee91c: r0 = Padding()
    //     0xdee91c: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xdee920: mov             x1, x0
    // 0xdee924: r0 = Instance_EdgeInsetsDirectional
    //     0xdee924: add             x0, PP, #0xd0, lsl #12  ; [pp+0xd06f0] Obj!EdgeInsetsDirectional@129c811
    //     0xdee928: ldr             x0, [x0, #0x6f0]
    // 0xdee92c: stur            x1, [fp, #-0x30]
    // 0xdee930: StoreField: r1->field_f = r0
    //     0xdee930: stur            w0, [x1, #0xf]
    // 0xdee934: ldur            x0, [fp, #-0x18]
    // 0xdee938: StoreField: r1->field_b = r0
    //     0xdee938: stur            w0, [x1, #0xb]
    // 0xdee93c: r0 = SizedBox()
    //     0xdee93c: bl              #0x8a7210  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0xdee940: mov             x2, x0
    // 0xdee944: r0 = 52.000000
    //     0xdee944: add             x0, PP, #0xd0, lsl #12  ; [pp+0xd06f8] 52
    //     0xdee948: ldr             x0, [x0, #0x6f8]
    // 0xdee94c: stur            x2, [fp, #-0x40]
    // 0xdee950: StoreField: r2->field_13 = r0
    //     0xdee950: stur            w0, [x2, #0x13]
    // 0xdee954: ldur            x0, [fp, #-0x30]
    // 0xdee958: StoreField: r2->field_b = r0
    //     0xdee958: stur            w0, [x2, #0xb]
    // 0xdee95c: ldur            x0, [fp, #-8]
    // 0xdee960: LoadField: r3 = r0->field_27
    //     0xdee960: ldur            w3, [x0, #0x27]
    // 0xdee964: DecompressPointer r3
    //     0xdee964: add             x3, x3, HEAP, lsl #32
    // 0xdee968: stur            x3, [fp, #-0x38]
    // 0xdee96c: LoadField: r4 = r0->field_2b
    //     0xdee96c: ldur            w4, [x0, #0x2b]
    // 0xdee970: DecompressPointer r4
    //     0xdee970: add             x4, x4, HEAP, lsl #32
    // 0xdee974: stur            x4, [fp, #-0x30]
    // 0xdee978: LoadField: r5 = r0->field_2f
    //     0xdee978: ldur            w5, [x0, #0x2f]
    // 0xdee97c: DecompressPointer r5
    //     0xdee97c: add             x5, x5, HEAP, lsl #32
    // 0xdee980: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdee984: cmp             w5, w16
    // 0xdee988: b.eq            #0xdeecc4
    // 0xdee98c: stur            x5, [fp, #-0x18]
    // 0xdee990: LoadField: r1 = r0->field_b
    //     0xdee990: ldur            w1, [x0, #0xb]
    // 0xdee994: DecompressPointer r1
    //     0xdee994: add             x1, x1, HEAP, lsl #32
    // 0xdee998: cmp             w1, NULL
    // 0xdee99c: b.eq            #0xdeecd0
    // 0xdee9a0: mov             x1, x5
    // 0xdee9a4: r0 = hasFocus()
    //     0xdee9a4: bl              #0x843d08  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::hasFocus
    // 0xdee9a8: tbnz            w0, #4, #0xdee9c0
    // 0xdee9ac: ldur            x0, [fp, #-8]
    // 0xdee9b0: LoadField: r1 = r0->field_33
    //     0xdee9b0: ldur            w1, [x0, #0x33]
    // 0xdee9b4: DecompressPointer r1
    //     0xdee9b4: add             x1, x1, HEAP, lsl #32
    // 0xdee9b8: mov             x7, x1
    // 0xdee9bc: b               #0xdee9c8
    // 0xdee9c0: ldur            x0, [fp, #-8]
    // 0xdee9c4: r7 = Null
    //     0xdee9c4: mov             x7, NULL
    // 0xdee9c8: ldur            x3, [fp, #-0x40]
    // 0xdee9cc: ldur            x4, [fp, #-0x38]
    // 0xdee9d0: ldur            x5, [fp, #-0x30]
    // 0xdee9d4: ldur            x6, [fp, #-0x18]
    // 0xdee9d8: stur            x7, [fp, #-0x58]
    // 0xdee9dc: LoadField: r8 = r0->field_13
    //     0xdee9dc: ldur            w8, [x0, #0x13]
    // 0xdee9e0: DecompressPointer r8
    //     0xdee9e0: add             x8, x8, HEAP, lsl #32
    // 0xdee9e4: stur            x8, [fp, #-0x50]
    // 0xdee9e8: LoadField: r10 = r0->field_1f
    //     0xdee9e8: ldur            w10, [x0, #0x1f]
    // 0xdee9ec: DecompressPointer r10
    //     0xdee9ec: add             x10, x10, HEAP, lsl #32
    // 0xdee9f0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdee9f4: cmp             w10, w16
    // 0xdee9f8: b.eq            #0xdeecd4
    // 0xdee9fc: stur            x10, [fp, #-0x48]
    // 0xdeea00: LoadField: r1 = r0->field_b
    //     0xdeea00: ldur            w1, [x0, #0xb]
    // 0xdeea04: DecompressPointer r1
    //     0xdeea04: add             x1, x1, HEAP, lsl #32
    // 0xdeea08: cmp             w1, NULL
    // 0xdeea0c: b.eq            #0xdeece0
    // 0xdeea10: LoadField: r2 = r1->field_13
    //     0xdeea10: ldur            w2, [x1, #0x13]
    // 0xdeea14: DecompressPointer r2
    //     0xdeea14: add             x2, x2, HEAP, lsl #32
    // 0xdeea18: ArrayLoad: r9 = r1[0]  ; List_4
    //     0xdeea18: ldur            w9, [x1, #0x17]
    // 0xdeea1c: DecompressPointer r9
    //     0xdeea1c: add             x9, x9, HEAP, lsl #32
    // 0xdeea20: mov             x1, x2
    // 0xdeea24: mov             x2, x9
    // 0xdeea28: r0 = monthDelta()
    //     0xdeea28: bl              #0xdeef48  ; [package:flutter/src/material/date.dart] DateUtils::monthDelta
    // 0xdeea2c: add             x5, x0, #1
    // 0xdeea30: ldur            x2, [fp, #-8]
    // 0xdeea34: stur            x5, [fp, #-0x60]
    // 0xdeea38: r1 = Function '_buildItems@54260463':.
    //     0xdeea38: add             x1, PP, #0xd0, lsl #12  ; [pp+0xd0700] AnonymousClosure: (0xdf00d8), in [package:flutter/src/material/calendar_date_picker.dart] _MonthPickerState::_buildItems (0xdf0118)
    //     0xdeea3c: ldr             x1, [x1, #0x700]
    // 0xdeea40: r0 = AllocateClosure()
    //     0xdeea40: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdeea44: ldur            x2, [fp, #-8]
    // 0xdeea48: r1 = Function '_handleMonthPageChanged@54260463':.
    //     0xdeea48: add             x1, PP, #0xd0, lsl #12  ; [pp+0xd0708] AnonymousClosure: (0xdefb9c), in [package:flutter/src/material/calendar_date_picker.dart] _MonthPickerState::_handleMonthPageChanged (0xdefbd8)
    //     0xdeea4c: ldr             x1, [x1, #0x708]
    // 0xdeea50: stur            x0, [fp, #-0x68]
    // 0xdeea54: r0 = AllocateClosure()
    //     0xdeea54: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdeea58: stur            x0, [fp, #-0x70]
    // 0xdeea5c: r0 = PageView()
    //     0xdeea5c: bl              #0xdeef3c  ; AllocatePageViewStub -> PageView (size=0x48)
    // 0xdeea60: stur            x0, [fp, #-0x78]
    // 0xdeea64: ldur            x16, [fp, #-0x50]
    // 0xdeea68: str             x16, [SP]
    // 0xdeea6c: mov             x1, x0
    // 0xdeea70: ldur            x2, [fp, #-0x48]
    // 0xdeea74: ldur            x3, [fp, #-0x68]
    // 0xdeea78: ldur            x5, [fp, #-0x60]
    // 0xdeea7c: ldur            x6, [fp, #-0x70]
    // 0xdeea80: r4 = const [0, 0x6, 0x1, 0x5, key, 0x5, null]
    //     0xdeea80: add             x4, PP, #0xd0, lsl #12  ; [pp+0xd0710] List(7) [0, 0x6, 0x1, 0x5, "key", 0x5, Null]
    //     0xdeea84: ldr             x4, [x4, #0x710]
    // 0xdeea88: r0 = PageView.builder()
    //     0xdeea88: bl              #0xdeecf0  ; [package:flutter/src/widgets/page_view.dart] PageView::PageView.builder
    // 0xdeea8c: r0 = Material()
    //     0xdeea8c: bl              #0x8a54b0  ; AllocateMaterialStub -> Material (size=0x44)
    // 0xdeea90: mov             x1, x0
    // 0xdeea94: r0 = Instance_MaterialType
    //     0xdeea94: add             x0, PP, #0x8c, lsl #12  ; [pp+0x8c618] Obj!MaterialType@12c5361
    //     0xdeea98: ldr             x0, [x0, #0x618]
    // 0xdeea9c: stur            x1, [fp, #-0x48]
    // 0xdeeaa0: StoreField: r1->field_f = r0
    //     0xdeeaa0: stur            w0, [x1, #0xf]
    // 0xdeeaa4: ArrayStore: r1[0] = rZR  ; List_8
    //     0xdeeaa4: stur            xzr, [x1, #0x17]
    // 0xdeeaa8: r0 = true
    //     0xdeeaa8: add             x0, NULL, #0x20  ; true
    // 0xdeeaac: StoreField: r1->field_33 = r0
    //     0xdeeaac: stur            w0, [x1, #0x33]
    // 0xdeeab0: r2 = Instance_Clip
    //     0xdeeab0: add             x2, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xdeeab4: ldr             x2, [x2, #0x840]
    // 0xdeeab8: StoreField: r1->field_37 = r2
    //     0xdeeab8: stur            w2, [x1, #0x37]
    // 0xdeeabc: r3 = Instance_Duration
    //     0xdeeabc: add             x3, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xdeeac0: ldr             x3, [x3, #0x318]
    // 0xdeeac4: StoreField: r1->field_3b = r3
    //     0xdeeac4: stur            w3, [x1, #0x3b]
    // 0xdeeac8: ldur            x3, [fp, #-0x78]
    // 0xdeeacc: StoreField: r1->field_b = r3
    //     0xdeeacc: stur            w3, [x1, #0xb]
    // 0xdeead0: r3 = false
    //     0xdeead0: add             x3, NULL, #0x30  ; false
    // 0xdeead4: StoreField: r1->field_13 = r3
    //     0xdeead4: stur            w3, [x1, #0x13]
    // 0xdeead8: r0 = _FocusedDate()
    //     0xdeead8: bl              #0xdeece4  ; Allocate_FocusedDateStub -> _FocusedDate (size=0x18)
    // 0xdeeadc: mov             x1, x0
    // 0xdeeae0: r0 = Instance_GregorianCalendarDelegate
    //     0xdeeae0: add             x0, PP, #0x28, lsl #12  ; [pp+0x28538] Obj!GregorianCalendarDelegate@129edd1
    //     0xdeeae4: ldr             x0, [x0, #0x538]
    // 0xdeeae8: stur            x1, [fp, #-0x50]
    // 0xdeeaec: StoreField: r1->field_f = r0
    //     0xdeeaec: stur            w0, [x1, #0xf]
    // 0xdeeaf0: ldur            x0, [fp, #-0x58]
    // 0xdeeaf4: StoreField: r1->field_13 = r0
    //     0xdeeaf4: stur            w0, [x1, #0x13]
    // 0xdeeaf8: ldur            x0, [fp, #-0x48]
    // 0xdeeafc: StoreField: r1->field_b = r0
    //     0xdeeafc: stur            w0, [x1, #0xb]
    // 0xdeeb00: r0 = FocusableActionDetector()
    //     0xdeeb00: bl              #0xd11ab4  ; AllocateFocusableActionDetectorStub -> FocusableActionDetector (size=0x40)
    // 0xdeeb04: mov             x3, x0
    // 0xdeeb08: r0 = true
    //     0xdeeb08: add             x0, NULL, #0x20  ; true
    // 0xdeeb0c: stur            x3, [fp, #-0x48]
    // 0xdeeb10: StoreField: r3->field_b = r0
    //     0xdeeb10: stur            w0, [x3, #0xb]
    // 0xdeeb14: ldur            x1, [fp, #-0x18]
    // 0xdeeb18: StoreField: r3->field_f = r1
    //     0xdeeb18: stur            w1, [x3, #0xf]
    // 0xdeeb1c: r1 = false
    //     0xdeeb1c: add             x1, NULL, #0x30  ; false
    // 0xdeeb20: StoreField: r3->field_13 = r1
    //     0xdeeb20: stur            w1, [x3, #0x13]
    // 0xdeeb24: ArrayStore: r3[0] = r0  ; List_4
    //     0xdeeb24: stur            w0, [x3, #0x17]
    // 0xdeeb28: StoreField: r3->field_1b = r0
    //     0xdeeb28: stur            w0, [x3, #0x1b]
    // 0xdeeb2c: ldur            x1, [fp, #-0x38]
    // 0xdeeb30: StoreField: r3->field_23 = r1
    //     0xdeeb30: stur            w1, [x3, #0x23]
    // 0xdeeb34: ldur            x1, [fp, #-0x30]
    // 0xdeeb38: StoreField: r3->field_1f = r1
    //     0xdeeb38: stur            w1, [x3, #0x1f]
    // 0xdeeb3c: ldur            x2, [fp, #-8]
    // 0xdeeb40: r1 = Function '_handleGridFocusChange@54260463':.
    //     0xdeeb40: add             x1, PP, #0xd0, lsl #12  ; [pp+0xd0718] AnonymousClosure: (0xdef2fc), in [package:flutter/src/material/calendar_date_picker.dart] _MonthPickerState::_handleGridFocusChange (0xdef338)
    //     0xdeeb44: ldr             x1, [x1, #0x718]
    // 0xdeeb48: r0 = AllocateClosure()
    //     0xdeeb48: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdeeb4c: mov             x1, x0
    // 0xdeeb50: ldur            x0, [fp, #-0x48]
    // 0xdeeb54: StoreField: r0->field_2f = r1
    //     0xdeeb54: stur            w1, [x0, #0x2f]
    // 0xdeeb58: r1 = Instance__DeferringMouseCursor
    //     0xdeeb58: ldr             x1, [PP, #0x2208]  ; [pp+0x2208] Obj!_DeferringMouseCursor@12b3241
    // 0xdeeb5c: StoreField: r0->field_33 = r1
    //     0xdeeb5c: stur            w1, [x0, #0x33]
    // 0xdeeb60: r1 = true
    //     0xdeeb60: add             x1, NULL, #0x20  ; true
    // 0xdeeb64: StoreField: r0->field_37 = r1
    //     0xdeeb64: stur            w1, [x0, #0x37]
    // 0xdeeb68: ldur            x1, [fp, #-0x50]
    // 0xdeeb6c: StoreField: r0->field_3b = r1
    //     0xdeeb6c: stur            w1, [x0, #0x3b]
    // 0xdeeb70: r1 = <FlexParentData>
    //     0xdeeb70: add             x1, PP, #0x15, lsl #12  ; [pp+0x15878] TypeArguments: <FlexParentData>
    //     0xdeeb74: ldr             x1, [x1, #0x878]
    // 0xdeeb78: r0 = Expanded()
    //     0xdeeb78: bl              #0x8a5b10  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0xdeeb7c: mov             x3, x0
    // 0xdeeb80: r0 = 1
    //     0xdeeb80: mov             x0, #1
    // 0xdeeb84: stur            x3, [fp, #-8]
    // 0xdeeb88: StoreField: r3->field_13 = r0
    //     0xdeeb88: stur            x0, [x3, #0x13]
    // 0xdeeb8c: r0 = Instance_FlexFit
    //     0xdeeb8c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15880] Obj!FlexFit@12c4641
    //     0xdeeb90: ldr             x0, [x0, #0x880]
    // 0xdeeb94: StoreField: r3->field_1b = r0
    //     0xdeeb94: stur            w0, [x3, #0x1b]
    // 0xdeeb98: ldur            x0, [fp, #-0x48]
    // 0xdeeb9c: StoreField: r3->field_b = r0
    //     0xdeeb9c: stur            w0, [x3, #0xb]
    // 0xdeeba0: r1 = Null
    //     0xdeeba0: mov             x1, NULL
    // 0xdeeba4: r2 = 4
    //     0xdeeba4: mov             x2, #4
    // 0xdeeba8: r0 = AllocateArray()
    //     0xdeeba8: bl              #0x13df928  ; AllocateArrayStub
    // 0xdeebac: mov             x2, x0
    // 0xdeebb0: ldur            x0, [fp, #-0x40]
    // 0xdeebb4: stur            x2, [fp, #-0x18]
    // 0xdeebb8: StoreField: r2->field_f = r0
    //     0xdeebb8: stur            w0, [x2, #0xf]
    // 0xdeebbc: ldur            x0, [fp, #-8]
    // 0xdeebc0: StoreField: r2->field_13 = r0
    //     0xdeebc0: stur            w0, [x2, #0x13]
    // 0xdeebc4: r1 = <Widget>
    //     0xdeebc4: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xdeebc8: r0 = AllocateGrowableArray()
    //     0xdeebc8: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xdeebcc: mov             x1, x0
    // 0xdeebd0: ldur            x0, [fp, #-0x18]
    // 0xdeebd4: stur            x1, [fp, #-8]
    // 0xdeebd8: StoreField: r1->field_f = r0
    //     0xdeebd8: stur            w0, [x1, #0xf]
    // 0xdeebdc: r0 = 4
    //     0xdeebdc: mov             x0, #4
    // 0xdeebe0: StoreField: r1->field_b = r0
    //     0xdeebe0: stur            w0, [x1, #0xb]
    // 0xdeebe4: r0 = Column()
    //     0xdeebe4: bl              #0x8a5b1c  ; AllocateColumnStub -> Column (size=0x38)
    // 0xdeebe8: mov             x1, x0
    // 0xdeebec: r0 = Instance_Axis
    //     0xdeebec: ldr             x0, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xdeebf0: stur            x1, [fp, #-0x18]
    // 0xdeebf4: StoreField: r1->field_f = r0
    //     0xdeebf4: stur            w0, [x1, #0xf]
    // 0xdeebf8: r0 = Instance_MainAxisAlignment
    //     0xdeebf8: add             x0, PP, #0x15, lsl #12  ; [pp+0x15820] Obj!MainAxisAlignment@12c4541
    //     0xdeebfc: ldr             x0, [x0, #0x820]
    // 0xdeec00: StoreField: r1->field_13 = r0
    //     0xdeec00: stur            w0, [x1, #0x13]
    // 0xdeec04: r0 = Instance_MainAxisSize
    //     0xdeec04: add             x0, PP, #0x15, lsl #12  ; [pp+0x15828] Obj!MainAxisSize@12c4621
    //     0xdeec08: ldr             x0, [x0, #0x828]
    // 0xdeec0c: ArrayStore: r1[0] = r0  ; List_4
    //     0xdeec0c: stur            w0, [x1, #0x17]
    // 0xdeec10: r0 = Instance_CrossAxisAlignment
    //     0xdeec10: add             x0, PP, #0x15, lsl #12  ; [pp+0x15888] Obj!CrossAxisAlignment@12c44a1
    //     0xdeec14: ldr             x0, [x0, #0x888]
    // 0xdeec18: StoreField: r1->field_1b = r0
    //     0xdeec18: stur            w0, [x1, #0x1b]
    // 0xdeec1c: r0 = Instance_VerticalDirection
    //     0xdeec1c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xdeec20: ldr             x0, [x0, #0x838]
    // 0xdeec24: StoreField: r1->field_23 = r0
    //     0xdeec24: stur            w0, [x1, #0x23]
    // 0xdeec28: r0 = Instance_Clip
    //     0xdeec28: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xdeec2c: ldr             x0, [x0, #0x840]
    // 0xdeec30: StoreField: r1->field_2b = r0
    //     0xdeec30: stur            w0, [x1, #0x2b]
    // 0xdeec34: StoreField: r1->field_2f = rZR
    //     0xdeec34: stur            xzr, [x1, #0x2f]
    // 0xdeec38: ldur            x0, [fp, #-8]
    // 0xdeec3c: StoreField: r1->field_b = r0
    //     0xdeec3c: stur            w0, [x1, #0xb]
    // 0xdeec40: r0 = Semantics()
    //     0xdeec40: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xdeec44: stur            x0, [fp, #-8]
    // 0xdeec48: r16 = true
    //     0xdeec48: add             x16, NULL, #0x20  ; true
    // 0xdeec4c: r30 = true
    //     0xdeec4c: add             lr, NULL, #0x20  ; true
    // 0xdeec50: stp             lr, x16, [SP, #0x20]
    // 0xdeec54: ldur            x16, [fp, #-0x28]
    // 0xdeec58: ldur            lr, [fp, #-0x20]
    // 0xdeec5c: stp             lr, x16, [SP, #0x10]
    // 0xdeec60: ldur            x16, [fp, #-0x10]
    // 0xdeec64: ldur            lr, [fp, #-0x18]
    // 0xdeec68: stp             lr, x16, [SP]
    // 0xdeec6c: mov             x1, x0
    // 0xdeec70: r4 = const [0, 0x7, 0x6, 0x1, accessibilityFocusBlockType, 0x4, child, 0x6, container, 0x1, explicitChildNodes, 0x2, label, 0x5, liveRegion, 0x3, null]
    //     0xdeec70: add             x4, PP, #0xd0, lsl #12  ; [pp+0xd0720] List(17) [0, 0x7, 0x6, 0x1, "accessibilityFocusBlockType", 0x4, "child", 0x6, "container", 0x1, "explicitChildNodes", 0x2, "label", 0x5, "liveRegion", 0x3, Null]
    //     0xdeec74: ldr             x4, [x4, #0x720]
    // 0xdeec78: r0 = Semantics()
    //     0xdeec78: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xdeec7c: ldur            x0, [fp, #-8]
    // 0xdeec80: LeaveFrame
    //     0xdeec80: mov             SP, fp
    //     0xdeec84: ldp             fp, lr, [SP], #0x10
    // 0xdeec88: ret
    //     0xdeec88: ret             
    // 0xdeec8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdeec8c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdeec90: b               #0xdee4e0
    // 0xdeec94: r9 = _localizations
    //     0xdeec94: add             x9, PP, #0xd0, lsl #12  ; [pp+0xd0728] Field <_MonthPickerState@54260463._localizations@54260463>: late (offset: 0x24)
    //     0xdeec98: ldr             x9, [x9, #0x728]
    // 0xdeec9c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdeec9c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdeeca0: r9 = _localizations
    //     0xdeeca0: add             x9, PP, #0xd0, lsl #12  ; [pp+0xd0728] Field <_MonthPickerState@54260463._localizations@54260463>: late (offset: 0x24)
    //     0xdeeca4: ldr             x9, [x9, #0x728]
    // 0xdeeca8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdeeca8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdeecac: r9 = _localizations
    //     0xdeecac: add             x9, PP, #0xd0, lsl #12  ; [pp+0xd0728] Field <_MonthPickerState@54260463._localizations@54260463>: late (offset: 0x24)
    //     0xdeecb0: ldr             x9, [x9, #0x728]
    // 0xdeecb4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdeecb4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdeecb8: r9 = _localizations
    //     0xdeecb8: add             x9, PP, #0xd0, lsl #12  ; [pp+0xd0728] Field <_MonthPickerState@54260463._localizations@54260463>: late (offset: 0x24)
    //     0xdeecbc: ldr             x9, [x9, #0x728]
    // 0xdeecc0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdeecc0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdeecc4: r9 = _dayGridFocus
    //     0xdeecc4: add             x9, PP, #0xd0, lsl #12  ; [pp+0xd0730] Field <_MonthPickerState@54260463._dayGridFocus@54260463>: late (offset: 0x30)
    //     0xdeecc8: ldr             x9, [x9, #0x730]
    // 0xdeeccc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdeeccc: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdeecd0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdeecd0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdeecd4: r9 = _pageController
    //     0xdeecd4: add             x9, PP, #0xd0, lsl #12  ; [pp+0xd0738] Field <_MonthPickerState@54260463._pageController@54260463>: late (offset: 0x20)
    //     0xdeecd8: ldr             x9, [x9, #0x738]
    // 0xdeecdc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdeecdc: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdeece0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdeece0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _isDisplayingLastMonth(/* No info */) {
    // ** addr: 0xdef09c, size: 0x130
    // 0xdef09c: EnterFrame
    //     0xdef09c: stp             fp, lr, [SP, #-0x10]!
    //     0xdef0a0: mov             fp, SP
    // 0xdef0a4: AllocStack(0x18)
    //     0xdef0a4: sub             SP, SP, #0x18
    // 0xdef0a8: SetupParameters(_MonthPickerState this /* r1 => r0, fp-0x10 */)
    //     0xdef0a8: mov             x0, x1
    //     0xdef0ac: stur            x1, [fp, #-0x10]
    // 0xdef0b0: CheckStackOverflow
    //     0xdef0b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdef0b4: cmp             SP, x16
    //     0xdef0b8: b.ls            #0xdef1a8
    // 0xdef0bc: LoadField: r2 = r0->field_1b
    //     0xdef0bc: ldur            w2, [x0, #0x1b]
    // 0xdef0c0: DecompressPointer r2
    //     0xdef0c0: add             x2, x2, HEAP, lsl #32
    // 0xdef0c4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdef0c8: cmp             w2, w16
    // 0xdef0cc: b.eq            #0xdef1b0
    // 0xdef0d0: stur            x2, [fp, #-8]
    // 0xdef0d4: LoadField: r1 = r0->field_b
    //     0xdef0d4: ldur            w1, [x0, #0xb]
    // 0xdef0d8: DecompressPointer r1
    //     0xdef0d8: add             x1, x1, HEAP, lsl #32
    // 0xdef0dc: cmp             w1, NULL
    // 0xdef0e0: b.eq            #0xdef1bc
    // 0xdef0e4: ArrayLoad: r3 = r1[0]  ; List_4
    //     0xdef0e4: ldur            w3, [x1, #0x17]
    // 0xdef0e8: DecompressPointer r3
    //     0xdef0e8: add             x3, x3, HEAP, lsl #32
    // 0xdef0ec: mov             x1, x3
    // 0xdef0f0: r0 = _parts()
    //     0xdef0f0: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xdef0f4: mov             x2, x0
    // 0xdef0f8: LoadField: r0 = r2->field_b
    //     0xdef0f8: ldur            w0, [x2, #0xb]
    // 0xdef0fc: r1 = LoadInt32Instr(r0)
    //     0xdef0fc: sbfx            x1, x0, #1, #0x1f
    // 0xdef100: mov             x0, x1
    // 0xdef104: r1 = 8
    //     0xdef104: mov             x1, #8
    // 0xdef108: cmp             x1, x0
    // 0xdef10c: b.hs            #0xdef1c0
    // 0xdef110: LoadField: r0 = r2->field_2f
    //     0xdef110: ldur            w0, [x2, #0x2f]
    // 0xdef114: DecompressPointer r0
    //     0xdef114: add             x0, x0, HEAP, lsl #32
    // 0xdef118: ldur            x1, [fp, #-0x10]
    // 0xdef11c: stur            x0, [fp, #-0x18]
    // 0xdef120: LoadField: r2 = r1->field_b
    //     0xdef120: ldur            w2, [x1, #0xb]
    // 0xdef124: DecompressPointer r2
    //     0xdef124: add             x2, x2, HEAP, lsl #32
    // 0xdef128: cmp             w2, NULL
    // 0xdef12c: b.eq            #0xdef1c4
    // 0xdef130: ArrayLoad: r1 = r2[0]  ; List_4
    //     0xdef130: ldur            w1, [x2, #0x17]
    // 0xdef134: DecompressPointer r1
    //     0xdef134: add             x1, x1, HEAP, lsl #32
    // 0xdef138: r0 = _parts()
    //     0xdef138: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xdef13c: mov             x2, x0
    // 0xdef140: LoadField: r0 = r2->field_b
    //     0xdef140: ldur            w0, [x2, #0xb]
    // 0xdef144: r1 = LoadInt32Instr(r0)
    //     0xdef144: sbfx            x1, x0, #1, #0x1f
    // 0xdef148: mov             x0, x1
    // 0xdef14c: r1 = 7
    //     0xdef14c: mov             x1, #7
    // 0xdef150: cmp             x1, x0
    // 0xdef154: b.hs            #0xdef1c8
    // 0xdef158: LoadField: r0 = r2->field_2b
    //     0xdef158: ldur            w0, [x2, #0x2b]
    // 0xdef15c: DecompressPointer r0
    //     0xdef15c: add             x0, x0, HEAP, lsl #32
    // 0xdef160: ldur            x1, [fp, #-0x18]
    // 0xdef164: r2 = LoadInt32Instr(r1)
    //     0xdef164: sbfx            x2, x1, #1, #0x1f
    //     0xdef168: tbz             w1, #0, #0xdef170
    //     0xdef16c: ldur            x2, [x1, #7]
    // 0xdef170: r3 = LoadInt32Instr(r0)
    //     0xdef170: sbfx            x3, x0, #1, #0x1f
    //     0xdef174: tbz             w0, #0, #0xdef17c
    //     0xdef178: ldur            x3, [x0, #7]
    // 0xdef17c: r1 = Instance_GregorianCalendarDelegate
    //     0xdef17c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28538] Obj!GregorianCalendarDelegate@129edd1
    //     0xdef180: ldr             x1, [x1, #0x538]
    // 0xdef184: r0 = getMonth()
    //     0xdef184: bl              #0xdedac8  ; [package:flutter/src/material/date.dart] GregorianCalendarDelegate::getMonth
    // 0xdef188: ldur            x1, [fp, #-8]
    // 0xdef18c: mov             x2, x0
    // 0xdef190: r0 = isBefore()
    //     0xdef190: bl              #0xd183f0  ; [dart:core] DateTime::isBefore
    // 0xdef194: eor             x1, x0, #0x10
    // 0xdef198: mov             x0, x1
    // 0xdef19c: LeaveFrame
    //     0xdef19c: mov             SP, fp
    //     0xdef1a0: ldp             fp, lr, [SP], #0x10
    // 0xdef1a4: ret
    //     0xdef1a4: ret             
    // 0xdef1a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdef1a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdef1ac: b               #0xdef0bc
    // 0xdef1b0: r9 = _currentMonth
    //     0xdef1b0: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa3fa8] Field <_MonthPickerState@54260463._currentMonth@54260463>: late (offset: 0x1c)
    //     0xdef1b4: ldr             x9, [x9, #0xfa8]
    // 0xdef1b8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdef1b8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdef1bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdef1bc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdef1c0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdef1c0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdef1c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdef1c4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdef1c8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdef1c8: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  get _ _isDisplayingFirstMonth(/* No info */) {
    // ** addr: 0xdef1cc, size: 0x130
    // 0xdef1cc: EnterFrame
    //     0xdef1cc: stp             fp, lr, [SP, #-0x10]!
    //     0xdef1d0: mov             fp, SP
    // 0xdef1d4: AllocStack(0x18)
    //     0xdef1d4: sub             SP, SP, #0x18
    // 0xdef1d8: SetupParameters(_MonthPickerState this /* r1 => r0, fp-0x10 */)
    //     0xdef1d8: mov             x0, x1
    //     0xdef1dc: stur            x1, [fp, #-0x10]
    // 0xdef1e0: CheckStackOverflow
    //     0xdef1e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdef1e4: cmp             SP, x16
    //     0xdef1e8: b.ls            #0xdef2d8
    // 0xdef1ec: LoadField: r2 = r0->field_1b
    //     0xdef1ec: ldur            w2, [x0, #0x1b]
    // 0xdef1f0: DecompressPointer r2
    //     0xdef1f0: add             x2, x2, HEAP, lsl #32
    // 0xdef1f4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdef1f8: cmp             w2, w16
    // 0xdef1fc: b.eq            #0xdef2e0
    // 0xdef200: stur            x2, [fp, #-8]
    // 0xdef204: LoadField: r1 = r0->field_b
    //     0xdef204: ldur            w1, [x0, #0xb]
    // 0xdef208: DecompressPointer r1
    //     0xdef208: add             x1, x1, HEAP, lsl #32
    // 0xdef20c: cmp             w1, NULL
    // 0xdef210: b.eq            #0xdef2ec
    // 0xdef214: LoadField: r3 = r1->field_13
    //     0xdef214: ldur            w3, [x1, #0x13]
    // 0xdef218: DecompressPointer r3
    //     0xdef218: add             x3, x3, HEAP, lsl #32
    // 0xdef21c: mov             x1, x3
    // 0xdef220: r0 = _parts()
    //     0xdef220: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xdef224: mov             x2, x0
    // 0xdef228: LoadField: r0 = r2->field_b
    //     0xdef228: ldur            w0, [x2, #0xb]
    // 0xdef22c: r1 = LoadInt32Instr(r0)
    //     0xdef22c: sbfx            x1, x0, #1, #0x1f
    // 0xdef230: mov             x0, x1
    // 0xdef234: r1 = 8
    //     0xdef234: mov             x1, #8
    // 0xdef238: cmp             x1, x0
    // 0xdef23c: b.hs            #0xdef2f0
    // 0xdef240: LoadField: r0 = r2->field_2f
    //     0xdef240: ldur            w0, [x2, #0x2f]
    // 0xdef244: DecompressPointer r0
    //     0xdef244: add             x0, x0, HEAP, lsl #32
    // 0xdef248: ldur            x1, [fp, #-0x10]
    // 0xdef24c: stur            x0, [fp, #-0x18]
    // 0xdef250: LoadField: r2 = r1->field_b
    //     0xdef250: ldur            w2, [x1, #0xb]
    // 0xdef254: DecompressPointer r2
    //     0xdef254: add             x2, x2, HEAP, lsl #32
    // 0xdef258: cmp             w2, NULL
    // 0xdef25c: b.eq            #0xdef2f4
    // 0xdef260: LoadField: r1 = r2->field_13
    //     0xdef260: ldur            w1, [x2, #0x13]
    // 0xdef264: DecompressPointer r1
    //     0xdef264: add             x1, x1, HEAP, lsl #32
    // 0xdef268: r0 = _parts()
    //     0xdef268: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xdef26c: mov             x2, x0
    // 0xdef270: LoadField: r0 = r2->field_b
    //     0xdef270: ldur            w0, [x2, #0xb]
    // 0xdef274: r1 = LoadInt32Instr(r0)
    //     0xdef274: sbfx            x1, x0, #1, #0x1f
    // 0xdef278: mov             x0, x1
    // 0xdef27c: r1 = 7
    //     0xdef27c: mov             x1, #7
    // 0xdef280: cmp             x1, x0
    // 0xdef284: b.hs            #0xdef2f8
    // 0xdef288: LoadField: r0 = r2->field_2b
    //     0xdef288: ldur            w0, [x2, #0x2b]
    // 0xdef28c: DecompressPointer r0
    //     0xdef28c: add             x0, x0, HEAP, lsl #32
    // 0xdef290: ldur            x1, [fp, #-0x18]
    // 0xdef294: r2 = LoadInt32Instr(r1)
    //     0xdef294: sbfx            x2, x1, #1, #0x1f
    //     0xdef298: tbz             w1, #0, #0xdef2a0
    //     0xdef29c: ldur            x2, [x1, #7]
    // 0xdef2a0: r3 = LoadInt32Instr(r0)
    //     0xdef2a0: sbfx            x3, x0, #1, #0x1f
    //     0xdef2a4: tbz             w0, #0, #0xdef2ac
    //     0xdef2a8: ldur            x3, [x0, #7]
    // 0xdef2ac: r1 = Instance_GregorianCalendarDelegate
    //     0xdef2ac: add             x1, PP, #0x28, lsl #12  ; [pp+0x28538] Obj!GregorianCalendarDelegate@129edd1
    //     0xdef2b0: ldr             x1, [x1, #0x538]
    // 0xdef2b4: r0 = getMonth()
    //     0xdef2b4: bl              #0xdedac8  ; [package:flutter/src/material/date.dart] GregorianCalendarDelegate::getMonth
    // 0xdef2b8: ldur            x1, [fp, #-8]
    // 0xdef2bc: mov             x2, x0
    // 0xdef2c0: r0 = isAfter()
    //     0xdef2c0: bl              #0xd183d4  ; [dart:core] DateTime::isAfter
    // 0xdef2c4: eor             x1, x0, #0x10
    // 0xdef2c8: mov             x0, x1
    // 0xdef2cc: LeaveFrame
    //     0xdef2cc: mov             SP, fp
    //     0xdef2d0: ldp             fp, lr, [SP], #0x10
    // 0xdef2d4: ret
    //     0xdef2d4: ret             
    // 0xdef2d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdef2d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdef2dc: b               #0xdef1ec
    // 0xdef2e0: r9 = _currentMonth
    //     0xdef2e0: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa3fa8] Field <_MonthPickerState@54260463._currentMonth@54260463>: late (offset: 0x1c)
    //     0xdef2e4: ldr             x9, [x9, #0xfa8]
    // 0xdef2e8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdef2e8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdef2ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdef2ec: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdef2f0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdef2f0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdef2f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdef2f4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdef2f8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdef2f8: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleGridFocusChange(dynamic, bool) {
    // ** addr: 0xdef2fc, size: 0x3c
    // 0xdef2fc: EnterFrame
    //     0xdef2fc: stp             fp, lr, [SP, #-0x10]!
    //     0xdef300: mov             fp, SP
    // 0xdef304: ldr             x0, [fp, #0x18]
    // 0xdef308: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdef308: ldur            w1, [x0, #0x17]
    // 0xdef30c: DecompressPointer r1
    //     0xdef30c: add             x1, x1, HEAP, lsl #32
    // 0xdef310: CheckStackOverflow
    //     0xdef310: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdef314: cmp             SP, x16
    //     0xdef318: b.ls            #0xdef330
    // 0xdef31c: ldr             x2, [fp, #0x10]
    // 0xdef320: r0 = _handleGridFocusChange()
    //     0xdef320: bl              #0xdef338  ; [package:flutter/src/material/calendar_date_picker.dart] _MonthPickerState::_handleGridFocusChange
    // 0xdef324: LeaveFrame
    //     0xdef324: mov             SP, fp
    //     0xdef328: ldp             fp, lr, [SP], #0x10
    // 0xdef32c: ret
    //     0xdef32c: ret             
    // 0xdef330: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdef330: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdef334: b               #0xdef31c
  }
  _ _handleGridFocusChange(/* No info */) {
    // ** addr: 0xdef338, size: 0x70
    // 0xdef338: EnterFrame
    //     0xdef338: stp             fp, lr, [SP, #-0x10]!
    //     0xdef33c: mov             fp, SP
    // 0xdef340: AllocStack(0x10)
    //     0xdef340: sub             SP, SP, #0x10
    // 0xdef344: SetupParameters(_MonthPickerState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xdef344: stur            x1, [fp, #-8]
    //     0xdef348: stur            x2, [fp, #-0x10]
    // 0xdef34c: CheckStackOverflow
    //     0xdef34c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdef350: cmp             SP, x16
    //     0xdef354: b.ls            #0xdef3a0
    // 0xdef358: r1 = 2
    //     0xdef358: mov             x1, #2
    // 0xdef35c: r0 = AllocateContext()
    //     0xdef35c: bl              #0x13de838  ; AllocateContextStub
    // 0xdef360: mov             x1, x0
    // 0xdef364: ldur            x0, [fp, #-8]
    // 0xdef368: StoreField: r1->field_f = r0
    //     0xdef368: stur            w0, [x1, #0xf]
    // 0xdef36c: ldur            x2, [fp, #-0x10]
    // 0xdef370: StoreField: r1->field_13 = r2
    //     0xdef370: stur            w2, [x1, #0x13]
    // 0xdef374: mov             x2, x1
    // 0xdef378: r1 = Function '<anonymous closure>':.
    //     0xdef378: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3fa0] AnonymousClosure: (0xdef3a8), in [package:flutter/src/material/calendar_date_picker.dart] _MonthPickerState::_handleGridFocusChange (0xdef338)
    //     0xdef37c: ldr             x1, [x1, #0xfa0]
    // 0xdef380: r0 = AllocateClosure()
    //     0xdef380: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdef384: ldur            x1, [fp, #-8]
    // 0xdef388: mov             x2, x0
    // 0xdef38c: r0 = setState()
    //     0xdef38c: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xdef390: r0 = Null
    //     0xdef390: mov             x0, NULL
    // 0xdef394: LeaveFrame
    //     0xdef394: mov             SP, fp
    //     0xdef398: ldp             fp, lr, [SP], #0x10
    // 0xdef39c: ret
    //     0xdef39c: ret             
    // 0xdef3a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdef3a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdef3a4: b               #0xdef358
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xdef3a8, size: 0x278
    // 0xdef3a8: EnterFrame
    //     0xdef3a8: stp             fp, lr, [SP, #-0x10]!
    //     0xdef3ac: mov             fp, SP
    // 0xdef3b0: AllocStack(0x18)
    //     0xdef3b0: sub             SP, SP, #0x18
    // 0xdef3b4: SetupParameters([dynamic _ /* r0 */])
    //     0xdef3b4: ldr             x0, [fp, #0x10]
    //     0xdef3b8: ldur            w4, [x0, #0x17]
    //     0xdef3bc: add             x4, x4, HEAP, lsl #32
    //     0xdef3c0: stur            x4, [fp, #-8]
    // 0xdef3c4: CheckStackOverflow
    //     0xdef3c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdef3c8: cmp             SP, x16
    //     0xdef3cc: b.ls            #0xdef5d4
    // 0xdef3d0: LoadField: r0 = r4->field_13
    //     0xdef3d0: ldur            w0, [x4, #0x13]
    // 0xdef3d4: DecompressPointer r0
    //     0xdef3d4: add             x0, x0, HEAP, lsl #32
    // 0xdef3d8: tbnz            w0, #4, #0xdef5c4
    // 0xdef3dc: LoadField: r0 = r4->field_f
    //     0xdef3dc: ldur            w0, [x4, #0xf]
    // 0xdef3e0: DecompressPointer r0
    //     0xdef3e0: add             x0, x0, HEAP, lsl #32
    // 0xdef3e4: LoadField: r1 = r0->field_33
    //     0xdef3e4: ldur            w1, [x0, #0x33]
    // 0xdef3e8: DecompressPointer r1
    //     0xdef3e8: add             x1, x1, HEAP, lsl #32
    // 0xdef3ec: cmp             w1, NULL
    // 0xdef3f0: b.ne            #0xdef5c4
    // 0xdef3f4: LoadField: r1 = r0->field_b
    //     0xdef3f4: ldur            w1, [x0, #0xb]
    // 0xdef3f8: DecompressPointer r1
    //     0xdef3f8: add             x1, x1, HEAP, lsl #32
    // 0xdef3fc: cmp             w1, NULL
    // 0xdef400: b.eq            #0xdef5dc
    // 0xdef404: LoadField: r2 = r1->field_1b
    //     0xdef404: ldur            w2, [x1, #0x1b]
    // 0xdef408: DecompressPointer r2
    //     0xdef408: add             x2, x2, HEAP, lsl #32
    // 0xdef40c: LoadField: r3 = r0->field_1b
    //     0xdef40c: ldur            w3, [x0, #0x1b]
    // 0xdef410: DecompressPointer r3
    //     0xdef410: add             x3, x3, HEAP, lsl #32
    // 0xdef414: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdef418: cmp             w3, w16
    // 0xdef41c: b.eq            #0xdef5e0
    // 0xdef420: r1 = Instance_GregorianCalendarDelegate
    //     0xdef420: add             x1, PP, #0x28, lsl #12  ; [pp+0x28538] Obj!GregorianCalendarDelegate@129edd1
    //     0xdef424: ldr             x1, [x1, #0x538]
    // 0xdef428: r0 = isSameMonth()
    //     0xdef428: bl              #0xdef958  ; [package:flutter/src/material/date.dart] CalendarDelegate::isSameMonth
    // 0xdef42c: tbnz            w0, #4, #0xdef478
    // 0xdef430: ldur            x0, [fp, #-8]
    // 0xdef434: LoadField: r1 = r0->field_f
    //     0xdef434: ldur            w1, [x0, #0xf]
    // 0xdef438: DecompressPointer r1
    //     0xdef438: add             x1, x1, HEAP, lsl #32
    // 0xdef43c: LoadField: r0 = r1->field_b
    //     0xdef43c: ldur            w0, [x1, #0xb]
    // 0xdef440: DecompressPointer r0
    //     0xdef440: add             x0, x0, HEAP, lsl #32
    // 0xdef444: cmp             w0, NULL
    // 0xdef448: b.eq            #0xdef5ec
    // 0xdef44c: LoadField: r2 = r0->field_1b
    //     0xdef44c: ldur            w2, [x0, #0x1b]
    // 0xdef450: DecompressPointer r2
    //     0xdef450: add             x2, x2, HEAP, lsl #32
    // 0xdef454: mov             x0, x2
    // 0xdef458: StoreField: r1->field_33 = r0
    //     0xdef458: stur            w0, [x1, #0x33]
    //     0xdef45c: ldurb           w16, [x1, #-1]
    //     0xdef460: ldurb           w17, [x0, #-1]
    //     0xdef464: and             x16, x17, x16, lsr #2
    //     0xdef468: tst             x16, HEAP, lsr #32
    //     0xdef46c: b.eq            #0xdef474
    //     0xdef470: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdef474: b               #0xdef5c4
    // 0xdef478: ldur            x0, [fp, #-8]
    // 0xdef47c: LoadField: r1 = r0->field_f
    //     0xdef47c: ldur            w1, [x0, #0xf]
    // 0xdef480: DecompressPointer r1
    //     0xdef480: add             x1, x1, HEAP, lsl #32
    // 0xdef484: LoadField: r2 = r1->field_b
    //     0xdef484: ldur            w2, [x1, #0xb]
    // 0xdef488: DecompressPointer r2
    //     0xdef488: add             x2, x2, HEAP, lsl #32
    // 0xdef48c: cmp             w2, NULL
    // 0xdef490: b.eq            #0xdef5f0
    // 0xdef494: LoadField: r3 = r2->field_f
    //     0xdef494: ldur            w3, [x2, #0xf]
    // 0xdef498: DecompressPointer r3
    //     0xdef498: add             x3, x3, HEAP, lsl #32
    // 0xdef49c: LoadField: r2 = r1->field_1b
    //     0xdef49c: ldur            w2, [x1, #0x1b]
    // 0xdef4a0: DecompressPointer r2
    //     0xdef4a0: add             x2, x2, HEAP, lsl #32
    // 0xdef4a4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdef4a8: cmp             w2, w16
    // 0xdef4ac: b.eq            #0xdef5f4
    // 0xdef4b0: mov             x16, x2
    // 0xdef4b4: mov             x2, x3
    // 0xdef4b8: mov             x3, x16
    // 0xdef4bc: r1 = Instance_GregorianCalendarDelegate
    //     0xdef4bc: add             x1, PP, #0x28, lsl #12  ; [pp+0x28538] Obj!GregorianCalendarDelegate@129edd1
    //     0xdef4c0: ldr             x1, [x1, #0x538]
    // 0xdef4c4: r0 = isSameMonth()
    //     0xdef4c4: bl              #0xdef958  ; [package:flutter/src/material/date.dart] CalendarDelegate::isSameMonth
    // 0xdef4c8: tbnz            w0, #4, #0xdef574
    // 0xdef4cc: ldur            x0, [fp, #-8]
    // 0xdef4d0: LoadField: r2 = r0->field_f
    //     0xdef4d0: ldur            w2, [x0, #0xf]
    // 0xdef4d4: DecompressPointer r2
    //     0xdef4d4: add             x2, x2, HEAP, lsl #32
    // 0xdef4d8: stur            x2, [fp, #-0x18]
    // 0xdef4dc: LoadField: r0 = r2->field_1b
    //     0xdef4dc: ldur            w0, [x2, #0x1b]
    // 0xdef4e0: DecompressPointer r0
    //     0xdef4e0: add             x0, x0, HEAP, lsl #32
    // 0xdef4e4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdef4e8: cmp             w0, w16
    // 0xdef4ec: b.eq            #0xdef600
    // 0xdef4f0: stur            x0, [fp, #-0x10]
    // 0xdef4f4: LoadField: r1 = r2->field_b
    //     0xdef4f4: ldur            w1, [x2, #0xb]
    // 0xdef4f8: DecompressPointer r1
    //     0xdef4f8: add             x1, x1, HEAP, lsl #32
    // 0xdef4fc: cmp             w1, NULL
    // 0xdef500: b.eq            #0xdef60c
    // 0xdef504: LoadField: r3 = r1->field_f
    //     0xdef504: ldur            w3, [x1, #0xf]
    // 0xdef508: DecompressPointer r3
    //     0xdef508: add             x3, x3, HEAP, lsl #32
    // 0xdef50c: mov             x1, x3
    // 0xdef510: r0 = _parts()
    //     0xdef510: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xdef514: mov             x2, x0
    // 0xdef518: LoadField: r0 = r2->field_b
    //     0xdef518: ldur            w0, [x2, #0xb]
    // 0xdef51c: r1 = LoadInt32Instr(r0)
    //     0xdef51c: sbfx            x1, x0, #1, #0x1f
    // 0xdef520: mov             x0, x1
    // 0xdef524: r1 = 5
    //     0xdef524: mov             x1, #5
    // 0xdef528: cmp             x1, x0
    // 0xdef52c: b.hs            #0xdef610
    // 0xdef530: LoadField: r0 = r2->field_23
    //     0xdef530: ldur            w0, [x2, #0x23]
    // 0xdef534: DecompressPointer r0
    //     0xdef534: add             x0, x0, HEAP, lsl #32
    // 0xdef538: r3 = LoadInt32Instr(r0)
    //     0xdef538: sbfx            x3, x0, #1, #0x1f
    //     0xdef53c: tbz             w0, #0, #0xdef544
    //     0xdef540: ldur            x3, [x0, #7]
    // 0xdef544: ldur            x1, [fp, #-0x18]
    // 0xdef548: ldur            x2, [fp, #-0x10]
    // 0xdef54c: r0 = _focusableDayForMonth()
    //     0xdef54c: bl              #0xdef620  ; [package:flutter/src/material/calendar_date_picker.dart] _MonthPickerState::_focusableDayForMonth
    // 0xdef550: ldur            x1, [fp, #-0x18]
    // 0xdef554: StoreField: r1->field_33 = r0
    //     0xdef554: stur            w0, [x1, #0x33]
    //     0xdef558: ldurb           w16, [x1, #-1]
    //     0xdef55c: ldurb           w17, [x0, #-1]
    //     0xdef560: and             x16, x17, x16, lsr #2
    //     0xdef564: tst             x16, HEAP, lsr #32
    //     0xdef568: b.eq            #0xdef570
    //     0xdef56c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdef570: b               #0xdef5c4
    // 0xdef574: ldur            x0, [fp, #-8]
    // 0xdef578: LoadField: r4 = r0->field_f
    //     0xdef578: ldur            w4, [x0, #0xf]
    // 0xdef57c: DecompressPointer r4
    //     0xdef57c: add             x4, x4, HEAP, lsl #32
    // 0xdef580: stur            x4, [fp, #-0x10]
    // 0xdef584: LoadField: r2 = r4->field_1b
    //     0xdef584: ldur            w2, [x4, #0x1b]
    // 0xdef588: DecompressPointer r2
    //     0xdef588: add             x2, x2, HEAP, lsl #32
    // 0xdef58c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdef590: cmp             w2, w16
    // 0xdef594: b.eq            #0xdef614
    // 0xdef598: mov             x1, x4
    // 0xdef59c: r3 = 1
    //     0xdef59c: mov             x3, #1
    // 0xdef5a0: r0 = _focusableDayForMonth()
    //     0xdef5a0: bl              #0xdef620  ; [package:flutter/src/material/calendar_date_picker.dart] _MonthPickerState::_focusableDayForMonth
    // 0xdef5a4: ldur            x1, [fp, #-0x10]
    // 0xdef5a8: StoreField: r1->field_33 = r0
    //     0xdef5a8: stur            w0, [x1, #0x33]
    //     0xdef5ac: ldurb           w16, [x1, #-1]
    //     0xdef5b0: ldurb           w17, [x0, #-1]
    //     0xdef5b4: and             x16, x17, x16, lsr #2
    //     0xdef5b8: tst             x16, HEAP, lsr #32
    //     0xdef5bc: b.eq            #0xdef5c4
    //     0xdef5c0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdef5c4: r0 = Null
    //     0xdef5c4: mov             x0, NULL
    // 0xdef5c8: LeaveFrame
    //     0xdef5c8: mov             SP, fp
    //     0xdef5cc: ldp             fp, lr, [SP], #0x10
    // 0xdef5d0: ret
    //     0xdef5d0: ret             
    // 0xdef5d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdef5d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdef5d8: b               #0xdef3d0
    // 0xdef5dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdef5dc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdef5e0: r9 = _currentMonth
    //     0xdef5e0: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa3fa8] Field <_MonthPickerState@54260463._currentMonth@54260463>: late (offset: 0x1c)
    //     0xdef5e4: ldr             x9, [x9, #0xfa8]
    // 0xdef5e8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdef5e8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdef5ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdef5ec: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdef5f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdef5f0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdef5f4: r9 = _currentMonth
    //     0xdef5f4: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa3fa8] Field <_MonthPickerState@54260463._currentMonth@54260463>: late (offset: 0x1c)
    //     0xdef5f8: ldr             x9, [x9, #0xfa8]
    // 0xdef5fc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdef5fc: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdef600: r9 = _currentMonth
    //     0xdef600: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa3fa8] Field <_MonthPickerState@54260463._currentMonth@54260463>: late (offset: 0x1c)
    //     0xdef604: ldr             x9, [x9, #0xfa8]
    // 0xdef608: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdef608: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdef60c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdef60c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdef610: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdef610: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdef614: r9 = _currentMonth
    //     0xdef614: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa3fa8] Field <_MonthPickerState@54260463._currentMonth@54260463>: late (offset: 0x1c)
    //     0xdef618: ldr             x9, [x9, #0xfa8]
    // 0xdef61c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdef61c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _focusableDayForMonth(/* No info */) {
    // ** addr: 0xdef620, size: 0x338
    // 0xdef620: EnterFrame
    //     0xdef620: stp             fp, lr, [SP, #-0x10]!
    //     0xdef624: mov             fp, SP
    // 0xdef628: AllocStack(0x20)
    //     0xdef628: sub             SP, SP, #0x20
    // 0xdef62c: SetupParameters(_MonthPickerState this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r5, fp-0x18 */)
    //     0xdef62c: mov             x0, x2
    //     0xdef630: stur            x2, [fp, #-0x10]
    //     0xdef634: mov             x2, x1
    //     0xdef638: mov             x5, x3
    //     0xdef63c: stur            x1, [fp, #-8]
    //     0xdef640: stur            x3, [fp, #-0x18]
    // 0xdef644: CheckStackOverflow
    //     0xdef644: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdef648: cmp             SP, x16
    //     0xdef64c: b.ls            #0xdef908
    // 0xdef650: LoadField: r1 = r2->field_b
    //     0xdef650: ldur            w1, [x2, #0xb]
    // 0xdef654: DecompressPointer r1
    //     0xdef654: add             x1, x1, HEAP, lsl #32
    // 0xdef658: cmp             w1, NULL
    // 0xdef65c: b.eq            #0xdef910
    // 0xdef660: mov             x1, x0
    // 0xdef664: r0 = _parts()
    //     0xdef664: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xdef668: mov             x2, x0
    // 0xdef66c: LoadField: r0 = r2->field_b
    //     0xdef66c: ldur            w0, [x2, #0xb]
    // 0xdef670: r1 = LoadInt32Instr(r0)
    //     0xdef670: sbfx            x1, x0, #1, #0x1f
    // 0xdef674: mov             x0, x1
    // 0xdef678: r1 = 8
    //     0xdef678: mov             x1, #8
    // 0xdef67c: cmp             x1, x0
    // 0xdef680: b.hs            #0xdef914
    // 0xdef684: LoadField: r0 = r2->field_2f
    //     0xdef684: ldur            w0, [x2, #0x2f]
    // 0xdef688: DecompressPointer r0
    //     0xdef688: add             x0, x0, HEAP, lsl #32
    // 0xdef68c: ldur            x1, [fp, #-0x10]
    // 0xdef690: stur            x0, [fp, #-0x20]
    // 0xdef694: r0 = _parts()
    //     0xdef694: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xdef698: mov             x2, x0
    // 0xdef69c: LoadField: r0 = r2->field_b
    //     0xdef69c: ldur            w0, [x2, #0xb]
    // 0xdef6a0: r1 = LoadInt32Instr(r0)
    //     0xdef6a0: sbfx            x1, x0, #1, #0x1f
    // 0xdef6a4: mov             x0, x1
    // 0xdef6a8: r1 = 7
    //     0xdef6a8: mov             x1, #7
    // 0xdef6ac: cmp             x1, x0
    // 0xdef6b0: b.hs            #0xdef918
    // 0xdef6b4: LoadField: r0 = r2->field_2b
    //     0xdef6b4: ldur            w0, [x2, #0x2b]
    // 0xdef6b8: DecompressPointer r0
    //     0xdef6b8: add             x0, x0, HEAP, lsl #32
    // 0xdef6bc: r1 = LoadInt32Instr(r0)
    //     0xdef6bc: sbfx            x1, x0, #1, #0x1f
    //     0xdef6c0: tbz             w0, #0, #0xdef6c8
    //     0xdef6c4: ldur            x1, [x0, #7]
    // 0xdef6c8: cmp             x1, #2
    // 0xdef6cc: b.ne            #0xdef728
    // 0xdef6d0: ldur            x0, [fp, #-0x20]
    // 0xdef6d4: r1 = LoadInt32Instr(r0)
    //     0xdef6d4: sbfx            x1, x0, #1, #0x1f
    //     0xdef6d8: tbz             w0, #0, #0xdef6e0
    //     0xdef6dc: ldur            x1, [x0, #7]
    // 0xdef6e0: tst             x1, #3
    // 0xdef6e4: b.ne            #0xdef700
    // 0xdef6e8: r0 = 100
    //     0xdef6e8: mov             x0, #0x64
    // 0xdef6ec: sdiv            x3, x1, x0
    // 0xdef6f0: msub            x2, x3, x0, x1
    // 0xdef6f4: cmp             x2, xzr
    // 0xdef6f8: b.lt            #0xdef91c
    // 0xdef6fc: cbnz            x2, #0xdef718
    // 0xdef700: r0 = 400
    //     0xdef700: mov             x0, #0x190
    // 0xdef704: sdiv            x3, x1, x0
    // 0xdef708: msub            x2, x3, x0, x1
    // 0xdef70c: cmp             x2, xzr
    // 0xdef710: b.lt            #0xdef924
    // 0xdef714: cbnz            x2, #0xdef720
    // 0xdef718: r0 = 29
    //     0xdef718: mov             x0, #0x1d
    // 0xdef71c: b               #0xdef760
    // 0xdef720: r0 = 28
    //     0xdef720: mov             x0, #0x1c
    // 0xdef724: b               #0xdef760
    // 0xdef728: r2 = const [0x1f, 0xffffffffffffffff, 0x1f, 0x1e, 0x1f, 0x1e, 0x1f, 0x1f, 0x1e, 0x1f, 0x1e, 0x1f]
    //     0xdef728: add             x2, PP, #0xa3, lsl #12  ; [pp+0xa3fb0] List<int>(12)
    //     0xdef72c: ldr             x2, [x2, #0xfb0]
    // 0xdef730: sub             x3, x1, #1
    // 0xdef734: mov             x1, x3
    // 0xdef738: r0 = 12
    //     0xdef738: mov             x0, #0xc
    // 0xdef73c: cmp             x1, x0
    // 0xdef740: b.hs            #0xdef92c
    // 0xdef744: ArrayLoad: r0 = r2[r3]  ; Unknown_4
    //     0xdef744: add             x16, x2, x3, lsl #2
    //     0xdef748: ldur            w0, [x16, #0xf]
    // 0xdef74c: DecompressPointer r0
    //     0xdef74c: add             x0, x0, HEAP, lsl #32
    // 0xdef750: r1 = LoadInt32Instr(r0)
    //     0xdef750: sbfx            x1, x0, #1, #0x1f
    //     0xdef754: tbz             w0, #0, #0xdef75c
    //     0xdef758: ldur            x1, [x0, #7]
    // 0xdef75c: mov             x0, x1
    // 0xdef760: ldur            x5, [fp, #-0x18]
    // 0xdef764: cmp             x5, x0
    // 0xdef768: b.gt            #0xdef828
    // 0xdef76c: ldur            x0, [fp, #-8]
    // 0xdef770: LoadField: r1 = r0->field_b
    //     0xdef770: ldur            w1, [x0, #0xb]
    // 0xdef774: DecompressPointer r1
    //     0xdef774: add             x1, x1, HEAP, lsl #32
    // 0xdef778: cmp             w1, NULL
    // 0xdef77c: b.eq            #0xdef930
    // 0xdef780: ldur            x1, [fp, #-0x10]
    // 0xdef784: r0 = _parts()
    //     0xdef784: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xdef788: mov             x2, x0
    // 0xdef78c: LoadField: r0 = r2->field_b
    //     0xdef78c: ldur            w0, [x2, #0xb]
    // 0xdef790: r1 = LoadInt32Instr(r0)
    //     0xdef790: sbfx            x1, x0, #1, #0x1f
    // 0xdef794: mov             x0, x1
    // 0xdef798: r1 = 8
    //     0xdef798: mov             x1, #8
    // 0xdef79c: cmp             x1, x0
    // 0xdef7a0: b.hs            #0xdef934
    // 0xdef7a4: LoadField: r0 = r2->field_2f
    //     0xdef7a4: ldur            w0, [x2, #0x2f]
    // 0xdef7a8: DecompressPointer r0
    //     0xdef7a8: add             x0, x0, HEAP, lsl #32
    // 0xdef7ac: ldur            x1, [fp, #-0x10]
    // 0xdef7b0: stur            x0, [fp, #-0x20]
    // 0xdef7b4: r0 = _parts()
    //     0xdef7b4: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xdef7b8: mov             x2, x0
    // 0xdef7bc: LoadField: r0 = r2->field_b
    //     0xdef7bc: ldur            w0, [x2, #0xb]
    // 0xdef7c0: r1 = LoadInt32Instr(r0)
    //     0xdef7c0: sbfx            x1, x0, #1, #0x1f
    // 0xdef7c4: mov             x0, x1
    // 0xdef7c8: r1 = 7
    //     0xdef7c8: mov             x1, #7
    // 0xdef7cc: cmp             x1, x0
    // 0xdef7d0: b.hs            #0xdef938
    // 0xdef7d4: LoadField: r0 = r2->field_2b
    //     0xdef7d4: ldur            w0, [x2, #0x2b]
    // 0xdef7d8: DecompressPointer r0
    //     0xdef7d8: add             x0, x0, HEAP, lsl #32
    // 0xdef7dc: ldur            x1, [fp, #-0x20]
    // 0xdef7e0: r2 = LoadInt32Instr(r1)
    //     0xdef7e0: sbfx            x2, x1, #1, #0x1f
    //     0xdef7e4: tbz             w1, #0, #0xdef7ec
    //     0xdef7e8: ldur            x2, [x1, #7]
    // 0xdef7ec: r3 = LoadInt32Instr(r0)
    //     0xdef7ec: sbfx            x3, x0, #1, #0x1f
    //     0xdef7f0: tbz             w0, #0, #0xdef7f8
    //     0xdef7f4: ldur            x3, [x0, #7]
    // 0xdef7f8: ldur            x5, [fp, #-0x18]
    // 0xdef7fc: r1 = Instance_GregorianCalendarDelegate
    //     0xdef7fc: add             x1, PP, #0x28, lsl #12  ; [pp+0x28538] Obj!GregorianCalendarDelegate@129edd1
    //     0xdef800: ldr             x1, [x1, #0x538]
    // 0xdef804: r0 = getDay()
    //     0xdef804: bl              #0xded5e4  ; [package:flutter/src/material/date.dart] GregorianCalendarDelegate::getDay
    // 0xdef808: ldur            x2, [fp, #-8]
    // 0xdef80c: LoadField: r1 = r2->field_b
    //     0xdef80c: ldur            w1, [x2, #0xb]
    // 0xdef810: DecompressPointer r1
    //     0xdef810: add             x1, x1, HEAP, lsl #32
    // 0xdef814: cmp             w1, NULL
    // 0xdef818: b.eq            #0xdef93c
    // 0xdef81c: LeaveFrame
    //     0xdef81c: mov             SP, fp
    //     0xdef820: ldp             fp, lr, [SP], #0x10
    // 0xdef824: ret
    //     0xdef824: ret             
    // 0xdef828: ldur            x2, [fp, #-8]
    // 0xdef82c: CheckStackOverflow
    //     0xdef82c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdef830: cmp             SP, x16
    //     0xdef834: b.ls            #0xdef940
    // 0xdef838: cmp             x0, #1
    // 0xdef83c: b.lt            #0xdef8f8
    // 0xdef840: LoadField: r0 = r2->field_b
    //     0xdef840: ldur            w0, [x2, #0xb]
    // 0xdef844: DecompressPointer r0
    //     0xdef844: add             x0, x0, HEAP, lsl #32
    // 0xdef848: cmp             w0, NULL
    // 0xdef84c: b.eq            #0xdef948
    // 0xdef850: ldur            x1, [fp, #-0x10]
    // 0xdef854: r0 = _parts()
    //     0xdef854: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xdef858: mov             x2, x0
    // 0xdef85c: LoadField: r0 = r2->field_b
    //     0xdef85c: ldur            w0, [x2, #0xb]
    // 0xdef860: r1 = LoadInt32Instr(r0)
    //     0xdef860: sbfx            x1, x0, #1, #0x1f
    // 0xdef864: mov             x0, x1
    // 0xdef868: r1 = 8
    //     0xdef868: mov             x1, #8
    // 0xdef86c: cmp             x1, x0
    // 0xdef870: b.hs            #0xdef94c
    // 0xdef874: LoadField: r0 = r2->field_2f
    //     0xdef874: ldur            w0, [x2, #0x2f]
    // 0xdef878: DecompressPointer r0
    //     0xdef878: add             x0, x0, HEAP, lsl #32
    // 0xdef87c: ldur            x1, [fp, #-0x10]
    // 0xdef880: stur            x0, [fp, #-0x20]
    // 0xdef884: r0 = _parts()
    //     0xdef884: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xdef888: mov             x2, x0
    // 0xdef88c: LoadField: r0 = r2->field_b
    //     0xdef88c: ldur            w0, [x2, #0xb]
    // 0xdef890: r1 = LoadInt32Instr(r0)
    //     0xdef890: sbfx            x1, x0, #1, #0x1f
    // 0xdef894: mov             x0, x1
    // 0xdef898: r1 = 7
    //     0xdef898: mov             x1, #7
    // 0xdef89c: cmp             x1, x0
    // 0xdef8a0: b.hs            #0xdef950
    // 0xdef8a4: LoadField: r0 = r2->field_2b
    //     0xdef8a4: ldur            w0, [x2, #0x2b]
    // 0xdef8a8: DecompressPointer r0
    //     0xdef8a8: add             x0, x0, HEAP, lsl #32
    // 0xdef8ac: ldur            x1, [fp, #-0x20]
    // 0xdef8b0: r2 = LoadInt32Instr(r1)
    //     0xdef8b0: sbfx            x2, x1, #1, #0x1f
    //     0xdef8b4: tbz             w1, #0, #0xdef8bc
    //     0xdef8b8: ldur            x2, [x1, #7]
    // 0xdef8bc: r3 = LoadInt32Instr(r0)
    //     0xdef8bc: sbfx            x3, x0, #1, #0x1f
    //     0xdef8c0: tbz             w0, #0, #0xdef8c8
    //     0xdef8c4: ldur            x3, [x0, #7]
    // 0xdef8c8: r1 = Instance_GregorianCalendarDelegate
    //     0xdef8c8: add             x1, PP, #0x28, lsl #12  ; [pp+0x28538] Obj!GregorianCalendarDelegate@129edd1
    //     0xdef8cc: ldr             x1, [x1, #0x538]
    // 0xdef8d0: r5 = 1
    //     0xdef8d0: mov             x5, #1
    // 0xdef8d4: r0 = getDay()
    //     0xdef8d4: bl              #0xded5e4  ; [package:flutter/src/material/date.dart] GregorianCalendarDelegate::getDay
    // 0xdef8d8: ldur            x1, [fp, #-8]
    // 0xdef8dc: LoadField: r2 = r1->field_b
    //     0xdef8dc: ldur            w2, [x1, #0xb]
    // 0xdef8e0: DecompressPointer r2
    //     0xdef8e0: add             x2, x2, HEAP, lsl #32
    // 0xdef8e4: cmp             w2, NULL
    // 0xdef8e8: b.eq            #0xdef954
    // 0xdef8ec: LeaveFrame
    //     0xdef8ec: mov             SP, fp
    //     0xdef8f0: ldp             fp, lr, [SP], #0x10
    // 0xdef8f4: ret
    //     0xdef8f4: ret             
    // 0xdef8f8: r0 = Null
    //     0xdef8f8: mov             x0, NULL
    // 0xdef8fc: LeaveFrame
    //     0xdef8fc: mov             SP, fp
    //     0xdef900: ldp             fp, lr, [SP], #0x10
    // 0xdef904: ret
    //     0xdef904: ret             
    // 0xdef908: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdef908: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdef90c: b               #0xdef650
    // 0xdef910: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdef910: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdef914: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdef914: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdef918: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdef918: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdef91c: add             x2, x2, x0
    // 0xdef920: b               #0xdef6fc
    // 0xdef924: add             x2, x2, x0
    // 0xdef928: b               #0xdef714
    // 0xdef92c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdef92c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdef930: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdef930: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdef934: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdef934: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdef938: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdef938: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdef93c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdef93c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdef940: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdef940: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdef944: b               #0xdef838
    // 0xdef948: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdef948: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdef94c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdef94c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdef950: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdef950: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdef954: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdef954: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleMonthPageChanged(dynamic, int) {
    // ** addr: 0xdefb9c, size: 0x3c
    // 0xdefb9c: EnterFrame
    //     0xdefb9c: stp             fp, lr, [SP, #-0x10]!
    //     0xdefba0: mov             fp, SP
    // 0xdefba4: ldr             x0, [fp, #0x18]
    // 0xdefba8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdefba8: ldur            w1, [x0, #0x17]
    // 0xdefbac: DecompressPointer r1
    //     0xdefbac: add             x1, x1, HEAP, lsl #32
    // 0xdefbb0: CheckStackOverflow
    //     0xdefbb0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdefbb4: cmp             SP, x16
    //     0xdefbb8: b.ls            #0xdefbd0
    // 0xdefbbc: ldr             x2, [fp, #0x10]
    // 0xdefbc0: r0 = _handleMonthPageChanged()
    //     0xdefbc0: bl              #0xdefbd8  ; [package:flutter/src/material/calendar_date_picker.dart] _MonthPickerState::_handleMonthPageChanged
    // 0xdefbc4: LeaveFrame
    //     0xdefbc4: mov             SP, fp
    //     0xdefbc8: ldp             fp, lr, [SP], #0x10
    // 0xdefbcc: ret
    //     0xdefbcc: ret             
    // 0xdefbd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdefbd0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdefbd4: b               #0xdefbbc
  }
  _ _handleMonthPageChanged(/* No info */) {
    // ** addr: 0xdefbd8, size: 0x70
    // 0xdefbd8: EnterFrame
    //     0xdefbd8: stp             fp, lr, [SP, #-0x10]!
    //     0xdefbdc: mov             fp, SP
    // 0xdefbe0: AllocStack(0x10)
    //     0xdefbe0: sub             SP, SP, #0x10
    // 0xdefbe4: SetupParameters(_MonthPickerState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xdefbe4: stur            x1, [fp, #-8]
    //     0xdefbe8: stur            x2, [fp, #-0x10]
    // 0xdefbec: CheckStackOverflow
    //     0xdefbec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdefbf0: cmp             SP, x16
    //     0xdefbf4: b.ls            #0xdefc40
    // 0xdefbf8: r1 = 2
    //     0xdefbf8: mov             x1, #2
    // 0xdefbfc: r0 = AllocateContext()
    //     0xdefbfc: bl              #0x13de838  ; AllocateContextStub
    // 0xdefc00: mov             x1, x0
    // 0xdefc04: ldur            x0, [fp, #-8]
    // 0xdefc08: StoreField: r1->field_f = r0
    //     0xdefc08: stur            w0, [x1, #0xf]
    // 0xdefc0c: ldur            x2, [fp, #-0x10]
    // 0xdefc10: StoreField: r1->field_13 = r2
    //     0xdefc10: stur            w2, [x1, #0x13]
    // 0xdefc14: mov             x2, x1
    // 0xdefc18: r1 = Function '<anonymous closure>':.
    //     0xdefc18: add             x1, PP, #0xd0, lsl #12  ; [pp+0xd0740] AnonymousClosure: (0xdefc48), in [package:flutter/src/material/calendar_date_picker.dart] _MonthPickerState::_handleMonthPageChanged (0xdefbd8)
    //     0xdefc1c: ldr             x1, [x1, #0x740]
    // 0xdefc20: r0 = AllocateClosure()
    //     0xdefc20: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdefc24: ldur            x1, [fp, #-8]
    // 0xdefc28: mov             x2, x0
    // 0xdefc2c: r0 = setState()
    //     0xdefc2c: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xdefc30: r0 = Null
    //     0xdefc30: mov             x0, NULL
    // 0xdefc34: LeaveFrame
    //     0xdefc34: mov             SP, fp
    //     0xdefc38: ldp             fp, lr, [SP], #0x10
    // 0xdefc3c: ret
    //     0xdefc3c: ret             
    // 0xdefc40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdefc40: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdefc44: b               #0xdefbf8
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xdefc48, size: 0x390
    // 0xdefc48: EnterFrame
    //     0xdefc48: stp             fp, lr, [SP, #-0x10]!
    //     0xdefc4c: mov             fp, SP
    // 0xdefc50: AllocStack(0x20)
    //     0xdefc50: sub             SP, SP, #0x20
    // 0xdefc54: SetupParameters([dynamic _ /* r0 */])
    //     0xdefc54: ldr             x0, [fp, #0x10]
    //     0xdefc58: ldur            w3, [x0, #0x17]
    //     0xdefc5c: add             x3, x3, HEAP, lsl #32
    //     0xdefc60: stur            x3, [fp, #-8]
    // 0xdefc64: CheckStackOverflow
    //     0xdefc64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdefc68: cmp             SP, x16
    //     0xdefc6c: b.ls            #0xdeff60
    // 0xdefc70: LoadField: r0 = r3->field_f
    //     0xdefc70: ldur            w0, [x3, #0xf]
    // 0xdefc74: DecompressPointer r0
    //     0xdefc74: add             x0, x0, HEAP, lsl #32
    // 0xdefc78: LoadField: r1 = r0->field_b
    //     0xdefc78: ldur            w1, [x0, #0xb]
    // 0xdefc7c: DecompressPointer r1
    //     0xdefc7c: add             x1, x1, HEAP, lsl #32
    // 0xdefc80: cmp             w1, NULL
    // 0xdefc84: b.eq            #0xdeff68
    // 0xdefc88: LoadField: r0 = r1->field_13
    //     0xdefc88: ldur            w0, [x1, #0x13]
    // 0xdefc8c: DecompressPointer r0
    //     0xdefc8c: add             x0, x0, HEAP, lsl #32
    // 0xdefc90: LoadField: r1 = r3->field_13
    //     0xdefc90: ldur            w1, [x3, #0x13]
    // 0xdefc94: DecompressPointer r1
    //     0xdefc94: add             x1, x1, HEAP, lsl #32
    // 0xdefc98: r2 = LoadInt32Instr(r1)
    //     0xdefc98: sbfx            x2, x1, #1, #0x1f
    //     0xdefc9c: tbz             w1, #0, #0xdefca4
    //     0xdefca0: ldur            x2, [x1, #7]
    // 0xdefca4: mov             x1, x0
    // 0xdefca8: r0 = addMonthsToMonthDate()
    //     0xdefca8: bl              #0xdeffd8  ; [package:flutter/src/material/date.dart] DateUtils::addMonthsToMonthDate
    // 0xdefcac: mov             x4, x0
    // 0xdefcb0: ldur            x0, [fp, #-8]
    // 0xdefcb4: stur            x4, [fp, #-0x10]
    // 0xdefcb8: LoadField: r1 = r0->field_f
    //     0xdefcb8: ldur            w1, [x0, #0xf]
    // 0xdefcbc: DecompressPointer r1
    //     0xdefcbc: add             x1, x1, HEAP, lsl #32
    // 0xdefcc0: LoadField: r2 = r1->field_b
    //     0xdefcc0: ldur            w2, [x1, #0xb]
    // 0xdefcc4: DecompressPointer r2
    //     0xdefcc4: add             x2, x2, HEAP, lsl #32
    // 0xdefcc8: cmp             w2, NULL
    // 0xdefccc: b.eq            #0xdeff6c
    // 0xdefcd0: LoadField: r2 = r1->field_1b
    //     0xdefcd0: ldur            w2, [x1, #0x1b]
    // 0xdefcd4: DecompressPointer r2
    //     0xdefcd4: add             x2, x2, HEAP, lsl #32
    // 0xdefcd8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdefcdc: cmp             w2, w16
    // 0xdefce0: b.eq            #0xdeff70
    // 0xdefce4: mov             x3, x4
    // 0xdefce8: r1 = Instance_GregorianCalendarDelegate
    //     0xdefce8: add             x1, PP, #0x28, lsl #12  ; [pp+0x28538] Obj!GregorianCalendarDelegate@129edd1
    //     0xdefcec: ldr             x1, [x1, #0x538]
    // 0xdefcf0: r0 = isSameMonth()
    //     0xdefcf0: bl              #0xdef958  ; [package:flutter/src/material/date.dart] CalendarDelegate::isSameMonth
    // 0xdefcf4: tbz             w0, #4, #0xdeff50
    // 0xdefcf8: ldur            x0, [fp, #-8]
    // 0xdefcfc: LoadField: r2 = r0->field_f
    //     0xdefcfc: ldur            w2, [x0, #0xf]
    // 0xdefd00: DecompressPointer r2
    //     0xdefd00: add             x2, x2, HEAP, lsl #32
    // 0xdefd04: stur            x2, [fp, #-0x18]
    // 0xdefd08: LoadField: r1 = r2->field_b
    //     0xdefd08: ldur            w1, [x2, #0xb]
    // 0xdefd0c: DecompressPointer r1
    //     0xdefd0c: add             x1, x1, HEAP, lsl #32
    // 0xdefd10: cmp             w1, NULL
    // 0xdefd14: b.eq            #0xdeff7c
    // 0xdefd18: ldur            x1, [fp, #-0x10]
    // 0xdefd1c: r0 = _parts()
    //     0xdefd1c: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xdefd20: mov             x2, x0
    // 0xdefd24: LoadField: r0 = r2->field_b
    //     0xdefd24: ldur            w0, [x2, #0xb]
    // 0xdefd28: r1 = LoadInt32Instr(r0)
    //     0xdefd28: sbfx            x1, x0, #1, #0x1f
    // 0xdefd2c: mov             x0, x1
    // 0xdefd30: r1 = 8
    //     0xdefd30: mov             x1, #8
    // 0xdefd34: cmp             x1, x0
    // 0xdefd38: b.hs            #0xdeff80
    // 0xdefd3c: LoadField: r0 = r2->field_2f
    //     0xdefd3c: ldur            w0, [x2, #0x2f]
    // 0xdefd40: DecompressPointer r0
    //     0xdefd40: add             x0, x0, HEAP, lsl #32
    // 0xdefd44: ldur            x1, [fp, #-0x10]
    // 0xdefd48: stur            x0, [fp, #-0x20]
    // 0xdefd4c: r0 = _parts()
    //     0xdefd4c: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xdefd50: mov             x2, x0
    // 0xdefd54: LoadField: r0 = r2->field_b
    //     0xdefd54: ldur            w0, [x2, #0xb]
    // 0xdefd58: r1 = LoadInt32Instr(r0)
    //     0xdefd58: sbfx            x1, x0, #1, #0x1f
    // 0xdefd5c: mov             x0, x1
    // 0xdefd60: r1 = 7
    //     0xdefd60: mov             x1, #7
    // 0xdefd64: cmp             x1, x0
    // 0xdefd68: b.hs            #0xdeff84
    // 0xdefd6c: LoadField: r0 = r2->field_2b
    //     0xdefd6c: ldur            w0, [x2, #0x2b]
    // 0xdefd70: DecompressPointer r0
    //     0xdefd70: add             x0, x0, HEAP, lsl #32
    // 0xdefd74: ldur            x1, [fp, #-0x20]
    // 0xdefd78: r2 = LoadInt32Instr(r1)
    //     0xdefd78: sbfx            x2, x1, #1, #0x1f
    //     0xdefd7c: tbz             w1, #0, #0xdefd84
    //     0xdefd80: ldur            x2, [x1, #7]
    // 0xdefd84: r3 = LoadInt32Instr(r0)
    //     0xdefd84: sbfx            x3, x0, #1, #0x1f
    //     0xdefd88: tbz             w0, #0, #0xdefd90
    //     0xdefd8c: ldur            x3, [x0, #7]
    // 0xdefd90: r1 = Instance_GregorianCalendarDelegate
    //     0xdefd90: add             x1, PP, #0x28, lsl #12  ; [pp+0x28538] Obj!GregorianCalendarDelegate@129edd1
    //     0xdefd94: ldr             x1, [x1, #0x538]
    // 0xdefd98: r0 = getMonth()
    //     0xdefd98: bl              #0xdedac8  ; [package:flutter/src/material/date.dart] GregorianCalendarDelegate::getMonth
    // 0xdefd9c: ldur            x1, [fp, #-0x18]
    // 0xdefda0: StoreField: r1->field_1b = r0
    //     0xdefda0: stur            w0, [x1, #0x1b]
    //     0xdefda4: ldurb           w16, [x1, #-1]
    //     0xdefda8: ldurb           w17, [x0, #-1]
    //     0xdefdac: and             x16, x17, x16, lsr #2
    //     0xdefdb0: tst             x16, HEAP, lsr #32
    //     0xdefdb4: b.eq            #0xdefdbc
    //     0xdefdb8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdefdbc: ldur            x0, [fp, #-8]
    // 0xdefdc0: LoadField: r1 = r0->field_f
    //     0xdefdc0: ldur            w1, [x0, #0xf]
    // 0xdefdc4: DecompressPointer r1
    //     0xdefdc4: add             x1, x1, HEAP, lsl #32
    // 0xdefdc8: LoadField: r2 = r1->field_b
    //     0xdefdc8: ldur            w2, [x1, #0xb]
    // 0xdefdcc: DecompressPointer r2
    //     0xdefdcc: add             x2, x2, HEAP, lsl #32
    // 0xdefdd0: cmp             w2, NULL
    // 0xdefdd4: b.eq            #0xdeff88
    // 0xdefdd8: LoadField: r3 = r1->field_1b
    //     0xdefdd8: ldur            w3, [x1, #0x1b]
    // 0xdefddc: DecompressPointer r3
    //     0xdefddc: add             x3, x3, HEAP, lsl #32
    // 0xdefde0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdefde4: cmp             w3, w16
    // 0xdefde8: b.eq            #0xdeff8c
    // 0xdefdec: LoadField: r1 = r2->field_23
    //     0xdefdec: ldur            w1, [x2, #0x23]
    // 0xdefdf0: DecompressPointer r1
    //     0xdefdf0: add             x1, x1, HEAP, lsl #32
    // 0xdefdf4: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xdefdf4: ldur            w2, [x1, #0x17]
    // 0xdefdf8: DecompressPointer r2
    //     0xdefdf8: add             x2, x2, HEAP, lsl #32
    // 0xdefdfc: mov             x1, x2
    // 0xdefe00: mov             x2, x3
    // 0xdefe04: r0 = _handleMonthChanged()
    //     0xdefe04: bl              #0xded7ac  ; [package:flutter/src/material/calendar_date_picker.dart] _CalendarDatePickerState::_handleMonthChanged
    // 0xdefe08: ldur            x0, [fp, #-8]
    // 0xdefe0c: LoadField: r1 = r0->field_f
    //     0xdefe0c: ldur            w1, [x0, #0xf]
    // 0xdefe10: DecompressPointer r1
    //     0xdefe10: add             x1, x1, HEAP, lsl #32
    // 0xdefe14: LoadField: r2 = r1->field_33
    //     0xdefe14: ldur            w2, [x1, #0x33]
    // 0xdefe18: DecompressPointer r2
    //     0xdefe18: add             x2, x2, HEAP, lsl #32
    // 0xdefe1c: cmp             w2, NULL
    // 0xdefe20: b.eq            #0xdefef0
    // 0xdefe24: LoadField: r3 = r1->field_b
    //     0xdefe24: ldur            w3, [x1, #0xb]
    // 0xdefe28: DecompressPointer r3
    //     0xdefe28: add             x3, x3, HEAP, lsl #32
    // 0xdefe2c: cmp             w3, NULL
    // 0xdefe30: b.eq            #0xdeff98
    // 0xdefe34: LoadField: r3 = r1->field_1b
    //     0xdefe34: ldur            w3, [x1, #0x1b]
    // 0xdefe38: DecompressPointer r3
    //     0xdefe38: add             x3, x3, HEAP, lsl #32
    // 0xdefe3c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdefe40: cmp             w3, w16
    // 0xdefe44: b.eq            #0xdeff9c
    // 0xdefe48: r1 = Instance_GregorianCalendarDelegate
    //     0xdefe48: add             x1, PP, #0x28, lsl #12  ; [pp+0x28538] Obj!GregorianCalendarDelegate@129edd1
    //     0xdefe4c: ldr             x1, [x1, #0x538]
    // 0xdefe50: r0 = isSameMonth()
    //     0xdefe50: bl              #0xdef958  ; [package:flutter/src/material/date.dart] CalendarDelegate::isSameMonth
    // 0xdefe54: tbz             w0, #4, #0xdefef0
    // 0xdefe58: ldur            x0, [fp, #-8]
    // 0xdefe5c: LoadField: r2 = r0->field_f
    //     0xdefe5c: ldur            w2, [x0, #0xf]
    // 0xdefe60: DecompressPointer r2
    //     0xdefe60: add             x2, x2, HEAP, lsl #32
    // 0xdefe64: stur            x2, [fp, #-0x18]
    // 0xdefe68: LoadField: r3 = r2->field_1b
    //     0xdefe68: ldur            w3, [x2, #0x1b]
    // 0xdefe6c: DecompressPointer r3
    //     0xdefe6c: add             x3, x3, HEAP, lsl #32
    // 0xdefe70: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdefe74: cmp             w3, w16
    // 0xdefe78: b.eq            #0xdeffa8
    // 0xdefe7c: stur            x3, [fp, #-0x10]
    // 0xdefe80: LoadField: r1 = r2->field_33
    //     0xdefe80: ldur            w1, [x2, #0x33]
    // 0xdefe84: DecompressPointer r1
    //     0xdefe84: add             x1, x1, HEAP, lsl #32
    // 0xdefe88: cmp             w1, NULL
    // 0xdefe8c: b.eq            #0xdeffb4
    // 0xdefe90: r0 = _parts()
    //     0xdefe90: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xdefe94: mov             x2, x0
    // 0xdefe98: LoadField: r0 = r2->field_b
    //     0xdefe98: ldur            w0, [x2, #0xb]
    // 0xdefe9c: r1 = LoadInt32Instr(r0)
    //     0xdefe9c: sbfx            x1, x0, #1, #0x1f
    // 0xdefea0: mov             x0, x1
    // 0xdefea4: r1 = 5
    //     0xdefea4: mov             x1, #5
    // 0xdefea8: cmp             x1, x0
    // 0xdefeac: b.hs            #0xdeffb8
    // 0xdefeb0: LoadField: r0 = r2->field_23
    //     0xdefeb0: ldur            w0, [x2, #0x23]
    // 0xdefeb4: DecompressPointer r0
    //     0xdefeb4: add             x0, x0, HEAP, lsl #32
    // 0xdefeb8: r3 = LoadInt32Instr(r0)
    //     0xdefeb8: sbfx            x3, x0, #1, #0x1f
    //     0xdefebc: tbz             w0, #0, #0xdefec4
    //     0xdefec0: ldur            x3, [x0, #7]
    // 0xdefec4: ldur            x1, [fp, #-0x18]
    // 0xdefec8: ldur            x2, [fp, #-0x10]
    // 0xdefecc: r0 = _focusableDayForMonth()
    //     0xdefecc: bl              #0xdef620  ; [package:flutter/src/material/calendar_date_picker.dart] _MonthPickerState::_focusableDayForMonth
    // 0xdefed0: ldur            x1, [fp, #-0x18]
    // 0xdefed4: StoreField: r1->field_33 = r0
    //     0xdefed4: stur            w0, [x1, #0x33]
    //     0xdefed8: ldurb           w16, [x1, #-1]
    //     0xdefedc: ldurb           w17, [x0, #-1]
    //     0xdefee0: and             x16, x17, x16, lsr #2
    //     0xdefee4: tst             x16, HEAP, lsr #32
    //     0xdefee8: b.eq            #0xdefef0
    //     0xdefeec: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdefef0: ldur            x0, [fp, #-8]
    // 0xdefef4: LoadField: r4 = r0->field_f
    //     0xdefef4: ldur            w4, [x0, #0xf]
    // 0xdefef8: DecompressPointer r4
    //     0xdefef8: add             x4, x4, HEAP, lsl #32
    // 0xdefefc: stur            x4, [fp, #-0x10]
    // 0xdeff00: LoadField: r0 = r4->field_b
    //     0xdeff00: ldur            w0, [x4, #0xb]
    // 0xdeff04: DecompressPointer r0
    //     0xdeff04: add             x0, x0, HEAP, lsl #32
    // 0xdeff08: cmp             w0, NULL
    // 0xdeff0c: b.eq            #0xdeffbc
    // 0xdeff10: LoadField: r2 = r4->field_1b
    //     0xdeff10: ldur            w2, [x4, #0x1b]
    // 0xdeff14: DecompressPointer r2
    //     0xdeff14: add             x2, x2, HEAP, lsl #32
    // 0xdeff18: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdeff1c: cmp             w2, w16
    // 0xdeff20: b.eq            #0xdeffc0
    // 0xdeff24: LoadField: r3 = r4->field_23
    //     0xdeff24: ldur            w3, [x4, #0x23]
    // 0xdeff28: DecompressPointer r3
    //     0xdeff28: add             x3, x3, HEAP, lsl #32
    // 0xdeff2c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdeff30: cmp             w3, w16
    // 0xdeff34: b.eq            #0xdeffcc
    // 0xdeff38: r1 = Instance_GregorianCalendarDelegate
    //     0xdeff38: add             x1, PP, #0x28, lsl #12  ; [pp+0x28538] Obj!GregorianCalendarDelegate@129edd1
    //     0xdeff3c: ldr             x1, [x1, #0x538]
    // 0xdeff40: r0 = formatMonthYear()
    //     0xdeff40: bl              #0xdecc7c  ; [package:flutter/src/material/date.dart] GregorianCalendarDelegate::formatMonthYear
    // 0xdeff44: ldur            x1, [fp, #-0x10]
    // 0xdeff48: mov             x2, x0
    // 0xdeff4c: r0 = _announce()
    //     0xdeff4c: bl              #0xdee348  ; [package:flutter/src/material/calendar_date_picker.dart] _CalendarDatePickerState::_announce
    // 0xdeff50: r0 = Null
    //     0xdeff50: mov             x0, NULL
    // 0xdeff54: LeaveFrame
    //     0xdeff54: mov             SP, fp
    //     0xdeff58: ldp             fp, lr, [SP], #0x10
    // 0xdeff5c: ret
    //     0xdeff5c: ret             
    // 0xdeff60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdeff60: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdeff64: b               #0xdefc70
    // 0xdeff68: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdeff68: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdeff6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdeff6c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdeff70: r9 = _currentMonth
    //     0xdeff70: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa3fa8] Field <_MonthPickerState@54260463._currentMonth@54260463>: late (offset: 0x1c)
    //     0xdeff74: ldr             x9, [x9, #0xfa8]
    // 0xdeff78: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdeff78: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdeff7c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdeff7c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdeff80: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdeff80: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdeff84: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdeff84: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdeff88: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdeff88: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdeff8c: r9 = _currentMonth
    //     0xdeff8c: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa3fa8] Field <_MonthPickerState@54260463._currentMonth@54260463>: late (offset: 0x1c)
    //     0xdeff90: ldr             x9, [x9, #0xfa8]
    // 0xdeff94: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdeff94: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdeff98: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdeff98: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdeff9c: r9 = _currentMonth
    //     0xdeff9c: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa3fa8] Field <_MonthPickerState@54260463._currentMonth@54260463>: late (offset: 0x1c)
    //     0xdeffa0: ldr             x9, [x9, #0xfa8]
    // 0xdeffa4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdeffa4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdeffa8: r9 = _currentMonth
    //     0xdeffa8: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa3fa8] Field <_MonthPickerState@54260463._currentMonth@54260463>: late (offset: 0x1c)
    //     0xdeffac: ldr             x9, [x9, #0xfa8]
    // 0xdeffb0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdeffb0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdeffb4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdeffb4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdeffb8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdeffb8: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdeffbc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdeffbc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdeffc0: r9 = _currentMonth
    //     0xdeffc0: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa3fa8] Field <_MonthPickerState@54260463._currentMonth@54260463>: late (offset: 0x1c)
    //     0xdeffc4: ldr             x9, [x9, #0xfa8]
    // 0xdeffc8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdeffc8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdeffcc: r9 = _localizations
    //     0xdeffcc: add             x9, PP, #0xd0, lsl #12  ; [pp+0xd0728] Field <_MonthPickerState@54260463._localizations@54260463>: late (offset: 0x24)
    //     0xdeffd0: ldr             x9, [x9, #0x728]
    // 0xdeffd4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdeffd4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Widget _buildItems(dynamic, BuildContext, int) {
    // ** addr: 0xdf00d8, size: 0x40
    // 0xdf00d8: EnterFrame
    //     0xdf00d8: stp             fp, lr, [SP, #-0x10]!
    //     0xdf00dc: mov             fp, SP
    // 0xdf00e0: ldr             x0, [fp, #0x20]
    // 0xdf00e4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdf00e4: ldur            w1, [x0, #0x17]
    // 0xdf00e8: DecompressPointer r1
    //     0xdf00e8: add             x1, x1, HEAP, lsl #32
    // 0xdf00ec: CheckStackOverflow
    //     0xdf00ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf00f0: cmp             SP, x16
    //     0xdf00f4: b.ls            #0xdf0110
    // 0xdf00f8: ldr             x2, [fp, #0x18]
    // 0xdf00fc: ldr             x3, [fp, #0x10]
    // 0xdf0100: r0 = _buildItems()
    //     0xdf0100: bl              #0xdf0118  ; [package:flutter/src/material/calendar_date_picker.dart] _MonthPickerState::_buildItems
    // 0xdf0104: LeaveFrame
    //     0xdf0104: mov             SP, fp
    //     0xdf0108: ldp             fp, lr, [SP], #0x10
    // 0xdf010c: ret
    //     0xdf010c: ret             
    // 0xdf0110: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf0110: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf0114: b               #0xdf00f8
  }
  _ _buildItems(/* No info */) {
    // ** addr: 0xdf0118, size: 0x138
    // 0xdf0118: EnterFrame
    //     0xdf0118: stp             fp, lr, [SP, #-0x10]!
    //     0xdf011c: mov             fp, SP
    // 0xdf0120: AllocStack(0x40)
    //     0xdf0120: sub             SP, SP, #0x40
    // 0xdf0124: SetupParameters(_MonthPickerState this /* r1 => r0, fp-0x8 */)
    //     0xdf0124: mov             x0, x1
    //     0xdf0128: stur            x1, [fp, #-8]
    // 0xdf012c: CheckStackOverflow
    //     0xdf012c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf0130: cmp             SP, x16
    //     0xdf0134: b.ls            #0xdf0240
    // 0xdf0138: LoadField: r1 = r0->field_b
    //     0xdf0138: ldur            w1, [x0, #0xb]
    // 0xdf013c: DecompressPointer r1
    //     0xdf013c: add             x1, x1, HEAP, lsl #32
    // 0xdf0140: cmp             w1, NULL
    // 0xdf0144: b.eq            #0xdf0248
    // 0xdf0148: LoadField: r2 = r1->field_13
    //     0xdf0148: ldur            w2, [x1, #0x13]
    // 0xdf014c: DecompressPointer r2
    //     0xdf014c: add             x2, x2, HEAP, lsl #32
    // 0xdf0150: r1 = LoadInt32Instr(r3)
    //     0xdf0150: sbfx            x1, x3, #1, #0x1f
    //     0xdf0154: tbz             w3, #0, #0xdf015c
    //     0xdf0158: ldur            x1, [x3, #7]
    // 0xdf015c: mov             x16, x1
    // 0xdf0160: mov             x1, x2
    // 0xdf0164: mov             x2, x16
    // 0xdf0168: r0 = addMonthsToMonthDate()
    //     0xdf0168: bl              #0xdeffd8  ; [package:flutter/src/material/date.dart] DateUtils::addMonthsToMonthDate
    // 0xdf016c: r1 = <DateTime>
    //     0xdf016c: add             x1, PP, #0x14, lsl #12  ; [pp+0x14b10] TypeArguments: <DateTime>
    //     0xdf0170: ldr             x1, [x1, #0xb10]
    // 0xdf0174: stur            x0, [fp, #-0x10]
    // 0xdf0178: r0 = ValueKey()
    //     0xdf0178: bl              #0x8e283c  ; AllocateValueKeyStub -> ValueKey<X0> (size=0x10)
    // 0xdf017c: mov             x1, x0
    // 0xdf0180: ldur            x0, [fp, #-0x10]
    // 0xdf0184: stur            x1, [fp, #-0x38]
    // 0xdf0188: StoreField: r1->field_b = r0
    //     0xdf0188: stur            w0, [x1, #0xb]
    // 0xdf018c: ldur            x2, [fp, #-8]
    // 0xdf0190: LoadField: r3 = r2->field_b
    //     0xdf0190: ldur            w3, [x2, #0xb]
    // 0xdf0194: DecompressPointer r3
    //     0xdf0194: add             x3, x3, HEAP, lsl #32
    // 0xdf0198: cmp             w3, NULL
    // 0xdf019c: b.eq            #0xdf024c
    // 0xdf01a0: LoadField: r4 = r3->field_1b
    //     0xdf01a0: ldur            w4, [x3, #0x1b]
    // 0xdf01a4: DecompressPointer r4
    //     0xdf01a4: add             x4, x4, HEAP, lsl #32
    // 0xdf01a8: stur            x4, [fp, #-0x30]
    // 0xdf01ac: LoadField: r5 = r3->field_f
    //     0xdf01ac: ldur            w5, [x3, #0xf]
    // 0xdf01b0: DecompressPointer r5
    //     0xdf01b0: add             x5, x5, HEAP, lsl #32
    // 0xdf01b4: stur            x5, [fp, #-0x28]
    // 0xdf01b8: LoadField: r6 = r3->field_13
    //     0xdf01b8: ldur            w6, [x3, #0x13]
    // 0xdf01bc: DecompressPointer r6
    //     0xdf01bc: add             x6, x6, HEAP, lsl #32
    // 0xdf01c0: stur            x6, [fp, #-0x20]
    // 0xdf01c4: ArrayLoad: r7 = r3[0]  ; List_4
    //     0xdf01c4: ldur            w7, [x3, #0x17]
    // 0xdf01c8: DecompressPointer r7
    //     0xdf01c8: add             x7, x7, HEAP, lsl #32
    // 0xdf01cc: stur            x7, [fp, #-0x18]
    // 0xdf01d0: r0 = _DayPicker()
    //     0xdf01d0: bl              #0xdf0250  ; Allocate_DayPickerStub -> _DayPicker (size=0x2c)
    // 0xdf01d4: mov             x3, x0
    // 0xdf01d8: ldur            x0, [fp, #-0x28]
    // 0xdf01dc: stur            x3, [fp, #-0x40]
    // 0xdf01e0: StoreField: r3->field_f = r0
    //     0xdf01e0: stur            w0, [x3, #0xf]
    // 0xdf01e4: ldur            x0, [fp, #-0x10]
    // 0xdf01e8: StoreField: r3->field_1f = r0
    //     0xdf01e8: stur            w0, [x3, #0x1f]
    // 0xdf01ec: ldur            x0, [fp, #-0x20]
    // 0xdf01f0: ArrayStore: r3[0] = r0  ; List_4
    //     0xdf01f0: stur            w0, [x3, #0x17]
    // 0xdf01f4: ldur            x0, [fp, #-0x18]
    // 0xdf01f8: StoreField: r3->field_1b = r0
    //     0xdf01f8: stur            w0, [x3, #0x1b]
    // 0xdf01fc: ldur            x0, [fp, #-0x30]
    // 0xdf0200: StoreField: r3->field_b = r0
    //     0xdf0200: stur            w0, [x3, #0xb]
    // 0xdf0204: ldur            x2, [fp, #-8]
    // 0xdf0208: r1 = Function '_handleDateSelected@54260463':.
    //     0xdf0208: add             x1, PP, #0xd0, lsl #12  ; [pp+0xd0748] AnonymousClosure: (0xdf0280), in [package:flutter/src/material/calendar_date_picker.dart] _MonthPickerState::_handleDateSelected (0xdf02bc)
    //     0xdf020c: ldr             x1, [x1, #0x748]
    // 0xdf0210: r0 = AllocateClosure()
    //     0xdf0210: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf0214: mov             x1, x0
    // 0xdf0218: ldur            x0, [fp, #-0x40]
    // 0xdf021c: StoreField: r0->field_13 = r1
    //     0xdf021c: stur            w1, [x0, #0x13]
    // 0xdf0220: r1 = Instance_GregorianCalendarDelegate
    //     0xdf0220: add             x1, PP, #0x28, lsl #12  ; [pp+0x28538] Obj!GregorianCalendarDelegate@129edd1
    //     0xdf0224: ldr             x1, [x1, #0x538]
    // 0xdf0228: StoreField: r0->field_27 = r1
    //     0xdf0228: stur            w1, [x0, #0x27]
    // 0xdf022c: ldur            x1, [fp, #-0x38]
    // 0xdf0230: StoreField: r0->field_7 = r1
    //     0xdf0230: stur            w1, [x0, #7]
    // 0xdf0234: LeaveFrame
    //     0xdf0234: mov             SP, fp
    //     0xdf0238: ldp             fp, lr, [SP], #0x10
    // 0xdf023c: ret
    //     0xdf023c: ret             
    // 0xdf0240: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf0240: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf0244: b               #0xdf0138
    // 0xdf0248: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf0248: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf024c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf024c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleDateSelected(dynamic, DateTime) {
    // ** addr: 0xdf0280, size: 0x3c
    // 0xdf0280: EnterFrame
    //     0xdf0280: stp             fp, lr, [SP, #-0x10]!
    //     0xdf0284: mov             fp, SP
    // 0xdf0288: ldr             x0, [fp, #0x18]
    // 0xdf028c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdf028c: ldur            w1, [x0, #0x17]
    // 0xdf0290: DecompressPointer r1
    //     0xdf0290: add             x1, x1, HEAP, lsl #32
    // 0xdf0294: CheckStackOverflow
    //     0xdf0294: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf0298: cmp             SP, x16
    //     0xdf029c: b.ls            #0xdf02b4
    // 0xdf02a0: ldr             x2, [fp, #0x10]
    // 0xdf02a4: r0 = _handleDateSelected()
    //     0xdf02a4: bl              #0xdf02bc  ; [package:flutter/src/material/calendar_date_picker.dart] _MonthPickerState::_handleDateSelected
    // 0xdf02a8: LeaveFrame
    //     0xdf02a8: mov             SP, fp
    //     0xdf02ac: ldp             fp, lr, [SP], #0x10
    // 0xdf02b0: ret
    //     0xdf02b0: ret             
    // 0xdf02b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf02b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf02b8: b               #0xdf02a0
  }
  _ _handleDateSelected(/* No info */) {
    // ** addr: 0xdf02bc, size: 0x88
    // 0xdf02bc: EnterFrame
    //     0xdf02bc: stp             fp, lr, [SP, #-0x10]!
    //     0xdf02c0: mov             fp, SP
    // 0xdf02c4: mov             x16, x2
    // 0xdf02c8: mov             x2, x1
    // 0xdf02cc: mov             x1, x16
    // 0xdf02d0: CheckStackOverflow
    //     0xdf02d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf02d4: cmp             SP, x16
    //     0xdf02d8: b.ls            #0xdf0338
    // 0xdf02dc: mov             x0, x1
    // 0xdf02e0: StoreField: r2->field_33 = r0
    //     0xdf02e0: stur            w0, [x2, #0x33]
    //     0xdf02e4: ldurb           w16, [x2, #-1]
    //     0xdf02e8: ldurb           w17, [x0, #-1]
    //     0xdf02ec: and             x16, x17, x16, lsr #2
    //     0xdf02f0: tst             x16, HEAP, lsr #32
    //     0xdf02f4: b.eq            #0xdf02fc
    //     0xdf02f8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xdf02fc: LoadField: r0 = r2->field_b
    //     0xdf02fc: ldur            w0, [x2, #0xb]
    // 0xdf0300: DecompressPointer r0
    //     0xdf0300: add             x0, x0, HEAP, lsl #32
    // 0xdf0304: cmp             w0, NULL
    // 0xdf0308: b.eq            #0xdf0340
    // 0xdf030c: LoadField: r2 = r0->field_1f
    //     0xdf030c: ldur            w2, [x0, #0x1f]
    // 0xdf0310: DecompressPointer r2
    //     0xdf0310: add             x2, x2, HEAP, lsl #32
    // 0xdf0314: ArrayLoad: r0 = r2[0]  ; List_4
    //     0xdf0314: ldur            w0, [x2, #0x17]
    // 0xdf0318: DecompressPointer r0
    //     0xdf0318: add             x0, x0, HEAP, lsl #32
    // 0xdf031c: mov             x2, x1
    // 0xdf0320: mov             x1, x0
    // 0xdf0324: r0 = _handleDayChanged()
    //     0xdf0324: bl              #0xdedbac  ; [package:flutter/src/material/calendar_date_picker.dart] _CalendarDatePickerState::_handleDayChanged
    // 0xdf0328: r0 = Null
    //     0xdf0328: mov             x0, NULL
    // 0xdf032c: LeaveFrame
    //     0xdf032c: mov             SP, fp
    //     0xdf0330: ldp             fp, lr, [SP], #0x10
    // 0xdf0334: ret
    //     0xdf0334: ret             
    // 0xdf0338: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf0338: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf033c: b               #0xdf02dc
    // 0xdf0340: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf0340: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleNextMonth(dynamic) {
    // ** addr: 0xdf0344, size: 0x38
    // 0xdf0344: EnterFrame
    //     0xdf0344: stp             fp, lr, [SP, #-0x10]!
    //     0xdf0348: mov             fp, SP
    // 0xdf034c: ldr             x0, [fp, #0x10]
    // 0xdf0350: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdf0350: ldur            w1, [x0, #0x17]
    // 0xdf0354: DecompressPointer r1
    //     0xdf0354: add             x1, x1, HEAP, lsl #32
    // 0xdf0358: CheckStackOverflow
    //     0xdf0358: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf035c: cmp             SP, x16
    //     0xdf0360: b.ls            #0xdf0374
    // 0xdf0364: r0 = _handleNextMonth()
    //     0xdf0364: bl              #0xdf037c  ; [package:flutter/src/material/calendar_date_picker.dart] _MonthPickerState::_handleNextMonth
    // 0xdf0368: LeaveFrame
    //     0xdf0368: mov             SP, fp
    //     0xdf036c: ldp             fp, lr, [SP], #0x10
    // 0xdf0370: ret
    //     0xdf0370: ret             
    // 0xdf0374: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf0374: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf0378: b               #0xdf0364
  }
  _ _handleNextMonth(/* No info */) {
    // ** addr: 0xdf037c, size: 0x74
    // 0xdf037c: EnterFrame
    //     0xdf037c: stp             fp, lr, [SP, #-0x10]!
    //     0xdf0380: mov             fp, SP
    // 0xdf0384: AllocStack(0x8)
    //     0xdf0384: sub             SP, SP, #8
    // 0xdf0388: SetupParameters(_MonthPickerState this /* r1 => r0, fp-0x8 */)
    //     0xdf0388: mov             x0, x1
    //     0xdf038c: stur            x1, [fp, #-8]
    // 0xdf0390: CheckStackOverflow
    //     0xdf0390: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf0394: cmp             SP, x16
    //     0xdf0398: b.ls            #0xdf03dc
    // 0xdf039c: mov             x1, x0
    // 0xdf03a0: r0 = _isDisplayingLastMonth()
    //     0xdf03a0: bl              #0xdef09c  ; [package:flutter/src/material/calendar_date_picker.dart] _MonthPickerState::_isDisplayingLastMonth
    // 0xdf03a4: tbz             w0, #4, #0xdf03cc
    // 0xdf03a8: ldur            x0, [fp, #-8]
    // 0xdf03ac: LoadField: r1 = r0->field_1f
    //     0xdf03ac: ldur            w1, [x0, #0x1f]
    // 0xdf03b0: DecompressPointer r1
    //     0xdf03b0: add             x1, x1, HEAP, lsl #32
    // 0xdf03b4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf03b8: cmp             w1, w16
    // 0xdf03bc: b.eq            #0xdf03e4
    // 0xdf03c0: r2 = Instance_Duration
    //     0xdf03c0: add             x2, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xdf03c4: ldr             x2, [x2, #0x318]
    // 0xdf03c8: r0 = nextPage()
    //     0xdf03c8: bl              #0xcec45c  ; [package:flutter/src/widgets/page_view.dart] PageController::nextPage
    // 0xdf03cc: r0 = Null
    //     0xdf03cc: mov             x0, NULL
    // 0xdf03d0: LeaveFrame
    //     0xdf03d0: mov             SP, fp
    //     0xdf03d4: ldp             fp, lr, [SP], #0x10
    // 0xdf03d8: ret
    //     0xdf03d8: ret             
    // 0xdf03dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf03dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf03e0: b               #0xdf039c
    // 0xdf03e4: r9 = _pageController
    //     0xdf03e4: add             x9, PP, #0xd0, lsl #12  ; [pp+0xd0738] Field <_MonthPickerState@54260463._pageController@54260463>: late (offset: 0x20)
    //     0xdf03e8: ldr             x9, [x9, #0x738]
    // 0xdf03ec: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdf03ec: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void _handlePreviousMonth(dynamic) {
    // ** addr: 0xdf03f0, size: 0x38
    // 0xdf03f0: EnterFrame
    //     0xdf03f0: stp             fp, lr, [SP, #-0x10]!
    //     0xdf03f4: mov             fp, SP
    // 0xdf03f8: ldr             x0, [fp, #0x10]
    // 0xdf03fc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdf03fc: ldur            w1, [x0, #0x17]
    // 0xdf0400: DecompressPointer r1
    //     0xdf0400: add             x1, x1, HEAP, lsl #32
    // 0xdf0404: CheckStackOverflow
    //     0xdf0404: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf0408: cmp             SP, x16
    //     0xdf040c: b.ls            #0xdf0420
    // 0xdf0410: r0 = _handlePreviousMonth()
    //     0xdf0410: bl              #0xdf0428  ; [package:flutter/src/material/calendar_date_picker.dart] _MonthPickerState::_handlePreviousMonth
    // 0xdf0414: LeaveFrame
    //     0xdf0414: mov             SP, fp
    //     0xdf0418: ldp             fp, lr, [SP], #0x10
    // 0xdf041c: ret
    //     0xdf041c: ret             
    // 0xdf0420: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf0420: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf0424: b               #0xdf0410
  }
  _ _handlePreviousMonth(/* No info */) {
    // ** addr: 0xdf0428, size: 0x74
    // 0xdf0428: EnterFrame
    //     0xdf0428: stp             fp, lr, [SP, #-0x10]!
    //     0xdf042c: mov             fp, SP
    // 0xdf0430: AllocStack(0x8)
    //     0xdf0430: sub             SP, SP, #8
    // 0xdf0434: SetupParameters(_MonthPickerState this /* r1 => r0, fp-0x8 */)
    //     0xdf0434: mov             x0, x1
    //     0xdf0438: stur            x1, [fp, #-8]
    // 0xdf043c: CheckStackOverflow
    //     0xdf043c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf0440: cmp             SP, x16
    //     0xdf0444: b.ls            #0xdf0488
    // 0xdf0448: mov             x1, x0
    // 0xdf044c: r0 = _isDisplayingFirstMonth()
    //     0xdf044c: bl              #0xdef1cc  ; [package:flutter/src/material/calendar_date_picker.dart] _MonthPickerState::_isDisplayingFirstMonth
    // 0xdf0450: tbz             w0, #4, #0xdf0478
    // 0xdf0454: ldur            x0, [fp, #-8]
    // 0xdf0458: LoadField: r1 = r0->field_1f
    //     0xdf0458: ldur            w1, [x0, #0x1f]
    // 0xdf045c: DecompressPointer r1
    //     0xdf045c: add             x1, x1, HEAP, lsl #32
    // 0xdf0460: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf0464: cmp             w1, w16
    // 0xdf0468: b.eq            #0xdf0490
    // 0xdf046c: r2 = Instance_Duration
    //     0xdf046c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xdf0470: ldr             x2, [x2, #0x318]
    // 0xdf0474: r0 = previousPage()
    //     0xdf0474: bl              #0xcebf30  ; [package:flutter/src/widgets/page_view.dart] PageController::previousPage
    // 0xdf0478: r0 = Null
    //     0xdf0478: mov             x0, NULL
    // 0xdf047c: LeaveFrame
    //     0xdf047c: mov             SP, fp
    //     0xdf0480: ldp             fp, lr, [SP], #0x10
    // 0xdf0484: ret
    //     0xdf0484: ret             
    // 0xdf0488: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf0488: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf048c: b               #0xdf0448
    // 0xdf0490: r9 = _pageController
    //     0xdf0490: add             x9, PP, #0xd0, lsl #12  ; [pp+0xd0738] Field <_MonthPickerState@54260463._pageController@54260463>: late (offset: 0x20)
    //     0xdf0494: ldr             x9, [x9, #0x738]
    // 0xdf0498: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdf0498: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0xef42a0, size: 0x70
    // 0xef42a0: EnterFrame
    //     0xef42a0: stp             fp, lr, [SP, #-0x10]!
    //     0xef42a4: mov             fp, SP
    // 0xef42a8: AllocStack(0x8)
    //     0xef42a8: sub             SP, SP, #8
    // 0xef42ac: SetupParameters(_MonthPickerState this /* r1 => r0, fp-0x8 */)
    //     0xef42ac: mov             x0, x1
    //     0xef42b0: stur            x1, [fp, #-8]
    // 0xef42b4: CheckStackOverflow
    //     0xef42b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef42b8: cmp             SP, x16
    //     0xef42bc: b.ls            #0xef4304
    // 0xef42c0: LoadField: r1 = r0->field_f
    //     0xef42c0: ldur            w1, [x0, #0xf]
    // 0xef42c4: DecompressPointer r1
    //     0xef42c4: add             x1, x1, HEAP, lsl #32
    // 0xef42c8: cmp             w1, NULL
    // 0xef42cc: b.eq            #0xef430c
    // 0xef42d0: r0 = of()
    //     0xef42d0: bl              #0xd0bbf8  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0xef42d4: ldur            x1, [fp, #-8]
    // 0xef42d8: StoreField: r1->field_23 = r0
    //     0xef42d8: stur            w0, [x1, #0x23]
    //     0xef42dc: ldurb           w16, [x1, #-1]
    //     0xef42e0: ldurb           w17, [x0, #-1]
    //     0xef42e4: and             x16, x17, x16, lsr #2
    //     0xef42e8: tst             x16, HEAP, lsr #32
    //     0xef42ec: b.eq            #0xef42f4
    //     0xef42f0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xef42f4: r0 = Null
    //     0xef42f4: mov             x0, NULL
    // 0xef42f8: LeaveFrame
    //     0xef42f8: mov             SP, fp
    //     0xef42fc: ldp             fp, lr, [SP], #0x10
    // 0xef4300: ret
    //     0xef4300: ret             
    // 0xef4304: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef4304: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef4308: b               #0xef42c0
    // 0xef430c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef430c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0xf8fa64, size: 0x418
    // 0xf8fa64: EnterFrame
    //     0xf8fa64: stp             fp, lr, [SP, #-0x10]!
    //     0xf8fa68: mov             fp, SP
    // 0xf8fa6c: AllocStack(0x38)
    //     0xf8fa6c: sub             SP, SP, #0x38
    // 0xf8fa70: SetupParameters(_MonthPickerState this /* r1 => r3, fp-0x8 */)
    //     0xf8fa70: mov             x3, x1
    //     0xf8fa74: stur            x1, [fp, #-8]
    // 0xf8fa78: CheckStackOverflow
    //     0xf8fa78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf8fa7c: cmp             SP, x16
    //     0xf8fa80: b.ls            #0xf8fe70
    // 0xf8fa84: LoadField: r1 = r3->field_b
    //     0xf8fa84: ldur            w1, [x3, #0xb]
    // 0xf8fa88: DecompressPointer r1
    //     0xf8fa88: add             x1, x1, HEAP, lsl #32
    // 0xf8fa8c: cmp             w1, NULL
    // 0xf8fa90: b.eq            #0xf8fe78
    // 0xf8fa94: LoadField: r2 = r1->field_b
    //     0xf8fa94: ldur            w2, [x1, #0xb]
    // 0xf8fa98: DecompressPointer r2
    //     0xf8fa98: add             x2, x2, HEAP, lsl #32
    // 0xf8fa9c: mov             x0, x2
    // 0xf8faa0: StoreField: r3->field_1b = r0
    //     0xf8faa0: stur            w0, [x3, #0x1b]
    //     0xf8faa4: ldurb           w16, [x3, #-1]
    //     0xf8faa8: ldurb           w17, [x0, #-1]
    //     0xf8faac: and             x16, x17, x16, lsr #2
    //     0xf8fab0: tst             x16, HEAP, lsr #32
    //     0xf8fab4: b.eq            #0xf8fabc
    //     0xf8fab8: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xf8fabc: LoadField: r0 = r1->field_13
    //     0xf8fabc: ldur            w0, [x1, #0x13]
    // 0xf8fac0: DecompressPointer r0
    //     0xf8fac0: add             x0, x0, HEAP, lsl #32
    // 0xf8fac4: mov             x1, x0
    // 0xf8fac8: r0 = monthDelta()
    //     0xf8fac8: bl              #0xdeef48  ; [package:flutter/src/material/date.dart] DateUtils::monthDelta
    // 0xf8facc: stur            x0, [fp, #-0x10]
    // 0xf8fad0: r0 = PageController()
    //     0xf8fad0: bl              #0xef6fd0  ; AllocatePageControllerStub -> PageController (size=0x54)
    // 0xf8fad4: mov             x2, x0
    // 0xf8fad8: ldur            x0, [fp, #-0x10]
    // 0xf8fadc: stur            x2, [fp, #-0x18]
    // 0xf8fae0: StoreField: r2->field_3f = r0
    //     0xf8fae0: stur            x0, [x2, #0x3f]
    // 0xf8fae4: r0 = true
    //     0xf8fae4: add             x0, NULL, #0x20  ; true
    // 0xf8fae8: StoreField: r2->field_47 = r0
    //     0xf8fae8: stur            w0, [x2, #0x47]
    // 0xf8faec: d0 = 1.000000
    //     0xf8faec: fmov            d0, #1.00000000
    // 0xf8faf0: StoreField: r2->field_4b = d0
    //     0xf8faf0: stur            d0, [x2, #0x4b]
    // 0xf8faf4: mov             x1, x2
    // 0xf8faf8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xf8faf8: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xf8fafc: r0 = ScrollController()
    //     0xf8fafc: bl              #0x86d884  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::ScrollController
    // 0xf8fb00: ldur            x0, [fp, #-0x18]
    // 0xf8fb04: ldur            x3, [fp, #-8]
    // 0xf8fb08: StoreField: r3->field_1f = r0
    //     0xf8fb08: stur            w0, [x3, #0x1f]
    //     0xf8fb0c: ldurb           w16, [x3, #-1]
    //     0xf8fb10: ldurb           w17, [x0, #-1]
    //     0xf8fb14: and             x16, x17, x16, lsr #2
    //     0xf8fb18: tst             x16, HEAP, lsr #32
    //     0xf8fb1c: b.eq            #0xf8fb24
    //     0xf8fb20: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xf8fb24: r0 = _ConstMap len:4
    //     0xf8fb24: add             x0, PP, #0xd0, lsl #12  ; [pp+0xd0770] Map<ShortcutActivator, Intent>(4)
    //     0xf8fb28: ldr             x0, [x0, #0x770]
    // 0xf8fb2c: StoreField: r3->field_27 = r0
    //     0xf8fb2c: stur            w0, [x3, #0x27]
    // 0xf8fb30: r1 = Null
    //     0xf8fb30: mov             x1, NULL
    // 0xf8fb34: r2 = 12
    //     0xf8fb34: mov             x2, #0xc
    // 0xf8fb38: r0 = AllocateArray()
    //     0xf8fb38: bl              #0x13df928  ; AllocateArrayStub
    // 0xf8fb3c: stur            x0, [fp, #-0x18]
    // 0xf8fb40: r16 = NextFocusIntent
    //     0xf8fb40: add             x16, PP, #0xa3, lsl #12  ; [pp+0xa3418] Type: NextFocusIntent
    //     0xf8fb44: ldr             x16, [x16, #0x418]
    // 0xf8fb48: StoreField: r0->field_f = r16
    //     0xf8fb48: stur            w16, [x0, #0xf]
    // 0xf8fb4c: ldur            x2, [fp, #-8]
    // 0xf8fb50: r1 = Function '_handleGridNextFocus@54260463':.
    //     0xf8fb50: add             x1, PP, #0xd0, lsl #12  ; [pp+0xd0778] AnonymousClosure: (0xf90488), in [package:flutter/src/material/calendar_date_picker.dart] _MonthPickerState::_handleGridNextFocus (0xf904c4)
    //     0xf8fb54: ldr             x1, [x1, #0x778]
    // 0xf8fb58: r0 = AllocateClosure()
    //     0xf8fb58: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf8fb5c: r1 = <NextFocusIntent>
    //     0xf8fb5c: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3420] TypeArguments: <NextFocusIntent>
    //     0xf8fb60: ldr             x1, [x1, #0x420]
    // 0xf8fb64: stur            x0, [fp, #-0x20]
    // 0xf8fb68: r0 = CallbackAction()
    //     0xf8fb68: bl              #0xd126e8  ; AllocateCallbackActionStub -> CallbackAction<X0 bound Intent> (size=0x18)
    // 0xf8fb6c: mov             x2, x0
    // 0xf8fb70: ldur            x0, [fp, #-0x20]
    // 0xf8fb74: stur            x2, [fp, #-0x28]
    // 0xf8fb78: StoreField: r2->field_13 = r0
    //     0xf8fb78: stur            w0, [x2, #0x13]
    // 0xf8fb7c: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0xf8fb7c: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a7a0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0xf8fb80: ldr             x1, [x1, #0x7a0]
    // 0xf8fb84: r0 = ObserverList()
    //     0xf8fb84: bl              #0x89f8bc  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0xf8fb88: mov             x3, x0
    // 0xf8fb8c: r0 = false
    //     0xf8fb8c: add             x0, NULL, #0x30  ; false
    // 0xf8fb90: stur            x3, [fp, #-0x20]
    // 0xf8fb94: StoreField: r3->field_f = r0
    //     0xf8fb94: stur            w0, [x3, #0xf]
    // 0xf8fb98: ldr             x4, [THR, #0x90]  ; THR::object_sentinel
    // 0xf8fb9c: StoreField: r3->field_13 = r4
    //     0xf8fb9c: stur            w4, [x3, #0x13]
    // 0xf8fba0: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0xf8fba0: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a7a0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0xf8fba4: ldr             x1, [x1, #0x7a0]
    // 0xf8fba8: r2 = 0
    //     0xf8fba8: mov             x2, #0
    // 0xf8fbac: r0 = _GrowableList()
    //     0xf8fbac: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xf8fbb0: ldur            x1, [fp, #-0x20]
    // 0xf8fbb4: StoreField: r1->field_b = r0
    //     0xf8fbb4: stur            w0, [x1, #0xb]
    //     0xf8fbb8: ldurb           w16, [x1, #-1]
    //     0xf8fbbc: ldurb           w17, [x0, #-1]
    //     0xf8fbc0: and             x16, x17, x16, lsr #2
    //     0xf8fbc4: tst             x16, HEAP, lsr #32
    //     0xf8fbc8: b.eq            #0xf8fbd0
    //     0xf8fbcc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf8fbd0: mov             x0, x1
    // 0xf8fbd4: ldur            x1, [fp, #-0x28]
    // 0xf8fbd8: StoreField: r1->field_b = r0
    //     0xf8fbd8: stur            w0, [x1, #0xb]
    //     0xf8fbdc: ldurb           w16, [x1, #-1]
    //     0xf8fbe0: ldurb           w17, [x0, #-1]
    //     0xf8fbe4: and             x16, x17, x16, lsr #2
    //     0xf8fbe8: tst             x16, HEAP, lsr #32
    //     0xf8fbec: b.eq            #0xf8fbf4
    //     0xf8fbf0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf8fbf4: mov             x0, x1
    // 0xf8fbf8: ldur            x1, [fp, #-0x18]
    // 0xf8fbfc: ArrayStore: r1[1] = r0  ; List_4
    //     0xf8fbfc: add             x25, x1, #0x13
    //     0xf8fc00: str             w0, [x25]
    //     0xf8fc04: tbz             w0, #0, #0xf8fc20
    //     0xf8fc08: ldurb           w16, [x1, #-1]
    //     0xf8fc0c: ldurb           w17, [x0, #-1]
    //     0xf8fc10: and             x16, x17, x16, lsr #2
    //     0xf8fc14: tst             x16, HEAP, lsr #32
    //     0xf8fc18: b.eq            #0xf8fc20
    //     0xf8fc1c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xf8fc20: ldur            x0, [fp, #-0x18]
    // 0xf8fc24: r16 = PreviousFocusIntent
    //     0xf8fc24: add             x16, PP, #0xa3, lsl #12  ; [pp+0xa3428] Type: PreviousFocusIntent
    //     0xf8fc28: ldr             x16, [x16, #0x428]
    // 0xf8fc2c: ArrayStore: r0[0] = r16  ; List_4
    //     0xf8fc2c: stur            w16, [x0, #0x17]
    // 0xf8fc30: ldur            x2, [fp, #-8]
    // 0xf8fc34: r1 = Function '_handleGridPreviousFocus@54260463':.
    //     0xf8fc34: add             x1, PP, #0xd0, lsl #12  ; [pp+0xd0780] AnonymousClosure: (0xf903dc), in [package:flutter/src/material/calendar_date_picker.dart] _MonthPickerState::_handleGridPreviousFocus (0xf90418)
    //     0xf8fc38: ldr             x1, [x1, #0x780]
    // 0xf8fc3c: r0 = AllocateClosure()
    //     0xf8fc3c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf8fc40: r1 = <PreviousFocusIntent>
    //     0xf8fc40: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3430] TypeArguments: <PreviousFocusIntent>
    //     0xf8fc44: ldr             x1, [x1, #0x430]
    // 0xf8fc48: stur            x0, [fp, #-0x20]
    // 0xf8fc4c: r0 = CallbackAction()
    //     0xf8fc4c: bl              #0xd126e8  ; AllocateCallbackActionStub -> CallbackAction<X0 bound Intent> (size=0x18)
    // 0xf8fc50: mov             x2, x0
    // 0xf8fc54: ldur            x0, [fp, #-0x20]
    // 0xf8fc58: stur            x2, [fp, #-0x28]
    // 0xf8fc5c: StoreField: r2->field_13 = r0
    //     0xf8fc5c: stur            w0, [x2, #0x13]
    // 0xf8fc60: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0xf8fc60: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a7a0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0xf8fc64: ldr             x1, [x1, #0x7a0]
    // 0xf8fc68: r0 = ObserverList()
    //     0xf8fc68: bl              #0x89f8bc  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0xf8fc6c: mov             x3, x0
    // 0xf8fc70: r0 = false
    //     0xf8fc70: add             x0, NULL, #0x30  ; false
    // 0xf8fc74: stur            x3, [fp, #-0x20]
    // 0xf8fc78: StoreField: r3->field_f = r0
    //     0xf8fc78: stur            w0, [x3, #0xf]
    // 0xf8fc7c: ldr             x4, [THR, #0x90]  ; THR::object_sentinel
    // 0xf8fc80: StoreField: r3->field_13 = r4
    //     0xf8fc80: stur            w4, [x3, #0x13]
    // 0xf8fc84: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0xf8fc84: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a7a0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0xf8fc88: ldr             x1, [x1, #0x7a0]
    // 0xf8fc8c: r2 = 0
    //     0xf8fc8c: mov             x2, #0
    // 0xf8fc90: r0 = _GrowableList()
    //     0xf8fc90: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xf8fc94: ldur            x1, [fp, #-0x20]
    // 0xf8fc98: StoreField: r1->field_b = r0
    //     0xf8fc98: stur            w0, [x1, #0xb]
    //     0xf8fc9c: ldurb           w16, [x1, #-1]
    //     0xf8fca0: ldurb           w17, [x0, #-1]
    //     0xf8fca4: and             x16, x17, x16, lsr #2
    //     0xf8fca8: tst             x16, HEAP, lsr #32
    //     0xf8fcac: b.eq            #0xf8fcb4
    //     0xf8fcb0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf8fcb4: mov             x0, x1
    // 0xf8fcb8: ldur            x1, [fp, #-0x28]
    // 0xf8fcbc: StoreField: r1->field_b = r0
    //     0xf8fcbc: stur            w0, [x1, #0xb]
    //     0xf8fcc0: ldurb           w16, [x1, #-1]
    //     0xf8fcc4: ldurb           w17, [x0, #-1]
    //     0xf8fcc8: and             x16, x17, x16, lsr #2
    //     0xf8fccc: tst             x16, HEAP, lsr #32
    //     0xf8fcd0: b.eq            #0xf8fcd8
    //     0xf8fcd4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf8fcd8: mov             x0, x1
    // 0xf8fcdc: ldur            x1, [fp, #-0x18]
    // 0xf8fce0: ArrayStore: r1[3] = r0  ; List_4
    //     0xf8fce0: add             x25, x1, #0x1b
    //     0xf8fce4: str             w0, [x25]
    //     0xf8fce8: tbz             w0, #0, #0xf8fd04
    //     0xf8fcec: ldurb           w16, [x1, #-1]
    //     0xf8fcf0: ldurb           w17, [x0, #-1]
    //     0xf8fcf4: and             x16, x17, x16, lsr #2
    //     0xf8fcf8: tst             x16, HEAP, lsr #32
    //     0xf8fcfc: b.eq            #0xf8fd04
    //     0xf8fd00: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xf8fd04: ldur            x0, [fp, #-0x18]
    // 0xf8fd08: r16 = DirectionalFocusIntent
    //     0xf8fd08: add             x16, PP, #0xa3, lsl #12  ; [pp+0xa3040] Type: DirectionalFocusIntent
    //     0xf8fd0c: ldr             x16, [x16, #0x40]
    // 0xf8fd10: StoreField: r0->field_1f = r16
    //     0xf8fd10: stur            w16, [x0, #0x1f]
    // 0xf8fd14: ldur            x2, [fp, #-8]
    // 0xf8fd18: r1 = Function '_handleDirectionFocus@54260463':.
    //     0xf8fd18: add             x1, PP, #0xd0, lsl #12  ; [pp+0xd0788] AnonymousClosure: (0xf8fe7c), in [package:flutter/src/material/calendar_date_picker.dart] _MonthPickerState::_handleDirectionFocus (0xf8feb8)
    //     0xf8fd1c: ldr             x1, [x1, #0x788]
    // 0xf8fd20: r0 = AllocateClosure()
    //     0xf8fd20: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf8fd24: r1 = <DirectionalFocusIntent>
    //     0xf8fd24: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3048] TypeArguments: <DirectionalFocusIntent>
    //     0xf8fd28: ldr             x1, [x1, #0x48]
    // 0xf8fd2c: stur            x0, [fp, #-0x20]
    // 0xf8fd30: r0 = CallbackAction()
    //     0xf8fd30: bl              #0xd126e8  ; AllocateCallbackActionStub -> CallbackAction<X0 bound Intent> (size=0x18)
    // 0xf8fd34: mov             x2, x0
    // 0xf8fd38: ldur            x0, [fp, #-0x20]
    // 0xf8fd3c: stur            x2, [fp, #-0x28]
    // 0xf8fd40: StoreField: r2->field_13 = r0
    //     0xf8fd40: stur            w0, [x2, #0x13]
    // 0xf8fd44: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0xf8fd44: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a7a0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0xf8fd48: ldr             x1, [x1, #0x7a0]
    // 0xf8fd4c: r0 = ObserverList()
    //     0xf8fd4c: bl              #0x89f8bc  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0xf8fd50: mov             x3, x0
    // 0xf8fd54: r0 = false
    //     0xf8fd54: add             x0, NULL, #0x30  ; false
    // 0xf8fd58: stur            x3, [fp, #-0x20]
    // 0xf8fd5c: StoreField: r3->field_f = r0
    //     0xf8fd5c: stur            w0, [x3, #0xf]
    // 0xf8fd60: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xf8fd64: StoreField: r3->field_13 = r0
    //     0xf8fd64: stur            w0, [x3, #0x13]
    // 0xf8fd68: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0xf8fd68: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a7a0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0xf8fd6c: ldr             x1, [x1, #0x7a0]
    // 0xf8fd70: r2 = 0
    //     0xf8fd70: mov             x2, #0
    // 0xf8fd74: r0 = _GrowableList()
    //     0xf8fd74: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xf8fd78: ldur            x1, [fp, #-0x20]
    // 0xf8fd7c: StoreField: r1->field_b = r0
    //     0xf8fd7c: stur            w0, [x1, #0xb]
    //     0xf8fd80: ldurb           w16, [x1, #-1]
    //     0xf8fd84: ldurb           w17, [x0, #-1]
    //     0xf8fd88: and             x16, x17, x16, lsr #2
    //     0xf8fd8c: tst             x16, HEAP, lsr #32
    //     0xf8fd90: b.eq            #0xf8fd98
    //     0xf8fd94: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf8fd98: mov             x0, x1
    // 0xf8fd9c: ldur            x1, [fp, #-0x28]
    // 0xf8fda0: StoreField: r1->field_b = r0
    //     0xf8fda0: stur            w0, [x1, #0xb]
    //     0xf8fda4: ldurb           w16, [x1, #-1]
    //     0xf8fda8: ldurb           w17, [x0, #-1]
    //     0xf8fdac: and             x16, x17, x16, lsr #2
    //     0xf8fdb0: tst             x16, HEAP, lsr #32
    //     0xf8fdb4: b.eq            #0xf8fdbc
    //     0xf8fdb8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf8fdbc: mov             x0, x1
    // 0xf8fdc0: ldur            x1, [fp, #-0x18]
    // 0xf8fdc4: ArrayStore: r1[5] = r0  ; List_4
    //     0xf8fdc4: add             x25, x1, #0x23
    //     0xf8fdc8: str             w0, [x25]
    //     0xf8fdcc: tbz             w0, #0, #0xf8fde8
    //     0xf8fdd0: ldurb           w16, [x1, #-1]
    //     0xf8fdd4: ldurb           w17, [x0, #-1]
    //     0xf8fdd8: and             x16, x17, x16, lsr #2
    //     0xf8fddc: tst             x16, HEAP, lsr #32
    //     0xf8fde0: b.eq            #0xf8fde8
    //     0xf8fde4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xf8fde8: r16 = <Type, Action<Intent>>
    //     0xf8fde8: add             x16, PP, #0x84, lsl #12  ; [pp+0x84b80] TypeArguments: <Type, Action<Intent>>
    //     0xf8fdec: ldr             x16, [x16, #0xb80]
    // 0xf8fdf0: ldur            lr, [fp, #-0x18]
    // 0xf8fdf4: stp             lr, x16, [SP]
    // 0xf8fdf8: r0 = Map._fromLiteral()
    //     0xf8fdf8: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xf8fdfc: ldur            x1, [fp, #-8]
    // 0xf8fe00: StoreField: r1->field_2b = r0
    //     0xf8fe00: stur            w0, [x1, #0x2b]
    //     0xf8fe04: ldurb           w16, [x1, #-1]
    //     0xf8fe08: ldurb           w17, [x0, #-1]
    //     0xf8fe0c: and             x16, x17, x16, lsr #2
    //     0xf8fe10: tst             x16, HEAP, lsr #32
    //     0xf8fe14: b.eq            #0xf8fe1c
    //     0xf8fe18: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf8fe1c: r0 = FocusNode()
    //     0xf8fe1c: bl              #0xd4952c  ; AllocateFocusNodeStub -> FocusNode (size=0x68)
    // 0xf8fe20: stur            x0, [fp, #-0x18]
    // 0xf8fe24: r16 = "Day Grid"
    //     0xf8fe24: add             x16, PP, #0xd0, lsl #12  ; [pp+0xd0790] "Day Grid"
    //     0xf8fe28: ldr             x16, [x16, #0x790]
    // 0xf8fe2c: str             x16, [SP]
    // 0xf8fe30: mov             x1, x0
    // 0xf8fe34: r4 = const [0, 0x2, 0x1, 0x1, debugLabel, 0x1, null]
    //     0xf8fe34: ldr             x4, [PP, #0x1e10]  ; [pp+0x1e10] List(7) [0, 0x2, 0x1, 0x1, "debugLabel", 0x1, Null]
    // 0xf8fe38: r0 = FocusNode()
    //     0xf8fe38: bl              #0x83cf84  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::FocusNode
    // 0xf8fe3c: ldur            x0, [fp, #-0x18]
    // 0xf8fe40: ldur            x1, [fp, #-8]
    // 0xf8fe44: StoreField: r1->field_2f = r0
    //     0xf8fe44: stur            w0, [x1, #0x2f]
    //     0xf8fe48: ldurb           w16, [x1, #-1]
    //     0xf8fe4c: ldurb           w17, [x0, #-1]
    //     0xf8fe50: and             x16, x17, x16, lsr #2
    //     0xf8fe54: tst             x16, HEAP, lsr #32
    //     0xf8fe58: b.eq            #0xf8fe60
    //     0xf8fe5c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf8fe60: r0 = Null
    //     0xf8fe60: mov             x0, NULL
    // 0xf8fe64: LeaveFrame
    //     0xf8fe64: mov             SP, fp
    //     0xf8fe68: ldp             fp, lr, [SP], #0x10
    // 0xf8fe6c: ret
    //     0xf8fe6c: ret             
    // 0xf8fe70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf8fe70: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf8fe74: b               #0xf8fa84
    // 0xf8fe78: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf8fe78: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleDirectionFocus(dynamic, DirectionalFocusIntent) {
    // ** addr: 0xf8fe7c, size: 0x3c
    // 0xf8fe7c: EnterFrame
    //     0xf8fe7c: stp             fp, lr, [SP, #-0x10]!
    //     0xf8fe80: mov             fp, SP
    // 0xf8fe84: ldr             x0, [fp, #0x18]
    // 0xf8fe88: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf8fe88: ldur            w1, [x0, #0x17]
    // 0xf8fe8c: DecompressPointer r1
    //     0xf8fe8c: add             x1, x1, HEAP, lsl #32
    // 0xf8fe90: CheckStackOverflow
    //     0xf8fe90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf8fe94: cmp             SP, x16
    //     0xf8fe98: b.ls            #0xf8feb0
    // 0xf8fe9c: ldr             x2, [fp, #0x10]
    // 0xf8fea0: r0 = _handleDirectionFocus()
    //     0xf8fea0: bl              #0xf8feb8  ; [package:flutter/src/material/calendar_date_picker.dart] _MonthPickerState::_handleDirectionFocus
    // 0xf8fea4: LeaveFrame
    //     0xf8fea4: mov             SP, fp
    //     0xf8fea8: ldp             fp, lr, [SP], #0x10
    // 0xf8feac: ret
    //     0xf8feac: ret             
    // 0xf8feb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf8feb0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf8feb4: b               #0xf8fe9c
  }
  _ _handleDirectionFocus(/* No info */) {
    // ** addr: 0xf8feb8, size: 0x70
    // 0xf8feb8: EnterFrame
    //     0xf8feb8: stp             fp, lr, [SP, #-0x10]!
    //     0xf8febc: mov             fp, SP
    // 0xf8fec0: AllocStack(0x10)
    //     0xf8fec0: sub             SP, SP, #0x10
    // 0xf8fec4: SetupParameters(_MonthPickerState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xf8fec4: stur            x1, [fp, #-8]
    //     0xf8fec8: stur            x2, [fp, #-0x10]
    // 0xf8fecc: CheckStackOverflow
    //     0xf8fecc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf8fed0: cmp             SP, x16
    //     0xf8fed4: b.ls            #0xf8ff20
    // 0xf8fed8: r1 = 2
    //     0xf8fed8: mov             x1, #2
    // 0xf8fedc: r0 = AllocateContext()
    //     0xf8fedc: bl              #0x13de838  ; AllocateContextStub
    // 0xf8fee0: mov             x1, x0
    // 0xf8fee4: ldur            x0, [fp, #-8]
    // 0xf8fee8: StoreField: r1->field_f = r0
    //     0xf8fee8: stur            w0, [x1, #0xf]
    // 0xf8feec: ldur            x2, [fp, #-0x10]
    // 0xf8fef0: StoreField: r1->field_13 = r2
    //     0xf8fef0: stur            w2, [x1, #0x13]
    // 0xf8fef4: mov             x2, x1
    // 0xf8fef8: r1 = Function '<anonymous closure>':.
    //     0xf8fef8: add             x1, PP, #0xd0, lsl #12  ; [pp+0xd0798] AnonymousClosure: (0xf8ff28), in [package:flutter/src/material/calendar_date_picker.dart] _MonthPickerState::_handleDirectionFocus (0xf8feb8)
    //     0xf8fefc: ldr             x1, [x1, #0x798]
    // 0xf8ff00: r0 = AllocateClosure()
    //     0xf8ff00: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf8ff04: ldur            x1, [fp, #-8]
    // 0xf8ff08: mov             x2, x0
    // 0xf8ff0c: r0 = setState()
    //     0xf8ff0c: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xf8ff10: r0 = Null
    //     0xf8ff10: mov             x0, NULL
    // 0xf8ff14: LeaveFrame
    //     0xf8ff14: mov             SP, fp
    //     0xf8ff18: ldp             fp, lr, [SP], #0x10
    // 0xf8ff1c: ret
    //     0xf8ff1c: ret             
    // 0xf8ff20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf8ff20: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf8ff24: b               #0xf8fed8
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xf8ff28, size: 0x114
    // 0xf8ff28: EnterFrame
    //     0xf8ff28: stp             fp, lr, [SP, #-0x10]!
    //     0xf8ff2c: mov             fp, SP
    // 0xf8ff30: AllocStack(0x8)
    //     0xf8ff30: sub             SP, SP, #8
    // 0xf8ff34: SetupParameters([dynamic _ /* r0 */])
    //     0xf8ff34: ldr             x0, [fp, #0x10]
    //     0xf8ff38: ldur            w4, [x0, #0x17]
    //     0xf8ff3c: add             x4, x4, HEAP, lsl #32
    //     0xf8ff40: stur            x4, [fp, #-8]
    // 0xf8ff44: CheckStackOverflow
    //     0xf8ff44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf8ff48: cmp             SP, x16
    //     0xf8ff4c: b.ls            #0xf9001c
    // 0xf8ff50: LoadField: r1 = r4->field_f
    //     0xf8ff50: ldur            w1, [x4, #0xf]
    // 0xf8ff54: DecompressPointer r1
    //     0xf8ff54: add             x1, x1, HEAP, lsl #32
    // 0xf8ff58: LoadField: r2 = r1->field_33
    //     0xf8ff58: ldur            w2, [x1, #0x33]
    // 0xf8ff5c: DecompressPointer r2
    //     0xf8ff5c: add             x2, x2, HEAP, lsl #32
    // 0xf8ff60: cmp             w2, NULL
    // 0xf8ff64: b.eq            #0xf90024
    // 0xf8ff68: LoadField: r0 = r4->field_13
    //     0xf8ff68: ldur            w0, [x4, #0x13]
    // 0xf8ff6c: DecompressPointer r0
    //     0xf8ff6c: add             x0, x0, HEAP, lsl #32
    // 0xf8ff70: LoadField: r3 = r0->field_7
    //     0xf8ff70: ldur            w3, [x0, #7]
    // 0xf8ff74: DecompressPointer r3
    //     0xf8ff74: add             x3, x3, HEAP, lsl #32
    // 0xf8ff78: r0 = _nextDateInDirection()
    //     0xf8ff78: bl              #0xf900d8  ; [package:flutter/src/material/calendar_date_picker.dart] _MonthPickerState::_nextDateInDirection
    // 0xf8ff7c: mov             x1, x0
    // 0xf8ff80: cmp             w1, NULL
    // 0xf8ff84: b.eq            #0xf9000c
    // 0xf8ff88: ldur            x4, [fp, #-8]
    // 0xf8ff8c: LoadField: r2 = r4->field_f
    //     0xf8ff8c: ldur            w2, [x4, #0xf]
    // 0xf8ff90: DecompressPointer r2
    //     0xf8ff90: add             x2, x2, HEAP, lsl #32
    // 0xf8ff94: mov             x0, x1
    // 0xf8ff98: StoreField: r2->field_33 = r0
    //     0xf8ff98: stur            w0, [x2, #0x33]
    //     0xf8ff9c: ldurb           w16, [x2, #-1]
    //     0xf8ffa0: ldurb           w17, [x0, #-1]
    //     0xf8ffa4: and             x16, x17, x16, lsr #2
    //     0xf8ffa8: tst             x16, HEAP, lsr #32
    //     0xf8ffac: b.eq            #0xf8ffb4
    //     0xf8ffb0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf8ffb4: LoadField: r0 = r2->field_b
    //     0xf8ffb4: ldur            w0, [x2, #0xb]
    // 0xf8ffb8: DecompressPointer r0
    //     0xf8ffb8: add             x0, x0, HEAP, lsl #32
    // 0xf8ffbc: cmp             w0, NULL
    // 0xf8ffc0: b.eq            #0xf90028
    // 0xf8ffc4: LoadField: r3 = r2->field_1b
    //     0xf8ffc4: ldur            w3, [x2, #0x1b]
    // 0xf8ffc8: DecompressPointer r3
    //     0xf8ffc8: add             x3, x3, HEAP, lsl #32
    // 0xf8ffcc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf8ffd0: cmp             w3, w16
    // 0xf8ffd4: b.eq            #0xf9002c
    // 0xf8ffd8: mov             x2, x1
    // 0xf8ffdc: r1 = Instance_GregorianCalendarDelegate
    //     0xf8ffdc: add             x1, PP, #0x28, lsl #12  ; [pp+0x28538] Obj!GregorianCalendarDelegate@129edd1
    //     0xf8ffe0: ldr             x1, [x1, #0x538]
    // 0xf8ffe4: r0 = isSameMonth()
    //     0xf8ffe4: bl              #0xdef958  ; [package:flutter/src/material/date.dart] CalendarDelegate::isSameMonth
    // 0xf8ffe8: tbz             w0, #4, #0xf9000c
    // 0xf8ffec: ldur            x0, [fp, #-8]
    // 0xf8fff0: LoadField: r1 = r0->field_f
    //     0xf8fff0: ldur            w1, [x0, #0xf]
    // 0xf8fff4: DecompressPointer r1
    //     0xf8fff4: add             x1, x1, HEAP, lsl #32
    // 0xf8fff8: LoadField: r2 = r1->field_33
    //     0xf8fff8: ldur            w2, [x1, #0x33]
    // 0xf8fffc: DecompressPointer r2
    //     0xf8fffc: add             x2, x2, HEAP, lsl #32
    // 0xf90000: cmp             w2, NULL
    // 0xf90004: b.eq            #0xf90038
    // 0xf90008: r0 = _showMonth()
    //     0xf90008: bl              #0xf9003c  ; [package:flutter/src/material/calendar_date_picker.dart] _MonthPickerState::_showMonth
    // 0xf9000c: r0 = Null
    //     0xf9000c: mov             x0, NULL
    // 0xf90010: LeaveFrame
    //     0xf90010: mov             SP, fp
    //     0xf90014: ldp             fp, lr, [SP], #0x10
    // 0xf90018: ret
    //     0xf90018: ret             
    // 0xf9001c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf9001c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf90020: b               #0xf8ff50
    // 0xf90024: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf90024: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf90028: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf90028: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf9002c: r9 = _currentMonth
    //     0xf9002c: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa3fa8] Field <_MonthPickerState@54260463._currentMonth@54260463>: late (offset: 0x1c)
    //     0xf90030: ldr             x9, [x9, #0xfa8]
    // 0xf90034: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf90034: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xf90038: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf90038: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _showMonth(/* No info */) {
    // ** addr: 0xf9003c, size: 0x9c
    // 0xf9003c: EnterFrame
    //     0xf9003c: stp             fp, lr, [SP, #-0x10]!
    //     0xf90040: mov             fp, SP
    // 0xf90044: AllocStack(0x8)
    //     0xf90044: sub             SP, SP, #8
    // 0xf90048: SetupParameters(_MonthPickerState this /* r1 => r0, fp-0x8 */)
    //     0xf90048: mov             x0, x1
    //     0xf9004c: stur            x1, [fp, #-8]
    // 0xf90050: CheckStackOverflow
    //     0xf90050: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf90054: cmp             SP, x16
    //     0xf90058: b.ls            #0xf900c0
    // 0xf9005c: LoadField: r1 = r0->field_b
    //     0xf9005c: ldur            w1, [x0, #0xb]
    // 0xf90060: DecompressPointer r1
    //     0xf90060: add             x1, x1, HEAP, lsl #32
    // 0xf90064: cmp             w1, NULL
    // 0xf90068: b.eq            #0xf900c8
    // 0xf9006c: LoadField: r3 = r1->field_13
    //     0xf9006c: ldur            w3, [x1, #0x13]
    // 0xf90070: DecompressPointer r3
    //     0xf90070: add             x3, x3, HEAP, lsl #32
    // 0xf90074: mov             x1, x3
    // 0xf90078: r0 = monthDelta()
    //     0xf90078: bl              #0xdeef48  ; [package:flutter/src/material/date.dart] DateUtils::monthDelta
    // 0xf9007c: mov             x1, x0
    // 0xf90080: ldur            x0, [fp, #-8]
    // 0xf90084: LoadField: r2 = r0->field_1f
    //     0xf90084: ldur            w2, [x0, #0x1f]
    // 0xf90088: DecompressPointer r2
    //     0xf90088: add             x2, x2, HEAP, lsl #32
    // 0xf9008c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf90090: cmp             w2, w16
    // 0xf90094: b.eq            #0xf900cc
    // 0xf90098: mov             x16, x1
    // 0xf9009c: mov             x1, x2
    // 0xf900a0: mov             x2, x16
    // 0xf900a4: r3 = Instance_Duration
    //     0xf900a4: add             x3, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xf900a8: ldr             x3, [x3, #0x318]
    // 0xf900ac: r0 = animateToPage()
    //     0xf900ac: bl              #0xcec0dc  ; [package:flutter/src/widgets/page_view.dart] PageController::animateToPage
    // 0xf900b0: r0 = Null
    //     0xf900b0: mov             x0, NULL
    // 0xf900b4: LeaveFrame
    //     0xf900b4: mov             SP, fp
    //     0xf900b8: ldp             fp, lr, [SP], #0x10
    // 0xf900bc: ret
    //     0xf900bc: ret             
    // 0xf900c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf900c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf900c4: b               #0xf9005c
    // 0xf900c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf900c8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf900cc: r9 = _pageController
    //     0xf900cc: add             x9, PP, #0xd0, lsl #12  ; [pp+0xd0738] Field <_MonthPickerState@54260463._pageController@54260463>: late (offset: 0x20)
    //     0xf900d0: ldr             x9, [x9, #0x738]
    // 0xf900d4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf900d4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _nextDateInDirection(/* No info */) {
    // ** addr: 0xf900d8, size: 0x130
    // 0xf900d8: EnterFrame
    //     0xf900d8: stp             fp, lr, [SP, #-0x10]!
    //     0xf900dc: mov             fp, SP
    // 0xf900e0: AllocStack(0x18)
    //     0xf900e0: sub             SP, SP, #0x18
    // 0xf900e4: SetupParameters(_MonthPickerState this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r2, fp-0x18 */)
    //     0xf900e4: mov             x0, x2
    //     0xf900e8: stur            x2, [fp, #-0x10]
    //     0xf900ec: mov             x2, x3
    //     0xf900f0: stur            x3, [fp, #-0x18]
    //     0xf900f4: mov             x3, x1
    //     0xf900f8: stur            x1, [fp, #-8]
    // 0xf900fc: CheckStackOverflow
    //     0xf900fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf90100: cmp             SP, x16
    //     0xf90104: b.ls            #0xf901e4
    // 0xf90108: LoadField: r1 = r3->field_f
    //     0xf90108: ldur            w1, [x3, #0xf]
    // 0xf9010c: DecompressPointer r1
    //     0xf9010c: add             x1, x1, HEAP, lsl #32
    // 0xf90110: cmp             w1, NULL
    // 0xf90114: b.eq            #0xf901ec
    // 0xf90118: r0 = of()
    //     0xf90118: bl              #0x87371c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0xf9011c: mov             x1, x0
    // 0xf90120: ldur            x0, [fp, #-8]
    // 0xf90124: LoadField: r2 = r0->field_b
    //     0xf90124: ldur            w2, [x0, #0xb]
    // 0xf90128: DecompressPointer r2
    //     0xf90128: add             x2, x2, HEAP, lsl #32
    // 0xf9012c: cmp             w2, NULL
    // 0xf90130: b.eq            #0xf901f0
    // 0xf90134: mov             x3, x1
    // 0xf90138: mov             x1, x0
    // 0xf9013c: ldur            x2, [fp, #-0x18]
    // 0xf90140: r0 = _dayDirectionOffset()
    //     0xf90140: bl              #0xf90340  ; [package:flutter/src/material/calendar_date_picker.dart] _MonthPickerState::_dayDirectionOffset
    // 0xf90144: ldur            x1, [fp, #-0x10]
    // 0xf90148: mov             x2, x0
    // 0xf9014c: r0 = addDaysToDate()
    //     0xf9014c: bl              #0xf90208  ; [package:flutter/src/material/date.dart] DateUtils::addDaysToDate
    // 0xf90150: stur            x0, [fp, #-0x10]
    // 0xf90154: CheckStackOverflow
    //     0xf90154: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf90158: cmp             SP, x16
    //     0xf9015c: b.ls            #0xf901f4
    // 0xf90160: ldur            x3, [fp, #-8]
    // 0xf90164: LoadField: r1 = r3->field_b
    //     0xf90164: ldur            w1, [x3, #0xb]
    // 0xf90168: DecompressPointer r1
    //     0xf90168: add             x1, x1, HEAP, lsl #32
    // 0xf9016c: cmp             w1, NULL
    // 0xf90170: b.eq            #0xf901fc
    // 0xf90174: LoadField: r2 = r1->field_13
    //     0xf90174: ldur            w2, [x1, #0x13]
    // 0xf90178: DecompressPointer r2
    //     0xf90178: add             x2, x2, HEAP, lsl #32
    // 0xf9017c: mov             x1, x0
    // 0xf90180: r0 = isBefore()
    //     0xf90180: bl              #0xd183f0  ; [dart:core] DateTime::isBefore
    // 0xf90184: tbz             w0, #4, #0xf901d4
    // 0xf90188: ldur            x0, [fp, #-8]
    // 0xf9018c: LoadField: r1 = r0->field_b
    //     0xf9018c: ldur            w1, [x0, #0xb]
    // 0xf90190: DecompressPointer r1
    //     0xf90190: add             x1, x1, HEAP, lsl #32
    // 0xf90194: cmp             w1, NULL
    // 0xf90198: b.eq            #0xf90200
    // 0xf9019c: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xf9019c: ldur            w2, [x1, #0x17]
    // 0xf901a0: DecompressPointer r2
    //     0xf901a0: add             x2, x2, HEAP, lsl #32
    // 0xf901a4: ldur            x1, [fp, #-0x10]
    // 0xf901a8: r0 = isAfter()
    //     0xf901a8: bl              #0xd183d4  ; [dart:core] DateTime::isAfter
    // 0xf901ac: tbz             w0, #4, #0xf901d4
    // 0xf901b0: ldur            x1, [fp, #-8]
    // 0xf901b4: LoadField: r2 = r1->field_b
    //     0xf901b4: ldur            w2, [x1, #0xb]
    // 0xf901b8: DecompressPointer r2
    //     0xf901b8: add             x2, x2, HEAP, lsl #32
    // 0xf901bc: cmp             w2, NULL
    // 0xf901c0: b.eq            #0xf90204
    // 0xf901c4: ldur            x0, [fp, #-0x10]
    // 0xf901c8: LeaveFrame
    //     0xf901c8: mov             SP, fp
    //     0xf901cc: ldp             fp, lr, [SP], #0x10
    // 0xf901d0: ret
    //     0xf901d0: ret             
    // 0xf901d4: r0 = Null
    //     0xf901d4: mov             x0, NULL
    // 0xf901d8: LeaveFrame
    //     0xf901d8: mov             SP, fp
    //     0xf901dc: ldp             fp, lr, [SP], #0x10
    // 0xf901e0: ret
    //     0xf901e0: ret             
    // 0xf901e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf901e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf901e8: b               #0xf90108
    // 0xf901ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf901ec: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf901f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf901f0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf901f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf901f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf901f8: b               #0xf90160
    // 0xf901fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf901fc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf90200: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf90200: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf90204: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf90204: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _dayDirectionOffset(/* No info */) {
    // ** addr: 0xf90340, size: 0x9c
    // 0xf90340: EnterFrame
    //     0xf90340: stp             fp, lr, [SP, #-0x10]!
    //     0xf90344: mov             fp, SP
    // 0xf90348: CheckStackOverflow
    //     0xf90348: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf9034c: cmp             SP, x16
    //     0xf90350: b.ls            #0xf903d0
    // 0xf90354: r16 = Instance_TextDirection
    //     0xf90354: ldr             x16, [PP, #0x2578]  ; [pp+0x2578] Obj!TextDirection@12c7381
    // 0xf90358: cmp             w3, w16
    // 0xf9035c: b.ne            #0xf903a0
    // 0xf90360: r16 = Instance_TraversalDirection
    //     0xf90360: add             x16, PP, #0xad, lsl #12  ; [pp+0xadd98] Obj!TraversalDirection@12c31a1
    //     0xf90364: ldr             x16, [x16, #0xd98]
    // 0xf90368: cmp             w2, w16
    // 0xf9036c: b.ne            #0xf9037c
    // 0xf90370: r0 = Instance_TraversalDirection
    //     0xf90370: add             x0, PP, #0xad, lsl #12  ; [pp+0xaddc0] Obj!TraversalDirection@12c3181
    //     0xf90374: ldr             x0, [x0, #0xdc0]
    // 0xf90378: b               #0xf9039c
    // 0xf9037c: r16 = Instance_TraversalDirection
    //     0xf9037c: add             x16, PP, #0xad, lsl #12  ; [pp+0xaddc0] Obj!TraversalDirection@12c3181
    //     0xf90380: ldr             x16, [x16, #0xdc0]
    // 0xf90384: cmp             w2, w16
    // 0xf90388: b.ne            #0xf90398
    // 0xf9038c: r0 = Instance_TraversalDirection
    //     0xf9038c: add             x0, PP, #0xad, lsl #12  ; [pp+0xadd98] Obj!TraversalDirection@12c31a1
    //     0xf90390: ldr             x0, [x0, #0xd98]
    // 0xf90394: b               #0xf9039c
    // 0xf90398: mov             x0, x2
    // 0xf9039c: mov             x2, x0
    // 0xf903a0: r1 = _ConstMap len:4
    //     0xf903a0: add             x1, PP, #0xd0, lsl #12  ; [pp+0xd07a0] Map<TraversalDirection, int>(4)
    //     0xf903a4: ldr             x1, [x1, #0x7a0]
    // 0xf903a8: r0 = []()
    //     0xf903a8: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0xf903ac: cmp             w0, NULL
    // 0xf903b0: b.eq            #0xf903d8
    // 0xf903b4: r1 = LoadInt32Instr(r0)
    //     0xf903b4: sbfx            x1, x0, #1, #0x1f
    //     0xf903b8: tbz             w0, #0, #0xf903c0
    //     0xf903bc: ldur            x1, [x0, #7]
    // 0xf903c0: mov             x0, x1
    // 0xf903c4: LeaveFrame
    //     0xf903c4: mov             SP, fp
    //     0xf903c8: ldp             fp, lr, [SP], #0x10
    // 0xf903cc: ret
    //     0xf903cc: ret             
    // 0xf903d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf903d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf903d4: b               #0xf90354
    // 0xf903d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf903d8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleGridPreviousFocus(dynamic, PreviousFocusIntent) {
    // ** addr: 0xf903dc, size: 0x3c
    // 0xf903dc: EnterFrame
    //     0xf903dc: stp             fp, lr, [SP, #-0x10]!
    //     0xf903e0: mov             fp, SP
    // 0xf903e4: ldr             x0, [fp, #0x18]
    // 0xf903e8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf903e8: ldur            w1, [x0, #0x17]
    // 0xf903ec: DecompressPointer r1
    //     0xf903ec: add             x1, x1, HEAP, lsl #32
    // 0xf903f0: CheckStackOverflow
    //     0xf903f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf903f4: cmp             SP, x16
    //     0xf903f8: b.ls            #0xf90410
    // 0xf903fc: ldr             x2, [fp, #0x10]
    // 0xf90400: r0 = _handleGridPreviousFocus()
    //     0xf90400: bl              #0xf90418  ; [package:flutter/src/material/calendar_date_picker.dart] _MonthPickerState::_handleGridPreviousFocus
    // 0xf90404: LeaveFrame
    //     0xf90404: mov             SP, fp
    //     0xf90408: ldp             fp, lr, [SP], #0x10
    // 0xf9040c: ret
    //     0xf9040c: ret             
    // 0xf90410: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf90410: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf90414: b               #0xf903fc
  }
  _ _handleGridPreviousFocus(/* No info */) {
    // ** addr: 0xf90418, size: 0x70
    // 0xf90418: EnterFrame
    //     0xf90418: stp             fp, lr, [SP, #-0x10]!
    //     0xf9041c: mov             fp, SP
    // 0xf90420: AllocStack(0x8)
    //     0xf90420: sub             SP, SP, #8
    // 0xf90424: SetupParameters(_MonthPickerState this /* r1 => r0, fp-0x8 */)
    //     0xf90424: mov             x0, x1
    //     0xf90428: stur            x1, [fp, #-8]
    // 0xf9042c: CheckStackOverflow
    //     0xf9042c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf90430: cmp             SP, x16
    //     0xf90434: b.ls            #0xf90474
    // 0xf90438: LoadField: r1 = r0->field_2f
    //     0xf90438: ldur            w1, [x0, #0x2f]
    // 0xf9043c: DecompressPointer r1
    //     0xf9043c: add             x1, x1, HEAP, lsl #32
    // 0xf90440: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf90444: cmp             w1, w16
    // 0xf90448: b.eq            #0xf9047c
    // 0xf9044c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xf9044c: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xf90450: r0 = requestFocus()
    //     0xf90450: bl              #0x83e7b8  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::requestFocus
    // 0xf90454: ldur            x0, [fp, #-8]
    // 0xf90458: LoadField: r1 = r0->field_2f
    //     0xf90458: ldur            w1, [x0, #0x2f]
    // 0xf9045c: DecompressPointer r1
    //     0xf9045c: add             x1, x1, HEAP, lsl #32
    // 0xf90460: r0 = previousFocus()
    //     0xf90460: bl              #0x83f3e0  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::previousFocus
    // 0xf90464: r0 = Null
    //     0xf90464: mov             x0, NULL
    // 0xf90468: LeaveFrame
    //     0xf90468: mov             SP, fp
    //     0xf9046c: ldp             fp, lr, [SP], #0x10
    // 0xf90470: ret
    //     0xf90470: ret             
    // 0xf90474: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf90474: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf90478: b               #0xf90438
    // 0xf9047c: r9 = _dayGridFocus
    //     0xf9047c: add             x9, PP, #0xd0, lsl #12  ; [pp+0xd0730] Field <_MonthPickerState@54260463._dayGridFocus@54260463>: late (offset: 0x30)
    //     0xf90480: ldr             x9, [x9, #0x730]
    // 0xf90484: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf90484: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleGridNextFocus(dynamic, NextFocusIntent) {
    // ** addr: 0xf90488, size: 0x3c
    // 0xf90488: EnterFrame
    //     0xf90488: stp             fp, lr, [SP, #-0x10]!
    //     0xf9048c: mov             fp, SP
    // 0xf90490: ldr             x0, [fp, #0x18]
    // 0xf90494: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf90494: ldur            w1, [x0, #0x17]
    // 0xf90498: DecompressPointer r1
    //     0xf90498: add             x1, x1, HEAP, lsl #32
    // 0xf9049c: CheckStackOverflow
    //     0xf9049c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf904a0: cmp             SP, x16
    //     0xf904a4: b.ls            #0xf904bc
    // 0xf904a8: ldr             x2, [fp, #0x10]
    // 0xf904ac: r0 = _handleGridNextFocus()
    //     0xf904ac: bl              #0xf904c4  ; [package:flutter/src/material/calendar_date_picker.dart] _MonthPickerState::_handleGridNextFocus
    // 0xf904b0: LeaveFrame
    //     0xf904b0: mov             SP, fp
    //     0xf904b4: ldp             fp, lr, [SP], #0x10
    // 0xf904b8: ret
    //     0xf904b8: ret             
    // 0xf904bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf904bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf904c0: b               #0xf904a8
  }
  _ _handleGridNextFocus(/* No info */) {
    // ** addr: 0xf904c4, size: 0x70
    // 0xf904c4: EnterFrame
    //     0xf904c4: stp             fp, lr, [SP, #-0x10]!
    //     0xf904c8: mov             fp, SP
    // 0xf904cc: AllocStack(0x8)
    //     0xf904cc: sub             SP, SP, #8
    // 0xf904d0: SetupParameters(_MonthPickerState this /* r1 => r0, fp-0x8 */)
    //     0xf904d0: mov             x0, x1
    //     0xf904d4: stur            x1, [fp, #-8]
    // 0xf904d8: CheckStackOverflow
    //     0xf904d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf904dc: cmp             SP, x16
    //     0xf904e0: b.ls            #0xf90520
    // 0xf904e4: LoadField: r1 = r0->field_2f
    //     0xf904e4: ldur            w1, [x0, #0x2f]
    // 0xf904e8: DecompressPointer r1
    //     0xf904e8: add             x1, x1, HEAP, lsl #32
    // 0xf904ec: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf904f0: cmp             w1, w16
    // 0xf904f4: b.eq            #0xf90528
    // 0xf904f8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xf904f8: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xf904fc: r0 = requestFocus()
    //     0xf904fc: bl              #0x83e7b8  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::requestFocus
    // 0xf90500: ldur            x0, [fp, #-8]
    // 0xf90504: LoadField: r1 = r0->field_2f
    //     0xf90504: ldur            w1, [x0, #0x2f]
    // 0xf90508: DecompressPointer r1
    //     0xf90508: add             x1, x1, HEAP, lsl #32
    // 0xf9050c: r0 = nextFocus()
    //     0xf9050c: bl              #0x83f4c4  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::nextFocus
    // 0xf90510: r0 = Null
    //     0xf90510: mov             x0, NULL
    // 0xf90514: LeaveFrame
    //     0xf90514: mov             SP, fp
    //     0xf90518: ldp             fp, lr, [SP], #0x10
    // 0xf9051c: ret
    //     0xf9051c: ret             
    // 0xf90520: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf90520: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf90524: b               #0xf904e4
    // 0xf90528: r9 = _dayGridFocus
    //     0xf90528: add             x9, PP, #0xd0, lsl #12  ; [pp+0xd0730] Field <_MonthPickerState@54260463._dayGridFocus@54260463>: late (offset: 0x30)
    //     0xf9052c: ldr             x9, [x9, #0x730]
    // 0xf90530: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf90530: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _MonthPickerState(/* No info */) {
    // ** addr: 0xfa0fe4, size: 0x68
    // 0xfa0fe4: EnterFrame
    //     0xfa0fe4: stp             fp, lr, [SP, #-0x10]!
    //     0xfa0fe8: mov             fp, SP
    // 0xfa0fec: AllocStack(0x8)
    //     0xfa0fec: sub             SP, SP, #8
    // 0xfa0ff0: r2 = ""
    //     0xfa0ff0: ldr             x2, [PP, #0x900]  ; [pp+0x900] ""
    // 0xfa0ff4: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa0ff8: mov             x3, x1
    // 0xfa0ffc: stur            x1, [fp, #-8]
    // 0xfa1000: ArrayStore: r3[0] = r2  ; List_4
    //     0xfa1000: stur            w2, [x3, #0x17]
    // 0xfa1004: StoreField: r3->field_1b = r0
    //     0xfa1004: stur            w0, [x3, #0x1b]
    // 0xfa1008: StoreField: r3->field_1f = r0
    //     0xfa1008: stur            w0, [x3, #0x1f]
    // 0xfa100c: StoreField: r3->field_23 = r0
    //     0xfa100c: stur            w0, [x3, #0x23]
    // 0xfa1010: StoreField: r3->field_2f = r0
    //     0xfa1010: stur            w0, [x3, #0x2f]
    // 0xfa1014: r1 = <State<StatefulWidget>>
    //     0xfa1014: ldr             x1, [PP, #0x4df8]  ; [pp+0x4df8] TypeArguments: <State<StatefulWidget>>
    // 0xfa1018: r0 = LabeledGlobalKey()
    //     0xfa1018: bl              #0x856cf8  ; AllocateLabeledGlobalKeyStub -> LabeledGlobalKey<X0 bound State> (size=0x10)
    // 0xfa101c: ldur            x1, [fp, #-8]
    // 0xfa1020: StoreField: r1->field_13 = r0
    //     0xfa1020: stur            w0, [x1, #0x13]
    //     0xfa1024: ldurb           w16, [x1, #-1]
    //     0xfa1028: ldurb           w17, [x0, #-1]
    //     0xfa102c: and             x16, x17, x16, lsr #2
    //     0xfa1030: tst             x16, HEAP, lsr #32
    //     0xfa1034: b.eq            #0xfa103c
    //     0xfa1038: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfa103c: r0 = Null
    //     0xfa103c: mov             x0, NULL
    // 0xfa1040: LeaveFrame
    //     0xfa1040: mov             SP, fp
    //     0xfa1044: ldp             fp, lr, [SP], #0x10
    // 0xfa1048: ret
    //     0xfa1048: ret             
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10e58c8, size: 0x84
    // 0x10e58c8: EnterFrame
    //     0x10e58c8: stp             fp, lr, [SP, #-0x10]!
    //     0x10e58cc: mov             fp, SP
    // 0x10e58d0: AllocStack(0x8)
    //     0x10e58d0: sub             SP, SP, #8
    // 0x10e58d4: SetupParameters(_MonthPickerState this /* r1 => r0, fp-0x8 */)
    //     0x10e58d4: mov             x0, x1
    //     0x10e58d8: stur            x1, [fp, #-8]
    // 0x10e58dc: CheckStackOverflow
    //     0x10e58dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e58e0: cmp             SP, x16
    //     0x10e58e4: b.ls            #0x10e592c
    // 0x10e58e8: LoadField: r1 = r0->field_1f
    //     0x10e58e8: ldur            w1, [x0, #0x1f]
    // 0x10e58ec: DecompressPointer r1
    //     0x10e58ec: add             x1, x1, HEAP, lsl #32
    // 0x10e58f0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10e58f4: cmp             w1, w16
    // 0x10e58f8: b.eq            #0x10e5934
    // 0x10e58fc: r0 = dispose()
    //     0x10e58fc: bl              #0x10ef540  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::dispose
    // 0x10e5900: ldur            x0, [fp, #-8]
    // 0x10e5904: LoadField: r1 = r0->field_2f
    //     0x10e5904: ldur            w1, [x0, #0x2f]
    // 0x10e5908: DecompressPointer r1
    //     0x10e5908: add             x1, x1, HEAP, lsl #32
    // 0x10e590c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10e5910: cmp             w1, w16
    // 0x10e5914: b.eq            #0x10e5940
    // 0x10e5918: r0 = dispose()
    //     0x10e5918: bl              #0x10ec024  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::dispose
    // 0x10e591c: r0 = Null
    //     0x10e591c: mov             x0, NULL
    // 0x10e5920: LeaveFrame
    //     0x10e5920: mov             SP, fp
    //     0x10e5924: ldp             fp, lr, [SP], #0x10
    // 0x10e5928: ret
    //     0x10e5928: ret             
    // 0x10e592c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e592c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e5930: b               #0x10e58e8
    // 0x10e5934: r9 = _pageController
    //     0x10e5934: add             x9, PP, #0xd0, lsl #12  ; [pp+0xd0738] Field <_MonthPickerState@54260463._pageController@54260463>: late (offset: 0x20)
    //     0x10e5938: ldr             x9, [x9, #0x738]
    // 0x10e593c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x10e593c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x10e5940: r9 = _dayGridFocus
    //     0x10e5940: add             x9, PP, #0xd0, lsl #12  ; [pp+0xd0730] Field <_MonthPickerState@54260463._dayGridFocus@54260463>: late (offset: 0x30)
    //     0x10e5944: ldr             x9, [x9, #0x730]
    // 0x10e5948: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x10e5948: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 5476, size: 0x38, field offset: 0x14
class _CalendarDatePickerState extends State<dynamic> {

  late DatePickerMode _mode; // offset: 0x1c
  late DateTime _currentDisplayedMonthDate; // offset: 0x20
  late MaterialLocalizations _localizations; // offset: 0x30
  late TextDirection _textDirection; // offset: 0x34

  _ build(/* No info */) {
    // ** addr: 0xdec7b4, size: 0x4bc
    // 0xdec7b4: EnterFrame
    //     0xdec7b4: stp             fp, lr, [SP, #-0x10]!
    //     0xdec7b8: mov             fp, SP
    // 0xdec7bc: AllocStack(0x68)
    //     0xdec7bc: sub             SP, SP, #0x68
    // 0xdec7c0: SetupParameters(_CalendarDatePickerState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xdec7c0: mov             x0, x1
    //     0xdec7c4: stur            x1, [fp, #-8]
    //     0xdec7c8: mov             x1, x2
    //     0xdec7cc: stur            x2, [fp, #-0x10]
    // 0xdec7d0: CheckStackOverflow
    //     0xdec7d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdec7d4: cmp             SP, x16
    //     0xdec7d8: b.ls            #0xdecc24
    // 0xdec7dc: r1 = 1
    //     0xdec7dc: mov             x1, #1
    // 0xdec7e0: r0 = AllocateContext()
    //     0xdec7e0: bl              #0x13de838  ; AllocateContextStub
    // 0xdec7e4: mov             x2, x0
    // 0xdec7e8: ldur            x0, [fp, #-8]
    // 0xdec7ec: stur            x2, [fp, #-0x18]
    // 0xdec7f0: StoreField: r2->field_f = r0
    //     0xdec7f0: stur            w0, [x2, #0xf]
    // 0xdec7f4: ldur            x1, [fp, #-0x10]
    // 0xdec7f8: r0 = textScalerOf()
    //     0xdec7f8: bl              #0xd16168  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::textScalerOf
    // 0xdec7fc: r1 = LoadClassIdInstr(r0)
    //     0xdec7fc: ldur            x1, [x0, #-1]
    //     0xdec800: ubfx            x1, x1, #0xc, #0x14
    // 0xdec804: mov             x16, x0
    // 0xdec808: mov             x0, x1
    // 0xdec80c: mov             x1, x16
    // 0xdec810: d0 = 3.000000
    //     0xdec810: fmov            d0, #3.00000000
    // 0xdec814: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xdec814: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xdec818: r0 = GDT[cid_x0 + -0xffa]()
    //     0xdec818: sub             lr, x0, #0xffa
    //     0xdec81c: ldr             lr, [x21, lr, lsl #3]
    //     0xdec820: blr             lr
    // 0xdec824: r1 = LoadClassIdInstr(r0)
    //     0xdec824: ldur            x1, [x0, #-1]
    //     0xdec828: ubfx            x1, x1, #0xc, #0x14
    // 0xdec82c: mov             x16, x0
    // 0xdec830: mov             x0, x1
    // 0xdec834: mov             x1, x16
    // 0xdec838: d0 = 14.000000
    //     0xdec838: fmov            d0, #14.00000000
    // 0xdec83c: r0 = GDT[cid_x0 + -0x1000]()
    //     0xdec83c: sub             lr, x0, #1, lsl #12
    //     0xdec840: ldr             lr, [x21, lr, lsl #3]
    //     0xdec844: blr             lr
    // 0xdec848: LoadField: d0 = r0->field_7
    //     0xdec848: ldur            d0, [x0, #7]
    // 0xdec84c: d1 = 14.000000
    //     0xdec84c: fmov            d1, #14.00000000
    // 0xdec850: fdiv            d2, d0, d1
    // 0xdec854: ldur            x1, [fp, #-0x10]
    // 0xdec858: stur            d2, [fp, #-0x40]
    // 0xdec85c: r0 = orientationOf()
    //     0xdec85c: bl              #0xd172a4  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::orientationOf
    // 0xdec860: ldur            x1, [fp, #-0x10]
    // 0xdec864: stur            x0, [fp, #-0x20]
    // 0xdec868: r0 = of()
    //     0xdec868: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xdec86c: LoadField: r1 = r0->field_2f
    //     0xdec86c: ldur            w1, [x0, #0x2f]
    // 0xdec870: DecompressPointer r1
    //     0xdec870: add             x1, x1, HEAP, lsl #32
    // 0xdec874: tbnz            w1, #4, #0xdec898
    // 0xdec878: ldur            x0, [fp, #-0x20]
    // 0xdec87c: r16 = Instance_Orientation
    //     0xdec87c: add             x16, PP, #0x14, lsl #12  ; [pp+0x143c8] Obj!Orientation@12c2ec1
    //     0xdec880: ldr             x16, [x16, #0x3c8]
    // 0xdec884: cmp             w0, w16
    // 0xdec888: b.ne            #0xdec898
    // 0xdec88c: d2 = 336.000000
    //     0xdec88c: add             x17, PP, #0xad, lsl #12  ; [pp+0xadf18] IMM: double(336) from 0x4075000000000000
    //     0xdec890: ldr             d2, [x17, #0xf18]
    // 0xdec894: b               #0xdec8a0
    // 0xdec898: d2 = 294.000000
    //     0xdec898: add             x17, PP, #0xad, lsl #12  ; [pp+0xadf20] IMM: double(294) from 0x4072600000000000
    //     0xdec89c: ldr             d2, [x17, #0xf20]
    // 0xdec8a0: ldur            d0, [fp, #-0x40]
    // 0xdec8a4: d1 = 1.300000
    //     0xdec8a4: add             x17, PP, #0x1f, lsl #12  ; [pp+0x1f200] IMM: double(1.3) from 0x3ff4cccccccccccd
    //     0xdec8a8: ldr             d1, [x17, #0x200]
    // 0xdec8ac: fcmp            d0, d1
    // 0xdec8b0: b.le            #0xdec8d8
    // 0xdec8b4: d4 = 1.000000
    //     0xdec8b4: fmov            d4, #1.00000000
    // 0xdec8b8: d3 = 8.000000
    //     0xdec8b8: fmov            d3, #8.00000000
    // 0xdec8bc: d1 = 7.000000
    //     0xdec8bc: fmov            d1, #7.00000000
    // 0xdec8c0: fsub            d5, d0, d4
    // 0xdec8c4: fmul            d0, d5, d3
    // 0xdec8c8: fmul            d3, d0, d1
    // 0xdec8cc: fadd            d0, d2, d3
    // 0xdec8d0: mov             v1.16b, v0.16b
    // 0xdec8d4: b               #0xdec8dc
    // 0xdec8d8: mov             v1.16b, v2.16b
    // 0xdec8dc: d0 = 52.000000
    //     0xdec8dc: add             x17, PP, #0x22, lsl #12  ; [pp+0x22108] IMM: double(52) from 0x404a000000000000
    //     0xdec8e0: ldr             d0, [x17, #0x108]
    // 0xdec8e4: fadd            d2, d1, d0
    // 0xdec8e8: ldur            x1, [fp, #-8]
    // 0xdec8ec: stur            d2, [fp, #-0x40]
    // 0xdec8f0: r0 = _buildPicker()
    //     0xdec8f0: bl              #0xdeccc8  ; [package:flutter/src/material/calendar_date_picker.dart] _CalendarDatePickerState::_buildPicker
    // 0xdec8f4: ldur            d0, [fp, #-0x40]
    // 0xdec8f8: stur            x0, [fp, #-0x28]
    // 0xdec8fc: r1 = inline_Allocate_Double()
    //     0xdec8fc: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xdec900: add             x1, x1, #0x10
    //     0xdec904: cmp             x2, x1
    //     0xdec908: b.ls            #0xdecc2c
    //     0xdec90c: str             x1, [THR, #0x60]  ; THR::top
    //     0xdec910: sub             x1, x1, #0xf
    //     0xdec914: mov             x2, #0xe19c
    //     0xdec918: movk            x2, #3, lsl #16
    //     0xdec91c: stur            x2, [x1, #-1]
    // 0xdec920: dmb             ishst
    // 0xdec924: StoreField: r1->field_7 = d0
    //     0xdec924: stur            d0, [x1, #7]
    // 0xdec928: stur            x1, [fp, #-0x20]
    // 0xdec92c: r0 = SizedBox()
    //     0xdec92c: bl              #0x8a7210  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0xdec930: mov             x3, x0
    // 0xdec934: ldur            x0, [fp, #-0x20]
    // 0xdec938: stur            x3, [fp, #-0x30]
    // 0xdec93c: StoreField: r3->field_13 = r0
    //     0xdec93c: stur            w0, [x3, #0x13]
    // 0xdec940: ldur            x0, [fp, #-0x28]
    // 0xdec944: StoreField: r3->field_b = r0
    //     0xdec944: stur            w0, [x3, #0xb]
    // 0xdec948: r1 = <Widget>
    //     0xdec948: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xdec94c: r2 = 0
    //     0xdec94c: mov             x2, #0
    // 0xdec950: r0 = _GrowableList()
    //     0xdec950: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xdec954: ldur            x1, [fp, #-0x10]
    // 0xdec958: stur            x0, [fp, #-0x10]
    // 0xdec95c: r0 = maybeSupportsAnnounceOf()
    //     0xdec95c: bl              #0xd19758  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::maybeSupportsAnnounceOf
    // 0xdec960: cmp             w0, NULL
    // 0xdec964: b.ne            #0xdec970
    // 0xdec968: ldur            x2, [fp, #-0x10]
    // 0xdec96c: b               #0xdec9f8
    // 0xdec970: tbnz            w0, #4, #0xdec9f4
    // 0xdec974: ldur            x0, [fp, #-0x10]
    // 0xdec978: LoadField: r1 = r0->field_b
    //     0xdec978: ldur            w1, [x0, #0xb]
    // 0xdec97c: LoadField: r2 = r0->field_f
    //     0xdec97c: ldur            w2, [x0, #0xf]
    // 0xdec980: DecompressPointer r2
    //     0xdec980: add             x2, x2, HEAP, lsl #32
    // 0xdec984: LoadField: r3 = r2->field_b
    //     0xdec984: ldur            w3, [x2, #0xb]
    // 0xdec988: r2 = LoadInt32Instr(r1)
    //     0xdec988: sbfx            x2, x1, #1, #0x1f
    // 0xdec98c: stur            x2, [fp, #-0x38]
    // 0xdec990: r1 = LoadInt32Instr(r3)
    //     0xdec990: sbfx            x1, x3, #1, #0x1f
    // 0xdec994: cmp             x2, x1
    // 0xdec998: b.ne            #0xdec9a4
    // 0xdec99c: mov             x1, x0
    // 0xdec9a0: r0 = _growToNextCapacity()
    //     0xdec9a0: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xdec9a4: ldur            x2, [fp, #-0x10]
    // 0xdec9a8: ldur            x3, [fp, #-0x38]
    // 0xdec9ac: add             x0, x3, #1
    // 0xdec9b0: lsl             x1, x0, #1
    // 0xdec9b4: StoreField: r2->field_b = r1
    //     0xdec9b4: stur            w1, [x2, #0xb]
    // 0xdec9b8: LoadField: r1 = r2->field_f
    //     0xdec9b8: ldur            w1, [x2, #0xf]
    // 0xdec9bc: DecompressPointer r1
    //     0xdec9bc: add             x1, x1, HEAP, lsl #32
    // 0xdec9c0: ldur            x0, [fp, #-0x30]
    // 0xdec9c4: ArrayStore: r1[r3] = r0  ; List_4
    //     0xdec9c4: add             x25, x1, x3, lsl #2
    //     0xdec9c8: add             x25, x25, #0xf
    //     0xdec9cc: str             w0, [x25]
    //     0xdec9d0: tbz             w0, #0, #0xdec9ec
    //     0xdec9d4: ldurb           w16, [x1, #-1]
    //     0xdec9d8: ldurb           w17, [x0, #-1]
    //     0xdec9dc: and             x16, x17, x16, lsr #2
    //     0xdec9e0: tst             x16, HEAP, lsr #32
    //     0xdec9e4: b.eq            #0xdec9ec
    //     0xdec9e8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdec9ec: mov             x4, x2
    // 0xdec9f0: b               #0xdecab8
    // 0xdec9f4: ldur            x2, [fp, #-0x10]
    // 0xdec9f8: ldur            x0, [fp, #-8]
    // 0xdec9fc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdec9fc: ldur            w1, [x0, #0x17]
    // 0xdeca00: DecompressPointer r1
    //     0xdeca00: add             x1, x1, HEAP, lsl #32
    // 0xdeca04: stur            x1, [fp, #-0x20]
    // 0xdeca08: r0 = Semantics()
    //     0xdeca08: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xdeca0c: stur            x0, [fp, #-0x28]
    // 0xdeca10: r16 = true
    //     0xdeca10: add             x16, NULL, #0x20  ; true
    // 0xdeca14: r30 = true
    //     0xdeca14: add             lr, NULL, #0x20  ; true
    // 0xdeca18: stp             lr, x16, [SP, #0x18]
    // 0xdeca1c: r16 = Instance_AccessibilityFocusBlockType
    //     0xdeca1c: ldr             x16, [PP, #0x2a88]  ; [pp+0x2a88] Obj!AccessibilityFocusBlockType@12c3ee1
    // 0xdeca20: ldur            lr, [fp, #-0x20]
    // 0xdeca24: stp             lr, x16, [SP, #8]
    // 0xdeca28: ldur            x16, [fp, #-0x30]
    // 0xdeca2c: str             x16, [SP]
    // 0xdeca30: mov             x1, x0
    // 0xdeca34: r4 = const [0, 0x6, 0x5, 0x1, accessibilityFocusBlockType, 0x3, child, 0x5, container, 0x1, label, 0x4, liveRegion, 0x2, null]
    //     0xdeca34: add             x4, PP, #0xad, lsl #12  ; [pp+0xadf28] List(15) [0, 0x6, 0x5, 0x1, "accessibilityFocusBlockType", 0x3, "child", 0x5, "container", 0x1, "label", 0x4, "liveRegion", 0x2, Null]
    //     0xdeca38: ldr             x4, [x4, #0xf28]
    // 0xdeca3c: r0 = Semantics()
    //     0xdeca3c: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xdeca40: ldur            x0, [fp, #-0x10]
    // 0xdeca44: LoadField: r1 = r0->field_b
    //     0xdeca44: ldur            w1, [x0, #0xb]
    // 0xdeca48: LoadField: r2 = r0->field_f
    //     0xdeca48: ldur            w2, [x0, #0xf]
    // 0xdeca4c: DecompressPointer r2
    //     0xdeca4c: add             x2, x2, HEAP, lsl #32
    // 0xdeca50: LoadField: r3 = r2->field_b
    //     0xdeca50: ldur            w3, [x2, #0xb]
    // 0xdeca54: r2 = LoadInt32Instr(r1)
    //     0xdeca54: sbfx            x2, x1, #1, #0x1f
    // 0xdeca58: stur            x2, [fp, #-0x38]
    // 0xdeca5c: r1 = LoadInt32Instr(r3)
    //     0xdeca5c: sbfx            x1, x3, #1, #0x1f
    // 0xdeca60: cmp             x2, x1
    // 0xdeca64: b.ne            #0xdeca70
    // 0xdeca68: mov             x1, x0
    // 0xdeca6c: r0 = _growToNextCapacity()
    //     0xdeca6c: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xdeca70: ldur            x4, [fp, #-0x10]
    // 0xdeca74: ldur            x2, [fp, #-0x38]
    // 0xdeca78: add             x0, x2, #1
    // 0xdeca7c: lsl             x1, x0, #1
    // 0xdeca80: StoreField: r4->field_b = r1
    //     0xdeca80: stur            w1, [x4, #0xb]
    // 0xdeca84: LoadField: r1 = r4->field_f
    //     0xdeca84: ldur            w1, [x4, #0xf]
    // 0xdeca88: DecompressPointer r1
    //     0xdeca88: add             x1, x1, HEAP, lsl #32
    // 0xdeca8c: ldur            x0, [fp, #-0x28]
    // 0xdeca90: ArrayStore: r1[r2] = r0  ; List_4
    //     0xdeca90: add             x25, x1, x2, lsl #2
    //     0xdeca94: add             x25, x25, #0xf
    //     0xdeca98: str             w0, [x25]
    //     0xdeca9c: tbz             w0, #0, #0xdecab8
    //     0xdecaa0: ldurb           w16, [x1, #-1]
    //     0xdecaa4: ldurb           w17, [x0, #-1]
    //     0xdecaa8: and             x16, x17, x16, lsr #2
    //     0xdecaac: tst             x16, HEAP, lsr #32
    //     0xdecab0: b.eq            #0xdecab8
    //     0xdecab4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdecab8: ldur            x0, [fp, #-8]
    // 0xdecabc: LoadField: r5 = r0->field_1b
    //     0xdecabc: ldur            w5, [x0, #0x1b]
    // 0xdecac0: DecompressPointer r5
    //     0xdecac0: add             x5, x5, HEAP, lsl #32
    // 0xdecac4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdecac8: cmp             w5, w16
    // 0xdecacc: b.eq            #0xdecc48
    // 0xdecad0: stur            x5, [fp, #-0x20]
    // 0xdecad4: LoadField: r1 = r0->field_b
    //     0xdecad4: ldur            w1, [x0, #0xb]
    // 0xdecad8: DecompressPointer r1
    //     0xdecad8: add             x1, x1, HEAP, lsl #32
    // 0xdecadc: cmp             w1, NULL
    // 0xdecae0: b.eq            #0xdecc54
    // 0xdecae4: LoadField: r2 = r0->field_1f
    //     0xdecae4: ldur            w2, [x0, #0x1f]
    // 0xdecae8: DecompressPointer r2
    //     0xdecae8: add             x2, x2, HEAP, lsl #32
    // 0xdecaec: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdecaf0: cmp             w2, w16
    // 0xdecaf4: b.eq            #0xdecc58
    // 0xdecaf8: LoadField: r3 = r0->field_2f
    //     0xdecaf8: ldur            w3, [x0, #0x2f]
    // 0xdecafc: DecompressPointer r3
    //     0xdecafc: add             x3, x3, HEAP, lsl #32
    // 0xdecb00: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdecb04: cmp             w3, w16
    // 0xdecb08: b.eq            #0xdecc64
    // 0xdecb0c: r1 = Instance_GregorianCalendarDelegate
    //     0xdecb0c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28538] Obj!GregorianCalendarDelegate@129edd1
    //     0xdecb10: ldr             x1, [x1, #0x538]
    // 0xdecb14: r0 = formatMonthYear()
    //     0xdecb14: bl              #0xdecc7c  ; [package:flutter/src/material/date.dart] GregorianCalendarDelegate::formatMonthYear
    // 0xdecb18: stur            x0, [fp, #-8]
    // 0xdecb1c: r0 = _DatePickerModeToggleButton()
    //     0xdecb1c: bl              #0xdecc70  ; Allocate_DatePickerModeToggleButtonStub -> _DatePickerModeToggleButton (size=0x18)
    // 0xdecb20: mov             x3, x0
    // 0xdecb24: ldur            x0, [fp, #-0x20]
    // 0xdecb28: stur            x3, [fp, #-0x28]
    // 0xdecb2c: StoreField: r3->field_b = r0
    //     0xdecb2c: stur            w0, [x3, #0xb]
    // 0xdecb30: ldur            x0, [fp, #-8]
    // 0xdecb34: StoreField: r3->field_f = r0
    //     0xdecb34: stur            w0, [x3, #0xf]
    // 0xdecb38: ldur            x2, [fp, #-0x18]
    // 0xdecb3c: r1 = Function '<anonymous closure>':.
    //     0xdecb3c: add             x1, PP, #0xad, lsl #12  ; [pp+0xadf30] AnonymousClosure: (0xdee0c0), in [package:flutter/src/material/calendar_date_picker.dart] _CalendarDatePickerState::build (0xdec7b4)
    //     0xdecb40: ldr             x1, [x1, #0xf30]
    // 0xdecb44: r0 = AllocateClosure()
    //     0xdecb44: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdecb48: ldur            x1, [fp, #-0x28]
    // 0xdecb4c: StoreField: r1->field_13 = r0
    //     0xdecb4c: stur            w0, [x1, #0x13]
    // 0xdecb50: r16 = 2.000000
    //     0xdecb50: add             x16, PP, #0x1b, lsl #12  ; [pp+0x1b1e0] 2
    //     0xdecb54: ldr             x16, [x16, #0x1e0]
    // 0xdecb58: str             x16, [SP]
    // 0xdecb5c: r4 = const [0, 0x2, 0x1, 0x1, maxScaleFactor, 0x1, null]
    //     0xdecb5c: add             x4, PP, #0x90, lsl #12  ; [pp+0x90d70] List(7) [0, 0x2, 0x1, 0x1, "maxScaleFactor", 0x1, Null]
    //     0xdecb60: ldr             x4, [x4, #0xd70]
    // 0xdecb64: r0 = withClampedTextScaling()
    //     0xdecb64: bl              #0xd16294  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::withClampedTextScaling
    // 0xdecb68: mov             x2, x0
    // 0xdecb6c: ldur            x0, [fp, #-0x10]
    // 0xdecb70: stur            x2, [fp, #-8]
    // 0xdecb74: LoadField: r1 = r0->field_b
    //     0xdecb74: ldur            w1, [x0, #0xb]
    // 0xdecb78: LoadField: r3 = r0->field_f
    //     0xdecb78: ldur            w3, [x0, #0xf]
    // 0xdecb7c: DecompressPointer r3
    //     0xdecb7c: add             x3, x3, HEAP, lsl #32
    // 0xdecb80: LoadField: r4 = r3->field_b
    //     0xdecb80: ldur            w4, [x3, #0xb]
    // 0xdecb84: r3 = LoadInt32Instr(r1)
    //     0xdecb84: sbfx            x3, x1, #1, #0x1f
    // 0xdecb88: stur            x3, [fp, #-0x38]
    // 0xdecb8c: r1 = LoadInt32Instr(r4)
    //     0xdecb8c: sbfx            x1, x4, #1, #0x1f
    // 0xdecb90: cmp             x3, x1
    // 0xdecb94: b.ne            #0xdecba0
    // 0xdecb98: mov             x1, x0
    // 0xdecb9c: r0 = _growToNextCapacity()
    //     0xdecb9c: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xdecba0: ldur            x2, [fp, #-0x10]
    // 0xdecba4: ldur            x3, [fp, #-0x38]
    // 0xdecba8: add             x0, x3, #1
    // 0xdecbac: lsl             x1, x0, #1
    // 0xdecbb0: StoreField: r2->field_b = r1
    //     0xdecbb0: stur            w1, [x2, #0xb]
    // 0xdecbb4: LoadField: r1 = r2->field_f
    //     0xdecbb4: ldur            w1, [x2, #0xf]
    // 0xdecbb8: DecompressPointer r1
    //     0xdecbb8: add             x1, x1, HEAP, lsl #32
    // 0xdecbbc: ldur            x0, [fp, #-8]
    // 0xdecbc0: ArrayStore: r1[r3] = r0  ; List_4
    //     0xdecbc0: add             x25, x1, x3, lsl #2
    //     0xdecbc4: add             x25, x25, #0xf
    //     0xdecbc8: str             w0, [x25]
    //     0xdecbcc: tbz             w0, #0, #0xdecbe8
    //     0xdecbd0: ldurb           w16, [x1, #-1]
    //     0xdecbd4: ldurb           w17, [x0, #-1]
    //     0xdecbd8: and             x16, x17, x16, lsr #2
    //     0xdecbdc: tst             x16, HEAP, lsr #32
    //     0xdecbe0: b.eq            #0xdecbe8
    //     0xdecbe4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdecbe8: r0 = Stack()
    //     0xdecbe8: bl              #0xd1a854  ; AllocateStackStub -> Stack (size=0x20)
    // 0xdecbec: r1 = Instance_AlignmentDirectional
    //     0xdecbec: add             x1, PP, #0x15, lsl #12  ; [pp+0x158d8] Obj!AlignmentDirectional@129e611
    //     0xdecbf0: ldr             x1, [x1, #0x8d8]
    // 0xdecbf4: StoreField: r0->field_f = r1
    //     0xdecbf4: stur            w1, [x0, #0xf]
    // 0xdecbf8: r1 = Instance_StackFit
    //     0xdecbf8: add             x1, PP, #0x15, lsl #12  ; [pp+0x158e0] Obj!StackFit@12c4221
    //     0xdecbfc: ldr             x1, [x1, #0x8e0]
    // 0xdecc00: ArrayStore: r0[0] = r1  ; List_4
    //     0xdecc00: stur            w1, [x0, #0x17]
    // 0xdecc04: r1 = Instance_Clip
    //     0xdecc04: add             x1, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xdecc08: ldr             x1, [x1, #0x850]
    // 0xdecc0c: StoreField: r0->field_1b = r1
    //     0xdecc0c: stur            w1, [x0, #0x1b]
    // 0xdecc10: ldur            x1, [fp, #-0x10]
    // 0xdecc14: StoreField: r0->field_b = r1
    //     0xdecc14: stur            w1, [x0, #0xb]
    // 0xdecc18: LeaveFrame
    //     0xdecc18: mov             SP, fp
    //     0xdecc1c: ldp             fp, lr, [SP], #0x10
    // 0xdecc20: ret
    //     0xdecc20: ret             
    // 0xdecc24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdecc24: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdecc28: b               #0xdec7dc
    // 0xdecc2c: SaveReg d0
    //     0xdecc2c: str             q0, [SP, #-0x10]!
    // 0xdecc30: SaveReg r0
    //     0xdecc30: str             x0, [SP, #-8]!
    // 0xdecc34: r0 = AllocateDouble()
    //     0xdecc34: bl              #0x13df878  ; AllocateDoubleStub
    // 0xdecc38: mov             x1, x0
    // 0xdecc3c: RestoreReg r0
    //     0xdecc3c: ldr             x0, [SP], #8
    // 0xdecc40: RestoreReg d0
    //     0xdecc40: ldr             q0, [SP], #0x10
    // 0xdecc44: b               #0xdec924
    // 0xdecc48: r9 = _mode
    //     0xdecc48: add             x9, PP, #0xad, lsl #12  ; [pp+0xadf38] Field <_CalendarDatePickerState@54260463._mode@54260463>: late (offset: 0x1c)
    //     0xdecc4c: ldr             x9, [x9, #0xf38]
    // 0xdecc50: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdecc50: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdecc54: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdecc54: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdecc58: r9 = _currentDisplayedMonthDate
    //     0xdecc58: add             x9, PP, #0xad, lsl #12  ; [pp+0xadf40] Field <_CalendarDatePickerState@54260463._currentDisplayedMonthDate@54260463>: late (offset: 0x20)
    //     0xdecc5c: ldr             x9, [x9, #0xf40]
    // 0xdecc60: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdecc60: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdecc64: r9 = _localizations
    //     0xdecc64: add             x9, PP, #0xad, lsl #12  ; [pp+0xadf48] Field <_CalendarDatePickerState@54260463._localizations@54260463>: late (offset: 0x30)
    //     0xdecc68: ldr             x9, [x9, #0xf48]
    // 0xdecc6c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdecc6c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _buildPicker(/* No info */) {
    // ** addr: 0xdeccc8, size: 0x204
    // 0xdeccc8: EnterFrame
    //     0xdeccc8: stp             fp, lr, [SP, #-0x10]!
    //     0xdecccc: mov             fp, SP
    // 0xdeccd0: AllocStack(0x68)
    //     0xdeccd0: sub             SP, SP, #0x68
    // 0xdeccd4: SetupParameters(_CalendarDatePickerState this /* r1 => r0, fp-0x38 */)
    //     0xdeccd4: mov             x0, x1
    //     0xdeccd8: stur            x1, [fp, #-0x38]
    // 0xdeccdc: CheckStackOverflow
    //     0xdeccdc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdecce0: cmp             SP, x16
    //     0xdecce4: b.ls            #0xdece98
    // 0xdecce8: LoadField: r1 = r0->field_1b
    //     0xdecce8: ldur            w1, [x0, #0x1b]
    // 0xdeccec: DecompressPointer r1
    //     0xdeccec: add             x1, x1, HEAP, lsl #32
    // 0xdeccf0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdeccf4: cmp             w1, w16
    // 0xdeccf8: b.eq            #0xdecea0
    // 0xdeccfc: LoadField: r2 = r1->field_7
    //     0xdeccfc: ldur            x2, [x1, #7]
    // 0xdecd00: cmp             x2, #0
    // 0xdecd04: b.gt            #0xdecddc
    // 0xdecd08: LoadField: r6 = r0->field_27
    //     0xdecd08: ldur            w6, [x0, #0x27]
    // 0xdecd0c: DecompressPointer r6
    //     0xdecd0c: add             x6, x6, HEAP, lsl #32
    // 0xdecd10: stur            x6, [fp, #-0x30]
    // 0xdecd14: LoadField: r1 = r0->field_b
    //     0xdecd14: ldur            w1, [x0, #0xb]
    // 0xdecd18: DecompressPointer r1
    //     0xdecd18: add             x1, x1, HEAP, lsl #32
    // 0xdecd1c: cmp             w1, NULL
    // 0xdecd20: b.eq            #0xdeceac
    // 0xdecd24: LoadField: r5 = r0->field_1f
    //     0xdecd24: ldur            w5, [x0, #0x1f]
    // 0xdecd28: DecompressPointer r5
    //     0xdecd28: add             x5, x5, HEAP, lsl #32
    // 0xdecd2c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdecd30: cmp             w5, w16
    // 0xdecd34: b.eq            #0xdeceb0
    // 0xdecd38: stur            x5, [fp, #-0x28]
    // 0xdecd3c: ArrayLoad: r3 = r1[0]  ; List_4
    //     0xdecd3c: ldur            w3, [x1, #0x17]
    // 0xdecd40: DecompressPointer r3
    //     0xdecd40: add             x3, x3, HEAP, lsl #32
    // 0xdecd44: stur            x3, [fp, #-0x20]
    // 0xdecd48: LoadField: r4 = r1->field_f
    //     0xdecd48: ldur            w4, [x1, #0xf]
    // 0xdecd4c: DecompressPointer r4
    //     0xdecd4c: add             x4, x4, HEAP, lsl #32
    // 0xdecd50: stur            x4, [fp, #-0x18]
    // 0xdecd54: LoadField: r7 = r1->field_13
    //     0xdecd54: ldur            w7, [x1, #0x13]
    // 0xdecd58: DecompressPointer r7
    //     0xdecd58: add             x7, x7, HEAP, lsl #32
    // 0xdecd5c: stur            x7, [fp, #-0x10]
    // 0xdecd60: LoadField: r8 = r0->field_23
    //     0xdecd60: ldur            w8, [x0, #0x23]
    // 0xdecd64: DecompressPointer r8
    //     0xdecd64: add             x8, x8, HEAP, lsl #32
    // 0xdecd68: mov             x2, x0
    // 0xdecd6c: stur            x8, [fp, #-8]
    // 0xdecd70: r1 = Function '_handleDayChanged@54260463':.
    //     0xdecd70: add             x1, PP, #0xad, lsl #12  ; [pp+0xadf70] AnonymousClosure: (0xdedb70), in [package:flutter/src/material/calendar_date_picker.dart] _CalendarDatePickerState::_handleDayChanged (0xdedbac)
    //     0xdecd74: ldr             x1, [x1, #0xf70]
    // 0xdecd78: r0 = AllocateClosure()
    //     0xdecd78: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdecd7c: ldur            x2, [fp, #-0x38]
    // 0xdecd80: r1 = Function '_handleMonthChanged@54260463':.
    //     0xdecd80: add             x1, PP, #0xad, lsl #12  ; [pp+0xadf78] AnonymousClosure: (0xdedb34), in [package:flutter/src/material/calendar_date_picker.dart] _CalendarDatePickerState::_handleMonthChanged (0xded7ac)
    //     0xdecd84: ldr             x1, [x1, #0xf78]
    // 0xdecd88: stur            x0, [fp, #-0x40]
    // 0xdecd8c: r0 = AllocateClosure()
    //     0xdecd8c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdecd90: stur            x0, [fp, #-0x48]
    // 0xdecd94: r0 = _MonthPicker()
    //     0xdecd94: bl              #0xded184  ; Allocate_MonthPickerStub -> _MonthPicker (size=0x30)
    // 0xdecd98: stur            x0, [fp, #-0x50]
    // 0xdecd9c: ldur            x16, [fp, #-0x40]
    // 0xdecda0: ldur            lr, [fp, #-0x48]
    // 0xdecda4: stp             lr, x16, [SP, #8]
    // 0xdecda8: ldur            x16, [fp, #-8]
    // 0xdecdac: str             x16, [SP]
    // 0xdecdb0: mov             x1, x0
    // 0xdecdb4: ldur            x2, [fp, #-0x20]
    // 0xdecdb8: ldur            x3, [fp, #-0x18]
    // 0xdecdbc: ldur            x5, [fp, #-0x28]
    // 0xdecdc0: ldur            x6, [fp, #-0x30]
    // 0xdecdc4: ldur            x7, [fp, #-0x10]
    // 0xdecdc8: r0 = _MonthPicker()
    //     0xdecdc8: bl              #0xded024  ; [package:flutter/src/material/calendar_date_picker.dart] _MonthPicker::_MonthPicker
    // 0xdecdcc: ldur            x0, [fp, #-0x50]
    // 0xdecdd0: LeaveFrame
    //     0xdecdd0: mov             SP, fp
    //     0xdecdd4: ldp             fp, lr, [SP], #0x10
    // 0xdecdd8: ret
    //     0xdecdd8: ret             
    // 0xdecddc: mov             x2, x0
    // 0xdecde0: LoadField: r5 = r2->field_2b
    //     0xdecde0: ldur            w5, [x2, #0x2b]
    // 0xdecde4: DecompressPointer r5
    //     0xdecde4: add             x5, x5, HEAP, lsl #32
    // 0xdecde8: stur            x5, [fp, #-0x28]
    // 0xdecdec: LoadField: r0 = r2->field_b
    //     0xdecdec: ldur            w0, [x2, #0xb]
    // 0xdecdf0: DecompressPointer r0
    //     0xdecdf0: add             x0, x0, HEAP, lsl #32
    // 0xdecdf4: cmp             w0, NULL
    // 0xdecdf8: b.eq            #0xdecebc
    // 0xdecdfc: ArrayLoad: r3 = r0[0]  ; List_4
    //     0xdecdfc: ldur            w3, [x0, #0x17]
    // 0xdece00: DecompressPointer r3
    //     0xdece00: add             x3, x3, HEAP, lsl #32
    // 0xdece04: stur            x3, [fp, #-0x20]
    // 0xdece08: LoadField: r4 = r0->field_f
    //     0xdece08: ldur            w4, [x0, #0xf]
    // 0xdece0c: DecompressPointer r4
    //     0xdece0c: add             x4, x4, HEAP, lsl #32
    // 0xdece10: stur            x4, [fp, #-0x18]
    // 0xdece14: LoadField: r6 = r0->field_13
    //     0xdece14: ldur            w6, [x0, #0x13]
    // 0xdece18: DecompressPointer r6
    //     0xdece18: add             x6, x6, HEAP, lsl #32
    // 0xdece1c: stur            x6, [fp, #-0x10]
    // 0xdece20: LoadField: r0 = r2->field_1f
    //     0xdece20: ldur            w0, [x2, #0x1f]
    // 0xdece24: DecompressPointer r0
    //     0xdece24: add             x0, x0, HEAP, lsl #32
    // 0xdece28: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdece2c: cmp             w0, w16
    // 0xdece30: b.eq            #0xdecec0
    // 0xdece34: stur            x0, [fp, #-8]
    // 0xdece38: r1 = Function '_handleYearChanged@54260463':.
    //     0xdece38: add             x1, PP, #0xad, lsl #12  ; [pp+0xadf80] AnonymousClosure: (0xded190), in [package:flutter/src/material/calendar_date_picker.dart] _CalendarDatePickerState::_handleYearChanged (0xded1cc)
    //     0xdece3c: ldr             x1, [x1, #0xf80]
    // 0xdece40: r0 = AllocateClosure()
    //     0xdece40: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdece44: stur            x0, [fp, #-0x30]
    // 0xdece48: r0 = YearPicker()
    //     0xdece48: bl              #0xded018  ; AllocateYearPickerStub -> YearPicker (size=0x28)
    // 0xdece4c: stur            x0, [fp, #-0x38]
    // 0xdece50: ldur            x16, [fp, #-8]
    // 0xdece54: str             x16, [SP]
    // 0xdece58: mov             x1, x0
    // 0xdece5c: ldur            x2, [fp, #-0x20]
    // 0xdece60: ldur            x3, [fp, #-0x18]
    // 0xdece64: ldur            x5, [fp, #-0x28]
    // 0xdece68: ldur            x6, [fp, #-0x10]
    // 0xdece6c: ldur            x7, [fp, #-0x30]
    // 0xdece70: r0 = YearPicker()
    //     0xdece70: bl              #0xdececc  ; [package:flutter/src/material/calendar_date_picker.dart] YearPicker::YearPicker
    // 0xdece74: r0 = Padding()
    //     0xdece74: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xdece78: r1 = Instance_EdgeInsets
    //     0xdece78: add             x1, PP, #0xad, lsl #12  ; [pp+0xadf88] Obj!EdgeInsets@129d5c1
    //     0xdece7c: ldr             x1, [x1, #0xf88]
    // 0xdece80: StoreField: r0->field_f = r1
    //     0xdece80: stur            w1, [x0, #0xf]
    // 0xdece84: ldur            x1, [fp, #-0x38]
    // 0xdece88: StoreField: r0->field_b = r1
    //     0xdece88: stur            w1, [x0, #0xb]
    // 0xdece8c: LeaveFrame
    //     0xdece8c: mov             SP, fp
    //     0xdece90: ldp             fp, lr, [SP], #0x10
    // 0xdece94: ret
    //     0xdece94: ret             
    // 0xdece98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdece98: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdece9c: b               #0xdecce8
    // 0xdecea0: r9 = _mode
    //     0xdecea0: add             x9, PP, #0xad, lsl #12  ; [pp+0xadf38] Field <_CalendarDatePickerState@54260463._mode@54260463>: late (offset: 0x1c)
    //     0xdecea4: ldr             x9, [x9, #0xf38]
    // 0xdecea8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdecea8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdeceac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdeceac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdeceb0: r9 = _currentDisplayedMonthDate
    //     0xdeceb0: add             x9, PP, #0xad, lsl #12  ; [pp+0xadf40] Field <_CalendarDatePickerState@54260463._currentDisplayedMonthDate@54260463>: late (offset: 0x20)
    //     0xdeceb4: ldr             x9, [x9, #0xf40]
    // 0xdeceb8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdeceb8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdecebc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdecebc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdecec0: r9 = _currentDisplayedMonthDate
    //     0xdecec0: add             x9, PP, #0xad, lsl #12  ; [pp+0xadf40] Field <_CalendarDatePickerState@54260463._currentDisplayedMonthDate@54260463>: late (offset: 0x20)
    //     0xdecec4: ldr             x9, [x9, #0xf40]
    // 0xdecec8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdecec8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleYearChanged(dynamic, DateTime) {
    // ** addr: 0xded190, size: 0x3c
    // 0xded190: EnterFrame
    //     0xded190: stp             fp, lr, [SP, #-0x10]!
    //     0xded194: mov             fp, SP
    // 0xded198: ldr             x0, [fp, #0x18]
    // 0xded19c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xded19c: ldur            w1, [x0, #0x17]
    // 0xded1a0: DecompressPointer r1
    //     0xded1a0: add             x1, x1, HEAP, lsl #32
    // 0xded1a4: CheckStackOverflow
    //     0xded1a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xded1a8: cmp             SP, x16
    //     0xded1ac: b.ls            #0xded1c4
    // 0xded1b0: ldr             x2, [fp, #0x10]
    // 0xded1b4: r0 = _handleYearChanged()
    //     0xded1b4: bl              #0xded1cc  ; [package:flutter/src/material/calendar_date_picker.dart] _CalendarDatePickerState::_handleYearChanged
    // 0xded1b8: LeaveFrame
    //     0xded1b8: mov             SP, fp
    //     0xded1bc: ldp             fp, lr, [SP], #0x10
    // 0xded1c0: ret
    //     0xded1c0: ret             
    // 0xded1c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xded1c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xded1c8: b               #0xded1b0
  }
  _ _handleYearChanged(/* No info */) {
    // ** addr: 0xded1cc, size: 0x418
    // 0xded1cc: EnterFrame
    //     0xded1cc: stp             fp, lr, [SP, #-0x10]!
    //     0xded1d0: mov             fp, SP
    // 0xded1d4: AllocStack(0x28)
    //     0xded1d4: sub             SP, SP, #0x28
    // 0xded1d8: SetupParameters(_CalendarDatePickerState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xded1d8: stur            x1, [fp, #-8]
    //     0xded1dc: stur            x2, [fp, #-0x10]
    // 0xded1e0: CheckStackOverflow
    //     0xded1e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xded1e4: cmp             SP, x16
    //     0xded1e8: b.ls            #0xded59c
    // 0xded1ec: r1 = 2
    //     0xded1ec: mov             x1, #2
    // 0xded1f0: r0 = AllocateContext()
    //     0xded1f0: bl              #0x13de838  ; AllocateContextStub
    // 0xded1f4: mov             x2, x0
    // 0xded1f8: ldur            x0, [fp, #-8]
    // 0xded1fc: stur            x2, [fp, #-0x18]
    // 0xded200: StoreField: r2->field_f = r0
    //     0xded200: stur            w0, [x2, #0xf]
    // 0xded204: ldur            x1, [fp, #-0x10]
    // 0xded208: StoreField: r2->field_13 = r1
    //     0xded208: stur            w1, [x2, #0x13]
    // 0xded20c: mov             x1, x0
    // 0xded210: r0 = _vibrate()
    //     0xded210: bl              #0xded670  ; [package:flutter/src/material/calendar_date_picker.dart] _CalendarDatePickerState::_vibrate
    // 0xded214: ldur            x0, [fp, #-8]
    // 0xded218: LoadField: r1 = r0->field_b
    //     0xded218: ldur            w1, [x0, #0xb]
    // 0xded21c: DecompressPointer r1
    //     0xded21c: add             x1, x1, HEAP, lsl #32
    // 0xded220: cmp             w1, NULL
    // 0xded224: b.eq            #0xded5a4
    // 0xded228: ldur            x2, [fp, #-0x18]
    // 0xded22c: LoadField: r1 = r2->field_13
    //     0xded22c: ldur            w1, [x2, #0x13]
    // 0xded230: DecompressPointer r1
    //     0xded230: add             x1, x1, HEAP, lsl #32
    // 0xded234: r0 = _parts()
    //     0xded234: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xded238: mov             x2, x0
    // 0xded23c: LoadField: r0 = r2->field_b
    //     0xded23c: ldur            w0, [x2, #0xb]
    // 0xded240: r1 = LoadInt32Instr(r0)
    //     0xded240: sbfx            x1, x0, #1, #0x1f
    // 0xded244: mov             x0, x1
    // 0xded248: r1 = 8
    //     0xded248: mov             x1, #8
    // 0xded24c: cmp             x1, x0
    // 0xded250: b.hs            #0xded5a8
    // 0xded254: LoadField: r0 = r2->field_2f
    //     0xded254: ldur            w0, [x2, #0x2f]
    // 0xded258: DecompressPointer r0
    //     0xded258: add             x0, x0, HEAP, lsl #32
    // 0xded25c: ldur            x2, [fp, #-0x18]
    // 0xded260: stur            x0, [fp, #-0x10]
    // 0xded264: LoadField: r1 = r2->field_13
    //     0xded264: ldur            w1, [x2, #0x13]
    // 0xded268: DecompressPointer r1
    //     0xded268: add             x1, x1, HEAP, lsl #32
    // 0xded26c: r0 = _parts()
    //     0xded26c: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xded270: mov             x2, x0
    // 0xded274: LoadField: r0 = r2->field_b
    //     0xded274: ldur            w0, [x2, #0xb]
    // 0xded278: r1 = LoadInt32Instr(r0)
    //     0xded278: sbfx            x1, x0, #1, #0x1f
    // 0xded27c: mov             x0, x1
    // 0xded280: r1 = 7
    //     0xded280: mov             x1, #7
    // 0xded284: cmp             x1, x0
    // 0xded288: b.hs            #0xded5ac
    // 0xded28c: LoadField: r0 = r2->field_2b
    //     0xded28c: ldur            w0, [x2, #0x2b]
    // 0xded290: DecompressPointer r0
    //     0xded290: add             x0, x0, HEAP, lsl #32
    // 0xded294: r1 = LoadInt32Instr(r0)
    //     0xded294: sbfx            x1, x0, #1, #0x1f
    //     0xded298: tbz             w0, #0, #0xded2a0
    //     0xded29c: ldur            x1, [x0, #7]
    // 0xded2a0: cmp             x1, #2
    // 0xded2a4: b.ne            #0xded304
    // 0xded2a8: ldur            x0, [fp, #-0x10]
    // 0xded2ac: r1 = LoadInt32Instr(r0)
    //     0xded2ac: sbfx            x1, x0, #1, #0x1f
    //     0xded2b0: tbz             w0, #0, #0xded2b8
    //     0xded2b4: ldur            x1, [x0, #7]
    // 0xded2b8: tst             x1, #3
    // 0xded2bc: b.ne            #0xded2d8
    // 0xded2c0: r0 = 100
    //     0xded2c0: mov             x0, #0x64
    // 0xded2c4: sdiv            x3, x1, x0
    // 0xded2c8: msub            x2, x3, x0, x1
    // 0xded2cc: cmp             x2, xzr
    // 0xded2d0: b.lt            #0xded5b0
    // 0xded2d4: cbnz            x2, #0xded2f0
    // 0xded2d8: r0 = 400
    //     0xded2d8: mov             x0, #0x190
    // 0xded2dc: sdiv            x3, x1, x0
    // 0xded2e0: msub            x2, x3, x0, x1
    // 0xded2e4: cmp             x2, xzr
    // 0xded2e8: b.lt            #0xded5b8
    // 0xded2ec: cbnz            x2, #0xded2f8
    // 0xded2f0: r0 = 29
    //     0xded2f0: mov             x0, #0x1d
    // 0xded2f4: b               #0xded2fc
    // 0xded2f8: r0 = 28
    //     0xded2f8: mov             x0, #0x1c
    // 0xded2fc: mov             x2, x0
    // 0xded300: b               #0xded33c
    // 0xded304: r2 = const [0x1f, 0xffffffffffffffff, 0x1f, 0x1e, 0x1f, 0x1e, 0x1f, 0x1f, 0x1e, 0x1f, 0x1e, 0x1f]
    //     0xded304: add             x2, PP, #0xa3, lsl #12  ; [pp+0xa3fb0] List<int>(12)
    //     0xded308: ldr             x2, [x2, #0xfb0]
    // 0xded30c: sub             x3, x1, #1
    // 0xded310: mov             x1, x3
    // 0xded314: r0 = 12
    //     0xded314: mov             x0, #0xc
    // 0xded318: cmp             x1, x0
    // 0xded31c: b.hs            #0xded5c0
    // 0xded320: ArrayLoad: r0 = r2[r3]  ; Unknown_4
    //     0xded320: add             x16, x2, x3, lsl #2
    //     0xded324: ldur            w0, [x16, #0xf]
    // 0xded328: DecompressPointer r0
    //     0xded328: add             x0, x0, HEAP, lsl #32
    // 0xded32c: r1 = LoadInt32Instr(r0)
    //     0xded32c: sbfx            x1, x0, #1, #0x1f
    //     0xded330: tbz             w0, #0, #0xded338
    //     0xded334: ldur            x1, [x0, #7]
    // 0xded338: mov             x2, x1
    // 0xded33c: ldur            x0, [fp, #-8]
    // 0xded340: stur            x2, [fp, #-0x20]
    // 0xded344: LoadField: r1 = r0->field_23
    //     0xded344: ldur            w1, [x0, #0x23]
    // 0xded348: DecompressPointer r1
    //     0xded348: add             x1, x1, HEAP, lsl #32
    // 0xded34c: cmp             w1, NULL
    // 0xded350: b.ne            #0xded35c
    // 0xded354: r0 = Null
    //     0xded354: mov             x0, NULL
    // 0xded358: b               #0xded384
    // 0xded35c: r0 = _parts()
    //     0xded35c: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xded360: mov             x2, x0
    // 0xded364: LoadField: r0 = r2->field_b
    //     0xded364: ldur            w0, [x2, #0xb]
    // 0xded368: r1 = LoadInt32Instr(r0)
    //     0xded368: sbfx            x1, x0, #1, #0x1f
    // 0xded36c: mov             x0, x1
    // 0xded370: r1 = 5
    //     0xded370: mov             x1, #5
    // 0xded374: cmp             x1, x0
    // 0xded378: b.hs            #0xded5c4
    // 0xded37c: LoadField: r0 = r2->field_23
    //     0xded37c: ldur            w0, [x2, #0x23]
    // 0xded380: DecompressPointer r0
    //     0xded380: add             x0, x0, HEAP, lsl #32
    // 0xded384: cmp             w0, NULL
    // 0xded388: b.ne            #0xded394
    // 0xded38c: r3 = 1
    //     0xded38c: mov             x3, #1
    // 0xded390: b               #0xded3a4
    // 0xded394: r1 = LoadInt32Instr(r0)
    //     0xded394: sbfx            x1, x0, #1, #0x1f
    //     0xded398: tbz             w0, #0, #0xded3a0
    //     0xded39c: ldur            x1, [x0, #7]
    // 0xded3a0: mov             x3, x1
    // 0xded3a4: ldur            x0, [fp, #-8]
    // 0xded3a8: ldur            x2, [fp, #-0x18]
    // 0xded3ac: ldur            x1, [fp, #-0x20]
    // 0xded3b0: cmp             x3, x1
    // 0xded3b4: csel            x5, x1, x3, gt
    // 0xded3b8: stur            x5, [fp, #-0x28]
    // 0xded3bc: LoadField: r1 = r0->field_b
    //     0xded3bc: ldur            w1, [x0, #0xb]
    // 0xded3c0: DecompressPointer r1
    //     0xded3c0: add             x1, x1, HEAP, lsl #32
    // 0xded3c4: cmp             w1, NULL
    // 0xded3c8: b.eq            #0xded5c8
    // 0xded3cc: LoadField: r1 = r2->field_13
    //     0xded3cc: ldur            w1, [x2, #0x13]
    // 0xded3d0: DecompressPointer r1
    //     0xded3d0: add             x1, x1, HEAP, lsl #32
    // 0xded3d4: r0 = _parts()
    //     0xded3d4: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xded3d8: mov             x2, x0
    // 0xded3dc: LoadField: r0 = r2->field_b
    //     0xded3dc: ldur            w0, [x2, #0xb]
    // 0xded3e0: r1 = LoadInt32Instr(r0)
    //     0xded3e0: sbfx            x1, x0, #1, #0x1f
    // 0xded3e4: mov             x0, x1
    // 0xded3e8: r1 = 8
    //     0xded3e8: mov             x1, #8
    // 0xded3ec: cmp             x1, x0
    // 0xded3f0: b.hs            #0xded5cc
    // 0xded3f4: LoadField: r0 = r2->field_2f
    //     0xded3f4: ldur            w0, [x2, #0x2f]
    // 0xded3f8: DecompressPointer r0
    //     0xded3f8: add             x0, x0, HEAP, lsl #32
    // 0xded3fc: ldur            x2, [fp, #-0x18]
    // 0xded400: stur            x0, [fp, #-0x10]
    // 0xded404: LoadField: r1 = r2->field_13
    //     0xded404: ldur            w1, [x2, #0x13]
    // 0xded408: DecompressPointer r1
    //     0xded408: add             x1, x1, HEAP, lsl #32
    // 0xded40c: r0 = _parts()
    //     0xded40c: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xded410: mov             x2, x0
    // 0xded414: LoadField: r0 = r2->field_b
    //     0xded414: ldur            w0, [x2, #0xb]
    // 0xded418: r1 = LoadInt32Instr(r0)
    //     0xded418: sbfx            x1, x0, #1, #0x1f
    // 0xded41c: mov             x0, x1
    // 0xded420: r1 = 7
    //     0xded420: mov             x1, #7
    // 0xded424: cmp             x1, x0
    // 0xded428: b.hs            #0xded5d0
    // 0xded42c: LoadField: r0 = r2->field_2b
    //     0xded42c: ldur            w0, [x2, #0x2b]
    // 0xded430: DecompressPointer r0
    //     0xded430: add             x0, x0, HEAP, lsl #32
    // 0xded434: ldur            x1, [fp, #-0x10]
    // 0xded438: r2 = LoadInt32Instr(r1)
    //     0xded438: sbfx            x2, x1, #1, #0x1f
    //     0xded43c: tbz             w1, #0, #0xded444
    //     0xded440: ldur            x2, [x1, #7]
    // 0xded444: r3 = LoadInt32Instr(r0)
    //     0xded444: sbfx            x3, x0, #1, #0x1f
    //     0xded448: tbz             w0, #0, #0xded450
    //     0xded44c: ldur            x3, [x0, #7]
    // 0xded450: ldur            x5, [fp, #-0x28]
    // 0xded454: r1 = Instance_GregorianCalendarDelegate
    //     0xded454: add             x1, PP, #0x28, lsl #12  ; [pp+0x28538] Obj!GregorianCalendarDelegate@129edd1
    //     0xded458: ldr             x1, [x1, #0x538]
    // 0xded45c: r0 = getDay()
    //     0xded45c: bl              #0xded5e4  ; [package:flutter/src/material/date.dart] GregorianCalendarDelegate::getDay
    // 0xded460: mov             x1, x0
    // 0xded464: ldur            x3, [fp, #-0x18]
    // 0xded468: StoreField: r3->field_13 = r0
    //     0xded468: stur            w0, [x3, #0x13]
    //     0xded46c: ldurb           w16, [x3, #-1]
    //     0xded470: ldurb           w17, [x0, #-1]
    //     0xded474: and             x16, x17, x16, lsr #2
    //     0xded478: tst             x16, HEAP, lsr #32
    //     0xded47c: b.eq            #0xded484
    //     0xded480: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xded484: ldur            x0, [fp, #-8]
    // 0xded488: LoadField: r2 = r0->field_b
    //     0xded488: ldur            w2, [x0, #0xb]
    // 0xded48c: DecompressPointer r2
    //     0xded48c: add             x2, x2, HEAP, lsl #32
    // 0xded490: cmp             w2, NULL
    // 0xded494: b.eq            #0xded5d4
    // 0xded498: LoadField: r4 = r2->field_f
    //     0xded498: ldur            w4, [x2, #0xf]
    // 0xded49c: DecompressPointer r4
    //     0xded49c: add             x4, x4, HEAP, lsl #32
    // 0xded4a0: mov             x2, x4
    // 0xded4a4: r0 = isBefore()
    //     0xded4a4: bl              #0xd183f0  ; [dart:core] DateTime::isBefore
    // 0xded4a8: tbnz            w0, #4, #0xded4f8
    // 0xded4ac: ldur            x4, [fp, #-8]
    // 0xded4b0: ldur            x3, [fp, #-0x18]
    // 0xded4b4: LoadField: r0 = r4->field_b
    //     0xded4b4: ldur            w0, [x4, #0xb]
    // 0xded4b8: DecompressPointer r0
    //     0xded4b8: add             x0, x0, HEAP, lsl #32
    // 0xded4bc: cmp             w0, NULL
    // 0xded4c0: b.eq            #0xded5d8
    // 0xded4c4: LoadField: r1 = r0->field_f
    //     0xded4c4: ldur            w1, [x0, #0xf]
    // 0xded4c8: DecompressPointer r1
    //     0xded4c8: add             x1, x1, HEAP, lsl #32
    // 0xded4cc: mov             x0, x1
    // 0xded4d0: StoreField: r3->field_13 = r0
    //     0xded4d0: stur            w0, [x3, #0x13]
    //     0xded4d4: ldurb           w16, [x3, #-1]
    //     0xded4d8: ldurb           w17, [x0, #-1]
    //     0xded4dc: and             x16, x17, x16, lsr #2
    //     0xded4e0: tst             x16, HEAP, lsr #32
    //     0xded4e4: b.eq            #0xded4ec
    //     0xded4e8: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xded4ec: mov             x2, x3
    // 0xded4f0: mov             x3, x4
    // 0xded4f4: b               #0xded574
    // 0xded4f8: ldur            x4, [fp, #-8]
    // 0xded4fc: ldur            x3, [fp, #-0x18]
    // 0xded500: LoadField: r1 = r3->field_13
    //     0xded500: ldur            w1, [x3, #0x13]
    // 0xded504: DecompressPointer r1
    //     0xded504: add             x1, x1, HEAP, lsl #32
    // 0xded508: LoadField: r0 = r4->field_b
    //     0xded508: ldur            w0, [x4, #0xb]
    // 0xded50c: DecompressPointer r0
    //     0xded50c: add             x0, x0, HEAP, lsl #32
    // 0xded510: cmp             w0, NULL
    // 0xded514: b.eq            #0xded5dc
    // 0xded518: LoadField: r2 = r0->field_13
    //     0xded518: ldur            w2, [x0, #0x13]
    // 0xded51c: DecompressPointer r2
    //     0xded51c: add             x2, x2, HEAP, lsl #32
    // 0xded520: r0 = isAfter()
    //     0xded520: bl              #0xd183d4  ; [dart:core] DateTime::isAfter
    // 0xded524: tbnz            w0, #4, #0xded56c
    // 0xded528: ldur            x3, [fp, #-8]
    // 0xded52c: ldur            x2, [fp, #-0x18]
    // 0xded530: LoadField: r0 = r3->field_b
    //     0xded530: ldur            w0, [x3, #0xb]
    // 0xded534: DecompressPointer r0
    //     0xded534: add             x0, x0, HEAP, lsl #32
    // 0xded538: cmp             w0, NULL
    // 0xded53c: b.eq            #0xded5e0
    // 0xded540: LoadField: r1 = r0->field_13
    //     0xded540: ldur            w1, [x0, #0x13]
    // 0xded544: DecompressPointer r1
    //     0xded544: add             x1, x1, HEAP, lsl #32
    // 0xded548: mov             x0, x1
    // 0xded54c: StoreField: r2->field_13 = r0
    //     0xded54c: stur            w0, [x2, #0x13]
    //     0xded550: ldurb           w16, [x2, #-1]
    //     0xded554: ldurb           w17, [x0, #-1]
    //     0xded558: and             x16, x17, x16, lsr #2
    //     0xded55c: tst             x16, HEAP, lsr #32
    //     0xded560: b.eq            #0xded568
    //     0xded564: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xded568: b               #0xded574
    // 0xded56c: ldur            x3, [fp, #-8]
    // 0xded570: ldur            x2, [fp, #-0x18]
    // 0xded574: r1 = Function '<anonymous closure>':.
    //     0xded574: add             x1, PP, #0xad, lsl #12  ; [pp+0xadf90] AnonymousClosure: (0xded6ec), in [package:flutter/src/material/calendar_date_picker.dart] _CalendarDatePickerState::_handleYearChanged (0xded1cc)
    //     0xded578: ldr             x1, [x1, #0xf90]
    // 0xded57c: r0 = AllocateClosure()
    //     0xded57c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xded580: ldur            x1, [fp, #-8]
    // 0xded584: mov             x2, x0
    // 0xded588: r0 = setState()
    //     0xded588: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xded58c: r0 = Null
    //     0xded58c: mov             x0, NULL
    // 0xded590: LeaveFrame
    //     0xded590: mov             SP, fp
    //     0xded594: ldp             fp, lr, [SP], #0x10
    // 0xded598: ret
    //     0xded598: ret             
    // 0xded59c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xded59c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xded5a0: b               #0xded1ec
    // 0xded5a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xded5a4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xded5a8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xded5a8: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xded5ac: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xded5ac: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xded5b0: add             x2, x2, x0
    // 0xded5b4: b               #0xded2d4
    // 0xded5b8: add             x2, x2, x0
    // 0xded5bc: b               #0xded2ec
    // 0xded5c0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xded5c0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xded5c4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xded5c4: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xded5c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xded5c8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xded5cc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xded5cc: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xded5d0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xded5d0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xded5d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xded5d4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xded5d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xded5d8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xded5dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xded5dc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xded5e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xded5e0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _vibrate(/* No info */) {
    // ** addr: 0xded670, size: 0x7c
    // 0xded670: EnterFrame
    //     0xded670: stp             fp, lr, [SP, #-0x10]!
    //     0xded674: mov             fp, SP
    // 0xded678: CheckStackOverflow
    //     0xded678: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xded67c: cmp             SP, x16
    //     0xded680: b.ls            #0xded6e0
    // 0xded684: LoadField: r0 = r1->field_f
    //     0xded684: ldur            w0, [x1, #0xf]
    // 0xded688: DecompressPointer r0
    //     0xded688: add             x0, x0, HEAP, lsl #32
    // 0xded68c: cmp             w0, NULL
    // 0xded690: b.eq            #0xded6e8
    // 0xded694: mov             x1, x0
    // 0xded698: r0 = of()
    //     0xded698: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xded69c: LoadField: r1 = r0->field_23
    //     0xded69c: ldur            w1, [x0, #0x23]
    // 0xded6a0: DecompressPointer r1
    //     0xded6a0: add             x1, x1, HEAP, lsl #32
    // 0xded6a4: LoadField: r0 = r1->field_7
    //     0xded6a4: ldur            x0, [x1, #7]
    // 0xded6a8: cmp             x0, #2
    // 0xded6ac: b.gt            #0xded6bc
    // 0xded6b0: cmp             x0, #1
    // 0xded6b4: b.gt            #0xded6d0
    // 0xded6b8: b               #0xded6cc
    // 0xded6bc: cmp             x0, #4
    // 0xded6c0: b.gt            #0xded6cc
    // 0xded6c4: cmp             x0, #3
    // 0xded6c8: b.gt            #0xded6d0
    // 0xded6cc: r0 = vibrate()
    //     0xded6cc: bl              #0xd4731c  ; [package:flutter/src/services/haptic_feedback.dart] HapticFeedback::vibrate
    // 0xded6d0: r0 = Null
    //     0xded6d0: mov             x0, NULL
    // 0xded6d4: LeaveFrame
    //     0xded6d4: mov             SP, fp
    //     0xded6d8: ldp             fp, lr, [SP], #0x10
    // 0xded6dc: ret
    //     0xded6dc: ret             
    // 0xded6e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xded6e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xded6e4: b               #0xded684
    // 0xded6e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xded6e8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xded6ec, size: 0xc0
    // 0xded6ec: EnterFrame
    //     0xded6ec: stp             fp, lr, [SP, #-0x10]!
    //     0xded6f0: mov             fp, SP
    // 0xded6f4: AllocStack(0x8)
    //     0xded6f4: sub             SP, SP, #8
    // 0xded6f8: SetupParameters([dynamic _ /* r1 */])
    //     0xded6f8: add             x0, PP, #0x28, lsl #12  ; [pp+0x28528] Obj!DatePickerMode@12c5821
    //     0xded6fc: ldr             x0, [x0, #0x528]
    //     0xded700: ldr             x1, [fp, #0x10]
    //     0xded704: ldur            w3, [x1, #0x17]
    //     0xded708: add             x3, x3, HEAP, lsl #32
    //     0xded70c: stur            x3, [fp, #-8]
    // 0xded6f8: r0 = Instance_DatePickerMode
    // 0xded710: CheckStackOverflow
    //     0xded710: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xded714: cmp             SP, x16
    //     0xded718: b.ls            #0xded7a0
    // 0xded71c: LoadField: r1 = r3->field_f
    //     0xded71c: ldur            w1, [x3, #0xf]
    // 0xded720: DecompressPointer r1
    //     0xded720: add             x1, x1, HEAP, lsl #32
    // 0xded724: StoreField: r1->field_1b = r0
    //     0xded724: stur            w0, [x1, #0x1b]
    // 0xded728: LoadField: r2 = r3->field_13
    //     0xded728: ldur            w2, [x3, #0x13]
    // 0xded72c: DecompressPointer r2
    //     0xded72c: add             x2, x2, HEAP, lsl #32
    // 0xded730: r0 = _handleMonthChanged()
    //     0xded730: bl              #0xded7ac  ; [package:flutter/src/material/calendar_date_picker.dart] _CalendarDatePickerState::_handleMonthChanged
    // 0xded734: ldur            x0, [fp, #-8]
    // 0xded738: LoadField: r1 = r0->field_f
    //     0xded738: ldur            w1, [x0, #0xf]
    // 0xded73c: DecompressPointer r1
    //     0xded73c: add             x1, x1, HEAP, lsl #32
    // 0xded740: LoadField: r2 = r1->field_b
    //     0xded740: ldur            w2, [x1, #0xb]
    // 0xded744: DecompressPointer r2
    //     0xded744: add             x2, x2, HEAP, lsl #32
    // 0xded748: cmp             w2, NULL
    // 0xded74c: b.eq            #0xded7a8
    // 0xded750: LoadField: r3 = r0->field_13
    //     0xded750: ldur            w3, [x0, #0x13]
    // 0xded754: DecompressPointer r3
    //     0xded754: add             x3, x3, HEAP, lsl #32
    // 0xded758: mov             x0, x3
    // 0xded75c: StoreField: r1->field_23 = r0
    //     0xded75c: stur            w0, [x1, #0x23]
    //     0xded760: ldurb           w16, [x1, #-1]
    //     0xded764: ldurb           w17, [x0, #-1]
    //     0xded768: and             x16, x17, x16, lsr #2
    //     0xded76c: tst             x16, HEAP, lsr #32
    //     0xded770: b.eq            #0xded778
    //     0xded774: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xded778: LoadField: r0 = r2->field_1b
    //     0xded778: ldur            w0, [x2, #0x1b]
    // 0xded77c: DecompressPointer r0
    //     0xded77c: add             x0, x0, HEAP, lsl #32
    // 0xded780: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xded780: ldur            w1, [x0, #0x17]
    // 0xded784: DecompressPointer r1
    //     0xded784: add             x1, x1, HEAP, lsl #32
    // 0xded788: mov             x2, x3
    // 0xded78c: r0 = _handleDateChanged()
    //     0xded78c: bl              #0xd18224  ; [package:flutter/src/material/date_picker.dart] _DatePickerDialogState::_handleDateChanged
    // 0xded790: r0 = Null
    //     0xded790: mov             x0, NULL
    // 0xded794: LeaveFrame
    //     0xded794: mov             SP, fp
    //     0xded798: ldp             fp, lr, [SP], #0x10
    // 0xded79c: ret
    //     0xded79c: ret             
    // 0xded7a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xded7a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xded7a4: b               #0xded71c
    // 0xded7a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xded7a8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _handleMonthChanged(/* No info */) {
    // ** addr: 0xded7ac, size: 0x70
    // 0xded7ac: EnterFrame
    //     0xded7ac: stp             fp, lr, [SP, #-0x10]!
    //     0xded7b0: mov             fp, SP
    // 0xded7b4: AllocStack(0x10)
    //     0xded7b4: sub             SP, SP, #0x10
    // 0xded7b8: SetupParameters(_CalendarDatePickerState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xded7b8: stur            x1, [fp, #-8]
    //     0xded7bc: stur            x2, [fp, #-0x10]
    // 0xded7c0: CheckStackOverflow
    //     0xded7c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xded7c4: cmp             SP, x16
    //     0xded7c8: b.ls            #0xded814
    // 0xded7cc: r1 = 2
    //     0xded7cc: mov             x1, #2
    // 0xded7d0: r0 = AllocateContext()
    //     0xded7d0: bl              #0x13de838  ; AllocateContextStub
    // 0xded7d4: mov             x1, x0
    // 0xded7d8: ldur            x0, [fp, #-8]
    // 0xded7dc: StoreField: r1->field_f = r0
    //     0xded7dc: stur            w0, [x1, #0xf]
    // 0xded7e0: ldur            x2, [fp, #-0x10]
    // 0xded7e4: StoreField: r1->field_13 = r2
    //     0xded7e4: stur            w2, [x1, #0x13]
    // 0xded7e8: mov             x2, x1
    // 0xded7ec: r1 = Function '<anonymous closure>':.
    //     0xded7ec: add             x1, PP, #0xad, lsl #12  ; [pp+0xadf98] AnonymousClosure: (0xded81c), in [package:flutter/src/material/calendar_date_picker.dart] _CalendarDatePickerState::_handleMonthChanged (0xded7ac)
    //     0xded7f0: ldr             x1, [x1, #0xf98]
    // 0xded7f4: r0 = AllocateClosure()
    //     0xded7f4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xded7f8: ldur            x1, [fp, #-8]
    // 0xded7fc: mov             x2, x0
    // 0xded800: r0 = setState()
    //     0xded800: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xded804: r0 = Null
    //     0xded804: mov             x0, NULL
    // 0xded808: LeaveFrame
    //     0xded808: mov             SP, fp
    //     0xded80c: ldp             fp, lr, [SP], #0x10
    // 0xded810: ret
    //     0xded810: ret             
    // 0xded814: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xded814: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xded818: b               #0xded7cc
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xded81c, size: 0x2ac
    // 0xded81c: EnterFrame
    //     0xded81c: stp             fp, lr, [SP, #-0x10]!
    //     0xded820: mov             fp, SP
    // 0xded824: AllocStack(0x18)
    //     0xded824: sub             SP, SP, #0x18
    // 0xded828: SetupParameters([dynamic _ /* r0 */])
    //     0xded828: ldr             x0, [fp, #0x10]
    //     0xded82c: ldur            w2, [x0, #0x17]
    //     0xded830: add             x2, x2, HEAP, lsl #32
    //     0xded834: stur            x2, [fp, #-8]
    // 0xded838: CheckStackOverflow
    //     0xded838: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xded83c: cmp             SP, x16
    //     0xded840: b.ls            #0xdeda88
    // 0xded844: LoadField: r0 = r2->field_f
    //     0xded844: ldur            w0, [x2, #0xf]
    // 0xded848: DecompressPointer r0
    //     0xded848: add             x0, x0, HEAP, lsl #32
    // 0xded84c: LoadField: r1 = r0->field_1f
    //     0xded84c: ldur            w1, [x0, #0x1f]
    // 0xded850: DecompressPointer r1
    //     0xded850: add             x1, x1, HEAP, lsl #32
    // 0xded854: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xded858: cmp             w1, w16
    // 0xded85c: b.eq            #0xdeda90
    // 0xded860: r0 = _parts()
    //     0xded860: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xded864: mov             x2, x0
    // 0xded868: LoadField: r0 = r2->field_b
    //     0xded868: ldur            w0, [x2, #0xb]
    // 0xded86c: r1 = LoadInt32Instr(r0)
    //     0xded86c: sbfx            x1, x0, #1, #0x1f
    // 0xded870: mov             x0, x1
    // 0xded874: r1 = 8
    //     0xded874: mov             x1, #8
    // 0xded878: cmp             x1, x0
    // 0xded87c: b.hs            #0xdeda9c
    // 0xded880: LoadField: r0 = r2->field_2f
    //     0xded880: ldur            w0, [x2, #0x2f]
    // 0xded884: DecompressPointer r0
    //     0xded884: add             x0, x0, HEAP, lsl #32
    // 0xded888: ldur            x2, [fp, #-8]
    // 0xded88c: stur            x0, [fp, #-0x10]
    // 0xded890: LoadField: r1 = r2->field_13
    //     0xded890: ldur            w1, [x2, #0x13]
    // 0xded894: DecompressPointer r1
    //     0xded894: add             x1, x1, HEAP, lsl #32
    // 0xded898: r0 = _parts()
    //     0xded898: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xded89c: mov             x2, x0
    // 0xded8a0: LoadField: r0 = r2->field_b
    //     0xded8a0: ldur            w0, [x2, #0xb]
    // 0xded8a4: r1 = LoadInt32Instr(r0)
    //     0xded8a4: sbfx            x1, x0, #1, #0x1f
    // 0xded8a8: mov             x0, x1
    // 0xded8ac: r1 = 8
    //     0xded8ac: mov             x1, #8
    // 0xded8b0: cmp             x1, x0
    // 0xded8b4: b.hs            #0xdedaa0
    // 0xded8b8: LoadField: r0 = r2->field_2f
    //     0xded8b8: ldur            w0, [x2, #0x2f]
    // 0xded8bc: DecompressPointer r0
    //     0xded8bc: add             x0, x0, HEAP, lsl #32
    // 0xded8c0: ldur            x1, [fp, #-0x10]
    // 0xded8c4: r2 = LoadInt32Instr(r1)
    //     0xded8c4: sbfx            x2, x1, #1, #0x1f
    //     0xded8c8: tbz             w1, #0, #0xded8d0
    //     0xded8cc: ldur            x2, [x1, #7]
    // 0xded8d0: r1 = LoadInt32Instr(r0)
    //     0xded8d0: sbfx            x1, x0, #1, #0x1f
    //     0xded8d4: tbz             w0, #0, #0xded8dc
    //     0xded8d8: ldur            x1, [x0, #7]
    // 0xded8dc: cmp             x2, x1
    // 0xded8e0: b.ne            #0xded98c
    // 0xded8e4: ldur            x0, [fp, #-8]
    // 0xded8e8: LoadField: r1 = r0->field_f
    //     0xded8e8: ldur            w1, [x0, #0xf]
    // 0xded8ec: DecompressPointer r1
    //     0xded8ec: add             x1, x1, HEAP, lsl #32
    // 0xded8f0: LoadField: r2 = r1->field_1f
    //     0xded8f0: ldur            w2, [x1, #0x1f]
    // 0xded8f4: DecompressPointer r2
    //     0xded8f4: add             x2, x2, HEAP, lsl #32
    // 0xded8f8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xded8fc: cmp             w2, w16
    // 0xded900: b.eq            #0xdedaa4
    // 0xded904: mov             x1, x2
    // 0xded908: r0 = _parts()
    //     0xded908: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xded90c: mov             x2, x0
    // 0xded910: LoadField: r0 = r2->field_b
    //     0xded910: ldur            w0, [x2, #0xb]
    // 0xded914: r1 = LoadInt32Instr(r0)
    //     0xded914: sbfx            x1, x0, #1, #0x1f
    // 0xded918: mov             x0, x1
    // 0xded91c: r1 = 7
    //     0xded91c: mov             x1, #7
    // 0xded920: cmp             x1, x0
    // 0xded924: b.hs            #0xdedab0
    // 0xded928: LoadField: r0 = r2->field_2b
    //     0xded928: ldur            w0, [x2, #0x2b]
    // 0xded92c: DecompressPointer r0
    //     0xded92c: add             x0, x0, HEAP, lsl #32
    // 0xded930: ldur            x2, [fp, #-8]
    // 0xded934: stur            x0, [fp, #-0x10]
    // 0xded938: LoadField: r1 = r2->field_13
    //     0xded938: ldur            w1, [x2, #0x13]
    // 0xded93c: DecompressPointer r1
    //     0xded93c: add             x1, x1, HEAP, lsl #32
    // 0xded940: r0 = _parts()
    //     0xded940: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xded944: mov             x2, x0
    // 0xded948: LoadField: r0 = r2->field_b
    //     0xded948: ldur            w0, [x2, #0xb]
    // 0xded94c: r1 = LoadInt32Instr(r0)
    //     0xded94c: sbfx            x1, x0, #1, #0x1f
    // 0xded950: mov             x0, x1
    // 0xded954: r1 = 7
    //     0xded954: mov             x1, #7
    // 0xded958: cmp             x1, x0
    // 0xded95c: b.hs            #0xdedab4
    // 0xded960: LoadField: r0 = r2->field_2b
    //     0xded960: ldur            w0, [x2, #0x2b]
    // 0xded964: DecompressPointer r0
    //     0xded964: add             x0, x0, HEAP, lsl #32
    // 0xded968: ldur            x1, [fp, #-0x10]
    // 0xded96c: r2 = LoadInt32Instr(r1)
    //     0xded96c: sbfx            x2, x1, #1, #0x1f
    //     0xded970: tbz             w1, #0, #0xded978
    //     0xded974: ldur            x2, [x1, #7]
    // 0xded978: r1 = LoadInt32Instr(r0)
    //     0xded978: sbfx            x1, x0, #1, #0x1f
    //     0xded97c: tbz             w0, #0, #0xded984
    //     0xded980: ldur            x1, [x0, #7]
    // 0xded984: cmp             x2, x1
    // 0xded988: b.eq            #0xdeda78
    // 0xded98c: ldur            x0, [fp, #-8]
    // 0xded990: LoadField: r2 = r0->field_f
    //     0xded990: ldur            w2, [x0, #0xf]
    // 0xded994: DecompressPointer r2
    //     0xded994: add             x2, x2, HEAP, lsl #32
    // 0xded998: stur            x2, [fp, #-0x10]
    // 0xded99c: LoadField: r1 = r2->field_b
    //     0xded99c: ldur            w1, [x2, #0xb]
    // 0xded9a0: DecompressPointer r1
    //     0xded9a0: add             x1, x1, HEAP, lsl #32
    // 0xded9a4: cmp             w1, NULL
    // 0xded9a8: b.eq            #0xdedab8
    // 0xded9ac: LoadField: r1 = r0->field_13
    //     0xded9ac: ldur            w1, [x0, #0x13]
    // 0xded9b0: DecompressPointer r1
    //     0xded9b0: add             x1, x1, HEAP, lsl #32
    // 0xded9b4: r0 = _parts()
    //     0xded9b4: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xded9b8: mov             x2, x0
    // 0xded9bc: LoadField: r0 = r2->field_b
    //     0xded9bc: ldur            w0, [x2, #0xb]
    // 0xded9c0: r1 = LoadInt32Instr(r0)
    //     0xded9c0: sbfx            x1, x0, #1, #0x1f
    // 0xded9c4: mov             x0, x1
    // 0xded9c8: r1 = 8
    //     0xded9c8: mov             x1, #8
    // 0xded9cc: cmp             x1, x0
    // 0xded9d0: b.hs            #0xdedabc
    // 0xded9d4: LoadField: r0 = r2->field_2f
    //     0xded9d4: ldur            w0, [x2, #0x2f]
    // 0xded9d8: DecompressPointer r0
    //     0xded9d8: add             x0, x0, HEAP, lsl #32
    // 0xded9dc: ldur            x2, [fp, #-8]
    // 0xded9e0: stur            x0, [fp, #-0x18]
    // 0xded9e4: LoadField: r1 = r2->field_13
    //     0xded9e4: ldur            w1, [x2, #0x13]
    // 0xded9e8: DecompressPointer r1
    //     0xded9e8: add             x1, x1, HEAP, lsl #32
    // 0xded9ec: r0 = _parts()
    //     0xded9ec: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xded9f0: mov             x2, x0
    // 0xded9f4: LoadField: r0 = r2->field_b
    //     0xded9f4: ldur            w0, [x2, #0xb]
    // 0xded9f8: r1 = LoadInt32Instr(r0)
    //     0xded9f8: sbfx            x1, x0, #1, #0x1f
    // 0xded9fc: mov             x0, x1
    // 0xdeda00: r1 = 7
    //     0xdeda00: mov             x1, #7
    // 0xdeda04: cmp             x1, x0
    // 0xdeda08: b.hs            #0xdedac0
    // 0xdeda0c: LoadField: r0 = r2->field_2b
    //     0xdeda0c: ldur            w0, [x2, #0x2b]
    // 0xdeda10: DecompressPointer r0
    //     0xdeda10: add             x0, x0, HEAP, lsl #32
    // 0xdeda14: ldur            x1, [fp, #-0x18]
    // 0xdeda18: r2 = LoadInt32Instr(r1)
    //     0xdeda18: sbfx            x2, x1, #1, #0x1f
    //     0xdeda1c: tbz             w1, #0, #0xdeda24
    //     0xdeda20: ldur            x2, [x1, #7]
    // 0xdeda24: r3 = LoadInt32Instr(r0)
    //     0xdeda24: sbfx            x3, x0, #1, #0x1f
    //     0xdeda28: tbz             w0, #0, #0xdeda30
    //     0xdeda2c: ldur            x3, [x0, #7]
    // 0xdeda30: r1 = Instance_GregorianCalendarDelegate
    //     0xdeda30: add             x1, PP, #0x28, lsl #12  ; [pp+0x28538] Obj!GregorianCalendarDelegate@129edd1
    //     0xdeda34: ldr             x1, [x1, #0x538]
    // 0xdeda38: r0 = getMonth()
    //     0xdeda38: bl              #0xdedac8  ; [package:flutter/src/material/date.dart] GregorianCalendarDelegate::getMonth
    // 0xdeda3c: ldur            x1, [fp, #-0x10]
    // 0xdeda40: StoreField: r1->field_1f = r0
    //     0xdeda40: stur            w0, [x1, #0x1f]
    //     0xdeda44: ldurb           w16, [x1, #-1]
    //     0xdeda48: ldurb           w17, [x0, #-1]
    //     0xdeda4c: and             x16, x17, x16, lsr #2
    //     0xdeda50: tst             x16, HEAP, lsr #32
    //     0xdeda54: b.eq            #0xdeda5c
    //     0xdeda58: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdeda5c: ldur            x1, [fp, #-8]
    // 0xdeda60: LoadField: r2 = r1->field_f
    //     0xdeda60: ldur            w2, [x1, #0xf]
    // 0xdeda64: DecompressPointer r2
    //     0xdeda64: add             x2, x2, HEAP, lsl #32
    // 0xdeda68: LoadField: r1 = r2->field_b
    //     0xdeda68: ldur            w1, [x2, #0xb]
    // 0xdeda6c: DecompressPointer r1
    //     0xdeda6c: add             x1, x1, HEAP, lsl #32
    // 0xdeda70: cmp             w1, NULL
    // 0xdeda74: b.eq            #0xdedac4
    // 0xdeda78: r0 = Null
    //     0xdeda78: mov             x0, NULL
    // 0xdeda7c: LeaveFrame
    //     0xdeda7c: mov             SP, fp
    //     0xdeda80: ldp             fp, lr, [SP], #0x10
    // 0xdeda84: ret
    //     0xdeda84: ret             
    // 0xdeda88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdeda88: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdeda8c: b               #0xded844
    // 0xdeda90: r9 = _currentDisplayedMonthDate
    //     0xdeda90: add             x9, PP, #0xad, lsl #12  ; [pp+0xadf40] Field <_CalendarDatePickerState@54260463._currentDisplayedMonthDate@54260463>: late (offset: 0x20)
    //     0xdeda94: ldr             x9, [x9, #0xf40]
    // 0xdeda98: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdeda98: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdeda9c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdeda9c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdedaa0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdedaa0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdedaa4: r9 = _currentDisplayedMonthDate
    //     0xdedaa4: add             x9, PP, #0xad, lsl #12  ; [pp+0xadf40] Field <_CalendarDatePickerState@54260463._currentDisplayedMonthDate@54260463>: late (offset: 0x20)
    //     0xdedaa8: ldr             x9, [x9, #0xf40]
    // 0xdedaac: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdedaac: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdedab0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdedab0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdedab4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdedab4: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdedab8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdedab8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdedabc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdedabc: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdedac0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdedac0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdedac4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdedac4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleMonthChanged(dynamic, DateTime) {
    // ** addr: 0xdedb34, size: 0x3c
    // 0xdedb34: EnterFrame
    //     0xdedb34: stp             fp, lr, [SP, #-0x10]!
    //     0xdedb38: mov             fp, SP
    // 0xdedb3c: ldr             x0, [fp, #0x18]
    // 0xdedb40: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdedb40: ldur            w1, [x0, #0x17]
    // 0xdedb44: DecompressPointer r1
    //     0xdedb44: add             x1, x1, HEAP, lsl #32
    // 0xdedb48: CheckStackOverflow
    //     0xdedb48: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdedb4c: cmp             SP, x16
    //     0xdedb50: b.ls            #0xdedb68
    // 0xdedb54: ldr             x2, [fp, #0x10]
    // 0xdedb58: r0 = _handleMonthChanged()
    //     0xdedb58: bl              #0xded7ac  ; [package:flutter/src/material/calendar_date_picker.dart] _CalendarDatePickerState::_handleMonthChanged
    // 0xdedb5c: LeaveFrame
    //     0xdedb5c: mov             SP, fp
    //     0xdedb60: ldp             fp, lr, [SP], #0x10
    // 0xdedb64: ret
    //     0xdedb64: ret             
    // 0xdedb68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdedb68: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdedb6c: b               #0xdedb54
  }
  [closure] void _handleDayChanged(dynamic, DateTime) {
    // ** addr: 0xdedb70, size: 0x3c
    // 0xdedb70: EnterFrame
    //     0xdedb70: stp             fp, lr, [SP, #-0x10]!
    //     0xdedb74: mov             fp, SP
    // 0xdedb78: ldr             x0, [fp, #0x18]
    // 0xdedb7c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdedb7c: ldur            w1, [x0, #0x17]
    // 0xdedb80: DecompressPointer r1
    //     0xdedb80: add             x1, x1, HEAP, lsl #32
    // 0xdedb84: CheckStackOverflow
    //     0xdedb84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdedb88: cmp             SP, x16
    //     0xdedb8c: b.ls            #0xdedba4
    // 0xdedb90: ldr             x2, [fp, #0x10]
    // 0xdedb94: r0 = _handleDayChanged()
    //     0xdedb94: bl              #0xdedbac  ; [package:flutter/src/material/calendar_date_picker.dart] _CalendarDatePickerState::_handleDayChanged
    // 0xdedb98: LeaveFrame
    //     0xdedb98: mov             SP, fp
    //     0xdedb9c: ldp             fp, lr, [SP], #0x10
    // 0xdedba0: ret
    //     0xdedba0: ret             
    // 0xdedba4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdedba4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdedba8: b               #0xdedb90
  }
  _ _handleDayChanged(/* No info */) {
    // ** addr: 0xdedbac, size: 0x7c
    // 0xdedbac: EnterFrame
    //     0xdedbac: stp             fp, lr, [SP, #-0x10]!
    //     0xdedbb0: mov             fp, SP
    // 0xdedbb4: AllocStack(0x18)
    //     0xdedbb4: sub             SP, SP, #0x18
    // 0xdedbb8: SetupParameters(_CalendarDatePickerState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xdedbb8: stur            x1, [fp, #-8]
    //     0xdedbbc: stur            x2, [fp, #-0x10]
    // 0xdedbc0: CheckStackOverflow
    //     0xdedbc0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdedbc4: cmp             SP, x16
    //     0xdedbc8: b.ls            #0xdedc20
    // 0xdedbcc: r1 = 2
    //     0xdedbcc: mov             x1, #2
    // 0xdedbd0: r0 = AllocateContext()
    //     0xdedbd0: bl              #0x13de838  ; AllocateContextStub
    // 0xdedbd4: mov             x2, x0
    // 0xdedbd8: ldur            x0, [fp, #-8]
    // 0xdedbdc: stur            x2, [fp, #-0x18]
    // 0xdedbe0: StoreField: r2->field_f = r0
    //     0xdedbe0: stur            w0, [x2, #0xf]
    // 0xdedbe4: ldur            x1, [fp, #-0x10]
    // 0xdedbe8: StoreField: r2->field_13 = r1
    //     0xdedbe8: stur            w1, [x2, #0x13]
    // 0xdedbec: mov             x1, x0
    // 0xdedbf0: r0 = _vibrate()
    //     0xdedbf0: bl              #0xded670  ; [package:flutter/src/material/calendar_date_picker.dart] _CalendarDatePickerState::_vibrate
    // 0xdedbf4: ldur            x2, [fp, #-0x18]
    // 0xdedbf8: r1 = Function '<anonymous closure>':.
    //     0xdedbf8: add             x1, PP, #0xad, lsl #12  ; [pp+0xadfa0] AnonymousClosure: (0xdedc28), in [package:flutter/src/material/calendar_date_picker.dart] _CalendarDatePickerState::_handleDayChanged (0xdedbac)
    //     0xdedbfc: ldr             x1, [x1, #0xfa0]
    // 0xdedc00: r0 = AllocateClosure()
    //     0xdedc00: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdedc04: ldur            x1, [fp, #-8]
    // 0xdedc08: mov             x2, x0
    // 0xdedc0c: r0 = setState()
    //     0xdedc0c: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xdedc10: r0 = Null
    //     0xdedc10: mov             x0, NULL
    // 0xdedc14: LeaveFrame
    //     0xdedc14: mov             SP, fp
    //     0xdedc18: ldp             fp, lr, [SP], #0x10
    // 0xdedc1c: ret
    //     0xdedc1c: ret             
    // 0xdedc20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdedc20: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdedc24: b               #0xdedbcc
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xdedc28, size: 0x384
    // 0xdedc28: EnterFrame
    //     0xdedc28: stp             fp, lr, [SP, #-0x10]!
    //     0xdedc2c: mov             fp, SP
    // 0xdedc30: AllocStack(0x30)
    //     0xdedc30: sub             SP, SP, #0x30
    // 0xdedc34: SetupParameters([dynamic _ /* r0 */])
    //     0xdedc34: ldr             x0, [fp, #0x10]
    //     0xdedc38: ldur            w3, [x0, #0x17]
    //     0xdedc3c: add             x3, x3, HEAP, lsl #32
    //     0xdedc40: stur            x3, [fp, #-8]
    // 0xdedc44: CheckStackOverflow
    //     0xdedc44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdedc48: cmp             SP, x16
    //     0xdedc4c: b.ls            #0xdedf5c
    // 0xdedc50: LoadField: r1 = r3->field_f
    //     0xdedc50: ldur            w1, [x3, #0xf]
    // 0xdedc54: DecompressPointer r1
    //     0xdedc54: add             x1, x1, HEAP, lsl #32
    // 0xdedc58: LoadField: r2 = r3->field_13
    //     0xdedc58: ldur            w2, [x3, #0x13]
    // 0xdedc5c: DecompressPointer r2
    //     0xdedc5c: add             x2, x2, HEAP, lsl #32
    // 0xdedc60: mov             x0, x2
    // 0xdedc64: StoreField: r1->field_23 = r0
    //     0xdedc64: stur            w0, [x1, #0x23]
    //     0xdedc68: ldurb           w16, [x1, #-1]
    //     0xdedc6c: ldurb           w17, [x0, #-1]
    //     0xdedc70: and             x16, x17, x16, lsr #2
    //     0xdedc74: tst             x16, HEAP, lsr #32
    //     0xdedc78: b.eq            #0xdedc80
    //     0xdedc7c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdedc80: LoadField: r0 = r1->field_b
    //     0xdedc80: ldur            w0, [x1, #0xb]
    // 0xdedc84: DecompressPointer r0
    //     0xdedc84: add             x0, x0, HEAP, lsl #32
    // 0xdedc88: cmp             w0, NULL
    // 0xdedc8c: b.eq            #0xdedf64
    // 0xdedc90: LoadField: r1 = r0->field_1b
    //     0xdedc90: ldur            w1, [x0, #0x1b]
    // 0xdedc94: DecompressPointer r1
    //     0xdedc94: add             x1, x1, HEAP, lsl #32
    // 0xdedc98: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xdedc98: ldur            w0, [x1, #0x17]
    // 0xdedc9c: DecompressPointer r0
    //     0xdedc9c: add             x0, x0, HEAP, lsl #32
    // 0xdedca0: mov             x1, x0
    // 0xdedca4: r0 = _handleDateChanged()
    //     0xdedca4: bl              #0xd18224  ; [package:flutter/src/material/date_picker.dart] _DatePickerDialogState::_handleDateChanged
    // 0xdedca8: ldur            x0, [fp, #-8]
    // 0xdedcac: LoadField: r1 = r0->field_f
    //     0xdedcac: ldur            w1, [x0, #0xf]
    // 0xdedcb0: DecompressPointer r1
    //     0xdedcb0: add             x1, x1, HEAP, lsl #32
    // 0xdedcb4: LoadField: r2 = r1->field_f
    //     0xdedcb4: ldur            w2, [x1, #0xf]
    // 0xdedcb8: DecompressPointer r2
    //     0xdedcb8: add             x2, x2, HEAP, lsl #32
    // 0xdedcbc: cmp             w2, NULL
    // 0xdedcc0: b.eq            #0xdedf68
    // 0xdedcc4: mov             x1, x2
    // 0xdedcc8: r0 = of()
    //     0xdedcc8: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xdedccc: LoadField: r1 = r0->field_23
    //     0xdedccc: ldur            w1, [x0, #0x23]
    // 0xdedcd0: DecompressPointer r1
    //     0xdedcd0: add             x1, x1, HEAP, lsl #32
    // 0xdedcd4: LoadField: r0 = r1->field_7
    //     0xdedcd4: ldur            x0, [x1, #7]
    // 0xdedcd8: cmp             x0, #2
    // 0xdedcdc: b.le            #0xdedf4c
    // 0xdedce0: ldur            x0, [fp, #-8]
    // 0xdedce4: LoadField: r1 = r0->field_f
    //     0xdedce4: ldur            w1, [x0, #0xf]
    // 0xdedce8: DecompressPointer r1
    //     0xdedce8: add             x1, x1, HEAP, lsl #32
    // 0xdedcec: LoadField: r2 = r1->field_b
    //     0xdedcec: ldur            w2, [x1, #0xb]
    // 0xdedcf0: DecompressPointer r2
    //     0xdedcf0: add             x2, x2, HEAP, lsl #32
    // 0xdedcf4: cmp             w2, NULL
    // 0xdedcf8: b.eq            #0xdedf6c
    // 0xdedcfc: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xdedcfc: ldur            w3, [x2, #0x17]
    // 0xdedd00: DecompressPointer r3
    //     0xdedd00: add             x3, x3, HEAP, lsl #32
    // 0xdedd04: LoadField: r2 = r1->field_23
    //     0xdedd04: ldur            w2, [x1, #0x23]
    // 0xdedd08: DecompressPointer r2
    //     0xdedd08: add             x2, x2, HEAP, lsl #32
    // 0xdedd0c: mov             x16, x2
    // 0xdedd10: mov             x2, x3
    // 0xdedd14: mov             x3, x16
    // 0xdedd18: r1 = Instance_GregorianCalendarDelegate
    //     0xdedd18: add             x1, PP, #0x28, lsl #12  ; [pp+0x28538] Obj!GregorianCalendarDelegate@129edd1
    //     0xdedd1c: ldr             x1, [x1, #0x538]
    // 0xdedd20: r0 = isSameDay()
    //     0xdedd20: bl              #0xc00af4  ; [package:flutter/src/material/date.dart] CalendarDelegate::isSameDay
    // 0xdedd24: tbnz            w0, #4, #0xdeddc0
    // 0xdedd28: ldur            x0, [fp, #-8]
    // 0xdedd2c: r1 = Null
    //     0xdedd2c: mov             x1, NULL
    // 0xdedd30: r2 = 4
    //     0xdedd30: mov             x2, #4
    // 0xdedd34: r0 = AllocateArray()
    //     0xdedd34: bl              #0x13df928  ; AllocateArrayStub
    // 0xdedd38: mov             x2, x0
    // 0xdedd3c: stur            x2, [fp, #-0x10]
    // 0xdedd40: r16 = ", "
    //     0xdedd40: ldr             x16, [PP, #0xe80]  ; [pp+0xe80] ", "
    // 0xdedd44: StoreField: r2->field_f = r16
    //     0xdedd44: stur            w16, [x2, #0xf]
    // 0xdedd48: ldur            x3, [fp, #-8]
    // 0xdedd4c: LoadField: r0 = r3->field_f
    //     0xdedd4c: ldur            w0, [x3, #0xf]
    // 0xdedd50: DecompressPointer r0
    //     0xdedd50: add             x0, x0, HEAP, lsl #32
    // 0xdedd54: LoadField: r1 = r0->field_2f
    //     0xdedd54: ldur            w1, [x0, #0x2f]
    // 0xdedd58: DecompressPointer r1
    //     0xdedd58: add             x1, x1, HEAP, lsl #32
    // 0xdedd5c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdedd60: cmp             w1, w16
    // 0xdedd64: b.eq            #0xdedf70
    // 0xdedd68: r0 = LoadClassIdInstr(r1)
    //     0xdedd68: ldur            x0, [x1, #-1]
    //     0xdedd6c: ubfx            x0, x0, #0xc, #0x14
    // 0xdedd70: r0 = GDT[cid_x0 + 0x16ee9]()
    //     0xdedd70: mov             x17, #0x6ee9
    //     0xdedd74: movk            x17, #1, lsl #16
    //     0xdedd78: add             lr, x0, x17
    //     0xdedd7c: ldr             lr, [x21, lr, lsl #3]
    //     0xdedd80: blr             lr
    // 0xdedd84: ldur            x1, [fp, #-0x10]
    // 0xdedd88: ArrayStore: r1[1] = r0  ; List_4
    //     0xdedd88: add             x25, x1, #0x13
    //     0xdedd8c: str             w0, [x25]
    //     0xdedd90: tbz             w0, #0, #0xdeddac
    //     0xdedd94: ldurb           w16, [x1, #-1]
    //     0xdedd98: ldurb           w17, [x0, #-1]
    //     0xdedd9c: and             x16, x17, x16, lsr #2
    //     0xdedda0: tst             x16, HEAP, lsr #32
    //     0xdedda4: b.eq            #0xdeddac
    //     0xdedda8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdeddac: ldur            x16, [fp, #-0x10]
    // 0xdeddb0: str             x16, [SP]
    // 0xdeddb4: r0 = _interpolate()
    //     0xdeddb4: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xdeddb8: mov             x2, x0
    // 0xdeddbc: b               #0xdeddc4
    // 0xdeddc0: r2 = ""
    //     0xdeddc0: ldr             x2, [PP, #0x900]  ; [pp+0x900] ""
    // 0xdeddc4: ldur            x0, [fp, #-8]
    // 0xdeddc8: stur            x2, [fp, #-0x10]
    // 0xdeddcc: LoadField: r1 = r0->field_f
    //     0xdeddcc: ldur            w1, [x0, #0xf]
    // 0xdeddd0: DecompressPointer r1
    //     0xdeddd0: add             x1, x1, HEAP, lsl #32
    // 0xdeddd4: LoadField: r3 = r1->field_f
    //     0xdeddd4: ldur            w3, [x1, #0xf]
    // 0xdeddd8: DecompressPointer r3
    //     0xdeddd8: add             x3, x3, HEAP, lsl #32
    // 0xdedddc: cmp             w3, NULL
    // 0xdedde0: b.eq            #0xdedf7c
    // 0xdedde4: mov             x1, x3
    // 0xdedde8: r0 = of()
    //     0xdedde8: bl              #0x864fc4  ; [package:flutter/src/widgets/view.dart] View::of
    // 0xdeddec: mov             x3, x0
    // 0xdeddf0: ldur            x2, [fp, #-8]
    // 0xdeddf4: stur            x3, [fp, #-0x18]
    // 0xdeddf8: LoadField: r0 = r2->field_f
    //     0xdeddf8: ldur            w0, [x2, #0xf]
    // 0xdeddfc: DecompressPointer r0
    //     0xdeddfc: add             x0, x0, HEAP, lsl #32
    // 0xdede00: LoadField: r1 = r0->field_2f
    //     0xdede00: ldur            w1, [x0, #0x2f]
    // 0xdede04: DecompressPointer r1
    //     0xdede04: add             x1, x1, HEAP, lsl #32
    // 0xdede08: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdede0c: cmp             w1, w16
    // 0xdede10: b.eq            #0xdedf80
    // 0xdede14: r0 = LoadClassIdInstr(r1)
    //     0xdede14: ldur            x0, [x1, #-1]
    //     0xdede18: ubfx            x0, x0, #0xc, #0x14
    // 0xdede1c: r0 = GDT[cid_x0 + 0x16496]()
    //     0xdede1c: mov             x17, #0x6496
    //     0xdede20: movk            x17, #1, lsl #16
    //     0xdede24: add             lr, x0, x17
    //     0xdede28: ldr             lr, [x21, lr, lsl #3]
    //     0xdede2c: blr             lr
    // 0xdede30: r1 = Null
    //     0xdede30: mov             x1, NULL
    // 0xdede34: r2 = 8
    //     0xdede34: mov             x2, #8
    // 0xdede38: stur            x0, [fp, #-0x20]
    // 0xdede3c: r0 = AllocateArray()
    //     0xdede3c: bl              #0x13df928  ; AllocateArrayStub
    // 0xdede40: mov             x4, x0
    // 0xdede44: ldur            x0, [fp, #-0x20]
    // 0xdede48: stur            x4, [fp, #-0x28]
    // 0xdede4c: StoreField: r4->field_f = r0
    //     0xdede4c: stur            w0, [x4, #0xf]
    // 0xdede50: r16 = " "
    //     0xdede50: ldr             x16, [PP, #0x8f8]  ; [pp+0x8f8] " "
    // 0xdede54: StoreField: r4->field_13 = r16
    //     0xdede54: stur            w16, [x4, #0x13]
    // 0xdede58: ldur            x0, [fp, #-8]
    // 0xdede5c: LoadField: r1 = r0->field_f
    //     0xdede5c: ldur            w1, [x0, #0xf]
    // 0xdede60: DecompressPointer r1
    //     0xdede60: add             x1, x1, HEAP, lsl #32
    // 0xdede64: LoadField: r2 = r1->field_b
    //     0xdede64: ldur            w2, [x1, #0xb]
    // 0xdede68: DecompressPointer r2
    //     0xdede68: add             x2, x2, HEAP, lsl #32
    // 0xdede6c: cmp             w2, NULL
    // 0xdede70: b.eq            #0xdedf8c
    // 0xdede74: LoadField: r2 = r1->field_23
    //     0xdede74: ldur            w2, [x1, #0x23]
    // 0xdede78: DecompressPointer r2
    //     0xdede78: add             x2, x2, HEAP, lsl #32
    // 0xdede7c: cmp             w2, NULL
    // 0xdede80: b.eq            #0xdedf90
    // 0xdede84: LoadField: r3 = r1->field_2f
    //     0xdede84: ldur            w3, [x1, #0x2f]
    // 0xdede88: DecompressPointer r3
    //     0xdede88: add             x3, x3, HEAP, lsl #32
    // 0xdede8c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdede90: cmp             w3, w16
    // 0xdede94: b.eq            #0xdedf94
    // 0xdede98: r1 = Instance_GregorianCalendarDelegate
    //     0xdede98: add             x1, PP, #0x28, lsl #12  ; [pp+0x28538] Obj!GregorianCalendarDelegate@129edd1
    //     0xdede9c: ldr             x1, [x1, #0x538]
    // 0xdedea0: r0 = formatFullDate()
    //     0xdedea0: bl              #0xdedfac  ; [package:flutter/src/material/date.dart] GregorianCalendarDelegate::formatFullDate
    // 0xdedea4: ldur            x1, [fp, #-0x28]
    // 0xdedea8: ArrayStore: r1[2] = r0  ; List_4
    //     0xdedea8: add             x25, x1, #0x17
    //     0xdedeac: str             w0, [x25]
    //     0xdedeb0: tbz             w0, #0, #0xdedecc
    //     0xdedeb4: ldurb           w16, [x1, #-1]
    //     0xdedeb8: ldurb           w17, [x0, #-1]
    //     0xdedebc: and             x16, x17, x16, lsr #2
    //     0xdedec0: tst             x16, HEAP, lsr #32
    //     0xdedec4: b.eq            #0xdedecc
    //     0xdedec8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdedecc: ldur            x1, [fp, #-0x28]
    // 0xdeded0: ldur            x0, [fp, #-0x10]
    // 0xdeded4: ArrayStore: r1[3] = r0  ; List_4
    //     0xdeded4: add             x25, x1, #0x1b
    //     0xdeded8: str             w0, [x25]
    //     0xdededc: tbz             w0, #0, #0xdedef8
    //     0xdedee0: ldurb           w16, [x1, #-1]
    //     0xdedee4: ldurb           w17, [x0, #-1]
    //     0xdedee8: and             x16, x17, x16, lsr #2
    //     0xdedeec: tst             x16, HEAP, lsr #32
    //     0xdedef0: b.eq            #0xdedef8
    //     0xdedef4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdedef8: ldur            x16, [fp, #-0x28]
    // 0xdedefc: str             x16, [SP]
    // 0xdedf00: r0 = _interpolate()
    //     0xdedf00: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xdedf04: mov             x1, x0
    // 0xdedf08: ldur            x0, [fp, #-8]
    // 0xdedf0c: LoadField: r2 = r0->field_f
    //     0xdedf0c: ldur            w2, [x0, #0xf]
    // 0xdedf10: DecompressPointer r2
    //     0xdedf10: add             x2, x2, HEAP, lsl #32
    // 0xdedf14: LoadField: r3 = r2->field_33
    //     0xdedf14: ldur            w3, [x2, #0x33]
    // 0xdedf18: DecompressPointer r3
    //     0xdedf18: add             x3, x3, HEAP, lsl #32
    // 0xdedf1c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdedf20: cmp             w3, w16
    // 0xdedf24: b.eq            #0xdedfa0
    // 0xdedf28: mov             x2, x1
    // 0xdedf2c: ldur            x1, [fp, #-0x18]
    // 0xdedf30: r4 = const [0, 0x3, 0, 0x3, null]
    //     0xdedf30: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0xdedf34: r0 = sendAnnouncement()
    //     0xdedf34: bl              #0xd19630  ; [package:flutter/src/semantics/semantics_service.dart] SemanticsService::sendAnnouncement
    // 0xdedf38: mov             x1, x0
    // 0xdedf3c: r2 = Closure: (Object, StackTrace) => void from Function '_reportAnnouncementError@54260463': static.
    //     0xdedf3c: add             x2, PP, #0xad, lsl #12  ; [pp+0xadf60] Closure: (Object, StackTrace) => void from Function '_reportAnnouncementError@54260463': static. (0x7f2adacd4ff8)
    //     0xdedf40: ldr             x2, [x2, #0xf60]
    // 0xdedf44: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xdedf44: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xdedf48: r0 = catchError()
    //     0xdedf48: bl              #0x1291b1c  ; [dart:async] _Future::catchError
    // 0xdedf4c: r0 = Null
    //     0xdedf4c: mov             x0, NULL
    // 0xdedf50: LeaveFrame
    //     0xdedf50: mov             SP, fp
    //     0xdedf54: ldp             fp, lr, [SP], #0x10
    // 0xdedf58: ret
    //     0xdedf58: ret             
    // 0xdedf5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdedf5c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdedf60: b               #0xdedc50
    // 0xdedf64: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdedf64: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdedf68: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdedf68: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdedf6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdedf6c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdedf70: r9 = _localizations
    //     0xdedf70: add             x9, PP, #0xad, lsl #12  ; [pp+0xadf48] Field <_CalendarDatePickerState@54260463._localizations@54260463>: late (offset: 0x30)
    //     0xdedf74: ldr             x9, [x9, #0xf48]
    // 0xdedf78: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdedf78: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdedf7c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdedf7c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdedf80: r9 = _localizations
    //     0xdedf80: add             x9, PP, #0xad, lsl #12  ; [pp+0xadf48] Field <_CalendarDatePickerState@54260463._localizations@54260463>: late (offset: 0x30)
    //     0xdedf84: ldr             x9, [x9, #0xf48]
    // 0xdedf88: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdedf88: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdedf8c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdedf8c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdedf90: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdedf90: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdedf94: r9 = _localizations
    //     0xdedf94: add             x9, PP, #0xad, lsl #12  ; [pp+0xadf48] Field <_CalendarDatePickerState@54260463._localizations@54260463>: late (offset: 0x30)
    //     0xdedf98: ldr             x9, [x9, #0xf48]
    // 0xdedf9c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdedf9c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdedfa0: r9 = _textDirection
    //     0xdedfa0: add             x9, PP, #0xad, lsl #12  ; [pp+0xadfa8] Field <_CalendarDatePickerState@54260463._textDirection@54260463>: late (offset: 0x34)
    //     0xdedfa4: ldr             x9, [x9, #0xfa8]
    // 0xdedfa8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdedfa8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xdee0c0, size: 0x88
    // 0xdee0c0: EnterFrame
    //     0xdee0c0: stp             fp, lr, [SP, #-0x10]!
    //     0xdee0c4: mov             fp, SP
    // 0xdee0c8: ldr             x0, [fp, #0x10]
    // 0xdee0cc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdee0cc: ldur            w1, [x0, #0x17]
    // 0xdee0d0: DecompressPointer r1
    //     0xdee0d0: add             x1, x1, HEAP, lsl #32
    // 0xdee0d4: CheckStackOverflow
    //     0xdee0d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdee0d8: cmp             SP, x16
    //     0xdee0dc: b.ls            #0xdee134
    // 0xdee0e0: LoadField: r0 = r1->field_f
    //     0xdee0e0: ldur            w0, [x1, #0xf]
    // 0xdee0e4: DecompressPointer r0
    //     0xdee0e4: add             x0, x0, HEAP, lsl #32
    // 0xdee0e8: LoadField: r1 = r0->field_1b
    //     0xdee0e8: ldur            w1, [x0, #0x1b]
    // 0xdee0ec: DecompressPointer r1
    //     0xdee0ec: add             x1, x1, HEAP, lsl #32
    // 0xdee0f0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdee0f4: cmp             w1, w16
    // 0xdee0f8: b.eq            #0xdee13c
    // 0xdee0fc: LoadField: r2 = r1->field_7
    //     0xdee0fc: ldur            x2, [x1, #7]
    // 0xdee100: cmp             x2, #0
    // 0xdee104: b.gt            #0xdee114
    // 0xdee108: r2 = Instance_DatePickerMode
    //     0xdee108: add             x2, PP, #0xad, lsl #12  ; [pp+0xadf50] Obj!DatePickerMode@12c5841
    //     0xdee10c: ldr             x2, [x2, #0xf50]
    // 0xdee110: b               #0xdee11c
    // 0xdee114: r2 = Instance_DatePickerMode
    //     0xdee114: add             x2, PP, #0x28, lsl #12  ; [pp+0x28528] Obj!DatePickerMode@12c5821
    //     0xdee118: ldr             x2, [x2, #0x528]
    // 0xdee11c: mov             x1, x0
    // 0xdee120: r0 = _handleModeChanged()
    //     0xdee120: bl              #0xdee148  ; [package:flutter/src/material/calendar_date_picker.dart] _CalendarDatePickerState::_handleModeChanged
    // 0xdee124: r0 = Null
    //     0xdee124: mov             x0, NULL
    // 0xdee128: LeaveFrame
    //     0xdee128: mov             SP, fp
    //     0xdee12c: ldp             fp, lr, [SP], #0x10
    // 0xdee130: ret
    //     0xdee130: ret             
    // 0xdee134: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdee134: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdee138: b               #0xdee0e0
    // 0xdee13c: r9 = _mode
    //     0xdee13c: add             x9, PP, #0xad, lsl #12  ; [pp+0xadf38] Field <_CalendarDatePickerState@54260463._mode@54260463>: late (offset: 0x1c)
    //     0xdee140: ldr             x9, [x9, #0xf38]
    // 0xdee144: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdee144: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _handleModeChanged(/* No info */) {
    // ** addr: 0xdee148, size: 0x7c
    // 0xdee148: EnterFrame
    //     0xdee148: stp             fp, lr, [SP, #-0x10]!
    //     0xdee14c: mov             fp, SP
    // 0xdee150: AllocStack(0x18)
    //     0xdee150: sub             SP, SP, #0x18
    // 0xdee154: SetupParameters(_CalendarDatePickerState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xdee154: stur            x1, [fp, #-8]
    //     0xdee158: stur            x2, [fp, #-0x10]
    // 0xdee15c: CheckStackOverflow
    //     0xdee15c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdee160: cmp             SP, x16
    //     0xdee164: b.ls            #0xdee1bc
    // 0xdee168: r1 = 2
    //     0xdee168: mov             x1, #2
    // 0xdee16c: r0 = AllocateContext()
    //     0xdee16c: bl              #0x13de838  ; AllocateContextStub
    // 0xdee170: mov             x2, x0
    // 0xdee174: ldur            x0, [fp, #-8]
    // 0xdee178: stur            x2, [fp, #-0x18]
    // 0xdee17c: StoreField: r2->field_f = r0
    //     0xdee17c: stur            w0, [x2, #0xf]
    // 0xdee180: ldur            x1, [fp, #-0x10]
    // 0xdee184: StoreField: r2->field_13 = r1
    //     0xdee184: stur            w1, [x2, #0x13]
    // 0xdee188: mov             x1, x0
    // 0xdee18c: r0 = _vibrate()
    //     0xdee18c: bl              #0xded670  ; [package:flutter/src/material/calendar_date_picker.dart] _CalendarDatePickerState::_vibrate
    // 0xdee190: ldur            x2, [fp, #-0x18]
    // 0xdee194: r1 = Function '<anonymous closure>':.
    //     0xdee194: add             x1, PP, #0xad, lsl #12  ; [pp+0xadf58] AnonymousClosure: (0xdee1c4), in [package:flutter/src/material/calendar_date_picker.dart] _CalendarDatePickerState::_handleModeChanged (0xdee148)
    //     0xdee198: ldr             x1, [x1, #0xf58]
    // 0xdee19c: r0 = AllocateClosure()
    //     0xdee19c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdee1a0: ldur            x1, [fp, #-8]
    // 0xdee1a4: mov             x2, x0
    // 0xdee1a8: r0 = setState()
    //     0xdee1a8: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xdee1ac: r0 = Null
    //     0xdee1ac: mov             x0, NULL
    // 0xdee1b0: LeaveFrame
    //     0xdee1b0: mov             SP, fp
    //     0xdee1b4: ldp             fp, lr, [SP], #0x10
    // 0xdee1b8: ret
    //     0xdee1b8: ret             
    // 0xdee1bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdee1bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdee1c0: b               #0xdee168
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xdee1c4, size: 0x184
    // 0xdee1c4: EnterFrame
    //     0xdee1c4: stp             fp, lr, [SP, #-0x10]!
    //     0xdee1c8: mov             fp, SP
    // 0xdee1cc: AllocStack(0x8)
    //     0xdee1cc: sub             SP, SP, #8
    // 0xdee1d0: SetupParameters([dynamic _ /* r0 */])
    //     0xdee1d0: ldr             x0, [fp, #0x10]
    //     0xdee1d4: ldur            w4, [x0, #0x17]
    //     0xdee1d8: add             x4, x4, HEAP, lsl #32
    //     0xdee1dc: stur            x4, [fp, #-8]
    // 0xdee1e0: CheckStackOverflow
    //     0xdee1e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdee1e4: cmp             SP, x16
    //     0xdee1e8: b.ls            #0xdee31c
    // 0xdee1ec: LoadField: r1 = r4->field_f
    //     0xdee1ec: ldur            w1, [x4, #0xf]
    // 0xdee1f0: DecompressPointer r1
    //     0xdee1f0: add             x1, x1, HEAP, lsl #32
    // 0xdee1f4: LoadField: r2 = r4->field_13
    //     0xdee1f4: ldur            w2, [x4, #0x13]
    // 0xdee1f8: DecompressPointer r2
    //     0xdee1f8: add             x2, x2, HEAP, lsl #32
    // 0xdee1fc: mov             x0, x2
    // 0xdee200: StoreField: r1->field_1b = r0
    //     0xdee200: stur            w0, [x1, #0x1b]
    //     0xdee204: ldurb           w16, [x1, #-1]
    //     0xdee208: ldurb           w17, [x0, #-1]
    //     0xdee20c: and             x16, x17, x16, lsr #2
    //     0xdee210: tst             x16, HEAP, lsr #32
    //     0xdee214: b.eq            #0xdee21c
    //     0xdee218: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdee21c: LoadField: r0 = r1->field_23
    //     0xdee21c: ldur            w0, [x1, #0x23]
    // 0xdee220: DecompressPointer r0
    //     0xdee220: add             x0, x0, HEAP, lsl #32
    // 0xdee224: r3 = LoadClassIdInstr(r0)
    //     0xdee224: ldur            x3, [x0, #-1]
    //     0xdee228: ubfx            x3, x3, #0xc, #0x14
    // 0xdee22c: r17 = 8404
    //     0xdee22c: mov             x17, #0x20d4
    // 0xdee230: cmp             x3, x17
    // 0xdee234: b.ne            #0xdee30c
    // 0xdee238: LoadField: r3 = r2->field_7
    //     0xdee238: ldur            x3, [x2, #7]
    // 0xdee23c: cmp             x3, #0
    // 0xdee240: b.gt            #0xdee280
    // 0xdee244: LoadField: r2 = r1->field_b
    //     0xdee244: ldur            w2, [x1, #0xb]
    // 0xdee248: DecompressPointer r2
    //     0xdee248: add             x2, x2, HEAP, lsl #32
    // 0xdee24c: cmp             w2, NULL
    // 0xdee250: b.eq            #0xdee324
    // 0xdee254: LoadField: r3 = r1->field_2f
    //     0xdee254: ldur            w3, [x1, #0x2f]
    // 0xdee258: DecompressPointer r3
    //     0xdee258: add             x3, x3, HEAP, lsl #32
    // 0xdee25c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdee260: cmp             w3, w16
    // 0xdee264: b.eq            #0xdee328
    // 0xdee268: mov             x2, x0
    // 0xdee26c: r1 = Instance_GregorianCalendarDelegate
    //     0xdee26c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28538] Obj!GregorianCalendarDelegate@129edd1
    //     0xdee270: ldr             x1, [x1, #0x538]
    // 0xdee274: r0 = formatMonthYear()
    //     0xdee274: bl              #0xdecc7c  ; [package:flutter/src/material/date.dart] GregorianCalendarDelegate::formatMonthYear
    // 0xdee278: mov             x2, x0
    // 0xdee27c: b               #0xdee2fc
    // 0xdee280: mov             x2, x4
    // 0xdee284: LoadField: r3 = r1->field_b
    //     0xdee284: ldur            w3, [x1, #0xb]
    // 0xdee288: DecompressPointer r3
    //     0xdee288: add             x3, x3, HEAP, lsl #32
    // 0xdee28c: cmp             w3, NULL
    // 0xdee290: b.eq            #0xdee334
    // 0xdee294: mov             x1, x0
    // 0xdee298: r0 = _parts()
    //     0xdee298: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xdee29c: mov             x2, x0
    // 0xdee2a0: LoadField: r0 = r2->field_b
    //     0xdee2a0: ldur            w0, [x2, #0xb]
    // 0xdee2a4: r1 = LoadInt32Instr(r0)
    //     0xdee2a4: sbfx            x1, x0, #1, #0x1f
    // 0xdee2a8: mov             x0, x1
    // 0xdee2ac: r1 = 8
    //     0xdee2ac: mov             x1, #8
    // 0xdee2b0: cmp             x1, x0
    // 0xdee2b4: b.hs            #0xdee338
    // 0xdee2b8: LoadField: r0 = r2->field_2f
    //     0xdee2b8: ldur            w0, [x2, #0x2f]
    // 0xdee2bc: DecompressPointer r0
    //     0xdee2bc: add             x0, x0, HEAP, lsl #32
    // 0xdee2c0: ldur            x4, [fp, #-8]
    // 0xdee2c4: LoadField: r1 = r4->field_f
    //     0xdee2c4: ldur            w1, [x4, #0xf]
    // 0xdee2c8: DecompressPointer r1
    //     0xdee2c8: add             x1, x1, HEAP, lsl #32
    // 0xdee2cc: LoadField: r3 = r1->field_2f
    //     0xdee2cc: ldur            w3, [x1, #0x2f]
    // 0xdee2d0: DecompressPointer r3
    //     0xdee2d0: add             x3, x3, HEAP, lsl #32
    // 0xdee2d4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdee2d8: cmp             w3, w16
    // 0xdee2dc: b.eq            #0xdee33c
    // 0xdee2e0: r2 = LoadInt32Instr(r0)
    //     0xdee2e0: sbfx            x2, x0, #1, #0x1f
    //     0xdee2e4: tbz             w0, #0, #0xdee2ec
    //     0xdee2e8: ldur            x2, [x0, #7]
    // 0xdee2ec: r1 = Instance_GregorianCalendarDelegate
    //     0xdee2ec: add             x1, PP, #0x28, lsl #12  ; [pp+0x28538] Obj!GregorianCalendarDelegate@129edd1
    //     0xdee2f0: ldr             x1, [x1, #0x538]
    // 0xdee2f4: r0 = formatYear()
    //     0xdee2f4: bl              #0xdee440  ; [package:flutter/src/material/date.dart] CalendarDelegate::formatYear
    // 0xdee2f8: mov             x2, x0
    // 0xdee2fc: ldur            x0, [fp, #-8]
    // 0xdee300: LoadField: r1 = r0->field_f
    //     0xdee300: ldur            w1, [x0, #0xf]
    // 0xdee304: DecompressPointer r1
    //     0xdee304: add             x1, x1, HEAP, lsl #32
    // 0xdee308: r0 = _announce()
    //     0xdee308: bl              #0xdee348  ; [package:flutter/src/material/calendar_date_picker.dart] _CalendarDatePickerState::_announce
    // 0xdee30c: r0 = Null
    //     0xdee30c: mov             x0, NULL
    // 0xdee310: LeaveFrame
    //     0xdee310: mov             SP, fp
    //     0xdee314: ldp             fp, lr, [SP], #0x10
    // 0xdee318: ret
    //     0xdee318: ret             
    // 0xdee31c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdee31c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdee320: b               #0xdee1ec
    // 0xdee324: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdee324: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdee328: r9 = _localizations
    //     0xdee328: add             x9, PP, #0xad, lsl #12  ; [pp+0xadf48] Field <_CalendarDatePickerState@54260463._localizations@54260463>: late (offset: 0x30)
    //     0xdee32c: ldr             x9, [x9, #0xf48]
    // 0xdee330: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdee330: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdee334: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdee334: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdee338: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdee338: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdee33c: r9 = _localizations
    //     0xdee33c: add             x9, PP, #0xad, lsl #12  ; [pp+0xadf48] Field <_CalendarDatePickerState@54260463._localizations@54260463>: late (offset: 0x30)
    //     0xdee340: ldr             x9, [x9, #0xf48]
    // 0xdee344: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdee344: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _announce(/* No info */) {
    // ** addr: 0xdee348, size: 0xf8
    // 0xdee348: EnterFrame
    //     0xdee348: stp             fp, lr, [SP, #-0x10]!
    //     0xdee34c: mov             fp, SP
    // 0xdee350: AllocStack(0x18)
    //     0xdee350: sub             SP, SP, #0x18
    // 0xdee354: SetupParameters(_CalendarDatePickerState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xdee354: mov             x0, x1
    //     0xdee358: stur            x1, [fp, #-8]
    //     0xdee35c: stur            x2, [fp, #-0x10]
    // 0xdee360: CheckStackOverflow
    //     0xdee360: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdee364: cmp             SP, x16
    //     0xdee368: b.ls            #0xdee42c
    // 0xdee36c: LoadField: r1 = r0->field_f
    //     0xdee36c: ldur            w1, [x0, #0xf]
    // 0xdee370: DecompressPointer r1
    //     0xdee370: add             x1, x1, HEAP, lsl #32
    // 0xdee374: cmp             w1, NULL
    // 0xdee378: b.eq            #0xdee434
    // 0xdee37c: r0 = maybeSupportsAnnounceOf()
    //     0xdee37c: bl              #0xd19758  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::maybeSupportsAnnounceOf
    // 0xdee380: cmp             w0, NULL
    // 0xdee384: b.ne            #0xdee390
    // 0xdee388: ldur            x1, [fp, #-8]
    // 0xdee38c: b               #0xdee3fc
    // 0xdee390: tbnz            w0, #4, #0xdee3f8
    // 0xdee394: ldur            x0, [fp, #-8]
    // 0xdee398: LoadField: r1 = r0->field_f
    //     0xdee398: ldur            w1, [x0, #0xf]
    // 0xdee39c: DecompressPointer r1
    //     0xdee39c: add             x1, x1, HEAP, lsl #32
    // 0xdee3a0: cmp             w1, NULL
    // 0xdee3a4: b.eq            #0xdee438
    // 0xdee3a8: r0 = of()
    //     0xdee3a8: bl              #0x864fc4  ; [package:flutter/src/widgets/view.dart] View::of
    // 0xdee3ac: ldur            x1, [fp, #-8]
    // 0xdee3b0: stur            x0, [fp, #-0x18]
    // 0xdee3b4: LoadField: r2 = r1->field_f
    //     0xdee3b4: ldur            w2, [x1, #0xf]
    // 0xdee3b8: DecompressPointer r2
    //     0xdee3b8: add             x2, x2, HEAP, lsl #32
    // 0xdee3bc: cmp             w2, NULL
    // 0xdee3c0: b.eq            #0xdee43c
    // 0xdee3c4: mov             x1, x2
    // 0xdee3c8: r0 = of()
    //     0xdee3c8: bl              #0x87371c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0xdee3cc: ldur            x1, [fp, #-0x18]
    // 0xdee3d0: ldur            x2, [fp, #-0x10]
    // 0xdee3d4: mov             x3, x0
    // 0xdee3d8: r4 = const [0, 0x3, 0, 0x3, null]
    //     0xdee3d8: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0xdee3dc: r0 = sendAnnouncement()
    //     0xdee3dc: bl              #0xd19630  ; [package:flutter/src/semantics/semantics_service.dart] SemanticsService::sendAnnouncement
    // 0xdee3e0: mov             x1, x0
    // 0xdee3e4: r2 = Closure: (Object, StackTrace) => void from Function '_reportAnnouncementError@54260463': static.
    //     0xdee3e4: add             x2, PP, #0xad, lsl #12  ; [pp+0xadf60] Closure: (Object, StackTrace) => void from Function '_reportAnnouncementError@54260463': static. (0x7f2adacd4ff8)
    //     0xdee3e8: ldr             x2, [x2, #0xf60]
    // 0xdee3ec: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xdee3ec: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xdee3f0: r0 = catchError()
    //     0xdee3f0: bl              #0x1291b1c  ; [dart:async] _Future::catchError
    // 0xdee3f4: b               #0xdee41c
    // 0xdee3f8: ldur            x1, [fp, #-8]
    // 0xdee3fc: ldur            x0, [fp, #-0x10]
    // 0xdee400: ArrayStore: r1[0] = r0  ; List_4
    //     0xdee400: stur            w0, [x1, #0x17]
    //     0xdee404: ldurb           w16, [x1, #-1]
    //     0xdee408: ldurb           w17, [x0, #-1]
    //     0xdee40c: and             x16, x17, x16, lsr #2
    //     0xdee410: tst             x16, HEAP, lsr #32
    //     0xdee414: b.eq            #0xdee41c
    //     0xdee418: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdee41c: r0 = Null
    //     0xdee41c: mov             x0, NULL
    // 0xdee420: LeaveFrame
    //     0xdee420: mov             SP, fp
    //     0xdee424: ldp             fp, lr, [SP], #0x10
    // 0xdee428: ret
    //     0xdee428: ret             
    // 0xdee42c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdee42c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdee430: b               #0xdee36c
    // 0xdee434: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdee434: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdee438: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdee438: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdee43c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdee43c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0xef40a0, size: 0x200
    // 0xef40a0: EnterFrame
    //     0xef40a0: stp             fp, lr, [SP, #-0x10]!
    //     0xef40a4: mov             fp, SP
    // 0xef40a8: AllocStack(0x20)
    //     0xef40a8: sub             SP, SP, #0x20
    // 0xef40ac: SetupParameters(_CalendarDatePickerState this /* r1 => r0, fp-0x8 */)
    //     0xef40ac: mov             x0, x1
    //     0xef40b0: stur            x1, [fp, #-8]
    // 0xef40b4: CheckStackOverflow
    //     0xef40b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef40b8: cmp             SP, x16
    //     0xef40bc: b.ls            #0xef4288
    // 0xef40c0: LoadField: r1 = r0->field_f
    //     0xef40c0: ldur            w1, [x0, #0xf]
    // 0xef40c4: DecompressPointer r1
    //     0xef40c4: add             x1, x1, HEAP, lsl #32
    // 0xef40c8: cmp             w1, NULL
    // 0xef40cc: b.eq            #0xef4290
    // 0xef40d0: r0 = of()
    //     0xef40d0: bl              #0xd0bbf8  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0xef40d4: ldur            x2, [fp, #-8]
    // 0xef40d8: StoreField: r2->field_2f = r0
    //     0xef40d8: stur            w0, [x2, #0x2f]
    //     0xef40dc: ldurb           w16, [x2, #-1]
    //     0xef40e0: ldurb           w17, [x0, #-1]
    //     0xef40e4: and             x16, x17, x16, lsr #2
    //     0xef40e8: tst             x16, HEAP, lsr #32
    //     0xef40ec: b.eq            #0xef40f4
    //     0xef40f0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xef40f4: LoadField: r1 = r2->field_f
    //     0xef40f4: ldur            w1, [x2, #0xf]
    // 0xef40f8: DecompressPointer r1
    //     0xef40f8: add             x1, x1, HEAP, lsl #32
    // 0xef40fc: cmp             w1, NULL
    // 0xef4100: b.eq            #0xef4294
    // 0xef4104: r0 = of()
    //     0xef4104: bl              #0x87371c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0xef4108: ldur            x4, [fp, #-8]
    // 0xef410c: StoreField: r4->field_33 = r0
    //     0xef410c: stur            w0, [x4, #0x33]
    //     0xef4110: ldurb           w16, [x4, #-1]
    //     0xef4114: ldurb           w17, [x0, #-1]
    //     0xef4118: and             x16, x17, x16, lsr #2
    //     0xef411c: tst             x16, HEAP, lsr #32
    //     0xef4120: b.eq            #0xef4128
    //     0xef4124: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xef4128: LoadField: r0 = r4->field_13
    //     0xef4128: ldur            w0, [x4, #0x13]
    // 0xef412c: DecompressPointer r0
    //     0xef412c: add             x0, x0, HEAP, lsl #32
    // 0xef4130: tbz             w0, #4, #0xef4278
    // 0xef4134: LoadField: r0 = r4->field_b
    //     0xef4134: ldur            w0, [x4, #0xb]
    // 0xef4138: DecompressPointer r0
    //     0xef4138: add             x0, x0, HEAP, lsl #32
    // 0xef413c: cmp             w0, NULL
    // 0xef4140: b.eq            #0xef4298
    // 0xef4144: LoadField: r1 = r0->field_b
    //     0xef4144: ldur            w1, [x0, #0xb]
    // 0xef4148: DecompressPointer r1
    //     0xef4148: add             x1, x1, HEAP, lsl #32
    // 0xef414c: cmp             w1, NULL
    // 0xef4150: b.eq            #0xef4278
    // 0xef4154: r1 = true
    //     0xef4154: add             x1, NULL, #0x20  ; true
    // 0xef4158: StoreField: r4->field_13 = r1
    //     0xef4158: stur            w1, [x4, #0x13]
    // 0xef415c: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xef415c: ldur            w2, [x0, #0x17]
    // 0xef4160: DecompressPointer r2
    //     0xef4160: add             x2, x2, HEAP, lsl #32
    // 0xef4164: LoadField: r3 = r4->field_23
    //     0xef4164: ldur            w3, [x4, #0x23]
    // 0xef4168: DecompressPointer r3
    //     0xef4168: add             x3, x3, HEAP, lsl #32
    // 0xef416c: r1 = Instance_GregorianCalendarDelegate
    //     0xef416c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28538] Obj!GregorianCalendarDelegate@129edd1
    //     0xef4170: ldr             x1, [x1, #0x538]
    // 0xef4174: r0 = isSameDay()
    //     0xef4174: bl              #0xc00af4  ; [package:flutter/src/material/date.dart] CalendarDelegate::isSameDay
    // 0xef4178: tbnz            w0, #4, #0xef4200
    // 0xef417c: ldur            x0, [fp, #-8]
    // 0xef4180: r1 = Null
    //     0xef4180: mov             x1, NULL
    // 0xef4184: r2 = 4
    //     0xef4184: mov             x2, #4
    // 0xef4188: r0 = AllocateArray()
    //     0xef4188: bl              #0x13df928  ; AllocateArrayStub
    // 0xef418c: mov             x2, x0
    // 0xef4190: stur            x2, [fp, #-0x10]
    // 0xef4194: r16 = ", "
    //     0xef4194: ldr             x16, [PP, #0xe80]  ; [pp+0xe80] ", "
    // 0xef4198: StoreField: r2->field_f = r16
    //     0xef4198: stur            w16, [x2, #0xf]
    // 0xef419c: ldur            x3, [fp, #-8]
    // 0xef41a0: LoadField: r1 = r3->field_2f
    //     0xef41a0: ldur            w1, [x3, #0x2f]
    // 0xef41a4: DecompressPointer r1
    //     0xef41a4: add             x1, x1, HEAP, lsl #32
    // 0xef41a8: r0 = LoadClassIdInstr(r1)
    //     0xef41a8: ldur            x0, [x1, #-1]
    //     0xef41ac: ubfx            x0, x0, #0xc, #0x14
    // 0xef41b0: r0 = GDT[cid_x0 + 0x16ee9]()
    //     0xef41b0: mov             x17, #0x6ee9
    //     0xef41b4: movk            x17, #1, lsl #16
    //     0xef41b8: add             lr, x0, x17
    //     0xef41bc: ldr             lr, [x21, lr, lsl #3]
    //     0xef41c0: blr             lr
    // 0xef41c4: ldur            x1, [fp, #-0x10]
    // 0xef41c8: ArrayStore: r1[1] = r0  ; List_4
    //     0xef41c8: add             x25, x1, #0x13
    //     0xef41cc: str             w0, [x25]
    //     0xef41d0: tbz             w0, #0, #0xef41ec
    //     0xef41d4: ldurb           w16, [x1, #-1]
    //     0xef41d8: ldurb           w17, [x0, #-1]
    //     0xef41dc: and             x16, x17, x16, lsr #2
    //     0xef41e0: tst             x16, HEAP, lsr #32
    //     0xef41e4: b.eq            #0xef41ec
    //     0xef41e8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xef41ec: ldur            x16, [fp, #-0x10]
    // 0xef41f0: str             x16, [SP]
    // 0xef41f4: r0 = _interpolate()
    //     0xef41f4: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xef41f8: mov             x4, x0
    // 0xef41fc: b               #0xef4204
    // 0xef4200: r4 = ""
    //     0xef4200: ldr             x4, [PP, #0x900]  ; [pp+0x900] ""
    // 0xef4204: ldur            x3, [fp, #-8]
    // 0xef4208: stur            x4, [fp, #-0x10]
    // 0xef420c: LoadField: r1 = r3->field_2f
    //     0xef420c: ldur            w1, [x3, #0x2f]
    // 0xef4210: DecompressPointer r1
    //     0xef4210: add             x1, x1, HEAP, lsl #32
    // 0xef4214: LoadField: r2 = r3->field_23
    //     0xef4214: ldur            w2, [x3, #0x23]
    // 0xef4218: DecompressPointer r2
    //     0xef4218: add             x2, x2, HEAP, lsl #32
    // 0xef421c: cmp             w2, NULL
    // 0xef4220: b.eq            #0xef429c
    // 0xef4224: r0 = LoadClassIdInstr(r1)
    //     0xef4224: ldur            x0, [x1, #-1]
    //     0xef4228: ubfx            x0, x0, #0xc, #0x14
    // 0xef422c: r0 = GDT[cid_x0 + 0x15945]()
    //     0xef422c: mov             x17, #0x5945
    //     0xef4230: movk            x17, #1, lsl #16
    //     0xef4234: add             lr, x0, x17
    //     0xef4238: ldr             lr, [x21, lr, lsl #3]
    //     0xef423c: blr             lr
    // 0xef4240: r1 = Null
    //     0xef4240: mov             x1, NULL
    // 0xef4244: r2 = 4
    //     0xef4244: mov             x2, #4
    // 0xef4248: stur            x0, [fp, #-0x18]
    // 0xef424c: r0 = AllocateArray()
    //     0xef424c: bl              #0x13df928  ; AllocateArrayStub
    // 0xef4250: mov             x1, x0
    // 0xef4254: ldur            x0, [fp, #-0x18]
    // 0xef4258: StoreField: r1->field_f = r0
    //     0xef4258: stur            w0, [x1, #0xf]
    // 0xef425c: ldur            x0, [fp, #-0x10]
    // 0xef4260: StoreField: r1->field_13 = r0
    //     0xef4260: stur            w0, [x1, #0x13]
    // 0xef4264: str             x1, [SP]
    // 0xef4268: r0 = _interpolate()
    //     0xef4268: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xef426c: ldur            x1, [fp, #-8]
    // 0xef4270: mov             x2, x0
    // 0xef4274: r0 = _announce()
    //     0xef4274: bl              #0xdee348  ; [package:flutter/src/material/calendar_date_picker.dart] _CalendarDatePickerState::_announce
    // 0xef4278: r0 = Null
    //     0xef4278: mov             x0, NULL
    // 0xef427c: LeaveFrame
    //     0xef427c: mov             SP, fp
    //     0xef4280: ldp             fp, lr, [SP], #0x10
    // 0xef4284: ret
    //     0xef4284: ret             
    // 0xef4288: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef4288: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef428c: b               #0xef40c0
    // 0xef4290: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef4290: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef4294: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef4294: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef4298: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef4298: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef429c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef429c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0xf8f904, size: 0x160
    // 0xf8f904: EnterFrame
    //     0xf8f904: stp             fp, lr, [SP, #-0x10]!
    //     0xf8f908: mov             fp, SP
    // 0xf8f90c: AllocStack(0x18)
    //     0xf8f90c: sub             SP, SP, #0x18
    // 0xf8f910: r0 = Instance_DatePickerMode
    //     0xf8f910: add             x0, PP, #0x28, lsl #12  ; [pp+0x28528] Obj!DatePickerMode@12c5821
    //     0xf8f914: ldr             x0, [x0, #0x528]
    // 0xf8f918: mov             x2, x1
    // 0xf8f91c: stur            x1, [fp, #-0x10]
    // 0xf8f920: CheckStackOverflow
    //     0xf8f920: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf8f924: cmp             SP, x16
    //     0xf8f928: b.ls            #0xf8fa4c
    // 0xf8f92c: LoadField: r1 = r2->field_b
    //     0xf8f92c: ldur            w1, [x2, #0xb]
    // 0xf8f930: DecompressPointer r1
    //     0xf8f930: add             x1, x1, HEAP, lsl #32
    // 0xf8f934: cmp             w1, NULL
    // 0xf8f938: b.eq            #0xf8fa54
    // 0xf8f93c: StoreField: r2->field_1b = r0
    //     0xf8f93c: stur            w0, [x2, #0x1b]
    // 0xf8f940: LoadField: r0 = r1->field_b
    //     0xf8f940: ldur            w0, [x1, #0xb]
    // 0xf8f944: DecompressPointer r0
    //     0xf8f944: add             x0, x0, HEAP, lsl #32
    // 0xf8f948: cmp             w0, NULL
    // 0xf8f94c: b.ne            #0xf8f958
    // 0xf8f950: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xf8f950: ldur            w0, [x1, #0x17]
    // 0xf8f954: DecompressPointer r0
    //     0xf8f954: add             x0, x0, HEAP, lsl #32
    // 0xf8f958: mov             x1, x0
    // 0xf8f95c: stur            x0, [fp, #-8]
    // 0xf8f960: r0 = _parts()
    //     0xf8f960: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xf8f964: mov             x2, x0
    // 0xf8f968: LoadField: r0 = r2->field_b
    //     0xf8f968: ldur            w0, [x2, #0xb]
    // 0xf8f96c: r1 = LoadInt32Instr(r0)
    //     0xf8f96c: sbfx            x1, x0, #1, #0x1f
    // 0xf8f970: mov             x0, x1
    // 0xf8f974: r1 = 8
    //     0xf8f974: mov             x1, #8
    // 0xf8f978: cmp             x1, x0
    // 0xf8f97c: b.hs            #0xf8fa58
    // 0xf8f980: LoadField: r0 = r2->field_2f
    //     0xf8f980: ldur            w0, [x2, #0x2f]
    // 0xf8f984: DecompressPointer r0
    //     0xf8f984: add             x0, x0, HEAP, lsl #32
    // 0xf8f988: ldur            x1, [fp, #-8]
    // 0xf8f98c: stur            x0, [fp, #-0x18]
    // 0xf8f990: r0 = _parts()
    //     0xf8f990: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xf8f994: mov             x2, x0
    // 0xf8f998: LoadField: r0 = r2->field_b
    //     0xf8f998: ldur            w0, [x2, #0xb]
    // 0xf8f99c: r1 = LoadInt32Instr(r0)
    //     0xf8f99c: sbfx            x1, x0, #1, #0x1f
    // 0xf8f9a0: mov             x0, x1
    // 0xf8f9a4: r1 = 7
    //     0xf8f9a4: mov             x1, #7
    // 0xf8f9a8: cmp             x1, x0
    // 0xf8f9ac: b.hs            #0xf8fa5c
    // 0xf8f9b0: LoadField: r0 = r2->field_2b
    //     0xf8f9b0: ldur            w0, [x2, #0x2b]
    // 0xf8f9b4: DecompressPointer r0
    //     0xf8f9b4: add             x0, x0, HEAP, lsl #32
    // 0xf8f9b8: ldur            x1, [fp, #-0x18]
    // 0xf8f9bc: r2 = LoadInt32Instr(r1)
    //     0xf8f9bc: sbfx            x2, x1, #1, #0x1f
    //     0xf8f9c0: tbz             w1, #0, #0xf8f9c8
    //     0xf8f9c4: ldur            x2, [x1, #7]
    // 0xf8f9c8: r3 = LoadInt32Instr(r0)
    //     0xf8f9c8: sbfx            x3, x0, #1, #0x1f
    //     0xf8f9cc: tbz             w0, #0, #0xf8f9d4
    //     0xf8f9d0: ldur            x3, [x0, #7]
    // 0xf8f9d4: r1 = Instance_GregorianCalendarDelegate
    //     0xf8f9d4: add             x1, PP, #0x28, lsl #12  ; [pp+0x28538] Obj!GregorianCalendarDelegate@129edd1
    //     0xf8f9d8: ldr             x1, [x1, #0x538]
    // 0xf8f9dc: r0 = getMonth()
    //     0xf8f9dc: bl              #0xdedac8  ; [package:flutter/src/material/date.dart] GregorianCalendarDelegate::getMonth
    // 0xf8f9e0: ldur            x1, [fp, #-0x10]
    // 0xf8f9e4: StoreField: r1->field_1f = r0
    //     0xf8f9e4: stur            w0, [x1, #0x1f]
    //     0xf8f9e8: ldurb           w16, [x1, #-1]
    //     0xf8f9ec: ldurb           w17, [x0, #-1]
    //     0xf8f9f0: and             x16, x17, x16, lsr #2
    //     0xf8f9f4: tst             x16, HEAP, lsr #32
    //     0xf8f9f8: b.eq            #0xf8fa00
    //     0xf8f9fc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf8fa00: LoadField: r2 = r1->field_b
    //     0xf8fa00: ldur            w2, [x1, #0xb]
    // 0xf8fa04: DecompressPointer r2
    //     0xf8fa04: add             x2, x2, HEAP, lsl #32
    // 0xf8fa08: cmp             w2, NULL
    // 0xf8fa0c: b.eq            #0xf8fa60
    // 0xf8fa10: LoadField: r0 = r2->field_b
    //     0xf8fa10: ldur            w0, [x2, #0xb]
    // 0xf8fa14: DecompressPointer r0
    //     0xf8fa14: add             x0, x0, HEAP, lsl #32
    // 0xf8fa18: cmp             w0, NULL
    // 0xf8fa1c: b.eq            #0xf8fa3c
    // 0xf8fa20: StoreField: r1->field_23 = r0
    //     0xf8fa20: stur            w0, [x1, #0x23]
    //     0xf8fa24: ldurb           w16, [x1, #-1]
    //     0xf8fa28: ldurb           w17, [x0, #-1]
    //     0xf8fa2c: and             x16, x17, x16, lsr #2
    //     0xf8fa30: tst             x16, HEAP, lsr #32
    //     0xf8fa34: b.eq            #0xf8fa3c
    //     0xf8fa38: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf8fa3c: r0 = Null
    //     0xf8fa3c: mov             x0, NULL
    // 0xf8fa40: LeaveFrame
    //     0xf8fa40: mov             SP, fp
    //     0xf8fa44: ldp             fp, lr, [SP], #0x10
    // 0xf8fa48: ret
    //     0xf8fa48: ret             
    // 0xf8fa4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf8fa4c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf8fa50: b               #0xf8f92c
    // 0xf8fa54: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf8fa54: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf8fa58: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xf8fa58: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xf8fa5c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xf8fa5c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xf8fa60: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf8fa60: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _CalendarDatePickerState(/* No info */) {
    // ** addr: 0xfa0ec0, size: 0x98
    // 0xfa0ec0: EnterFrame
    //     0xfa0ec0: stp             fp, lr, [SP, #-0x10]!
    //     0xfa0ec4: mov             fp, SP
    // 0xfa0ec8: AllocStack(0x8)
    //     0xfa0ec8: sub             SP, SP, #8
    // 0xfa0ecc: r3 = false
    //     0xfa0ecc: add             x3, NULL, #0x30  ; false
    // 0xfa0ed0: r2 = ""
    //     0xfa0ed0: ldr             x2, [PP, #0x900]  ; [pp+0x900] ""
    // 0xfa0ed4: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa0ed8: mov             x4, x1
    // 0xfa0edc: stur            x1, [fp, #-8]
    // 0xfa0ee0: StoreField: r4->field_13 = r3
    //     0xfa0ee0: stur            w3, [x4, #0x13]
    // 0xfa0ee4: ArrayStore: r4[0] = r2  ; List_4
    //     0xfa0ee4: stur            w2, [x4, #0x17]
    // 0xfa0ee8: StoreField: r4->field_1b = r0
    //     0xfa0ee8: stur            w0, [x4, #0x1b]
    // 0xfa0eec: StoreField: r4->field_1f = r0
    //     0xfa0eec: stur            w0, [x4, #0x1f]
    // 0xfa0ef0: StoreField: r4->field_2f = r0
    //     0xfa0ef0: stur            w0, [x4, #0x2f]
    // 0xfa0ef4: StoreField: r4->field_33 = r0
    //     0xfa0ef4: stur            w0, [x4, #0x33]
    // 0xfa0ef8: r1 = <State<StatefulWidget>>
    //     0xfa0ef8: ldr             x1, [PP, #0x4df8]  ; [pp+0x4df8] TypeArguments: <State<StatefulWidget>>
    // 0xfa0efc: r0 = LabeledGlobalKey()
    //     0xfa0efc: bl              #0x856cf8  ; AllocateLabeledGlobalKeyStub -> LabeledGlobalKey<X0 bound State> (size=0x10)
    // 0xfa0f00: ldur            x2, [fp, #-8]
    // 0xfa0f04: StoreField: r2->field_27 = r0
    //     0xfa0f04: stur            w0, [x2, #0x27]
    //     0xfa0f08: ldurb           w16, [x2, #-1]
    //     0xfa0f0c: ldurb           w17, [x0, #-1]
    //     0xfa0f10: and             x16, x17, x16, lsr #2
    //     0xfa0f14: tst             x16, HEAP, lsr #32
    //     0xfa0f18: b.eq            #0xfa0f20
    //     0xfa0f1c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xfa0f20: r1 = <State<StatefulWidget>>
    //     0xfa0f20: ldr             x1, [PP, #0x4df8]  ; [pp+0x4df8] TypeArguments: <State<StatefulWidget>>
    // 0xfa0f24: r0 = LabeledGlobalKey()
    //     0xfa0f24: bl              #0x856cf8  ; AllocateLabeledGlobalKeyStub -> LabeledGlobalKey<X0 bound State> (size=0x10)
    // 0xfa0f28: ldur            x1, [fp, #-8]
    // 0xfa0f2c: StoreField: r1->field_2b = r0
    //     0xfa0f2c: stur            w0, [x1, #0x2b]
    //     0xfa0f30: ldurb           w16, [x1, #-1]
    //     0xfa0f34: ldurb           w17, [x0, #-1]
    //     0xfa0f38: and             x16, x17, x16, lsr #2
    //     0xfa0f3c: tst             x16, HEAP, lsr #32
    //     0xfa0f40: b.eq            #0xfa0f48
    //     0xfa0f44: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfa0f48: r0 = Null
    //     0xfa0f48: mov             x0, NULL
    // 0xfa0f4c: LeaveFrame
    //     0xfa0f4c: mov             SP, fp
    //     0xfa0f50: ldp             fp, lr, [SP], #0x10
    // 0xfa0f54: ret
    //     0xfa0f54: ret             
  }
}

// class id: 5773, size: 0x20, field offset: 0x1c
class _DatePickerModeToggleButtonState extends _MixinApplication18&State&SingleTickerProviderStateMixin {

  late AnimationController _controller; // offset: 0x1c

  _ build(/* No info */) {
    // ** addr: 0xd0f4f0, size: 0x860
    // 0xd0f4f0: EnterFrame
    //     0xd0f4f0: stp             fp, lr, [SP, #-0x10]!
    //     0xd0f4f4: mov             fp, SP
    // 0xd0f4f8: AllocStack(0x60)
    //     0xd0f4f8: sub             SP, SP, #0x60
    // 0xd0f4fc: SetupParameters(_DatePickerModeToggleButtonState this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xd0f4fc: mov             x0, x2
    //     0xd0f500: stur            x2, [fp, #-0x10]
    //     0xd0f504: mov             x2, x1
    //     0xd0f508: stur            x1, [fp, #-8]
    // 0xd0f50c: CheckStackOverflow
    //     0xd0f50c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0f510: cmp             SP, x16
    //     0xd0f514: b.ls            #0xd0fd34
    // 0xd0f518: mov             x1, x0
    // 0xd0f51c: r0 = of()
    //     0xd0f51c: bl              #0xd0ff6c  ; [package:flutter/src/material/date_picker_theme.dart] DatePickerTheme::of
    // 0xd0f520: ldur            x1, [fp, #-0x10]
    // 0xd0f524: r0 = defaults()
    //     0xd0f524: bl              #0xd0fd74  ; [package:flutter/src/material/date_picker_theme.dart] DatePickerTheme::defaults
    // 0xd0f528: stur            x0, [fp, #-0x20]
    // 0xd0f52c: r2 = LoadClassIdInstr(r0)
    //     0xd0f52c: ldur            x2, [x0, #-1]
    //     0xd0f530: ubfx            x2, x2, #0xc, #0x14
    // 0xd0f534: stur            x2, [fp, #-0x18]
    // 0xd0f538: r17 = 5167
    //     0xd0f538: mov             x17, #0x142f
    // 0xd0f53c: cmp             x2, x17
    // 0xd0f540: b.ne            #0xd0f558
    // 0xd0f544: LoadField: r1 = r0->field_a3
    //     0xd0f544: ldur            w1, [x0, #0xa3]
    // 0xd0f548: DecompressPointer r1
    //     0xd0f548: add             x1, x1, HEAP, lsl #32
    // 0xd0f54c: mov             x0, x2
    // 0xd0f550: mov             x2, x1
    // 0xd0f554: b               #0xd0f6a8
    // 0xd0f558: r17 = 5168
    //     0xd0f558: mov             x17, #0x1430
    // 0xd0f55c: cmp             x2, x17
    // 0xd0f560: b.ne            #0xd0f608
    // 0xd0f564: mov             x1, x0
    // 0xd0f568: LoadField: r0 = r1->field_b7
    //     0xd0f568: ldur            w0, [x1, #0xb7]
    // 0xd0f56c: DecompressPointer r0
    //     0xd0f56c: add             x0, x0, HEAP, lsl #32
    // 0xd0f570: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd0f574: cmp             w0, w16
    // 0xd0f578: b.ne            #0xd0f588
    // 0xd0f57c: r2 = _textTheme
    //     0xd0f57c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26418] Field <_DatePickerDefaultsM3@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0xd0f580: ldr             x2, [x2, #0x418]
    // 0xd0f584: r0 = InitLateFinalInstanceField()
    //     0xd0f584: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd0f588: LoadField: r2 = r0->field_27
    //     0xd0f588: ldur            w2, [x0, #0x27]
    // 0xd0f58c: DecompressPointer r2
    //     0xd0f58c: add             x2, x2, HEAP, lsl #32
    // 0xd0f590: stur            x2, [fp, #-0x28]
    // 0xd0f594: cmp             w2, NULL
    // 0xd0f598: b.ne            #0xd0f5a4
    // 0xd0f59c: r0 = Null
    //     0xd0f59c: mov             x0, NULL
    // 0xd0f5a0: b               #0xd0f5fc
    // 0xd0f5a4: ldur            x1, [fp, #-0x20]
    // 0xd0f5a8: LoadField: r0 = r1->field_b3
    //     0xd0f5a8: ldur            w0, [x1, #0xb3]
    // 0xd0f5ac: DecompressPointer r0
    //     0xd0f5ac: add             x0, x0, HEAP, lsl #32
    // 0xd0f5b0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd0f5b4: cmp             w0, w16
    // 0xd0f5b8: b.ne            #0xd0f5c8
    // 0xd0f5bc: r2 = _colors
    //     0xd0f5bc: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xd0f5c0: ldr             x2, [x2, #0x400]
    // 0xd0f5c4: r0 = InitLateFinalInstanceField()
    //     0xd0f5c4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd0f5c8: LoadField: r1 = r0->field_7f
    //     0xd0f5c8: ldur            w1, [x0, #0x7f]
    // 0xd0f5cc: DecompressPointer r1
    //     0xd0f5cc: add             x1, x1, HEAP, lsl #32
    // 0xd0f5d0: r0 = LoadClassIdInstr(r1)
    //     0xd0f5d0: ldur            x0, [x1, #-1]
    //     0xd0f5d4: ubfx            x0, x0, #0xc, #0x14
    // 0xd0f5d8: d0 = 0.600000
    //     0xd0f5d8: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c88] IMM: double(0.6) from 0x3fe3333333333333
    //     0xd0f5dc: ldr             d0, [x17, #0xc88]
    // 0xd0f5e0: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd0f5e0: sub             lr, x0, #1, lsl #12
    //     0xd0f5e4: ldr             lr, [x21, lr, lsl #3]
    //     0xd0f5e8: blr             lr
    // 0xd0f5ec: ldur            x1, [fp, #-0x28]
    // 0xd0f5f0: mov             x2, x0
    // 0xd0f5f4: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xd0f5f4: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xd0f5f8: r0 = apply()
    //     0xd0f5f8: bl              #0x8acf20  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0xd0f5fc: mov             x2, x0
    // 0xd0f600: ldur            x0, [fp, #-0x18]
    // 0xd0f604: b               #0xd0f6a8
    // 0xd0f608: ldur            x1, [fp, #-0x20]
    // 0xd0f60c: LoadField: r0 = r1->field_b7
    //     0xd0f60c: ldur            w0, [x1, #0xb7]
    // 0xd0f610: DecompressPointer r0
    //     0xd0f610: add             x0, x0, HEAP, lsl #32
    // 0xd0f614: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd0f618: cmp             w0, w16
    // 0xd0f61c: b.ne            #0xd0f62c
    // 0xd0f620: r2 = _textTheme
    //     0xd0f620: add             x2, PP, #0x26, lsl #12  ; [pp+0x26420] Field <_DatePickerDefaultsM2@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0xd0f624: ldr             x2, [x2, #0x420]
    // 0xd0f628: r0 = InitLateFinalInstanceField()
    //     0xd0f628: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd0f62c: LoadField: r2 = r0->field_27
    //     0xd0f62c: ldur            w2, [x0, #0x27]
    // 0xd0f630: DecompressPointer r2
    //     0xd0f630: add             x2, x2, HEAP, lsl #32
    // 0xd0f634: stur            x2, [fp, #-0x28]
    // 0xd0f638: cmp             w2, NULL
    // 0xd0f63c: b.ne            #0xd0f648
    // 0xd0f640: r0 = Null
    //     0xd0f640: mov             x0, NULL
    // 0xd0f644: b               #0xd0f6a0
    // 0xd0f648: ldur            x1, [fp, #-0x20]
    // 0xd0f64c: LoadField: r0 = r1->field_b3
    //     0xd0f64c: ldur            w0, [x1, #0xb3]
    // 0xd0f650: DecompressPointer r0
    //     0xd0f650: add             x0, x0, HEAP, lsl #32
    // 0xd0f654: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd0f658: cmp             w0, w16
    // 0xd0f65c: b.ne            #0xd0f66c
    // 0xd0f660: r2 = _colors
    //     0xd0f660: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xd0f664: ldr             x2, [x2, #0x410]
    // 0xd0f668: r0 = InitLateFinalInstanceField()
    //     0xd0f668: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd0f66c: LoadField: r1 = r0->field_7f
    //     0xd0f66c: ldur            w1, [x0, #0x7f]
    // 0xd0f670: DecompressPointer r1
    //     0xd0f670: add             x1, x1, HEAP, lsl #32
    // 0xd0f674: r0 = LoadClassIdInstr(r1)
    //     0xd0f674: ldur            x0, [x1, #-1]
    //     0xd0f678: ubfx            x0, x0, #0xc, #0x14
    // 0xd0f67c: d0 = 0.600000
    //     0xd0f67c: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c88] IMM: double(0.6) from 0x3fe3333333333333
    //     0xd0f680: ldr             d0, [x17, #0xc88]
    // 0xd0f684: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd0f684: sub             lr, x0, #1, lsl #12
    //     0xd0f688: ldr             lr, [x21, lr, lsl #3]
    //     0xd0f68c: blr             lr
    // 0xd0f690: ldur            x1, [fp, #-0x28]
    // 0xd0f694: mov             x2, x0
    // 0xd0f698: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xd0f698: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xd0f69c: r0 = apply()
    //     0xd0f69c: bl              #0x8acf20  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0xd0f6a0: mov             x2, x0
    // 0xd0f6a4: ldur            x0, [fp, #-0x18]
    // 0xd0f6a8: stur            x2, [fp, #-0x28]
    // 0xd0f6ac: r17 = 5167
    //     0xd0f6ac: mov             x17, #0x142f
    // 0xd0f6b0: cmp             x0, x17
    // 0xd0f6b4: b.ne            #0xd0f6cc
    // 0xd0f6b8: ldur            x3, [fp, #-0x20]
    // 0xd0f6bc: LoadField: r1 = r3->field_a7
    //     0xd0f6bc: ldur            w1, [x3, #0xa7]
    // 0xd0f6c0: DecompressPointer r1
    //     0xd0f6c0: add             x1, x1, HEAP, lsl #32
    // 0xd0f6c4: mov             x2, x1
    // 0xd0f6c8: b               #0xd0f780
    // 0xd0f6cc: ldur            x3, [fp, #-0x20]
    // 0xd0f6d0: r17 = 5168
    //     0xd0f6d0: mov             x17, #0x1430
    // 0xd0f6d4: cmp             x0, x17
    // 0xd0f6d8: b.ne            #0xd0f730
    // 0xd0f6dc: mov             x1, x3
    // 0xd0f6e0: LoadField: r0 = r1->field_b3
    //     0xd0f6e0: ldur            w0, [x1, #0xb3]
    // 0xd0f6e4: DecompressPointer r0
    //     0xd0f6e4: add             x0, x0, HEAP, lsl #32
    // 0xd0f6e8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd0f6ec: cmp             w0, w16
    // 0xd0f6f0: b.ne            #0xd0f700
    // 0xd0f6f4: r2 = _colors
    //     0xd0f6f4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xd0f6f8: ldr             x2, [x2, #0x400]
    // 0xd0f6fc: r0 = InitLateFinalInstanceField()
    //     0xd0f6fc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd0f700: LoadField: r1 = r0->field_7f
    //     0xd0f700: ldur            w1, [x0, #0x7f]
    // 0xd0f704: DecompressPointer r1
    //     0xd0f704: add             x1, x1, HEAP, lsl #32
    // 0xd0f708: r0 = LoadClassIdInstr(r1)
    //     0xd0f708: ldur            x0, [x1, #-1]
    //     0xd0f70c: ubfx            x0, x0, #0xc, #0x14
    // 0xd0f710: d0 = 0.600000
    //     0xd0f710: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c88] IMM: double(0.6) from 0x3fe3333333333333
    //     0xd0f714: ldr             d0, [x17, #0xc88]
    // 0xd0f718: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd0f718: sub             lr, x0, #1, lsl #12
    //     0xd0f71c: ldr             lr, [x21, lr, lsl #3]
    //     0xd0f720: blr             lr
    // 0xd0f724: mov             x2, x0
    // 0xd0f728: ldur            x0, [fp, #-0x18]
    // 0xd0f72c: b               #0xd0f780
    // 0xd0f730: ldur            x1, [fp, #-0x20]
    // 0xd0f734: LoadField: r0 = r1->field_b3
    //     0xd0f734: ldur            w0, [x1, #0xb3]
    // 0xd0f738: DecompressPointer r0
    //     0xd0f738: add             x0, x0, HEAP, lsl #32
    // 0xd0f73c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd0f740: cmp             w0, w16
    // 0xd0f744: b.ne            #0xd0f754
    // 0xd0f748: r2 = _colors
    //     0xd0f748: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xd0f74c: ldr             x2, [x2, #0x410]
    // 0xd0f750: r0 = InitLateFinalInstanceField()
    //     0xd0f750: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd0f754: LoadField: r1 = r0->field_7f
    //     0xd0f754: ldur            w1, [x0, #0x7f]
    // 0xd0f758: DecompressPointer r1
    //     0xd0f758: add             x1, x1, HEAP, lsl #32
    // 0xd0f75c: r0 = LoadClassIdInstr(r1)
    //     0xd0f75c: ldur            x0, [x1, #-1]
    //     0xd0f760: ubfx            x0, x0, #0xc, #0x14
    // 0xd0f764: d0 = 0.600000
    //     0xd0f764: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c88] IMM: double(0.6) from 0x3fe3333333333333
    //     0xd0f768: ldr             d0, [x17, #0xc88]
    // 0xd0f76c: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd0f76c: sub             lr, x0, #1, lsl #12
    //     0xd0f770: ldr             lr, [x21, lr, lsl #3]
    //     0xd0f774: blr             lr
    // 0xd0f778: mov             x2, x0
    // 0xd0f77c: ldur            x0, [fp, #-0x18]
    // 0xd0f780: stur            x2, [fp, #-0x30]
    // 0xd0f784: r17 = 5167
    //     0xd0f784: mov             x17, #0x142f
    // 0xd0f788: cmp             x0, x17
    // 0xd0f78c: b.ne            #0xd0f7a0
    // 0xd0f790: ldur            x3, [fp, #-0x20]
    // 0xd0f794: LoadField: r0 = r3->field_a3
    //     0xd0f794: ldur            w0, [x3, #0xa3]
    // 0xd0f798: DecompressPointer r0
    //     0xd0f798: add             x0, x0, HEAP, lsl #32
    // 0xd0f79c: b               #0xd0f8e4
    // 0xd0f7a0: ldur            x3, [fp, #-0x20]
    // 0xd0f7a4: r17 = 5168
    //     0xd0f7a4: mov             x17, #0x1430
    // 0xd0f7a8: cmp             x0, x17
    // 0xd0f7ac: b.ne            #0xd0f84c
    // 0xd0f7b0: mov             x1, x3
    // 0xd0f7b4: LoadField: r0 = r1->field_b7
    //     0xd0f7b4: ldur            w0, [x1, #0xb7]
    // 0xd0f7b8: DecompressPointer r0
    //     0xd0f7b8: add             x0, x0, HEAP, lsl #32
    // 0xd0f7bc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd0f7c0: cmp             w0, w16
    // 0xd0f7c4: b.ne            #0xd0f7d4
    // 0xd0f7c8: r2 = _textTheme
    //     0xd0f7c8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26418] Field <_DatePickerDefaultsM3@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0xd0f7cc: ldr             x2, [x2, #0x418]
    // 0xd0f7d0: r0 = InitLateFinalInstanceField()
    //     0xd0f7d0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd0f7d4: LoadField: r2 = r0->field_27
    //     0xd0f7d4: ldur            w2, [x0, #0x27]
    // 0xd0f7d8: DecompressPointer r2
    //     0xd0f7d8: add             x2, x2, HEAP, lsl #32
    // 0xd0f7dc: stur            x2, [fp, #-0x38]
    // 0xd0f7e0: cmp             w2, NULL
    // 0xd0f7e4: b.ne            #0xd0f7f0
    // 0xd0f7e8: r0 = Null
    //     0xd0f7e8: mov             x0, NULL
    // 0xd0f7ec: b               #0xd0f8e4
    // 0xd0f7f0: ldur            x1, [fp, #-0x20]
    // 0xd0f7f4: LoadField: r0 = r1->field_b3
    //     0xd0f7f4: ldur            w0, [x1, #0xb3]
    // 0xd0f7f8: DecompressPointer r0
    //     0xd0f7f8: add             x0, x0, HEAP, lsl #32
    // 0xd0f7fc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd0f800: cmp             w0, w16
    // 0xd0f804: b.ne            #0xd0f814
    // 0xd0f808: r2 = _colors
    //     0xd0f808: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xd0f80c: ldr             x2, [x2, #0x400]
    // 0xd0f810: r0 = InitLateFinalInstanceField()
    //     0xd0f810: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd0f814: LoadField: r1 = r0->field_7f
    //     0xd0f814: ldur            w1, [x0, #0x7f]
    // 0xd0f818: DecompressPointer r1
    //     0xd0f818: add             x1, x1, HEAP, lsl #32
    // 0xd0f81c: r0 = LoadClassIdInstr(r1)
    //     0xd0f81c: ldur            x0, [x1, #-1]
    //     0xd0f820: ubfx            x0, x0, #0xc, #0x14
    // 0xd0f824: d0 = 0.600000
    //     0xd0f824: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c88] IMM: double(0.6) from 0x3fe3333333333333
    //     0xd0f828: ldr             d0, [x17, #0xc88]
    // 0xd0f82c: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd0f82c: sub             lr, x0, #1, lsl #12
    //     0xd0f830: ldr             lr, [x21, lr, lsl #3]
    //     0xd0f834: blr             lr
    // 0xd0f838: ldur            x1, [fp, #-0x38]
    // 0xd0f83c: mov             x2, x0
    // 0xd0f840: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xd0f840: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xd0f844: r0 = apply()
    //     0xd0f844: bl              #0x8acf20  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0xd0f848: b               #0xd0f8e4
    // 0xd0f84c: ldur            x1, [fp, #-0x20]
    // 0xd0f850: LoadField: r0 = r1->field_b7
    //     0xd0f850: ldur            w0, [x1, #0xb7]
    // 0xd0f854: DecompressPointer r0
    //     0xd0f854: add             x0, x0, HEAP, lsl #32
    // 0xd0f858: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd0f85c: cmp             w0, w16
    // 0xd0f860: b.ne            #0xd0f870
    // 0xd0f864: r2 = _textTheme
    //     0xd0f864: add             x2, PP, #0x26, lsl #12  ; [pp+0x26420] Field <_DatePickerDefaultsM2@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0xd0f868: ldr             x2, [x2, #0x420]
    // 0xd0f86c: r0 = InitLateFinalInstanceField()
    //     0xd0f86c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd0f870: LoadField: r2 = r0->field_27
    //     0xd0f870: ldur            w2, [x0, #0x27]
    // 0xd0f874: DecompressPointer r2
    //     0xd0f874: add             x2, x2, HEAP, lsl #32
    // 0xd0f878: stur            x2, [fp, #-0x38]
    // 0xd0f87c: cmp             w2, NULL
    // 0xd0f880: b.ne            #0xd0f88c
    // 0xd0f884: r0 = Null
    //     0xd0f884: mov             x0, NULL
    // 0xd0f888: b               #0xd0f8e4
    // 0xd0f88c: ldur            x1, [fp, #-0x20]
    // 0xd0f890: LoadField: r0 = r1->field_b3
    //     0xd0f890: ldur            w0, [x1, #0xb3]
    // 0xd0f894: DecompressPointer r0
    //     0xd0f894: add             x0, x0, HEAP, lsl #32
    // 0xd0f898: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd0f89c: cmp             w0, w16
    // 0xd0f8a0: b.ne            #0xd0f8b0
    // 0xd0f8a4: r2 = _colors
    //     0xd0f8a4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xd0f8a8: ldr             x2, [x2, #0x410]
    // 0xd0f8ac: r0 = InitLateFinalInstanceField()
    //     0xd0f8ac: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd0f8b0: LoadField: r1 = r0->field_7f
    //     0xd0f8b0: ldur            w1, [x0, #0x7f]
    // 0xd0f8b4: DecompressPointer r1
    //     0xd0f8b4: add             x1, x1, HEAP, lsl #32
    // 0xd0f8b8: r0 = LoadClassIdInstr(r1)
    //     0xd0f8b8: ldur            x0, [x1, #-1]
    //     0xd0f8bc: ubfx            x0, x0, #0xc, #0x14
    // 0xd0f8c0: d0 = 0.600000
    //     0xd0f8c0: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c88] IMM: double(0.6) from 0x3fe3333333333333
    //     0xd0f8c4: ldr             d0, [x17, #0xc88]
    // 0xd0f8c8: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd0f8c8: sub             lr, x0, #1, lsl #12
    //     0xd0f8cc: ldr             lr, [x21, lr, lsl #3]
    //     0xd0f8d0: blr             lr
    // 0xd0f8d4: ldur            x1, [fp, #-0x38]
    // 0xd0f8d8: mov             x2, x0
    // 0xd0f8dc: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xd0f8dc: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xd0f8e0: r0 = apply()
    //     0xd0f8e0: bl              #0x8acf20  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0xd0f8e4: cmp             w0, NULL
    // 0xd0f8e8: b.ne            #0xd0f8f4
    // 0xd0f8ec: r3 = Null
    //     0xd0f8ec: mov             x3, NULL
    // 0xd0f8f0: b               #0xd0f900
    // 0xd0f8f4: LoadField: r1 = r0->field_b
    //     0xd0f8f4: ldur            w1, [x0, #0xb]
    // 0xd0f8f8: DecompressPointer r1
    //     0xd0f8f8: add             x1, x1, HEAP, lsl #32
    // 0xd0f8fc: mov             x3, x1
    // 0xd0f900: ldur            x2, [fp, #-8]
    // 0xd0f904: ldur            x0, [fp, #-0x28]
    // 0xd0f908: ldur            x1, [fp, #-0x10]
    // 0xd0f90c: stur            x3, [fp, #-0x20]
    // 0xd0f910: r0 = of()
    //     0xd0f910: bl              #0xd0bbf8  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0xd0f914: r1 = LoadClassIdInstr(r0)
    //     0xd0f914: ldur            x1, [x0, #-1]
    //     0xd0f918: ubfx            x1, x1, #0xc, #0x14
    // 0xd0f91c: mov             x16, x0
    // 0xd0f920: mov             x0, x1
    // 0xd0f924: mov             x1, x16
    // 0xd0f928: r0 = GDT[cid_x0 + 0x1532a]()
    //     0xd0f928: mov             x17, #0x532a
    //     0xd0f92c: movk            x17, #1, lsl #16
    //     0xd0f930: add             lr, x0, x17
    //     0xd0f934: ldr             lr, [x21, lr, lsl #3]
    //     0xd0f938: blr             lr
    // 0xd0f93c: mov             x3, x0
    // 0xd0f940: ldur            x0, [fp, #-8]
    // 0xd0f944: stur            x3, [fp, #-0x40]
    // 0xd0f948: LoadField: r1 = r0->field_b
    //     0xd0f948: ldur            w1, [x0, #0xb]
    // 0xd0f94c: DecompressPointer r1
    //     0xd0f94c: add             x1, x1, HEAP, lsl #32
    // 0xd0f950: cmp             w1, NULL
    // 0xd0f954: b.eq            #0xd0fd3c
    // 0xd0f958: LoadField: r4 = r1->field_13
    //     0xd0f958: ldur            w4, [x1, #0x13]
    // 0xd0f95c: DecompressPointer r4
    //     0xd0f95c: add             x4, x4, HEAP, lsl #32
    // 0xd0f960: stur            x4, [fp, #-0x38]
    // 0xd0f964: LoadField: r5 = r1->field_f
    //     0xd0f964: ldur            w5, [x1, #0xf]
    // 0xd0f968: DecompressPointer r5
    //     0xd0f968: add             x5, x5, HEAP, lsl #32
    // 0xd0f96c: ldur            x1, [fp, #-0x28]
    // 0xd0f970: stur            x5, [fp, #-0x10]
    // 0xd0f974: cmp             w1, NULL
    // 0xd0f978: b.ne            #0xd0f98c
    // 0xd0f97c: mov             x1, x4
    // 0xd0f980: mov             x2, x5
    // 0xd0f984: r4 = Null
    //     0xd0f984: mov             x4, NULL
    // 0xd0f988: b               #0xd0f9a8
    // 0xd0f98c: ldur            x2, [fp, #-0x20]
    // 0xd0f990: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xd0f990: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xd0f994: r0 = apply()
    //     0xd0f994: bl              #0x8acf20  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0xd0f998: mov             x4, x0
    // 0xd0f99c: ldur            x0, [fp, #-8]
    // 0xd0f9a0: ldur            x1, [fp, #-0x38]
    // 0xd0f9a4: ldur            x2, [fp, #-0x10]
    // 0xd0f9a8: ldur            x3, [fp, #-0x30]
    // 0xd0f9ac: stur            x4, [fp, #-0x20]
    // 0xd0f9b0: r0 = Text()
    //     0xd0f9b0: bl              #0x8a70a4  ; AllocateTextStub -> Text (size=0x50)
    // 0xd0f9b4: mov             x2, x0
    // 0xd0f9b8: ldur            x0, [fp, #-0x10]
    // 0xd0f9bc: stur            x2, [fp, #-0x28]
    // 0xd0f9c0: StoreField: r2->field_b = r0
    //     0xd0f9c0: stur            w0, [x2, #0xb]
    // 0xd0f9c4: ldur            x0, [fp, #-0x20]
    // 0xd0f9c8: StoreField: r2->field_13 = r0
    //     0xd0f9c8: stur            w0, [x2, #0x13]
    // 0xd0f9cc: r0 = Instance_TextOverflow
    //     0xd0f9cc: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1ac18] Obj!TextOverflow@12c47a1
    //     0xd0f9d0: ldr             x0, [x0, #0xc18]
    // 0xd0f9d4: StoreField: r2->field_2b = r0
    //     0xd0f9d4: stur            w0, [x2, #0x2b]
    // 0xd0f9d8: r1 = <FlexParentData>
    //     0xd0f9d8: add             x1, PP, #0x15, lsl #12  ; [pp+0x15878] TypeArguments: <FlexParentData>
    //     0xd0f9dc: ldr             x1, [x1, #0x878]
    // 0xd0f9e0: r0 = Flexible()
    //     0xd0f9e0: bl              #0xd0fd68  ; AllocateFlexibleStub -> Flexible (size=0x20)
    // 0xd0f9e4: mov             x1, x0
    // 0xd0f9e8: r0 = 1
    //     0xd0f9e8: mov             x0, #1
    // 0xd0f9ec: stur            x1, [fp, #-0x20]
    // 0xd0f9f0: StoreField: r1->field_13 = r0
    //     0xd0f9f0: stur            x0, [x1, #0x13]
    // 0xd0f9f4: r2 = Instance_FlexFit
    //     0xd0f9f4: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1ac30] Obj!FlexFit@12c4661
    //     0xd0f9f8: ldr             x2, [x2, #0xc30]
    // 0xd0f9fc: StoreField: r1->field_1b = r2
    //     0xd0f9fc: stur            w2, [x1, #0x1b]
    // 0xd0fa00: ldur            x3, [fp, #-0x28]
    // 0xd0fa04: StoreField: r1->field_b = r3
    //     0xd0fa04: stur            w3, [x1, #0xb]
    // 0xd0fa08: ldur            x3, [fp, #-8]
    // 0xd0fa0c: LoadField: r4 = r3->field_1b
    //     0xd0fa0c: ldur            w4, [x3, #0x1b]
    // 0xd0fa10: DecompressPointer r4
    //     0xd0fa10: add             x4, x4, HEAP, lsl #32
    // 0xd0fa14: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd0fa18: cmp             w4, w16
    // 0xd0fa1c: b.eq            #0xd0fd40
    // 0xd0fa20: stur            x4, [fp, #-0x10]
    // 0xd0fa24: r0 = Icon()
    //     0xd0fa24: bl              #0xd0fd5c  ; AllocateIconStub -> Icon (size=0x40)
    // 0xd0fa28: mov             x1, x0
    // 0xd0fa2c: r0 = Instance_IconData
    //     0xd0fa2c: add             x0, PP, #0x28, lsl #12  ; [pp+0x281f0] Obj!IconData@128a231
    //     0xd0fa30: ldr             x0, [x0, #0x1f0]
    // 0xd0fa34: stur            x1, [fp, #-0x28]
    // 0xd0fa38: StoreField: r1->field_b = r0
    //     0xd0fa38: stur            w0, [x1, #0xb]
    // 0xd0fa3c: ldur            x0, [fp, #-0x30]
    // 0xd0fa40: StoreField: r1->field_23 = r0
    //     0xd0fa40: stur            w0, [x1, #0x23]
    // 0xd0fa44: r0 = RotationTransition()
    //     0xd0fa44: bl              #0xd0fd50  ; AllocateRotationTransitionStub -> RotationTransition (size=0x20)
    // 0xd0fa48: mov             x3, x0
    // 0xd0fa4c: r0 = Closure: (double) => Matrix4 from Function '_handleTurnsMatrix@589170175': static.
    //     0xd0fa4c: add             x0, PP, #0x95, lsl #12  ; [pp+0x95d30] Closure: (double) => Matrix4 from Function '_handleTurnsMatrix@589170175': static. (0x7f2adabf7000)
    //     0xd0fa50: ldr             x0, [x0, #0xd30]
    // 0xd0fa54: stur            x3, [fp, #-0x30]
    // 0xd0fa58: StoreField: r3->field_f = r0
    //     0xd0fa58: stur            w0, [x3, #0xf]
    // 0xd0fa5c: r0 = Instance_Alignment
    //     0xd0fa5c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xd0fa60: ldr             x0, [x0, #0xb80]
    // 0xd0fa64: StoreField: r3->field_13 = r0
    //     0xd0fa64: stur            w0, [x3, #0x13]
    // 0xd0fa68: ldur            x0, [fp, #-0x28]
    // 0xd0fa6c: StoreField: r3->field_1b = r0
    //     0xd0fa6c: stur            w0, [x3, #0x1b]
    // 0xd0fa70: ldur            x0, [fp, #-0x10]
    // 0xd0fa74: StoreField: r3->field_b = r0
    //     0xd0fa74: stur            w0, [x3, #0xb]
    // 0xd0fa78: r1 = Null
    //     0xd0fa78: mov             x1, NULL
    // 0xd0fa7c: r2 = 4
    //     0xd0fa7c: mov             x2, #4
    // 0xd0fa80: r0 = AllocateArray()
    //     0xd0fa80: bl              #0x13df928  ; AllocateArrayStub
    // 0xd0fa84: mov             x2, x0
    // 0xd0fa88: ldur            x0, [fp, #-0x20]
    // 0xd0fa8c: stur            x2, [fp, #-0x10]
    // 0xd0fa90: StoreField: r2->field_f = r0
    //     0xd0fa90: stur            w0, [x2, #0xf]
    // 0xd0fa94: ldur            x0, [fp, #-0x30]
    // 0xd0fa98: StoreField: r2->field_13 = r0
    //     0xd0fa98: stur            w0, [x2, #0x13]
    // 0xd0fa9c: r1 = <Widget>
    //     0xd0fa9c: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xd0faa0: r0 = AllocateGrowableArray()
    //     0xd0faa0: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xd0faa4: mov             x1, x0
    // 0xd0faa8: ldur            x0, [fp, #-0x10]
    // 0xd0faac: stur            x1, [fp, #-0x20]
    // 0xd0fab0: StoreField: r1->field_f = r0
    //     0xd0fab0: stur            w0, [x1, #0xf]
    // 0xd0fab4: r0 = 4
    //     0xd0fab4: mov             x0, #4
    // 0xd0fab8: StoreField: r1->field_b = r0
    //     0xd0fab8: stur            w0, [x1, #0xb]
    // 0xd0fabc: r0 = Row()
    //     0xd0fabc: bl              #0x8a5b04  ; AllocateRowStub -> Row (size=0x38)
    // 0xd0fac0: mov             x1, x0
    // 0xd0fac4: r0 = Instance_Axis
    //     0xd0fac4: ldr             x0, [PP, #0x49c8]  ; [pp+0x49c8] Obj!Axis@12c4a61
    // 0xd0fac8: stur            x1, [fp, #-0x10]
    // 0xd0facc: StoreField: r1->field_f = r0
    //     0xd0facc: stur            w0, [x1, #0xf]
    // 0xd0fad0: r2 = Instance_MainAxisAlignment
    //     0xd0fad0: add             x2, PP, #0x15, lsl #12  ; [pp+0x15820] Obj!MainAxisAlignment@12c4541
    //     0xd0fad4: ldr             x2, [x2, #0x820]
    // 0xd0fad8: StoreField: r1->field_13 = r2
    //     0xd0fad8: stur            w2, [x1, #0x13]
    // 0xd0fadc: r3 = Instance_MainAxisSize
    //     0xd0fadc: add             x3, PP, #0x15, lsl #12  ; [pp+0x15828] Obj!MainAxisSize@12c4621
    //     0xd0fae0: ldr             x3, [x3, #0x828]
    // 0xd0fae4: ArrayStore: r1[0] = r3  ; List_4
    //     0xd0fae4: stur            w3, [x1, #0x17]
    // 0xd0fae8: r4 = Instance_CrossAxisAlignment
    //     0xd0fae8: add             x4, PP, #0x15, lsl #12  ; [pp+0x15888] Obj!CrossAxisAlignment@12c44a1
    //     0xd0faec: ldr             x4, [x4, #0x888]
    // 0xd0faf0: StoreField: r1->field_1b = r4
    //     0xd0faf0: stur            w4, [x1, #0x1b]
    // 0xd0faf4: r5 = Instance_VerticalDirection
    //     0xd0faf4: add             x5, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xd0faf8: ldr             x5, [x5, #0x838]
    // 0xd0fafc: StoreField: r1->field_23 = r5
    //     0xd0fafc: stur            w5, [x1, #0x23]
    // 0xd0fb00: r6 = Instance_Clip
    //     0xd0fb00: add             x6, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xd0fb04: ldr             x6, [x6, #0x840]
    // 0xd0fb08: StoreField: r1->field_2b = r6
    //     0xd0fb08: stur            w6, [x1, #0x2b]
    // 0xd0fb0c: StoreField: r1->field_2f = rZR
    //     0xd0fb0c: stur            xzr, [x1, #0x2f]
    // 0xd0fb10: ldur            x7, [fp, #-0x20]
    // 0xd0fb14: StoreField: r1->field_b = r7
    //     0xd0fb14: stur            w7, [x1, #0xb]
    // 0xd0fb18: r0 = Padding()
    //     0xd0fb18: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xd0fb1c: mov             x1, x0
    // 0xd0fb20: r0 = Instance_EdgeInsets
    //     0xd0fb20: add             x0, PP, #0x7a, lsl #12  ; [pp+0x7abf0] Obj!EdgeInsets@129cd21
    //     0xd0fb24: ldr             x0, [x0, #0xbf0]
    // 0xd0fb28: stur            x1, [fp, #-0x20]
    // 0xd0fb2c: StoreField: r1->field_f = r0
    //     0xd0fb2c: stur            w0, [x1, #0xf]
    // 0xd0fb30: ldur            x0, [fp, #-0x10]
    // 0xd0fb34: StoreField: r1->field_b = r0
    //     0xd0fb34: stur            w0, [x1, #0xb]
    // 0xd0fb38: r0 = InkWell()
    //     0xd0fb38: bl              #0xd0c57c  ; AllocateInkWellStub -> InkWell (size=0x94)
    // 0xd0fb3c: mov             x1, x0
    // 0xd0fb40: ldur            x0, [fp, #-0x20]
    // 0xd0fb44: stur            x1, [fp, #-0x10]
    // 0xd0fb48: StoreField: r1->field_b = r0
    //     0xd0fb48: stur            w0, [x1, #0xb]
    // 0xd0fb4c: ldur            x0, [fp, #-0x38]
    // 0xd0fb50: StoreField: r1->field_f = r0
    //     0xd0fb50: stur            w0, [x1, #0xf]
    // 0xd0fb54: r0 = true
    //     0xd0fb54: add             x0, NULL, #0x20  ; true
    // 0xd0fb58: StoreField: r1->field_47 = r0
    //     0xd0fb58: stur            w0, [x1, #0x47]
    // 0xd0fb5c: r2 = Instance_BoxShape
    //     0xd0fb5c: add             x2, PP, #0x17, lsl #12  ; [pp+0x171f8] Obj!BoxShape@12c4921
    //     0xd0fb60: ldr             x2, [x2, #0x1f8]
    // 0xd0fb64: StoreField: r1->field_4b = r2
    //     0xd0fb64: stur            w2, [x1, #0x4b]
    // 0xd0fb68: StoreField: r1->field_73 = r0
    //     0xd0fb68: stur            w0, [x1, #0x73]
    // 0xd0fb6c: r2 = false
    //     0xd0fb6c: add             x2, NULL, #0x30  ; false
    // 0xd0fb70: StoreField: r1->field_77 = r2
    //     0xd0fb70: stur            w2, [x1, #0x77]
    // 0xd0fb74: StoreField: r1->field_87 = r0
    //     0xd0fb74: stur            w0, [x1, #0x87]
    // 0xd0fb78: StoreField: r1->field_7f = r2
    //     0xd0fb78: stur            w2, [x1, #0x7f]
    // 0xd0fb7c: r0 = SizedBox()
    //     0xd0fb7c: bl              #0x8a7210  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0xd0fb80: mov             x1, x0
    // 0xd0fb84: r0 = 52.000000
    //     0xd0fb84: add             x0, PP, #0xd0, lsl #12  ; [pp+0xd06f8] 52
    //     0xd0fb88: ldr             x0, [x0, #0x6f8]
    // 0xd0fb8c: stur            x1, [fp, #-0x20]
    // 0xd0fb90: StoreField: r1->field_13 = r0
    //     0xd0fb90: stur            w0, [x1, #0x13]
    // 0xd0fb94: ldur            x2, [fp, #-0x10]
    // 0xd0fb98: StoreField: r1->field_b = r2
    //     0xd0fb98: stur            w2, [x1, #0xb]
    // 0xd0fb9c: r0 = Semantics()
    //     0xd0fb9c: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xd0fba0: stur            x0, [fp, #-0x10]
    // 0xd0fba4: ldur            x16, [fp, #-0x40]
    // 0xd0fba8: r30 = true
    //     0xd0fba8: add             lr, NULL, #0x20  ; true
    // 0xd0fbac: stp             lr, x16, [SP, #0x10]
    // 0xd0fbb0: r16 = true
    //     0xd0fbb0: add             x16, NULL, #0x20  ; true
    // 0xd0fbb4: ldur            lr, [fp, #-0x20]
    // 0xd0fbb8: stp             lr, x16, [SP]
    // 0xd0fbbc: mov             x1, x0
    // 0xd0fbc0: r4 = const [0, 0x5, 0x4, 0x1, button, 0x2, child, 0x4, container, 0x3, label, 0x1, null]
    //     0xd0fbc0: add             x4, PP, #0xd0, lsl #12  ; [pp+0xd07b0] List(13) [0, 0x5, 0x4, 0x1, "button", 0x2, "child", 0x4, "container", 0x3, "label", 0x1, Null]
    //     0xd0fbc4: ldr             x4, [x4, #0x7b0]
    // 0xd0fbc8: r0 = Semantics()
    //     0xd0fbc8: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xd0fbcc: r1 = <FlexParentData>
    //     0xd0fbcc: add             x1, PP, #0x15, lsl #12  ; [pp+0x15878] TypeArguments: <FlexParentData>
    //     0xd0fbd0: ldr             x1, [x1, #0x878]
    // 0xd0fbd4: r0 = Flexible()
    //     0xd0fbd4: bl              #0xd0fd68  ; AllocateFlexibleStub -> Flexible (size=0x20)
    // 0xd0fbd8: mov             x3, x0
    // 0xd0fbdc: r0 = 1
    //     0xd0fbdc: mov             x0, #1
    // 0xd0fbe0: stur            x3, [fp, #-0x20]
    // 0xd0fbe4: StoreField: r3->field_13 = r0
    //     0xd0fbe4: stur            x0, [x3, #0x13]
    // 0xd0fbe8: r0 = Instance_FlexFit
    //     0xd0fbe8: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1ac30] Obj!FlexFit@12c4661
    //     0xd0fbec: ldr             x0, [x0, #0xc30]
    // 0xd0fbf0: StoreField: r3->field_1b = r0
    //     0xd0fbf0: stur            w0, [x3, #0x1b]
    // 0xd0fbf4: ldur            x0, [fp, #-0x10]
    // 0xd0fbf8: StoreField: r3->field_b = r0
    //     0xd0fbf8: stur            w0, [x3, #0xb]
    // 0xd0fbfc: r1 = Null
    //     0xd0fbfc: mov             x1, NULL
    // 0xd0fc00: r2 = 2
    //     0xd0fc00: mov             x2, #2
    // 0xd0fc04: r0 = AllocateArray()
    //     0xd0fc04: bl              #0x13df928  ; AllocateArrayStub
    // 0xd0fc08: mov             x2, x0
    // 0xd0fc0c: ldur            x0, [fp, #-0x20]
    // 0xd0fc10: stur            x2, [fp, #-0x10]
    // 0xd0fc14: StoreField: r2->field_f = r0
    //     0xd0fc14: stur            w0, [x2, #0xf]
    // 0xd0fc18: r1 = <Widget>
    //     0xd0fc18: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xd0fc1c: r0 = AllocateGrowableArray()
    //     0xd0fc1c: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xd0fc20: mov             x2, x0
    // 0xd0fc24: ldur            x0, [fp, #-0x10]
    // 0xd0fc28: stur            x2, [fp, #-0x20]
    // 0xd0fc2c: StoreField: r2->field_f = r0
    //     0xd0fc2c: stur            w0, [x2, #0xf]
    // 0xd0fc30: r0 = 2
    //     0xd0fc30: mov             x0, #2
    // 0xd0fc34: StoreField: r2->field_b = r0
    //     0xd0fc34: stur            w0, [x2, #0xb]
    // 0xd0fc38: ldur            x0, [fp, #-8]
    // 0xd0fc3c: LoadField: r1 = r0->field_b
    //     0xd0fc3c: ldur            w1, [x0, #0xb]
    // 0xd0fc40: DecompressPointer r1
    //     0xd0fc40: add             x1, x1, HEAP, lsl #32
    // 0xd0fc44: cmp             w1, NULL
    // 0xd0fc48: b.eq            #0xd0fd4c
    // 0xd0fc4c: LoadField: r0 = r1->field_b
    //     0xd0fc4c: ldur            w0, [x1, #0xb]
    // 0xd0fc50: DecompressPointer r0
    //     0xd0fc50: add             x0, x0, HEAP, lsl #32
    // 0xd0fc54: r16 = Instance_DatePickerMode
    //     0xd0fc54: add             x16, PP, #0x28, lsl #12  ; [pp+0x28528] Obj!DatePickerMode@12c5821
    //     0xd0fc58: ldr             x16, [x16, #0x528]
    // 0xd0fc5c: cmp             w0, w16
    // 0xd0fc60: b.ne            #0xd0fc90
    // 0xd0fc64: mov             x1, x2
    // 0xd0fc68: r0 = _growToNextCapacity()
    //     0xd0fc68: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xd0fc6c: ldur            x0, [fp, #-0x20]
    // 0xd0fc70: r1 = 4
    //     0xd0fc70: mov             x1, #4
    // 0xd0fc74: StoreField: r0->field_b = r1
    //     0xd0fc74: stur            w1, [x0, #0xb]
    // 0xd0fc78: LoadField: r1 = r0->field_f
    //     0xd0fc78: ldur            w1, [x0, #0xf]
    // 0xd0fc7c: DecompressPointer r1
    //     0xd0fc7c: add             x1, x1, HEAP, lsl #32
    // 0xd0fc80: r16 = Instance_SizedBox
    //     0xd0fc80: add             x16, PP, #0xd0, lsl #12  ; [pp+0xd07b8] Obj!SizedBox@12b7101
    //     0xd0fc84: ldr             x16, [x16, #0x7b8]
    // 0xd0fc88: StoreField: r1->field_13 = r16
    //     0xd0fc88: stur            w16, [x1, #0x13]
    // 0xd0fc8c: b               #0xd0fc94
    // 0xd0fc90: mov             x0, x2
    // 0xd0fc94: r0 = Row()
    //     0xd0fc94: bl              #0x8a5b04  ; AllocateRowStub -> Row (size=0x38)
    // 0xd0fc98: mov             x1, x0
    // 0xd0fc9c: r0 = Instance_Axis
    //     0xd0fc9c: ldr             x0, [PP, #0x49c8]  ; [pp+0x49c8] Obj!Axis@12c4a61
    // 0xd0fca0: stur            x1, [fp, #-8]
    // 0xd0fca4: StoreField: r1->field_f = r0
    //     0xd0fca4: stur            w0, [x1, #0xf]
    // 0xd0fca8: r0 = Instance_MainAxisAlignment
    //     0xd0fca8: add             x0, PP, #0x15, lsl #12  ; [pp+0x15820] Obj!MainAxisAlignment@12c4541
    //     0xd0fcac: ldr             x0, [x0, #0x820]
    // 0xd0fcb0: StoreField: r1->field_13 = r0
    //     0xd0fcb0: stur            w0, [x1, #0x13]
    // 0xd0fcb4: r0 = Instance_MainAxisSize
    //     0xd0fcb4: add             x0, PP, #0x15, lsl #12  ; [pp+0x15828] Obj!MainAxisSize@12c4621
    //     0xd0fcb8: ldr             x0, [x0, #0x828]
    // 0xd0fcbc: ArrayStore: r1[0] = r0  ; List_4
    //     0xd0fcbc: stur            w0, [x1, #0x17]
    // 0xd0fcc0: r0 = Instance_CrossAxisAlignment
    //     0xd0fcc0: add             x0, PP, #0x15, lsl #12  ; [pp+0x15888] Obj!CrossAxisAlignment@12c44a1
    //     0xd0fcc4: ldr             x0, [x0, #0x888]
    // 0xd0fcc8: StoreField: r1->field_1b = r0
    //     0xd0fcc8: stur            w0, [x1, #0x1b]
    // 0xd0fccc: r0 = Instance_VerticalDirection
    //     0xd0fccc: add             x0, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xd0fcd0: ldr             x0, [x0, #0x838]
    // 0xd0fcd4: StoreField: r1->field_23 = r0
    //     0xd0fcd4: stur            w0, [x1, #0x23]
    // 0xd0fcd8: r0 = Instance_Clip
    //     0xd0fcd8: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xd0fcdc: ldr             x0, [x0, #0x840]
    // 0xd0fce0: StoreField: r1->field_2b = r0
    //     0xd0fce0: stur            w0, [x1, #0x2b]
    // 0xd0fce4: StoreField: r1->field_2f = rZR
    //     0xd0fce4: stur            xzr, [x1, #0x2f]
    // 0xd0fce8: ldur            x0, [fp, #-0x20]
    // 0xd0fcec: StoreField: r1->field_b = r0
    //     0xd0fcec: stur            w0, [x1, #0xb]
    // 0xd0fcf0: r0 = Padding()
    //     0xd0fcf0: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xd0fcf4: mov             x1, x0
    // 0xd0fcf8: r0 = Instance_EdgeInsetsDirectional
    //     0xd0fcf8: add             x0, PP, #0xd0, lsl #12  ; [pp+0xd06f0] Obj!EdgeInsetsDirectional@129c811
    //     0xd0fcfc: ldr             x0, [x0, #0x6f0]
    // 0xd0fd00: stur            x1, [fp, #-0x10]
    // 0xd0fd04: StoreField: r1->field_f = r0
    //     0xd0fd04: stur            w0, [x1, #0xf]
    // 0xd0fd08: ldur            x0, [fp, #-8]
    // 0xd0fd0c: StoreField: r1->field_b = r0
    //     0xd0fd0c: stur            w0, [x1, #0xb]
    // 0xd0fd10: r0 = SizedBox()
    //     0xd0fd10: bl              #0x8a7210  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0xd0fd14: r1 = 52.000000
    //     0xd0fd14: add             x1, PP, #0xd0, lsl #12  ; [pp+0xd06f8] 52
    //     0xd0fd18: ldr             x1, [x1, #0x6f8]
    // 0xd0fd1c: StoreField: r0->field_13 = r1
    //     0xd0fd1c: stur            w1, [x0, #0x13]
    // 0xd0fd20: ldur            x1, [fp, #-0x10]
    // 0xd0fd24: StoreField: r0->field_b = r1
    //     0xd0fd24: stur            w1, [x0, #0xb]
    // 0xd0fd28: LeaveFrame
    //     0xd0fd28: mov             SP, fp
    //     0xd0fd2c: ldp             fp, lr, [SP], #0x10
    // 0xd0fd30: ret
    //     0xd0fd30: ret             
    // 0xd0fd34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0fd34: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0fd38: b               #0xd0f518
    // 0xd0fd3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0fd3c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0fd40: r9 = _controller
    //     0xd0fd40: add             x9, PP, #0xd0, lsl #12  ; [pp+0xd07a8] Field <_DatePickerModeToggleButtonState@54260463._controller@54260463>: late (offset: 0x1c)
    //     0xd0fd44: ldr             x9, [x9, #0x7a8]
    // 0xd0fd48: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd0fd48: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd0fd4c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0fd4c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf37a50, size: 0x160
    // 0xf37a50: EnterFrame
    //     0xf37a50: stp             fp, lr, [SP, #-0x10]!
    //     0xf37a54: mov             fp, SP
    // 0xf37a58: AllocStack(0x10)
    //     0xf37a58: sub             SP, SP, #0x10
    // 0xf37a5c: SetupParameters(_DatePickerModeToggleButtonState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xf37a5c: mov             x4, x1
    //     0xf37a60: mov             x3, x2
    //     0xf37a64: stur            x1, [fp, #-8]
    //     0xf37a68: stur            x2, [fp, #-0x10]
    // 0xf37a6c: CheckStackOverflow
    //     0xf37a6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf37a70: cmp             SP, x16
    //     0xf37a74: b.ls            #0xf37b8c
    // 0xf37a78: mov             x0, x3
    // 0xf37a7c: r2 = Null
    //     0xf37a7c: mov             x2, NULL
    // 0xf37a80: r1 = Null
    //     0xf37a80: mov             x1, NULL
    // 0xf37a84: r4 = 60
    //     0xf37a84: mov             x4, #0x3c
    // 0xf37a88: branchIfSmi(r0, 0xf37a94)
    //     0xf37a88: tbz             w0, #0, #0xf37a94
    // 0xf37a8c: r4 = LoadClassIdInstr(r0)
    //     0xf37a8c: ldur            x4, [x0, #-1]
    //     0xf37a90: ubfx            x4, x4, #0xc, #0x14
    // 0xf37a94: r17 = 6492
    //     0xf37a94: mov             x17, #0x195c
    // 0xf37a98: cmp             x4, x17
    // 0xf37a9c: b.eq            #0xf37ab4
    // 0xf37aa0: r8 = _DatePickerModeToggleButton
    //     0xf37aa0: add             x8, PP, #0xd0, lsl #12  ; [pp+0xd07c0] Type: _DatePickerModeToggleButton
    //     0xf37aa4: ldr             x8, [x8, #0x7c0]
    // 0xf37aa8: r3 = Null
    //     0xf37aa8: add             x3, PP, #0xd0, lsl #12  ; [pp+0xd07c8] Null
    //     0xf37aac: ldr             x3, [x3, #0x7c8]
    // 0xf37ab0: r0 = _DatePickerModeToggleButton()
    //     0xf37ab0: bl              #0xacd97c  ; IsType__DatePickerModeToggleButton_Stub
    // 0xf37ab4: ldur            x3, [fp, #-8]
    // 0xf37ab8: LoadField: r2 = r3->field_7
    //     0xf37ab8: ldur            w2, [x3, #7]
    // 0xf37abc: DecompressPointer r2
    //     0xf37abc: add             x2, x2, HEAP, lsl #32
    // 0xf37ac0: ldur            x0, [fp, #-0x10]
    // 0xf37ac4: r1 = Null
    //     0xf37ac4: mov             x1, NULL
    // 0xf37ac8: cmp             w2, NULL
    // 0xf37acc: b.eq            #0xf37af0
    // 0xf37ad0: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf37ad0: ldur            w4, [x2, #0x17]
    // 0xf37ad4: DecompressPointer r4
    //     0xf37ad4: add             x4, x4, HEAP, lsl #32
    // 0xf37ad8: r8 = X0 bound StatefulWidget
    //     0xf37ad8: add             x8, PP, #0x12, lsl #12  ; [pp+0x12498] TypeParameter: X0 bound StatefulWidget
    //     0xf37adc: ldr             x8, [x8, #0x498]
    // 0xf37ae0: LoadField: r9 = r4->field_7
    //     0xf37ae0: ldur            x9, [x4, #7]
    // 0xf37ae4: r3 = Null
    //     0xf37ae4: add             x3, PP, #0xd0, lsl #12  ; [pp+0xd07d8] Null
    //     0xf37ae8: ldr             x3, [x3, #0x7d8]
    // 0xf37aec: blr             x9
    // 0xf37af0: ldur            x0, [fp, #-0x10]
    // 0xf37af4: LoadField: r1 = r0->field_b
    //     0xf37af4: ldur            w1, [x0, #0xb]
    // 0xf37af8: DecompressPointer r1
    //     0xf37af8: add             x1, x1, HEAP, lsl #32
    // 0xf37afc: ldur            x0, [fp, #-8]
    // 0xf37b00: LoadField: r2 = r0->field_b
    //     0xf37b00: ldur            w2, [x0, #0xb]
    // 0xf37b04: DecompressPointer r2
    //     0xf37b04: add             x2, x2, HEAP, lsl #32
    // 0xf37b08: cmp             w2, NULL
    // 0xf37b0c: b.eq            #0xf37b94
    // 0xf37b10: LoadField: r3 = r2->field_b
    //     0xf37b10: ldur            w3, [x2, #0xb]
    // 0xf37b14: DecompressPointer r3
    //     0xf37b14: add             x3, x3, HEAP, lsl #32
    // 0xf37b18: cmp             w1, w3
    // 0xf37b1c: b.ne            #0xf37b30
    // 0xf37b20: r0 = Null
    //     0xf37b20: mov             x0, NULL
    // 0xf37b24: LeaveFrame
    //     0xf37b24: mov             SP, fp
    //     0xf37b28: ldp             fp, lr, [SP], #0x10
    // 0xf37b2c: ret
    //     0xf37b2c: ret             
    // 0xf37b30: r16 = Instance_DatePickerMode
    //     0xf37b30: add             x16, PP, #0xad, lsl #12  ; [pp+0xadf50] Obj!DatePickerMode@12c5841
    //     0xf37b34: ldr             x16, [x16, #0xf50]
    // 0xf37b38: cmp             w3, w16
    // 0xf37b3c: b.ne            #0xf37b60
    // 0xf37b40: LoadField: r1 = r0->field_1b
    //     0xf37b40: ldur            w1, [x0, #0x1b]
    // 0xf37b44: DecompressPointer r1
    //     0xf37b44: add             x1, x1, HEAP, lsl #32
    // 0xf37b48: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf37b4c: cmp             w1, w16
    // 0xf37b50: b.eq            #0xf37b98
    // 0xf37b54: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xf37b54: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xf37b58: r0 = forward()
    //     0xf37b58: bl              #0x8cd83c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0xf37b5c: b               #0xf37b7c
    // 0xf37b60: LoadField: r1 = r0->field_1b
    //     0xf37b60: ldur            w1, [x0, #0x1b]
    // 0xf37b64: DecompressPointer r1
    //     0xf37b64: add             x1, x1, HEAP, lsl #32
    // 0xf37b68: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf37b6c: cmp             w1, w16
    // 0xf37b70: b.eq            #0xf37ba4
    // 0xf37b74: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xf37b74: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xf37b78: r0 = reverse()
    //     0xf37b78: bl              #0x8c8688  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0xf37b7c: r0 = Null
    //     0xf37b7c: mov             x0, NULL
    // 0xf37b80: LeaveFrame
    //     0xf37b80: mov             SP, fp
    //     0xf37b84: ldp             fp, lr, [SP], #0x10
    // 0xf37b88: ret
    //     0xf37b88: ret             
    // 0xf37b8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf37b8c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf37b90: b               #0xf37a78
    // 0xf37b94: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf37b94: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf37b98: r9 = _controller
    //     0xf37b98: add             x9, PP, #0xd0, lsl #12  ; [pp+0xd07a8] Field <_DatePickerModeToggleButtonState@54260463._controller@54260463>: late (offset: 0x1c)
    //     0xf37b9c: ldr             x9, [x9, #0x7a8]
    // 0xf37ba0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf37ba0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xf37ba4: r9 = _controller
    //     0xf37ba4: add             x9, PP, #0xd0, lsl #12  ; [pp+0xd07a8] Field <_DatePickerModeToggleButtonState@54260463._controller@54260463>: late (offset: 0x1c)
    //     0xf37ba8: ldr             x9, [x9, #0x7a8]
    // 0xf37bac: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf37bac: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0xf79214, size: 0x114
    // 0xf79214: EnterFrame
    //     0xf79214: stp             fp, lr, [SP, #-0x10]!
    //     0xf79218: mov             fp, SP
    // 0xf7921c: AllocStack(0x30)
    //     0xf7921c: sub             SP, SP, #0x30
    // 0xf79220: SetupParameters(_DatePickerModeToggleButtonState this /* r1 => r2, fp-0x10 */)
    //     0xf79220: mov             x2, x1
    //     0xf79224: stur            x1, [fp, #-0x10]
    // 0xf79228: CheckStackOverflow
    //     0xf79228: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf7922c: cmp             SP, x16
    //     0xf79230: b.ls            #0xf79304
    // 0xf79234: LoadField: r0 = r2->field_b
    //     0xf79234: ldur            w0, [x2, #0xb]
    // 0xf79238: DecompressPointer r0
    //     0xf79238: add             x0, x0, HEAP, lsl #32
    // 0xf7923c: cmp             w0, NULL
    // 0xf79240: b.eq            #0xf7930c
    // 0xf79244: LoadField: r1 = r0->field_b
    //     0xf79244: ldur            w1, [x0, #0xb]
    // 0xf79248: DecompressPointer r1
    //     0xf79248: add             x1, x1, HEAP, lsl #32
    // 0xf7924c: r16 = Instance_DatePickerMode
    //     0xf7924c: add             x16, PP, #0xad, lsl #12  ; [pp+0xadf50] Obj!DatePickerMode@12c5841
    //     0xf79250: ldr             x16, [x16, #0xf50]
    // 0xf79254: cmp             w1, w16
    // 0xf79258: b.ne            #0xf79264
    // 0xf7925c: d0 = 0.500000
    //     0xf7925c: fmov            d0, #0.50000000
    // 0xf79260: b               #0xf79268
    // 0xf79264: d0 = 0.000000
    //     0xf79264: eor             v0.16b, v0.16b, v0.16b
    // 0xf79268: r0 = inline_Allocate_Double()
    //     0xf79268: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xf7926c: add             x0, x0, #0x10
    //     0xf79270: cmp             x1, x0
    //     0xf79274: b.ls            #0xf79310
    //     0xf79278: str             x0, [THR, #0x60]  ; THR::top
    //     0xf7927c: sub             x0, x0, #0xf
    //     0xf79280: mov             x1, #0xe19c
    //     0xf79284: movk            x1, #3, lsl #16
    //     0xf79288: stur            x1, [x0, #-1]
    // 0xf7928c: dmb             ishst
    // 0xf79290: StoreField: r0->field_7 = d0
    //     0xf79290: stur            d0, [x0, #7]
    // 0xf79294: stur            x0, [fp, #-8]
    // 0xf79298: r1 = <double>
    //     0xf79298: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf7929c: r0 = AnimationController()
    //     0xf7929c: bl              #0x87522c  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0xf792a0: stur            x0, [fp, #-0x18]
    // 0xf792a4: ldur            x16, [fp, #-8]
    // 0xf792a8: r30 = 0.500000
    //     0xf792a8: ldr             lr, [PP, #0x4c70]  ; [pp+0x4c70] 0.5
    // 0xf792ac: stp             lr, x16, [SP, #8]
    // 0xf792b0: r16 = Instance_Duration
    //     0xf792b0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xf792b4: ldr             x16, [x16, #0x318]
    // 0xf792b8: str             x16, [SP]
    // 0xf792bc: mov             x1, x0
    // 0xf792c0: ldur            x2, [fp, #-0x10]
    // 0xf792c4: r4 = const [0, 0x5, 0x3, 0x2, duration, 0x4, upperBound, 0x3, value, 0x2, null]
    //     0xf792c4: add             x4, PP, #0xd0, lsl #12  ; [pp+0xd07e8] List(11) [0, 0x5, 0x3, 0x2, "duration", 0x4, "upperBound", 0x3, "value", 0x2, Null]
    //     0xf792c8: ldr             x4, [x4, #0x7e8]
    // 0xf792cc: r0 = AnimationController()
    //     0xf792cc: bl              #0x874ea4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0xf792d0: ldur            x0, [fp, #-0x18]
    // 0xf792d4: ldur            x1, [fp, #-0x10]
    // 0xf792d8: StoreField: r1->field_1b = r0
    //     0xf792d8: stur            w0, [x1, #0x1b]
    //     0xf792dc: ldurb           w16, [x1, #-1]
    //     0xf792e0: ldurb           w17, [x0, #-1]
    //     0xf792e4: and             x16, x17, x16, lsr #2
    //     0xf792e8: tst             x16, HEAP, lsr #32
    //     0xf792ec: b.eq            #0xf792f4
    //     0xf792f0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf792f4: r0 = Null
    //     0xf792f4: mov             x0, NULL
    // 0xf792f8: LeaveFrame
    //     0xf792f8: mov             SP, fp
    //     0xf792fc: ldp             fp, lr, [SP], #0x10
    // 0xf79300: ret
    //     0xf79300: ret             
    // 0xf79304: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf79304: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf79308: b               #0xf79234
    // 0xf7930c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf7930c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf79310: SaveReg d0
    //     0xf79310: str             q0, [SP, #-0x10]!
    // 0xf79314: SaveReg r2
    //     0xf79314: str             x2, [SP, #-8]!
    // 0xf79318: r0 = AllocateDouble()
    //     0xf79318: bl              #0x13df878  ; AllocateDoubleStub
    // 0xf7931c: RestoreReg r2
    //     0xf7931c: ldr             x2, [SP], #8
    // 0xf79320: RestoreReg d0
    //     0xf79320: ldr             q0, [SP], #0x10
    // 0xf79324: b               #0xf79290
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10dc304, size: 0x64
    // 0x10dc304: EnterFrame
    //     0x10dc304: stp             fp, lr, [SP, #-0x10]!
    //     0x10dc308: mov             fp, SP
    // 0x10dc30c: AllocStack(0x8)
    //     0x10dc30c: sub             SP, SP, #8
    // 0x10dc310: SetupParameters(_DatePickerModeToggleButtonState this /* r1 => r0, fp-0x8 */)
    //     0x10dc310: mov             x0, x1
    //     0x10dc314: stur            x1, [fp, #-8]
    // 0x10dc318: CheckStackOverflow
    //     0x10dc318: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10dc31c: cmp             SP, x16
    //     0x10dc320: b.ls            #0x10dc354
    // 0x10dc324: LoadField: r1 = r0->field_1b
    //     0x10dc324: ldur            w1, [x0, #0x1b]
    // 0x10dc328: DecompressPointer r1
    //     0x10dc328: add             x1, x1, HEAP, lsl #32
    // 0x10dc32c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10dc330: cmp             w1, w16
    // 0x10dc334: b.eq            #0x10dc35c
    // 0x10dc338: r0 = dispose()
    //     0x10dc338: bl              #0x9164f4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x10dc33c: ldur            x1, [fp, #-8]
    // 0x10dc340: r0 = dispose()
    //     0x10dc340: bl              #0x10dc368  ; [dart:mixin_deduplication] _MixinApplication18&State&SingleTickerProviderStateMixin::dispose
    // 0x10dc344: r0 = Null
    //     0x10dc344: mov             x0, NULL
    // 0x10dc348: LeaveFrame
    //     0x10dc348: mov             SP, fp
    //     0x10dc34c: ldp             fp, lr, [SP], #0x10
    // 0x10dc350: ret
    //     0x10dc350: ret             
    // 0x10dc354: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10dc354: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10dc358: b               #0x10dc324
    // 0x10dc35c: r9 = _controller
    //     0x10dc35c: add             x9, PP, #0xd0, lsl #12  ; [pp+0xd07a8] Field <_DatePickerModeToggleButtonState@54260463._controller@54260463>: late (offset: 0x1c)
    //     0x10dc360: ldr             x9, [x9, #0x7a8]
    // 0x10dc364: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x10dc364: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 6488, size: 0x28, field offset: 0xc
class YearPicker extends StatefulWidget {

  _ YearPicker(/* No info */) {
    // ** addr: 0xdececc, size: 0x128
    // 0xdececc: EnterFrame
    //     0xdececc: stp             fp, lr, [SP, #-0x10]!
    //     0xdeced0: mov             fp, SP
    // 0xdeced4: AllocStack(0x10)
    //     0xdeced4: sub             SP, SP, #0x10
    // 0xdeced8: r8 = Instance_DragStartBehavior
    //     0xdeced8: ldr             x8, [PP, #0x5360]  ; [pp+0x5360] Obj!DragStartBehavior@12c5c61
    // 0xdecedc: r4 = Instance_GregorianCalendarDelegate
    //     0xdecedc: add             x4, PP, #0x28, lsl #12  ; [pp+0x28538] Obj!GregorianCalendarDelegate@129edd1
    //     0xdecee0: ldr             x4, [x4, #0x538]
    // 0xdecee4: mov             x0, x3
    // 0xdecee8: mov             x3, x5
    // 0xdeceec: stur            x5, [fp, #-0x10]
    // 0xdecef0: mov             x5, x2
    // 0xdecef4: mov             x2, x6
    // 0xdecef8: mov             x6, x1
    // 0xdecefc: stur            x1, [fp, #-8]
    // 0xdecf00: mov             x1, x7
    // 0xdecf04: CheckStackOverflow
    //     0xdecf04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdecf08: cmp             SP, x16
    //     0xdecf0c: b.ls            #0xdecfec
    // 0xdecf10: StoreField: r6->field_f = r0
    //     0xdecf10: stur            w0, [x6, #0xf]
    //     0xdecf14: ldurb           w16, [x6, #-1]
    //     0xdecf18: ldurb           w17, [x0, #-1]
    //     0xdecf1c: and             x16, x17, x16, lsr #2
    //     0xdecf20: tst             x16, HEAP, lsr #32
    //     0xdecf24: b.eq            #0xdecf2c
    //     0xdecf28: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0xdecf2c: mov             x0, x2
    // 0xdecf30: StoreField: r6->field_13 = r0
    //     0xdecf30: stur            w0, [x6, #0x13]
    //     0xdecf34: ldurb           w16, [x6, #-1]
    //     0xdecf38: ldurb           w17, [x0, #-1]
    //     0xdecf3c: and             x16, x17, x16, lsr #2
    //     0xdecf40: tst             x16, HEAP, lsr #32
    //     0xdecf44: b.eq            #0xdecf4c
    //     0xdecf48: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0xdecf4c: ldr             x0, [fp, #0x10]
    // 0xdecf50: ArrayStore: r6[0] = r0  ; List_4
    //     0xdecf50: stur            w0, [x6, #0x17]
    //     0xdecf54: ldurb           w16, [x6, #-1]
    //     0xdecf58: ldurb           w17, [x0, #-1]
    //     0xdecf5c: and             x16, x17, x16, lsr #2
    //     0xdecf60: tst             x16, HEAP, lsr #32
    //     0xdecf64: b.eq            #0xdecf6c
    //     0xdecf68: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0xdecf6c: mov             x0, x1
    // 0xdecf70: StoreField: r6->field_1b = r0
    //     0xdecf70: stur            w0, [x6, #0x1b]
    //     0xdecf74: ldurb           w16, [x6, #-1]
    //     0xdecf78: ldurb           w17, [x0, #-1]
    //     0xdecf7c: and             x16, x17, x16, lsr #2
    //     0xdecf80: tst             x16, HEAP, lsr #32
    //     0xdecf84: b.eq            #0xdecf8c
    //     0xdecf88: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0xdecf8c: StoreField: r6->field_1f = r8
    //     0xdecf8c: stur            w8, [x6, #0x1f]
    // 0xdecf90: StoreField: r6->field_23 = r4
    //     0xdecf90: stur            w4, [x6, #0x23]
    // 0xdecf94: mov             x1, x5
    // 0xdecf98: r0 = dateOnly()
    //     0xdecf98: bl              #0xd18a20  ; [package:flutter/src/material/date.dart] DateUtils::dateOnly
    // 0xdecf9c: ldur            x1, [fp, #-8]
    // 0xdecfa0: StoreField: r1->field_b = r0
    //     0xdecfa0: stur            w0, [x1, #0xb]
    //     0xdecfa4: ldurb           w16, [x1, #-1]
    //     0xdecfa8: ldurb           w17, [x0, #-1]
    //     0xdecfac: and             x16, x17, x16, lsr #2
    //     0xdecfb0: tst             x16, HEAP, lsr #32
    //     0xdecfb4: b.eq            #0xdecfbc
    //     0xdecfb8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdecfbc: ldur            x0, [fp, #-0x10]
    // 0xdecfc0: StoreField: r1->field_7 = r0
    //     0xdecfc0: stur            w0, [x1, #7]
    //     0xdecfc4: ldurb           w16, [x1, #-1]
    //     0xdecfc8: ldurb           w17, [x0, #-1]
    //     0xdecfcc: and             x16, x17, x16, lsr #2
    //     0xdecfd0: tst             x16, HEAP, lsr #32
    //     0xdecfd4: b.eq            #0xdecfdc
    //     0xdecfd8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdecfdc: r0 = Null
    //     0xdecfdc: mov             x0, NULL
    // 0xdecfe0: LeaveFrame
    //     0xdecfe0: mov             SP, fp
    //     0xdecfe4: ldp             fp, lr, [SP], #0x10
    // 0xdecfe8: ret
    //     0xdecfe8: ret             
    // 0xdecfec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdecfec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdecff0: b               #0xdecf10
  }
  _ createState(/* No info */) {
    // ** addr: 0xfa10f4, size: 0x58
    // 0xfa10f4: EnterFrame
    //     0xfa10f4: stp             fp, lr, [SP, #-0x10]!
    //     0xfa10f8: mov             fp, SP
    // 0xfa10fc: AllocStack(0x8)
    //     0xfa10fc: sub             SP, SP, #8
    // 0xfa1100: CheckStackOverflow
    //     0xfa1100: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa1104: cmp             SP, x16
    //     0xfa1108: b.ls            #0xfa1144
    // 0xfa110c: r1 = <Set<WidgetState>>
    //     0xfa110c: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f978] TypeArguments: <Set<WidgetState>>
    //     0xfa1110: ldr             x1, [x1, #0x978]
    // 0xfa1114: r0 = WidgetStatesController()
    //     0xfa1114: bl              #0xf379b8  ; AllocateWidgetStatesControllerStub -> WidgetStatesController (size=0x2c)
    // 0xfa1118: mov             x1, x0
    // 0xfa111c: stur            x0, [fp, #-8]
    // 0xfa1120: r0 = WidgetStatesController()
    //     0xfa1120: bl              #0xf378e8  ; [package:flutter/src/widgets/widget_state.dart] WidgetStatesController::WidgetStatesController
    // 0xfa1124: r1 = <YearPicker>
    //     0xfa1124: add             x1, PP, #0xcd, lsl #12  ; [pp+0xcd8b8] TypeArguments: <YearPicker>
    //     0xfa1128: ldr             x1, [x1, #0x8b8]
    // 0xfa112c: r0 = _YearPickerState()
    //     0xfa112c: bl              #0xfa114c  ; Allocate_YearPickerStateStub -> _YearPickerState (size=0x1c)
    // 0xfa1130: ldur            x1, [fp, #-8]
    // 0xfa1134: ArrayStore: r0[0] = r1  ; List_4
    //     0xfa1134: stur            w1, [x0, #0x17]
    // 0xfa1138: LeaveFrame
    //     0xfa1138: mov             SP, fp
    //     0xfa113c: ldp             fp, lr, [SP], #0x10
    // 0xfa1140: ret
    //     0xfa1140: ret             
    // 0xfa1144: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa1144: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa1148: b               #0xfa110c
  }
}

// class id: 6489, size: 0x28, field offset: 0xc
//   const constructor, 
class _Day extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa1090, size: 0x58
    // 0xfa1090: EnterFrame
    //     0xfa1090: stp             fp, lr, [SP, #-0x10]!
    //     0xfa1094: mov             fp, SP
    // 0xfa1098: AllocStack(0x8)
    //     0xfa1098: sub             SP, SP, #8
    // 0xfa109c: CheckStackOverflow
    //     0xfa109c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa10a0: cmp             SP, x16
    //     0xfa10a4: b.ls            #0xfa10e0
    // 0xfa10a8: r1 = <Set<WidgetState>>
    //     0xfa10a8: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f978] TypeArguments: <Set<WidgetState>>
    //     0xfa10ac: ldr             x1, [x1, #0x978]
    // 0xfa10b0: r0 = WidgetStatesController()
    //     0xfa10b0: bl              #0xf379b8  ; AllocateWidgetStatesControllerStub -> WidgetStatesController (size=0x2c)
    // 0xfa10b4: mov             x1, x0
    // 0xfa10b8: stur            x0, [fp, #-8]
    // 0xfa10bc: r0 = WidgetStatesController()
    //     0xfa10bc: bl              #0xf378e8  ; [package:flutter/src/widgets/widget_state.dart] WidgetStatesController::WidgetStatesController
    // 0xfa10c0: r1 = <_Day>
    //     0xfa10c0: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd35b8] TypeArguments: <_Day>
    //     0xfa10c4: ldr             x1, [x1, #0x5b8]
    // 0xfa10c8: r0 = _DayState()
    //     0xfa10c8: bl              #0xfa10e8  ; Allocate_DayStateStub -> _DayState (size=0x18)
    // 0xfa10cc: ldur            x1, [fp, #-8]
    // 0xfa10d0: StoreField: r0->field_13 = r1
    //     0xfa10d0: stur            w1, [x0, #0x13]
    // 0xfa10d4: LeaveFrame
    //     0xfa10d4: mov             SP, fp
    //     0xfa10d8: ldp             fp, lr, [SP], #0x10
    // 0xfa10dc: ret
    //     0xfa10dc: ret             
    // 0xfa10e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa10e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa10e4: b               #0xfa10a8
  }
}

// class id: 6490, size: 0x2c, field offset: 0xc
class _DayPicker extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa1058, size: 0x2c
    // 0xfa1058: EnterFrame
    //     0xfa1058: stp             fp, lr, [SP, #-0x10]!
    //     0xfa105c: mov             fp, SP
    // 0xfa1060: mov             x0, x1
    // 0xfa1064: r1 = <_DayPicker>
    //     0xfa1064: add             x1, PP, #0xd1, lsl #12  ; [pp+0xd1e58] TypeArguments: <_DayPicker>
    //     0xfa1068: ldr             x1, [x1, #0xe58]
    // 0xfa106c: r0 = _DayPickerState()
    //     0xfa106c: bl              #0xfa1084  ; Allocate_DayPickerStateStub -> _DayPickerState (size=0x18)
    // 0xfa1070: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa1074: StoreField: r0->field_13 = r1
    //     0xfa1074: stur            w1, [x0, #0x13]
    // 0xfa1078: LeaveFrame
    //     0xfa1078: mov             SP, fp
    //     0xfa107c: ldp             fp, lr, [SP], #0x10
    // 0xfa1080: ret
    //     0xfa1080: ret             
  }
}

// class id: 6491, size: 0x30, field offset: 0xc
class _MonthPicker extends StatefulWidget {

  _ _MonthPicker(/* No info */) {
    // ** addr: 0xded024, size: 0x13c
    // 0xded024: EnterFrame
    //     0xded024: stp             fp, lr, [SP, #-0x10]!
    //     0xded028: mov             fp, SP
    // 0xded02c: r4 = Instance_GregorianCalendarDelegate
    //     0xded02c: add             x4, PP, #0x28, lsl #12  ; [pp+0x28538] Obj!GregorianCalendarDelegate@129edd1
    //     0xded030: ldr             x4, [x4, #0x538]
    // 0xded034: mov             x0, x5
    // 0xded038: mov             x16, x7
    // 0xded03c: mov             x7, x1
    // 0xded040: mov             x1, x16
    // 0xded044: mov             x16, x6
    // 0xded048: mov             x6, x2
    // 0xded04c: mov             x2, x16
    // 0xded050: StoreField: r7->field_b = r0
    //     0xded050: stur            w0, [x7, #0xb]
    //     0xded054: ldurb           w16, [x7, #-1]
    //     0xded058: ldurb           w17, [x0, #-1]
    //     0xded05c: and             x16, x17, x16, lsr #2
    //     0xded060: tst             x16, HEAP, lsr #32
    //     0xded064: b.eq            #0xded06c
    //     0xded068: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xded06c: mov             x0, x6
    // 0xded070: StoreField: r7->field_f = r0
    //     0xded070: stur            w0, [x7, #0xf]
    //     0xded074: ldurb           w16, [x7, #-1]
    //     0xded078: ldurb           w17, [x0, #-1]
    //     0xded07c: and             x16, x17, x16, lsr #2
    //     0xded080: tst             x16, HEAP, lsr #32
    //     0xded084: b.eq            #0xded08c
    //     0xded088: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xded08c: mov             x0, x3
    // 0xded090: StoreField: r7->field_13 = r0
    //     0xded090: stur            w0, [x7, #0x13]
    //     0xded094: ldurb           w16, [x7, #-1]
    //     0xded098: ldurb           w17, [x0, #-1]
    //     0xded09c: and             x16, x17, x16, lsr #2
    //     0xded0a0: tst             x16, HEAP, lsr #32
    //     0xded0a4: b.eq            #0xded0ac
    //     0xded0a8: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xded0ac: mov             x0, x1
    // 0xded0b0: ArrayStore: r7[0] = r0  ; List_4
    //     0xded0b0: stur            w0, [x7, #0x17]
    //     0xded0b4: ldurb           w16, [x7, #-1]
    //     0xded0b8: ldurb           w17, [x0, #-1]
    //     0xded0bc: and             x16, x17, x16, lsr #2
    //     0xded0c0: tst             x16, HEAP, lsr #32
    //     0xded0c4: b.eq            #0xded0cc
    //     0xded0c8: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xded0cc: ldr             x0, [fp, #0x10]
    // 0xded0d0: StoreField: r7->field_1b = r0
    //     0xded0d0: stur            w0, [x7, #0x1b]
    //     0xded0d4: ldurb           w16, [x7, #-1]
    //     0xded0d8: ldurb           w17, [x0, #-1]
    //     0xded0dc: and             x16, x17, x16, lsr #2
    //     0xded0e0: tst             x16, HEAP, lsr #32
    //     0xded0e4: b.eq            #0xded0ec
    //     0xded0e8: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xded0ec: ldr             x0, [fp, #0x20]
    // 0xded0f0: StoreField: r7->field_1f = r0
    //     0xded0f0: stur            w0, [x7, #0x1f]
    //     0xded0f4: ldurb           w16, [x7, #-1]
    //     0xded0f8: ldurb           w17, [x0, #-1]
    //     0xded0fc: and             x16, x17, x16, lsr #2
    //     0xded100: tst             x16, HEAP, lsr #32
    //     0xded104: b.eq            #0xded10c
    //     0xded108: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xded10c: ldr             x0, [fp, #0x18]
    // 0xded110: StoreField: r7->field_23 = r0
    //     0xded110: stur            w0, [x7, #0x23]
    //     0xded114: ldurb           w16, [x7, #-1]
    //     0xded118: ldurb           w17, [x0, #-1]
    //     0xded11c: and             x16, x17, x16, lsr #2
    //     0xded120: tst             x16, HEAP, lsr #32
    //     0xded124: b.eq            #0xded12c
    //     0xded128: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xded12c: StoreField: r7->field_2b = r4
    //     0xded12c: stur            w4, [x7, #0x2b]
    // 0xded130: mov             x0, x2
    // 0xded134: StoreField: r7->field_7 = r0
    //     0xded134: stur            w0, [x7, #7]
    //     0xded138: ldurb           w16, [x7, #-1]
    //     0xded13c: ldurb           w17, [x0, #-1]
    //     0xded140: and             x16, x17, x16, lsr #2
    //     0xded144: tst             x16, HEAP, lsr #32
    //     0xded148: b.eq            #0xded150
    //     0xded14c: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xded150: r0 = Null
    //     0xded150: mov             x0, NULL
    // 0xded154: LeaveFrame
    //     0xded154: mov             SP, fp
    //     0xded158: ldp             fp, lr, [SP], #0x10
    // 0xded15c: ret
    //     0xded15c: ret             
  }
  _ createState(/* No info */) {
    // ** addr: 0xfa0f9c, size: 0x48
    // 0xfa0f9c: EnterFrame
    //     0xfa0f9c: stp             fp, lr, [SP, #-0x10]!
    //     0xfa0fa0: mov             fp, SP
    // 0xfa0fa4: AllocStack(0x8)
    //     0xfa0fa4: sub             SP, SP, #8
    // 0xfa0fa8: CheckStackOverflow
    //     0xfa0fa8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa0fac: cmp             SP, x16
    //     0xfa0fb0: b.ls            #0xfa0fdc
    // 0xfa0fb4: r1 = <_MonthPicker>
    //     0xfa0fb4: add             x1, PP, #0xcd, lsl #12  ; [pp+0xcd8b0] TypeArguments: <_MonthPicker>
    //     0xfa0fb8: ldr             x1, [x1, #0x8b0]
    // 0xfa0fbc: r0 = _MonthPickerState()
    //     0xfa0fbc: bl              #0xfa104c  ; Allocate_MonthPickerStateStub -> _MonthPickerState (size=0x38)
    // 0xfa0fc0: mov             x1, x0
    // 0xfa0fc4: stur            x0, [fp, #-8]
    // 0xfa0fc8: r0 = _MonthPickerState()
    //     0xfa0fc8: bl              #0xfa0fe4  ; [package:flutter/src/material/calendar_date_picker.dart] _MonthPickerState::_MonthPickerState
    // 0xfa0fcc: ldur            x0, [fp, #-8]
    // 0xfa0fd0: LeaveFrame
    //     0xfa0fd0: mov             SP, fp
    //     0xfa0fd4: ldp             fp, lr, [SP], #0x10
    // 0xfa0fd8: ret
    //     0xfa0fd8: ret             
    // 0xfa0fdc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa0fdc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa0fe0: b               #0xfa0fb4
  }
}

// class id: 6492, size: 0x18, field offset: 0xc
//   const constructor, 
class _DatePickerModeToggleButton extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa0f64, size: 0x2c
    // 0xfa0f64: EnterFrame
    //     0xfa0f64: stp             fp, lr, [SP, #-0x10]!
    //     0xfa0f68: mov             fp, SP
    // 0xfa0f6c: mov             x0, x1
    // 0xfa0f70: r1 = <_DatePickerModeToggleButton>
    //     0xfa0f70: add             x1, PP, #0xcd, lsl #12  ; [pp+0xcd8a8] TypeArguments: <_DatePickerModeToggleButton>
    //     0xfa0f74: ldr             x1, [x1, #0x8a8]
    // 0xfa0f78: r0 = _DatePickerModeToggleButtonState()
    //     0xfa0f78: bl              #0xfa0f90  ; Allocate_DatePickerModeToggleButtonStateStub -> _DatePickerModeToggleButtonState (size=0x20)
    // 0xfa0f7c: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa0f80: StoreField: r0->field_1b = r1
    //     0xfa0f80: stur            w1, [x0, #0x1b]
    // 0xfa0f84: LeaveFrame
    //     0xfa0f84: mov             SP, fp
    //     0xfa0f88: ldp             fp, lr, [SP], #0x10
    // 0xfa0f8c: ret
    //     0xfa0f8c: ret             
  }
}

// class id: 6493, size: 0x30, field offset: 0xc
class CalendarDatePicker extends StatefulWidget {

  _ CalendarDatePicker(/* No info */) {
    // ** addr: 0xd18cd0, size: 0x188
    // 0xd18cd0: EnterFrame
    //     0xd18cd0: stp             fp, lr, [SP, #-0x10]!
    //     0xd18cd4: mov             fp, SP
    // 0xd18cd8: AllocStack(0x28)
    //     0xd18cd8: sub             SP, SP, #0x28
    // 0xd18cdc: r8 = Instance_DatePickerMode
    //     0xd18cdc: add             x8, PP, #0x28, lsl #12  ; [pp+0x28528] Obj!DatePickerMode@12c5821
    //     0xd18ce0: ldr             x8, [x8, #0x528]
    // 0xd18ce4: r4 = Instance_GregorianCalendarDelegate
    //     0xd18ce4: add             x4, PP, #0x28, lsl #12  ; [pp+0x28538] Obj!GregorianCalendarDelegate@129edd1
    //     0xd18ce8: ldr             x4, [x4, #0x538]
    // 0xd18cec: stur            x1, [fp, #-8]
    // 0xd18cf0: mov             x16, x5
    // 0xd18cf4: mov             x5, x1
    // 0xd18cf8: mov             x1, x16
    // 0xd18cfc: mov             x16, x3
    // 0xd18d00: mov             x3, x5
    // 0xd18d04: mov             x5, x16
    // 0xd18d08: mov             x16, x6
    // 0xd18d0c: mov             x6, x3
    // 0xd18d10: mov             x3, x16
    // 0xd18d14: mov             x16, x2
    // 0xd18d18: mov             x2, x6
    // 0xd18d1c: mov             x6, x16
    // 0xd18d20: mov             x16, x7
    // 0xd18d24: mov             x7, x2
    // 0xd18d28: mov             x2, x16
    // 0xd18d2c: stur            x6, [fp, #-0x10]
    // 0xd18d30: stur            x5, [fp, #-0x18]
    // 0xd18d34: stur            x3, [fp, #-0x20]
    // 0xd18d38: stur            x2, [fp, #-0x28]
    // 0xd18d3c: CheckStackOverflow
    //     0xd18d3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd18d40: cmp             SP, x16
    //     0xd18d44: b.ls            #0xd18e50
    // 0xd18d48: ldr             x0, [fp, #0x10]
    // 0xd18d4c: StoreField: r7->field_1b = r0
    //     0xd18d4c: stur            w0, [x7, #0x1b]
    //     0xd18d50: ldurb           w16, [x7, #-1]
    //     0xd18d54: ldurb           w17, [x0, #-1]
    //     0xd18d58: and             x16, x17, x16, lsr #2
    //     0xd18d5c: tst             x16, HEAP, lsr #32
    //     0xd18d60: b.eq            #0xd18d68
    //     0xd18d64: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xd18d68: StoreField: r7->field_23 = r8
    //     0xd18d68: stur            w8, [x7, #0x23]
    // 0xd18d6c: StoreField: r7->field_2b = r4
    //     0xd18d6c: stur            w4, [x7, #0x2b]
    // 0xd18d70: cmp             w1, NULL
    // 0xd18d74: b.ne            #0xd18d84
    // 0xd18d78: mov             x2, x7
    // 0xd18d7c: r0 = Null
    //     0xd18d7c: mov             x0, NULL
    // 0xd18d80: b               #0xd18d8c
    // 0xd18d84: r0 = dateOnly()
    //     0xd18d84: bl              #0xd18a20  ; [package:flutter/src/material/date.dart] DateUtils::dateOnly
    // 0xd18d88: ldur            x2, [fp, #-8]
    // 0xd18d8c: StoreField: r2->field_b = r0
    //     0xd18d8c: stur            w0, [x2, #0xb]
    //     0xd18d90: ldurb           w16, [x2, #-1]
    //     0xd18d94: ldurb           w17, [x0, #-1]
    //     0xd18d98: and             x16, x17, x16, lsr #2
    //     0xd18d9c: tst             x16, HEAP, lsr #32
    //     0xd18da0: b.eq            #0xd18da8
    //     0xd18da4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd18da8: ldur            x1, [fp, #-0x18]
    // 0xd18dac: r0 = dateOnly()
    //     0xd18dac: bl              #0xd18a20  ; [package:flutter/src/material/date.dart] DateUtils::dateOnly
    // 0xd18db0: ldur            x2, [fp, #-8]
    // 0xd18db4: StoreField: r2->field_f = r0
    //     0xd18db4: stur            w0, [x2, #0xf]
    //     0xd18db8: ldurb           w16, [x2, #-1]
    //     0xd18dbc: ldurb           w17, [x0, #-1]
    //     0xd18dc0: and             x16, x17, x16, lsr #2
    //     0xd18dc4: tst             x16, HEAP, lsr #32
    //     0xd18dc8: b.eq            #0xd18dd0
    //     0xd18dcc: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd18dd0: ldur            x1, [fp, #-0x28]
    // 0xd18dd4: r0 = dateOnly()
    //     0xd18dd4: bl              #0xd18a20  ; [package:flutter/src/material/date.dart] DateUtils::dateOnly
    // 0xd18dd8: ldur            x2, [fp, #-8]
    // 0xd18ddc: StoreField: r2->field_13 = r0
    //     0xd18ddc: stur            w0, [x2, #0x13]
    //     0xd18de0: ldurb           w16, [x2, #-1]
    //     0xd18de4: ldurb           w17, [x0, #-1]
    //     0xd18de8: and             x16, x17, x16, lsr #2
    //     0xd18dec: tst             x16, HEAP, lsr #32
    //     0xd18df0: b.eq            #0xd18df8
    //     0xd18df4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd18df8: ldur            x1, [fp, #-0x10]
    // 0xd18dfc: r0 = dateOnly()
    //     0xd18dfc: bl              #0xd18a20  ; [package:flutter/src/material/date.dart] DateUtils::dateOnly
    // 0xd18e00: ldur            x1, [fp, #-8]
    // 0xd18e04: ArrayStore: r1[0] = r0  ; List_4
    //     0xd18e04: stur            w0, [x1, #0x17]
    //     0xd18e08: ldurb           w16, [x1, #-1]
    //     0xd18e0c: ldurb           w17, [x0, #-1]
    //     0xd18e10: and             x16, x17, x16, lsr #2
    //     0xd18e14: tst             x16, HEAP, lsr #32
    //     0xd18e18: b.eq            #0xd18e20
    //     0xd18e1c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd18e20: ldur            x0, [fp, #-0x20]
    // 0xd18e24: StoreField: r1->field_7 = r0
    //     0xd18e24: stur            w0, [x1, #7]
    //     0xd18e28: ldurb           w16, [x1, #-1]
    //     0xd18e2c: ldurb           w17, [x0, #-1]
    //     0xd18e30: and             x16, x17, x16, lsr #2
    //     0xd18e34: tst             x16, HEAP, lsr #32
    //     0xd18e38: b.eq            #0xd18e40
    //     0xd18e3c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd18e40: r0 = Null
    //     0xd18e40: mov             x0, NULL
    // 0xd18e44: LeaveFrame
    //     0xd18e44: mov             SP, fp
    //     0xd18e48: ldp             fp, lr, [SP], #0x10
    // 0xd18e4c: ret
    //     0xd18e4c: ret             
    // 0xd18e50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd18e50: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd18e54: b               #0xd18d48
  }
  _ createState(/* No info */) {
    // ** addr: 0xfa0e78, size: 0x48
    // 0xfa0e78: EnterFrame
    //     0xfa0e78: stp             fp, lr, [SP, #-0x10]!
    //     0xfa0e7c: mov             fp, SP
    // 0xfa0e80: AllocStack(0x8)
    //     0xfa0e80: sub             SP, SP, #8
    // 0xfa0e84: CheckStackOverflow
    //     0xfa0e84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa0e88: cmp             SP, x16
    //     0xfa0e8c: b.ls            #0xfa0eb8
    // 0xfa0e90: r1 = <CalendarDatePicker>
    //     0xfa0e90: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa4138] TypeArguments: <CalendarDatePicker>
    //     0xfa0e94: ldr             x1, [x1, #0x138]
    // 0xfa0e98: r0 = _CalendarDatePickerState()
    //     0xfa0e98: bl              #0xfa0f58  ; Allocate_CalendarDatePickerStateStub -> _CalendarDatePickerState (size=0x38)
    // 0xfa0e9c: mov             x1, x0
    // 0xfa0ea0: stur            x0, [fp, #-8]
    // 0xfa0ea4: r0 = _CalendarDatePickerState()
    //     0xfa0ea4: bl              #0xfa0ec0  ; [package:flutter/src/material/calendar_date_picker.dart] _CalendarDatePickerState::_CalendarDatePickerState
    // 0xfa0ea8: ldur            x0, [fp, #-8]
    // 0xfa0eac: LeaveFrame
    //     0xfa0eac: mov             SP, fp
    //     0xfa0eb0: ldp             fp, lr, [SP], #0x10
    // 0xfa0eb4: ret
    //     0xfa0eb4: ret             
    // 0xfa0eb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa0eb8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa0ebc: b               #0xfa0e90
  }
}

// class id: 6818, size: 0x18, field offset: 0x10
//   const constructor, 
class _FocusedDate extends InheritedWidget {

  _ updateShouldNotify(/* No info */) {
    // ** addr: 0xc00a50, size: 0xa4
    // 0xc00a50: EnterFrame
    //     0xc00a50: stp             fp, lr, [SP, #-0x10]!
    //     0xc00a54: mov             fp, SP
    // 0xc00a58: AllocStack(0x10)
    //     0xc00a58: sub             SP, SP, #0x10
    // 0xc00a5c: SetupParameters(_FocusedDate this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xc00a5c: mov             x4, x1
    //     0xc00a60: mov             x3, x2
    //     0xc00a64: stur            x1, [fp, #-8]
    //     0xc00a68: stur            x2, [fp, #-0x10]
    // 0xc00a6c: CheckStackOverflow
    //     0xc00a6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc00a70: cmp             SP, x16
    //     0xc00a74: b.ls            #0xc00aec
    // 0xc00a78: mov             x0, x3
    // 0xc00a7c: r2 = Null
    //     0xc00a7c: mov             x2, NULL
    // 0xc00a80: r1 = Null
    //     0xc00a80: mov             x1, NULL
    // 0xc00a84: r4 = 60
    //     0xc00a84: mov             x4, #0x3c
    // 0xc00a88: branchIfSmi(r0, 0xc00a94)
    //     0xc00a88: tbz             w0, #0, #0xc00a94
    // 0xc00a8c: r4 = LoadClassIdInstr(r0)
    //     0xc00a8c: ldur            x4, [x0, #-1]
    //     0xc00a90: ubfx            x4, x4, #0xc, #0x14
    // 0xc00a94: r17 = 6818
    //     0xc00a94: mov             x17, #0x1aa2
    // 0xc00a98: cmp             x4, x17
    // 0xc00a9c: b.eq            #0xc00ab4
    // 0xc00aa0: r8 = _FocusedDate
    //     0xc00aa0: add             x8, PP, #0xd1, lsl #12  ; [pp+0xd1e40] Type: _FocusedDate
    //     0xc00aa4: ldr             x8, [x8, #0xe40]
    // 0xc00aa8: r3 = Null
    //     0xc00aa8: add             x3, PP, #0xd1, lsl #12  ; [pp+0xd1e48] Null
    //     0xc00aac: ldr             x3, [x3, #0xe48]
    // 0xc00ab0: r0 = DefaultTypeTest()
    //     0xc00ab0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xc00ab4: ldur            x0, [fp, #-8]
    // 0xc00ab8: LoadField: r2 = r0->field_13
    //     0xc00ab8: ldur            w2, [x0, #0x13]
    // 0xc00abc: DecompressPointer r2
    //     0xc00abc: add             x2, x2, HEAP, lsl #32
    // 0xc00ac0: ldur            x0, [fp, #-0x10]
    // 0xc00ac4: LoadField: r3 = r0->field_13
    //     0xc00ac4: ldur            w3, [x0, #0x13]
    // 0xc00ac8: DecompressPointer r3
    //     0xc00ac8: add             x3, x3, HEAP, lsl #32
    // 0xc00acc: r1 = Instance_GregorianCalendarDelegate
    //     0xc00acc: add             x1, PP, #0x28, lsl #12  ; [pp+0x28538] Obj!GregorianCalendarDelegate@129edd1
    //     0xc00ad0: ldr             x1, [x1, #0x538]
    // 0xc00ad4: r0 = isSameDay()
    //     0xc00ad4: bl              #0xc00af4  ; [package:flutter/src/material/date.dart] CalendarDelegate::isSameDay
    // 0xc00ad8: eor             x1, x0, #0x10
    // 0xc00adc: mov             x0, x1
    // 0xc00ae0: LeaveFrame
    //     0xc00ae0: mov             SP, fp
    //     0xc00ae4: ldp             fp, lr, [SP], #0x10
    // 0xc00ae8: ret
    //     0xc00ae8: ret             
    // 0xc00aec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc00aec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc00af0: b               #0xc00a78
  }
  static _ maybeOf(/* No info */) {
    // ** addr: 0xef4444, size: 0x5c
    // 0xef4444: EnterFrame
    //     0xef4444: stp             fp, lr, [SP, #-0x10]!
    //     0xef4448: mov             fp, SP
    // 0xef444c: AllocStack(0x10)
    //     0xef444c: sub             SP, SP, #0x10
    // 0xef4450: CheckStackOverflow
    //     0xef4450: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef4454: cmp             SP, x16
    //     0xef4458: b.ls            #0xef4498
    // 0xef445c: r16 = <_FocusedDate>
    //     0xef445c: add             x16, PP, #0xd2, lsl #12  ; [pp+0xd2900] TypeArguments: <_FocusedDate>
    //     0xef4460: ldr             x16, [x16, #0x900]
    // 0xef4464: stp             x1, x16, [SP]
    // 0xef4468: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xef4468: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xef446c: r0 = dependOnInheritedWidgetOfExactType()
    //     0xef446c: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xef4470: cmp             w0, NULL
    // 0xef4474: b.ne            #0xef4480
    // 0xef4478: r0 = Null
    //     0xef4478: mov             x0, NULL
    // 0xef447c: b               #0xef448c
    // 0xef4480: LoadField: r1 = r0->field_13
    //     0xef4480: ldur            w1, [x0, #0x13]
    // 0xef4484: DecompressPointer r1
    //     0xef4484: add             x1, x1, HEAP, lsl #32
    // 0xef4488: mov             x0, x1
    // 0xef448c: LeaveFrame
    //     0xef448c: mov             SP, fp
    //     0xef4490: ldp             fp, lr, [SP], #0x10
    // 0xef4494: ret
    //     0xef4494: ret             
    // 0xef4498: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef4498: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef449c: b               #0xef445c
  }
}
