// lib: , url: package:flutter/src/material/popup_menu.dart

// class id: 1048928, size: 0x8
class :: {

  static _ showMenu(/* No info */) {
    // ** addr: 0xecdea8, size: 0x214
    // 0xecdea8: EnterFrame
    //     0xecdea8: stp             fp, lr, [SP, #-0x10]!
    //     0xecdeac: mov             fp, SP
    // 0xecdeb0: AllocStack(0x70)
    //     0xecdeb0: sub             SP, SP, #0x70
    // 0xecdeb4: SetupParameters(dynamic _ /* r0, fp-0x20 */, dynamic _ /* r6, fp-0x18 */, dynamic _ /* r7, fp-0x10 */)
    //     0xecdeb4: ldur            w0, [x4, #0x13]
    //     0xecdeb8: sub             x1, x0, #6
    //     0xecdebc: add             x0, fp, w1, sxtw #2
    //     0xecdec0: ldr             x0, [x0, #0x20]
    //     0xecdec4: stur            x0, [fp, #-0x20]
    //     0xecdec8: add             x6, fp, w1, sxtw #2
    //     0xecdecc: ldr             x6, [x6, #0x18]
    //     0xecded0: stur            x6, [fp, #-0x18]
    //     0xecded4: add             x7, fp, w1, sxtw #2
    //     0xecded8: ldr             x7, [x7, #0x10]
    //     0xecdedc: stur            x7, [fp, #-0x10]
    //     0xecdee0: ldur            w1, [x4, #0xf]
    //     0xecdee4: cbnz            w1, #0xecdef0
    //     0xecdee8: mov             x2, NULL
    //     0xecdeec: b               #0xecdefc
    //     0xecdef0: ldur            w1, [x4, #0x17]
    //     0xecdef4: add             x2, fp, w1, sxtw #2
    //     0xecdef8: ldr             x2, [x2, #0x10]
    //     0xecdefc: stur            x2, [fp, #-8]
    // 0xecdf00: CheckStackOverflow
    //     0xecdf00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xecdf04: cmp             SP, x16
    //     0xecdf08: b.ls            #0xece0a8
    // 0xecdf0c: mov             x1, x0
    // 0xecdf10: r0 = of()
    //     0xecdf10: bl              #0xd0bbf8  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0xecdf14: r1 = LoadClassIdInstr(r0)
    //     0xecdf14: ldur            x1, [x0, #-1]
    //     0xecdf18: ubfx            x1, x1, #0xc, #0x14
    // 0xecdf1c: mov             x16, x0
    // 0xecdf20: mov             x0, x1
    // 0xecdf24: mov             x1, x16
    // 0xecdf28: r0 = GDT[cid_x0 + 0x15d4d]()
    //     0xecdf28: mov             x17, #0x5d4d
    //     0xecdf2c: movk            x17, #1, lsl #16
    //     0xecdf30: add             lr, x0, x17
    //     0xecdf34: ldr             lr, [x21, lr, lsl #3]
    //     0xecdf38: blr             lr
    // 0xecdf3c: ldur            x6, [fp, #-0x18]
    // 0xecdf40: stur            x0, [fp, #-0x28]
    // 0xecdf44: LoadField: r1 = r6->field_b
    //     0xecdf44: ldur            w1, [x6, #0xb]
    // 0xecdf48: r2 = LoadInt32Instr(r1)
    //     0xecdf48: sbfx            x2, x1, #1, #0x1f
    // 0xecdf4c: r1 = <GlobalKey<State<StatefulWidget>>>
    //     0xecdf4c: add             x1, PP, #0x8a, lsl #12  ; [pp+0x8ad68] TypeArguments: <GlobalKey<State<StatefulWidget>>>
    //     0xecdf50: ldr             x1, [x1, #0xd68]
    // 0xecdf54: r0 = _GrowableList()
    //     0xecdf54: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xecdf58: stur            x0, [fp, #-0x48]
    // 0xecdf5c: LoadField: r1 = r0->field_b
    //     0xecdf5c: ldur            w1, [x0, #0xb]
    // 0xecdf60: r2 = LoadInt32Instr(r1)
    //     0xecdf60: sbfx            x2, x1, #1, #0x1f
    // 0xecdf64: stur            x2, [fp, #-0x40]
    // 0xecdf68: LoadField: r3 = r0->field_f
    //     0xecdf68: ldur            w3, [x0, #0xf]
    // 0xecdf6c: DecompressPointer r3
    //     0xecdf6c: add             x3, x3, HEAP, lsl #32
    // 0xecdf70: stur            x3, [fp, #-0x38]
    // 0xecdf74: r4 = 0
    //     0xecdf74: mov             x4, #0
    // 0xecdf78: stur            x4, [fp, #-0x30]
    // 0xecdf7c: CheckStackOverflow
    //     0xecdf7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xecdf80: cmp             SP, x16
    //     0xecdf84: b.ls            #0xece0b0
    // 0xecdf88: cmp             x4, x2
    // 0xecdf8c: b.ge            #0xecdfdc
    // 0xecdf90: r1 = <State<StatefulWidget>>
    //     0xecdf90: ldr             x1, [PP, #0x4df8]  ; [pp+0x4df8] TypeArguments: <State<StatefulWidget>>
    // 0xecdf94: r0 = LabeledGlobalKey()
    //     0xecdf94: bl              #0x856cf8  ; AllocateLabeledGlobalKeyStub -> LabeledGlobalKey<X0 bound State> (size=0x10)
    // 0xecdf98: ldur            x1, [fp, #-0x38]
    // 0xecdf9c: ldur            x2, [fp, #-0x30]
    // 0xecdfa0: ArrayStore: r1[r2] = r0  ; List_4
    //     0xecdfa0: add             x25, x1, x2, lsl #2
    //     0xecdfa4: add             x25, x25, #0xf
    //     0xecdfa8: str             w0, [x25]
    //     0xecdfac: tbz             w0, #0, #0xecdfc8
    //     0xecdfb0: ldurb           w16, [x1, #-1]
    //     0xecdfb4: ldurb           w17, [x0, #-1]
    //     0xecdfb8: and             x16, x17, x16, lsr #2
    //     0xecdfbc: tst             x16, HEAP, lsr #32
    //     0xecdfc0: b.eq            #0xecdfc8
    //     0xecdfc4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xecdfc8: add             x4, x2, #1
    // 0xecdfcc: ldur            x0, [fp, #-0x48]
    // 0xecdfd0: ldur            x3, [fp, #-0x38]
    // 0xecdfd4: ldur            x2, [fp, #-0x40]
    // 0xecdfd8: b               #0xecdf78
    // 0xecdfdc: r16 = false
    //     0xecdfdc: add             x16, NULL, #0x30  ; false
    // 0xecdfe0: str             x16, [SP]
    // 0xecdfe4: ldur            x1, [fp, #-0x20]
    // 0xecdfe8: r4 = const [0, 0x2, 0x1, 0x1, rootNavigator, 0x1, null]
    //     0xecdfe8: add             x4, PP, #0x15, lsl #12  ; [pp+0x150a0] List(7) [0, 0x2, 0x1, 0x1, "rootNavigator", 0x1, Null]
    //     0xecdfec: ldr             x4, [x4, #0xa0]
    // 0xecdff0: r0 = of()
    //     0xecdff0: bl              #0xb35e68  ; [package:flutter/src/widgets/navigator.dart] Navigator::of
    // 0xecdff4: ldur            x1, [fp, #-0x20]
    // 0xecdff8: stur            x0, [fp, #-0x38]
    // 0xecdffc: r0 = of()
    //     0xecdffc: bl              #0xd0bbf8  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0xece000: r1 = LoadClassIdInstr(r0)
    //     0xece000: ldur            x1, [x0, #-1]
    //     0xece004: ubfx            x1, x1, #0xc, #0x14
    // 0xece008: mov             x16, x0
    // 0xece00c: mov             x0, x1
    // 0xece010: mov             x1, x16
    // 0xece014: r0 = GDT[cid_x0 + 0x16331]()
    //     0xece014: mov             x17, #0x6331
    //     0xece018: movk            x17, #1, lsl #16
    //     0xece01c: add             lr, x0, x17
    //     0xece020: ldr             lr, [x21, lr, lsl #3]
    //     0xece024: blr             lr
    // 0xece028: mov             x3, x0
    // 0xece02c: ldur            x0, [fp, #-0x38]
    // 0xece030: stur            x3, [fp, #-0x50]
    // 0xece034: LoadField: r2 = r0->field_f
    //     0xece034: ldur            w2, [x0, #0xf]
    // 0xece038: DecompressPointer r2
    //     0xece038: add             x2, x2, HEAP, lsl #32
    // 0xece03c: cmp             w2, NULL
    // 0xece040: b.eq            #0xece0b8
    // 0xece044: ldur            x1, [fp, #-0x20]
    // 0xece048: r0 = capture()
    //     0xece048: bl              #0x8556d4  ; [package:flutter/src/widgets/inherited_theme.dart] InheritedTheme::capture
    // 0xece04c: ldur            x1, [fp, #-8]
    // 0xece050: stur            x0, [fp, #-0x20]
    // 0xece054: r0 = _PopupMenuRoute()
    //     0xece054: bl              #0xece21c  ; Allocate_PopupMenuRouteStub -> _PopupMenuRoute<X0> (size=0xe4)
    // 0xece058: stur            x0, [fp, #-0x58]
    // 0xece05c: ldur            x16, [fp, #-0x28]
    // 0xece060: str             x16, [SP]
    // 0xece064: mov             x1, x0
    // 0xece068: ldur            x2, [fp, #-0x50]
    // 0xece06c: ldur            x3, [fp, #-0x20]
    // 0xece070: ldur            x5, [fp, #-0x48]
    // 0xece074: ldur            x6, [fp, #-0x18]
    // 0xece078: ldur            x7, [fp, #-0x10]
    // 0xece07c: r0 = _PopupMenuRoute()
    //     0xece07c: bl              #0xece0bc  ; [package:flutter/src/material/popup_menu.dart] _PopupMenuRoute::_PopupMenuRoute
    // 0xece080: ldur            x16, [fp, #-8]
    // 0xece084: ldur            lr, [fp, #-0x38]
    // 0xece088: stp             lr, x16, [SP, #8]
    // 0xece08c: ldur            x16, [fp, #-0x58]
    // 0xece090: str             x16, [SP]
    // 0xece094: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xece094: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xece098: r0 = push()
    //     0xece098: bl              #0x9ec7a0  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::push
    // 0xece09c: LeaveFrame
    //     0xece09c: mov             SP, fp
    //     0xece0a0: ldp             fp, lr, [SP], #0x10
    // 0xece0a4: ret
    //     0xece0a4: ret             
    // 0xece0a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xece0a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xece0ac: b               #0xecdf0c
    // 0xece0b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xece0b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xece0b4: b               #0xecdf88
    // 0xece0b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xece0b8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2644, size: 0xe4, field offset: 0x98
class _PopupMenuRoute<X0> extends PopupRoute<X0> {

  _ createAnimation(/* No info */) {
    // ** addr: 0xba5a20, size: 0xb0
    // 0xba5a20: EnterFrame
    //     0xba5a20: stp             fp, lr, [SP, #-0x10]!
    //     0xba5a24: mov             fp, SP
    // 0xba5a28: AllocStack(0x20)
    //     0xba5a28: sub             SP, SP, #0x20
    // 0xba5a2c: SetupParameters(_PopupMenuRoute<X0> this /* r1 => r0, fp-0x8 */)
    //     0xba5a2c: mov             x0, x1
    //     0xba5a30: stur            x1, [fp, #-8]
    // 0xba5a34: CheckStackOverflow
    //     0xba5a34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba5a38: cmp             SP, x16
    //     0xba5a3c: b.ls            #0xba5ac8
    // 0xba5a40: LoadField: r1 = r0->field_db
    //     0xba5a40: ldur            w1, [x0, #0xdb]
    // 0xba5a44: DecompressPointer r1
    //     0xba5a44: add             x1, x1, HEAP, lsl #32
    // 0xba5a48: cmp             w1, NULL
    // 0xba5a4c: b.ne            #0xba5ab8
    // 0xba5a50: mov             x1, x0
    // 0xba5a54: r0 = createAnimation()
    //     0xba5a54: bl              #0xba5ad0  ; [package:flutter/src/widgets/routes.dart] TransitionRoute::createAnimation
    // 0xba5a58: r1 = <double>
    //     0xba5a58: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xba5a5c: stur            x0, [fp, #-0x10]
    // 0xba5a60: r0 = CurvedAnimation()
    //     0xba5a60: bl              #0x915e4c  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0xba5a64: stur            x0, [fp, #-0x18]
    // 0xba5a68: r16 = Instance_Interval
    //     0xba5a68: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8fad0] Obj!Interval@129f9b1
    //     0xba5a6c: ldr             x16, [x16, #0xad0]
    // 0xba5a70: str             x16, [SP]
    // 0xba5a74: mov             x1, x0
    // 0xba5a78: ldur            x3, [fp, #-0x10]
    // 0xba5a7c: r2 = Instance__Linear
    //     0xba5a7c: ldr             x2, [PP, #0x5168]  ; [pp+0x5168] Obj!_Linear@129fef1
    // 0xba5a80: r4 = const [0, 0x4, 0x1, 0x3, reverseCurve, 0x3, null]
    //     0xba5a80: add             x4, PP, #0x16, lsl #12  ; [pp+0x16dc0] List(7) [0, 0x4, 0x1, 0x3, "reverseCurve", 0x3, Null]
    //     0xba5a84: ldr             x4, [x4, #0xdc0]
    // 0xba5a88: r0 = CurvedAnimation()
    //     0xba5a88: bl              #0x915be4  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0xba5a8c: ldur            x0, [fp, #-0x18]
    // 0xba5a90: ldur            x2, [fp, #-8]
    // 0xba5a94: StoreField: r2->field_db = r0
    //     0xba5a94: stur            w0, [x2, #0xdb]
    //     0xba5a98: ldurb           w16, [x2, #-1]
    //     0xba5a9c: ldurb           w17, [x0, #-1]
    //     0xba5aa0: and             x16, x17, x16, lsr #2
    //     0xba5aa4: tst             x16, HEAP, lsr #32
    //     0xba5aa8: b.eq            #0xba5ab0
    //     0xba5aac: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xba5ab0: ldur            x0, [fp, #-0x18]
    // 0xba5ab4: b               #0xba5abc
    // 0xba5ab8: mov             x0, x1
    // 0xba5abc: LeaveFrame
    //     0xba5abc: mov             SP, fp
    //     0xba5ac0: ldp             fp, lr, [SP], #0x10
    // 0xba5ac4: ret
    //     0xba5ac4: ret             
    // 0xba5ac8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba5ac8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba5acc: b               #0xba5a40
  }
  _ dispose(/* No info */) {
    // ** addr: 0xbb1324, size: 0x54
    // 0xbb1324: EnterFrame
    //     0xbb1324: stp             fp, lr, [SP, #-0x10]!
    //     0xbb1328: mov             fp, SP
    // 0xbb132c: AllocStack(0x8)
    //     0xbb132c: sub             SP, SP, #8
    // 0xbb1330: SetupParameters(_PopupMenuRoute<X0> this /* r1 => r0, fp-0x8 */)
    //     0xbb1330: mov             x0, x1
    //     0xbb1334: stur            x1, [fp, #-8]
    // 0xbb1338: CheckStackOverflow
    //     0xbb1338: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbb133c: cmp             SP, x16
    //     0xbb1340: b.ls            #0xbb1370
    // 0xbb1344: LoadField: r1 = r0->field_db
    //     0xbb1344: ldur            w1, [x0, #0xdb]
    // 0xbb1348: DecompressPointer r1
    //     0xbb1348: add             x1, x1, HEAP, lsl #32
    // 0xbb134c: cmp             w1, NULL
    // 0xbb1350: b.eq            #0xbb1358
    // 0xbb1354: r0 = dispose()
    //     0xbb1354: bl              #0xb29014  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::dispose
    // 0xbb1358: ldur            x1, [fp, #-8]
    // 0xbb135c: r0 = dispose()
    //     0xbb135c: bl              #0xbb10c4  ; [package:flutter/src/widgets/routes.dart] TransitionRoute::dispose
    // 0xbb1360: r0 = Null
    //     0xbb1360: mov             x0, NULL
    // 0xbb1364: LeaveFrame
    //     0xbb1364: mov             SP, fp
    //     0xbb1368: ldp             fp, lr, [SP], #0x10
    // 0xbb136c: ret
    //     0xbb136c: ret             
    // 0xbb1370: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbb1370: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbb1374: b               #0xbb1344
  }
  _ _PopupMenuRoute(/* No info */) {
    // ** addr: 0xece0bc, size: 0x160
    // 0xece0bc: EnterFrame
    //     0xece0bc: stp             fp, lr, [SP, #-0x10]!
    //     0xece0c0: mov             fp, SP
    // 0xece0c4: AllocStack(0x8)
    //     0xece0c4: sub             SP, SP, #8
    // 0xece0c8: r8 = Instance_BoxConstraints
    //     0xece0c8: add             x8, PP, #0xd2, lsl #12  ; [pp+0xd2eb0] Obj!BoxConstraints@129c351
    //     0xece0cc: ldr             x8, [x8, #0xeb0]
    // 0xece0d0: r4 = Instance_Clip
    //     0xece0d0: add             x4, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xece0d4: ldr             x4, [x4, #0x840]
    // 0xece0d8: stur            x1, [fp, #-8]
    // 0xece0dc: mov             x16, x6
    // 0xece0e0: mov             x6, x1
    // 0xece0e4: mov             x1, x16
    // 0xece0e8: mov             x16, x5
    // 0xece0ec: mov             x5, x2
    // 0xece0f0: mov             x2, x16
    // 0xece0f4: mov             x0, x7
    // 0xece0f8: CheckStackOverflow
    //     0xece0f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xece0fc: cmp             SP, x16
    //     0xece100: b.ls            #0xece214
    // 0xece104: StoreField: r6->field_97 = r0
    //     0xece104: stur            w0, [x6, #0x97]
    //     0xece108: ldurb           w16, [x6, #-1]
    //     0xece10c: ldurb           w17, [x0, #-1]
    //     0xece110: and             x16, x17, x16, lsr #2
    //     0xece114: tst             x16, HEAP, lsr #32
    //     0xece118: b.eq            #0xece120
    //     0xece11c: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0xece120: mov             x0, x1
    // 0xece124: StoreField: r6->field_9f = r0
    //     0xece124: stur            w0, [x6, #0x9f]
    //     0xece128: ldurb           w16, [x6, #-1]
    //     0xece12c: ldurb           w17, [x0, #-1]
    //     0xece130: and             x16, x17, x16, lsr #2
    //     0xece134: tst             x16, HEAP, lsr #32
    //     0xece138: b.eq            #0xece140
    //     0xece13c: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0xece140: mov             x0, x2
    // 0xece144: StoreField: r6->field_a3 = r0
    //     0xece144: stur            w0, [x6, #0xa3]
    //     0xece148: ldurb           w16, [x6, #-1]
    //     0xece14c: ldurb           w17, [x0, #-1]
    //     0xece150: and             x16, x17, x16, lsr #2
    //     0xece154: tst             x16, HEAP, lsr #32
    //     0xece158: b.eq            #0xece160
    //     0xece15c: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0xece160: mov             x0, x5
    // 0xece164: StoreField: r6->field_df = r0
    //     0xece164: stur            w0, [x6, #0xdf]
    //     0xece168: ldurb           w16, [x6, #-1]
    //     0xece16c: ldurb           w17, [x0, #-1]
    //     0xece170: and             x16, x17, x16, lsr #2
    //     0xece174: tst             x16, HEAP, lsr #32
    //     0xece178: b.eq            #0xece180
    //     0xece17c: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0xece180: ldr             x0, [fp, #0x10]
    // 0xece184: StoreField: r6->field_bb = r0
    //     0xece184: stur            w0, [x6, #0xbb]
    //     0xece188: ldurb           w16, [x6, #-1]
    //     0xece18c: ldurb           w17, [x0, #-1]
    //     0xece190: and             x16, x17, x16, lsr #2
    //     0xece194: tst             x16, HEAP, lsr #32
    //     0xece198: b.eq            #0xece1a0
    //     0xece19c: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0xece1a0: mov             x0, x3
    // 0xece1a4: StoreField: r6->field_cb = r0
    //     0xece1a4: stur            w0, [x6, #0xcb]
    //     0xece1a8: ldurb           w16, [x6, #-1]
    //     0xece1ac: ldurb           w17, [x0, #-1]
    //     0xece1b0: and             x16, x17, x16, lsr #2
    //     0xece1b4: tst             x16, HEAP, lsr #32
    //     0xece1b8: b.eq            #0xece1c0
    //     0xece1bc: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0xece1c0: StoreField: r6->field_cf = r8
    //     0xece1c0: stur            w8, [x6, #0xcf]
    // 0xece1c4: StoreField: r6->field_d3 = r4
    //     0xece1c4: stur            w4, [x6, #0xd3]
    // 0xece1c8: LoadField: r2 = r1->field_b
    //     0xece1c8: ldur            w2, [x1, #0xb]
    // 0xece1cc: r1 = <Size?>
    //     0xece1cc: add             x1, PP, #0x26, lsl #12  ; [pp+0x26aa8] TypeArguments: <Size?>
    //     0xece1d0: ldr             x1, [x1, #0xaa8]
    // 0xece1d4: r0 = AllocateArray()
    //     0xece1d4: bl              #0x13df928  ; AllocateArrayStub
    // 0xece1d8: ldur            x1, [fp, #-8]
    // 0xece1dc: StoreField: r1->field_a7 = r0
    //     0xece1dc: stur            w0, [x1, #0xa7]
    //     0xece1e0: ldurb           w16, [x1, #-1]
    //     0xece1e4: ldurb           w17, [x0, #-1]
    //     0xece1e8: and             x16, x17, x16, lsr #2
    //     0xece1ec: tst             x16, HEAP, lsr #32
    //     0xece1f0: b.eq            #0xece1f8
    //     0xece1f4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xece1f8: r2 = Null
    //     0xece1f8: mov             x2, NULL
    // 0xece1fc: r3 = Instance_TraversalEdgeBehavior
    //     0xece1fc: ldr             x3, [PP, #0x2088]  ; [pp+0x2088] Obj!TraversalEdgeBehavior@12c3121
    // 0xece200: r0 = ModalRoute()
    //     0xece200: bl              #0x8e04e0  ; [package:flutter/src/widgets/routes.dart] ModalRoute::ModalRoute
    // 0xece204: r0 = Null
    //     0xece204: mov             x0, NULL
    // 0xece208: LeaveFrame
    //     0xece208: mov             SP, fp
    //     0xece20c: ldp             fp, lr, [SP], #0x10
    // 0xece210: ret
    //     0xece210: ret             
    // 0xece214: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xece214: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xece218: b               #0xece104
  }
  _ buildPage(/* No info */) {
    // ** addr: 0x11035d0, size: 0x150
    // 0x11035d0: EnterFrame
    //     0x11035d0: stp             fp, lr, [SP, #-0x10]!
    //     0x11035d4: mov             fp, SP
    // 0x11035d8: AllocStack(0x48)
    //     0x11035d8: sub             SP, SP, #0x48
    // 0x11035dc: SetupParameters(_PopupMenuRoute<X0> this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0x11035dc: mov             x0, x1
    //     0x11035e0: stur            x1, [fp, #-8]
    //     0x11035e4: mov             x1, x2
    //     0x11035e8: stur            x2, [fp, #-0x10]
    // 0x11035ec: CheckStackOverflow
    //     0x11035ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11035f0: cmp             SP, x16
    //     0x11035f4: b.ls            #0x1103718
    // 0x11035f8: r1 = 3
    //     0x11035f8: mov             x1, #3
    // 0x11035fc: r0 = AllocateContext()
    //     0x11035fc: bl              #0x13de838  ; AllocateContextStub
    // 0x1103600: mov             x2, x0
    // 0x1103604: ldur            x0, [fp, #-8]
    // 0x1103608: stur            x2, [fp, #-0x28]
    // 0x110360c: StoreField: r2->field_f = r0
    //     0x110360c: stur            w0, [x2, #0xf]
    // 0x1103610: LoadField: r3 = r0->field_a3
    //     0x1103610: ldur            w3, [x0, #0xa3]
    // 0x1103614: DecompressPointer r3
    //     0x1103614: add             x3, x3, HEAP, lsl #32
    // 0x1103618: stur            x3, [fp, #-0x20]
    // 0x110361c: LoadField: r4 = r0->field_bb
    //     0x110361c: ldur            w4, [x0, #0xbb]
    // 0x1103620: DecompressPointer r4
    //     0x1103620: add             x4, x4, HEAP, lsl #32
    // 0x1103624: stur            x4, [fp, #-0x18]
    // 0x1103628: LoadField: r1 = r0->field_7
    //     0x1103628: ldur            w1, [x0, #7]
    // 0x110362c: DecompressPointer r1
    //     0x110362c: add             x1, x1, HEAP, lsl #32
    // 0x1103630: r0 = _PopupMenu()
    //     0x1103630: bl              #0x1103720  ; Allocate_PopupMenuStub -> _PopupMenu<X0> (size=0x24)
    // 0x1103634: mov             x1, x0
    // 0x1103638: ldur            x0, [fp, #-0x20]
    // 0x110363c: StoreField: r1->field_f = r0
    //     0x110363c: stur            w0, [x1, #0xf]
    // 0x1103640: ldur            x0, [fp, #-8]
    // 0x1103644: StoreField: r1->field_13 = r0
    //     0x1103644: stur            w0, [x1, #0x13]
    // 0x1103648: ldur            x0, [fp, #-0x18]
    // 0x110364c: ArrayStore: r1[0] = r0  ; List_4
    //     0x110364c: stur            w0, [x1, #0x17]
    // 0x1103650: r0 = Instance_BoxConstraints
    //     0x1103650: add             x0, PP, #0xd2, lsl #12  ; [pp+0xd2eb0] Obj!BoxConstraints@129c351
    //     0x1103654: ldr             x0, [x0, #0xeb0]
    // 0x1103658: StoreField: r1->field_1b = r0
    //     0x1103658: stur            w0, [x1, #0x1b]
    // 0x110365c: r0 = Instance_Clip
    //     0x110365c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0x1103660: ldr             x0, [x0, #0x840]
    // 0x1103664: StoreField: r1->field_1f = r0
    //     0x1103664: stur            w0, [x1, #0x1f]
    // 0x1103668: ldur            x2, [fp, #-0x28]
    // 0x110366c: StoreField: r2->field_13 = r1
    //     0x110366c: stur            w1, [x2, #0x13]
    // 0x1103670: ldur            x1, [fp, #-0x10]
    // 0x1103674: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x1103674: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x1103678: r0 = _of()
    //     0x1103678: bl              #0x8651cc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::_of
    // 0x110367c: ldur            x2, [fp, #-0x28]
    // 0x1103680: ArrayStore: r2[0] = r0  ; List_4
    //     0x1103680: stur            w0, [x2, #0x17]
    //     0x1103684: ldurb           w16, [x2, #-1]
    //     0x1103688: ldurb           w17, [x0, #-1]
    //     0x110368c: and             x16, x17, x16, lsr #2
    //     0x1103690: tst             x16, HEAP, lsr #32
    //     0x1103694: b.eq            #0x110369c
    //     0x1103698: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x110369c: r1 = Function '<anonymous closure>':.
    //     0x110369c: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4208] AnonymousClosure: (0x110372c), in [package:flutter/src/material/popup_menu.dart] _PopupMenuRoute::buildPage (0x11035d0)
    //     0x11036a0: ldr             x1, [x1, #0x208]
    // 0x11036a4: r0 = AllocateClosure()
    //     0x11036a4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11036a8: r1 = <BoxConstraints>
    //     0x11036a8: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c3f0] TypeArguments: <BoxConstraints>
    //     0x11036ac: ldr             x1, [x1, #0x3f0]
    // 0x11036b0: stur            x0, [fp, #-8]
    // 0x11036b4: r0 = LayoutBuilder()
    //     0x11036b4: bl              #0xd15d50  ; AllocateLayoutBuilderStub -> LayoutBuilder (size=0x14)
    // 0x11036b8: mov             x2, x0
    // 0x11036bc: ldur            x0, [fp, #-8]
    // 0x11036c0: stur            x2, [fp, #-0x18]
    // 0x11036c4: StoreField: r2->field_f = r0
    //     0x11036c4: stur            w0, [x2, #0xf]
    // 0x11036c8: r1 = <_MediaQueryAspect>
    //     0x11036c8: add             x1, PP, #0x12, lsl #12  ; [pp+0x12828] TypeArguments: <_MediaQueryAspect>
    //     0x11036cc: ldr             x1, [x1, #0x828]
    // 0x11036d0: r0 = MediaQuery()
    //     0x11036d0: bl              #0xd0af24  ; AllocateMediaQueryStub -> MediaQuery (size=0x18)
    // 0x11036d4: stur            x0, [fp, #-8]
    // 0x11036d8: r16 = true
    //     0x11036d8: add             x16, NULL, #0x20  ; true
    // 0x11036dc: r30 = true
    //     0x11036dc: add             lr, NULL, #0x20  ; true
    // 0x11036e0: stp             lr, x16, [SP, #0x10]
    // 0x11036e4: r16 = true
    //     0x11036e4: add             x16, NULL, #0x20  ; true
    // 0x11036e8: r30 = true
    //     0x11036e8: add             lr, NULL, #0x20  ; true
    // 0x11036ec: stp             lr, x16, [SP]
    // 0x11036f0: mov             x1, x0
    // 0x11036f4: ldur            x2, [fp, #-0x18]
    // 0x11036f8: ldur            x3, [fp, #-0x10]
    // 0x11036fc: r4 = const [0, 0x7, 0x4, 0x3, removeBottom, 0x4, removeLeft, 0x5, removeRight, 0x6, removeTop, 0x3, null]
    //     0x11036fc: add             x4, PP, #0xcd, lsl #12  ; [pp+0xcd560] List(13) [0, 0x7, 0x4, 0x3, "removeBottom", 0x4, "removeLeft", 0x5, "removeRight", 0x6, "removeTop", 0x3, Null]
    //     0x1103700: ldr             x4, [x4, #0x560]
    // 0x1103704: r0 = MediaQuery.removePadding()
    //     0x1103704: bl              #0xd0a5a0  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::MediaQuery.removePadding
    // 0x1103708: ldur            x0, [fp, #-8]
    // 0x110370c: LeaveFrame
    //     0x110370c: mov             SP, fp
    //     0x1103710: ldp             fp, lr, [SP], #0x10
    // 0x1103714: ret
    //     0x1103714: ret             
    // 0x1103718: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1103718: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x110371c: b               #0x11035f8
  }
  [closure] CustomSingleChildLayout <anonymous closure>(dynamic, BuildContext, BoxConstraints) {
    // ** addr: 0x110372c, size: 0x10c
    // 0x110372c: EnterFrame
    //     0x110372c: stp             fp, lr, [SP, #-0x10]!
    //     0x1103730: mov             fp, SP
    // 0x1103734: AllocStack(0x38)
    //     0x1103734: sub             SP, SP, #0x38
    // 0x1103738: SetupParameters([dynamic _ /* r0 */])
    //     0x1103738: ldr             x0, [fp, #0x20]
    //     0x110373c: ldur            w2, [x0, #0x17]
    //     0x1103740: add             x2, x2, HEAP, lsl #32
    //     0x1103744: stur            x2, [fp, #-0x18]
    // 0x1103748: CheckStackOverflow
    //     0x1103748: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x110374c: cmp             SP, x16
    //     0x1103750: b.ls            #0x1103830
    // 0x1103754: LoadField: r0 = r2->field_f
    //     0x1103754: ldur            w0, [x2, #0xf]
    // 0x1103758: DecompressPointer r0
    //     0x1103758: add             x0, x0, HEAP, lsl #32
    // 0x110375c: LoadField: r3 = r0->field_97
    //     0x110375c: ldur            w3, [x0, #0x97]
    // 0x1103760: DecompressPointer r3
    //     0x1103760: add             x3, x3, HEAP, lsl #32
    // 0x1103764: stur            x3, [fp, #-0x10]
    // 0x1103768: LoadField: r4 = r0->field_a7
    //     0x1103768: ldur            w4, [x0, #0xa7]
    // 0x110376c: DecompressPointer r4
    //     0x110376c: add             x4, x4, HEAP, lsl #32
    // 0x1103770: ldr             x1, [fp, #0x18]
    // 0x1103774: stur            x4, [fp, #-8]
    // 0x1103778: r0 = of()
    //     0x1103778: bl              #0x87371c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0x110377c: mov             x3, x0
    // 0x1103780: ldur            x0, [fp, #-0x18]
    // 0x1103784: stur            x3, [fp, #-0x28]
    // 0x1103788: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x1103788: ldur            w2, [x0, #0x17]
    // 0x110378c: DecompressPointer r2
    //     0x110378c: add             x2, x2, HEAP, lsl #32
    // 0x1103790: LoadField: r4 = r2->field_27
    //     0x1103790: ldur            w4, [x2, #0x27]
    // 0x1103794: DecompressPointer r4
    //     0x1103794: add             x4, x4, HEAP, lsl #32
    // 0x1103798: stur            x4, [fp, #-0x20]
    // 0x110379c: LoadField: r1 = r0->field_f
    //     0x110379c: ldur            w1, [x0, #0xf]
    // 0x11037a0: DecompressPointer r1
    //     0x11037a0: add             x1, x1, HEAP, lsl #32
    // 0x11037a4: r0 = _avoidBounds()
    //     0x11037a4: bl              #0x1103844  ; [package:flutter/src/material/popup_menu.dart] _PopupMenuRoute::_avoidBounds
    // 0x11037a8: stur            x0, [fp, #-0x30]
    // 0x11037ac: r0 = _PopupMenuRouteLayout()
    //     0x11037ac: bl              #0x1103838  ; Allocate_PopupMenuRouteLayoutStub -> _PopupMenuRouteLayout (size=0x24)
    // 0x11037b0: mov             x3, x0
    // 0x11037b4: ldur            x0, [fp, #-0x10]
    // 0x11037b8: stur            x3, [fp, #-0x38]
    // 0x11037bc: StoreField: r3->field_b = r0
    //     0x11037bc: stur            w0, [x3, #0xb]
    // 0x11037c0: ldur            x0, [fp, #-8]
    // 0x11037c4: StoreField: r3->field_f = r0
    //     0x11037c4: stur            w0, [x3, #0xf]
    // 0x11037c8: ldur            x0, [fp, #-0x28]
    // 0x11037cc: ArrayStore: r3[0] = r0  ; List_4
    //     0x11037cc: stur            w0, [x3, #0x17]
    // 0x11037d0: ldur            x0, [fp, #-0x20]
    // 0x11037d4: StoreField: r3->field_1b = r0
    //     0x11037d4: stur            w0, [x3, #0x1b]
    // 0x11037d8: ldur            x0, [fp, #-0x30]
    // 0x11037dc: StoreField: r3->field_1f = r0
    //     0x11037dc: stur            w0, [x3, #0x1f]
    // 0x11037e0: ldur            x0, [fp, #-0x18]
    // 0x11037e4: LoadField: r1 = r0->field_f
    //     0x11037e4: ldur            w1, [x0, #0xf]
    // 0x11037e8: DecompressPointer r1
    //     0x11037e8: add             x1, x1, HEAP, lsl #32
    // 0x11037ec: LoadField: r2 = r1->field_cb
    //     0x11037ec: ldur            w2, [x1, #0xcb]
    // 0x11037f0: DecompressPointer r2
    //     0x11037f0: add             x2, x2, HEAP, lsl #32
    // 0x11037f4: LoadField: r1 = r0->field_13
    //     0x11037f4: ldur            w1, [x0, #0x13]
    // 0x11037f8: DecompressPointer r1
    //     0x11037f8: add             x1, x1, HEAP, lsl #32
    // 0x11037fc: mov             x16, x1
    // 0x1103800: mov             x1, x2
    // 0x1103804: mov             x2, x16
    // 0x1103808: r0 = wrap()
    //     0x1103808: bl              #0x856110  ; [package:flutter/src/widgets/inherited_theme.dart] CapturedThemes::wrap
    // 0x110380c: stur            x0, [fp, #-8]
    // 0x1103810: r0 = CustomSingleChildLayout()
    //     0x1103810: bl              #0xd70b7c  ; AllocateCustomSingleChildLayoutStub -> CustomSingleChildLayout (size=0x14)
    // 0x1103814: ldur            x1, [fp, #-0x38]
    // 0x1103818: StoreField: r0->field_f = r1
    //     0x1103818: stur            w1, [x0, #0xf]
    // 0x110381c: ldur            x1, [fp, #-8]
    // 0x1103820: StoreField: r0->field_b = r1
    //     0x1103820: stur            w1, [x0, #0xb]
    // 0x1103824: LeaveFrame
    //     0x1103824: mov             SP, fp
    //     0x1103828: ldp             fp, lr, [SP], #0x10
    // 0x110382c: ret
    //     0x110382c: ret             
    // 0x1103830: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1103830: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1103834: b               #0x1103754
  }
  _ _avoidBounds(/* No info */) {
    // ** addr: 0x1103844, size: 0x3c
    // 0x1103844: EnterFrame
    //     0x1103844: stp             fp, lr, [SP, #-0x10]!
    //     0x1103848: mov             fp, SP
    // 0x110384c: mov             x0, x1
    // 0x1103850: mov             x1, x2
    // 0x1103854: CheckStackOverflow
    //     0x1103854: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1103858: cmp             SP, x16
    //     0x110385c: b.ls            #0x1103878
    // 0x1103860: r0 = avoidBounds()
    //     0x1103860: bl              #0xfc14b4  ; [package:flutter/src/widgets/display_feature_sub_screen.dart] DisplayFeatureSubScreen::avoidBounds
    // 0x1103864: mov             x1, x0
    // 0x1103868: r0 = toSet()
    //     0x1103868: bl              #0xba60e0  ; [dart:core] _GrowableList::toSet
    // 0x110386c: LeaveFrame
    //     0x110386c: mov             SP, fp
    //     0x1103870: ldp             fp, lr, [SP], #0x10
    // 0x1103874: ret
    //     0x1103874: ret             
    // 0x1103878: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1103878: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x110387c: b               #0x1103860
  }
}

// class id: 3132, size: 0x24, field offset: 0xc
class _PopupMenuRouteLayout extends SingleChildLayoutDelegate {

  _ shouldRelayout(/* No info */) {
    // ** addr: 0x1142008, size: 0x178
    // 0x1142008: EnterFrame
    //     0x1142008: stp             fp, lr, [SP, #-0x10]!
    //     0x114200c: mov             fp, SP
    // 0x1142010: AllocStack(0x28)
    //     0x1142010: sub             SP, SP, #0x28
    // 0x1142014: SetupParameters(_PopupMenuRouteLayout this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x1142014: mov             x4, x1
    //     0x1142018: mov             x3, x2
    //     0x114201c: stur            x1, [fp, #-8]
    //     0x1142020: stur            x2, [fp, #-0x10]
    // 0x1142024: CheckStackOverflow
    //     0x1142024: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1142028: cmp             SP, x16
    //     0x114202c: b.ls            #0x1142178
    // 0x1142030: mov             x0, x3
    // 0x1142034: r2 = Null
    //     0x1142034: mov             x2, NULL
    // 0x1142038: r1 = Null
    //     0x1142038: mov             x1, NULL
    // 0x114203c: r4 = 60
    //     0x114203c: mov             x4, #0x3c
    // 0x1142040: branchIfSmi(r0, 0x114204c)
    //     0x1142040: tbz             w0, #0, #0x114204c
    // 0x1142044: r4 = LoadClassIdInstr(r0)
    //     0x1142044: ldur            x4, [x0, #-1]
    //     0x1142048: ubfx            x4, x4, #0xc, #0x14
    // 0x114204c: cmp             x4, #0xc3c
    // 0x1142050: b.eq            #0x1142068
    // 0x1142054: r8 = _PopupMenuRouteLayout
    //     0x1142054: add             x8, PP, #0xd4, lsl #12  ; [pp+0xd4860] Type: _PopupMenuRouteLayout
    //     0x1142058: ldr             x8, [x8, #0x860]
    // 0x114205c: r3 = Null
    //     0x114205c: add             x3, PP, #0xd4, lsl #12  ; [pp+0xd4868] Null
    //     0x1142060: ldr             x3, [x3, #0x868]
    // 0x1142064: r0 = DefaultTypeTest()
    //     0x1142064: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x1142068: ldur            x0, [fp, #-8]
    // 0x114206c: LoadField: r1 = r0->field_b
    //     0x114206c: ldur            w1, [x0, #0xb]
    // 0x1142070: DecompressPointer r1
    //     0x1142070: add             x1, x1, HEAP, lsl #32
    // 0x1142074: ldur            x2, [fp, #-0x10]
    // 0x1142078: LoadField: r3 = r2->field_b
    //     0x1142078: ldur            w3, [x2, #0xb]
    // 0x114207c: DecompressPointer r3
    //     0x114207c: add             x3, x3, HEAP, lsl #32
    // 0x1142080: cmp             w1, w3
    // 0x1142084: b.eq            #0x11420c8
    // 0x1142088: LoadField: d0 = r3->field_7
    //     0x1142088: ldur            d0, [x3, #7]
    // 0x114208c: LoadField: d1 = r1->field_7
    //     0x114208c: ldur            d1, [x1, #7]
    // 0x1142090: fcmp            d0, d1
    // 0x1142094: b.ne            #0x1142168
    // 0x1142098: LoadField: d0 = r3->field_f
    //     0x1142098: ldur            d0, [x3, #0xf]
    // 0x114209c: LoadField: d1 = r1->field_f
    //     0x114209c: ldur            d1, [x1, #0xf]
    // 0x11420a0: fcmp            d0, d1
    // 0x11420a4: b.ne            #0x1142168
    // 0x11420a8: ArrayLoad: d0 = r3[0]  ; List_8
    //     0x11420a8: ldur            d0, [x3, #0x17]
    // 0x11420ac: ArrayLoad: d1 = r1[0]  ; List_8
    //     0x11420ac: ldur            d1, [x1, #0x17]
    // 0x11420b0: fcmp            d0, d1
    // 0x11420b4: b.ne            #0x1142168
    // 0x11420b8: LoadField: d0 = r3->field_1f
    //     0x11420b8: ldur            d0, [x3, #0x1f]
    // 0x11420bc: LoadField: d1 = r1->field_1f
    //     0x11420bc: ldur            d1, [x1, #0x1f]
    // 0x11420c0: fcmp            d0, d1
    // 0x11420c4: b.ne            #0x1142168
    // 0x11420c8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x11420c8: ldur            w1, [x0, #0x17]
    // 0x11420cc: DecompressPointer r1
    //     0x11420cc: add             x1, x1, HEAP, lsl #32
    // 0x11420d0: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x11420d0: ldur            w3, [x2, #0x17]
    // 0x11420d4: DecompressPointer r3
    //     0x11420d4: add             x3, x3, HEAP, lsl #32
    // 0x11420d8: cmp             w1, w3
    // 0x11420dc: b.ne            #0x1142168
    // 0x11420e0: LoadField: r1 = r0->field_f
    //     0x11420e0: ldur            w1, [x0, #0xf]
    // 0x11420e4: DecompressPointer r1
    //     0x11420e4: add             x1, x1, HEAP, lsl #32
    // 0x11420e8: LoadField: r3 = r2->field_f
    //     0x11420e8: ldur            w3, [x2, #0xf]
    // 0x11420ec: DecompressPointer r3
    //     0x11420ec: add             x3, x3, HEAP, lsl #32
    // 0x11420f0: r16 = <Size?>
    //     0x11420f0: add             x16, PP, #0x26, lsl #12  ; [pp+0x26aa8] TypeArguments: <Size?>
    //     0x11420f4: ldr             x16, [x16, #0xaa8]
    // 0x11420f8: stp             x1, x16, [SP, #8]
    // 0x11420fc: str             x3, [SP]
    // 0x1142100: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x1142100: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x1142104: r0 = listEquals()
    //     0x1142104: bl              #0x8595b0  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0x1142108: tbnz            w0, #4, #0x1142168
    // 0x114210c: ldur            x0, [fp, #-8]
    // 0x1142110: ldur            x1, [fp, #-0x10]
    // 0x1142114: LoadField: r2 = r0->field_1b
    //     0x1142114: ldur            w2, [x0, #0x1b]
    // 0x1142118: DecompressPointer r2
    //     0x1142118: add             x2, x2, HEAP, lsl #32
    // 0x114211c: LoadField: r3 = r1->field_1b
    //     0x114211c: ldur            w3, [x1, #0x1b]
    // 0x1142120: DecompressPointer r3
    //     0x1142120: add             x3, x3, HEAP, lsl #32
    // 0x1142124: stp             x3, x2, [SP]
    // 0x1142128: r0 = ==()
    //     0x1142128: bl              #0x1298c8c  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::==
    // 0x114212c: tbnz            w0, #4, #0x1142168
    // 0x1142130: ldur            x0, [fp, #-8]
    // 0x1142134: ldur            x1, [fp, #-0x10]
    // 0x1142138: LoadField: r2 = r0->field_1f
    //     0x1142138: ldur            w2, [x0, #0x1f]
    // 0x114213c: DecompressPointer r2
    //     0x114213c: add             x2, x2, HEAP, lsl #32
    // 0x1142140: LoadField: r0 = r1->field_1f
    //     0x1142140: ldur            w0, [x1, #0x1f]
    // 0x1142144: DecompressPointer r0
    //     0x1142144: add             x0, x0, HEAP, lsl #32
    // 0x1142148: r16 = <Rect>
    //     0x1142148: ldr             x16, [PP, #0x48d0]  ; [pp+0x48d0] TypeArguments: <Rect>
    // 0x114214c: stp             x2, x16, [SP, #8]
    // 0x1142150: str             x0, [SP]
    // 0x1142154: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x1142154: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x1142158: r0 = setEquals()
    //     0x1142158: bl              #0x86d470  ; [package:flutter/src/foundation/collections.dart] ::setEquals
    // 0x114215c: eor             x1, x0, #0x10
    // 0x1142160: mov             x0, x1
    // 0x1142164: b               #0x114216c
    // 0x1142168: r0 = true
    //     0x1142168: add             x0, NULL, #0x20  ; true
    // 0x114216c: LeaveFrame
    //     0x114216c: mov             SP, fp
    //     0x1142170: ldp             fp, lr, [SP], #0x10
    // 0x1142174: ret
    //     0x1142174: ret             
    // 0x1142178: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1142178: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x114217c: b               #0x1142030
  }
  _ getConstraintsForChild(/* No info */) {
    // ** addr: 0x12dca44, size: 0xa0
    // 0x12dca44: EnterFrame
    //     0x12dca44: stp             fp, lr, [SP, #-0x10]!
    //     0x12dca48: mov             fp, SP
    // 0x12dca4c: AllocStack(0x20)
    //     0x12dca4c: sub             SP, SP, #0x20
    // 0x12dca50: SetupParameters(_PopupMenuRouteLayout this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x12dca50: mov             x0, x2
    //     0x12dca54: stur            x2, [fp, #-0x10]
    //     0x12dca58: mov             x2, x1
    //     0x12dca5c: stur            x1, [fp, #-8]
    // 0x12dca60: CheckStackOverflow
    //     0x12dca60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12dca64: cmp             SP, x16
    //     0x12dca68: b.ls            #0x12dcadc
    // 0x12dca6c: mov             x1, x0
    // 0x12dca70: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x12dca70: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x12dca74: r0 = constrainWidth()
    //     0x12dca74: bl              #0x898d38  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainWidth
    // 0x12dca78: ldur            x1, [fp, #-0x10]
    // 0x12dca7c: stur            d0, [fp, #-0x18]
    // 0x12dca80: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x12dca80: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x12dca84: r0 = constrainHeight()
    //     0x12dca84: bl              #0x898cc4  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainHeight
    // 0x12dca88: stur            d0, [fp, #-0x20]
    // 0x12dca8c: r0 = BoxConstraints()
    //     0x12dca8c: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x12dca90: stur            x0, [fp, #-0x10]
    // 0x12dca94: StoreField: r0->field_7 = rZR
    //     0x12dca94: stur            xzr, [x0, #7]
    // 0x12dca98: ldur            d0, [fp, #-0x18]
    // 0x12dca9c: StoreField: r0->field_f = d0
    //     0x12dca9c: stur            d0, [x0, #0xf]
    // 0x12dcaa0: ArrayStore: r0[0] = rZR  ; List_8
    //     0x12dcaa0: stur            xzr, [x0, #0x17]
    // 0x12dcaa4: ldur            d0, [fp, #-0x20]
    // 0x12dcaa8: StoreField: r0->field_1f = d0
    //     0x12dcaa8: stur            d0, [x0, #0x1f]
    // 0x12dcaac: ldur            x1, [fp, #-8]
    // 0x12dcab0: LoadField: r2 = r1->field_1b
    //     0x12dcab0: ldur            w2, [x1, #0x1b]
    // 0x12dcab4: DecompressPointer r2
    //     0x12dcab4: add             x2, x2, HEAP, lsl #32
    // 0x12dcab8: r1 = Instance_EdgeInsets
    //     0x12dcab8: add             x1, PP, #0x18, lsl #12  ; [pp+0x18338] Obj!EdgeInsets@129d051
    //     0x12dcabc: ldr             x1, [x1, #0x338]
    // 0x12dcac0: r0 = +()
    //     0x12dcac0: bl              #0x8584ec  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::+
    // 0x12dcac4: ldur            x1, [fp, #-0x10]
    // 0x12dcac8: mov             x2, x0
    // 0x12dcacc: r0 = deflate()
    //     0x12dcacc: bl              #0xb4cd58  ; [package:flutter/src/rendering/box.dart] BoxConstraints::deflate
    // 0x12dcad0: LeaveFrame
    //     0x12dcad0: mov             SP, fp
    //     0x12dcad4: ldp             fp, lr, [SP], #0x10
    // 0x12dcad8: ret
    //     0x12dcad8: ret             
    // 0x12dcadc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12dcadc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12dcae0: b               #0x12dca6c
  }
  _ getPositionForChild(/* No info */) {
    // ** addr: 0x12e44d4, size: 0x128
    // 0x12e44d4: EnterFrame
    //     0x12e44d4: stp             fp, lr, [SP, #-0x10]!
    //     0x12e44d8: mov             fp, SP
    // 0x12e44dc: AllocStack(0x38)
    //     0x12e44dc: sub             SP, SP, #0x38
    // 0x12e44e0: SetupParameters(_PopupMenuRouteLayout this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */)
    //     0x12e44e0: stur            x1, [fp, #-0x10]
    //     0x12e44e4: stur            x2, [fp, #-0x18]
    //     0x12e44e8: stur            x3, [fp, #-0x20]
    // 0x12e44ec: CheckStackOverflow
    //     0x12e44ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e44f0: cmp             SP, x16
    //     0x12e44f4: b.ls            #0x12e45f4
    // 0x12e44f8: LoadField: r0 = r1->field_b
    //     0x12e44f8: ldur            w0, [x1, #0xb]
    // 0x12e44fc: DecompressPointer r0
    //     0x12e44fc: add             x0, x0, HEAP, lsl #32
    // 0x12e4500: stur            x0, [fp, #-8]
    // 0x12e4504: LoadField: d0 = r0->field_f
    //     0x12e4504: ldur            d0, [x0, #0xf]
    // 0x12e4508: stur            d0, [fp, #-0x38]
    // 0x12e450c: LoadField: d1 = r0->field_7
    //     0x12e450c: ldur            d1, [x0, #7]
    // 0x12e4510: ArrayLoad: d2 = r0[0]  ; List_8
    //     0x12e4510: ldur            d2, [x0, #0x17]
    // 0x12e4514: fcmp            d1, d2
    // 0x12e4518: b.le            #0x12e4534
    // 0x12e451c: LoadField: d1 = r2->field_7
    //     0x12e451c: ldur            d1, [x2, #7]
    // 0x12e4520: fsub            d3, d1, d2
    // 0x12e4524: LoadField: d1 = r3->field_7
    //     0x12e4524: ldur            d1, [x3, #7]
    // 0x12e4528: fsub            d2, d3, d1
    // 0x12e452c: mov             v1.16b, v2.16b
    // 0x12e4530: b               #0x12e4564
    // 0x12e4534: fcmp            d2, d1
    // 0x12e4538: b.gt            #0x12e4564
    // 0x12e453c: ArrayLoad: r4 = r1[0]  ; List_4
    //     0x12e453c: ldur            w4, [x1, #0x17]
    // 0x12e4540: DecompressPointer r4
    //     0x12e4540: add             x4, x4, HEAP, lsl #32
    // 0x12e4544: LoadField: r5 = r4->field_7
    //     0x12e4544: ldur            x5, [x4, #7]
    // 0x12e4548: cmp             x5, #0
    // 0x12e454c: b.gt            #0x12e4564
    // 0x12e4550: LoadField: d1 = r2->field_7
    //     0x12e4550: ldur            d1, [x2, #7]
    // 0x12e4554: fsub            d3, d1, d2
    // 0x12e4558: LoadField: d1 = r3->field_7
    //     0x12e4558: ldur            d1, [x3, #7]
    // 0x12e455c: fsub            d2, d3, d1
    // 0x12e4560: mov             v1.16b, v2.16b
    // 0x12e4564: stur            d1, [fp, #-0x30]
    // 0x12e4568: r0 = Offset()
    //     0x12e4568: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x12e456c: ldur            d0, [fp, #-0x30]
    // 0x12e4570: stur            x0, [fp, #-0x28]
    // 0x12e4574: StoreField: r0->field_7 = d0
    //     0x12e4574: stur            d0, [x0, #7]
    // 0x12e4578: ldur            d0, [fp, #-0x38]
    // 0x12e457c: StoreField: r0->field_f = d0
    //     0x12e457c: stur            d0, [x0, #0xf]
    // 0x12e4580: ldur            x2, [fp, #-0x18]
    // 0x12e4584: r1 = Instance_Offset
    //     0x12e4584: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x12e4588: r0 = &()
    //     0x12e4588: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0x12e458c: ldur            x1, [fp, #-8]
    // 0x12e4590: mov             x2, x0
    // 0x12e4594: r0 = toRect()
    //     0x12e4594: bl              #0x12e4818  ; [package:flutter/src/rendering/stack.dart] RelativeRect::toRect
    // 0x12e4598: mov             x1, x0
    // 0x12e459c: r0 = center()
    //     0x12e459c: bl              #0x869350  ; [dart:ui] Rect::center
    // 0x12e45a0: ldur            x2, [fp, #-0x18]
    // 0x12e45a4: r1 = Instance_Offset
    //     0x12e45a4: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x12e45a8: stur            x0, [fp, #-8]
    // 0x12e45ac: r0 = &()
    //     0x12e45ac: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0x12e45b0: mov             x1, x0
    // 0x12e45b4: ldur            x0, [fp, #-0x10]
    // 0x12e45b8: LoadField: r2 = r0->field_1f
    //     0x12e45b8: ldur            w2, [x0, #0x1f]
    // 0x12e45bc: DecompressPointer r2
    //     0x12e45bc: add             x2, x2, HEAP, lsl #32
    // 0x12e45c0: r0 = subScreensInBounds()
    //     0x12e45c0: bl              #0xfc0cf4  ; [package:flutter/src/widgets/display_feature_sub_screen.dart] DisplayFeatureSubScreen::subScreensInBounds
    // 0x12e45c4: ldur            x1, [fp, #-0x10]
    // 0x12e45c8: mov             x2, x0
    // 0x12e45cc: ldur            x3, [fp, #-8]
    // 0x12e45d0: r0 = _closestScreen()
    //     0x12e45d0: bl              #0x12e46e8  ; [package:flutter/src/material/popup_menu.dart] _PopupMenuRouteLayout::_closestScreen
    // 0x12e45d4: ldur            x1, [fp, #-0x10]
    // 0x12e45d8: mov             x2, x0
    // 0x12e45dc: ldur            x3, [fp, #-0x20]
    // 0x12e45e0: ldur            x5, [fp, #-0x28]
    // 0x12e45e4: r0 = _fitInsideScreen()
    //     0x12e45e4: bl              #0x12e45fc  ; [package:flutter/src/material/popup_menu.dart] _PopupMenuRouteLayout::_fitInsideScreen
    // 0x12e45e8: LeaveFrame
    //     0x12e45e8: mov             SP, fp
    //     0x12e45ec: ldp             fp, lr, [SP], #0x10
    // 0x12e45f0: ret
    //     0x12e45f0: ret             
    // 0x12e45f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e45f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e45f8: b               #0x12e44f8
  }
  _ _fitInsideScreen(/* No info */) {
    // ** addr: 0x12e45fc, size: 0xec
    // 0x12e45fc: EnterFrame
    //     0x12e45fc: stp             fp, lr, [SP, #-0x10]!
    //     0x12e4600: mov             fp, SP
    // 0x12e4604: AllocStack(0x10)
    //     0x12e4604: sub             SP, SP, #0x10
    // 0x12e4608: d0 = 8.000000
    //     0x12e4608: fmov            d0, #8.00000000
    // 0x12e460c: LoadField: d1 = r5->field_7
    //     0x12e460c: ldur            d1, [x5, #7]
    // 0x12e4610: LoadField: d2 = r5->field_f
    //     0x12e4610: ldur            d2, [x5, #0xf]
    // 0x12e4614: LoadField: d3 = r2->field_7
    //     0x12e4614: ldur            d3, [x2, #7]
    // 0x12e4618: fadd            d4, d3, d0
    // 0x12e461c: LoadField: r0 = r1->field_1b
    //     0x12e461c: ldur            w0, [x1, #0x1b]
    // 0x12e4620: DecompressPointer r0
    //     0x12e4620: add             x0, x0, HEAP, lsl #32
    // 0x12e4624: LoadField: d3 = r0->field_7
    //     0x12e4624: ldur            d3, [x0, #7]
    // 0x12e4628: fadd            d5, d4, d3
    // 0x12e462c: fcmp            d5, d1
    // 0x12e4630: b.le            #0x12e463c
    // 0x12e4634: mov             v1.16b, v5.16b
    // 0x12e4638: b               #0x12e4668
    // 0x12e463c: LoadField: d3 = r3->field_7
    //     0x12e463c: ldur            d3, [x3, #7]
    // 0x12e4640: fadd            d4, d1, d3
    // 0x12e4644: ArrayLoad: d5 = r2[0]  ; List_8
    //     0x12e4644: ldur            d5, [x2, #0x17]
    // 0x12e4648: fsub            d6, d5, d0
    // 0x12e464c: ArrayLoad: d7 = r0[0]  ; List_8
    //     0x12e464c: ldur            d7, [x0, #0x17]
    // 0x12e4650: fsub            d8, d6, d7
    // 0x12e4654: fcmp            d4, d8
    // 0x12e4658: b.le            #0x12e4668
    // 0x12e465c: fsub            d1, d5, d3
    // 0x12e4660: fsub            d3, d1, d0
    // 0x12e4664: fsub            d1, d3, d7
    // 0x12e4668: stur            d1, [fp, #-0x10]
    // 0x12e466c: LoadField: d3 = r2->field_f
    //     0x12e466c: ldur            d3, [x2, #0xf]
    // 0x12e4670: fadd            d4, d3, d0
    // 0x12e4674: LoadField: d3 = r0->field_f
    //     0x12e4674: ldur            d3, [x0, #0xf]
    // 0x12e4678: fadd            d5, d4, d3
    // 0x12e467c: fcmp            d5, d2
    // 0x12e4680: b.le            #0x12e4690
    // 0x12e4684: fadd            d2, d3, d0
    // 0x12e4688: mov             v0.16b, v2.16b
    // 0x12e468c: b               #0x12e46c4
    // 0x12e4690: LoadField: d3 = r3->field_f
    //     0x12e4690: ldur            d3, [x3, #0xf]
    // 0x12e4694: fadd            d4, d2, d3
    // 0x12e4698: LoadField: d5 = r2->field_1f
    //     0x12e4698: ldur            d5, [x2, #0x1f]
    // 0x12e469c: fsub            d6, d5, d0
    // 0x12e46a0: LoadField: d7 = r0->field_1f
    //     0x12e46a0: ldur            d7, [x0, #0x1f]
    // 0x12e46a4: fsub            d8, d6, d7
    // 0x12e46a8: fcmp            d4, d8
    // 0x12e46ac: b.le            #0x12e46c0
    // 0x12e46b0: fsub            d2, d5, d3
    // 0x12e46b4: fsub            d3, d2, d0
    // 0x12e46b8: fsub            d0, d3, d7
    // 0x12e46bc: b               #0x12e46c4
    // 0x12e46c0: mov             v0.16b, v2.16b
    // 0x12e46c4: stur            d0, [fp, #-8]
    // 0x12e46c8: r0 = Offset()
    //     0x12e46c8: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x12e46cc: ldur            d0, [fp, #-0x10]
    // 0x12e46d0: StoreField: r0->field_7 = d0
    //     0x12e46d0: stur            d0, [x0, #7]
    // 0x12e46d4: ldur            d0, [fp, #-8]
    // 0x12e46d8: StoreField: r0->field_f = d0
    //     0x12e46d8: stur            d0, [x0, #0xf]
    // 0x12e46dc: LeaveFrame
    //     0x12e46dc: mov             SP, fp
    //     0x12e46e0: ldp             fp, lr, [SP], #0x10
    // 0x12e46e4: ret
    //     0x12e46e4: ret             
  }
  _ _closestScreen(/* No info */) {
    // ** addr: 0x12e46e8, size: 0x130
    // 0x12e46e8: EnterFrame
    //     0x12e46e8: stp             fp, lr, [SP, #-0x10]!
    //     0x12e46ec: mov             fp, SP
    // 0x12e46f0: AllocStack(0x10)
    //     0x12e46f0: sub             SP, SP, #0x10
    // 0x12e46f4: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0x12e46f4: mov             x0, x2
    //     0x12e46f8: stur            x2, [fp, #-8]
    //     0x12e46fc: stur            x3, [fp, #-0x10]
    // 0x12e4700: CheckStackOverflow
    //     0x12e4700: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e4704: cmp             SP, x16
    //     0x12e4708: b.ls            #0x12e4808
    // 0x12e470c: mov             x1, x0
    // 0x12e4710: r0 = first()
    //     0x12e4710: bl              #0xbb5720  ; [dart:core] _GrowableList::first
    // 0x12e4714: ldur            x1, [fp, #-8]
    // 0x12e4718: LoadField: r2 = r1->field_b
    //     0x12e4718: ldur            w2, [x1, #0xb]
    // 0x12e471c: r3 = LoadInt32Instr(r2)
    //     0x12e471c: sbfx            x3, x2, #1, #0x1f
    // 0x12e4720: LoadField: r2 = r1->field_f
    //     0x12e4720: ldur            w2, [x1, #0xf]
    // 0x12e4724: DecompressPointer r2
    //     0x12e4724: add             x2, x2, HEAP, lsl #32
    // 0x12e4728: ldur            x1, [fp, #-0x10]
    // 0x12e472c: LoadField: d0 = r1->field_7
    //     0x12e472c: ldur            d0, [x1, #7]
    // 0x12e4730: LoadField: d1 = r1->field_f
    //     0x12e4730: ldur            d1, [x1, #0xf]
    // 0x12e4734: mov             x4, x0
    // 0x12e4738: r1 = 0
    //     0x12e4738: mov             x1, #0
    // 0x12e473c: d2 = 2.000000
    //     0x12e473c: fmov            d2, #2.00000000
    // 0x12e4740: CheckStackOverflow
    //     0x12e4740: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e4744: cmp             SP, x16
    //     0x12e4748: b.ls            #0x12e4810
    // 0x12e474c: cmp             x1, x3
    // 0x12e4750: b.ge            #0x12e47f8
    // 0x12e4754: ArrayLoad: r5 = r2[r1]  ; Unknown_4
    //     0x12e4754: add             x16, x2, x1, lsl #2
    //     0x12e4758: ldur            w5, [x16, #0xf]
    // 0x12e475c: DecompressPointer r5
    //     0x12e475c: add             x5, x5, HEAP, lsl #32
    // 0x12e4760: add             x0, x1, #1
    // 0x12e4764: LoadField: d3 = r5->field_7
    //     0x12e4764: ldur            d3, [x5, #7]
    // 0x12e4768: ArrayLoad: d4 = r5[0]  ; List_8
    //     0x12e4768: ldur            d4, [x5, #0x17]
    // 0x12e476c: fsub            d5, d4, d3
    // 0x12e4770: fdiv            d4, d5, d2
    // 0x12e4774: fadd            d5, d3, d4
    // 0x12e4778: LoadField: d3 = r5->field_f
    //     0x12e4778: ldur            d3, [x5, #0xf]
    // 0x12e477c: LoadField: d4 = r5->field_1f
    //     0x12e477c: ldur            d4, [x5, #0x1f]
    // 0x12e4780: fsub            d6, d4, d3
    // 0x12e4784: fdiv            d4, d6, d2
    // 0x12e4788: fadd            d6, d3, d4
    // 0x12e478c: fsub            d3, d5, d0
    // 0x12e4790: fsub            d4, d6, d1
    // 0x12e4794: fmul            d5, d3, d3
    // 0x12e4798: fmul            d3, d4, d4
    // 0x12e479c: fadd            d4, d5, d3
    // 0x12e47a0: fsqrt           d3, d4
    // 0x12e47a4: LoadField: d4 = r4->field_7
    //     0x12e47a4: ldur            d4, [x4, #7]
    // 0x12e47a8: ArrayLoad: d5 = r4[0]  ; List_8
    //     0x12e47a8: ldur            d5, [x4, #0x17]
    // 0x12e47ac: fsub            d6, d5, d4
    // 0x12e47b0: fdiv            d5, d6, d2
    // 0x12e47b4: fadd            d6, d4, d5
    // 0x12e47b8: LoadField: d4 = r4->field_f
    //     0x12e47b8: ldur            d4, [x4, #0xf]
    // 0x12e47bc: LoadField: d5 = r4->field_1f
    //     0x12e47bc: ldur            d5, [x4, #0x1f]
    // 0x12e47c0: fsub            d7, d5, d4
    // 0x12e47c4: fdiv            d5, d7, d2
    // 0x12e47c8: fadd            d7, d4, d5
    // 0x12e47cc: fsub            d4, d6, d0
    // 0x12e47d0: fsub            d5, d7, d1
    // 0x12e47d4: fmul            d6, d4, d4
    // 0x12e47d8: fmul            d4, d5, d5
    // 0x12e47dc: fadd            d5, d6, d4
    // 0x12e47e0: fsqrt           d4, d5
    // 0x12e47e4: fcmp            d4, d3
    // 0x12e47e8: b.le            #0x12e47f0
    // 0x12e47ec: mov             x4, x5
    // 0x12e47f0: mov             x1, x0
    // 0x12e47f4: b               #0x12e4740
    // 0x12e47f8: mov             x0, x4
    // 0x12e47fc: LeaveFrame
    //     0x12e47fc: mov             SP, fp
    //     0x12e4800: ldp             fp, lr, [SP], #0x10
    // 0x12e4804: ret
    //     0x12e4804: ret             
    // 0x12e4808: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e4808: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e480c: b               #0x12e470c
    // 0x12e4810: r0 = StackOverflowSharedWithFPURegs()
    //     0x12e4810: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12e4814: b               #0x12e474c
  }
}

// class id: 4878, size: 0x58, field offset: 0x54
class _RenderMenuItem extends RenderShiftedBox {

  _ computeDryLayout(/* No info */) {
    // ** addr: 0xb4d8e0, size: 0x60
    // 0xb4d8e0: EnterFrame
    //     0xb4d8e0: stp             fp, lr, [SP, #-0x10]!
    //     0xb4d8e4: mov             fp, SP
    // 0xb4d8e8: CheckStackOverflow
    //     0xb4d8e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb4d8ec: cmp             SP, x16
    //     0xb4d8f0: b.ls            #0xb4d938
    // 0xb4d8f4: LoadField: r0 = r1->field_4f
    //     0xb4d8f4: ldur            w0, [x1, #0x4f]
    // 0xb4d8f8: DecompressPointer r0
    //     0xb4d8f8: add             x0, x0, HEAP, lsl #32
    // 0xb4d8fc: cmp             w0, NULL
    // 0xb4d900: b.ne            #0xb4d90c
    // 0xb4d904: r1 = Null
    //     0xb4d904: mov             x1, NULL
    // 0xb4d908: b               #0xb4d918
    // 0xb4d90c: mov             x1, x0
    // 0xb4d910: r0 = getDryLayout()
    //     0xb4d910: bl              #0xb20410  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xb4d914: mov             x1, x0
    // 0xb4d918: cmp             w1, NULL
    // 0xb4d91c: b.ne            #0xb4d928
    // 0xb4d920: r0 = Instance_Size
    //     0xb4d920: ldr             x0, [PP, #0x7f28]  ; [pp+0x7f28] Obj!Size@12a74d1
    // 0xb4d924: b               #0xb4d92c
    // 0xb4d928: mov             x0, x1
    // 0xb4d92c: LeaveFrame
    //     0xb4d92c: mov             SP, fp
    //     0xb4d930: ldp             fp, lr, [SP], #0x10
    // 0xb4d934: ret
    //     0xb4d934: ret             
    // 0xb4d938: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb4d938: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb4d93c: b               #0xb4d8f4
  }
  _ computeDryBaseline(/* No info */) {
    // ** addr: 0xb60ed4, size: 0xa0
    // 0xb60ed4: EnterFrame
    //     0xb60ed4: stp             fp, lr, [SP, #-0x10]!
    //     0xb60ed8: mov             fp, SP
    // 0xb60edc: AllocStack(0x18)
    //     0xb60edc: sub             SP, SP, #0x18
    // 0xb60ee0: SetupParameters(_RenderMenuItem this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xb60ee0: mov             x5, x1
    //     0xb60ee4: mov             x4, x2
    //     0xb60ee8: stur            x1, [fp, #-8]
    //     0xb60eec: stur            x2, [fp, #-0x10]
    //     0xb60ef0: stur            x3, [fp, #-0x18]
    // 0xb60ef4: CheckStackOverflow
    //     0xb60ef4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb60ef8: cmp             SP, x16
    //     0xb60efc: b.ls            #0xb60f6c
    // 0xb60f00: mov             x0, x4
    // 0xb60f04: r2 = Null
    //     0xb60f04: mov             x2, NULL
    // 0xb60f08: r1 = Null
    //     0xb60f08: mov             x1, NULL
    // 0xb60f0c: r4 = 60
    //     0xb60f0c: mov             x4, #0x3c
    // 0xb60f10: branchIfSmi(r0, 0xb60f1c)
    //     0xb60f10: tbz             w0, #0, #0xb60f1c
    // 0xb60f14: r4 = LoadClassIdInstr(r0)
    //     0xb60f14: ldur            x4, [x0, #-1]
    //     0xb60f18: ubfx            x4, x4, #0xc, #0x14
    // 0xb60f1c: sub             x4, x4, #0xb46
    // 0xb60f20: cmp             x4, #1
    // 0xb60f24: b.ls            #0xb60f38
    // 0xb60f28: r8 = BoxConstraints
    //     0xb60f28: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xb60f2c: r3 = Null
    //     0xb60f2c: add             x3, PP, #0xd4, lsl #12  ; [pp+0xd4f60] Null
    //     0xb60f30: ldr             x3, [x3, #0xf60]
    // 0xb60f34: r0 = BoxConstraints()
    //     0xb60f34: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xb60f38: ldur            x0, [fp, #-8]
    // 0xb60f3c: LoadField: r1 = r0->field_4f
    //     0xb60f3c: ldur            w1, [x0, #0x4f]
    // 0xb60f40: DecompressPointer r1
    //     0xb60f40: add             x1, x1, HEAP, lsl #32
    // 0xb60f44: cmp             w1, NULL
    // 0xb60f48: b.ne            #0xb60f54
    // 0xb60f4c: r0 = Null
    //     0xb60f4c: mov             x0, NULL
    // 0xb60f50: b               #0xb60f60
    // 0xb60f54: ldur            x2, [fp, #-0x10]
    // 0xb60f58: ldur            x3, [fp, #-0x18]
    // 0xb60f5c: r0 = getDryBaseline()
    //     0xb60f5c: bl              #0xb19678  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryBaseline
    // 0xb60f60: LeaveFrame
    //     0xb60f60: mov             SP, fp
    //     0xb60f64: ldp             fp, lr, [SP], #0x10
    // 0xb60f68: ret
    //     0xb60f68: ret             
    // 0xb60f6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb60f6c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb60f70: b               #0xb60f00
  }
  _ performLayout(/* No info */) {
    // ** addr: 0xbbcc04, size: 0x23c
    // 0xbbcc04: EnterFrame
    //     0xbbcc04: stp             fp, lr, [SP, #-0x10]!
    //     0xbbcc08: mov             fp, SP
    // 0xbbcc0c: AllocStack(0x28)
    //     0xbbcc0c: sub             SP, SP, #0x28
    // 0xbbcc10: SetupParameters(_RenderMenuItem this /* r1 => r3, fp-0x18 */)
    //     0xbbcc10: mov             x3, x1
    //     0xbbcc14: stur            x1, [fp, #-0x18]
    // 0xbbcc18: CheckStackOverflow
    //     0xbbcc18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbbcc1c: cmp             SP, x16
    //     0xbbcc20: b.ls            #0xbbce2c
    // 0xbbcc24: LoadField: r4 = r3->field_4f
    //     0xbbcc24: ldur            w4, [x3, #0x4f]
    // 0xbbcc28: DecompressPointer r4
    //     0xbbcc28: add             x4, x4, HEAP, lsl #32
    // 0xbbcc2c: stur            x4, [fp, #-0x10]
    // 0xbbcc30: cmp             w4, NULL
    // 0xbbcc34: b.ne            #0xbbcc48
    // 0xbbcc38: r0 = Instance_Size
    //     0xbbcc38: ldr             x0, [PP, #0x7f28]  ; [pp+0x7f28] Obj!Size@12a74d1
    // 0xbbcc3c: StoreField: r3->field_4b = r0
    //     0xbbcc3c: stur            w0, [x3, #0x4b]
    // 0xbbcc40: mov             x0, x3
    // 0xbbcc44: b               #0xbbcdb4
    // 0xbbcc48: LoadField: r5 = r3->field_27
    //     0xbbcc48: ldur            w5, [x3, #0x27]
    // 0xbbcc4c: DecompressPointer r5
    //     0xbbcc4c: add             x5, x5, HEAP, lsl #32
    // 0xbbcc50: stur            x5, [fp, #-8]
    // 0xbbcc54: cmp             w5, NULL
    // 0xbbcc58: b.eq            #0xbbcdf0
    // 0xbbcc5c: mov             x0, x5
    // 0xbbcc60: r2 = Null
    //     0xbbcc60: mov             x2, NULL
    // 0xbbcc64: r1 = Null
    //     0xbbcc64: mov             x1, NULL
    // 0xbbcc68: r4 = LoadClassIdInstr(r0)
    //     0xbbcc68: ldur            x4, [x0, #-1]
    //     0xbbcc6c: ubfx            x4, x4, #0xc, #0x14
    // 0xbbcc70: sub             x4, x4, #0xb46
    // 0xbbcc74: cmp             x4, #1
    // 0xbbcc78: b.ls            #0xbbcc8c
    // 0xbbcc7c: r8 = BoxConstraints
    //     0xbbcc7c: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbbcc80: r3 = Null
    //     0xbbcc80: add             x3, PP, #0xd4, lsl #12  ; [pp+0xd4f30] Null
    //     0xbbcc84: ldr             x3, [x3, #0xf30]
    // 0xbbcc88: r0 = BoxConstraints()
    //     0xbbcc88: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbbcc8c: ldur            x1, [fp, #-0x10]
    // 0xbbcc90: r0 = LoadClassIdInstr(r1)
    //     0xbbcc90: ldur            x0, [x1, #-1]
    //     0xbbcc94: ubfx            x0, x0, #0xc, #0x14
    // 0xbbcc98: r16 = true
    //     0xbbcc98: add             x16, NULL, #0x20  ; true
    // 0xbbcc9c: str             x16, [SP]
    // 0xbbcca0: ldur            x2, [fp, #-8]
    // 0xbbcca4: r4 = const [0, 0x3, 0x1, 0x2, parentUsesSize, 0x2, null]
    //     0xbbcca4: add             x4, PP, #0xd, lsl #12  ; [pp+0xded0] List(7) [0, 0x3, 0x1, 0x2, "parentUsesSize", 0x2, Null]
    //     0xbbcca8: ldr             x4, [x4, #0xed0]
    // 0xbbccac: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0xbbccac: mov             x17, #0xe6b9
    //     0xbbccb0: add             lr, x0, x17
    //     0xbbccb4: ldr             lr, [x21, lr, lsl #3]
    //     0xbbccb8: blr             lr
    // 0xbbccbc: ldur            x3, [fp, #-0x18]
    // 0xbbccc0: LoadField: r4 = r3->field_27
    //     0xbbccc0: ldur            w4, [x3, #0x27]
    // 0xbbccc4: DecompressPointer r4
    //     0xbbccc4: add             x4, x4, HEAP, lsl #32
    // 0xbbccc8: stur            x4, [fp, #-8]
    // 0xbbcccc: cmp             w4, NULL
    // 0xbbccd0: b.eq            #0xbbce0c
    // 0xbbccd4: mov             x0, x4
    // 0xbbccd8: r2 = Null
    //     0xbbccd8: mov             x2, NULL
    // 0xbbccdc: r1 = Null
    //     0xbbccdc: mov             x1, NULL
    // 0xbbcce0: r4 = LoadClassIdInstr(r0)
    //     0xbbcce0: ldur            x4, [x0, #-1]
    //     0xbbcce4: ubfx            x4, x4, #0xc, #0x14
    // 0xbbcce8: sub             x4, x4, #0xb46
    // 0xbbccec: cmp             x4, #1
    // 0xbbccf0: b.ls            #0xbbcd04
    // 0xbbccf4: r8 = BoxConstraints
    //     0xbbccf4: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbbccf8: r3 = Null
    //     0xbbccf8: add             x3, PP, #0xd4, lsl #12  ; [pp+0xd4f40] Null
    //     0xbbccfc: ldr             x3, [x3, #0xf40]
    // 0xbbcd00: r0 = BoxConstraints()
    //     0xbbcd00: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbbcd04: ldur            x0, [fp, #-0x18]
    // 0xbbcd08: LoadField: r1 = r0->field_4f
    //     0xbbcd08: ldur            w1, [x0, #0x4f]
    // 0xbbcd0c: DecompressPointer r1
    //     0xbbcd0c: add             x1, x1, HEAP, lsl #32
    // 0xbbcd10: cmp             w1, NULL
    // 0xbbcd14: b.eq            #0xbbce34
    // 0xbbcd18: r0 = size()
    //     0xbbcd18: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbbcd1c: ldur            x1, [fp, #-8]
    // 0xbbcd20: mov             x2, x0
    // 0xbbcd24: r0 = constrain()
    //     0xbbcd24: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xbbcd28: ldur            x3, [fp, #-0x18]
    // 0xbbcd2c: StoreField: r3->field_4b = r0
    //     0xbbcd2c: stur            w0, [x3, #0x4b]
    //     0xbbcd30: ldurb           w16, [x3, #-1]
    //     0xbbcd34: ldurb           w17, [x0, #-1]
    //     0xbbcd38: and             x16, x17, x16, lsr #2
    //     0xbbcd3c: tst             x16, HEAP, lsr #32
    //     0xbbcd40: b.eq            #0xbbcd48
    //     0xbbcd44: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbbcd48: LoadField: r0 = r3->field_4f
    //     0xbbcd48: ldur            w0, [x3, #0x4f]
    // 0xbbcd4c: DecompressPointer r0
    //     0xbbcd4c: add             x0, x0, HEAP, lsl #32
    // 0xbbcd50: cmp             w0, NULL
    // 0xbbcd54: b.eq            #0xbbce38
    // 0xbbcd58: LoadField: r4 = r0->field_7
    //     0xbbcd58: ldur            w4, [x0, #7]
    // 0xbbcd5c: DecompressPointer r4
    //     0xbbcd5c: add             x4, x4, HEAP, lsl #32
    // 0xbbcd60: stur            x4, [fp, #-8]
    // 0xbbcd64: cmp             w4, NULL
    // 0xbbcd68: b.eq            #0xbbce3c
    // 0xbbcd6c: mov             x0, x4
    // 0xbbcd70: r2 = Null
    //     0xbbcd70: mov             x2, NULL
    // 0xbbcd74: r1 = Null
    //     0xbbcd74: mov             x1, NULL
    // 0xbbcd78: r4 = LoadClassIdInstr(r0)
    //     0xbbcd78: ldur            x4, [x0, #-1]
    //     0xbbcd7c: ubfx            x4, x4, #0xc, #0x14
    // 0xbbcd80: r17 = -4190
    //     0xbbcd80: mov             x17, #-0x105e
    // 0xbbcd84: add             x4, x4, x17
    // 0xbbcd88: cmp             x4, #0x17
    // 0xbbcd8c: b.ls            #0xbbcda4
    // 0xbbcd90: r8 = BoxParentData
    //     0xbbcd90: add             x8, PP, #0x15, lsl #12  ; [pp+0x155e8] Type: BoxParentData
    //     0xbbcd94: ldr             x8, [x8, #0x5e8]
    // 0xbbcd98: r3 = Null
    //     0xbbcd98: add             x3, PP, #0xd4, lsl #12  ; [pp+0xd4f50] Null
    //     0xbbcd9c: ldr             x3, [x3, #0xf50]
    // 0xbbcda0: r0 = DefaultTypeTest()
    //     0xbbcda0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbbcda4: ldur            x0, [fp, #-8]
    // 0xbbcda8: r1 = Instance_Offset
    //     0xbbcda8: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xbbcdac: StoreField: r0->field_7 = r1
    //     0xbbcdac: stur            w1, [x0, #7]
    // 0xbbcdb0: ldur            x0, [fp, #-0x18]
    // 0xbbcdb4: mov             x1, x0
    // 0xbbcdb8: r0 = size()
    //     0xbbcdb8: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbbcdbc: mov             x1, x0
    // 0xbbcdc0: ldur            x0, [fp, #-0x18]
    // 0xbbcdc4: LoadField: r2 = r0->field_53
    //     0xbbcdc4: ldur            w2, [x0, #0x53]
    // 0xbbcdc8: DecompressPointer r2
    //     0xbbcdc8: add             x2, x2, HEAP, lsl #32
    // 0xbbcdcc: stp             x1, x2, [SP]
    // 0xbbcdd0: mov             x0, x2
    // 0xbbcdd4: ClosureCall
    //     0xbbcdd4: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xbbcdd8: ldur            x2, [x0, #0x1f]
    //     0xbbcddc: blr             x2
    // 0xbbcde0: r0 = Null
    //     0xbbcde0: mov             x0, NULL
    // 0xbbcde4: LeaveFrame
    //     0xbbcde4: mov             SP, fp
    //     0xbbcde8: ldp             fp, lr, [SP], #0x10
    // 0xbbcdec: ret
    //     0xbbcdec: ret             
    // 0xbbcdf0: r0 = StateError()
    //     0xbbcdf0: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbbcdf4: mov             x1, x0
    // 0xbbcdf8: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbbcdf8: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbbcdfc: StoreField: r1->field_b = r0
    //     0xbbcdfc: stur            w0, [x1, #0xb]
    // 0xbbce00: mov             x0, x1
    // 0xbbce04: r0 = Throw()
    //     0xbbce04: bl              #0x13ddb2c  ; ThrowStub
    // 0xbbce08: brk             #0
    // 0xbbce0c: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbbce0c: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbbce10: r0 = StateError()
    //     0xbbce10: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbbce14: mov             x1, x0
    // 0xbbce18: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbbce18: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbbce1c: StoreField: r1->field_b = r0
    //     0xbbce1c: stur            w0, [x1, #0xb]
    // 0xbbce20: mov             x0, x1
    // 0xbbce24: r0 = Throw()
    //     0xbbce24: bl              #0x13ddb2c  ; ThrowStub
    // 0xbbce28: brk             #0
    // 0xbbce2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbbce2c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbbce30: b               #0xbbcc24
    // 0xbbce34: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbce34: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbbce38: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbce38: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbbce3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbce3c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 5130, size: 0x4c, field offset: 0x3c
class _PopupMenuDefaultsM3 extends PopupMenuThemeData {

  late final ColorScheme _colors; // offset: 0x44
  late final TextTheme _textTheme; // offset: 0x48
  late final ThemeData _theme; // offset: 0x40
  static late EdgeInsets menuItemPadding; // offset: 0x75c

  static EdgeInsets menuItemPadding() {
    // ** addr: 0xdf873c, size: 0xc
    // 0xdf873c: r0 = Instance_EdgeInsets
    //     0xdf873c: add             x0, PP, #0xd2, lsl #12  ; [pp+0xd2cc8] Obj!EdgeInsets@129d321
    //     0xdf8740: ldr             x0, [x0, #0xcc8]
    // 0xdf8744: ret
    //     0xdf8744: ret             
  }
  [closure] TextStyle <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xdf87d8, size: 0x148
    // 0xdf87d8: EnterFrame
    //     0xdf87d8: stp             fp, lr, [SP, #-0x10]!
    //     0xdf87dc: mov             fp, SP
    // 0xdf87e0: AllocStack(0x10)
    //     0xdf87e0: sub             SP, SP, #0x10
    // 0xdf87e4: SetupParameters([dynamic _ /* r0 */])
    //     0xdf87e4: ldr             x0, [fp, #0x18]
    //     0xdf87e8: ldur            w2, [x0, #0x17]
    //     0xdf87ec: add             x2, x2, HEAP, lsl #32
    //     0xdf87f0: stur            x2, [fp, #-8]
    // 0xdf87f4: CheckStackOverflow
    //     0xdf87f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf87f8: cmp             SP, x16
    //     0xdf87fc: b.ls            #0xdf8918
    // 0xdf8800: LoadField: r1 = r2->field_f
    //     0xdf8800: ldur            w1, [x2, #0xf]
    // 0xdf8804: DecompressPointer r1
    //     0xdf8804: add             x1, x1, HEAP, lsl #32
    // 0xdf8808: LoadField: r0 = r1->field_47
    //     0xdf8808: ldur            w0, [x1, #0x47]
    // 0xdf880c: DecompressPointer r0
    //     0xdf880c: add             x0, x0, HEAP, lsl #32
    // 0xdf8810: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf8814: cmp             w0, w16
    // 0xdf8818: b.ne            #0xdf8828
    // 0xdf881c: r2 = _textTheme
    //     0xdf881c: add             x2, PP, #0x26, lsl #12  ; [pp+0x262f0] Field <_PopupMenuDefaultsM3@113182389._textTheme@113182389>: late final (offset: 0x48)
    //     0xdf8820: ldr             x2, [x2, #0x2f0]
    // 0xdf8824: r0 = InitLateFinalInstanceField()
    //     0xdf8824: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf8828: LoadField: r3 = r0->field_37
    //     0xdf8828: ldur            w3, [x0, #0x37]
    // 0xdf882c: DecompressPointer r3
    //     0xdf882c: add             x3, x3, HEAP, lsl #32
    // 0xdf8830: ldr             x1, [fp, #0x10]
    // 0xdf8834: stur            x3, [fp, #-0x10]
    // 0xdf8838: r0 = LoadClassIdInstr(r1)
    //     0xdf8838: ldur            x0, [x1, #-1]
    //     0xdf883c: ubfx            x0, x0, #0xc, #0x14
    // 0xdf8840: r2 = Instance_WidgetState
    //     0xdf8840: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xdf8844: ldr             x2, [x2, #0xa70]
    // 0xdf8848: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdf8848: mov             x17, #0x2929
    //     0xdf884c: movk            x17, #1, lsl #16
    //     0xdf8850: add             lr, x0, x17
    //     0xdf8854: ldr             lr, [x21, lr, lsl #3]
    //     0xdf8858: blr             lr
    // 0xdf885c: tbnz            w0, #4, #0xdf88cc
    // 0xdf8860: ldur            x0, [fp, #-8]
    // 0xdf8864: LoadField: r1 = r0->field_f
    //     0xdf8864: ldur            w1, [x0, #0xf]
    // 0xdf8868: DecompressPointer r1
    //     0xdf8868: add             x1, x1, HEAP, lsl #32
    // 0xdf886c: LoadField: r0 = r1->field_43
    //     0xdf886c: ldur            w0, [x1, #0x43]
    // 0xdf8870: DecompressPointer r0
    //     0xdf8870: add             x0, x0, HEAP, lsl #32
    // 0xdf8874: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf8878: cmp             w0, w16
    // 0xdf887c: b.ne            #0xdf888c
    // 0xdf8880: r2 = _colors
    //     0xdf8880: add             x2, PP, #0x26, lsl #12  ; [pp+0x262d0] Field <_PopupMenuDefaultsM3@113182389._colors@113182389>: late final (offset: 0x44)
    //     0xdf8884: ldr             x2, [x2, #0x2d0]
    // 0xdf8888: r0 = InitLateFinalInstanceField()
    //     0xdf8888: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf888c: LoadField: r1 = r0->field_7f
    //     0xdf888c: ldur            w1, [x0, #0x7f]
    // 0xdf8890: DecompressPointer r1
    //     0xdf8890: add             x1, x1, HEAP, lsl #32
    // 0xdf8894: r0 = LoadClassIdInstr(r1)
    //     0xdf8894: ldur            x0, [x1, #-1]
    //     0xdf8898: ubfx            x0, x0, #0xc, #0x14
    // 0xdf889c: d0 = 0.380000
    //     0xdf889c: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xdf88a0: ldr             d0, [x17, #0x1f0]
    // 0xdf88a4: r0 = GDT[cid_x0 + -0x1000]()
    //     0xdf88a4: sub             lr, x0, #1, lsl #12
    //     0xdf88a8: ldr             lr, [x21, lr, lsl #3]
    //     0xdf88ac: blr             lr
    // 0xdf88b0: ldur            x1, [fp, #-0x10]
    // 0xdf88b4: mov             x2, x0
    // 0xdf88b8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xdf88b8: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xdf88bc: r0 = apply()
    //     0xdf88bc: bl              #0x8acf20  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0xdf88c0: LeaveFrame
    //     0xdf88c0: mov             SP, fp
    //     0xdf88c4: ldp             fp, lr, [SP], #0x10
    // 0xdf88c8: ret
    //     0xdf88c8: ret             
    // 0xdf88cc: ldur            x0, [fp, #-8]
    // 0xdf88d0: LoadField: r1 = r0->field_f
    //     0xdf88d0: ldur            w1, [x0, #0xf]
    // 0xdf88d4: DecompressPointer r1
    //     0xdf88d4: add             x1, x1, HEAP, lsl #32
    // 0xdf88d8: LoadField: r0 = r1->field_43
    //     0xdf88d8: ldur            w0, [x1, #0x43]
    // 0xdf88dc: DecompressPointer r0
    //     0xdf88dc: add             x0, x0, HEAP, lsl #32
    // 0xdf88e0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf88e4: cmp             w0, w16
    // 0xdf88e8: b.ne            #0xdf88f8
    // 0xdf88ec: r2 = _colors
    //     0xdf88ec: add             x2, PP, #0x26, lsl #12  ; [pp+0x262d0] Field <_PopupMenuDefaultsM3@113182389._colors@113182389>: late final (offset: 0x44)
    //     0xdf88f0: ldr             x2, [x2, #0x2d0]
    // 0xdf88f4: r0 = InitLateFinalInstanceField()
    //     0xdf88f4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf88f8: LoadField: r2 = r0->field_7f
    //     0xdf88f8: ldur            w2, [x0, #0x7f]
    // 0xdf88fc: DecompressPointer r2
    //     0xdf88fc: add             x2, x2, HEAP, lsl #32
    // 0xdf8900: ldur            x1, [fp, #-0x10]
    // 0xdf8904: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xdf8904: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xdf8908: r0 = apply()
    //     0xdf8908: bl              #0x8acf20  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0xdf890c: LeaveFrame
    //     0xdf890c: mov             SP, fp
    //     0xdf8910: ldp             fp, lr, [SP], #0x10
    // 0xdf8914: ret
    //     0xdf8914: ret             
    // 0xdf8918: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf8918: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf891c: b               #0xdf8800
  }
  TextTheme _textTheme(_PopupMenuDefaultsM3) {
    // ** addr: 0xdf8920, size: 0x58
    // 0xdf8920: EnterFrame
    //     0xdf8920: stp             fp, lr, [SP, #-0x10]!
    //     0xdf8924: mov             fp, SP
    // 0xdf8928: CheckStackOverflow
    //     0xdf8928: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf892c: cmp             SP, x16
    //     0xdf8930: b.ls            #0xdf8970
    // 0xdf8934: ldr             x1, [fp, #0x10]
    // 0xdf8938: LoadField: r0 = r1->field_3f
    //     0xdf8938: ldur            w0, [x1, #0x3f]
    // 0xdf893c: DecompressPointer r0
    //     0xdf893c: add             x0, x0, HEAP, lsl #32
    // 0xdf8940: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf8944: cmp             w0, w16
    // 0xdf8948: b.ne            #0xdf8958
    // 0xdf894c: r2 = _theme
    //     0xdf894c: add             x2, PP, #0x26, lsl #12  ; [pp+0x262f8] Field <_PopupMenuDefaultsM3@113182389._theme@113182389>: late final (offset: 0x40)
    //     0xdf8950: ldr             x2, [x2, #0x2f8]
    // 0xdf8954: r0 = InitLateFinalInstanceField()
    //     0xdf8954: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf8958: LoadField: r1 = r0->field_87
    //     0xdf8958: ldur            w1, [x0, #0x87]
    // 0xdf895c: DecompressPointer r1
    //     0xdf895c: add             x1, x1, HEAP, lsl #32
    // 0xdf8960: mov             x0, x1
    // 0xdf8964: LeaveFrame
    //     0xdf8964: mov             SP, fp
    //     0xdf8968: ldp             fp, lr, [SP], #0x10
    // 0xdf896c: ret
    //     0xdf896c: ret             
    // 0xdf8970: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf8970: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf8974: b               #0xdf8934
  }
  ColorScheme _colors(_PopupMenuDefaultsM3) {
    // ** addr: 0xdf8978, size: 0x58
    // 0xdf8978: EnterFrame
    //     0xdf8978: stp             fp, lr, [SP, #-0x10]!
    //     0xdf897c: mov             fp, SP
    // 0xdf8980: CheckStackOverflow
    //     0xdf8980: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf8984: cmp             SP, x16
    //     0xdf8988: b.ls            #0xdf89c8
    // 0xdf898c: ldr             x1, [fp, #0x10]
    // 0xdf8990: LoadField: r0 = r1->field_3f
    //     0xdf8990: ldur            w0, [x1, #0x3f]
    // 0xdf8994: DecompressPointer r0
    //     0xdf8994: add             x0, x0, HEAP, lsl #32
    // 0xdf8998: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf899c: cmp             w0, w16
    // 0xdf89a0: b.ne            #0xdf89b0
    // 0xdf89a4: r2 = _theme
    //     0xdf89a4: add             x2, PP, #0x26, lsl #12  ; [pp+0x262f8] Field <_PopupMenuDefaultsM3@113182389._theme@113182389>: late final (offset: 0x40)
    //     0xdf89a8: ldr             x2, [x2, #0x2f8]
    // 0xdf89ac: r0 = InitLateFinalInstanceField()
    //     0xdf89ac: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf89b0: LoadField: r1 = r0->field_3f
    //     0xdf89b0: ldur            w1, [x0, #0x3f]
    // 0xdf89b4: DecompressPointer r1
    //     0xdf89b4: add             x1, x1, HEAP, lsl #32
    // 0xdf89b8: mov             x0, x1
    // 0xdf89bc: LeaveFrame
    //     0xdf89bc: mov             SP, fp
    //     0xdf89c0: ldp             fp, lr, [SP], #0x10
    // 0xdf89c4: ret
    //     0xdf89c4: ret             
    // 0xdf89c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf89c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf89cc: b               #0xdf898c
  }
}

// class id: 5131, size: 0x48, field offset: 0x3c
class _PopupMenuDefaultsM2 extends PopupMenuThemeData {

  late final TextTheme _textTheme; // offset: 0x44
  late final ThemeData _theme; // offset: 0x40
  static late EdgeInsets menuItemPadding; // offset: 0x760

  static EdgeInsets menuItemPadding() {
    // ** addr: 0xdf8730, size: 0xc
    // 0xdf8730: r0 = Instance_EdgeInsets
    //     0xdf8730: add             x0, PP, #0x26, lsl #12  ; [pp+0x26510] Obj!EdgeInsets@129cdb1
    //     0xdf8734: ldr             x0, [x0, #0x510]
    // 0xdf8738: ret
    //     0xdf8738: ret             
  }
  TextTheme _textTheme(_PopupMenuDefaultsM2) {
    // ** addr: 0xdf8748, size: 0x58
    // 0xdf8748: EnterFrame
    //     0xdf8748: stp             fp, lr, [SP, #-0x10]!
    //     0xdf874c: mov             fp, SP
    // 0xdf8750: CheckStackOverflow
    //     0xdf8750: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf8754: cmp             SP, x16
    //     0xdf8758: b.ls            #0xdf8798
    // 0xdf875c: ldr             x1, [fp, #0x10]
    // 0xdf8760: LoadField: r0 = r1->field_3f
    //     0xdf8760: ldur            w0, [x1, #0x3f]
    // 0xdf8764: DecompressPointer r0
    //     0xdf8764: add             x0, x0, HEAP, lsl #32
    // 0xdf8768: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf876c: cmp             w0, w16
    // 0xdf8770: b.ne            #0xdf8780
    // 0xdf8774: r2 = _theme
    //     0xdf8774: add             x2, PP, #0x26, lsl #12  ; [pp+0x26300] Field <_PopupMenuDefaultsM2@113182389._theme@113182389>: late final (offset: 0x40)
    //     0xdf8778: ldr             x2, [x2, #0x300]
    // 0xdf877c: r0 = InitLateFinalInstanceField()
    //     0xdf877c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf8780: LoadField: r1 = r0->field_87
    //     0xdf8780: ldur            w1, [x0, #0x87]
    // 0xdf8784: DecompressPointer r1
    //     0xdf8784: add             x1, x1, HEAP, lsl #32
    // 0xdf8788: mov             x0, x1
    // 0xdf878c: LeaveFrame
    //     0xdf878c: mov             SP, fp
    //     0xdf8790: ldp             fp, lr, [SP], #0x10
    // 0xdf8794: ret
    //     0xdf8794: ret             
    // 0xdf8798: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf8798: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf879c: b               #0xdf875c
  }
  ThemeData _theme(_PopupMenuDefaultsM2) {
    // ** addr: 0xdf87a0, size: 0x38
    // 0xdf87a0: EnterFrame
    //     0xdf87a0: stp             fp, lr, [SP, #-0x10]!
    //     0xdf87a4: mov             fp, SP
    // 0xdf87a8: CheckStackOverflow
    //     0xdf87a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf87ac: cmp             SP, x16
    //     0xdf87b0: b.ls            #0xdf87d0
    // 0xdf87b4: ldr             x0, [fp, #0x10]
    // 0xdf87b8: LoadField: r1 = r0->field_3b
    //     0xdf87b8: ldur            w1, [x0, #0x3b]
    // 0xdf87bc: DecompressPointer r1
    //     0xdf87bc: add             x1, x1, HEAP, lsl #32
    // 0xdf87c0: r0 = of()
    //     0xdf87c0: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xdf87c4: LeaveFrame
    //     0xdf87c4: mov             SP, fp
    //     0xdf87c8: ldp             fp, lr, [SP], #0x10
    // 0xdf87cc: ret
    //     0xdf87cc: ret             
    // 0xdf87d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf87d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf87d4: b               #0xdf87b4
  }
}

// class id: 5189, size: 0x10, field offset: 0x8
//   const constructor, 
class _EffectiveMouseCursor extends WidgetStateMouseCursor {

  MouseCursor resolve(_EffectiveMouseCursor, Set<WidgetState>) {
    // ** addr: 0x8de4b8, size: 0x58
    // 0x8de4b8: EnterFrame
    //     0x8de4b8: stp             fp, lr, [SP, #-0x10]!
    //     0x8de4bc: mov             fp, SP
    // 0x8de4c0: AllocStack(0x20)
    //     0x8de4c0: sub             SP, SP, #0x20
    // 0x8de4c4: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x8de4c4: stur            x2, [fp, #-8]
    // 0x8de4c8: CheckStackOverflow
    //     0x8de4c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8de4cc: cmp             SP, x16
    //     0x8de4d0: b.ls            #0x8de508
    // 0x8de4d4: r16 = <MouseCursor?>
    //     0x8de4d4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15ab8] TypeArguments: <MouseCursor?>
    //     0x8de4d8: ldr             x16, [x16, #0xab8]
    // 0x8de4dc: stp             NULL, x16, [SP, #8]
    // 0x8de4e0: str             x2, [SP]
    // 0x8de4e4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8de4e4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8de4e8: r0 = resolveAs()
    //     0x8de4e8: bl              #0x8de57c  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveAs
    // 0x8de4ec: ldur            x2, [fp, #-8]
    // 0x8de4f0: r1 = Instance__WidgetStateMouseCursor
    //     0x8de4f0: add             x1, PP, #0x80, lsl #12  ; [pp+0x80c18] Obj!_WidgetStateMouseCursor@12b3251
    //     0x8de4f4: ldr             x1, [x1, #0xc18]
    // 0x8de4f8: r0 = resolve()
    //     0x8de4f8: bl              #0x8de794  ; [package:flutter/src/widgets/widget_state.dart] _WidgetStateMouseCursor::resolve
    // 0x8de4fc: LeaveFrame
    //     0x8de4fc: mov             SP, fp
    //     0x8de500: ldp             fp, lr, [SP], #0x10
    // 0x8de504: ret
    //     0x8de504: ret             
    // 0x8de508: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8de508: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8de50c: b               #0x8de4d4
  }
  MouseCursor resolve(_EffectiveMouseCursor, Set<WidgetState>) {
    // ** addr: 0x8de528, size: 0x6c
    // 0x8de528: EnterFrame
    //     0x8de528: stp             fp, lr, [SP, #-0x10]!
    //     0x8de52c: mov             fp, SP
    // 0x8de530: CheckStackOverflow
    //     0x8de530: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8de534: cmp             SP, x16
    //     0x8de538: b.ls            #0x8de574
    // 0x8de53c: ldr             x0, [fp, #0x10]
    // 0x8de540: r2 = Null
    //     0x8de540: mov             x2, NULL
    // 0x8de544: r1 = Null
    //     0x8de544: mov             x1, NULL
    // 0x8de548: r8 = Set<WidgetState>
    //     0x8de548: add             x8, PP, #0x85, lsl #12  ; [pp+0x85200] Type: Set<WidgetState>
    //     0x8de54c: ldr             x8, [x8, #0x200]
    // 0x8de550: r3 = Null
    //     0x8de550: add             x3, PP, #0xd4, lsl #12  ; [pp+0xd4b88] Null
    //     0x8de554: ldr             x3, [x3, #0xb88]
    // 0x8de558: r0 = Set<WidgetState>()
    //     0x8de558: bl              #0x8de430  ; IsType_Set<WidgetState>_Stub
    // 0x8de55c: ldr             x1, [fp, #0x18]
    // 0x8de560: ldr             x2, [fp, #0x10]
    // 0x8de564: r0 = resolve()
    //     0x8de564: bl              #0x8de4b8  ; [package:flutter/src/material/popup_menu.dart] _EffectiveMouseCursor::resolve
    // 0x8de568: LeaveFrame
    //     0x8de568: mov             SP, fp
    //     0x8de56c: ldp             fp, lr, [SP], #0x10
    // 0x8de570: ret
    //     0x8de570: ret             
    // 0x8de574: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8de574: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8de578: b               #0x8de53c
  }
}

// class id: 5460, size: 0x18, field offset: 0x14
class _PopupMenuState<C1X0> extends State<C1X0> {

  _ build(/* No info */) {
    // ** addr: 0xdf89d0, size: 0x698
    // 0xdf89d0: EnterFrame
    //     0xdf89d0: stp             fp, lr, [SP, #-0x10]!
    //     0xdf89d4: mov             fp, SP
    // 0xdf89d8: AllocStack(0x90)
    //     0xdf89d8: sub             SP, SP, #0x90
    // 0xdf89dc: SetupParameters(_PopupMenuState<C1X0> this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xdf89dc: mov             x0, x1
    //     0xdf89e0: stur            x1, [fp, #-8]
    //     0xdf89e4: mov             x1, x2
    //     0xdf89e8: stur            x2, [fp, #-0x10]
    // 0xdf89ec: CheckStackOverflow
    //     0xdf89ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf89f0: cmp             SP, x16
    //     0xdf89f4: b.ls            #0xdf903c
    // 0xdf89f8: r1 = 6
    //     0xdf89f8: mov             x1, #6
    // 0xdf89fc: r0 = AllocateContext()
    //     0xdf89fc: bl              #0x13de838  ; AllocateContextStub
    // 0xdf8a00: mov             x3, x0
    // 0xdf8a04: ldur            x0, [fp, #-8]
    // 0xdf8a08: stur            x3, [fp, #-0x18]
    // 0xdf8a0c: StoreField: r3->field_f = r0
    //     0xdf8a0c: stur            w0, [x3, #0xf]
    // 0xdf8a10: LoadField: r1 = r0->field_b
    //     0xdf8a10: ldur            w1, [x0, #0xb]
    // 0xdf8a14: DecompressPointer r1
    //     0xdf8a14: add             x1, x1, HEAP, lsl #32
    // 0xdf8a18: cmp             w1, NULL
    // 0xdf8a1c: b.eq            #0xdf9044
    // 0xdf8a20: LoadField: r2 = r1->field_13
    //     0xdf8a20: ldur            w2, [x1, #0x13]
    // 0xdf8a24: DecompressPointer r2
    //     0xdf8a24: add             x2, x2, HEAP, lsl #32
    // 0xdf8a28: LoadField: r1 = r2->field_9f
    //     0xdf8a28: ldur            w1, [x2, #0x9f]
    // 0xdf8a2c: DecompressPointer r1
    //     0xdf8a2c: add             x1, x1, HEAP, lsl #32
    // 0xdf8a30: LoadField: r2 = r1->field_b
    //     0xdf8a30: ldur            w2, [x1, #0xb]
    // 0xdf8a34: r16 = LoadInt32Instr(r2)
    //     0xdf8a34: sbfx            x16, x2, #1, #0x1f
    // 0xdf8a38: scvtf           d0, w16
    // 0xdf8a3c: d1 = 1.500000
    //     0xdf8a3c: fmov            d1, #1.50000000
    // 0xdf8a40: fadd            d2, d0, d1
    // 0xdf8a44: d0 = 1.000000
    //     0xdf8a44: fmov            d0, #1.00000000
    // 0xdf8a48: fdiv            d1, d0, d2
    // 0xdf8a4c: stur            d1, [fp, #-0x58]
    // 0xdf8a50: r1 = <Widget>
    //     0xdf8a50: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xdf8a54: r2 = 0
    //     0xdf8a54: mov             x2, #0
    // 0xdf8a58: r0 = _GrowableList()
    //     0xdf8a58: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xdf8a5c: ldur            x1, [fp, #-0x10]
    // 0xdf8a60: stur            x0, [fp, #-0x20]
    // 0xdf8a64: r0 = of()
    //     0xdf8a64: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xdf8a68: ldur            x1, [fp, #-0x10]
    // 0xdf8a6c: stur            x0, [fp, #-0x28]
    // 0xdf8a70: r0 = of()
    //     0xdf8a70: bl              #0xdf85e0  ; [package:flutter/src/material/popup_menu_theme.dart] PopupMenuTheme::of
    // 0xdf8a74: ldur            x1, [fp, #-0x18]
    // 0xdf8a78: StoreField: r1->field_13 = r0
    //     0xdf8a78: stur            w0, [x1, #0x13]
    //     0xdf8a7c: ldurb           w16, [x1, #-1]
    //     0xdf8a80: ldurb           w17, [x0, #-1]
    //     0xdf8a84: and             x16, x17, x16, lsr #2
    //     0xdf8a88: tst             x16, HEAP, lsr #32
    //     0xdf8a8c: b.eq            #0xdf8a94
    //     0xdf8a90: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdf8a94: ldur            x0, [fp, #-0x28]
    // 0xdf8a98: LoadField: r2 = r0->field_2f
    //     0xdf8a98: ldur            w2, [x0, #0x2f]
    // 0xdf8a9c: DecompressPointer r2
    //     0xdf8a9c: add             x2, x2, HEAP, lsl #32
    // 0xdf8aa0: tbnz            w2, #4, #0xdf8adc
    // 0xdf8aa4: ldur            x0, [fp, #-0x10]
    // 0xdf8aa8: r0 = _PopupMenuDefaultsM3()
    //     0xdf8aa8: bl              #0xdf85d4  ; Allocate_PopupMenuDefaultsM3Stub -> _PopupMenuDefaultsM3 (size=0x4c)
    // 0xdf8aac: mov             x1, x0
    // 0xdf8ab0: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf8ab4: StoreField: r1->field_3f = r0
    //     0xdf8ab4: stur            w0, [x1, #0x3f]
    // 0xdf8ab8: StoreField: r1->field_43 = r0
    //     0xdf8ab8: stur            w0, [x1, #0x43]
    // 0xdf8abc: StoreField: r1->field_47 = r0
    //     0xdf8abc: stur            w0, [x1, #0x47]
    // 0xdf8ac0: ldur            x2, [fp, #-0x10]
    // 0xdf8ac4: StoreField: r1->field_3b = r2
    //     0xdf8ac4: stur            w2, [x1, #0x3b]
    // 0xdf8ac8: r0 = 3.000000
    //     0xdf8ac8: add             x0, PP, #0x22, lsl #12  ; [pp+0x223f8] 3
    //     0xdf8acc: ldr             x0, [x0, #0x3f8]
    // 0xdf8ad0: StoreField: r1->field_13 = r0
    //     0xdf8ad0: stur            w0, [x1, #0x13]
    // 0xdf8ad4: mov             x0, x1
    // 0xdf8ad8: b               #0xdf8b10
    // 0xdf8adc: ldur            x2, [fp, #-0x10]
    // 0xdf8ae0: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf8ae4: r0 = _PopupMenuDefaultsM2()
    //     0xdf8ae4: bl              #0xdf85c8  ; Allocate_PopupMenuDefaultsM2Stub -> _PopupMenuDefaultsM2 (size=0x48)
    // 0xdf8ae8: mov             x1, x0
    // 0xdf8aec: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf8af0: StoreField: r1->field_3f = r0
    //     0xdf8af0: stur            w0, [x1, #0x3f]
    // 0xdf8af4: StoreField: r1->field_43 = r0
    //     0xdf8af4: stur            w0, [x1, #0x43]
    // 0xdf8af8: ldur            x0, [fp, #-0x10]
    // 0xdf8afc: StoreField: r1->field_3b = r0
    //     0xdf8afc: stur            w0, [x1, #0x3b]
    // 0xdf8b00: r0 = 8.000000
    //     0xdf8b00: add             x0, PP, #0x19, lsl #12  ; [pp+0x19e08] 8
    //     0xdf8b04: ldr             x0, [x0, #0xe08]
    // 0xdf8b08: StoreField: r1->field_13 = r0
    //     0xdf8b08: stur            w0, [x1, #0x13]
    // 0xdf8b0c: mov             x0, x1
    // 0xdf8b10: ldur            x1, [fp, #-0x18]
    // 0xdf8b14: ArrayStore: r1[0] = r0  ; List_4
    //     0xdf8b14: stur            w0, [x1, #0x17]
    //     0xdf8b18: ldurb           w16, [x1, #-1]
    //     0xdf8b1c: ldurb           w17, [x0, #-1]
    //     0xdf8b20: and             x16, x17, x16, lsr #2
    //     0xdf8b24: tst             x16, HEAP, lsr #32
    //     0xdf8b28: b.eq            #0xdf8b30
    //     0xdf8b2c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdf8b30: r1 = 1
    //     0xdf8b30: mov             x1, #1
    // 0xdf8b34: r0 = AllocateContext()
    //     0xdf8b34: bl              #0x13de838  ; AllocateContextStub
    // 0xdf8b38: mov             x1, x0
    // 0xdf8b3c: ldur            x0, [fp, #-0x18]
    // 0xdf8b40: StoreField: r1->field_b = r0
    //     0xdf8b40: stur            w0, [x1, #0xb]
    // 0xdf8b44: StoreField: r1->field_f = rZR
    //     0xdf8b44: stur            wzr, [x1, #0xf]
    // 0xdf8b48: mov             x5, x1
    // 0xdf8b4c: r4 = 0
    //     0xdf8b4c: mov             x4, #0
    // 0xdf8b50: ldur            x3, [fp, #-8]
    // 0xdf8b54: ldur            x2, [fp, #-0x20]
    // 0xdf8b58: stur            x5, [fp, #-0x10]
    // 0xdf8b5c: CheckStackOverflow
    //     0xdf8b5c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf8b60: cmp             SP, x16
    //     0xdf8b64: b.ls            #0xdf9048
    // 0xdf8b68: LoadField: r0 = r3->field_b
    //     0xdf8b68: ldur            w0, [x3, #0xb]
    // 0xdf8b6c: DecompressPointer r0
    //     0xdf8b6c: add             x0, x0, HEAP, lsl #32
    // 0xdf8b70: stur            x0, [fp, #-0x50]
    // 0xdf8b74: cmp             w0, NULL
    // 0xdf8b78: b.eq            #0xdf9050
    // 0xdf8b7c: LoadField: r1 = r0->field_13
    //     0xdf8b7c: ldur            w1, [x0, #0x13]
    // 0xdf8b80: DecompressPointer r1
    //     0xdf8b80: add             x1, x1, HEAP, lsl #32
    // 0xdf8b84: LoadField: r6 = r1->field_9f
    //     0xdf8b84: ldur            w6, [x1, #0x9f]
    // 0xdf8b88: DecompressPointer r6
    //     0xdf8b88: add             x6, x6, HEAP, lsl #32
    // 0xdf8b8c: LoadField: r7 = r6->field_b
    //     0xdf8b8c: ldur            w7, [x6, #0xb]
    // 0xdf8b90: stur            x7, [fp, #-0x48]
    // 0xdf8b94: r1 = LoadInt32Instr(r7)
    //     0xdf8b94: sbfx            x1, x7, #1, #0x1f
    // 0xdf8b98: cmp             x4, x1
    // 0xdf8b9c: b.ge            #0xdf8db4
    // 0xdf8ba0: LoadField: r6 = r3->field_13
    //     0xdf8ba0: ldur            w6, [x3, #0x13]
    // 0xdf8ba4: DecompressPointer r6
    //     0xdf8ba4: add             x6, x6, HEAP, lsl #32
    // 0xdf8ba8: r0 = BoxInt64Instr(r4)
    //     0xdf8ba8: sbfiz           x0, x4, #1, #0x1f
    //     0xdf8bac: cmp             x4, x0, asr #1
    //     0xdf8bb0: b.eq            #0xdf8bbc
    //     0xdf8bb4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xdf8bb8: stur            x4, [x0, #7]
    // 0xdf8bbc: r1 = LoadClassIdInstr(r6)
    //     0xdf8bbc: ldur            x1, [x6, #-1]
    //     0xdf8bc0: ubfx            x1, x1, #0xc, #0x14
    // 0xdf8bc4: stp             x0, x6, [SP]
    // 0xdf8bc8: mov             x0, x1
    // 0xdf8bcc: r0 = GDT[cid_x0 + -0xdfd]()
    //     0xdf8bcc: sub             lr, x0, #0xdfd
    //     0xdf8bd0: ldr             lr, [x21, lr, lsl #3]
    //     0xdf8bd4: blr             lr
    // 0xdf8bd8: mov             x3, x0
    // 0xdf8bdc: ldur            x2, [fp, #-8]
    // 0xdf8be0: stur            x3, [fp, #-0x30]
    // 0xdf8be4: LoadField: r4 = r2->field_b
    //     0xdf8be4: ldur            w4, [x2, #0xb]
    // 0xdf8be8: DecompressPointer r4
    //     0xdf8be8: add             x4, x4, HEAP, lsl #32
    // 0xdf8bec: cmp             w4, NULL
    // 0xdf8bf0: b.eq            #0xdf9054
    // 0xdf8bf4: LoadField: r0 = r4->field_13
    //     0xdf8bf4: ldur            w0, [x4, #0x13]
    // 0xdf8bf8: DecompressPointer r0
    //     0xdf8bf8: add             x0, x0, HEAP, lsl #32
    // 0xdf8bfc: LoadField: r5 = r0->field_9f
    //     0xdf8bfc: ldur            w5, [x0, #0x9f]
    // 0xdf8c00: DecompressPointer r5
    //     0xdf8c00: add             x5, x5, HEAP, lsl #32
    // 0xdf8c04: ldur            x6, [fp, #-0x10]
    // 0xdf8c08: LoadField: r0 = r6->field_f
    //     0xdf8c08: ldur            w0, [x6, #0xf]
    // 0xdf8c0c: DecompressPointer r0
    //     0xdf8c0c: add             x0, x0, HEAP, lsl #32
    // 0xdf8c10: LoadField: r1 = r5->field_b
    //     0xdf8c10: ldur            w1, [x5, #0xb]
    // 0xdf8c14: r7 = LoadInt32Instr(r0)
    //     0xdf8c14: sbfx            x7, x0, #1, #0x1f
    //     0xdf8c18: tbz             w0, #0, #0xdf8c20
    //     0xdf8c1c: ldur            x7, [x0, #7]
    // 0xdf8c20: r0 = LoadInt32Instr(r1)
    //     0xdf8c20: sbfx            x0, x1, #1, #0x1f
    // 0xdf8c24: mov             x1, x7
    // 0xdf8c28: cmp             x1, x0
    // 0xdf8c2c: b.hs            #0xdf9058
    // 0xdf8c30: LoadField: r0 = r5->field_f
    //     0xdf8c30: ldur            w0, [x5, #0xf]
    // 0xdf8c34: DecompressPointer r0
    //     0xdf8c34: add             x0, x0, HEAP, lsl #32
    // 0xdf8c38: ArrayLoad: r5 = r0[r7]  ; Unknown_4
    //     0xdf8c38: add             x16, x0, x7, lsl #2
    //     0xdf8c3c: ldur            w5, [x16, #0xf]
    // 0xdf8c40: DecompressPointer r5
    //     0xdf8c40: add             x5, x5, HEAP, lsl #32
    // 0xdf8c44: stur            x5, [fp, #-0x28]
    // 0xdf8c48: LoadField: r8 = r4->field_f
    //     0xdf8c48: ldur            w8, [x4, #0xf]
    // 0xdf8c4c: DecompressPointer r8
    //     0xdf8c4c: add             x8, x8, HEAP, lsl #32
    // 0xdf8c50: LoadField: r0 = r8->field_b
    //     0xdf8c50: ldur            w0, [x8, #0xb]
    // 0xdf8c54: r1 = LoadInt32Instr(r0)
    //     0xdf8c54: sbfx            x1, x0, #1, #0x1f
    // 0xdf8c58: mov             x0, x1
    // 0xdf8c5c: mov             x1, x7
    // 0xdf8c60: cmp             x1, x0
    // 0xdf8c64: b.hs            #0xdf905c
    // 0xdf8c68: LoadField: r0 = r8->field_f
    //     0xdf8c68: ldur            w0, [x8, #0xf]
    // 0xdf8c6c: DecompressPointer r0
    //     0xdf8c6c: add             x0, x0, HEAP, lsl #32
    // 0xdf8c70: ArrayLoad: r1 = r0[r7]  ; Unknown_4
    //     0xdf8c70: add             x16, x0, x7, lsl #2
    //     0xdf8c74: ldur            w1, [x16, #0xf]
    // 0xdf8c78: DecompressPointer r1
    //     0xdf8c78: add             x1, x1, HEAP, lsl #32
    // 0xdf8c7c: stur            x1, [fp, #-0x18]
    // 0xdf8c80: r0 = FadeTransition()
    //     0xdf8c80: bl              #0xb28358  ; AllocateFadeTransitionStub -> FadeTransition (size=0x18)
    // 0xdf8c84: mov             x3, x0
    // 0xdf8c88: ldur            x0, [fp, #-0x30]
    // 0xdf8c8c: stur            x3, [fp, #-0x38]
    // 0xdf8c90: StoreField: r3->field_f = r0
    //     0xdf8c90: stur            w0, [x3, #0xf]
    // 0xdf8c94: r0 = false
    //     0xdf8c94: add             x0, NULL, #0x30  ; false
    // 0xdf8c98: StoreField: r3->field_13 = r0
    //     0xdf8c98: stur            w0, [x3, #0x13]
    // 0xdf8c9c: ldur            x1, [fp, #-0x28]
    // 0xdf8ca0: StoreField: r3->field_b = r1
    //     0xdf8ca0: stur            w1, [x3, #0xb]
    // 0xdf8ca4: ldur            x1, [fp, #-0x18]
    // 0xdf8ca8: StoreField: r3->field_7 = r1
    //     0xdf8ca8: stur            w1, [x3, #7]
    // 0xdf8cac: ldur            x2, [fp, #-0x10]
    // 0xdf8cb0: r1 = Function '<anonymous closure>':.
    //     0xdf8cb0: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4b40] AnonymousClosure: (0xdf9574), in [package:flutter/src/material/popup_menu.dart] _PopupMenuState::build (0xdf89d0)
    //     0xdf8cb4: ldr             x1, [x1, #0xb40]
    // 0xdf8cb8: r0 = AllocateClosure()
    //     0xdf8cb8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf8cbc: stur            x0, [fp, #-0x18]
    // 0xdf8cc0: r0 = _MenuItem()
    //     0xdf8cc0: bl              #0xdf9164  ; Allocate_MenuItemStub -> _MenuItem (size=0x14)
    // 0xdf8cc4: mov             x2, x0
    // 0xdf8cc8: ldur            x0, [fp, #-0x18]
    // 0xdf8ccc: stur            x2, [fp, #-0x28]
    // 0xdf8cd0: StoreField: r2->field_f = r0
    //     0xdf8cd0: stur            w0, [x2, #0xf]
    // 0xdf8cd4: ldur            x0, [fp, #-0x38]
    // 0xdf8cd8: StoreField: r2->field_b = r0
    //     0xdf8cd8: stur            w0, [x2, #0xb]
    // 0xdf8cdc: ldur            x0, [fp, #-0x20]
    // 0xdf8ce0: LoadField: r1 = r0->field_b
    //     0xdf8ce0: ldur            w1, [x0, #0xb]
    // 0xdf8ce4: LoadField: r3 = r0->field_f
    //     0xdf8ce4: ldur            w3, [x0, #0xf]
    // 0xdf8ce8: DecompressPointer r3
    //     0xdf8ce8: add             x3, x3, HEAP, lsl #32
    // 0xdf8cec: LoadField: r4 = r3->field_b
    //     0xdf8cec: ldur            w4, [x3, #0xb]
    // 0xdf8cf0: r3 = LoadInt32Instr(r1)
    //     0xdf8cf0: sbfx            x3, x1, #1, #0x1f
    // 0xdf8cf4: stur            x3, [fp, #-0x40]
    // 0xdf8cf8: r1 = LoadInt32Instr(r4)
    //     0xdf8cf8: sbfx            x1, x4, #1, #0x1f
    // 0xdf8cfc: cmp             x3, x1
    // 0xdf8d00: b.ne            #0xdf8d0c
    // 0xdf8d04: mov             x1, x0
    // 0xdf8d08: r0 = _growToNextCapacity()
    //     0xdf8d08: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xdf8d0c: ldur            x2, [fp, #-0x20]
    // 0xdf8d10: ldur            x3, [fp, #-0x40]
    // 0xdf8d14: add             x0, x3, #1
    // 0xdf8d18: lsl             x1, x0, #1
    // 0xdf8d1c: StoreField: r2->field_b = r1
    //     0xdf8d1c: stur            w1, [x2, #0xb]
    // 0xdf8d20: LoadField: r1 = r2->field_f
    //     0xdf8d20: ldur            w1, [x2, #0xf]
    // 0xdf8d24: DecompressPointer r1
    //     0xdf8d24: add             x1, x1, HEAP, lsl #32
    // 0xdf8d28: ldur            x0, [fp, #-0x28]
    // 0xdf8d2c: ArrayStore: r1[r3] = r0  ; List_4
    //     0xdf8d2c: add             x25, x1, x3, lsl #2
    //     0xdf8d30: add             x25, x25, #0xf
    //     0xdf8d34: str             w0, [x25]
    //     0xdf8d38: tbz             w0, #0, #0xdf8d54
    //     0xdf8d3c: ldurb           w16, [x1, #-1]
    //     0xdf8d40: ldurb           w17, [x0, #-1]
    //     0xdf8d44: and             x16, x17, x16, lsr #2
    //     0xdf8d48: tst             x16, HEAP, lsr #32
    //     0xdf8d4c: b.eq            #0xdf8d54
    //     0xdf8d50: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdf8d54: ldur            x5, [fp, #-0x10]
    // 0xdf8d58: r0 = CloneContext()
    //     0xdf8d58: bl              #0x13de1f4  ; CloneContextStub
    // 0xdf8d5c: mov             x2, x0
    // 0xdf8d60: LoadField: r0 = r2->field_f
    //     0xdf8d60: ldur            w0, [x2, #0xf]
    // 0xdf8d64: DecompressPointer r0
    //     0xdf8d64: add             x0, x0, HEAP, lsl #32
    // 0xdf8d68: r1 = LoadInt32Instr(r0)
    //     0xdf8d68: sbfx            x1, x0, #1, #0x1f
    //     0xdf8d6c: tbz             w0, #0, #0xdf8d74
    //     0xdf8d70: ldur            x1, [x0, #7]
    // 0xdf8d74: add             x4, x1, #1
    // 0xdf8d78: r0 = BoxInt64Instr(r4)
    //     0xdf8d78: sbfiz           x0, x4, #1, #0x1f
    //     0xdf8d7c: cmp             x4, x0, asr #1
    //     0xdf8d80: b.eq            #0xdf8d8c
    //     0xdf8d84: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xdf8d88: stur            x4, [x0, #7]
    // 0xdf8d8c: StoreField: r2->field_f = r0
    //     0xdf8d8c: stur            w0, [x2, #0xf]
    //     0xdf8d90: tbz             w0, #0, #0xdf8dac
    //     0xdf8d94: ldurb           w16, [x2, #-1]
    //     0xdf8d98: ldurb           w17, [x0, #-1]
    //     0xdf8d9c: and             x16, x17, x16, lsr #2
    //     0xdf8da0: tst             x16, HEAP, lsr #32
    //     0xdf8da4: b.eq            #0xdf8dac
    //     0xdf8da8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xdf8dac: mov             x5, x2
    // 0xdf8db0: b               #0xdf8b50
    // 0xdf8db4: ldur            d0, [fp, #-0x58]
    // 0xdf8db8: mov             x1, x5
    // 0xdf8dbc: LoadField: r4 = r1->field_b
    //     0xdf8dbc: ldur            w4, [x1, #0xb]
    // 0xdf8dc0: DecompressPointer r4
    //     0xdf8dc0: add             x4, x4, HEAP, lsl #32
    // 0xdf8dc4: stur            x4, [fp, #-0x18]
    // 0xdf8dc8: r1 = <double>
    //     0xdf8dc8: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xdf8dcc: r0 = CurveTween()
    //     0xdf8dcc: bl              #0xb280f4  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0xdf8dd0: mov             x1, x0
    // 0xdf8dd4: r0 = Instance_Interval
    //     0xdf8dd4: add             x0, PP, #0xd4, lsl #12  ; [pp+0xd4b48] Obj!Interval@129fa91
    //     0xdf8dd8: ldr             x0, [x0, #0xb48]
    // 0xdf8ddc: StoreField: r1->field_b = r0
    //     0xdf8ddc: stur            w0, [x1, #0xb]
    // 0xdf8de0: mov             x0, x1
    // 0xdf8de4: ldur            x2, [fp, #-0x18]
    // 0xdf8de8: StoreField: r2->field_1b = r0
    //     0xdf8de8: stur            w0, [x2, #0x1b]
    //     0xdf8dec: ldurb           w16, [x2, #-1]
    //     0xdf8df0: ldurb           w17, [x0, #-1]
    //     0xdf8df4: and             x16, x17, x16, lsr #2
    //     0xdf8df8: tst             x16, HEAP, lsr #32
    //     0xdf8dfc: b.eq            #0xdf8e04
    //     0xdf8e00: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xdf8e04: r1 = <double>
    //     0xdf8e04: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xdf8e08: r0 = Interval()
    //     0xdf8e08: bl              #0xc0c688  ; AllocateIntervalStub -> Interval (size=0x20)
    // 0xdf8e0c: stur            x0, [fp, #-0x10]
    // 0xdf8e10: StoreField: r0->field_b = rZR
    //     0xdf8e10: stur            xzr, [x0, #0xb]
    // 0xdf8e14: ldur            d0, [fp, #-0x58]
    // 0xdf8e18: StoreField: r0->field_13 = d0
    //     0xdf8e18: stur            d0, [x0, #0x13]
    // 0xdf8e1c: r2 = Instance__Linear
    //     0xdf8e1c: ldr             x2, [PP, #0x5168]  ; [pp+0x5168] Obj!_Linear@129fef1
    // 0xdf8e20: StoreField: r0->field_1b = r2
    //     0xdf8e20: stur            w2, [x0, #0x1b]
    // 0xdf8e24: r1 = <double>
    //     0xdf8e24: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xdf8e28: r0 = CurveTween()
    //     0xdf8e28: bl              #0xb280f4  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0xdf8e2c: mov             x1, x0
    // 0xdf8e30: ldur            x0, [fp, #-0x10]
    // 0xdf8e34: StoreField: r1->field_b = r0
    //     0xdf8e34: stur            w0, [x1, #0xb]
    // 0xdf8e38: mov             x0, x1
    // 0xdf8e3c: ldur            x2, [fp, #-0x18]
    // 0xdf8e40: StoreField: r2->field_1f = r0
    //     0xdf8e40: stur            w0, [x2, #0x1f]
    //     0xdf8e44: ldurb           w16, [x2, #-1]
    //     0xdf8e48: ldurb           w17, [x0, #-1]
    //     0xdf8e4c: and             x16, x17, x16, lsr #2
    //     0xdf8e50: tst             x16, HEAP, lsr #32
    //     0xdf8e54: b.eq            #0xdf8e5c
    //     0xdf8e58: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xdf8e5c: ldur            x0, [fp, #-0x48]
    // 0xdf8e60: r16 = LoadInt32Instr(r0)
    //     0xdf8e60: sbfx            x16, x0, #1, #0x1f
    // 0xdf8e64: scvtf           d0, w16
    // 0xdf8e68: ldur            d1, [fp, #-0x58]
    // 0xdf8e6c: fmul            d2, d1, d0
    // 0xdf8e70: stur            d2, [fp, #-0x60]
    // 0xdf8e74: r1 = <double>
    //     0xdf8e74: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xdf8e78: r0 = Interval()
    //     0xdf8e78: bl              #0xc0c688  ; AllocateIntervalStub -> Interval (size=0x20)
    // 0xdf8e7c: stur            x0, [fp, #-0x10]
    // 0xdf8e80: StoreField: r0->field_b = rZR
    //     0xdf8e80: stur            xzr, [x0, #0xb]
    // 0xdf8e84: ldur            d0, [fp, #-0x60]
    // 0xdf8e88: StoreField: r0->field_13 = d0
    //     0xdf8e88: stur            d0, [x0, #0x13]
    // 0xdf8e8c: r1 = Instance__Linear
    //     0xdf8e8c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] Obj!_Linear@129fef1
    // 0xdf8e90: StoreField: r0->field_1b = r1
    //     0xdf8e90: stur            w1, [x0, #0x1b]
    // 0xdf8e94: r1 = <double>
    //     0xdf8e94: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xdf8e98: r0 = CurveTween()
    //     0xdf8e98: bl              #0xb280f4  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0xdf8e9c: mov             x1, x0
    // 0xdf8ea0: ldur            x0, [fp, #-0x10]
    // 0xdf8ea4: StoreField: r1->field_b = r0
    //     0xdf8ea4: stur            w0, [x1, #0xb]
    // 0xdf8ea8: mov             x0, x1
    // 0xdf8eac: ldur            x2, [fp, #-0x18]
    // 0xdf8eb0: StoreField: r2->field_23 = r0
    //     0xdf8eb0: stur            w0, [x2, #0x23]
    //     0xdf8eb4: ldurb           w16, [x2, #-1]
    //     0xdf8eb8: ldurb           w17, [x0, #-1]
    //     0xdf8ebc: and             x16, x17, x16, lsr #2
    //     0xdf8ec0: tst             x16, HEAP, lsr #32
    //     0xdf8ec4: b.eq            #0xdf8ecc
    //     0xdf8ec8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xdf8ecc: ldur            x0, [fp, #-0x50]
    // 0xdf8ed0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdf8ed0: ldur            w1, [x0, #0x17]
    // 0xdf8ed4: DecompressPointer r1
    //     0xdf8ed4: add             x1, x1, HEAP, lsl #32
    // 0xdf8ed8: stur            x1, [fp, #-0x10]
    // 0xdf8edc: r0 = ListBody()
    //     0xdf8edc: bl              #0xdf9158  ; AllocateListBodyStub -> ListBody (size=0x18)
    // 0xdf8ee0: mov             x1, x0
    // 0xdf8ee4: r0 = Instance_Axis
    //     0xdf8ee4: ldr             x0, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xdf8ee8: stur            x1, [fp, #-0x28]
    // 0xdf8eec: StoreField: r1->field_f = r0
    //     0xdf8eec: stur            w0, [x1, #0xf]
    // 0xdf8ef0: r2 = false
    //     0xdf8ef0: add             x2, NULL, #0x30  ; false
    // 0xdf8ef4: StoreField: r1->field_13 = r2
    //     0xdf8ef4: stur            w2, [x1, #0x13]
    // 0xdf8ef8: ldur            x3, [fp, #-0x20]
    // 0xdf8efc: StoreField: r1->field_b = r3
    //     0xdf8efc: stur            w3, [x1, #0xb]
    // 0xdf8f00: r0 = SingleChildScrollView()
    //     0xdf8f00: bl              #0xdc8fa4  ; AllocateSingleChildScrollViewStub -> SingleChildScrollView (size=0x3c)
    // 0xdf8f04: mov             x1, x0
    // 0xdf8f08: r0 = Instance_Axis
    //     0xdf8f08: ldr             x0, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xdf8f0c: stur            x1, [fp, #-0x20]
    // 0xdf8f10: StoreField: r1->field_b = r0
    //     0xdf8f10: stur            w0, [x1, #0xb]
    // 0xdf8f14: r0 = false
    //     0xdf8f14: add             x0, NULL, #0x30  ; false
    // 0xdf8f18: StoreField: r1->field_f = r0
    //     0xdf8f18: stur            w0, [x1, #0xf]
    // 0xdf8f1c: r0 = Instance_EdgeInsets
    //     0xdf8f1c: add             x0, PP, #0x26, lsl #12  ; [pp+0x262d8] Obj!EdgeInsets@129d5f1
    //     0xdf8f20: ldr             x0, [x0, #0x2d8]
    // 0xdf8f24: StoreField: r1->field_13 = r0
    //     0xdf8f24: stur            w0, [x1, #0x13]
    // 0xdf8f28: ldur            x0, [fp, #-0x28]
    // 0xdf8f2c: StoreField: r1->field_23 = r0
    //     0xdf8f2c: stur            w0, [x1, #0x23]
    // 0xdf8f30: r0 = Instance_DragStartBehavior
    //     0xdf8f30: ldr             x0, [PP, #0x5360]  ; [pp+0x5360] Obj!DragStartBehavior@12c5c61
    // 0xdf8f34: StoreField: r1->field_27 = r0
    //     0xdf8f34: stur            w0, [x1, #0x27]
    // 0xdf8f38: r0 = Instance_Clip
    //     0xdf8f38: add             x0, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xdf8f3c: ldr             x0, [x0, #0x850]
    // 0xdf8f40: StoreField: r1->field_2b = r0
    //     0xdf8f40: stur            w0, [x1, #0x2b]
    // 0xdf8f44: r0 = Instance_HitTestBehavior
    //     0xdf8f44: add             x0, PP, #0x15, lsl #12  ; [pp+0x155c0] Obj!HitTestBehavior@12c43c1
    //     0xdf8f48: ldr             x0, [x0, #0x5c0]
    // 0xdf8f4c: StoreField: r1->field_2f = r0
    //     0xdf8f4c: stur            w0, [x1, #0x2f]
    // 0xdf8f50: r0 = Semantics()
    //     0xdf8f50: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xdf8f54: stur            x0, [fp, #-0x28]
    // 0xdf8f58: r16 = Instance_SemanticsRole
    //     0xdf8f58: add             x16, PP, #0xd1, lsl #12  ; [pp+0xd1df8] Obj!SemanticsRole@12c7961
    //     0xdf8f5c: ldr             x16, [x16, #0xdf8]
    // 0xdf8f60: r30 = true
    //     0xdf8f60: add             lr, NULL, #0x20  ; true
    // 0xdf8f64: stp             lr, x16, [SP, #0x20]
    // 0xdf8f68: r16 = true
    //     0xdf8f68: add             x16, NULL, #0x20  ; true
    // 0xdf8f6c: r30 = true
    //     0xdf8f6c: add             lr, NULL, #0x20  ; true
    // 0xdf8f70: stp             lr, x16, [SP, #0x10]
    // 0xdf8f74: ldur            x16, [fp, #-0x10]
    // 0xdf8f78: ldur            lr, [fp, #-0x20]
    // 0xdf8f7c: stp             lr, x16, [SP]
    // 0xdf8f80: mov             x1, x0
    // 0xdf8f84: r4 = const [0, 0x7, 0x6, 0x1, child, 0x6, explicitChildNodes, 0x4, label, 0x5, namesRoute, 0x3, role, 0x1, scopesRoute, 0x2, null]
    //     0xdf8f84: add             x4, PP, #0xd1, lsl #12  ; [pp+0xd1e00] List(17) [0, 0x7, 0x6, 0x1, "child", 0x6, "explicitChildNodes", 0x4, "label", 0x5, "namesRoute", 0x3, "role", 0x1, "scopesRoute", 0x2, Null]
    //     0xdf8f88: ldr             x4, [x4, #0xe00]
    // 0xdf8f8c: r0 = Semantics()
    //     0xdf8f8c: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xdf8f90: r0 = IntrinsicWidth()
    //     0xdf8f90: bl              #0xdf914c  ; AllocateIntrinsicWidthStub -> IntrinsicWidth (size=0x18)
    // 0xdf8f94: mov             x1, x0
    // 0xdf8f98: r0 = 56.000000
    //     0xdf8f98: add             x0, PP, #0x18, lsl #12  ; [pp+0x180d0] 56
    //     0xdf8f9c: ldr             x0, [x0, #0xd0]
    // 0xdf8fa0: stur            x1, [fp, #-0x10]
    // 0xdf8fa4: StoreField: r1->field_f = r0
    //     0xdf8fa4: stur            w0, [x1, #0xf]
    // 0xdf8fa8: ldur            x0, [fp, #-0x28]
    // 0xdf8fac: StoreField: r1->field_b = r0
    //     0xdf8fac: stur            w0, [x1, #0xb]
    // 0xdf8fb0: r0 = ConstrainedBox()
    //     0xdf8fb0: bl              #0xd0a588  ; AllocateConstrainedBoxStub -> ConstrainedBox (size=0x14)
    // 0xdf8fb4: mov             x3, x0
    // 0xdf8fb8: r0 = Instance_BoxConstraints
    //     0xdf8fb8: add             x0, PP, #0xd2, lsl #12  ; [pp+0xd2eb0] Obj!BoxConstraints@129c351
    //     0xdf8fbc: ldr             x0, [x0, #0xeb0]
    // 0xdf8fc0: stur            x3, [fp, #-0x20]
    // 0xdf8fc4: StoreField: r3->field_f = r0
    //     0xdf8fc4: stur            w0, [x3, #0xf]
    // 0xdf8fc8: ldur            x0, [fp, #-0x10]
    // 0xdf8fcc: StoreField: r3->field_b = r0
    //     0xdf8fcc: stur            w0, [x3, #0xb]
    // 0xdf8fd0: ldur            x0, [fp, #-8]
    // 0xdf8fd4: LoadField: r1 = r0->field_b
    //     0xdf8fd4: ldur            w1, [x0, #0xb]
    // 0xdf8fd8: DecompressPointer r1
    //     0xdf8fd8: add             x1, x1, HEAP, lsl #32
    // 0xdf8fdc: cmp             w1, NULL
    // 0xdf8fe0: b.eq            #0xdf9060
    // 0xdf8fe4: LoadField: r0 = r1->field_13
    //     0xdf8fe4: ldur            w0, [x1, #0x13]
    // 0xdf8fe8: DecompressPointer r0
    //     0xdf8fe8: add             x0, x0, HEAP, lsl #32
    // 0xdf8fec: LoadField: r4 = r0->field_6f
    //     0xdf8fec: ldur            w4, [x0, #0x6f]
    // 0xdf8ff0: DecompressPointer r4
    //     0xdf8ff0: add             x4, x4, HEAP, lsl #32
    // 0xdf8ff4: stur            x4, [fp, #-8]
    // 0xdf8ff8: cmp             w4, NULL
    // 0xdf8ffc: b.eq            #0xdf9064
    // 0xdf9000: ldur            x2, [fp, #-0x18]
    // 0xdf9004: r1 = Function '<anonymous closure>':.
    //     0xdf9004: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4b50] AnonymousClosure: (0xdf9170), in [package:flutter/src/material/popup_menu.dart] _PopupMenuState::build (0xdf89d0)
    //     0xdf9008: ldr             x1, [x1, #0xb50]
    // 0xdf900c: r0 = AllocateClosure()
    //     0xdf900c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf9010: stur            x0, [fp, #-0x10]
    // 0xdf9014: r0 = AnimatedBuilder()
    //     0xdf9014: bl              #0x918e2c  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0xdf9018: ldur            x1, [fp, #-0x10]
    // 0xdf901c: StoreField: r0->field_f = r1
    //     0xdf901c: stur            w1, [x0, #0xf]
    // 0xdf9020: ldur            x1, [fp, #-0x20]
    // 0xdf9024: StoreField: r0->field_13 = r1
    //     0xdf9024: stur            w1, [x0, #0x13]
    // 0xdf9028: ldur            x1, [fp, #-8]
    // 0xdf902c: StoreField: r0->field_b = r1
    //     0xdf902c: stur            w1, [x0, #0xb]
    // 0xdf9030: LeaveFrame
    //     0xdf9030: mov             SP, fp
    //     0xdf9034: ldp             fp, lr, [SP], #0x10
    // 0xdf9038: ret
    //     0xdf9038: ret             
    // 0xdf903c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf903c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf9040: b               #0xdf89f8
    // 0xdf9044: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf9044: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf9048: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf9048: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf904c: b               #0xdf8b68
    // 0xdf9050: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf9050: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf9054: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf9054: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf9058: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdf9058: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdf905c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdf905c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdf9060: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf9060: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf9064: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf9064: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] FadeTransition <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0xdf9170, size: 0x404
    // 0xdf9170: EnterFrame
    //     0xdf9170: stp             fp, lr, [SP, #-0x10]!
    //     0xdf9174: mov             fp, SP
    // 0xdf9178: AllocStack(0x50)
    //     0xdf9178: sub             SP, SP, #0x50
    // 0xdf917c: SetupParameters([dynamic _ /* r0 */])
    //     0xdf917c: ldr             x0, [fp, #0x20]
    //     0xdf9180: ldur            w3, [x0, #0x17]
    //     0xdf9184: add             x3, x3, HEAP, lsl #32
    //     0xdf9188: stur            x3, [fp, #-8]
    // 0xdf918c: CheckStackOverflow
    //     0xdf918c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf9190: cmp             SP, x16
    //     0xdf9194: b.ls            #0xdf9548
    // 0xdf9198: LoadField: r1 = r3->field_1b
    //     0xdf9198: ldur            w1, [x3, #0x1b]
    // 0xdf919c: DecompressPointer r1
    //     0xdf919c: add             x1, x1, HEAP, lsl #32
    // 0xdf91a0: LoadField: r0 = r3->field_f
    //     0xdf91a0: ldur            w0, [x3, #0xf]
    // 0xdf91a4: DecompressPointer r0
    //     0xdf91a4: add             x0, x0, HEAP, lsl #32
    // 0xdf91a8: LoadField: r2 = r0->field_b
    //     0xdf91a8: ldur            w2, [x0, #0xb]
    // 0xdf91ac: DecompressPointer r2
    //     0xdf91ac: add             x2, x2, HEAP, lsl #32
    // 0xdf91b0: cmp             w2, NULL
    // 0xdf91b4: b.eq            #0xdf9550
    // 0xdf91b8: LoadField: r0 = r2->field_13
    //     0xdf91b8: ldur            w0, [x2, #0x13]
    // 0xdf91bc: DecompressPointer r0
    //     0xdf91bc: add             x0, x0, HEAP, lsl #32
    // 0xdf91c0: LoadField: r2 = r0->field_6f
    //     0xdf91c0: ldur            w2, [x0, #0x6f]
    // 0xdf91c4: DecompressPointer r2
    //     0xdf91c4: add             x2, x2, HEAP, lsl #32
    // 0xdf91c8: cmp             w2, NULL
    // 0xdf91cc: b.eq            #0xdf9554
    // 0xdf91d0: r0 = animate()
    //     0xdf91d0: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xdf91d4: mov             x2, x0
    // 0xdf91d8: ldur            x0, [fp, #-8]
    // 0xdf91dc: stur            x2, [fp, #-0x28]
    // 0xdf91e0: LoadField: r1 = r0->field_f
    //     0xdf91e0: ldur            w1, [x0, #0xf]
    // 0xdf91e4: DecompressPointer r1
    //     0xdf91e4: add             x1, x1, HEAP, lsl #32
    // 0xdf91e8: LoadField: r3 = r1->field_b
    //     0xdf91e8: ldur            w3, [x1, #0xb]
    // 0xdf91ec: DecompressPointer r3
    //     0xdf91ec: add             x3, x3, HEAP, lsl #32
    // 0xdf91f0: cmp             w3, NULL
    // 0xdf91f4: b.eq            #0xdf9558
    // 0xdf91f8: ArrayLoad: r3 = r0[0]  ; List_4
    //     0xdf91f8: ldur            w3, [x0, #0x17]
    // 0xdf91fc: DecompressPointer r3
    //     0xdf91fc: add             x3, x3, HEAP, lsl #32
    // 0xdf9200: stur            x3, [fp, #-0x20]
    // 0xdf9204: r4 = LoadClassIdInstr(r3)
    //     0xdf9204: ldur            x4, [x3, #-1]
    //     0xdf9208: ubfx            x4, x4, #0xc, #0x14
    // 0xdf920c: stur            x4, [fp, #-0x18]
    // 0xdf9210: r17 = 5129
    //     0xdf9210: mov             x17, #0x1409
    // 0xdf9214: cmp             x4, x17
    // 0xdf9218: b.eq            #0xdf9234
    // 0xdf921c: r17 = 5130
    //     0xdf921c: mov             x17, #0x140a
    // 0xdf9220: cmp             x4, x17
    // 0xdf9224: b.ne            #0xdf9234
    // 0xdf9228: r5 = Instance_RoundedRectangleBorder
    //     0xdf9228: add             x5, PP, #0x26, lsl #12  ; [pp+0x26218] Obj!RoundedRectangleBorder@129ec21
    //     0xdf922c: ldr             x5, [x5, #0x218]
    // 0xdf9230: b               #0xdf9240
    // 0xdf9234: LoadField: r1 = r3->field_b
    //     0xdf9234: ldur            w1, [x3, #0xb]
    // 0xdf9238: DecompressPointer r1
    //     0xdf9238: add             x1, x1, HEAP, lsl #32
    // 0xdf923c: mov             x5, x1
    // 0xdf9240: stur            x5, [fp, #-0x10]
    // 0xdf9244: r17 = 5129
    //     0xdf9244: mov             x17, #0x1409
    // 0xdf9248: cmp             x4, x17
    // 0xdf924c: b.ne            #0xdf9258
    // 0xdf9250: mov             x0, x3
    // 0xdf9254: b               #0xdf92bc
    // 0xdf9258: r17 = 5130
    //     0xdf9258: mov             x17, #0x140a
    // 0xdf925c: cmp             x4, x17
    // 0xdf9260: b.ne            #0xdf92b8
    // 0xdf9264: mov             x1, x3
    // 0xdf9268: LoadField: r0 = r1->field_43
    //     0xdf9268: ldur            w0, [x1, #0x43]
    // 0xdf926c: DecompressPointer r0
    //     0xdf926c: add             x0, x0, HEAP, lsl #32
    // 0xdf9270: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf9274: cmp             w0, w16
    // 0xdf9278: b.ne            #0xdf9288
    // 0xdf927c: r2 = _colors
    //     0xdf927c: add             x2, PP, #0x26, lsl #12  ; [pp+0x262d0] Field <_PopupMenuDefaultsM3@113182389._colors@113182389>: late final (offset: 0x44)
    //     0xdf9280: ldr             x2, [x2, #0x2d0]
    // 0xdf9284: r0 = InitLateFinalInstanceField()
    //     0xdf9284: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf9288: LoadField: r1 = r0->field_97
    //     0xdf9288: ldur            w1, [x0, #0x97]
    // 0xdf928c: DecompressPointer r1
    //     0xdf928c: add             x1, x1, HEAP, lsl #32
    // 0xdf9290: cmp             w1, NULL
    // 0xdf9294: b.ne            #0xdf92a8
    // 0xdf9298: LoadField: r1 = r0->field_7b
    //     0xdf9298: ldur            w1, [x0, #0x7b]
    // 0xdf929c: DecompressPointer r1
    //     0xdf929c: add             x1, x1, HEAP, lsl #32
    // 0xdf92a0: mov             x0, x1
    // 0xdf92a4: b               #0xdf92ac
    // 0xdf92a8: mov             x0, x1
    // 0xdf92ac: mov             x3, x0
    // 0xdf92b0: ldur            x0, [fp, #-0x20]
    // 0xdf92b4: b               #0xdf92c8
    // 0xdf92b8: ldur            x0, [fp, #-0x20]
    // 0xdf92bc: LoadField: r1 = r0->field_7
    //     0xdf92bc: ldur            w1, [x0, #7]
    // 0xdf92c0: DecompressPointer r1
    //     0xdf92c0: add             x1, x1, HEAP, lsl #32
    // 0xdf92c4: mov             x3, x1
    // 0xdf92c8: ldur            x2, [fp, #-8]
    // 0xdf92cc: stur            x3, [fp, #-0x30]
    // 0xdf92d0: LoadField: r1 = r2->field_f
    //     0xdf92d0: ldur            w1, [x2, #0xf]
    // 0xdf92d4: DecompressPointer r1
    //     0xdf92d4: add             x1, x1, HEAP, lsl #32
    // 0xdf92d8: LoadField: r4 = r1->field_b
    //     0xdf92d8: ldur            w4, [x1, #0xb]
    // 0xdf92dc: DecompressPointer r4
    //     0xdf92dc: add             x4, x4, HEAP, lsl #32
    // 0xdf92e0: cmp             w4, NULL
    // 0xdf92e4: b.eq            #0xdf955c
    // 0xdf92e8: LoadField: r1 = r2->field_13
    //     0xdf92e8: ldur            w1, [x2, #0x13]
    // 0xdf92ec: DecompressPointer r1
    //     0xdf92ec: add             x1, x1, HEAP, lsl #32
    // 0xdf92f0: LoadField: r4 = r1->field_13
    //     0xdf92f0: ldur            w4, [x1, #0x13]
    // 0xdf92f4: DecompressPointer r4
    //     0xdf92f4: add             x4, x4, HEAP, lsl #32
    // 0xdf92f8: cmp             w4, NULL
    // 0xdf92fc: b.ne            #0xdf9318
    // 0xdf9300: LoadField: r1 = r0->field_13
    //     0xdf9300: ldur            w1, [x0, #0x13]
    // 0xdf9304: DecompressPointer r1
    //     0xdf9304: add             x1, x1, HEAP, lsl #32
    // 0xdf9308: cmp             w1, NULL
    // 0xdf930c: b.eq            #0xdf9560
    // 0xdf9310: LoadField: d0 = r1->field_7
    //     0xdf9310: ldur            d0, [x1, #7]
    // 0xdf9314: b               #0xdf931c
    // 0xdf9318: LoadField: d0 = r4->field_7
    //     0xdf9318: ldur            d0, [x4, #7]
    // 0xdf931c: ldur            x4, [fp, #-0x18]
    // 0xdf9320: stur            d0, [fp, #-0x50]
    // 0xdf9324: r17 = 5129
    //     0xdf9324: mov             x17, #0x1409
    // 0xdf9328: cmp             x4, x17
    // 0xdf932c: b.eq            #0xdf9390
    // 0xdf9330: r17 = 5130
    //     0xdf9330: mov             x17, #0x140a
    // 0xdf9334: cmp             x4, x17
    // 0xdf9338: b.ne            #0xdf938c
    // 0xdf933c: mov             x1, x0
    // 0xdf9340: LoadField: r0 = r1->field_43
    //     0xdf9340: ldur            w0, [x1, #0x43]
    // 0xdf9344: DecompressPointer r0
    //     0xdf9344: add             x0, x0, HEAP, lsl #32
    // 0xdf9348: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf934c: cmp             w0, w16
    // 0xdf9350: b.ne            #0xdf9360
    // 0xdf9354: r2 = _colors
    //     0xdf9354: add             x2, PP, #0x26, lsl #12  ; [pp+0x262d0] Field <_PopupMenuDefaultsM3@113182389._colors@113182389>: late final (offset: 0x44)
    //     0xdf9358: ldr             x2, [x2, #0x2d0]
    // 0xdf935c: r0 = InitLateFinalInstanceField()
    //     0xdf935c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf9360: LoadField: r1 = r0->field_af
    //     0xdf9360: ldur            w1, [x0, #0xaf]
    // 0xdf9364: DecompressPointer r1
    //     0xdf9364: add             x1, x1, HEAP, lsl #32
    // 0xdf9368: cmp             w1, NULL
    // 0xdf936c: b.ne            #0xdf937c
    // 0xdf9370: r0 = Instance_Color
    //     0xdf9370: add             x0, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0xdf9374: ldr             x0, [x0, #0x948]
    // 0xdf9378: b               #0xdf9380
    // 0xdf937c: mov             x0, x1
    // 0xdf9380: mov             x4, x0
    // 0xdf9384: ldur            x0, [fp, #-0x20]
    // 0xdf9388: b               #0xdf939c
    // 0xdf938c: ldur            x0, [fp, #-0x20]
    // 0xdf9390: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdf9390: ldur            w1, [x0, #0x17]
    // 0xdf9394: DecompressPointer r1
    //     0xdf9394: add             x1, x1, HEAP, lsl #32
    // 0xdf9398: mov             x4, x1
    // 0xdf939c: ldur            x3, [fp, #-8]
    // 0xdf93a0: ldur            x1, [fp, #-0x18]
    // 0xdf93a4: stur            x4, [fp, #-0x38]
    // 0xdf93a8: LoadField: r2 = r3->field_f
    //     0xdf93a8: ldur            w2, [x3, #0xf]
    // 0xdf93ac: DecompressPointer r2
    //     0xdf93ac: add             x2, x2, HEAP, lsl #32
    // 0xdf93b0: LoadField: r5 = r2->field_b
    //     0xdf93b0: ldur            w5, [x2, #0xb]
    // 0xdf93b4: DecompressPointer r5
    //     0xdf93b4: add             x5, x5, HEAP, lsl #32
    // 0xdf93b8: cmp             w5, NULL
    // 0xdf93bc: b.eq            #0xdf9564
    // 0xdf93c0: r17 = 5129
    //     0xdf93c0: mov             x17, #0x1409
    // 0xdf93c4: cmp             x1, x17
    // 0xdf93c8: b.eq            #0xdf93e4
    // 0xdf93cc: r17 = 5130
    //     0xdf93cc: mov             x17, #0x140a
    // 0xdf93d0: cmp             x1, x17
    // 0xdf93d4: b.ne            #0xdf93e4
    // 0xdf93d8: r9 = Instance_Color
    //     0xdf93d8: add             x9, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xdf93dc: ldr             x9, [x9, #0x810]
    // 0xdf93e0: b               #0xdf93f0
    // 0xdf93e4: LoadField: r1 = r0->field_1b
    //     0xdf93e4: ldur            w1, [x0, #0x1b]
    // 0xdf93e8: DecompressPointer r1
    //     0xdf93e8: add             x1, x1, HEAP, lsl #32
    // 0xdf93ec: mov             x9, x1
    // 0xdf93f0: ldr             x8, [fp, #0x10]
    // 0xdf93f4: ldur            x6, [fp, #-0x28]
    // 0xdf93f8: ldur            d0, [fp, #-0x50]
    // 0xdf93fc: ldur            x0, [fp, #-0x30]
    // 0xdf9400: ldur            x7, [fp, #-0x10]
    // 0xdf9404: stur            x9, [fp, #-0x20]
    // 0xdf9408: LoadField: r1 = r3->field_1f
    //     0xdf9408: ldur            w1, [x3, #0x1f]
    // 0xdf940c: DecompressPointer r1
    //     0xdf940c: add             x1, x1, HEAP, lsl #32
    // 0xdf9410: LoadField: r2 = r5->field_13
    //     0xdf9410: ldur            w2, [x5, #0x13]
    // 0xdf9414: DecompressPointer r2
    //     0xdf9414: add             x2, x2, HEAP, lsl #32
    // 0xdf9418: LoadField: r5 = r2->field_6f
    //     0xdf9418: ldur            w5, [x2, #0x6f]
    // 0xdf941c: DecompressPointer r5
    //     0xdf941c: add             x5, x5, HEAP, lsl #32
    // 0xdf9420: cmp             w5, NULL
    // 0xdf9424: b.eq            #0xdf9568
    // 0xdf9428: mov             x2, x5
    // 0xdf942c: r0 = evaluate()
    //     0xdf942c: bl              #0x112be60  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xdf9430: mov             x3, x0
    // 0xdf9434: ldur            x0, [fp, #-8]
    // 0xdf9438: stur            x3, [fp, #-0x40]
    // 0xdf943c: LoadField: r1 = r0->field_23
    //     0xdf943c: ldur            w1, [x0, #0x23]
    // 0xdf9440: DecompressPointer r1
    //     0xdf9440: add             x1, x1, HEAP, lsl #32
    // 0xdf9444: LoadField: r2 = r0->field_f
    //     0xdf9444: ldur            w2, [x0, #0xf]
    // 0xdf9448: DecompressPointer r2
    //     0xdf9448: add             x2, x2, HEAP, lsl #32
    // 0xdf944c: LoadField: r0 = r2->field_b
    //     0xdf944c: ldur            w0, [x2, #0xb]
    // 0xdf9450: DecompressPointer r0
    //     0xdf9450: add             x0, x0, HEAP, lsl #32
    // 0xdf9454: cmp             w0, NULL
    // 0xdf9458: b.eq            #0xdf956c
    // 0xdf945c: LoadField: r2 = r0->field_13
    //     0xdf945c: ldur            w2, [x0, #0x13]
    // 0xdf9460: DecompressPointer r2
    //     0xdf9460: add             x2, x2, HEAP, lsl #32
    // 0xdf9464: LoadField: r0 = r2->field_6f
    //     0xdf9464: ldur            w0, [x2, #0x6f]
    // 0xdf9468: DecompressPointer r0
    //     0xdf9468: add             x0, x0, HEAP, lsl #32
    // 0xdf946c: cmp             w0, NULL
    // 0xdf9470: b.eq            #0xdf9570
    // 0xdf9474: mov             x2, x0
    // 0xdf9478: r0 = evaluate()
    //     0xdf9478: bl              #0x112be60  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xdf947c: stur            x0, [fp, #-8]
    // 0xdf9480: r0 = Align()
    //     0xdf9480: bl              #0xb281f8  ; AllocateAlignStub -> Align (size=0x1c)
    // 0xdf9484: mov             x1, x0
    // 0xdf9488: r0 = Instance_AlignmentDirectional
    //     0xdf9488: add             x0, PP, #0xd4, lsl #12  ; [pp+0xd4b58] Obj!AlignmentDirectional@129e691
    //     0xdf948c: ldr             x0, [x0, #0xb58]
    // 0xdf9490: stur            x1, [fp, #-0x48]
    // 0xdf9494: StoreField: r1->field_f = r0
    //     0xdf9494: stur            w0, [x1, #0xf]
    // 0xdf9498: ldur            x0, [fp, #-0x40]
    // 0xdf949c: StoreField: r1->field_13 = r0
    //     0xdf949c: stur            w0, [x1, #0x13]
    // 0xdf94a0: ldur            x0, [fp, #-8]
    // 0xdf94a4: ArrayStore: r1[0] = r0  ; List_4
    //     0xdf94a4: stur            w0, [x1, #0x17]
    // 0xdf94a8: ldr             x0, [fp, #0x10]
    // 0xdf94ac: StoreField: r1->field_b = r0
    //     0xdf94ac: stur            w0, [x1, #0xb]
    // 0xdf94b0: r0 = Material()
    //     0xdf94b0: bl              #0x8a54b0  ; AllocateMaterialStub -> Material (size=0x44)
    // 0xdf94b4: mov             x1, x0
    // 0xdf94b8: r0 = Instance_MaterialType
    //     0xdf94b8: add             x0, PP, #0x8c, lsl #12  ; [pp+0x8c988] Obj!MaterialType@12c53c1
    //     0xdf94bc: ldr             x0, [x0, #0x988]
    // 0xdf94c0: stur            x1, [fp, #-8]
    // 0xdf94c4: StoreField: r1->field_f = r0
    //     0xdf94c4: stur            w0, [x1, #0xf]
    // 0xdf94c8: ldur            d0, [fp, #-0x50]
    // 0xdf94cc: ArrayStore: r1[0] = d0  ; List_8
    //     0xdf94cc: stur            d0, [x1, #0x17]
    // 0xdf94d0: ldur            x0, [fp, #-0x30]
    // 0xdf94d4: StoreField: r1->field_1f = r0
    //     0xdf94d4: stur            w0, [x1, #0x1f]
    // 0xdf94d8: ldur            x0, [fp, #-0x38]
    // 0xdf94dc: StoreField: r1->field_23 = r0
    //     0xdf94dc: stur            w0, [x1, #0x23]
    // 0xdf94e0: ldur            x0, [fp, #-0x20]
    // 0xdf94e4: StoreField: r1->field_27 = r0
    //     0xdf94e4: stur            w0, [x1, #0x27]
    // 0xdf94e8: ldur            x0, [fp, #-0x10]
    // 0xdf94ec: StoreField: r1->field_2f = r0
    //     0xdf94ec: stur            w0, [x1, #0x2f]
    // 0xdf94f0: r0 = true
    //     0xdf94f0: add             x0, NULL, #0x20  ; true
    // 0xdf94f4: StoreField: r1->field_33 = r0
    //     0xdf94f4: stur            w0, [x1, #0x33]
    // 0xdf94f8: r0 = Instance_Clip
    //     0xdf94f8: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xdf94fc: ldr             x0, [x0, #0x840]
    // 0xdf9500: StoreField: r1->field_37 = r0
    //     0xdf9500: stur            w0, [x1, #0x37]
    // 0xdf9504: r0 = Instance_Duration
    //     0xdf9504: add             x0, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xdf9508: ldr             x0, [x0, #0x318]
    // 0xdf950c: StoreField: r1->field_3b = r0
    //     0xdf950c: stur            w0, [x1, #0x3b]
    // 0xdf9510: ldur            x0, [fp, #-0x48]
    // 0xdf9514: StoreField: r1->field_b = r0
    //     0xdf9514: stur            w0, [x1, #0xb]
    // 0xdf9518: r0 = false
    //     0xdf9518: add             x0, NULL, #0x30  ; false
    // 0xdf951c: StoreField: r1->field_13 = r0
    //     0xdf951c: stur            w0, [x1, #0x13]
    // 0xdf9520: r0 = FadeTransition()
    //     0xdf9520: bl              #0xb28358  ; AllocateFadeTransitionStub -> FadeTransition (size=0x18)
    // 0xdf9524: ldur            x1, [fp, #-0x28]
    // 0xdf9528: StoreField: r0->field_f = r1
    //     0xdf9528: stur            w1, [x0, #0xf]
    // 0xdf952c: r1 = false
    //     0xdf952c: add             x1, NULL, #0x30  ; false
    // 0xdf9530: StoreField: r0->field_13 = r1
    //     0xdf9530: stur            w1, [x0, #0x13]
    // 0xdf9534: ldur            x1, [fp, #-8]
    // 0xdf9538: StoreField: r0->field_b = r1
    //     0xdf9538: stur            w1, [x0, #0xb]
    // 0xdf953c: LeaveFrame
    //     0xdf953c: mov             SP, fp
    //     0xdf9540: ldp             fp, lr, [SP], #0x10
    // 0xdf9544: ret
    //     0xdf9544: ret             
    // 0xdf9548: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf9548: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf954c: b               #0xdf9198
    // 0xdf9550: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf9550: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf9554: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf9554: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf9558: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf9558: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf955c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf955c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf9560: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf9560: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf9564: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf9564: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf9568: r0 = NullCastErrorSharedWithFPURegs()
    //     0xdf9568: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xdf956c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf956c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf9570: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf9570: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, Size) {
    // ** addr: 0xdf9574, size: 0xb4
    // 0xdf9574: EnterFrame
    //     0xdf9574: stp             fp, lr, [SP, #-0x10]!
    //     0xdf9578: mov             fp, SP
    // 0xdf957c: ldr             x2, [fp, #0x18]
    // 0xdf9580: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xdf9580: ldur            w3, [x2, #0x17]
    // 0xdf9584: DecompressPointer r3
    //     0xdf9584: add             x3, x3, HEAP, lsl #32
    // 0xdf9588: LoadField: r2 = r3->field_b
    //     0xdf9588: ldur            w2, [x3, #0xb]
    // 0xdf958c: DecompressPointer r2
    //     0xdf958c: add             x2, x2, HEAP, lsl #32
    // 0xdf9590: LoadField: r4 = r2->field_f
    //     0xdf9590: ldur            w4, [x2, #0xf]
    // 0xdf9594: DecompressPointer r4
    //     0xdf9594: add             x4, x4, HEAP, lsl #32
    // 0xdf9598: LoadField: r2 = r4->field_b
    //     0xdf9598: ldur            w2, [x4, #0xb]
    // 0xdf959c: DecompressPointer r2
    //     0xdf959c: add             x2, x2, HEAP, lsl #32
    // 0xdf95a0: cmp             w2, NULL
    // 0xdf95a4: b.eq            #0xdf9620
    // 0xdf95a8: LoadField: r4 = r2->field_13
    //     0xdf95a8: ldur            w4, [x2, #0x13]
    // 0xdf95ac: DecompressPointer r4
    //     0xdf95ac: add             x4, x4, HEAP, lsl #32
    // 0xdf95b0: LoadField: r2 = r4->field_a7
    //     0xdf95b0: ldur            w2, [x4, #0xa7]
    // 0xdf95b4: DecompressPointer r2
    //     0xdf95b4: add             x2, x2, HEAP, lsl #32
    // 0xdf95b8: LoadField: r4 = r3->field_f
    //     0xdf95b8: ldur            w4, [x3, #0xf]
    // 0xdf95bc: DecompressPointer r4
    //     0xdf95bc: add             x4, x4, HEAP, lsl #32
    // 0xdf95c0: LoadField: r3 = r2->field_b
    //     0xdf95c0: ldur            w3, [x2, #0xb]
    // 0xdf95c4: r5 = LoadInt32Instr(r4)
    //     0xdf95c4: sbfx            x5, x4, #1, #0x1f
    //     0xdf95c8: tbz             w4, #0, #0xdf95d0
    //     0xdf95cc: ldur            x5, [x4, #7]
    // 0xdf95d0: r0 = LoadInt32Instr(r3)
    //     0xdf95d0: sbfx            x0, x3, #1, #0x1f
    // 0xdf95d4: mov             x1, x5
    // 0xdf95d8: cmp             x1, x0
    // 0xdf95dc: b.hs            #0xdf9624
    // 0xdf95e0: mov             x1, x2
    // 0xdf95e4: ldr             x0, [fp, #0x10]
    // 0xdf95e8: ArrayStore: r1[r5] = r0  ; List_4
    //     0xdf95e8: add             x25, x1, x5, lsl #2
    //     0xdf95ec: add             x25, x25, #0xf
    //     0xdf95f0: str             w0, [x25]
    //     0xdf95f4: tbz             w0, #0, #0xdf9610
    //     0xdf95f8: ldurb           w16, [x1, #-1]
    //     0xdf95fc: ldurb           w17, [x0, #-1]
    //     0xdf9600: and             x16, x17, x16, lsr #2
    //     0xdf9604: tst             x16, HEAP, lsr #32
    //     0xdf9608: b.eq            #0xdf9610
    //     0xdf960c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdf9610: r0 = Null
    //     0xdf9610: mov             x0, NULL
    // 0xdf9614: LeaveFrame
    //     0xdf9614: mov             SP, fp
    //     0xdf9618: ldp             fp, lr, [SP], #0x10
    // 0xdf961c: ret
    //     0xdf961c: ret             
    // 0xdf9620: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf9620: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf9624: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdf9624: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf6dfec, size: 0x110
    // 0xf6dfec: EnterFrame
    //     0xf6dfec: stp             fp, lr, [SP, #-0x10]!
    //     0xf6dff0: mov             fp, SP
    // 0xf6dff4: AllocStack(0x18)
    //     0xf6dff4: sub             SP, SP, #0x18
    // 0xf6dff8: SetupParameters(_PopupMenuState<C1X0> this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r3, fp-0x18 */)
    //     0xf6dff8: mov             x4, x1
    //     0xf6dffc: mov             x3, x2
    //     0xf6e000: stur            x1, [fp, #-0x10]
    //     0xf6e004: stur            x2, [fp, #-0x18]
    // 0xf6e008: CheckStackOverflow
    //     0xf6e008: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6e00c: cmp             SP, x16
    //     0xf6e010: b.ls            #0xf6e0f0
    // 0xf6e014: LoadField: r5 = r4->field_7
    //     0xf6e014: ldur            w5, [x4, #7]
    // 0xf6e018: DecompressPointer r5
    //     0xf6e018: add             x5, x5, HEAP, lsl #32
    // 0xf6e01c: mov             x0, x3
    // 0xf6e020: mov             x2, x5
    // 0xf6e024: stur            x5, [fp, #-8]
    // 0xf6e028: r1 = Null
    //     0xf6e028: mov             x1, NULL
    // 0xf6e02c: r8 = _PopupMenu<C1X0>
    //     0xf6e02c: add             x8, PP, #0xd4, lsl #12  ; [pp+0xd4b60] Type: _PopupMenu<C1X0>
    //     0xf6e030: ldr             x8, [x8, #0xb60]
    // 0xf6e034: LoadField: r9 = r8->field_7
    //     0xf6e034: ldur            x9, [x8, #7]
    // 0xf6e038: r3 = Null
    //     0xf6e038: add             x3, PP, #0xd4, lsl #12  ; [pp+0xd4b68] Null
    //     0xf6e03c: ldr             x3, [x3, #0xb68]
    // 0xf6e040: blr             x9
    // 0xf6e044: ldur            x0, [fp, #-0x18]
    // 0xf6e048: ldur            x2, [fp, #-8]
    // 0xf6e04c: r1 = Null
    //     0xf6e04c: mov             x1, NULL
    // 0xf6e050: cmp             w2, NULL
    // 0xf6e054: b.eq            #0xf6e078
    // 0xf6e058: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf6e058: ldur            w4, [x2, #0x17]
    // 0xf6e05c: DecompressPointer r4
    //     0xf6e05c: add             x4, x4, HEAP, lsl #32
    // 0xf6e060: r8 = X0 bound StatefulWidget
    //     0xf6e060: add             x8, PP, #0x12, lsl #12  ; [pp+0x12498] TypeParameter: X0 bound StatefulWidget
    //     0xf6e064: ldr             x8, [x8, #0x498]
    // 0xf6e068: LoadField: r9 = r4->field_7
    //     0xf6e068: ldur            x9, [x4, #7]
    // 0xf6e06c: r3 = Null
    //     0xf6e06c: add             x3, PP, #0xd4, lsl #12  ; [pp+0xd4b78] Null
    //     0xf6e070: ldr             x3, [x3, #0xb78]
    // 0xf6e074: blr             x9
    // 0xf6e078: ldur            x0, [fp, #-0x18]
    // 0xf6e07c: LoadField: r1 = r0->field_13
    //     0xf6e07c: ldur            w1, [x0, #0x13]
    // 0xf6e080: DecompressPointer r1
    //     0xf6e080: add             x1, x1, HEAP, lsl #32
    // 0xf6e084: LoadField: r0 = r1->field_9f
    //     0xf6e084: ldur            w0, [x1, #0x9f]
    // 0xf6e088: DecompressPointer r0
    //     0xf6e088: add             x0, x0, HEAP, lsl #32
    // 0xf6e08c: LoadField: r2 = r0->field_b
    //     0xf6e08c: ldur            w2, [x0, #0xb]
    // 0xf6e090: ldur            x0, [fp, #-0x10]
    // 0xf6e094: LoadField: r3 = r0->field_b
    //     0xf6e094: ldur            w3, [x0, #0xb]
    // 0xf6e098: DecompressPointer r3
    //     0xf6e098: add             x3, x3, HEAP, lsl #32
    // 0xf6e09c: cmp             w3, NULL
    // 0xf6e0a0: b.eq            #0xf6e0f8
    // 0xf6e0a4: LoadField: r4 = r3->field_13
    //     0xf6e0a4: ldur            w4, [x3, #0x13]
    // 0xf6e0a8: DecompressPointer r4
    //     0xf6e0a8: add             x4, x4, HEAP, lsl #32
    // 0xf6e0ac: LoadField: r3 = r4->field_9f
    //     0xf6e0ac: ldur            w3, [x4, #0x9f]
    // 0xf6e0b0: DecompressPointer r3
    //     0xf6e0b0: add             x3, x3, HEAP, lsl #32
    // 0xf6e0b4: LoadField: r5 = r3->field_b
    //     0xf6e0b4: ldur            w5, [x3, #0xb]
    // 0xf6e0b8: cmp             w2, w5
    // 0xf6e0bc: b.ne            #0xf6e0d8
    // 0xf6e0c0: LoadField: r2 = r1->field_6f
    //     0xf6e0c0: ldur            w2, [x1, #0x6f]
    // 0xf6e0c4: DecompressPointer r2
    //     0xf6e0c4: add             x2, x2, HEAP, lsl #32
    // 0xf6e0c8: LoadField: r1 = r4->field_6f
    //     0xf6e0c8: ldur            w1, [x4, #0x6f]
    // 0xf6e0cc: DecompressPointer r1
    //     0xf6e0cc: add             x1, x1, HEAP, lsl #32
    // 0xf6e0d0: cmp             w2, w1
    // 0xf6e0d4: b.eq            #0xf6e0e0
    // 0xf6e0d8: mov             x1, x0
    // 0xf6e0dc: r0 = _setOpacities()
    //     0xf6e0dc: bl              #0xf6e0fc  ; [package:flutter/src/material/popup_menu.dart] _PopupMenuState::_setOpacities
    // 0xf6e0e0: r0 = Null
    //     0xf6e0e0: mov             x0, NULL
    // 0xf6e0e4: LeaveFrame
    //     0xf6e0e4: mov             SP, fp
    //     0xf6e0e8: ldp             fp, lr, [SP], #0x10
    // 0xf6e0ec: ret
    //     0xf6e0ec: ret             
    // 0xf6e0f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6e0f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6e0f4: b               #0xf6e014
    // 0xf6e0f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6e0f8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _setOpacities(/* No info */) {
    // ** addr: 0xf6e0fc, size: 0x34c
    // 0xf6e0fc: EnterFrame
    //     0xf6e0fc: stp             fp, lr, [SP, #-0x10]!
    //     0xf6e100: mov             fp, SP
    // 0xf6e104: AllocStack(0x58)
    //     0xf6e104: sub             SP, SP, #0x58
    // 0xf6e108: SetupParameters(_PopupMenuState<C1X0> this /* r1 => r2, fp-0x8 */)
    //     0xf6e108: mov             x2, x1
    //     0xf6e10c: stur            x1, [fp, #-8]
    // 0xf6e110: CheckStackOverflow
    //     0xf6e110: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6e114: cmp             SP, x16
    //     0xf6e118: b.ls            #0xf6e424
    // 0xf6e11c: LoadField: r1 = r2->field_13
    //     0xf6e11c: ldur            w1, [x2, #0x13]
    // 0xf6e120: DecompressPointer r1
    //     0xf6e120: add             x1, x1, HEAP, lsl #32
    // 0xf6e124: r0 = LoadClassIdInstr(r1)
    //     0xf6e124: ldur            x0, [x1, #-1]
    //     0xf6e128: ubfx            x0, x0, #0xc, #0x14
    // 0xf6e12c: r0 = GDT[cid_x0 + 0x12641]()
    //     0xf6e12c: mov             x17, #0x2641
    //     0xf6e130: movk            x17, #1, lsl #16
    //     0xf6e134: add             lr, x0, x17
    //     0xf6e138: ldr             lr, [x21, lr, lsl #3]
    //     0xf6e13c: blr             lr
    // 0xf6e140: mov             x2, x0
    // 0xf6e144: stur            x2, [fp, #-0x10]
    // 0xf6e148: CheckStackOverflow
    //     0xf6e148: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6e14c: cmp             SP, x16
    //     0xf6e150: b.ls            #0xf6e42c
    // 0xf6e154: r0 = LoadClassIdInstr(r2)
    //     0xf6e154: ldur            x0, [x2, #-1]
    //     0xf6e158: ubfx            x0, x0, #0xc, #0x14
    // 0xf6e15c: mov             x1, x2
    // 0xf6e160: r0 = GDT[cid_x0 + 0x1845b]()
    //     0xf6e160: mov             x17, #0x845b
    //     0xf6e164: movk            x17, #1, lsl #16
    //     0xf6e168: add             lr, x0, x17
    //     0xf6e16c: ldr             lr, [x21, lr, lsl #3]
    //     0xf6e170: blr             lr
    // 0xf6e174: tbnz            w0, #4, #0xf6e1e4
    // 0xf6e178: ldur            x2, [fp, #-0x10]
    // 0xf6e17c: r0 = LoadClassIdInstr(r2)
    //     0xf6e17c: ldur            x0, [x2, #-1]
    //     0xf6e180: ubfx            x0, x0, #0xc, #0x14
    // 0xf6e184: mov             x1, x2
    // 0xf6e188: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0xf6e188: mov             x17, #0x7d4c
    //     0xf6e18c: movk            x17, #1, lsl #16
    //     0xf6e190: add             lr, x0, x17
    //     0xf6e194: ldr             lr, [x21, lr, lsl #3]
    //     0xf6e198: blr             lr
    // 0xf6e19c: LoadField: r3 = r0->field_b
    //     0xf6e19c: ldur            w3, [x0, #0xb]
    // 0xf6e1a0: DecompressPointer r3
    //     0xf6e1a0: add             x3, x3, HEAP, lsl #32
    // 0xf6e1a4: mov             x2, x0
    // 0xf6e1a8: stur            x3, [fp, #-0x18]
    // 0xf6e1ac: r1 = Function '_updateCurveDirection@63411118':.
    //     0xf6e1ac: add             x1, PP, #0x16, lsl #12  ; [pp+0x16de0] AnonymousClosure: (0x915e10), in [package:flutter/src/animation/animations.dart] CurvedAnimation::_updateCurveDirection (0x915d94)
    //     0xf6e1b0: ldr             x1, [x1, #0xde0]
    // 0xf6e1b4: r0 = AllocateClosure()
    //     0xf6e1b4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf6e1b8: ldur            x1, [fp, #-0x18]
    // 0xf6e1bc: r2 = LoadClassIdInstr(r1)
    //     0xf6e1bc: ldur            x2, [x1, #-1]
    //     0xf6e1c0: ubfx            x2, x2, #0xc, #0x14
    // 0xf6e1c4: mov             x16, x0
    // 0xf6e1c8: mov             x0, x2
    // 0xf6e1cc: mov             x2, x16
    // 0xf6e1d0: r0 = GDT[cid_x0 + 0xabe]()
    //     0xf6e1d0: add             lr, x0, #0xabe
    //     0xf6e1d4: ldr             lr, [x21, lr, lsl #3]
    //     0xf6e1d8: blr             lr
    // 0xf6e1dc: ldur            x2, [fp, #-0x10]
    // 0xf6e1e0: b               #0xf6e148
    // 0xf6e1e4: ldur            x0, [fp, #-8]
    // 0xf6e1e8: r1 = <CurvedAnimation>
    //     0xf6e1e8: add             x1, PP, #0x85, lsl #12  ; [pp+0x85370] TypeArguments: <CurvedAnimation>
    //     0xf6e1ec: ldr             x1, [x1, #0x370]
    // 0xf6e1f0: r2 = 0
    //     0xf6e1f0: mov             x2, #0
    // 0xf6e1f4: r0 = _GrowableList()
    //     0xf6e1f4: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xf6e1f8: mov             x2, x0
    // 0xf6e1fc: ldur            x0, [fp, #-8]
    // 0xf6e200: stur            x2, [fp, #-0x18]
    // 0xf6e204: LoadField: r1 = r0->field_b
    //     0xf6e204: ldur            w1, [x0, #0xb]
    // 0xf6e208: DecompressPointer r1
    //     0xf6e208: add             x1, x1, HEAP, lsl #32
    // 0xf6e20c: cmp             w1, NULL
    // 0xf6e210: b.eq            #0xf6e434
    // 0xf6e214: LoadField: r3 = r1->field_13
    //     0xf6e214: ldur            w3, [x1, #0x13]
    // 0xf6e218: DecompressPointer r3
    //     0xf6e218: add             x3, x3, HEAP, lsl #32
    // 0xf6e21c: LoadField: r1 = r3->field_9f
    //     0xf6e21c: ldur            w1, [x3, #0x9f]
    // 0xf6e220: DecompressPointer r1
    //     0xf6e220: add             x1, x1, HEAP, lsl #32
    // 0xf6e224: LoadField: r3 = r1->field_b
    //     0xf6e224: ldur            w3, [x1, #0xb]
    // 0xf6e228: r16 = LoadInt32Instr(r3)
    //     0xf6e228: sbfx            x16, x3, #1, #0x1f
    // 0xf6e22c: scvtf           d0, w16
    // 0xf6e230: d1 = 1.500000
    //     0xf6e230: fmov            d1, #1.50000000
    // 0xf6e234: fadd            d2, d0, d1
    // 0xf6e238: d0 = 1.000000
    //     0xf6e238: fmov            d0, #1.00000000
    // 0xf6e23c: fdiv            d3, d0, d2
    // 0xf6e240: stur            d3, [fp, #-0x58]
    // 0xf6e244: fmul            d2, d3, d1
    // 0xf6e248: stur            d2, [fp, #-0x50]
    // 0xf6e24c: r1 = 0
    //     0xf6e24c: mov             x1, #0
    // 0xf6e250: d1 = 0.000000
    //     0xf6e250: eor             v1.16b, v1.16b, v1.16b
    // 0xf6e254: CheckStackOverflow
    //     0xf6e254: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6e258: cmp             SP, x16
    //     0xf6e25c: b.ls            #0xf6e438
    // 0xf6e260: LoadField: r3 = r0->field_b
    //     0xf6e260: ldur            w3, [x0, #0xb]
    // 0xf6e264: DecompressPointer r3
    //     0xf6e264: add             x3, x3, HEAP, lsl #32
    // 0xf6e268: cmp             w3, NULL
    // 0xf6e26c: b.eq            #0xf6e440
    // 0xf6e270: LoadField: r4 = r3->field_13
    //     0xf6e270: ldur            w4, [x3, #0x13]
    // 0xf6e274: DecompressPointer r4
    //     0xf6e274: add             x4, x4, HEAP, lsl #32
    // 0xf6e278: LoadField: r3 = r4->field_9f
    //     0xf6e278: ldur            w3, [x4, #0x9f]
    // 0xf6e27c: DecompressPointer r3
    //     0xf6e27c: add             x3, x3, HEAP, lsl #32
    // 0xf6e280: LoadField: r5 = r3->field_b
    //     0xf6e280: ldur            w5, [x3, #0xb]
    // 0xf6e284: r3 = LoadInt32Instr(r5)
    //     0xf6e284: sbfx            x3, x5, #1, #0x1f
    // 0xf6e288: cmp             x1, x3
    // 0xf6e28c: b.ge            #0xf6e3f0
    // 0xf6e290: add             x3, x1, #1
    // 0xf6e294: stur            x3, [fp, #-0x20]
    // 0xf6e298: scvtf           d4, x3
    // 0xf6e29c: fmul            d5, d4, d3
    // 0xf6e2a0: stur            d5, [fp, #-0x48]
    // 0xf6e2a4: fadd            d4, d5, d2
    // 0xf6e2a8: fcmp            d1, d4
    // 0xf6e2ac: b.le            #0xf6e2b8
    // 0xf6e2b0: d4 = 0.000000
    //     0xf6e2b0: eor             v4.16b, v4.16b, v4.16b
    // 0xf6e2b4: b               #0xf6e2d4
    // 0xf6e2b8: fcmp            d4, d0
    // 0xf6e2bc: b.le            #0xf6e2c8
    // 0xf6e2c0: d4 = 1.000000
    //     0xf6e2c0: fmov            d4, #1.00000000
    // 0xf6e2c4: b               #0xf6e2d4
    // 0xf6e2c8: fcmp            d4, d4
    // 0xf6e2cc: b.vc            #0xf6e2d4
    // 0xf6e2d0: d4 = 1.000000
    //     0xf6e2d0: fmov            d4, #1.00000000
    // 0xf6e2d4: stur            d4, [fp, #-0x40]
    // 0xf6e2d8: LoadField: r5 = r4->field_6f
    //     0xf6e2d8: ldur            w5, [x4, #0x6f]
    // 0xf6e2dc: DecompressPointer r5
    //     0xf6e2dc: add             x5, x5, HEAP, lsl #32
    // 0xf6e2e0: stur            x5, [fp, #-0x10]
    // 0xf6e2e4: cmp             w5, NULL
    // 0xf6e2e8: b.eq            #0xf6e444
    // 0xf6e2ec: r1 = <double>
    //     0xf6e2ec: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf6e2f0: r0 = Interval()
    //     0xf6e2f0: bl              #0xc0c688  ; AllocateIntervalStub -> Interval (size=0x20)
    // 0xf6e2f4: ldur            d0, [fp, #-0x48]
    // 0xf6e2f8: stur            x0, [fp, #-0x28]
    // 0xf6e2fc: StoreField: r0->field_b = d0
    //     0xf6e2fc: stur            d0, [x0, #0xb]
    // 0xf6e300: ldur            d0, [fp, #-0x40]
    // 0xf6e304: StoreField: r0->field_13 = d0
    //     0xf6e304: stur            d0, [x0, #0x13]
    // 0xf6e308: r2 = Instance__Linear
    //     0xf6e308: ldr             x2, [PP, #0x5168]  ; [pp+0x5168] Obj!_Linear@129fef1
    // 0xf6e30c: StoreField: r0->field_1b = r2
    //     0xf6e30c: stur            w2, [x0, #0x1b]
    // 0xf6e310: r1 = <double>
    //     0xf6e310: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf6e314: r0 = CurvedAnimation()
    //     0xf6e314: bl              #0x915e4c  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0xf6e318: mov             x2, x0
    // 0xf6e31c: ldur            x0, [fp, #-0x10]
    // 0xf6e320: stur            x2, [fp, #-0x30]
    // 0xf6e324: StoreField: r2->field_b = r0
    //     0xf6e324: stur            w0, [x2, #0xb]
    // 0xf6e328: ldur            x1, [fp, #-0x28]
    // 0xf6e32c: StoreField: r2->field_f = r1
    //     0xf6e32c: stur            w1, [x2, #0xf]
    // 0xf6e330: mov             x1, x0
    // 0xf6e334: r0 = status()
    //     0xf6e334: bl              #0x1284d68  ; [package:flutter/src/animation/animations.dart] ProxyAnimation::status
    // 0xf6e338: ldur            x1, [fp, #-0x30]
    // 0xf6e33c: mov             x2, x0
    // 0xf6e340: r0 = _updateCurveDirection()
    //     0xf6e340: bl              #0x915d94  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::_updateCurveDirection
    // 0xf6e344: ldur            x2, [fp, #-0x30]
    // 0xf6e348: r1 = Function '_updateCurveDirection@63411118':.
    //     0xf6e348: add             x1, PP, #0x16, lsl #12  ; [pp+0x16de0] AnonymousClosure: (0x915e10), in [package:flutter/src/animation/animations.dart] CurvedAnimation::_updateCurveDirection (0x915d94)
    //     0xf6e34c: ldr             x1, [x1, #0xde0]
    // 0xf6e350: r0 = AllocateClosure()
    //     0xf6e350: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf6e354: ldur            x1, [fp, #-0x10]
    // 0xf6e358: mov             x2, x0
    // 0xf6e35c: r0 = addStatusListener()
    //     0xf6e35c: bl              #0x1254cfc  ; [dart:mixin_deduplication] _MixinApplication459&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::addStatusListener
    // 0xf6e360: ldur            x0, [fp, #-0x18]
    // 0xf6e364: LoadField: r1 = r0->field_b
    //     0xf6e364: ldur            w1, [x0, #0xb]
    // 0xf6e368: LoadField: r2 = r0->field_f
    //     0xf6e368: ldur            w2, [x0, #0xf]
    // 0xf6e36c: DecompressPointer r2
    //     0xf6e36c: add             x2, x2, HEAP, lsl #32
    // 0xf6e370: LoadField: r3 = r2->field_b
    //     0xf6e370: ldur            w3, [x2, #0xb]
    // 0xf6e374: r2 = LoadInt32Instr(r1)
    //     0xf6e374: sbfx            x2, x1, #1, #0x1f
    // 0xf6e378: stur            x2, [fp, #-0x38]
    // 0xf6e37c: r1 = LoadInt32Instr(r3)
    //     0xf6e37c: sbfx            x1, x3, #1, #0x1f
    // 0xf6e380: cmp             x2, x1
    // 0xf6e384: b.ne            #0xf6e390
    // 0xf6e388: mov             x1, x0
    // 0xf6e38c: r0 = _growToNextCapacity()
    //     0xf6e38c: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xf6e390: ldur            x2, [fp, #-0x18]
    // 0xf6e394: ldur            x3, [fp, #-0x38]
    // 0xf6e398: add             x4, x3, #1
    // 0xf6e39c: lsl             x5, x4, #1
    // 0xf6e3a0: StoreField: r2->field_b = r5
    //     0xf6e3a0: stur            w5, [x2, #0xb]
    // 0xf6e3a4: LoadField: r1 = r2->field_f
    //     0xf6e3a4: ldur            w1, [x2, #0xf]
    // 0xf6e3a8: DecompressPointer r1
    //     0xf6e3a8: add             x1, x1, HEAP, lsl #32
    // 0xf6e3ac: ldur            x0, [fp, #-0x30]
    // 0xf6e3b0: ArrayStore: r1[r3] = r0  ; List_4
    //     0xf6e3b0: add             x25, x1, x3, lsl #2
    //     0xf6e3b4: add             x25, x25, #0xf
    //     0xf6e3b8: str             w0, [x25]
    //     0xf6e3bc: tbz             w0, #0, #0xf6e3d8
    //     0xf6e3c0: ldurb           w16, [x1, #-1]
    //     0xf6e3c4: ldurb           w17, [x0, #-1]
    //     0xf6e3c8: and             x16, x17, x16, lsr #2
    //     0xf6e3cc: tst             x16, HEAP, lsr #32
    //     0xf6e3d0: b.eq            #0xf6e3d8
    //     0xf6e3d4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xf6e3d8: ldur            x1, [fp, #-0x20]
    // 0xf6e3dc: ldur            x0, [fp, #-8]
    // 0xf6e3e0: ldur            d3, [fp, #-0x58]
    // 0xf6e3e4: ldur            d2, [fp, #-0x50]
    // 0xf6e3e8: d0 = 1.000000
    //     0xf6e3e8: fmov            d0, #1.00000000
    // 0xf6e3ec: b               #0xf6e250
    // 0xf6e3f0: mov             x1, x0
    // 0xf6e3f4: mov             x0, x2
    // 0xf6e3f8: StoreField: r1->field_13 = r0
    //     0xf6e3f8: stur            w0, [x1, #0x13]
    //     0xf6e3fc: ldurb           w16, [x1, #-1]
    //     0xf6e400: ldurb           w17, [x0, #-1]
    //     0xf6e404: and             x16, x17, x16, lsr #2
    //     0xf6e408: tst             x16, HEAP, lsr #32
    //     0xf6e40c: b.eq            #0xf6e414
    //     0xf6e410: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf6e414: r0 = Null
    //     0xf6e414: mov             x0, NULL
    // 0xf6e418: LeaveFrame
    //     0xf6e418: mov             SP, fp
    //     0xf6e41c: ldp             fp, lr, [SP], #0x10
    // 0xf6e420: ret
    //     0xf6e420: ret             
    // 0xf6e424: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6e424: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6e428: b               #0xf6e11c
    // 0xf6e42c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6e42c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6e430: b               #0xf6e154
    // 0xf6e434: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6e434: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6e438: r0 = StackOverflowSharedWithFPURegs()
    //     0xf6e438: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xf6e43c: b               #0xf6e260
    // 0xf6e440: r0 = NullCastErrorSharedWithFPURegs()
    //     0xf6e440: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xf6e444: r0 = NullCastErrorSharedWithFPURegs()
    //     0xf6e444: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0xf90fdc, size: 0x30
    // 0xf90fdc: EnterFrame
    //     0xf90fdc: stp             fp, lr, [SP, #-0x10]!
    //     0xf90fe0: mov             fp, SP
    // 0xf90fe4: CheckStackOverflow
    //     0xf90fe4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf90fe8: cmp             SP, x16
    //     0xf90fec: b.ls            #0xf91004
    // 0xf90ff0: r0 = _setOpacities()
    //     0xf90ff0: bl              #0xf6e0fc  ; [package:flutter/src/material/popup_menu.dart] _PopupMenuState::_setOpacities
    // 0xf90ff4: r0 = Null
    //     0xf90ff4: mov             x0, NULL
    // 0xf90ff8: LeaveFrame
    //     0xf90ff8: mov             SP, fp
    //     0xf90ffc: ldp             fp, lr, [SP], #0x10
    // 0xf91000: ret
    //     0xf91000: ret             
    // 0xf91004: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf91004: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf91008: b               #0xf90ff0
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10e5d7c, size: 0x10c
    // 0x10e5d7c: EnterFrame
    //     0x10e5d7c: stp             fp, lr, [SP, #-0x10]!
    //     0x10e5d80: mov             fp, SP
    // 0x10e5d84: AllocStack(0x10)
    //     0x10e5d84: sub             SP, SP, #0x10
    // 0x10e5d88: CheckStackOverflow
    //     0x10e5d88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e5d8c: cmp             SP, x16
    //     0x10e5d90: b.ls            #0x10e5e78
    // 0x10e5d94: LoadField: r0 = r1->field_13
    //     0x10e5d94: ldur            w0, [x1, #0x13]
    // 0x10e5d98: DecompressPointer r0
    //     0x10e5d98: add             x0, x0, HEAP, lsl #32
    // 0x10e5d9c: r1 = LoadClassIdInstr(r0)
    //     0x10e5d9c: ldur            x1, [x0, #-1]
    //     0x10e5da0: ubfx            x1, x1, #0xc, #0x14
    // 0x10e5da4: mov             x16, x0
    // 0x10e5da8: mov             x0, x1
    // 0x10e5dac: mov             x1, x16
    // 0x10e5db0: r0 = GDT[cid_x0 + 0x12641]()
    //     0x10e5db0: mov             x17, #0x2641
    //     0x10e5db4: movk            x17, #1, lsl #16
    //     0x10e5db8: add             lr, x0, x17
    //     0x10e5dbc: ldr             lr, [x21, lr, lsl #3]
    //     0x10e5dc0: blr             lr
    // 0x10e5dc4: mov             x2, x0
    // 0x10e5dc8: stur            x2, [fp, #-8]
    // 0x10e5dcc: CheckStackOverflow
    //     0x10e5dcc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e5dd0: cmp             SP, x16
    //     0x10e5dd4: b.ls            #0x10e5e80
    // 0x10e5dd8: r0 = LoadClassIdInstr(r2)
    //     0x10e5dd8: ldur            x0, [x2, #-1]
    //     0x10e5ddc: ubfx            x0, x0, #0xc, #0x14
    // 0x10e5de0: mov             x1, x2
    // 0x10e5de4: r0 = GDT[cid_x0 + 0x1845b]()
    //     0x10e5de4: mov             x17, #0x845b
    //     0x10e5de8: movk            x17, #1, lsl #16
    //     0x10e5dec: add             lr, x0, x17
    //     0x10e5df0: ldr             lr, [x21, lr, lsl #3]
    //     0x10e5df4: blr             lr
    // 0x10e5df8: tbnz            w0, #4, #0x10e5e68
    // 0x10e5dfc: ldur            x2, [fp, #-8]
    // 0x10e5e00: r0 = LoadClassIdInstr(r2)
    //     0x10e5e00: ldur            x0, [x2, #-1]
    //     0x10e5e04: ubfx            x0, x0, #0xc, #0x14
    // 0x10e5e08: mov             x1, x2
    // 0x10e5e0c: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0x10e5e0c: mov             x17, #0x7d4c
    //     0x10e5e10: movk            x17, #1, lsl #16
    //     0x10e5e14: add             lr, x0, x17
    //     0x10e5e18: ldr             lr, [x21, lr, lsl #3]
    //     0x10e5e1c: blr             lr
    // 0x10e5e20: LoadField: r3 = r0->field_b
    //     0x10e5e20: ldur            w3, [x0, #0xb]
    // 0x10e5e24: DecompressPointer r3
    //     0x10e5e24: add             x3, x3, HEAP, lsl #32
    // 0x10e5e28: mov             x2, x0
    // 0x10e5e2c: stur            x3, [fp, #-0x10]
    // 0x10e5e30: r1 = Function '_updateCurveDirection@63411118':.
    //     0x10e5e30: add             x1, PP, #0x16, lsl #12  ; [pp+0x16de0] AnonymousClosure: (0x915e10), in [package:flutter/src/animation/animations.dart] CurvedAnimation::_updateCurveDirection (0x915d94)
    //     0x10e5e34: ldr             x1, [x1, #0xde0]
    // 0x10e5e38: r0 = AllocateClosure()
    //     0x10e5e38: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10e5e3c: ldur            x1, [fp, #-0x10]
    // 0x10e5e40: r2 = LoadClassIdInstr(r1)
    //     0x10e5e40: ldur            x2, [x1, #-1]
    //     0x10e5e44: ubfx            x2, x2, #0xc, #0x14
    // 0x10e5e48: mov             x16, x0
    // 0x10e5e4c: mov             x0, x2
    // 0x10e5e50: mov             x2, x16
    // 0x10e5e54: r0 = GDT[cid_x0 + 0xabe]()
    //     0x10e5e54: add             lr, x0, #0xabe
    //     0x10e5e58: ldr             lr, [x21, lr, lsl #3]
    //     0x10e5e5c: blr             lr
    // 0x10e5e60: ldur            x2, [fp, #-8]
    // 0x10e5e64: b               #0x10e5dcc
    // 0x10e5e68: r0 = Null
    //     0x10e5e68: mov             x0, NULL
    // 0x10e5e6c: LeaveFrame
    //     0x10e5e6c: mov             SP, fp
    //     0x10e5e70: ldp             fp, lr, [SP], #0x10
    // 0x10e5e74: ret
    //     0x10e5e74: ret             
    // 0x10e5e78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e5e78: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e5e7c: b               #0x10e5d94
    // 0x10e5e80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e5e80: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e5e84: b               #0x10e5dd8
  }
}

// class id: 5461, size: 0x14, field offset: 0x14
class PopupMenuItemState<C1X0, C1X1 bound PopupMenuItem> extends State<C1X0> {

  _ buildChild(/* No info */) {
    // ** addr: 0xdf80d8, size: 0x28
    // 0xdf80d8: LoadField: r2 = r1->field_b
    //     0xdf80d8: ldur            w2, [x1, #0xb]
    // 0xdf80dc: DecompressPointer r2
    //     0xdf80dc: add             x2, x2, HEAP, lsl #32
    // 0xdf80e0: cmp             w2, NULL
    // 0xdf80e4: b.eq            #0xdf80f4
    // 0xdf80e8: LoadField: r0 = r2->field_33
    //     0xdf80e8: ldur            w0, [x2, #0x33]
    // 0xdf80ec: DecompressPointer r0
    //     0xdf80ec: add             x0, x0, HEAP, lsl #32
    // 0xdf80f0: ret
    //     0xdf80f0: ret             
    // 0xdf80f4: EnterFrame
    //     0xdf80f4: stp             fp, lr, [SP, #-0x10]!
    //     0xdf80f8: mov             fp, SP
    // 0xdf80fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf80fc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ build(/* No info */) {
    // ** addr: 0xdf8100, size: 0x440
    // 0xdf8100: EnterFrame
    //     0xdf8100: stp             fp, lr, [SP, #-0x10]!
    //     0xdf8104: mov             fp, SP
    // 0xdf8108: AllocStack(0x40)
    //     0xdf8108: sub             SP, SP, #0x40
    // 0xdf810c: SetupParameters(PopupMenuItemState<C1X0, C1X1 bound PopupMenuItem> this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xdf810c: mov             x0, x2
    //     0xdf8110: stur            x2, [fp, #-0x10]
    //     0xdf8114: mov             x2, x1
    //     0xdf8118: stur            x1, [fp, #-8]
    // 0xdf811c: CheckStackOverflow
    //     0xdf811c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf8120: cmp             SP, x16
    //     0xdf8124: b.ls            #0xdf851c
    // 0xdf8128: mov             x1, x0
    // 0xdf812c: r0 = of()
    //     0xdf812c: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xdf8130: ldur            x1, [fp, #-0x10]
    // 0xdf8134: stur            x0, [fp, #-0x18]
    // 0xdf8138: r0 = of()
    //     0xdf8138: bl              #0xdf85e0  ; [package:flutter/src/material/popup_menu_theme.dart] PopupMenuTheme::of
    // 0xdf813c: ldur            x0, [fp, #-0x18]
    // 0xdf8140: LoadField: r1 = r0->field_2f
    //     0xdf8140: ldur            w1, [x0, #0x2f]
    // 0xdf8144: DecompressPointer r1
    //     0xdf8144: add             x1, x1, HEAP, lsl #32
    // 0xdf8148: stur            x1, [fp, #-0x20]
    // 0xdf814c: tbnz            w1, #4, #0xdf8188
    // 0xdf8150: ldur            x0, [fp, #-0x10]
    // 0xdf8154: r0 = _PopupMenuDefaultsM3()
    //     0xdf8154: bl              #0xdf85d4  ; Allocate_PopupMenuDefaultsM3Stub -> _PopupMenuDefaultsM3 (size=0x4c)
    // 0xdf8158: mov             x1, x0
    // 0xdf815c: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf8160: StoreField: r1->field_3f = r0
    //     0xdf8160: stur            w0, [x1, #0x3f]
    // 0xdf8164: StoreField: r1->field_43 = r0
    //     0xdf8164: stur            w0, [x1, #0x43]
    // 0xdf8168: StoreField: r1->field_47 = r0
    //     0xdf8168: stur            w0, [x1, #0x47]
    // 0xdf816c: ldur            x2, [fp, #-0x10]
    // 0xdf8170: StoreField: r1->field_3b = r2
    //     0xdf8170: stur            w2, [x1, #0x3b]
    // 0xdf8174: r0 = 3.000000
    //     0xdf8174: add             x0, PP, #0x22, lsl #12  ; [pp+0x223f8] 3
    //     0xdf8178: ldr             x0, [x0, #0x3f8]
    // 0xdf817c: StoreField: r1->field_13 = r0
    //     0xdf817c: stur            w0, [x1, #0x13]
    // 0xdf8180: mov             x3, x1
    // 0xdf8184: b               #0xdf81bc
    // 0xdf8188: ldur            x2, [fp, #-0x10]
    // 0xdf818c: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf8190: r0 = _PopupMenuDefaultsM2()
    //     0xdf8190: bl              #0xdf85c8  ; Allocate_PopupMenuDefaultsM2Stub -> _PopupMenuDefaultsM2 (size=0x48)
    // 0xdf8194: mov             x1, x0
    // 0xdf8198: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf819c: StoreField: r1->field_3f = r0
    //     0xdf819c: stur            w0, [x1, #0x3f]
    // 0xdf81a0: StoreField: r1->field_43 = r0
    //     0xdf81a0: stur            w0, [x1, #0x43]
    // 0xdf81a4: ldur            x0, [fp, #-0x10]
    // 0xdf81a8: StoreField: r1->field_3b = r0
    //     0xdf81a8: stur            w0, [x1, #0x3b]
    // 0xdf81ac: r0 = 8.000000
    //     0xdf81ac: add             x0, PP, #0x19, lsl #12  ; [pp+0x19e08] 8
    //     0xdf81b0: ldr             x0, [x0, #0xe08]
    // 0xdf81b4: StoreField: r1->field_13 = r0
    //     0xdf81b4: stur            w0, [x1, #0x13]
    // 0xdf81b8: mov             x3, x1
    // 0xdf81bc: ldur            x2, [fp, #-8]
    // 0xdf81c0: ldur            x0, [fp, #-0x20]
    // 0xdf81c4: stur            x3, [fp, #-0x10]
    // 0xdf81c8: r1 = <WidgetState>
    //     0xdf81c8: add             x1, PP, #0x84, lsl #12  ; [pp+0x84a10] TypeArguments: <WidgetState>
    //     0xdf81cc: ldr             x1, [x1, #0xa10]
    // 0xdf81d0: r0 = _Set()
    //     0xdf81d0: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0xdf81d4: mov             x1, x0
    // 0xdf81d8: r0 = _Uint32List
    //     0xdf81d8: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0xdf81dc: stur            x1, [fp, #-0x18]
    // 0xdf81e0: StoreField: r1->field_1b = r0
    //     0xdf81e0: stur            w0, [x1, #0x1b]
    // 0xdf81e4: StoreField: r1->field_b = rZR
    //     0xdf81e4: stur            wzr, [x1, #0xb]
    // 0xdf81e8: r0 = const []
    //     0xdf81e8: ldr             x0, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0xdf81ec: StoreField: r1->field_f = r0
    //     0xdf81ec: stur            w0, [x1, #0xf]
    // 0xdf81f0: StoreField: r1->field_13 = rZR
    //     0xdf81f0: stur            wzr, [x1, #0x13]
    // 0xdf81f4: ArrayStore: r1[0] = rZR  ; List_4
    //     0xdf81f4: stur            wzr, [x1, #0x17]
    // 0xdf81f8: ldur            x0, [fp, #-8]
    // 0xdf81fc: LoadField: r2 = r0->field_b
    //     0xdf81fc: ldur            w2, [x0, #0xb]
    // 0xdf8200: DecompressPointer r2
    //     0xdf8200: add             x2, x2, HEAP, lsl #32
    // 0xdf8204: cmp             w2, NULL
    // 0xdf8208: b.eq            #0xdf8524
    // 0xdf820c: ldur            x2, [fp, #-0x20]
    // 0xdf8210: tbnz            w2, #4, #0xdf82ac
    // 0xdf8214: ldur            x3, [fp, #-0x10]
    // 0xdf8218: r4 = LoadClassIdInstr(r3)
    //     0xdf8218: ldur            x4, [x3, #-1]
    //     0xdf821c: ubfx            x4, x4, #0xc, #0x14
    // 0xdf8220: r17 = 5129
    //     0xdf8220: mov             x17, #0x1409
    // 0xdf8224: cmp             x4, x17
    // 0xdf8228: b.ne            #0xdf8234
    // 0xdf822c: mov             x1, x3
    // 0xdf8230: b               #0xdf8280
    // 0xdf8234: r17 = 5130
    //     0xdf8234: mov             x17, #0x140a
    // 0xdf8238: cmp             x4, x17
    // 0xdf823c: b.ne            #0xdf827c
    // 0xdf8240: r1 = 1
    //     0xdf8240: mov             x1, #1
    // 0xdf8244: r0 = AllocateContext()
    //     0xdf8244: bl              #0x13de838  ; AllocateContextStub
    // 0xdf8248: ldur            x1, [fp, #-0x10]
    // 0xdf824c: StoreField: r0->field_f = r1
    //     0xdf824c: stur            w1, [x0, #0xf]
    // 0xdf8250: mov             x2, x0
    // 0xdf8254: r1 = Function '<anonymous closure>':.
    //     0xdf8254: add             x1, PP, #0x26, lsl #12  ; [pp+0x262e8] AnonymousClosure: (0xdf87d8), of [package:flutter/src/material/popup_menu.dart] _PopupMenuDefaultsM3
    //     0xdf8258: ldr             x1, [x1, #0x2e8]
    // 0xdf825c: r0 = AllocateClosure()
    //     0xdf825c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf8260: r16 = <TextStyle?>
    //     0xdf8260: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a88] TypeArguments: <TextStyle?>
    //     0xdf8264: ldr             x16, [x16, #0xa88]
    // 0xdf8268: stp             x0, x16, [SP]
    // 0xdf826c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdf826c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdf8270: r0 = resolveWith()
    //     0xdf8270: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xdf8274: mov             x1, x0
    // 0xdf8278: b               #0xdf828c
    // 0xdf827c: mov             x1, x3
    // 0xdf8280: LoadField: r0 = r1->field_23
    //     0xdf8280: ldur            w0, [x1, #0x23]
    // 0xdf8284: DecompressPointer r0
    //     0xdf8284: add             x0, x0, HEAP, lsl #32
    // 0xdf8288: mov             x1, x0
    // 0xdf828c: cmp             w1, NULL
    // 0xdf8290: b.eq            #0xdf8528
    // 0xdf8294: ldur            x2, [fp, #-0x18]
    // 0xdf8298: r0 = build()
    //     0xdf8298: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xdf829c: cmp             w0, NULL
    // 0xdf82a0: b.eq            #0xdf852c
    // 0xdf82a4: mov             x2, x0
    // 0xdf82a8: b               #0xdf830c
    // 0xdf82ac: ldur            x1, [fp, #-0x10]
    // 0xdf82b0: r0 = LoadClassIdInstr(r1)
    //     0xdf82b0: ldur            x0, [x1, #-1]
    //     0xdf82b4: ubfx            x0, x0, #0xc, #0x14
    // 0xdf82b8: r17 = -5129
    //     0xdf82b8: mov             x17, #-0x1409
    // 0xdf82bc: add             x16, x0, x17
    // 0xdf82c0: cmp             x16, #1
    // 0xdf82c4: b.hi            #0xdf82d4
    // 0xdf82c8: LoadField: r0 = r1->field_1f
    //     0xdf82c8: ldur            w0, [x1, #0x1f]
    // 0xdf82cc: DecompressPointer r0
    //     0xdf82cc: add             x0, x0, HEAP, lsl #32
    // 0xdf82d0: b               #0xdf8300
    // 0xdf82d4: LoadField: r0 = r1->field_43
    //     0xdf82d4: ldur            w0, [x1, #0x43]
    // 0xdf82d8: DecompressPointer r0
    //     0xdf82d8: add             x0, x0, HEAP, lsl #32
    // 0xdf82dc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf82e0: cmp             w0, w16
    // 0xdf82e4: b.ne            #0xdf82f4
    // 0xdf82e8: r2 = _textTheme
    //     0xdf82e8: add             x2, PP, #0x26, lsl #12  ; [pp+0x262e0] Field <_PopupMenuDefaultsM2@113182389._textTheme@113182389>: late final (offset: 0x44)
    //     0xdf82ec: ldr             x2, [x2, #0x2e0]
    // 0xdf82f0: r0 = InitLateFinalInstanceField()
    //     0xdf82f0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf82f4: LoadField: r1 = r0->field_23
    //     0xdf82f4: ldur            w1, [x0, #0x23]
    // 0xdf82f8: DecompressPointer r1
    //     0xdf82f8: add             x1, x1, HEAP, lsl #32
    // 0xdf82fc: mov             x0, x1
    // 0xdf8300: cmp             w0, NULL
    // 0xdf8304: b.eq            #0xdf8530
    // 0xdf8308: mov             x2, x0
    // 0xdf830c: ldur            x1, [fp, #-8]
    // 0xdf8310: ldur            x0, [fp, #-0x20]
    // 0xdf8314: stur            x2, [fp, #-0x10]
    // 0xdf8318: LoadField: r3 = r1->field_b
    //     0xdf8318: ldur            w3, [x1, #0xb]
    // 0xdf831c: DecompressPointer r3
    //     0xdf831c: add             x3, x3, HEAP, lsl #32
    // 0xdf8320: cmp             w3, NULL
    // 0xdf8324: b.eq            #0xdf8534
    // 0xdf8328: tbnz            w0, #4, #0xdf8358
    // 0xdf832c: r0 = LoadStaticField(0x75c)
    //     0xdf832c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xdf8330: ldr             x0, [x0, #0xeb8]
    // 0xdf8334: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf8338: cmp             w0, w16
    // 0xdf833c: b.ne            #0xdf834c
    // 0xdf8340: r2 = menuItemPadding
    //     0xdf8340: add             x2, PP, #0xd4, lsl #12  ; [pp+0xd4878] Field <_PopupMenuDefaultsM3@113182389.menuItemPadding>: static late (offset: 0x75c)
    //     0xdf8344: ldr             x2, [x2, #0x878]
    // 0xdf8348: r0 = InitLateStaticField()
    //     0xdf8348: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0xdf834c: r2 = Instance_EdgeInsets
    //     0xdf834c: add             x2, PP, #0xd2, lsl #12  ; [pp+0xd2cc8] Obj!EdgeInsets@129d321
    //     0xdf8350: ldr             x2, [x2, #0xcc8]
    // 0xdf8354: b               #0xdf8380
    // 0xdf8358: r0 = LoadStaticField(0x760)
    //     0xdf8358: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xdf835c: ldr             x0, [x0, #0xec0]
    // 0xdf8360: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf8364: cmp             w0, w16
    // 0xdf8368: b.ne            #0xdf8378
    // 0xdf836c: r2 = menuItemPadding
    //     0xdf836c: add             x2, PP, #0xd4, lsl #12  ; [pp+0xd4880] Field <_PopupMenuDefaultsM2@113182389.menuItemPadding>: static late (offset: 0x760)
    //     0xdf8370: ldr             x2, [x2, #0x880]
    // 0xdf8374: r0 = InitLateStaticField()
    //     0xdf8374: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0xdf8378: r2 = Instance_EdgeInsets
    //     0xdf8378: add             x2, PP, #0x26, lsl #12  ; [pp+0x26510] Obj!EdgeInsets@129cdb1
    //     0xdf837c: ldr             x2, [x2, #0x510]
    // 0xdf8380: ldur            x1, [fp, #-8]
    // 0xdf8384: ldur            x0, [fp, #-0x10]
    // 0xdf8388: stur            x2, [fp, #-0x18]
    // 0xdf838c: LoadField: r3 = r1->field_b
    //     0xdf838c: ldur            w3, [x1, #0xb]
    // 0xdf8390: DecompressPointer r3
    //     0xdf8390: add             x3, x3, HEAP, lsl #32
    // 0xdf8394: cmp             w3, NULL
    // 0xdf8398: b.eq            #0xdf8538
    // 0xdf839c: r0 = BoxConstraints()
    //     0xdf839c: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xdf83a0: stur            x0, [fp, #-0x20]
    // 0xdf83a4: StoreField: r0->field_7 = rZR
    //     0xdf83a4: stur            xzr, [x0, #7]
    // 0xdf83a8: d0 = inf
    //     0xdf83a8: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xdf83ac: StoreField: r0->field_f = d0
    //     0xdf83ac: stur            d0, [x0, #0xf]
    // 0xdf83b0: d1 = 48.000000
    //     0xdf83b0: ldr             d1, [PP, #0x5650]  ; [pp+0x5650] IMM: double(48) from 0x4048000000000000
    // 0xdf83b4: ArrayStore: r0[0] = d1  ; List_8
    //     0xdf83b4: stur            d1, [x0, #0x17]
    // 0xdf83b8: StoreField: r0->field_1f = d0
    //     0xdf83b8: stur            d0, [x0, #0x1f]
    // 0xdf83bc: ldur            x1, [fp, #-8]
    // 0xdf83c0: r0 = buildChild()
    //     0xdf83c0: bl              #0xdf80d8  ; [package:flutter/src/material/popup_menu.dart] PopupMenuItemState::buildChild
    // 0xdf83c4: stur            x0, [fp, #-0x28]
    // 0xdf83c8: r0 = Align()
    //     0xdf83c8: bl              #0xb281f8  ; AllocateAlignStub -> Align (size=0x1c)
    // 0xdf83cc: mov             x1, x0
    // 0xdf83d0: r0 = Instance_AlignmentDirectional
    //     0xdf83d0: add             x0, PP, #0x28, lsl #12  ; [pp+0x28258] Obj!AlignmentDirectional@129e651
    //     0xdf83d4: ldr             x0, [x0, #0x258]
    // 0xdf83d8: stur            x1, [fp, #-0x30]
    // 0xdf83dc: StoreField: r1->field_f = r0
    //     0xdf83dc: stur            w0, [x1, #0xf]
    // 0xdf83e0: ldur            x0, [fp, #-0x28]
    // 0xdf83e4: StoreField: r1->field_b = r0
    //     0xdf83e4: stur            w0, [x1, #0xb]
    // 0xdf83e8: r0 = Padding()
    //     0xdf83e8: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xdf83ec: mov             x1, x0
    // 0xdf83f0: ldur            x0, [fp, #-0x18]
    // 0xdf83f4: stur            x1, [fp, #-0x28]
    // 0xdf83f8: StoreField: r1->field_f = r0
    //     0xdf83f8: stur            w0, [x1, #0xf]
    // 0xdf83fc: ldur            x0, [fp, #-0x30]
    // 0xdf8400: StoreField: r1->field_b = r0
    //     0xdf8400: stur            w0, [x1, #0xb]
    // 0xdf8404: r0 = ConstrainedBox()
    //     0xdf8404: bl              #0xd0a588  ; AllocateConstrainedBoxStub -> ConstrainedBox (size=0x14)
    // 0xdf8408: mov             x1, x0
    // 0xdf840c: ldur            x0, [fp, #-0x20]
    // 0xdf8410: stur            x1, [fp, #-0x18]
    // 0xdf8414: StoreField: r1->field_f = r0
    //     0xdf8414: stur            w0, [x1, #0xf]
    // 0xdf8418: ldur            x0, [fp, #-0x28]
    // 0xdf841c: StoreField: r1->field_b = r0
    //     0xdf841c: stur            w0, [x1, #0xb]
    // 0xdf8420: r0 = AnimatedDefaultTextStyle()
    //     0xdf8420: bl              #0xd2ad90  ; AllocateAnimatedDefaultTextStyleStub -> AnimatedDefaultTextStyle (size=0x38)
    // 0xdf8424: mov             x1, x0
    // 0xdf8428: ldur            x0, [fp, #-0x18]
    // 0xdf842c: ArrayStore: r1[0] = r0  ; List_4
    //     0xdf842c: stur            w0, [x1, #0x17]
    // 0xdf8430: ldur            x0, [fp, #-0x10]
    // 0xdf8434: StoreField: r1->field_1b = r0
    //     0xdf8434: stur            w0, [x1, #0x1b]
    // 0xdf8438: r2 = true
    //     0xdf8438: add             x2, NULL, #0x20  ; true
    // 0xdf843c: StoreField: r1->field_23 = r2
    //     0xdf843c: stur            w2, [x1, #0x23]
    // 0xdf8440: r3 = Instance_TextOverflow
    //     0xdf8440: add             x3, PP, #0x20, lsl #12  ; [pp+0x20108] Obj!TextOverflow@12c47c1
    //     0xdf8444: ldr             x3, [x3, #0x108]
    // 0xdf8448: StoreField: r1->field_27 = r3
    //     0xdf8448: stur            w3, [x1, #0x27]
    // 0xdf844c: r3 = Instance_TextWidthBasis
    //     0xdf844c: add             x3, PP, #0x20, lsl #12  ; [pp+0x20110] Obj!TextWidthBasis@12c4781
    //     0xdf8450: ldr             x3, [x3, #0x110]
    // 0xdf8454: StoreField: r1->field_2f = r3
    //     0xdf8454: stur            w3, [x1, #0x2f]
    // 0xdf8458: r3 = Instance__Linear
    //     0xdf8458: ldr             x3, [PP, #0x5168]  ; [pp+0x5168] Obj!_Linear@129fef1
    // 0xdf845c: StoreField: r1->field_b = r3
    //     0xdf845c: stur            w3, [x1, #0xb]
    // 0xdf8460: r3 = Instance_Duration
    //     0xdf8460: add             x3, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xdf8464: ldr             x3, [x3, #0x318]
    // 0xdf8468: StoreField: r1->field_f = r3
    //     0xdf8468: stur            w3, [x1, #0xf]
    // 0xdf846c: ldur            x3, [fp, #-8]
    // 0xdf8470: LoadField: r4 = r3->field_b
    //     0xdf8470: ldur            w4, [x3, #0xb]
    // 0xdf8474: DecompressPointer r4
    //     0xdf8474: add             x4, x4, HEAP, lsl #32
    // 0xdf8478: cmp             w4, NULL
    // 0xdf847c: b.eq            #0xdf853c
    // 0xdf8480: r16 = Instance_EdgeInsets
    //     0xdf8480: ldr             x16, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0xdf8484: stp             x0, x16, [SP]
    // 0xdf8488: r4 = const [0, 0x3, 0x2, 0x1, contentPadding, 0x1, titleTextStyle, 0x2, null]
    //     0xdf8488: add             x4, PP, #0xd4, lsl #12  ; [pp+0xd4888] List(9) [0, 0x3, 0x2, 0x1, "contentPadding", 0x1, "titleTextStyle", 0x2, Null]
    //     0xdf848c: ldr             x4, [x4, #0x888]
    // 0xdf8490: r0 = merge()
    //     0xdf8490: bl              #0xd19d10  ; [package:flutter/src/material/list_tile_theme.dart] ListTileTheme::merge
    // 0xdf8494: stur            x0, [fp, #-0x10]
    // 0xdf8498: r0 = InkWell()
    //     0xdf8498: bl              #0xd0c57c  ; AllocateInkWellStub -> InkWell (size=0x94)
    // 0xdf849c: mov             x3, x0
    // 0xdf84a0: ldur            x0, [fp, #-0x10]
    // 0xdf84a4: stur            x3, [fp, #-0x18]
    // 0xdf84a8: StoreField: r3->field_b = r0
    //     0xdf84a8: stur            w0, [x3, #0xb]
    // 0xdf84ac: ldur            x2, [fp, #-8]
    // 0xdf84b0: r1 = Function 'handleTap':.
    //     0xdf84b0: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4890] AnonymousClosure: (0xdf863c), in [package:flutter/src/material/popup_menu.dart] PopupMenuItemState::handleTap (0xdf8674)
    //     0xdf84b4: ldr             x1, [x1, #0x890]
    // 0xdf84b8: r0 = AllocateClosure()
    //     0xdf84b8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf84bc: ldur            x2, [fp, #-0x18]
    // 0xdf84c0: StoreField: r2->field_f = r0
    //     0xdf84c0: stur            w0, [x2, #0xf]
    // 0xdf84c4: r0 = _EffectiveMouseCursor()
    //     0xdf84c4: bl              #0xdf85bc  ; Allocate_EffectiveMouseCursorStub -> _EffectiveMouseCursor (size=0x10)
    // 0xdf84c8: ldur            x2, [fp, #-0x18]
    // 0xdf84cc: StoreField: r2->field_43 = r0
    //     0xdf84cc: stur            w0, [x2, #0x43]
    // 0xdf84d0: r0 = true
    //     0xdf84d0: add             x0, NULL, #0x20  ; true
    // 0xdf84d4: StoreField: r2->field_47 = r0
    //     0xdf84d4: stur            w0, [x2, #0x47]
    // 0xdf84d8: r1 = Instance_BoxShape
    //     0xdf84d8: add             x1, PP, #0x17, lsl #12  ; [pp+0x171f8] Obj!BoxShape@12c4921
    //     0xdf84dc: ldr             x1, [x1, #0x1f8]
    // 0xdf84e0: StoreField: r2->field_4b = r1
    //     0xdf84e0: stur            w1, [x2, #0x4b]
    // 0xdf84e4: StoreField: r2->field_73 = r0
    //     0xdf84e4: stur            w0, [x2, #0x73]
    // 0xdf84e8: r1 = false
    //     0xdf84e8: add             x1, NULL, #0x30  ; false
    // 0xdf84ec: StoreField: r2->field_77 = r1
    //     0xdf84ec: stur            w1, [x2, #0x77]
    // 0xdf84f0: StoreField: r2->field_87 = r0
    //     0xdf84f0: stur            w0, [x2, #0x87]
    // 0xdf84f4: StoreField: r2->field_7f = r1
    //     0xdf84f4: stur            w1, [x2, #0x7f]
    // 0xdf84f8: ldur            x1, [fp, #-8]
    // 0xdf84fc: r0 = buildSemantics()
    //     0xdf84fc: bl              #0xdf8540  ; [package:flutter/src/material/popup_menu.dart] PopupMenuItemState::buildSemantics
    // 0xdf8500: stur            x0, [fp, #-8]
    // 0xdf8504: r0 = MergeSemantics()
    //     0xdf8504: bl              #0xd32f80  ; AllocateMergeSemanticsStub -> MergeSemantics (size=0x10)
    // 0xdf8508: ldur            x1, [fp, #-8]
    // 0xdf850c: StoreField: r0->field_b = r1
    //     0xdf850c: stur            w1, [x0, #0xb]
    // 0xdf8510: LeaveFrame
    //     0xdf8510: mov             SP, fp
    //     0xdf8514: ldp             fp, lr, [SP], #0x10
    // 0xdf8518: ret
    //     0xdf8518: ret             
    // 0xdf851c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf851c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf8520: b               #0xdf8128
    // 0xdf8524: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf8524: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf8528: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf8528: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf852c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf852c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf8530: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf8530: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf8534: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf8534: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf8538: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf8538: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf853c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf853c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ buildSemantics(/* No info */) {
    // ** addr: 0xdf8540, size: 0x7c
    // 0xdf8540: EnterFrame
    //     0xdf8540: stp             fp, lr, [SP, #-0x10]!
    //     0xdf8544: mov             fp, SP
    // 0xdf8548: AllocStack(0x30)
    //     0xdf8548: sub             SP, SP, #0x30
    // 0xdf854c: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0xdf854c: stur            x2, [fp, #-8]
    // 0xdf8550: CheckStackOverflow
    //     0xdf8550: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf8554: cmp             SP, x16
    //     0xdf8558: b.ls            #0xdf85b0
    // 0xdf855c: LoadField: r0 = r1->field_b
    //     0xdf855c: ldur            w0, [x1, #0xb]
    // 0xdf8560: DecompressPointer r0
    //     0xdf8560: add             x0, x0, HEAP, lsl #32
    // 0xdf8564: cmp             w0, NULL
    // 0xdf8568: b.eq            #0xdf85b8
    // 0xdf856c: r0 = Semantics()
    //     0xdf856c: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xdf8570: stur            x0, [fp, #-0x10]
    // 0xdf8574: r16 = Instance_SemanticsRole
    //     0xdf8574: add             x16, PP, #0xd3, lsl #12  ; [pp+0xd3568] Obj!SemanticsRole@12c7941
    //     0xdf8578: ldr             x16, [x16, #0x568]
    // 0xdf857c: r30 = true
    //     0xdf857c: add             lr, NULL, #0x20  ; true
    // 0xdf8580: stp             lr, x16, [SP, #0x10]
    // 0xdf8584: r16 = true
    //     0xdf8584: add             x16, NULL, #0x20  ; true
    // 0xdf8588: ldur            lr, [fp, #-8]
    // 0xdf858c: stp             lr, x16, [SP]
    // 0xdf8590: mov             x1, x0
    // 0xdf8594: r4 = const [0, 0x5, 0x4, 0x1, button, 0x3, child, 0x4, enabled, 0x2, role, 0x1, null]
    //     0xdf8594: add             x4, PP, #0xd4, lsl #12  ; [pp+0xd4898] List(13) [0, 0x5, 0x4, 0x1, "button", 0x3, "child", 0x4, "enabled", 0x2, "role", 0x1, Null]
    //     0xdf8598: ldr             x4, [x4, #0x898]
    // 0xdf859c: r0 = Semantics()
    //     0xdf859c: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xdf85a0: ldur            x0, [fp, #-0x10]
    // 0xdf85a4: LeaveFrame
    //     0xdf85a4: mov             SP, fp
    //     0xdf85a8: ldp             fp, lr, [SP], #0x10
    // 0xdf85ac: ret
    //     0xdf85ac: ret             
    // 0xdf85b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf85b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf85b4: b               #0xdf855c
    // 0xdf85b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf85b8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void handleTap(dynamic) {
    // ** addr: 0xdf863c, size: 0x38
    // 0xdf863c: EnterFrame
    //     0xdf863c: stp             fp, lr, [SP, #-0x10]!
    //     0xdf8640: mov             fp, SP
    // 0xdf8644: ldr             x0, [fp, #0x10]
    // 0xdf8648: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdf8648: ldur            w1, [x0, #0x17]
    // 0xdf864c: DecompressPointer r1
    //     0xdf864c: add             x1, x1, HEAP, lsl #32
    // 0xdf8650: CheckStackOverflow
    //     0xdf8650: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf8654: cmp             SP, x16
    //     0xdf8658: b.ls            #0xdf866c
    // 0xdf865c: r0 = handleTap()
    //     0xdf865c: bl              #0xdf8674  ; [package:flutter/src/material/popup_menu.dart] PopupMenuItemState::handleTap
    // 0xdf8660: LeaveFrame
    //     0xdf8660: mov             SP, fp
    //     0xdf8664: ldp             fp, lr, [SP], #0x10
    // 0xdf8668: ret
    //     0xdf8668: ret             
    // 0xdf866c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf866c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf8670: b               #0xdf865c
  }
  _ handleTap(/* No info */) {
    // ** addr: 0xdf8674, size: 0xbc
    // 0xdf8674: EnterFrame
    //     0xdf8674: stp             fp, lr, [SP, #-0x10]!
    //     0xdf8678: mov             fp, SP
    // 0xdf867c: AllocStack(0x20)
    //     0xdf867c: sub             SP, SP, #0x20
    // 0xdf8680: SetupParameters(PopupMenuItemState<C1X0, C1X1 bound PopupMenuItem> this /* r1 => r0, fp-0x8 */)
    //     0xdf8680: mov             x0, x1
    //     0xdf8684: stur            x1, [fp, #-8]
    // 0xdf8688: CheckStackOverflow
    //     0xdf8688: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf868c: cmp             SP, x16
    //     0xdf8690: b.ls            #0xdf871c
    // 0xdf8694: LoadField: r2 = r0->field_7
    //     0xdf8694: ldur            w2, [x0, #7]
    // 0xdf8698: DecompressPointer r2
    //     0xdf8698: add             x2, x2, HEAP, lsl #32
    // 0xdf869c: r1 = Null
    //     0xdf869c: mov             x1, NULL
    // 0xdf86a0: r3 = <C1X0>
    //     0xdf86a0: add             x3, PP, #0x11, lsl #12  ; [pp+0x11880] TypeArguments: <C1X0>
    //     0xdf86a4: ldr             x3, [x3, #0x880]
    // 0xdf86a8: r0 = Null
    //     0xdf86a8: mov             x0, NULL
    // 0xdf86ac: cmp             x2, x0
    // 0xdf86b0: b.eq            #0xdf86c0
    // 0xdf86b4: r30 = InstantiateTypeArgumentsStub
    //     0xdf86b4: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0xdf86b8: LoadField: r30 = r30->field_7
    //     0xdf86b8: ldur            lr, [lr, #7]
    // 0xdf86bc: blr             lr
    // 0xdf86c0: mov             x1, x0
    // 0xdf86c4: ldur            x0, [fp, #-8]
    // 0xdf86c8: LoadField: r2 = r0->field_f
    //     0xdf86c8: ldur            w2, [x0, #0xf]
    // 0xdf86cc: DecompressPointer r2
    //     0xdf86cc: add             x2, x2, HEAP, lsl #32
    // 0xdf86d0: cmp             w2, NULL
    // 0xdf86d4: b.eq            #0xdf8724
    // 0xdf86d8: LoadField: r3 = r0->field_b
    //     0xdf86d8: ldur            w3, [x0, #0xb]
    // 0xdf86dc: DecompressPointer r3
    //     0xdf86dc: add             x3, x3, HEAP, lsl #32
    // 0xdf86e0: cmp             w3, NULL
    // 0xdf86e4: b.eq            #0xdf8728
    // 0xdf86e8: stp             x2, x1, [SP, #8]
    // 0xdf86ec: str             NULL, [SP]
    // 0xdf86f0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xdf86f0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xdf86f4: r0 = pop()
    //     0xdf86f4: bl              #0xd190ec  ; [package:flutter/src/widgets/navigator.dart] Navigator::pop
    // 0xdf86f8: ldur            x1, [fp, #-8]
    // 0xdf86fc: LoadField: r2 = r1->field_b
    //     0xdf86fc: ldur            w2, [x1, #0xb]
    // 0xdf8700: DecompressPointer r2
    //     0xdf8700: add             x2, x2, HEAP, lsl #32
    // 0xdf8704: cmp             w2, NULL
    // 0xdf8708: b.eq            #0xdf872c
    // 0xdf870c: r0 = Null
    //     0xdf870c: mov             x0, NULL
    // 0xdf8710: LeaveFrame
    //     0xdf8710: mov             SP, fp
    //     0xdf8714: ldp             fp, lr, [SP], #0x10
    // 0xdf8718: ret
    //     0xdf8718: ret             
    // 0xdf871c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf871c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf8720: b               #0xdf8694
    // 0xdf8724: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf8724: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf8728: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf8728: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf872c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf872c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 6450, size: 0x24, field offset: 0xc
//   const constructor, 
class _PopupMenu<X0> extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa235c, size: 0x48
    // 0xfa235c: EnterFrame
    //     0xfa235c: stp             fp, lr, [SP, #-0x10]!
    //     0xfa2360: mov             fp, SP
    // 0xfa2364: LoadField: r2 = r1->field_b
    //     0xfa2364: ldur            w2, [x1, #0xb]
    // 0xfa2368: DecompressPointer r2
    //     0xfa2368: add             x2, x2, HEAP, lsl #32
    // 0xfa236c: r1 = Null
    //     0xfa236c: mov             x1, NULL
    // 0xfa2370: r3 = <_PopupMenu<X0>, X0>
    //     0xfa2370: add             x3, PP, #0xd4, lsl #12  ; [pp+0xd4850] TypeArguments: <_PopupMenu<X0>, X0>
    //     0xfa2374: ldr             x3, [x3, #0x850]
    // 0xfa2378: r30 = InstantiateTypeArgumentsStub
    //     0xfa2378: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0xfa237c: LoadField: r30 = r30->field_7
    //     0xfa237c: ldur            lr, [lr, #7]
    // 0xfa2380: blr             lr
    // 0xfa2384: mov             x1, x0
    // 0xfa2388: r0 = _PopupMenuState()
    //     0xfa2388: bl              #0xfa23a4  ; Allocate_PopupMenuStateStub -> _PopupMenuState<C1X0> (size=0x18)
    // 0xfa238c: r1 = const []
    //     0xfa238c: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4858] List<CurvedAnimation>(0)
    //     0xfa2390: ldr             x1, [x1, #0x858]
    // 0xfa2394: StoreField: r0->field_13 = r1
    //     0xfa2394: stur            w1, [x0, #0x13]
    // 0xfa2398: LeaveFrame
    //     0xfa2398: mov             SP, fp
    //     0xfa239c: ldp             fp, lr, [SP], #0x10
    // 0xfa23a0: ret
    //     0xfa23a0: ret             
  }
}

// class id: 6451, size: 0x10, field offset: 0xc
//   const constructor, 
abstract class PopupMenuEntry<X0> extends StatefulWidget {
}

// class id: 6452, size: 0x38, field offset: 0x10
//   const constructor, 
class PopupMenuItem<X0> extends PopupMenuEntry<X0> {

  _ createState(/* No info */) {
    // ** addr: 0xfa2314, size: 0x3c
    // 0xfa2314: EnterFrame
    //     0xfa2314: stp             fp, lr, [SP, #-0x10]!
    //     0xfa2318: mov             fp, SP
    // 0xfa231c: LoadField: r2 = r1->field_b
    //     0xfa231c: ldur            w2, [x1, #0xb]
    // 0xfa2320: DecompressPointer r2
    //     0xfa2320: add             x2, x2, HEAP, lsl #32
    // 0xfa2324: r1 = Null
    //     0xfa2324: mov             x1, NULL
    // 0xfa2328: r3 = <PopupMenuItem<X0>, X0, PopupMenuItem<X0>>
    //     0xfa2328: add             x3, PP, #0xd4, lsl #12  ; [pp+0xd4200] TypeArguments: <PopupMenuItem<X0>, X0, PopupMenuItem<X0>>
    //     0xfa232c: ldr             x3, [x3, #0x200]
    // 0xfa2330: r30 = InstantiateTypeArgumentsStub
    //     0xfa2330: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0xfa2334: LoadField: r30 = r30->field_7
    //     0xfa2334: ldur            lr, [lr, #7]
    // 0xfa2338: blr             lr
    // 0xfa233c: mov             x1, x0
    // 0xfa2340: r0 = PopupMenuItemState()
    //     0xfa2340: bl              #0xfa2350  ; AllocatePopupMenuItemStateStub -> PopupMenuItemState<C1X0, C1X1 bound PopupMenuItem> (size=0x14)
    // 0xfa2344: LeaveFrame
    //     0xfa2344: mov             SP, fp
    //     0xfa2348: ldp             fp, lr, [SP], #0x10
    // 0xfa234c: ret
    //     0xfa234c: ret             
  }
}

// class id: 6651, size: 0x14, field offset: 0x10
//   const constructor, 
class _MenuItem extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf4c34, size: 0x94
    // 0xcf4c34: EnterFrame
    //     0xcf4c34: stp             fp, lr, [SP, #-0x10]!
    //     0xcf4c38: mov             fp, SP
    // 0xcf4c3c: AllocStack(0x10)
    //     0xcf4c3c: sub             SP, SP, #0x10
    // 0xcf4c40: SetupParameters(_MenuItem this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4 */, dynamic _ /* r3 => r0, fp-0x10 */)
    //     0xcf4c40: mov             x0, x3
    //     0xcf4c44: mov             x5, x1
    //     0xcf4c48: mov             x4, x2
    //     0xcf4c4c: stur            x1, [fp, #-8]
    //     0xcf4c50: stur            x3, [fp, #-0x10]
    // 0xcf4c54: r2 = Null
    //     0xcf4c54: mov             x2, NULL
    // 0xcf4c58: r1 = Null
    //     0xcf4c58: mov             x1, NULL
    // 0xcf4c5c: r4 = 60
    //     0xcf4c5c: mov             x4, #0x3c
    // 0xcf4c60: branchIfSmi(r0, 0xcf4c6c)
    //     0xcf4c60: tbz             w0, #0, #0xcf4c6c
    // 0xcf4c64: r4 = LoadClassIdInstr(r0)
    //     0xcf4c64: ldur            x4, [x0, #-1]
    //     0xcf4c68: ubfx            x4, x4, #0xc, #0x14
    // 0xcf4c6c: r17 = 4878
    //     0xcf4c6c: mov             x17, #0x130e
    // 0xcf4c70: cmp             x4, x17
    // 0xcf4c74: b.eq            #0xcf4c8c
    // 0xcf4c78: r8 = _RenderMenuItem
    //     0xcf4c78: add             x8, PP, #0xd4, lsl #12  ; [pp+0xd4e70] Type: _RenderMenuItem
    //     0xcf4c7c: ldr             x8, [x8, #0xe70]
    // 0xcf4c80: r3 = Null
    //     0xcf4c80: add             x3, PP, #0xd4, lsl #12  ; [pp+0xd4e78] Null
    //     0xcf4c84: ldr             x3, [x3, #0xe78]
    // 0xcf4c88: r0 = DefaultTypeTest()
    //     0xcf4c88: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf4c8c: ldur            x1, [fp, #-8]
    // 0xcf4c90: LoadField: r0 = r1->field_f
    //     0xcf4c90: ldur            w0, [x1, #0xf]
    // 0xcf4c94: DecompressPointer r0
    //     0xcf4c94: add             x0, x0, HEAP, lsl #32
    // 0xcf4c98: ldur            x1, [fp, #-0x10]
    // 0xcf4c9c: StoreField: r1->field_53 = r0
    //     0xcf4c9c: stur            w0, [x1, #0x53]
    //     0xcf4ca0: ldurb           w16, [x1, #-1]
    //     0xcf4ca4: ldurb           w17, [x0, #-1]
    //     0xcf4ca8: and             x16, x17, x16, lsr #2
    //     0xcf4cac: tst             x16, HEAP, lsr #32
    //     0xcf4cb0: b.eq            #0xcf4cb8
    //     0xcf4cb4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf4cb8: r0 = Null
    //     0xcf4cb8: mov             x0, NULL
    // 0xcf4cbc: LeaveFrame
    //     0xcf4cbc: mov             SP, fp
    //     0xcf4cc0: ldp             fp, lr, [SP], #0x10
    // 0xcf4cc4: ret
    //     0xcf4cc4: ret             
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11cfb88, size: 0x74
    // 0x11cfb88: EnterFrame
    //     0x11cfb88: stp             fp, lr, [SP, #-0x10]!
    //     0x11cfb8c: mov             fp, SP
    // 0x11cfb90: AllocStack(0x10)
    //     0x11cfb90: sub             SP, SP, #0x10
    // 0x11cfb94: CheckStackOverflow
    //     0x11cfb94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11cfb98: cmp             SP, x16
    //     0x11cfb9c: b.ls            #0x11cfbf4
    // 0x11cfba0: LoadField: r0 = r1->field_f
    //     0x11cfba0: ldur            w0, [x1, #0xf]
    // 0x11cfba4: DecompressPointer r0
    //     0x11cfba4: add             x0, x0, HEAP, lsl #32
    // 0x11cfba8: stur            x0, [fp, #-8]
    // 0x11cfbac: r0 = _RenderMenuItem()
    //     0x11cfbac: bl              #0x11cfbfc  ; Allocate_RenderMenuItemStub -> _RenderMenuItem (size=0x58)
    // 0x11cfbb0: mov             x1, x0
    // 0x11cfbb4: ldur            x0, [fp, #-8]
    // 0x11cfbb8: stur            x1, [fp, #-0x10]
    // 0x11cfbbc: StoreField: r1->field_53 = r0
    //     0x11cfbbc: stur            w0, [x1, #0x53]
    // 0x11cfbc0: r0 = _LayoutCacheStorage()
    //     0x11cfbc0: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11cfbc4: mov             x1, x0
    // 0x11cfbc8: ldur            x0, [fp, #-0x10]
    // 0x11cfbcc: StoreField: r0->field_47 = r1
    //     0x11cfbcc: stur            w1, [x0, #0x47]
    // 0x11cfbd0: mov             x1, x0
    // 0x11cfbd4: r0 = RenderObject()
    //     0x11cfbd4: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11cfbd8: ldur            x1, [fp, #-0x10]
    // 0x11cfbdc: r2 = Null
    //     0x11cfbdc: mov             x2, NULL
    // 0x11cfbe0: r0 = child=()
    //     0x11cfbe0: bl              #0xaef33c  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::child=
    // 0x11cfbe4: ldur            x0, [fp, #-0x10]
    // 0x11cfbe8: LeaveFrame
    //     0x11cfbe8: mov             SP, fp
    //     0x11cfbec: ldp             fp, lr, [SP], #0x10
    // 0x11cfbf0: ret
    //     0x11cfbf0: ret             
    // 0x11cfbf4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11cfbf4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11cfbf8: b               #0x11cfba0
  }
}
