// lib: , url: package:flutter/src/material/button_style_button.dart

// class id: 1048858, size: 0x8
class :: {
}

// class id: 4879, size: 0x58, field offset: 0x54
class _RenderInputPadding extends RenderShiftedBox {

  [closure] bool <anonymous closure>(dynamic, BoxHitTestResult, Offset) {
    // ** addr: 0xaf9a78, size: 0x7c
    // 0xaf9a78: EnterFrame
    //     0xaf9a78: stp             fp, lr, [SP, #-0x10]!
    //     0xaf9a7c: mov             fp, SP
    // 0xaf9a80: ldr             x0, [fp, #0x20]
    // 0xaf9a84: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xaf9a84: ldur            w1, [x0, #0x17]
    // 0xaf9a88: DecompressPointer r1
    //     0xaf9a88: add             x1, x1, HEAP, lsl #32
    // 0xaf9a8c: CheckStackOverflow
    //     0xaf9a8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xaf9a90: cmp             SP, x16
    //     0xaf9a94: b.ls            #0xaf9ae8
    // 0xaf9a98: LoadField: r0 = r1->field_f
    //     0xaf9a98: ldur            w0, [x1, #0xf]
    // 0xaf9a9c: DecompressPointer r0
    //     0xaf9a9c: add             x0, x0, HEAP, lsl #32
    // 0xaf9aa0: LoadField: r2 = r0->field_4f
    //     0xaf9aa0: ldur            w2, [x0, #0x4f]
    // 0xaf9aa4: DecompressPointer r2
    //     0xaf9aa4: add             x2, x2, HEAP, lsl #32
    // 0xaf9aa8: cmp             w2, NULL
    // 0xaf9aac: b.eq            #0xaf9af0
    // 0xaf9ab0: LoadField: r3 = r1->field_13
    //     0xaf9ab0: ldur            w3, [x1, #0x13]
    // 0xaf9ab4: DecompressPointer r3
    //     0xaf9ab4: add             x3, x3, HEAP, lsl #32
    // 0xaf9ab8: r0 = LoadClassIdInstr(r2)
    //     0xaf9ab8: ldur            x0, [x2, #-1]
    //     0xaf9abc: ubfx            x0, x0, #0xc, #0x14
    // 0xaf9ac0: mov             x1, x2
    // 0xaf9ac4: ldr             x2, [fp, #0x18]
    // 0xaf9ac8: r0 = GDT[cid_x0 + 0x13d77]()
    //     0xaf9ac8: mov             x17, #0x3d77
    //     0xaf9acc: movk            x17, #1, lsl #16
    //     0xaf9ad0: add             lr, x0, x17
    //     0xaf9ad4: ldr             lr, [x21, lr, lsl #3]
    //     0xaf9ad8: blr             lr
    // 0xaf9adc: LeaveFrame
    //     0xaf9adc: mov             SP, fp
    //     0xaf9ae0: ldp             fp, lr, [SP], #0x10
    // 0xaf9ae4: ret
    //     0xaf9ae4: ret             
    // 0xaf9ae8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaf9ae8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaf9aec: b               #0xaf9a98
    // 0xaf9af0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xaf9af0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ hitTest(/* No info */) {
    // ** addr: 0xaf9af4, size: 0xf4
    // 0xaf9af4: EnterFrame
    //     0xaf9af4: stp             fp, lr, [SP, #-0x10]!
    //     0xaf9af8: mov             fp, SP
    // 0xaf9afc: AllocStack(0x20)
    //     0xaf9afc: sub             SP, SP, #0x20
    // 0xaf9b00: SetupParameters(_RenderInputPadding this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xaf9b00: stur            x1, [fp, #-8]
    //     0xaf9b04: stur            x2, [fp, #-0x10]
    //     0xaf9b08: stur            x3, [fp, #-0x18]
    // 0xaf9b0c: CheckStackOverflow
    //     0xaf9b0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xaf9b10: cmp             SP, x16
    //     0xaf9b14: b.ls            #0xaf9bdc
    // 0xaf9b18: r1 = 2
    //     0xaf9b18: mov             x1, #2
    // 0xaf9b1c: r0 = AllocateContext()
    //     0xaf9b1c: bl              #0x13de838  ; AllocateContextStub
    // 0xaf9b20: mov             x4, x0
    // 0xaf9b24: ldur            x0, [fp, #-8]
    // 0xaf9b28: stur            x4, [fp, #-0x20]
    // 0xaf9b2c: StoreField: r4->field_f = r0
    //     0xaf9b2c: stur            w0, [x4, #0xf]
    // 0xaf9b30: mov             x1, x0
    // 0xaf9b34: ldur            x2, [fp, #-0x10]
    // 0xaf9b38: ldur            x3, [fp, #-0x18]
    // 0xaf9b3c: r0 = hitTest()
    //     0xaf9b3c: bl              #0xafb454  ; [package:flutter/src/rendering/box.dart] RenderBox::hitTest
    // 0xaf9b40: tbnz            w0, #4, #0xaf9b54
    // 0xaf9b44: r0 = true
    //     0xaf9b44: add             x0, NULL, #0x20  ; true
    // 0xaf9b48: LeaveFrame
    //     0xaf9b48: mov             SP, fp
    //     0xaf9b4c: ldp             fp, lr, [SP], #0x10
    // 0xaf9b50: ret
    //     0xaf9b50: ret             
    // 0xaf9b54: ldur            x0, [fp, #-8]
    // 0xaf9b58: ldur            x2, [fp, #-0x20]
    // 0xaf9b5c: LoadField: r1 = r0->field_4f
    //     0xaf9b5c: ldur            w1, [x0, #0x4f]
    // 0xaf9b60: DecompressPointer r1
    //     0xaf9b60: add             x1, x1, HEAP, lsl #32
    // 0xaf9b64: cmp             w1, NULL
    // 0xaf9b68: b.eq            #0xaf9be4
    // 0xaf9b6c: r0 = size()
    //     0xaf9b6c: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xaf9b70: mov             x1, x0
    // 0xaf9b74: r0 = center()
    //     0xaf9b74: bl              #0xaf9a1c  ; [dart:ui] Size::center
    // 0xaf9b78: mov             x3, x0
    // 0xaf9b7c: ldur            x2, [fp, #-0x20]
    // 0xaf9b80: stur            x3, [fp, #-8]
    // 0xaf9b84: StoreField: r2->field_13 = r0
    //     0xaf9b84: stur            w0, [x2, #0x13]
    //     0xaf9b88: ldurb           w16, [x2, #-1]
    //     0xaf9b8c: ldurb           w17, [x0, #-1]
    //     0xaf9b90: and             x16, x17, x16, lsr #2
    //     0xaf9b94: tst             x16, HEAP, lsr #32
    //     0xaf9b98: b.eq            #0xaf9ba0
    //     0xaf9b9c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xaf9ba0: mov             x1, x3
    // 0xaf9ba4: r0 = forceToPoint()
    //     0xaf9ba4: bl              #0xaf99c4  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::forceToPoint
    // 0xaf9ba8: ldur            x2, [fp, #-0x20]
    // 0xaf9bac: r1 = Function '<anonymous closure>':.
    //     0xaf9bac: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa4160] AnonymousClosure: (0xaf9a78), in [package:flutter/src/material/button_style_button.dart] _RenderInputPadding::hitTest (0xaf9af4)
    //     0xaf9bb0: ldr             x1, [x1, #0x160]
    // 0xaf9bb4: stur            x0, [fp, #-0x18]
    // 0xaf9bb8: r0 = AllocateClosure()
    //     0xaf9bb8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xaf9bbc: ldur            x1, [fp, #-0x10]
    // 0xaf9bc0: mov             x2, x0
    // 0xaf9bc4: ldur            x3, [fp, #-8]
    // 0xaf9bc8: ldur            x5, [fp, #-0x18]
    // 0xaf9bcc: r0 = addWithRawTransform()
    //     0xaf9bcc: bl              #0xaf9790  ; [package:flutter/src/rendering/box.dart] BoxHitTestResult::addWithRawTransform
    // 0xaf9bd0: LeaveFrame
    //     0xaf9bd0: mov             SP, fp
    //     0xaf9bd4: ldp             fp, lr, [SP], #0x10
    // 0xaf9bd8: ret
    //     0xaf9bd8: ret             
    // 0xaf9bdc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaf9bdc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaf9be0: b               #0xaf9b18
    // 0xaf9be4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xaf9be4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0xb17070, size: 0x24
    // 0xb17070: EnterFrame
    //     0xb17070: stp             fp, lr, [SP, #-0x10]!
    //     0xb17074: mov             fp, SP
    // 0xb17078: ldr             x2, [fp, #0x10]
    // 0xb1707c: r1 = Function 'computeMinIntrinsicWidth':.
    //     0xb1707c: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa4158] AnonymousClosure: (0xb17094), in [package:flutter/src/material/button.dart] _RenderInputPadding::computeMinIntrinsicWidth (0xb16ffc)
    //     0xb17080: ldr             x1, [x1, #0x158]
    // 0xb17084: r0 = AllocateClosure()
    //     0xb17084: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb17088: LeaveFrame
    //     0xb17088: mov             SP, fp
    //     0xb1708c: ldp             fp, lr, [SP], #0x10
    // 0xb17090: ret
    //     0xb17090: ret             
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb17094, size: 0x78
    // 0xb17094: EnterFrame
    //     0xb17094: stp             fp, lr, [SP, #-0x10]!
    //     0xb17098: mov             fp, SP
    // 0xb1709c: ldr             x0, [fp, #0x18]
    // 0xb170a0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb170a0: ldur            w1, [x0, #0x17]
    // 0xb170a4: DecompressPointer r1
    //     0xb170a4: add             x1, x1, HEAP, lsl #32
    // 0xb170a8: CheckStackOverflow
    //     0xb170a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb170ac: cmp             SP, x16
    //     0xb170b0: b.ls            #0xb170f4
    // 0xb170b4: ldr             x2, [fp, #0x10]
    // 0xb170b8: r0 = computeMinIntrinsicWidth()
    //     0xb170b8: bl              #0xb16ffc  ; [package:flutter/src/material/button.dart] _RenderInputPadding::computeMinIntrinsicWidth
    // 0xb170bc: r0 = inline_Allocate_Double()
    //     0xb170bc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb170c0: add             x0, x0, #0x10
    //     0xb170c4: cmp             x1, x0
    //     0xb170c8: b.ls            #0xb170fc
    //     0xb170cc: str             x0, [THR, #0x60]  ; THR::top
    //     0xb170d0: sub             x0, x0, #0xf
    //     0xb170d4: mov             x1, #0xe19c
    //     0xb170d8: movk            x1, #3, lsl #16
    //     0xb170dc: stur            x1, [x0, #-1]
    // 0xb170e0: dmb             ishst
    // 0xb170e4: StoreField: r0->field_7 = d0
    //     0xb170e4: stur            d0, [x0, #7]
    // 0xb170e8: LeaveFrame
    //     0xb170e8: mov             SP, fp
    //     0xb170ec: ldp             fp, lr, [SP], #0x10
    // 0xb170f0: ret
    //     0xb170f0: ret             
    // 0xb170f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb170f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb170f8: b               #0xb170b4
    // 0xb170fc: SaveReg d0
    //     0xb170fc: str             q0, [SP, #-0x10]!
    // 0xb17100: r0 = AllocateDouble()
    //     0xb17100: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb17104: RestoreReg d0
    //     0xb17104: ldr             q0, [SP], #0x10
    // 0xb17108: b               #0xb170e4
  }
  _ computeMinIntrinsicHeight(/* No info */) {
    // ** addr: 0xb2328c, size: 0x74
    // 0xb2328c: EnterFrame
    //     0xb2328c: stp             fp, lr, [SP, #-0x10]!
    //     0xb23290: mov             fp, SP
    // 0xb23294: AllocStack(0x8)
    //     0xb23294: sub             SP, SP, #8
    // 0xb23298: SetupParameters(_RenderInputPadding this /* r1 => r0, fp-0x8 */)
    //     0xb23298: mov             x0, x1
    //     0xb2329c: stur            x1, [fp, #-8]
    // 0xb232a0: CheckStackOverflow
    //     0xb232a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb232a4: cmp             SP, x16
    //     0xb232a8: b.ls            #0xb232f8
    // 0xb232ac: LoadField: r1 = r0->field_4f
    //     0xb232ac: ldur            w1, [x0, #0x4f]
    // 0xb232b0: DecompressPointer r1
    //     0xb232b0: add             x1, x1, HEAP, lsl #32
    // 0xb232b4: cmp             w1, NULL
    // 0xb232b8: b.eq            #0xb232e8
    // 0xb232bc: LoadField: d0 = r2->field_7
    //     0xb232bc: ldur            d0, [x2, #7]
    // 0xb232c0: r0 = getMinIntrinsicHeight()
    //     0xb232c0: bl              #0xb177d8  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicHeight
    // 0xb232c4: ldur            x0, [fp, #-8]
    // 0xb232c8: LoadField: r1 = r0->field_53
    //     0xb232c8: ldur            w1, [x0, #0x53]
    // 0xb232cc: DecompressPointer r1
    //     0xb232cc: add             x1, x1, HEAP, lsl #32
    // 0xb232d0: LoadField: d1 = r1->field_f
    //     0xb232d0: ldur            d1, [x1, #0xf]
    // 0xb232d4: fmax            v2.2d, v0.2d, v1.2d
    // 0xb232d8: mov             v0.16b, v2.16b
    // 0xb232dc: LeaveFrame
    //     0xb232dc: mov             SP, fp
    //     0xb232e0: ldp             fp, lr, [SP], #0x10
    // 0xb232e4: ret
    //     0xb232e4: ret             
    // 0xb232e8: d0 = 0.000000
    //     0xb232e8: eor             v0.16b, v0.16b, v0.16b
    // 0xb232ec: LeaveFrame
    //     0xb232ec: mov             SP, fp
    //     0xb232f0: ldp             fp, lr, [SP], #0x10
    // 0xb232f4: ret
    //     0xb232f4: ret             
    // 0xb232f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb232f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb232fc: b               #0xb232ac
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0xb23300, size: 0x78
    // 0xb23300: EnterFrame
    //     0xb23300: stp             fp, lr, [SP, #-0x10]!
    //     0xb23304: mov             fp, SP
    // 0xb23308: ldr             x0, [fp, #0x18]
    // 0xb2330c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb2330c: ldur            w1, [x0, #0x17]
    // 0xb23310: DecompressPointer r1
    //     0xb23310: add             x1, x1, HEAP, lsl #32
    // 0xb23314: CheckStackOverflow
    //     0xb23314: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb23318: cmp             SP, x16
    //     0xb2331c: b.ls            #0xb23360
    // 0xb23320: ldr             x2, [fp, #0x10]
    // 0xb23324: r0 = computeMinIntrinsicHeight()
    //     0xb23324: bl              #0xb2328c  ; [package:flutter/src/material/button_style_button.dart] _RenderInputPadding::computeMinIntrinsicHeight
    // 0xb23328: r0 = inline_Allocate_Double()
    //     0xb23328: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2332c: add             x0, x0, #0x10
    //     0xb23330: cmp             x1, x0
    //     0xb23334: b.ls            #0xb23368
    //     0xb23338: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2333c: sub             x0, x0, #0xf
    //     0xb23340: mov             x1, #0xe19c
    //     0xb23344: movk            x1, #3, lsl #16
    //     0xb23348: stur            x1, [x0, #-1]
    // 0xb2334c: dmb             ishst
    // 0xb23350: StoreField: r0->field_7 = d0
    //     0xb23350: stur            d0, [x0, #7]
    // 0xb23354: LeaveFrame
    //     0xb23354: mov             SP, fp
    //     0xb23358: ldp             fp, lr, [SP], #0x10
    // 0xb2335c: ret
    //     0xb2335c: ret             
    // 0xb23360: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb23360: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb23364: b               #0xb23320
    // 0xb23368: SaveReg d0
    //     0xb23368: str             q0, [SP, #-0x10]!
    // 0xb2336c: r0 = AllocateDouble()
    //     0xb2336c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb23370: RestoreReg d0
    //     0xb23370: ldr             q0, [SP], #0x10
    // 0xb23374: b               #0xb23350
  }
  _ computeMaxIntrinsicHeight(/* No info */) {
    // ** addr: 0xb29eb8, size: 0x74
    // 0xb29eb8: EnterFrame
    //     0xb29eb8: stp             fp, lr, [SP, #-0x10]!
    //     0xb29ebc: mov             fp, SP
    // 0xb29ec0: AllocStack(0x8)
    //     0xb29ec0: sub             SP, SP, #8
    // 0xb29ec4: SetupParameters(_RenderInputPadding this /* r1 => r0, fp-0x8 */)
    //     0xb29ec4: mov             x0, x1
    //     0xb29ec8: stur            x1, [fp, #-8]
    // 0xb29ecc: CheckStackOverflow
    //     0xb29ecc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb29ed0: cmp             SP, x16
    //     0xb29ed4: b.ls            #0xb29f24
    // 0xb29ed8: LoadField: r1 = r0->field_4f
    //     0xb29ed8: ldur            w1, [x0, #0x4f]
    // 0xb29edc: DecompressPointer r1
    //     0xb29edc: add             x1, x1, HEAP, lsl #32
    // 0xb29ee0: cmp             w1, NULL
    // 0xb29ee4: b.eq            #0xb29f14
    // 0xb29ee8: LoadField: d0 = r2->field_7
    //     0xb29ee8: ldur            d0, [x2, #7]
    // 0xb29eec: r0 = getMaxIntrinsicHeight()
    //     0xb29eec: bl              #0xb16950  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicHeight
    // 0xb29ef0: ldur            x0, [fp, #-8]
    // 0xb29ef4: LoadField: r1 = r0->field_53
    //     0xb29ef4: ldur            w1, [x0, #0x53]
    // 0xb29ef8: DecompressPointer r1
    //     0xb29ef8: add             x1, x1, HEAP, lsl #32
    // 0xb29efc: LoadField: d1 = r1->field_f
    //     0xb29efc: ldur            d1, [x1, #0xf]
    // 0xb29f00: fmax            v2.2d, v0.2d, v1.2d
    // 0xb29f04: mov             v0.16b, v2.16b
    // 0xb29f08: LeaveFrame
    //     0xb29f08: mov             SP, fp
    //     0xb29f0c: ldp             fp, lr, [SP], #0x10
    // 0xb29f10: ret
    //     0xb29f10: ret             
    // 0xb29f14: d0 = 0.000000
    //     0xb29f14: eor             v0.16b, v0.16b, v0.16b
    // 0xb29f18: LeaveFrame
    //     0xb29f18: mov             SP, fp
    //     0xb29f1c: ldp             fp, lr, [SP], #0x10
    // 0xb29f20: ret
    //     0xb29f20: ret             
    // 0xb29f24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb29f24: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb29f28: b               #0xb29ed8
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0xb29f2c, size: 0x78
    // 0xb29f2c: EnterFrame
    //     0xb29f2c: stp             fp, lr, [SP, #-0x10]!
    //     0xb29f30: mov             fp, SP
    // 0xb29f34: ldr             x0, [fp, #0x18]
    // 0xb29f38: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb29f38: ldur            w1, [x0, #0x17]
    // 0xb29f3c: DecompressPointer r1
    //     0xb29f3c: add             x1, x1, HEAP, lsl #32
    // 0xb29f40: CheckStackOverflow
    //     0xb29f40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb29f44: cmp             SP, x16
    //     0xb29f48: b.ls            #0xb29f8c
    // 0xb29f4c: ldr             x2, [fp, #0x10]
    // 0xb29f50: r0 = computeMaxIntrinsicHeight()
    //     0xb29f50: bl              #0xb29eb8  ; [package:flutter/src/material/button_style_button.dart] _RenderInputPadding::computeMaxIntrinsicHeight
    // 0xb29f54: r0 = inline_Allocate_Double()
    //     0xb29f54: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb29f58: add             x0, x0, #0x10
    //     0xb29f5c: cmp             x1, x0
    //     0xb29f60: b.ls            #0xb29f94
    //     0xb29f64: str             x0, [THR, #0x60]  ; THR::top
    //     0xb29f68: sub             x0, x0, #0xf
    //     0xb29f6c: mov             x1, #0xe19c
    //     0xb29f70: movk            x1, #3, lsl #16
    //     0xb29f74: stur            x1, [x0, #-1]
    // 0xb29f78: dmb             ishst
    // 0xb29f7c: StoreField: r0->field_7 = d0
    //     0xb29f7c: stur            d0, [x0, #7]
    // 0xb29f80: LeaveFrame
    //     0xb29f80: mov             SP, fp
    //     0xb29f84: ldp             fp, lr, [SP], #0x10
    // 0xb29f88: ret
    //     0xb29f88: ret             
    // 0xb29f8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb29f8c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb29f90: b               #0xb29f4c
    // 0xb29f94: SaveReg d0
    //     0xb29f94: str             q0, [SP, #-0x10]!
    // 0xb29f98: r0 = AllocateDouble()
    //     0xb29f98: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb29f9c: RestoreReg d0
    //     0xb29f9c: ldr             q0, [SP], #0x10
    // 0xb29fa0: b               #0xb29f7c
  }
  _ computeMaxIntrinsicWidth(/* No info */) {
    // ** addr: 0xb2d2e4, size: 0x74
    // 0xb2d2e4: EnterFrame
    //     0xb2d2e4: stp             fp, lr, [SP, #-0x10]!
    //     0xb2d2e8: mov             fp, SP
    // 0xb2d2ec: AllocStack(0x8)
    //     0xb2d2ec: sub             SP, SP, #8
    // 0xb2d2f0: SetupParameters(_RenderInputPadding this /* r1 => r0, fp-0x8 */)
    //     0xb2d2f0: mov             x0, x1
    //     0xb2d2f4: stur            x1, [fp, #-8]
    // 0xb2d2f8: CheckStackOverflow
    //     0xb2d2f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2d2fc: cmp             SP, x16
    //     0xb2d300: b.ls            #0xb2d350
    // 0xb2d304: LoadField: r1 = r0->field_4f
    //     0xb2d304: ldur            w1, [x0, #0x4f]
    // 0xb2d308: DecompressPointer r1
    //     0xb2d308: add             x1, x1, HEAP, lsl #32
    // 0xb2d30c: cmp             w1, NULL
    // 0xb2d310: b.eq            #0xb2d340
    // 0xb2d314: LoadField: d0 = r2->field_7
    //     0xb2d314: ldur            d0, [x2, #7]
    // 0xb2d318: r0 = getMaxIntrinsicWidth()
    //     0xb2d318: bl              #0xb16750  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicWidth
    // 0xb2d31c: ldur            x0, [fp, #-8]
    // 0xb2d320: LoadField: r1 = r0->field_53
    //     0xb2d320: ldur            w1, [x0, #0x53]
    // 0xb2d324: DecompressPointer r1
    //     0xb2d324: add             x1, x1, HEAP, lsl #32
    // 0xb2d328: LoadField: d1 = r1->field_7
    //     0xb2d328: ldur            d1, [x1, #7]
    // 0xb2d32c: fmax            v2.2d, v0.2d, v1.2d
    // 0xb2d330: mov             v0.16b, v2.16b
    // 0xb2d334: LeaveFrame
    //     0xb2d334: mov             SP, fp
    //     0xb2d338: ldp             fp, lr, [SP], #0x10
    // 0xb2d33c: ret
    //     0xb2d33c: ret             
    // 0xb2d340: d0 = 0.000000
    //     0xb2d340: eor             v0.16b, v0.16b, v0.16b
    // 0xb2d344: LeaveFrame
    //     0xb2d344: mov             SP, fp
    //     0xb2d348: ldp             fp, lr, [SP], #0x10
    // 0xb2d34c: ret
    //     0xb2d34c: ret             
    // 0xb2d350: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2d350: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2d354: b               #0xb2d304
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb2d358, size: 0x78
    // 0xb2d358: EnterFrame
    //     0xb2d358: stp             fp, lr, [SP, #-0x10]!
    //     0xb2d35c: mov             fp, SP
    // 0xb2d360: ldr             x0, [fp, #0x18]
    // 0xb2d364: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb2d364: ldur            w1, [x0, #0x17]
    // 0xb2d368: DecompressPointer r1
    //     0xb2d368: add             x1, x1, HEAP, lsl #32
    // 0xb2d36c: CheckStackOverflow
    //     0xb2d36c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2d370: cmp             SP, x16
    //     0xb2d374: b.ls            #0xb2d3b8
    // 0xb2d378: ldr             x2, [fp, #0x10]
    // 0xb2d37c: r0 = computeMaxIntrinsicWidth()
    //     0xb2d37c: bl              #0xb2d2e4  ; [package:flutter/src/material/button_style_button.dart] _RenderInputPadding::computeMaxIntrinsicWidth
    // 0xb2d380: r0 = inline_Allocate_Double()
    //     0xb2d380: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2d384: add             x0, x0, #0x10
    //     0xb2d388: cmp             x1, x0
    //     0xb2d38c: b.ls            #0xb2d3c0
    //     0xb2d390: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2d394: sub             x0, x0, #0xf
    //     0xb2d398: mov             x1, #0xe19c
    //     0xb2d39c: movk            x1, #3, lsl #16
    //     0xb2d3a0: stur            x1, [x0, #-1]
    // 0xb2d3a4: dmb             ishst
    // 0xb2d3a8: StoreField: r0->field_7 = d0
    //     0xb2d3a8: stur            d0, [x0, #7]
    // 0xb2d3ac: LeaveFrame
    //     0xb2d3ac: mov             SP, fp
    //     0xb2d3b0: ldp             fp, lr, [SP], #0x10
    // 0xb2d3b4: ret
    //     0xb2d3b4: ret             
    // 0xb2d3b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2d3b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2d3bc: b               #0xb2d378
    // 0xb2d3c0: SaveReg d0
    //     0xb2d3c0: str             q0, [SP, #-0x10]!
    // 0xb2d3c4: r0 = AllocateDouble()
    //     0xb2d3c4: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2d3c8: RestoreReg d0
    //     0xb2d3c8: ldr             q0, [SP], #0x10
    // 0xb2d3cc: b               #0xb2d3a8
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xb4d8ac, size: 0x34
    // 0xb4d8ac: EnterFrame
    //     0xb4d8ac: stp             fp, lr, [SP, #-0x10]!
    //     0xb4d8b0: mov             fp, SP
    // 0xb4d8b4: CheckStackOverflow
    //     0xb4d8b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb4d8b8: cmp             SP, x16
    //     0xb4d8bc: b.ls            #0xb4d8d8
    // 0xb4d8c0: r3 = Closure: (RenderBox, BoxConstraints) => Size from Function 'dryLayoutChild': static.
    //     0xb4d8c0: add             x3, PP, #0x90, lsl #12  ; [pp+0x90700] Closure: (RenderBox, BoxConstraints) => Size from Function 'dryLayoutChild': static. (0x7f2adaa12214)
    //     0xb4d8c4: ldr             x3, [x3, #0x700]
    // 0xb4d8c8: r0 = _computeSize()
    //     0xb4d8c8: bl              #0xb4d7e8  ; [package:flutter/src/material/button.dart] _RenderInputPadding::_computeSize
    // 0xb4d8cc: LeaveFrame
    //     0xb4d8cc: mov             SP, fp
    //     0xb4d8d0: ldp             fp, lr, [SP], #0x10
    // 0xb4d8d4: ret
    //     0xb4d8d4: ret             
    // 0xb4d8d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb4d8d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb4d8dc: b               #0xb4d8c0
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0xb5839c, size: 0x24
    // 0xb5839c: EnterFrame
    //     0xb5839c: stp             fp, lr, [SP, #-0x10]!
    //     0xb583a0: mov             fp, SP
    // 0xb583a4: ldr             x2, [fp, #0x10]
    // 0xb583a8: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0xb583a8: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa4148] AnonymousClosure: (0xb2d358), in [package:flutter/src/material/button_style_button.dart] _RenderInputPadding::computeMaxIntrinsicWidth (0xb2d2e4)
    //     0xb583ac: ldr             x1, [x1, #0x148]
    // 0xb583b0: r0 = AllocateClosure()
    //     0xb583b0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb583b4: LeaveFrame
    //     0xb583b4: mov             SP, fp
    //     0xb583b8: ldp             fp, lr, [SP], #0x10
    // 0xb583bc: ret
    //     0xb583bc: ret             
  }
  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0xb5e524, size: 0x24
    // 0xb5e524: EnterFrame
    //     0xb5e524: stp             fp, lr, [SP, #-0x10]!
    //     0xb5e528: mov             fp, SP
    // 0xb5e52c: ldr             x2, [fp, #0x10]
    // 0xb5e530: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0xb5e530: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa4140] AnonymousClosure: (0xb29f2c), in [package:flutter/src/material/button_style_button.dart] _RenderInputPadding::computeMaxIntrinsicHeight (0xb29eb8)
    //     0xb5e534: ldr             x1, [x1, #0x140]
    // 0xb5e538: r0 = AllocateClosure()
    //     0xb5e538: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb5e53c: LeaveFrame
    //     0xb5e53c: mov             SP, fp
    //     0xb5e540: ldp             fp, lr, [SP], #0x10
    // 0xb5e544: ret
    //     0xb5e544: ret             
  }
  _ computeDryBaseline(/* No info */) {
    // ** addr: 0xb60d84, size: 0x150
    // 0xb60d84: EnterFrame
    //     0xb60d84: stp             fp, lr, [SP, #-0x10]!
    //     0xb60d88: mov             fp, SP
    // 0xb60d8c: AllocStack(0x20)
    //     0xb60d8c: sub             SP, SP, #0x20
    // 0xb60d90: SetupParameters(_RenderInputPadding this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xb60d90: mov             x5, x1
    //     0xb60d94: mov             x4, x2
    //     0xb60d98: stur            x1, [fp, #-8]
    //     0xb60d9c: stur            x2, [fp, #-0x10]
    //     0xb60da0: stur            x3, [fp, #-0x18]
    // 0xb60da4: CheckStackOverflow
    //     0xb60da4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb60da8: cmp             SP, x16
    //     0xb60dac: b.ls            #0xb60ebc
    // 0xb60db0: mov             x0, x4
    // 0xb60db4: r2 = Null
    //     0xb60db4: mov             x2, NULL
    // 0xb60db8: r1 = Null
    //     0xb60db8: mov             x1, NULL
    // 0xb60dbc: r4 = 60
    //     0xb60dbc: mov             x4, #0x3c
    // 0xb60dc0: branchIfSmi(r0, 0xb60dcc)
    //     0xb60dc0: tbz             w0, #0, #0xb60dcc
    // 0xb60dc4: r4 = LoadClassIdInstr(r0)
    //     0xb60dc4: ldur            x4, [x0, #-1]
    //     0xb60dc8: ubfx            x4, x4, #0xc, #0x14
    // 0xb60dcc: sub             x4, x4, #0xb46
    // 0xb60dd0: cmp             x4, #1
    // 0xb60dd4: b.ls            #0xb60de8
    // 0xb60dd8: r8 = BoxConstraints
    //     0xb60dd8: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xb60ddc: r3 = Null
    //     0xb60ddc: add             x3, PP, #0xa4, lsl #12  ; [pp+0xa4188] Null
    //     0xb60de0: ldr             x3, [x3, #0x188]
    // 0xb60de4: r0 = BoxConstraints()
    //     0xb60de4: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xb60de8: ldur            x0, [fp, #-8]
    // 0xb60dec: LoadField: r4 = r0->field_4f
    //     0xb60dec: ldur            w4, [x0, #0x4f]
    // 0xb60df0: DecompressPointer r4
    //     0xb60df0: add             x4, x4, HEAP, lsl #32
    // 0xb60df4: stur            x4, [fp, #-0x20]
    // 0xb60df8: cmp             w4, NULL
    // 0xb60dfc: b.ne            #0xb60e10
    // 0xb60e00: r0 = Null
    //     0xb60e00: mov             x0, NULL
    // 0xb60e04: LeaveFrame
    //     0xb60e04: mov             SP, fp
    //     0xb60e08: ldp             fp, lr, [SP], #0x10
    // 0xb60e0c: ret
    //     0xb60e0c: ret             
    // 0xb60e10: mov             x1, x4
    // 0xb60e14: ldur            x2, [fp, #-0x10]
    // 0xb60e18: ldur            x3, [fp, #-0x18]
    // 0xb60e1c: r0 = getDryBaseline()
    //     0xb60e1c: bl              #0xb19678  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryBaseline
    // 0xb60e20: stur            x0, [fp, #-0x18]
    // 0xb60e24: cmp             w0, NULL
    // 0xb60e28: b.ne            #0xb60e3c
    // 0xb60e2c: r0 = Null
    //     0xb60e2c: mov             x0, NULL
    // 0xb60e30: LeaveFrame
    //     0xb60e30: mov             SP, fp
    //     0xb60e34: ldp             fp, lr, [SP], #0x10
    // 0xb60e38: ret
    //     0xb60e38: ret             
    // 0xb60e3c: ldur            x1, [fp, #-0x20]
    // 0xb60e40: ldur            x2, [fp, #-0x10]
    // 0xb60e44: r0 = getDryLayout()
    //     0xb60e44: bl              #0xb20410  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xb60e48: ldur            x1, [fp, #-8]
    // 0xb60e4c: ldur            x2, [fp, #-0x10]
    // 0xb60e50: stur            x0, [fp, #-8]
    // 0xb60e54: r0 = getDryLayout()
    //     0xb60e54: bl              #0xb20410  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xb60e58: mov             x1, x0
    // 0xb60e5c: ldur            x2, [fp, #-8]
    // 0xb60e60: r0 = -()
    //     0xb60e60: bl              #0x81d2c0  ; [dart:ui] Size::-
    // 0xb60e64: mov             x2, x0
    // 0xb60e68: r1 = Instance_Alignment
    //     0xb60e68: add             x1, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xb60e6c: ldr             x1, [x1, #0xb80]
    // 0xb60e70: r0 = alongOffset()
    //     0xb60e70: bl              #0xb5f054  ; [package:flutter/src/painting/alignment.dart] Alignment::alongOffset
    // 0xb60e74: LoadField: d0 = r0->field_f
    //     0xb60e74: ldur            d0, [x0, #0xf]
    // 0xb60e78: ldur            x1, [fp, #-0x18]
    // 0xb60e7c: LoadField: d1 = r1->field_7
    //     0xb60e7c: ldur            d1, [x1, #7]
    // 0xb60e80: fadd            d2, d1, d0
    // 0xb60e84: r0 = inline_Allocate_Double()
    //     0xb60e84: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb60e88: add             x0, x0, #0x10
    //     0xb60e8c: cmp             x1, x0
    //     0xb60e90: b.ls            #0xb60ec4
    //     0xb60e94: str             x0, [THR, #0x60]  ; THR::top
    //     0xb60e98: sub             x0, x0, #0xf
    //     0xb60e9c: mov             x1, #0xe19c
    //     0xb60ea0: movk            x1, #3, lsl #16
    //     0xb60ea4: stur            x1, [x0, #-1]
    // 0xb60ea8: dmb             ishst
    // 0xb60eac: StoreField: r0->field_7 = d2
    //     0xb60eac: stur            d2, [x0, #7]
    // 0xb60eb0: LeaveFrame
    //     0xb60eb0: mov             SP, fp
    //     0xb60eb4: ldp             fp, lr, [SP], #0x10
    // 0xb60eb8: ret
    //     0xb60eb8: ret             
    // 0xb60ebc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb60ebc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb60ec0: b               #0xb60db0
    // 0xb60ec4: SaveReg d2
    //     0xb60ec4: str             q2, [SP, #-0x10]!
    // 0xb60ec8: r0 = AllocateDouble()
    //     0xb60ec8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb60ecc: RestoreReg d2
    //     0xb60ecc: ldr             q2, [SP], #0x10
    // 0xb60ed0: b               #0xb60eac
  }
  _ performLayout(/* No info */) {
    // ** addr: 0xbbca70, size: 0x194
    // 0xbbca70: EnterFrame
    //     0xbbca70: stp             fp, lr, [SP, #-0x10]!
    //     0xbbca74: mov             fp, SP
    // 0xbbca78: AllocStack(0x18)
    //     0xbbca78: sub             SP, SP, #0x18
    // 0xbbca7c: SetupParameters(_RenderInputPadding this /* r1 => r3, fp-0x10 */)
    //     0xbbca7c: mov             x3, x1
    //     0xbbca80: stur            x1, [fp, #-0x10]
    // 0xbbca84: CheckStackOverflow
    //     0xbbca84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbbca88: cmp             SP, x16
    //     0xbbca8c: b.ls            #0xbbcbf4
    // 0xbbca90: LoadField: r4 = r3->field_27
    //     0xbbca90: ldur            w4, [x3, #0x27]
    // 0xbbca94: DecompressPointer r4
    //     0xbbca94: add             x4, x4, HEAP, lsl #32
    // 0xbbca98: stur            x4, [fp, #-8]
    // 0xbbca9c: cmp             w4, NULL
    // 0xbbcaa0: b.eq            #0xbbcbd8
    // 0xbbcaa4: mov             x0, x4
    // 0xbbcaa8: r2 = Null
    //     0xbbcaa8: mov             x2, NULL
    // 0xbbcaac: r1 = Null
    //     0xbbcaac: mov             x1, NULL
    // 0xbbcab0: r4 = LoadClassIdInstr(r0)
    //     0xbbcab0: ldur            x4, [x0, #-1]
    //     0xbbcab4: ubfx            x4, x4, #0xc, #0x14
    // 0xbbcab8: sub             x4, x4, #0xb46
    // 0xbbcabc: cmp             x4, #1
    // 0xbbcac0: b.ls            #0xbbcad4
    // 0xbbcac4: r8 = BoxConstraints
    //     0xbbcac4: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbbcac8: r3 = Null
    //     0xbbcac8: add             x3, PP, #0xa4, lsl #12  ; [pp+0xa4168] Null
    //     0xbbcacc: ldr             x3, [x3, #0x168]
    // 0xbbcad0: r0 = BoxConstraints()
    //     0xbbcad0: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbbcad4: ldur            x1, [fp, #-0x10]
    // 0xbbcad8: ldur            x2, [fp, #-8]
    // 0xbbcadc: r3 = Closure: (RenderBox, BoxConstraints) => Size from Function 'layoutChild': static.
    //     0xbbcadc: add             x3, PP, #0x8e, lsl #12  ; [pp+0x8e4f8] Closure: (RenderBox, BoxConstraints) => Size from Function 'layoutChild': static. (0x7f2adaa34e18)
    //     0xbbcae0: ldr             x3, [x3, #0x4f8]
    // 0xbbcae4: r0 = _computeSize()
    //     0xbbcae4: bl              #0xb4d7e8  ; [package:flutter/src/material/button.dart] _RenderInputPadding::_computeSize
    // 0xbbcae8: ldur            x3, [fp, #-0x10]
    // 0xbbcaec: StoreField: r3->field_4b = r0
    //     0xbbcaec: stur            w0, [x3, #0x4b]
    //     0xbbcaf0: ldurb           w16, [x3, #-1]
    //     0xbbcaf4: ldurb           w17, [x0, #-1]
    //     0xbbcaf8: and             x16, x17, x16, lsr #2
    //     0xbbcafc: tst             x16, HEAP, lsr #32
    //     0xbbcb00: b.eq            #0xbbcb08
    //     0xbbcb04: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbbcb08: LoadField: r0 = r3->field_4f
    //     0xbbcb08: ldur            w0, [x3, #0x4f]
    // 0xbbcb0c: DecompressPointer r0
    //     0xbbcb0c: add             x0, x0, HEAP, lsl #32
    // 0xbbcb10: cmp             w0, NULL
    // 0xbbcb14: b.eq            #0xbbcbc8
    // 0xbbcb18: LoadField: r4 = r0->field_7
    //     0xbbcb18: ldur            w4, [x0, #7]
    // 0xbbcb1c: DecompressPointer r4
    //     0xbbcb1c: add             x4, x4, HEAP, lsl #32
    // 0xbbcb20: stur            x4, [fp, #-8]
    // 0xbbcb24: cmp             w4, NULL
    // 0xbbcb28: b.eq            #0xbbcbfc
    // 0xbbcb2c: mov             x0, x4
    // 0xbbcb30: r2 = Null
    //     0xbbcb30: mov             x2, NULL
    // 0xbbcb34: r1 = Null
    //     0xbbcb34: mov             x1, NULL
    // 0xbbcb38: r4 = LoadClassIdInstr(r0)
    //     0xbbcb38: ldur            x4, [x0, #-1]
    //     0xbbcb3c: ubfx            x4, x4, #0xc, #0x14
    // 0xbbcb40: r17 = -4190
    //     0xbbcb40: mov             x17, #-0x105e
    // 0xbbcb44: add             x4, x4, x17
    // 0xbbcb48: cmp             x4, #0x17
    // 0xbbcb4c: b.ls            #0xbbcb64
    // 0xbbcb50: r8 = BoxParentData
    //     0xbbcb50: add             x8, PP, #0x15, lsl #12  ; [pp+0x155e8] Type: BoxParentData
    //     0xbbcb54: ldr             x8, [x8, #0x5e8]
    // 0xbbcb58: r3 = Null
    //     0xbbcb58: add             x3, PP, #0xa4, lsl #12  ; [pp+0xa4178] Null
    //     0xbbcb5c: ldr             x3, [x3, #0x178]
    // 0xbbcb60: r0 = DefaultTypeTest()
    //     0xbbcb60: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbbcb64: ldur            x1, [fp, #-0x10]
    // 0xbbcb68: r0 = size()
    //     0xbbcb68: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbbcb6c: mov             x2, x0
    // 0xbbcb70: ldur            x0, [fp, #-0x10]
    // 0xbbcb74: stur            x2, [fp, #-0x18]
    // 0xbbcb78: LoadField: r1 = r0->field_4f
    //     0xbbcb78: ldur            w1, [x0, #0x4f]
    // 0xbbcb7c: DecompressPointer r1
    //     0xbbcb7c: add             x1, x1, HEAP, lsl #32
    // 0xbbcb80: cmp             w1, NULL
    // 0xbbcb84: b.eq            #0xbbcc00
    // 0xbbcb88: r0 = size()
    //     0xbbcb88: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbbcb8c: ldur            x1, [fp, #-0x18]
    // 0xbbcb90: mov             x2, x0
    // 0xbbcb94: r0 = -()
    //     0xbbcb94: bl              #0x81d2c0  ; [dart:ui] Size::-
    // 0xbbcb98: mov             x2, x0
    // 0xbbcb9c: r1 = Instance_Alignment
    //     0xbbcb9c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xbbcba0: ldr             x1, [x1, #0xb80]
    // 0xbbcba4: r0 = alongOffset()
    //     0xbbcba4: bl              #0xb5f054  ; [package:flutter/src/painting/alignment.dart] Alignment::alongOffset
    // 0xbbcba8: ldur            x1, [fp, #-8]
    // 0xbbcbac: StoreField: r1->field_7 = r0
    //     0xbbcbac: stur            w0, [x1, #7]
    //     0xbbcbb0: ldurb           w16, [x1, #-1]
    //     0xbbcbb4: ldurb           w17, [x0, #-1]
    //     0xbbcbb8: and             x16, x17, x16, lsr #2
    //     0xbbcbbc: tst             x16, HEAP, lsr #32
    //     0xbbcbc0: b.eq            #0xbbcbc8
    //     0xbbcbc4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbbcbc8: r0 = Null
    //     0xbbcbc8: mov             x0, NULL
    // 0xbbcbcc: LeaveFrame
    //     0xbbcbcc: mov             SP, fp
    //     0xbbcbd0: ldp             fp, lr, [SP], #0x10
    // 0xbbcbd4: ret
    //     0xbbcbd4: ret             
    // 0xbbcbd8: r0 = StateError()
    //     0xbbcbd8: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbbcbdc: mov             x1, x0
    // 0xbbcbe0: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbbcbe0: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbbcbe4: StoreField: r1->field_b = r0
    //     0xbbcbe4: stur            w0, [x1, #0xb]
    // 0xbbcbe8: mov             x0, x1
    // 0xbbcbec: r0 = Throw()
    //     0xbbcbec: bl              #0x13ddb2c  ; ThrowStub
    // 0xbbcbf0: brk             #0
    // 0xbbcbf4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbbcbf4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbbcbf8: b               #0xbbca90
    // 0xbbcbfc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbcbfc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbbcc00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbcc00: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x10efd30, size: 0x24
    // 0x10efd30: EnterFrame
    //     0x10efd30: stp             fp, lr, [SP, #-0x10]!
    //     0x10efd34: mov             fp, SP
    // 0x10efd38: ldr             x2, [fp, #0x10]
    // 0x10efd3c: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x10efd3c: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa4150] AnonymousClosure: (0xb23300), in [package:flutter/src/material/button_style_button.dart] _RenderInputPadding::computeMinIntrinsicHeight (0xb2328c)
    //     0x10efd40: ldr             x1, [x1, #0x150]
    // 0x10efd44: r0 = AllocateClosure()
    //     0x10efd44: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10efd48: LeaveFrame
    //     0x10efd48: mov             SP, fp
    //     0x10efd4c: ldp             fp, lr, [SP], #0x10
    // 0x10efd50: ret
    //     0x10efd50: ret             
  }
}

// class id: 5191, size: 0xc, field offset: 0x8
//   const constructor, 
class _MouseCursor extends WidgetStateMouseCursor {

  MouseCursor resolve(_MouseCursor, Set<WidgetState>) {
    // ** addr: 0x8de320, size: 0x50
    // 0x8de320: EnterFrame
    //     0x8de320: stp             fp, lr, [SP, #-0x10]!
    //     0x8de324: mov             fp, SP
    // 0x8de328: AllocStack(0x10)
    //     0x8de328: sub             SP, SP, #0x10
    // 0x8de32c: CheckStackOverflow
    //     0x8de32c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8de330: cmp             SP, x16
    //     0x8de334: b.ls            #0x8de364
    // 0x8de338: LoadField: r0 = r1->field_7
    //     0x8de338: ldur            w0, [x1, #7]
    // 0x8de33c: DecompressPointer r0
    //     0x8de33c: add             x0, x0, HEAP, lsl #32
    // 0x8de340: stp             x2, x0, [SP]
    // 0x8de344: ClosureCall
    //     0x8de344: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x8de348: ldur            x2, [x0, #0x1f]
    //     0x8de34c: blr             x2
    // 0x8de350: cmp             w0, NULL
    // 0x8de354: b.eq            #0x8de36c
    // 0x8de358: LeaveFrame
    //     0x8de358: mov             SP, fp
    //     0x8de35c: ldp             fp, lr, [SP], #0x10
    // 0x8de360: ret
    //     0x8de360: ret             
    // 0x8de364: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8de364: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8de368: b               #0x8de338
    // 0x8de36c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8de36c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  MouseCursor resolve(_MouseCursor, Set<WidgetState>) {
    // ** addr: 0x8de388, size: 0x6c
    // 0x8de388: EnterFrame
    //     0x8de388: stp             fp, lr, [SP, #-0x10]!
    //     0x8de38c: mov             fp, SP
    // 0x8de390: CheckStackOverflow
    //     0x8de390: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8de394: cmp             SP, x16
    //     0x8de398: b.ls            #0x8de3d4
    // 0x8de39c: ldr             x0, [fp, #0x10]
    // 0x8de3a0: r2 = Null
    //     0x8de3a0: mov             x2, NULL
    // 0x8de3a4: r1 = Null
    //     0x8de3a4: mov             x1, NULL
    // 0x8de3a8: r8 = Set<WidgetState>
    //     0x8de3a8: add             x8, PP, #0x85, lsl #12  ; [pp+0x85200] Type: Set<WidgetState>
    //     0x8de3ac: ldr             x8, [x8, #0x200]
    // 0x8de3b0: r3 = Null
    //     0x8de3b0: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a130] Null
    //     0x8de3b4: ldr             x3, [x3, #0x130]
    // 0x8de3b8: r0 = Set<WidgetState>()
    //     0x8de3b8: bl              #0x8de430  ; IsType_Set<WidgetState>_Stub
    // 0x8de3bc: ldr             x1, [fp, #0x18]
    // 0x8de3c0: ldr             x2, [fp, #0x10]
    // 0x8de3c4: r0 = resolve()
    //     0x8de3c4: bl              #0x8de320  ; [package:flutter/src/material/button_style_button.dart] _MouseCursor::resolve
    // 0x8de3c8: LeaveFrame
    //     0x8de3c8: mov             SP, fp
    //     0x8de3cc: ldp             fp, lr, [SP], #0x10
    // 0x8de3d0: ret
    //     0x8de3d0: ret             
    // 0x8de3d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8de3d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8de3d8: b               #0x8de39c
  }
}

// class id: 5776, size: 0x2c, field offset: 0x1c
class _ButtonStyleState extends _MixinApplication17&State&TickerProviderStateMixin {

  _ build(/* No info */) {
    // ** addr: 0xd0ce1c, size: 0x1084
    // 0xd0ce1c: EnterFrame
    //     0xd0ce1c: stp             fp, lr, [SP, #-0x10]!
    //     0xd0ce20: mov             fp, SP
    // 0xd0ce24: AllocStack(0x128)
    //     0xd0ce24: sub             SP, SP, #0x128
    // 0xd0ce28: SetupParameters(_ButtonStyleState this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xd0ce28: stur            x1, [fp, #-8]
    //     0xd0ce2c: mov             x16, x2
    //     0xd0ce30: mov             x2, x1
    //     0xd0ce34: mov             x1, x16
    //     0xd0ce38: stur            x1, [fp, #-0x10]
    // 0xd0ce3c: CheckStackOverflow
    //     0xd0ce3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0ce40: cmp             SP, x16
    //     0xd0ce44: b.ls            #0xd0de14
    // 0xd0ce48: r1 = 5
    //     0xd0ce48: mov             x1, #5
    // 0xd0ce4c: r0 = AllocateContext()
    //     0xd0ce4c: bl              #0x13de838  ; AllocateContextStub
    // 0xd0ce50: ldur            x2, [fp, #-8]
    // 0xd0ce54: stur            x0, [fp, #-0x18]
    // 0xd0ce58: StoreField: r0->field_f = r2
    //     0xd0ce58: stur            w2, [x0, #0xf]
    // 0xd0ce5c: ldur            x1, [fp, #-0x10]
    // 0xd0ce60: r0 = of()
    //     0xd0ce60: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd0ce64: ldur            x1, [fp, #-0x10]
    // 0xd0ce68: stur            x0, [fp, #-0x20]
    // 0xd0ce6c: r0 = of()
    //     0xd0ce6c: bl              #0xd0e004  ; [package:flutter/src/widgets/icon_theme.dart] IconTheme::of
    // 0xd0ce70: mov             x4, x0
    // 0xd0ce74: ldur            x3, [fp, #-8]
    // 0xd0ce78: stur            x4, [fp, #-0x28]
    // 0xd0ce7c: LoadField: r1 = r3->field_b
    //     0xd0ce7c: ldur            w1, [x3, #0xb]
    // 0xd0ce80: DecompressPointer r1
    //     0xd0ce80: add             x1, x1, HEAP, lsl #32
    // 0xd0ce84: cmp             w1, NULL
    // 0xd0ce88: b.eq            #0xd0de1c
    // 0xd0ce8c: LoadField: r0 = r1->field_1b
    //     0xd0ce8c: ldur            w0, [x1, #0x1b]
    // 0xd0ce90: DecompressPointer r0
    //     0xd0ce90: add             x0, x0, HEAP, lsl #32
    // 0xd0ce94: ldur            x5, [fp, #-0x18]
    // 0xd0ce98: StoreField: r5->field_13 = r0
    //     0xd0ce98: stur            w0, [x5, #0x13]
    //     0xd0ce9c: ldurb           w16, [x5, #-1]
    //     0xd0cea0: ldurb           w17, [x0, #-1]
    //     0xd0cea4: and             x16, x17, x16, lsr #2
    //     0xd0cea8: tst             x16, HEAP, lsr #32
    //     0xd0ceac: b.eq            #0xd0ceb4
    //     0xd0ceb0: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0xd0ceb4: r0 = LoadClassIdInstr(r1)
    //     0xd0ceb4: ldur            x0, [x1, #-1]
    //     0xd0ceb8: ubfx            x0, x0, #0xc, #0x14
    // 0xd0cebc: ldur            x2, [fp, #-0x10]
    // 0xd0cec0: r0 = GDT[cid_x0 + 0xd56]()
    //     0xd0cec0: add             lr, x0, #0xd56
    //     0xd0cec4: ldr             lr, [x21, lr, lsl #3]
    //     0xd0cec8: blr             lr
    // 0xd0cecc: ldur            x3, [fp, #-0x18]
    // 0xd0ced0: ArrayStore: r3[0] = r0  ; List_4
    //     0xd0ced0: stur            w0, [x3, #0x17]
    //     0xd0ced4: ldurb           w16, [x3, #-1]
    //     0xd0ced8: ldurb           w17, [x0, #-1]
    //     0xd0cedc: and             x16, x17, x16, lsr #2
    //     0xd0cee0: tst             x16, HEAP, lsr #32
    //     0xd0cee4: b.eq            #0xd0ceec
    //     0xd0cee8: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xd0ceec: ldur            x4, [fp, #-8]
    // 0xd0cef0: LoadField: r1 = r4->field_b
    //     0xd0cef0: ldur            w1, [x4, #0xb]
    // 0xd0cef4: DecompressPointer r1
    //     0xd0cef4: add             x1, x1, HEAP, lsl #32
    // 0xd0cef8: cmp             w1, NULL
    // 0xd0cefc: b.eq            #0xd0de20
    // 0xd0cf00: r0 = LoadClassIdInstr(r1)
    //     0xd0cf00: ldur            x0, [x1, #-1]
    //     0xd0cf04: ubfx            x0, x0, #0xc, #0x14
    // 0xd0cf08: ldur            x2, [fp, #-0x10]
    // 0xd0cf0c: r0 = GDT[cid_x0 + 0xd5a]()
    //     0xd0cf0c: add             lr, x0, #0xd5a
    //     0xd0cf10: ldr             lr, [x21, lr, lsl #3]
    //     0xd0cf14: blr             lr
    // 0xd0cf18: ldur            x3, [fp, #-0x18]
    // 0xd0cf1c: StoreField: r3->field_1b = r0
    //     0xd0cf1c: stur            w0, [x3, #0x1b]
    //     0xd0cf20: ldurb           w16, [x3, #-1]
    //     0xd0cf24: ldurb           w17, [x0, #-1]
    //     0xd0cf28: and             x16, x17, x16, lsr #2
    //     0xd0cf2c: tst             x16, HEAP, lsr #32
    //     0xd0cf30: b.eq            #0xd0cf38
    //     0xd0cf34: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xd0cf38: mov             x2, x3
    // 0xd0cf3c: r1 = Function 'effectiveValue':.
    //     0xd0cf3c: add             x1, PP, #0x90, lsl #12  ; [pp+0x90518] AnonymousClosure: (0xd0f3ec), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0xd0ce1c)
    //     0xd0cf40: ldr             x1, [x1, #0x518]
    // 0xd0cf44: r0 = AllocateClosureGeneric()
    //     0xd0cf44: bl              #0x13deb28  ; AllocateClosureGenericStub
    // 0xd0cf48: mov             x4, x0
    // 0xd0cf4c: ldur            x3, [fp, #-0x18]
    // 0xd0cf50: stur            x4, [fp, #-0x10]
    // 0xd0cf54: StoreField: r3->field_1f = r0
    //     0xd0cf54: stur            w0, [x3, #0x1f]
    //     0xd0cf58: ldurb           w16, [x3, #-1]
    //     0xd0cf5c: ldurb           w17, [x0, #-1]
    //     0xd0cf60: and             x16, x17, x16, lsr #2
    //     0xd0cf64: tst             x16, HEAP, lsr #32
    //     0xd0cf68: b.eq            #0xd0cf70
    //     0xd0cf6c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xd0cf70: mov             x2, x3
    // 0xd0cf74: r1 = Function 'resolve':.
    //     0xd0cf74: add             x1, PP, #0x90, lsl #12  ; [pp+0x90520] AnonymousClosure: (0xd0f220), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0xd0ce1c)
    //     0xd0cf78: ldr             x1, [x1, #0x520]
    // 0xd0cf7c: r0 = AllocateClosureGeneric()
    //     0xd0cf7c: bl              #0x13deb28  ; AllocateClosureGenericStub
    // 0xd0cf80: ldur            x2, [fp, #-0x18]
    // 0xd0cf84: r1 = Function 'effectiveIconColor':.
    //     0xd0cf84: add             x1, PP, #0x90, lsl #12  ; [pp+0x90528] AnonymousClosure: (0xd0edc8), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0xd0ce1c)
    //     0xd0cf88: ldr             x1, [x1, #0x528]
    // 0xd0cf8c: stur            x0, [fp, #-0x30]
    // 0xd0cf90: r0 = AllocateClosure()
    //     0xd0cf90: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd0cf94: r1 = Function '<anonymous closure>':.
    //     0xd0cf94: add             x1, PP, #0x90, lsl #12  ; [pp+0x90530] AnonymousClosure: (0xd0ed78), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0xd0ce1c)
    //     0xd0cf98: ldr             x1, [x1, #0x530]
    // 0xd0cf9c: r2 = Null
    //     0xd0cf9c: mov             x2, NULL
    // 0xd0cfa0: stur            x0, [fp, #-0x38]
    // 0xd0cfa4: r0 = AllocateClosure()
    //     0xd0cfa4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd0cfa8: r16 = <double?>
    //     0xd0cfa8: add             x16, PP, #0x7a, lsl #12  ; [pp+0x7aba8] TypeArguments: <double?>
    //     0xd0cfac: ldr             x16, [x16, #0xba8]
    // 0xd0cfb0: ldur            lr, [fp, #-0x30]
    // 0xd0cfb4: stp             lr, x16, [SP, #8]
    // 0xd0cfb8: str             x0, [SP]
    // 0xd0cfbc: ldur            x0, [fp, #-0x30]
    // 0xd0cfc0: ClosureCall
    //     0xd0cfc0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0xd0cfc4: ldur            x2, [x0, #0x1f]
    //     0xd0cfc8: blr             x2
    // 0xd0cfcc: r1 = Function '<anonymous closure>':.
    //     0xd0cfcc: add             x1, PP, #0x90, lsl #12  ; [pp+0x90538] AnonymousClosure: (0xd0ed28), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0xd0ce1c)
    //     0xd0cfd0: ldr             x1, [x1, #0x538]
    // 0xd0cfd4: r2 = Null
    //     0xd0cfd4: mov             x2, NULL
    // 0xd0cfd8: stur            x0, [fp, #-0x40]
    // 0xd0cfdc: r0 = AllocateClosure()
    //     0xd0cfdc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd0cfe0: r16 = <TextStyle?>
    //     0xd0cfe0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a88] TypeArguments: <TextStyle?>
    //     0xd0cfe4: ldr             x16, [x16, #0xa88]
    // 0xd0cfe8: ldur            lr, [fp, #-0x30]
    // 0xd0cfec: stp             lr, x16, [SP, #8]
    // 0xd0cff0: str             x0, [SP]
    // 0xd0cff4: ldur            x0, [fp, #-0x30]
    // 0xd0cff8: ClosureCall
    //     0xd0cff8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0xd0cffc: ldur            x2, [x0, #0x1f]
    //     0xd0d000: blr             x2
    // 0xd0d004: r1 = Function '<anonymous closure>':.
    //     0xd0d004: add             x1, PP, #0x90, lsl #12  ; [pp+0x90540] AnonymousClosure: (0xd0ecd8), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0xd0ce1c)
    //     0xd0d008: ldr             x1, [x1, #0x540]
    // 0xd0d00c: r2 = Null
    //     0xd0d00c: mov             x2, NULL
    // 0xd0d010: stur            x0, [fp, #-0x48]
    // 0xd0d014: r0 = AllocateClosure()
    //     0xd0d014: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd0d018: r16 = <Color?>
    //     0xd0d018: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xd0d01c: ldr             x16, [x16, #0xa40]
    // 0xd0d020: ldur            lr, [fp, #-0x30]
    // 0xd0d024: stp             lr, x16, [SP, #8]
    // 0xd0d028: str             x0, [SP]
    // 0xd0d02c: ldur            x0, [fp, #-0x30]
    // 0xd0d030: ClosureCall
    //     0xd0d030: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0xd0d034: ldur            x2, [x0, #0x1f]
    //     0xd0d038: blr             x2
    // 0xd0d03c: r1 = Function '<anonymous closure>':.
    //     0xd0d03c: add             x1, PP, #0x90, lsl #12  ; [pp+0x90548] AnonymousClosure: (0xd0ec88), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0xd0ce1c)
    //     0xd0d040: ldr             x1, [x1, #0x548]
    // 0xd0d044: r2 = Null
    //     0xd0d044: mov             x2, NULL
    // 0xd0d048: stur            x0, [fp, #-0x50]
    // 0xd0d04c: r0 = AllocateClosure()
    //     0xd0d04c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd0d050: r16 = <Color?>
    //     0xd0d050: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xd0d054: ldr             x16, [x16, #0xa40]
    // 0xd0d058: ldur            lr, [fp, #-0x30]
    // 0xd0d05c: stp             lr, x16, [SP, #8]
    // 0xd0d060: str             x0, [SP]
    // 0xd0d064: ldur            x0, [fp, #-0x30]
    // 0xd0d068: ClosureCall
    //     0xd0d068: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0xd0d06c: ldur            x2, [x0, #0x1f]
    //     0xd0d070: blr             x2
    // 0xd0d074: r1 = Function '<anonymous closure>':.
    //     0xd0d074: add             x1, PP, #0x90, lsl #12  ; [pp+0x90550] AnonymousClosure: (0xd0ec38), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0xd0ce1c)
    //     0xd0d078: ldr             x1, [x1, #0x550]
    // 0xd0d07c: r2 = Null
    //     0xd0d07c: mov             x2, NULL
    // 0xd0d080: stur            x0, [fp, #-0x58]
    // 0xd0d084: r0 = AllocateClosure()
    //     0xd0d084: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd0d088: r16 = <Color?>
    //     0xd0d088: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xd0d08c: ldr             x16, [x16, #0xa40]
    // 0xd0d090: ldur            lr, [fp, #-0x30]
    // 0xd0d094: stp             lr, x16, [SP, #8]
    // 0xd0d098: str             x0, [SP]
    // 0xd0d09c: ldur            x0, [fp, #-0x30]
    // 0xd0d0a0: ClosureCall
    //     0xd0d0a0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0xd0d0a4: ldur            x2, [x0, #0x1f]
    //     0xd0d0a8: blr             x2
    // 0xd0d0ac: r1 = Function '<anonymous closure>':.
    //     0xd0d0ac: add             x1, PP, #0x90, lsl #12  ; [pp+0x90558] AnonymousClosure: (0xd0ebe4), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0xd0ce1c)
    //     0xd0d0b0: ldr             x1, [x1, #0x558]
    // 0xd0d0b4: r2 = Null
    //     0xd0d0b4: mov             x2, NULL
    // 0xd0d0b8: stur            x0, [fp, #-0x60]
    // 0xd0d0bc: r0 = AllocateClosure()
    //     0xd0d0bc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd0d0c0: r16 = <Color?>
    //     0xd0d0c0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xd0d0c4: ldr             x16, [x16, #0xa40]
    // 0xd0d0c8: ldur            lr, [fp, #-0x30]
    // 0xd0d0cc: stp             lr, x16, [SP, #8]
    // 0xd0d0d0: str             x0, [SP]
    // 0xd0d0d4: ldur            x0, [fp, #-0x30]
    // 0xd0d0d8: ClosureCall
    //     0xd0d0d8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0xd0d0dc: ldur            x2, [x0, #0x1f]
    //     0xd0d0e0: blr             x2
    // 0xd0d0e4: r1 = Function '<anonymous closure>':.
    //     0xd0d0e4: add             x1, PP, #0x90, lsl #12  ; [pp+0x90560] AnonymousClosure: (0xd0eb90), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0xd0ce1c)
    //     0xd0d0e8: ldr             x1, [x1, #0x560]
    // 0xd0d0ec: r2 = Null
    //     0xd0d0ec: mov             x2, NULL
    // 0xd0d0f0: stur            x0, [fp, #-0x68]
    // 0xd0d0f4: r0 = AllocateClosure()
    //     0xd0d0f4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd0d0f8: r16 = <EdgeInsetsGeometry?>
    //     0xd0d0f8: add             x16, PP, #0x7d, lsl #12  ; [pp+0x7d4a0] TypeArguments: <EdgeInsetsGeometry?>
    //     0xd0d0fc: ldr             x16, [x16, #0x4a0]
    // 0xd0d100: ldur            lr, [fp, #-0x30]
    // 0xd0d104: stp             lr, x16, [SP, #8]
    // 0xd0d108: str             x0, [SP]
    // 0xd0d10c: ldur            x0, [fp, #-0x30]
    // 0xd0d110: ClosureCall
    //     0xd0d110: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0xd0d114: ldur            x2, [x0, #0x1f]
    //     0xd0d118: blr             x2
    // 0xd0d11c: r1 = Function '<anonymous closure>':.
    //     0xd0d11c: add             x1, PP, #0x90, lsl #12  ; [pp+0x90568] AnonymousClosure: (0xd0eb3c), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0xd0ce1c)
    //     0xd0d120: ldr             x1, [x1, #0x568]
    // 0xd0d124: r2 = Null
    //     0xd0d124: mov             x2, NULL
    // 0xd0d128: stur            x0, [fp, #-0x70]
    // 0xd0d12c: r0 = AllocateClosure()
    //     0xd0d12c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd0d130: r16 = <Size?>
    //     0xd0d130: add             x16, PP, #0x26, lsl #12  ; [pp+0x26aa8] TypeArguments: <Size?>
    //     0xd0d134: ldr             x16, [x16, #0xaa8]
    // 0xd0d138: ldur            lr, [fp, #-0x30]
    // 0xd0d13c: stp             lr, x16, [SP, #8]
    // 0xd0d140: str             x0, [SP]
    // 0xd0d144: ldur            x0, [fp, #-0x30]
    // 0xd0d148: ClosureCall
    //     0xd0d148: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0xd0d14c: ldur            x2, [x0, #0x1f]
    //     0xd0d150: blr             x2
    // 0xd0d154: r1 = Function '<anonymous closure>':.
    //     0xd0d154: add             x1, PP, #0x90, lsl #12  ; [pp+0x90570] AnonymousClosure: (0xd0eb18), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0xd0ce1c)
    //     0xd0d158: ldr             x1, [x1, #0x570]
    // 0xd0d15c: r2 = Null
    //     0xd0d15c: mov             x2, NULL
    // 0xd0d160: stur            x0, [fp, #-0x78]
    // 0xd0d164: r0 = AllocateClosure()
    //     0xd0d164: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd0d168: r16 = <Size?>
    //     0xd0d168: add             x16, PP, #0x26, lsl #12  ; [pp+0x26aa8] TypeArguments: <Size?>
    //     0xd0d16c: ldr             x16, [x16, #0xaa8]
    // 0xd0d170: ldur            lr, [fp, #-0x30]
    // 0xd0d174: stp             lr, x16, [SP, #8]
    // 0xd0d178: str             x0, [SP]
    // 0xd0d17c: ldur            x0, [fp, #-0x30]
    // 0xd0d180: ClosureCall
    //     0xd0d180: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0xd0d184: ldur            x2, [x0, #0x1f]
    //     0xd0d188: blr             x2
    // 0xd0d18c: r1 = Function '<anonymous closure>':.
    //     0xd0d18c: add             x1, PP, #0x90, lsl #12  ; [pp+0x90578] AnonymousClosure: (0xd0eac4), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0xd0ce1c)
    //     0xd0d190: ldr             x1, [x1, #0x578]
    // 0xd0d194: r2 = Null
    //     0xd0d194: mov             x2, NULL
    // 0xd0d198: stur            x0, [fp, #-0x80]
    // 0xd0d19c: r0 = AllocateClosure()
    //     0xd0d19c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd0d1a0: r16 = <Size?>
    //     0xd0d1a0: add             x16, PP, #0x26, lsl #12  ; [pp+0x26aa8] TypeArguments: <Size?>
    //     0xd0d1a4: ldr             x16, [x16, #0xaa8]
    // 0xd0d1a8: ldur            lr, [fp, #-0x30]
    // 0xd0d1ac: stp             lr, x16, [SP, #8]
    // 0xd0d1b0: str             x0, [SP]
    // 0xd0d1b4: ldur            x0, [fp, #-0x30]
    // 0xd0d1b8: ClosureCall
    //     0xd0d1b8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0xd0d1bc: ldur            x2, [x0, #0x1f]
    //     0xd0d1c0: blr             x2
    // 0xd0d1c4: mov             x1, x0
    // 0xd0d1c8: stur            x1, [fp, #-0x88]
    // 0xd0d1cc: ldur            x16, [fp, #-0x38]
    // 0xd0d1d0: str             x16, [SP]
    // 0xd0d1d4: ldur            x0, [fp, #-0x38]
    // 0xd0d1d8: ClosureCall
    //     0xd0d1d8: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xd0d1dc: ldur            x2, [x0, #0x1f]
    //     0xd0d1e0: blr             x2
    // 0xd0d1e4: r1 = Function '<anonymous closure>':.
    //     0xd0d1e4: add             x1, PP, #0x90, lsl #12  ; [pp+0x90580] AnonymousClosure: (0xd0ea70), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0xd0ce1c)
    //     0xd0d1e8: ldr             x1, [x1, #0x580]
    // 0xd0d1ec: r2 = Null
    //     0xd0d1ec: mov             x2, NULL
    // 0xd0d1f0: stur            x0, [fp, #-0x38]
    // 0xd0d1f4: r0 = AllocateClosure()
    //     0xd0d1f4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd0d1f8: r16 = <double?>
    //     0xd0d1f8: add             x16, PP, #0x7a, lsl #12  ; [pp+0x7aba8] TypeArguments: <double?>
    //     0xd0d1fc: ldr             x16, [x16, #0xba8]
    // 0xd0d200: ldur            lr, [fp, #-0x30]
    // 0xd0d204: stp             lr, x16, [SP, #8]
    // 0xd0d208: str             x0, [SP]
    // 0xd0d20c: ldur            x0, [fp, #-0x30]
    // 0xd0d210: ClosureCall
    //     0xd0d210: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0xd0d214: ldur            x2, [x0, #0x1f]
    //     0xd0d218: blr             x2
    // 0xd0d21c: r1 = Function '<anonymous closure>':.
    //     0xd0d21c: add             x1, PP, #0x90, lsl #12  ; [pp+0x90588] AnonymousClosure: (0xd0ea1c), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0xd0ce1c)
    //     0xd0d220: ldr             x1, [x1, #0x588]
    // 0xd0d224: r2 = Null
    //     0xd0d224: mov             x2, NULL
    // 0xd0d228: stur            x0, [fp, #-0x90]
    // 0xd0d22c: r0 = AllocateClosure()
    //     0xd0d22c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd0d230: r16 = <BorderSide?>
    //     0xd0d230: add             x16, PP, #0x7d, lsl #12  ; [pp+0x7d4b0] TypeArguments: <BorderSide?>
    //     0xd0d234: ldr             x16, [x16, #0x4b0]
    // 0xd0d238: ldur            lr, [fp, #-0x30]
    // 0xd0d23c: stp             lr, x16, [SP, #8]
    // 0xd0d240: str             x0, [SP]
    // 0xd0d244: ldur            x0, [fp, #-0x30]
    // 0xd0d248: ClosureCall
    //     0xd0d248: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0xd0d24c: ldur            x2, [x0, #0x1f]
    //     0xd0d250: blr             x2
    // 0xd0d254: r1 = Function '<anonymous closure>':.
    //     0xd0d254: add             x1, PP, #0x90, lsl #12  ; [pp+0x90590] AnonymousClosure: (0xd0e9cc), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0xd0ce1c)
    //     0xd0d258: ldr             x1, [x1, #0x590]
    // 0xd0d25c: r2 = Null
    //     0xd0d25c: mov             x2, NULL
    // 0xd0d260: stur            x0, [fp, #-0x98]
    // 0xd0d264: r0 = AllocateClosure()
    //     0xd0d264: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd0d268: r16 = <OutlinedBorder?>
    //     0xd0d268: add             x16, PP, #0x7d, lsl #12  ; [pp+0x7d4a8] TypeArguments: <OutlinedBorder?>
    //     0xd0d26c: ldr             x16, [x16, #0x4a8]
    // 0xd0d270: ldur            lr, [fp, #-0x30]
    // 0xd0d274: stp             lr, x16, [SP, #8]
    // 0xd0d278: str             x0, [SP]
    // 0xd0d27c: ldur            x0, [fp, #-0x30]
    // 0xd0d280: ClosureCall
    //     0xd0d280: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0xd0d284: ldur            x2, [x0, #0x1f]
    //     0xd0d288: blr             x2
    // 0xd0d28c: stur            x0, [fp, #-0x30]
    // 0xd0d290: r0 = _MouseCursor()
    //     0xd0d290: bl              #0xd0dff8  ; Allocate_MouseCursorStub -> _MouseCursor (size=0xc)
    // 0xd0d294: ldur            x2, [fp, #-0x18]
    // 0xd0d298: r1 = Function '<anonymous closure>':.
    //     0xd0d298: add             x1, PP, #0x90, lsl #12  ; [pp+0x90598] AnonymousClosure: (0xd0e888), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0xd0ce1c)
    //     0xd0d29c: ldr             x1, [x1, #0x598]
    // 0xd0d2a0: stur            x0, [fp, #-0xa0]
    // 0xd0d2a4: r0 = AllocateClosure()
    //     0xd0d2a4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd0d2a8: mov             x1, x0
    // 0xd0d2ac: ldur            x0, [fp, #-0xa0]
    // 0xd0d2b0: StoreField: r0->field_7 = r1
    //     0xd0d2b0: stur            w1, [x0, #7]
    // 0xd0d2b4: ldur            x2, [fp, #-0x18]
    // 0xd0d2b8: r1 = Function '<anonymous closure>':.
    //     0xd0d2b8: add             x1, PP, #0x90, lsl #12  ; [pp+0x905a0] AnonymousClosure: (0xd0e740), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0xd0ce1c)
    //     0xd0d2bc: ldr             x1, [x1, #0x5a0]
    // 0xd0d2c0: r0 = AllocateClosure()
    //     0xd0d2c0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd0d2c4: r16 = <Color?>
    //     0xd0d2c4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xd0d2c8: ldr             x16, [x16, #0xa40]
    // 0xd0d2cc: stp             x0, x16, [SP]
    // 0xd0d2d0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd0d2d0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd0d2d4: r0 = resolveWith()
    //     0xd0d2d4: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd0d2d8: r1 = Function '<anonymous closure>':.
    //     0xd0d2d8: add             x1, PP, #0x90, lsl #12  ; [pp+0x905a8] AnonymousClosure: (0xd0e6f0), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0xd0ce1c)
    //     0xd0d2dc: ldr             x1, [x1, #0x5a8]
    // 0xd0d2e0: r2 = Null
    //     0xd0d2e0: mov             x2, NULL
    // 0xd0d2e4: stur            x0, [fp, #-0xa8]
    // 0xd0d2e8: r0 = AllocateClosure()
    //     0xd0d2e8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd0d2ec: r16 = <VisualDensity>
    //     0xd0d2ec: add             x16, PP, #0x90, lsl #12  ; [pp+0x905b0] TypeArguments: <VisualDensity>
    //     0xd0d2f0: ldr             x16, [x16, #0x5b0]
    // 0xd0d2f4: ldur            lr, [fp, #-0x10]
    // 0xd0d2f8: stp             lr, x16, [SP, #8]
    // 0xd0d2fc: str             x0, [SP]
    // 0xd0d300: ldur            x0, [fp, #-0x10]
    // 0xd0d304: ClosureCall
    //     0xd0d304: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0xd0d308: ldur            x2, [x0, #0x1f]
    //     0xd0d30c: blr             x2
    // 0xd0d310: r1 = Function '<anonymous closure>':.
    //     0xd0d310: add             x1, PP, #0x90, lsl #12  ; [pp+0x905b8] AnonymousClosure: (0xd0e6a0), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0xd0ce1c)
    //     0xd0d314: ldr             x1, [x1, #0x5b8]
    // 0xd0d318: r2 = Null
    //     0xd0d318: mov             x2, NULL
    // 0xd0d31c: stur            x0, [fp, #-0xb0]
    // 0xd0d320: r0 = AllocateClosure()
    //     0xd0d320: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd0d324: r16 = <MaterialTapTargetSize>
    //     0xd0d324: add             x16, PP, #0x90, lsl #12  ; [pp+0x905c0] TypeArguments: <MaterialTapTargetSize>
    //     0xd0d328: ldr             x16, [x16, #0x5c0]
    // 0xd0d32c: ldur            lr, [fp, #-0x10]
    // 0xd0d330: stp             lr, x16, [SP, #8]
    // 0xd0d334: str             x0, [SP]
    // 0xd0d338: ldur            x0, [fp, #-0x10]
    // 0xd0d33c: ClosureCall
    //     0xd0d33c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0xd0d340: ldur            x2, [x0, #0x1f]
    //     0xd0d344: blr             x2
    // 0xd0d348: r1 = Function '<anonymous closure>':.
    //     0xd0d348: add             x1, PP, #0x90, lsl #12  ; [pp+0x905c8] AnonymousClosure: (0xd0e67c), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0xd0ce1c)
    //     0xd0d34c: ldr             x1, [x1, #0x5c8]
    // 0xd0d350: r2 = Null
    //     0xd0d350: mov             x2, NULL
    // 0xd0d354: stur            x0, [fp, #-0xb8]
    // 0xd0d358: r0 = AllocateClosure()
    //     0xd0d358: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd0d35c: r16 = <Duration>
    //     0xd0d35c: ldr             x16, [PP, #0x6b78]  ; [pp+0x6b78] TypeArguments: <Duration>
    // 0xd0d360: ldur            lr, [fp, #-0x10]
    // 0xd0d364: stp             lr, x16, [SP, #8]
    // 0xd0d368: str             x0, [SP]
    // 0xd0d36c: ldur            x0, [fp, #-0x10]
    // 0xd0d370: ClosureCall
    //     0xd0d370: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0xd0d374: ldur            x2, [x0, #0x1f]
    //     0xd0d378: blr             x2
    // 0xd0d37c: r1 = Function '<anonymous closure>':.
    //     0xd0d37c: add             x1, PP, #0x90, lsl #12  ; [pp+0x905d0] AnonymousClosure: (0xd0e658), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0xd0ce1c)
    //     0xd0d380: ldr             x1, [x1, #0x5d0]
    // 0xd0d384: r2 = Null
    //     0xd0d384: mov             x2, NULL
    // 0xd0d388: stur            x0, [fp, #-0xc0]
    // 0xd0d38c: r0 = AllocateClosure()
    //     0xd0d38c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd0d390: r16 = <bool>
    //     0xd0d390: ldr             x16, [PP, #0x1918]  ; [pp+0x1918] TypeArguments: <bool>
    // 0xd0d394: ldur            lr, [fp, #-0x10]
    // 0xd0d398: stp             lr, x16, [SP, #8]
    // 0xd0d39c: str             x0, [SP]
    // 0xd0d3a0: ldur            x0, [fp, #-0x10]
    // 0xd0d3a4: ClosureCall
    //     0xd0d3a4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0xd0d3a8: ldur            x2, [x0, #0x1f]
    //     0xd0d3ac: blr             x2
    // 0xd0d3b0: cmp             w0, NULL
    // 0xd0d3b4: b.ne            #0xd0d3c0
    // 0xd0d3b8: r4 = true
    //     0xd0d3b8: add             x4, NULL, #0x20  ; true
    // 0xd0d3bc: b               #0xd0d3c4
    // 0xd0d3c0: mov             x4, x0
    // 0xd0d3c4: ldur            x3, [fp, #-8]
    // 0xd0d3c8: ldur            x0, [fp, #-0xb0]
    // 0xd0d3cc: stur            x4, [fp, #-0xc8]
    // 0xd0d3d0: r1 = Function '<anonymous closure>':.
    //     0xd0d3d0: add             x1, PP, #0x90, lsl #12  ; [pp+0x905d8] AnonymousClosure: (0xd0e604), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0xd0ce1c)
    //     0xd0d3d4: ldr             x1, [x1, #0x5d8]
    // 0xd0d3d8: r2 = Null
    //     0xd0d3d8: mov             x2, NULL
    // 0xd0d3dc: r0 = AllocateClosure()
    //     0xd0d3dc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd0d3e0: r16 = <AlignmentGeometry>
    //     0xd0d3e0: add             x16, PP, #0x90, lsl #12  ; [pp+0x905e0] TypeArguments: <AlignmentGeometry>
    //     0xd0d3e4: ldr             x16, [x16, #0x5e0]
    // 0xd0d3e8: ldur            lr, [fp, #-0x10]
    // 0xd0d3ec: stp             lr, x16, [SP, #8]
    // 0xd0d3f0: str             x0, [SP]
    // 0xd0d3f4: ldur            x0, [fp, #-0x10]
    // 0xd0d3f8: ClosureCall
    //     0xd0d3f8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0xd0d3fc: ldur            x2, [x0, #0x1f]
    //     0xd0d400: blr             x2
    // 0xd0d404: mov             x2, x0
    // 0xd0d408: ldur            x0, [fp, #-0xb0]
    // 0xd0d40c: stur            x2, [fp, #-0xd0]
    // 0xd0d410: cmp             w0, NULL
    // 0xd0d414: b.eq            #0xd0de24
    // 0xd0d418: mov             x1, x0
    // 0xd0d41c: r0 = baseSizeAdjustment()
    //     0xd0d41c: bl              #0xb2496c  ; [package:flutter/src/material/theme_data.dart] VisualDensity::baseSizeAdjustment
    // 0xd0d420: r1 = Function '<anonymous closure>':.
    //     0xd0d420: add             x1, PP, #0x90, lsl #12  ; [pp+0x905e8] AnonymousClosure: (0xd0e5b4), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0xd0ce1c)
    //     0xd0d424: ldr             x1, [x1, #0x5e8]
    // 0xd0d428: r2 = Null
    //     0xd0d428: mov             x2, NULL
    // 0xd0d42c: stur            x0, [fp, #-0xd8]
    // 0xd0d430: r0 = AllocateClosure()
    //     0xd0d430: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd0d434: r16 = <InteractiveInkFeatureFactory>
    //     0xd0d434: add             x16, PP, #0x90, lsl #12  ; [pp+0x905f0] TypeArguments: <InteractiveInkFeatureFactory>
    //     0xd0d438: ldr             x16, [x16, #0x5f0]
    // 0xd0d43c: ldur            lr, [fp, #-0x10]
    // 0xd0d440: stp             lr, x16, [SP, #8]
    // 0xd0d444: str             x0, [SP]
    // 0xd0d448: ldur            x0, [fp, #-0x10]
    // 0xd0d44c: ClosureCall
    //     0xd0d44c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0xd0d450: ldur            x2, [x0, #0x1f]
    //     0xd0d454: blr             x2
    // 0xd0d458: r1 = Function '<anonymous closure>':.
    //     0xd0d458: add             x1, PP, #0x90, lsl #12  ; [pp+0x905f8] Function: [dart:ui] Shader::Shader._ (0x13cf838)
    //     0xd0d45c: ldr             x1, [x1, #0x5f8]
    // 0xd0d460: r2 = Null
    //     0xd0d460: mov             x2, NULL
    // 0xd0d464: stur            x0, [fp, #-0xe0]
    // 0xd0d468: r0 = AllocateClosure()
    //     0xd0d468: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd0d46c: r16 = <(dynamic this, BuildContext, Set<WidgetState>, Widget?) => Widget>
    //     0xd0d46c: add             x16, PP, #0x90, lsl #12  ; [pp+0x90600] TypeArguments: <(dynamic this, BuildContext, Set<WidgetState>, Widget?) => Widget>
    //     0xd0d470: ldr             x16, [x16, #0x600]
    // 0xd0d474: ldur            lr, [fp, #-0x10]
    // 0xd0d478: stp             lr, x16, [SP, #8]
    // 0xd0d47c: str             x0, [SP]
    // 0xd0d480: ldur            x0, [fp, #-0x10]
    // 0xd0d484: ClosureCall
    //     0xd0d484: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0xd0d488: ldur            x2, [x0, #0x1f]
    //     0xd0d48c: blr             x2
    // 0xd0d490: r1 = Function '<anonymous closure>':.
    //     0xd0d490: add             x1, PP, #0x90, lsl #12  ; [pp+0x90608] Function: [dart:ui] Shader::Shader._ (0x13cf838)
    //     0xd0d494: ldr             x1, [x1, #0x608]
    // 0xd0d498: r2 = Null
    //     0xd0d498: mov             x2, NULL
    // 0xd0d49c: r0 = AllocateClosure()
    //     0xd0d49c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd0d4a0: r16 = <(dynamic this, BuildContext, Set<WidgetState>, Widget?) => Widget>
    //     0xd0d4a0: add             x16, PP, #0x90, lsl #12  ; [pp+0x90600] TypeArguments: <(dynamic this, BuildContext, Set<WidgetState>, Widget?) => Widget>
    //     0xd0d4a4: ldr             x16, [x16, #0x600]
    // 0xd0d4a8: ldur            lr, [fp, #-0x10]
    // 0xd0d4ac: stp             lr, x16, [SP, #8]
    // 0xd0d4b0: str             x0, [SP]
    // 0xd0d4b4: ldur            x0, [fp, #-0x10]
    // 0xd0d4b8: ClosureCall
    //     0xd0d4b8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0xd0d4bc: ldur            x2, [x0, #0x1f]
    //     0xd0d4c0: blr             x2
    // 0xd0d4c4: ldur            x2, [fp, #-8]
    // 0xd0d4c8: LoadField: r0 = r2->field_b
    //     0xd0d4c8: ldur            w0, [x2, #0xb]
    // 0xd0d4cc: DecompressPointer r0
    //     0xd0d4cc: add             x0, x0, HEAP, lsl #32
    // 0xd0d4d0: cmp             w0, NULL
    // 0xd0d4d4: b.eq            #0xd0de28
    // 0xd0d4d8: LoadField: r1 = r0->field_1f
    //     0xd0d4d8: ldur            w1, [x0, #0x1f]
    // 0xd0d4dc: DecompressPointer r1
    //     0xd0d4dc: add             x1, x1, HEAP, lsl #32
    // 0xd0d4e0: cmp             w1, NULL
    // 0xd0d4e4: b.ne            #0xd0d4f4
    // 0xd0d4e8: r4 = Instance_Clip
    //     0xd0d4e8: add             x4, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xd0d4ec: ldr             x4, [x4, #0x840]
    // 0xd0d4f0: b               #0xd0d4f8
    // 0xd0d4f4: mov             x4, x1
    // 0xd0d4f8: ldur            x3, [fp, #-0x78]
    // 0xd0d4fc: ldur            x1, [fp, #-0x80]
    // 0xd0d500: ldur            x0, [fp, #-0x88]
    // 0xd0d504: stur            x4, [fp, #-0x10]
    // 0xd0d508: cmp             w3, NULL
    // 0xd0d50c: b.eq            #0xd0de2c
    // 0xd0d510: LoadField: d0 = r3->field_7
    //     0xd0d510: ldur            d0, [x3, #7]
    // 0xd0d514: r17 = -264
    //     0xd0d514: mov             x17, #-0x108
    // 0xd0d518: str             d0, [fp, x17]
    // 0xd0d51c: LoadField: d1 = r3->field_f
    //     0xd0d51c: ldur            d1, [x3, #0xf]
    // 0xd0d520: stur            d1, [fp, #-0x100]
    // 0xd0d524: cmp             w0, NULL
    // 0xd0d528: b.eq            #0xd0de30
    // 0xd0d52c: LoadField: d2 = r0->field_7
    //     0xd0d52c: ldur            d2, [x0, #7]
    // 0xd0d530: stur            d2, [fp, #-0xf8]
    // 0xd0d534: LoadField: d3 = r0->field_f
    //     0xd0d534: ldur            d3, [x0, #0xf]
    // 0xd0d538: stur            d3, [fp, #-0xf0]
    // 0xd0d53c: r0 = BoxConstraints()
    //     0xd0d53c: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xd0d540: r17 = -264
    //     0xd0d540: mov             x17, #-0x108
    // 0xd0d544: ldr             d0, [fp, x17]
    // 0xd0d548: StoreField: r0->field_7 = d0
    //     0xd0d548: stur            d0, [x0, #7]
    // 0xd0d54c: ldur            d0, [fp, #-0xf8]
    // 0xd0d550: StoreField: r0->field_f = d0
    //     0xd0d550: stur            d0, [x0, #0xf]
    // 0xd0d554: ldur            d0, [fp, #-0x100]
    // 0xd0d558: ArrayStore: r0[0] = d0  ; List_8
    //     0xd0d558: stur            d0, [x0, #0x17]
    // 0xd0d55c: ldur            d0, [fp, #-0xf0]
    // 0xd0d560: StoreField: r0->field_1f = d0
    //     0xd0d560: stur            d0, [x0, #0x1f]
    // 0xd0d564: ldur            x1, [fp, #-0xb0]
    // 0xd0d568: mov             x2, x0
    // 0xd0d56c: r0 = effectiveConstraints()
    //     0xd0d56c: bl              #0xd0cad0  ; [package:flutter/src/material/theme_data.dart] VisualDensity::effectiveConstraints
    // 0xd0d570: ldur            x2, [fp, #-0x80]
    // 0xd0d574: stur            x0, [fp, #-0x78]
    // 0xd0d578: cmp             w2, NULL
    // 0xd0d57c: b.eq            #0xd0d664
    // 0xd0d580: mov             x1, x0
    // 0xd0d584: r0 = constrain()
    //     0xd0d584: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xd0d588: stur            x0, [fp, #-0x80]
    // 0xd0d58c: LoadField: d0 = r0->field_7
    //     0xd0d58c: ldur            d0, [x0, #7]
    // 0xd0d590: mov             x1, v0.d[0]
    // 0xd0d594: and             x1, x1, #0x7fffffffffffffff
    // 0xd0d598: r17 = 9218868437227405312
    //     0xd0d598: mov             x17, #0x7ff0000000000000
    // 0xd0d59c: cmp             x1, x17
    // 0xd0d5a0: b.eq            #0xd0d5f0
    // 0xd0d5a4: fcmp            d0, d0
    // 0xd0d5a8: b.vs            #0xd0d5f0
    // 0xd0d5ac: r1 = inline_Allocate_Double()
    //     0xd0d5ac: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xd0d5b0: add             x1, x1, #0x10
    //     0xd0d5b4: cmp             x2, x1
    //     0xd0d5b8: b.ls            #0xd0de34
    //     0xd0d5bc: str             x1, [THR, #0x60]  ; THR::top
    //     0xd0d5c0: sub             x1, x1, #0xf
    //     0xd0d5c4: mov             x2, #0xe19c
    //     0xd0d5c8: movk            x2, #3, lsl #16
    //     0xd0d5cc: stur            x2, [x1, #-1]
    // 0xd0d5d0: dmb             ishst
    // 0xd0d5d4: StoreField: r1->field_7 = d0
    //     0xd0d5d4: stur            d0, [x1, #7]
    // 0xd0d5d8: stp             x1, x1, [SP]
    // 0xd0d5dc: ldur            x1, [fp, #-0x78]
    // 0xd0d5e0: r4 = const [0, 0x3, 0x2, 0x1, maxWidth, 0x2, minWidth, 0x1, null]
    //     0xd0d5e0: ldr             x4, [PP, #0x4ca8]  ; [pp+0x4ca8] List(9) [0, 0x3, 0x2, 0x1, "maxWidth", 0x2, "minWidth", 0x1, Null]
    // 0xd0d5e4: r0 = copyWith()
    //     0xd0d5e4: bl              #0xb4cfe8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::copyWith
    // 0xd0d5e8: mov             x1, x0
    // 0xd0d5ec: b               #0xd0d5f4
    // 0xd0d5f0: ldur            x1, [fp, #-0x78]
    // 0xd0d5f4: ldur            x0, [fp, #-0x80]
    // 0xd0d5f8: LoadField: d0 = r0->field_f
    //     0xd0d5f8: ldur            d0, [x0, #0xf]
    // 0xd0d5fc: mov             x0, v0.d[0]
    // 0xd0d600: and             x0, x0, #0x7fffffffffffffff
    // 0xd0d604: r17 = 9218868437227405312
    //     0xd0d604: mov             x17, #0x7ff0000000000000
    // 0xd0d608: cmp             x0, x17
    // 0xd0d60c: b.eq            #0xd0d658
    // 0xd0d610: fcmp            d0, d0
    // 0xd0d614: b.vs            #0xd0d658
    // 0xd0d618: r0 = inline_Allocate_Double()
    //     0xd0d618: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xd0d61c: add             x0, x0, #0x10
    //     0xd0d620: cmp             x2, x0
    //     0xd0d624: b.ls            #0xd0de50
    //     0xd0d628: str             x0, [THR, #0x60]  ; THR::top
    //     0xd0d62c: sub             x0, x0, #0xf
    //     0xd0d630: mov             x2, #0xe19c
    //     0xd0d634: movk            x2, #3, lsl #16
    //     0xd0d638: stur            x2, [x0, #-1]
    // 0xd0d63c: dmb             ishst
    // 0xd0d640: StoreField: r0->field_7 = d0
    //     0xd0d640: stur            d0, [x0, #7]
    // 0xd0d644: stp             x0, x0, [SP]
    // 0xd0d648: r4 = const [0, 0x3, 0x2, 0x1, maxHeight, 0x2, minHeight, 0x1, null]
    //     0xd0d648: add             x4, PP, #0x90, lsl #12  ; [pp+0x90610] List(9) [0, 0x3, 0x2, 0x1, "maxHeight", 0x2, "minHeight", 0x1, Null]
    //     0xd0d64c: ldr             x4, [x4, #0x610]
    // 0xd0d650: r0 = copyWith()
    //     0xd0d650: bl              #0xb4cfe8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::copyWith
    // 0xd0d654: b               #0xd0d65c
    // 0xd0d658: mov             x0, x1
    // 0xd0d65c: mov             x3, x0
    // 0xd0d660: b               #0xd0d668
    // 0xd0d664: ldur            x3, [fp, #-0x78]
    // 0xd0d668: ldur            x2, [fp, #-0x70]
    // 0xd0d66c: ldur            x1, [fp, #-0xc0]
    // 0xd0d670: ldur            x0, [fp, #-0xd8]
    // 0xd0d674: d0 = 0.000000
    //     0xd0d674: eor             v0.16b, v0.16b, v0.16b
    // 0xd0d678: stur            x3, [fp, #-0x78]
    // 0xd0d67c: LoadField: d1 = r0->field_f
    //     0xd0d67c: ldur            d1, [x0, #0xf]
    // 0xd0d680: stur            d1, [fp, #-0x100]
    // 0xd0d684: LoadField: d2 = r0->field_7
    //     0xd0d684: ldur            d2, [x0, #7]
    // 0xd0d688: stur            d2, [fp, #-0xf8]
    // 0xd0d68c: fmax            v3.2d, v0.2d, v2.2d
    // 0xd0d690: stur            d3, [fp, #-0xf0]
    // 0xd0d694: cmp             w2, NULL
    // 0xd0d698: b.eq            #0xd0de68
    // 0xd0d69c: r0 = EdgeInsets()
    //     0xd0d69c: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xd0d6a0: ldur            d0, [fp, #-0xf0]
    // 0xd0d6a4: StoreField: r0->field_7 = d0
    //     0xd0d6a4: stur            d0, [x0, #7]
    // 0xd0d6a8: ldur            d1, [fp, #-0x100]
    // 0xd0d6ac: StoreField: r0->field_f = d1
    //     0xd0d6ac: stur            d1, [x0, #0xf]
    // 0xd0d6b0: ArrayStore: r0[0] = d0  ; List_8
    //     0xd0d6b0: stur            d0, [x0, #0x17]
    // 0xd0d6b4: StoreField: r0->field_1f = d1
    //     0xd0d6b4: stur            d1, [x0, #0x1f]
    // 0xd0d6b8: ldur            x1, [fp, #-0x70]
    // 0xd0d6bc: r2 = LoadClassIdInstr(r1)
    //     0xd0d6bc: ldur            x2, [x1, #-1]
    //     0xd0d6c0: ubfx            x2, x2, #0xc, #0x14
    // 0xd0d6c4: mov             x16, x0
    // 0xd0d6c8: mov             x0, x2
    // 0xd0d6cc: mov             x2, x16
    // 0xd0d6d0: r0 = GDT[cid_x0 + -0xf8e]()
    //     0xd0d6d0: sub             lr, x0, #0xf8e
    //     0xd0d6d4: ldr             lr, [x21, lr, lsl #3]
    //     0xd0d6d8: blr             lr
    // 0xd0d6dc: r1 = LoadClassIdInstr(r0)
    //     0xd0d6dc: ldur            x1, [x0, #-1]
    //     0xd0d6e0: ubfx            x1, x1, #0xc, #0x14
    // 0xd0d6e4: mov             x16, x0
    // 0xd0d6e8: mov             x0, x1
    // 0xd0d6ec: mov             x1, x16
    // 0xd0d6f0: r0 = GDT[cid_x0 + -0xf8b]()
    //     0xd0d6f0: sub             lr, x0, #0xf8b
    //     0xd0d6f4: ldr             lr, [x21, lr, lsl #3]
    //     0xd0d6f8: blr             lr
    // 0xd0d6fc: mov             x1, x0
    // 0xd0d700: ldur            x0, [fp, #-0xc0]
    // 0xd0d704: stur            x1, [fp, #-0x70]
    // 0xd0d708: cmp             w0, NULL
    // 0xd0d70c: b.eq            #0xd0de6c
    // 0xd0d710: LoadField: r2 = r0->field_7
    //     0xd0d710: ldur            x2, [x0, #7]
    // 0xd0d714: cmp             x2, #0
    // 0xd0d718: b.le            #0xd0d964
    // 0xd0d71c: ldur            x2, [fp, #-8]
    // 0xd0d720: LoadField: r3 = r2->field_1f
    //     0xd0d720: ldur            w3, [x2, #0x1f]
    // 0xd0d724: DecompressPointer r3
    //     0xd0d724: add             x3, x3, HEAP, lsl #32
    // 0xd0d728: cmp             w3, NULL
    // 0xd0d72c: b.eq            #0xd0d964
    // 0xd0d730: LoadField: r4 = r2->field_23
    //     0xd0d730: ldur            w4, [x2, #0x23]
    // 0xd0d734: DecompressPointer r4
    //     0xd0d734: add             x4, x4, HEAP, lsl #32
    // 0xd0d738: cmp             w4, NULL
    // 0xd0d73c: b.eq            #0xd0d964
    // 0xd0d740: ldur            x16, [fp, #-0x40]
    // 0xd0d744: stp             x16, x3, [SP]
    // 0xd0d748: r0 = ==()
    //     0xd0d748: bl              #0x12b7c00  ; [dart:core] _Double::==
    // 0xd0d74c: tbz             w0, #4, #0xd0d964
    // 0xd0d750: ldur            x2, [fp, #-8]
    // 0xd0d754: ldur            x3, [fp, #-0x50]
    // 0xd0d758: LoadField: r1 = r2->field_23
    //     0xd0d758: ldur            w1, [x2, #0x23]
    // 0xd0d75c: DecompressPointer r1
    //     0xd0d75c: add             x1, x1, HEAP, lsl #32
    // 0xd0d760: cmp             w1, NULL
    // 0xd0d764: b.eq            #0xd0de70
    // 0xd0d768: r0 = LoadClassIdInstr(r1)
    //     0xd0d768: ldur            x0, [x1, #-1]
    //     0xd0d76c: ubfx            x0, x0, #0xc, #0x14
    // 0xd0d770: r0 = GDT[cid_x0 + -0xfb8]()
    //     0xd0d770: sub             lr, x0, #0xfb8
    //     0xd0d774: ldr             lr, [x21, lr, lsl #3]
    //     0xd0d778: blr             lr
    // 0xd0d77c: mov             x3, x0
    // 0xd0d780: ldur            x2, [fp, #-0x50]
    // 0xd0d784: stur            x3, [fp, #-0xe8]
    // 0xd0d788: cmp             w2, NULL
    // 0xd0d78c: b.eq            #0xd0de74
    // 0xd0d790: r0 = LoadClassIdInstr(r2)
    //     0xd0d790: ldur            x0, [x2, #-1]
    //     0xd0d794: ubfx            x0, x0, #0xc, #0x14
    // 0xd0d798: mov             x1, x2
    // 0xd0d79c: r0 = GDT[cid_x0 + -0xfb8]()
    //     0xd0d79c: sub             lr, x0, #0xfb8
    //     0xd0d7a0: ldr             lr, [x21, lr, lsl #3]
    //     0xd0d7a4: blr             lr
    // 0xd0d7a8: mov             x1, x0
    // 0xd0d7ac: ldur            x0, [fp, #-0xe8]
    // 0xd0d7b0: cmp             x0, x1
    // 0xd0d7b4: b.eq            #0xd0d964
    // 0xd0d7b8: ldur            x2, [fp, #-8]
    // 0xd0d7bc: LoadField: r1 = r2->field_23
    //     0xd0d7bc: ldur            w1, [x2, #0x23]
    // 0xd0d7c0: DecompressPointer r1
    //     0xd0d7c0: add             x1, x1, HEAP, lsl #32
    // 0xd0d7c4: cmp             w1, NULL
    // 0xd0d7c8: b.eq            #0xd0de78
    // 0xd0d7cc: r0 = LoadClassIdInstr(r1)
    //     0xd0d7cc: ldur            x0, [x1, #-1]
    //     0xd0d7d0: ubfx            x0, x0, #0xc, #0x14
    // 0xd0d7d4: r0 = GDT[cid_x0 + -0xfab]()
    //     0xd0d7d4: sub             lr, x0, #0xfab
    //     0xd0d7d8: ldr             lr, [x21, lr, lsl #3]
    //     0xd0d7dc: blr             lr
    // 0xd0d7e0: mov             v1.16b, v0.16b
    // 0xd0d7e4: d0 = 1.000000
    //     0xd0d7e4: fmov            d0, #1.00000000
    // 0xd0d7e8: fcmp            d1, d0
    // 0xd0d7ec: b.ne            #0xd0d964
    // 0xd0d7f0: ldur            x2, [fp, #-0x50]
    // 0xd0d7f4: r0 = LoadClassIdInstr(r2)
    //     0xd0d7f4: ldur            x0, [x2, #-1]
    //     0xd0d7f8: ubfx            x0, x0, #0xc, #0x14
    // 0xd0d7fc: mov             x1, x2
    // 0xd0d800: r0 = GDT[cid_x0 + -0xfab]()
    //     0xd0d800: sub             lr, x0, #0xfab
    //     0xd0d804: ldr             lr, [x21, lr, lsl #3]
    //     0xd0d808: blr             lr
    // 0xd0d80c: mov             v1.16b, v0.16b
    // 0xd0d810: d0 = 1.000000
    //     0xd0d810: fmov            d0, #1.00000000
    // 0xd0d814: fcmp            d0, d1
    // 0xd0d818: b.le            #0xd0d964
    // 0xd0d81c: ldur            x1, [fp, #-0x40]
    // 0xd0d820: r0 = 60
    //     0xd0d820: mov             x0, #0x3c
    // 0xd0d824: branchIfSmi(r1, 0xd0d830)
    //     0xd0d824: tbz             w1, #0, #0xd0d830
    // 0xd0d828: r0 = LoadClassIdInstr(r1)
    //     0xd0d828: ldur            x0, [x1, #-1]
    //     0xd0d82c: ubfx            x0, x0, #0xc, #0x14
    // 0xd0d830: stp             xzr, x1, [SP]
    // 0xd0d834: mov             lr, x0
    // 0xd0d838: ldr             lr, [x21, lr, lsl #3]
    // 0xd0d83c: blr             lr
    // 0xd0d840: tbnz            w0, #4, #0xd0d964
    // 0xd0d844: ldur            x2, [fp, #-8]
    // 0xd0d848: LoadField: r0 = r2->field_1b
    //     0xd0d848: ldur            w0, [x2, #0x1b]
    // 0xd0d84c: DecompressPointer r0
    //     0xd0d84c: add             x0, x0, HEAP, lsl #32
    // 0xd0d850: cmp             w0, NULL
    // 0xd0d854: b.ne            #0xd0d860
    // 0xd0d858: r0 = Null
    //     0xd0d858: mov             x0, NULL
    // 0xd0d85c: b               #0xd0d86c
    // 0xd0d860: LoadField: r1 = r0->field_27
    //     0xd0d860: ldur            w1, [x0, #0x27]
    // 0xd0d864: DecompressPointer r1
    //     0xd0d864: add             x1, x1, HEAP, lsl #32
    // 0xd0d868: mov             x0, x1
    // 0xd0d86c: r1 = LoadClassIdInstr(r0)
    //     0xd0d86c: ldur            x1, [x0, #-1]
    //     0xd0d870: ubfx            x1, x1, #0xc, #0x14
    // 0xd0d874: ldur            x16, [fp, #-0xc0]
    // 0xd0d878: stp             x16, x0, [SP]
    // 0xd0d87c: mov             x0, x1
    // 0xd0d880: mov             lr, x0
    // 0xd0d884: ldr             lr, [x21, lr, lsl #3]
    // 0xd0d888: blr             lr
    // 0xd0d88c: tbz             w0, #4, #0xd0d918
    // 0xd0d890: ldur            x2, [fp, #-8]
    // 0xd0d894: LoadField: r1 = r2->field_1b
    //     0xd0d894: ldur            w1, [x2, #0x1b]
    // 0xd0d898: DecompressPointer r1
    //     0xd0d898: add             x1, x1, HEAP, lsl #32
    // 0xd0d89c: cmp             w1, NULL
    // 0xd0d8a0: b.eq            #0xd0d8ac
    // 0xd0d8a4: r0 = dispose()
    //     0xd0d8a4: bl              #0x9164f4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0xd0d8a8: ldur            x2, [fp, #-8]
    // 0xd0d8ac: r1 = <double>
    //     0xd0d8ac: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd0d8b0: r0 = AnimationController()
    //     0xd0d8b0: bl              #0x87522c  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0xd0d8b4: stur            x0, [fp, #-0x80]
    // 0xd0d8b8: ldur            x16, [fp, #-0xc0]
    // 0xd0d8bc: str             x16, [SP]
    // 0xd0d8c0: mov             x1, x0
    // 0xd0d8c4: ldur            x2, [fp, #-8]
    // 0xd0d8c8: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0xd0d8c8: add             x4, PP, #0x15, lsl #12  ; [pp+0x155a0] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0xd0d8cc: ldr             x4, [x4, #0x5a0]
    // 0xd0d8d0: r0 = AnimationController()
    //     0xd0d8d0: bl              #0x874ea4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0xd0d8d4: ldur            x2, [fp, #-0x18]
    // 0xd0d8d8: r1 = Function '<anonymous closure>':.
    //     0xd0d8d8: add             x1, PP, #0x90, lsl #12  ; [pp+0x90618] AnonymousClosure: (0xd0e540), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0xd0ce1c)
    //     0xd0d8dc: ldr             x1, [x1, #0x618]
    // 0xd0d8e0: r0 = AllocateClosure()
    //     0xd0d8e0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd0d8e4: ldur            x1, [fp, #-0x80]
    // 0xd0d8e8: mov             x2, x0
    // 0xd0d8ec: r0 = addStatusListener()
    //     0xd0d8ec: bl              #0x1254cc0  ; [dart:mixin_deduplication] _MixinApplication456&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::addStatusListener
    // 0xd0d8f0: ldur            x0, [fp, #-0x80]
    // 0xd0d8f4: ldur            x3, [fp, #-8]
    // 0xd0d8f8: StoreField: r3->field_1b = r0
    //     0xd0d8f8: stur            w0, [x3, #0x1b]
    //     0xd0d8fc: ldurb           w16, [x3, #-1]
    //     0xd0d900: ldurb           w17, [x0, #-1]
    //     0xd0d904: and             x16, x17, x16, lsr #2
    //     0xd0d908: tst             x16, HEAP, lsr #32
    //     0xd0d90c: b.eq            #0xd0d914
    //     0xd0d910: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xd0d914: b               #0xd0d91c
    // 0xd0d918: ldur            x3, [fp, #-8]
    // 0xd0d91c: LoadField: r0 = r3->field_23
    //     0xd0d91c: ldur            w0, [x3, #0x23]
    // 0xd0d920: DecompressPointer r0
    //     0xd0d920: add             x0, x0, HEAP, lsl #32
    // 0xd0d924: stur            x0, [fp, #-0x18]
    // 0xd0d928: LoadField: r1 = r3->field_1b
    //     0xd0d928: ldur            w1, [x3, #0x1b]
    // 0xd0d92c: DecompressPointer r1
    //     0xd0d92c: add             x1, x1, HEAP, lsl #32
    // 0xd0d930: cmp             w1, NULL
    // 0xd0d934: b.eq            #0xd0de7c
    // 0xd0d938: r2 = 0.000000
    //     0xd0d938: ldr             x2, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xd0d93c: r0 = value=()
    //     0xd0d93c: bl              #0x829534  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0xd0d940: ldur            x0, [fp, #-8]
    // 0xd0d944: LoadField: r1 = r0->field_1b
    //     0xd0d944: ldur            w1, [x0, #0x1b]
    // 0xd0d948: DecompressPointer r1
    //     0xd0d948: add             x1, x1, HEAP, lsl #32
    // 0xd0d94c: cmp             w1, NULL
    // 0xd0d950: b.eq            #0xd0de80
    // 0xd0d954: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd0d954: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd0d958: r0 = forward()
    //     0xd0d958: bl              #0x8cd83c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0xd0d95c: ldur            x6, [fp, #-0x18]
    // 0xd0d960: b               #0xd0d968
    // 0xd0d964: ldur            x6, [fp, #-0x50]
    // 0xd0d968: ldur            x1, [fp, #-8]
    // 0xd0d96c: ldur            x5, [fp, #-0x38]
    // 0xd0d970: ldur            x4, [fp, #-0x90]
    // 0xd0d974: ldur            x3, [fp, #-0xd0]
    // 0xd0d978: ldur            x2, [fp, #-0x70]
    // 0xd0d97c: ldur            x0, [fp, #-0x40]
    // 0xd0d980: stur            x6, [fp, #-0x50]
    // 0xd0d984: StoreField: r1->field_1f = r0
    //     0xd0d984: stur            w0, [x1, #0x1f]
    //     0xd0d988: ldurb           w16, [x1, #-1]
    //     0xd0d98c: ldurb           w17, [x0, #-1]
    //     0xd0d990: and             x16, x17, x16, lsr #2
    //     0xd0d994: tst             x16, HEAP, lsr #32
    //     0xd0d998: b.eq            #0xd0d9a0
    //     0xd0d99c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd0d9a0: mov             x0, x6
    // 0xd0d9a4: StoreField: r1->field_23 = r0
    //     0xd0d9a4: stur            w0, [x1, #0x23]
    //     0xd0d9a8: ldurb           w16, [x1, #-1]
    //     0xd0d9ac: ldurb           w17, [x0, #-1]
    //     0xd0d9b0: and             x16, x17, x16, lsr #2
    //     0xd0d9b4: tst             x16, HEAP, lsr #32
    //     0xd0d9b8: b.eq            #0xd0d9c0
    //     0xd0d9bc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd0d9c0: cmp             w3, NULL
    // 0xd0d9c4: b.eq            #0xd0de84
    // 0xd0d9c8: LoadField: r0 = r1->field_b
    //     0xd0d9c8: ldur            w0, [x1, #0xb]
    // 0xd0d9cc: DecompressPointer r0
    //     0xd0d9cc: add             x0, x0, HEAP, lsl #32
    // 0xd0d9d0: cmp             w0, NULL
    // 0xd0d9d4: b.eq            #0xd0de88
    // 0xd0d9d8: LoadField: r7 = r0->field_37
    //     0xd0d9d8: ldur            w7, [x0, #0x37]
    // 0xd0d9dc: DecompressPointer r7
    //     0xd0d9dc: add             x7, x7, HEAP, lsl #32
    // 0xd0d9e0: stur            x7, [fp, #-0x18]
    // 0xd0d9e4: r0 = Align()
    //     0xd0d9e4: bl              #0xb281f8  ; AllocateAlignStub -> Align (size=0x1c)
    // 0xd0d9e8: mov             x1, x0
    // 0xd0d9ec: ldur            x0, [fp, #-0xd0]
    // 0xd0d9f0: stur            x1, [fp, #-0x80]
    // 0xd0d9f4: StoreField: r1->field_f = r0
    //     0xd0d9f4: stur            w0, [x1, #0xf]
    // 0xd0d9f8: r0 = 1.000000
    //     0xd0d9f8: ldr             x0, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xd0d9fc: StoreField: r1->field_13 = r0
    //     0xd0d9fc: stur            w0, [x1, #0x13]
    // 0xd0da00: ArrayStore: r1[0] = r0  ; List_4
    //     0xd0da00: stur            w0, [x1, #0x17]
    // 0xd0da04: ldur            x0, [fp, #-0x18]
    // 0xd0da08: StoreField: r1->field_b = r0
    //     0xd0da08: stur            w0, [x1, #0xb]
    // 0xd0da0c: r0 = Padding()
    //     0xd0da0c: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xd0da10: mov             x1, x0
    // 0xd0da14: ldur            x0, [fp, #-0x70]
    // 0xd0da18: stur            x1, [fp, #-0x18]
    // 0xd0da1c: StoreField: r1->field_f = r0
    //     0xd0da1c: stur            w0, [x1, #0xf]
    // 0xd0da20: ldur            x0, [fp, #-0x80]
    // 0xd0da24: StoreField: r1->field_b = r0
    //     0xd0da24: stur            w0, [x1, #0xb]
    // 0xd0da28: r0 = IconThemeData()
    //     0xd0da28: bl              #0x8ac78c  ; AllocateIconThemeDataStub -> IconThemeData (size=0x2c)
    // 0xd0da2c: mov             x1, x0
    // 0xd0da30: ldur            x0, [fp, #-0x90]
    // 0xd0da34: StoreField: r1->field_7 = r0
    //     0xd0da34: stur            w0, [x1, #7]
    // 0xd0da38: ldur            x0, [fp, #-0x38]
    // 0xd0da3c: StoreField: r1->field_1b = r0
    //     0xd0da3c: stur            w0, [x1, #0x1b]
    // 0xd0da40: mov             x2, x1
    // 0xd0da44: ldur            x1, [fp, #-0x28]
    // 0xd0da48: r0 = merge()
    //     0xd0da48: bl              #0xd0c674  ; [package:flutter/src/widgets/icon_theme_data.dart] IconThemeData::merge
    // 0xd0da4c: str             x0, [SP]
    // 0xd0da50: ldur            x1, [fp, #-0x20]
    // 0xd0da54: r4 = const [0, 0x2, 0x1, 0x1, iconTheme, 0x1, null]
    //     0xd0da54: add             x4, PP, #0x90, lsl #12  ; [pp+0x90620] List(7) [0, 0x2, 0x1, 0x1, "iconTheme", 0x1, Null]
    //     0xd0da58: ldr             x4, [x4, #0x620]
    // 0xd0da5c: r0 = copyWith()
    //     0xd0da5c: bl              #0x8a7b68  ; [package:flutter/src/material/theme_data.dart] ThemeData::copyWith
    // 0xd0da60: mov             x4, x0
    // 0xd0da64: ldur            x3, [fp, #-8]
    // 0xd0da68: stur            x4, [fp, #-0x38]
    // 0xd0da6c: LoadField: r0 = r3->field_b
    //     0xd0da6c: ldur            w0, [x3, #0xb]
    // 0xd0da70: DecompressPointer r0
    //     0xd0da70: add             x0, x0, HEAP, lsl #32
    // 0xd0da74: cmp             w0, NULL
    // 0xd0da78: b.eq            #0xd0de8c
    // 0xd0da7c: LoadField: r5 = r0->field_b
    //     0xd0da7c: ldur            w5, [x0, #0xb]
    // 0xd0da80: DecompressPointer r5
    //     0xd0da80: add             x5, x5, HEAP, lsl #32
    // 0xd0da84: stur            x5, [fp, #-0x28]
    // 0xd0da88: cmp             w5, NULL
    // 0xd0da8c: b.eq            #0xd0da98
    // 0xd0da90: r12 = true
    //     0xd0da90: add             x12, NULL, #0x20  ; true
    // 0xd0da94: b               #0xd0da9c
    // 0xd0da98: r12 = false
    //     0xd0da98: add             x12, NULL, #0x30  ; false
    // 0xd0da9c: ldur            x11, [fp, #-0x30]
    // 0xd0daa0: ldur            x10, [fp, #-0xa0]
    // 0xd0daa4: ldur            x9, [fp, #-0xa8]
    // 0xd0daa8: ldur            x8, [fp, #-0xc8]
    // 0xd0daac: ldur            x7, [fp, #-0xe0]
    // 0xd0dab0: ldur            x6, [fp, #-0x18]
    // 0xd0dab4: stur            x12, [fp, #-0x20]
    // 0xd0dab8: cmp             w11, NULL
    // 0xd0dabc: b.eq            #0xd0de90
    // 0xd0dac0: r0 = LoadClassIdInstr(r11)
    //     0xd0dac0: ldur            x0, [x11, #-1]
    //     0xd0dac4: ubfx            x0, x0, #0xc, #0x14
    // 0xd0dac8: mov             x1, x11
    // 0xd0dacc: ldur            x2, [fp, #-0x98]
    // 0xd0dad0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xd0dad0: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xd0dad4: r0 = GDT[cid_x0 + -0xff6]()
    //     0xd0dad4: sub             lr, x0, #0xff6
    //     0xd0dad8: ldr             lr, [x21, lr, lsl #3]
    //     0xd0dadc: blr             lr
    // 0xd0dae0: ldur            x1, [fp, #-8]
    // 0xd0dae4: stur            x0, [fp, #-0x70]
    // 0xd0dae8: r0 = statesController()
    //     0xd0dae8: bl              #0xd0dee8  ; [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::statesController
    // 0xd0daec: stur            x0, [fp, #-0x80]
    // 0xd0daf0: r0 = InkWell()
    //     0xd0daf0: bl              #0xd0c57c  ; AllocateInkWellStub -> InkWell (size=0x94)
    // 0xd0daf4: mov             x1, x0
    // 0xd0daf8: ldur            x0, [fp, #-0x18]
    // 0xd0dafc: stur            x1, [fp, #-0x88]
    // 0xd0db00: StoreField: r1->field_b = r0
    //     0xd0db00: stur            w0, [x1, #0xb]
    // 0xd0db04: ldur            x0, [fp, #-0x28]
    // 0xd0db08: StoreField: r1->field_f = r0
    //     0xd0db08: stur            w0, [x1, #0xf]
    // 0xd0db0c: ldur            x0, [fp, #-0xa0]
    // 0xd0db10: StoreField: r1->field_43 = r0
    //     0xd0db10: stur            w0, [x1, #0x43]
    // 0xd0db14: r0 = true
    //     0xd0db14: add             x0, NULL, #0x20  ; true
    // 0xd0db18: StoreField: r1->field_47 = r0
    //     0xd0db18: stur            w0, [x1, #0x47]
    // 0xd0db1c: r2 = Instance_BoxShape
    //     0xd0db1c: add             x2, PP, #0x17, lsl #12  ; [pp+0x171f8] Obj!BoxShape@12c4921
    //     0xd0db20: ldr             x2, [x2, #0x1f8]
    // 0xd0db24: StoreField: r1->field_4b = r2
    //     0xd0db24: stur            w2, [x1, #0x4b]
    // 0xd0db28: ldur            x2, [fp, #-0x70]
    // 0xd0db2c: StoreField: r1->field_57 = r2
    //     0xd0db2c: stur            w2, [x1, #0x57]
    // 0xd0db30: r2 = Instance_Color
    //     0xd0db30: add             x2, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xd0db34: ldr             x2, [x2, #0x810]
    // 0xd0db38: StoreField: r1->field_63 = r2
    //     0xd0db38: stur            w2, [x1, #0x63]
    // 0xd0db3c: ldur            x2, [fp, #-0xa8]
    // 0xd0db40: StoreField: r1->field_67 = r2
    //     0xd0db40: stur            w2, [x1, #0x67]
    // 0xd0db44: ldur            x2, [fp, #-0xe0]
    // 0xd0db48: StoreField: r1->field_6f = r2
    //     0xd0db48: stur            w2, [x1, #0x6f]
    // 0xd0db4c: ldur            x2, [fp, #-0xc8]
    // 0xd0db50: StoreField: r1->field_73 = r2
    //     0xd0db50: stur            w2, [x1, #0x73]
    // 0xd0db54: r2 = false
    //     0xd0db54: add             x2, NULL, #0x30  ; false
    // 0xd0db58: StoreField: r1->field_77 = r2
    //     0xd0db58: stur            w2, [x1, #0x77]
    // 0xd0db5c: ldur            x3, [fp, #-0x20]
    // 0xd0db60: StoreField: r1->field_87 = r3
    //     0xd0db60: stur            w3, [x1, #0x87]
    // 0xd0db64: StoreField: r1->field_7f = r2
    //     0xd0db64: stur            w2, [x1, #0x7f]
    // 0xd0db68: ldur            x3, [fp, #-0x80]
    // 0xd0db6c: StoreField: r1->field_8b = r3
    //     0xd0db6c: stur            w3, [x1, #0x8b]
    // 0xd0db70: r0 = AnimatedTheme()
    //     0xd0db70: bl              #0xd0deb8  ; AllocateAnimatedThemeStub -> AnimatedTheme (size=0x20)
    // 0xd0db74: mov             x1, x0
    // 0xd0db78: ldur            x0, [fp, #-0x38]
    // 0xd0db7c: stur            x1, [fp, #-0x20]
    // 0xd0db80: ArrayStore: r1[0] = r0  ; List_4
    //     0xd0db80: stur            w0, [x1, #0x17]
    // 0xd0db84: ldur            x0, [fp, #-0x88]
    // 0xd0db88: StoreField: r1->field_1b = r0
    //     0xd0db88: stur            w0, [x1, #0x1b]
    // 0xd0db8c: r0 = Instance__Linear
    //     0xd0db8c: ldr             x0, [PP, #0x5168]  ; [pp+0x5168] Obj!_Linear@129fef1
    // 0xd0db90: StoreField: r1->field_b = r0
    //     0xd0db90: stur            w0, [x1, #0xb]
    // 0xd0db94: r0 = Instance_Duration
    //     0xd0db94: add             x0, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xd0db98: ldr             x0, [x0, #0x318]
    // 0xd0db9c: StoreField: r1->field_f = r0
    //     0xd0db9c: stur            w0, [x1, #0xf]
    // 0xd0dba0: ldur            x2, [fp, #-8]
    // 0xd0dba4: LoadField: r3 = r2->field_b
    //     0xd0dba4: ldur            w3, [x2, #0xb]
    // 0xd0dba8: DecompressPointer r3
    //     0xd0dba8: add             x3, x3, HEAP, lsl #32
    // 0xd0dbac: stur            x3, [fp, #-0x18]
    // 0xd0dbb0: cmp             w3, NULL
    // 0xd0dbb4: b.eq            #0xd0de94
    // 0xd0dbb8: LoadField: r2 = r3->field_33
    //     0xd0dbb8: ldur            w2, [x3, #0x33]
    // 0xd0dbbc: DecompressPointer r2
    //     0xd0dbbc: add             x2, x2, HEAP, lsl #32
    // 0xd0dbc0: stur            x2, [fp, #-8]
    // 0xd0dbc4: cmp             w2, NULL
    // 0xd0dbc8: b.eq            #0xd0dbf0
    // 0xd0dbcc: r0 = Tooltip()
    //     0xd0dbcc: bl              #0xd0deac  ; AllocateTooltipStub -> Tooltip (size=0x68)
    // 0xd0dbd0: mov             x1, x0
    // 0xd0dbd4: ldur            x0, [fp, #-8]
    // 0xd0dbd8: StoreField: r1->field_b = r0
    //     0xd0dbd8: stur            w0, [x1, #0xb]
    // 0xd0dbdc: r0 = true
    //     0xd0dbdc: add             x0, NULL, #0x20  ; true
    // 0xd0dbe0: StoreField: r1->field_4b = r0
    //     0xd0dbe0: stur            w0, [x1, #0x4b]
    // 0xd0dbe4: ldur            x0, [fp, #-0x20]
    // 0xd0dbe8: StoreField: r1->field_2f = r0
    //     0xd0dbe8: stur            w0, [x1, #0x2f]
    // 0xd0dbec: b               #0xd0dbf8
    // 0xd0dbf0: mov             x0, x1
    // 0xd0dbf4: mov             x1, x0
    // 0xd0dbf8: ldur            x0, [fp, #-0xb8]
    // 0xd0dbfc: stur            x1, [fp, #-8]
    // 0xd0dc00: cmp             w0, NULL
    // 0xd0dc04: b.eq            #0xd0de98
    // 0xd0dc08: LoadField: r2 = r0->field_7
    //     0xd0dc08: ldur            x2, [x0, #7]
    // 0xd0dc0c: cmp             x2, #0
    // 0xd0dc10: b.gt            #0xd0dc54
    // 0xd0dc14: ldur            d0, [fp, #-0x100]
    // 0xd0dc18: ldur            d1, [fp, #-0xf8]
    // 0xd0dc1c: d2 = 48.000000
    //     0xd0dc1c: ldr             d2, [PP, #0x5650]  ; [pp+0x5650] IMM: double(48) from 0x4048000000000000
    // 0xd0dc20: fadd            d3, d1, d2
    // 0xd0dc24: r17 = -264
    //     0xd0dc24: mov             x17, #-0x108
    // 0xd0dc28: str             d3, [fp, x17]
    // 0xd0dc2c: fadd            d1, d0, d2
    // 0xd0dc30: stur            d1, [fp, #-0xf0]
    // 0xd0dc34: r0 = Size()
    //     0xd0dc34: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xd0dc38: r17 = -264
    //     0xd0dc38: mov             x17, #-0x108
    // 0xd0dc3c: ldr             d0, [fp, x17]
    // 0xd0dc40: StoreField: r0->field_7 = d0
    //     0xd0dc40: stur            d0, [x0, #7]
    // 0xd0dc44: ldur            d0, [fp, #-0xf0]
    // 0xd0dc48: StoreField: r0->field_f = d0
    //     0xd0dc48: stur            d0, [x0, #0xf]
    // 0xd0dc4c: mov             x2, x0
    // 0xd0dc50: b               #0xd0dc58
    // 0xd0dc54: r2 = Instance_Size
    //     0xd0dc54: ldr             x2, [PP, #0x7f28]  ; [pp+0x7f28] Obj!Size@12a74d1
    // 0xd0dc58: ldur            x0, [fp, #-0x18]
    // 0xd0dc5c: stur            x2, [fp, #-0x20]
    // 0xd0dc60: LoadField: r1 = r0->field_b
    //     0xd0dc60: ldur            w1, [x0, #0xb]
    // 0xd0dc64: DecompressPointer r1
    //     0xd0dc64: add             x1, x1, HEAP, lsl #32
    // 0xd0dc68: cmp             w1, NULL
    // 0xd0dc6c: b.eq            #0xd0dc78
    // 0xd0dc70: r3 = true
    //     0xd0dc70: add             x3, NULL, #0x20  ; true
    // 0xd0dc74: b               #0xd0dc7c
    // 0xd0dc78: r3 = false
    //     0xd0dc78: add             x3, NULL, #0x30  ; false
    // 0xd0dc7c: ldur            x0, [fp, #-0x40]
    // 0xd0dc80: ldur            x1, [fp, #-0x48]
    // 0xd0dc84: stur            x3, [fp, #-0x18]
    // 0xd0dc88: cmp             w0, NULL
    // 0xd0dc8c: b.eq            #0xd0de9c
    // 0xd0dc90: cmp             w1, NULL
    // 0xd0dc94: b.ne            #0xd0dca0
    // 0xd0dc98: r4 = Null
    //     0xd0dc98: mov             x4, NULL
    // 0xd0dc9c: b               #0xd0dcb8
    // 0xd0dca0: ldur            x16, [fp, #-0x58]
    // 0xd0dca4: str             x16, [SP]
    // 0xd0dca8: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0xd0dca8: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0xd0dcac: ldr             x4, [x4, #0x7f0]
    // 0xd0dcb0: r0 = copyWith()
    //     0xd0dcb0: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xd0dcb4: mov             x4, x0
    // 0xd0dcb8: ldur            x1, [fp, #-0x30]
    // 0xd0dcbc: ldur            x3, [fp, #-0x50]
    // 0xd0dcc0: stur            x4, [fp, #-0x28]
    // 0xd0dcc4: r0 = LoadClassIdInstr(r1)
    //     0xd0dcc4: ldur            x0, [x1, #-1]
    //     0xd0dcc8: ubfx            x0, x0, #0xc, #0x14
    // 0xd0dccc: ldur            x2, [fp, #-0x98]
    // 0xd0dcd0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xd0dcd0: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xd0dcd4: r0 = GDT[cid_x0 + -0xff6]()
    //     0xd0dcd4: sub             lr, x0, #0xff6
    //     0xd0dcd8: ldr             lr, [x21, lr, lsl #3]
    //     0xd0dcdc: blr             lr
    // 0xd0dce0: mov             x1, x0
    // 0xd0dce4: ldur            x0, [fp, #-0x50]
    // 0xd0dce8: stur            x1, [fp, #-0x38]
    // 0xd0dcec: cmp             w0, NULL
    // 0xd0dcf0: b.ne            #0xd0dd00
    // 0xd0dcf4: r10 = Instance_MaterialType
    //     0xd0dcf4: add             x10, PP, #0x8c, lsl #12  ; [pp+0x8c618] Obj!MaterialType@12c5361
    //     0xd0dcf8: ldr             x10, [x10, #0x618]
    // 0xd0dcfc: b               #0xd0dd08
    // 0xd0dd00: r10 = Instance_MaterialType
    //     0xd0dd00: add             x10, PP, #0x8f, lsl #12  ; [pp+0x8fca8] Obj!MaterialType@12c5381
    //     0xd0dd04: ldr             x10, [x10, #0xca8]
    // 0xd0dd08: ldur            x4, [fp, #-0x40]
    // 0xd0dd0c: ldur            x9, [fp, #-0x60]
    // 0xd0dd10: ldur            x8, [fp, #-0x68]
    // 0xd0dd14: ldur            x7, [fp, #-0x10]
    // 0xd0dd18: ldur            x6, [fp, #-0x78]
    // 0xd0dd1c: ldur            x5, [fp, #-8]
    // 0xd0dd20: ldur            x3, [fp, #-0x20]
    // 0xd0dd24: ldur            x2, [fp, #-0x28]
    // 0xd0dd28: stur            x10, [fp, #-0x30]
    // 0xd0dd2c: r0 = Material()
    //     0xd0dd2c: bl              #0x8a54b0  ; AllocateMaterialStub -> Material (size=0x44)
    // 0xd0dd30: mov             x1, x0
    // 0xd0dd34: ldur            x0, [fp, #-0x30]
    // 0xd0dd38: stur            x1, [fp, #-0x48]
    // 0xd0dd3c: StoreField: r1->field_f = r0
    //     0xd0dd3c: stur            w0, [x1, #0xf]
    // 0xd0dd40: ldur            x0, [fp, #-0x40]
    // 0xd0dd44: LoadField: d0 = r0->field_7
    //     0xd0dd44: ldur            d0, [x0, #7]
    // 0xd0dd48: ArrayStore: r1[0] = d0  ; List_8
    //     0xd0dd48: stur            d0, [x1, #0x17]
    // 0xd0dd4c: ldur            x0, [fp, #-0x50]
    // 0xd0dd50: StoreField: r1->field_1f = r0
    //     0xd0dd50: stur            w0, [x1, #0x1f]
    // 0xd0dd54: ldur            x0, [fp, #-0x60]
    // 0xd0dd58: StoreField: r1->field_23 = r0
    //     0xd0dd58: stur            w0, [x1, #0x23]
    // 0xd0dd5c: ldur            x0, [fp, #-0x68]
    // 0xd0dd60: StoreField: r1->field_27 = r0
    //     0xd0dd60: stur            w0, [x1, #0x27]
    // 0xd0dd64: ldur            x0, [fp, #-0x28]
    // 0xd0dd68: StoreField: r1->field_2b = r0
    //     0xd0dd68: stur            w0, [x1, #0x2b]
    // 0xd0dd6c: ldur            x0, [fp, #-0x38]
    // 0xd0dd70: StoreField: r1->field_2f = r0
    //     0xd0dd70: stur            w0, [x1, #0x2f]
    // 0xd0dd74: r0 = false
    //     0xd0dd74: add             x0, NULL, #0x30  ; false
    // 0xd0dd78: StoreField: r1->field_33 = r0
    //     0xd0dd78: stur            w0, [x1, #0x33]
    // 0xd0dd7c: ldur            x2, [fp, #-0x10]
    // 0xd0dd80: StoreField: r1->field_37 = r2
    //     0xd0dd80: stur            w2, [x1, #0x37]
    // 0xd0dd84: r2 = Instance_Duration
    //     0xd0dd84: add             x2, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xd0dd88: ldr             x2, [x2, #0x318]
    // 0xd0dd8c: StoreField: r1->field_3b = r2
    //     0xd0dd8c: stur            w2, [x1, #0x3b]
    // 0xd0dd90: ldur            x2, [fp, #-8]
    // 0xd0dd94: StoreField: r1->field_b = r2
    //     0xd0dd94: stur            w2, [x1, #0xb]
    // 0xd0dd98: StoreField: r1->field_13 = r0
    //     0xd0dd98: stur            w0, [x1, #0x13]
    // 0xd0dd9c: r0 = ConstrainedBox()
    //     0xd0dd9c: bl              #0xd0a588  ; AllocateConstrainedBoxStub -> ConstrainedBox (size=0x14)
    // 0xd0dda0: mov             x1, x0
    // 0xd0dda4: ldur            x0, [fp, #-0x78]
    // 0xd0dda8: stur            x1, [fp, #-8]
    // 0xd0ddac: StoreField: r1->field_f = r0
    //     0xd0ddac: stur            w0, [x1, #0xf]
    // 0xd0ddb0: ldur            x0, [fp, #-0x48]
    // 0xd0ddb4: StoreField: r1->field_b = r0
    //     0xd0ddb4: stur            w0, [x1, #0xb]
    // 0xd0ddb8: r0 = _InputPadding()
    //     0xd0ddb8: bl              #0xd0dea0  ; Allocate_InputPaddingStub -> _InputPadding (size=0x14)
    // 0xd0ddbc: mov             x1, x0
    // 0xd0ddc0: ldur            x0, [fp, #-0x20]
    // 0xd0ddc4: stur            x1, [fp, #-0x10]
    // 0xd0ddc8: StoreField: r1->field_f = r0
    //     0xd0ddc8: stur            w0, [x1, #0xf]
    // 0xd0ddcc: ldur            x0, [fp, #-8]
    // 0xd0ddd0: StoreField: r1->field_b = r0
    //     0xd0ddd0: stur            w0, [x1, #0xb]
    // 0xd0ddd4: r0 = Semantics()
    //     0xd0ddd4: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xd0ddd8: stur            x0, [fp, #-8]
    // 0xd0dddc: r16 = true
    //     0xd0dddc: add             x16, NULL, #0x20  ; true
    // 0xd0dde0: r30 = true
    //     0xd0dde0: add             lr, NULL, #0x20  ; true
    // 0xd0dde4: stp             lr, x16, [SP, #0x10]
    // 0xd0dde8: ldur            x16, [fp, #-0x18]
    // 0xd0ddec: ldur            lr, [fp, #-0x10]
    // 0xd0ddf0: stp             lr, x16, [SP]
    // 0xd0ddf4: mov             x1, x0
    // 0xd0ddf8: r4 = const [0, 0x5, 0x4, 0x1, button, 0x2, child, 0x4, container, 0x1, enabled, 0x3, null]
    //     0xd0ddf8: add             x4, PP, #0x90, lsl #12  ; [pp+0x90628] List(13) [0, 0x5, 0x4, 0x1, "button", 0x2, "child", 0x4, "container", 0x1, "enabled", 0x3, Null]
    //     0xd0ddfc: ldr             x4, [x4, #0x628]
    // 0xd0de00: r0 = Semantics()
    //     0xd0de00: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xd0de04: ldur            x0, [fp, #-8]
    // 0xd0de08: LeaveFrame
    //     0xd0de08: mov             SP, fp
    //     0xd0de0c: ldp             fp, lr, [SP], #0x10
    // 0xd0de10: ret
    //     0xd0de10: ret             
    // 0xd0de14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0de14: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0de18: b               #0xd0ce48
    // 0xd0de1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0de1c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0de20: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0de20: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0de24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0de24: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0de28: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0de28: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0de2c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0de2c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0de30: r0 = NullCastErrorSharedWithFPURegs()
    //     0xd0de30: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xd0de34: SaveReg d0
    //     0xd0de34: str             q0, [SP, #-0x10]!
    // 0xd0de38: SaveReg r0
    //     0xd0de38: str             x0, [SP, #-8]!
    // 0xd0de3c: r0 = AllocateDouble()
    //     0xd0de3c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd0de40: mov             x1, x0
    // 0xd0de44: RestoreReg r0
    //     0xd0de44: ldr             x0, [SP], #8
    // 0xd0de48: RestoreReg d0
    //     0xd0de48: ldr             q0, [SP], #0x10
    // 0xd0de4c: b               #0xd0d5d4
    // 0xd0de50: SaveReg d0
    //     0xd0de50: str             q0, [SP, #-0x10]!
    // 0xd0de54: SaveReg r1
    //     0xd0de54: str             x1, [SP, #-8]!
    // 0xd0de58: r0 = AllocateDouble()
    //     0xd0de58: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd0de5c: RestoreReg r1
    //     0xd0de5c: ldr             x1, [SP], #8
    // 0xd0de60: RestoreReg d0
    //     0xd0de60: ldr             q0, [SP], #0x10
    // 0xd0de64: b               #0xd0d640
    // 0xd0de68: r0 = NullCastErrorSharedWithFPURegs()
    //     0xd0de68: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xd0de6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0de6c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0de70: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0de70: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0de74: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0de74: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0de78: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0de78: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0de7c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0de7c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0de80: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0de80: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0de84: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0de84: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0de88: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0de88: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0de8c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0de8c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0de90: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0de90: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0de94: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0de94: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0de98: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0de98: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0de9c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0de9c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ statesController(/* No info */) {
    // ** addr: 0xd0dee8, size: 0x58
    // 0xd0dee8: EnterFrame
    //     0xd0dee8: stp             fp, lr, [SP, #-0x10]!
    //     0xd0deec: mov             fp, SP
    // 0xd0def0: LoadField: r2 = r1->field_b
    //     0xd0def0: ldur            w2, [x1, #0xb]
    // 0xd0def4: DecompressPointer r2
    //     0xd0def4: add             x2, x2, HEAP, lsl #32
    // 0xd0def8: cmp             w2, NULL
    // 0xd0defc: b.eq            #0xd0df38
    // 0xd0df00: LoadField: r3 = r2->field_2b
    //     0xd0df00: ldur            w3, [x2, #0x2b]
    // 0xd0df04: DecompressPointer r3
    //     0xd0df04: add             x3, x3, HEAP, lsl #32
    // 0xd0df08: cmp             w3, NULL
    // 0xd0df0c: b.ne            #0xd0df28
    // 0xd0df10: LoadField: r2 = r1->field_27
    //     0xd0df10: ldur            w2, [x1, #0x27]
    // 0xd0df14: DecompressPointer r2
    //     0xd0df14: add             x2, x2, HEAP, lsl #32
    // 0xd0df18: cmp             w2, NULL
    // 0xd0df1c: b.eq            #0xd0df3c
    // 0xd0df20: mov             x0, x2
    // 0xd0df24: b               #0xd0df2c
    // 0xd0df28: mov             x0, x3
    // 0xd0df2c: LeaveFrame
    //     0xd0df2c: mov             SP, fp
    //     0xd0df30: ldp             fp, lr, [SP], #0x10
    // 0xd0df34: ret
    //     0xd0df34: ret             
    // 0xd0df38: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0df38: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0df3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0df3c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, AnimationStatus) {
    // ** addr: 0xd0e540, size: 0x74
    // 0xd0e540: EnterFrame
    //     0xd0e540: stp             fp, lr, [SP, #-0x10]!
    //     0xd0e544: mov             fp, SP
    // 0xd0e548: AllocStack(0x8)
    //     0xd0e548: sub             SP, SP, #8
    // 0xd0e54c: SetupParameters([dynamic _ /* r0 */])
    //     0xd0e54c: ldr             x0, [fp, #0x18]
    //     0xd0e550: ldur            w1, [x0, #0x17]
    //     0xd0e554: add             x1, x1, HEAP, lsl #32
    // 0xd0e558: CheckStackOverflow
    //     0xd0e558: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0e55c: cmp             SP, x16
    //     0xd0e560: b.ls            #0xd0e5ac
    // 0xd0e564: ldr             x0, [fp, #0x10]
    // 0xd0e568: r16 = Instance_AnimationStatus
    //     0xd0e568: ldr             x16, [PP, #0x51a0]  ; [pp+0x51a0] Obj!AnimationStatus@12c61a1
    // 0xd0e56c: cmp             w0, w16
    // 0xd0e570: b.ne            #0xd0e59c
    // 0xd0e574: LoadField: r0 = r1->field_f
    //     0xd0e574: ldur            w0, [x1, #0xf]
    // 0xd0e578: DecompressPointer r0
    //     0xd0e578: add             x0, x0, HEAP, lsl #32
    // 0xd0e57c: stur            x0, [fp, #-8]
    // 0xd0e580: r1 = Function '<anonymous closure>':.
    //     0xd0e580: add             x1, PP, #0x90, lsl #12  ; [pp+0x90630] Function: [dart:ui] Shader::Shader._ (0x13cf838)
    //     0xd0e584: ldr             x1, [x1, #0x630]
    // 0xd0e588: r2 = Null
    //     0xd0e588: mov             x2, NULL
    // 0xd0e58c: r0 = AllocateClosure()
    //     0xd0e58c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd0e590: ldur            x1, [fp, #-8]
    // 0xd0e594: mov             x2, x0
    // 0xd0e598: r0 = setState()
    //     0xd0e598: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xd0e59c: r0 = Null
    //     0xd0e59c: mov             x0, NULL
    // 0xd0e5a0: LeaveFrame
    //     0xd0e5a0: mov             SP, fp
    //     0xd0e5a4: ldp             fp, lr, [SP], #0x10
    // 0xd0e5a8: ret
    //     0xd0e5a8: ret             
    // 0xd0e5ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0e5ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0e5b0: b               #0xd0e564
  }
  [closure] InteractiveInkFeatureFactory? <anonymous closure>(dynamic, ButtonStyle?) {
    // ** addr: 0xd0e5b4, size: 0x50
    // 0xd0e5b4: EnterFrame
    //     0xd0e5b4: stp             fp, lr, [SP, #-0x10]!
    //     0xd0e5b8: mov             fp, SP
    // 0xd0e5bc: CheckStackOverflow
    //     0xd0e5bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0e5c0: cmp             SP, x16
    //     0xd0e5c4: b.ls            #0xd0e5fc
    // 0xd0e5c8: ldr             x1, [fp, #0x10]
    // 0xd0e5cc: cmp             w1, NULL
    // 0xd0e5d0: b.ne            #0xd0e5dc
    // 0xd0e5d4: r0 = Null
    //     0xd0e5d4: mov             x0, NULL
    // 0xd0e5d8: b               #0xd0e5f0
    // 0xd0e5dc: r0 = LoadClassIdInstr(r1)
    //     0xd0e5dc: ldur            x0, [x1, #-1]
    //     0xd0e5e0: ubfx            x0, x0, #0xc, #0x14
    // 0xd0e5e4: r0 = GDT[cid_x0 + 0xed5]()
    //     0xd0e5e4: add             lr, x0, #0xed5
    //     0xd0e5e8: ldr             lr, [x21, lr, lsl #3]
    //     0xd0e5ec: blr             lr
    // 0xd0e5f0: LeaveFrame
    //     0xd0e5f0: mov             SP, fp
    //     0xd0e5f4: ldp             fp, lr, [SP], #0x10
    // 0xd0e5f8: ret
    //     0xd0e5f8: ret             
    // 0xd0e5fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0e5fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0e600: b               #0xd0e5c8
  }
  [closure] AlignmentGeometry? <anonymous closure>(dynamic, ButtonStyle?) {
    // ** addr: 0xd0e604, size: 0x24
    // 0xd0e604: ldr             x1, [SP]
    // 0xd0e608: cmp             w1, NULL
    // 0xd0e60c: b.ne            #0xd0e618
    // 0xd0e610: r0 = Null
    //     0xd0e610: mov             x0, NULL
    // 0xd0e614: b               #0xd0e624
    // 0xd0e618: LoadField: r2 = r1->field_5b
    //     0xd0e618: ldur            w2, [x1, #0x5b]
    // 0xd0e61c: DecompressPointer r2
    //     0xd0e61c: add             x2, x2, HEAP, lsl #32
    // 0xd0e620: mov             x0, x2
    // 0xd0e624: ret
    //     0xd0e624: ret             
  }
  [closure] bool? <anonymous closure>(dynamic, ButtonStyle?) {
    // ** addr: 0xd0e658, size: 0x24
    // 0xd0e658: ldr             x1, [SP]
    // 0xd0e65c: cmp             w1, NULL
    // 0xd0e660: b.ne            #0xd0e66c
    // 0xd0e664: r0 = Null
    //     0xd0e664: mov             x0, NULL
    // 0xd0e668: b               #0xd0e678
    // 0xd0e66c: LoadField: r2 = r1->field_57
    //     0xd0e66c: ldur            w2, [x1, #0x57]
    // 0xd0e670: DecompressPointer r2
    //     0xd0e670: add             x2, x2, HEAP, lsl #32
    // 0xd0e674: mov             x0, x2
    // 0xd0e678: ret
    //     0xd0e678: ret             
  }
  [closure] Duration? <anonymous closure>(dynamic, ButtonStyle?) {
    // ** addr: 0xd0e67c, size: 0x24
    // 0xd0e67c: ldr             x1, [SP]
    // 0xd0e680: cmp             w1, NULL
    // 0xd0e684: b.ne            #0xd0e690
    // 0xd0e688: r0 = Null
    //     0xd0e688: mov             x0, NULL
    // 0xd0e68c: b               #0xd0e69c
    // 0xd0e690: LoadField: r2 = r1->field_53
    //     0xd0e690: ldur            w2, [x1, #0x53]
    // 0xd0e694: DecompressPointer r2
    //     0xd0e694: add             x2, x2, HEAP, lsl #32
    // 0xd0e698: mov             x0, x2
    // 0xd0e69c: ret
    //     0xd0e69c: ret             
  }
  [closure] MaterialTapTargetSize? <anonymous closure>(dynamic, ButtonStyle?) {
    // ** addr: 0xd0e6a0, size: 0x50
    // 0xd0e6a0: EnterFrame
    //     0xd0e6a0: stp             fp, lr, [SP, #-0x10]!
    //     0xd0e6a4: mov             fp, SP
    // 0xd0e6a8: CheckStackOverflow
    //     0xd0e6a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0e6ac: cmp             SP, x16
    //     0xd0e6b0: b.ls            #0xd0e6e8
    // 0xd0e6b4: ldr             x1, [fp, #0x10]
    // 0xd0e6b8: cmp             w1, NULL
    // 0xd0e6bc: b.ne            #0xd0e6c8
    // 0xd0e6c0: r0 = Null
    //     0xd0e6c0: mov             x0, NULL
    // 0xd0e6c4: b               #0xd0e6dc
    // 0xd0e6c8: r0 = LoadClassIdInstr(r1)
    //     0xd0e6c8: ldur            x0, [x1, #-1]
    //     0xd0e6cc: ubfx            x0, x0, #0xc, #0x14
    // 0xd0e6d0: r0 = GDT[cid_x0 + 0xef1]()
    //     0xd0e6d0: add             lr, x0, #0xef1
    //     0xd0e6d4: ldr             lr, [x21, lr, lsl #3]
    //     0xd0e6d8: blr             lr
    // 0xd0e6dc: LeaveFrame
    //     0xd0e6dc: mov             SP, fp
    //     0xd0e6e0: ldp             fp, lr, [SP], #0x10
    // 0xd0e6e4: ret
    //     0xd0e6e4: ret             
    // 0xd0e6e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0e6e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0e6ec: b               #0xd0e6b4
  }
  [closure] VisualDensity? <anonymous closure>(dynamic, ButtonStyle?) {
    // ** addr: 0xd0e6f0, size: 0x50
    // 0xd0e6f0: EnterFrame
    //     0xd0e6f0: stp             fp, lr, [SP, #-0x10]!
    //     0xd0e6f4: mov             fp, SP
    // 0xd0e6f8: CheckStackOverflow
    //     0xd0e6f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0e6fc: cmp             SP, x16
    //     0xd0e700: b.ls            #0xd0e738
    // 0xd0e704: ldr             x1, [fp, #0x10]
    // 0xd0e708: cmp             w1, NULL
    // 0xd0e70c: b.ne            #0xd0e718
    // 0xd0e710: r0 = Null
    //     0xd0e710: mov             x0, NULL
    // 0xd0e714: b               #0xd0e72c
    // 0xd0e718: r0 = LoadClassIdInstr(r1)
    //     0xd0e718: ldur            x0, [x1, #-1]
    //     0xd0e71c: ubfx            x0, x0, #0xc, #0x14
    // 0xd0e720: r0 = GDT[cid_x0 + 0xef9]()
    //     0xd0e720: add             lr, x0, #0xef9
    //     0xd0e724: ldr             lr, [x21, lr, lsl #3]
    //     0xd0e728: blr             lr
    // 0xd0e72c: LeaveFrame
    //     0xd0e72c: mov             SP, fp
    //     0xd0e730: ldp             fp, lr, [SP], #0x10
    // 0xd0e734: ret
    //     0xd0e734: ret             
    // 0xd0e738: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0e738: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0e73c: b               #0xd0e704
  }
  [closure] Color? <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xd0e740, size: 0x98
    // 0xd0e740: EnterFrame
    //     0xd0e740: stp             fp, lr, [SP, #-0x10]!
    //     0xd0e744: mov             fp, SP
    // 0xd0e748: AllocStack(0x28)
    //     0xd0e748: sub             SP, SP, #0x28
    // 0xd0e74c: SetupParameters([dynamic _ /* r0 */])
    //     0xd0e74c: ldr             x0, [fp, #0x18]
    //     0xd0e750: ldur            w1, [x0, #0x17]
    //     0xd0e754: add             x1, x1, HEAP, lsl #32
    //     0xd0e758: stur            x1, [fp, #-8]
    // 0xd0e75c: CheckStackOverflow
    //     0xd0e75c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0e760: cmp             SP, x16
    //     0xd0e764: b.ls            #0xd0e7d0
    // 0xd0e768: r1 = 1
    //     0xd0e768: mov             x1, #1
    // 0xd0e76c: r0 = AllocateContext()
    //     0xd0e76c: bl              #0x13de838  ; AllocateContextStub
    // 0xd0e770: mov             x1, x0
    // 0xd0e774: ldur            x0, [fp, #-8]
    // 0xd0e778: StoreField: r1->field_b = r0
    //     0xd0e778: stur            w0, [x1, #0xb]
    // 0xd0e77c: ldr             x2, [fp, #0x10]
    // 0xd0e780: StoreField: r1->field_f = r2
    //     0xd0e780: stur            w2, [x1, #0xf]
    // 0xd0e784: LoadField: r3 = r0->field_1f
    //     0xd0e784: ldur            w3, [x0, #0x1f]
    // 0xd0e788: DecompressPointer r3
    //     0xd0e788: add             x3, x3, HEAP, lsl #32
    // 0xd0e78c: mov             x2, x1
    // 0xd0e790: stur            x3, [fp, #-0x10]
    // 0xd0e794: r1 = Function '<anonymous closure>':.
    //     0xd0e794: add             x1, PP, #0x90, lsl #12  ; [pp+0x90638] AnonymousClosure: (0xd0e7d8), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0xd0ce1c)
    //     0xd0e798: ldr             x1, [x1, #0x638]
    // 0xd0e79c: r0 = AllocateClosure()
    //     0xd0e79c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd0e7a0: r16 = <Color>
    //     0xd0e7a0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xd0e7a4: ldr             x16, [x16, #0xa90]
    // 0xd0e7a8: ldur            lr, [fp, #-0x10]
    // 0xd0e7ac: stp             lr, x16, [SP, #8]
    // 0xd0e7b0: str             x0, [SP]
    // 0xd0e7b4: ldur            x0, [fp, #-0x10]
    // 0xd0e7b8: ClosureCall
    //     0xd0e7b8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0xd0e7bc: ldur            x2, [x0, #0x1f]
    //     0xd0e7c0: blr             x2
    // 0xd0e7c4: LeaveFrame
    //     0xd0e7c4: mov             SP, fp
    //     0xd0e7c8: ldp             fp, lr, [SP], #0x10
    // 0xd0e7cc: ret
    //     0xd0e7cc: ret             
    // 0xd0e7d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0e7d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0e7d4: b               #0xd0e768
  }
  [closure] Color? <anonymous closure>(dynamic, ButtonStyle?) {
    // ** addr: 0xd0e7d8, size: 0xb0
    // 0xd0e7d8: EnterFrame
    //     0xd0e7d8: stp             fp, lr, [SP, #-0x10]!
    //     0xd0e7dc: mov             fp, SP
    // 0xd0e7e0: AllocStack(0x8)
    //     0xd0e7e0: sub             SP, SP, #8
    // 0xd0e7e4: SetupParameters([dynamic _ /* r0 */])
    //     0xd0e7e4: ldr             x0, [fp, #0x18]
    //     0xd0e7e8: ldur            w2, [x0, #0x17]
    //     0xd0e7ec: add             x2, x2, HEAP, lsl #32
    //     0xd0e7f0: stur            x2, [fp, #-8]
    // 0xd0e7f4: CheckStackOverflow
    //     0xd0e7f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0e7f8: cmp             SP, x16
    //     0xd0e7fc: b.ls            #0xd0e880
    // 0xd0e800: ldr             x1, [fp, #0x10]
    // 0xd0e804: cmp             w1, NULL
    // 0xd0e808: b.ne            #0xd0e814
    // 0xd0e80c: r0 = Null
    //     0xd0e80c: mov             x0, NULL
    // 0xd0e810: b               #0xd0e874
    // 0xd0e814: r0 = LoadClassIdInstr(r1)
    //     0xd0e814: ldur            x0, [x1, #-1]
    //     0xd0e818: ubfx            x0, x0, #0xc, #0x14
    // 0xd0e81c: r0 = GDT[cid_x0 + 0xf41]()
    //     0xd0e81c: add             lr, x0, #0xf41
    //     0xd0e820: ldr             lr, [x21, lr, lsl #3]
    //     0xd0e824: blr             lr
    // 0xd0e828: cmp             w0, NULL
    // 0xd0e82c: b.ne            #0xd0e838
    // 0xd0e830: r1 = Null
    //     0xd0e830: mov             x1, NULL
    // 0xd0e834: b               #0xd0e870
    // 0xd0e838: ldur            x1, [fp, #-8]
    // 0xd0e83c: LoadField: r2 = r1->field_f
    //     0xd0e83c: ldur            w2, [x1, #0xf]
    // 0xd0e840: DecompressPointer r2
    //     0xd0e840: add             x2, x2, HEAP, lsl #32
    // 0xd0e844: r1 = LoadClassIdInstr(r0)
    //     0xd0e844: ldur            x1, [x0, #-1]
    //     0xd0e848: ubfx            x1, x1, #0xc, #0x14
    // 0xd0e84c: mov             x16, x0
    // 0xd0e850: mov             x0, x1
    // 0xd0e854: mov             x1, x16
    // 0xd0e858: r0 = GDT[cid_x0 + 0x17c77]()
    //     0xd0e858: mov             x17, #0x7c77
    //     0xd0e85c: movk            x17, #1, lsl #16
    //     0xd0e860: add             lr, x0, x17
    //     0xd0e864: ldr             lr, [x21, lr, lsl #3]
    //     0xd0e868: blr             lr
    // 0xd0e86c: mov             x1, x0
    // 0xd0e870: mov             x0, x1
    // 0xd0e874: LeaveFrame
    //     0xd0e874: mov             SP, fp
    //     0xd0e878: ldp             fp, lr, [SP], #0x10
    // 0xd0e87c: ret
    //     0xd0e87c: ret             
    // 0xd0e880: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0e880: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0e884: b               #0xd0e800
  }
  [closure] MouseCursor? <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xd0e888, size: 0x94
    // 0xd0e888: EnterFrame
    //     0xd0e888: stp             fp, lr, [SP, #-0x10]!
    //     0xd0e88c: mov             fp, SP
    // 0xd0e890: AllocStack(0x28)
    //     0xd0e890: sub             SP, SP, #0x28
    // 0xd0e894: SetupParameters([dynamic _ /* r0 */])
    //     0xd0e894: ldr             x0, [fp, #0x18]
    //     0xd0e898: ldur            w1, [x0, #0x17]
    //     0xd0e89c: add             x1, x1, HEAP, lsl #32
    //     0xd0e8a0: stur            x1, [fp, #-8]
    // 0xd0e8a4: CheckStackOverflow
    //     0xd0e8a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0e8a8: cmp             SP, x16
    //     0xd0e8ac: b.ls            #0xd0e914
    // 0xd0e8b0: r1 = 1
    //     0xd0e8b0: mov             x1, #1
    // 0xd0e8b4: r0 = AllocateContext()
    //     0xd0e8b4: bl              #0x13de838  ; AllocateContextStub
    // 0xd0e8b8: mov             x1, x0
    // 0xd0e8bc: ldur            x0, [fp, #-8]
    // 0xd0e8c0: StoreField: r1->field_b = r0
    //     0xd0e8c0: stur            w0, [x1, #0xb]
    // 0xd0e8c4: ldr             x2, [fp, #0x10]
    // 0xd0e8c8: StoreField: r1->field_f = r2
    //     0xd0e8c8: stur            w2, [x1, #0xf]
    // 0xd0e8cc: LoadField: r3 = r0->field_1f
    //     0xd0e8cc: ldur            w3, [x0, #0x1f]
    // 0xd0e8d0: DecompressPointer r3
    //     0xd0e8d0: add             x3, x3, HEAP, lsl #32
    // 0xd0e8d4: mov             x2, x1
    // 0xd0e8d8: stur            x3, [fp, #-0x10]
    // 0xd0e8dc: r1 = Function '<anonymous closure>':.
    //     0xd0e8dc: add             x1, PP, #0x90, lsl #12  ; [pp+0x90640] AnonymousClosure: (0xd0e91c), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0xd0ce1c)
    //     0xd0e8e0: ldr             x1, [x1, #0x640]
    // 0xd0e8e4: r0 = AllocateClosure()
    //     0xd0e8e4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd0e8e8: r16 = <MouseCursor>
    //     0xd0e8e8: ldr             x16, [PP, #0x21a8]  ; [pp+0x21a8] TypeArguments: <MouseCursor>
    // 0xd0e8ec: ldur            lr, [fp, #-0x10]
    // 0xd0e8f0: stp             lr, x16, [SP, #8]
    // 0xd0e8f4: str             x0, [SP]
    // 0xd0e8f8: ldur            x0, [fp, #-0x10]
    // 0xd0e8fc: ClosureCall
    //     0xd0e8fc: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0xd0e900: ldur            x2, [x0, #0x1f]
    //     0xd0e904: blr             x2
    // 0xd0e908: LeaveFrame
    //     0xd0e908: mov             SP, fp
    //     0xd0e90c: ldp             fp, lr, [SP], #0x10
    // 0xd0e910: ret
    //     0xd0e910: ret             
    // 0xd0e914: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0e914: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0e918: b               #0xd0e8b0
  }
  [closure] MouseCursor? <anonymous closure>(dynamic, ButtonStyle?) {
    // ** addr: 0xd0e91c, size: 0xb0
    // 0xd0e91c: EnterFrame
    //     0xd0e91c: stp             fp, lr, [SP, #-0x10]!
    //     0xd0e920: mov             fp, SP
    // 0xd0e924: AllocStack(0x8)
    //     0xd0e924: sub             SP, SP, #8
    // 0xd0e928: SetupParameters([dynamic _ /* r0 */])
    //     0xd0e928: ldr             x0, [fp, #0x18]
    //     0xd0e92c: ldur            w2, [x0, #0x17]
    //     0xd0e930: add             x2, x2, HEAP, lsl #32
    //     0xd0e934: stur            x2, [fp, #-8]
    // 0xd0e938: CheckStackOverflow
    //     0xd0e938: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0e93c: cmp             SP, x16
    //     0xd0e940: b.ls            #0xd0e9c4
    // 0xd0e944: ldr             x1, [fp, #0x10]
    // 0xd0e948: cmp             w1, NULL
    // 0xd0e94c: b.ne            #0xd0e958
    // 0xd0e950: r0 = Null
    //     0xd0e950: mov             x0, NULL
    // 0xd0e954: b               #0xd0e9b8
    // 0xd0e958: r0 = LoadClassIdInstr(r1)
    //     0xd0e958: ldur            x0, [x1, #-1]
    //     0xd0e95c: ubfx            x0, x0, #0xc, #0x14
    // 0xd0e960: r0 = GDT[cid_x0 + 0xf13]()
    //     0xd0e960: add             lr, x0, #0xf13
    //     0xd0e964: ldr             lr, [x21, lr, lsl #3]
    //     0xd0e968: blr             lr
    // 0xd0e96c: cmp             w0, NULL
    // 0xd0e970: b.ne            #0xd0e97c
    // 0xd0e974: r1 = Null
    //     0xd0e974: mov             x1, NULL
    // 0xd0e978: b               #0xd0e9b4
    // 0xd0e97c: ldur            x1, [fp, #-8]
    // 0xd0e980: LoadField: r2 = r1->field_f
    //     0xd0e980: ldur            w2, [x1, #0xf]
    // 0xd0e984: DecompressPointer r2
    //     0xd0e984: add             x2, x2, HEAP, lsl #32
    // 0xd0e988: r1 = LoadClassIdInstr(r0)
    //     0xd0e988: ldur            x1, [x0, #-1]
    //     0xd0e98c: ubfx            x1, x1, #0xc, #0x14
    // 0xd0e990: mov             x16, x0
    // 0xd0e994: mov             x0, x1
    // 0xd0e998: mov             x1, x16
    // 0xd0e99c: r0 = GDT[cid_x0 + 0x17c77]()
    //     0xd0e99c: mov             x17, #0x7c77
    //     0xd0e9a0: movk            x17, #1, lsl #16
    //     0xd0e9a4: add             lr, x0, x17
    //     0xd0e9a8: ldr             lr, [x21, lr, lsl #3]
    //     0xd0e9ac: blr             lr
    // 0xd0e9b0: mov             x1, x0
    // 0xd0e9b4: mov             x0, x1
    // 0xd0e9b8: LeaveFrame
    //     0xd0e9b8: mov             SP, fp
    //     0xd0e9bc: ldp             fp, lr, [SP], #0x10
    // 0xd0e9c0: ret
    //     0xd0e9c0: ret             
    // 0xd0e9c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0e9c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0e9c8: b               #0xd0e944
  }
  [closure] WidgetStateProperty<OutlinedBorder?>? <anonymous closure>(dynamic, ButtonStyle?) {
    // ** addr: 0xd0e9cc, size: 0x50
    // 0xd0e9cc: EnterFrame
    //     0xd0e9cc: stp             fp, lr, [SP, #-0x10]!
    //     0xd0e9d0: mov             fp, SP
    // 0xd0e9d4: CheckStackOverflow
    //     0xd0e9d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0e9d8: cmp             SP, x16
    //     0xd0e9dc: b.ls            #0xd0ea14
    // 0xd0e9e0: ldr             x1, [fp, #0x10]
    // 0xd0e9e4: cmp             w1, NULL
    // 0xd0e9e8: b.ne            #0xd0e9f4
    // 0xd0e9ec: r0 = Null
    //     0xd0e9ec: mov             x0, NULL
    // 0xd0e9f0: b               #0xd0ea08
    // 0xd0e9f4: r0 = LoadClassIdInstr(r1)
    //     0xd0e9f4: ldur            x0, [x1, #-1]
    //     0xd0e9f8: ubfx            x0, x0, #0xc, #0x14
    // 0xd0e9fc: r0 = GDT[cid_x0 + 0xf2e]()
    //     0xd0e9fc: add             lr, x0, #0xf2e
    //     0xd0ea00: ldr             lr, [x21, lr, lsl #3]
    //     0xd0ea04: blr             lr
    // 0xd0ea08: LeaveFrame
    //     0xd0ea08: mov             SP, fp
    //     0xd0ea0c: ldp             fp, lr, [SP], #0x10
    // 0xd0ea10: ret
    //     0xd0ea10: ret             
    // 0xd0ea14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0ea14: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0ea18: b               #0xd0e9e0
  }
  [closure] WidgetStateProperty<BorderSide?>? <anonymous closure>(dynamic, ButtonStyle?) {
    // ** addr: 0xd0ea1c, size: 0x54
    // 0xd0ea1c: EnterFrame
    //     0xd0ea1c: stp             fp, lr, [SP, #-0x10]!
    //     0xd0ea20: mov             fp, SP
    // 0xd0ea24: CheckStackOverflow
    //     0xd0ea24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0ea28: cmp             SP, x16
    //     0xd0ea2c: b.ls            #0xd0ea68
    // 0xd0ea30: ldr             x1, [fp, #0x10]
    // 0xd0ea34: cmp             w1, NULL
    // 0xd0ea38: b.ne            #0xd0ea44
    // 0xd0ea3c: r0 = Null
    //     0xd0ea3c: mov             x0, NULL
    // 0xd0ea40: b               #0xd0ea5c
    // 0xd0ea44: r0 = LoadClassIdInstr(r1)
    //     0xd0ea44: ldur            x0, [x1, #-1]
    //     0xd0ea48: ubfx            x0, x0, #0xc, #0x14
    // 0xd0ea4c: r0 = GDT[cid_x0 + 0x3576]()
    //     0xd0ea4c: mov             x17, #0x3576
    //     0xd0ea50: add             lr, x0, x17
    //     0xd0ea54: ldr             lr, [x21, lr, lsl #3]
    //     0xd0ea58: blr             lr
    // 0xd0ea5c: LeaveFrame
    //     0xd0ea5c: mov             SP, fp
    //     0xd0ea60: ldp             fp, lr, [SP], #0x10
    // 0xd0ea64: ret
    //     0xd0ea64: ret             
    // 0xd0ea68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0ea68: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0ea6c: b               #0xd0ea30
  }
  [closure] WidgetStateProperty<double?>? <anonymous closure>(dynamic, ButtonStyle?) {
    // ** addr: 0xd0ea70, size: 0x54
    // 0xd0ea70: EnterFrame
    //     0xd0ea70: stp             fp, lr, [SP, #-0x10]!
    //     0xd0ea74: mov             fp, SP
    // 0xd0ea78: CheckStackOverflow
    //     0xd0ea78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0ea7c: cmp             SP, x16
    //     0xd0ea80: b.ls            #0xd0eabc
    // 0xd0ea84: ldr             x1, [fp, #0x10]
    // 0xd0ea88: cmp             w1, NULL
    // 0xd0ea8c: b.ne            #0xd0ea98
    // 0xd0ea90: r0 = Null
    //     0xd0ea90: mov             x0, NULL
    // 0xd0ea94: b               #0xd0eab0
    // 0xd0ea98: r0 = LoadClassIdInstr(r1)
    //     0xd0ea98: ldur            x0, [x1, #-1]
    //     0xd0ea9c: ubfx            x0, x0, #0xc, #0x14
    // 0xd0eaa0: r0 = GDT[cid_x0 + 0x610d]()
    //     0xd0eaa0: mov             x17, #0x610d
    //     0xd0eaa4: add             lr, x0, x17
    //     0xd0eaa8: ldr             lr, [x21, lr, lsl #3]
    //     0xd0eaac: blr             lr
    // 0xd0eab0: LeaveFrame
    //     0xd0eab0: mov             SP, fp
    //     0xd0eab4: ldp             fp, lr, [SP], #0x10
    // 0xd0eab8: ret
    //     0xd0eab8: ret             
    // 0xd0eabc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0eabc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0eac0: b               #0xd0ea84
  }
  [closure] WidgetStateProperty<Size?>? <anonymous closure>(dynamic, ButtonStyle?) {
    // ** addr: 0xd0eac4, size: 0x54
    // 0xd0eac4: EnterFrame
    //     0xd0eac4: stp             fp, lr, [SP, #-0x10]!
    //     0xd0eac8: mov             fp, SP
    // 0xd0eacc: CheckStackOverflow
    //     0xd0eacc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0ead0: cmp             SP, x16
    //     0xd0ead4: b.ls            #0xd0eb10
    // 0xd0ead8: ldr             x1, [fp, #0x10]
    // 0xd0eadc: cmp             w1, NULL
    // 0xd0eae0: b.ne            #0xd0eaec
    // 0xd0eae4: r0 = Null
    //     0xd0eae4: mov             x0, NULL
    // 0xd0eae8: b               #0xd0eb04
    // 0xd0eaec: r0 = LoadClassIdInstr(r1)
    //     0xd0eaec: ldur            x0, [x1, #-1]
    //     0xd0eaf0: ubfx            x0, x0, #0xc, #0x14
    // 0xd0eaf4: r0 = GDT[cid_x0 + 0x5978]()
    //     0xd0eaf4: mov             x17, #0x5978
    //     0xd0eaf8: add             lr, x0, x17
    //     0xd0eafc: ldr             lr, [x21, lr, lsl #3]
    //     0xd0eb00: blr             lr
    // 0xd0eb04: LeaveFrame
    //     0xd0eb04: mov             SP, fp
    //     0xd0eb08: ldp             fp, lr, [SP], #0x10
    // 0xd0eb0c: ret
    //     0xd0eb0c: ret             
    // 0xd0eb10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0eb10: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0eb14: b               #0xd0ead8
  }
  [closure] WidgetStateProperty<Size?>? <anonymous closure>(dynamic, ButtonStyle?) {
    // ** addr: 0xd0eb18, size: 0x24
    // 0xd0eb18: ldr             x1, [SP]
    // 0xd0eb1c: cmp             w1, NULL
    // 0xd0eb20: b.ne            #0xd0eb2c
    // 0xd0eb24: r0 = Null
    //     0xd0eb24: mov             x0, NULL
    // 0xd0eb28: b               #0xd0eb38
    // 0xd0eb2c: LoadField: r2 = r1->field_2b
    //     0xd0eb2c: ldur            w2, [x1, #0x2b]
    // 0xd0eb30: DecompressPointer r2
    //     0xd0eb30: add             x2, x2, HEAP, lsl #32
    // 0xd0eb34: mov             x0, x2
    // 0xd0eb38: ret
    //     0xd0eb38: ret             
  }
  [closure] WidgetStateProperty<Size?>? <anonymous closure>(dynamic, ButtonStyle?) {
    // ** addr: 0xd0eb3c, size: 0x54
    // 0xd0eb3c: EnterFrame
    //     0xd0eb3c: stp             fp, lr, [SP, #-0x10]!
    //     0xd0eb40: mov             fp, SP
    // 0xd0eb44: CheckStackOverflow
    //     0xd0eb44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0eb48: cmp             SP, x16
    //     0xd0eb4c: b.ls            #0xd0eb88
    // 0xd0eb50: ldr             x1, [fp, #0x10]
    // 0xd0eb54: cmp             w1, NULL
    // 0xd0eb58: b.ne            #0xd0eb64
    // 0xd0eb5c: r0 = Null
    //     0xd0eb5c: mov             x0, NULL
    // 0xd0eb60: b               #0xd0eb7c
    // 0xd0eb64: r0 = LoadClassIdInstr(r1)
    //     0xd0eb64: ldur            x0, [x1, #-1]
    //     0xd0eb68: ubfx            x0, x0, #0xc, #0x14
    // 0xd0eb6c: r0 = GDT[cid_x0 + 0x5659]()
    //     0xd0eb6c: mov             x17, #0x5659
    //     0xd0eb70: add             lr, x0, x17
    //     0xd0eb74: ldr             lr, [x21, lr, lsl #3]
    //     0xd0eb78: blr             lr
    // 0xd0eb7c: LeaveFrame
    //     0xd0eb7c: mov             SP, fp
    //     0xd0eb80: ldp             fp, lr, [SP], #0x10
    // 0xd0eb84: ret
    //     0xd0eb84: ret             
    // 0xd0eb88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0eb88: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0eb8c: b               #0xd0eb50
  }
  [closure] WidgetStateProperty<EdgeInsetsGeometry?>? <anonymous closure>(dynamic, ButtonStyle?) {
    // ** addr: 0xd0eb90, size: 0x54
    // 0xd0eb90: EnterFrame
    //     0xd0eb90: stp             fp, lr, [SP, #-0x10]!
    //     0xd0eb94: mov             fp, SP
    // 0xd0eb98: CheckStackOverflow
    //     0xd0eb98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0eb9c: cmp             SP, x16
    //     0xd0eba0: b.ls            #0xd0ebdc
    // 0xd0eba4: ldr             x1, [fp, #0x10]
    // 0xd0eba8: cmp             w1, NULL
    // 0xd0ebac: b.ne            #0xd0ebb8
    // 0xd0ebb0: r0 = Null
    //     0xd0ebb0: mov             x0, NULL
    // 0xd0ebb4: b               #0xd0ebd0
    // 0xd0ebb8: r0 = LoadClassIdInstr(r1)
    //     0xd0ebb8: ldur            x0, [x1, #-1]
    //     0xd0ebbc: ubfx            x0, x0, #0xc, #0x14
    // 0xd0ebc0: r0 = GDT[cid_x0 + 0x6f31]()
    //     0xd0ebc0: mov             x17, #0x6f31
    //     0xd0ebc4: add             lr, x0, x17
    //     0xd0ebc8: ldr             lr, [x21, lr, lsl #3]
    //     0xd0ebcc: blr             lr
    // 0xd0ebd0: LeaveFrame
    //     0xd0ebd0: mov             SP, fp
    //     0xd0ebd4: ldp             fp, lr, [SP], #0x10
    // 0xd0ebd8: ret
    //     0xd0ebd8: ret             
    // 0xd0ebdc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0ebdc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0ebe0: b               #0xd0eba4
  }
  [closure] WidgetStateProperty<Color?>? <anonymous closure>(dynamic, ButtonStyle?) {
    // ** addr: 0xd0ebe4, size: 0x54
    // 0xd0ebe4: EnterFrame
    //     0xd0ebe4: stp             fp, lr, [SP, #-0x10]!
    //     0xd0ebe8: mov             fp, SP
    // 0xd0ebec: CheckStackOverflow
    //     0xd0ebec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0ebf0: cmp             SP, x16
    //     0xd0ebf4: b.ls            #0xd0ec30
    // 0xd0ebf8: ldr             x1, [fp, #0x10]
    // 0xd0ebfc: cmp             w1, NULL
    // 0xd0ec00: b.ne            #0xd0ec0c
    // 0xd0ec04: r0 = Null
    //     0xd0ec04: mov             x0, NULL
    // 0xd0ec08: b               #0xd0ec24
    // 0xd0ec0c: r0 = LoadClassIdInstr(r1)
    //     0xd0ec0c: ldur            x0, [x1, #-1]
    //     0xd0ec10: ubfx            x0, x0, #0xc, #0x14
    // 0xd0ec14: r0 = GDT[cid_x0 + 0x2930]()
    //     0xd0ec14: mov             x17, #0x2930
    //     0xd0ec18: add             lr, x0, x17
    //     0xd0ec1c: ldr             lr, [x21, lr, lsl #3]
    //     0xd0ec20: blr             lr
    // 0xd0ec24: LeaveFrame
    //     0xd0ec24: mov             SP, fp
    //     0xd0ec28: ldp             fp, lr, [SP], #0x10
    // 0xd0ec2c: ret
    //     0xd0ec2c: ret             
    // 0xd0ec30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0ec30: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0ec34: b               #0xd0ebf8
  }
  [closure] WidgetStateProperty<Color?>? <anonymous closure>(dynamic, ButtonStyle?) {
    // ** addr: 0xd0ec38, size: 0x50
    // 0xd0ec38: EnterFrame
    //     0xd0ec38: stp             fp, lr, [SP, #-0x10]!
    //     0xd0ec3c: mov             fp, SP
    // 0xd0ec40: CheckStackOverflow
    //     0xd0ec40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0ec44: cmp             SP, x16
    //     0xd0ec48: b.ls            #0xd0ec80
    // 0xd0ec4c: ldr             x1, [fp, #0x10]
    // 0xd0ec50: cmp             w1, NULL
    // 0xd0ec54: b.ne            #0xd0ec60
    // 0xd0ec58: r0 = Null
    //     0xd0ec58: mov             x0, NULL
    // 0xd0ec5c: b               #0xd0ec74
    // 0xd0ec60: r0 = LoadClassIdInstr(r1)
    //     0xd0ec60: ldur            x0, [x1, #-1]
    //     0xd0ec64: ubfx            x0, x0, #0xc, #0x14
    // 0xd0ec68: r0 = GDT[cid_x0 + 0xf36]()
    //     0xd0ec68: add             lr, x0, #0xf36
    //     0xd0ec6c: ldr             lr, [x21, lr, lsl #3]
    //     0xd0ec70: blr             lr
    // 0xd0ec74: LeaveFrame
    //     0xd0ec74: mov             SP, fp
    //     0xd0ec78: ldp             fp, lr, [SP], #0x10
    // 0xd0ec7c: ret
    //     0xd0ec7c: ret             
    // 0xd0ec80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0ec80: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0ec84: b               #0xd0ec4c
  }
  [closure] WidgetStateProperty<Color?>? <anonymous closure>(dynamic, ButtonStyle?) {
    // ** addr: 0xd0ec88, size: 0x50
    // 0xd0ec88: EnterFrame
    //     0xd0ec88: stp             fp, lr, [SP, #-0x10]!
    //     0xd0ec8c: mov             fp, SP
    // 0xd0ec90: CheckStackOverflow
    //     0xd0ec90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0ec94: cmp             SP, x16
    //     0xd0ec98: b.ls            #0xd0ecd0
    // 0xd0ec9c: ldr             x1, [fp, #0x10]
    // 0xd0eca0: cmp             w1, NULL
    // 0xd0eca4: b.ne            #0xd0ecb0
    // 0xd0eca8: r0 = Null
    //     0xd0eca8: mov             x0, NULL
    // 0xd0ecac: b               #0xd0ecc4
    // 0xd0ecb0: r0 = LoadClassIdInstr(r1)
    //     0xd0ecb0: ldur            x0, [x1, #-1]
    //     0xd0ecb4: ubfx            x0, x0, #0xc, #0x14
    // 0xd0ecb8: r0 = GDT[cid_x0 + 0xe62]()
    //     0xd0ecb8: add             lr, x0, #0xe62
    //     0xd0ecbc: ldr             lr, [x21, lr, lsl #3]
    //     0xd0ecc0: blr             lr
    // 0xd0ecc4: LeaveFrame
    //     0xd0ecc4: mov             SP, fp
    //     0xd0ecc8: ldp             fp, lr, [SP], #0x10
    // 0xd0eccc: ret
    //     0xd0eccc: ret             
    // 0xd0ecd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0ecd0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0ecd4: b               #0xd0ec9c
  }
  [closure] WidgetStateProperty<Color?>? <anonymous closure>(dynamic, ButtonStyle?) {
    // ** addr: 0xd0ecd8, size: 0x50
    // 0xd0ecd8: EnterFrame
    //     0xd0ecd8: stp             fp, lr, [SP, #-0x10]!
    //     0xd0ecdc: mov             fp, SP
    // 0xd0ece0: CheckStackOverflow
    //     0xd0ece0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0ece4: cmp             SP, x16
    //     0xd0ece8: b.ls            #0xd0ed20
    // 0xd0ecec: ldr             x1, [fp, #0x10]
    // 0xd0ecf0: cmp             w1, NULL
    // 0xd0ecf4: b.ne            #0xd0ed00
    // 0xd0ecf8: r0 = Null
    //     0xd0ecf8: mov             x0, NULL
    // 0xd0ecfc: b               #0xd0ed14
    // 0xd0ed00: r0 = LoadClassIdInstr(r1)
    //     0xd0ed00: ldur            x0, [x1, #-1]
    //     0xd0ed04: ubfx            x0, x0, #0xc, #0x14
    // 0xd0ed08: r0 = GDT[cid_x0 + 0xf75]()
    //     0xd0ed08: add             lr, x0, #0xf75
    //     0xd0ed0c: ldr             lr, [x21, lr, lsl #3]
    //     0xd0ed10: blr             lr
    // 0xd0ed14: LeaveFrame
    //     0xd0ed14: mov             SP, fp
    //     0xd0ed18: ldp             fp, lr, [SP], #0x10
    // 0xd0ed1c: ret
    //     0xd0ed1c: ret             
    // 0xd0ed20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0ed20: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0ed24: b               #0xd0ecec
  }
  [closure] WidgetStateProperty<TextStyle?>? <anonymous closure>(dynamic, ButtonStyle?) {
    // ** addr: 0xd0ed28, size: 0x50
    // 0xd0ed28: EnterFrame
    //     0xd0ed28: stp             fp, lr, [SP, #-0x10]!
    //     0xd0ed2c: mov             fp, SP
    // 0xd0ed30: CheckStackOverflow
    //     0xd0ed30: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0ed34: cmp             SP, x16
    //     0xd0ed38: b.ls            #0xd0ed70
    // 0xd0ed3c: ldr             x1, [fp, #0x10]
    // 0xd0ed40: cmp             w1, NULL
    // 0xd0ed44: b.ne            #0xd0ed50
    // 0xd0ed48: r0 = Null
    //     0xd0ed48: mov             x0, NULL
    // 0xd0ed4c: b               #0xd0ed64
    // 0xd0ed50: r0 = LoadClassIdInstr(r1)
    //     0xd0ed50: ldur            x0, [x1, #-1]
    //     0xd0ed54: ubfx            x0, x0, #0xc, #0x14
    // 0xd0ed58: r0 = GDT[cid_x0 + 0xe00]()
    //     0xd0ed58: add             lr, x0, #0xe00
    //     0xd0ed5c: ldr             lr, [x21, lr, lsl #3]
    //     0xd0ed60: blr             lr
    // 0xd0ed64: LeaveFrame
    //     0xd0ed64: mov             SP, fp
    //     0xd0ed68: ldp             fp, lr, [SP], #0x10
    // 0xd0ed6c: ret
    //     0xd0ed6c: ret             
    // 0xd0ed70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0ed70: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0ed74: b               #0xd0ed3c
  }
  [closure] WidgetStateProperty<double?>? <anonymous closure>(dynamic, ButtonStyle?) {
    // ** addr: 0xd0ed78, size: 0x50
    // 0xd0ed78: EnterFrame
    //     0xd0ed78: stp             fp, lr, [SP, #-0x10]!
    //     0xd0ed7c: mov             fp, SP
    // 0xd0ed80: CheckStackOverflow
    //     0xd0ed80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0ed84: cmp             SP, x16
    //     0xd0ed88: b.ls            #0xd0edc0
    // 0xd0ed8c: ldr             x1, [fp, #0x10]
    // 0xd0ed90: cmp             w1, NULL
    // 0xd0ed94: b.ne            #0xd0eda0
    // 0xd0ed98: r0 = Null
    //     0xd0ed98: mov             x0, NULL
    // 0xd0ed9c: b               #0xd0edb4
    // 0xd0eda0: r0 = LoadClassIdInstr(r1)
    //     0xd0eda0: ldur            x0, [x1, #-1]
    //     0xd0eda4: ubfx            x0, x0, #0xc, #0x14
    // 0xd0eda8: r0 = GDT[cid_x0 + 0xea7]()
    //     0xd0eda8: add             lr, x0, #0xea7
    //     0xd0edac: ldr             lr, [x21, lr, lsl #3]
    //     0xd0edb0: blr             lr
    // 0xd0edb4: LeaveFrame
    //     0xd0edb4: mov             SP, fp
    //     0xd0edb8: ldp             fp, lr, [SP], #0x10
    // 0xd0edbc: ret
    //     0xd0edbc: ret             
    // 0xd0edc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0edc0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0edc4: b               #0xd0ed8c
  }
  [closure] Color? effectiveIconColor(dynamic) {
    // ** addr: 0xd0edc8, size: 0x458
    // 0xd0edc8: EnterFrame
    //     0xd0edc8: stp             fp, lr, [SP, #-0x10]!
    //     0xd0edcc: mov             fp, SP
    // 0xd0edd0: AllocStack(0x10)
    //     0xd0edd0: sub             SP, SP, #0x10
    // 0xd0edd4: SetupParameters([dynamic _ /* r0 */])
    //     0xd0edd4: ldr             x0, [fp, #0x10]
    //     0xd0edd8: ldur            w3, [x0, #0x17]
    //     0xd0eddc: add             x3, x3, HEAP, lsl #32
    //     0xd0ede0: stur            x3, [fp, #-0x10]
    // 0xd0ede4: CheckStackOverflow
    //     0xd0ede4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0ede8: cmp             SP, x16
    //     0xd0edec: b.ls            #0xd0f1e8
    // 0xd0edf0: LoadField: r4 = r3->field_13
    //     0xd0edf0: ldur            w4, [x3, #0x13]
    // 0xd0edf4: DecompressPointer r4
    //     0xd0edf4: add             x4, x4, HEAP, lsl #32
    // 0xd0edf8: stur            x4, [fp, #-8]
    // 0xd0edfc: cmp             w4, NULL
    // 0xd0ee00: b.ne            #0xd0ee0c
    // 0xd0ee04: r0 = Null
    //     0xd0ee04: mov             x0, NULL
    // 0xd0ee08: b               #0xd0ee8c
    // 0xd0ee0c: LoadField: r1 = r4->field_33
    //     0xd0ee0c: ldur            w1, [x4, #0x33]
    // 0xd0ee10: DecompressPointer r1
    //     0xd0ee10: add             x1, x1, HEAP, lsl #32
    // 0xd0ee14: cmp             w1, NULL
    // 0xd0ee18: b.ne            #0xd0ee24
    // 0xd0ee1c: r0 = Null
    //     0xd0ee1c: mov             x0, NULL
    // 0xd0ee20: b               #0xd0ee8c
    // 0xd0ee24: LoadField: r0 = r3->field_f
    //     0xd0ee24: ldur            w0, [x3, #0xf]
    // 0xd0ee28: DecompressPointer r0
    //     0xd0ee28: add             x0, x0, HEAP, lsl #32
    // 0xd0ee2c: LoadField: r2 = r0->field_b
    //     0xd0ee2c: ldur            w2, [x0, #0xb]
    // 0xd0ee30: DecompressPointer r2
    //     0xd0ee30: add             x2, x2, HEAP, lsl #32
    // 0xd0ee34: cmp             w2, NULL
    // 0xd0ee38: b.eq            #0xd0f1f0
    // 0xd0ee3c: LoadField: r5 = r2->field_2b
    //     0xd0ee3c: ldur            w5, [x2, #0x2b]
    // 0xd0ee40: DecompressPointer r5
    //     0xd0ee40: add             x5, x5, HEAP, lsl #32
    // 0xd0ee44: cmp             w5, NULL
    // 0xd0ee48: b.ne            #0xd0ee64
    // 0xd0ee4c: LoadField: r2 = r0->field_27
    //     0xd0ee4c: ldur            w2, [x0, #0x27]
    // 0xd0ee50: DecompressPointer r2
    //     0xd0ee50: add             x2, x2, HEAP, lsl #32
    // 0xd0ee54: cmp             w2, NULL
    // 0xd0ee58: b.eq            #0xd0f1f4
    // 0xd0ee5c: mov             x0, x2
    // 0xd0ee60: b               #0xd0ee68
    // 0xd0ee64: mov             x0, x5
    // 0xd0ee68: LoadField: r2 = r0->field_27
    //     0xd0ee68: ldur            w2, [x0, #0x27]
    // 0xd0ee6c: DecompressPointer r2
    //     0xd0ee6c: add             x2, x2, HEAP, lsl #32
    // 0xd0ee70: r0 = LoadClassIdInstr(r1)
    //     0xd0ee70: ldur            x0, [x1, #-1]
    //     0xd0ee74: ubfx            x0, x0, #0xc, #0x14
    // 0xd0ee78: r0 = GDT[cid_x0 + 0x17c77]()
    //     0xd0ee78: mov             x17, #0x7c77
    //     0xd0ee7c: movk            x17, #1, lsl #16
    //     0xd0ee80: add             lr, x0, x17
    //     0xd0ee84: ldr             lr, [x21, lr, lsl #3]
    //     0xd0ee88: blr             lr
    // 0xd0ee8c: cmp             w0, NULL
    // 0xd0ee90: b.ne            #0xd0ef30
    // 0xd0ee94: ldur            x3, [fp, #-0x10]
    // 0xd0ee98: ArrayLoad: r0 = r3[0]  ; List_4
    //     0xd0ee98: ldur            w0, [x3, #0x17]
    // 0xd0ee9c: DecompressPointer r0
    //     0xd0ee9c: add             x0, x0, HEAP, lsl #32
    // 0xd0eea0: cmp             w0, NULL
    // 0xd0eea4: b.ne            #0xd0eeb0
    // 0xd0eea8: r0 = Null
    //     0xd0eea8: mov             x0, NULL
    // 0xd0eeac: b               #0xd0ef30
    // 0xd0eeb0: LoadField: r1 = r0->field_33
    //     0xd0eeb0: ldur            w1, [x0, #0x33]
    // 0xd0eeb4: DecompressPointer r1
    //     0xd0eeb4: add             x1, x1, HEAP, lsl #32
    // 0xd0eeb8: cmp             w1, NULL
    // 0xd0eebc: b.ne            #0xd0eec8
    // 0xd0eec0: r0 = Null
    //     0xd0eec0: mov             x0, NULL
    // 0xd0eec4: b               #0xd0ef30
    // 0xd0eec8: LoadField: r0 = r3->field_f
    //     0xd0eec8: ldur            w0, [x3, #0xf]
    // 0xd0eecc: DecompressPointer r0
    //     0xd0eecc: add             x0, x0, HEAP, lsl #32
    // 0xd0eed0: LoadField: r2 = r0->field_b
    //     0xd0eed0: ldur            w2, [x0, #0xb]
    // 0xd0eed4: DecompressPointer r2
    //     0xd0eed4: add             x2, x2, HEAP, lsl #32
    // 0xd0eed8: cmp             w2, NULL
    // 0xd0eedc: b.eq            #0xd0f1f8
    // 0xd0eee0: LoadField: r4 = r2->field_2b
    //     0xd0eee0: ldur            w4, [x2, #0x2b]
    // 0xd0eee4: DecompressPointer r4
    //     0xd0eee4: add             x4, x4, HEAP, lsl #32
    // 0xd0eee8: cmp             w4, NULL
    // 0xd0eeec: b.ne            #0xd0ef08
    // 0xd0eef0: LoadField: r2 = r0->field_27
    //     0xd0eef0: ldur            w2, [x0, #0x27]
    // 0xd0eef4: DecompressPointer r2
    //     0xd0eef4: add             x2, x2, HEAP, lsl #32
    // 0xd0eef8: cmp             w2, NULL
    // 0xd0eefc: b.eq            #0xd0f1fc
    // 0xd0ef00: mov             x0, x2
    // 0xd0ef04: b               #0xd0ef0c
    // 0xd0ef08: mov             x0, x4
    // 0xd0ef0c: LoadField: r2 = r0->field_27
    //     0xd0ef0c: ldur            w2, [x0, #0x27]
    // 0xd0ef10: DecompressPointer r2
    //     0xd0ef10: add             x2, x2, HEAP, lsl #32
    // 0xd0ef14: r0 = LoadClassIdInstr(r1)
    //     0xd0ef14: ldur            x0, [x1, #-1]
    //     0xd0ef18: ubfx            x0, x0, #0xc, #0x14
    // 0xd0ef1c: r0 = GDT[cid_x0 + 0x17c77]()
    //     0xd0ef1c: mov             x17, #0x7c77
    //     0xd0ef20: movk            x17, #1, lsl #16
    //     0xd0ef24: add             lr, x0, x17
    //     0xd0ef28: ldr             lr, [x21, lr, lsl #3]
    //     0xd0ef2c: blr             lr
    // 0xd0ef30: cmp             w0, NULL
    // 0xd0ef34: b.ne            #0xd0efd0
    // 0xd0ef38: ldur            x0, [fp, #-8]
    // 0xd0ef3c: cmp             w0, NULL
    // 0xd0ef40: b.ne            #0xd0ef4c
    // 0xd0ef44: r0 = Null
    //     0xd0ef44: mov             x0, NULL
    // 0xd0ef48: b               #0xd0efd0
    // 0xd0ef4c: LoadField: r1 = r0->field_f
    //     0xd0ef4c: ldur            w1, [x0, #0xf]
    // 0xd0ef50: DecompressPointer r1
    //     0xd0ef50: add             x1, x1, HEAP, lsl #32
    // 0xd0ef54: cmp             w1, NULL
    // 0xd0ef58: b.ne            #0xd0ef64
    // 0xd0ef5c: r0 = Null
    //     0xd0ef5c: mov             x0, NULL
    // 0xd0ef60: b               #0xd0efd0
    // 0xd0ef64: ldur            x3, [fp, #-0x10]
    // 0xd0ef68: LoadField: r0 = r3->field_f
    //     0xd0ef68: ldur            w0, [x3, #0xf]
    // 0xd0ef6c: DecompressPointer r0
    //     0xd0ef6c: add             x0, x0, HEAP, lsl #32
    // 0xd0ef70: LoadField: r2 = r0->field_b
    //     0xd0ef70: ldur            w2, [x0, #0xb]
    // 0xd0ef74: DecompressPointer r2
    //     0xd0ef74: add             x2, x2, HEAP, lsl #32
    // 0xd0ef78: cmp             w2, NULL
    // 0xd0ef7c: b.eq            #0xd0f200
    // 0xd0ef80: LoadField: r4 = r2->field_2b
    //     0xd0ef80: ldur            w4, [x2, #0x2b]
    // 0xd0ef84: DecompressPointer r4
    //     0xd0ef84: add             x4, x4, HEAP, lsl #32
    // 0xd0ef88: cmp             w4, NULL
    // 0xd0ef8c: b.ne            #0xd0efa8
    // 0xd0ef90: LoadField: r2 = r0->field_27
    //     0xd0ef90: ldur            w2, [x0, #0x27]
    // 0xd0ef94: DecompressPointer r2
    //     0xd0ef94: add             x2, x2, HEAP, lsl #32
    // 0xd0ef98: cmp             w2, NULL
    // 0xd0ef9c: b.eq            #0xd0f204
    // 0xd0efa0: mov             x0, x2
    // 0xd0efa4: b               #0xd0efac
    // 0xd0efa8: mov             x0, x4
    // 0xd0efac: LoadField: r2 = r0->field_27
    //     0xd0efac: ldur            w2, [x0, #0x27]
    // 0xd0efb0: DecompressPointer r2
    //     0xd0efb0: add             x2, x2, HEAP, lsl #32
    // 0xd0efb4: r0 = LoadClassIdInstr(r1)
    //     0xd0efb4: ldur            x0, [x1, #-1]
    //     0xd0efb8: ubfx            x0, x0, #0xc, #0x14
    // 0xd0efbc: r0 = GDT[cid_x0 + 0x17c77]()
    //     0xd0efbc: mov             x17, #0x7c77
    //     0xd0efc0: movk            x17, #1, lsl #16
    //     0xd0efc4: add             lr, x0, x17
    //     0xd0efc8: ldr             lr, [x21, lr, lsl #3]
    //     0xd0efcc: blr             lr
    // 0xd0efd0: cmp             w0, NULL
    // 0xd0efd4: b.ne            #0xd0f074
    // 0xd0efd8: ldur            x3, [fp, #-0x10]
    // 0xd0efdc: ArrayLoad: r0 = r3[0]  ; List_4
    //     0xd0efdc: ldur            w0, [x3, #0x17]
    // 0xd0efe0: DecompressPointer r0
    //     0xd0efe0: add             x0, x0, HEAP, lsl #32
    // 0xd0efe4: cmp             w0, NULL
    // 0xd0efe8: b.ne            #0xd0eff4
    // 0xd0efec: r0 = Null
    //     0xd0efec: mov             x0, NULL
    // 0xd0eff0: b               #0xd0f074
    // 0xd0eff4: LoadField: r1 = r0->field_f
    //     0xd0eff4: ldur            w1, [x0, #0xf]
    // 0xd0eff8: DecompressPointer r1
    //     0xd0eff8: add             x1, x1, HEAP, lsl #32
    // 0xd0effc: cmp             w1, NULL
    // 0xd0f000: b.ne            #0xd0f00c
    // 0xd0f004: r0 = Null
    //     0xd0f004: mov             x0, NULL
    // 0xd0f008: b               #0xd0f074
    // 0xd0f00c: LoadField: r0 = r3->field_f
    //     0xd0f00c: ldur            w0, [x3, #0xf]
    // 0xd0f010: DecompressPointer r0
    //     0xd0f010: add             x0, x0, HEAP, lsl #32
    // 0xd0f014: LoadField: r2 = r0->field_b
    //     0xd0f014: ldur            w2, [x0, #0xb]
    // 0xd0f018: DecompressPointer r2
    //     0xd0f018: add             x2, x2, HEAP, lsl #32
    // 0xd0f01c: cmp             w2, NULL
    // 0xd0f020: b.eq            #0xd0f208
    // 0xd0f024: LoadField: r4 = r2->field_2b
    //     0xd0f024: ldur            w4, [x2, #0x2b]
    // 0xd0f028: DecompressPointer r4
    //     0xd0f028: add             x4, x4, HEAP, lsl #32
    // 0xd0f02c: cmp             w4, NULL
    // 0xd0f030: b.ne            #0xd0f04c
    // 0xd0f034: LoadField: r2 = r0->field_27
    //     0xd0f034: ldur            w2, [x0, #0x27]
    // 0xd0f038: DecompressPointer r2
    //     0xd0f038: add             x2, x2, HEAP, lsl #32
    // 0xd0f03c: cmp             w2, NULL
    // 0xd0f040: b.eq            #0xd0f20c
    // 0xd0f044: mov             x0, x2
    // 0xd0f048: b               #0xd0f050
    // 0xd0f04c: mov             x0, x4
    // 0xd0f050: LoadField: r2 = r0->field_27
    //     0xd0f050: ldur            w2, [x0, #0x27]
    // 0xd0f054: DecompressPointer r2
    //     0xd0f054: add             x2, x2, HEAP, lsl #32
    // 0xd0f058: r0 = LoadClassIdInstr(r1)
    //     0xd0f058: ldur            x0, [x1, #-1]
    //     0xd0f05c: ubfx            x0, x0, #0xc, #0x14
    // 0xd0f060: r0 = GDT[cid_x0 + 0x17c77]()
    //     0xd0f060: mov             x17, #0x7c77
    //     0xd0f064: movk            x17, #1, lsl #16
    //     0xd0f068: add             lr, x0, x17
    //     0xd0f06c: ldr             lr, [x21, lr, lsl #3]
    //     0xd0f070: blr             lr
    // 0xd0f074: cmp             w0, NULL
    // 0xd0f078: b.ne            #0xd0f128
    // 0xd0f07c: ldur            x2, [fp, #-0x10]
    // 0xd0f080: LoadField: r1 = r2->field_1b
    //     0xd0f080: ldur            w1, [x2, #0x1b]
    // 0xd0f084: DecompressPointer r1
    //     0xd0f084: add             x1, x1, HEAP, lsl #32
    // 0xd0f088: r0 = LoadClassIdInstr(r1)
    //     0xd0f088: ldur            x0, [x1, #-1]
    //     0xd0f08c: ubfx            x0, x0, #0xc, #0x14
    // 0xd0f090: r0 = GDT[cid_x0 + 0x60e5]()
    //     0xd0f090: mov             x17, #0x60e5
    //     0xd0f094: add             lr, x0, x17
    //     0xd0f098: ldr             lr, [x21, lr, lsl #3]
    //     0xd0f09c: blr             lr
    // 0xd0f0a0: cmp             w0, NULL
    // 0xd0f0a4: b.ne            #0xd0f0b0
    // 0xd0f0a8: r0 = Null
    //     0xd0f0a8: mov             x0, NULL
    // 0xd0f0ac: b               #0xd0f128
    // 0xd0f0b0: ldur            x3, [fp, #-0x10]
    // 0xd0f0b4: LoadField: r1 = r3->field_f
    //     0xd0f0b4: ldur            w1, [x3, #0xf]
    // 0xd0f0b8: DecompressPointer r1
    //     0xd0f0b8: add             x1, x1, HEAP, lsl #32
    // 0xd0f0bc: LoadField: r2 = r1->field_b
    //     0xd0f0bc: ldur            w2, [x1, #0xb]
    // 0xd0f0c0: DecompressPointer r2
    //     0xd0f0c0: add             x2, x2, HEAP, lsl #32
    // 0xd0f0c4: cmp             w2, NULL
    // 0xd0f0c8: b.eq            #0xd0f210
    // 0xd0f0cc: LoadField: r4 = r2->field_2b
    //     0xd0f0cc: ldur            w4, [x2, #0x2b]
    // 0xd0f0d0: DecompressPointer r4
    //     0xd0f0d0: add             x4, x4, HEAP, lsl #32
    // 0xd0f0d4: cmp             w4, NULL
    // 0xd0f0d8: b.ne            #0xd0f0f4
    // 0xd0f0dc: LoadField: r2 = r1->field_27
    //     0xd0f0dc: ldur            w2, [x1, #0x27]
    // 0xd0f0e0: DecompressPointer r2
    //     0xd0f0e0: add             x2, x2, HEAP, lsl #32
    // 0xd0f0e4: cmp             w2, NULL
    // 0xd0f0e8: b.eq            #0xd0f214
    // 0xd0f0ec: mov             x1, x2
    // 0xd0f0f0: b               #0xd0f0f8
    // 0xd0f0f4: mov             x1, x4
    // 0xd0f0f8: LoadField: r2 = r1->field_27
    //     0xd0f0f8: ldur            w2, [x1, #0x27]
    // 0xd0f0fc: DecompressPointer r2
    //     0xd0f0fc: add             x2, x2, HEAP, lsl #32
    // 0xd0f100: r1 = LoadClassIdInstr(r0)
    //     0xd0f100: ldur            x1, [x0, #-1]
    //     0xd0f104: ubfx            x1, x1, #0xc, #0x14
    // 0xd0f108: mov             x16, x0
    // 0xd0f10c: mov             x0, x1
    // 0xd0f110: mov             x1, x16
    // 0xd0f114: r0 = GDT[cid_x0 + 0x17c77]()
    //     0xd0f114: mov             x17, #0x7c77
    //     0xd0f118: movk            x17, #1, lsl #16
    //     0xd0f11c: add             lr, x0, x17
    //     0xd0f120: ldr             lr, [x21, lr, lsl #3]
    //     0xd0f124: blr             lr
    // 0xd0f128: cmp             w0, NULL
    // 0xd0f12c: b.ne            #0xd0f1dc
    // 0xd0f130: ldur            x2, [fp, #-0x10]
    // 0xd0f134: LoadField: r1 = r2->field_1b
    //     0xd0f134: ldur            w1, [x2, #0x1b]
    // 0xd0f138: DecompressPointer r1
    //     0xd0f138: add             x1, x1, HEAP, lsl #32
    // 0xd0f13c: r0 = LoadClassIdInstr(r1)
    //     0xd0f13c: ldur            x0, [x1, #-1]
    //     0xd0f140: ubfx            x0, x0, #0xc, #0x14
    // 0xd0f144: r0 = GDT[cid_x0 + 0xe62]()
    //     0xd0f144: add             lr, x0, #0xe62
    //     0xd0f148: ldr             lr, [x21, lr, lsl #3]
    //     0xd0f14c: blr             lr
    // 0xd0f150: cmp             w0, NULL
    // 0xd0f154: b.ne            #0xd0f160
    // 0xd0f158: r1 = Null
    //     0xd0f158: mov             x1, NULL
    // 0xd0f15c: b               #0xd0f1d8
    // 0xd0f160: ldur            x1, [fp, #-0x10]
    // 0xd0f164: LoadField: r2 = r1->field_f
    //     0xd0f164: ldur            w2, [x1, #0xf]
    // 0xd0f168: DecompressPointer r2
    //     0xd0f168: add             x2, x2, HEAP, lsl #32
    // 0xd0f16c: LoadField: r1 = r2->field_b
    //     0xd0f16c: ldur            w1, [x2, #0xb]
    // 0xd0f170: DecompressPointer r1
    //     0xd0f170: add             x1, x1, HEAP, lsl #32
    // 0xd0f174: cmp             w1, NULL
    // 0xd0f178: b.eq            #0xd0f218
    // 0xd0f17c: LoadField: r3 = r1->field_2b
    //     0xd0f17c: ldur            w3, [x1, #0x2b]
    // 0xd0f180: DecompressPointer r3
    //     0xd0f180: add             x3, x3, HEAP, lsl #32
    // 0xd0f184: cmp             w3, NULL
    // 0xd0f188: b.ne            #0xd0f1a0
    // 0xd0f18c: LoadField: r1 = r2->field_27
    //     0xd0f18c: ldur            w1, [x2, #0x27]
    // 0xd0f190: DecompressPointer r1
    //     0xd0f190: add             x1, x1, HEAP, lsl #32
    // 0xd0f194: cmp             w1, NULL
    // 0xd0f198: b.eq            #0xd0f21c
    // 0xd0f19c: b               #0xd0f1a4
    // 0xd0f1a0: mov             x1, x3
    // 0xd0f1a4: LoadField: r2 = r1->field_27
    //     0xd0f1a4: ldur            w2, [x1, #0x27]
    // 0xd0f1a8: DecompressPointer r2
    //     0xd0f1a8: add             x2, x2, HEAP, lsl #32
    // 0xd0f1ac: r1 = LoadClassIdInstr(r0)
    //     0xd0f1ac: ldur            x1, [x0, #-1]
    //     0xd0f1b0: ubfx            x1, x1, #0xc, #0x14
    // 0xd0f1b4: mov             x16, x0
    // 0xd0f1b8: mov             x0, x1
    // 0xd0f1bc: mov             x1, x16
    // 0xd0f1c0: r0 = GDT[cid_x0 + 0x17c77]()
    //     0xd0f1c0: mov             x17, #0x7c77
    //     0xd0f1c4: movk            x17, #1, lsl #16
    //     0xd0f1c8: add             lr, x0, x17
    //     0xd0f1cc: ldr             lr, [x21, lr, lsl #3]
    //     0xd0f1d0: blr             lr
    // 0xd0f1d4: mov             x1, x0
    // 0xd0f1d8: mov             x0, x1
    // 0xd0f1dc: LeaveFrame
    //     0xd0f1dc: mov             SP, fp
    //     0xd0f1e0: ldp             fp, lr, [SP], #0x10
    // 0xd0f1e4: ret
    //     0xd0f1e4: ret             
    // 0xd0f1e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0f1e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0f1ec: b               #0xd0edf0
    // 0xd0f1f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0f1f0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0f1f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0f1f4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0f1f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0f1f8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0f1fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0f1fc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0f200: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0f200: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0f204: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0f204: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0f208: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0f208: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0f20c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0f20c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0f210: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0f210: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0f214: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0f214: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0f218: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0f218: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0f21c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0f21c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Y0? resolve<Y0>(dynamic, (dynamic, ButtonStyle?) => WidgetStateProperty<Y0>?) {
    // ** addr: 0xd0f220, size: 0xdc
    // 0xd0f220: EnterFrame
    //     0xd0f220: stp             fp, lr, [SP, #-0x10]!
    //     0xd0f224: mov             fp, SP
    // 0xd0f228: AllocStack(0x30)
    //     0xd0f228: sub             SP, SP, #0x30
    // 0xd0f22c: SetupParameters([dynamic _ /* r0 */])
    //     0xd0f22c: ldr             x0, [fp, #0x18]
    //     0xd0f230: ldur            w1, [x0, #0x17]
    //     0xd0f234: add             x1, x1, HEAP, lsl #32
    //     0xd0f238: stur            x1, [fp, #-0x10]
    // 0xd0f23c: LoadField: r2 = r4->field_f
    //     0xd0f23c: ldur            w2, [x4, #0xf]
    // 0xd0f240: cbnz            w2, #0xd0f24c
    // 0xd0f244: r2 = Null
    //     0xd0f244: mov             x2, NULL
    // 0xd0f248: b               #0xd0f25c
    // 0xd0f24c: ArrayLoad: r2 = r4[0]  ; List_4
    //     0xd0f24c: ldur            w2, [x4, #0x17]
    // 0xd0f250: add             x3, fp, w2, sxtw #2
    // 0xd0f254: ldr             x3, [x3, #0x10]
    // 0xd0f258: mov             x2, x3
    // 0xd0f25c: LoadField: r3 = r0->field_f
    //     0xd0f25c: ldur            w3, [x0, #0xf]
    // 0xd0f260: DecompressPointer r3
    //     0xd0f260: add             x3, x3, HEAP, lsl #32
    // 0xd0f264: ldr             x16, [THR, #0xb0]  ; THR::empty_type_arguments
    // 0xd0f268: cmp             w3, w16
    // 0xd0f26c: b.eq            #0xd0f274
    // 0xd0f270: mov             x2, x3
    // 0xd0f274: ldr             x0, [fp, #0x10]
    // 0xd0f278: stur            x2, [fp, #-8]
    // 0xd0f27c: CheckStackOverflow
    //     0xd0f27c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0f280: cmp             SP, x16
    //     0xd0f284: b.ls            #0xd0f2f4
    // 0xd0f288: r1 = 1
    //     0xd0f288: mov             x1, #1
    // 0xd0f28c: r0 = AllocateContext()
    //     0xd0f28c: bl              #0x13de838  ; AllocateContextStub
    // 0xd0f290: mov             x1, x0
    // 0xd0f294: ldur            x0, [fp, #-0x10]
    // 0xd0f298: StoreField: r1->field_b = r0
    //     0xd0f298: stur            w0, [x1, #0xb]
    // 0xd0f29c: ldr             x2, [fp, #0x10]
    // 0xd0f2a0: StoreField: r1->field_f = r2
    //     0xd0f2a0: stur            w2, [x1, #0xf]
    // 0xd0f2a4: LoadField: r3 = r0->field_1f
    //     0xd0f2a4: ldur            w3, [x0, #0x1f]
    // 0xd0f2a8: DecompressPointer r3
    //     0xd0f2a8: add             x3, x3, HEAP, lsl #32
    // 0xd0f2ac: mov             x2, x1
    // 0xd0f2b0: stur            x3, [fp, #-0x18]
    // 0xd0f2b4: r1 = Function '<anonymous closure>':.
    //     0xd0f2b4: add             x1, PP, #0x90, lsl #12  ; [pp+0x90648] AnonymousClosure: (0xd0f2fc), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0xd0ce1c)
    //     0xd0f2b8: ldr             x1, [x1, #0x648]
    // 0xd0f2bc: r0 = AllocateClosure()
    //     0xd0f2bc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd0f2c0: mov             x1, x0
    // 0xd0f2c4: ldur            x0, [fp, #-8]
    // 0xd0f2c8: StoreField: r1->field_b = r0
    //     0xd0f2c8: stur            w0, [x1, #0xb]
    // 0xd0f2cc: ldur            x16, [fp, #-0x18]
    // 0xd0f2d0: stp             x16, x0, [SP, #8]
    // 0xd0f2d4: str             x1, [SP]
    // 0xd0f2d8: ldur            x0, [fp, #-0x18]
    // 0xd0f2dc: ClosureCall
    //     0xd0f2dc: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0xd0f2e0: ldur            x2, [x0, #0x1f]
    //     0xd0f2e4: blr             x2
    // 0xd0f2e8: LeaveFrame
    //     0xd0f2e8: mov             SP, fp
    //     0xd0f2ec: ldp             fp, lr, [SP], #0x10
    // 0xd0f2f0: ret
    //     0xd0f2f0: ret             
    // 0xd0f2f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0f2f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0f2f8: b               #0xd0f288
  }
  [closure] Y0? <anonymous closure>(dynamic, ButtonStyle?) {
    // ** addr: 0xd0f2fc, size: 0xf0
    // 0xd0f2fc: EnterFrame
    //     0xd0f2fc: stp             fp, lr, [SP, #-0x10]!
    //     0xd0f300: mov             fp, SP
    // 0xd0f304: AllocStack(0x18)
    //     0xd0f304: sub             SP, SP, #0x18
    // 0xd0f308: SetupParameters([dynamic _ /* r0 */])
    //     0xd0f308: ldr             x0, [fp, #0x18]
    //     0xd0f30c: ldur            w1, [x0, #0x17]
    //     0xd0f310: add             x1, x1, HEAP, lsl #32
    //     0xd0f314: stur            x1, [fp, #-8]
    // 0xd0f318: CheckStackOverflow
    //     0xd0f318: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0f31c: cmp             SP, x16
    //     0xd0f320: b.ls            #0xd0f3dc
    // 0xd0f324: LoadField: r0 = r1->field_f
    //     0xd0f324: ldur            w0, [x1, #0xf]
    // 0xd0f328: DecompressPointer r0
    //     0xd0f328: add             x0, x0, HEAP, lsl #32
    // 0xd0f32c: ldr             x16, [fp, #0x10]
    // 0xd0f330: stp             x16, x0, [SP]
    // 0xd0f334: ClosureCall
    //     0xd0f334: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xd0f338: ldur            x2, [x0, #0x1f]
    //     0xd0f33c: blr             x2
    // 0xd0f340: cmp             w0, NULL
    // 0xd0f344: b.ne            #0xd0f350
    // 0xd0f348: r0 = Null
    //     0xd0f348: mov             x0, NULL
    // 0xd0f34c: b               #0xd0f3d0
    // 0xd0f350: ldur            x1, [fp, #-8]
    // 0xd0f354: LoadField: r2 = r1->field_b
    //     0xd0f354: ldur            w2, [x1, #0xb]
    // 0xd0f358: DecompressPointer r2
    //     0xd0f358: add             x2, x2, HEAP, lsl #32
    // 0xd0f35c: LoadField: r1 = r2->field_f
    //     0xd0f35c: ldur            w1, [x2, #0xf]
    // 0xd0f360: DecompressPointer r1
    //     0xd0f360: add             x1, x1, HEAP, lsl #32
    // 0xd0f364: LoadField: r2 = r1->field_b
    //     0xd0f364: ldur            w2, [x1, #0xb]
    // 0xd0f368: DecompressPointer r2
    //     0xd0f368: add             x2, x2, HEAP, lsl #32
    // 0xd0f36c: cmp             w2, NULL
    // 0xd0f370: b.eq            #0xd0f3e4
    // 0xd0f374: LoadField: r3 = r2->field_2b
    //     0xd0f374: ldur            w3, [x2, #0x2b]
    // 0xd0f378: DecompressPointer r3
    //     0xd0f378: add             x3, x3, HEAP, lsl #32
    // 0xd0f37c: cmp             w3, NULL
    // 0xd0f380: b.ne            #0xd0f39c
    // 0xd0f384: LoadField: r2 = r1->field_27
    //     0xd0f384: ldur            w2, [x1, #0x27]
    // 0xd0f388: DecompressPointer r2
    //     0xd0f388: add             x2, x2, HEAP, lsl #32
    // 0xd0f38c: cmp             w2, NULL
    // 0xd0f390: b.eq            #0xd0f3e8
    // 0xd0f394: mov             x1, x2
    // 0xd0f398: b               #0xd0f3a0
    // 0xd0f39c: mov             x1, x3
    // 0xd0f3a0: LoadField: r2 = r1->field_27
    //     0xd0f3a0: ldur            w2, [x1, #0x27]
    // 0xd0f3a4: DecompressPointer r2
    //     0xd0f3a4: add             x2, x2, HEAP, lsl #32
    // 0xd0f3a8: r1 = LoadClassIdInstr(r0)
    //     0xd0f3a8: ldur            x1, [x0, #-1]
    //     0xd0f3ac: ubfx            x1, x1, #0xc, #0x14
    // 0xd0f3b0: mov             x16, x0
    // 0xd0f3b4: mov             x0, x1
    // 0xd0f3b8: mov             x1, x16
    // 0xd0f3bc: r0 = GDT[cid_x0 + 0x17c77]()
    //     0xd0f3bc: mov             x17, #0x7c77
    //     0xd0f3c0: movk            x17, #1, lsl #16
    //     0xd0f3c4: add             lr, x0, x17
    //     0xd0f3c8: ldr             lr, [x21, lr, lsl #3]
    //     0xd0f3cc: blr             lr
    // 0xd0f3d0: LeaveFrame
    //     0xd0f3d0: mov             SP, fp
    //     0xd0f3d4: ldp             fp, lr, [SP], #0x10
    // 0xd0f3d8: ret
    //     0xd0f3d8: ret             
    // 0xd0f3dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0f3dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0f3e0: b               #0xd0f324
    // 0xd0f3e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0f3e4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0f3e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0f3e8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Y0? effectiveValue<Y0>(dynamic, (dynamic, ButtonStyle?) => Y0?) {
    // ** addr: 0xd0f3ec, size: 0xd0
    // 0xd0f3ec: EnterFrame
    //     0xd0f3ec: stp             fp, lr, [SP, #-0x10]!
    //     0xd0f3f0: mov             fp, SP
    // 0xd0f3f4: AllocStack(0x28)
    //     0xd0f3f4: sub             SP, SP, #0x28
    // 0xd0f3f8: SetupParameters([dynamic _ /* r0 */])
    //     0xd0f3f8: ldr             x0, [fp, #0x18]
    //     0xd0f3fc: ldur            w1, [x0, #0x17]
    //     0xd0f400: add             x1, x1, HEAP, lsl #32
    //     0xd0f404: stur            x1, [fp, #-8]
    // 0xd0f408: CheckStackOverflow
    //     0xd0f408: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0f40c: cmp             SP, x16
    //     0xd0f410: b.ls            #0xd0f4b4
    // 0xd0f414: LoadField: r0 = r1->field_13
    //     0xd0f414: ldur            w0, [x1, #0x13]
    // 0xd0f418: DecompressPointer r0
    //     0xd0f418: add             x0, x0, HEAP, lsl #32
    // 0xd0f41c: ldr             x16, [fp, #0x10]
    // 0xd0f420: stp             x0, x16, [SP]
    // 0xd0f424: ldr             x0, [fp, #0x10]
    // 0xd0f428: ClosureCall
    //     0xd0f428: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xd0f42c: ldur            x2, [x0, #0x1f]
    //     0xd0f430: blr             x2
    // 0xd0f434: mov             x2, x0
    // 0xd0f438: ldur            x1, [fp, #-8]
    // 0xd0f43c: stur            x2, [fp, #-0x10]
    // 0xd0f440: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xd0f440: ldur            w0, [x1, #0x17]
    // 0xd0f444: DecompressPointer r0
    //     0xd0f444: add             x0, x0, HEAP, lsl #32
    // 0xd0f448: ldr             x16, [fp, #0x10]
    // 0xd0f44c: stp             x0, x16, [SP]
    // 0xd0f450: ldr             x0, [fp, #0x10]
    // 0xd0f454: ClosureCall
    //     0xd0f454: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xd0f458: ldur            x2, [x0, #0x1f]
    //     0xd0f45c: blr             x2
    // 0xd0f460: mov             x1, x0
    // 0xd0f464: ldur            x0, [fp, #-8]
    // 0xd0f468: stur            x1, [fp, #-0x18]
    // 0xd0f46c: LoadField: r2 = r0->field_1b
    //     0xd0f46c: ldur            w2, [x0, #0x1b]
    // 0xd0f470: DecompressPointer r2
    //     0xd0f470: add             x2, x2, HEAP, lsl #32
    // 0xd0f474: ldr             x16, [fp, #0x10]
    // 0xd0f478: stp             x2, x16, [SP]
    // 0xd0f47c: ldr             x0, [fp, #0x10]
    // 0xd0f480: ClosureCall
    //     0xd0f480: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xd0f484: ldur            x2, [x0, #0x1f]
    //     0xd0f488: blr             x2
    // 0xd0f48c: ldur            x1, [fp, #-0x10]
    // 0xd0f490: cmp             w1, NULL
    // 0xd0f494: b.ne            #0xd0f49c
    // 0xd0f498: ldur            x1, [fp, #-0x18]
    // 0xd0f49c: cmp             w1, NULL
    // 0xd0f4a0: b.eq            #0xd0f4a8
    // 0xd0f4a4: mov             x0, x1
    // 0xd0f4a8: LeaveFrame
    //     0xd0f4a8: mov             SP, fp
    //     0xd0f4ac: ldp             fp, lr, [SP], #0x10
    // 0xd0f4b0: ret
    //     0xd0f4b0: ret             
    // 0xd0f4b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0f4b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0f4b8: b               #0xd0f414
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf37510, size: 0x274
    // 0xf37510: EnterFrame
    //     0xf37510: stp             fp, lr, [SP, #-0x10]!
    //     0xf37514: mov             fp, SP
    // 0xf37518: AllocStack(0x18)
    //     0xf37518: sub             SP, SP, #0x18
    // 0xf3751c: SetupParameters(_ButtonStyleState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xf3751c: mov             x4, x1
    //     0xf37520: mov             x3, x2
    //     0xf37524: stur            x1, [fp, #-8]
    //     0xf37528: stur            x2, [fp, #-0x10]
    // 0xf3752c: CheckStackOverflow
    //     0xf3752c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf37530: cmp             SP, x16
    //     0xf37534: b.ls            #0xf37764
    // 0xf37538: mov             x0, x3
    // 0xf3753c: r2 = Null
    //     0xf3753c: mov             x2, NULL
    // 0xf37540: r1 = Null
    //     0xf37540: mov             x1, NULL
    // 0xf37544: r4 = 60
    //     0xf37544: mov             x4, #0x3c
    // 0xf37548: branchIfSmi(r0, 0xf37554)
    //     0xf37548: tbz             w0, #0, #0xf37554
    // 0xf3754c: r4 = LoadClassIdInstr(r0)
    //     0xf3754c: ldur            x4, [x0, #-1]
    //     0xf37550: ubfx            x4, x4, #0xc, #0x14
    // 0xf37554: r17 = -6495
    //     0xf37554: mov             x17, #-0x195f
    // 0xf37558: add             x4, x4, x17
    // 0xf3755c: cmp             x4, #3
    // 0xf37560: b.ls            #0xf37578
    // 0xf37564: r8 = ButtonStyleButton
    //     0xf37564: add             x8, PP, #0x90, lsl #12  ; [pp+0x90660] Type: ButtonStyleButton
    //     0xf37568: ldr             x8, [x8, #0x660]
    // 0xf3756c: r3 = Null
    //     0xf3756c: add             x3, PP, #0x90, lsl #12  ; [pp+0x90668] Null
    //     0xf37570: ldr             x3, [x3, #0x668]
    // 0xf37574: r0 = ButtonStyleButton()
    //     0xf37574: bl              #0xacd530  ; IsType_ButtonStyleButton_Stub
    // 0xf37578: ldur            x3, [fp, #-8]
    // 0xf3757c: LoadField: r2 = r3->field_7
    //     0xf3757c: ldur            w2, [x3, #7]
    // 0xf37580: DecompressPointer r2
    //     0xf37580: add             x2, x2, HEAP, lsl #32
    // 0xf37584: ldur            x0, [fp, #-0x10]
    // 0xf37588: r1 = Null
    //     0xf37588: mov             x1, NULL
    // 0xf3758c: cmp             w2, NULL
    // 0xf37590: b.eq            #0xf375b4
    // 0xf37594: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf37594: ldur            w4, [x2, #0x17]
    // 0xf37598: DecompressPointer r4
    //     0xf37598: add             x4, x4, HEAP, lsl #32
    // 0xf3759c: r8 = X0 bound StatefulWidget
    //     0xf3759c: add             x8, PP, #0x12, lsl #12  ; [pp+0x12498] TypeParameter: X0 bound StatefulWidget
    //     0xf375a0: ldr             x8, [x8, #0x498]
    // 0xf375a4: LoadField: r9 = r4->field_7
    //     0xf375a4: ldur            x9, [x4, #7]
    // 0xf375a8: r3 = Null
    //     0xf375a8: add             x3, PP, #0x90, lsl #12  ; [pp+0x90678] Null
    //     0xf375ac: ldr             x3, [x3, #0x678]
    // 0xf375b0: blr             x9
    // 0xf375b4: ldur            x0, [fp, #-8]
    // 0xf375b8: LoadField: r1 = r0->field_b
    //     0xf375b8: ldur            w1, [x0, #0xb]
    // 0xf375bc: DecompressPointer r1
    //     0xf375bc: add             x1, x1, HEAP, lsl #32
    // 0xf375c0: cmp             w1, NULL
    // 0xf375c4: b.eq            #0xf3776c
    // 0xf375c8: LoadField: r2 = r1->field_2b
    //     0xf375c8: ldur            w2, [x1, #0x2b]
    // 0xf375cc: DecompressPointer r2
    //     0xf375cc: add             x2, x2, HEAP, lsl #32
    // 0xf375d0: ldur            x3, [fp, #-0x10]
    // 0xf375d4: LoadField: r4 = r3->field_2b
    //     0xf375d4: ldur            w4, [x3, #0x2b]
    // 0xf375d8: DecompressPointer r4
    //     0xf375d8: add             x4, x4, HEAP, lsl #32
    // 0xf375dc: stur            x4, [fp, #-0x18]
    // 0xf375e0: cmp             w2, w4
    // 0xf375e4: b.eq            #0xf37654
    // 0xf375e8: cmp             w4, NULL
    // 0xf375ec: b.eq            #0xf37610
    // 0xf375f0: mov             x2, x0
    // 0xf375f4: r1 = Function 'handleStatesControllerChange':.
    //     0xf375f4: add             x1, PP, #0x90, lsl #12  ; [pp+0x90650] AnonymousClosure: (0xf379c4), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::handleStatesControllerChange (0xf379fc)
    //     0xf375f8: ldr             x1, [x1, #0x650]
    // 0xf375fc: r0 = AllocateClosure()
    //     0xf375fc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf37600: ldur            x1, [fp, #-0x18]
    // 0xf37604: mov             x2, x0
    // 0xf37608: r0 = removeListener()
    //     0xf37608: bl              #0xcff968  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xf3760c: ldur            x0, [fp, #-8]
    // 0xf37610: LoadField: r1 = r0->field_b
    //     0xf37610: ldur            w1, [x0, #0xb]
    // 0xf37614: DecompressPointer r1
    //     0xf37614: add             x1, x1, HEAP, lsl #32
    // 0xf37618: cmp             w1, NULL
    // 0xf3761c: b.eq            #0xf37770
    // 0xf37620: LoadField: r2 = r1->field_2b
    //     0xf37620: ldur            w2, [x1, #0x2b]
    // 0xf37624: DecompressPointer r2
    //     0xf37624: add             x2, x2, HEAP, lsl #32
    // 0xf37628: cmp             w2, NULL
    // 0xf3762c: b.eq            #0xf3764c
    // 0xf37630: LoadField: r1 = r0->field_27
    //     0xf37630: ldur            w1, [x0, #0x27]
    // 0xf37634: DecompressPointer r1
    //     0xf37634: add             x1, x1, HEAP, lsl #32
    // 0xf37638: cmp             w1, NULL
    // 0xf3763c: b.eq            #0xf37648
    // 0xf37640: r0 = dispose()
    //     0xf37640: bl              #0x10ef878  ; [dart:mixin_deduplication] _MixinApplication276&Object&ChangeNotifier::dispose
    // 0xf37644: ldur            x0, [fp, #-8]
    // 0xf37648: StoreField: r0->field_27 = rNULL
    //     0xf37648: stur            NULL, [x0, #0x27]
    // 0xf3764c: mov             x1, x0
    // 0xf37650: r0 = initStatesController()
    //     0xf37650: bl              #0xf37784  ; [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::initStatesController
    // 0xf37654: ldur            x0, [fp, #-8]
    // 0xf37658: LoadField: r1 = r0->field_b
    //     0xf37658: ldur            w1, [x0, #0xb]
    // 0xf3765c: DecompressPointer r1
    //     0xf3765c: add             x1, x1, HEAP, lsl #32
    // 0xf37660: cmp             w1, NULL
    // 0xf37664: b.eq            #0xf37774
    // 0xf37668: LoadField: r2 = r1->field_b
    //     0xf37668: ldur            w2, [x1, #0xb]
    // 0xf3766c: DecompressPointer r2
    //     0xf3766c: add             x2, x2, HEAP, lsl #32
    // 0xf37670: cmp             w2, NULL
    // 0xf37674: b.eq            #0xf37680
    // 0xf37678: r4 = true
    //     0xf37678: add             x4, NULL, #0x20  ; true
    // 0xf3767c: b               #0xf37684
    // 0xf37680: r4 = false
    //     0xf37680: add             x4, NULL, #0x30  ; false
    // 0xf37684: ldur            x3, [fp, #-0x10]
    // 0xf37688: LoadField: r5 = r3->field_b
    //     0xf37688: ldur            w5, [x3, #0xb]
    // 0xf3768c: DecompressPointer r5
    //     0xf3768c: add             x5, x5, HEAP, lsl #32
    // 0xf37690: cmp             w5, NULL
    // 0xf37694: b.eq            #0xf376a0
    // 0xf37698: r3 = true
    //     0xf37698: add             x3, NULL, #0x20  ; true
    // 0xf3769c: b               #0xf376a4
    // 0xf376a0: r3 = false
    //     0xf376a0: add             x3, NULL, #0x30  ; false
    // 0xf376a4: cmp             w4, w3
    // 0xf376a8: b.eq            #0xf37754
    // 0xf376ac: LoadField: r3 = r1->field_2b
    //     0xf376ac: ldur            w3, [x1, #0x2b]
    // 0xf376b0: DecompressPointer r3
    //     0xf376b0: add             x3, x3, HEAP, lsl #32
    // 0xf376b4: cmp             w3, NULL
    // 0xf376b8: b.ne            #0xf376d0
    // 0xf376bc: LoadField: r1 = r0->field_27
    //     0xf376bc: ldur            w1, [x0, #0x27]
    // 0xf376c0: DecompressPointer r1
    //     0xf376c0: add             x1, x1, HEAP, lsl #32
    // 0xf376c4: cmp             w1, NULL
    // 0xf376c8: b.eq            #0xf37778
    // 0xf376cc: b               #0xf376d4
    // 0xf376d0: mov             x1, x3
    // 0xf376d4: cmp             w2, NULL
    // 0xf376d8: b.eq            #0xf376e4
    // 0xf376dc: r2 = true
    //     0xf376dc: add             x2, NULL, #0x20  ; true
    // 0xf376e0: b               #0xf376e8
    // 0xf376e4: r2 = false
    //     0xf376e4: add             x2, NULL, #0x30  ; false
    // 0xf376e8: eor             x3, x2, #0x10
    // 0xf376ec: r2 = Instance_WidgetState
    //     0xf376ec: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xf376f0: ldr             x2, [x2, #0xa70]
    // 0xf376f4: r0 = update()
    //     0xf376f4: bl              #0xd223e0  ; [package:flutter/src/widgets/widget_state.dart] WidgetStatesController::update
    // 0xf376f8: ldur            x0, [fp, #-8]
    // 0xf376fc: LoadField: r1 = r0->field_b
    //     0xf376fc: ldur            w1, [x0, #0xb]
    // 0xf37700: DecompressPointer r1
    //     0xf37700: add             x1, x1, HEAP, lsl #32
    // 0xf37704: cmp             w1, NULL
    // 0xf37708: b.eq            #0xf3777c
    // 0xf3770c: LoadField: r2 = r1->field_b
    //     0xf3770c: ldur            w2, [x1, #0xb]
    // 0xf37710: DecompressPointer r2
    //     0xf37710: add             x2, x2, HEAP, lsl #32
    // 0xf37714: cmp             w2, NULL
    // 0xf37718: b.ne            #0xf37754
    // 0xf3771c: LoadField: r2 = r1->field_2b
    //     0xf3771c: ldur            w2, [x1, #0x2b]
    // 0xf37720: DecompressPointer r2
    //     0xf37720: add             x2, x2, HEAP, lsl #32
    // 0xf37724: cmp             w2, NULL
    // 0xf37728: b.ne            #0xf37740
    // 0xf3772c: LoadField: r1 = r0->field_27
    //     0xf3772c: ldur            w1, [x0, #0x27]
    // 0xf37730: DecompressPointer r1
    //     0xf37730: add             x1, x1, HEAP, lsl #32
    // 0xf37734: cmp             w1, NULL
    // 0xf37738: b.eq            #0xf37780
    // 0xf3773c: b               #0xf37744
    // 0xf37740: mov             x1, x2
    // 0xf37744: r2 = Instance_WidgetState
    //     0xf37744: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0xf37748: ldr             x2, [x2, #0xa48]
    // 0xf3774c: r3 = false
    //     0xf3774c: add             x3, NULL, #0x30  ; false
    // 0xf37750: r0 = update()
    //     0xf37750: bl              #0xd223e0  ; [package:flutter/src/widgets/widget_state.dart] WidgetStatesController::update
    // 0xf37754: r0 = Null
    //     0xf37754: mov             x0, NULL
    // 0xf37758: LeaveFrame
    //     0xf37758: mov             SP, fp
    //     0xf3775c: ldp             fp, lr, [SP], #0x10
    // 0xf37760: ret
    //     0xf37760: ret             
    // 0xf37764: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf37764: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf37768: b               #0xf37538
    // 0xf3776c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3776c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf37770: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf37770: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf37774: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf37774: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf37778: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf37778: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3777c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3777c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf37780: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf37780: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initStatesController(/* No info */) {
    // ** addr: 0xf37784, size: 0x164
    // 0xf37784: EnterFrame
    //     0xf37784: stp             fp, lr, [SP, #-0x10]!
    //     0xf37788: mov             fp, SP
    // 0xf3778c: AllocStack(0x10)
    //     0xf3778c: sub             SP, SP, #0x10
    // 0xf37790: SetupParameters(_ButtonStyleState this /* r1 => r2, fp-0x8 */)
    //     0xf37790: mov             x2, x1
    //     0xf37794: stur            x1, [fp, #-8]
    // 0xf37798: CheckStackOverflow
    //     0xf37798: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3779c: cmp             SP, x16
    //     0xf377a0: b.ls            #0xf378cc
    // 0xf377a4: LoadField: r0 = r2->field_b
    //     0xf377a4: ldur            w0, [x2, #0xb]
    // 0xf377a8: DecompressPointer r0
    //     0xf377a8: add             x0, x0, HEAP, lsl #32
    // 0xf377ac: cmp             w0, NULL
    // 0xf377b0: b.eq            #0xf378d4
    // 0xf377b4: LoadField: r1 = r0->field_2b
    //     0xf377b4: ldur            w1, [x0, #0x2b]
    // 0xf377b8: DecompressPointer r1
    //     0xf377b8: add             x1, x1, HEAP, lsl #32
    // 0xf377bc: cmp             w1, NULL
    // 0xf377c0: b.ne            #0xf37804
    // 0xf377c4: r1 = <Set<WidgetState>>
    //     0xf377c4: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f978] TypeArguments: <Set<WidgetState>>
    //     0xf377c8: ldr             x1, [x1, #0x978]
    // 0xf377cc: r0 = WidgetStatesController()
    //     0xf377cc: bl              #0xf379b8  ; AllocateWidgetStatesControllerStub -> WidgetStatesController (size=0x2c)
    // 0xf377d0: mov             x1, x0
    // 0xf377d4: stur            x0, [fp, #-0x10]
    // 0xf377d8: r0 = WidgetStatesController()
    //     0xf377d8: bl              #0xf378e8  ; [package:flutter/src/widgets/widget_state.dart] WidgetStatesController::WidgetStatesController
    // 0xf377dc: ldur            x0, [fp, #-0x10]
    // 0xf377e0: ldur            x4, [fp, #-8]
    // 0xf377e4: StoreField: r4->field_27 = r0
    //     0xf377e4: stur            w0, [x4, #0x27]
    //     0xf377e8: ldurb           w16, [x4, #-1]
    //     0xf377ec: ldurb           w17, [x0, #-1]
    //     0xf377f0: and             x16, x17, x16, lsr #2
    //     0xf377f4: tst             x16, HEAP, lsr #32
    //     0xf377f8: b.eq            #0xf37800
    //     0xf377fc: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xf37800: b               #0xf37808
    // 0xf37804: mov             x4, x2
    // 0xf37808: LoadField: r0 = r4->field_b
    //     0xf37808: ldur            w0, [x4, #0xb]
    // 0xf3780c: DecompressPointer r0
    //     0xf3780c: add             x0, x0, HEAP, lsl #32
    // 0xf37810: cmp             w0, NULL
    // 0xf37814: b.eq            #0xf378d8
    // 0xf37818: LoadField: r1 = r0->field_2b
    //     0xf37818: ldur            w1, [x0, #0x2b]
    // 0xf3781c: DecompressPointer r1
    //     0xf3781c: add             x1, x1, HEAP, lsl #32
    // 0xf37820: cmp             w1, NULL
    // 0xf37824: b.ne            #0xf37838
    // 0xf37828: LoadField: r1 = r4->field_27
    //     0xf37828: ldur            w1, [x4, #0x27]
    // 0xf3782c: DecompressPointer r1
    //     0xf3782c: add             x1, x1, HEAP, lsl #32
    // 0xf37830: cmp             w1, NULL
    // 0xf37834: b.eq            #0xf378dc
    // 0xf37838: LoadField: r2 = r0->field_b
    //     0xf37838: ldur            w2, [x0, #0xb]
    // 0xf3783c: DecompressPointer r2
    //     0xf3783c: add             x2, x2, HEAP, lsl #32
    // 0xf37840: cmp             w2, NULL
    // 0xf37844: b.eq            #0xf37850
    // 0xf37848: r0 = true
    //     0xf37848: add             x0, NULL, #0x20  ; true
    // 0xf3784c: b               #0xf37854
    // 0xf37850: r0 = false
    //     0xf37850: add             x0, NULL, #0x30  ; false
    // 0xf37854: eor             x3, x0, #0x10
    // 0xf37858: r2 = Instance_WidgetState
    //     0xf37858: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xf3785c: ldr             x2, [x2, #0xa70]
    // 0xf37860: r0 = update()
    //     0xf37860: bl              #0xd223e0  ; [package:flutter/src/widgets/widget_state.dart] WidgetStatesController::update
    // 0xf37864: ldur            x2, [fp, #-8]
    // 0xf37868: LoadField: r0 = r2->field_b
    //     0xf37868: ldur            w0, [x2, #0xb]
    // 0xf3786c: DecompressPointer r0
    //     0xf3786c: add             x0, x0, HEAP, lsl #32
    // 0xf37870: cmp             w0, NULL
    // 0xf37874: b.eq            #0xf378e0
    // 0xf37878: LoadField: r1 = r0->field_2b
    //     0xf37878: ldur            w1, [x0, #0x2b]
    // 0xf3787c: DecompressPointer r1
    //     0xf3787c: add             x1, x1, HEAP, lsl #32
    // 0xf37880: cmp             w1, NULL
    // 0xf37884: b.ne            #0xf3789c
    // 0xf37888: LoadField: r0 = r2->field_27
    //     0xf37888: ldur            w0, [x2, #0x27]
    // 0xf3788c: DecompressPointer r0
    //     0xf3788c: add             x0, x0, HEAP, lsl #32
    // 0xf37890: cmp             w0, NULL
    // 0xf37894: b.eq            #0xf378e4
    // 0xf37898: b               #0xf378a0
    // 0xf3789c: mov             x0, x1
    // 0xf378a0: stur            x0, [fp, #-0x10]
    // 0xf378a4: r1 = Function 'handleStatesControllerChange':.
    //     0xf378a4: add             x1, PP, #0x90, lsl #12  ; [pp+0x90650] AnonymousClosure: (0xf379c4), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::handleStatesControllerChange (0xf379fc)
    //     0xf378a8: ldr             x1, [x1, #0x650]
    // 0xf378ac: r0 = AllocateClosure()
    //     0xf378ac: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf378b0: ldur            x1, [fp, #-0x10]
    // 0xf378b4: mov             x2, x0
    // 0xf378b8: r0 = addListener()
    //     0xf378b8: bl              #0xd038e0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0xf378bc: r0 = Null
    //     0xf378bc: mov             x0, NULL
    // 0xf378c0: LeaveFrame
    //     0xf378c0: mov             SP, fp
    //     0xf378c4: ldp             fp, lr, [SP], #0x10
    // 0xf378c8: ret
    //     0xf378c8: ret             
    // 0xf378cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf378cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf378d0: b               #0xf377a4
    // 0xf378d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf378d4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf378d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf378d8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf378dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf378dc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf378e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf378e0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf378e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf378e4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void handleStatesControllerChange(dynamic) {
    // ** addr: 0xf379c4, size: 0x38
    // 0xf379c4: EnterFrame
    //     0xf379c4: stp             fp, lr, [SP, #-0x10]!
    //     0xf379c8: mov             fp, SP
    // 0xf379cc: ldr             x0, [fp, #0x10]
    // 0xf379d0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf379d0: ldur            w1, [x0, #0x17]
    // 0xf379d4: DecompressPointer r1
    //     0xf379d4: add             x1, x1, HEAP, lsl #32
    // 0xf379d8: CheckStackOverflow
    //     0xf379d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf379dc: cmp             SP, x16
    //     0xf379e0: b.ls            #0xf379f4
    // 0xf379e4: r0 = handleStatesControllerChange()
    //     0xf379e4: bl              #0xf379fc  ; [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::handleStatesControllerChange
    // 0xf379e8: LeaveFrame
    //     0xf379e8: mov             SP, fp
    //     0xf379ec: ldp             fp, lr, [SP], #0x10
    // 0xf379f0: ret
    //     0xf379f0: ret             
    // 0xf379f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf379f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf379f8: b               #0xf379e4
  }
  _ handleStatesControllerChange(/* No info */) {
    // ** addr: 0xf379fc, size: 0x54
    // 0xf379fc: EnterFrame
    //     0xf379fc: stp             fp, lr, [SP, #-0x10]!
    //     0xf37a00: mov             fp, SP
    // 0xf37a04: AllocStack(0x8)
    //     0xf37a04: sub             SP, SP, #8
    // 0xf37a08: SetupParameters(_ButtonStyleState this /* r1 => r0, fp-0x8 */)
    //     0xf37a08: mov             x0, x1
    //     0xf37a0c: stur            x1, [fp, #-8]
    // 0xf37a10: CheckStackOverflow
    //     0xf37a10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf37a14: cmp             SP, x16
    //     0xf37a18: b.ls            #0xf37a48
    // 0xf37a1c: r1 = Function '<anonymous closure>':.
    //     0xf37a1c: add             x1, PP, #0x90, lsl #12  ; [pp+0x90658] Function: [dart:ui] Shader::Shader._ (0x13cf838)
    //     0xf37a20: ldr             x1, [x1, #0x658]
    // 0xf37a24: r2 = Null
    //     0xf37a24: mov             x2, NULL
    // 0xf37a28: r0 = AllocateClosure()
    //     0xf37a28: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf37a2c: ldur            x1, [fp, #-8]
    // 0xf37a30: mov             x2, x0
    // 0xf37a34: r0 = setState()
    //     0xf37a34: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xf37a38: r0 = Null
    //     0xf37a38: mov             x0, NULL
    // 0xf37a3c: LeaveFrame
    //     0xf37a3c: mov             SP, fp
    //     0xf37a40: ldp             fp, lr, [SP], #0x10
    // 0xf37a44: ret
    //     0xf37a44: ret             
    // 0xf37a48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf37a48: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf37a4c: b               #0xf37a1c
  }
  _ initState(/* No info */) {
    // ** addr: 0xf791e4, size: 0x30
    // 0xf791e4: EnterFrame
    //     0xf791e4: stp             fp, lr, [SP, #-0x10]!
    //     0xf791e8: mov             fp, SP
    // 0xf791ec: CheckStackOverflow
    //     0xf791ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf791f0: cmp             SP, x16
    //     0xf791f4: b.ls            #0xf7920c
    // 0xf791f8: r0 = initStatesController()
    //     0xf791f8: bl              #0xf37784  ; [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::initStatesController
    // 0xf791fc: r0 = Null
    //     0xf791fc: mov             x0, NULL
    // 0xf79200: LeaveFrame
    //     0xf79200: mov             SP, fp
    //     0xf79204: ldp             fp, lr, [SP], #0x10
    // 0xf79208: ret
    //     0xf79208: ret             
    // 0xf7920c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf7920c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf79210: b               #0xf791f8
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10dc19c, size: 0xd4
    // 0x10dc19c: EnterFrame
    //     0x10dc19c: stp             fp, lr, [SP, #-0x10]!
    //     0x10dc1a0: mov             fp, SP
    // 0x10dc1a4: AllocStack(0x10)
    //     0x10dc1a4: sub             SP, SP, #0x10
    // 0x10dc1a8: SetupParameters(_ButtonStyleState this /* r1 => r0, fp-0x10 */)
    //     0x10dc1a8: mov             x0, x1
    //     0x10dc1ac: stur            x1, [fp, #-0x10]
    // 0x10dc1b0: CheckStackOverflow
    //     0x10dc1b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10dc1b4: cmp             SP, x16
    //     0x10dc1b8: b.ls            #0x10dc260
    // 0x10dc1bc: LoadField: r1 = r0->field_b
    //     0x10dc1bc: ldur            w1, [x0, #0xb]
    // 0x10dc1c0: DecompressPointer r1
    //     0x10dc1c0: add             x1, x1, HEAP, lsl #32
    // 0x10dc1c4: cmp             w1, NULL
    // 0x10dc1c8: b.eq            #0x10dc268
    // 0x10dc1cc: LoadField: r2 = r1->field_2b
    //     0x10dc1cc: ldur            w2, [x1, #0x2b]
    // 0x10dc1d0: DecompressPointer r2
    //     0x10dc1d0: add             x2, x2, HEAP, lsl #32
    // 0x10dc1d4: cmp             w2, NULL
    // 0x10dc1d8: b.ne            #0x10dc1f4
    // 0x10dc1dc: LoadField: r1 = r0->field_27
    //     0x10dc1dc: ldur            w1, [x0, #0x27]
    // 0x10dc1e0: DecompressPointer r1
    //     0x10dc1e0: add             x1, x1, HEAP, lsl #32
    // 0x10dc1e4: cmp             w1, NULL
    // 0x10dc1e8: b.eq            #0x10dc26c
    // 0x10dc1ec: mov             x3, x1
    // 0x10dc1f0: b               #0x10dc1f8
    // 0x10dc1f4: mov             x3, x2
    // 0x10dc1f8: mov             x2, x0
    // 0x10dc1fc: stur            x3, [fp, #-8]
    // 0x10dc200: r1 = Function 'handleStatesControllerChange':.
    //     0x10dc200: add             x1, PP, #0x90, lsl #12  ; [pp+0x90650] AnonymousClosure: (0xf379c4), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::handleStatesControllerChange (0xf379fc)
    //     0x10dc204: ldr             x1, [x1, #0x650]
    // 0x10dc208: r0 = AllocateClosure()
    //     0x10dc208: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10dc20c: ldur            x1, [fp, #-8]
    // 0x10dc210: mov             x2, x0
    // 0x10dc214: r0 = removeListener()
    //     0x10dc214: bl              #0xcff968  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x10dc218: ldur            x0, [fp, #-0x10]
    // 0x10dc21c: LoadField: r1 = r0->field_27
    //     0x10dc21c: ldur            w1, [x0, #0x27]
    // 0x10dc220: DecompressPointer r1
    //     0x10dc220: add             x1, x1, HEAP, lsl #32
    // 0x10dc224: cmp             w1, NULL
    // 0x10dc228: b.eq            #0x10dc234
    // 0x10dc22c: r0 = dispose()
    //     0x10dc22c: bl              #0x10ef878  ; [dart:mixin_deduplication] _MixinApplication276&Object&ChangeNotifier::dispose
    // 0x10dc230: ldur            x0, [fp, #-0x10]
    // 0x10dc234: LoadField: r1 = r0->field_1b
    //     0x10dc234: ldur            w1, [x0, #0x1b]
    // 0x10dc238: DecompressPointer r1
    //     0x10dc238: add             x1, x1, HEAP, lsl #32
    // 0x10dc23c: cmp             w1, NULL
    // 0x10dc240: b.eq            #0x10dc248
    // 0x10dc244: r0 = dispose()
    //     0x10dc244: bl              #0x9164f4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x10dc248: ldur            x1, [fp, #-0x10]
    // 0x10dc24c: r0 = dispose()
    //     0x10dc24c: bl              #0x10dc270  ; [dart:mixin_deduplication] _MixinApplication17&State&TickerProviderStateMixin::dispose
    // 0x10dc250: r0 = Null
    //     0x10dc250: mov             x0, NULL
    // 0x10dc254: LeaveFrame
    //     0x10dc254: mov             SP, fp
    //     0x10dc258: ldp             fp, lr, [SP], #0x10
    // 0x10dc25c: ret
    //     0x10dc25c: ret             
    // 0x10dc260: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10dc260: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10dc264: b               #0x10dc1bc
    // 0x10dc268: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10dc268: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x10dc26c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10dc26c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 6494, size: 0x3c, field offset: 0xc
//   const constructor, 
abstract class ButtonStyleButton extends StatefulWidget {

  static _ allOrNull(/* No info */) {
    // ** addr: 0xd17190, size: 0x50
    // 0xd17190: EnterFrame
    //     0xd17190: stp             fp, lr, [SP, #-0x10]!
    //     0xd17194: mov             fp, SP
    // 0xd17198: LoadField: r0 = r4->field_f
    //     0xd17198: ldur            w0, [x4, #0xf]
    // 0xd1719c: cbnz            w0, #0xd171a8
    // 0xd171a0: r1 = Null
    //     0xd171a0: mov             x1, NULL
    // 0xd171a4: b               #0xd171b4
    // 0xd171a8: ArrayLoad: r0 = r4[0]  ; List_4
    //     0xd171a8: ldur            w0, [x4, #0x17]
    // 0xd171ac: add             x1, fp, w0, sxtw #2
    // 0xd171b0: ldr             x1, [x1, #0x10]
    // 0xd171b4: ldr             x0, [fp, #0x10]
    // 0xd171b8: cmp             w0, NULL
    // 0xd171bc: b.ne            #0xd171c8
    // 0xd171c0: r0 = Null
    //     0xd171c0: mov             x0, NULL
    // 0xd171c4: b               #0xd171d4
    // 0xd171c8: r0 = WidgetStatePropertyAll()
    //     0xd171c8: bl              #0xd132c8  ; AllocateWidgetStatePropertyAllStub -> WidgetStatePropertyAll<X0> (size=0x10)
    // 0xd171cc: ldr             x1, [fp, #0x10]
    // 0xd171d0: StoreField: r0->field_b = r1
    //     0xd171d0: stur            w1, [x0, #0xb]
    // 0xd171d4: LeaveFrame
    //     0xd171d4: mov             SP, fp
    //     0xd171d8: ldp             fp, lr, [SP], #0x10
    // 0xd171dc: ret
    //     0xd171dc: ret             
  }
  static _ defaultColor(/* No info */) {
    // ** addr: 0xd171ec, size: 0xb8
    // 0xd171ec: EnterFrame
    //     0xd171ec: stp             fp, lr, [SP, #-0x10]!
    //     0xd171f0: mov             fp, SP
    // 0xd171f4: AllocStack(0x20)
    //     0xd171f4: sub             SP, SP, #0x20
    // 0xd171f8: SetupParameters(dynamic _ /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xd171f8: mov             x3, x1
    //     0xd171fc: mov             x0, x2
    //     0xd17200: stur            x1, [fp, #-8]
    //     0xd17204: stur            x2, [fp, #-0x10]
    // 0xd17208: CheckStackOverflow
    //     0xd17208: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd1720c: cmp             SP, x16
    //     0xd17210: b.ls            #0xd1729c
    // 0xd17214: cmp             w3, NULL
    // 0xd17218: b.ne            #0xd17234
    // 0xd1721c: cmp             w0, NULL
    // 0xd17220: b.ne            #0xd17234
    // 0xd17224: r0 = Null
    //     0xd17224: mov             x0, NULL
    // 0xd17228: LeaveFrame
    //     0xd17228: mov             SP, fp
    //     0xd1722c: ldp             fp, lr, [SP], #0x10
    // 0xd17230: ret
    //     0xd17230: ret             
    // 0xd17234: r1 = Null
    //     0xd17234: mov             x1, NULL
    // 0xd17238: r2 = 8
    //     0xd17238: mov             x2, #8
    // 0xd1723c: r0 = AllocateArray()
    //     0xd1723c: bl              #0x13df928  ; AllocateArrayStub
    // 0xd17240: r16 = Instance_WidgetState
    //     0xd17240: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xd17244: ldr             x16, [x16, #0xa70]
    // 0xd17248: StoreField: r0->field_f = r16
    //     0xd17248: stur            w16, [x0, #0xf]
    // 0xd1724c: ldur            x1, [fp, #-0x10]
    // 0xd17250: StoreField: r0->field_13 = r1
    //     0xd17250: stur            w1, [x0, #0x13]
    // 0xd17254: r16 = Instance__AnyWidgetStates
    //     0xd17254: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a78] Obj!_AnyWidgetStates@12aa401
    //     0xd17258: ldr             x16, [x16, #0xa78]
    // 0xd1725c: ArrayStore: r0[0] = r16  ; List_4
    //     0xd1725c: stur            w16, [x0, #0x17]
    // 0xd17260: ldur            x1, [fp, #-8]
    // 0xd17264: StoreField: r0->field_1b = r1
    //     0xd17264: stur            w1, [x0, #0x1b]
    // 0xd17268: r16 = <WidgetStatesConstraint, Color?>
    //     0xd17268: add             x16, PP, #0x15, lsl #12  ; [pp+0x15ac0] TypeArguments: <WidgetStatesConstraint, Color?>
    //     0xd1726c: ldr             x16, [x16, #0xac0]
    // 0xd17270: stp             x0, x16, [SP]
    // 0xd17274: r0 = Map._fromLiteral()
    //     0xd17274: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xd17278: r1 = <Color?>
    //     0xd17278: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xd1727c: ldr             x1, [x1, #0xa40]
    // 0xd17280: stur            x0, [fp, #-8]
    // 0xd17284: r0 = WidgetStateMapper()
    //     0xd17284: bl              #0xd171e0  ; AllocateWidgetStateMapperStub -> WidgetStateMapper<X0> (size=0x10)
    // 0xd17288: ldur            x1, [fp, #-8]
    // 0xd1728c: StoreField: r0->field_b = r1
    //     0xd1728c: stur            w1, [x0, #0xb]
    // 0xd17290: LeaveFrame
    //     0xd17290: mov             SP, fp
    //     0xd17294: ldp             fp, lr, [SP], #0x10
    // 0xd17298: ret
    //     0xd17298: ret             
    // 0xd1729c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1729c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd172a0: b               #0xd17214
  }
  _ createState(/* No info */) {
    // ** addr: 0xfa0e48, size: 0x24
    // 0xfa0e48: EnterFrame
    //     0xfa0e48: stp             fp, lr, [SP, #-0x10]!
    //     0xfa0e4c: mov             fp, SP
    // 0xfa0e50: mov             x0, x1
    // 0xfa0e54: r1 = <ButtonStyleButton>
    //     0xfa0e54: add             x1, PP, #0x85, lsl #12  ; [pp+0x851b8] TypeArguments: <ButtonStyleButton>
    //     0xfa0e58: ldr             x1, [x1, #0x1b8]
    // 0xfa0e5c: r0 = _ButtonStyleState()
    //     0xfa0e5c: bl              #0xfa0e6c  ; Allocate_ButtonStyleStateStub -> _ButtonStyleState (size=0x2c)
    // 0xfa0e60: LeaveFrame
    //     0xfa0e60: mov             SP, fp
    //     0xfa0e64: ldp             fp, lr, [SP], #0x10
    // 0xfa0e68: ret
    //     0xfa0e68: ret             
  }
  static _ scaledPadding(/* No info */) {
    // ** addr: 0x1140cd0, size: 0x110
    // 0x1140cd0: EnterFrame
    //     0x1140cd0: stp             fp, lr, [SP, #-0x10]!
    //     0x1140cd4: mov             fp, SP
    // 0x1140cd8: d1 = 1.000000
    //     0x1140cd8: fmov            d1, #1.00000000
    // 0x1140cdc: mov             x0, x2
    // 0x1140ce0: mov             x2, x3
    // 0x1140ce4: CheckStackOverflow
    //     0x1140ce4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1140ce8: cmp             SP, x16
    //     0x1140cec: b.ls            #0x1140da0
    // 0x1140cf0: fcmp            d1, d0
    // 0x1140cf4: b.lt            #0x1140d00
    // 0x1140cf8: mov             x0, x1
    // 0x1140cfc: b               #0x1140d94
    // 0x1140d00: d2 = 2.000000
    //     0x1140d00: fmov            d2, #2.00000000
    // 0x1140d04: fcmp            d2, d0
    // 0x1140d08: b.le            #0x1140d48
    // 0x1140d0c: fsub            d2, d0, d1
    // 0x1140d10: r3 = inline_Allocate_Double()
    //     0x1140d10: ldp             x3, x2, [THR, #0x60]  ; THR::top
    //     0x1140d14: add             x3, x3, #0x10
    //     0x1140d18: cmp             x2, x3
    //     0x1140d1c: b.ls            #0x1140da8
    //     0x1140d20: str             x3, [THR, #0x60]  ; THR::top
    //     0x1140d24: sub             x3, x3, #0xf
    //     0x1140d28: mov             x2, #0xe19c
    //     0x1140d2c: movk            x2, #3, lsl #16
    //     0x1140d30: stur            x2, [x3, #-1]
    // 0x1140d34: dmb             ishst
    // 0x1140d38: StoreField: r3->field_7 = d2
    //     0x1140d38: stur            d2, [x3, #7]
    // 0x1140d3c: mov             x2, x0
    // 0x1140d40: r0 = lerp()
    //     0x1140d40: bl              #0x1140de0  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0x1140d44: b               #0x1140d94
    // 0x1140d48: d1 = 3.000000
    //     0x1140d48: fmov            d1, #3.00000000
    // 0x1140d4c: fcmp            d1, d0
    // 0x1140d50: b.le            #0x1140d90
    // 0x1140d54: fsub            d1, d0, d2
    // 0x1140d58: r3 = inline_Allocate_Double()
    //     0x1140d58: ldp             x3, x1, [THR, #0x60]  ; THR::top
    //     0x1140d5c: add             x3, x3, #0x10
    //     0x1140d60: cmp             x1, x3
    //     0x1140d64: b.ls            #0x1140dc4
    //     0x1140d68: str             x3, [THR, #0x60]  ; THR::top
    //     0x1140d6c: sub             x3, x3, #0xf
    //     0x1140d70: mov             x1, #0xe19c
    //     0x1140d74: movk            x1, #3, lsl #16
    //     0x1140d78: stur            x1, [x3, #-1]
    // 0x1140d7c: dmb             ishst
    // 0x1140d80: StoreField: r3->field_7 = d1
    //     0x1140d80: stur            d1, [x3, #7]
    // 0x1140d84: mov             x1, x0
    // 0x1140d88: r0 = lerp()
    //     0x1140d88: bl              #0x1140de0  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0x1140d8c: b               #0x1140d94
    // 0x1140d90: mov             x0, x2
    // 0x1140d94: LeaveFrame
    //     0x1140d94: mov             SP, fp
    //     0x1140d98: ldp             fp, lr, [SP], #0x10
    // 0x1140d9c: ret
    //     0x1140d9c: ret             
    // 0x1140da0: r0 = StackOverflowSharedWithFPURegs()
    //     0x1140da0: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1140da4: b               #0x1140cf0
    // 0x1140da8: SaveReg d2
    //     0x1140da8: str             q2, [SP, #-0x10]!
    // 0x1140dac: stp             x0, x1, [SP, #-0x10]!
    // 0x1140db0: r0 = AllocateDouble()
    //     0x1140db0: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1140db4: mov             x3, x0
    // 0x1140db8: ldp             x0, x1, [SP], #0x10
    // 0x1140dbc: RestoreReg d2
    //     0x1140dbc: ldr             q2, [SP], #0x10
    // 0x1140dc0: b               #0x1140d38
    // 0x1140dc4: SaveReg d1
    //     0x1140dc4: str             q1, [SP, #-0x10]!
    // 0x1140dc8: stp             x0, x2, [SP, #-0x10]!
    // 0x1140dcc: r0 = AllocateDouble()
    //     0x1140dcc: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1140dd0: mov             x3, x0
    // 0x1140dd4: ldp             x0, x2, [SP], #0x10
    // 0x1140dd8: RestoreReg d1
    //     0x1140dd8: ldr             q1, [SP], #0x10
    // 0x1140ddc: b               #0x1140d80
  }
}

// class id: 6655, size: 0x14, field offset: 0x10
//   const constructor, 
class _InputPadding extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf49c0, size: 0x8c
    // 0xcf49c0: EnterFrame
    //     0xcf49c0: stp             fp, lr, [SP, #-0x10]!
    //     0xcf49c4: mov             fp, SP
    // 0xcf49c8: AllocStack(0x10)
    //     0xcf49c8: sub             SP, SP, #0x10
    // 0xcf49cc: SetupParameters(_InputPadding this /* r1 => r4, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xcf49cc: mov             x4, x1
    //     0xcf49d0: stur            x1, [fp, #-8]
    //     0xcf49d4: stur            x3, [fp, #-0x10]
    // 0xcf49d8: CheckStackOverflow
    //     0xcf49d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf49dc: cmp             SP, x16
    //     0xcf49e0: b.ls            #0xcf4a44
    // 0xcf49e4: mov             x0, x3
    // 0xcf49e8: r2 = Null
    //     0xcf49e8: mov             x2, NULL
    // 0xcf49ec: r1 = Null
    //     0xcf49ec: mov             x1, NULL
    // 0xcf49f0: r4 = 60
    //     0xcf49f0: mov             x4, #0x3c
    // 0xcf49f4: branchIfSmi(r0, 0xcf4a00)
    //     0xcf49f4: tbz             w0, #0, #0xcf4a00
    // 0xcf49f8: r4 = LoadClassIdInstr(r0)
    //     0xcf49f8: ldur            x4, [x0, #-1]
    //     0xcf49fc: ubfx            x4, x4, #0xc, #0x14
    // 0xcf4a00: r17 = 4879
    //     0xcf4a00: mov             x17, #0x130f
    // 0xcf4a04: cmp             x4, x17
    // 0xcf4a08: b.eq            #0xcf4a20
    // 0xcf4a0c: r8 = _RenderInputPadding
    //     0xcf4a0c: add             x8, PP, #0x9a, lsl #12  ; [pp+0x9a118] Type: _RenderInputPadding
    //     0xcf4a10: ldr             x8, [x8, #0x118]
    // 0xcf4a14: r3 = Null
    //     0xcf4a14: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a120] Null
    //     0xcf4a18: ldr             x3, [x3, #0x120]
    // 0xcf4a1c: r0 = DefaultTypeTest()
    //     0xcf4a1c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf4a20: ldur            x0, [fp, #-8]
    // 0xcf4a24: LoadField: r2 = r0->field_f
    //     0xcf4a24: ldur            w2, [x0, #0xf]
    // 0xcf4a28: DecompressPointer r2
    //     0xcf4a28: add             x2, x2, HEAP, lsl #32
    // 0xcf4a2c: ldur            x1, [fp, #-0x10]
    // 0xcf4a30: r0 = minSize=()
    //     0xcf4a30: bl              #0xcf4938  ; [package:flutter/src/material/button.dart] _RenderInputPadding::minSize=
    // 0xcf4a34: r0 = Null
    //     0xcf4a34: mov             x0, NULL
    // 0xcf4a38: LeaveFrame
    //     0xcf4a38: mov             SP, fp
    //     0xcf4a3c: ldp             fp, lr, [SP], #0x10
    // 0xcf4a40: ret
    //     0xcf4a40: ret             
    // 0xcf4a44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf4a44: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf4a48: b               #0xcf49e4
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11cf914, size: 0x74
    // 0x11cf914: EnterFrame
    //     0x11cf914: stp             fp, lr, [SP, #-0x10]!
    //     0x11cf918: mov             fp, SP
    // 0x11cf91c: AllocStack(0x10)
    //     0x11cf91c: sub             SP, SP, #0x10
    // 0x11cf920: CheckStackOverflow
    //     0x11cf920: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11cf924: cmp             SP, x16
    //     0x11cf928: b.ls            #0x11cf980
    // 0x11cf92c: LoadField: r0 = r1->field_f
    //     0x11cf92c: ldur            w0, [x1, #0xf]
    // 0x11cf930: DecompressPointer r0
    //     0x11cf930: add             x0, x0, HEAP, lsl #32
    // 0x11cf934: stur            x0, [fp, #-8]
    // 0x11cf938: r0 = _RenderInputPadding()
    //     0x11cf938: bl              #0x11cf988  ; Allocate_RenderInputPaddingStub -> _RenderInputPadding (size=0x58)
    // 0x11cf93c: mov             x1, x0
    // 0x11cf940: ldur            x0, [fp, #-8]
    // 0x11cf944: stur            x1, [fp, #-0x10]
    // 0x11cf948: StoreField: r1->field_53 = r0
    //     0x11cf948: stur            w0, [x1, #0x53]
    // 0x11cf94c: r0 = _LayoutCacheStorage()
    //     0x11cf94c: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11cf950: mov             x1, x0
    // 0x11cf954: ldur            x0, [fp, #-0x10]
    // 0x11cf958: StoreField: r0->field_47 = r1
    //     0x11cf958: stur            w1, [x0, #0x47]
    // 0x11cf95c: mov             x1, x0
    // 0x11cf960: r0 = RenderObject()
    //     0x11cf960: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11cf964: ldur            x1, [fp, #-0x10]
    // 0x11cf968: r2 = Null
    //     0x11cf968: mov             x2, NULL
    // 0x11cf96c: r0 = child=()
    //     0x11cf96c: bl              #0xaef33c  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::child=
    // 0x11cf970: ldur            x0, [fp, #-0x10]
    // 0x11cf974: LeaveFrame
    //     0x11cf974: mov             SP, fp
    //     0x11cf978: ldp             fp, lr, [SP], #0x10
    // 0x11cf97c: ret
    //     0x11cf97c: ret             
    // 0x11cf980: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11cf980: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11cf984: b               #0x11cf92c
  }
}
