// lib: , url: package:flutter/src/material/tab_controller.dart

// class id: 1048956, size: 0x8
class :: {
}

// class id: 4489, size: 0x4c, field offset: 0x24
class TabController extends ChangeNotifier {

  const int dyn:get:length(TabController) {
    // ** addr: 0xae63cc, size: 0x48
    // 0xae63cc: ldr             x2, [SP]
    // 0xae63d0: LoadField: r3 = r2->field_2b
    //     0xae63d0: ldur            x3, [x2, #0x2b]
    // 0xae63d4: r0 = BoxInt64Instr(r3)
    //     0xae63d4: sbfiz           x0, x3, #1, #0x1f
    //     0xae63d8: cmp             x3, x0, asr #1
    //     0xae63dc: b.eq            #0xae63f8
    //     0xae63e0: stp             fp, lr, [SP, #-0x10]!
    //     0xae63e4: mov             fp, SP
    //     0xae63e8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xae63ec: mov             SP, fp
    //     0xae63f0: ldp             fp, lr, [SP], #0x10
    //     0xae63f4: stur            x3, [x0, #7]
    // 0xae63f8: ret
    //     0xae63f8: ret             
  }
  _ animateTo(/* No info */) {
    // ** addr: 0xdffdf0, size: 0x44
    // 0xdffdf0: EnterFrame
    //     0xdffdf0: stp             fp, lr, [SP, #-0x10]!
    //     0xdffdf4: mov             fp, SP
    // 0xdffdf8: AllocStack(0x10)
    //     0xdffdf8: sub             SP, SP, #0x10
    // 0xdffdfc: CheckStackOverflow
    //     0xdffdfc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdffe00: cmp             SP, x16
    //     0xdffe04: b.ls            #0xdffe2c
    // 0xdffe08: r16 = Instance_Duration
    //     0xdffe08: ldr             x16, [PP, #0x7cd8]  ; [pp+0x7cd8] Obj!Duration@12c8971
    // 0xdffe0c: r30 = Instance_Cubic
    //     0xdffe0c: ldr             lr, [PP, #0x53e8]  ; [pp+0x53e8] Obj!Cubic@129f421
    // 0xdffe10: stp             lr, x16, [SP]
    // 0xdffe14: r4 = const [0, 0x4, 0x2, 0x2, curve, 0x3, duration, 0x2, null]
    //     0xdffe14: ldr             x4, [PP, #0x5158]  ; [pp+0x5158] List(9) [0, 0x4, 0x2, 0x2, "curve", 0x3, "duration", 0x2, Null]
    // 0xdffe18: r0 = _changeIndex()
    //     0xdffe18: bl              #0xdffe34  ; [package:flutter/src/material/tab_controller.dart] TabController::_changeIndex
    // 0xdffe1c: r0 = Null
    //     0xdffe1c: mov             x0, NULL
    // 0xdffe20: LeaveFrame
    //     0xdffe20: mov             SP, fp
    //     0xdffe24: ldp             fp, lr, [SP], #0x10
    // 0xdffe28: ret
    //     0xdffe28: ret             
    // 0xdffe2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdffe2c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdffe30: b               #0xdffe08
  }
  _ _changeIndex(/* No info */) {
    // ** addr: 0xdffe34, size: 0x228
    // 0xdffe34: EnterFrame
    //     0xdffe34: stp             fp, lr, [SP, #-0x10]!
    //     0xdffe38: mov             fp, SP
    // 0xdffe3c: AllocStack(0x40)
    //     0xdffe3c: sub             SP, SP, #0x40
    // 0xdffe40: SetupParameters(TabController this /* r1 => r1, fp-0x18 */, dynamic _ /* r2 => r2, fp-0x20 */, {dynamic curve = Null /* r5, fp-0x10 */, dynamic duration = Null /* r0, fp-0x8 */})
    //     0xdffe40: stur            x1, [fp, #-0x18]
    //     0xdffe44: stur            x2, [fp, #-0x20]
    //     0xdffe48: ldur            w0, [x4, #0x13]
    //     0xdffe4c: ldur            w3, [x4, #0x1f]
    //     0xdffe50: add             x3, x3, HEAP, lsl #32
    //     0xdffe54: ldr             x16, [PP, #0x5160]  ; [pp+0x5160] "curve"
    //     0xdffe58: cmp             w3, w16
    //     0xdffe5c: b.ne            #0xdffe80
    //     0xdffe60: ldur            w3, [x4, #0x23]
    //     0xdffe64: add             x3, x3, HEAP, lsl #32
    //     0xdffe68: sub             w5, w0, w3
    //     0xdffe6c: add             x3, fp, w5, sxtw #2
    //     0xdffe70: ldr             x3, [x3, #8]
    //     0xdffe74: mov             x5, x3
    //     0xdffe78: mov             x3, #1
    //     0xdffe7c: b               #0xdffe88
    //     0xdffe80: mov             x5, NULL
    //     0xdffe84: mov             x3, #0
    //     0xdffe88: stur            x5, [fp, #-0x10]
    //     0xdffe8c: lsl             x6, x3, #1
    //     0xdffe90: lsl             w3, w6, #1
    //     0xdffe94: add             w6, w3, #8
    //     0xdffe98: add             x16, x4, w6, sxtw #1
    //     0xdffe9c: ldur            w7, [x16, #0xf]
    //     0xdffea0: add             x7, x7, HEAP, lsl #32
    //     0xdffea4: ldr             x16, [PP, #0x5170]  ; [pp+0x5170] "duration"
    //     0xdffea8: cmp             w7, w16
    //     0xdffeac: b.ne            #0xdffed0
    //     0xdffeb0: add             w6, w3, #0xa
    //     0xdffeb4: add             x16, x4, w6, sxtw #1
    //     0xdffeb8: ldur            w3, [x16, #0xf]
    //     0xdffebc: add             x3, x3, HEAP, lsl #32
    //     0xdffec0: sub             w4, w0, w3
    //     0xdffec4: add             x0, fp, w4, sxtw #2
    //     0xdffec8: ldr             x0, [x0, #8]
    //     0xdffecc: b               #0xdffed4
    //     0xdffed0: mov             x0, NULL
    //     0xdffed4: stur            x0, [fp, #-8]
    // 0xdffed8: CheckStackOverflow
    //     0xdffed8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdffedc: cmp             SP, x16
    //     0xdffee0: b.ls            #0xe0004c
    // 0xdffee4: r1 = 1
    //     0xdffee4: mov             x1, #1
    // 0xdffee8: r0 = AllocateContext()
    //     0xdffee8: bl              #0x13de838  ; AllocateContextStub
    // 0xdffeec: mov             x2, x0
    // 0xdffef0: ldur            x0, [fp, #-0x18]
    // 0xdffef4: stur            x2, [fp, #-0x28]
    // 0xdffef8: StoreField: r2->field_f = r0
    //     0xdffef8: stur            w0, [x2, #0xf]
    // 0xdffefc: LoadField: r1 = r0->field_33
    //     0xdffefc: ldur            x1, [x0, #0x33]
    // 0xdfff00: ldur            x3, [fp, #-0x20]
    // 0xdfff04: cmp             x3, x1
    // 0xdfff08: b.eq            #0xdfff18
    // 0xdfff0c: LoadField: r4 = r0->field_2b
    //     0xdfff0c: ldur            x4, [x0, #0x2b]
    // 0xdfff10: cmp             x4, #2
    // 0xdfff14: b.ge            #0xdfff28
    // 0xdfff18: r0 = Null
    //     0xdfff18: mov             x0, NULL
    // 0xdfff1c: LeaveFrame
    //     0xdfff1c: mov             SP, fp
    //     0xdfff20: ldp             fp, lr, [SP], #0x10
    // 0xdfff24: ret
    //     0xdfff24: ret             
    // 0xdfff28: ldur            x4, [fp, #-8]
    // 0xdfff2c: StoreField: r0->field_3b = r1
    //     0xdfff2c: stur            x1, [x0, #0x3b]
    // 0xdfff30: StoreField: r0->field_33 = r3
    //     0xdfff30: stur            x3, [x0, #0x33]
    // 0xdfff34: cmp             w4, NULL
    // 0xdfff38: b.eq            #0xdfffdc
    // 0xdfff3c: LoadField: r1 = r4->field_7
    //     0xdfff3c: ldur            x1, [x4, #7]
    // 0xdfff40: cmp             x1, #0
    // 0xdfff44: b.le            #0xdfffd4
    // 0xdfff48: LoadField: r1 = r0->field_43
    //     0xdfff48: ldur            x1, [x0, #0x43]
    // 0xdfff4c: add             x3, x1, #1
    // 0xdfff50: StoreField: r0->field_43 = r3
    //     0xdfff50: stur            x3, [x0, #0x43]
    // 0xdfff54: mov             x1, x0
    // 0xdfff58: r0 = notifyListeners()
    //     0xdfff58: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xdfff5c: ldur            x2, [fp, #-0x18]
    // 0xdfff60: LoadField: r3 = r2->field_23
    //     0xdfff60: ldur            w3, [x2, #0x23]
    // 0xdfff64: DecompressPointer r3
    //     0xdfff64: add             x3, x3, HEAP, lsl #32
    // 0xdfff68: stur            x3, [fp, #-0x30]
    // 0xdfff6c: cmp             w3, NULL
    // 0xdfff70: b.eq            #0xe00054
    // 0xdfff74: LoadField: r4 = r2->field_33
    //     0xdfff74: ldur            x4, [x2, #0x33]
    // 0xdfff78: r0 = BoxInt64Instr(r4)
    //     0xdfff78: sbfiz           x0, x4, #1, #0x1f
    //     0xdfff7c: cmp             x4, x0, asr #1
    //     0xdfff80: b.eq            #0xdfff8c
    //     0xdfff84: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xdfff88: stur            x4, [x0, #7]
    // 0xdfff8c: stp             x0, NULL, [SP]
    // 0xdfff90: r0 = _Double.fromInteger()
    //     0xdfff90: bl              #0x806648  ; [dart:core] _Double::_Double.fromInteger
    // 0xdfff94: LoadField: d0 = r0->field_7
    //     0xdfff94: ldur            d0, [x0, #7]
    // 0xdfff98: ldur            x16, [fp, #-8]
    // 0xdfff9c: ldur            lr, [fp, #-0x10]
    // 0xdfffa0: stp             lr, x16, [SP]
    // 0xdfffa4: ldur            x1, [fp, #-0x30]
    // 0xdfffa8: r4 = const [0, 0x4, 0x2, 0x2, curve, 0x3, duration, 0x2, null]
    //     0xdfffa8: ldr             x4, [PP, #0x5158]  ; [pp+0x5158] List(9) [0, 0x4, 0x2, 0x2, "curve", 0x3, "duration", 0x2, Null]
    // 0xdfffac: r0 = animateTo()
    //     0xdfffac: bl              #0x866084  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::animateTo
    // 0xdfffb0: ldur            x2, [fp, #-0x28]
    // 0xdfffb4: r1 = Function '<anonymous closure>':.
    //     0xdfffb4: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c620] AnonymousClosure: (0xe0005c), in [package:flutter/src/material/tab_controller.dart] TabController::_changeIndex (0xdffe34)
    //     0xdfffb8: ldr             x1, [x1, #0x620]
    // 0xdfffbc: stur            x0, [fp, #-8]
    // 0xdfffc0: r0 = AllocateClosure()
    //     0xdfffc0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdfffc4: ldur            x1, [fp, #-8]
    // 0xdfffc8: mov             x2, x0
    // 0xdfffcc: r0 = whenCompleteOrCancel()
    //     0xdfffcc: bl              #0x8ccecc  ; [package:flutter/src/scheduler/ticker.dart] TickerFuture::whenCompleteOrCancel
    // 0xdfffd0: b               #0xe0003c
    // 0xdfffd4: mov             x2, x0
    // 0xdfffd8: b               #0xdfffe0
    // 0xdfffdc: mov             x2, x0
    // 0xdfffe0: LoadField: r0 = r2->field_43
    //     0xdfffe0: ldur            x0, [x2, #0x43]
    // 0xdfffe4: add             x1, x0, #1
    // 0xdfffe8: StoreField: r2->field_43 = r1
    //     0xdfffe8: stur            x1, [x2, #0x43]
    // 0xdfffec: LoadField: r4 = r2->field_23
    //     0xdfffec: ldur            w4, [x2, #0x23]
    // 0xdffff0: DecompressPointer r4
    //     0xdffff0: add             x4, x4, HEAP, lsl #32
    // 0xdffff4: stur            x4, [fp, #-8]
    // 0xdffff8: cmp             w4, NULL
    // 0xdffffc: b.eq            #0xe00058
    // 0xe00000: r0 = BoxInt64Instr(r3)
    //     0xe00000: sbfiz           x0, x3, #1, #0x1f
    //     0xe00004: cmp             x3, x0, asr #1
    //     0xe00008: b.eq            #0xe00014
    //     0xe0000c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xe00010: stur            x3, [x0, #7]
    // 0xe00014: stp             x0, NULL, [SP]
    // 0xe00018: r0 = _Double.fromInteger()
    //     0xe00018: bl              #0x806648  ; [dart:core] _Double::_Double.fromInteger
    // 0xe0001c: ldur            x1, [fp, #-8]
    // 0xe00020: mov             x2, x0
    // 0xe00024: r0 = value=()
    //     0xe00024: bl              #0x829534  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0xe00028: ldur            x1, [fp, #-0x18]
    // 0xe0002c: LoadField: r0 = r1->field_43
    //     0xe0002c: ldur            x0, [x1, #0x43]
    // 0xe00030: sub             x2, x0, #1
    // 0xe00034: StoreField: r1->field_43 = r2
    //     0xe00034: stur            x2, [x1, #0x43]
    // 0xe00038: r0 = notifyListeners()
    //     0xe00038: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xe0003c: r0 = Null
    //     0xe0003c: mov             x0, NULL
    // 0xe00040: LeaveFrame
    //     0xe00040: mov             SP, fp
    //     0xe00044: ldp             fp, lr, [SP], #0x10
    // 0xe00048: ret
    //     0xe00048: ret             
    // 0xe0004c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe0004c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe00050: b               #0xdffee4
    // 0xe00054: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe00054: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xe00058: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe00058: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xe0005c, size: 0x64
    // 0xe0005c: EnterFrame
    //     0xe0005c: stp             fp, lr, [SP, #-0x10]!
    //     0xe00060: mov             fp, SP
    // 0xe00064: ldr             x0, [fp, #0x10]
    // 0xe00068: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xe00068: ldur            w1, [x0, #0x17]
    // 0xe0006c: DecompressPointer r1
    //     0xe0006c: add             x1, x1, HEAP, lsl #32
    // 0xe00070: CheckStackOverflow
    //     0xe00070: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe00074: cmp             SP, x16
    //     0xe00078: b.ls            #0xe000b8
    // 0xe0007c: LoadField: r0 = r1->field_f
    //     0xe0007c: ldur            w0, [x1, #0xf]
    // 0xe00080: DecompressPointer r0
    //     0xe00080: add             x0, x0, HEAP, lsl #32
    // 0xe00084: LoadField: r1 = r0->field_23
    //     0xe00084: ldur            w1, [x0, #0x23]
    // 0xe00088: DecompressPointer r1
    //     0xe00088: add             x1, x1, HEAP, lsl #32
    // 0xe0008c: cmp             w1, NULL
    // 0xe00090: b.eq            #0xe000a8
    // 0xe00094: LoadField: r1 = r0->field_43
    //     0xe00094: ldur            x1, [x0, #0x43]
    // 0xe00098: sub             x2, x1, #1
    // 0xe0009c: StoreField: r0->field_43 = r2
    //     0xe0009c: stur            x2, [x0, #0x43]
    // 0xe000a0: mov             x1, x0
    // 0xe000a4: r0 = notifyListeners()
    //     0xe000a4: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xe000a8: r0 = Null
    //     0xe000a8: mov             x0, NULL
    // 0xe000ac: LeaveFrame
    //     0xe000ac: mov             SP, fp
    //     0xe000b0: ldp             fp, lr, [SP], #0x10
    // 0xe000b4: ret
    //     0xe000b4: ret             
    // 0xe000b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe000b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe000bc: b               #0xe0007c
  }
  set _ offset=(/* No info */) {
    // ** addr: 0xe01688, size: 0xf4
    // 0xe01688: EnterFrame
    //     0xe01688: stp             fp, lr, [SP, #-0x10]!
    //     0xe0168c: mov             fp, SP
    // 0xe01690: AllocStack(0x28)
    //     0xe01690: sub             SP, SP, #0x28
    // 0xe01694: SetupParameters(TabController this /* r1 => r0, fp-0x8 */, dynamic _ /* d0 => d0, fp-0x18 */)
    //     0xe01694: mov             x0, x1
    //     0xe01698: stur            x1, [fp, #-8]
    //     0xe0169c: stur            d0, [fp, #-0x18]
    // 0xe016a0: CheckStackOverflow
    //     0xe016a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe016a4: cmp             SP, x16
    //     0xe016a8: b.ls            #0xe0175c
    // 0xe016ac: mov             x1, x0
    // 0xe016b0: r0 = offset()
    //     0xe016b0: bl              #0xe0177c  ; [package:flutter/src/material/tab_controller.dart] TabController::offset
    // 0xe016b4: mov             v1.16b, v0.16b
    // 0xe016b8: ldur            d0, [fp, #-0x18]
    // 0xe016bc: fcmp            d0, d1
    // 0xe016c0: b.ne            #0xe016d4
    // 0xe016c4: r0 = Null
    //     0xe016c4: mov             x0, NULL
    // 0xe016c8: LeaveFrame
    //     0xe016c8: mov             SP, fp
    //     0xe016cc: ldp             fp, lr, [SP], #0x10
    // 0xe016d0: ret
    //     0xe016d0: ret             
    // 0xe016d4: ldur            x0, [fp, #-8]
    // 0xe016d8: LoadField: r2 = r0->field_23
    //     0xe016d8: ldur            w2, [x0, #0x23]
    // 0xe016dc: DecompressPointer r2
    //     0xe016dc: add             x2, x2, HEAP, lsl #32
    // 0xe016e0: stur            x2, [fp, #-0x10]
    // 0xe016e4: cmp             w2, NULL
    // 0xe016e8: b.eq            #0xe01764
    // 0xe016ec: LoadField: r3 = r0->field_33
    //     0xe016ec: ldur            x3, [x0, #0x33]
    // 0xe016f0: r0 = BoxInt64Instr(r3)
    //     0xe016f0: sbfiz           x0, x3, #1, #0x1f
    //     0xe016f4: cmp             x3, x0, asr #1
    //     0xe016f8: b.eq            #0xe01704
    //     0xe016fc: bl              #0x13dfc6c  ; AllocateMintSharedWithFPURegsStub
    //     0xe01700: stur            x3, [x0, #7]
    // 0xe01704: stp             x0, NULL, [SP]
    // 0xe01708: r0 = _Double.fromInteger()
    //     0xe01708: bl              #0x806648  ; [dart:core] _Double::_Double.fromInteger
    // 0xe0170c: LoadField: d0 = r0->field_7
    //     0xe0170c: ldur            d0, [x0, #7]
    // 0xe01710: ldur            d1, [fp, #-0x18]
    // 0xe01714: fadd            d2, d1, d0
    // 0xe01718: r2 = inline_Allocate_Double()
    //     0xe01718: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0xe0171c: add             x2, x2, #0x10
    //     0xe01720: cmp             x0, x2
    //     0xe01724: b.ls            #0xe01768
    //     0xe01728: str             x2, [THR, #0x60]  ; THR::top
    //     0xe0172c: sub             x2, x2, #0xf
    //     0xe01730: mov             x0, #0xe19c
    //     0xe01734: movk            x0, #3, lsl #16
    //     0xe01738: stur            x0, [x2, #-1]
    // 0xe0173c: dmb             ishst
    // 0xe01740: StoreField: r2->field_7 = d2
    //     0xe01740: stur            d2, [x2, #7]
    // 0xe01744: ldur            x1, [fp, #-0x10]
    // 0xe01748: r0 = value=()
    //     0xe01748: bl              #0x829534  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0xe0174c: r0 = Null
    //     0xe0174c: mov             x0, NULL
    // 0xe01750: LeaveFrame
    //     0xe01750: mov             SP, fp
    //     0xe01754: ldp             fp, lr, [SP], #0x10
    // 0xe01758: ret
    //     0xe01758: ret             
    // 0xe0175c: r0 = StackOverflowSharedWithFPURegs()
    //     0xe0175c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xe01760: b               #0xe016ac
    // 0xe01764: r0 = NullCastErrorSharedWithFPURegs()
    //     0xe01764: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xe01768: SaveReg d2
    //     0xe01768: str             q2, [SP, #-0x10]!
    // 0xe0176c: r0 = AllocateDouble()
    //     0xe0176c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xe01770: mov             x2, x0
    // 0xe01774: RestoreReg d2
    //     0xe01774: ldr             q2, [SP], #0x10
    // 0xe01778: b               #0xe01740
  }
  get _ offset(/* No info */) {
    // ** addr: 0xe0177c, size: 0x94
    // 0xe0177c: EnterFrame
    //     0xe0177c: stp             fp, lr, [SP, #-0x10]!
    //     0xe01780: mov             fp, SP
    // 0xe01784: AllocStack(0x18)
    //     0xe01784: sub             SP, SP, #0x18
    // 0xe01788: CheckStackOverflow
    //     0xe01788: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe0178c: cmp             SP, x16
    //     0xe01790: b.ls            #0xe017fc
    // 0xe01794: LoadField: r0 = r1->field_23
    //     0xe01794: ldur            w0, [x1, #0x23]
    // 0xe01798: DecompressPointer r0
    //     0xe01798: add             x0, x0, HEAP, lsl #32
    // 0xe0179c: cmp             w0, NULL
    // 0xe017a0: b.eq            #0xe01804
    // 0xe017a4: LoadField: r2 = r0->field_37
    //     0xe017a4: ldur            w2, [x0, #0x37]
    // 0xe017a8: DecompressPointer r2
    //     0xe017a8: add             x2, x2, HEAP, lsl #32
    // 0xe017ac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xe017b0: cmp             w2, w16
    // 0xe017b4: b.eq            #0xe01808
    // 0xe017b8: stur            x2, [fp, #-8]
    // 0xe017bc: LoadField: r3 = r1->field_33
    //     0xe017bc: ldur            x3, [x1, #0x33]
    // 0xe017c0: r0 = BoxInt64Instr(r3)
    //     0xe017c0: sbfiz           x0, x3, #1, #0x1f
    //     0xe017c4: cmp             x3, x0, asr #1
    //     0xe017c8: b.eq            #0xe017d4
    //     0xe017cc: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xe017d0: stur            x3, [x0, #7]
    // 0xe017d4: stp             x0, NULL, [SP]
    // 0xe017d8: r0 = _Double.fromInteger()
    //     0xe017d8: bl              #0x806648  ; [dart:core] _Double::_Double.fromInteger
    // 0xe017dc: mov             x1, x0
    // 0xe017e0: ldur            x0, [fp, #-8]
    // 0xe017e4: LoadField: d1 = r0->field_7
    //     0xe017e4: ldur            d1, [x0, #7]
    // 0xe017e8: LoadField: d2 = r1->field_7
    //     0xe017e8: ldur            d2, [x1, #7]
    // 0xe017ec: fsub            d0, d1, d2
    // 0xe017f0: LeaveFrame
    //     0xe017f0: mov             SP, fp
    //     0xe017f4: ldp             fp, lr, [SP], #0x10
    // 0xe017f8: ret
    //     0xe017f8: ret             
    // 0xe017fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe017fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe01800: b               #0xe01794
    // 0xe01804: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe01804: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xe01808: r9 = _value
    //     0xe01808: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0xe0180c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xe0180c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _copyWithAndDispose(/* No info */) {
    // ** addr: 0xf3de14, size: 0xe8
    // 0xf3de14: EnterFrame
    //     0xf3de14: stp             fp, lr, [SP, #-0x10]!
    //     0xf3de18: mov             fp, SP
    // 0xf3de1c: AllocStack(0x40)
    //     0xf3de1c: sub             SP, SP, #0x40
    // 0xf3de20: SetupParameters(TabController this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */, dynamic _ /* r3 => r5, fp-0x20 */, dynamic _ /* r5 => r6, fp-0x28 */)
    //     0xf3de20: mov             x6, x5
    //     0xf3de24: stur            x5, [fp, #-0x28]
    //     0xf3de28: mov             x5, x3
    //     0xf3de2c: stur            x1, [fp, #-0x10]
    //     0xf3de30: stur            x2, [fp, #-0x18]
    //     0xf3de34: stur            x3, [fp, #-0x20]
    // 0xf3de38: CheckStackOverflow
    //     0xf3de38: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3de3c: cmp             SP, x16
    //     0xf3de40: b.ls            #0xf3def0
    // 0xf3de44: cmp             w2, NULL
    // 0xf3de48: b.eq            #0xf3de74
    // 0xf3de4c: LoadField: r0 = r1->field_23
    //     0xf3de4c: ldur            w0, [x1, #0x23]
    // 0xf3de50: DecompressPointer r0
    //     0xf3de50: add             x0, x0, HEAP, lsl #32
    // 0xf3de54: stur            x0, [fp, #-8]
    // 0xf3de58: cmp             w0, NULL
    // 0xf3de5c: b.eq            #0xf3def8
    // 0xf3de60: stp             x2, NULL, [SP]
    // 0xf3de64: r0 = _Double.fromInteger()
    //     0xf3de64: bl              #0x806648  ; [dart:core] _Double::_Double.fromInteger
    // 0xf3de68: ldur            x1, [fp, #-8]
    // 0xf3de6c: mov             x2, x0
    // 0xf3de70: r0 = value=()
    //     0xf3de70: bl              #0x829534  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0xf3de74: ldur            x0, [fp, #-0x18]
    // 0xf3de78: cmp             w0, NULL
    // 0xf3de7c: b.ne            #0xf3de90
    // 0xf3de80: ldur            x1, [fp, #-0x10]
    // 0xf3de84: LoadField: r0 = r1->field_33
    //     0xf3de84: ldur            x0, [x1, #0x33]
    // 0xf3de88: mov             x3, x0
    // 0xf3de8c: b               #0xf3dea4
    // 0xf3de90: ldur            x1, [fp, #-0x10]
    // 0xf3de94: r2 = LoadInt32Instr(r0)
    //     0xf3de94: sbfx            x2, x0, #1, #0x1f
    //     0xf3de98: tbz             w0, #0, #0xf3dea0
    //     0xf3de9c: ldur            x2, [x0, #7]
    // 0xf3dea0: mov             x3, x2
    // 0xf3dea4: stur            x3, [fp, #-0x30]
    // 0xf3dea8: LoadField: r2 = r1->field_23
    //     0xf3dea8: ldur            w2, [x1, #0x23]
    // 0xf3deac: DecompressPointer r2
    //     0xf3deac: add             x2, x2, HEAP, lsl #32
    // 0xf3deb0: stur            x2, [fp, #-8]
    // 0xf3deb4: r0 = TabController()
    //     0xf3deb4: bl              #0xf3dfb0  ; AllocateTabControllerStub -> TabController (size=0x4c)
    // 0xf3deb8: mov             x1, x0
    // 0xf3debc: ldur            x2, [fp, #-8]
    // 0xf3dec0: ldur            x3, [fp, #-0x30]
    // 0xf3dec4: ldur            x5, [fp, #-0x20]
    // 0xf3dec8: ldur            x6, [fp, #-0x28]
    // 0xf3decc: stur            x0, [fp, #-8]
    // 0xf3ded0: r0 = TabController._()
    //     0xf3ded0: bl              #0xf3defc  ; [package:flutter/src/material/tab_controller.dart] TabController::TabController._
    // 0xf3ded4: ldur            x1, [fp, #-0x10]
    // 0xf3ded8: StoreField: r1->field_23 = rNULL
    //     0xf3ded8: stur            NULL, [x1, #0x23]
    // 0xf3dedc: r0 = dispose()
    //     0xf3dedc: bl              #0x10ef4ac  ; [package:flutter/src/material/tab_controller.dart] TabController::dispose
    // 0xf3dee0: ldur            x0, [fp, #-8]
    // 0xf3dee4: LeaveFrame
    //     0xf3dee4: mov             SP, fp
    //     0xf3dee8: ldp             fp, lr, [SP], #0x10
    // 0xf3deec: ret
    //     0xf3deec: ret             
    // 0xf3def0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3def0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3def4: b               #0xf3de44
    // 0xf3def8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3def8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ TabController._(/* No info */) {
    // ** addr: 0xf3defc, size: 0xb4
    // 0xf3defc: EnterFrame
    //     0xf3defc: stp             fp, lr, [SP, #-0x10]!
    //     0xf3df00: mov             fp, SP
    // 0xf3df04: AllocStack(0x8)
    //     0xf3df04: sub             SP, SP, #8
    // 0xf3df08: r4 = Instance_Duration
    //     0xf3df08: ldr             x4, [PP, #0x7cd8]  ; [pp+0x7cd8] Obj!Duration@12c8971
    // 0xf3df0c: mov             x0, x2
    // 0xf3df10: stur            x1, [fp, #-8]
    // 0xf3df14: CheckStackOverflow
    //     0xf3df14: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3df18: cmp             SP, x16
    //     0xf3df1c: b.ls            #0xf3dfa8
    // 0xf3df20: StoreField: r1->field_43 = rZR
    //     0xf3df20: stur            xzr, [x1, #0x43]
    // 0xf3df24: StoreField: r1->field_2b = r5
    //     0xf3df24: stur            x5, [x1, #0x2b]
    // 0xf3df28: StoreField: r1->field_33 = r3
    //     0xf3df28: stur            x3, [x1, #0x33]
    // 0xf3df2c: StoreField: r1->field_3b = r6
    //     0xf3df2c: stur            x6, [x1, #0x3b]
    // 0xf3df30: StoreField: r1->field_23 = r0
    //     0xf3df30: stur            w0, [x1, #0x23]
    //     0xf3df34: ldurb           w16, [x1, #-1]
    //     0xf3df38: ldurb           w17, [x0, #-1]
    //     0xf3df3c: and             x16, x17, x16, lsr #2
    //     0xf3df40: tst             x16, HEAP, lsr #32
    //     0xf3df44: b.eq            #0xf3df4c
    //     0xf3df48: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf3df4c: StoreField: r1->field_27 = r4
    //     0xf3df4c: stur            w4, [x1, #0x27]
    // 0xf3df50: StoreField: r1->field_7 = rZR
    //     0xf3df50: stur            xzr, [x1, #7]
    // 0xf3df54: StoreField: r1->field_13 = rZR
    //     0xf3df54: stur            xzr, [x1, #0x13]
    // 0xf3df58: StoreField: r1->field_1b = rZR
    //     0xf3df58: stur            xzr, [x1, #0x1b]
    // 0xf3df5c: r0 = LoadStaticField(0x45c)
    //     0xf3df5c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf3df60: ldr             x0, [x0, #0x8b8]
    // 0xf3df64: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3df68: cmp             w0, w16
    // 0xf3df6c: b.ne            #0xf3df78
    // 0xf3df70: r2 = _emptyListeners
    //     0xf3df70: ldr             x2, [PP, #0x17f0]  ; [pp+0x17f0] Field <ChangeNotifier._emptyListeners@28329750>: static late final (offset: 0x45c)
    // 0xf3df74: r0 = InitLateFinalStaticField()
    //     0xf3df74: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xf3df78: ldur            x1, [fp, #-8]
    // 0xf3df7c: StoreField: r1->field_f = r0
    //     0xf3df7c: stur            w0, [x1, #0xf]
    //     0xf3df80: ldurb           w16, [x1, #-1]
    //     0xf3df84: ldurb           w17, [x0, #-1]
    //     0xf3df88: and             x16, x17, x16, lsr #2
    //     0xf3df8c: tst             x16, HEAP, lsr #32
    //     0xf3df90: b.eq            #0xf3df98
    //     0xf3df94: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf3df98: r0 = Null
    //     0xf3df98: mov             x0, NULL
    // 0xf3df9c: LeaveFrame
    //     0xf3df9c: mov             SP, fp
    //     0xf3dfa0: ldp             fp, lr, [SP], #0x10
    // 0xf3dfa4: ret
    //     0xf3dfa4: ret             
    // 0xf3dfa8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3dfa8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3dfac: b               #0xf3df20
  }
  _ TabController(/* No info */) {
    // ** addr: 0xf7c834, size: 0x150
    // 0xf7c834: EnterFrame
    //     0xf7c834: stp             fp, lr, [SP, #-0x10]!
    //     0xf7c838: mov             fp, SP
    // 0xf7c83c: AllocStack(0x30)
    //     0xf7c83c: sub             SP, SP, #0x30
    // 0xf7c840: SetupParameters(TabController this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0 */, dynamic _ /* r3 => r2, fp-0x10 */, {int initialIndex = 0 /* r4 */})
    //     0xf7c840: mov             x0, x2
    //     0xf7c844: mov             x2, x3
    //     0xf7c848: stur            x3, [fp, #-0x10]
    //     0xf7c84c: mov             x3, x1
    //     0xf7c850: stur            x1, [fp, #-8]
    //     0xf7c854: ldur            w1, [x4, #0x13]
    //     0xf7c858: ldur            w5, [x4, #0x1f]
    //     0xf7c85c: add             x5, x5, HEAP, lsl #32
    //     0xf7c860: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8f9b8] "initialIndex"
    //     0xf7c864: ldr             x16, [x16, #0x9b8]
    //     0xf7c868: cmp             w5, w16
    //     0xf7c86c: b.ne            #0xf7c894
    //     0xf7c870: ldur            w5, [x4, #0x23]
    //     0xf7c874: add             x5, x5, HEAP, lsl #32
    //     0xf7c878: sub             w4, w1, w5
    //     0xf7c87c: add             x1, fp, w4, sxtw #2
    //     0xf7c880: ldr             x1, [x1, #8]
    //     0xf7c884: sbfx            x4, x1, #1, #0x1f
    //     0xf7c888: tbz             w1, #0, #0xf7c890
    //     0xf7c88c: ldur            x4, [x1, #7]
    //     0xf7c890: b               #0xf7c898
    //     0xf7c894: mov             x4, #0
    //     0xf7c898: ldr             x1, [PP, #0x7cd8]  ; [pp+0x7cd8] Obj!Duration@12c8971
    // 0xf7c898: r1 = Instance_Duration
    // 0xf7c89c: CheckStackOverflow
    //     0xf7c89c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf7c8a0: cmp             SP, x16
    //     0xf7c8a4: b.ls            #0xf7c97c
    // 0xf7c8a8: StoreField: r3->field_43 = rZR
    //     0xf7c8a8: stur            xzr, [x3, #0x43]
    // 0xf7c8ac: StoreField: r3->field_2b = r0
    //     0xf7c8ac: stur            x0, [x3, #0x2b]
    // 0xf7c8b0: StoreField: r3->field_33 = r4
    //     0xf7c8b0: stur            x4, [x3, #0x33]
    // 0xf7c8b4: StoreField: r3->field_3b = r4
    //     0xf7c8b4: stur            x4, [x3, #0x3b]
    // 0xf7c8b8: StoreField: r3->field_27 = r1
    //     0xf7c8b8: stur            w1, [x3, #0x27]
    // 0xf7c8bc: r0 = BoxInt64Instr(r4)
    //     0xf7c8bc: sbfiz           x0, x4, #1, #0x1f
    //     0xf7c8c0: cmp             x4, x0, asr #1
    //     0xf7c8c4: b.eq            #0xf7c8d0
    //     0xf7c8c8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xf7c8cc: stur            x4, [x0, #7]
    // 0xf7c8d0: stp             x0, NULL, [SP]
    // 0xf7c8d4: r0 = _Double.fromInteger()
    //     0xf7c8d4: bl              #0x806648  ; [dart:core] _Double::_Double.fromInteger
    // 0xf7c8d8: r1 = <double>
    //     0xf7c8d8: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf7c8dc: stur            x0, [fp, #-0x18]
    // 0xf7c8e0: r0 = AnimationController()
    //     0xf7c8e0: bl              #0x87522c  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0xf7c8e4: stur            x0, [fp, #-0x20]
    // 0xf7c8e8: ldur            x16, [fp, #-0x18]
    // 0xf7c8ec: str             x16, [SP]
    // 0xf7c8f0: mov             x1, x0
    // 0xf7c8f4: ldur            x2, [fp, #-0x10]
    // 0xf7c8f8: r4 = const [0, 0x3, 0x1, 0x2, value, 0x2, null]
    //     0xf7c8f8: ldr             x4, [PP, #0x56f0]  ; [pp+0x56f0] List(7) [0, 0x3, 0x1, 0x2, "value", 0x2, Null]
    // 0xf7c8fc: r0 = AnimationController.unbounded()
    //     0xf7c8fc: bl              #0x86ef04  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController.unbounded
    // 0xf7c900: ldur            x0, [fp, #-0x20]
    // 0xf7c904: ldur            x1, [fp, #-8]
    // 0xf7c908: StoreField: r1->field_23 = r0
    //     0xf7c908: stur            w0, [x1, #0x23]
    //     0xf7c90c: ldurb           w16, [x1, #-1]
    //     0xf7c910: ldurb           w17, [x0, #-1]
    //     0xf7c914: and             x16, x17, x16, lsr #2
    //     0xf7c918: tst             x16, HEAP, lsr #32
    //     0xf7c91c: b.eq            #0xf7c924
    //     0xf7c920: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf7c924: StoreField: r1->field_7 = rZR
    //     0xf7c924: stur            xzr, [x1, #7]
    // 0xf7c928: StoreField: r1->field_13 = rZR
    //     0xf7c928: stur            xzr, [x1, #0x13]
    // 0xf7c92c: StoreField: r1->field_1b = rZR
    //     0xf7c92c: stur            xzr, [x1, #0x1b]
    // 0xf7c930: r0 = LoadStaticField(0x45c)
    //     0xf7c930: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf7c934: ldr             x0, [x0, #0x8b8]
    // 0xf7c938: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf7c93c: cmp             w0, w16
    // 0xf7c940: b.ne            #0xf7c94c
    // 0xf7c944: r2 = _emptyListeners
    //     0xf7c944: ldr             x2, [PP, #0x17f0]  ; [pp+0x17f0] Field <ChangeNotifier._emptyListeners@28329750>: static late final (offset: 0x45c)
    // 0xf7c948: r0 = InitLateFinalStaticField()
    //     0xf7c948: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xf7c94c: ldur            x1, [fp, #-8]
    // 0xf7c950: StoreField: r1->field_f = r0
    //     0xf7c950: stur            w0, [x1, #0xf]
    //     0xf7c954: ldurb           w16, [x1, #-1]
    //     0xf7c958: ldurb           w17, [x0, #-1]
    //     0xf7c95c: and             x16, x17, x16, lsr #2
    //     0xf7c960: tst             x16, HEAP, lsr #32
    //     0xf7c964: b.eq            #0xf7c96c
    //     0xf7c968: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf7c96c: r0 = Null
    //     0xf7c96c: mov             x0, NULL
    // 0xf7c970: LeaveFrame
    //     0xf7c970: mov             SP, fp
    //     0xf7c974: ldp             fp, lr, [SP], #0x10
    // 0xf7c978: ret
    //     0xf7c978: ret             
    // 0xf7c97c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf7c97c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf7c980: b               #0xf7c8a8
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10ef4ac, size: 0x60
    // 0x10ef4ac: EnterFrame
    //     0x10ef4ac: stp             fp, lr, [SP, #-0x10]!
    //     0x10ef4b0: mov             fp, SP
    // 0x10ef4b4: AllocStack(0x8)
    //     0x10ef4b4: sub             SP, SP, #8
    // 0x10ef4b8: SetupParameters(TabController this /* r1 => r0, fp-0x8 */)
    //     0x10ef4b8: mov             x0, x1
    //     0x10ef4bc: stur            x1, [fp, #-8]
    // 0x10ef4c0: CheckStackOverflow
    //     0x10ef4c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10ef4c4: cmp             SP, x16
    //     0x10ef4c8: b.ls            #0x10ef504
    // 0x10ef4cc: LoadField: r1 = r0->field_23
    //     0x10ef4cc: ldur            w1, [x0, #0x23]
    // 0x10ef4d0: DecompressPointer r1
    //     0x10ef4d0: add             x1, x1, HEAP, lsl #32
    // 0x10ef4d4: cmp             w1, NULL
    // 0x10ef4d8: b.ne            #0x10ef4e4
    // 0x10ef4dc: mov             x1, x0
    // 0x10ef4e0: b               #0x10ef4ec
    // 0x10ef4e4: r0 = dispose()
    //     0x10ef4e4: bl              #0x9164f4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x10ef4e8: ldur            x1, [fp, #-8]
    // 0x10ef4ec: StoreField: r1->field_23 = rNULL
    //     0x10ef4ec: stur            NULL, [x1, #0x23]
    // 0x10ef4f0: r0 = dispose()
    //     0x10ef4f0: bl              #0x10ef878  ; [dart:mixin_deduplication] _MixinApplication276&Object&ChangeNotifier::dispose
    // 0x10ef4f4: r0 = Null
    //     0x10ef4f4: mov             x0, NULL
    // 0x10ef4f8: LeaveFrame
    //     0x10ef4f8: mov             SP, fp
    //     0x10ef4fc: ldp             fp, lr, [SP], #0x10
    // 0x10ef500: ret
    //     0x10ef500: ret             
    // 0x10ef504: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10ef504: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10ef508: b               #0x10ef4cc
  }
}

// class id: 5697, size: 0x20, field offset: 0x1c
class _DefaultTabControllerState extends _MixinApplication112&State&SingleTickerProviderStateMixin {

  late TabController _controller; // offset: 0x1c

  _ build(/* No info */) {
    // ** addr: 0xd45494, size: 0xa8
    // 0xd45494: EnterFrame
    //     0xd45494: stp             fp, lr, [SP, #-0x10]!
    //     0xd45498: mov             fp, SP
    // 0xd4549c: AllocStack(0x18)
    //     0xd4549c: sub             SP, SP, #0x18
    // 0xd454a0: SetupParameters(_DefaultTabControllerState this /* r1 => r0, fp-0x10 */, dynamic _ /* r2 => r1 */)
    //     0xd454a0: mov             x0, x1
    //     0xd454a4: stur            x1, [fp, #-0x10]
    //     0xd454a8: mov             x1, x2
    // 0xd454ac: CheckStackOverflow
    //     0xd454ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd454b0: cmp             SP, x16
    //     0xd454b4: b.ls            #0xd45524
    // 0xd454b8: LoadField: r2 = r0->field_1b
    //     0xd454b8: ldur            w2, [x0, #0x1b]
    // 0xd454bc: DecompressPointer r2
    //     0xd454bc: add             x2, x2, HEAP, lsl #32
    // 0xd454c0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd454c4: cmp             w2, w16
    // 0xd454c8: b.eq            #0xd4552c
    // 0xd454cc: stur            x2, [fp, #-8]
    // 0xd454d0: r0 = of()
    //     0xd454d0: bl              #0xd45548  ; [package:flutter/src/widgets/ticker_provider.dart] TickerMode::of
    // 0xd454d4: mov             x1, x0
    // 0xd454d8: ldur            x0, [fp, #-0x10]
    // 0xd454dc: stur            x1, [fp, #-0x18]
    // 0xd454e0: LoadField: r2 = r0->field_b
    //     0xd454e0: ldur            w2, [x0, #0xb]
    // 0xd454e4: DecompressPointer r2
    //     0xd454e4: add             x2, x2, HEAP, lsl #32
    // 0xd454e8: cmp             w2, NULL
    // 0xd454ec: b.eq            #0xd45538
    // 0xd454f0: LoadField: r0 = r2->field_1f
    //     0xd454f0: ldur            w0, [x2, #0x1f]
    // 0xd454f4: DecompressPointer r0
    //     0xd454f4: add             x0, x0, HEAP, lsl #32
    // 0xd454f8: stur            x0, [fp, #-0x10]
    // 0xd454fc: r0 = _TabControllerScope()
    //     0xd454fc: bl              #0xd4553c  ; Allocate_TabControllerScopeStub -> _TabControllerScope (size=0x18)
    // 0xd45500: ldur            x1, [fp, #-8]
    // 0xd45504: StoreField: r0->field_f = r1
    //     0xd45504: stur            w1, [x0, #0xf]
    // 0xd45508: ldur            x1, [fp, #-0x18]
    // 0xd4550c: StoreField: r0->field_13 = r1
    //     0xd4550c: stur            w1, [x0, #0x13]
    // 0xd45510: ldur            x1, [fp, #-0x10]
    // 0xd45514: StoreField: r0->field_b = r1
    //     0xd45514: stur            w1, [x0, #0xb]
    // 0xd45518: LeaveFrame
    //     0xd45518: mov             SP, fp
    //     0xd4551c: ldp             fp, lr, [SP], #0x10
    // 0xd45520: ret
    //     0xd45520: ret             
    // 0xd45524: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd45524: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd45528: b               #0xd454b8
    // 0xd4552c: r9 = _controller
    //     0xd4552c: add             x9, PP, #0x8f, lsl #12  ; [pp+0x8f9a8] Field <_DefaultTabControllerState@129237367._controller@129237367>: late (offset: 0x1c)
    //     0xd45530: ldr             x9, [x9, #0x9a8]
    // 0xd45534: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd45534: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd45538: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd45538: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf3dc88, size: 0x18c
    // 0xf3dc88: EnterFrame
    //     0xf3dc88: stp             fp, lr, [SP, #-0x10]!
    //     0xf3dc8c: mov             fp, SP
    // 0xf3dc90: AllocStack(0x10)
    //     0xf3dc90: sub             SP, SP, #0x10
    // 0xf3dc94: SetupParameters(_DefaultTabControllerState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xf3dc94: mov             x4, x1
    //     0xf3dc98: mov             x3, x2
    //     0xf3dc9c: stur            x1, [fp, #-8]
    //     0xf3dca0: stur            x2, [fp, #-0x10]
    // 0xf3dca4: CheckStackOverflow
    //     0xf3dca4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3dca8: cmp             SP, x16
    //     0xf3dcac: b.ls            #0xf3ddf8
    // 0xf3dcb0: mov             x0, x3
    // 0xf3dcb4: r2 = Null
    //     0xf3dcb4: mov             x2, NULL
    // 0xf3dcb8: r1 = Null
    //     0xf3dcb8: mov             x1, NULL
    // 0xf3dcbc: r4 = 60
    //     0xf3dcbc: mov             x4, #0x3c
    // 0xf3dcc0: branchIfSmi(r0, 0xf3dccc)
    //     0xf3dcc0: tbz             w0, #0, #0xf3dccc
    // 0xf3dcc4: r4 = LoadClassIdInstr(r0)
    //     0xf3dcc4: ldur            x4, [x0, #-1]
    //     0xf3dcc8: ubfx            x4, x4, #0xc, #0x14
    // 0xf3dccc: r17 = 6430
    //     0xf3dccc: mov             x17, #0x191e
    // 0xf3dcd0: cmp             x4, x17
    // 0xf3dcd4: b.eq            #0xf3dcec
    // 0xf3dcd8: r8 = DefaultTabController
    //     0xf3dcd8: add             x8, PP, #0x8f, lsl #12  ; [pp+0x8f980] Type: DefaultTabController
    //     0xf3dcdc: ldr             x8, [x8, #0x980]
    // 0xf3dce0: r3 = Null
    //     0xf3dce0: add             x3, PP, #0x8f, lsl #12  ; [pp+0x8f988] Null
    //     0xf3dce4: ldr             x3, [x3, #0x988]
    // 0xf3dce8: r0 = DefaultTabController()
    //     0xf3dce8: bl              #0xad1ae8  ; IsType_DefaultTabController_Stub
    // 0xf3dcec: ldur            x3, [fp, #-8]
    // 0xf3dcf0: LoadField: r2 = r3->field_7
    //     0xf3dcf0: ldur            w2, [x3, #7]
    // 0xf3dcf4: DecompressPointer r2
    //     0xf3dcf4: add             x2, x2, HEAP, lsl #32
    // 0xf3dcf8: ldur            x0, [fp, #-0x10]
    // 0xf3dcfc: r1 = Null
    //     0xf3dcfc: mov             x1, NULL
    // 0xf3dd00: cmp             w2, NULL
    // 0xf3dd04: b.eq            #0xf3dd28
    // 0xf3dd08: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf3dd08: ldur            w4, [x2, #0x17]
    // 0xf3dd0c: DecompressPointer r4
    //     0xf3dd0c: add             x4, x4, HEAP, lsl #32
    // 0xf3dd10: r8 = X0 bound StatefulWidget
    //     0xf3dd10: add             x8, PP, #0x12, lsl #12  ; [pp+0x12498] TypeParameter: X0 bound StatefulWidget
    //     0xf3dd14: ldr             x8, [x8, #0x498]
    // 0xf3dd18: LoadField: r9 = r4->field_7
    //     0xf3dd18: ldur            x9, [x4, #7]
    // 0xf3dd1c: r3 = Null
    //     0xf3dd1c: add             x3, PP, #0x8f, lsl #12  ; [pp+0x8f998] Null
    //     0xf3dd20: ldr             x3, [x3, #0x998]
    // 0xf3dd24: blr             x9
    // 0xf3dd28: ldur            x0, [fp, #-0x10]
    // 0xf3dd2c: LoadField: r1 = r0->field_b
    //     0xf3dd2c: ldur            x1, [x0, #0xb]
    // 0xf3dd30: ldur            x4, [fp, #-8]
    // 0xf3dd34: LoadField: r0 = r4->field_b
    //     0xf3dd34: ldur            w0, [x4, #0xb]
    // 0xf3dd38: DecompressPointer r0
    //     0xf3dd38: add             x0, x0, HEAP, lsl #32
    // 0xf3dd3c: cmp             w0, NULL
    // 0xf3dd40: b.eq            #0xf3de00
    // 0xf3dd44: LoadField: r3 = r0->field_b
    //     0xf3dd44: ldur            x3, [x0, #0xb]
    // 0xf3dd48: cmp             x1, x3
    // 0xf3dd4c: b.eq            #0xf3ddd4
    // 0xf3dd50: LoadField: r2 = r4->field_1b
    //     0xf3dd50: ldur            w2, [x4, #0x1b]
    // 0xf3dd54: DecompressPointer r2
    //     0xf3dd54: add             x2, x2, HEAP, lsl #32
    // 0xf3dd58: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3dd5c: cmp             w2, w16
    // 0xf3dd60: b.eq            #0xf3de04
    // 0xf3dd64: LoadField: r0 = r2->field_3b
    //     0xf3dd64: ldur            x0, [x2, #0x3b]
    // 0xf3dd68: LoadField: r5 = r2->field_33
    //     0xf3dd68: ldur            x5, [x2, #0x33]
    // 0xf3dd6c: cmp             x5, x3
    // 0xf3dd70: b.lt            #0xf3dd9c
    // 0xf3dd74: r0 = 0
    //     0xf3dd74: mov             x0, #0
    // 0xf3dd78: sub             x1, x3, #1
    // 0xf3dd7c: cmp             x0, x1
    // 0xf3dd80: csel            x6, x1, x0, lt
    // 0xf3dd84: r0 = BoxInt64Instr(r6)
    //     0xf3dd84: sbfiz           x0, x6, #1, #0x1f
    //     0xf3dd88: cmp             x6, x0, asr #1
    //     0xf3dd8c: b.eq            #0xf3dd98
    //     0xf3dd90: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xf3dd94: stur            x6, [x0, #7]
    // 0xf3dd98: b               #0xf3dda4
    // 0xf3dd9c: mov             x5, x0
    // 0xf3dda0: r0 = Null
    //     0xf3dda0: mov             x0, NULL
    // 0xf3dda4: mov             x1, x2
    // 0xf3dda8: mov             x2, x0
    // 0xf3ddac: r0 = _copyWithAndDispose()
    //     0xf3ddac: bl              #0xf3de14  ; [package:flutter/src/material/tab_controller.dart] TabController::_copyWithAndDispose
    // 0xf3ddb0: ldur            x1, [fp, #-8]
    // 0xf3ddb4: StoreField: r1->field_1b = r0
    //     0xf3ddb4: stur            w0, [x1, #0x1b]
    //     0xf3ddb8: ldurb           w16, [x1, #-1]
    //     0xf3ddbc: ldurb           w17, [x0, #-1]
    //     0xf3ddc0: and             x16, x17, x16, lsr #2
    //     0xf3ddc4: tst             x16, HEAP, lsr #32
    //     0xf3ddc8: b.eq            #0xf3ddd0
    //     0xf3ddcc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf3ddd0: b               #0xf3ddd8
    // 0xf3ddd4: mov             x1, x4
    // 0xf3ddd8: LoadField: r2 = r1->field_b
    //     0xf3ddd8: ldur            w2, [x1, #0xb]
    // 0xf3dddc: DecompressPointer r2
    //     0xf3dddc: add             x2, x2, HEAP, lsl #32
    // 0xf3dde0: cmp             w2, NULL
    // 0xf3dde4: b.eq            #0xf3de10
    // 0xf3dde8: r0 = Null
    //     0xf3dde8: mov             x0, NULL
    // 0xf3ddec: LeaveFrame
    //     0xf3ddec: mov             SP, fp
    //     0xf3ddf0: ldp             fp, lr, [SP], #0x10
    // 0xf3ddf4: ret
    //     0xf3ddf4: ret             
    // 0xf3ddf8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3ddf8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3ddfc: b               #0xf3dcb0
    // 0xf3de00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3de00: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3de04: r9 = _controller
    //     0xf3de04: add             x9, PP, #0x8f, lsl #12  ; [pp+0x8f9a8] Field <_DefaultTabControllerState@129237367._controller@129237367>: late (offset: 0x1c)
    //     0xf3de08: ldr             x9, [x9, #0x9a8]
    // 0xf3de0c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf3de0c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xf3de10: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3de10: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0xf7c778, size: 0xbc
    // 0xf7c778: EnterFrame
    //     0xf7c778: stp             fp, lr, [SP, #-0x10]!
    //     0xf7c77c: mov             fp, SP
    // 0xf7c780: AllocStack(0x28)
    //     0xf7c780: sub             SP, SP, #0x28
    // 0xf7c784: SetupParameters(_DefaultTabControllerState this /* r1 => r3, fp-0x18 */)
    //     0xf7c784: mov             x3, x1
    //     0xf7c788: stur            x1, [fp, #-0x18]
    // 0xf7c78c: CheckStackOverflow
    //     0xf7c78c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf7c790: cmp             SP, x16
    //     0xf7c794: b.ls            #0xf7c828
    // 0xf7c798: LoadField: r0 = r3->field_b
    //     0xf7c798: ldur            w0, [x3, #0xb]
    // 0xf7c79c: DecompressPointer r0
    //     0xf7c79c: add             x0, x0, HEAP, lsl #32
    // 0xf7c7a0: cmp             w0, NULL
    // 0xf7c7a4: b.eq            #0xf7c830
    // 0xf7c7a8: LoadField: r2 = r0->field_b
    //     0xf7c7a8: ldur            x2, [x0, #0xb]
    // 0xf7c7ac: stur            x2, [fp, #-0x10]
    // 0xf7c7b0: LoadField: r4 = r0->field_13
    //     0xf7c7b0: ldur            x4, [x0, #0x13]
    // 0xf7c7b4: r0 = BoxInt64Instr(r4)
    //     0xf7c7b4: sbfiz           x0, x4, #1, #0x1f
    //     0xf7c7b8: cmp             x4, x0, asr #1
    //     0xf7c7bc: b.eq            #0xf7c7c8
    //     0xf7c7c0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xf7c7c4: stur            x4, [x0, #7]
    // 0xf7c7c8: stur            x0, [fp, #-8]
    // 0xf7c7cc: r0 = TabController()
    //     0xf7c7cc: bl              #0xf3dfb0  ; AllocateTabControllerStub -> TabController (size=0x4c)
    // 0xf7c7d0: stur            x0, [fp, #-0x20]
    // 0xf7c7d4: ldur            x16, [fp, #-8]
    // 0xf7c7d8: str             x16, [SP]
    // 0xf7c7dc: mov             x1, x0
    // 0xf7c7e0: ldur            x2, [fp, #-0x10]
    // 0xf7c7e4: ldur            x3, [fp, #-0x18]
    // 0xf7c7e8: r4 = const [0, 0x4, 0x1, 0x3, initialIndex, 0x3, null]
    //     0xf7c7e8: add             x4, PP, #0x8f, lsl #12  ; [pp+0x8f9b0] List(7) [0, 0x4, 0x1, 0x3, "initialIndex", 0x3, Null]
    //     0xf7c7ec: ldr             x4, [x4, #0x9b0]
    // 0xf7c7f0: r0 = TabController()
    //     0xf7c7f0: bl              #0xf7c834  ; [package:flutter/src/material/tab_controller.dart] TabController::TabController
    // 0xf7c7f4: ldur            x0, [fp, #-0x20]
    // 0xf7c7f8: ldur            x1, [fp, #-0x18]
    // 0xf7c7fc: StoreField: r1->field_1b = r0
    //     0xf7c7fc: stur            w0, [x1, #0x1b]
    //     0xf7c800: ldurb           w16, [x1, #-1]
    //     0xf7c804: ldurb           w17, [x0, #-1]
    //     0xf7c808: and             x16, x17, x16, lsr #2
    //     0xf7c80c: tst             x16, HEAP, lsr #32
    //     0xf7c810: b.eq            #0xf7c818
    //     0xf7c814: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf7c818: r0 = Null
    //     0xf7c818: mov             x0, NULL
    // 0xf7c81c: LeaveFrame
    //     0xf7c81c: mov             SP, fp
    //     0xf7c820: ldp             fp, lr, [SP], #0x10
    // 0xf7c824: ret
    //     0xf7c824: ret             
    // 0xf7c828: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf7c828: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf7c82c: b               #0xf7c798
    // 0xf7c830: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf7c830: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10de39c, size: 0x64
    // 0x10de39c: EnterFrame
    //     0x10de39c: stp             fp, lr, [SP, #-0x10]!
    //     0x10de3a0: mov             fp, SP
    // 0x10de3a4: AllocStack(0x8)
    //     0x10de3a4: sub             SP, SP, #8
    // 0x10de3a8: SetupParameters(_DefaultTabControllerState this /* r1 => r0, fp-0x8 */)
    //     0x10de3a8: mov             x0, x1
    //     0x10de3ac: stur            x1, [fp, #-8]
    // 0x10de3b0: CheckStackOverflow
    //     0x10de3b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10de3b4: cmp             SP, x16
    //     0x10de3b8: b.ls            #0x10de3ec
    // 0x10de3bc: LoadField: r1 = r0->field_1b
    //     0x10de3bc: ldur            w1, [x0, #0x1b]
    // 0x10de3c0: DecompressPointer r1
    //     0x10de3c0: add             x1, x1, HEAP, lsl #32
    // 0x10de3c4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10de3c8: cmp             w1, w16
    // 0x10de3cc: b.eq            #0x10de3f4
    // 0x10de3d0: r0 = dispose()
    //     0x10de3d0: bl              #0x10ef4ac  ; [package:flutter/src/material/tab_controller.dart] TabController::dispose
    // 0x10de3d4: ldur            x1, [fp, #-8]
    // 0x10de3d8: r0 = dispose()
    //     0x10de3d8: bl              #0x10de400  ; [dart:mixin_deduplication] _MixinApplication112&State&SingleTickerProviderStateMixin::dispose
    // 0x10de3dc: r0 = Null
    //     0x10de3dc: mov             x0, NULL
    // 0x10de3e0: LeaveFrame
    //     0x10de3e0: mov             SP, fp
    //     0x10de3e4: ldp             fp, lr, [SP], #0x10
    // 0x10de3e8: ret
    //     0x10de3e8: ret             
    // 0x10de3ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10de3ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10de3f0: b               #0x10de3bc
    // 0x10de3f4: r9 = _controller
    //     0x10de3f4: add             x9, PP, #0x8f, lsl #12  ; [pp+0x8f9a8] Field <_DefaultTabControllerState@129237367._controller@129237367>: late (offset: 0x1c)
    //     0x10de3f8: ldr             x9, [x9, #0x9a8]
    // 0x10de3fc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x10de3fc: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 6430, size: 0x24, field offset: 0xc
//   const constructor, 
class DefaultTabController extends StatefulWidget {

  static _ maybeOf(/* No info */) {
    // ** addr: 0xef6a7c, size: 0x5c
    // 0xef6a7c: EnterFrame
    //     0xef6a7c: stp             fp, lr, [SP, #-0x10]!
    //     0xef6a80: mov             fp, SP
    // 0xef6a84: AllocStack(0x10)
    //     0xef6a84: sub             SP, SP, #0x10
    // 0xef6a88: CheckStackOverflow
    //     0xef6a88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef6a8c: cmp             SP, x16
    //     0xef6a90: b.ls            #0xef6ad0
    // 0xef6a94: r16 = <_TabControllerScope>
    //     0xef6a94: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8c728] TypeArguments: <_TabControllerScope>
    //     0xef6a98: ldr             x16, [x16, #0x728]
    // 0xef6a9c: stp             x1, x16, [SP]
    // 0xef6aa0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xef6aa0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xef6aa4: r0 = dependOnInheritedWidgetOfExactType()
    //     0xef6aa4: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xef6aa8: cmp             w0, NULL
    // 0xef6aac: b.ne            #0xef6ab8
    // 0xef6ab0: r0 = Null
    //     0xef6ab0: mov             x0, NULL
    // 0xef6ab4: b               #0xef6ac4
    // 0xef6ab8: LoadField: r1 = r0->field_f
    //     0xef6ab8: ldur            w1, [x0, #0xf]
    // 0xef6abc: DecompressPointer r1
    //     0xef6abc: add             x1, x1, HEAP, lsl #32
    // 0xef6ac0: mov             x0, x1
    // 0xef6ac4: LeaveFrame
    //     0xef6ac4: mov             SP, fp
    //     0xef6ac8: ldp             fp, lr, [SP], #0x10
    // 0xef6acc: ret
    //     0xef6acc: ret             
    // 0xef6ad0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef6ad0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef6ad4: b               #0xef6a94
  }
  _ createState(/* No info */) {
    // ** addr: 0xfa31b0, size: 0x2c
    // 0xfa31b0: EnterFrame
    //     0xfa31b0: stp             fp, lr, [SP, #-0x10]!
    //     0xfa31b4: mov             fp, SP
    // 0xfa31b8: mov             x0, x1
    // 0xfa31bc: r1 = <DefaultTabController>
    //     0xfa31bc: add             x1, PP, #0x84, lsl #12  ; [pp+0x84938] TypeArguments: <DefaultTabController>
    //     0xfa31c0: ldr             x1, [x1, #0x938]
    // 0xfa31c4: r0 = _DefaultTabControllerState()
    //     0xfa31c4: bl              #0xfa31dc  ; Allocate_DefaultTabControllerStateStub -> _DefaultTabControllerState (size=0x20)
    // 0xfa31c8: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa31cc: StoreField: r0->field_1b = r1
    //     0xfa31cc: stur            w1, [x0, #0x1b]
    // 0xfa31d0: LeaveFrame
    //     0xfa31d0: mov             SP, fp
    //     0xfa31d4: ldp             fp, lr, [SP], #0x10
    // 0xfa31d8: ret
    //     0xfa31d8: ret             
  }
}

// class id: 6807, size: 0x18, field offset: 0x10
//   const constructor, 
class _TabControllerScope extends InheritedWidget {

  _ updateShouldNotify(/* No info */) {
    // ** addr: 0xc0118c, size: 0xb0
    // 0xc0118c: EnterFrame
    //     0xc0118c: stp             fp, lr, [SP, #-0x10]!
    //     0xc01190: mov             fp, SP
    // 0xc01194: AllocStack(0x10)
    //     0xc01194: sub             SP, SP, #0x10
    // 0xc01198: SetupParameters(_TabControllerScope this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xc01198: mov             x0, x2
    //     0xc0119c: mov             x4, x1
    //     0xc011a0: mov             x3, x2
    //     0xc011a4: stur            x1, [fp, #-8]
    //     0xc011a8: stur            x2, [fp, #-0x10]
    // 0xc011ac: r2 = Null
    //     0xc011ac: mov             x2, NULL
    // 0xc011b0: r1 = Null
    //     0xc011b0: mov             x1, NULL
    // 0xc011b4: r4 = 60
    //     0xc011b4: mov             x4, #0x3c
    // 0xc011b8: branchIfSmi(r0, 0xc011c4)
    //     0xc011b8: tbz             w0, #0, #0xc011c4
    // 0xc011bc: r4 = LoadClassIdInstr(r0)
    //     0xc011bc: ldur            x4, [x0, #-1]
    //     0xc011c0: ubfx            x4, x4, #0xc, #0x14
    // 0xc011c4: r17 = 6807
    //     0xc011c4: mov             x17, #0x1a97
    // 0xc011c8: cmp             x4, x17
    // 0xc011cc: b.eq            #0xc011e4
    // 0xc011d0: r8 = _TabControllerScope
    //     0xc011d0: add             x8, PP, #0x98, lsl #12  ; [pp+0x98e90] Type: _TabControllerScope
    //     0xc011d4: ldr             x8, [x8, #0xe90]
    // 0xc011d8: r3 = Null
    //     0xc011d8: add             x3, PP, #0x98, lsl #12  ; [pp+0x98e98] Null
    //     0xc011dc: ldr             x3, [x3, #0xe98]
    // 0xc011e0: r0 = DefaultTypeTest()
    //     0xc011e0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xc011e4: ldur            x1, [fp, #-8]
    // 0xc011e8: LoadField: r2 = r1->field_13
    //     0xc011e8: ldur            w2, [x1, #0x13]
    // 0xc011ec: DecompressPointer r2
    //     0xc011ec: add             x2, x2, HEAP, lsl #32
    // 0xc011f0: ldur            x3, [fp, #-0x10]
    // 0xc011f4: LoadField: r4 = r3->field_13
    //     0xc011f4: ldur            w4, [x3, #0x13]
    // 0xc011f8: DecompressPointer r4
    //     0xc011f8: add             x4, x4, HEAP, lsl #32
    // 0xc011fc: cmp             w2, w4
    // 0xc01200: b.eq            #0xc0120c
    // 0xc01204: r0 = true
    //     0xc01204: add             x0, NULL, #0x20  ; true
    // 0xc01208: b               #0xc01230
    // 0xc0120c: LoadField: r2 = r1->field_f
    //     0xc0120c: ldur            w2, [x1, #0xf]
    // 0xc01210: DecompressPointer r2
    //     0xc01210: add             x2, x2, HEAP, lsl #32
    // 0xc01214: LoadField: r1 = r3->field_f
    //     0xc01214: ldur            w1, [x3, #0xf]
    // 0xc01218: DecompressPointer r1
    //     0xc01218: add             x1, x1, HEAP, lsl #32
    // 0xc0121c: cmp             w2, w1
    // 0xc01220: r16 = true
    //     0xc01220: add             x16, NULL, #0x20  ; true
    // 0xc01224: r17 = false
    //     0xc01224: add             x17, NULL, #0x30  ; false
    // 0xc01228: csel            x3, x16, x17, ne
    // 0xc0122c: mov             x0, x3
    // 0xc01230: LeaveFrame
    //     0xc01230: mov             SP, fp
    //     0xc01234: ldp             fp, lr, [SP], #0x10
    // 0xc01238: ret
    //     0xc01238: ret             
  }
}
