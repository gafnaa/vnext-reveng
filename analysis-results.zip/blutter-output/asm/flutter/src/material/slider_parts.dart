// lib: , url: package:flutter/src/material/slider_parts.dart

// class id: 1048946, size: 0x8
class :: {
}

// class id: 2975, size: 0x8, field offset: 0x8
//   const constructor, 
class _DropSliderValueIndicatorPathPainter extends Object {

  _ paint(/* No info */) {
    // ** addr: 0x12ea8a0, size: 0x69c
    // 0x12ea8a0: EnterFrame
    //     0x12ea8a0: stp             fp, lr, [SP, #-0x10]!
    //     0x12ea8a4: mov             fp, SP
    // 0x12ea8a8: AllocStack(0x80)
    //     0x12ea8a8: sub             SP, SP, #0x80
    // 0x12ea8ac: d2 = 0.000000
    //     0x12ea8ac: eor             v2.16b, v2.16b, v2.16b
    // 0x12ea8b0: mov             x4, x3
    // 0x12ea8b4: stur            x3, [fp, #-0x18]
    // 0x12ea8b8: mov             x3, x5
    // 0x12ea8bc: stur            x5, [fp, #-0x20]
    // 0x12ea8c0: mov             x5, x7
    // 0x12ea8c4: stur            x7, [fp, #-0x30]
    // 0x12ea8c8: mov             x7, x1
    // 0x12ea8cc: mov             x0, x6
    // 0x12ea8d0: stur            x6, [fp, #-0x28]
    // 0x12ea8d4: mov             x6, x2
    // 0x12ea8d8: mov             v3.16b, v0.16b
    // 0x12ea8dc: stur            x1, [fp, #-8]
    // 0x12ea8e0: stur            x2, [fp, #-0x10]
    // 0x12ea8e4: stur            d0, [fp, #-0x50]
    // 0x12ea8e8: stur            d1, [fp, #-0x58]
    // 0x12ea8ec: CheckStackOverflow
    //     0x12ea8ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12ea8f0: cmp             SP, x16
    //     0x12ea8f4: b.ls            #0x12eaf04
    // 0x12ea8f8: fcmp            d3, d2
    // 0x12ea8fc: b.ne            #0x12ea910
    // 0x12ea900: r0 = Null
    //     0x12ea900: mov             x0, NULL
    // 0x12ea904: LeaveFrame
    //     0x12ea904: mov             SP, fp
    //     0x12ea908: ldp             fp, lr, [SP], #0x10
    // 0x12ea90c: ret
    //     0x12ea90c: ret             
    // 0x12ea910: mov             x1, x7
    // 0x12ea914: mov             x2, x0
    // 0x12ea918: mov             v0.16b, v3.16b
    // 0x12ea91c: r0 = _upperRectangleWidth()
    //     0x12ea91c: bl              #0x12eb0b4  ; [package:flutter/src/material/slider_parts.dart] _DropSliderValueIndicatorPathPainter::_upperRectangleWidth
    // 0x12ea920: ldur            x1, [fp, #-8]
    // 0x12ea924: ldur            x2, [fp, #-0x20]
    // 0x12ea928: ldur            x3, [fp, #-0x28]
    // 0x12ea92c: ldur            x5, [fp, #-0x30]
    // 0x12ea930: mov             v2.16b, v0.16b
    // 0x12ea934: ldur            d0, [fp, #-0x50]
    // 0x12ea938: ldr             x6, [fp, #0x10]
    // 0x12ea93c: ldur            d1, [fp, #-0x58]
    // 0x12ea940: stur            d2, [fp, #-0x58]
    // 0x12ea944: r0 = getHorizontalShift()
    //     0x12ea944: bl              #0x12eafc8  ; [package:flutter/src/material/slider_parts.dart] _DropSliderValueIndicatorPathPainter::getHorizontalShift
    // 0x12ea948: mov             v1.16b, v0.16b
    // 0x12ea94c: ldur            d0, [fp, #-0x58]
    // 0x12ea950: stur            d1, [fp, #-0x70]
    // 0x12ea954: fneg            d2, d0
    // 0x12ea958: d3 = 2.000000
    //     0x12ea958: fmov            d3, #2.00000000
    // 0x12ea95c: fdiv            d4, d2, d3
    // 0x12ea960: fadd            d2, d4, d1
    // 0x12ea964: stur            d2, [fp, #-0x68]
    // 0x12ea968: fadd            d4, d2, d0
    // 0x12ea96c: stur            d4, [fp, #-0x60]
    // 0x12ea970: r0 = Rect()
    //     0x12ea970: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0x12ea974: ldur            d0, [fp, #-0x68]
    // 0x12ea978: stur            x0, [fp, #-0x30]
    // 0x12ea97c: StoreField: r0->field_7 = d0
    //     0x12ea97c: stur            d0, [x0, #7]
    // 0x12ea980: d0 = -34.000000
    //     0x12ea980: add             x17, PP, #0xcc, lsl #12  ; [pp+0xccf28] IMM: double(-34) from 0xc041000000000000
    //     0x12ea984: ldr             d0, [x17, #0xf28]
    // 0x12ea988: StoreField: r0->field_f = d0
    //     0x12ea988: stur            d0, [x0, #0xf]
    // 0x12ea98c: ldur            d0, [fp, #-0x60]
    // 0x12ea990: ArrayStore: r0[0] = d0  ; List_8
    //     0x12ea990: stur            d0, [x0, #0x17]
    // 0x12ea994: d0 = -6.000000
    //     0x12ea994: fmov            d0, #-6.00000000
    // 0x12ea998: StoreField: r0->field_1f = d0
    //     0x12ea998: stur            d0, [x0, #0x1f]
    // 0x12ea99c: r16 = 136
    //     0x12ea99c: mov             x16, #0x88
    // 0x12ea9a0: stp             x16, NULL, [SP]
    // 0x12ea9a4: r0 = ByteData()
    //     0x12ea9a4: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0x12ea9a8: stur            x0, [fp, #-0x38]
    // 0x12ea9ac: r0 = Paint()
    //     0x12ea9ac: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x12ea9b0: ldur            x5, [fp, #-0x38]
    // 0x12ea9b4: stur            x0, [fp, #-0x40]
    // 0x12ea9b8: StoreField: r0->field_7 = r5
    //     0x12ea9b8: stur            w5, [x0, #7]
    // 0x12ea9bc: mov             x1, x0
    // 0x12ea9c0: ldur            x2, [fp, #-0x10]
    // 0x12ea9c4: r0 = color=()
    //     0x12ea9c4: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0x12ea9c8: ldur            x2, [fp, #-0x18]
    // 0x12ea9cc: LoadField: r0 = r2->field_7
    //     0x12ea9cc: ldur            w0, [x2, #7]
    // 0x12ea9d0: DecompressPointer r0
    //     0x12ea9d0: add             x0, x0, HEAP, lsl #32
    // 0x12ea9d4: cmp             w0, NULL
    // 0x12ea9d8: b.eq            #0x12eaf0c
    // 0x12ea9dc: LoadField: r1 = r0->field_7
    //     0x12ea9dc: ldur            x1, [x0, #7]
    // 0x12ea9e0: ldr             x0, [x1]
    // 0x12ea9e4: cbz             x0, #0x12eae64
    // 0x12ea9e8: ldur            x3, [fp, #-0x20]
    // 0x12ea9ec: stur            x0, [fp, #-0x48]
    // 0x12ea9f0: r1 = <Never>
    //     0x12ea9f0: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12ea9f4: r0 = Pointer()
    //     0x12ea9f4: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12ea9f8: mov             x1, x0
    // 0x12ea9fc: ldur            x0, [fp, #-0x48]
    // 0x12eaa00: StoreField: r1->field_7 = r0
    //     0x12eaa00: stur            x0, [x1, #7]
    // 0x12eaa04: r0 = _save$Method$FfiNative()
    //     0x12eaa04: bl              #0xb74adc  ; [dart:ui] _NativeCanvas::_save$Method$FfiNative
    // 0x12eaa08: ldur            x0, [fp, #-0x20]
    // 0x12eaa0c: LoadField: d0 = r0->field_7
    //     0x12eaa0c: ldur            d0, [x0, #7]
    // 0x12eaa10: stur            d0, [fp, #-0x60]
    // 0x12eaa14: LoadField: d1 = r0->field_f
    //     0x12eaa14: ldur            d1, [x0, #0xf]
    // 0x12eaa18: d2 = 16.000000
    //     0x12eaa18: fmov            d2, #16.00000000
    // 0x12eaa1c: fsub            d3, d1, d2
    // 0x12eaa20: ldur            x2, [fp, #-0x18]
    // 0x12eaa24: stur            d3, [fp, #-0x58]
    // 0x12eaa28: LoadField: r0 = r2->field_7
    //     0x12eaa28: ldur            w0, [x2, #7]
    // 0x12eaa2c: DecompressPointer r0
    //     0x12eaa2c: add             x0, x0, HEAP, lsl #32
    // 0x12eaa30: cmp             w0, NULL
    // 0x12eaa34: b.eq            #0x12eaf10
    // 0x12eaa38: LoadField: r1 = r0->field_7
    //     0x12eaa38: ldur            x1, [x0, #7]
    // 0x12eaa3c: ldr             x0, [x1]
    // 0x12eaa40: cbz             x0, #0x12eae74
    // 0x12eaa44: stur            x0, [fp, #-0x48]
    // 0x12eaa48: r1 = <Never>
    //     0x12eaa48: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12eaa4c: r0 = Pointer()
    //     0x12eaa4c: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12eaa50: mov             x1, x0
    // 0x12eaa54: ldur            x0, [fp, #-0x48]
    // 0x12eaa58: StoreField: r1->field_7 = r0
    //     0x12eaa58: stur            x0, [x1, #7]
    // 0x12eaa5c: ldur            d0, [fp, #-0x60]
    // 0x12eaa60: ldur            d1, [fp, #-0x58]
    // 0x12eaa64: r0 = _translate$Method$FfiNative()
    //     0x12eaa64: bl              #0xb74a38  ; [dart:ui] _NativeCanvas::_translate$Method$FfiNative
    // 0x12eaa68: ldur            x2, [fp, #-0x18]
    // 0x12eaa6c: LoadField: r0 = r2->field_7
    //     0x12eaa6c: ldur            w0, [x2, #7]
    // 0x12eaa70: DecompressPointer r0
    //     0x12eaa70: add             x0, x0, HEAP, lsl #32
    // 0x12eaa74: cmp             w0, NULL
    // 0x12eaa78: b.eq            #0x12eaf14
    // 0x12eaa7c: LoadField: r1 = r0->field_7
    //     0x12eaa7c: ldur            x1, [x0, #7]
    // 0x12eaa80: ldr             x0, [x1]
    // 0x12eaa84: cbz             x0, #0x12eae84
    // 0x12eaa88: stur            x0, [fp, #-0x48]
    // 0x12eaa8c: r1 = <Never>
    //     0x12eaa8c: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12eaa90: r0 = Pointer()
    //     0x12eaa90: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12eaa94: mov             x1, x0
    // 0x12eaa98: ldur            x0, [fp, #-0x48]
    // 0x12eaa9c: StoreField: r1->field_7 = r0
    //     0x12eaa9c: stur            x0, [x1, #7]
    // 0x12eaaa0: ldur            d0, [fp, #-0x50]
    // 0x12eaaa4: ldur            d1, [fp, #-0x50]
    // 0x12eaaa8: r0 = __scale$Method$FfiNative()
    //     0x12eaaa8: bl              #0xb76308  ; [dart:ui] _NativeCanvas::__scale$Method$FfiNative
    // 0x12eaaac: ldur            x1, [fp, #-8]
    // 0x12eaab0: ldur            x2, [fp, #-0x30]
    // 0x12eaab4: r0 = _adjustBorderRadius()
    //     0x12eaab4: bl              #0x12eaf3c  ; [package:flutter/src/material/slider_parts.dart] _DropSliderValueIndicatorPathPainter::_adjustBorderRadius
    // 0x12eaab8: mov             x1, x0
    // 0x12eaabc: ldur            x2, [fp, #-0x30]
    // 0x12eaac0: r0 = toRRect()
    //     0x12eaac0: bl              #0xb77a10  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0x12eaac4: stur            x0, [fp, #-8]
    // 0x12eaac8: r0 = _NativePath()
    //     0x12eaac8: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0x12eaacc: mov             x1, x0
    // 0x12eaad0: stur            x0, [fp, #-0x10]
    // 0x12eaad4: r0 = __constructor$Method$FfiNative()
    //     0x12eaad4: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0x12eaad8: ldur            x0, [fp, #-0x10]
    // 0x12eaadc: LoadField: r1 = r0->field_7
    //     0x12eaadc: ldur            w1, [x0, #7]
    // 0x12eaae0: DecompressPointer r1
    //     0x12eaae0: add             x1, x1, HEAP, lsl #32
    // 0x12eaae4: cmp             w1, NULL
    // 0x12eaae8: b.eq            #0x12eaf18
    // 0x12eaaec: LoadField: r2 = r1->field_7
    //     0x12eaaec: ldur            x2, [x1, #7]
    // 0x12eaaf0: ldr             x1, [x2]
    // 0x12eaaf4: cbz             x1, #0x12eae94
    // 0x12eaaf8: mov             x2, x1
    // 0x12eaafc: stur            x2, [fp, #-0x48]
    // 0x12eab00: r1 = <Never>
    //     0x12eab00: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12eab04: r0 = Pointer()
    //     0x12eab04: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12eab08: mov             x1, x0
    // 0x12eab0c: ldur            x0, [fp, #-0x48]
    // 0x12eab10: StoreField: r1->field_7 = r0
    //     0x12eab10: stur            x0, [x1, #7]
    // 0x12eab14: d0 = -10.000000
    //     0x12eab14: fmov            d0, #-10.00000000
    // 0x12eab18: d1 = -10.000000
    //     0x12eab18: fmov            d1, #-10.00000000
    // 0x12eab1c: r0 = _lineTo$Method$FfiNative()
    //     0x12eab1c: bl              #0xb69bd0  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x12eab20: ldur            x0, [fp, #-0x10]
    // 0x12eab24: LoadField: r1 = r0->field_7
    //     0x12eab24: ldur            w1, [x0, #7]
    // 0x12eab28: DecompressPointer r1
    //     0x12eab28: add             x1, x1, HEAP, lsl #32
    // 0x12eab2c: cmp             w1, NULL
    // 0x12eab30: b.eq            #0x12eaf1c
    // 0x12eab34: LoadField: r2 = r1->field_7
    //     0x12eab34: ldur            x2, [x1, #7]
    // 0x12eab38: ldr             x1, [x2]
    // 0x12eab3c: cbz             x1, #0x12eaea4
    // 0x12eab40: mov             x2, x1
    // 0x12eab44: stur            x2, [fp, #-0x48]
    // 0x12eab48: r1 = <Never>
    //     0x12eab48: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12eab4c: r0 = Pointer()
    //     0x12eab4c: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12eab50: mov             x1, x0
    // 0x12eab54: ldur            x0, [fp, #-0x48]
    // 0x12eab58: StoreField: r1->field_7 = r0
    //     0x12eab58: stur            x0, [x1, #7]
    // 0x12eab5c: d0 = 10.000000
    //     0x12eab5c: fmov            d0, #10.00000000
    // 0x12eab60: d1 = -10.000000
    //     0x12eab60: fmov            d1, #-10.00000000
    // 0x12eab64: r0 = _lineTo$Method$FfiNative()
    //     0x12eab64: bl              #0xb69bd0  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x12eab68: ldur            x0, [fp, #-0x10]
    // 0x12eab6c: LoadField: r1 = r0->field_7
    //     0x12eab6c: ldur            w1, [x0, #7]
    // 0x12eab70: DecompressPointer r1
    //     0x12eab70: add             x1, x1, HEAP, lsl #32
    // 0x12eab74: cmp             w1, NULL
    // 0x12eab78: b.eq            #0x12eaf20
    // 0x12eab7c: LoadField: r2 = r1->field_7
    //     0x12eab7c: ldur            x2, [x1, #7]
    // 0x12eab80: ldr             x1, [x2]
    // 0x12eab84: cbz             x1, #0x12eaeb4
    // 0x12eab88: ldur            x2, [fp, #-8]
    // 0x12eab8c: mov             x3, x1
    // 0x12eab90: stur            x3, [fp, #-0x48]
    // 0x12eab94: r1 = <Never>
    //     0x12eab94: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12eab98: r0 = Pointer()
    //     0x12eab98: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12eab9c: mov             x1, x0
    // 0x12eaba0: ldur            x0, [fp, #-0x48]
    // 0x12eaba4: StoreField: r1->field_7 = r0
    //     0x12eaba4: stur            x0, [x1, #7]
    // 0x12eaba8: r0 = _close$Method$FfiNative()
    //     0x12eaba8: bl              #0xb78188  ; [dart:ui] _NativePath::_close$Method$FfiNative
    // 0x12eabac: ldur            x0, [fp, #-8]
    // 0x12eabb0: LoadField: d0 = r0->field_b
    //     0x12eabb0: ldur            d0, [x0, #0xb]
    // 0x12eabb4: fcvt            s1, d0
    // 0x12eabb8: stur            d1, [fp, #-0x50]
    // 0x12eabbc: r4 = 24
    //     0x12eabbc: mov             x4, #0x18
    // 0x12eabc0: r0 = AllocateFloat32Array()
    //     0x12eabc0: bl              #0x13defe8  ; AllocateFloat32ArrayStub
    // 0x12eabc4: ldur            d0, [fp, #-0x50]
    // 0x12eabc8: stur            x0, [fp, #-0x20]
    // 0x12eabcc: ArrayStore: r0[0] = d0  ; List_8
    //     0x12eabcc: stur            s0, [x0, #0x17]
    // 0x12eabd0: ldur            x1, [fp, #-8]
    // 0x12eabd4: LoadField: d0 = r1->field_13
    //     0x12eabd4: ldur            d0, [x1, #0x13]
    // 0x12eabd8: fcvt            s1, d0
    // 0x12eabdc: StoreField: r0->field_1b = d1
    //     0x12eabdc: stur            s1, [x0, #0x1b]
    // 0x12eabe0: LoadField: d0 = r1->field_1b
    //     0x12eabe0: ldur            d0, [x1, #0x1b]
    // 0x12eabe4: fcvt            s1, d0
    // 0x12eabe8: StoreField: r0->field_1f = d1
    //     0x12eabe8: stur            s1, [x0, #0x1f]
    // 0x12eabec: LoadField: d0 = r1->field_23
    //     0x12eabec: ldur            d0, [x1, #0x23]
    // 0x12eabf0: fcvt            s1, d0
    // 0x12eabf4: StoreField: r0->field_23 = d1
    //     0x12eabf4: stur            s1, [x0, #0x23]
    // 0x12eabf8: LoadField: d0 = r1->field_2b
    //     0x12eabf8: ldur            d0, [x1, #0x2b]
    // 0x12eabfc: fcvt            s1, d0
    // 0x12eac00: StoreField: r0->field_27 = d1
    //     0x12eac00: stur            s1, [x0, #0x27]
    // 0x12eac04: LoadField: d0 = r1->field_33
    //     0x12eac04: ldur            d0, [x1, #0x33]
    // 0x12eac08: fcvt            s1, d0
    // 0x12eac0c: StoreField: r0->field_2b = d1
    //     0x12eac0c: stur            s1, [x0, #0x2b]
    // 0x12eac10: LoadField: d0 = r1->field_3b
    //     0x12eac10: ldur            d0, [x1, #0x3b]
    // 0x12eac14: fcvt            s1, d0
    // 0x12eac18: StoreField: r0->field_2f = d1
    //     0x12eac18: stur            s1, [x0, #0x2f]
    // 0x12eac1c: LoadField: d0 = r1->field_43
    //     0x12eac1c: ldur            d0, [x1, #0x43]
    // 0x12eac20: fcvt            s1, d0
    // 0x12eac24: StoreField: r0->field_33 = d1
    //     0x12eac24: stur            s1, [x0, #0x33]
    // 0x12eac28: LoadField: d0 = r1->field_4b
    //     0x12eac28: ldur            d0, [x1, #0x4b]
    // 0x12eac2c: fcvt            s1, d0
    // 0x12eac30: StoreField: r0->field_37 = d1
    //     0x12eac30: stur            s1, [x0, #0x37]
    // 0x12eac34: LoadField: d0 = r1->field_53
    //     0x12eac34: ldur            d0, [x1, #0x53]
    // 0x12eac38: fcvt            s1, d0
    // 0x12eac3c: StoreField: r0->field_3b = d1
    //     0x12eac3c: stur            s1, [x0, #0x3b]
    // 0x12eac40: LoadField: d0 = r1->field_5b
    //     0x12eac40: ldur            d0, [x1, #0x5b]
    // 0x12eac44: fcvt            s1, d0
    // 0x12eac48: StoreField: r0->field_3f = d1
    //     0x12eac48: stur            s1, [x0, #0x3f]
    // 0x12eac4c: LoadField: d0 = r1->field_63
    //     0x12eac4c: ldur            d0, [x1, #0x63]
    // 0x12eac50: fcvt            s1, d0
    // 0x12eac54: StoreField: r0->field_43 = d1
    //     0x12eac54: stur            s1, [x0, #0x43]
    // 0x12eac58: ldur            x2, [fp, #-0x10]
    // 0x12eac5c: LoadField: r1 = r2->field_7
    //     0x12eac5c: ldur            w1, [x2, #7]
    // 0x12eac60: DecompressPointer r1
    //     0x12eac60: add             x1, x1, HEAP, lsl #32
    // 0x12eac64: cmp             w1, NULL
    // 0x12eac68: b.eq            #0x12eaf24
    // 0x12eac6c: LoadField: r3 = r1->field_7
    //     0x12eac6c: ldur            x3, [x1, #7]
    // 0x12eac70: ldr             x1, [x3]
    // 0x12eac74: cbz             x1, #0x12eaec4
    // 0x12eac78: ldur            x3, [fp, #-0x18]
    // 0x12eac7c: ldur            x4, [fp, #-0x40]
    // 0x12eac80: mov             x5, x1
    // 0x12eac84: stur            x5, [fp, #-0x48]
    // 0x12eac88: r1 = <Never>
    //     0x12eac88: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12eac8c: r0 = Pointer()
    //     0x12eac8c: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12eac90: mov             x1, x0
    // 0x12eac94: ldur            x0, [fp, #-0x48]
    // 0x12eac98: StoreField: r1->field_7 = r0
    //     0x12eac98: stur            x0, [x1, #7]
    // 0x12eac9c: ldur            x2, [fp, #-0x20]
    // 0x12eaca0: r0 = __addRRect$Method$FfiNative()
    //     0x12eaca0: bl              #0xbfd930  ; [dart:ui] _NativePath::__addRRect$Method$FfiNative
    // 0x12eaca4: ldur            x0, [fp, #-0x40]
    // 0x12eaca8: LoadField: r3 = r0->field_b
    //     0x12eaca8: ldur            w3, [x0, #0xb]
    // 0x12eacac: DecompressPointer r3
    //     0x12eacac: add             x3, x3, HEAP, lsl #32
    // 0x12eacb0: ldur            x2, [fp, #-0x18]
    // 0x12eacb4: stur            x3, [fp, #-8]
    // 0x12eacb8: LoadField: r0 = r2->field_7
    //     0x12eacb8: ldur            w0, [x2, #7]
    // 0x12eacbc: DecompressPointer r0
    //     0x12eacbc: add             x0, x0, HEAP, lsl #32
    // 0x12eacc0: cmp             w0, NULL
    // 0x12eacc4: b.eq            #0x12eaf28
    // 0x12eacc8: LoadField: r1 = r0->field_7
    //     0x12eacc8: ldur            x1, [x0, #7]
    // 0x12eaccc: ldr             x0, [x1]
    // 0x12eacd0: cbz             x0, #0x12eaed4
    // 0x12eacd4: ldur            x4, [fp, #-0x10]
    // 0x12eacd8: stur            x0, [fp, #-0x48]
    // 0x12eacdc: r1 = <Never>
    //     0x12eacdc: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12eace0: r0 = Pointer()
    //     0x12eace0: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12eace4: mov             x2, x0
    // 0x12eace8: ldur            x0, [fp, #-0x48]
    // 0x12eacec: stur            x2, [fp, #-0x20]
    // 0x12eacf0: StoreField: r2->field_7 = r0
    //     0x12eacf0: stur            x0, [x2, #7]
    // 0x12eacf4: ldur            x0, [fp, #-0x10]
    // 0x12eacf8: LoadField: r1 = r0->field_7
    //     0x12eacf8: ldur            w1, [x0, #7]
    // 0x12eacfc: DecompressPointer r1
    //     0x12eacfc: add             x1, x1, HEAP, lsl #32
    // 0x12ead00: cmp             w1, NULL
    // 0x12ead04: b.eq            #0x12eaf2c
    // 0x12ead08: LoadField: r3 = r1->field_7
    //     0x12ead08: ldur            x3, [x1, #7]
    // 0x12ead0c: ldr             x1, [x3]
    // 0x12ead10: mov             x3, x1
    // 0x12ead14: stur            x3, [fp, #-0x48]
    // 0x12ead18: r1 = <Never>
    //     0x12ead18: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12ead1c: r0 = Pointer()
    //     0x12ead1c: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12ead20: mov             x1, x0
    // 0x12ead24: ldur            x0, [fp, #-0x48]
    // 0x12ead28: StoreField: r1->field_7 = r0
    //     0x12ead28: stur            x0, [x1, #7]
    // 0x12ead2c: mov             x2, x1
    // 0x12ead30: ldur            x1, [fp, #-0x20]
    // 0x12ead34: ldur            x3, [fp, #-8]
    // 0x12ead38: ldur            x5, [fp, #-0x38]
    // 0x12ead3c: r0 = __drawPath$Method$FfiNative()
    //     0x12ead3c: bl              #0xb69a00  ; [dart:ui] _NativeCanvas::__drawPath$Method$FfiNative
    // 0x12ead40: ldur            x2, [fp, #-0x18]
    // 0x12ead44: LoadField: r0 = r2->field_7
    //     0x12ead44: ldur            w0, [x2, #7]
    // 0x12ead48: DecompressPointer r0
    //     0x12ead48: add             x0, x0, HEAP, lsl #32
    // 0x12ead4c: cmp             w0, NULL
    // 0x12ead50: b.eq            #0x12eaf30
    // 0x12ead54: LoadField: r1 = r0->field_7
    //     0x12ead54: ldur            x1, [x0, #7]
    // 0x12ead58: ldr             x0, [x1]
    // 0x12ead5c: cbz             x0, #0x12eaee4
    // 0x12ead60: ldur            x3, [fp, #-0x28]
    // 0x12ead64: ldur            d0, [fp, #-0x70]
    // 0x12ead68: stur            x0, [fp, #-0x48]
    // 0x12ead6c: r1 = <Never>
    //     0x12ead6c: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12ead70: r0 = Pointer()
    //     0x12ead70: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12ead74: mov             x1, x0
    // 0x12ead78: ldur            x0, [fp, #-0x48]
    // 0x12ead7c: StoreField: r1->field_7 = r0
    //     0x12ead7c: stur            x0, [x1, #7]
    // 0x12ead80: d0 = 0.000000
    //     0x12ead80: eor             v0.16b, v0.16b, v0.16b
    // 0x12ead84: d1 = -36.000000
    //     0x12ead84: add             x17, PP, #0xcc, lsl #12  ; [pp+0xccf30] IMM: double(-36) from 0xc042000000000000
    //     0x12ead88: ldr             d1, [x17, #0xf30]
    // 0x12ead8c: r0 = _translate$Method$FfiNative()
    //     0x12ead8c: bl              #0xb74a38  ; [dart:ui] _NativeCanvas::_translate$Method$FfiNative
    // 0x12ead90: r0 = Offset()
    //     0x12ead90: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x12ead94: ldur            d0, [fp, #-0x70]
    // 0x12ead98: stur            x0, [fp, #-8]
    // 0x12ead9c: StoreField: r0->field_7 = d0
    //     0x12ead9c: stur            d0, [x0, #7]
    // 0x12eada0: d0 = 16.000000
    //     0x12eada0: fmov            d0, #16.00000000
    // 0x12eada4: StoreField: r0->field_f = d0
    //     0x12eada4: stur            d0, [x0, #0xf]
    // 0x12eada8: ldur            x2, [fp, #-0x28]
    // 0x12eadac: LoadField: r1 = r2->field_7
    //     0x12eadac: ldur            w1, [x2, #7]
    // 0x12eadb0: DecompressPointer r1
    //     0x12eadb0: add             x1, x1, HEAP, lsl #32
    // 0x12eadb4: cmp             w1, NULL
    // 0x12eadb8: b.eq            #0x12eaf34
    // 0x12eadbc: LoadField: d0 = r1->field_13
    //     0x12eadbc: ldur            d0, [x1, #0x13]
    // 0x12eadc0: d1 = 2.000000
    //     0x12eadc0: fmov            d1, #2.00000000
    // 0x12eadc4: fdiv            d2, d0, d1
    // 0x12eadc8: mov             x1, x2
    // 0x12eadcc: stur            d2, [fp, #-0x50]
    // 0x12eadd0: r0 = height()
    //     0x12eadd0: bl              #0x859ce8  ; [package:flutter/src/painting/text_painter.dart] TextPainter::height
    // 0x12eadd4: mov             v1.16b, v0.16b
    // 0x12eadd8: d0 = 2.000000
    //     0x12eadd8: fmov            d0, #2.00000000
    // 0x12eaddc: fdiv            d2, d1, d0
    // 0x12eade0: stur            d2, [fp, #-0x58]
    // 0x12eade4: r0 = Offset()
    //     0x12eade4: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x12eade8: ldur            d0, [fp, #-0x50]
    // 0x12eadec: StoreField: r0->field_7 = d0
    //     0x12eadec: stur            d0, [x0, #7]
    // 0x12eadf0: ldur            d0, [fp, #-0x58]
    // 0x12eadf4: StoreField: r0->field_f = d0
    //     0x12eadf4: stur            d0, [x0, #0xf]
    // 0x12eadf8: ldur            x1, [fp, #-8]
    // 0x12eadfc: mov             x2, x0
    // 0x12eae00: r0 = -()
    //     0x12eae00: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0x12eae04: ldur            x1, [fp, #-0x28]
    // 0x12eae08: ldur            x2, [fp, #-0x18]
    // 0x12eae0c: mov             x3, x0
    // 0x12eae10: r0 = paint()
    //     0x12eae10: bl              #0xc22fac  ; [package:flutter/src/painting/text_painter.dart] TextPainter::paint
    // 0x12eae14: ldur            x0, [fp, #-0x18]
    // 0x12eae18: LoadField: r1 = r0->field_7
    //     0x12eae18: ldur            w1, [x0, #7]
    // 0x12eae1c: DecompressPointer r1
    //     0x12eae1c: add             x1, x1, HEAP, lsl #32
    // 0x12eae20: cmp             w1, NULL
    // 0x12eae24: b.eq            #0x12eaf38
    // 0x12eae28: LoadField: r2 = r1->field_7
    //     0x12eae28: ldur            x2, [x1, #7]
    // 0x12eae2c: ldr             x1, [x2]
    // 0x12eae30: cbz             x1, #0x12eaef4
    // 0x12eae34: mov             x2, x1
    // 0x12eae38: stur            x2, [fp, #-0x48]
    // 0x12eae3c: r1 = <Never>
    //     0x12eae3c: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12eae40: r0 = Pointer()
    //     0x12eae40: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12eae44: mov             x1, x0
    // 0x12eae48: ldur            x0, [fp, #-0x48]
    // 0x12eae4c: StoreField: r1->field_7 = r0
    //     0x12eae4c: stur            x0, [x1, #7]
    // 0x12eae50: r0 = _restore$Method$FfiNative()
    //     0x12eae50: bl              #0xb74908  ; [dart:ui] _NativeCanvas::_restore$Method$FfiNative
    // 0x12eae54: r0 = Null
    //     0x12eae54: mov             x0, NULL
    // 0x12eae58: LeaveFrame
    //     0x12eae58: mov             SP, fp
    //     0x12eae5c: ldp             fp, lr, [SP], #0x10
    // 0x12eae60: ret
    //     0x12eae60: ret             
    // 0x12eae64: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12eae64: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12eae68: str             x16, [SP]
    // 0x12eae6c: r0 = _throwNew()
    //     0x12eae6c: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12eae70: brk             #0
    // 0x12eae74: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12eae74: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12eae78: str             x16, [SP]
    // 0x12eae7c: r0 = _throwNew()
    //     0x12eae7c: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12eae80: brk             #0
    // 0x12eae84: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12eae84: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12eae88: str             x16, [SP]
    // 0x12eae8c: r0 = _throwNew()
    //     0x12eae8c: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12eae90: brk             #0
    // 0x12eae94: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12eae94: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12eae98: str             x16, [SP]
    // 0x12eae9c: r0 = _throwNew()
    //     0x12eae9c: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12eaea0: brk             #0
    // 0x12eaea4: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12eaea4: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12eaea8: str             x16, [SP]
    // 0x12eaeac: r0 = _throwNew()
    //     0x12eaeac: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12eaeb0: brk             #0
    // 0x12eaeb4: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12eaeb4: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12eaeb8: str             x16, [SP]
    // 0x12eaebc: r0 = _throwNew()
    //     0x12eaebc: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12eaec0: brk             #0
    // 0x12eaec4: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12eaec4: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12eaec8: str             x16, [SP]
    // 0x12eaecc: r0 = _throwNew()
    //     0x12eaecc: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12eaed0: brk             #0
    // 0x12eaed4: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12eaed4: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12eaed8: str             x16, [SP]
    // 0x12eaedc: r0 = _throwNew()
    //     0x12eaedc: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12eaee0: brk             #0
    // 0x12eaee4: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12eaee4: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12eaee8: str             x16, [SP]
    // 0x12eaeec: r0 = _throwNew()
    //     0x12eaeec: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12eaef0: brk             #0
    // 0x12eaef4: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12eaef4: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12eaef8: str             x16, [SP]
    // 0x12eaefc: r0 = _throwNew()
    //     0x12eaefc: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12eaf00: brk             #0
    // 0x12eaf04: r0 = StackOverflowSharedWithFPURegs()
    //     0x12eaf04: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12eaf08: b               #0x12ea8f8
    // 0x12eaf0c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12eaf0c: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12eaf10: r0 = NullErrorSharedWithFPURegs()
    //     0x12eaf10: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0x12eaf14: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12eaf14: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12eaf18: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12eaf18: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12eaf1c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12eaf1c: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12eaf20: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12eaf20: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12eaf24: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12eaf24: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12eaf28: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12eaf28: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12eaf2c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12eaf2c: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12eaf30: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12eaf30: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12eaf34: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12eaf34: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x12eaf38: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12eaf38: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ _adjustBorderRadius(/* No info */) {
    // ** addr: 0x12eaf3c, size: 0x8c
    // 0x12eaf3c: EnterFrame
    //     0x12eaf3c: stp             fp, lr, [SP, #-0x10]!
    //     0x12eaf40: mov             fp, SP
    // 0x12eaf44: AllocStack(0x10)
    //     0x12eaf44: sub             SP, SP, #0x10
    // 0x12eaf48: SetupParameters(_DropSliderValueIndicatorPathPainter this /* r1 => r0 */, dynamic _ /* r2 => r1 */)
    //     0x12eaf48: mov             x0, x1
    //     0x12eaf4c: mov             x1, x2
    // 0x12eaf50: CheckStackOverflow
    //     0x12eaf50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12eaf54: cmp             SP, x16
    //     0x12eaf58: b.ls            #0x12eafc0
    // 0x12eaf5c: r0 = shortestSide()
    //     0x12eaf5c: bl              #0xbfe320  ; [dart:ui] Rect::shortestSide
    // 0x12eaf60: mov             v1.16b, v0.16b
    // 0x12eaf64: d0 = 2.000000
    //     0x12eaf64: fmov            d0, #2.00000000
    // 0x12eaf68: fdiv            d2, d1, d0
    // 0x12eaf6c: stur            d2, [fp, #-0x10]
    // 0x12eaf70: r0 = Radius()
    //     0x12eaf70: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x12eaf74: ldur            d0, [fp, #-0x10]
    // 0x12eaf78: stur            x0, [fp, #-8]
    // 0x12eaf7c: StoreField: r0->field_7 = d0
    //     0x12eaf7c: stur            d0, [x0, #7]
    // 0x12eaf80: StoreField: r0->field_f = d0
    //     0x12eaf80: stur            d0, [x0, #0xf]
    // 0x12eaf84: r0 = BorderRadius()
    //     0x12eaf84: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x12eaf88: mov             x1, x0
    // 0x12eaf8c: ldur            x0, [fp, #-8]
    // 0x12eaf90: StoreField: r1->field_7 = r0
    //     0x12eaf90: stur            w0, [x1, #7]
    // 0x12eaf94: StoreField: r1->field_b = r0
    //     0x12eaf94: stur            w0, [x1, #0xb]
    // 0x12eaf98: StoreField: r1->field_f = r0
    //     0x12eaf98: stur            w0, [x1, #0xf]
    // 0x12eaf9c: StoreField: r1->field_13 = r0
    //     0x12eaf9c: stur            w0, [x1, #0x13]
    // 0x12eafa0: mov             x2, x1
    // 0x12eafa4: r1 = Instance_BorderRadius
    //     0x12eafa4: add             x1, PP, #0x8e, lsl #12  ; [pp+0x8e328] Obj!BorderRadius@129e2f1
    //     0x12eafa8: ldr             x1, [x1, #0x328]
    // 0x12eafac: d0 = 1.000000
    //     0x12eafac: fmov            d0, #1.00000000
    // 0x12eafb0: r0 = lerp()
    //     0x12eafb0: bl              #0xbfea10  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::lerp
    // 0x12eafb4: LeaveFrame
    //     0x12eafb4: mov             SP, fp
    //     0x12eafb8: ldp             fp, lr, [SP], #0x10
    // 0x12eafbc: ret
    //     0x12eafbc: ret             
    // 0x12eafc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12eafc0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12eafc4: b               #0x12eaf5c
  }
  _ getHorizontalShift(/* No info */) {
    // ** addr: 0x12eafc8, size: 0xec
    // 0x12eafc8: EnterFrame
    //     0x12eafc8: stp             fp, lr, [SP, #-0x10]!
    //     0x12eafcc: mov             fp, SP
    // 0x12eafd0: AllocStack(0x28)
    //     0x12eafd0: sub             SP, SP, #0x28
    // 0x12eafd4: SetupParameters(dynamic _ /* r2 => r3, fp-0x10 */, dynamic _ /* r3 => r2, fp-0x18 */, [dynamic _ /* fp-0x20 */])
    //     0x12eafd4: stur            x2, [fp, #-8]
    //     0x12eafd8: mov             x16, x3
    //     0x12eafdc: mov             x3, x2
    //     0x12eafe0: mov             x2, x16
    //     0x12eafe4: mov             x0, x5
    //     0x12eafe8: stur            x5, [fp, #-0x10]
    //     0x12eafec: stur            x6, [fp, #-0x18]
    //     0x12eaff0: stur            d1, [fp, #-0x20]
    // 0x12eaff4: CheckStackOverflow
    //     0x12eaff4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12eaff8: cmp             SP, x16
    //     0x12eaffc: b.ls            #0x12eb0ac
    // 0x12eb000: r0 = _upperRectangleWidth()
    //     0x12eb000: bl              #0x12eb0b4  ; [package:flutter/src/material/slider_parts.dart] _DropSliderValueIndicatorPathPainter::_upperRectangleWidth
    // 0x12eb004: ldur            x1, [fp, #-0x10]
    // 0x12eb008: ldur            x2, [fp, #-8]
    // 0x12eb00c: stur            d0, [fp, #-0x28]
    // 0x12eb010: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x12eb010: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x12eb014: r0 = localToGlobal()
    //     0x12eb014: bl              #0x856eb0  ; [package:flutter/src/rendering/box.dart] RenderBox::localToGlobal
    // 0x12eb018: ldur            d1, [fp, #-0x28]
    // 0x12eb01c: d2 = 2.000000
    //     0x12eb01c: fmov            d2, #2.00000000
    // 0x12eb020: fdiv            d3, d1, d2
    // 0x12eb024: LoadField: d2 = r0->field_7
    //     0x12eb024: ldur            d2, [x0, #7]
    // 0x12eb028: fsub            d4, d3, d2
    // 0x12eb02c: d5 = 8.000000
    //     0x12eb02c: fmov            d5, #8.00000000
    // 0x12eb030: fadd            d6, d4, d5
    // 0x12eb034: d4 = 0.000000
    //     0x12eb034: eor             v4.16b, v4.16b, v4.16b
    // 0x12eb038: fmax            v7.2d, v4.2d, v6.2d
    // 0x12eb03c: ldur            x0, [fp, #-0x18]
    // 0x12eb040: LoadField: d6 = r0->field_7
    //     0x12eb040: ldur            d6, [x0, #7]
    // 0x12eb044: fsub            d8, d6, d2
    // 0x12eb048: fsub            d2, d8, d5
    // 0x12eb04c: fsub            d8, d3, d2
    // 0x12eb050: fmax            v2.2d, v4.2d, v8.2d
    // 0x12eb054: fcmp            d6, d1
    // 0x12eb058: b.le            #0x12eb06c
    // 0x12eb05c: fsub            d0, d7, d2
    // 0x12eb060: LeaveFrame
    //     0x12eb060: mov             SP, fp
    //     0x12eb064: ldp             fp, lr, [SP], #0x10
    // 0x12eb068: ret
    //     0x12eb068: ret             
    // 0x12eb06c: fsub            d1, d7, d2
    // 0x12eb070: fcmp            d1, d4
    // 0x12eb074: b.le            #0x12eb090
    // 0x12eb078: ldur            d1, [fp, #-0x20]
    // 0x12eb07c: fmul            d3, d1, d5
    // 0x12eb080: fsub            d0, d7, d3
    // 0x12eb084: LeaveFrame
    //     0x12eb084: mov             SP, fp
    //     0x12eb088: ldp             fp, lr, [SP], #0x10
    // 0x12eb08c: ret
    //     0x12eb08c: ret             
    // 0x12eb090: ldur            d1, [fp, #-0x20]
    // 0x12eb094: fneg            d3, d2
    // 0x12eb098: fmul            d2, d1, d5
    // 0x12eb09c: fadd            d0, d3, d2
    // 0x12eb0a0: LeaveFrame
    //     0x12eb0a0: mov             SP, fp
    //     0x12eb0a4: ldp             fp, lr, [SP], #0x10
    // 0x12eb0a8: ret
    //     0x12eb0a8: ret             
    // 0x12eb0ac: r0 = StackOverflowSharedWithFPURegs()
    //     0x12eb0ac: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12eb0b0: b               #0x12eb000
  }
  _ _upperRectangleWidth(/* No info */) {
    // ** addr: 0x12eb0b4, size: 0x3c
    // 0x12eb0b4: d2 = 20.000000
    //     0x12eb0b4: fmov            d2, #20.00000000
    // 0x12eb0b8: d1 = 8.000000
    //     0x12eb0b8: fmov            d1, #8.00000000
    // 0x12eb0bc: LoadField: r0 = r2->field_7
    //     0x12eb0bc: ldur            w0, [x2, #7]
    // 0x12eb0c0: DecompressPointer r0
    //     0x12eb0c0: add             x0, x0, HEAP, lsl #32
    // 0x12eb0c4: cmp             w0, NULL
    // 0x12eb0c8: b.eq            #0x12eb0e4
    // 0x12eb0cc: LoadField: d3 = r0->field_13
    //     0x12eb0cc: ldur            d3, [x0, #0x13]
    // 0x12eb0d0: fmax            v4.2d, v2.2d, v3.2d
    // 0x12eb0d4: fadd            d2, d4, d1
    // 0x12eb0d8: fmul            d1, d2, d0
    // 0x12eb0dc: mov             v0.16b, v1.16b
    // 0x12eb0e0: ret
    //     0x12eb0e0: ret             
    // 0x12eb0e4: EnterFrame
    //     0x12eb0e4: stp             fp, lr, [SP, #-0x10]!
    //     0x12eb0e8: mov             fp, SP
    // 0x12eb0ec: r0 = NullCastErrorSharedWithFPURegs()
    //     0x12eb0ec: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
}

// class id: 2979, size: 0x8, field offset: 0x8
//   const constructor, 
class RoundedRectSliderValueIndicatorShape extends SliderComponentShape {
}

// class id: 2980, size: 0x8, field offset: 0x8
//   const constructor, 
class HandleThumbShape extends SliderComponentShape {
}

// class id: 2981, size: 0x8, field offset: 0x8
//   const constructor, 
class DropSliderValueIndicatorShape extends SliderComponentShape {

  _ paint(/* No info */) {
    // ** addr: 0x12ea7bc, size: 0xe4
    // 0x12ea7bc: EnterFrame
    //     0x12ea7bc: stp             fp, lr, [SP, #-0x10]!
    //     0x12ea7c0: mov             fp, SP
    // 0x12ea7c4: AllocStack(0x30)
    //     0x12ea7c4: sub             SP, SP, #0x30
    // 0x12ea7c8: SetupParameters(DropSliderValueIndicatorShape this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r5, fp-0x8 */, [dynamic _ /* r0 */, dynamic _ /* r6, fp-0x18 */, dynamic _ /* d1, fp-0x28 */])
    //     0x12ea7c8: mov             x16, x2
    //     0x12ea7cc: mov             x2, x1
    //     0x12ea7d0: mov             x1, x16
    //     0x12ea7d4: mov             x16, x5
    //     0x12ea7d8: mov             x5, x2
    //     0x12ea7dc: mov             x2, x16
    //     0x12ea7e0: mov             x16, x3
    //     0x12ea7e4: mov             x3, x5
    //     0x12ea7e8: mov             x5, x16
    //     0x12ea7ec: mov             x0, x6
    //     0x12ea7f0: mov             x6, x7
    //     0x12ea7f4: mov             v1.16b, v0.16b
    //     0x12ea7f8: stur            x5, [fp, #-8]
    //     0x12ea7fc: stur            x2, [fp, #-0x10]
    //     0x12ea800: stur            x7, [fp, #-0x18]
    //     0x12ea804: stur            d0, [fp, #-0x28]
    // 0x12ea808: CheckStackOverflow
    //     0x12ea808: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12ea80c: cmp             SP, x16
    //     0x12ea810: b.ls            #0x12ea894
    // 0x12ea814: r0 = canvas()
    //     0x12ea814: bl              #0xc17694  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0x12ea818: mov             x2, x0
    // 0x12ea81c: ldur            x1, [fp, #-0x10]
    // 0x12ea820: stur            x2, [fp, #-0x20]
    // 0x12ea824: r0 = LoadClassIdInstr(r1)
    //     0x12ea824: ldur            x0, [x1, #-1]
    //     0x12ea828: ubfx            x0, x0, #0xc, #0x14
    // 0x12ea82c: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0x12ea82c: mov             x17, #0x4e2e
    //     0x12ea830: movk            x17, #1, lsl #16
    //     0x12ea834: add             lr, x0, x17
    //     0x12ea838: ldr             lr, [x21, lr, lsl #3]
    //     0x12ea83c: blr             lr
    // 0x12ea840: mov             x1, x0
    // 0x12ea844: ldr             x0, [fp, #0x10]
    // 0x12ea848: LoadField: r2 = r0->field_43
    //     0x12ea848: ldur            w2, [x0, #0x43]
    // 0x12ea84c: DecompressPointer r2
    //     0x12ea84c: add             x2, x2, HEAP, lsl #32
    // 0x12ea850: cmp             w2, NULL
    // 0x12ea854: b.eq            #0x12ea89c
    // 0x12ea858: LoadField: d0 = r1->field_7
    //     0x12ea858: ldur            d0, [x1, #7]
    // 0x12ea85c: ldr             x16, [fp, #0x18]
    // 0x12ea860: str             x16, [SP]
    // 0x12ea864: ldur            x3, [fp, #-0x20]
    // 0x12ea868: ldur            x5, [fp, #-8]
    // 0x12ea86c: ldur            x6, [fp, #-0x18]
    // 0x12ea870: ldr             x7, [fp, #0x20]
    // 0x12ea874: ldur            d1, [fp, #-0x28]
    // 0x12ea878: r1 = Instance__DropSliderValueIndicatorPathPainter
    //     0x12ea878: add             x1, PP, #0xcc, lsl #12  ; [pp+0xccf20] Obj!_DropSliderValueIndicatorPathPainter@129e881
    //     0x12ea87c: ldr             x1, [x1, #0xf20]
    // 0x12ea880: r0 = paint()
    //     0x12ea880: bl              #0x12ea8a0  ; [package:flutter/src/material/slider_parts.dart] _DropSliderValueIndicatorPathPainter::paint
    // 0x12ea884: r0 = Null
    //     0x12ea884: mov             x0, NULL
    // 0x12ea888: LeaveFrame
    //     0x12ea888: mov             SP, fp
    //     0x12ea88c: ldp             fp, lr, [SP], #0x10
    // 0x12ea890: ret
    //     0x12ea890: ret             
    // 0x12ea894: r0 = StackOverflowSharedWithFPURegs()
    //     0x12ea894: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12ea898: b               #0x12ea814
    // 0x12ea89c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12ea89c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2982, size: 0x24, field offset: 0x8
//   const constructor, 
class RoundSliderThumbShape extends SliderComponentShape {

  _Double field_8;
  _Double field_14;
  _Double field_1c;

  _ getPreferredSize(/* No info */) {
    // ** addr: 0xb1e464, size: 0x24
    // 0xb1e464: EnterFrame
    //     0xb1e464: stp             fp, lr, [SP, #-0x10]!
    //     0xb1e468: mov             fp, SP
    // 0xb1e46c: r0 = Size()
    //     0xb1e46c: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb1e470: d0 = 20.000000
    //     0xb1e470: fmov            d0, #20.00000000
    // 0xb1e474: StoreField: r0->field_7 = d0
    //     0xb1e474: stur            d0, [x0, #7]
    // 0xb1e478: StoreField: r0->field_f = d0
    //     0xb1e478: stur            d0, [x0, #0xf]
    // 0xb1e47c: LeaveFrame
    //     0xb1e47c: mov             SP, fp
    //     0xb1e480: ldp             fp, lr, [SP], #0x10
    // 0xb1e484: ret
    //     0xb1e484: ret             
  }
  _ paint(/* No info */) {
    // ** addr: 0x12ea4d0, size: 0x2ec
    // 0x12ea4d0: EnterFrame
    //     0x12ea4d0: stp             fp, lr, [SP, #-0x10]!
    //     0x12ea4d4: mov             fp, SP
    // 0x12ea4d8: AllocStack(0x80)
    //     0x12ea4d8: sub             SP, SP, #0x80
    // 0x12ea4dc: SetupParameters(RoundSliderThumbShape this /* r1 => r4 */, dynamic _ /* r2 => r1 */, dynamic _ /* r3 => r3, fp-0x8 */, dynamic _ /* r5 => r0, fp-0x10 */, dynamic _ /* r6 => r2, fp-0x18 */)
    //     0x12ea4dc: mov             x4, x1
    //     0x12ea4e0: mov             x1, x2
    //     0x12ea4e4: mov             x0, x5
    //     0x12ea4e8: mov             x2, x6
    //     0x12ea4ec: stur            x3, [fp, #-8]
    //     0x12ea4f0: stur            x5, [fp, #-0x10]
    //     0x12ea4f4: stur            x6, [fp, #-0x18]
    // 0x12ea4f8: CheckStackOverflow
    //     0x12ea4f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12ea4fc: cmp             SP, x16
    //     0x12ea500: b.ls            #0x12ea7a4
    // 0x12ea504: r0 = canvas()
    //     0x12ea504: bl              #0xc17694  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0x12ea508: r1 = <double>
    //     0x12ea508: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0x12ea50c: stur            x0, [fp, #-0x20]
    // 0x12ea510: r0 = Tween()
    //     0x12ea510: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x12ea514: mov             x2, x0
    // 0x12ea518: r0 = 10.000000
    //     0x12ea518: add             x0, PP, #0x13, lsl #12  ; [pp+0x13850] 10
    //     0x12ea51c: ldr             x0, [x0, #0x850]
    // 0x12ea520: stur            x2, [fp, #-0x38]
    // 0x12ea524: StoreField: r2->field_b = r0
    //     0x12ea524: stur            w0, [x2, #0xb]
    // 0x12ea528: StoreField: r2->field_f = r0
    //     0x12ea528: stur            w0, [x2, #0xf]
    // 0x12ea52c: ldr             x0, [fp, #0x10]
    // 0x12ea530: LoadField: r3 = r0->field_3b
    //     0x12ea530: ldur            w3, [x0, #0x3b]
    // 0x12ea534: DecompressPointer r3
    //     0x12ea534: add             x3, x3, HEAP, lsl #32
    // 0x12ea538: stur            x3, [fp, #-0x30]
    // 0x12ea53c: LoadField: r4 = r0->field_33
    //     0x12ea53c: ldur            w4, [x0, #0x33]
    // 0x12ea540: DecompressPointer r4
    //     0x12ea540: add             x4, x4, HEAP, lsl #32
    // 0x12ea544: stur            x4, [fp, #-0x28]
    // 0x12ea548: r1 = <Color?>
    //     0x12ea548: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x12ea54c: ldr             x1, [x1, #0xa40]
    // 0x12ea550: r0 = ColorTween()
    //     0x12ea550: bl              #0x915f2c  ; AllocateColorTweenStub -> ColorTween (size=0x14)
    // 0x12ea554: mov             x1, x0
    // 0x12ea558: ldur            x0, [fp, #-0x30]
    // 0x12ea55c: StoreField: r1->field_b = r0
    //     0x12ea55c: stur            w0, [x1, #0xb]
    // 0x12ea560: ldur            x0, [fp, #-0x28]
    // 0x12ea564: StoreField: r1->field_f = r0
    //     0x12ea564: stur            w0, [x1, #0xf]
    // 0x12ea568: ldur            x2, [fp, #-0x18]
    // 0x12ea56c: r0 = evaluate()
    //     0x12ea56c: bl              #0x112be60  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x12ea570: stur            x0, [fp, #-0x28]
    // 0x12ea574: cmp             w0, NULL
    // 0x12ea578: b.eq            #0x12ea7ac
    // 0x12ea57c: ldur            x1, [fp, #-0x38]
    // 0x12ea580: ldur            x2, [fp, #-0x18]
    // 0x12ea584: r0 = evaluate()
    //     0x12ea584: bl              #0x112be60  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x12ea588: r1 = <double>
    //     0x12ea588: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0x12ea58c: stur            x0, [fp, #-0x18]
    // 0x12ea590: r0 = Tween()
    //     0x12ea590: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x12ea594: mov             x1, x0
    // 0x12ea598: r0 = 1.000000
    //     0x12ea598: ldr             x0, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0x12ea59c: StoreField: r1->field_b = r0
    //     0x12ea59c: stur            w0, [x1, #0xb]
    // 0x12ea5a0: r0 = 6.000000
    //     0x12ea5a0: add             x0, PP, #0x1c, lsl #12  ; [pp+0x1c438] 6
    //     0x12ea5a4: ldr             x0, [x0, #0x438]
    // 0x12ea5a8: StoreField: r1->field_f = r0
    //     0x12ea5a8: stur            w0, [x1, #0xf]
    // 0x12ea5ac: ldur            x2, [fp, #-0x10]
    // 0x12ea5b0: r0 = evaluate()
    //     0x12ea5b0: bl              #0x112be60  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x12ea5b4: stur            x0, [fp, #-0x10]
    // 0x12ea5b8: r0 = _NativePath()
    //     0x12ea5b8: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0x12ea5bc: mov             x1, x0
    // 0x12ea5c0: stur            x0, [fp, #-0x30]
    // 0x12ea5c4: r0 = __constructor$Method$FfiNative()
    //     0x12ea5c4: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0x12ea5c8: ldur            x0, [fp, #-0x18]
    // 0x12ea5cc: LoadField: d0 = r0->field_7
    //     0x12ea5cc: ldur            d0, [x0, #7]
    // 0x12ea5d0: stur            d0, [fp, #-0x58]
    // 0x12ea5d4: d1 = 2.000000
    //     0x12ea5d4: fmov            d1, #2.00000000
    // 0x12ea5d8: fmul            d2, d0, d1
    // 0x12ea5dc: stur            d2, [fp, #-0x50]
    // 0x12ea5e0: r0 = Rect()
    //     0x12ea5e0: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0x12ea5e4: mov             x1, x0
    // 0x12ea5e8: ldur            x2, [fp, #-8]
    // 0x12ea5ec: ldur            d0, [fp, #-0x50]
    // 0x12ea5f0: ldur            d1, [fp, #-0x50]
    // 0x12ea5f4: stur            x0, [fp, #-0x18]
    // 0x12ea5f8: r0 = Rect.fromCenter()
    //     0x12ea5f8: bl              #0x86ddc8  ; [dart:ui] Rect::Rect.fromCenter
    // 0x12ea5fc: ldur            x0, [fp, #-0x18]
    // 0x12ea600: LoadField: d0 = r0->field_7
    //     0x12ea600: ldur            d0, [x0, #7]
    // 0x12ea604: stur            d0, [fp, #-0x70]
    // 0x12ea608: LoadField: d1 = r0->field_f
    //     0x12ea608: ldur            d1, [x0, #0xf]
    // 0x12ea60c: stur            d1, [fp, #-0x68]
    // 0x12ea610: ArrayLoad: d2 = r0[0]  ; List_8
    //     0x12ea610: ldur            d2, [x0, #0x17]
    // 0x12ea614: stur            d2, [fp, #-0x60]
    // 0x12ea618: LoadField: d3 = r0->field_1f
    //     0x12ea618: ldur            d3, [x0, #0x1f]
    // 0x12ea61c: ldur            x0, [fp, #-0x30]
    // 0x12ea620: stur            d3, [fp, #-0x50]
    // 0x12ea624: LoadField: r1 = r0->field_7
    //     0x12ea624: ldur            w1, [x0, #7]
    // 0x12ea628: DecompressPointer r1
    //     0x12ea628: add             x1, x1, HEAP, lsl #32
    // 0x12ea62c: cmp             w1, NULL
    // 0x12ea630: b.eq            #0x12ea7b0
    // 0x12ea634: LoadField: r2 = r1->field_7
    //     0x12ea634: ldur            x2, [x1, #7]
    // 0x12ea638: ldr             x1, [x2]
    // 0x12ea63c: cbz             x1, #0x12ea784
    // 0x12ea640: ldur            x2, [fp, #-0x20]
    // 0x12ea644: mov             x3, x1
    // 0x12ea648: stur            x3, [fp, #-0x40]
    // 0x12ea64c: r1 = <Never>
    //     0x12ea64c: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12ea650: r0 = Pointer()
    //     0x12ea650: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12ea654: mov             x1, x0
    // 0x12ea658: ldur            x0, [fp, #-0x40]
    // 0x12ea65c: StoreField: r1->field_7 = r0
    //     0x12ea65c: stur            x0, [x1, #7]
    // 0x12ea660: ldur            d0, [fp, #-0x70]
    // 0x12ea664: ldur            d1, [fp, #-0x68]
    // 0x12ea668: ldur            d2, [fp, #-0x60]
    // 0x12ea66c: ldur            d3, [fp, #-0x50]
    // 0x12ea670: d4 = 0.000000
    //     0x12ea670: eor             v4.16b, v4.16b, v4.16b
    // 0x12ea674: d5 = 6.283185
    //     0x12ea674: add             x17, PP, #0x13, lsl #12  ; [pp+0x13298] IMM: double(6.283185307179586) from 0x401921fb54442d18
    //     0x12ea678: ldr             d5, [x17, #0x298]
    // 0x12ea67c: r0 = __addArc$Method$FfiNative()
    //     0x12ea67c: bl              #0xb836a8  ; [dart:ui] _NativePath::__addArc$Method$FfiNative
    // 0x12ea680: r1 = Instance_Color
    //     0x12ea680: add             x1, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0x12ea684: ldr             x1, [x1, #0x948]
    // 0x12ea688: r0 = toARGB32()
    //     0x12ea688: bl              #0x119defc  ; [dart:ui] Color::toARGB32
    // 0x12ea68c: mov             x2, x0
    // 0x12ea690: ldur            x0, [fp, #-0x20]
    // 0x12ea694: stur            x2, [fp, #-0x48]
    // 0x12ea698: LoadField: r1 = r0->field_7
    //     0x12ea698: ldur            w1, [x0, #7]
    // 0x12ea69c: DecompressPointer r1
    //     0x12ea69c: add             x1, x1, HEAP, lsl #32
    // 0x12ea6a0: cmp             w1, NULL
    // 0x12ea6a4: b.eq            #0x12ea7b4
    // 0x12ea6a8: LoadField: r3 = r1->field_7
    //     0x12ea6a8: ldur            x3, [x1, #7]
    // 0x12ea6ac: ldr             x1, [x3]
    // 0x12ea6b0: cbz             x1, #0x12ea794
    // 0x12ea6b4: ldur            x4, [fp, #-0x10]
    // 0x12ea6b8: ldur            x3, [fp, #-0x30]
    // 0x12ea6bc: mov             x5, x1
    // 0x12ea6c0: stur            x5, [fp, #-0x40]
    // 0x12ea6c4: r1 = <Never>
    //     0x12ea6c4: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12ea6c8: r0 = Pointer()
    //     0x12ea6c8: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12ea6cc: mov             x2, x0
    // 0x12ea6d0: ldur            x0, [fp, #-0x40]
    // 0x12ea6d4: stur            x2, [fp, #-0x18]
    // 0x12ea6d8: StoreField: r2->field_7 = r0
    //     0x12ea6d8: stur            x0, [x2, #7]
    // 0x12ea6dc: ldur            x0, [fp, #-0x30]
    // 0x12ea6e0: LoadField: r1 = r0->field_7
    //     0x12ea6e0: ldur            w1, [x0, #7]
    // 0x12ea6e4: DecompressPointer r1
    //     0x12ea6e4: add             x1, x1, HEAP, lsl #32
    // 0x12ea6e8: cmp             w1, NULL
    // 0x12ea6ec: b.eq            #0x12ea7b8
    // 0x12ea6f0: LoadField: r3 = r1->field_7
    //     0x12ea6f0: ldur            x3, [x1, #7]
    // 0x12ea6f4: ldr             x1, [x3]
    // 0x12ea6f8: mov             x3, x1
    // 0x12ea6fc: stur            x3, [fp, #-0x40]
    // 0x12ea700: r1 = <Never>
    //     0x12ea700: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12ea704: r0 = Pointer()
    //     0x12ea704: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12ea708: mov             x1, x0
    // 0x12ea70c: ldur            x0, [fp, #-0x40]
    // 0x12ea710: StoreField: r1->field_7 = r0
    //     0x12ea710: stur            x0, [x1, #7]
    // 0x12ea714: ldur            x0, [fp, #-0x10]
    // 0x12ea718: LoadField: d0 = r0->field_7
    //     0x12ea718: ldur            d0, [x0, #7]
    // 0x12ea71c: mov             x2, x1
    // 0x12ea720: ldur            x1, [fp, #-0x18]
    // 0x12ea724: ldur            x3, [fp, #-0x48]
    // 0x12ea728: r5 = true
    //     0x12ea728: add             x5, NULL, #0x20  ; true
    // 0x12ea72c: r0 = __drawShadow$Method$FfiNative()
    //     0x12ea72c: bl              #0xb7447c  ; [dart:ui] _NativeCanvas::__drawShadow$Method$FfiNative
    // 0x12ea730: r16 = 136
    //     0x12ea730: mov             x16, #0x88
    // 0x12ea734: stp             x16, NULL, [SP]
    // 0x12ea738: r0 = ByteData()
    //     0x12ea738: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0x12ea73c: stur            x0, [fp, #-0x10]
    // 0x12ea740: r0 = Paint()
    //     0x12ea740: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x12ea744: mov             x3, x0
    // 0x12ea748: ldur            x0, [fp, #-0x10]
    // 0x12ea74c: stur            x3, [fp, #-0x18]
    // 0x12ea750: StoreField: r3->field_7 = r0
    //     0x12ea750: stur            w0, [x3, #7]
    // 0x12ea754: mov             x1, x3
    // 0x12ea758: ldur            x2, [fp, #-0x28]
    // 0x12ea75c: r0 = color=()
    //     0x12ea75c: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0x12ea760: ldur            x1, [fp, #-0x20]
    // 0x12ea764: ldur            x2, [fp, #-8]
    // 0x12ea768: ldur            d0, [fp, #-0x58]
    // 0x12ea76c: ldur            x3, [fp, #-0x18]
    // 0x12ea770: r0 = drawCircle()
    //     0x12ea770: bl              #0xb6acd4  ; [dart:ui] _NativeCanvas::drawCircle
    // 0x12ea774: r0 = Null
    //     0x12ea774: mov             x0, NULL
    // 0x12ea778: LeaveFrame
    //     0x12ea778: mov             SP, fp
    //     0x12ea77c: ldp             fp, lr, [SP], #0x10
    // 0x12ea780: ret
    //     0x12ea780: ret             
    // 0x12ea784: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12ea784: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12ea788: str             x16, [SP]
    // 0x12ea78c: r0 = _throwNew()
    //     0x12ea78c: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12ea790: brk             #0
    // 0x12ea794: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12ea794: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12ea798: str             x16, [SP]
    // 0x12ea79c: r0 = _throwNew()
    //     0x12ea79c: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12ea7a0: brk             #0
    // 0x12ea7a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12ea7a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12ea7a8: b               #0x12ea504
    // 0x12ea7ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12ea7ac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x12ea7b0: r0 = NullErrorSharedWithFPURegs()
    //     0x12ea7b0: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0x12ea7b4: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12ea7b4: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12ea7b8: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12ea7b8: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
}

// class id: 2983, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class SliderTickMarkShape extends Object {
}

// class id: 2984, size: 0xc, field offset: 0x8
//   const constructor, 
class RoundSliderTickMarkShape extends SliderTickMarkShape {

  _Double field_8;

  _ getPreferredSize(/* No info */) {
    // ** addr: 0xb1e3f0, size: 0x74
    // 0xb1e3f0: EnterFrame
    //     0xb1e3f0: stp             fp, lr, [SP, #-0x10]!
    //     0xb1e3f4: mov             fp, SP
    // 0xb1e3f8: AllocStack(0x8)
    //     0xb1e3f8: sub             SP, SP, #8
    // 0xb1e3fc: LoadField: r0 = r1->field_7
    //     0xb1e3fc: ldur            w0, [x1, #7]
    // 0xb1e400: DecompressPointer r0
    //     0xb1e400: add             x0, x0, HEAP, lsl #32
    // 0xb1e404: cmp             w0, NULL
    // 0xb1e408: b.ne            #0xb1e430
    // 0xb1e40c: d0 = 4.000000
    //     0xb1e40c: fmov            d0, #4.00000000
    // 0xb1e410: LoadField: r0 = r2->field_7
    //     0xb1e410: ldur            w0, [x2, #7]
    // 0xb1e414: DecompressPointer r0
    //     0xb1e414: add             x0, x0, HEAP, lsl #32
    // 0xb1e418: cmp             w0, NULL
    // 0xb1e41c: b.eq            #0xb1e460
    // 0xb1e420: LoadField: d1 = r0->field_7
    //     0xb1e420: ldur            d1, [x0, #7]
    // 0xb1e424: fdiv            d2, d1, d0
    // 0xb1e428: mov             v1.16b, v2.16b
    // 0xb1e42c: b               #0xb1e438
    // 0xb1e430: LoadField: d0 = r0->field_7
    //     0xb1e430: ldur            d0, [x0, #7]
    // 0xb1e434: mov             v1.16b, v0.16b
    // 0xb1e438: d0 = 2.000000
    //     0xb1e438: fmov            d0, #2.00000000
    // 0xb1e43c: fmul            d2, d1, d0
    // 0xb1e440: stur            d2, [fp, #-8]
    // 0xb1e444: r0 = Size()
    //     0xb1e444: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb1e448: ldur            d0, [fp, #-8]
    // 0xb1e44c: StoreField: r0->field_7 = d0
    //     0xb1e44c: stur            d0, [x0, #7]
    // 0xb1e450: StoreField: r0->field_f = d0
    //     0xb1e450: stur            d0, [x0, #0xf]
    // 0xb1e454: LeaveFrame
    //     0xb1e454: mov             SP, fp
    //     0xb1e458: ldp             fp, lr, [SP], #0x10
    // 0xb1e45c: ret
    //     0xb1e45c: ret             
    // 0xb1e460: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb1e460: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  _ paint(/* No info */) {
    // ** addr: 0xc23ec0, size: 0x1cc
    // 0xc23ec0: EnterFrame
    //     0xc23ec0: stp             fp, lr, [SP, #-0x10]!
    //     0xc23ec4: mov             fp, SP
    // 0xc23ec8: AllocStack(0x60)
    //     0xc23ec8: sub             SP, SP, #0x60
    // 0xc23ecc: SetupParameters(RoundSliderTickMarkShape this /* r1 => r6, fp-0x8 */, dynamic _ /* r2 => r5, fp-0x10 */, dynamic _ /* r3 => r4, fp-0x18 */, dynamic _ /* r5 => r1, fp-0x20 */, dynamic _ /* r6 => r0, fp-0x28 */)
    //     0xc23ecc: mov             x0, x6
    //     0xc23ed0: stur            x6, [fp, #-0x28]
    //     0xc23ed4: mov             x6, x1
    //     0xc23ed8: stur            x1, [fp, #-8]
    //     0xc23edc: mov             x1, x5
    //     0xc23ee0: stur            x5, [fp, #-0x20]
    //     0xc23ee4: mov             x5, x2
    //     0xc23ee8: mov             x4, x3
    //     0xc23eec: stur            x2, [fp, #-0x10]
    //     0xc23ef0: stur            x3, [fp, #-0x18]
    // 0xc23ef4: CheckStackOverflow
    //     0xc23ef4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc23ef8: cmp             SP, x16
    //     0xc23efc: b.ls            #0xc24080
    // 0xc23f00: LoadField: d0 = r4->field_7
    //     0xc23f00: ldur            d0, [x4, #7]
    // 0xc23f04: ldr             x2, [fp, #0x10]
    // 0xc23f08: LoadField: d1 = r2->field_7
    //     0xc23f08: ldur            d1, [x2, #7]
    // 0xc23f0c: fsub            d2, d0, d1
    // 0xc23f10: r16 = Instance_TextDirection
    //     0xc23f10: ldr             x16, [PP, #0x25b0]  ; [pp+0x25b0] Obj!TextDirection@12c73a1
    // 0xc23f14: cmp             w7, w16
    // 0xc23f18: r16 = true
    //     0xc23f18: add             x16, NULL, #0x20  ; true
    // 0xc23f1c: r17 = false
    //     0xc23f1c: add             x17, NULL, #0x30  ; false
    // 0xc23f20: csel            x2, x16, x17, eq
    // 0xc23f24: tbnz            w2, #4, #0xc23f4c
    // 0xc23f28: d0 = 0.000000
    //     0xc23f28: eor             v0.16b, v0.16b, v0.16b
    // 0xc23f2c: fcmp            d2, d0
    // 0xc23f30: b.le            #0xc23f4c
    // 0xc23f34: LoadField: r2 = r0->field_2f
    //     0xc23f34: ldur            w2, [x0, #0x2f]
    // 0xc23f38: DecompressPointer r2
    //     0xc23f38: add             x2, x2, HEAP, lsl #32
    // 0xc23f3c: LoadField: r3 = r0->field_27
    //     0xc23f3c: ldur            w3, [x0, #0x27]
    // 0xc23f40: DecompressPointer r3
    //     0xc23f40: add             x3, x3, HEAP, lsl #32
    // 0xc23f44: r0 = AllocateRecord2()
    //     0xc23f44: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xc23f48: b               #0xc23fb4
    // 0xc23f4c: r16 = Instance_TextDirection
    //     0xc23f4c: ldr             x16, [PP, #0x2578]  ; [pp+0x2578] Obj!TextDirection@12c7381
    // 0xc23f50: cmp             w7, w16
    // 0xc23f54: r16 = true
    //     0xc23f54: add             x16, NULL, #0x20  ; true
    // 0xc23f58: r17 = false
    //     0xc23f58: add             x17, NULL, #0x30  ; false
    // 0xc23f5c: csel            x0, x16, x17, eq
    // 0xc23f60: tbnz            w0, #4, #0xc23f8c
    // 0xc23f64: d0 = 0.000000
    //     0xc23f64: eor             v0.16b, v0.16b, v0.16b
    // 0xc23f68: fcmp            d0, d2
    // 0xc23f6c: b.le            #0xc23f8c
    // 0xc23f70: ldur            x0, [fp, #-0x28]
    // 0xc23f74: LoadField: r2 = r0->field_2f
    //     0xc23f74: ldur            w2, [x0, #0x2f]
    // 0xc23f78: DecompressPointer r2
    //     0xc23f78: add             x2, x2, HEAP, lsl #32
    // 0xc23f7c: LoadField: r3 = r0->field_27
    //     0xc23f7c: ldur            w3, [x0, #0x27]
    // 0xc23f80: DecompressPointer r3
    //     0xc23f80: add             x3, x3, HEAP, lsl #32
    // 0xc23f84: r0 = AllocateRecord2()
    //     0xc23f84: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xc23f88: b               #0xc23fb4
    // 0xc23f8c: tbz             w2, #4, #0xc23f94
    // 0xc23f90: tbnz            w0, #4, #0xc23fb0
    // 0xc23f94: ldur            x0, [fp, #-0x28]
    // 0xc23f98: LoadField: r2 = r0->field_2b
    //     0xc23f98: ldur            w2, [x0, #0x2b]
    // 0xc23f9c: DecompressPointer r2
    //     0xc23f9c: add             x2, x2, HEAP, lsl #32
    // 0xc23fa0: LoadField: r3 = r0->field_23
    //     0xc23fa0: ldur            w3, [x0, #0x23]
    // 0xc23fa4: DecompressPointer r3
    //     0xc23fa4: add             x3, x3, HEAP, lsl #32
    // 0xc23fa8: r0 = AllocateRecord2()
    //     0xc23fa8: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xc23fac: b               #0xc23fb4
    // 0xc23fb0: r0 = Null
    //     0xc23fb0: mov             x0, NULL
    // 0xc23fb4: LoadField: r1 = r0->field_f
    //     0xc23fb4: ldur            w1, [x0, #0xf]
    // 0xc23fb8: DecompressPointer r1
    //     0xc23fb8: add             x1, x1, HEAP, lsl #32
    // 0xc23fbc: stur            x1, [fp, #-0x38]
    // 0xc23fc0: LoadField: r2 = r0->field_13
    //     0xc23fc0: ldur            w2, [x0, #0x13]
    // 0xc23fc4: DecompressPointer r2
    //     0xc23fc4: add             x2, x2, HEAP, lsl #32
    // 0xc23fc8: stur            x2, [fp, #-0x30]
    // 0xc23fcc: r16 = 136
    //     0xc23fcc: mov             x16, #0x88
    // 0xc23fd0: stp             x16, NULL, [SP]
    // 0xc23fd4: r0 = ByteData()
    //     0xc23fd4: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xc23fd8: stur            x0, [fp, #-0x40]
    // 0xc23fdc: r0 = Paint()
    //     0xc23fdc: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xc23fe0: mov             x2, x0
    // 0xc23fe4: ldur            x0, [fp, #-0x40]
    // 0xc23fe8: stur            x2, [fp, #-0x48]
    // 0xc23fec: StoreField: r2->field_7 = r0
    //     0xc23fec: stur            w0, [x2, #7]
    // 0xc23ff0: r1 = <Color?>
    //     0xc23ff0: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xc23ff4: ldr             x1, [x1, #0xa40]
    // 0xc23ff8: r0 = ColorTween()
    //     0xc23ff8: bl              #0x915f2c  ; AllocateColorTweenStub -> ColorTween (size=0x14)
    // 0xc23ffc: mov             x1, x0
    // 0xc24000: ldur            x0, [fp, #-0x38]
    // 0xc24004: StoreField: r1->field_b = r0
    //     0xc24004: stur            w0, [x1, #0xb]
    // 0xc24008: ldur            x0, [fp, #-0x30]
    // 0xc2400c: StoreField: r1->field_f = r0
    //     0xc2400c: stur            w0, [x1, #0xf]
    // 0xc24010: ldur            x2, [fp, #-0x20]
    // 0xc24014: r0 = evaluate()
    //     0xc24014: bl              #0x112be60  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xc24018: cmp             w0, NULL
    // 0xc2401c: b.eq            #0xc24088
    // 0xc24020: ldur            x1, [fp, #-0x48]
    // 0xc24024: mov             x2, x0
    // 0xc24028: r0 = color=()
    //     0xc24028: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xc2402c: ldur            x1, [fp, #-8]
    // 0xc24030: ldur            x2, [fp, #-0x28]
    // 0xc24034: r0 = getPreferredSize()
    //     0xc24034: bl              #0xb1e3f0  ; [package:flutter/src/material/slider_parts.dart] RoundSliderTickMarkShape::getPreferredSize
    // 0xc24038: LoadField: d0 = r0->field_7
    //     0xc24038: ldur            d0, [x0, #7]
    // 0xc2403c: d1 = 2.000000
    //     0xc2403c: fmov            d1, #2.00000000
    // 0xc24040: fdiv            d2, d0, d1
    // 0xc24044: stur            d2, [fp, #-0x50]
    // 0xc24048: d0 = 0.000000
    //     0xc24048: eor             v0.16b, v0.16b, v0.16b
    // 0xc2404c: fcmp            d2, d0
    // 0xc24050: b.le            #0xc24070
    // 0xc24054: ldur            x1, [fp, #-0x10]
    // 0xc24058: r0 = canvas()
    //     0xc24058: bl              #0xc17694  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0xc2405c: mov             x1, x0
    // 0xc24060: ldur            x2, [fp, #-0x18]
    // 0xc24064: ldur            d0, [fp, #-0x50]
    // 0xc24068: ldur            x3, [fp, #-0x48]
    // 0xc2406c: r0 = drawCircle()
    //     0xc2406c: bl              #0xb6acd4  ; [dart:ui] _NativeCanvas::drawCircle
    // 0xc24070: r0 = Null
    //     0xc24070: mov             x0, NULL
    // 0xc24074: LeaveFrame
    //     0xc24074: mov             SP, fp
    //     0xc24078: ldp             fp, lr, [SP], #0x10
    // 0xc2407c: ret
    //     0xc2407c: ret             
    // 0xc24080: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc24080: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc24084: b               #0xc23f00
    // 0xc24088: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc24088: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4625, size: 0x8, field offset: 0x8
abstract class BaseSliderTrackShape extends Object {
}

// class id: 4626, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class SliderTrackShape extends Object {
}

// class id: 4628, size: 0x8, field offset: 0x8
//   const constructor, 
class GappedSliderTrackShape extends _MixinApplication107&SliderTrackShape&BaseSliderTrackShape {
}

// class id: 4629, size: 0x8, field offset: 0x8
//   const constructor, 
class RoundedRectSliderTrackShape extends _MixinApplication107&SliderTrackShape&BaseSliderTrackShape {

  _ paint(/* No info */) {
    // ** addr: 0xc2408c, size: 0x604
    // 0xc2408c: EnterFrame
    //     0xc2408c: stp             fp, lr, [SP, #-0x10]!
    //     0xc24090: mov             fp, SP
    // 0xc24094: AllocStack(0xa0)
    //     0xc24094: sub             SP, SP, #0xa0
    // 0xc24098: SetupParameters(RoundedRectSliderTrackShape this /* r1 => r5, fp-0x18 */, dynamic _ /* r2 => r4, fp-0x20 */, dynamic _ /* r3 => r3, fp-0x28 */, dynamic _ /* r5 => r0, fp-0x30 */, dynamic _ /* r6 => r6, fp-0x38 */, dynamic _ /* r7 => r2, fp-0x40 */)
    //     0xc24098: mov             x0, x5
    //     0xc2409c: stur            x5, [fp, #-0x30]
    //     0xc240a0: mov             x5, x1
    //     0xc240a4: mov             x4, x2
    //     0xc240a8: stur            x2, [fp, #-0x20]
    //     0xc240ac: mov             x2, x7
    //     0xc240b0: stur            x1, [fp, #-0x18]
    //     0xc240b4: stur            x3, [fp, #-0x28]
    //     0xc240b8: stur            x6, [fp, #-0x38]
    //     0xc240bc: stur            x7, [fp, #-0x40]
    // 0xc240c0: CheckStackOverflow
    //     0xc240c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc240c4: cmp             SP, x16
    //     0xc240c8: b.ls            #0xc2467c
    // 0xc240cc: ldr             x7, [fp, #0x20]
    // 0xc240d0: LoadField: r1 = r7->field_7
    //     0xc240d0: ldur            w1, [x7, #7]
    // 0xc240d4: DecompressPointer r1
    //     0xc240d4: add             x1, x1, HEAP, lsl #32
    // 0xc240d8: cmp             w1, NULL
    // 0xc240dc: b.eq            #0xc240f4
    // 0xc240e0: d0 = 0.000000
    //     0xc240e0: eor             v0.16b, v0.16b, v0.16b
    // 0xc240e4: LoadField: d1 = r1->field_7
    //     0xc240e4: ldur            d1, [x1, #7]
    // 0xc240e8: stur            d1, [fp, #-0x58]
    // 0xc240ec: fcmp            d0, d1
    // 0xc240f0: b.lt            #0xc24104
    // 0xc240f4: r0 = Null
    //     0xc240f4: mov             x0, NULL
    // 0xc240f8: LeaveFrame
    //     0xc240f8: mov             SP, fp
    //     0xc240fc: ldp             fp, lr, [SP], #0x10
    // 0xc24100: ret
    //     0xc24100: ret             
    // 0xc24104: ldr             x8, [fp, #0x18]
    // 0xc24108: ArrayLoad: r9 = r7[0]  ; List_4
    //     0xc24108: ldur            w9, [x7, #0x17]
    // 0xc2410c: DecompressPointer r9
    //     0xc2410c: add             x9, x9, HEAP, lsl #32
    // 0xc24110: stur            x9, [fp, #-0x10]
    // 0xc24114: LoadField: r10 = r7->field_b
    //     0xc24114: ldur            w10, [x7, #0xb]
    // 0xc24118: DecompressPointer r10
    //     0xc24118: add             x10, x10, HEAP, lsl #32
    // 0xc2411c: stur            x10, [fp, #-8]
    // 0xc24120: r1 = <Color?>
    //     0xc24120: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xc24124: ldr             x1, [x1, #0xa40]
    // 0xc24128: r0 = ColorTween()
    //     0xc24128: bl              #0x915f2c  ; AllocateColorTweenStub -> ColorTween (size=0x14)
    // 0xc2412c: mov             x2, x0
    // 0xc24130: ldur            x0, [fp, #-0x10]
    // 0xc24134: stur            x2, [fp, #-0x48]
    // 0xc24138: StoreField: r2->field_b = r0
    //     0xc24138: stur            w0, [x2, #0xb]
    // 0xc2413c: ldur            x0, [fp, #-8]
    // 0xc24140: StoreField: r2->field_f = r0
    //     0xc24140: stur            w0, [x2, #0xf]
    // 0xc24144: ldr             x3, [fp, #0x20]
    // 0xc24148: LoadField: r0 = r3->field_1f
    //     0xc24148: ldur            w0, [x3, #0x1f]
    // 0xc2414c: DecompressPointer r0
    //     0xc2414c: add             x0, x0, HEAP, lsl #32
    // 0xc24150: stur            x0, [fp, #-0x10]
    // 0xc24154: LoadField: r4 = r3->field_f
    //     0xc24154: ldur            w4, [x3, #0xf]
    // 0xc24158: DecompressPointer r4
    //     0xc24158: add             x4, x4, HEAP, lsl #32
    // 0xc2415c: stur            x4, [fp, #-8]
    // 0xc24160: r1 = <Color?>
    //     0xc24160: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xc24164: ldr             x1, [x1, #0xa40]
    // 0xc24168: r0 = ColorTween()
    //     0xc24168: bl              #0x915f2c  ; AllocateColorTweenStub -> ColorTween (size=0x14)
    // 0xc2416c: mov             x1, x0
    // 0xc24170: ldur            x0, [fp, #-0x10]
    // 0xc24174: stur            x1, [fp, #-0x50]
    // 0xc24178: StoreField: r1->field_b = r0
    //     0xc24178: stur            w0, [x1, #0xb]
    // 0xc2417c: ldur            x0, [fp, #-8]
    // 0xc24180: StoreField: r1->field_f = r0
    //     0xc24180: stur            w0, [x1, #0xf]
    // 0xc24184: r16 = 136
    //     0xc24184: mov             x16, #0x88
    // 0xc24188: stp             x16, NULL, [SP]
    // 0xc2418c: r0 = ByteData()
    //     0xc2418c: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xc24190: stur            x0, [fp, #-8]
    // 0xc24194: r0 = Paint()
    //     0xc24194: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xc24198: mov             x3, x0
    // 0xc2419c: ldur            x0, [fp, #-8]
    // 0xc241a0: stur            x3, [fp, #-0x10]
    // 0xc241a4: StoreField: r3->field_7 = r0
    //     0xc241a4: stur            w0, [x3, #7]
    // 0xc241a8: ldur            x1, [fp, #-0x48]
    // 0xc241ac: ldur            x2, [fp, #-0x30]
    // 0xc241b0: r0 = evaluate()
    //     0xc241b0: bl              #0x112be60  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xc241b4: cmp             w0, NULL
    // 0xc241b8: b.eq            #0xc24684
    // 0xc241bc: ldur            x1, [fp, #-0x10]
    // 0xc241c0: mov             x2, x0
    // 0xc241c4: r0 = color=()
    //     0xc241c4: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xc241c8: r16 = 136
    //     0xc241c8: mov             x16, #0x88
    // 0xc241cc: stp             x16, NULL, [SP]
    // 0xc241d0: r0 = ByteData()
    //     0xc241d0: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xc241d4: stur            x0, [fp, #-8]
    // 0xc241d8: r0 = Paint()
    //     0xc241d8: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xc241dc: mov             x3, x0
    // 0xc241e0: ldur            x0, [fp, #-8]
    // 0xc241e4: stur            x3, [fp, #-0x48]
    // 0xc241e8: StoreField: r3->field_7 = r0
    //     0xc241e8: stur            w0, [x3, #7]
    // 0xc241ec: ldur            x1, [fp, #-0x50]
    // 0xc241f0: ldur            x2, [fp, #-0x30]
    // 0xc241f4: r0 = evaluate()
    //     0xc241f4: bl              #0x112be60  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xc241f8: cmp             w0, NULL
    // 0xc241fc: b.eq            #0xc24688
    // 0xc24200: ldur            x1, [fp, #-0x48]
    // 0xc24204: mov             x2, x0
    // 0xc24208: r0 = color=()
    //     0xc24208: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xc2420c: ldr             x0, [fp, #0x18]
    // 0xc24210: LoadField: r1 = r0->field_7
    //     0xc24210: ldur            x1, [x0, #7]
    // 0xc24214: cmp             x1, #0
    // 0xc24218: b.gt            #0xc24230
    // 0xc2421c: ldur            x2, [fp, #-0x48]
    // 0xc24220: ldur            x3, [fp, #-0x10]
    // 0xc24224: r0 = AllocateRecord2()
    //     0xc24224: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xc24228: mov             x1, x0
    // 0xc2422c: b               #0xc24240
    // 0xc24230: ldur            x2, [fp, #-0x10]
    // 0xc24234: ldur            x3, [fp, #-0x48]
    // 0xc24238: r0 = AllocateRecord2()
    //     0xc24238: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xc2423c: mov             x1, x0
    // 0xc24240: ldr             x0, [fp, #0x18]
    // 0xc24244: ldr             x4, [fp, #0x10]
    // 0xc24248: ldur            d0, [fp, #-0x58]
    // 0xc2424c: LoadField: r5 = r1->field_f
    //     0xc2424c: ldur            w5, [x1, #0xf]
    // 0xc24250: DecompressPointer r5
    //     0xc24250: add             x5, x5, HEAP, lsl #32
    // 0xc24254: stur            x5, [fp, #-0x10]
    // 0xc24258: LoadField: r6 = r1->field_13
    //     0xc24258: ldur            w6, [x1, #0x13]
    // 0xc2425c: DecompressPointer r6
    //     0xc2425c: add             x6, x6, HEAP, lsl #32
    // 0xc24260: stur            x6, [fp, #-8]
    // 0xc24264: ldur            x16, [fp, #-0x28]
    // 0xc24268: ldur            lr, [fp, #-0x38]
    // 0xc2426c: stp             lr, x16, [SP]
    // 0xc24270: ldur            x1, [fp, #-0x18]
    // 0xc24274: ldur            x2, [fp, #-0x40]
    // 0xc24278: ldr             x3, [fp, #0x20]
    // 0xc2427c: r4 = const [0, 0x5, 0x2, 0x3, isEnabled, 0x4, offset, 0x3, null]
    //     0xc2427c: add             x4, PP, #0xad, lsl #12  ; [pp+0xad788] List(9) [0, 0x5, 0x2, 0x3, "isEnabled", 0x4, "offset", 0x3, Null]
    //     0xc24280: ldr             x4, [x4, #0x788]
    // 0xc24284: r0 = getPreferredRect()
    //     0xc24284: bl              #0xc12580  ; [dart:mixin_deduplication] _MixinApplication107&SliderTrackShape&BaseSliderTrackShape::getPreferredRect
    // 0xc24288: stur            x0, [fp, #-0x18]
    // 0xc2428c: LoadField: d0 = r0->field_1f
    //     0xc2428c: ldur            d0, [x0, #0x1f]
    // 0xc24290: stur            d0, [fp, #-0x78]
    // 0xc24294: LoadField: d1 = r0->field_f
    //     0xc24294: ldur            d1, [x0, #0xf]
    // 0xc24298: stur            d1, [fp, #-0x70]
    // 0xc2429c: fsub            d2, d0, d1
    // 0xc242a0: stur            d2, [fp, #-0x68]
    // 0xc242a4: d3 = 2.000000
    //     0xc242a4: fmov            d3, #2.00000000
    // 0xc242a8: fdiv            d4, d2, d3
    // 0xc242ac: stur            d4, [fp, #-0x60]
    // 0xc242b0: r0 = Radius()
    //     0xc242b0: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0xc242b4: ldur            d0, [fp, #-0x60]
    // 0xc242b8: stur            x0, [fp, #-0x28]
    // 0xc242bc: StoreField: r0->field_7 = d0
    //     0xc242bc: stur            d0, [x0, #7]
    // 0xc242c0: StoreField: r0->field_f = d0
    //     0xc242c0: stur            d0, [x0, #0xf]
    // 0xc242c4: ldur            d0, [fp, #-0x68]
    // 0xc242c8: d1 = 2.000000
    //     0xc242c8: fmov            d1, #2.00000000
    // 0xc242cc: fadd            d2, d0, d1
    // 0xc242d0: fdiv            d0, d2, d1
    // 0xc242d4: stur            d0, [fp, #-0x60]
    // 0xc242d8: r0 = Radius()
    //     0xc242d8: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0xc242dc: ldur            d0, [fp, #-0x60]
    // 0xc242e0: stur            x0, [fp, #-0x48]
    // 0xc242e4: StoreField: r0->field_7 = d0
    //     0xc242e4: stur            d0, [x0, #7]
    // 0xc242e8: StoreField: r0->field_f = d0
    //     0xc242e8: stur            d0, [x0, #0xf]
    // 0xc242ec: ldr             x1, [fp, #0x18]
    // 0xc242f0: r16 = Instance_TextDirection
    //     0xc242f0: ldr             x16, [PP, #0x25b0]  ; [pp+0x25b0] Obj!TextDirection@12c73a1
    // 0xc242f4: cmp             w1, w16
    // 0xc242f8: r16 = true
    //     0xc242f8: add             x16, NULL, #0x20  ; true
    // 0xc242fc: r17 = false
    //     0xc242fc: add             x17, NULL, #0x30  ; false
    // 0xc24300: csel            x2, x16, x17, eq
    // 0xc24304: stur            x2, [fp, #-0x40]
    // 0xc24308: r16 = Instance_TextDirection
    //     0xc24308: ldr             x16, [PP, #0x2578]  ; [pp+0x2578] Obj!TextDirection@12c7381
    // 0xc2430c: cmp             w1, w16
    // 0xc24310: r16 = true
    //     0xc24310: add             x16, NULL, #0x20  ; true
    // 0xc24314: r17 = false
    //     0xc24314: add             x17, NULL, #0x30  ; false
    // 0xc24318: csel            x3, x16, x17, eq
    // 0xc2431c: ldr             x1, [fp, #0x10]
    // 0xc24320: stur            x3, [fp, #-0x38]
    // 0xc24324: LoadField: d0 = r1->field_7
    //     0xc24324: ldur            d0, [x1, #7]
    // 0xc24328: ldur            x4, [fp, #-0x18]
    // 0xc2432c: stur            d0, [fp, #-0x80]
    // 0xc24330: ArrayLoad: d2 = r4[0]  ; List_8
    //     0xc24330: ldur            d2, [x4, #0x17]
    // 0xc24334: ldur            d3, [fp, #-0x58]
    // 0xc24338: stur            d2, [fp, #-0x68]
    // 0xc2433c: d1 = 2.000000
    //     0xc2433c: fmov            d1, #2.00000000
    // 0xc24340: fdiv            d4, d3, d1
    // 0xc24344: stur            d4, [fp, #-0x60]
    // 0xc24348: fsub            d1, d2, d4
    // 0xc2434c: fcmp            d1, d0
    // 0xc24350: b.le            #0xc24408
    // 0xc24354: ldur            x1, [fp, #-0x20]
    // 0xc24358: r0 = canvas()
    //     0xc24358: bl              #0xc17694  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0xc2435c: ldur            d1, [fp, #-0x60]
    // 0xc24360: ldur            d0, [fp, #-0x80]
    // 0xc24364: stur            x0, [fp, #-0x50]
    // 0xc24368: fsub            d2, d0, d1
    // 0xc2436c: ldur            x1, [fp, #-0x38]
    // 0xc24370: stur            d2, [fp, #-0x90]
    // 0xc24374: tbnz            w1, #4, #0xc24388
    // 0xc24378: ldur            d3, [fp, #-0x70]
    // 0xc2437c: d4 = 1.000000
    //     0xc2437c: fmov            d4, #1.00000000
    // 0xc24380: fsub            d5, d3, d4
    // 0xc24384: b               #0xc24394
    // 0xc24388: ldur            d3, [fp, #-0x70]
    // 0xc2438c: d4 = 1.000000
    //     0xc2438c: fmov            d4, #1.00000000
    // 0xc24390: mov             v5.16b, v3.16b
    // 0xc24394: stur            d5, [fp, #-0x88]
    // 0xc24398: tbnz            w1, #4, #0xc243a8
    // 0xc2439c: ldur            d6, [fp, #-0x78]
    // 0xc243a0: fadd            d7, d6, d4
    // 0xc243a4: b               #0xc243b0
    // 0xc243a8: ldur            d6, [fp, #-0x78]
    // 0xc243ac: mov             v7.16b, v6.16b
    // 0xc243b0: ldur            x2, [fp, #-0x40]
    // 0xc243b4: stur            d7, [fp, #-0x58]
    // 0xc243b8: tbnz            w2, #4, #0xc243c4
    // 0xc243bc: ldur            x3, [fp, #-0x28]
    // 0xc243c0: b               #0xc243c8
    // 0xc243c4: ldur            x3, [fp, #-0x48]
    // 0xc243c8: stur            x3, [fp, #-0x38]
    // 0xc243cc: r1 = <RRect>
    //     0xc243cc: add             x1, PP, #0x85, lsl #12  ; [pp+0x85108] TypeArguments: <RRect>
    //     0xc243d0: ldr             x1, [x1, #0x108]
    // 0xc243d4: r0 = RRect()
    //     0xc243d4: bl              #0xb6e214  ; AllocateRRectStub -> RRect (size=0x6c)
    // 0xc243d8: mov             x1, x0
    // 0xc243dc: ldur            d0, [fp, #-0x90]
    // 0xc243e0: ldur            d1, [fp, #-0x88]
    // 0xc243e4: ldur            d2, [fp, #-0x68]
    // 0xc243e8: ldur            d3, [fp, #-0x58]
    // 0xc243ec: ldur            x2, [fp, #-0x38]
    // 0xc243f0: stur            x0, [fp, #-0x38]
    // 0xc243f4: r0 = RRect.fromLTRBR()
    //     0xc243f4: bl              #0xb6e1d4  ; [dart:ui] RRect::RRect.fromLTRBR
    // 0xc243f8: ldur            x1, [fp, #-0x50]
    // 0xc243fc: ldur            x2, [fp, #-0x38]
    // 0xc24400: ldur            x3, [fp, #-8]
    // 0xc24404: r0 = drawRRect()
    //     0xc24404: bl              #0xb6dce0  ; [dart:ui] _NativeCanvas::drawRRect
    // 0xc24408: ldur            x0, [fp, #-0x18]
    // 0xc2440c: ldur            d1, [fp, #-0x60]
    // 0xc24410: ldur            d0, [fp, #-0x80]
    // 0xc24414: LoadField: d2 = r0->field_7
    //     0xc24414: ldur            d2, [x0, #7]
    // 0xc24418: stur            d2, [fp, #-0x58]
    // 0xc2441c: fadd            d3, d2, d1
    // 0xc24420: fcmp            d0, d3
    // 0xc24424: b.le            #0xc244e8
    // 0xc24428: ldur            x0, [fp, #-0x40]
    // 0xc2442c: ldur            x1, [fp, #-0x20]
    // 0xc24430: r0 = canvas()
    //     0xc24430: bl              #0xc17694  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0xc24434: mov             x2, x0
    // 0xc24438: ldur            x0, [fp, #-0x40]
    // 0xc2443c: stur            x2, [fp, #-0x18]
    // 0xc24440: tbnz            w0, #4, #0xc24458
    // 0xc24444: ldur            d0, [fp, #-0x70]
    // 0xc24448: d1 = 1.000000
    //     0xc24448: fmov            d1, #1.00000000
    // 0xc2444c: fsub            d2, d0, d1
    // 0xc24450: mov             v4.16b, v2.16b
    // 0xc24454: b               #0xc24464
    // 0xc24458: ldur            d0, [fp, #-0x70]
    // 0xc2445c: d1 = 1.000000
    //     0xc2445c: fmov            d1, #1.00000000
    // 0xc24460: mov             v4.16b, v0.16b
    // 0xc24464: ldur            d3, [fp, #-0x60]
    // 0xc24468: ldur            d2, [fp, #-0x80]
    // 0xc2446c: stur            d4, [fp, #-0x88]
    // 0xc24470: fadd            d5, d2, d3
    // 0xc24474: stur            d5, [fp, #-0x68]
    // 0xc24478: tbnz            w0, #4, #0xc2448c
    // 0xc2447c: ldur            d3, [fp, #-0x78]
    // 0xc24480: fadd            d6, d3, d1
    // 0xc24484: mov             v1.16b, v6.16b
    // 0xc24488: b               #0xc24494
    // 0xc2448c: ldur            d3, [fp, #-0x78]
    // 0xc24490: mov             v1.16b, v3.16b
    // 0xc24494: stur            d1, [fp, #-0x60]
    // 0xc24498: tbnz            w0, #4, #0xc244a4
    // 0xc2449c: ldur            x3, [fp, #-0x48]
    // 0xc244a0: b               #0xc244a8
    // 0xc244a4: ldur            x3, [fp, #-0x28]
    // 0xc244a8: stur            x3, [fp, #-8]
    // 0xc244ac: r1 = <RRect>
    //     0xc244ac: add             x1, PP, #0x85, lsl #12  ; [pp+0x85108] TypeArguments: <RRect>
    //     0xc244b0: ldr             x1, [x1, #0x108]
    // 0xc244b4: r0 = RRect()
    //     0xc244b4: bl              #0xb6e214  ; AllocateRRectStub -> RRect (size=0x6c)
    // 0xc244b8: mov             x1, x0
    // 0xc244bc: ldur            d0, [fp, #-0x58]
    // 0xc244c0: ldur            d1, [fp, #-0x88]
    // 0xc244c4: ldur            d2, [fp, #-0x68]
    // 0xc244c8: ldur            d3, [fp, #-0x60]
    // 0xc244cc: ldur            x2, [fp, #-8]
    // 0xc244d0: stur            x0, [fp, #-8]
    // 0xc244d4: r0 = RRect.fromLTRBR()
    //     0xc244d4: bl              #0xb6e1d4  ; [dart:ui] RRect::RRect.fromLTRBR
    // 0xc244d8: ldur            x1, [fp, #-0x18]
    // 0xc244dc: ldur            x2, [fp, #-8]
    // 0xc244e0: ldur            x3, [fp, #-0x10]
    // 0xc244e4: r0 = drawRRect()
    //     0xc244e4: bl              #0xb6dce0  ; [dart:ui] _NativeCanvas::drawRRect
    // 0xc244e8: ldr             x0, [fp, #0x28]
    // 0xc244ec: cmp             w0, NULL
    // 0xc244f0: b.eq            #0xc2466c
    // 0xc244f4: ldur            x2, [fp, #-0x40]
    // 0xc244f8: tbnz            w2, #4, #0xc24514
    // 0xc244fc: ldur            d0, [fp, #-0x80]
    // 0xc24500: LoadField: d1 = r0->field_7
    //     0xc24500: ldur            d1, [x0, #7]
    // 0xc24504: fcmp            d1, d0
    // 0xc24508: b.le            #0xc2466c
    // 0xc2450c: mov             v2.16b, v1.16b
    // 0xc24510: b               #0xc24528
    // 0xc24514: ldur            d0, [fp, #-0x80]
    // 0xc24518: LoadField: d1 = r0->field_7
    //     0xc24518: ldur            d1, [x0, #7]
    // 0xc2451c: fcmp            d0, d1
    // 0xc24520: b.le            #0xc2466c
    // 0xc24524: mov             v2.16b, v1.16b
    // 0xc24528: ldr             x0, [fp, #0x20]
    // 0xc2452c: stur            d2, [fp, #-0x58]
    // 0xc24530: LoadField: r3 = r0->field_1b
    //     0xc24530: ldur            w3, [x0, #0x1b]
    // 0xc24534: DecompressPointer r3
    //     0xc24534: add             x3, x3, HEAP, lsl #32
    // 0xc24538: stur            x3, [fp, #-0x10]
    // 0xc2453c: LoadField: r4 = r0->field_13
    //     0xc2453c: ldur            w4, [x0, #0x13]
    // 0xc24540: DecompressPointer r4
    //     0xc24540: add             x4, x4, HEAP, lsl #32
    // 0xc24544: stur            x4, [fp, #-8]
    // 0xc24548: r1 = <Color?>
    //     0xc24548: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xc2454c: ldr             x1, [x1, #0xa40]
    // 0xc24550: r0 = ColorTween()
    //     0xc24550: bl              #0x915f2c  ; AllocateColorTweenStub -> ColorTween (size=0x14)
    // 0xc24554: mov             x1, x0
    // 0xc24558: ldur            x0, [fp, #-0x10]
    // 0xc2455c: stur            x1, [fp, #-0x18]
    // 0xc24560: StoreField: r1->field_b = r0
    //     0xc24560: stur            w0, [x1, #0xb]
    // 0xc24564: ldur            x0, [fp, #-8]
    // 0xc24568: StoreField: r1->field_f = r0
    //     0xc24568: stur            w0, [x1, #0xf]
    // 0xc2456c: r16 = 136
    //     0xc2456c: mov             x16, #0x88
    // 0xc24570: stp             x16, NULL, [SP]
    // 0xc24574: r0 = ByteData()
    //     0xc24574: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xc24578: stur            x0, [fp, #-8]
    // 0xc2457c: r0 = Paint()
    //     0xc2457c: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xc24580: mov             x3, x0
    // 0xc24584: ldur            x0, [fp, #-8]
    // 0xc24588: stur            x3, [fp, #-0x10]
    // 0xc2458c: StoreField: r3->field_7 = r0
    //     0xc2458c: stur            w0, [x3, #7]
    // 0xc24590: ldur            x1, [fp, #-0x18]
    // 0xc24594: ldur            x2, [fp, #-0x30]
    // 0xc24598: r0 = evaluate()
    //     0xc24598: bl              #0x112be60  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xc2459c: cmp             w0, NULL
    // 0xc245a0: b.eq            #0xc2468c
    // 0xc245a4: ldur            x1, [fp, #-0x10]
    // 0xc245a8: mov             x2, x0
    // 0xc245ac: r0 = color=()
    //     0xc245ac: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xc245b0: ldur            x0, [fp, #-0x40]
    // 0xc245b4: tbnz            w0, #4, #0xc24614
    // 0xc245b8: ldur            x1, [fp, #-0x20]
    // 0xc245bc: r0 = canvas()
    //     0xc245bc: bl              #0xc17694  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0xc245c0: r1 = <RRect>
    //     0xc245c0: add             x1, PP, #0x85, lsl #12  ; [pp+0x85108] TypeArguments: <RRect>
    //     0xc245c4: ldr             x1, [x1, #0x108]
    // 0xc245c8: stur            x0, [fp, #-8]
    // 0xc245cc: r0 = RRect()
    //     0xc245cc: bl              #0xb6e214  ; AllocateRRectStub -> RRect (size=0x6c)
    // 0xc245d0: stur            x0, [fp, #-0x18]
    // 0xc245d4: ldur            x16, [fp, #-0x28]
    // 0xc245d8: ldur            lr, [fp, #-0x28]
    // 0xc245dc: stp             lr, x16, [SP]
    // 0xc245e0: mov             x1, x0
    // 0xc245e4: ldur            d0, [fp, #-0x80]
    // 0xc245e8: ldur            d1, [fp, #-0x70]
    // 0xc245ec: ldur            d2, [fp, #-0x58]
    // 0xc245f0: ldur            d3, [fp, #-0x78]
    // 0xc245f4: r4 = const [0, 0x7, 0x2, 0x5, bottomRight, 0x6, topRight, 0x5, null]
    //     0xc245f4: add             x4, PP, #0xad, lsl #12  ; [pp+0xad790] List(9) [0, 0x7, 0x2, 0x5, "bottomRight", 0x6, "topRight", 0x5, Null]
    //     0xc245f8: ldr             x4, [x4, #0x790]
    // 0xc245fc: r0 = RRect.fromLTRBAndCorners()
    //     0xc245fc: bl              #0xc24690  ; [dart:ui] RRect::RRect.fromLTRBAndCorners
    // 0xc24600: ldur            x1, [fp, #-8]
    // 0xc24604: ldur            x2, [fp, #-0x18]
    // 0xc24608: ldur            x3, [fp, #-0x10]
    // 0xc2460c: r0 = drawRRect()
    //     0xc2460c: bl              #0xb6dce0  ; [dart:ui] _NativeCanvas::drawRRect
    // 0xc24610: b               #0xc2466c
    // 0xc24614: ldur            x1, [fp, #-0x20]
    // 0xc24618: r0 = canvas()
    //     0xc24618: bl              #0xc17694  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0xc2461c: r1 = <RRect>
    //     0xc2461c: add             x1, PP, #0x85, lsl #12  ; [pp+0x85108] TypeArguments: <RRect>
    //     0xc24620: ldr             x1, [x1, #0x108]
    // 0xc24624: stur            x0, [fp, #-8]
    // 0xc24628: r0 = RRect()
    //     0xc24628: bl              #0xb6e214  ; AllocateRRectStub -> RRect (size=0x6c)
    // 0xc2462c: stur            x0, [fp, #-0x18]
    // 0xc24630: ldur            x16, [fp, #-0x28]
    // 0xc24634: ldur            lr, [fp, #-0x28]
    // 0xc24638: stp             lr, x16, [SP]
    // 0xc2463c: mov             x1, x0
    // 0xc24640: ldur            d0, [fp, #-0x58]
    // 0xc24644: ldur            d1, [fp, #-0x70]
    // 0xc24648: ldur            d2, [fp, #-0x80]
    // 0xc2464c: ldur            d3, [fp, #-0x78]
    // 0xc24650: r4 = const [0, 0x7, 0x2, 0x5, bottomLeft, 0x6, topLeft, 0x5, null]
    //     0xc24650: add             x4, PP, #0xad, lsl #12  ; [pp+0xad798] List(9) [0, 0x7, 0x2, 0x5, "bottomLeft", 0x6, "topLeft", 0x5, Null]
    //     0xc24654: ldr             x4, [x4, #0x798]
    // 0xc24658: r0 = RRect.fromLTRBAndCorners()
    //     0xc24658: bl              #0xc24690  ; [dart:ui] RRect::RRect.fromLTRBAndCorners
    // 0xc2465c: ldur            x1, [fp, #-8]
    // 0xc24660: ldur            x2, [fp, #-0x18]
    // 0xc24664: ldur            x3, [fp, #-0x10]
    // 0xc24668: r0 = drawRRect()
    //     0xc24668: bl              #0xb6dce0  ; [dart:ui] _NativeCanvas::drawRRect
    // 0xc2466c: r0 = Null
    //     0xc2466c: mov             x0, NULL
    // 0xc24670: LeaveFrame
    //     0xc24670: mov             SP, fp
    //     0xc24674: ldp             fp, lr, [SP], #0x10
    // 0xc24678: ret
    //     0xc24678: ret             
    // 0xc2467c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc2467c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc24680: b               #0xc240cc
    // 0xc24684: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc24684: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc24688: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc24688: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc2468c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc2468c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}
