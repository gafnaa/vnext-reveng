// lib: , url: package:flutter/src/material/icon_button_theme.dart

// class id: 1048899, size: 0x8
class :: {
}

// class id: 5147, size: 0xc, field offset: 0x8
//   const constructor, 
class IconButtonThemeData extends _MixinApplication3&Object&Diagnosticable {

  static _ lerp(/* No info */) {
    // ** addr: 0x1166dec, size: 0x6c
    // 0x1166dec: EnterFrame
    //     0x1166dec: stp             fp, lr, [SP, #-0x10]!
    //     0x1166df0: mov             fp, SP
    // 0x1166df4: AllocStack(0x8)
    //     0x1166df4: sub             SP, SP, #8
    // 0x1166df8: SetupParameters(dynamic _ /* r1 => r0 */)
    //     0x1166df8: mov             x0, x1
    // 0x1166dfc: CheckStackOverflow
    //     0x1166dfc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1166e00: cmp             SP, x16
    //     0x1166e04: b.ls            #0x1166e50
    // 0x1166e08: cmp             w0, w2
    // 0x1166e0c: b.ne            #0x1166e1c
    // 0x1166e10: LeaveFrame
    //     0x1166e10: mov             SP, fp
    //     0x1166e14: ldp             fp, lr, [SP], #0x10
    // 0x1166e18: ret
    //     0x1166e18: ret             
    // 0x1166e1c: LoadField: r1 = r0->field_7
    //     0x1166e1c: ldur            w1, [x0, #7]
    // 0x1166e20: DecompressPointer r1
    //     0x1166e20: add             x1, x1, HEAP, lsl #32
    // 0x1166e24: LoadField: r0 = r2->field_7
    //     0x1166e24: ldur            w0, [x2, #7]
    // 0x1166e28: DecompressPointer r0
    //     0x1166e28: add             x0, x0, HEAP, lsl #32
    // 0x1166e2c: mov             x2, x0
    // 0x1166e30: r0 = lerp()
    //     0x1166e30: bl              #0x1164644  ; [package:flutter/src/material/button_style.dart] ButtonStyle::lerp
    // 0x1166e34: stur            x0, [fp, #-8]
    // 0x1166e38: r0 = IconButtonThemeData()
    //     0x1166e38: bl              #0xd29654  ; AllocateIconButtonThemeDataStub -> IconButtonThemeData (size=0xc)
    // 0x1166e3c: ldur            x1, [fp, #-8]
    // 0x1166e40: StoreField: r0->field_7 = r1
    //     0x1166e40: stur            w1, [x0, #7]
    // 0x1166e44: LeaveFrame
    //     0x1166e44: mov             SP, fp
    //     0x1166e48: ldp             fp, lr, [SP], #0x10
    // 0x1166e4c: ret
    //     0x1166e4c: ret             
    // 0x1166e50: r0 = StackOverflowSharedWithFPURegs()
    //     0x1166e50: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1166e54: b               #0x1166e08
  }
  _ ==(/* No info */) {
    // ** addr: 0x126d7dc, size: 0xfc
    // 0x126d7dc: EnterFrame
    //     0x126d7dc: stp             fp, lr, [SP, #-0x10]!
    //     0x126d7e0: mov             fp, SP
    // 0x126d7e4: AllocStack(0x10)
    //     0x126d7e4: sub             SP, SP, #0x10
    // 0x126d7e8: CheckStackOverflow
    //     0x126d7e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x126d7ec: cmp             SP, x16
    //     0x126d7f0: b.ls            #0x126d8d0
    // 0x126d7f4: ldr             x0, [fp, #0x10]
    // 0x126d7f8: cmp             w0, NULL
    // 0x126d7fc: b.ne            #0x126d810
    // 0x126d800: r0 = false
    //     0x126d800: add             x0, NULL, #0x30  ; false
    // 0x126d804: LeaveFrame
    //     0x126d804: mov             SP, fp
    //     0x126d808: ldp             fp, lr, [SP], #0x10
    // 0x126d80c: ret
    //     0x126d80c: ret             
    // 0x126d810: ldr             x1, [fp, #0x18]
    // 0x126d814: cmp             w1, w0
    // 0x126d818: b.ne            #0x126d82c
    // 0x126d81c: r0 = true
    //     0x126d81c: add             x0, NULL, #0x20  ; true
    // 0x126d820: LeaveFrame
    //     0x126d820: mov             SP, fp
    //     0x126d824: ldp             fp, lr, [SP], #0x10
    // 0x126d828: ret
    //     0x126d828: ret             
    // 0x126d82c: str             x0, [SP]
    // 0x126d830: r0 = runtimeType()
    //     0x126d830: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x126d834: r1 = LoadClassIdInstr(r0)
    //     0x126d834: ldur            x1, [x0, #-1]
    //     0x126d838: ubfx            x1, x1, #0xc, #0x14
    // 0x126d83c: r16 = IconButtonThemeData
    //     0x126d83c: add             x16, PP, #0x26, lsl #12  ; [pp+0x26350] Type: IconButtonThemeData
    //     0x126d840: ldr             x16, [x16, #0x350]
    // 0x126d844: stp             x16, x0, [SP]
    // 0x126d848: mov             x0, x1
    // 0x126d84c: mov             lr, x0
    // 0x126d850: ldr             lr, [x21, lr, lsl #3]
    // 0x126d854: blr             lr
    // 0x126d858: tbz             w0, #4, #0x126d86c
    // 0x126d85c: r0 = false
    //     0x126d85c: add             x0, NULL, #0x30  ; false
    // 0x126d860: LeaveFrame
    //     0x126d860: mov             SP, fp
    //     0x126d864: ldp             fp, lr, [SP], #0x10
    // 0x126d868: ret
    //     0x126d868: ret             
    // 0x126d86c: ldr             x0, [fp, #0x10]
    // 0x126d870: r1 = 60
    //     0x126d870: mov             x1, #0x3c
    // 0x126d874: branchIfSmi(r0, 0x126d880)
    //     0x126d874: tbz             w0, #0, #0x126d880
    // 0x126d878: r1 = LoadClassIdInstr(r0)
    //     0x126d878: ldur            x1, [x0, #-1]
    //     0x126d87c: ubfx            x1, x1, #0xc, #0x14
    // 0x126d880: r17 = 5147
    //     0x126d880: mov             x17, #0x141b
    // 0x126d884: cmp             x1, x17
    // 0x126d888: b.ne            #0x126d8c0
    // 0x126d88c: ldr             x1, [fp, #0x18]
    // 0x126d890: LoadField: r2 = r0->field_7
    //     0x126d890: ldur            w2, [x0, #7]
    // 0x126d894: DecompressPointer r2
    //     0x126d894: add             x2, x2, HEAP, lsl #32
    // 0x126d898: LoadField: r0 = r1->field_7
    //     0x126d898: ldur            w0, [x1, #7]
    // 0x126d89c: DecompressPointer r0
    //     0x126d89c: add             x0, x0, HEAP, lsl #32
    // 0x126d8a0: r1 = LoadClassIdInstr(r2)
    //     0x126d8a0: ldur            x1, [x2, #-1]
    //     0x126d8a4: ubfx            x1, x1, #0xc, #0x14
    // 0x126d8a8: stp             x0, x2, [SP]
    // 0x126d8ac: mov             x0, x1
    // 0x126d8b0: mov             lr, x0
    // 0x126d8b4: ldr             lr, [x21, lr, lsl #3]
    // 0x126d8b8: blr             lr
    // 0x126d8bc: b               #0x126d8c4
    // 0x126d8c0: r0 = false
    //     0x126d8c0: add             x0, NULL, #0x30  ; false
    // 0x126d8c4: LeaveFrame
    //     0x126d8c4: mov             SP, fp
    //     0x126d8c8: ldp             fp, lr, [SP], #0x10
    // 0x126d8cc: ret
    //     0x126d8cc: ret             
    // 0x126d8d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x126d8d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x126d8d4: b               #0x126d7f4
  }
}

// class id: 6844, size: 0x14, field offset: 0x10
//   const constructor, 
class IconButtonTheme extends InheritedTheme {

  _ updateShouldNotify(/* No info */) {
    // ** addr: 0xc0049c, size: 0xa0
    // 0xc0049c: EnterFrame
    //     0xc0049c: stp             fp, lr, [SP, #-0x10]!
    //     0xc004a0: mov             fp, SP
    // 0xc004a4: AllocStack(0x20)
    //     0xc004a4: sub             SP, SP, #0x20
    // 0xc004a8: SetupParameters(IconButtonTheme this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xc004a8: mov             x4, x1
    //     0xc004ac: mov             x3, x2
    //     0xc004b0: stur            x1, [fp, #-8]
    //     0xc004b4: stur            x2, [fp, #-0x10]
    // 0xc004b8: CheckStackOverflow
    //     0xc004b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc004bc: cmp             SP, x16
    //     0xc004c0: b.ls            #0xc00534
    // 0xc004c4: mov             x0, x3
    // 0xc004c8: r2 = Null
    //     0xc004c8: mov             x2, NULL
    // 0xc004cc: r1 = Null
    //     0xc004cc: mov             x1, NULL
    // 0xc004d0: r4 = 60
    //     0xc004d0: mov             x4, #0x3c
    // 0xc004d4: branchIfSmi(r0, 0xc004e0)
    //     0xc004d4: tbz             w0, #0, #0xc004e0
    // 0xc004d8: r4 = LoadClassIdInstr(r0)
    //     0xc004d8: ldur            x4, [x0, #-1]
    //     0xc004dc: ubfx            x4, x4, #0xc, #0x14
    // 0xc004e0: r17 = 6844
    //     0xc004e0: mov             x17, #0x1abc
    // 0xc004e4: cmp             x4, x17
    // 0xc004e8: b.eq            #0xc00500
    // 0xc004ec: r8 = IconButtonTheme
    //     0xc004ec: add             x8, PP, #0x95, lsl #12  ; [pp+0x95c58] Type: IconButtonTheme
    //     0xc004f0: ldr             x8, [x8, #0xc58]
    // 0xc004f4: r3 = Null
    //     0xc004f4: add             x3, PP, #0x95, lsl #12  ; [pp+0x95c60] Null
    //     0xc004f8: ldr             x3, [x3, #0xc60]
    // 0xc004fc: r0 = DefaultTypeTest()
    //     0xc004fc: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xc00500: ldur            x0, [fp, #-8]
    // 0xc00504: LoadField: r1 = r0->field_f
    //     0xc00504: ldur            w1, [x0, #0xf]
    // 0xc00508: DecompressPointer r1
    //     0xc00508: add             x1, x1, HEAP, lsl #32
    // 0xc0050c: ldur            x0, [fp, #-0x10]
    // 0xc00510: LoadField: r2 = r0->field_f
    //     0xc00510: ldur            w2, [x0, #0xf]
    // 0xc00514: DecompressPointer r2
    //     0xc00514: add             x2, x2, HEAP, lsl #32
    // 0xc00518: stp             x2, x1, [SP]
    // 0xc0051c: r0 = ==()
    //     0xc0051c: bl              #0x126d7dc  ; [package:flutter/src/material/icon_button_theme.dart] IconButtonThemeData::==
    // 0xc00520: eor             x1, x0, #0x10
    // 0xc00524: mov             x0, x1
    // 0xc00528: LeaveFrame
    //     0xc00528: mov             SP, fp
    //     0xc0052c: ldp             fp, lr, [SP], #0x10
    // 0xc00530: ret
    //     0xc00530: ret             
    // 0xc00534: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc00534: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc00538: b               #0xc004c4
  }
  static _ of(/* No info */) {
    // ** addr: 0xd2d638, size: 0x7c
    // 0xd2d638: EnterFrame
    //     0xd2d638: stp             fp, lr, [SP, #-0x10]!
    //     0xd2d63c: mov             fp, SP
    // 0xd2d640: AllocStack(0x18)
    //     0xd2d640: sub             SP, SP, #0x18
    // 0xd2d644: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0xd2d644: stur            x1, [fp, #-8]
    // 0xd2d648: CheckStackOverflow
    //     0xd2d648: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd2d64c: cmp             SP, x16
    //     0xd2d650: b.ls            #0xd2d6ac
    // 0xd2d654: r16 = <IconButtonTheme>
    //     0xd2d654: add             x16, PP, #0x84, lsl #12  ; [pp+0x84a70] TypeArguments: <IconButtonTheme>
    //     0xd2d658: ldr             x16, [x16, #0xa70]
    // 0xd2d65c: stp             x1, x16, [SP]
    // 0xd2d660: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd2d660: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd2d664: r0 = dependOnInheritedWidgetOfExactType()
    //     0xd2d664: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xd2d668: cmp             w0, NULL
    // 0xd2d66c: b.ne            #0xd2d678
    // 0xd2d670: r0 = Null
    //     0xd2d670: mov             x0, NULL
    // 0xd2d674: b               #0xd2d684
    // 0xd2d678: LoadField: r1 = r0->field_f
    //     0xd2d678: ldur            w1, [x0, #0xf]
    // 0xd2d67c: DecompressPointer r1
    //     0xd2d67c: add             x1, x1, HEAP, lsl #32
    // 0xd2d680: mov             x0, x1
    // 0xd2d684: cmp             w0, NULL
    // 0xd2d688: b.ne            #0xd2d6a0
    // 0xd2d68c: ldur            x1, [fp, #-8]
    // 0xd2d690: r0 = of()
    //     0xd2d690: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd2d694: LoadField: r1 = r0->field_e7
    //     0xd2d694: ldur            w1, [x0, #0xe7]
    // 0xd2d698: DecompressPointer r1
    //     0xd2d698: add             x1, x1, HEAP, lsl #32
    // 0xd2d69c: mov             x0, x1
    // 0xd2d6a0: LeaveFrame
    //     0xd2d6a0: mov             SP, fp
    //     0xd2d6a4: ldp             fp, lr, [SP], #0x10
    // 0xd2d6a8: ret
    //     0xd2d6a8: ret             
    // 0xd2d6ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd2d6ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd2d6b0: b               #0xd2d654
  }
  _ wrap(/* No info */) {
    // ** addr: 0x1200dc4, size: 0x3c
    // 0x1200dc4: EnterFrame
    //     0x1200dc4: stp             fp, lr, [SP, #-0x10]!
    //     0x1200dc8: mov             fp, SP
    // 0x1200dcc: AllocStack(0x10)
    //     0x1200dcc: sub             SP, SP, #0x10
    // 0x1200dd0: SetupParameters(dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x1200dd0: stur            x2, [fp, #-0x10]
    // 0x1200dd4: LoadField: r0 = r1->field_f
    //     0x1200dd4: ldur            w0, [x1, #0xf]
    // 0x1200dd8: DecompressPointer r0
    //     0x1200dd8: add             x0, x0, HEAP, lsl #32
    // 0x1200ddc: stur            x0, [fp, #-8]
    // 0x1200de0: r0 = IconButtonTheme()
    //     0x1200de0: bl              #0xd29648  ; AllocateIconButtonThemeStub -> IconButtonTheme (size=0x14)
    // 0x1200de4: ldur            x1, [fp, #-8]
    // 0x1200de8: StoreField: r0->field_f = r1
    //     0x1200de8: stur            w1, [x0, #0xf]
    // 0x1200dec: ldur            x1, [fp, #-0x10]
    // 0x1200df0: StoreField: r0->field_b = r1
    //     0x1200df0: stur            w1, [x0, #0xb]
    // 0x1200df4: LeaveFrame
    //     0x1200df4: mov             SP, fp
    //     0x1200df8: ldp             fp, lr, [SP], #0x10
    // 0x1200dfc: ret
    //     0x1200dfc: ret             
  }
}
