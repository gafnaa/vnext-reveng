// lib: , url: package:flutter/src/material/input_border.dart

// class id: 1048906, size: 0x8
class :: {
}

// class id: 3015, size: 0xc, field offset: 0x8
//   const constructor, 
abstract class InputBorder extends ShapeBorder {
}

// class id: 3016, size: 0x18, field offset: 0xc
//   const constructor, 
class OutlineInputBorder extends InputBorder {

  BorderSide field_8;
  _Double field_c;
  BorderRadius field_14;

  _ getInnerPath(/* No info */) {
    // ** addr: 0xbffbf8, size: 0x198
    // 0xbffbf8: EnterFrame
    //     0xbffbf8: stp             fp, lr, [SP, #-0x10]!
    //     0xbffbfc: mov             fp, SP
    // 0xbffc00: AllocStack(0x30)
    //     0xbffc00: sub             SP, SP, #0x30
    // 0xbffc04: SetupParameters(OutlineInputBorder this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xbffc04: stur            x1, [fp, #-8]
    //     0xbffc08: stur            x2, [fp, #-0x10]
    // 0xbffc0c: CheckStackOverflow
    //     0xbffc0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbffc10: cmp             SP, x16
    //     0xbffc14: b.ls            #0xbffd84
    // 0xbffc18: r0 = _NativePath()
    //     0xbffc18: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0xbffc1c: mov             x1, x0
    // 0xbffc20: stur            x0, [fp, #-0x18]
    // 0xbffc24: r0 = __constructor$Method$FfiNative()
    //     0xbffc24: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0xbffc28: ldur            x0, [fp, #-8]
    // 0xbffc2c: LoadField: r1 = r0->field_13
    //     0xbffc2c: ldur            w1, [x0, #0x13]
    // 0xbffc30: DecompressPointer r1
    //     0xbffc30: add             x1, x1, HEAP, lsl #32
    // 0xbffc34: ldur            x2, [fp, #-0x10]
    // 0xbffc38: r0 = toRRect()
    //     0xbffc38: bl              #0xb77a10  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0xbffc3c: mov             x1, x0
    // 0xbffc40: ldur            x0, [fp, #-8]
    // 0xbffc44: LoadField: r2 = r0->field_7
    //     0xbffc44: ldur            w2, [x0, #7]
    // 0xbffc48: DecompressPointer r2
    //     0xbffc48: add             x2, x2, HEAP, lsl #32
    // 0xbffc4c: LoadField: d0 = r2->field_b
    //     0xbffc4c: ldur            d0, [x2, #0xb]
    // 0xbffc50: ArrayLoad: d1 = r2[0]  ; List_8
    //     0xbffc50: ldur            d1, [x2, #0x17]
    // 0xbffc54: d2 = 1.000000
    //     0xbffc54: fmov            d2, #1.00000000
    // 0xbffc58: fadd            d3, d1, d2
    // 0xbffc5c: d1 = 2.000000
    //     0xbffc5c: fmov            d1, #2.00000000
    // 0xbffc60: fdiv            d4, d3, d1
    // 0xbffc64: fsub            d1, d2, d4
    // 0xbffc68: fmul            d2, d0, d1
    // 0xbffc6c: mov             v0.16b, v2.16b
    // 0xbffc70: r0 = deflate()
    //     0xbffc70: bl              #0xbfdae4  ; [dart:ui] _RRectLike::deflate
    // 0xbffc74: stur            x0, [fp, #-8]
    // 0xbffc78: LoadField: d0 = r0->field_b
    //     0xbffc78: ldur            d0, [x0, #0xb]
    // 0xbffc7c: fcvt            s1, d0
    // 0xbffc80: stur            d1, [fp, #-0x28]
    // 0xbffc84: r4 = 24
    //     0xbffc84: mov             x4, #0x18
    // 0xbffc88: r0 = AllocateFloat32Array()
    //     0xbffc88: bl              #0x13defe8  ; AllocateFloat32ArrayStub
    // 0xbffc8c: ldur            d0, [fp, #-0x28]
    // 0xbffc90: stur            x0, [fp, #-0x10]
    // 0xbffc94: ArrayStore: r0[0] = d0  ; List_8
    //     0xbffc94: stur            s0, [x0, #0x17]
    // 0xbffc98: ldur            x1, [fp, #-8]
    // 0xbffc9c: LoadField: d0 = r1->field_13
    //     0xbffc9c: ldur            d0, [x1, #0x13]
    // 0xbffca0: fcvt            s1, d0
    // 0xbffca4: StoreField: r0->field_1b = d1
    //     0xbffca4: stur            s1, [x0, #0x1b]
    // 0xbffca8: LoadField: d0 = r1->field_1b
    //     0xbffca8: ldur            d0, [x1, #0x1b]
    // 0xbffcac: fcvt            s1, d0
    // 0xbffcb0: StoreField: r0->field_1f = d1
    //     0xbffcb0: stur            s1, [x0, #0x1f]
    // 0xbffcb4: LoadField: d0 = r1->field_23
    //     0xbffcb4: ldur            d0, [x1, #0x23]
    // 0xbffcb8: fcvt            s1, d0
    // 0xbffcbc: StoreField: r0->field_23 = d1
    //     0xbffcbc: stur            s1, [x0, #0x23]
    // 0xbffcc0: LoadField: d0 = r1->field_2b
    //     0xbffcc0: ldur            d0, [x1, #0x2b]
    // 0xbffcc4: fcvt            s1, d0
    // 0xbffcc8: StoreField: r0->field_27 = d1
    //     0xbffcc8: stur            s1, [x0, #0x27]
    // 0xbffccc: LoadField: d0 = r1->field_33
    //     0xbffccc: ldur            d0, [x1, #0x33]
    // 0xbffcd0: fcvt            s1, d0
    // 0xbffcd4: StoreField: r0->field_2b = d1
    //     0xbffcd4: stur            s1, [x0, #0x2b]
    // 0xbffcd8: LoadField: d0 = r1->field_3b
    //     0xbffcd8: ldur            d0, [x1, #0x3b]
    // 0xbffcdc: fcvt            s1, d0
    // 0xbffce0: StoreField: r0->field_2f = d1
    //     0xbffce0: stur            s1, [x0, #0x2f]
    // 0xbffce4: LoadField: d0 = r1->field_43
    //     0xbffce4: ldur            d0, [x1, #0x43]
    // 0xbffce8: fcvt            s1, d0
    // 0xbffcec: StoreField: r0->field_33 = d1
    //     0xbffcec: stur            s1, [x0, #0x33]
    // 0xbffcf0: LoadField: d0 = r1->field_4b
    //     0xbffcf0: ldur            d0, [x1, #0x4b]
    // 0xbffcf4: fcvt            s1, d0
    // 0xbffcf8: StoreField: r0->field_37 = d1
    //     0xbffcf8: stur            s1, [x0, #0x37]
    // 0xbffcfc: LoadField: d0 = r1->field_53
    //     0xbffcfc: ldur            d0, [x1, #0x53]
    // 0xbffd00: fcvt            s1, d0
    // 0xbffd04: StoreField: r0->field_3b = d1
    //     0xbffd04: stur            s1, [x0, #0x3b]
    // 0xbffd08: LoadField: d0 = r1->field_5b
    //     0xbffd08: ldur            d0, [x1, #0x5b]
    // 0xbffd0c: fcvt            s1, d0
    // 0xbffd10: StoreField: r0->field_3f = d1
    //     0xbffd10: stur            s1, [x0, #0x3f]
    // 0xbffd14: LoadField: d0 = r1->field_63
    //     0xbffd14: ldur            d0, [x1, #0x63]
    // 0xbffd18: fcvt            s1, d0
    // 0xbffd1c: StoreField: r0->field_43 = d1
    //     0xbffd1c: stur            s1, [x0, #0x43]
    // 0xbffd20: ldur            x2, [fp, #-0x18]
    // 0xbffd24: LoadField: r1 = r2->field_7
    //     0xbffd24: ldur            w1, [x2, #7]
    // 0xbffd28: DecompressPointer r1
    //     0xbffd28: add             x1, x1, HEAP, lsl #32
    // 0xbffd2c: cmp             w1, NULL
    // 0xbffd30: b.eq            #0xbffd8c
    // 0xbffd34: LoadField: r3 = r1->field_7
    //     0xbffd34: ldur            x3, [x1, #7]
    // 0xbffd38: ldr             x1, [x3]
    // 0xbffd3c: cbz             x1, #0xbffd74
    // 0xbffd40: mov             x3, x1
    // 0xbffd44: stur            x3, [fp, #-0x20]
    // 0xbffd48: r1 = <Never>
    //     0xbffd48: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xbffd4c: r0 = Pointer()
    //     0xbffd4c: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xbffd50: mov             x1, x0
    // 0xbffd54: ldur            x0, [fp, #-0x20]
    // 0xbffd58: StoreField: r1->field_7 = r0
    //     0xbffd58: stur            x0, [x1, #7]
    // 0xbffd5c: ldur            x2, [fp, #-0x10]
    // 0xbffd60: r0 = __addRRect$Method$FfiNative()
    //     0xbffd60: bl              #0xbfd930  ; [dart:ui] _NativePath::__addRRect$Method$FfiNative
    // 0xbffd64: ldur            x0, [fp, #-0x18]
    // 0xbffd68: LeaveFrame
    //     0xbffd68: mov             SP, fp
    //     0xbffd6c: ldp             fp, lr, [SP], #0x10
    // 0xbffd70: ret
    //     0xbffd70: ret             
    // 0xbffd74: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xbffd74: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xbffd78: str             x16, [SP]
    // 0xbffd7c: r0 = _throwNew()
    //     0xbffd7c: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xbffd80: brk             #0
    // 0xbffd84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbffd84: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbffd88: b               #0xbffc18
    // 0xbffd8c: r0 = NullErrorSharedWithoutFPURegs()
    //     0xbffd8c: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ lerpFrom(/* No info */) {
    // ** addr: 0x10ee584, size: 0xfc
    // 0x10ee584: EnterFrame
    //     0x10ee584: stp             fp, lr, [SP, #-0x10]!
    //     0x10ee588: mov             fp, SP
    // 0x10ee58c: AllocStack(0x30)
    //     0x10ee58c: sub             SP, SP, #0x30
    // 0x10ee590: SetupParameters(OutlineInputBorder this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* d0 => d1, fp-0x28 */)
    //     0x10ee590: mov             x3, x1
    //     0x10ee594: mov             x0, x2
    //     0x10ee598: mov             v1.16b, v0.16b
    //     0x10ee59c: stur            x1, [fp, #-8]
    //     0x10ee5a0: stur            x2, [fp, #-0x10]
    //     0x10ee5a4: stur            d0, [fp, #-0x28]
    // 0x10ee5a8: CheckStackOverflow
    //     0x10ee5a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10ee5ac: cmp             SP, x16
    //     0x10ee5b0: b.ls            #0x10ee678
    // 0x10ee5b4: r1 = LoadClassIdInstr(r0)
    //     0x10ee5b4: ldur            x1, [x0, #-1]
    //     0x10ee5b8: ubfx            x1, x1, #0xc, #0x14
    // 0x10ee5bc: cmp             x1, #0xbc8
    // 0x10ee5c0: b.ne            #0x10ee64c
    // 0x10ee5c4: LoadField: r1 = r0->field_13
    //     0x10ee5c4: ldur            w1, [x0, #0x13]
    // 0x10ee5c8: DecompressPointer r1
    //     0x10ee5c8: add             x1, x1, HEAP, lsl #32
    // 0x10ee5cc: LoadField: r2 = r3->field_13
    //     0x10ee5cc: ldur            w2, [x3, #0x13]
    // 0x10ee5d0: DecompressPointer r2
    //     0x10ee5d0: add             x2, x2, HEAP, lsl #32
    // 0x10ee5d4: mov             v0.16b, v1.16b
    // 0x10ee5d8: r0 = lerp()
    //     0x10ee5d8: bl              #0xbfea10  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::lerp
    // 0x10ee5dc: mov             x3, x0
    // 0x10ee5e0: ldur            x0, [fp, #-0x10]
    // 0x10ee5e4: stur            x3, [fp, #-0x18]
    // 0x10ee5e8: LoadField: r1 = r0->field_7
    //     0x10ee5e8: ldur            w1, [x0, #7]
    // 0x10ee5ec: DecompressPointer r1
    //     0x10ee5ec: add             x1, x1, HEAP, lsl #32
    // 0x10ee5f0: ldur            x2, [fp, #-8]
    // 0x10ee5f4: LoadField: r4 = r2->field_7
    //     0x10ee5f4: ldur            w4, [x2, #7]
    // 0x10ee5f8: DecompressPointer r4
    //     0x10ee5f8: add             x4, x4, HEAP, lsl #32
    // 0x10ee5fc: mov             x2, x4
    // 0x10ee600: ldur            d0, [fp, #-0x28]
    // 0x10ee604: r0 = lerp()
    //     0x10ee604: bl              #0xa07be0  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x10ee608: mov             x1, x0
    // 0x10ee60c: ldur            x0, [fp, #-0x10]
    // 0x10ee610: stur            x1, [fp, #-0x20]
    // 0x10ee614: LoadField: d0 = r0->field_b
    //     0x10ee614: ldur            d0, [x0, #0xb]
    // 0x10ee618: stur            d0, [fp, #-0x30]
    // 0x10ee61c: r0 = OutlineInputBorder()
    //     0x10ee61c: bl              #0xd93f40  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x10ee620: mov             x1, x0
    // 0x10ee624: ldur            x0, [fp, #-0x18]
    // 0x10ee628: StoreField: r1->field_13 = r0
    //     0x10ee628: stur            w0, [x1, #0x13]
    // 0x10ee62c: ldur            d0, [fp, #-0x30]
    // 0x10ee630: StoreField: r1->field_b = d0
    //     0x10ee630: stur            d0, [x1, #0xb]
    // 0x10ee634: ldur            x0, [fp, #-0x20]
    // 0x10ee638: StoreField: r1->field_7 = r0
    //     0x10ee638: stur            w0, [x1, #7]
    // 0x10ee63c: mov             x0, x1
    // 0x10ee640: LeaveFrame
    //     0x10ee640: mov             SP, fp
    //     0x10ee644: ldp             fp, lr, [SP], #0x10
    // 0x10ee648: ret
    //     0x10ee648: ret             
    // 0x10ee64c: mov             x2, x3
    // 0x10ee650: cmp             w0, NULL
    // 0x10ee654: b.ne            #0x10ee668
    // 0x10ee658: mov             x1, x2
    // 0x10ee65c: ldur            d0, [fp, #-0x28]
    // 0x10ee660: r0 = scale()
    //     0x10ee660: bl              #0x12fcffc  ; [package:flutter/src/material/input_border.dart] OutlineInputBorder::scale
    // 0x10ee664: b               #0x10ee66c
    // 0x10ee668: r0 = Null
    //     0x10ee668: mov             x0, NULL
    // 0x10ee66c: LeaveFrame
    //     0x10ee66c: mov             SP, fp
    //     0x10ee670: ldp             fp, lr, [SP], #0x10
    // 0x10ee674: ret
    //     0x10ee674: ret             
    // 0x10ee678: r0 = StackOverflowSharedWithFPURegs()
    //     0x10ee678: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x10ee67c: b               #0x10ee5b4
  }
  _ lerpTo(/* No info */) {
    // ** addr: 0x10f16b0, size: 0xec
    // 0x10f16b0: EnterFrame
    //     0x10f16b0: stp             fp, lr, [SP, #-0x10]!
    //     0x10f16b4: mov             fp, SP
    // 0x10f16b8: AllocStack(0x30)
    //     0x10f16b8: sub             SP, SP, #0x30
    // 0x10f16bc: SetupParameters(OutlineInputBorder this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* d0 => d1, fp-0x28 */)
    //     0x10f16bc: mov             x3, x1
    //     0x10f16c0: mov             x0, x2
    //     0x10f16c4: mov             v1.16b, v0.16b
    //     0x10f16c8: stur            x1, [fp, #-8]
    //     0x10f16cc: stur            x2, [fp, #-0x10]
    //     0x10f16d0: stur            d0, [fp, #-0x28]
    // 0x10f16d4: CheckStackOverflow
    //     0x10f16d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f16d8: cmp             SP, x16
    //     0x10f16dc: b.ls            #0x10f1794
    // 0x10f16e0: r1 = LoadClassIdInstr(r0)
    //     0x10f16e0: ldur            x1, [x0, #-1]
    //     0x10f16e4: ubfx            x1, x1, #0xc, #0x14
    // 0x10f16e8: cmp             x1, #0xbc8
    // 0x10f16ec: b.ne            #0x10f1778
    // 0x10f16f0: LoadField: r1 = r3->field_13
    //     0x10f16f0: ldur            w1, [x3, #0x13]
    // 0x10f16f4: DecompressPointer r1
    //     0x10f16f4: add             x1, x1, HEAP, lsl #32
    // 0x10f16f8: LoadField: r2 = r0->field_13
    //     0x10f16f8: ldur            w2, [x0, #0x13]
    // 0x10f16fc: DecompressPointer r2
    //     0x10f16fc: add             x2, x2, HEAP, lsl #32
    // 0x10f1700: mov             v0.16b, v1.16b
    // 0x10f1704: r0 = lerp()
    //     0x10f1704: bl              #0xbfea10  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::lerp
    // 0x10f1708: ldur            x1, [fp, #-8]
    // 0x10f170c: stur            x0, [fp, #-0x18]
    // 0x10f1710: LoadField: r2 = r1->field_7
    //     0x10f1710: ldur            w2, [x1, #7]
    // 0x10f1714: DecompressPointer r2
    //     0x10f1714: add             x2, x2, HEAP, lsl #32
    // 0x10f1718: ldur            x3, [fp, #-0x10]
    // 0x10f171c: LoadField: r1 = r3->field_7
    //     0x10f171c: ldur            w1, [x3, #7]
    // 0x10f1720: DecompressPointer r1
    //     0x10f1720: add             x1, x1, HEAP, lsl #32
    // 0x10f1724: mov             x16, x1
    // 0x10f1728: mov             x1, x2
    // 0x10f172c: mov             x2, x16
    // 0x10f1730: ldur            d0, [fp, #-0x28]
    // 0x10f1734: r0 = lerp()
    //     0x10f1734: bl              #0xa07be0  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x10f1738: ldur            x2, [fp, #-0x10]
    // 0x10f173c: stur            x0, [fp, #-0x20]
    // 0x10f1740: LoadField: d0 = r2->field_b
    //     0x10f1740: ldur            d0, [x2, #0xb]
    // 0x10f1744: stur            d0, [fp, #-0x30]
    // 0x10f1748: r0 = OutlineInputBorder()
    //     0x10f1748: bl              #0xd93f40  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x10f174c: mov             x1, x0
    // 0x10f1750: ldur            x0, [fp, #-0x18]
    // 0x10f1754: StoreField: r1->field_13 = r0
    //     0x10f1754: stur            w0, [x1, #0x13]
    // 0x10f1758: ldur            d0, [fp, #-0x30]
    // 0x10f175c: StoreField: r1->field_b = d0
    //     0x10f175c: stur            d0, [x1, #0xb]
    // 0x10f1760: ldur            x0, [fp, #-0x20]
    // 0x10f1764: StoreField: r1->field_7 = r0
    //     0x10f1764: stur            w0, [x1, #7]
    // 0x10f1768: mov             x0, x1
    // 0x10f176c: LeaveFrame
    //     0x10f176c: mov             SP, fp
    //     0x10f1770: ldp             fp, lr, [SP], #0x10
    // 0x10f1774: ret
    //     0x10f1774: ret             
    // 0x10f1778: mov             x1, x3
    // 0x10f177c: mov             x2, x0
    // 0x10f1780: ldur            d0, [fp, #-0x28]
    // 0x10f1784: r0 = lerpTo()
    //     0x10f1784: bl              #0x10f17e8  ; [package:flutter/src/painting/borders.dart] ShapeBorder::lerpTo
    // 0x10f1788: LeaveFrame
    //     0x10f1788: mov             SP, fp
    //     0x10f178c: ldp             fp, lr, [SP], #0x10
    // 0x10f1790: ret
    //     0x10f1790: ret             
    // 0x10f1794: r0 = StackOverflowSharedWithFPURegs()
    //     0x10f1794: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x10f1798: b               #0x10f16e0
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x114adf4, size: 0xac
    // 0x114adf4: EnterFrame
    //     0x114adf4: stp             fp, lr, [SP, #-0x10]!
    //     0x114adf8: mov             fp, SP
    // 0x114adfc: AllocStack(0x8)
    //     0x114adfc: sub             SP, SP, #8
    // 0x114ae00: CheckStackOverflow
    //     0x114ae00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x114ae04: cmp             SP, x16
    //     0x114ae08: b.ls            #0x114ae80
    // 0x114ae0c: ldr             x0, [fp, #0x10]
    // 0x114ae10: LoadField: r1 = r0->field_7
    //     0x114ae10: ldur            w1, [x0, #7]
    // 0x114ae14: DecompressPointer r1
    //     0x114ae14: add             x1, x1, HEAP, lsl #32
    // 0x114ae18: LoadField: r2 = r0->field_13
    //     0x114ae18: ldur            w2, [x0, #0x13]
    // 0x114ae1c: DecompressPointer r2
    //     0x114ae1c: add             x2, x2, HEAP, lsl #32
    // 0x114ae20: LoadField: d0 = r0->field_b
    //     0x114ae20: ldur            d0, [x0, #0xb]
    // 0x114ae24: r0 = inline_Allocate_Double()
    //     0x114ae24: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0x114ae28: add             x0, x0, #0x10
    //     0x114ae2c: cmp             x3, x0
    //     0x114ae30: b.ls            #0x114ae88
    //     0x114ae34: str             x0, [THR, #0x60]  ; THR::top
    //     0x114ae38: sub             x0, x0, #0xf
    //     0x114ae3c: mov             x3, #0xe19c
    //     0x114ae40: movk            x3, #3, lsl #16
    //     0x114ae44: stur            x3, [x0, #-1]
    // 0x114ae48: dmb             ishst
    // 0x114ae4c: StoreField: r0->field_7 = d0
    //     0x114ae4c: stur            d0, [x0, #7]
    // 0x114ae50: str             x0, [SP]
    // 0x114ae54: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x114ae54: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x114ae58: r0 = hash()
    //     0x114ae58: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x114ae5c: mov             x2, x0
    // 0x114ae60: r0 = BoxInt64Instr(r2)
    //     0x114ae60: sbfiz           x0, x2, #1, #0x1f
    //     0x114ae64: cmp             x2, x0, asr #1
    //     0x114ae68: b.eq            #0x114ae74
    //     0x114ae6c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x114ae70: stur            x2, [x0, #7]
    // 0x114ae74: LeaveFrame
    //     0x114ae74: mov             SP, fp
    //     0x114ae78: ldp             fp, lr, [SP], #0x10
    // 0x114ae7c: ret
    //     0x114ae7c: ret             
    // 0x114ae80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x114ae80: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x114ae84: b               #0x114ae0c
    // 0x114ae88: SaveReg d0
    //     0x114ae88: str             q0, [SP, #-0x10]!
    // 0x114ae8c: stp             x1, x2, [SP, #-0x10]!
    // 0x114ae90: r0 = AllocateDouble()
    //     0x114ae90: bl              #0x13df878  ; AllocateDoubleStub
    // 0x114ae94: ldp             x1, x2, [SP], #0x10
    // 0x114ae98: RestoreReg d0
    //     0x114ae98: ldr             q0, [SP], #0x10
    // 0x114ae9c: b               #0x114ae4c
  }
  _ ==(/* No info */) {
    // ** addr: 0x12966d0, size: 0x130
    // 0x12966d0: EnterFrame
    //     0x12966d0: stp             fp, lr, [SP, #-0x10]!
    //     0x12966d4: mov             fp, SP
    // 0x12966d8: AllocStack(0x10)
    //     0x12966d8: sub             SP, SP, #0x10
    // 0x12966dc: CheckStackOverflow
    //     0x12966dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12966e0: cmp             SP, x16
    //     0x12966e4: b.ls            #0x12967f8
    // 0x12966e8: ldr             x0, [fp, #0x10]
    // 0x12966ec: cmp             w0, NULL
    // 0x12966f0: b.ne            #0x1296704
    // 0x12966f4: r0 = false
    //     0x12966f4: add             x0, NULL, #0x30  ; false
    // 0x12966f8: LeaveFrame
    //     0x12966f8: mov             SP, fp
    //     0x12966fc: ldp             fp, lr, [SP], #0x10
    // 0x1296700: ret
    //     0x1296700: ret             
    // 0x1296704: ldr             x1, [fp, #0x18]
    // 0x1296708: cmp             w1, w0
    // 0x129670c: b.ne            #0x1296720
    // 0x1296710: r0 = true
    //     0x1296710: add             x0, NULL, #0x20  ; true
    // 0x1296714: LeaveFrame
    //     0x1296714: mov             SP, fp
    //     0x1296718: ldp             fp, lr, [SP], #0x10
    // 0x129671c: ret
    //     0x129671c: ret             
    // 0x1296720: str             x0, [SP]
    // 0x1296724: r0 = runtimeType()
    //     0x1296724: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x1296728: r1 = LoadClassIdInstr(r0)
    //     0x1296728: ldur            x1, [x0, #-1]
    //     0x129672c: ubfx            x1, x1, #0xc, #0x14
    // 0x1296730: r16 = OutlineInputBorder
    //     0x1296730: add             x16, PP, #0x26, lsl #12  ; [pp+0x26690] Type: OutlineInputBorder
    //     0x1296734: ldr             x16, [x16, #0x690]
    // 0x1296738: stp             x16, x0, [SP]
    // 0x129673c: mov             x0, x1
    // 0x1296740: mov             lr, x0
    // 0x1296744: ldr             lr, [x21, lr, lsl #3]
    // 0x1296748: blr             lr
    // 0x129674c: tbz             w0, #4, #0x1296760
    // 0x1296750: r0 = false
    //     0x1296750: add             x0, NULL, #0x30  ; false
    // 0x1296754: LeaveFrame
    //     0x1296754: mov             SP, fp
    //     0x1296758: ldp             fp, lr, [SP], #0x10
    // 0x129675c: ret
    //     0x129675c: ret             
    // 0x1296760: ldr             x0, [fp, #0x10]
    // 0x1296764: r1 = 60
    //     0x1296764: mov             x1, #0x3c
    // 0x1296768: branchIfSmi(r0, 0x1296774)
    //     0x1296768: tbz             w0, #0, #0x1296774
    // 0x129676c: r1 = LoadClassIdInstr(r0)
    //     0x129676c: ldur            x1, [x0, #-1]
    //     0x1296770: ubfx            x1, x1, #0xc, #0x14
    // 0x1296774: cmp             x1, #0xbc8
    // 0x1296778: b.ne            #0x12967e8
    // 0x129677c: ldr             x1, [fp, #0x18]
    // 0x1296780: LoadField: r2 = r0->field_7
    //     0x1296780: ldur            w2, [x0, #7]
    // 0x1296784: DecompressPointer r2
    //     0x1296784: add             x2, x2, HEAP, lsl #32
    // 0x1296788: LoadField: r3 = r1->field_7
    //     0x1296788: ldur            w3, [x1, #7]
    // 0x129678c: DecompressPointer r3
    //     0x129678c: add             x3, x3, HEAP, lsl #32
    // 0x1296790: stp             x3, x2, [SP]
    // 0x1296794: r0 = ==()
    //     0x1296794: bl              #0x1278854  ; [package:flutter/src/painting/borders.dart] BorderSide::==
    // 0x1296798: tbnz            w0, #4, #0x12967e8
    // 0x129679c: ldr             x1, [fp, #0x18]
    // 0x12967a0: ldr             x0, [fp, #0x10]
    // 0x12967a4: LoadField: r2 = r0->field_13
    //     0x12967a4: ldur            w2, [x0, #0x13]
    // 0x12967a8: DecompressPointer r2
    //     0x12967a8: add             x2, x2, HEAP, lsl #32
    // 0x12967ac: LoadField: r3 = r1->field_13
    //     0x12967ac: ldur            w3, [x1, #0x13]
    // 0x12967b0: DecompressPointer r3
    //     0x12967b0: add             x3, x3, HEAP, lsl #32
    // 0x12967b4: stp             x3, x2, [SP]
    // 0x12967b8: r0 = ==()
    //     0x12967b8: bl              #0x1298058  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::==
    // 0x12967bc: tbnz            w0, #4, #0x12967e8
    // 0x12967c0: ldr             x2, [fp, #0x18]
    // 0x12967c4: ldr             x1, [fp, #0x10]
    // 0x12967c8: LoadField: d0 = r1->field_b
    //     0x12967c8: ldur            d0, [x1, #0xb]
    // 0x12967cc: LoadField: d1 = r2->field_b
    //     0x12967cc: ldur            d1, [x2, #0xb]
    // 0x12967d0: fcmp            d0, d1
    // 0x12967d4: r16 = true
    //     0x12967d4: add             x16, NULL, #0x20  ; true
    // 0x12967d8: r17 = false
    //     0x12967d8: add             x17, NULL, #0x30  ; false
    // 0x12967dc: csel            x1, x16, x17, eq
    // 0x12967e0: mov             x0, x1
    // 0x12967e4: b               #0x12967ec
    // 0x12967e8: r0 = false
    //     0x12967e8: add             x0, NULL, #0x30  ; false
    // 0x12967ec: LeaveFrame
    //     0x12967ec: mov             SP, fp
    //     0x12967f0: ldp             fp, lr, [SP], #0x10
    // 0x12967f4: ret
    //     0x12967f4: ret             
    // 0x12967f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12967f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12967fc: b               #0x12966e8
  }
  _ paintInterior(/* No info */) {
    // ** addr: 0x12eca74, size: 0x64
    // 0x12eca74: EnterFrame
    //     0x12eca74: stp             fp, lr, [SP, #-0x10]!
    //     0x12eca78: mov             fp, SP
    // 0x12eca7c: AllocStack(0x10)
    //     0x12eca7c: sub             SP, SP, #0x10
    // 0x12eca80: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */, dynamic _ /* r3 => r2 */, dynamic _ /* r5 => r3, fp-0x10 */)
    //     0x12eca80: mov             x0, x2
    //     0x12eca84: stur            x2, [fp, #-8]
    //     0x12eca88: mov             x2, x3
    //     0x12eca8c: mov             x3, x5
    //     0x12eca90: stur            x5, [fp, #-0x10]
    // 0x12eca94: CheckStackOverflow
    //     0x12eca94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12eca98: cmp             SP, x16
    //     0x12eca9c: b.ls            #0x12ecad0
    // 0x12ecaa0: LoadField: r4 = r1->field_13
    //     0x12ecaa0: ldur            w4, [x1, #0x13]
    // 0x12ecaa4: DecompressPointer r4
    //     0x12ecaa4: add             x4, x4, HEAP, lsl #32
    // 0x12ecaa8: mov             x1, x4
    // 0x12ecaac: r0 = toRRect()
    //     0x12ecaac: bl              #0xb77a10  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0x12ecab0: ldur            x1, [fp, #-8]
    // 0x12ecab4: mov             x2, x0
    // 0x12ecab8: ldur            x3, [fp, #-0x10]
    // 0x12ecabc: r0 = drawRRect()
    //     0x12ecabc: bl              #0xb6dce0  ; [dart:ui] _NativeCanvas::drawRRect
    // 0x12ecac0: r0 = Null
    //     0x12ecac0: mov             x0, NULL
    // 0x12ecac4: LeaveFrame
    //     0x12ecac4: mov             SP, fp
    //     0x12ecac8: ldp             fp, lr, [SP], #0x10
    // 0x12ecacc: ret
    //     0x12ecacc: ret             
    // 0x12ecad0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12ecad0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12ecad4: b               #0x12ecaa0
  }
  _ paint(/* No info */) {
    // ** addr: 0x12eeab4, size: 0x464
    // 0x12eeab4: EnterFrame
    //     0x12eeab4: stp             fp, lr, [SP, #-0x10]!
    //     0x12eeab8: mov             fp, SP
    // 0x12eeabc: AllocStack(0x60)
    //     0x12eeabc: sub             SP, SP, #0x60
    // 0x12eeac0: SetupParameters(OutlineInputBorder this /* r1 => r3, fp-0x20 */, dynamic _ /* r2 => r0, fp-0x28 */, dynamic _ /* r3 => r2, fp-0x30 */, {_Double gapExtent = 0.000000 /* d0, fp-0x50 */, _Double gapPercentage = 0.000000 /* d1, fp-0x48 */, dynamic gapStart = Null /* r6, fp-0x18 */, dynamic textDirection = Null /* r4, fp-0x10 */})
    //     0x12eeac0: mov             x0, x2
    //     0x12eeac4: stur            x2, [fp, #-0x28]
    //     0x12eeac8: mov             x2, x3
    //     0x12eeacc: stur            x3, [fp, #-0x30]
    //     0x12eead0: mov             x3, x1
    //     0x12eead4: stur            x1, [fp, #-0x20]
    //     0x12eead8: ldur            w1, [x4, #0x13]
    //     0x12eeadc: ldur            w5, [x4, #0x1f]
    //     0x12eeae0: add             x5, x5, HEAP, lsl #32
    //     0x12eeae4: add             x16, PP, #0xab, lsl #12  ; [pp+0xab3c0] "gapExtent"
    //     0x12eeae8: ldr             x16, [x16, #0x3c0]
    //     0x12eeaec: cmp             w5, w16
    //     0x12eeaf0: b.ne            #0x12eeb14
    //     0x12eeaf4: ldur            w5, [x4, #0x23]
    //     0x12eeaf8: add             x5, x5, HEAP, lsl #32
    //     0x12eeafc: sub             w6, w1, w5
    //     0x12eeb00: add             x5, fp, w6, sxtw #2
    //     0x12eeb04: ldr             x5, [x5, #8]
    //     0x12eeb08: ldur            d0, [x5, #7]
    //     0x12eeb0c: mov             x5, #1
    //     0x12eeb10: b               #0x12eeb1c
    //     0x12eeb14: eor             v0.16b, v0.16b, v0.16b
    //     0x12eeb18: mov             x5, #0
    //     0x12eeb1c: stur            d0, [fp, #-0x50]
    //     0x12eeb20: lsl             x6, x5, #1
    //     0x12eeb24: lsl             w7, w6, #1
    //     0x12eeb28: add             w8, w7, #8
    //     0x12eeb2c: add             x16, x4, w8, sxtw #1
    //     0x12eeb30: ldur            w9, [x16, #0xf]
    //     0x12eeb34: add             x9, x9, HEAP, lsl #32
    //     0x12eeb38: add             x16, PP, #0xab, lsl #12  ; [pp+0xab3c8] "gapPercentage"
    //     0x12eeb3c: ldr             x16, [x16, #0x3c8]
    //     0x12eeb40: cmp             w9, w16
    //     0x12eeb44: b.ne            #0x12eeb78
    //     0x12eeb48: add             w5, w7, #0xa
    //     0x12eeb4c: add             x16, x4, w5, sxtw #1
    //     0x12eeb50: ldur            w7, [x16, #0xf]
    //     0x12eeb54: add             x7, x7, HEAP, lsl #32
    //     0x12eeb58: sub             w5, w1, w7
    //     0x12eeb5c: add             x7, fp, w5, sxtw #2
    //     0x12eeb60: ldr             x7, [x7, #8]
    //     0x12eeb64: add             w5, w6, #2
    //     0x12eeb68: ldur            d1, [x7, #7]
    //     0x12eeb6c: sbfx            x6, x5, #1, #0x1f
    //     0x12eeb70: mov             x5, x6
    //     0x12eeb74: b               #0x12eeb7c
    //     0x12eeb78: eor             v1.16b, v1.16b, v1.16b
    //     0x12eeb7c: stur            d1, [fp, #-0x48]
    //     0x12eeb80: lsl             x6, x5, #1
    //     0x12eeb84: lsl             w7, w6, #1
    //     0x12eeb88: add             w8, w7, #8
    //     0x12eeb8c: add             x16, x4, w8, sxtw #1
    //     0x12eeb90: ldur            w9, [x16, #0xf]
    //     0x12eeb94: add             x9, x9, HEAP, lsl #32
    //     0x12eeb98: add             x16, PP, #0xab, lsl #12  ; [pp+0xab3d0] "gapStart"
    //     0x12eeb9c: ldr             x16, [x16, #0x3d0]
    //     0x12eeba0: cmp             w9, w16
    //     0x12eeba4: b.ne            #0x12eebd8
    //     0x12eeba8: add             w5, w7, #0xa
    //     0x12eebac: add             x16, x4, w5, sxtw #1
    //     0x12eebb0: ldur            w7, [x16, #0xf]
    //     0x12eebb4: add             x7, x7, HEAP, lsl #32
    //     0x12eebb8: sub             w5, w1, w7
    //     0x12eebbc: add             x7, fp, w5, sxtw #2
    //     0x12eebc0: ldr             x7, [x7, #8]
    //     0x12eebc4: add             w5, w6, #2
    //     0x12eebc8: sbfx            x6, x5, #1, #0x1f
    //     0x12eebcc: mov             x5, x6
    //     0x12eebd0: mov             x6, x7
    //     0x12eebd4: b               #0x12eebdc
    //     0x12eebd8: mov             x6, NULL
    //     0x12eebdc: stur            x6, [fp, #-0x18]
    //     0x12eebe0: lsl             x7, x5, #1
    //     0x12eebe4: lsl             w5, w7, #1
    //     0x12eebe8: add             w7, w5, #8
    //     0x12eebec: add             x16, x4, w7, sxtw #1
    //     0x12eebf0: ldur            w8, [x16, #0xf]
    //     0x12eebf4: add             x8, x8, HEAP, lsl #32
    //     0x12eebf8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15210] "textDirection"
    //     0x12eebfc: ldr             x16, [x16, #0x210]
    //     0x12eec00: cmp             w8, w16
    //     0x12eec04: b.ne            #0x12eec2c
    //     0x12eec08: add             w7, w5, #0xa
    //     0x12eec0c: add             x16, x4, w7, sxtw #1
    //     0x12eec10: ldur            w5, [x16, #0xf]
    //     0x12eec14: add             x5, x5, HEAP, lsl #32
    //     0x12eec18: sub             w4, w1, w5
    //     0x12eec1c: add             x1, fp, w4, sxtw #2
    //     0x12eec20: ldr             x1, [x1, #8]
    //     0x12eec24: mov             x4, x1
    //     0x12eec28: b               #0x12eec30
    //     0x12eec2c: mov             x4, NULL
    //     0x12eec30: stur            x4, [fp, #-0x10]
    // 0x12eec34: CheckStackOverflow
    //     0x12eec34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12eec38: cmp             SP, x16
    //     0x12eec3c: b.ls            #0x12eeea8
    // 0x12eec40: LoadField: r5 = r3->field_7
    //     0x12eec40: ldur            w5, [x3, #7]
    // 0x12eec44: DecompressPointer r5
    //     0x12eec44: add             x5, x5, HEAP, lsl #32
    // 0x12eec48: mov             x1, x5
    // 0x12eec4c: stur            x5, [fp, #-8]
    // 0x12eec50: r0 = toPaint()
    //     0x12eec50: bl              #0x12ed2c0  ; [package:flutter/src/painting/borders.dart] BorderSide::toPaint
    // 0x12eec54: mov             x3, x0
    // 0x12eec58: ldur            x0, [fp, #-0x20]
    // 0x12eec5c: stur            x3, [fp, #-0x38]
    // 0x12eec60: LoadField: r1 = r0->field_13
    //     0x12eec60: ldur            w1, [x0, #0x13]
    // 0x12eec64: DecompressPointer r1
    //     0x12eec64: add             x1, x1, HEAP, lsl #32
    // 0x12eec68: ldur            x2, [fp, #-0x30]
    // 0x12eec6c: r0 = toRRect()
    //     0x12eec6c: bl              #0xb77a10  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0x12eec70: mov             x2, x0
    // 0x12eec74: ldur            x0, [fp, #-8]
    // 0x12eec78: stur            x2, [fp, #-0x30]
    // 0x12eec7c: LoadField: d0 = r0->field_b
    //     0x12eec7c: ldur            d0, [x0, #0xb]
    // 0x12eec80: ArrayLoad: d1 = r0[0]  ; List_8
    //     0x12eec80: ldur            d1, [x0, #0x17]
    // 0x12eec84: fmul            d2, d0, d1
    // 0x12eec88: d1 = 2.000000
    //     0x12eec88: fmov            d1, #2.00000000
    // 0x12eec8c: fdiv            d0, d2, d1
    // 0x12eec90: mov             x1, x2
    // 0x12eec94: r0 = inflate()
    //     0x12eec94: bl              #0xb6daf4  ; [dart:ui] _RRectLike::inflate
    // 0x12eec98: mov             x4, x0
    // 0x12eec9c: ldur            x0, [fp, #-0x18]
    // 0x12eeca0: stur            x4, [fp, #-8]
    // 0x12eeca4: cmp             w0, NULL
    // 0x12eeca8: b.eq            #0x12eecc8
    // 0x12eecac: ldur            d0, [fp, #-0x50]
    // 0x12eecb0: d1 = 0.000000
    //     0x12eecb0: eor             v1.16b, v1.16b, v1.16b
    // 0x12eecb4: fcmp            d1, d0
    // 0x12eecb8: b.ge            #0x12eecc8
    // 0x12eecbc: ldur            d2, [fp, #-0x48]
    // 0x12eecc0: fcmp            d2, d1
    // 0x12eecc4: b.ne            #0x12eecdc
    // 0x12eecc8: ldur            x1, [fp, #-0x28]
    // 0x12eeccc: mov             x2, x4
    // 0x12eecd0: ldur            x3, [fp, #-0x38]
    // 0x12eecd4: r0 = drawRRect()
    //     0x12eecd4: bl              #0xb6dce0  ; [dart:ui] _NativeCanvas::drawRRect
    // 0x12eecd8: b               #0x12eee88
    // 0x12eecdc: ldur            x5, [fp, #-0x20]
    // 0x12eece0: ldur            x6, [fp, #-0x10]
    // 0x12eece4: d3 = 2.000000
    //     0x12eece4: fmov            d3, #2.00000000
    // 0x12eece8: LoadField: d4 = r5->field_b
    //     0x12eece8: ldur            d4, [x5, #0xb]
    // 0x12eecec: stur            d4, [fp, #-0x58]
    // 0x12eecf0: fmul            d5, d4, d3
    // 0x12eecf4: fadd            d3, d0, d5
    // 0x12eecf8: r3 = inline_Allocate_Double()
    //     0x12eecf8: ldp             x3, x1, [THR, #0x60]  ; THR::top
    //     0x12eecfc: add             x3, x3, #0x10
    //     0x12eed00: cmp             x1, x3
    //     0x12eed04: b.ls            #0x12eeeb0
    //     0x12eed08: str             x3, [THR, #0x60]  ; THR::top
    //     0x12eed0c: sub             x3, x3, #0xf
    //     0x12eed10: mov             x1, #0xe19c
    //     0x12eed14: movk            x1, #3, lsl #16
    //     0x12eed18: stur            x1, [x3, #-1]
    // 0x12eed1c: dmb             ishst
    // 0x12eed20: StoreField: r3->field_7 = d2
    //     0x12eed20: stur            d2, [x3, #7]
    // 0x12eed24: r2 = inline_Allocate_Double()
    //     0x12eed24: ldp             x2, x1, [THR, #0x60]  ; THR::top
    //     0x12eed28: add             x2, x2, #0x10
    //     0x12eed2c: cmp             x1, x2
    //     0x12eed30: b.ls            #0x12eeedc
    //     0x12eed34: str             x2, [THR, #0x60]  ; THR::top
    //     0x12eed38: sub             x2, x2, #0xf
    //     0x12eed3c: mov             x1, #0xe19c
    //     0x12eed40: movk            x1, #3, lsl #16
    //     0x12eed44: stur            x1, [x2, #-1]
    // 0x12eed48: dmb             ishst
    // 0x12eed4c: StoreField: r2->field_7 = d3
    //     0x12eed4c: stur            d3, [x2, #7]
    // 0x12eed50: r1 = 0.000000
    //     0x12eed50: ldr             x1, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0x12eed54: r0 = lerpDouble()
    //     0x12eed54: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x12eed58: mov             x1, x0
    // 0x12eed5c: ldur            x0, [fp, #-0x10]
    // 0x12eed60: LoadField: r2 = r0->field_7
    //     0x12eed60: ldur            x2, [x0, #7]
    // 0x12eed64: cmp             x2, #0
    // 0x12eed68: b.gt            #0x12eed88
    // 0x12eed6c: ldur            x0, [fp, #-0x18]
    // 0x12eed70: ldur            d0, [fp, #-0x58]
    // 0x12eed74: LoadField: d1 = r0->field_7
    //     0x12eed74: ldur            d1, [x0, #7]
    // 0x12eed78: fadd            d2, d1, d0
    // 0x12eed7c: LoadField: d0 = r1->field_7
    //     0x12eed7c: ldur            d0, [x1, #7]
    // 0x12eed80: fsub            d1, d2, d0
    // 0x12eed84: b               #0x12eed9c
    // 0x12eed88: ldur            x0, [fp, #-0x18]
    // 0x12eed8c: ldur            d0, [fp, #-0x58]
    // 0x12eed90: LoadField: d1 = r0->field_7
    //     0x12eed90: ldur            d1, [x0, #7]
    // 0x12eed94: fsub            d2, d1, d0
    // 0x12eed98: mov             v1.16b, v2.16b
    // 0x12eed9c: ldur            x4, [fp, #-0x28]
    // 0x12eeda0: ldur            x3, [fp, #-0x38]
    // 0x12eeda4: ldur            x0, [fp, #-0x30]
    // 0x12eeda8: d0 = 0.000000
    //     0x12eeda8: eor             v0.16b, v0.16b, v0.16b
    // 0x12eedac: LoadField: d2 = r0->field_1b
    //     0x12eedac: ldur            d2, [x0, #0x1b]
    // 0x12eedb0: LoadField: d3 = r0->field_b
    //     0x12eedb0: ldur            d3, [x0, #0xb]
    // 0x12eedb4: fsub            d4, d2, d3
    // 0x12eedb8: fmax            v2.2d, v0.2d, v1.2d
    // 0x12eedbc: LoadField: d0 = r1->field_7
    //     0x12eedbc: ldur            d0, [x1, #7]
    // 0x12eedc0: ldur            x1, [fp, #-0x20]
    // 0x12eedc4: ldur            x2, [fp, #-8]
    // 0x12eedc8: mov             v1.16b, v2.16b
    // 0x12eedcc: mov             v2.16b, v0.16b
    // 0x12eedd0: mov             v0.16b, v4.16b
    // 0x12eedd4: r0 = _gapBorderPath()
    //     0x12eedd4: bl              #0x12eef18  ; [package:flutter/src/material/input_border.dart] OutlineInputBorder::_gapBorderPath
    // 0x12eedd8: mov             x2, x0
    // 0x12eeddc: ldur            x0, [fp, #-0x38]
    // 0x12eede0: stur            x2, [fp, #-0x18]
    // 0x12eede4: LoadField: r3 = r0->field_b
    //     0x12eede4: ldur            w3, [x0, #0xb]
    // 0x12eede8: DecompressPointer r3
    //     0x12eede8: add             x3, x3, HEAP, lsl #32
    // 0x12eedec: stur            x3, [fp, #-0x10]
    // 0x12eedf0: LoadField: r5 = r0->field_7
    //     0x12eedf0: ldur            w5, [x0, #7]
    // 0x12eedf4: DecompressPointer r5
    //     0x12eedf4: add             x5, x5, HEAP, lsl #32
    // 0x12eedf8: ldur            x0, [fp, #-0x28]
    // 0x12eedfc: stur            x5, [fp, #-8]
    // 0x12eee00: LoadField: r1 = r0->field_7
    //     0x12eee00: ldur            w1, [x0, #7]
    // 0x12eee04: DecompressPointer r1
    //     0x12eee04: add             x1, x1, HEAP, lsl #32
    // 0x12eee08: cmp             w1, NULL
    // 0x12eee0c: b.eq            #0x12eef10
    // 0x12eee10: LoadField: r4 = r1->field_7
    //     0x12eee10: ldur            x4, [x1, #7]
    // 0x12eee14: ldr             x1, [x4]
    // 0x12eee18: cbz             x1, #0x12eee98
    // 0x12eee1c: mov             x4, x1
    // 0x12eee20: stur            x4, [fp, #-0x40]
    // 0x12eee24: r1 = <Never>
    //     0x12eee24: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12eee28: r0 = Pointer()
    //     0x12eee28: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12eee2c: mov             x2, x0
    // 0x12eee30: ldur            x0, [fp, #-0x40]
    // 0x12eee34: stur            x2, [fp, #-0x20]
    // 0x12eee38: StoreField: r2->field_7 = r0
    //     0x12eee38: stur            x0, [x2, #7]
    // 0x12eee3c: ldur            x0, [fp, #-0x18]
    // 0x12eee40: LoadField: r1 = r0->field_7
    //     0x12eee40: ldur            w1, [x0, #7]
    // 0x12eee44: DecompressPointer r1
    //     0x12eee44: add             x1, x1, HEAP, lsl #32
    // 0x12eee48: cmp             w1, NULL
    // 0x12eee4c: b.eq            #0x12eef14
    // 0x12eee50: LoadField: r3 = r1->field_7
    //     0x12eee50: ldur            x3, [x1, #7]
    // 0x12eee54: ldr             x1, [x3]
    // 0x12eee58: mov             x3, x1
    // 0x12eee5c: stur            x3, [fp, #-0x40]
    // 0x12eee60: r1 = <Never>
    //     0x12eee60: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12eee64: r0 = Pointer()
    //     0x12eee64: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12eee68: mov             x1, x0
    // 0x12eee6c: ldur            x0, [fp, #-0x40]
    // 0x12eee70: StoreField: r1->field_7 = r0
    //     0x12eee70: stur            x0, [x1, #7]
    // 0x12eee74: mov             x2, x1
    // 0x12eee78: ldur            x1, [fp, #-0x20]
    // 0x12eee7c: ldur            x3, [fp, #-0x10]
    // 0x12eee80: ldur            x5, [fp, #-8]
    // 0x12eee84: r0 = __drawPath$Method$FfiNative()
    //     0x12eee84: bl              #0xb69a00  ; [dart:ui] _NativeCanvas::__drawPath$Method$FfiNative
    // 0x12eee88: r0 = Null
    //     0x12eee88: mov             x0, NULL
    // 0x12eee8c: LeaveFrame
    //     0x12eee8c: mov             SP, fp
    //     0x12eee90: ldp             fp, lr, [SP], #0x10
    // 0x12eee94: ret
    //     0x12eee94: ret             
    // 0x12eee98: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12eee98: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12eee9c: str             x16, [SP]
    // 0x12eeea0: r0 = _throwNew()
    //     0x12eeea0: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12eeea4: brk             #0
    // 0x12eeea8: r0 = StackOverflowSharedWithFPURegs()
    //     0x12eeea8: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12eeeac: b               #0x12eec40
    // 0x12eeeb0: stp             q3, q4, [SP, #-0x20]!
    // 0x12eeeb4: stp             q1, q2, [SP, #-0x20]!
    // 0x12eeeb8: stp             x5, x6, [SP, #-0x10]!
    // 0x12eeebc: stp             x0, x4, [SP, #-0x10]!
    // 0x12eeec0: r0 = AllocateDouble()
    //     0x12eeec0: bl              #0x13df878  ; AllocateDoubleStub
    // 0x12eeec4: mov             x3, x0
    // 0x12eeec8: ldp             x0, x4, [SP], #0x10
    // 0x12eeecc: ldp             x5, x6, [SP], #0x10
    // 0x12eeed0: ldp             q1, q2, [SP], #0x20
    // 0x12eeed4: ldp             q3, q4, [SP], #0x20
    // 0x12eeed8: b               #0x12eed20
    // 0x12eeedc: stp             q3, q4, [SP, #-0x20]!
    // 0x12eeee0: SaveReg d1
    //     0x12eeee0: str             q1, [SP, #-0x10]!
    // 0x12eeee4: stp             x5, x6, [SP, #-0x10]!
    // 0x12eeee8: stp             x3, x4, [SP, #-0x10]!
    // 0x12eeeec: SaveReg r0
    //     0x12eeeec: str             x0, [SP, #-8]!
    // 0x12eeef0: r0 = AllocateDouble()
    //     0x12eeef0: bl              #0x13df878  ; AllocateDoubleStub
    // 0x12eeef4: mov             x2, x0
    // 0x12eeef8: RestoreReg r0
    //     0x12eeef8: ldr             x0, [SP], #8
    // 0x12eeefc: ldp             x3, x4, [SP], #0x10
    // 0x12eef00: ldp             x5, x6, [SP], #0x10
    // 0x12eef04: RestoreReg d1
    //     0x12eef04: ldr             q1, [SP], #0x10
    // 0x12eef08: ldp             q3, q4, [SP], #0x20
    // 0x12eef0c: b               #0x12eed4c
    // 0x12eef10: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12eef10: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12eef14: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12eef14: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ _gapBorderPath(/* No info */) {
    // ** addr: 0x12eef18, size: 0xad4
    // 0x12eef18: EnterFrame
    //     0x12eef18: stp             fp, lr, [SP, #-0x10]!
    //     0x12eef1c: mov             fp, SP
    // 0x12eef20: AllocStack(0x108)
    //     0x12eef20: sub             SP, SP, #0x108
    // 0x12eef24: SetupParameters(OutlineInputBorder this /* r1 => r0, fp-0x30 */, dynamic _ /* r2 => r1 */, dynamic _ /* d0 => d1, fp-0x20 */, dynamic _ /* d1 => d0, fp-0x28 */)
    //     0x12eef24: mov             x0, x1
    //     0x12eef28: stur            x1, [fp, #-8]
    //     0x12eef2c: mov             x1, x2
    //     0x12eef30: stur            d0, [fp, #-0x20]
    //     0x12eef34: mov             v31.16b, v1.16b
    //     0x12eef38: mov             v1.16b, v0.16b
    //     0x12eef3c: mov             v0.16b, v31.16b
    //     0x12eef40: stur            d0, [fp, #-0x28]
    //     0x12eef44: stur            d2, [fp, #-0x30]
    // 0x12eef48: CheckStackOverflow
    //     0x12eef48: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12eef4c: cmp             SP, x16
    //     0x12eef50: b.ls            #0x12ef9b0
    // 0x12eef54: r0 = scaleRadii()
    //     0x12eef54: bl              #0xaf8eac  ; [dart:ui] _RRectLike::scaleRadii
    // 0x12eef58: LoadField: d0 = r0->field_b
    //     0x12eef58: ldur            d0, [x0, #0xb]
    // 0x12eef5c: stur            d0, [fp, #-0xf0]
    // 0x12eef60: LoadField: d1 = r0->field_13
    //     0x12eef60: ldur            d1, [x0, #0x13]
    // 0x12eef64: stur            d1, [fp, #-0xe8]
    // 0x12eef68: LoadField: d2 = r0->field_2b
    //     0x12eef68: ldur            d2, [x0, #0x2b]
    // 0x12eef6c: stur            d2, [fp, #-0xe0]
    // 0x12eef70: d3 = 2.000000
    //     0x12eef70: fmov            d3, #2.00000000
    // 0x12eef74: fmul            d4, d2, d3
    // 0x12eef78: LoadField: d5 = r0->field_33
    //     0x12eef78: ldur            d5, [x0, #0x33]
    // 0x12eef7c: stur            d5, [fp, #-0xd8]
    // 0x12eef80: fmul            d6, d5, d3
    // 0x12eef84: fadd            d7, d0, d4
    // 0x12eef88: stur            d7, [fp, #-0xd0]
    // 0x12eef8c: fadd            d4, d1, d6
    // 0x12eef90: stur            d4, [fp, #-0xc8]
    // 0x12eef94: LoadField: d6 = r0->field_1b
    //     0x12eef94: ldur            d6, [x0, #0x1b]
    // 0x12eef98: stur            d6, [fp, #-0xc0]
    // 0x12eef9c: LoadField: d8 = r0->field_3b
    //     0x12eef9c: ldur            d8, [x0, #0x3b]
    // 0x12eefa0: stur            d8, [fp, #-0xb8]
    // 0x12eefa4: fmul            d9, d8, d3
    // 0x12eefa8: fsub            d10, d6, d9
    // 0x12eefac: stur            d10, [fp, #-0xb0]
    // 0x12eefb0: LoadField: d11 = r0->field_43
    //     0x12eefb0: ldur            d11, [x0, #0x43]
    // 0x12eefb4: stur            d11, [fp, #-0xa8]
    // 0x12eefb8: fmul            d12, d11, d3
    // 0x12eefbc: fadd            d13, d10, d9
    // 0x12eefc0: stur            d13, [fp, #-0xa0]
    // 0x12eefc4: fadd            d9, d1, d12
    // 0x12eefc8: stur            d9, [fp, #-0x98]
    // 0x12eefcc: LoadField: d12 = r0->field_4b
    //     0x12eefcc: ldur            d12, [x0, #0x4b]
    // 0x12eefd0: stur            d12, [fp, #-0x90]
    // 0x12eefd4: fmul            d14, d12, d3
    // 0x12eefd8: fsub            d15, d6, d14
    // 0x12eefdc: stur            d15, [fp, #-0x88]
    // 0x12eefe0: LoadField: d16 = r0->field_23
    //     0x12eefe0: ldur            d16, [x0, #0x23]
    // 0x12eefe4: stur            d16, [fp, #-0x80]
    // 0x12eefe8: LoadField: d17 = r0->field_53
    //     0x12eefe8: ldur            d17, [x0, #0x53]
    // 0x12eefec: stur            d17, [fp, #-0x78]
    // 0x12eeff0: fmul            d18, d17, d3
    // 0x12eeff4: fsub            d19, d16, d18
    // 0x12eeff8: stur            d19, [fp, #-0x70]
    // 0x12eeffc: fadd            d20, d15, d14
    // 0x12ef000: stur            d20, [fp, #-0x68]
    // 0x12ef004: fadd            d14, d19, d18
    // 0x12ef008: stur            d14, [fp, #-0x60]
    // 0x12ef00c: LoadField: d18 = r0->field_63
    //     0x12ef00c: ldur            d18, [x0, #0x63]
    // 0x12ef010: stur            d18, [fp, #-0x58]
    // 0x12ef014: fmul            d21, d18, d3
    // 0x12ef018: fsub            d22, d16, d21
    // 0x12ef01c: stur            d22, [fp, #-0x50]
    // 0x12ef020: LoadField: d23 = r0->field_5b
    //     0x12ef020: ldur            d23, [x0, #0x5b]
    // 0x12ef024: stur            d23, [fp, #-0x48]
    // 0x12ef028: fmul            d24, d23, d3
    // 0x12ef02c: fadd            d25, d0, d24
    // 0x12ef030: stur            d25, [fp, #-0x40]
    // 0x12ef034: fadd            d24, d22, d21
    // 0x12ef038: stur            d24, [fp, #-0x38]
    // 0x12ef03c: r0 = _NativePath()
    //     0x12ef03c: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0x12ef040: mov             x1, x0
    // 0x12ef044: stur            x0, [fp, #-0x10]
    // 0x12ef048: r0 = __constructor$Method$FfiNative()
    //     0x12ef048: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0x12ef04c: r0 = Radius()
    //     0x12ef04c: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x12ef050: ldur            d0, [fp, #-0xe0]
    // 0x12ef054: StoreField: r0->field_7 = d0
    //     0x12ef054: stur            d0, [x0, #7]
    // 0x12ef058: ldur            d1, [fp, #-0xd8]
    // 0x12ef05c: StoreField: r0->field_f = d1
    //     0x12ef05c: stur            d1, [x0, #0xf]
    // 0x12ef060: r16 = Instance_Radius
    //     0x12ef060: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12ef064: ldr             x16, [x16, #0x1a0]
    // 0x12ef068: cmp             w0, w16
    // 0x12ef06c: b.ne            #0x12ef07c
    // 0x12ef070: r0 = Instance_Radius
    //     0x12ef070: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12ef074: ldr             x0, [x0, #0x1a0]
    // 0x12ef078: b               #0x12ef0c0
    // 0x12ef07c: r16 = Radius
    //     0x12ef07c: add             x16, PP, #0x26, lsl #12  ; [pp+0x26960] Type: Radius
    //     0x12ef080: ldr             x16, [x16, #0x960]
    // 0x12ef084: r30 = Radius
    //     0x12ef084: add             lr, PP, #0x26, lsl #12  ; [pp+0x26960] Type: Radius
    //     0x12ef088: ldr             lr, [lr, #0x960]
    // 0x12ef08c: stp             lr, x16, [SP]
    // 0x12ef090: r0 = ==()
    //     0x12ef090: bl              #0x12b7fbc  ; [dart:core] _Type::==
    // 0x12ef094: tbnz            w0, #4, #0x12ef138
    // 0x12ef098: ldur            d0, [fp, #-0xe0]
    // 0x12ef09c: r0 = Instance_Radius
    //     0x12ef09c: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12ef0a0: ldr             x0, [x0, #0x1a0]
    // 0x12ef0a4: LoadField: d1 = r0->field_7
    //     0x12ef0a4: ldur            d1, [x0, #7]
    // 0x12ef0a8: fcmp            d1, d0
    // 0x12ef0ac: b.ne            #0x12ef138
    // 0x12ef0b0: ldur            d1, [fp, #-0xd8]
    // 0x12ef0b4: LoadField: d2 = r0->field_f
    //     0x12ef0b4: ldur            d2, [x0, #0xf]
    // 0x12ef0b8: fcmp            d2, d1
    // 0x12ef0bc: b.ne            #0x12ef138
    // 0x12ef0c0: ldur            x1, [fp, #-8]
    // 0x12ef0c4: ldur            d2, [fp, #-0xf0]
    // 0x12ef0c8: ldur            x2, [fp, #-0x10]
    // 0x12ef0cc: d3 = 2.000000
    //     0x12ef0cc: fmov            d3, #2.00000000
    // 0x12ef0d0: LoadField: r3 = r1->field_7
    //     0x12ef0d0: ldur            w3, [x1, #7]
    // 0x12ef0d4: DecompressPointer r3
    //     0x12ef0d4: add             x3, x3, HEAP, lsl #32
    // 0x12ef0d8: LoadField: d4 = r3->field_b
    //     0x12ef0d8: ldur            d4, [x3, #0xb]
    // 0x12ef0dc: ArrayLoad: d5 = r3[0]  ; List_8
    //     0x12ef0dc: ldur            d5, [x3, #0x17]
    // 0x12ef0e0: fmul            d6, d4, d5
    // 0x12ef0e4: fdiv            d4, d6, d3
    // 0x12ef0e8: fadd            d3, d2, d4
    // 0x12ef0ec: stur            d3, [fp, #-0xf8]
    // 0x12ef0f0: LoadField: r1 = r2->field_7
    //     0x12ef0f0: ldur            w1, [x2, #7]
    // 0x12ef0f4: DecompressPointer r1
    //     0x12ef0f4: add             x1, x1, HEAP, lsl #32
    // 0x12ef0f8: cmp             w1, NULL
    // 0x12ef0fc: b.eq            #0x12ef9b8
    // 0x12ef100: LoadField: r3 = r1->field_7
    //     0x12ef100: ldur            x3, [x1, #7]
    // 0x12ef104: ldr             x1, [x3]
    // 0x12ef108: cbz             x1, #0x12ef8e0
    // 0x12ef10c: mov             x3, x1
    // 0x12ef110: stur            x3, [fp, #-0x18]
    // 0x12ef114: r1 = <Never>
    //     0x12ef114: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12ef118: r0 = Pointer()
    //     0x12ef118: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12ef11c: mov             x1, x0
    // 0x12ef120: ldur            x0, [fp, #-0x18]
    // 0x12ef124: StoreField: r1->field_7 = r0
    //     0x12ef124: stur            x0, [x1, #7]
    // 0x12ef128: ldur            d0, [fp, #-0xf8]
    // 0x12ef12c: ldur            d1, [fp, #-0xe8]
    // 0x12ef130: r0 = _moveTo$Method$FfiNative()
    //     0x12ef130: bl              #0xb69c74  ; [dart:ui] _NativePath::_moveTo$Method$FfiNative
    // 0x12ef134: b               #0x12ef214
    // 0x12ef138: ldur            d2, [fp, #-0x28]
    // 0x12ef13c: ldur            d1, [fp, #-0xe0]
    // 0x12ef140: d3 = 1.000000
    //     0x12ef140: fmov            d3, #1.00000000
    // 0x12ef144: d4 = 0.000000
    //     0x12ef144: eor             v4.16b, v4.16b, v4.16b
    // 0x12ef148: fdiv            d0, d2, d1
    // 0x12ef14c: fsub            d5, d3, d0
    // 0x12ef150: fcmp            d4, d5
    // 0x12ef154: b.le            #0x12ef160
    // 0x12ef158: d0 = 0.000000
    //     0x12ef158: eor             v0.16b, v0.16b, v0.16b
    // 0x12ef15c: b               #0x12ef184
    // 0x12ef160: fcmp            d5, d3
    // 0x12ef164: b.le            #0x12ef170
    // 0x12ef168: d0 = 1.000000
    //     0x12ef168: fmov            d0, #1.00000000
    // 0x12ef16c: b               #0x12ef184
    // 0x12ef170: fcmp            d5, d5
    // 0x12ef174: b.vc            #0x12ef180
    // 0x12ef178: d0 = 1.000000
    //     0x12ef178: fmov            d0, #1.00000000
    // 0x12ef17c: b               #0x12ef184
    // 0x12ef180: mov             v0.16b, v5.16b
    // 0x12ef184: ldur            x19, [fp, #-0x10]
    // 0x12ef188: stp             fp, lr, [SP, #-0x10]!
    // 0x12ef18c: mov             fp, SP
    // 0x12ef190: CallRuntime_LibcAcos(double) -> double
    //     0x12ef190: and             SP, SP, #0xfffffffffffffff0
    //     0x12ef194: mov             sp, SP
    //     0x12ef198: ldr             x16, [THR, #0x790]  ; THR::LibcAcos
    //     0x12ef19c: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x12ef1a0: blr             x16
    //     0x12ef1a4: mov             x16, #8
    //     0x12ef1a8: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x12ef1ac: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x12ef1b0: sub             sp, x16, #1, lsl #12
    //     0x12ef1b4: mov             SP, fp
    //     0x12ef1b8: ldp             fp, lr, [SP], #0x10
    // 0x12ef1bc: stur            d0, [fp, #-0xf8]
    // 0x12ef1c0: LoadField: r0 = r19->field_7
    //     0x12ef1c0: ldur            w0, [x19, #7]
    // 0x12ef1c4: DecompressPointer r0
    //     0x12ef1c4: add             x0, x0, HEAP, lsl #32
    // 0x12ef1c8: cmp             w0, NULL
    // 0x12ef1cc: b.eq            #0x12ef9bc
    // 0x12ef1d0: LoadField: r1 = r0->field_7
    //     0x12ef1d0: ldur            x1, [x0, #7]
    // 0x12ef1d4: ldr             x0, [x1]
    // 0x12ef1d8: cbz             x0, #0x12ef8f0
    // 0x12ef1dc: stur            x0, [fp, #-0x18]
    // 0x12ef1e0: r1 = <Never>
    //     0x12ef1e0: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12ef1e4: r0 = Pointer()
    //     0x12ef1e4: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12ef1e8: mov             x1, x0
    // 0x12ef1ec: ldur            x0, [fp, #-0x18]
    // 0x12ef1f0: StoreField: r1->field_7 = r0
    //     0x12ef1f0: stur            x0, [x1, #7]
    // 0x12ef1f4: ldur            d0, [fp, #-0xf0]
    // 0x12ef1f8: ldur            d1, [fp, #-0xe8]
    // 0x12ef1fc: ldur            d2, [fp, #-0xd0]
    // 0x12ef200: ldur            d3, [fp, #-0xc8]
    // 0x12ef204: ldur            d5, [fp, #-0xf8]
    // 0x12ef208: d4 = 3.141593
    //     0x12ef208: add             x17, PP, #0x13, lsl #12  ; [pp+0x13178] IMM: double(3.141592653589793) from 0x400921fb54442d18
    //     0x12ef20c: ldr             d4, [x17, #0x178]
    // 0x12ef210: r0 = __addArc$Method$FfiNative()
    //     0x12ef210: bl              #0xb836a8  ; [dart:ui] _NativePath::__addArc$Method$FfiNative
    // 0x12ef214: ldur            d1, [fp, #-0x28]
    // 0x12ef218: ldur            d0, [fp, #-0xe0]
    // 0x12ef21c: fcmp            d1, d0
    // 0x12ef220: b.le            #0x12ef26c
    // 0x12ef224: ldur            x0, [fp, #-0x10]
    // 0x12ef228: LoadField: r1 = r0->field_7
    //     0x12ef228: ldur            w1, [x0, #7]
    // 0x12ef22c: DecompressPointer r1
    //     0x12ef22c: add             x1, x1, HEAP, lsl #32
    // 0x12ef230: cmp             w1, NULL
    // 0x12ef234: b.eq            #0x12ef9c0
    // 0x12ef238: LoadField: r2 = r1->field_7
    //     0x12ef238: ldur            x2, [x1, #7]
    // 0x12ef23c: ldr             x1, [x2]
    // 0x12ef240: cbz             x1, #0x12ef900
    // 0x12ef244: mov             x2, x1
    // 0x12ef248: stur            x2, [fp, #-0x18]
    // 0x12ef24c: r1 = <Never>
    //     0x12ef24c: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12ef250: r0 = Pointer()
    //     0x12ef250: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12ef254: mov             x1, x0
    // 0x12ef258: ldur            x0, [fp, #-0x18]
    // 0x12ef25c: StoreField: r1->field_7 = r0
    //     0x12ef25c: stur            x0, [x1, #7]
    // 0x12ef260: ldur            d0, [fp, #-0x28]
    // 0x12ef264: ldur            d1, [fp, #-0xe8]
    // 0x12ef268: r0 = _lineTo$Method$FfiNative()
    //     0x12ef268: bl              #0xb69bd0  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x12ef26c: ldur            d3, [fp, #-0x20]
    // 0x12ef270: ldur            d0, [fp, #-0x28]
    // 0x12ef274: ldur            d2, [fp, #-0x30]
    // 0x12ef278: ldur            d1, [fp, #-0xb8]
    // 0x12ef27c: fadd            d4, d0, d2
    // 0x12ef280: stur            d4, [fp, #-0xc8]
    // 0x12ef284: fsub            d0, d3, d1
    // 0x12ef288: fcmp            d0, d4
    // 0x12ef28c: b.le            #0x12ef42c
    // 0x12ef290: ldur            x0, [fp, #-0x10]
    // 0x12ef294: LoadField: r1 = r0->field_7
    //     0x12ef294: ldur            w1, [x0, #7]
    // 0x12ef298: DecompressPointer r1
    //     0x12ef298: add             x1, x1, HEAP, lsl #32
    // 0x12ef29c: cmp             w1, NULL
    // 0x12ef2a0: b.eq            #0x12ef9c4
    // 0x12ef2a4: LoadField: r2 = r1->field_7
    //     0x12ef2a4: ldur            x2, [x1, #7]
    // 0x12ef2a8: ldr             x1, [x2]
    // 0x12ef2ac: cbz             x1, #0x12ef910
    // 0x12ef2b0: ldur            d0, [fp, #-0xc0]
    // 0x12ef2b4: mov             x2, x1
    // 0x12ef2b8: stur            x2, [fp, #-0x18]
    // 0x12ef2bc: r1 = <Never>
    //     0x12ef2bc: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12ef2c0: r0 = Pointer()
    //     0x12ef2c0: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12ef2c4: mov             x1, x0
    // 0x12ef2c8: ldur            x0, [fp, #-0x18]
    // 0x12ef2cc: StoreField: r1->field_7 = r0
    //     0x12ef2cc: stur            x0, [x1, #7]
    // 0x12ef2d0: ldur            d0, [fp, #-0xc8]
    // 0x12ef2d4: ldur            d1, [fp, #-0xe8]
    // 0x12ef2d8: r0 = _moveTo$Method$FfiNative()
    //     0x12ef2d8: bl              #0xb69c74  ; [dart:ui] _NativePath::_moveTo$Method$FfiNative
    // 0x12ef2dc: ldur            d1, [fp, #-0xc0]
    // 0x12ef2e0: ldur            d0, [fp, #-0xb8]
    // 0x12ef2e4: fsub            d2, d1, d0
    // 0x12ef2e8: ldur            x0, [fp, #-0x10]
    // 0x12ef2ec: stur            d2, [fp, #-0x28]
    // 0x12ef2f0: LoadField: r1 = r0->field_7
    //     0x12ef2f0: ldur            w1, [x0, #7]
    // 0x12ef2f4: DecompressPointer r1
    //     0x12ef2f4: add             x1, x1, HEAP, lsl #32
    // 0x12ef2f8: cmp             w1, NULL
    // 0x12ef2fc: b.eq            #0x12ef9c8
    // 0x12ef300: LoadField: r2 = r1->field_7
    //     0x12ef300: ldur            x2, [x1, #7]
    // 0x12ef304: ldr             x1, [x2]
    // 0x12ef308: cbz             x1, #0x12ef920
    // 0x12ef30c: ldur            d3, [fp, #-0xa8]
    // 0x12ef310: mov             x2, x1
    // 0x12ef314: stur            x2, [fp, #-0x18]
    // 0x12ef318: r1 = <Never>
    //     0x12ef318: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12ef31c: r0 = Pointer()
    //     0x12ef31c: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12ef320: mov             x1, x0
    // 0x12ef324: ldur            x0, [fp, #-0x18]
    // 0x12ef328: StoreField: r1->field_7 = r0
    //     0x12ef328: stur            x0, [x1, #7]
    // 0x12ef32c: ldur            d0, [fp, #-0x28]
    // 0x12ef330: ldur            d1, [fp, #-0xe8]
    // 0x12ef334: r0 = _lineTo$Method$FfiNative()
    //     0x12ef334: bl              #0xb69bd0  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x12ef338: r0 = Radius()
    //     0x12ef338: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x12ef33c: ldur            d0, [fp, #-0xb8]
    // 0x12ef340: StoreField: r0->field_7 = d0
    //     0x12ef340: stur            d0, [x0, #7]
    // 0x12ef344: ldur            d1, [fp, #-0xa8]
    // 0x12ef348: StoreField: r0->field_f = d1
    //     0x12ef348: stur            d1, [x0, #0xf]
    // 0x12ef34c: r16 = Instance_Radius
    //     0x12ef34c: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12ef350: ldr             x16, [x16, #0x1a0]
    // 0x12ef354: cmp             w0, w16
    // 0x12ef358: b.ne            #0x12ef36c
    // 0x12ef35c: mov             v0.16b, v1.16b
    // 0x12ef360: r0 = Instance_Radius
    //     0x12ef360: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12ef364: ldr             x0, [x0, #0x1a0]
    // 0x12ef368: b               #0x12ef528
    // 0x12ef36c: r16 = Radius
    //     0x12ef36c: add             x16, PP, #0x26, lsl #12  ; [pp+0x26960] Type: Radius
    //     0x12ef370: ldr             x16, [x16, #0x960]
    // 0x12ef374: r30 = Radius
    //     0x12ef374: add             lr, PP, #0x26, lsl #12  ; [pp+0x26960] Type: Radius
    //     0x12ef378: ldr             lr, [lr, #0x960]
    // 0x12ef37c: stp             lr, x16, [SP]
    // 0x12ef380: r0 = ==()
    //     0x12ef380: bl              #0x12b7fbc  ; [dart:core] _Type::==
    // 0x12ef384: tbz             w0, #4, #0x12ef398
    // 0x12ef388: ldur            d0, [fp, #-0xa8]
    // 0x12ef38c: r0 = Instance_Radius
    //     0x12ef38c: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12ef390: ldr             x0, [x0, #0x1a0]
    // 0x12ef394: b               #0x12ef3c8
    // 0x12ef398: ldur            d0, [fp, #-0xb8]
    // 0x12ef39c: r0 = Instance_Radius
    //     0x12ef39c: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12ef3a0: ldr             x0, [x0, #0x1a0]
    // 0x12ef3a4: LoadField: d1 = r0->field_7
    //     0x12ef3a4: ldur            d1, [x0, #7]
    // 0x12ef3a8: fcmp            d1, d0
    // 0x12ef3ac: b.ne            #0x12ef3c4
    // 0x12ef3b0: ldur            d0, [fp, #-0xa8]
    // 0x12ef3b4: LoadField: d1 = r0->field_f
    //     0x12ef3b4: ldur            d1, [x0, #0xf]
    // 0x12ef3b8: fcmp            d1, d0
    // 0x12ef3bc: b.eq            #0x12ef528
    // 0x12ef3c0: b               #0x12ef3c8
    // 0x12ef3c4: ldur            d0, [fp, #-0xa8]
    // 0x12ef3c8: ldur            x2, [fp, #-0x10]
    // 0x12ef3cc: LoadField: r1 = r2->field_7
    //     0x12ef3cc: ldur            w1, [x2, #7]
    // 0x12ef3d0: DecompressPointer r1
    //     0x12ef3d0: add             x1, x1, HEAP, lsl #32
    // 0x12ef3d4: cmp             w1, NULL
    // 0x12ef3d8: b.eq            #0x12ef9cc
    // 0x12ef3dc: LoadField: r3 = r1->field_7
    //     0x12ef3dc: ldur            x3, [x1, #7]
    // 0x12ef3e0: ldr             x1, [x3]
    // 0x12ef3e4: cbz             x1, #0x12ef930
    // 0x12ef3e8: mov             x3, x1
    // 0x12ef3ec: stur            x3, [fp, #-0x18]
    // 0x12ef3f0: r1 = <Never>
    //     0x12ef3f0: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12ef3f4: r0 = Pointer()
    //     0x12ef3f4: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12ef3f8: mov             x1, x0
    // 0x12ef3fc: ldur            x0, [fp, #-0x18]
    // 0x12ef400: StoreField: r1->field_7 = r0
    //     0x12ef400: stur            x0, [x1, #7]
    // 0x12ef404: ldur            d0, [fp, #-0xb0]
    // 0x12ef408: ldur            d1, [fp, #-0xe8]
    // 0x12ef40c: ldur            d2, [fp, #-0xa0]
    // 0x12ef410: ldur            d3, [fp, #-0x98]
    // 0x12ef414: d4 = 4.712389
    //     0x12ef414: add             x17, PP, #0xa2, lsl #12  ; [pp+0xa2058] IMM: double(4.71238898038469) from 0x4012d97c7f3321d2
    //     0x12ef418: ldr             d4, [x17, #0x58]
    // 0x12ef41c: d5 = 1.570796
    //     0x12ef41c: add             x17, PP, #0x95, lsl #12  ; [pp+0x95ed8] IMM: double(1.5707963267948966) from 0x3ff921fb54442d18
    //     0x12ef420: ldr             d5, [x17, #0xed8]
    // 0x12ef424: r0 = __addArc$Method$FfiNative()
    //     0x12ef424: bl              #0xb836a8  ; [dart:ui] _NativePath::__addArc$Method$FfiNative
    // 0x12ef428: b               #0x12ef528
    // 0x12ef42c: mov             v0.16b, v1.16b
    // 0x12ef430: mov             v1.16b, v4.16b
    // 0x12ef434: fcmp            d3, d1
    // 0x12ef438: b.le            #0x12ef528
    // 0x12ef43c: d2 = 1.000000
    //     0x12ef43c: fmov            d2, #1.00000000
    // 0x12ef440: d4 = 0.000000
    //     0x12ef440: eor             v4.16b, v4.16b, v4.16b
    // 0x12ef444: fsub            d5, d3, d1
    // 0x12ef448: fdiv            d1, d5, d0
    // 0x12ef44c: fsub            d0, d2, d1
    // 0x12ef450: fcmp            d4, d0
    // 0x12ef454: b.le            #0x12ef460
    // 0x12ef458: d0 = 0.000000
    //     0x12ef458: eor             v0.16b, v0.16b, v0.16b
    // 0x12ef45c: b               #0x12ef47c
    // 0x12ef460: fcmp            d0, d2
    // 0x12ef464: b.le            #0x12ef470
    // 0x12ef468: d0 = 1.000000
    //     0x12ef468: fmov            d0, #1.00000000
    // 0x12ef46c: b               #0x12ef47c
    // 0x12ef470: fcmp            d0, d0
    // 0x12ef474: b.vc            #0x12ef47c
    // 0x12ef478: d0 = 1.000000
    //     0x12ef478: fmov            d0, #1.00000000
    // 0x12ef47c: ldur            x19, [fp, #-0x10]
    // 0x12ef480: stp             fp, lr, [SP, #-0x10]!
    // 0x12ef484: mov             fp, SP
    // 0x12ef488: CallRuntime_LibcAsin(double) -> double
    //     0x12ef488: and             SP, SP, #0xfffffffffffffff0
    //     0x12ef48c: mov             sp, SP
    //     0x12ef490: ldr             x16, [THR, #0x798]  ; THR::LibcAsin
    //     0x12ef494: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x12ef498: blr             x16
    //     0x12ef49c: mov             x16, #8
    //     0x12ef4a0: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x12ef4a4: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x12ef4a8: sub             sp, x16, #1, lsl #12
    //     0x12ef4ac: mov             SP, fp
    //     0x12ef4b0: ldp             fp, lr, [SP], #0x10
    // 0x12ef4b4: mov             v1.16b, v0.16b
    // 0x12ef4b8: d0 = 4.712389
    //     0x12ef4b8: add             x17, PP, #0xa2, lsl #12  ; [pp+0xa2058] IMM: double(4.71238898038469) from 0x4012d97c7f3321d2
    //     0x12ef4bc: ldr             d0, [x17, #0x58]
    // 0x12ef4c0: fadd            d4, d1, d0
    // 0x12ef4c4: stur            d4, [fp, #-0x28]
    // 0x12ef4c8: d5 = 1.570796
    //     0x12ef4c8: add             x17, PP, #0x95, lsl #12  ; [pp+0x95ed8] IMM: double(1.5707963267948966) from 0x3ff921fb54442d18
    //     0x12ef4cc: ldr             d5, [x17, #0xed8]
    // 0x12ef4d0: fsub            d0, d5, d1
    // 0x12ef4d4: stur            d0, [fp, #-0x20]
    // 0x12ef4d8: LoadField: r0 = r19->field_7
    //     0x12ef4d8: ldur            w0, [x19, #7]
    // 0x12ef4dc: DecompressPointer r0
    //     0x12ef4dc: add             x0, x0, HEAP, lsl #32
    // 0x12ef4e0: cmp             w0, NULL
    // 0x12ef4e4: b.eq            #0x12ef9d0
    // 0x12ef4e8: LoadField: r1 = r0->field_7
    //     0x12ef4e8: ldur            x1, [x0, #7]
    // 0x12ef4ec: ldr             x0, [x1]
    // 0x12ef4f0: cbz             x0, #0x12ef940
    // 0x12ef4f4: stur            x0, [fp, #-0x18]
    // 0x12ef4f8: r1 = <Never>
    //     0x12ef4f8: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12ef4fc: r0 = Pointer()
    //     0x12ef4fc: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12ef500: mov             x1, x0
    // 0x12ef504: ldur            x0, [fp, #-0x18]
    // 0x12ef508: StoreField: r1->field_7 = r0
    //     0x12ef508: stur            x0, [x1, #7]
    // 0x12ef50c: ldur            d0, [fp, #-0xb0]
    // 0x12ef510: ldur            d1, [fp, #-0xe8]
    // 0x12ef514: ldur            d2, [fp, #-0xa0]
    // 0x12ef518: ldur            d3, [fp, #-0x98]
    // 0x12ef51c: ldur            d4, [fp, #-0x28]
    // 0x12ef520: ldur            d5, [fp, #-0x20]
    // 0x12ef524: r0 = __addArc$Method$FfiNative()
    //     0x12ef524: bl              #0xb836a8  ; [dart:ui] _NativePath::__addArc$Method$FfiNative
    // 0x12ef528: ldur            d0, [fp, #-0x90]
    // 0x12ef52c: ldur            d1, [fp, #-0x78]
    // 0x12ef530: r0 = Radius()
    //     0x12ef530: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x12ef534: ldur            d0, [fp, #-0x90]
    // 0x12ef538: StoreField: r0->field_7 = d0
    //     0x12ef538: stur            d0, [x0, #7]
    // 0x12ef53c: ldur            d1, [fp, #-0x78]
    // 0x12ef540: StoreField: r0->field_f = d1
    //     0x12ef540: stur            d1, [x0, #0xf]
    // 0x12ef544: r16 = Instance_Radius
    //     0x12ef544: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12ef548: ldr             x16, [x16, #0x1a0]
    // 0x12ef54c: cmp             w0, w16
    // 0x12ef550: b.ne            #0x12ef560
    // 0x12ef554: r0 = Instance_Radius
    //     0x12ef554: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12ef558: ldr             x0, [x0, #0x1a0]
    // 0x12ef55c: b               #0x12ef5b8
    // 0x12ef560: r16 = Radius
    //     0x12ef560: add             x16, PP, #0x26, lsl #12  ; [pp+0x26960] Type: Radius
    //     0x12ef564: ldr             x16, [x16, #0x960]
    // 0x12ef568: r30 = Radius
    //     0x12ef568: add             lr, PP, #0x26, lsl #12  ; [pp+0x26960] Type: Radius
    //     0x12ef56c: ldr             lr, [lr, #0x960]
    // 0x12ef570: stp             lr, x16, [SP]
    // 0x12ef574: r0 = ==()
    //     0x12ef574: bl              #0x12b7fbc  ; [dart:core] _Type::==
    // 0x12ef578: tbz             w0, #4, #0x12ef590
    // 0x12ef57c: ldur            d0, [fp, #-0x90]
    // 0x12ef580: ldur            d1, [fp, #-0x78]
    // 0x12ef584: r0 = Instance_Radius
    //     0x12ef584: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12ef588: ldr             x0, [x0, #0x1a0]
    // 0x12ef58c: b               #0x12ef5c4
    // 0x12ef590: ldur            d0, [fp, #-0x90]
    // 0x12ef594: r0 = Instance_Radius
    //     0x12ef594: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12ef598: ldr             x0, [x0, #0x1a0]
    // 0x12ef59c: LoadField: d1 = r0->field_7
    //     0x12ef59c: ldur            d1, [x0, #7]
    // 0x12ef5a0: fcmp            d1, d0
    // 0x12ef5a4: b.ne            #0x12ef5c0
    // 0x12ef5a8: ldur            d1, [fp, #-0x78]
    // 0x12ef5ac: LoadField: d2 = r0->field_f
    //     0x12ef5ac: ldur            d2, [x0, #0xf]
    // 0x12ef5b0: fcmp            d2, d1
    // 0x12ef5b4: b.ne            #0x12ef5c4
    // 0x12ef5b8: mov             v0.16b, v1.16b
    // 0x12ef5bc: b               #0x12ef620
    // 0x12ef5c0: ldur            d1, [fp, #-0x78]
    // 0x12ef5c4: ldur            d3, [fp, #-0xe8]
    // 0x12ef5c8: ldur            d2, [fp, #-0xa8]
    // 0x12ef5cc: ldur            x2, [fp, #-0x10]
    // 0x12ef5d0: fadd            d4, d3, d2
    // 0x12ef5d4: stur            d4, [fp, #-0x20]
    // 0x12ef5d8: LoadField: r1 = r2->field_7
    //     0x12ef5d8: ldur            w1, [x2, #7]
    // 0x12ef5dc: DecompressPointer r1
    //     0x12ef5dc: add             x1, x1, HEAP, lsl #32
    // 0x12ef5e0: cmp             w1, NULL
    // 0x12ef5e4: b.eq            #0x12ef9d4
    // 0x12ef5e8: LoadField: r3 = r1->field_7
    //     0x12ef5e8: ldur            x3, [x1, #7]
    // 0x12ef5ec: ldr             x1, [x3]
    // 0x12ef5f0: cbz             x1, #0x12ef950
    // 0x12ef5f4: mov             x3, x1
    // 0x12ef5f8: stur            x3, [fp, #-0x18]
    // 0x12ef5fc: r1 = <Never>
    //     0x12ef5fc: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12ef600: r0 = Pointer()
    //     0x12ef600: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12ef604: mov             x1, x0
    // 0x12ef608: ldur            x0, [fp, #-0x18]
    // 0x12ef60c: StoreField: r1->field_7 = r0
    //     0x12ef60c: stur            x0, [x1, #7]
    // 0x12ef610: ldur            d0, [fp, #-0xc0]
    // 0x12ef614: ldur            d1, [fp, #-0x20]
    // 0x12ef618: r0 = _moveTo$Method$FfiNative()
    //     0x12ef618: bl              #0xb69c74  ; [dart:ui] _NativePath::_moveTo$Method$FfiNative
    // 0x12ef61c: ldur            d0, [fp, #-0x78]
    // 0x12ef620: ldur            d1, [fp, #-0x80]
    // 0x12ef624: ldur            x0, [fp, #-0x10]
    // 0x12ef628: fsub            d2, d1, d0
    // 0x12ef62c: stur            d2, [fp, #-0x20]
    // 0x12ef630: LoadField: r1 = r0->field_7
    //     0x12ef630: ldur            w1, [x0, #7]
    // 0x12ef634: DecompressPointer r1
    //     0x12ef634: add             x1, x1, HEAP, lsl #32
    // 0x12ef638: cmp             w1, NULL
    // 0x12ef63c: b.eq            #0x12ef9d8
    // 0x12ef640: LoadField: r2 = r1->field_7
    //     0x12ef640: ldur            x2, [x1, #7]
    // 0x12ef644: ldr             x1, [x2]
    // 0x12ef648: cbz             x1, #0x12ef960
    // 0x12ef64c: ldur            d3, [fp, #-0x90]
    // 0x12ef650: mov             x2, x1
    // 0x12ef654: stur            x2, [fp, #-0x18]
    // 0x12ef658: r1 = <Never>
    //     0x12ef658: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12ef65c: r0 = Pointer()
    //     0x12ef65c: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12ef660: mov             x1, x0
    // 0x12ef664: ldur            x0, [fp, #-0x18]
    // 0x12ef668: StoreField: r1->field_7 = r0
    //     0x12ef668: stur            x0, [x1, #7]
    // 0x12ef66c: ldur            d0, [fp, #-0xc0]
    // 0x12ef670: ldur            d1, [fp, #-0x20]
    // 0x12ef674: r0 = _lineTo$Method$FfiNative()
    //     0x12ef674: bl              #0xb69bd0  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x12ef678: r0 = Radius()
    //     0x12ef678: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x12ef67c: ldur            d0, [fp, #-0x90]
    // 0x12ef680: StoreField: r0->field_7 = d0
    //     0x12ef680: stur            d0, [x0, #7]
    // 0x12ef684: ldur            d1, [fp, #-0x78]
    // 0x12ef688: StoreField: r0->field_f = d1
    //     0x12ef688: stur            d1, [x0, #0xf]
    // 0x12ef68c: r16 = Instance_Radius
    //     0x12ef68c: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12ef690: ldr             x16, [x16, #0x1a0]
    // 0x12ef694: cmp             w0, w16
    // 0x12ef698: b.ne            #0x12ef6a8
    // 0x12ef69c: r0 = Instance_Radius
    //     0x12ef69c: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12ef6a0: ldr             x0, [x0, #0x1a0]
    // 0x12ef6a4: b               #0x12ef754
    // 0x12ef6a8: r16 = Radius
    //     0x12ef6a8: add             x16, PP, #0x26, lsl #12  ; [pp+0x26960] Type: Radius
    //     0x12ef6ac: ldr             x16, [x16, #0x960]
    // 0x12ef6b0: r30 = Radius
    //     0x12ef6b0: add             lr, PP, #0x26, lsl #12  ; [pp+0x26960] Type: Radius
    //     0x12ef6b4: ldr             lr, [lr, #0x960]
    // 0x12ef6b8: stp             lr, x16, [SP]
    // 0x12ef6bc: r0 = ==()
    //     0x12ef6bc: bl              #0x12b7fbc  ; [dart:core] _Type::==
    // 0x12ef6c0: tbz             w0, #4, #0x12ef6d0
    // 0x12ef6c4: r0 = Instance_Radius
    //     0x12ef6c4: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12ef6c8: ldr             x0, [x0, #0x1a0]
    // 0x12ef6cc: b               #0x12ef6f8
    // 0x12ef6d0: ldur            d0, [fp, #-0x90]
    // 0x12ef6d4: r0 = Instance_Radius
    //     0x12ef6d4: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12ef6d8: ldr             x0, [x0, #0x1a0]
    // 0x12ef6dc: LoadField: d1 = r0->field_7
    //     0x12ef6dc: ldur            d1, [x0, #7]
    // 0x12ef6e0: fcmp            d1, d0
    // 0x12ef6e4: b.ne            #0x12ef6f8
    // 0x12ef6e8: ldur            d0, [fp, #-0x78]
    // 0x12ef6ec: LoadField: d1 = r0->field_f
    //     0x12ef6ec: ldur            d1, [x0, #0xf]
    // 0x12ef6f0: fcmp            d1, d0
    // 0x12ef6f4: b.eq            #0x12ef754
    // 0x12ef6f8: ldur            x2, [fp, #-0x10]
    // 0x12ef6fc: LoadField: r1 = r2->field_7
    //     0x12ef6fc: ldur            w1, [x2, #7]
    // 0x12ef700: DecompressPointer r1
    //     0x12ef700: add             x1, x1, HEAP, lsl #32
    // 0x12ef704: cmp             w1, NULL
    // 0x12ef708: b.eq            #0x12ef9dc
    // 0x12ef70c: LoadField: r3 = r1->field_7
    //     0x12ef70c: ldur            x3, [x1, #7]
    // 0x12ef710: ldr             x1, [x3]
    // 0x12ef714: cbz             x1, #0x12ef970
    // 0x12ef718: mov             x3, x1
    // 0x12ef71c: stur            x3, [fp, #-0x18]
    // 0x12ef720: r1 = <Never>
    //     0x12ef720: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12ef724: r0 = Pointer()
    //     0x12ef724: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12ef728: mov             x1, x0
    // 0x12ef72c: ldur            x0, [fp, #-0x18]
    // 0x12ef730: StoreField: r1->field_7 = r0
    //     0x12ef730: stur            x0, [x1, #7]
    // 0x12ef734: ldur            d0, [fp, #-0x88]
    // 0x12ef738: ldur            d1, [fp, #-0x70]
    // 0x12ef73c: ldur            d2, [fp, #-0x68]
    // 0x12ef740: ldur            d3, [fp, #-0x60]
    // 0x12ef744: d4 = 0.000000
    //     0x12ef744: eor             v4.16b, v4.16b, v4.16b
    // 0x12ef748: d5 = 1.570796
    //     0x12ef748: add             x17, PP, #0x95, lsl #12  ; [pp+0x95ed8] IMM: double(1.5707963267948966) from 0x3ff921fb54442d18
    //     0x12ef74c: ldr             d5, [x17, #0xed8]
    // 0x12ef750: r0 = __addArc$Method$FfiNative()
    //     0x12ef750: bl              #0xb836a8  ; [dart:ui] _NativePath::__addArc$Method$FfiNative
    // 0x12ef754: ldur            d0, [fp, #-0xf0]
    // 0x12ef758: ldur            d1, [fp, #-0x48]
    // 0x12ef75c: ldur            x0, [fp, #-0x10]
    // 0x12ef760: fadd            d2, d0, d1
    // 0x12ef764: stur            d2, [fp, #-0x20]
    // 0x12ef768: LoadField: r1 = r0->field_7
    //     0x12ef768: ldur            w1, [x0, #7]
    // 0x12ef76c: DecompressPointer r1
    //     0x12ef76c: add             x1, x1, HEAP, lsl #32
    // 0x12ef770: cmp             w1, NULL
    // 0x12ef774: b.eq            #0x12ef9e0
    // 0x12ef778: LoadField: r2 = r1->field_7
    //     0x12ef778: ldur            x2, [x1, #7]
    // 0x12ef77c: ldr             x1, [x2]
    // 0x12ef780: cbz             x1, #0x12ef980
    // 0x12ef784: ldur            d3, [fp, #-0x58]
    // 0x12ef788: mov             x2, x1
    // 0x12ef78c: stur            x2, [fp, #-0x18]
    // 0x12ef790: r1 = <Never>
    //     0x12ef790: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12ef794: r0 = Pointer()
    //     0x12ef794: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12ef798: mov             x1, x0
    // 0x12ef79c: ldur            x0, [fp, #-0x18]
    // 0x12ef7a0: StoreField: r1->field_7 = r0
    //     0x12ef7a0: stur            x0, [x1, #7]
    // 0x12ef7a4: ldur            d0, [fp, #-0x20]
    // 0x12ef7a8: ldur            d1, [fp, #-0x80]
    // 0x12ef7ac: r0 = _lineTo$Method$FfiNative()
    //     0x12ef7ac: bl              #0xb69bd0  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x12ef7b0: r0 = Radius()
    //     0x12ef7b0: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x12ef7b4: ldur            d0, [fp, #-0x48]
    // 0x12ef7b8: StoreField: r0->field_7 = d0
    //     0x12ef7b8: stur            d0, [x0, #7]
    // 0x12ef7bc: ldur            d1, [fp, #-0x58]
    // 0x12ef7c0: StoreField: r0->field_f = d1
    //     0x12ef7c0: stur            d1, [x0, #0xf]
    // 0x12ef7c4: r16 = Instance_Radius
    //     0x12ef7c4: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12ef7c8: ldr             x16, [x16, #0x1a0]
    // 0x12ef7cc: cmp             w0, w16
    // 0x12ef7d0: b.eq            #0x12ef878
    // 0x12ef7d4: r16 = Radius
    //     0x12ef7d4: add             x16, PP, #0x26, lsl #12  ; [pp+0x26960] Type: Radius
    //     0x12ef7d8: ldr             x16, [x16, #0x960]
    // 0x12ef7dc: r30 = Radius
    //     0x12ef7dc: add             lr, PP, #0x26, lsl #12  ; [pp+0x26960] Type: Radius
    //     0x12ef7e0: ldr             lr, [lr, #0x960]
    // 0x12ef7e4: stp             lr, x16, [SP]
    // 0x12ef7e8: r0 = ==()
    //     0x12ef7e8: bl              #0x12b7fbc  ; [dart:core] _Type::==
    // 0x12ef7ec: tbnz            w0, #4, #0x12ef818
    // 0x12ef7f0: ldur            d0, [fp, #-0x48]
    // 0x12ef7f4: r0 = Instance_Radius
    //     0x12ef7f4: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12ef7f8: ldr             x0, [x0, #0x1a0]
    // 0x12ef7fc: LoadField: d1 = r0->field_7
    //     0x12ef7fc: ldur            d1, [x0, #7]
    // 0x12ef800: fcmp            d1, d0
    // 0x12ef804: b.ne            #0x12ef818
    // 0x12ef808: ldur            d0, [fp, #-0x58]
    // 0x12ef80c: LoadField: d1 = r0->field_f
    //     0x12ef80c: ldur            d1, [x0, #0xf]
    // 0x12ef810: fcmp            d1, d0
    // 0x12ef814: b.eq            #0x12ef878
    // 0x12ef818: ldur            x0, [fp, #-0x10]
    // 0x12ef81c: LoadField: r1 = r0->field_7
    //     0x12ef81c: ldur            w1, [x0, #7]
    // 0x12ef820: DecompressPointer r1
    //     0x12ef820: add             x1, x1, HEAP, lsl #32
    // 0x12ef824: cmp             w1, NULL
    // 0x12ef828: b.eq            #0x12ef9e4
    // 0x12ef82c: LoadField: r2 = r1->field_7
    //     0x12ef82c: ldur            x2, [x1, #7]
    // 0x12ef830: ldr             x1, [x2]
    // 0x12ef834: cbz             x1, #0x12ef990
    // 0x12ef838: mov             x2, x1
    // 0x12ef83c: stur            x2, [fp, #-0x18]
    // 0x12ef840: r1 = <Never>
    //     0x12ef840: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12ef844: r0 = Pointer()
    //     0x12ef844: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12ef848: mov             x1, x0
    // 0x12ef84c: ldur            x0, [fp, #-0x18]
    // 0x12ef850: StoreField: r1->field_7 = r0
    //     0x12ef850: stur            x0, [x1, #7]
    // 0x12ef854: ldur            d0, [fp, #-0xf0]
    // 0x12ef858: ldur            d1, [fp, #-0x50]
    // 0x12ef85c: ldur            d2, [fp, #-0x40]
    // 0x12ef860: ldur            d3, [fp, #-0x38]
    // 0x12ef864: d4 = 1.570796
    //     0x12ef864: add             x17, PP, #0x95, lsl #12  ; [pp+0x95ed8] IMM: double(1.5707963267948966) from 0x3ff921fb54442d18
    //     0x12ef868: ldr             d4, [x17, #0xed8]
    // 0x12ef86c: d5 = 1.570796
    //     0x12ef86c: add             x17, PP, #0x95, lsl #12  ; [pp+0x95ed8] IMM: double(1.5707963267948966) from 0x3ff921fb54442d18
    //     0x12ef870: ldr             d5, [x17, #0xed8]
    // 0x12ef874: r0 = __addArc$Method$FfiNative()
    //     0x12ef874: bl              #0xb836a8  ; [dart:ui] _NativePath::__addArc$Method$FfiNative
    // 0x12ef878: ldur            d0, [fp, #-0xe8]
    // 0x12ef87c: ldur            d1, [fp, #-0xd8]
    // 0x12ef880: ldur            x0, [fp, #-0x10]
    // 0x12ef884: fadd            d2, d0, d1
    // 0x12ef888: stur            d2, [fp, #-0x20]
    // 0x12ef88c: LoadField: r1 = r0->field_7
    //     0x12ef88c: ldur            w1, [x0, #7]
    // 0x12ef890: DecompressPointer r1
    //     0x12ef890: add             x1, x1, HEAP, lsl #32
    // 0x12ef894: cmp             w1, NULL
    // 0x12ef898: b.eq            #0x12ef9e8
    // 0x12ef89c: LoadField: r2 = r1->field_7
    //     0x12ef89c: ldur            x2, [x1, #7]
    // 0x12ef8a0: ldr             x1, [x2]
    // 0x12ef8a4: cbz             x1, #0x12ef9a0
    // 0x12ef8a8: mov             x2, x1
    // 0x12ef8ac: stur            x2, [fp, #-0x18]
    // 0x12ef8b0: r1 = <Never>
    //     0x12ef8b0: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12ef8b4: r0 = Pointer()
    //     0x12ef8b4: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12ef8b8: mov             x1, x0
    // 0x12ef8bc: ldur            x0, [fp, #-0x18]
    // 0x12ef8c0: StoreField: r1->field_7 = r0
    //     0x12ef8c0: stur            x0, [x1, #7]
    // 0x12ef8c4: ldur            d0, [fp, #-0xf0]
    // 0x12ef8c8: ldur            d1, [fp, #-0x20]
    // 0x12ef8cc: r0 = _lineTo$Method$FfiNative()
    //     0x12ef8cc: bl              #0xb69bd0  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x12ef8d0: ldur            x0, [fp, #-0x10]
    // 0x12ef8d4: LeaveFrame
    //     0x12ef8d4: mov             SP, fp
    //     0x12ef8d8: ldp             fp, lr, [SP], #0x10
    // 0x12ef8dc: ret
    //     0x12ef8dc: ret             
    // 0x12ef8e0: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12ef8e0: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12ef8e4: str             x16, [SP]
    // 0x12ef8e8: r0 = _throwNew()
    //     0x12ef8e8: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12ef8ec: brk             #0
    // 0x12ef8f0: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12ef8f0: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12ef8f4: str             x16, [SP]
    // 0x12ef8f8: r0 = _throwNew()
    //     0x12ef8f8: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12ef8fc: brk             #0
    // 0x12ef900: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12ef900: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12ef904: str             x16, [SP]
    // 0x12ef908: r0 = _throwNew()
    //     0x12ef908: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12ef90c: brk             #0
    // 0x12ef910: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12ef910: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12ef914: str             x16, [SP]
    // 0x12ef918: r0 = _throwNew()
    //     0x12ef918: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12ef91c: brk             #0
    // 0x12ef920: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12ef920: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12ef924: str             x16, [SP]
    // 0x12ef928: r0 = _throwNew()
    //     0x12ef928: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12ef92c: brk             #0
    // 0x12ef930: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12ef930: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12ef934: str             x16, [SP]
    // 0x12ef938: r0 = _throwNew()
    //     0x12ef938: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12ef93c: brk             #0
    // 0x12ef940: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12ef940: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12ef944: str             x16, [SP]
    // 0x12ef948: r0 = _throwNew()
    //     0x12ef948: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12ef94c: brk             #0
    // 0x12ef950: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12ef950: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12ef954: str             x16, [SP]
    // 0x12ef958: r0 = _throwNew()
    //     0x12ef958: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12ef95c: brk             #0
    // 0x12ef960: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12ef960: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12ef964: str             x16, [SP]
    // 0x12ef968: r0 = _throwNew()
    //     0x12ef968: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12ef96c: brk             #0
    // 0x12ef970: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12ef970: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12ef974: str             x16, [SP]
    // 0x12ef978: r0 = _throwNew()
    //     0x12ef978: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12ef97c: brk             #0
    // 0x12ef980: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12ef980: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12ef984: str             x16, [SP]
    // 0x12ef988: r0 = _throwNew()
    //     0x12ef988: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12ef98c: brk             #0
    // 0x12ef990: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12ef990: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12ef994: str             x16, [SP]
    // 0x12ef998: r0 = _throwNew()
    //     0x12ef998: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12ef99c: brk             #0
    // 0x12ef9a0: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12ef9a0: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12ef9a4: str             x16, [SP]
    // 0x12ef9a8: r0 = _throwNew()
    //     0x12ef9a8: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12ef9ac: brk             #0
    // 0x12ef9b0: r0 = StackOverflowSharedWithFPURegs()
    //     0x12ef9b0: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12ef9b4: b               #0x12eef54
    // 0x12ef9b8: r0 = NullErrorSharedWithFPURegs()
    //     0x12ef9b8: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0x12ef9bc: r0 = NullErrorSharedWithFPURegs()
    //     0x12ef9bc: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0x12ef9c0: r0 = NullErrorSharedWithFPURegs()
    //     0x12ef9c0: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0x12ef9c4: r0 = NullErrorSharedWithFPURegs()
    //     0x12ef9c4: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0x12ef9c8: r0 = NullErrorSharedWithFPURegs()
    //     0x12ef9c8: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0x12ef9cc: r0 = NullErrorSharedWithFPURegs()
    //     0x12ef9cc: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0x12ef9d0: r0 = NullErrorSharedWithFPURegs()
    //     0x12ef9d0: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0x12ef9d4: r0 = NullErrorSharedWithFPURegs()
    //     0x12ef9d4: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0x12ef9d8: r0 = NullErrorSharedWithFPURegs()
    //     0x12ef9d8: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0x12ef9dc: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12ef9dc: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12ef9e0: r0 = NullErrorSharedWithFPURegs()
    //     0x12ef9e0: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0x12ef9e4: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12ef9e4: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12ef9e8: r0 = NullErrorSharedWithFPURegs()
    //     0x12ef9e8: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
  }
  get _ dimensions(/* No info */) {
    // ** addr: 0x12f5668, size: 0x5c
    // 0x12f5668: EnterFrame
    //     0x12f5668: stp             fp, lr, [SP, #-0x10]!
    //     0x12f566c: mov             fp, SP
    // 0x12f5670: AllocStack(0x8)
    //     0x12f5670: sub             SP, SP, #8
    // 0x12f5674: d1 = 1.000000
    //     0x12f5674: fmov            d1, #1.00000000
    // 0x12f5678: d0 = 2.000000
    //     0x12f5678: fmov            d0, #2.00000000
    // 0x12f567c: LoadField: r0 = r1->field_7
    //     0x12f567c: ldur            w0, [x1, #7]
    // 0x12f5680: DecompressPointer r0
    //     0x12f5680: add             x0, x0, HEAP, lsl #32
    // 0x12f5684: LoadField: d2 = r0->field_b
    //     0x12f5684: ldur            d2, [x0, #0xb]
    // 0x12f5688: ArrayLoad: d3 = r0[0]  ; List_8
    //     0x12f5688: ldur            d3, [x0, #0x17]
    // 0x12f568c: fadd            d4, d3, d1
    // 0x12f5690: fdiv            d3, d4, d0
    // 0x12f5694: fsub            d0, d1, d3
    // 0x12f5698: fmul            d1, d2, d0
    // 0x12f569c: stur            d1, [fp, #-8]
    // 0x12f56a0: r0 = EdgeInsets()
    //     0x12f56a0: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x12f56a4: ldur            d0, [fp, #-8]
    // 0x12f56a8: StoreField: r0->field_7 = d0
    //     0x12f56a8: stur            d0, [x0, #7]
    // 0x12f56ac: StoreField: r0->field_f = d0
    //     0x12f56ac: stur            d0, [x0, #0xf]
    // 0x12f56b0: ArrayStore: r0[0] = d0  ; List_8
    //     0x12f56b0: stur            d0, [x0, #0x17]
    // 0x12f56b4: StoreField: r0->field_1f = d0
    //     0x12f56b4: stur            d0, [x0, #0x1f]
    // 0x12f56b8: LeaveFrame
    //     0x12f56b8: mov             SP, fp
    //     0x12f56bc: ldp             fp, lr, [SP], #0x10
    // 0x12f56c0: ret
    //     0x12f56c0: ret             
  }
  _ scale(/* No info */) {
    // ** addr: 0x12fcffc, size: 0xa0
    // 0x12fcffc: EnterFrame
    //     0x12fcffc: stp             fp, lr, [SP, #-0x10]!
    //     0x12fd000: mov             fp, SP
    // 0x12fd004: AllocStack(0x28)
    //     0x12fd004: sub             SP, SP, #0x28
    // 0x12fd008: SetupParameters(OutlineInputBorder this /* r1 => r0, fp-0x8 */, dynamic _ /* d0 => d1, fp-0x20 */)
    //     0x12fd008: mov             x0, x1
    //     0x12fd00c: mov             v1.16b, v0.16b
    //     0x12fd010: stur            x1, [fp, #-8]
    //     0x12fd014: stur            d0, [fp, #-0x20]
    // 0x12fd018: CheckStackOverflow
    //     0x12fd018: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fd01c: cmp             SP, x16
    //     0x12fd020: b.ls            #0x12fd094
    // 0x12fd024: LoadField: r1 = r0->field_7
    //     0x12fd024: ldur            w1, [x0, #7]
    // 0x12fd028: DecompressPointer r1
    //     0x12fd028: add             x1, x1, HEAP, lsl #32
    // 0x12fd02c: mov             v0.16b, v1.16b
    // 0x12fd030: r0 = scale()
    //     0x12fd030: bl              #0x12fc608  ; [package:flutter/src/painting/borders.dart] BorderSide::scale
    // 0x12fd034: mov             x2, x0
    // 0x12fd038: ldur            x0, [fp, #-8]
    // 0x12fd03c: stur            x2, [fp, #-0x10]
    // 0x12fd040: LoadField: r1 = r0->field_13
    //     0x12fd040: ldur            w1, [x0, #0x13]
    // 0x12fd044: DecompressPointer r1
    //     0x12fd044: add             x1, x1, HEAP, lsl #32
    // 0x12fd048: ldur            d0, [fp, #-0x20]
    // 0x12fd04c: r0 = *()
    //     0x12fd04c: bl              #0x1301cb4  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::*
    // 0x12fd050: mov             x1, x0
    // 0x12fd054: ldur            x0, [fp, #-8]
    // 0x12fd058: stur            x1, [fp, #-0x18]
    // 0x12fd05c: LoadField: d0 = r0->field_b
    //     0x12fd05c: ldur            d0, [x0, #0xb]
    // 0x12fd060: ldur            d1, [fp, #-0x20]
    // 0x12fd064: fmul            d2, d0, d1
    // 0x12fd068: stur            d2, [fp, #-0x28]
    // 0x12fd06c: r0 = OutlineInputBorder()
    //     0x12fd06c: bl              #0xd93f40  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x12fd070: ldur            x1, [fp, #-0x18]
    // 0x12fd074: StoreField: r0->field_13 = r1
    //     0x12fd074: stur            w1, [x0, #0x13]
    // 0x12fd078: ldur            d0, [fp, #-0x28]
    // 0x12fd07c: StoreField: r0->field_b = d0
    //     0x12fd07c: stur            d0, [x0, #0xb]
    // 0x12fd080: ldur            x1, [fp, #-0x10]
    // 0x12fd084: StoreField: r0->field_7 = r1
    //     0x12fd084: stur            w1, [x0, #7]
    // 0x12fd088: LeaveFrame
    //     0x12fd088: mov             SP, fp
    //     0x12fd08c: ldp             fp, lr, [SP], #0x10
    // 0x12fd090: ret
    //     0x12fd090: ret             
    // 0x12fd094: r0 = StackOverflowSharedWithFPURegs()
    //     0x12fd094: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12fd098: b               #0x12fd024
  }
  _ getOuterPath(/* No info */) {
    // ** addr: 0x1300c2c, size: 0x160
    // 0x1300c2c: EnterFrame
    //     0x1300c2c: stp             fp, lr, [SP, #-0x10]!
    //     0x1300c30: mov             fp, SP
    // 0x1300c34: AllocStack(0x30)
    //     0x1300c34: sub             SP, SP, #0x30
    // 0x1300c38: SetupParameters(OutlineInputBorder this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x1300c38: stur            x1, [fp, #-8]
    //     0x1300c3c: stur            x2, [fp, #-0x10]
    // 0x1300c40: CheckStackOverflow
    //     0x1300c40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1300c44: cmp             SP, x16
    //     0x1300c48: b.ls            #0x1300d80
    // 0x1300c4c: r0 = _NativePath()
    //     0x1300c4c: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0x1300c50: mov             x1, x0
    // 0x1300c54: stur            x0, [fp, #-0x18]
    // 0x1300c58: r0 = __constructor$Method$FfiNative()
    //     0x1300c58: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0x1300c5c: ldur            x0, [fp, #-8]
    // 0x1300c60: LoadField: r1 = r0->field_13
    //     0x1300c60: ldur            w1, [x0, #0x13]
    // 0x1300c64: DecompressPointer r1
    //     0x1300c64: add             x1, x1, HEAP, lsl #32
    // 0x1300c68: ldur            x2, [fp, #-0x10]
    // 0x1300c6c: r0 = toRRect()
    //     0x1300c6c: bl              #0xb77a10  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0x1300c70: stur            x0, [fp, #-8]
    // 0x1300c74: LoadField: d0 = r0->field_b
    //     0x1300c74: ldur            d0, [x0, #0xb]
    // 0x1300c78: fcvt            s1, d0
    // 0x1300c7c: stur            d1, [fp, #-0x28]
    // 0x1300c80: r4 = 24
    //     0x1300c80: mov             x4, #0x18
    // 0x1300c84: r0 = AllocateFloat32Array()
    //     0x1300c84: bl              #0x13defe8  ; AllocateFloat32ArrayStub
    // 0x1300c88: ldur            d0, [fp, #-0x28]
    // 0x1300c8c: stur            x0, [fp, #-0x10]
    // 0x1300c90: ArrayStore: r0[0] = d0  ; List_8
    //     0x1300c90: stur            s0, [x0, #0x17]
    // 0x1300c94: ldur            x1, [fp, #-8]
    // 0x1300c98: LoadField: d0 = r1->field_13
    //     0x1300c98: ldur            d0, [x1, #0x13]
    // 0x1300c9c: fcvt            s1, d0
    // 0x1300ca0: StoreField: r0->field_1b = d1
    //     0x1300ca0: stur            s1, [x0, #0x1b]
    // 0x1300ca4: LoadField: d0 = r1->field_1b
    //     0x1300ca4: ldur            d0, [x1, #0x1b]
    // 0x1300ca8: fcvt            s1, d0
    // 0x1300cac: StoreField: r0->field_1f = d1
    //     0x1300cac: stur            s1, [x0, #0x1f]
    // 0x1300cb0: LoadField: d0 = r1->field_23
    //     0x1300cb0: ldur            d0, [x1, #0x23]
    // 0x1300cb4: fcvt            s1, d0
    // 0x1300cb8: StoreField: r0->field_23 = d1
    //     0x1300cb8: stur            s1, [x0, #0x23]
    // 0x1300cbc: LoadField: d0 = r1->field_2b
    //     0x1300cbc: ldur            d0, [x1, #0x2b]
    // 0x1300cc0: fcvt            s1, d0
    // 0x1300cc4: StoreField: r0->field_27 = d1
    //     0x1300cc4: stur            s1, [x0, #0x27]
    // 0x1300cc8: LoadField: d0 = r1->field_33
    //     0x1300cc8: ldur            d0, [x1, #0x33]
    // 0x1300ccc: fcvt            s1, d0
    // 0x1300cd0: StoreField: r0->field_2b = d1
    //     0x1300cd0: stur            s1, [x0, #0x2b]
    // 0x1300cd4: LoadField: d0 = r1->field_3b
    //     0x1300cd4: ldur            d0, [x1, #0x3b]
    // 0x1300cd8: fcvt            s1, d0
    // 0x1300cdc: StoreField: r0->field_2f = d1
    //     0x1300cdc: stur            s1, [x0, #0x2f]
    // 0x1300ce0: LoadField: d0 = r1->field_43
    //     0x1300ce0: ldur            d0, [x1, #0x43]
    // 0x1300ce4: fcvt            s1, d0
    // 0x1300ce8: StoreField: r0->field_33 = d1
    //     0x1300ce8: stur            s1, [x0, #0x33]
    // 0x1300cec: LoadField: d0 = r1->field_4b
    //     0x1300cec: ldur            d0, [x1, #0x4b]
    // 0x1300cf0: fcvt            s1, d0
    // 0x1300cf4: StoreField: r0->field_37 = d1
    //     0x1300cf4: stur            s1, [x0, #0x37]
    // 0x1300cf8: LoadField: d0 = r1->field_53
    //     0x1300cf8: ldur            d0, [x1, #0x53]
    // 0x1300cfc: fcvt            s1, d0
    // 0x1300d00: StoreField: r0->field_3b = d1
    //     0x1300d00: stur            s1, [x0, #0x3b]
    // 0x1300d04: LoadField: d0 = r1->field_5b
    //     0x1300d04: ldur            d0, [x1, #0x5b]
    // 0x1300d08: fcvt            s1, d0
    // 0x1300d0c: StoreField: r0->field_3f = d1
    //     0x1300d0c: stur            s1, [x0, #0x3f]
    // 0x1300d10: LoadField: d0 = r1->field_63
    //     0x1300d10: ldur            d0, [x1, #0x63]
    // 0x1300d14: fcvt            s1, d0
    // 0x1300d18: StoreField: r0->field_43 = d1
    //     0x1300d18: stur            s1, [x0, #0x43]
    // 0x1300d1c: ldur            x2, [fp, #-0x18]
    // 0x1300d20: LoadField: r1 = r2->field_7
    //     0x1300d20: ldur            w1, [x2, #7]
    // 0x1300d24: DecompressPointer r1
    //     0x1300d24: add             x1, x1, HEAP, lsl #32
    // 0x1300d28: cmp             w1, NULL
    // 0x1300d2c: b.eq            #0x1300d88
    // 0x1300d30: LoadField: r3 = r1->field_7
    //     0x1300d30: ldur            x3, [x1, #7]
    // 0x1300d34: ldr             x1, [x3]
    // 0x1300d38: cbz             x1, #0x1300d70
    // 0x1300d3c: mov             x3, x1
    // 0x1300d40: stur            x3, [fp, #-0x20]
    // 0x1300d44: r1 = <Never>
    //     0x1300d44: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x1300d48: r0 = Pointer()
    //     0x1300d48: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x1300d4c: mov             x1, x0
    // 0x1300d50: ldur            x0, [fp, #-0x20]
    // 0x1300d54: StoreField: r1->field_7 = r0
    //     0x1300d54: stur            x0, [x1, #7]
    // 0x1300d58: ldur            x2, [fp, #-0x10]
    // 0x1300d5c: r0 = __addRRect$Method$FfiNative()
    //     0x1300d5c: bl              #0xbfd930  ; [dart:ui] _NativePath::__addRRect$Method$FfiNative
    // 0x1300d60: ldur            x0, [fp, #-0x18]
    // 0x1300d64: LeaveFrame
    //     0x1300d64: mov             SP, fp
    //     0x1300d68: ldp             fp, lr, [SP], #0x10
    // 0x1300d6c: ret
    //     0x1300d6c: ret             
    // 0x1300d70: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x1300d70: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x1300d74: str             x16, [SP]
    // 0x1300d78: r0 = _throwNew()
    //     0x1300d78: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x1300d7c: brk             #0
    // 0x1300d80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1300d80: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1300d84: b               #0x1300c4c
    // 0x1300d88: r0 = NullErrorSharedWithoutFPURegs()
    //     0x1300d88: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ copyWith(/* No info */) {
    // ** addr: 0x1300f90, size: 0x64
    // 0x1300f90: EnterFrame
    //     0x1300f90: stp             fp, lr, [SP, #-0x10]!
    //     0x1300f94: mov             fp, SP
    // 0x1300f98: AllocStack(0x18)
    //     0x1300f98: sub             SP, SP, #0x18
    // 0x1300f9c: cmp             w2, NULL
    // 0x1300fa0: b.ne            #0x1300fb0
    // 0x1300fa4: LoadField: r0 = r1->field_7
    //     0x1300fa4: ldur            w0, [x1, #7]
    // 0x1300fa8: DecompressPointer r0
    //     0x1300fa8: add             x0, x0, HEAP, lsl #32
    // 0x1300fac: b               #0x1300fb4
    // 0x1300fb0: mov             x0, x2
    // 0x1300fb4: stur            x0, [fp, #-0x10]
    // 0x1300fb8: LoadField: r2 = r1->field_13
    //     0x1300fb8: ldur            w2, [x1, #0x13]
    // 0x1300fbc: DecompressPointer r2
    //     0x1300fbc: add             x2, x2, HEAP, lsl #32
    // 0x1300fc0: stur            x2, [fp, #-8]
    // 0x1300fc4: LoadField: d0 = r1->field_b
    //     0x1300fc4: ldur            d0, [x1, #0xb]
    // 0x1300fc8: stur            d0, [fp, #-0x18]
    // 0x1300fcc: r0 = OutlineInputBorder()
    //     0x1300fcc: bl              #0xd93f40  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x1300fd0: ldur            x1, [fp, #-8]
    // 0x1300fd4: StoreField: r0->field_13 = r1
    //     0x1300fd4: stur            w1, [x0, #0x13]
    // 0x1300fd8: ldur            d0, [fp, #-0x18]
    // 0x1300fdc: StoreField: r0->field_b = d0
    //     0x1300fdc: stur            d0, [x0, #0xb]
    // 0x1300fe0: ldur            x1, [fp, #-0x10]
    // 0x1300fe4: StoreField: r0->field_7 = r1
    //     0x1300fe4: stur            w1, [x0, #7]
    // 0x1300fe8: LeaveFrame
    //     0x1300fe8: mov             SP, fp
    //     0x1300fec: ldp             fp, lr, [SP], #0x10
    // 0x1300ff0: ret
    //     0x1300ff0: ret             
  }
}

// class id: 3017, size: 0x10, field offset: 0xc
//   const constructor, 
class UnderlineInputBorder extends InputBorder {

  BorderSide field_8;
  BorderRadius field_c;

  _ getInnerPath(/* No info */) {
    // ** addr: 0xbffad8, size: 0xfc
    // 0xbffad8: EnterFrame
    //     0xbffad8: stp             fp, lr, [SP, #-0x10]!
    //     0xbffadc: mov             fp, SP
    // 0xbffae0: AllocStack(0x48)
    //     0xbffae0: sub             SP, SP, #0x48
    // 0xbffae4: SetupParameters(UnderlineInputBorder this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xbffae4: stur            x1, [fp, #-8]
    //     0xbffae8: stur            x2, [fp, #-0x10]
    // 0xbffaec: CheckStackOverflow
    //     0xbffaec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbffaf0: cmp             SP, x16
    //     0xbffaf4: b.ls            #0xbffbc8
    // 0xbffaf8: r0 = _NativePath()
    //     0xbffaf8: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0xbffafc: mov             x1, x0
    // 0xbffb00: stur            x0, [fp, #-0x18]
    // 0xbffb04: r0 = __constructor$Method$FfiNative()
    //     0xbffb04: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0xbffb08: ldur            x0, [fp, #-0x10]
    // 0xbffb0c: LoadField: d0 = r0->field_7
    //     0xbffb0c: ldur            d0, [x0, #7]
    // 0xbffb10: stur            d0, [fp, #-0x40]
    // 0xbffb14: LoadField: d1 = r0->field_f
    //     0xbffb14: ldur            d1, [x0, #0xf]
    // 0xbffb18: stur            d1, [fp, #-0x38]
    // 0xbffb1c: ArrayLoad: d2 = r0[0]  ; List_8
    //     0xbffb1c: ldur            d2, [x0, #0x17]
    // 0xbffb20: fsub            d3, d2, d0
    // 0xbffb24: LoadField: d2 = r0->field_1f
    //     0xbffb24: ldur            d2, [x0, #0x1f]
    // 0xbffb28: fsub            d4, d2, d1
    // 0xbffb2c: ldur            x0, [fp, #-8]
    // 0xbffb30: LoadField: r1 = r0->field_7
    //     0xbffb30: ldur            w1, [x0, #7]
    // 0xbffb34: DecompressPointer r1
    //     0xbffb34: add             x1, x1, HEAP, lsl #32
    // 0xbffb38: LoadField: d2 = r1->field_b
    //     0xbffb38: ldur            d2, [x1, #0xb]
    // 0xbffb3c: fsub            d5, d4, d2
    // 0xbffb40: d2 = 0.000000
    //     0xbffb40: eor             v2.16b, v2.16b, v2.16b
    // 0xbffb44: fmax            v4.2d, v2.2d, v5.2d
    // 0xbffb48: fadd            d2, d0, d3
    // 0xbffb4c: stur            d2, [fp, #-0x30]
    // 0xbffb50: fadd            d3, d1, d4
    // 0xbffb54: ldur            x0, [fp, #-0x18]
    // 0xbffb58: stur            d3, [fp, #-0x28]
    // 0xbffb5c: LoadField: r1 = r0->field_7
    //     0xbffb5c: ldur            w1, [x0, #7]
    // 0xbffb60: DecompressPointer r1
    //     0xbffb60: add             x1, x1, HEAP, lsl #32
    // 0xbffb64: cmp             w1, NULL
    // 0xbffb68: b.eq            #0xbffbd0
    // 0xbffb6c: LoadField: r2 = r1->field_7
    //     0xbffb6c: ldur            x2, [x1, #7]
    // 0xbffb70: ldr             x1, [x2]
    // 0xbffb74: cbz             x1, #0xbffbb8
    // 0xbffb78: mov             x2, x1
    // 0xbffb7c: stur            x2, [fp, #-0x20]
    // 0xbffb80: r1 = <Never>
    //     0xbffb80: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xbffb84: r0 = Pointer()
    //     0xbffb84: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xbffb88: mov             x1, x0
    // 0xbffb8c: ldur            x0, [fp, #-0x20]
    // 0xbffb90: StoreField: r1->field_7 = r0
    //     0xbffb90: stur            x0, [x1, #7]
    // 0xbffb94: ldur            d0, [fp, #-0x40]
    // 0xbffb98: ldur            d1, [fp, #-0x38]
    // 0xbffb9c: ldur            d2, [fp, #-0x30]
    // 0xbffba0: ldur            d3, [fp, #-0x28]
    // 0xbffba4: r0 = __addRect$Method$FfiNative()
    //     0xbffba4: bl              #0xb74e24  ; [dart:ui] _NativePath::__addRect$Method$FfiNative
    // 0xbffba8: ldur            x0, [fp, #-0x18]
    // 0xbffbac: LeaveFrame
    //     0xbffbac: mov             SP, fp
    //     0xbffbb0: ldp             fp, lr, [SP], #0x10
    // 0xbffbb4: ret
    //     0xbffbb4: ret             
    // 0xbffbb8: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xbffbb8: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xbffbbc: str             x16, [SP]
    // 0xbffbc0: r0 = _throwNew()
    //     0xbffbc0: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xbffbc4: brk             #0
    // 0xbffbc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbffbc8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbffbcc: b               #0xbffaf8
    // 0xbffbd0: r0 = NullErrorSharedWithFPURegs()
    //     0xbffbd0: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
  }
  _ lerpFrom(/* No info */) {
    // ** addr: 0x10ee4a0, size: 0xe4
    // 0x10ee4a0: EnterFrame
    //     0x10ee4a0: stp             fp, lr, [SP, #-0x10]!
    //     0x10ee4a4: mov             fp, SP
    // 0x10ee4a8: AllocStack(0x28)
    //     0x10ee4a8: sub             SP, SP, #0x28
    // 0x10ee4ac: SetupParameters(UnderlineInputBorder this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* d0 => d1, fp-0x28 */)
    //     0x10ee4ac: mov             x3, x1
    //     0x10ee4b0: mov             x0, x2
    //     0x10ee4b4: mov             v1.16b, v0.16b
    //     0x10ee4b8: stur            x1, [fp, #-8]
    //     0x10ee4bc: stur            x2, [fp, #-0x10]
    //     0x10ee4c0: stur            d0, [fp, #-0x28]
    // 0x10ee4c4: CheckStackOverflow
    //     0x10ee4c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10ee4c8: cmp             SP, x16
    //     0x10ee4cc: b.ls            #0x10ee57c
    // 0x10ee4d0: r1 = LoadClassIdInstr(r0)
    //     0x10ee4d0: ldur            x1, [x0, #-1]
    //     0x10ee4d4: ubfx            x1, x1, #0xc, #0x14
    // 0x10ee4d8: cmp             x1, #0xbc9
    // 0x10ee4dc: b.ne            #0x10ee550
    // 0x10ee4e0: LoadField: r1 = r0->field_7
    //     0x10ee4e0: ldur            w1, [x0, #7]
    // 0x10ee4e4: DecompressPointer r1
    //     0x10ee4e4: add             x1, x1, HEAP, lsl #32
    // 0x10ee4e8: LoadField: r2 = r3->field_7
    //     0x10ee4e8: ldur            w2, [x3, #7]
    // 0x10ee4ec: DecompressPointer r2
    //     0x10ee4ec: add             x2, x2, HEAP, lsl #32
    // 0x10ee4f0: mov             v0.16b, v1.16b
    // 0x10ee4f4: r0 = lerp()
    //     0x10ee4f4: bl              #0xa07be0  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x10ee4f8: mov             x3, x0
    // 0x10ee4fc: ldur            x0, [fp, #-0x10]
    // 0x10ee500: stur            x3, [fp, #-0x18]
    // 0x10ee504: LoadField: r1 = r0->field_b
    //     0x10ee504: ldur            w1, [x0, #0xb]
    // 0x10ee508: DecompressPointer r1
    //     0x10ee508: add             x1, x1, HEAP, lsl #32
    // 0x10ee50c: ldur            x2, [fp, #-8]
    // 0x10ee510: LoadField: r0 = r2->field_b
    //     0x10ee510: ldur            w0, [x2, #0xb]
    // 0x10ee514: DecompressPointer r0
    //     0x10ee514: add             x0, x0, HEAP, lsl #32
    // 0x10ee518: mov             x2, x0
    // 0x10ee51c: ldur            d0, [fp, #-0x28]
    // 0x10ee520: r0 = lerp()
    //     0x10ee520: bl              #0xbfea10  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::lerp
    // 0x10ee524: stur            x0, [fp, #-0x20]
    // 0x10ee528: r0 = UnderlineInputBorder()
    //     0x10ee528: bl              #0xec4de4  ; AllocateUnderlineInputBorderStub -> UnderlineInputBorder (size=0x10)
    // 0x10ee52c: mov             x1, x0
    // 0x10ee530: ldur            x0, [fp, #-0x20]
    // 0x10ee534: StoreField: r1->field_b = r0
    //     0x10ee534: stur            w0, [x1, #0xb]
    // 0x10ee538: ldur            x0, [fp, #-0x18]
    // 0x10ee53c: StoreField: r1->field_7 = r0
    //     0x10ee53c: stur            w0, [x1, #7]
    // 0x10ee540: mov             x0, x1
    // 0x10ee544: LeaveFrame
    //     0x10ee544: mov             SP, fp
    //     0x10ee548: ldp             fp, lr, [SP], #0x10
    // 0x10ee54c: ret
    //     0x10ee54c: ret             
    // 0x10ee550: mov             x2, x3
    // 0x10ee554: cmp             w0, NULL
    // 0x10ee558: b.ne            #0x10ee56c
    // 0x10ee55c: mov             x1, x2
    // 0x10ee560: ldur            d0, [fp, #-0x28]
    // 0x10ee564: r0 = scale()
    //     0x10ee564: bl              #0x12fcfa4  ; [package:flutter/src/material/input_border.dart] UnderlineInputBorder::scale
    // 0x10ee568: b               #0x10ee570
    // 0x10ee56c: r0 = Null
    //     0x10ee56c: mov             x0, NULL
    // 0x10ee570: LeaveFrame
    //     0x10ee570: mov             SP, fp
    //     0x10ee574: ldp             fp, lr, [SP], #0x10
    // 0x10ee578: ret
    //     0x10ee578: ret             
    // 0x10ee57c: r0 = StackOverflowSharedWithFPURegs()
    //     0x10ee57c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x10ee580: b               #0x10ee4d0
  }
  _ lerpTo(/* No info */) {
    // ** addr: 0x10f15d4, size: 0xdc
    // 0x10f15d4: EnterFrame
    //     0x10f15d4: stp             fp, lr, [SP, #-0x10]!
    //     0x10f15d8: mov             fp, SP
    // 0x10f15dc: AllocStack(0x28)
    //     0x10f15dc: sub             SP, SP, #0x28
    // 0x10f15e0: SetupParameters(UnderlineInputBorder this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* d0 => d1, fp-0x28 */)
    //     0x10f15e0: mov             x3, x1
    //     0x10f15e4: mov             x0, x2
    //     0x10f15e8: mov             v1.16b, v0.16b
    //     0x10f15ec: stur            x1, [fp, #-8]
    //     0x10f15f0: stur            x2, [fp, #-0x10]
    //     0x10f15f4: stur            d0, [fp, #-0x28]
    // 0x10f15f8: CheckStackOverflow
    //     0x10f15f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f15fc: cmp             SP, x16
    //     0x10f1600: b.ls            #0x10f16a8
    // 0x10f1604: r1 = LoadClassIdInstr(r0)
    //     0x10f1604: ldur            x1, [x0, #-1]
    //     0x10f1608: ubfx            x1, x1, #0xc, #0x14
    // 0x10f160c: cmp             x1, #0xbc9
    // 0x10f1610: b.ne            #0x10f1688
    // 0x10f1614: LoadField: r1 = r3->field_7
    //     0x10f1614: ldur            w1, [x3, #7]
    // 0x10f1618: DecompressPointer r1
    //     0x10f1618: add             x1, x1, HEAP, lsl #32
    // 0x10f161c: LoadField: r2 = r0->field_7
    //     0x10f161c: ldur            w2, [x0, #7]
    // 0x10f1620: DecompressPointer r2
    //     0x10f1620: add             x2, x2, HEAP, lsl #32
    // 0x10f1624: mov             v0.16b, v1.16b
    // 0x10f1628: r0 = lerp()
    //     0x10f1628: bl              #0xa07be0  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x10f162c: ldur            x1, [fp, #-8]
    // 0x10f1630: stur            x0, [fp, #-0x18]
    // 0x10f1634: LoadField: r2 = r1->field_b
    //     0x10f1634: ldur            w2, [x1, #0xb]
    // 0x10f1638: DecompressPointer r2
    //     0x10f1638: add             x2, x2, HEAP, lsl #32
    // 0x10f163c: ldur            x3, [fp, #-0x10]
    // 0x10f1640: LoadField: r1 = r3->field_b
    //     0x10f1640: ldur            w1, [x3, #0xb]
    // 0x10f1644: DecompressPointer r1
    //     0x10f1644: add             x1, x1, HEAP, lsl #32
    // 0x10f1648: mov             x16, x1
    // 0x10f164c: mov             x1, x2
    // 0x10f1650: mov             x2, x16
    // 0x10f1654: ldur            d0, [fp, #-0x28]
    // 0x10f1658: r0 = lerp()
    //     0x10f1658: bl              #0xbfea10  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::lerp
    // 0x10f165c: stur            x0, [fp, #-0x20]
    // 0x10f1660: r0 = UnderlineInputBorder()
    //     0x10f1660: bl              #0xec4de4  ; AllocateUnderlineInputBorderStub -> UnderlineInputBorder (size=0x10)
    // 0x10f1664: mov             x1, x0
    // 0x10f1668: ldur            x0, [fp, #-0x20]
    // 0x10f166c: StoreField: r1->field_b = r0
    //     0x10f166c: stur            w0, [x1, #0xb]
    // 0x10f1670: ldur            x0, [fp, #-0x18]
    // 0x10f1674: StoreField: r1->field_7 = r0
    //     0x10f1674: stur            w0, [x1, #7]
    // 0x10f1678: mov             x0, x1
    // 0x10f167c: LeaveFrame
    //     0x10f167c: mov             SP, fp
    //     0x10f1680: ldp             fp, lr, [SP], #0x10
    // 0x10f1684: ret
    //     0x10f1684: ret             
    // 0x10f1688: mov             x1, x3
    // 0x10f168c: mov             x3, x0
    // 0x10f1690: mov             x2, x3
    // 0x10f1694: ldur            d0, [fp, #-0x28]
    // 0x10f1698: r0 = lerpTo()
    //     0x10f1698: bl              #0x10f17e8  ; [package:flutter/src/painting/borders.dart] ShapeBorder::lerpTo
    // 0x10f169c: LeaveFrame
    //     0x10f169c: mov             SP, fp
    //     0x10f16a0: ldp             fp, lr, [SP], #0x10
    // 0x10f16a4: ret
    //     0x10f16a4: ret             
    // 0x10f16a8: r0 = StackOverflowSharedWithFPURegs()
    //     0x10f16a8: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x10f16ac: b               #0x10f1604
  }
  _ ==(/* No info */) {
    // ** addr: 0x12965c8, size: 0x108
    // 0x12965c8: EnterFrame
    //     0x12965c8: stp             fp, lr, [SP, #-0x10]!
    //     0x12965cc: mov             fp, SP
    // 0x12965d0: AllocStack(0x10)
    //     0x12965d0: sub             SP, SP, #0x10
    // 0x12965d4: CheckStackOverflow
    //     0x12965d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12965d8: cmp             SP, x16
    //     0x12965dc: b.ls            #0x12966c8
    // 0x12965e0: ldr             x0, [fp, #0x10]
    // 0x12965e4: cmp             w0, NULL
    // 0x12965e8: b.ne            #0x12965fc
    // 0x12965ec: r0 = false
    //     0x12965ec: add             x0, NULL, #0x30  ; false
    // 0x12965f0: LeaveFrame
    //     0x12965f0: mov             SP, fp
    //     0x12965f4: ldp             fp, lr, [SP], #0x10
    // 0x12965f8: ret
    //     0x12965f8: ret             
    // 0x12965fc: ldr             x1, [fp, #0x18]
    // 0x1296600: cmp             w1, w0
    // 0x1296604: b.ne            #0x1296618
    // 0x1296608: r0 = true
    //     0x1296608: add             x0, NULL, #0x20  ; true
    // 0x129660c: LeaveFrame
    //     0x129660c: mov             SP, fp
    //     0x1296610: ldp             fp, lr, [SP], #0x10
    // 0x1296614: ret
    //     0x1296614: ret             
    // 0x1296618: str             x0, [SP]
    // 0x129661c: r0 = runtimeType()
    //     0x129661c: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x1296620: r1 = LoadClassIdInstr(r0)
    //     0x1296620: ldur            x1, [x0, #-1]
    //     0x1296624: ubfx            x1, x1, #0xc, #0x14
    // 0x1296628: r16 = UnderlineInputBorder
    //     0x1296628: add             x16, PP, #0xab, lsl #12  ; [pp+0xab3d8] Type: UnderlineInputBorder
    //     0x129662c: ldr             x16, [x16, #0x3d8]
    // 0x1296630: stp             x16, x0, [SP]
    // 0x1296634: mov             x0, x1
    // 0x1296638: mov             lr, x0
    // 0x129663c: ldr             lr, [x21, lr, lsl #3]
    // 0x1296640: blr             lr
    // 0x1296644: tbz             w0, #4, #0x1296658
    // 0x1296648: r0 = false
    //     0x1296648: add             x0, NULL, #0x30  ; false
    // 0x129664c: LeaveFrame
    //     0x129664c: mov             SP, fp
    //     0x1296650: ldp             fp, lr, [SP], #0x10
    // 0x1296654: ret
    //     0x1296654: ret             
    // 0x1296658: ldr             x0, [fp, #0x10]
    // 0x129665c: r1 = 60
    //     0x129665c: mov             x1, #0x3c
    // 0x1296660: branchIfSmi(r0, 0x129666c)
    //     0x1296660: tbz             w0, #0, #0x129666c
    // 0x1296664: r1 = LoadClassIdInstr(r0)
    //     0x1296664: ldur            x1, [x0, #-1]
    //     0x1296668: ubfx            x1, x1, #0xc, #0x14
    // 0x129666c: cmp             x1, #0xbc9
    // 0x1296670: b.ne            #0x12966b8
    // 0x1296674: ldr             x1, [fp, #0x18]
    // 0x1296678: LoadField: r2 = r0->field_7
    //     0x1296678: ldur            w2, [x0, #7]
    // 0x129667c: DecompressPointer r2
    //     0x129667c: add             x2, x2, HEAP, lsl #32
    // 0x1296680: LoadField: r3 = r1->field_7
    //     0x1296680: ldur            w3, [x1, #7]
    // 0x1296684: DecompressPointer r3
    //     0x1296684: add             x3, x3, HEAP, lsl #32
    // 0x1296688: stp             x3, x2, [SP]
    // 0x129668c: r0 = ==()
    //     0x129668c: bl              #0x1278854  ; [package:flutter/src/painting/borders.dart] BorderSide::==
    // 0x1296690: tbnz            w0, #4, #0x12966b8
    // 0x1296694: ldr             x1, [fp, #0x18]
    // 0x1296698: ldr             x0, [fp, #0x10]
    // 0x129669c: LoadField: r2 = r0->field_b
    //     0x129669c: ldur            w2, [x0, #0xb]
    // 0x12966a0: DecompressPointer r2
    //     0x12966a0: add             x2, x2, HEAP, lsl #32
    // 0x12966a4: LoadField: r0 = r1->field_b
    //     0x12966a4: ldur            w0, [x1, #0xb]
    // 0x12966a8: DecompressPointer r0
    //     0x12966a8: add             x0, x0, HEAP, lsl #32
    // 0x12966ac: stp             x0, x2, [SP]
    // 0x12966b0: r0 = ==()
    //     0x12966b0: bl              #0x1298058  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::==
    // 0x12966b4: b               #0x12966bc
    // 0x12966b8: r0 = false
    //     0x12966b8: add             x0, NULL, #0x30  ; false
    // 0x12966bc: LeaveFrame
    //     0x12966bc: mov             SP, fp
    //     0x12966c0: ldp             fp, lr, [SP], #0x10
    // 0x12966c4: ret
    //     0x12966c4: ret             
    // 0x12966c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12966c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12966cc: b               #0x12965e0
  }
  _ paintInterior(/* No info */) {
    // ** addr: 0x12eca10, size: 0x64
    // 0x12eca10: EnterFrame
    //     0x12eca10: stp             fp, lr, [SP, #-0x10]!
    //     0x12eca14: mov             fp, SP
    // 0x12eca18: AllocStack(0x10)
    //     0x12eca18: sub             SP, SP, #0x10
    // 0x12eca1c: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */, dynamic _ /* r3 => r2 */, dynamic _ /* r5 => r3, fp-0x10 */)
    //     0x12eca1c: mov             x0, x2
    //     0x12eca20: stur            x2, [fp, #-8]
    //     0x12eca24: mov             x2, x3
    //     0x12eca28: mov             x3, x5
    //     0x12eca2c: stur            x5, [fp, #-0x10]
    // 0x12eca30: CheckStackOverflow
    //     0x12eca30: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12eca34: cmp             SP, x16
    //     0x12eca38: b.ls            #0x12eca6c
    // 0x12eca3c: LoadField: r4 = r1->field_b
    //     0x12eca3c: ldur            w4, [x1, #0xb]
    // 0x12eca40: DecompressPointer r4
    //     0x12eca40: add             x4, x4, HEAP, lsl #32
    // 0x12eca44: mov             x1, x4
    // 0x12eca48: r0 = toRRect()
    //     0x12eca48: bl              #0xb77a10  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0x12eca4c: ldur            x1, [fp, #-8]
    // 0x12eca50: mov             x2, x0
    // 0x12eca54: ldur            x3, [fp, #-0x10]
    // 0x12eca58: r0 = drawRRect()
    //     0x12eca58: bl              #0xb6dce0  ; [dart:ui] _NativeCanvas::drawRRect
    // 0x12eca5c: r0 = Null
    //     0x12eca5c: mov             x0, NULL
    // 0x12eca60: LeaveFrame
    //     0x12eca60: mov             SP, fp
    //     0x12eca64: ldp             fp, lr, [SP], #0x10
    // 0x12eca68: ret
    //     0x12eca68: ret             
    // 0x12eca6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12eca6c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12eca70: b               #0x12eca3c
  }
  _ paint(/* No info */) {
    // ** addr: 0x12edd14, size: 0x448
    // 0x12edd14: EnterFrame
    //     0x12edd14: stp             fp, lr, [SP, #-0x10]!
    //     0x12edd18: mov             fp, SP
    // 0x12edd1c: AllocStack(0x60)
    //     0x12edd1c: sub             SP, SP, #0x60
    // 0x12edd20: SetupParameters(UnderlineInputBorder this /* r1 => r0 */, dynamic _ /* r2 => r1, fp-0x28 */, dynamic _ /* r3 => r2, fp-0x30 */, {dynamic gapExtent, dynamic gapPercentage, dynamic gapStart, dynamic textDirection = Null /* r7, fp-0x20 */})
    //     0x12edd20: mov             x0, x1
    //     0x12edd24: mov             x1, x2
    //     0x12edd28: stur            x2, [fp, #-0x28]
    //     0x12edd2c: mov             x2, x3
    //     0x12edd30: stur            x3, [fp, #-0x30]
    //     0x12edd34: ldur            w3, [x4, #0x13]
    //     0x12edd38: ldur            w5, [x4, #0x1f]
    //     0x12edd3c: add             x5, x5, HEAP, lsl #32
    //     0x12edd40: add             x16, PP, #0xab, lsl #12  ; [pp+0xab3c0] "gapExtent"
    //     0x12edd44: ldr             x16, [x16, #0x3c0]
    //     0x12edd48: cmp             w5, w16
    //     0x12edd4c: b.ne            #0x12edd58
    //     0x12edd50: mov             x5, #1
    //     0x12edd54: b               #0x12edd5c
    //     0x12edd58: mov             x5, #0
    //     0x12edd5c: lsl             x6, x5, #1
    //     0x12edd60: lsl             w7, w6, #1
    //     0x12edd64: add             w8, w7, #8
    //     0x12edd68: add             x16, x4, w8, sxtw #1
    //     0x12edd6c: ldur            w7, [x16, #0xf]
    //     0x12edd70: add             x7, x7, HEAP, lsl #32
    //     0x12edd74: add             x16, PP, #0xab, lsl #12  ; [pp+0xab3c8] "gapPercentage"
    //     0x12edd78: ldr             x16, [x16, #0x3c8]
    //     0x12edd7c: cmp             w7, w16
    //     0x12edd80: b.ne            #0x12edd90
    //     0x12edd84: add             w5, w6, #2
    //     0x12edd88: sbfx            x6, x5, #1, #0x1f
    //     0x12edd8c: mov             x5, x6
    //     0x12edd90: lsl             x6, x5, #1
    //     0x12edd94: lsl             w7, w6, #1
    //     0x12edd98: add             w8, w7, #8
    //     0x12edd9c: add             x16, x4, w8, sxtw #1
    //     0x12edda0: ldur            w7, [x16, #0xf]
    //     0x12edda4: add             x7, x7, HEAP, lsl #32
    //     0x12edda8: add             x16, PP, #0xab, lsl #12  ; [pp+0xab3d0] "gapStart"
    //     0x12eddac: ldr             x16, [x16, #0x3d0]
    //     0x12eddb0: cmp             w7, w16
    //     0x12eddb4: b.ne            #0x12eddc4
    //     0x12eddb8: add             w5, w6, #2
    //     0x12eddbc: sbfx            x6, x5, #1, #0x1f
    //     0x12eddc0: mov             x5, x6
    //     0x12eddc4: lsl             x6, x5, #1
    //     0x12eddc8: lsl             w5, w6, #1
    //     0x12eddcc: add             w6, w5, #8
    //     0x12eddd0: add             x16, x4, w6, sxtw #1
    //     0x12eddd4: ldur            w7, [x16, #0xf]
    //     0x12eddd8: add             x7, x7, HEAP, lsl #32
    //     0x12edddc: add             x16, PP, #0x15, lsl #12  ; [pp+0x15210] "textDirection"
    //     0x12edde0: ldr             x16, [x16, #0x210]
    //     0x12edde4: cmp             w7, w16
    //     0x12edde8: b.ne            #0x12ede10
    //     0x12eddec: add             w6, w5, #0xa
    //     0x12eddf0: add             x16, x4, w6, sxtw #1
    //     0x12eddf4: ldur            w5, [x16, #0xf]
    //     0x12eddf8: add             x5, x5, HEAP, lsl #32
    //     0x12eddfc: sub             w4, w3, w5
    //     0x12ede00: add             x3, fp, w4, sxtw #2
    //     0x12ede04: ldr             x3, [x3, #8]
    //     0x12ede08: mov             x7, x3
    //     0x12ede0c: b               #0x12ede14
    //     0x12ede10: mov             x7, NULL
    //     0x12ede14: stur            x7, [fp, #-0x20]
    // 0x12ede18: CheckStackOverflow
    //     0x12ede18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12ede1c: cmp             SP, x16
    //     0x12ede20: b.ls            #0x12ee154
    // 0x12ede24: LoadField: r3 = r0->field_7
    //     0x12ede24: ldur            w3, [x0, #7]
    // 0x12ede28: DecompressPointer r3
    //     0x12ede28: add             x3, x3, HEAP, lsl #32
    // 0x12ede2c: stur            x3, [fp, #-0x18]
    // 0x12ede30: LoadField: r4 = r3->field_13
    //     0x12ede30: ldur            w4, [x3, #0x13]
    // 0x12ede34: DecompressPointer r4
    //     0x12ede34: add             x4, x4, HEAP, lsl #32
    // 0x12ede38: r16 = Instance_BorderStyle
    //     0x12ede38: add             x16, PP, #0x89, lsl #12  ; [pp+0x89518] Obj!BorderStyle@12c4981
    //     0x12ede3c: ldr             x16, [x16, #0x518]
    // 0x12ede40: cmp             w4, w16
    // 0x12ede44: b.ne            #0x12ede58
    // 0x12ede48: r0 = Null
    //     0x12ede48: mov             x0, NULL
    // 0x12ede4c: LeaveFrame
    //     0x12ede4c: mov             SP, fp
    //     0x12ede50: ldp             fp, lr, [SP], #0x10
    // 0x12ede54: ret
    //     0x12ede54: ret             
    // 0x12ede58: LoadField: r4 = r0->field_b
    //     0x12ede58: ldur            w4, [x0, #0xb]
    // 0x12ede5c: DecompressPointer r4
    //     0x12ede5c: add             x4, x4, HEAP, lsl #32
    // 0x12ede60: stur            x4, [fp, #-0x10]
    // 0x12ede64: LoadField: r0 = r4->field_f
    //     0x12ede64: ldur            w0, [x4, #0xf]
    // 0x12ede68: DecompressPointer r0
    //     0x12ede68: add             x0, x0, HEAP, lsl #32
    // 0x12ede6c: stur            x0, [fp, #-8]
    // 0x12ede70: r16 = Instance_Radius
    //     0x12ede70: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12ede74: ldr             x16, [x16, #0x1a0]
    // 0x12ede78: cmp             w0, w16
    // 0x12ede7c: b.ne            #0x12ede94
    // 0x12ede80: mov             x2, x4
    // 0x12ede84: mov             x1, x0
    // 0x12ede88: r0 = Instance_Radius
    //     0x12ede88: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12ede8c: ldr             x0, [x0, #0x1a0]
    // 0x12ede90: b               #0x12edf00
    // 0x12ede94: r16 = Radius
    //     0x12ede94: add             x16, PP, #0x26, lsl #12  ; [pp+0x26960] Type: Radius
    //     0x12ede98: ldr             x16, [x16, #0x960]
    // 0x12ede9c: r30 = Radius
    //     0x12ede9c: add             lr, PP, #0x26, lsl #12  ; [pp+0x26960] Type: Radius
    //     0x12edea0: ldr             lr, [lr, #0x960]
    // 0x12edea4: stp             lr, x16, [SP]
    // 0x12edea8: r0 = ==()
    //     0x12edea8: bl              #0x12b7fbc  ; [dart:core] _Type::==
    // 0x12edeac: tbz             w0, #4, #0x12edec4
    // 0x12edeb0: ldur            x2, [fp, #-0x30]
    // 0x12edeb4: r0 = Instance_Radius
    //     0x12edeb4: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12edeb8: ldr             x0, [x0, #0x1a0]
    // 0x12edebc: d0 = 2.000000
    //     0x12edebc: fmov            d0, #2.00000000
    // 0x12edec0: b               #0x12ee04c
    // 0x12edec4: ldur            x1, [fp, #-8]
    // 0x12edec8: r0 = Instance_Radius
    //     0x12edec8: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12edecc: ldr             x0, [x0, #0x1a0]
    // 0x12eded0: LoadField: d0 = r0->field_7
    //     0x12eded0: ldur            d0, [x0, #7]
    // 0x12eded4: LoadField: d1 = r1->field_7
    //     0x12eded4: ldur            d1, [x1, #7]
    // 0x12eded8: fcmp            d0, d1
    // 0x12ededc: b.ne            #0x12ee044
    // 0x12edee0: LoadField: d0 = r0->field_f
    //     0x12edee0: ldur            d0, [x0, #0xf]
    // 0x12edee4: LoadField: d1 = r1->field_f
    //     0x12edee4: ldur            d1, [x1, #0xf]
    // 0x12edee8: fcmp            d0, d1
    // 0x12edeec: b.eq            #0x12edefc
    // 0x12edef0: ldur            x2, [fp, #-0x30]
    // 0x12edef4: d0 = 2.000000
    //     0x12edef4: fmov            d0, #2.00000000
    // 0x12edef8: b               #0x12ee04c
    // 0x12edefc: ldur            x2, [fp, #-0x10]
    // 0x12edf00: LoadField: r3 = r2->field_13
    //     0x12edf00: ldur            w3, [x2, #0x13]
    // 0x12edf04: DecompressPointer r3
    //     0x12edf04: add             x3, x3, HEAP, lsl #32
    // 0x12edf08: stur            x3, [fp, #-0x38]
    // 0x12edf0c: r16 = Instance_Radius
    //     0x12edf0c: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12edf10: ldr             x16, [x16, #0x1a0]
    // 0x12edf14: cmp             w3, w16
    // 0x12edf18: b.eq            #0x12edf84
    // 0x12edf1c: r16 = Radius
    //     0x12edf1c: add             x16, PP, #0x26, lsl #12  ; [pp+0x26960] Type: Radius
    //     0x12edf20: ldr             x16, [x16, #0x960]
    // 0x12edf24: r30 = Radius
    //     0x12edf24: add             lr, PP, #0x26, lsl #12  ; [pp+0x26960] Type: Radius
    //     0x12edf28: ldr             lr, [lr, #0x960]
    // 0x12edf2c: stp             lr, x16, [SP]
    // 0x12edf30: r0 = ==()
    //     0x12edf30: bl              #0x12b7fbc  ; [dart:core] _Type::==
    // 0x12edf34: tbz             w0, #4, #0x12edf4c
    // 0x12edf38: ldur            x2, [fp, #-0x30]
    // 0x12edf3c: r0 = Instance_Radius
    //     0x12edf3c: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12edf40: ldr             x0, [x0, #0x1a0]
    // 0x12edf44: d0 = 2.000000
    //     0x12edf44: fmov            d0, #2.00000000
    // 0x12edf48: b               #0x12ee04c
    // 0x12edf4c: ldur            x1, [fp, #-0x38]
    // 0x12edf50: r0 = Instance_Radius
    //     0x12edf50: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12edf54: ldr             x0, [x0, #0x1a0]
    // 0x12edf58: LoadField: d0 = r0->field_7
    //     0x12edf58: ldur            d0, [x0, #7]
    // 0x12edf5c: LoadField: d1 = r1->field_7
    //     0x12edf5c: ldur            d1, [x1, #7]
    // 0x12edf60: fcmp            d0, d1
    // 0x12edf64: b.ne            #0x12ee038
    // 0x12edf68: LoadField: d0 = r0->field_f
    //     0x12edf68: ldur            d0, [x0, #0xf]
    // 0x12edf6c: LoadField: d1 = r1->field_f
    //     0x12edf6c: ldur            d1, [x1, #0xf]
    // 0x12edf70: fcmp            d0, d1
    // 0x12edf74: b.eq            #0x12edf84
    // 0x12edf78: ldur            x2, [fp, #-0x30]
    // 0x12edf7c: d0 = 2.000000
    //     0x12edf7c: fmov            d0, #2.00000000
    // 0x12edf80: b               #0x12ee04c
    // 0x12edf84: ldur            x2, [fp, #-0x30]
    // 0x12edf88: ldur            x1, [fp, #-0x18]
    // 0x12edf8c: d0 = 2.000000
    //     0x12edf8c: fmov            d0, #2.00000000
    // 0x12edf90: LoadField: d1 = r1->field_b
    //     0x12edf90: ldur            d1, [x1, #0xb]
    // 0x12edf94: fdiv            d2, d1, d0
    // 0x12edf98: stur            d2, [fp, #-0x48]
    // 0x12edf9c: r0 = Offset()
    //     0x12edf9c: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x12edfa0: stur            x0, [fp, #-0x38]
    // 0x12edfa4: StoreField: r0->field_7 = rZR
    //     0x12edfa4: stur            xzr, [x0, #7]
    // 0x12edfa8: ldur            d0, [fp, #-0x48]
    // 0x12edfac: StoreField: r0->field_f = d0
    //     0x12edfac: stur            d0, [x0, #0xf]
    // 0x12edfb0: ldur            x2, [fp, #-0x30]
    // 0x12edfb4: LoadField: d0 = r2->field_7
    //     0x12edfb4: ldur            d0, [x2, #7]
    // 0x12edfb8: stur            d0, [fp, #-0x50]
    // 0x12edfbc: LoadField: d1 = r2->field_1f
    //     0x12edfbc: ldur            d1, [x2, #0x1f]
    // 0x12edfc0: stur            d1, [fp, #-0x48]
    // 0x12edfc4: r0 = Offset()
    //     0x12edfc4: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x12edfc8: ldur            d0, [fp, #-0x50]
    // 0x12edfcc: StoreField: r0->field_7 = d0
    //     0x12edfcc: stur            d0, [x0, #7]
    // 0x12edfd0: ldur            d0, [fp, #-0x48]
    // 0x12edfd4: StoreField: r0->field_f = d0
    //     0x12edfd4: stur            d0, [x0, #0xf]
    // 0x12edfd8: mov             x1, x0
    // 0x12edfdc: ldur            x2, [fp, #-0x38]
    // 0x12edfe0: r0 = -()
    //     0x12edfe0: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0x12edfe4: ldur            x2, [fp, #-0x30]
    // 0x12edfe8: stur            x0, [fp, #-0x40]
    // 0x12edfec: ArrayLoad: d0 = r2[0]  ; List_8
    //     0x12edfec: ldur            d0, [x2, #0x17]
    // 0x12edff0: stur            d0, [fp, #-0x50]
    // 0x12edff4: r0 = Offset()
    //     0x12edff4: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x12edff8: ldur            d0, [fp, #-0x50]
    // 0x12edffc: StoreField: r0->field_7 = d0
    //     0x12edffc: stur            d0, [x0, #7]
    // 0x12ee000: ldur            d0, [fp, #-0x48]
    // 0x12ee004: StoreField: r0->field_f = d0
    //     0x12ee004: stur            d0, [x0, #0xf]
    // 0x12ee008: mov             x1, x0
    // 0x12ee00c: ldur            x2, [fp, #-0x38]
    // 0x12ee010: r0 = -()
    //     0x12ee010: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0x12ee014: ldur            x1, [fp, #-0x18]
    // 0x12ee018: stur            x0, [fp, #-0x38]
    // 0x12ee01c: r0 = toPaint()
    //     0x12ee01c: bl              #0x12ed2c0  ; [package:flutter/src/painting/borders.dart] BorderSide::toPaint
    // 0x12ee020: ldur            x1, [fp, #-0x28]
    // 0x12ee024: ldur            x2, [fp, #-0x40]
    // 0x12ee028: ldur            x3, [fp, #-0x38]
    // 0x12ee02c: mov             x5, x0
    // 0x12ee030: r0 = drawLine()
    //     0x12ee030: bl              #0xb6932c  ; [dart:ui] _NativeCanvas::drawLine
    // 0x12ee034: b               #0x12ee144
    // 0x12ee038: ldur            x2, [fp, #-0x30]
    // 0x12ee03c: d0 = 2.000000
    //     0x12ee03c: fmov            d0, #2.00000000
    // 0x12ee040: b               #0x12ee04c
    // 0x12ee044: ldur            x2, [fp, #-0x30]
    // 0x12ee048: d0 = 2.000000
    //     0x12ee048: fmov            d0, #2.00000000
    // 0x12ee04c: ldur            x1, [fp, #-0x18]
    // 0x12ee050: ldur            x3, [fp, #-0x10]
    // 0x12ee054: LoadField: d1 = r2->field_1f
    //     0x12ee054: ldur            d1, [x2, #0x1f]
    // 0x12ee058: LoadField: d2 = r2->field_f
    //     0x12ee058: ldur            d2, [x2, #0xf]
    // 0x12ee05c: fsub            d3, d1, d2
    // 0x12ee060: fdiv            d1, d3, d0
    // 0x12ee064: stur            d1, [fp, #-0x48]
    // 0x12ee068: r0 = Radius()
    //     0x12ee068: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x12ee06c: ldur            d0, [fp, #-0x48]
    // 0x12ee070: StoreField: r0->field_7 = d0
    //     0x12ee070: stur            d0, [x0, #7]
    // 0x12ee074: StoreField: r0->field_f = d0
    //     0x12ee074: stur            d0, [x0, #0xf]
    // 0x12ee078: str             x0, [SP]
    // 0x12ee07c: ldur            x1, [fp, #-8]
    // 0x12ee080: r4 = const [0, 0x2, 0x1, 0x1, maximum, 0x1, null]
    //     0x12ee080: add             x4, PP, #0xab, lsl #12  ; [pp+0xab3e0] List(7) [0, 0x2, 0x1, 0x1, "maximum", 0x1, Null]
    //     0x12ee084: ldr             x4, [x4, #0x3e0]
    // 0x12ee088: r0 = clamp()
    //     0x12ee088: bl              #0xb77b88  ; [dart:ui] Radius::clamp
    // 0x12ee08c: mov             x1, x0
    // 0x12ee090: ldur            x0, [fp, #-0x10]
    // 0x12ee094: stur            x1, [fp, #-0x38]
    // 0x12ee098: LoadField: r2 = r0->field_13
    //     0x12ee098: ldur            w2, [x0, #0x13]
    // 0x12ee09c: DecompressPointer r2
    //     0x12ee09c: add             x2, x2, HEAP, lsl #32
    // 0x12ee0a0: stur            x2, [fp, #-8]
    // 0x12ee0a4: r0 = Radius()
    //     0x12ee0a4: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x12ee0a8: ldur            d0, [fp, #-0x48]
    // 0x12ee0ac: StoreField: r0->field_7 = d0
    //     0x12ee0ac: stur            d0, [x0, #7]
    // 0x12ee0b0: StoreField: r0->field_f = d0
    //     0x12ee0b0: stur            d0, [x0, #0xf]
    // 0x12ee0b4: str             x0, [SP]
    // 0x12ee0b8: ldur            x1, [fp, #-8]
    // 0x12ee0bc: r4 = const [0, 0x2, 0x1, 0x1, maximum, 0x1, null]
    //     0x12ee0bc: add             x4, PP, #0xab, lsl #12  ; [pp+0xab3e0] List(7) [0, 0x2, 0x1, 0x1, "maximum", 0x1, Null]
    //     0x12ee0c0: ldr             x4, [x4, #0x3e0]
    // 0x12ee0c4: r0 = clamp()
    //     0x12ee0c4: bl              #0xb77b88  ; [dart:ui] Radius::clamp
    // 0x12ee0c8: stur            x0, [fp, #-8]
    // 0x12ee0cc: r0 = BorderRadius()
    //     0x12ee0cc: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x12ee0d0: mov             x2, x0
    // 0x12ee0d4: r0 = Instance_Radius
    //     0x12ee0d4: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12ee0d8: ldr             x0, [x0, #0x1a0]
    // 0x12ee0dc: stur            x2, [fp, #-0x10]
    // 0x12ee0e0: StoreField: r2->field_7 = r0
    //     0x12ee0e0: stur            w0, [x2, #7]
    // 0x12ee0e4: StoreField: r2->field_b = r0
    //     0x12ee0e4: stur            w0, [x2, #0xb]
    // 0x12ee0e8: ldur            x0, [fp, #-0x38]
    // 0x12ee0ec: StoreField: r2->field_f = r0
    //     0x12ee0ec: stur            w0, [x2, #0xf]
    // 0x12ee0f0: ldur            x0, [fp, #-8]
    // 0x12ee0f4: StoreField: r2->field_13 = r0
    //     0x12ee0f4: stur            w0, [x2, #0x13]
    // 0x12ee0f8: r16 = -1.000000
    //     0x12ee0f8: add             x16, PP, #0x13, lsl #12  ; [pp+0x132a8] -1
    //     0x12ee0fc: ldr             x16, [x16, #0x2a8]
    // 0x12ee100: str             x16, [SP]
    // 0x12ee104: ldur            x1, [fp, #-0x18]
    // 0x12ee108: r4 = const [0, 0x2, 0x1, 0x1, strokeAlign, 0x1, null]
    //     0x12ee108: add             x4, PP, #0xab, lsl #12  ; [pp+0xab3e8] List(7) [0, 0x2, 0x1, 0x1, "strokeAlign", 0x1, Null]
    //     0x12ee10c: ldr             x4, [x4, #0x3e8]
    // 0x12ee110: r0 = copyWith()
    //     0x12ee110: bl              #0xdf1d5c  ; [package:flutter/src/painting/borders.dart] BorderSide::copyWith
    // 0x12ee114: mov             x1, x0
    // 0x12ee118: ldur            x0, [fp, #-0x18]
    // 0x12ee11c: LoadField: r6 = r0->field_7
    //     0x12ee11c: ldur            w6, [x0, #7]
    // 0x12ee120: DecompressPointer r6
    //     0x12ee120: add             x6, x6, HEAP, lsl #32
    // 0x12ee124: mov             x5, x1
    // 0x12ee128: ldur            x1, [fp, #-0x28]
    // 0x12ee12c: ldur            x2, [fp, #-0x30]
    // 0x12ee130: ldur            x3, [fp, #-0x10]
    // 0x12ee134: ldur            x7, [fp, #-0x20]
    // 0x12ee138: r4 = const [0, 0x6, 0, 0x6, null]
    //     0x12ee138: add             x4, PP, #0x20, lsl #12  ; [pp+0x20fa8] List(5) [0, 0x6, 0, 0x6, Null]
    //     0x12ee13c: ldr             x4, [x4, #0xfa8]
    // 0x12ee140: r0 = paintNonUniformBorder()
    //     0x12ee140: bl              #0x12ee15c  ; [package:flutter/src/painting/box_border.dart] BoxBorder::paintNonUniformBorder
    // 0x12ee144: r0 = Null
    //     0x12ee144: mov             x0, NULL
    // 0x12ee148: LeaveFrame
    //     0x12ee148: mov             SP, fp
    //     0x12ee14c: ldp             fp, lr, [SP], #0x10
    // 0x12ee150: ret
    //     0x12ee150: ret             
    // 0x12ee154: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12ee154: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12ee158: b               #0x12ede24
  }
  get _ dimensions(/* No info */) {
    // ** addr: 0x12f5628, size: 0x40
    // 0x12f5628: EnterFrame
    //     0x12f5628: stp             fp, lr, [SP, #-0x10]!
    //     0x12f562c: mov             fp, SP
    // 0x12f5630: AllocStack(0x8)
    //     0x12f5630: sub             SP, SP, #8
    // 0x12f5634: LoadField: r0 = r1->field_7
    //     0x12f5634: ldur            w0, [x1, #7]
    // 0x12f5638: DecompressPointer r0
    //     0x12f5638: add             x0, x0, HEAP, lsl #32
    // 0x12f563c: LoadField: d0 = r0->field_b
    //     0x12f563c: ldur            d0, [x0, #0xb]
    // 0x12f5640: stur            d0, [fp, #-8]
    // 0x12f5644: r0 = EdgeInsets()
    //     0x12f5644: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x12f5648: StoreField: r0->field_7 = rZR
    //     0x12f5648: stur            xzr, [x0, #7]
    // 0x12f564c: StoreField: r0->field_f = rZR
    //     0x12f564c: stur            xzr, [x0, #0xf]
    // 0x12f5650: ArrayStore: r0[0] = rZR  ; List_8
    //     0x12f5650: stur            xzr, [x0, #0x17]
    // 0x12f5654: ldur            d0, [fp, #-8]
    // 0x12f5658: StoreField: r0->field_1f = d0
    //     0x12f5658: stur            d0, [x0, #0x1f]
    // 0x12f565c: LeaveFrame
    //     0x12f565c: mov             SP, fp
    //     0x12f5660: ldp             fp, lr, [SP], #0x10
    // 0x12f5664: ret
    //     0x12f5664: ret             
  }
  _ scale(/* No info */) {
    // ** addr: 0x12fcfa4, size: 0x58
    // 0x12fcfa4: EnterFrame
    //     0x12fcfa4: stp             fp, lr, [SP, #-0x10]!
    //     0x12fcfa8: mov             fp, SP
    // 0x12fcfac: AllocStack(0x8)
    //     0x12fcfac: sub             SP, SP, #8
    // 0x12fcfb0: CheckStackOverflow
    //     0x12fcfb0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fcfb4: cmp             SP, x16
    //     0x12fcfb8: b.ls            #0x12fcff4
    // 0x12fcfbc: LoadField: r0 = r1->field_7
    //     0x12fcfbc: ldur            w0, [x1, #7]
    // 0x12fcfc0: DecompressPointer r0
    //     0x12fcfc0: add             x0, x0, HEAP, lsl #32
    // 0x12fcfc4: mov             x1, x0
    // 0x12fcfc8: r0 = scale()
    //     0x12fcfc8: bl              #0x12fc608  ; [package:flutter/src/painting/borders.dart] BorderSide::scale
    // 0x12fcfcc: stur            x0, [fp, #-8]
    // 0x12fcfd0: r0 = UnderlineInputBorder()
    //     0x12fcfd0: bl              #0xec4de4  ; AllocateUnderlineInputBorderStub -> UnderlineInputBorder (size=0x10)
    // 0x12fcfd4: r1 = Instance_BorderRadius
    //     0x12fcfd4: add             x1, PP, #0xab, lsl #12  ; [pp+0xab3f0] Obj!BorderRadius@129e391
    //     0x12fcfd8: ldr             x1, [x1, #0x3f0]
    // 0x12fcfdc: StoreField: r0->field_b = r1
    //     0x12fcfdc: stur            w1, [x0, #0xb]
    // 0x12fcfe0: ldur            x1, [fp, #-8]
    // 0x12fcfe4: StoreField: r0->field_7 = r1
    //     0x12fcfe4: stur            w1, [x0, #7]
    // 0x12fcfe8: LeaveFrame
    //     0x12fcfe8: mov             SP, fp
    //     0x12fcfec: ldp             fp, lr, [SP], #0x10
    // 0x12fcff0: ret
    //     0x12fcff0: ret             
    // 0x12fcff4: r0 = StackOverflowSharedWithFPURegs()
    //     0x12fcff4: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12fcff8: b               #0x12fcfbc
  }
  _ getOuterPath(/* No info */) {
    // ** addr: 0x1300acc, size: 0x160
    // 0x1300acc: EnterFrame
    //     0x1300acc: stp             fp, lr, [SP, #-0x10]!
    //     0x1300ad0: mov             fp, SP
    // 0x1300ad4: AllocStack(0x30)
    //     0x1300ad4: sub             SP, SP, #0x30
    // 0x1300ad8: SetupParameters(UnderlineInputBorder this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x1300ad8: stur            x1, [fp, #-8]
    //     0x1300adc: stur            x2, [fp, #-0x10]
    // 0x1300ae0: CheckStackOverflow
    //     0x1300ae0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1300ae4: cmp             SP, x16
    //     0x1300ae8: b.ls            #0x1300c20
    // 0x1300aec: r0 = _NativePath()
    //     0x1300aec: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0x1300af0: mov             x1, x0
    // 0x1300af4: stur            x0, [fp, #-0x18]
    // 0x1300af8: r0 = __constructor$Method$FfiNative()
    //     0x1300af8: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0x1300afc: ldur            x0, [fp, #-8]
    // 0x1300b00: LoadField: r1 = r0->field_b
    //     0x1300b00: ldur            w1, [x0, #0xb]
    // 0x1300b04: DecompressPointer r1
    //     0x1300b04: add             x1, x1, HEAP, lsl #32
    // 0x1300b08: ldur            x2, [fp, #-0x10]
    // 0x1300b0c: r0 = toRRect()
    //     0x1300b0c: bl              #0xb77a10  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0x1300b10: stur            x0, [fp, #-8]
    // 0x1300b14: LoadField: d0 = r0->field_b
    //     0x1300b14: ldur            d0, [x0, #0xb]
    // 0x1300b18: fcvt            s1, d0
    // 0x1300b1c: stur            d1, [fp, #-0x28]
    // 0x1300b20: r4 = 24
    //     0x1300b20: mov             x4, #0x18
    // 0x1300b24: r0 = AllocateFloat32Array()
    //     0x1300b24: bl              #0x13defe8  ; AllocateFloat32ArrayStub
    // 0x1300b28: ldur            d0, [fp, #-0x28]
    // 0x1300b2c: stur            x0, [fp, #-0x10]
    // 0x1300b30: ArrayStore: r0[0] = d0  ; List_8
    //     0x1300b30: stur            s0, [x0, #0x17]
    // 0x1300b34: ldur            x1, [fp, #-8]
    // 0x1300b38: LoadField: d0 = r1->field_13
    //     0x1300b38: ldur            d0, [x1, #0x13]
    // 0x1300b3c: fcvt            s1, d0
    // 0x1300b40: StoreField: r0->field_1b = d1
    //     0x1300b40: stur            s1, [x0, #0x1b]
    // 0x1300b44: LoadField: d0 = r1->field_1b
    //     0x1300b44: ldur            d0, [x1, #0x1b]
    // 0x1300b48: fcvt            s1, d0
    // 0x1300b4c: StoreField: r0->field_1f = d1
    //     0x1300b4c: stur            s1, [x0, #0x1f]
    // 0x1300b50: LoadField: d0 = r1->field_23
    //     0x1300b50: ldur            d0, [x1, #0x23]
    // 0x1300b54: fcvt            s1, d0
    // 0x1300b58: StoreField: r0->field_23 = d1
    //     0x1300b58: stur            s1, [x0, #0x23]
    // 0x1300b5c: LoadField: d0 = r1->field_2b
    //     0x1300b5c: ldur            d0, [x1, #0x2b]
    // 0x1300b60: fcvt            s1, d0
    // 0x1300b64: StoreField: r0->field_27 = d1
    //     0x1300b64: stur            s1, [x0, #0x27]
    // 0x1300b68: LoadField: d0 = r1->field_33
    //     0x1300b68: ldur            d0, [x1, #0x33]
    // 0x1300b6c: fcvt            s1, d0
    // 0x1300b70: StoreField: r0->field_2b = d1
    //     0x1300b70: stur            s1, [x0, #0x2b]
    // 0x1300b74: LoadField: d0 = r1->field_3b
    //     0x1300b74: ldur            d0, [x1, #0x3b]
    // 0x1300b78: fcvt            s1, d0
    // 0x1300b7c: StoreField: r0->field_2f = d1
    //     0x1300b7c: stur            s1, [x0, #0x2f]
    // 0x1300b80: LoadField: d0 = r1->field_43
    //     0x1300b80: ldur            d0, [x1, #0x43]
    // 0x1300b84: fcvt            s1, d0
    // 0x1300b88: StoreField: r0->field_33 = d1
    //     0x1300b88: stur            s1, [x0, #0x33]
    // 0x1300b8c: LoadField: d0 = r1->field_4b
    //     0x1300b8c: ldur            d0, [x1, #0x4b]
    // 0x1300b90: fcvt            s1, d0
    // 0x1300b94: StoreField: r0->field_37 = d1
    //     0x1300b94: stur            s1, [x0, #0x37]
    // 0x1300b98: LoadField: d0 = r1->field_53
    //     0x1300b98: ldur            d0, [x1, #0x53]
    // 0x1300b9c: fcvt            s1, d0
    // 0x1300ba0: StoreField: r0->field_3b = d1
    //     0x1300ba0: stur            s1, [x0, #0x3b]
    // 0x1300ba4: LoadField: d0 = r1->field_5b
    //     0x1300ba4: ldur            d0, [x1, #0x5b]
    // 0x1300ba8: fcvt            s1, d0
    // 0x1300bac: StoreField: r0->field_3f = d1
    //     0x1300bac: stur            s1, [x0, #0x3f]
    // 0x1300bb0: LoadField: d0 = r1->field_63
    //     0x1300bb0: ldur            d0, [x1, #0x63]
    // 0x1300bb4: fcvt            s1, d0
    // 0x1300bb8: StoreField: r0->field_43 = d1
    //     0x1300bb8: stur            s1, [x0, #0x43]
    // 0x1300bbc: ldur            x2, [fp, #-0x18]
    // 0x1300bc0: LoadField: r1 = r2->field_7
    //     0x1300bc0: ldur            w1, [x2, #7]
    // 0x1300bc4: DecompressPointer r1
    //     0x1300bc4: add             x1, x1, HEAP, lsl #32
    // 0x1300bc8: cmp             w1, NULL
    // 0x1300bcc: b.eq            #0x1300c28
    // 0x1300bd0: LoadField: r3 = r1->field_7
    //     0x1300bd0: ldur            x3, [x1, #7]
    // 0x1300bd4: ldr             x1, [x3]
    // 0x1300bd8: cbz             x1, #0x1300c10
    // 0x1300bdc: mov             x3, x1
    // 0x1300be0: stur            x3, [fp, #-0x20]
    // 0x1300be4: r1 = <Never>
    //     0x1300be4: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x1300be8: r0 = Pointer()
    //     0x1300be8: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x1300bec: mov             x1, x0
    // 0x1300bf0: ldur            x0, [fp, #-0x20]
    // 0x1300bf4: StoreField: r1->field_7 = r0
    //     0x1300bf4: stur            x0, [x1, #7]
    // 0x1300bf8: ldur            x2, [fp, #-0x10]
    // 0x1300bfc: r0 = __addRRect$Method$FfiNative()
    //     0x1300bfc: bl              #0xbfd930  ; [dart:ui] _NativePath::__addRRect$Method$FfiNative
    // 0x1300c00: ldur            x0, [fp, #-0x18]
    // 0x1300c04: LeaveFrame
    //     0x1300c04: mov             SP, fp
    //     0x1300c08: ldp             fp, lr, [SP], #0x10
    // 0x1300c0c: ret
    //     0x1300c0c: ret             
    // 0x1300c10: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x1300c10: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x1300c14: str             x16, [SP]
    // 0x1300c18: r0 = _throwNew()
    //     0x1300c18: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x1300c1c: brk             #0
    // 0x1300c20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1300c20: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1300c24: b               #0x1300aec
    // 0x1300c28: r0 = NullErrorSharedWithoutFPURegs()
    //     0x1300c28: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ copyWith(/* No info */) {
    // ** addr: 0x1300f3c, size: 0x54
    // 0x1300f3c: EnterFrame
    //     0x1300f3c: stp             fp, lr, [SP, #-0x10]!
    //     0x1300f40: mov             fp, SP
    // 0x1300f44: AllocStack(0x10)
    //     0x1300f44: sub             SP, SP, #0x10
    // 0x1300f48: cmp             w2, NULL
    // 0x1300f4c: b.ne            #0x1300f5c
    // 0x1300f50: LoadField: r0 = r1->field_7
    //     0x1300f50: ldur            w0, [x1, #7]
    // 0x1300f54: DecompressPointer r0
    //     0x1300f54: add             x0, x0, HEAP, lsl #32
    // 0x1300f58: b               #0x1300f60
    // 0x1300f5c: mov             x0, x2
    // 0x1300f60: stur            x0, [fp, #-0x10]
    // 0x1300f64: LoadField: r2 = r1->field_b
    //     0x1300f64: ldur            w2, [x1, #0xb]
    // 0x1300f68: DecompressPointer r2
    //     0x1300f68: add             x2, x2, HEAP, lsl #32
    // 0x1300f6c: stur            x2, [fp, #-8]
    // 0x1300f70: r0 = UnderlineInputBorder()
    //     0x1300f70: bl              #0xec4de4  ; AllocateUnderlineInputBorderStub -> UnderlineInputBorder (size=0x10)
    // 0x1300f74: ldur            x1, [fp, #-8]
    // 0x1300f78: StoreField: r0->field_b = r1
    //     0x1300f78: stur            w1, [x0, #0xb]
    // 0x1300f7c: ldur            x1, [fp, #-0x10]
    // 0x1300f80: StoreField: r0->field_7 = r1
    //     0x1300f80: stur            w1, [x0, #7]
    // 0x1300f84: LeaveFrame
    //     0x1300f84: mov             SP, fp
    //     0x1300f88: ldp             fp, lr, [SP], #0x10
    // 0x1300f8c: ret
    //     0x1300f8c: ret             
  }
}

// class id: 3018, size: 0xc, field offset: 0xc
//   const constructor, 
class _NoInputBorder extends InputBorder {

  BorderSide field_8;

  _ paint(/* No info */) {
    // ** addr: 0x12edc7c, size: 0x98
    // 0x12edc7c: EnterFrame
    //     0x12edc7c: stp             fp, lr, [SP, #-0x10]!
    //     0x12edc80: mov             fp, SP
    // 0x12edc84: LoadField: r1 = r4->field_1f
    //     0x12edc84: ldur            w1, [x4, #0x1f]
    // 0x12edc88: DecompressPointer r1
    //     0x12edc88: add             x1, x1, HEAP, lsl #32
    // 0x12edc8c: r16 = "gapExtent"
    //     0x12edc8c: add             x16, PP, #0xab, lsl #12  ; [pp+0xab3c0] "gapExtent"
    //     0x12edc90: ldr             x16, [x16, #0x3c0]
    // 0x12edc94: cmp             w1, w16
    // 0x12edc98: b.ne            #0x12edca4
    // 0x12edc9c: r1 = 1
    //     0x12edc9c: mov             x1, #1
    // 0x12edca0: b               #0x12edca8
    // 0x12edca4: r1 = 0
    //     0x12edca4: mov             x1, #0
    // 0x12edca8: lsl             x2, x1, #1
    // 0x12edcac: lsl             w3, w2, #1
    // 0x12edcb0: add             w5, w3, #8
    // 0x12edcb4: ArrayLoad: r3 = r4[r5]  ; Unknown_4
    //     0x12edcb4: add             x16, x4, w5, sxtw #1
    //     0x12edcb8: ldur            w3, [x16, #0xf]
    // 0x12edcbc: DecompressPointer r3
    //     0x12edcbc: add             x3, x3, HEAP, lsl #32
    // 0x12edcc0: r16 = "gapPercentage"
    //     0x12edcc0: add             x16, PP, #0xab, lsl #12  ; [pp+0xab3c8] "gapPercentage"
    //     0x12edcc4: ldr             x16, [x16, #0x3c8]
    // 0x12edcc8: cmp             w3, w16
    // 0x12edccc: b.ne            #0x12edcdc
    // 0x12edcd0: add             w3, w2, #2
    // 0x12edcd4: r2 = LoadInt32Instr(r3)
    //     0x12edcd4: sbfx            x2, x3, #1, #0x1f
    // 0x12edcd8: mov             x1, x2
    // 0x12edcdc: lsl             x2, x1, #1
    // 0x12edce0: lsl             w1, w2, #1
    // 0x12edce4: add             w2, w1, #8
    // 0x12edce8: ArrayLoad: r1 = r4[r2]  ; Unknown_4
    //     0x12edce8: add             x16, x4, w2, sxtw #1
    //     0x12edcec: ldur            w1, [x16, #0xf]
    // 0x12edcf0: DecompressPointer r1
    //     0x12edcf0: add             x1, x1, HEAP, lsl #32
    // 0x12edcf4: r16 = "gapStart"
    //     0x12edcf4: add             x16, PP, #0xab, lsl #12  ; [pp+0xab3d0] "gapStart"
    //     0x12edcf8: ldr             x16, [x16, #0x3d0]
    // 0x12edcfc: cmp             w1, w16
    // 0x12edd00: b.eq            #0x12edd04
    // 0x12edd04: r0 = Null
    //     0x12edd04: mov             x0, NULL
    // 0x12edd08: LeaveFrame
    //     0x12edd08: mov             SP, fp
    //     0x12edd0c: ldp             fp, lr, [SP], #0x10
    // 0x12edd10: ret
    //     0x12edd10: ret             
  }
  get _ dimensions(/* No info */) {
    // ** addr: 0x12f5620, size: 0x8
    // 0x12f5620: r0 = Instance_EdgeInsets
    //     0x12f5620: ldr             x0, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0x12f5624: ret
    //     0x12f5624: ret             
  }
  _ copyWith(/* No info */) {
    // ** addr: 0x1300f30, size: 0xc
    // 0x1300f30: r0 = Instance__NoInputBorder
    //     0x1300f30: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1aeb0] Obj!_NoInputBorder@129ebd1
    //     0x1300f34: ldr             x0, [x0, #0xeb0]
    // 0x1300f38: ret
    //     0x1300f38: ret             
  }
}
