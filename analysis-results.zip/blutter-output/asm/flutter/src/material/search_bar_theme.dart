// lib: , url: package:flutter/src/material/search_bar_theme.dart

// class id: 1048941, size: 0x8
class :: {
}

// class id: 5117, size: 0x38, field offset: 0x8
//   const constructor, 
class SearchBarThemeData extends _MixinApplication3&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0x1135a84, size: 0x6c
    // 0x1135a84: EnterFrame
    //     0x1135a84: stp             fp, lr, [SP, #-0x10]!
    //     0x1135a88: mov             fp, SP
    // 0x1135a8c: AllocStack(0x50)
    //     0x1135a8c: sub             SP, SP, #0x50
    // 0x1135a90: CheckStackOverflow
    //     0x1135a90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1135a94: cmp             SP, x16
    //     0x1135a98: b.ls            #0x1135ae8
    // 0x1135a9c: stp             NULL, NULL, [SP, #0x40]
    // 0x1135aa0: stp             NULL, NULL, [SP, #0x30]
    // 0x1135aa4: stp             NULL, NULL, [SP, #0x20]
    // 0x1135aa8: stp             NULL, NULL, [SP, #0x10]
    // 0x1135aac: stp             NULL, NULL, [SP]
    // 0x1135ab0: r1 = Null
    //     0x1135ab0: mov             x1, NULL
    // 0x1135ab4: r2 = Null
    //     0x1135ab4: mov             x2, NULL
    // 0x1135ab8: r4 = const [0, 0xc, 0xa, 0xc, null]
    //     0x1135ab8: add             x4, PP, #0x26, lsl #12  ; [pp+0x26270] List(5) [0, 0xc, 0xa, 0xc, Null]
    //     0x1135abc: ldr             x4, [x4, #0x270]
    // 0x1135ac0: r0 = hash()
    //     0x1135ac0: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x1135ac4: mov             x2, x0
    // 0x1135ac8: r0 = BoxInt64Instr(r2)
    //     0x1135ac8: sbfiz           x0, x2, #1, #0x1f
    //     0x1135acc: cmp             x2, x0, asr #1
    //     0x1135ad0: b.eq            #0x1135adc
    //     0x1135ad4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1135ad8: stur            x2, [x0, #7]
    // 0x1135adc: LeaveFrame
    //     0x1135adc: mov             SP, fp
    //     0x1135ae0: ldp             fp, lr, [SP], #0x10
    // 0x1135ae4: ret
    //     0x1135ae4: ret             
    // 0x1135ae8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1135ae8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1135aec: b               #0x1135a9c
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x1165f80, size: 0x50
    // 0x1165f80: EnterFrame
    //     0x1165f80: stp             fp, lr, [SP, #-0x10]!
    //     0x1165f84: mov             fp, SP
    // 0x1165f88: mov             x0, x1
    // 0x1165f8c: CheckStackOverflow
    //     0x1165f8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1165f90: cmp             SP, x16
    //     0x1165f94: b.ls            #0x1165fc8
    // 0x1165f98: cmp             w0, w2
    // 0x1165f9c: b.ne            #0x1165fac
    // 0x1165fa0: LeaveFrame
    //     0x1165fa0: mov             SP, fp
    //     0x1165fa4: ldp             fp, lr, [SP], #0x10
    // 0x1165fa8: ret
    //     0x1165fa8: ret             
    // 0x1165fac: r1 = Null
    //     0x1165fac: mov             x1, NULL
    // 0x1165fb0: r2 = Null
    //     0x1165fb0: mov             x2, NULL
    // 0x1165fb4: r0 = lerp()
    //     0x1165fb4: bl              #0x1163c14  ; [package:flutter/src/rendering/box.dart] BoxConstraints::lerp
    // 0x1165fb8: r0 = SearchBarThemeData()
    //     0x1165fb8: bl              #0x1165fd0  ; AllocateSearchBarThemeDataStub -> SearchBarThemeData (size=0x38)
    // 0x1165fbc: LeaveFrame
    //     0x1165fbc: mov             SP, fp
    //     0x1165fc0: ldp             fp, lr, [SP], #0x10
    // 0x1165fc4: ret
    //     0x1165fc4: ret             
    // 0x1165fc8: r0 = StackOverflowSharedWithFPURegs()
    //     0x1165fc8: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1165fcc: b               #0x1165f98
  }
  _ ==(/* No info */) {
    // ** addr: 0x1271884, size: 0xd0
    // 0x1271884: EnterFrame
    //     0x1271884: stp             fp, lr, [SP, #-0x10]!
    //     0x1271888: mov             fp, SP
    // 0x127188c: AllocStack(0x10)
    //     0x127188c: sub             SP, SP, #0x10
    // 0x1271890: CheckStackOverflow
    //     0x1271890: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1271894: cmp             SP, x16
    //     0x1271898: b.ls            #0x127194c
    // 0x127189c: ldr             x0, [fp, #0x10]
    // 0x12718a0: cmp             w0, NULL
    // 0x12718a4: b.ne            #0x12718b8
    // 0x12718a8: r0 = false
    //     0x12718a8: add             x0, NULL, #0x30  ; false
    // 0x12718ac: LeaveFrame
    //     0x12718ac: mov             SP, fp
    //     0x12718b0: ldp             fp, lr, [SP], #0x10
    // 0x12718b4: ret
    //     0x12718b4: ret             
    // 0x12718b8: ldr             x1, [fp, #0x18]
    // 0x12718bc: cmp             w1, w0
    // 0x12718c0: b.ne            #0x12718d4
    // 0x12718c4: r0 = true
    //     0x12718c4: add             x0, NULL, #0x20  ; true
    // 0x12718c8: LeaveFrame
    //     0x12718c8: mov             SP, fp
    //     0x12718cc: ldp             fp, lr, [SP], #0x10
    // 0x12718d0: ret
    //     0x12718d0: ret             
    // 0x12718d4: str             x0, [SP]
    // 0x12718d8: r0 = runtimeType()
    //     0x12718d8: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x12718dc: r1 = LoadClassIdInstr(r0)
    //     0x12718dc: ldur            x1, [x0, #-1]
    //     0x12718e0: ubfx            x1, x1, #0xc, #0x14
    // 0x12718e4: r16 = SearchBarThemeData
    //     0x12718e4: add             x16, PP, #0x26, lsl #12  ; [pp+0x26268] Type: SearchBarThemeData
    //     0x12718e8: ldr             x16, [x16, #0x268]
    // 0x12718ec: stp             x16, x0, [SP]
    // 0x12718f0: mov             x0, x1
    // 0x12718f4: mov             lr, x0
    // 0x12718f8: ldr             lr, [x21, lr, lsl #3]
    // 0x12718fc: blr             lr
    // 0x1271900: tbz             w0, #4, #0x1271914
    // 0x1271904: r0 = false
    //     0x1271904: add             x0, NULL, #0x30  ; false
    // 0x1271908: LeaveFrame
    //     0x1271908: mov             SP, fp
    //     0x127190c: ldp             fp, lr, [SP], #0x10
    // 0x1271910: ret
    //     0x1271910: ret             
    // 0x1271914: ldr             x1, [fp, #0x10]
    // 0x1271918: r2 = 60
    //     0x1271918: mov             x2, #0x3c
    // 0x127191c: branchIfSmi(r1, 0x1271928)
    //     0x127191c: tbz             w1, #0, #0x1271928
    // 0x1271920: r2 = LoadClassIdInstr(r1)
    //     0x1271920: ldur            x2, [x1, #-1]
    //     0x1271924: ubfx            x2, x2, #0xc, #0x14
    // 0x1271928: r17 = 5117
    //     0x1271928: mov             x17, #0x13fd
    // 0x127192c: cmp             x2, x17
    // 0x1271930: b.ne            #0x127193c
    // 0x1271934: r0 = true
    //     0x1271934: add             x0, NULL, #0x20  ; true
    // 0x1271938: b               #0x1271940
    // 0x127193c: r0 = false
    //     0x127193c: add             x0, NULL, #0x30  ; false
    // 0x1271940: LeaveFrame
    //     0x1271940: mov             SP, fp
    //     0x1271944: ldp             fp, lr, [SP], #0x10
    // 0x1271948: ret
    //     0x1271948: ret             
    // 0x127194c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x127194c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1271950: b               #0x127189c
  }
}
