// lib: , url: package:flutter/src/material/button_theme.dart

// class id: 1048859, size: 0x8
class :: {
}

// class id: 5182, size: 0x4c, field offset: 0x8
//   const constructor, 
class ButtonThemeData extends _MixinApplication3&Object&Diagnosticable {

  _ copyWith(/* No info */) {
    // ** addr: 0xd1e690, size: 0x134
    // 0xd1e690: EnterFrame
    //     0xd1e690: stp             fp, lr, [SP, #-0x10]!
    //     0xd1e694: mov             fp, SP
    // 0xd1e698: AllocStack(0x48)
    //     0xd1e698: sub             SP, SP, #0x48
    // 0xd1e69c: SetupParameters(dynamic _ /* r2 => r2, fp-0x38 */)
    //     0xd1e69c: stur            x2, [fp, #-0x38]
    // 0xd1e6a0: LoadField: d0 = r1->field_7
    //     0xd1e6a0: ldur            d0, [x1, #7]
    // 0xd1e6a4: stur            d0, [fp, #-0x48]
    // 0xd1e6a8: LoadField: d1 = r1->field_f
    //     0xd1e6a8: ldur            d1, [x1, #0xf]
    // 0xd1e6ac: stur            d1, [fp, #-0x40]
    // 0xd1e6b0: LoadField: r0 = r1->field_1f
    //     0xd1e6b0: ldur            w0, [x1, #0x1f]
    // 0xd1e6b4: DecompressPointer r0
    //     0xd1e6b4: add             x0, x0, HEAP, lsl #32
    // 0xd1e6b8: cmp             w0, NULL
    // 0xd1e6bc: b.ne            #0xd1e6fc
    // 0xd1e6c0: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xd1e6c0: ldur            w0, [x1, #0x17]
    // 0xd1e6c4: DecompressPointer r0
    //     0xd1e6c4: add             x0, x0, HEAP, lsl #32
    // 0xd1e6c8: LoadField: r3 = r0->field_7
    //     0xd1e6c8: ldur            x3, [x0, #7]
    // 0xd1e6cc: cmp             x3, #1
    // 0xd1e6d0: b.gt            #0xd1e6f4
    // 0xd1e6d4: cmp             x3, #0
    // 0xd1e6d8: b.gt            #0xd1e6e8
    // 0xd1e6dc: r0 = Instance_EdgeInsets
    //     0xd1e6dc: add             x0, PP, #0x26, lsl #12  ; [pp+0x26510] Obj!EdgeInsets@129cdb1
    //     0xd1e6e0: ldr             x0, [x0, #0x510]
    // 0xd1e6e4: b               #0xd1e6fc
    // 0xd1e6e8: r0 = Instance_EdgeInsets
    //     0xd1e6e8: add             x0, PP, #0x26, lsl #12  ; [pp+0x26510] Obj!EdgeInsets@129cdb1
    //     0xd1e6ec: ldr             x0, [x0, #0x510]
    // 0xd1e6f0: b               #0xd1e6fc
    // 0xd1e6f4: r0 = Instance_EdgeInsets
    //     0xd1e6f4: add             x0, PP, #0x26, lsl #12  ; [pp+0x26518] Obj!EdgeInsets@129cd51
    //     0xd1e6f8: ldr             x0, [x0, #0x518]
    // 0xd1e6fc: stur            x0, [fp, #-0x30]
    // 0xd1e700: LoadField: r3 = r1->field_23
    //     0xd1e700: ldur            w3, [x1, #0x23]
    // 0xd1e704: DecompressPointer r3
    //     0xd1e704: add             x3, x3, HEAP, lsl #32
    // 0xd1e708: cmp             w3, NULL
    // 0xd1e70c: b.ne            #0xd1e718
    // 0xd1e710: r3 = Instance_RoundedRectangleBorder
    //     0xd1e710: add             x3, PP, #0x26, lsl #12  ; [pp+0x264d0] Obj!RoundedRectangleBorder@129ec61
    //     0xd1e714: ldr             x3, [x3, #0x4d0]
    // 0xd1e718: stur            x3, [fp, #-0x28]
    // 0xd1e71c: LoadField: r4 = r1->field_2b
    //     0xd1e71c: ldur            w4, [x1, #0x2b]
    // 0xd1e720: DecompressPointer r4
    //     0xd1e720: add             x4, x4, HEAP, lsl #32
    // 0xd1e724: stur            x4, [fp, #-0x20]
    // 0xd1e728: LoadField: r5 = r1->field_33
    //     0xd1e728: ldur            w5, [x1, #0x33]
    // 0xd1e72c: DecompressPointer r5
    //     0xd1e72c: add             x5, x5, HEAP, lsl #32
    // 0xd1e730: stur            x5, [fp, #-0x18]
    // 0xd1e734: LoadField: r6 = r1->field_37
    //     0xd1e734: ldur            w6, [x1, #0x37]
    // 0xd1e738: DecompressPointer r6
    //     0xd1e738: add             x6, x6, HEAP, lsl #32
    // 0xd1e73c: stur            x6, [fp, #-0x10]
    // 0xd1e740: LoadField: r7 = r1->field_47
    //     0xd1e740: ldur            w7, [x1, #0x47]
    // 0xd1e744: DecompressPointer r7
    //     0xd1e744: add             x7, x7, HEAP, lsl #32
    // 0xd1e748: stur            x7, [fp, #-8]
    // 0xd1e74c: r0 = ButtonThemeData()
    //     0xd1e74c: bl              #0x8ad590  ; AllocateButtonThemeDataStub -> ButtonThemeData (size=0x4c)
    // 0xd1e750: r1 = Instance_ButtonTextTheme
    //     0xd1e750: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c90] Obj!ButtonTextTheme@12c5981
    //     0xd1e754: ldr             x1, [x1, #0xc90]
    // 0xd1e758: ArrayStore: r0[0] = r1  ; List_4
    //     0xd1e758: stur            w1, [x0, #0x17]
    // 0xd1e75c: ldur            d0, [fp, #-0x48]
    // 0xd1e760: StoreField: r0->field_7 = d0
    //     0xd1e760: stur            d0, [x0, #7]
    // 0xd1e764: ldur            d0, [fp, #-0x40]
    // 0xd1e768: StoreField: r0->field_f = d0
    //     0xd1e768: stur            d0, [x0, #0xf]
    // 0xd1e76c: r1 = Instance_ButtonBarLayoutBehavior
    //     0xd1e76c: add             x1, PP, #0x12, lsl #12  ; [pp+0x12ca8] Obj!ButtonBarLayoutBehavior@12c5961
    //     0xd1e770: ldr             x1, [x1, #0xca8]
    // 0xd1e774: StoreField: r0->field_1b = r1
    //     0xd1e774: stur            w1, [x0, #0x1b]
    // 0xd1e778: r1 = false
    //     0xd1e778: add             x1, NULL, #0x30  ; false
    // 0xd1e77c: StoreField: r0->field_27 = r1
    //     0xd1e77c: stur            w1, [x0, #0x27]
    // 0xd1e780: ldur            x1, [fp, #-0x38]
    // 0xd1e784: StoreField: r0->field_43 = r1
    //     0xd1e784: stur            w1, [x0, #0x43]
    // 0xd1e788: ldur            x1, [fp, #-0x20]
    // 0xd1e78c: StoreField: r0->field_2b = r1
    //     0xd1e78c: stur            w1, [x0, #0x2b]
    // 0xd1e790: ldur            x1, [fp, #-0x18]
    // 0xd1e794: StoreField: r0->field_33 = r1
    //     0xd1e794: stur            w1, [x0, #0x33]
    // 0xd1e798: ldur            x1, [fp, #-0x10]
    // 0xd1e79c: StoreField: r0->field_37 = r1
    //     0xd1e79c: stur            w1, [x0, #0x37]
    // 0xd1e7a0: ldur            x1, [fp, #-0x30]
    // 0xd1e7a4: StoreField: r0->field_1f = r1
    //     0xd1e7a4: stur            w1, [x0, #0x1f]
    // 0xd1e7a8: ldur            x1, [fp, #-0x28]
    // 0xd1e7ac: StoreField: r0->field_23 = r1
    //     0xd1e7ac: stur            w1, [x0, #0x23]
    // 0xd1e7b0: ldur            x1, [fp, #-8]
    // 0xd1e7b4: StoreField: r0->field_47 = r1
    //     0xd1e7b4: stur            w1, [x0, #0x47]
    // 0xd1e7b8: LeaveFrame
    //     0xd1e7b8: mov             SP, fp
    //     0xd1e7bc: ldp             fp, lr, [SP], #0x10
    // 0xd1e7c0: ret
    //     0xd1e7c0: ret             
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x112f8f8, size: 0x1cc
    // 0x112f8f8: EnterFrame
    //     0x112f8f8: stp             fp, lr, [SP, #-0x10]!
    //     0x112f8fc: mov             fp, SP
    // 0x112f900: AllocStack(0x60)
    //     0x112f900: sub             SP, SP, #0x60
    // 0x112f904: CheckStackOverflow
    //     0x112f904: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x112f908: cmp             SP, x16
    //     0x112f90c: b.ls            #0x112fa58
    // 0x112f910: ldr             x0, [fp, #0x10]
    // 0x112f914: LoadField: d0 = r0->field_7
    //     0x112f914: ldur            d0, [x0, #7]
    // 0x112f918: LoadField: d1 = r0->field_f
    //     0x112f918: ldur            d1, [x0, #0xf]
    // 0x112f91c: LoadField: r1 = r0->field_1f
    //     0x112f91c: ldur            w1, [x0, #0x1f]
    // 0x112f920: DecompressPointer r1
    //     0x112f920: add             x1, x1, HEAP, lsl #32
    // 0x112f924: cmp             w1, NULL
    // 0x112f928: b.ne            #0x112f968
    // 0x112f92c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x112f92c: ldur            w1, [x0, #0x17]
    // 0x112f930: DecompressPointer r1
    //     0x112f930: add             x1, x1, HEAP, lsl #32
    // 0x112f934: LoadField: r2 = r1->field_7
    //     0x112f934: ldur            x2, [x1, #7]
    // 0x112f938: cmp             x2, #1
    // 0x112f93c: b.gt            #0x112f960
    // 0x112f940: cmp             x2, #0
    // 0x112f944: b.gt            #0x112f954
    // 0x112f948: r1 = Instance_EdgeInsets
    //     0x112f948: add             x1, PP, #0x26, lsl #12  ; [pp+0x26510] Obj!EdgeInsets@129cdb1
    //     0x112f94c: ldr             x1, [x1, #0x510]
    // 0x112f950: b               #0x112f968
    // 0x112f954: r1 = Instance_EdgeInsets
    //     0x112f954: add             x1, PP, #0x26, lsl #12  ; [pp+0x26510] Obj!EdgeInsets@129cdb1
    //     0x112f958: ldr             x1, [x1, #0x510]
    // 0x112f95c: b               #0x112f968
    // 0x112f960: r1 = Instance_EdgeInsets
    //     0x112f960: add             x1, PP, #0x26, lsl #12  ; [pp+0x26518] Obj!EdgeInsets@129cd51
    //     0x112f964: ldr             x1, [x1, #0x518]
    // 0x112f968: LoadField: r2 = r0->field_23
    //     0x112f968: ldur            w2, [x0, #0x23]
    // 0x112f96c: DecompressPointer r2
    //     0x112f96c: add             x2, x2, HEAP, lsl #32
    // 0x112f970: cmp             w2, NULL
    // 0x112f974: b.ne            #0x112f980
    // 0x112f978: r2 = Instance_RoundedRectangleBorder
    //     0x112f978: add             x2, PP, #0x26, lsl #12  ; [pp+0x264d0] Obj!RoundedRectangleBorder@129ec61
    //     0x112f97c: ldr             x2, [x2, #0x4d0]
    // 0x112f980: LoadField: r3 = r0->field_2b
    //     0x112f980: ldur            w3, [x0, #0x2b]
    // 0x112f984: DecompressPointer r3
    //     0x112f984: add             x3, x3, HEAP, lsl #32
    // 0x112f988: LoadField: r4 = r0->field_33
    //     0x112f988: ldur            w4, [x0, #0x33]
    // 0x112f98c: DecompressPointer r4
    //     0x112f98c: add             x4, x4, HEAP, lsl #32
    // 0x112f990: LoadField: r5 = r0->field_37
    //     0x112f990: ldur            w5, [x0, #0x37]
    // 0x112f994: DecompressPointer r5
    //     0x112f994: add             x5, x5, HEAP, lsl #32
    // 0x112f998: LoadField: r6 = r0->field_43
    //     0x112f998: ldur            w6, [x0, #0x43]
    // 0x112f99c: DecompressPointer r6
    //     0x112f99c: add             x6, x6, HEAP, lsl #32
    // 0x112f9a0: LoadField: r7 = r0->field_47
    //     0x112f9a0: ldur            w7, [x0, #0x47]
    // 0x112f9a4: DecompressPointer r7
    //     0x112f9a4: add             x7, x7, HEAP, lsl #32
    // 0x112f9a8: r0 = inline_Allocate_Double()
    //     0x112f9a8: ldp             x0, x8, [THR, #0x60]  ; THR::top
    //     0x112f9ac: add             x0, x0, #0x10
    //     0x112f9b0: cmp             x8, x0
    //     0x112f9b4: b.ls            #0x112fa60
    //     0x112f9b8: str             x0, [THR, #0x60]  ; THR::top
    //     0x112f9bc: sub             x0, x0, #0xf
    //     0x112f9c0: mov             x8, #0xe19c
    //     0x112f9c4: movk            x8, #3, lsl #16
    //     0x112f9c8: stur            x8, [x0, #-1]
    // 0x112f9cc: dmb             ishst
    // 0x112f9d0: StoreField: r0->field_7 = d0
    //     0x112f9d0: stur            d0, [x0, #7]
    // 0x112f9d4: r8 = inline_Allocate_Double()
    //     0x112f9d4: ldp             x8, x9, [THR, #0x60]  ; THR::top
    //     0x112f9d8: add             x8, x8, #0x10
    //     0x112f9dc: cmp             x9, x8
    //     0x112f9e0: b.ls            #0x112fa90
    //     0x112f9e4: str             x8, [THR, #0x60]  ; THR::top
    //     0x112f9e8: sub             x8, x8, #0xf
    //     0x112f9ec: mov             x9, #0xe19c
    //     0x112f9f0: movk            x9, #3, lsl #16
    //     0x112f9f4: stur            x9, [x8, #-1]
    // 0x112f9f8: dmb             ishst
    // 0x112f9fc: StoreField: r8->field_7 = d1
    //     0x112f9fc: stur            d1, [x8, #7]
    // 0x112fa00: stp             x1, x8, [SP, #0x50]
    // 0x112fa04: r16 = false
    //     0x112fa04: add             x16, NULL, #0x30  ; false
    // 0x112fa08: stp             x16, x2, [SP, #0x40]
    // 0x112fa0c: stp             NULL, x3, [SP, #0x30]
    // 0x112fa10: stp             x5, x4, [SP, #0x20]
    // 0x112fa14: stp             NULL, NULL, [SP, #0x10]
    // 0x112fa18: stp             x7, x6, [SP]
    // 0x112fa1c: mov             x2, x0
    // 0x112fa20: r1 = Instance_ButtonTextTheme
    //     0x112fa20: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c90] Obj!ButtonTextTheme@12c5981
    //     0x112fa24: ldr             x1, [x1, #0xc90]
    // 0x112fa28: r4 = const [0, 0xe, 0xc, 0xe, null]
    //     0x112fa28: add             x4, PP, #0x26, lsl #12  ; [pp+0x26520] List(5) [0, 0xe, 0xc, 0xe, Null]
    //     0x112fa2c: ldr             x4, [x4, #0x520]
    // 0x112fa30: r0 = hash()
    //     0x112fa30: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x112fa34: mov             x2, x0
    // 0x112fa38: r0 = BoxInt64Instr(r2)
    //     0x112fa38: sbfiz           x0, x2, #1, #0x1f
    //     0x112fa3c: cmp             x2, x0, asr #1
    //     0x112fa40: b.eq            #0x112fa4c
    //     0x112fa44: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x112fa48: stur            x2, [x0, #7]
    // 0x112fa4c: LeaveFrame
    //     0x112fa4c: mov             SP, fp
    //     0x112fa50: ldp             fp, lr, [SP], #0x10
    // 0x112fa54: ret
    //     0x112fa54: ret             
    // 0x112fa58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x112fa58: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x112fa5c: b               #0x112f910
    // 0x112fa60: stp             q0, q1, [SP, #-0x20]!
    // 0x112fa64: stp             x6, x7, [SP, #-0x10]!
    // 0x112fa68: stp             x4, x5, [SP, #-0x10]!
    // 0x112fa6c: stp             x2, x3, [SP, #-0x10]!
    // 0x112fa70: SaveReg r1
    //     0x112fa70: str             x1, [SP, #-8]!
    // 0x112fa74: r0 = AllocateDouble()
    //     0x112fa74: bl              #0x13df878  ; AllocateDoubleStub
    // 0x112fa78: RestoreReg r1
    //     0x112fa78: ldr             x1, [SP], #8
    // 0x112fa7c: ldp             x2, x3, [SP], #0x10
    // 0x112fa80: ldp             x4, x5, [SP], #0x10
    // 0x112fa84: ldp             x6, x7, [SP], #0x10
    // 0x112fa88: ldp             q0, q1, [SP], #0x20
    // 0x112fa8c: b               #0x112f9d0
    // 0x112fa90: SaveReg d1
    //     0x112fa90: str             q1, [SP, #-0x10]!
    // 0x112fa94: stp             x6, x7, [SP, #-0x10]!
    // 0x112fa98: stp             x4, x5, [SP, #-0x10]!
    // 0x112fa9c: stp             x2, x3, [SP, #-0x10]!
    // 0x112faa0: stp             x0, x1, [SP, #-0x10]!
    // 0x112faa4: r0 = AllocateDouble()
    //     0x112faa4: bl              #0x13df878  ; AllocateDoubleStub
    // 0x112faa8: mov             x8, x0
    // 0x112faac: ldp             x0, x1, [SP], #0x10
    // 0x112fab0: ldp             x2, x3, [SP], #0x10
    // 0x112fab4: ldp             x4, x5, [SP], #0x10
    // 0x112fab8: ldp             x6, x7, [SP], #0x10
    // 0x112fabc: RestoreReg d1
    //     0x112fabc: ldr             q1, [SP], #0x10
    // 0x112fac0: b               #0x112f9fc
  }
  _ ==(/* No info */) {
    // ** addr: 0x12657f0, size: 0x2d0
    // 0x12657f0: EnterFrame
    //     0x12657f0: stp             fp, lr, [SP, #-0x10]!
    //     0x12657f4: mov             fp, SP
    // 0x12657f8: AllocStack(0x10)
    //     0x12657f8: sub             SP, SP, #0x10
    // 0x12657fc: CheckStackOverflow
    //     0x12657fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1265800: cmp             SP, x16
    //     0x1265804: b.ls            #0x1265ab8
    // 0x1265808: ldr             x0, [fp, #0x10]
    // 0x126580c: cmp             w0, NULL
    // 0x1265810: b.ne            #0x1265824
    // 0x1265814: r0 = false
    //     0x1265814: add             x0, NULL, #0x30  ; false
    // 0x1265818: LeaveFrame
    //     0x1265818: mov             SP, fp
    //     0x126581c: ldp             fp, lr, [SP], #0x10
    // 0x1265820: ret
    //     0x1265820: ret             
    // 0x1265824: str             x0, [SP]
    // 0x1265828: r0 = runtimeType()
    //     0x1265828: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x126582c: r1 = LoadClassIdInstr(r0)
    //     0x126582c: ldur            x1, [x0, #-1]
    //     0x1265830: ubfx            x1, x1, #0xc, #0x14
    // 0x1265834: r16 = ButtonThemeData
    //     0x1265834: add             x16, PP, #0x26, lsl #12  ; [pp+0x26528] Type: ButtonThemeData
    //     0x1265838: ldr             x16, [x16, #0x528]
    // 0x126583c: stp             x16, x0, [SP]
    // 0x1265840: mov             x0, x1
    // 0x1265844: mov             lr, x0
    // 0x1265848: ldr             lr, [x21, lr, lsl #3]
    // 0x126584c: blr             lr
    // 0x1265850: tbz             w0, #4, #0x1265864
    // 0x1265854: r0 = false
    //     0x1265854: add             x0, NULL, #0x30  ; false
    // 0x1265858: LeaveFrame
    //     0x1265858: mov             SP, fp
    //     0x126585c: ldp             fp, lr, [SP], #0x10
    // 0x1265860: ret
    //     0x1265860: ret             
    // 0x1265864: ldr             x0, [fp, #0x10]
    // 0x1265868: r1 = 60
    //     0x1265868: mov             x1, #0x3c
    // 0x126586c: branchIfSmi(r0, 0x1265878)
    //     0x126586c: tbz             w0, #0, #0x1265878
    // 0x1265870: r1 = LoadClassIdInstr(r0)
    //     0x1265870: ldur            x1, [x0, #-1]
    //     0x1265874: ubfx            x1, x1, #0xc, #0x14
    // 0x1265878: r17 = 5182
    //     0x1265878: mov             x17, #0x143e
    // 0x126587c: cmp             x1, x17
    // 0x1265880: b.ne            #0x1265aa8
    // 0x1265884: ldr             x1, [fp, #0x18]
    // 0x1265888: LoadField: d0 = r0->field_7
    //     0x1265888: ldur            d0, [x0, #7]
    // 0x126588c: LoadField: d1 = r1->field_7
    //     0x126588c: ldur            d1, [x1, #7]
    // 0x1265890: fcmp            d0, d1
    // 0x1265894: b.ne            #0x1265aa8
    // 0x1265898: LoadField: d0 = r0->field_f
    //     0x1265898: ldur            d0, [x0, #0xf]
    // 0x126589c: LoadField: d1 = r1->field_f
    //     0x126589c: ldur            d1, [x1, #0xf]
    // 0x12658a0: fcmp            d0, d1
    // 0x12658a4: b.ne            #0x1265aa8
    // 0x12658a8: LoadField: r2 = r0->field_1f
    //     0x12658a8: ldur            w2, [x0, #0x1f]
    // 0x12658ac: DecompressPointer r2
    //     0x12658ac: add             x2, x2, HEAP, lsl #32
    // 0x12658b0: cmp             w2, NULL
    // 0x12658b4: b.ne            #0x12658f4
    // 0x12658b8: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x12658b8: ldur            w2, [x0, #0x17]
    // 0x12658bc: DecompressPointer r2
    //     0x12658bc: add             x2, x2, HEAP, lsl #32
    // 0x12658c0: LoadField: r3 = r2->field_7
    //     0x12658c0: ldur            x3, [x2, #7]
    // 0x12658c4: cmp             x3, #1
    // 0x12658c8: b.gt            #0x12658ec
    // 0x12658cc: cmp             x3, #0
    // 0x12658d0: b.gt            #0x12658e0
    // 0x12658d4: r2 = Instance_EdgeInsets
    //     0x12658d4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26510] Obj!EdgeInsets@129cdb1
    //     0x12658d8: ldr             x2, [x2, #0x510]
    // 0x12658dc: b               #0x12658f4
    // 0x12658e0: r2 = Instance_EdgeInsets
    //     0x12658e0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26510] Obj!EdgeInsets@129cdb1
    //     0x12658e4: ldr             x2, [x2, #0x510]
    // 0x12658e8: b               #0x12658f4
    // 0x12658ec: r2 = Instance_EdgeInsets
    //     0x12658ec: add             x2, PP, #0x26, lsl #12  ; [pp+0x26518] Obj!EdgeInsets@129cd51
    //     0x12658f0: ldr             x2, [x2, #0x518]
    // 0x12658f4: LoadField: r3 = r1->field_1f
    //     0x12658f4: ldur            w3, [x1, #0x1f]
    // 0x12658f8: DecompressPointer r3
    //     0x12658f8: add             x3, x3, HEAP, lsl #32
    // 0x12658fc: cmp             w3, NULL
    // 0x1265900: b.ne            #0x1265940
    // 0x1265904: ArrayLoad: r3 = r1[0]  ; List_4
    //     0x1265904: ldur            w3, [x1, #0x17]
    // 0x1265908: DecompressPointer r3
    //     0x1265908: add             x3, x3, HEAP, lsl #32
    // 0x126590c: LoadField: r4 = r3->field_7
    //     0x126590c: ldur            x4, [x3, #7]
    // 0x1265910: cmp             x4, #1
    // 0x1265914: b.gt            #0x1265938
    // 0x1265918: cmp             x4, #0
    // 0x126591c: b.gt            #0x126592c
    // 0x1265920: r3 = Instance_EdgeInsets
    //     0x1265920: add             x3, PP, #0x26, lsl #12  ; [pp+0x26510] Obj!EdgeInsets@129cdb1
    //     0x1265924: ldr             x3, [x3, #0x510]
    // 0x1265928: b               #0x1265940
    // 0x126592c: r3 = Instance_EdgeInsets
    //     0x126592c: add             x3, PP, #0x26, lsl #12  ; [pp+0x26510] Obj!EdgeInsets@129cdb1
    //     0x1265930: ldr             x3, [x3, #0x510]
    // 0x1265934: b               #0x1265940
    // 0x1265938: r3 = Instance_EdgeInsets
    //     0x1265938: add             x3, PP, #0x26, lsl #12  ; [pp+0x26518] Obj!EdgeInsets@129cd51
    //     0x126593c: ldr             x3, [x3, #0x518]
    // 0x1265940: stp             x3, x2, [SP]
    // 0x1265944: r0 = ==()
    //     0x1265944: bl              #0x1298c8c  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::==
    // 0x1265948: tbnz            w0, #4, #0x1265aa8
    // 0x126594c: ldr             x0, [fp, #0x10]
    // 0x1265950: LoadField: r1 = r0->field_23
    //     0x1265950: ldur            w1, [x0, #0x23]
    // 0x1265954: DecompressPointer r1
    //     0x1265954: add             x1, x1, HEAP, lsl #32
    // 0x1265958: cmp             w1, NULL
    // 0x126595c: b.ne            #0x126596c
    // 0x1265960: r2 = Instance_RoundedRectangleBorder
    //     0x1265960: add             x2, PP, #0x26, lsl #12  ; [pp+0x264d0] Obj!RoundedRectangleBorder@129ec61
    //     0x1265964: ldr             x2, [x2, #0x4d0]
    // 0x1265968: b               #0x1265970
    // 0x126596c: mov             x2, x1
    // 0x1265970: ldr             x1, [fp, #0x18]
    // 0x1265974: LoadField: r3 = r1->field_23
    //     0x1265974: ldur            w3, [x1, #0x23]
    // 0x1265978: DecompressPointer r3
    //     0x1265978: add             x3, x3, HEAP, lsl #32
    // 0x126597c: cmp             w3, NULL
    // 0x1265980: b.ne            #0x126598c
    // 0x1265984: r3 = Instance_RoundedRectangleBorder
    //     0x1265984: add             x3, PP, #0x26, lsl #12  ; [pp+0x264d0] Obj!RoundedRectangleBorder@129ec61
    //     0x1265988: ldr             x3, [x3, #0x4d0]
    // 0x126598c: stp             x3, x2, [SP]
    // 0x1265990: r0 = ==()
    //     0x1265990: bl              #0x1295ee4  ; [package:flutter/src/painting/rounded_rectangle_border.dart] RoundedRectangleBorder::==
    // 0x1265994: tbnz            w0, #4, #0x1265aa8
    // 0x1265998: ldr             x2, [fp, #0x18]
    // 0x126599c: ldr             x1, [fp, #0x10]
    // 0x12659a0: LoadField: r0 = r1->field_2b
    //     0x12659a0: ldur            w0, [x1, #0x2b]
    // 0x12659a4: DecompressPointer r0
    //     0x12659a4: add             x0, x0, HEAP, lsl #32
    // 0x12659a8: LoadField: r3 = r2->field_2b
    //     0x12659a8: ldur            w3, [x2, #0x2b]
    // 0x12659ac: DecompressPointer r3
    //     0x12659ac: add             x3, x3, HEAP, lsl #32
    // 0x12659b0: r4 = LoadClassIdInstr(r0)
    //     0x12659b0: ldur            x4, [x0, #-1]
    //     0x12659b4: ubfx            x4, x4, #0xc, #0x14
    // 0x12659b8: stp             x3, x0, [SP]
    // 0x12659bc: mov             x0, x4
    // 0x12659c0: mov             lr, x0
    // 0x12659c4: ldr             lr, [x21, lr, lsl #3]
    // 0x12659c8: blr             lr
    // 0x12659cc: tbnz            w0, #4, #0x1265aa8
    // 0x12659d0: ldr             x2, [fp, #0x18]
    // 0x12659d4: ldr             x1, [fp, #0x10]
    // 0x12659d8: LoadField: r0 = r1->field_33
    //     0x12659d8: ldur            w0, [x1, #0x33]
    // 0x12659dc: DecompressPointer r0
    //     0x12659dc: add             x0, x0, HEAP, lsl #32
    // 0x12659e0: LoadField: r3 = r2->field_33
    //     0x12659e0: ldur            w3, [x2, #0x33]
    // 0x12659e4: DecompressPointer r3
    //     0x12659e4: add             x3, x3, HEAP, lsl #32
    // 0x12659e8: r4 = LoadClassIdInstr(r0)
    //     0x12659e8: ldur            x4, [x0, #-1]
    //     0x12659ec: ubfx            x4, x4, #0xc, #0x14
    // 0x12659f0: stp             x3, x0, [SP]
    // 0x12659f4: mov             x0, x4
    // 0x12659f8: mov             lr, x0
    // 0x12659fc: ldr             lr, [x21, lr, lsl #3]
    // 0x1265a00: blr             lr
    // 0x1265a04: tbnz            w0, #4, #0x1265aa8
    // 0x1265a08: ldr             x2, [fp, #0x18]
    // 0x1265a0c: ldr             x1, [fp, #0x10]
    // 0x1265a10: LoadField: r0 = r1->field_37
    //     0x1265a10: ldur            w0, [x1, #0x37]
    // 0x1265a14: DecompressPointer r0
    //     0x1265a14: add             x0, x0, HEAP, lsl #32
    // 0x1265a18: LoadField: r3 = r2->field_37
    //     0x1265a18: ldur            w3, [x2, #0x37]
    // 0x1265a1c: DecompressPointer r3
    //     0x1265a1c: add             x3, x3, HEAP, lsl #32
    // 0x1265a20: r4 = LoadClassIdInstr(r0)
    //     0x1265a20: ldur            x4, [x0, #-1]
    //     0x1265a24: ubfx            x4, x4, #0xc, #0x14
    // 0x1265a28: stp             x3, x0, [SP]
    // 0x1265a2c: mov             x0, x4
    // 0x1265a30: mov             lr, x0
    // 0x1265a34: ldr             lr, [x21, lr, lsl #3]
    // 0x1265a38: blr             lr
    // 0x1265a3c: tbnz            w0, #4, #0x1265aa8
    // 0x1265a40: ldr             x2, [fp, #0x18]
    // 0x1265a44: ldr             x1, [fp, #0x10]
    // 0x1265a48: LoadField: r0 = r1->field_43
    //     0x1265a48: ldur            w0, [x1, #0x43]
    // 0x1265a4c: DecompressPointer r0
    //     0x1265a4c: add             x0, x0, HEAP, lsl #32
    // 0x1265a50: LoadField: r3 = r2->field_43
    //     0x1265a50: ldur            w3, [x2, #0x43]
    // 0x1265a54: DecompressPointer r3
    //     0x1265a54: add             x3, x3, HEAP, lsl #32
    // 0x1265a58: r4 = LoadClassIdInstr(r0)
    //     0x1265a58: ldur            x4, [x0, #-1]
    //     0x1265a5c: ubfx            x4, x4, #0xc, #0x14
    // 0x1265a60: stp             x3, x0, [SP]
    // 0x1265a64: mov             x0, x4
    // 0x1265a68: mov             lr, x0
    // 0x1265a6c: ldr             lr, [x21, lr, lsl #3]
    // 0x1265a70: blr             lr
    // 0x1265a74: tbnz            w0, #4, #0x1265aa8
    // 0x1265a78: ldr             x2, [fp, #0x18]
    // 0x1265a7c: ldr             x1, [fp, #0x10]
    // 0x1265a80: LoadField: r3 = r1->field_47
    //     0x1265a80: ldur            w3, [x1, #0x47]
    // 0x1265a84: DecompressPointer r3
    //     0x1265a84: add             x3, x3, HEAP, lsl #32
    // 0x1265a88: LoadField: r1 = r2->field_47
    //     0x1265a88: ldur            w1, [x2, #0x47]
    // 0x1265a8c: DecompressPointer r1
    //     0x1265a8c: add             x1, x1, HEAP, lsl #32
    // 0x1265a90: cmp             w3, w1
    // 0x1265a94: r16 = true
    //     0x1265a94: add             x16, NULL, #0x20  ; true
    // 0x1265a98: r17 = false
    //     0x1265a98: add             x17, NULL, #0x30  ; false
    // 0x1265a9c: csel            x2, x16, x17, eq
    // 0x1265aa0: mov             x0, x2
    // 0x1265aa4: b               #0x1265aac
    // 0x1265aa8: r0 = false
    //     0x1265aa8: add             x0, NULL, #0x30  ; false
    // 0x1265aac: LeaveFrame
    //     0x1265aac: mov             SP, fp
    //     0x1265ab0: ldp             fp, lr, [SP], #0x10
    // 0x1265ab4: ret
    //     0x1265ab4: ret             
    // 0x1265ab8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1265ab8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1265abc: b               #0x1265808
  }
}

// class id: 6851, size: 0x14, field offset: 0x10
//   const constructor, 
class ButtonTheme extends InheritedTheme {

  _ updateShouldNotify(/* No info */) {
    // ** addr: 0xc00390, size: 0xa0
    // 0xc00390: EnterFrame
    //     0xc00390: stp             fp, lr, [SP, #-0x10]!
    //     0xc00394: mov             fp, SP
    // 0xc00398: AllocStack(0x20)
    //     0xc00398: sub             SP, SP, #0x20
    // 0xc0039c: SetupParameters(ButtonTheme this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xc0039c: mov             x4, x1
    //     0xc003a0: mov             x3, x2
    //     0xc003a4: stur            x1, [fp, #-8]
    //     0xc003a8: stur            x2, [fp, #-0x10]
    // 0xc003ac: CheckStackOverflow
    //     0xc003ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc003b0: cmp             SP, x16
    //     0xc003b4: b.ls            #0xc00428
    // 0xc003b8: mov             x0, x3
    // 0xc003bc: r2 = Null
    //     0xc003bc: mov             x2, NULL
    // 0xc003c0: r1 = Null
    //     0xc003c0: mov             x1, NULL
    // 0xc003c4: r4 = 60
    //     0xc003c4: mov             x4, #0x3c
    // 0xc003c8: branchIfSmi(r0, 0xc003d4)
    //     0xc003c8: tbz             w0, #0, #0xc003d4
    // 0xc003cc: r4 = LoadClassIdInstr(r0)
    //     0xc003cc: ldur            x4, [x0, #-1]
    //     0xc003d0: ubfx            x4, x4, #0xc, #0x14
    // 0xc003d4: r17 = 6851
    //     0xc003d4: mov             x17, #0x1ac3
    // 0xc003d8: cmp             x4, x17
    // 0xc003dc: b.eq            #0xc003f4
    // 0xc003e0: r8 = ButtonTheme
    //     0xc003e0: add             x8, PP, #0x95, lsl #12  ; [pp+0x95e48] Type: ButtonTheme
    //     0xc003e4: ldr             x8, [x8, #0xe48]
    // 0xc003e8: r3 = Null
    //     0xc003e8: add             x3, PP, #0x95, lsl #12  ; [pp+0x95e50] Null
    //     0xc003ec: ldr             x3, [x3, #0xe50]
    // 0xc003f0: r0 = DefaultTypeTest()
    //     0xc003f0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xc003f4: ldur            x0, [fp, #-8]
    // 0xc003f8: LoadField: r1 = r0->field_f
    //     0xc003f8: ldur            w1, [x0, #0xf]
    // 0xc003fc: DecompressPointer r1
    //     0xc003fc: add             x1, x1, HEAP, lsl #32
    // 0xc00400: ldur            x0, [fp, #-0x10]
    // 0xc00404: LoadField: r2 = r0->field_f
    //     0xc00404: ldur            w2, [x0, #0xf]
    // 0xc00408: DecompressPointer r2
    //     0xc00408: add             x2, x2, HEAP, lsl #32
    // 0xc0040c: stp             x2, x1, [SP]
    // 0xc00410: r0 = ==()
    //     0xc00410: bl              #0x12657f0  ; [package:flutter/src/material/button_theme.dart] ButtonThemeData::==
    // 0xc00414: eor             x1, x0, #0x10
    // 0xc00418: mov             x0, x1
    // 0xc0041c: LeaveFrame
    //     0xc0041c: mov             SP, fp
    //     0xc00420: ldp             fp, lr, [SP], #0x10
    // 0xc00424: ret
    //     0xc00424: ret             
    // 0xc00428: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc00428: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc0042c: b               #0xc003b8
  }
  static _ of(/* No info */) {
    // ** addr: 0xd1e5a4, size: 0xec
    // 0xd1e5a4: EnterFrame
    //     0xd1e5a4: stp             fp, lr, [SP, #-0x10]!
    //     0xd1e5a8: mov             fp, SP
    // 0xd1e5ac: AllocStack(0x20)
    //     0xd1e5ac: sub             SP, SP, #0x20
    // 0xd1e5b0: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0xd1e5b0: stur            x1, [fp, #-8]
    // 0xd1e5b4: CheckStackOverflow
    //     0xd1e5b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd1e5b8: cmp             SP, x16
    //     0xd1e5bc: b.ls            #0xd1e688
    // 0xd1e5c0: r16 = <ButtonTheme>
    //     0xd1e5c0: add             x16, PP, #0x99, lsl #12  ; [pp+0x99a08] TypeArguments: <ButtonTheme>
    //     0xd1e5c4: ldr             x16, [x16, #0xa08]
    // 0xd1e5c8: stp             x1, x16, [SP]
    // 0xd1e5cc: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd1e5cc: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd1e5d0: r0 = dependOnInheritedWidgetOfExactType()
    //     0xd1e5d0: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xd1e5d4: cmp             w0, NULL
    // 0xd1e5d8: b.ne            #0xd1e5e4
    // 0xd1e5dc: r0 = Null
    //     0xd1e5dc: mov             x0, NULL
    // 0xd1e5e0: b               #0xd1e5f0
    // 0xd1e5e4: LoadField: r1 = r0->field_f
    //     0xd1e5e4: ldur            w1, [x0, #0xf]
    // 0xd1e5e8: DecompressPointer r1
    //     0xd1e5e8: add             x1, x1, HEAP, lsl #32
    // 0xd1e5ec: mov             x0, x1
    // 0xd1e5f0: stur            x0, [fp, #-0x10]
    // 0xd1e5f4: cmp             w0, NULL
    // 0xd1e5f8: b.eq            #0xd1e60c
    // 0xd1e5fc: LoadField: r1 = r0->field_43
    //     0xd1e5fc: ldur            w1, [x0, #0x43]
    // 0xd1e600: DecompressPointer r1
    //     0xd1e600: add             x1, x1, HEAP, lsl #32
    // 0xd1e604: cmp             w1, NULL
    // 0xd1e608: b.ne            #0xd1e67c
    // 0xd1e60c: ldur            x1, [fp, #-8]
    // 0xd1e610: r0 = of()
    //     0xd1e610: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd1e614: mov             x1, x0
    // 0xd1e618: ldur            x0, [fp, #-0x10]
    // 0xd1e61c: cmp             w0, NULL
    // 0xd1e620: b.ne            #0xd1e62c
    // 0xd1e624: LoadField: r0 = r1->field_ab
    //     0xd1e624: ldur            w0, [x1, #0xab]
    // 0xd1e628: DecompressPointer r0
    //     0xd1e628: add             x0, x0, HEAP, lsl #32
    // 0xd1e62c: LoadField: r2 = r0->field_43
    //     0xd1e62c: ldur            w2, [x0, #0x43]
    // 0xd1e630: DecompressPointer r2
    //     0xd1e630: add             x2, x2, HEAP, lsl #32
    // 0xd1e634: cmp             w2, NULL
    // 0xd1e638: b.ne            #0xd1e674
    // 0xd1e63c: LoadField: r2 = r1->field_ab
    //     0xd1e63c: ldur            w2, [x1, #0xab]
    // 0xd1e640: DecompressPointer r2
    //     0xd1e640: add             x2, x2, HEAP, lsl #32
    // 0xd1e644: LoadField: r3 = r2->field_43
    //     0xd1e644: ldur            w3, [x2, #0x43]
    // 0xd1e648: DecompressPointer r3
    //     0xd1e648: add             x3, x3, HEAP, lsl #32
    // 0xd1e64c: cmp             w3, NULL
    // 0xd1e650: b.ne            #0xd1e660
    // 0xd1e654: LoadField: r2 = r1->field_3f
    //     0xd1e654: ldur            w2, [x1, #0x3f]
    // 0xd1e658: DecompressPointer r2
    //     0xd1e658: add             x2, x2, HEAP, lsl #32
    // 0xd1e65c: b               #0xd1e664
    // 0xd1e660: mov             x2, x3
    // 0xd1e664: mov             x1, x0
    // 0xd1e668: r0 = copyWith()
    //     0xd1e668: bl              #0xd1e690  ; [package:flutter/src/material/button_theme.dart] ButtonThemeData::copyWith
    // 0xd1e66c: mov             x1, x0
    // 0xd1e670: b               #0xd1e678
    // 0xd1e674: mov             x1, x0
    // 0xd1e678: mov             x0, x1
    // 0xd1e67c: LeaveFrame
    //     0xd1e67c: mov             SP, fp
    //     0xd1e680: ldp             fp, lr, [SP], #0x10
    // 0xd1e684: ret
    //     0xd1e684: ret             
    // 0xd1e688: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1e688: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd1e68c: b               #0xd1e5c0
  }
  _ wrap(/* No info */) {
    // ** addr: 0x1200b28, size: 0x3c
    // 0x1200b28: EnterFrame
    //     0x1200b28: stp             fp, lr, [SP, #-0x10]!
    //     0x1200b2c: mov             fp, SP
    // 0x1200b30: AllocStack(0x10)
    //     0x1200b30: sub             SP, SP, #0x10
    // 0x1200b34: SetupParameters(dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x1200b34: stur            x2, [fp, #-0x10]
    // 0x1200b38: LoadField: r0 = r1->field_f
    //     0x1200b38: ldur            w0, [x1, #0xf]
    // 0x1200b3c: DecompressPointer r0
    //     0x1200b3c: add             x0, x0, HEAP, lsl #32
    // 0x1200b40: stur            x0, [fp, #-8]
    // 0x1200b44: r0 = ButtonTheme()
    //     0x1200b44: bl              #0x104f910  ; AllocateButtonThemeStub -> ButtonTheme (size=0x14)
    // 0x1200b48: ldur            x1, [fp, #-8]
    // 0x1200b4c: StoreField: r0->field_f = r1
    //     0x1200b4c: stur            w1, [x0, #0xf]
    // 0x1200b50: ldur            x1, [fp, #-0x10]
    // 0x1200b54: StoreField: r0->field_b = r1
    //     0x1200b54: stur            w1, [x0, #0xb]
    // 0x1200b58: LeaveFrame
    //     0x1200b58: mov             SP, fp
    //     0x1200b5c: ldp             fp, lr, [SP], #0x10
    // 0x1200b60: ret
    //     0x1200b60: ret             
  }
}

// class id: 8296, size: 0x14, field offset: 0x14
enum ButtonBarLayoutBehavior extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11a9e3c, size: 0x64
    // 0x11a9e3c: EnterFrame
    //     0x11a9e3c: stp             fp, lr, [SP, #-0x10]!
    //     0x11a9e40: mov             fp, SP
    // 0x11a9e44: AllocStack(0x10)
    //     0x11a9e44: sub             SP, SP, #0x10
    // 0x11a9e48: SetupParameters(ButtonBarLayoutBehavior this /* r1 => r0, fp-0x8 */)
    //     0x11a9e48: mov             x0, x1
    //     0x11a9e4c: stur            x1, [fp, #-8]
    // 0x11a9e50: CheckStackOverflow
    //     0x11a9e50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a9e54: cmp             SP, x16
    //     0x11a9e58: b.ls            #0x11a9e98
    // 0x11a9e5c: r1 = Null
    //     0x11a9e5c: mov             x1, NULL
    // 0x11a9e60: r2 = 4
    //     0x11a9e60: mov             x2, #4
    // 0x11a9e64: r0 = AllocateArray()
    //     0x11a9e64: bl              #0x13df928  ; AllocateArrayStub
    // 0x11a9e68: r16 = "ButtonBarLayoutBehavior."
    //     0x11a9e68: add             x16, PP, #0x26, lsl #12  ; [pp+0x26540] "ButtonBarLayoutBehavior."
    //     0x11a9e6c: ldr             x16, [x16, #0x540]
    // 0x11a9e70: StoreField: r0->field_f = r16
    //     0x11a9e70: stur            w16, [x0, #0xf]
    // 0x11a9e74: ldur            x1, [fp, #-8]
    // 0x11a9e78: LoadField: r2 = r1->field_f
    //     0x11a9e78: ldur            w2, [x1, #0xf]
    // 0x11a9e7c: DecompressPointer r2
    //     0x11a9e7c: add             x2, x2, HEAP, lsl #32
    // 0x11a9e80: StoreField: r0->field_13 = r2
    //     0x11a9e80: stur            w2, [x0, #0x13]
    // 0x11a9e84: str             x0, [SP]
    // 0x11a9e88: r0 = _interpolate()
    //     0x11a9e88: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11a9e8c: LeaveFrame
    //     0x11a9e8c: mov             SP, fp
    //     0x11a9e90: ldp             fp, lr, [SP], #0x10
    // 0x11a9e94: ret
    //     0x11a9e94: ret             
    // 0x11a9e98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a9e98: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a9e9c: b               #0x11a9e5c
  }
}

// class id: 8297, size: 0x14, field offset: 0x14
enum ButtonTextTheme extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11a9dd8, size: 0x64
    // 0x11a9dd8: EnterFrame
    //     0x11a9dd8: stp             fp, lr, [SP, #-0x10]!
    //     0x11a9ddc: mov             fp, SP
    // 0x11a9de0: AllocStack(0x10)
    //     0x11a9de0: sub             SP, SP, #0x10
    // 0x11a9de4: SetupParameters(ButtonTextTheme this /* r1 => r0, fp-0x8 */)
    //     0x11a9de4: mov             x0, x1
    //     0x11a9de8: stur            x1, [fp, #-8]
    // 0x11a9dec: CheckStackOverflow
    //     0x11a9dec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a9df0: cmp             SP, x16
    //     0x11a9df4: b.ls            #0x11a9e34
    // 0x11a9df8: r1 = Null
    //     0x11a9df8: mov             x1, NULL
    // 0x11a9dfc: r2 = 4
    //     0x11a9dfc: mov             x2, #4
    // 0x11a9e00: r0 = AllocateArray()
    //     0x11a9e00: bl              #0x13df928  ; AllocateArrayStub
    // 0x11a9e04: r16 = "ButtonTextTheme."
    //     0x11a9e04: add             x16, PP, #0x26, lsl #12  ; [pp+0x26538] "ButtonTextTheme."
    //     0x11a9e08: ldr             x16, [x16, #0x538]
    // 0x11a9e0c: StoreField: r0->field_f = r16
    //     0x11a9e0c: stur            w16, [x0, #0xf]
    // 0x11a9e10: ldur            x1, [fp, #-8]
    // 0x11a9e14: LoadField: r2 = r1->field_f
    //     0x11a9e14: ldur            w2, [x1, #0xf]
    // 0x11a9e18: DecompressPointer r2
    //     0x11a9e18: add             x2, x2, HEAP, lsl #32
    // 0x11a9e1c: StoreField: r0->field_13 = r2
    //     0x11a9e1c: stur            w2, [x0, #0x13]
    // 0x11a9e20: str             x0, [SP]
    // 0x11a9e24: r0 = _interpolate()
    //     0x11a9e24: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11a9e28: LeaveFrame
    //     0x11a9e28: mov             SP, fp
    //     0x11a9e2c: ldp             fp, lr, [SP], #0x10
    // 0x11a9e30: ret
    //     0x11a9e30: ret             
    // 0x11a9e34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a9e34: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a9e38: b               #0x11a9df8
  }
}
