// lib: , url: package:device_info_plus_platform_interface/method_channel/method_channel_device_info.dart

// class id: 1048689, size: 0x8
class :: {
}

// class id: 3708, size: 0xc, field offset: 0x8
class MethodChannelDeviceInfo extends DeviceInfoPlatform {

  _ deviceInfo(/* No info */) async {
    // ** addr: 0x9ebeb0, size: 0xd4
    // 0x9ebeb0: EnterFrame
    //     0x9ebeb0: stp             fp, lr, [SP, #-0x10]!
    //     0x9ebeb4: mov             fp, SP
    // 0x9ebeb8: AllocStack(0x30)
    //     0x9ebeb8: sub             SP, SP, #0x30
    // 0x9ebebc: SetupParameters(MethodChannelDeviceInfo this /* r1 => r1, fp-0x10 */)
    //     0x9ebebc: stur            NULL, [fp, #-8]
    //     0x9ebec0: stur            x1, [fp, #-0x10]
    // 0x9ebec4: CheckStackOverflow
    //     0x9ebec4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ebec8: cmp             SP, x16
    //     0x9ebecc: b.ls            #0x9ebf7c
    // 0x9ebed0: InitAsync() -> Future<BaseDeviceInfo>
    //     0x9ebed0: add             x0, PP, #0x7a, lsl #12  ; [pp+0x7a9a0] TypeArguments: <BaseDeviceInfo>
    //     0x9ebed4: ldr             x0, [x0, #0x9a0]
    //     0x9ebed8: bl              #0x7f5e44  ; InitAsyncStub
    // 0x9ebedc: r0 = BaseDeviceInfo()
    //     0x9ebedc: bl              #0x9ebf84  ; AllocateBaseDeviceInfoStub -> BaseDeviceInfo (size=0xc)
    // 0x9ebee0: stur            x0, [fp, #-0x10]
    // 0x9ebee4: r16 = Instance_MethodChannel
    //     0x9ebee4: add             x16, PP, #0x7a, lsl #12  ; [pp+0x7a9a8] Obj!MethodChannel@129bbc1
    //     0x9ebee8: ldr             x16, [x16, #0x9a8]
    // 0x9ebeec: stp             x16, NULL, [SP, #8]
    // 0x9ebef0: r16 = "getDeviceInfo"
    //     0x9ebef0: add             x16, PP, #0x7a, lsl #12  ; [pp+0x7a9b0] "getDeviceInfo"
    //     0x9ebef4: ldr             x16, [x16, #0x9b0]
    // 0x9ebef8: str             x16, [SP]
    // 0x9ebefc: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x9ebefc: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x9ebf00: r0 = invokeMethod()
    //     0x9ebf00: bl              #0x130b008  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0x9ebf04: mov             x1, x0
    // 0x9ebf08: stur            x1, [fp, #-0x18]
    // 0x9ebf0c: r0 = Await()
    //     0x9ebf0c: bl              #0x7f5c00  ; AwaitStub
    // 0x9ebf10: r16 = <String, dynamic>
    //     0x9ebf10: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x9ebf14: stp             x0, x16, [SP]
    // 0x9ebf18: r4 = 0
    //     0x9ebf18: mov             x4, #0
    // 0x9ebf1c: ldr             x0, [SP]
    // 0x9ebf20: r16 = 139822029843448
    //     0x9ebf20: add             x16, PP, #0x7a, lsl #12  ; [pp+0x7a9b8] IMM: 0x7f2ada6babf8
    //     0x9ebf24: add             x16, x16, #0x9b8
    // 0x9ebf28: ldp             lr, x5, [x16]
    // 0x9ebf2c: blr             lr
    // 0x9ebf30: mov             x3, x0
    // 0x9ebf34: r2 = Null
    //     0x9ebf34: mov             x2, NULL
    // 0x9ebf38: r1 = Null
    //     0x9ebf38: mov             x1, NULL
    // 0x9ebf3c: stur            x3, [fp, #-0x18]
    // 0x9ebf40: r8 = Map<String, dynamic>
    //     0x9ebf40: ldr             x8, [PP, #0x3298]  ; [pp+0x3298] Type: Map<String, dynamic>
    // 0x9ebf44: r3 = Null
    //     0x9ebf44: add             x3, PP, #0x7a, lsl #12  ; [pp+0x7a9c8] Null
    //     0x9ebf48: ldr             x3, [x3, #0x9c8]
    // 0x9ebf4c: r0 = Map<String, dynamic>()
    //     0x9ebf4c: bl              #0x84f9a4  ; IsType_Map<String, dynamic>_Stub
    // 0x9ebf50: ldur            x0, [fp, #-0x18]
    // 0x9ebf54: ldur            x1, [fp, #-0x10]
    // 0x9ebf58: StoreField: r1->field_7 = r0
    //     0x9ebf58: stur            w0, [x1, #7]
    //     0x9ebf5c: ldurb           w16, [x1, #-1]
    //     0x9ebf60: ldurb           w17, [x0, #-1]
    //     0x9ebf64: and             x16, x17, x16, lsr #2
    //     0x9ebf68: tst             x16, HEAP, lsr #32
    //     0x9ebf6c: b.eq            #0x9ebf74
    //     0x9ebf70: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x9ebf74: mov             x0, x1
    // 0x9ebf78: r0 = ReturnAsyncNotFuture()
    //     0x9ebf78: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x9ebf7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ebf7c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ebf80: b               #0x9ebed0
  }
}
