// lib: , url: package:device_info_plus_platform_interface/device_info_plus_platform_interface.dart

// class id: 1048688, size: 0x8
class :: {
}

// class id: 3707, size: 0x8, field offset: 0x8
abstract class DeviceInfoPlatform extends PlatformInterface {

  static late DeviceInfoPlatform _instance; // offset: 0xf84
  static late final Object _token; // offset: 0xf80

  static DeviceInfoPlatform _instance() {
    // ** addr: 0x9ebf90, size: 0x98
    // 0x9ebf90: EnterFrame
    //     0x9ebf90: stp             fp, lr, [SP, #-0x10]!
    //     0x9ebf94: mov             fp, SP
    // 0x9ebf98: AllocStack(0x10)
    //     0x9ebf98: sub             SP, SP, #0x10
    // 0x9ebf9c: CheckStackOverflow
    //     0x9ebf9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ebfa0: cmp             SP, x16
    //     0x9ebfa4: b.ls            #0x9ec020
    // 0x9ebfa8: r0 = MethodChannelDeviceInfo()
    //     0x9ebfa8: bl              #0x9ec028  ; AllocateMethodChannelDeviceInfoStub -> MethodChannelDeviceInfo (size=0xc)
    // 0x9ebfac: mov             x1, x0
    // 0x9ebfb0: r0 = Instance_MethodChannel
    //     0x9ebfb0: add             x0, PP, #0x7a, lsl #12  ; [pp+0x7a9a8] Obj!MethodChannel@129bbc1
    //     0x9ebfb4: ldr             x0, [x0, #0x9a8]
    // 0x9ebfb8: stur            x1, [fp, #-8]
    // 0x9ebfbc: StoreField: r1->field_7 = r0
    //     0x9ebfbc: stur            w0, [x1, #7]
    // 0x9ebfc0: r0 = LoadStaticField(0xf80)
    //     0x9ebfc0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x9ebfc4: ldr             x0, [x0, #0x1f00]
    // 0x9ebfc8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9ebfcc: cmp             w0, w16
    // 0x9ebfd0: b.ne            #0x9ebfe0
    // 0x9ebfd4: r2 = _token
    //     0x9ebfd4: add             x2, PP, #0x7a, lsl #12  ; [pp+0x7a9d8] Field <DeviceInfoPlatform._token@1255502559>: static late final (offset: 0xf80)
    //     0x9ebfd8: ldr             x2, [x2, #0x9d8]
    // 0x9ebfdc: r0 = InitLateFinalStaticField()
    //     0x9ebfdc: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x9ebfe0: stur            x0, [fp, #-0x10]
    // 0x9ebfe4: r0 = LoadStaticField(0xde8)
    //     0x9ebfe4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x9ebfe8: ldr             x0, [x0, #0x1bd0]
    // 0x9ebfec: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9ebff0: cmp             w0, w16
    // 0x9ebff4: b.ne            #0x9ec000
    // 0x9ebff8: r2 = _instanceTokens
    //     0x9ebff8: ldr             x2, [PP, #0x68c0]  ; [pp+0x68c0] Field <PlatformInterface._instanceTokens@1171304592>: static late final (offset: 0xde8)
    // 0x9ebffc: r0 = InitLateFinalStaticField()
    //     0x9ebffc: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x9ec000: mov             x1, x0
    // 0x9ec004: ldur            x2, [fp, #-8]
    // 0x9ec008: ldur            x3, [fp, #-0x10]
    // 0x9ec00c: r0 = []=()
    //     0x9ec00c: bl              #0x7f6290  ; [dart:core] Expando::[]=
    // 0x9ec010: ldur            x0, [fp, #-8]
    // 0x9ec014: LeaveFrame
    //     0x9ec014: mov             SP, fp
    //     0x9ec018: ldp             fp, lr, [SP], #0x10
    // 0x9ec01c: ret
    //     0x9ec01c: ret             
    // 0x9ec020: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ec020: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ec024: b               #0x9ebfa8
  }
}
