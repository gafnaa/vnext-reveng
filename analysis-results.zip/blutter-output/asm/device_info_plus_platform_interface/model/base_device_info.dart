// lib: , url: package:device_info_plus_platform_interface/model/base_device_info.dart

// class id: 1048690, size: 0x8
class :: {
}

// class id: 3419, size: 0xc, field offset: 0x8
class BaseDeviceInfo extends Object {

  _ toString(/* No info */) {
    // ** addr: 0x11142b4, size: 0x68
    // 0x11142b4: EnterFrame
    //     0x11142b4: stp             fp, lr, [SP, #-0x10]!
    //     0x11142b8: mov             fp, SP
    // 0x11142bc: AllocStack(0x8)
    //     0x11142bc: sub             SP, SP, #8
    // 0x11142c0: CheckStackOverflow
    //     0x11142c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11142c4: cmp             SP, x16
    //     0x11142c8: b.ls            #0x1114314
    // 0x11142cc: r1 = Null
    //     0x11142cc: mov             x1, NULL
    // 0x11142d0: r2 = 6
    //     0x11142d0: mov             x2, #6
    // 0x11142d4: r0 = AllocateArray()
    //     0x11142d4: bl              #0x13df928  ; AllocateArrayStub
    // 0x11142d8: r16 = "BaseDeviceInfo{data: "
    //     0x11142d8: add             x16, PP, #0x8a, lsl #12  ; [pp+0x8af80] "BaseDeviceInfo{data: "
    //     0x11142dc: ldr             x16, [x16, #0xf80]
    // 0x11142e0: StoreField: r0->field_f = r16
    //     0x11142e0: stur            w16, [x0, #0xf]
    // 0x11142e4: ldr             x1, [fp, #0x10]
    // 0x11142e8: LoadField: r2 = r1->field_7
    //     0x11142e8: ldur            w2, [x1, #7]
    // 0x11142ec: DecompressPointer r2
    //     0x11142ec: add             x2, x2, HEAP, lsl #32
    // 0x11142f0: StoreField: r0->field_13 = r2
    //     0x11142f0: stur            w2, [x0, #0x13]
    // 0x11142f4: r16 = "}"
    //     0x11142f4: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf78] "}"
    //     0x11142f8: ldr             x16, [x16, #0xf78]
    // 0x11142fc: ArrayStore: r0[0] = r16  ; List_4
    //     0x11142fc: stur            w16, [x0, #0x17]
    // 0x1114300: str             x0, [SP]
    // 0x1114304: r0 = _interpolate()
    //     0x1114304: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x1114308: LeaveFrame
    //     0x1114308: mov             SP, fp
    //     0x111430c: ldp             fp, lr, [SP], #0x10
    // 0x1114310: ret
    //     0x1114310: ret             
    // 0x1114314: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1114314: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1114318: b               #0x11142cc
  }
}
