// lib: , url: package:connectivity_plus_platform_interface/connectivity_plus_platform_interface.dart

// class id: 1048661, size: 0x8
class :: {
}

// class id: 3709, size: 0x8, field offset: 0x8
abstract class ConnectivityPlatform extends PlatformInterface {

  static late ConnectivityPlatform _instance; // offset: 0xf68
  static late final Object _token; // offset: 0xf64

  static ConnectivityPlatform _instance() {
    // ** addr: 0x920448, size: 0x40
    // 0x920448: EnterFrame
    //     0x920448: stp             fp, lr, [SP, #-0x10]!
    //     0x92044c: mov             fp, SP
    // 0x920450: AllocStack(0x8)
    //     0x920450: sub             SP, SP, #8
    // 0x920454: CheckStackOverflow
    //     0x920454: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x920458: cmp             SP, x16
    //     0x92045c: b.ls            #0x920480
    // 0x920460: r0 = MethodChannelConnectivity()
    //     0x920460: bl              #0x920524  ; AllocateMethodChannelConnectivityStub -> MethodChannelConnectivity (size=0x14)
    // 0x920464: mov             x1, x0
    // 0x920468: stur            x0, [fp, #-8]
    // 0x92046c: r0 = MethodChannelConnectivity()
    //     0x92046c: bl              #0x920488  ; [package:connectivity_plus_platform_interface/method_channel_connectivity.dart] MethodChannelConnectivity::MethodChannelConnectivity
    // 0x920470: ldur            x0, [fp, #-8]
    // 0x920474: LeaveFrame
    //     0x920474: mov             SP, fp
    //     0x920478: ldp             fp, lr, [SP], #0x10
    // 0x92047c: ret
    //     0x92047c: ret             
    // 0x920480: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x920480: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x920484: b               #0x920460
  }
}
