// lib: , url: package:connectivity_plus_platform_interface/method_channel_connectivity.dart

// class id: 1048662, size: 0x8
class :: {
}

// class id: 3710, size: 0x14, field offset: 0x8
class MethodChannelConnectivity extends ConnectivityPlatform {

  _ checkConnectivity(/* No info */) {
    // ** addr: 0x920010, size: 0x80
    // 0x920010: EnterFrame
    //     0x920010: stp             fp, lr, [SP, #-0x10]!
    //     0x920014: mov             fp, SP
    // 0x920018: AllocStack(0x20)
    //     0x920018: sub             SP, SP, #0x20
    // 0x92001c: CheckStackOverflow
    //     0x92001c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x920020: cmp             SP, x16
    //     0x920024: b.ls            #0x920088
    // 0x920028: r16 = <String>
    //     0x920028: ldr             x16, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    // 0x92002c: r30 = Instance_MethodChannel
    //     0x92002c: add             lr, PP, #0x15, lsl #12  ; [pp+0x153f8] Obj!MethodChannel@129bb41
    //     0x920030: ldr             lr, [lr, #0x3f8]
    // 0x920034: stp             lr, x16, [SP, #8]
    // 0x920038: r16 = "check"
    //     0x920038: add             x16, PP, #0x15, lsl #12  ; [pp+0x15420] "check"
    //     0x92003c: ldr             x16, [x16, #0x420]
    // 0x920040: str             x16, [SP]
    // 0x920044: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x920044: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x920048: r0 = invokeListMethod()
    //     0x920048: bl              #0x920090  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeListMethod
    // 0x92004c: r1 = Function '<anonymous closure>':.
    //     0x92004c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15428] AnonymousClosure: (0x9201ac), in [package:connectivity_plus_platform_interface/method_channel_connectivity.dart] MethodChannelConnectivity::checkConnectivity (0x920010)
    //     0x920050: ldr             x1, [x1, #0x428]
    // 0x920054: r2 = Null
    //     0x920054: mov             x2, NULL
    // 0x920058: stur            x0, [fp, #-8]
    // 0x92005c: r0 = AllocateClosure()
    //     0x92005c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x920060: r16 = <List<ConnectivityResult>>
    //     0x920060: add             x16, PP, #0x15, lsl #12  ; [pp+0x15360] TypeArguments: <List<ConnectivityResult>>
    //     0x920064: ldr             x16, [x16, #0x360]
    // 0x920068: ldur            lr, [fp, #-8]
    // 0x92006c: stp             lr, x16, [SP, #8]
    // 0x920070: str             x0, [SP]
    // 0x920074: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x920074: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x920078: r0 = then()
    //     0x920078: bl              #0x1293070  ; [dart:async] _Future::then
    // 0x92007c: LeaveFrame
    //     0x92007c: mov             SP, fp
    //     0x920080: ldp             fp, lr, [SP], #0x10
    // 0x920084: ret
    //     0x920084: ret             
    // 0x920088: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x920088: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x92008c: b               #0x920028
  }
  [closure] List<ConnectivityResult> <anonymous closure>(dynamic, List<String>?) {
    // ** addr: 0x9201ac, size: 0x50
    // 0x9201ac: EnterFrame
    //     0x9201ac: stp             fp, lr, [SP, #-0x10]!
    //     0x9201b0: mov             fp, SP
    // 0x9201b4: CheckStackOverflow
    //     0x9201b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9201b8: cmp             SP, x16
    //     0x9201bc: b.ls            #0x9201f4
    // 0x9201c0: ldr             x0, [fp, #0x10]
    // 0x9201c4: cmp             w0, NULL
    // 0x9201c8: b.ne            #0x9201e0
    // 0x9201cc: r1 = <String>
    //     0x9201cc: ldr             x1, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    // 0x9201d0: r2 = 0
    //     0x9201d0: mov             x2, #0
    // 0x9201d4: r0 = _GrowableList()
    //     0x9201d4: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x9201d8: mov             x1, x0
    // 0x9201dc: b               #0x9201e4
    // 0x9201e0: mov             x1, x0
    // 0x9201e4: r0 = parseConnectivityResults()
    //     0x9201e4: bl              #0x9201fc  ; [package:connectivity_plus_platform_interface/src/utils.dart] ::parseConnectivityResults
    // 0x9201e8: LeaveFrame
    //     0x9201e8: mov             SP, fp
    //     0x9201ec: ldp             fp, lr, [SP], #0x10
    // 0x9201f0: ret
    //     0x9201f0: ret             
    // 0x9201f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9201f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9201f8: b               #0x9201c0
  }
  _ MethodChannelConnectivity(/* No info */) {
    // ** addr: 0x920488, size: 0x9c
    // 0x920488: EnterFrame
    //     0x920488: stp             fp, lr, [SP, #-0x10]!
    //     0x92048c: mov             fp, SP
    // 0x920490: AllocStack(0x10)
    //     0x920490: sub             SP, SP, #0x10
    // 0x920494: r2 = Instance_MethodChannel
    //     0x920494: add             x2, PP, #0x15, lsl #12  ; [pp+0x153f8] Obj!MethodChannel@129bb41
    //     0x920498: ldr             x2, [x2, #0x3f8]
    // 0x92049c: r0 = Instance_EventChannel
    //     0x92049c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15348] Obj!EventChannel@129ba61
    //     0x9204a0: ldr             x0, [x0, #0x348]
    // 0x9204a4: stur            x1, [fp, #-8]
    // 0x9204a8: CheckStackOverflow
    //     0x9204a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9204ac: cmp             SP, x16
    //     0x9204b0: b.ls            #0x92051c
    // 0x9204b4: StoreField: r1->field_7 = r2
    //     0x9204b4: stur            w2, [x1, #7]
    // 0x9204b8: StoreField: r1->field_b = r0
    //     0x9204b8: stur            w0, [x1, #0xb]
    // 0x9204bc: r0 = LoadStaticField(0xf64)
    //     0x9204bc: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x9204c0: ldr             x0, [x0, #0x1ec8]
    // 0x9204c4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9204c8: cmp             w0, w16
    // 0x9204cc: b.ne            #0x9204dc
    // 0x9204d0: r2 = _token
    //     0x9204d0: add             x2, PP, #0x15, lsl #12  ; [pp+0x15400] Field <ConnectivityPlatform._token@1232483631>: static late final (offset: 0xf64)
    //     0x9204d4: ldr             x2, [x2, #0x400]
    // 0x9204d8: r0 = InitLateFinalStaticField()
    //     0x9204d8: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x9204dc: stur            x0, [fp, #-0x10]
    // 0x9204e0: r0 = LoadStaticField(0xde8)
    //     0x9204e0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x9204e4: ldr             x0, [x0, #0x1bd0]
    // 0x9204e8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9204ec: cmp             w0, w16
    // 0x9204f0: b.ne            #0x9204fc
    // 0x9204f4: r2 = _instanceTokens
    //     0x9204f4: ldr             x2, [PP, #0x68c0]  ; [pp+0x68c0] Field <PlatformInterface._instanceTokens@1171304592>: static late final (offset: 0xde8)
    // 0x9204f8: r0 = InitLateFinalStaticField()
    //     0x9204f8: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x9204fc: mov             x1, x0
    // 0x920500: ldur            x2, [fp, #-8]
    // 0x920504: ldur            x3, [fp, #-0x10]
    // 0x920508: r0 = []=()
    //     0x920508: bl              #0x7f6290  ; [dart:core] Expando::[]=
    // 0x92050c: r0 = Null
    //     0x92050c: mov             x0, NULL
    // 0x920510: LeaveFrame
    //     0x920510: mov             SP, fp
    //     0x920514: ldp             fp, lr, [SP], #0x10
    // 0x920518: ret
    //     0x920518: ret             
    // 0x92051c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x92051c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x920520: b               #0x9204b4
  }
  get _ onConnectivityChanged(/* No info */) {
    // ** addr: 0xf98d90, size: 0xd0
    // 0xf98d90: EnterFrame
    //     0xf98d90: stp             fp, lr, [SP, #-0x10]!
    //     0xf98d94: mov             fp, SP
    // 0xf98d98: AllocStack(0x28)
    //     0xf98d98: sub             SP, SP, #0x28
    // 0xf98d9c: SetupParameters(MethodChannelConnectivity this /* r1 => r0, fp-0x8 */)
    //     0xf98d9c: mov             x0, x1
    //     0xf98da0: stur            x1, [fp, #-8]
    // 0xf98da4: CheckStackOverflow
    //     0xf98da4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf98da8: cmp             SP, x16
    //     0xf98dac: b.ls            #0xf98e58
    // 0xf98db0: LoadField: r1 = r0->field_f
    //     0xf98db0: ldur            w1, [x0, #0xf]
    // 0xf98db4: DecompressPointer r1
    //     0xf98db4: add             x1, x1, HEAP, lsl #32
    // 0xf98db8: cmp             w1, NULL
    // 0xf98dbc: b.ne            #0xf98e48
    // 0xf98dc0: r1 = Instance_EventChannel
    //     0xf98dc0: add             x1, PP, #0x15, lsl #12  ; [pp+0x15348] Obj!EventChannel@129ba61
    //     0xf98dc4: ldr             x1, [x1, #0x348]
    // 0xf98dc8: r0 = receiveBroadcastStream()
    //     0xf98dc8: bl              #0x8c35d4  ; [package:flutter/src/services/platform_channel.dart] EventChannel::receiveBroadcastStream
    // 0xf98dcc: r1 = Function '<anonymous closure>':.
    //     0xf98dcc: add             x1, PP, #0x15, lsl #12  ; [pp+0x15350] AnonymousClosure: (0xf98e60), in [package:connectivity_plus_platform_interface/method_channel_connectivity.dart] MethodChannelConnectivity::onConnectivityChanged (0xf98d90)
    //     0xf98dd0: ldr             x1, [x1, #0x350]
    // 0xf98dd4: r2 = Null
    //     0xf98dd4: mov             x2, NULL
    // 0xf98dd8: stur            x0, [fp, #-0x10]
    // 0xf98ddc: r0 = AllocateClosure()
    //     0xf98ddc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf98de0: r16 = <List<String>>
    //     0xf98de0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15358] TypeArguments: <List<String>>
    //     0xf98de4: ldr             x16, [x16, #0x358]
    // 0xf98de8: ldur            lr, [fp, #-0x10]
    // 0xf98dec: stp             lr, x16, [SP, #8]
    // 0xf98df0: str             x0, [SP]
    // 0xf98df4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xf98df4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xf98df8: r0 = map()
    //     0xf98df8: bl              #0x8c354c  ; [dart:async] Stream::map
    // 0xf98dfc: r16 = <List<ConnectivityResult>>
    //     0xf98dfc: add             x16, PP, #0x15, lsl #12  ; [pp+0x15360] TypeArguments: <List<ConnectivityResult>>
    //     0xf98e00: ldr             x16, [x16, #0x360]
    // 0xf98e04: stp             x0, x16, [SP, #8]
    // 0xf98e08: r16 = Closure: (List<String>) => List<ConnectivityResult> from Function 'parseConnectivityResults': static.
    //     0xf98e08: add             x16, PP, #0x15, lsl #12  ; [pp+0x15368] Closure: (List<String>) => List<ConnectivityResult> from Function 'parseConnectivityResults': static. (0x7f2ada8072a8)
    //     0xf98e0c: ldr             x16, [x16, #0x368]
    // 0xf98e10: str             x16, [SP]
    // 0xf98e14: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xf98e14: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xf98e18: r0 = map()
    //     0xf98e18: bl              #0x8c354c  ; [dart:async] Stream::map
    // 0xf98e1c: mov             x1, x0
    // 0xf98e20: ldur            x2, [fp, #-8]
    // 0xf98e24: StoreField: r2->field_f = r0
    //     0xf98e24: stur            w0, [x2, #0xf]
    //     0xf98e28: ldurb           w16, [x2, #-1]
    //     0xf98e2c: ldurb           w17, [x0, #-1]
    //     0xf98e30: and             x16, x17, x16, lsr #2
    //     0xf98e34: tst             x16, HEAP, lsr #32
    //     0xf98e38: b.eq            #0xf98e40
    //     0xf98e3c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf98e40: mov             x0, x1
    // 0xf98e44: b               #0xf98e4c
    // 0xf98e48: mov             x0, x1
    // 0xf98e4c: LeaveFrame
    //     0xf98e4c: mov             SP, fp
    //     0xf98e50: ldp             fp, lr, [SP], #0x10
    // 0xf98e54: ret
    //     0xf98e54: ret             
    // 0xf98e58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf98e58: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf98e5c: b               #0xf98db0
  }
  [closure] List<String> <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0xf98e60, size: 0x54
    // 0xf98e60: EnterFrame
    //     0xf98e60: stp             fp, lr, [SP, #-0x10]!
    //     0xf98e64: mov             fp, SP
    // 0xf98e68: CheckStackOverflow
    //     0xf98e68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf98e6c: cmp             SP, x16
    //     0xf98e70: b.ls            #0xf98eac
    // 0xf98e74: ldr             x0, [fp, #0x10]
    // 0xf98e78: r2 = Null
    //     0xf98e78: mov             x2, NULL
    // 0xf98e7c: r1 = Null
    //     0xf98e7c: mov             x1, NULL
    // 0xf98e80: r8 = Iterable
    //     0xf98e80: ldr             x8, [PP, #0x11a0]  ; [pp+0x11a0] Type: Iterable
    // 0xf98e84: r3 = Null
    //     0xf98e84: add             x3, PP, #0x15, lsl #12  ; [pp+0x153e8] Null
    //     0xf98e88: ldr             x3, [x3, #0x3e8]
    // 0xf98e8c: r0 = Iterable()
    //     0xf98e8c: bl              #0x7e7350  ; IsType_Iterable_Stub
    // 0xf98e90: ldr             x2, [fp, #0x10]
    // 0xf98e94: r1 = <String>
    //     0xf98e94: ldr             x1, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    // 0xf98e98: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xf98e98: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xf98e9c: r0 = List.from()
    //     0xf98e9c: bl              #0x876494  ; [dart:core] List::List.from
    // 0xf98ea0: LeaveFrame
    //     0xf98ea0: mov             SP, fp
    //     0xf98ea4: ldp             fp, lr, [SP], #0x10
    // 0xf98ea8: ret
    //     0xf98ea8: ret             
    // 0xf98eac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf98eac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf98eb0: b               #0xf98e74
  }
}
