// lib: , url: package:connectivity_plus_platform_interface/src/utils.dart

// class id: 1048664, size: 0x8
class :: {

  static _ parseConnectivityResults(/* No info */) {
    // ** addr: 0x9201fc, size: 0xac
    // 0x9201fc: EnterFrame
    //     0x9201fc: stp             fp, lr, [SP, #-0x10]!
    //     0x920200: mov             fp, SP
    // 0x920204: AllocStack(0x20)
    //     0x920204: sub             SP, SP, #0x20
    // 0x920208: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */)
    //     0x920208: mov             x0, x1
    //     0x92020c: stur            x1, [fp, #-8]
    // 0x920210: CheckStackOverflow
    //     0x920210: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x920214: cmp             SP, x16
    //     0x920218: b.ls            #0x9202a0
    // 0x92021c: r1 = Function '<anonymous closure>': static.
    //     0x92021c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15370] AnonymousClosure: static (0x9202d8), in [package:connectivity_plus_platform_interface/src/utils.dart] ::parseConnectivityResults (0x9201fc)
    //     0x920220: ldr             x1, [x1, #0x370]
    // 0x920224: r2 = Null
    //     0x920224: mov             x2, NULL
    // 0x920228: r0 = AllocateClosure()
    //     0x920228: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x92022c: mov             x1, x0
    // 0x920230: ldur            x0, [fp, #-8]
    // 0x920234: r2 = LoadClassIdInstr(r0)
    //     0x920234: ldur            x2, [x0, #-1]
    //     0x920238: ubfx            x2, x2, #0xc, #0x14
    // 0x92023c: r16 = <ConnectivityResult>
    //     0x92023c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15340] TypeArguments: <ConnectivityResult>
    //     0x920240: ldr             x16, [x16, #0x340]
    // 0x920244: stp             x0, x16, [SP, #8]
    // 0x920248: str             x1, [SP]
    // 0x92024c: mov             x0, x2
    // 0x920250: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x920250: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x920254: r0 = GDT[cid_x0 + 0x12caa]()
    //     0x920254: mov             x17, #0x2caa
    //     0x920258: movk            x17, #1, lsl #16
    //     0x92025c: add             lr, x0, x17
    //     0x920260: ldr             lr, [x21, lr, lsl #3]
    //     0x920264: blr             lr
    // 0x920268: r1 = LoadClassIdInstr(r0)
    //     0x920268: ldur            x1, [x0, #-1]
    //     0x92026c: ubfx            x1, x1, #0xc, #0x14
    // 0x920270: mov             x16, x0
    // 0x920274: mov             x0, x1
    // 0x920278: mov             x1, x16
    // 0x92027c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x92027c: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x920280: r0 = GDT[cid_x0 + 0x126dc]()
    //     0x920280: mov             x17, #0x26dc
    //     0x920284: movk            x17, #1, lsl #16
    //     0x920288: add             lr, x0, x17
    //     0x92028c: ldr             lr, [x21, lr, lsl #3]
    //     0x920290: blr             lr
    // 0x920294: LeaveFrame
    //     0x920294: mov             SP, fp
    //     0x920298: ldp             fp, lr, [SP], #0x10
    // 0x92029c: ret
    //     0x92029c: ret             
    // 0x9202a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9202a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9202a4: b               #0x92021c
  }
  [closure] static List<ConnectivityResult> parseConnectivityResults(dynamic, List<String>) {
    // ** addr: 0x9202a8, size: 0x30
    // 0x9202a8: EnterFrame
    //     0x9202a8: stp             fp, lr, [SP, #-0x10]!
    //     0x9202ac: mov             fp, SP
    // 0x9202b0: CheckStackOverflow
    //     0x9202b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9202b4: cmp             SP, x16
    //     0x9202b8: b.ls            #0x9202d0
    // 0x9202bc: ldr             x1, [fp, #0x10]
    // 0x9202c0: r0 = parseConnectivityResults()
    //     0x9202c0: bl              #0x9201fc  ; [package:connectivity_plus_platform_interface/src/utils.dart] ::parseConnectivityResults
    // 0x9202c4: LeaveFrame
    //     0x9202c4: mov             SP, fp
    //     0x9202c8: ldp             fp, lr, [SP], #0x10
    // 0x9202cc: ret
    //     0x9202cc: ret             
    // 0x9202d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9202d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9202d4: b               #0x9202bc
  }
  [closure] static ConnectivityResult <anonymous closure>(dynamic, String) {
    // ** addr: 0x9202d8, size: 0x170
    // 0x9202d8: EnterFrame
    //     0x9202d8: stp             fp, lr, [SP, #-0x10]!
    //     0x9202dc: mov             fp, SP
    // 0x9202e0: AllocStack(0x18)
    //     0x9202e0: sub             SP, SP, #0x18
    // 0x9202e4: CheckStackOverflow
    //     0x9202e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9202e8: cmp             SP, x16
    //     0x9202ec: b.ls            #0x920440
    // 0x9202f0: ldr             x1, [fp, #0x10]
    // 0x9202f4: r0 = trim()
    //     0x9202f4: bl              #0x808ff4  ; [dart:core] _StringBase::trim
    // 0x9202f8: stur            x0, [fp, #-8]
    // 0x9202fc: r16 = "bluetooth"
    //     0x9202fc: add             x16, PP, #0x15, lsl #12  ; [pp+0x15378] "bluetooth"
    //     0x920300: ldr             x16, [x16, #0x378]
    // 0x920304: stp             x0, x16, [SP]
    // 0x920308: r0 = ==()
    //     0x920308: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x92030c: tbnz            w0, #4, #0x920324
    // 0x920310: r0 = Instance_ConnectivityResult
    //     0x920310: add             x0, PP, #0x15, lsl #12  ; [pp+0x15380] Obj!ConnectivityResult@12c6741
    //     0x920314: ldr             x0, [x0, #0x380]
    // 0x920318: LeaveFrame
    //     0x920318: mov             SP, fp
    //     0x92031c: ldp             fp, lr, [SP], #0x10
    // 0x920320: ret
    //     0x920320: ret             
    // 0x920324: r16 = "wifi"
    //     0x920324: add             x16, PP, #0x15, lsl #12  ; [pp+0x15388] "wifi"
    //     0x920328: ldr             x16, [x16, #0x388]
    // 0x92032c: ldur            lr, [fp, #-8]
    // 0x920330: stp             lr, x16, [SP]
    // 0x920334: r0 = ==()
    //     0x920334: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x920338: tbnz            w0, #4, #0x920350
    // 0x92033c: r0 = Instance_ConnectivityResult
    //     0x92033c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15390] Obj!ConnectivityResult@12c6721
    //     0x920340: ldr             x0, [x0, #0x390]
    // 0x920344: LeaveFrame
    //     0x920344: mov             SP, fp
    //     0x920348: ldp             fp, lr, [SP], #0x10
    // 0x92034c: ret
    //     0x92034c: ret             
    // 0x920350: r16 = "ethernet"
    //     0x920350: add             x16, PP, #0x15, lsl #12  ; [pp+0x15398] "ethernet"
    //     0x920354: ldr             x16, [x16, #0x398]
    // 0x920358: ldur            lr, [fp, #-8]
    // 0x92035c: stp             lr, x16, [SP]
    // 0x920360: r0 = ==()
    //     0x920360: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x920364: tbnz            w0, #4, #0x92037c
    // 0x920368: r0 = Instance_ConnectivityResult
    //     0x920368: add             x0, PP, #0x15, lsl #12  ; [pp+0x153a0] Obj!ConnectivityResult@12c6701
    //     0x92036c: ldr             x0, [x0, #0x3a0]
    // 0x920370: LeaveFrame
    //     0x920370: mov             SP, fp
    //     0x920374: ldp             fp, lr, [SP], #0x10
    // 0x920378: ret
    //     0x920378: ret             
    // 0x92037c: r16 = "mobile"
    //     0x92037c: add             x16, PP, #0x15, lsl #12  ; [pp+0x153a8] "mobile"
    //     0x920380: ldr             x16, [x16, #0x3a8]
    // 0x920384: ldur            lr, [fp, #-8]
    // 0x920388: stp             lr, x16, [SP]
    // 0x92038c: r0 = ==()
    //     0x92038c: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x920390: tbnz            w0, #4, #0x9203a8
    // 0x920394: r0 = Instance_ConnectivityResult
    //     0x920394: add             x0, PP, #0x15, lsl #12  ; [pp+0x153b0] Obj!ConnectivityResult@12c66e1
    //     0x920398: ldr             x0, [x0, #0x3b0]
    // 0x92039c: LeaveFrame
    //     0x92039c: mov             SP, fp
    //     0x9203a0: ldp             fp, lr, [SP], #0x10
    // 0x9203a4: ret
    //     0x9203a4: ret             
    // 0x9203a8: r16 = "vpn"
    //     0x9203a8: add             x16, PP, #0x15, lsl #12  ; [pp+0x153b8] "vpn"
    //     0x9203ac: ldr             x16, [x16, #0x3b8]
    // 0x9203b0: ldur            lr, [fp, #-8]
    // 0x9203b4: stp             lr, x16, [SP]
    // 0x9203b8: r0 = ==()
    //     0x9203b8: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x9203bc: tbnz            w0, #4, #0x9203d4
    // 0x9203c0: r0 = Instance_ConnectivityResult
    //     0x9203c0: add             x0, PP, #0x15, lsl #12  ; [pp+0x153c0] Obj!ConnectivityResult@12c66c1
    //     0x9203c4: ldr             x0, [x0, #0x3c0]
    // 0x9203c8: LeaveFrame
    //     0x9203c8: mov             SP, fp
    //     0x9203cc: ldp             fp, lr, [SP], #0x10
    // 0x9203d0: ret
    //     0x9203d0: ret             
    // 0x9203d4: r16 = "satellite"
    //     0x9203d4: add             x16, PP, #0x15, lsl #12  ; [pp+0x153c8] "satellite"
    //     0x9203d8: ldr             x16, [x16, #0x3c8]
    // 0x9203dc: ldur            lr, [fp, #-8]
    // 0x9203e0: stp             lr, x16, [SP]
    // 0x9203e4: r0 = ==()
    //     0x9203e4: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x9203e8: tbnz            w0, #4, #0x920400
    // 0x9203ec: r0 = Instance_ConnectivityResult
    //     0x9203ec: add             x0, PP, #0x15, lsl #12  ; [pp+0x153d0] Obj!ConnectivityResult@12c66a1
    //     0x9203f0: ldr             x0, [x0, #0x3d0]
    // 0x9203f4: LeaveFrame
    //     0x9203f4: mov             SP, fp
    //     0x9203f8: ldp             fp, lr, [SP], #0x10
    // 0x9203fc: ret
    //     0x9203fc: ret             
    // 0x920400: r16 = "other"
    //     0x920400: add             x16, PP, #0x15, lsl #12  ; [pp+0x153d8] "other"
    //     0x920404: ldr             x16, [x16, #0x3d8]
    // 0x920408: ldur            lr, [fp, #-8]
    // 0x92040c: stp             lr, x16, [SP]
    // 0x920410: r0 = ==()
    //     0x920410: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x920414: tbnz            w0, #4, #0x92042c
    // 0x920418: r0 = Instance_ConnectivityResult
    //     0x920418: add             x0, PP, #0x15, lsl #12  ; [pp+0x153e0] Obj!ConnectivityResult@12c6681
    //     0x92041c: ldr             x0, [x0, #0x3e0]
    // 0x920420: LeaveFrame
    //     0x920420: mov             SP, fp
    //     0x920424: ldp             fp, lr, [SP], #0x10
    // 0x920428: ret
    //     0x920428: ret             
    // 0x92042c: r0 = Instance_ConnectivityResult
    //     0x92042c: add             x0, PP, #0x14, lsl #12  ; [pp+0x14fe0] Obj!ConnectivityResult@12c6761
    //     0x920430: ldr             x0, [x0, #0xfe0]
    // 0x920434: LeaveFrame
    //     0x920434: mov             SP, fp
    //     0x920438: ldp             fp, lr, [SP], #0x10
    // 0x92043c: ret
    //     0x92043c: ret             
    // 0x920440: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x920440: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x920444: b               #0x9202f0
  }
}
