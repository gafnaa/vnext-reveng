// lib: , url: package:connectivity_plus_platform_interface/src/enums.dart

// class id: 1048663, size: 0x8
class :: {
}

// class id: 8340, size: 0x14, field offset: 0x14
enum ConnectivityResult extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11a9090, size: 0x64
    // 0x11a9090: EnterFrame
    //     0x11a9090: stp             fp, lr, [SP, #-0x10]!
    //     0x11a9094: mov             fp, SP
    // 0x11a9098: AllocStack(0x10)
    //     0x11a9098: sub             SP, SP, #0x10
    // 0x11a909c: SetupParameters(ConnectivityResult this /* r1 => r0, fp-0x8 */)
    //     0x11a909c: mov             x0, x1
    //     0x11a90a0: stur            x1, [fp, #-8]
    // 0x11a90a4: CheckStackOverflow
    //     0x11a90a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a90a8: cmp             SP, x16
    //     0x11a90ac: b.ls            #0x11a90ec
    // 0x11a90b0: r1 = Null
    //     0x11a90b0: mov             x1, NULL
    // 0x11a90b4: r2 = 4
    //     0x11a90b4: mov             x2, #4
    // 0x11a90b8: r0 = AllocateArray()
    //     0x11a90b8: bl              #0x13df928  ; AllocateArrayStub
    // 0x11a90bc: r16 = "ConnectivityResult."
    //     0x11a90bc: add             x16, PP, #0x26, lsl #12  ; [pp+0x26018] "ConnectivityResult."
    //     0x11a90c0: ldr             x16, [x16, #0x18]
    // 0x11a90c4: StoreField: r0->field_f = r16
    //     0x11a90c4: stur            w16, [x0, #0xf]
    // 0x11a90c8: ldur            x1, [fp, #-8]
    // 0x11a90cc: LoadField: r2 = r1->field_f
    //     0x11a90cc: ldur            w2, [x1, #0xf]
    // 0x11a90d0: DecompressPointer r2
    //     0x11a90d0: add             x2, x2, HEAP, lsl #32
    // 0x11a90d4: StoreField: r0->field_13 = r2
    //     0x11a90d4: stur            w2, [x0, #0x13]
    // 0x11a90d8: str             x0, [SP]
    // 0x11a90dc: r0 = _interpolate()
    //     0x11a90dc: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11a90e0: LeaveFrame
    //     0x11a90e0: mov             SP, fp
    //     0x11a90e4: ldp             fp, lr, [SP], #0x10
    // 0x11a90e8: ret
    //     0x11a90e8: ret             
    // 0x11a90ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a90ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a90f0: b               #0x11a90b0
  }
}
