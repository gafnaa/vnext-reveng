// lib: , url: package:fading_edge_scrollview/src/fading_edge_scrollview.dart

// class id: 1048721, size: 0x8
class :: {
}

// class id: 5558, size: 0x1c, field offset: 0x14
class FadingEdgeScrollViewState extends _MixinApplication742&State&WidgetsBindingObserver {

  late ScrollController _controller; // offset: 0x14

  _ didChangeMetrics(/* No info */) {
    // ** addr: 0x8d0950, size: 0x30
    // 0x8d0950: EnterFrame
    //     0x8d0950: stp             fp, lr, [SP, #-0x10]!
    //     0x8d0954: mov             fp, SP
    // 0x8d0958: CheckStackOverflow
    //     0x8d0958: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d095c: cmp             SP, x16
    //     0x8d0960: b.ls            #0x8d0978
    // 0x8d0964: r0 = _updateScrollState()
    //     0x8d0964: bl              #0x8d09a4  ; [package:fading_edge_scrollview/src/fading_edge_scrollview.dart] FadingEdgeScrollViewState::_updateScrollState
    // 0x8d0968: r0 = Null
    //     0x8d0968: mov             x0, NULL
    // 0x8d096c: LeaveFrame
    //     0x8d096c: mov             SP, fp
    //     0x8d0970: ldp             fp, lr, [SP], #0x10
    // 0x8d0974: ret
    //     0x8d0974: ret             
    // 0x8d0978: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d0978: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d097c: b               #0x8d0964
  }
  _ _updateScrollState(/* No info */) {
    // ** addr: 0x8d09a4, size: 0x300
    // 0x8d09a4: EnterFrame
    //     0x8d09a4: stp             fp, lr, [SP, #-0x10]!
    //     0x8d09a8: mov             fp, SP
    // 0x8d09ac: AllocStack(0x20)
    //     0x8d09ac: sub             SP, SP, #0x20
    // 0x8d09b0: SetupParameters(FadingEdgeScrollViewState this /* r1 => r1, fp-0x8 */)
    //     0x8d09b0: stur            x1, [fp, #-8]
    // 0x8d09b4: CheckStackOverflow
    //     0x8d09b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d09b8: cmp             SP, x16
    //     0x8d09bc: b.ls            #0x8d0c84
    // 0x8d09c0: r1 = 2
    //     0x8d09c0: mov             x1, #2
    // 0x8d09c4: r0 = AllocateContext()
    //     0x8d09c4: bl              #0x13de838  ; AllocateContextStub
    // 0x8d09c8: mov             x2, x0
    // 0x8d09cc: ldur            x0, [fp, #-8]
    // 0x8d09d0: stur            x2, [fp, #-0x10]
    // 0x8d09d4: StoreField: r2->field_f = r0
    //     0x8d09d4: stur            w0, [x2, #0xf]
    // 0x8d09d8: mov             x1, x0
    // 0x8d09dc: r0 = _controllerIsReady()
    //     0x8d09dc: bl              #0x8d0d48  ; [package:fading_edge_scrollview/src/fading_edge_scrollview.dart] FadingEdgeScrollViewState::_controllerIsReady
    // 0x8d09e0: tbz             w0, #4, #0x8d09f4
    // 0x8d09e4: r0 = Null
    //     0x8d09e4: mov             x0, NULL
    // 0x8d09e8: LeaveFrame
    //     0x8d09e8: mov             SP, fp
    //     0x8d09ec: ldp             fp, lr, [SP], #0x10
    // 0x8d09f0: ret
    //     0x8d09f0: ret             
    // 0x8d09f4: ldur            x0, [fp, #-8]
    // 0x8d09f8: LoadField: r1 = r0->field_13
    //     0x8d09f8: ldur            w1, [x0, #0x13]
    // 0x8d09fc: DecompressPointer r1
    //     0x8d09fc: add             x1, x1, HEAP, lsl #32
    // 0x8d0a00: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8d0a04: cmp             w1, w16
    // 0x8d0a08: b.eq            #0x8d0c8c
    // 0x8d0a0c: LoadField: r2 = r1->field_3b
    //     0x8d0a0c: ldur            w2, [x1, #0x3b]
    // 0x8d0a10: DecompressPointer r2
    //     0x8d0a10: add             x2, x2, HEAP, lsl #32
    // 0x8d0a14: mov             x1, x2
    // 0x8d0a18: r0 = last()
    //     0x8d0a18: bl              #0xb22764  ; [dart:core] _GrowableList::last
    // 0x8d0a1c: LoadField: r2 = r0->field_3f
    //     0x8d0a1c: ldur            w2, [x0, #0x3f]
    // 0x8d0a20: DecompressPointer r2
    //     0x8d0a20: add             x2, x2, HEAP, lsl #32
    // 0x8d0a24: stur            x2, [fp, #-0x18]
    // 0x8d0a28: cmp             w2, NULL
    // 0x8d0a2c: b.eq            #0x8d0c98
    // 0x8d0a30: ldur            x0, [fp, #-8]
    // 0x8d0a34: LoadField: r1 = r0->field_13
    //     0x8d0a34: ldur            w1, [x0, #0x13]
    // 0x8d0a38: DecompressPointer r1
    //     0x8d0a38: add             x1, x1, HEAP, lsl #32
    // 0x8d0a3c: LoadField: r3 = r1->field_3b
    //     0x8d0a3c: ldur            w3, [x1, #0x3b]
    // 0x8d0a40: DecompressPointer r3
    //     0x8d0a40: add             x3, x3, HEAP, lsl #32
    // 0x8d0a44: mov             x1, x3
    // 0x8d0a48: r0 = last()
    //     0x8d0a48: bl              #0xb22764  ; [dart:core] _GrowableList::last
    // 0x8d0a4c: LoadField: r2 = r0->field_2f
    //     0x8d0a4c: ldur            w2, [x0, #0x2f]
    // 0x8d0a50: DecompressPointer r2
    //     0x8d0a50: add             x2, x2, HEAP, lsl #32
    // 0x8d0a54: stur            x2, [fp, #-0x20]
    // 0x8d0a58: cmp             w2, NULL
    // 0x8d0a5c: b.eq            #0x8d0c9c
    // 0x8d0a60: ldur            x0, [fp, #-8]
    // 0x8d0a64: LoadField: r1 = r0->field_13
    //     0x8d0a64: ldur            w1, [x0, #0x13]
    // 0x8d0a68: DecompressPointer r1
    //     0x8d0a68: add             x1, x1, HEAP, lsl #32
    // 0x8d0a6c: LoadField: r3 = r1->field_3b
    //     0x8d0a6c: ldur            w3, [x1, #0x3b]
    // 0x8d0a70: DecompressPointer r3
    //     0x8d0a70: add             x3, x3, HEAP, lsl #32
    // 0x8d0a74: mov             x1, x3
    // 0x8d0a78: r0 = last()
    //     0x8d0a78: bl              #0xb22764  ; [dart:core] _GrowableList::last
    // 0x8d0a7c: LoadField: r1 = r0->field_33
    //     0x8d0a7c: ldur            w1, [x0, #0x33]
    // 0x8d0a80: DecompressPointer r1
    //     0x8d0a80: add             x1, x1, HEAP, lsl #32
    // 0x8d0a84: cmp             w1, NULL
    // 0x8d0a88: b.eq            #0x8d0ca0
    // 0x8d0a8c: ldur            x0, [fp, #-0x18]
    // 0x8d0a90: LoadField: d0 = r0->field_7
    //     0x8d0a90: ldur            d0, [x0, #7]
    // 0x8d0a94: LoadField: d1 = r1->field_7
    //     0x8d0a94: ldur            d1, [x1, #7]
    // 0x8d0a98: fcmp            d0, d1
    // 0x8d0a9c: r16 = true
    //     0x8d0a9c: add             x16, NULL, #0x20  ; true
    // 0x8d0aa0: r17 = false
    //     0x8d0aa0: add             x17, NULL, #0x30  ; false
    // 0x8d0aa4: csel            x0, x16, x17, ge
    // 0x8d0aa8: ldur            x1, [fp, #-0x20]
    // 0x8d0aac: LoadField: d1 = r1->field_7
    //     0x8d0aac: ldur            d1, [x1, #7]
    // 0x8d0ab0: fcmp            d1, d0
    // 0x8d0ab4: r16 = true
    //     0x8d0ab4: add             x16, NULL, #0x20  ; true
    // 0x8d0ab8: r17 = false
    //     0x8d0ab8: add             x17, NULL, #0x30  ; false
    // 0x8d0abc: csel            x1, x16, x17, ge
    // 0x8d0ac0: tbnz            w1, #4, #0x8d0ae8
    // 0x8d0ac4: tbnz            w0, #4, #0x8d0ad4
    // 0x8d0ac8: r1 = Instance__ScrollState
    //     0x8d0ac8: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa1b78] Obj!_ScrollState@12c6381
    //     0x8d0acc: ldr             x1, [x1, #0xb78]
    // 0x8d0ad0: b               #0x8d0c04
    // 0x8d0ad4: mov             x5, x0
    // 0x8d0ad8: mov             x3, x0
    // 0x8d0adc: r4 = true
    //     0x8d0adc: add             x4, NULL, #0x20  ; true
    // 0x8d0ae0: r2 = true
    //     0x8d0ae0: add             x2, NULL, #0x20  ; true
    // 0x8d0ae4: b               #0x8d0af8
    // 0x8d0ae8: r5 = Null
    //     0x8d0ae8: mov             x5, NULL
    // 0x8d0aec: r4 = false
    //     0x8d0aec: add             x4, NULL, #0x30  ; false
    // 0x8d0af0: r3 = Null
    //     0x8d0af0: mov             x3, NULL
    // 0x8d0af4: r2 = false
    //     0x8d0af4: add             x2, NULL, #0x30  ; false
    // 0x8d0af8: tbnz            w1, #4, #0x8d0b48
    // 0x8d0afc: tbnz            w2, #4, #0x8d0b08
    // 0x8d0b00: mov             x2, x3
    // 0x8d0b04: b               #0x8d0b10
    // 0x8d0b08: mov             x3, x0
    // 0x8d0b0c: mov             x2, x0
    // 0x8d0b10: r16 = false
    //     0x8d0b10: add             x16, NULL, #0x30  ; false
    // 0x8d0b14: cmp             w3, w16
    // 0x8d0b18: r16 = true
    //     0x8d0b18: add             x16, NULL, #0x20  ; true
    // 0x8d0b1c: r17 = false
    //     0x8d0b1c: add             x17, NULL, #0x30  ; false
    // 0x8d0b20: csel            x6, x16, x17, eq
    // 0x8d0b24: tbnz            w6, #4, #0x8d0b34
    // 0x8d0b28: r1 = Instance__ScrollState
    //     0x8d0b28: add             x1, PP, #0xac, lsl #12  ; [pp+0xac340] Obj!_ScrollState@12c6361
    //     0x8d0b2c: ldr             x1, [x1, #0x340]
    // 0x8d0b30: b               #0x8d0c04
    // 0x8d0b34: mov             x7, x2
    // 0x8d0b38: mov             x3, x6
    // 0x8d0b3c: r6 = true
    //     0x8d0b3c: add             x6, NULL, #0x20  ; true
    // 0x8d0b40: r2 = true
    //     0x8d0b40: add             x2, NULL, #0x20  ; true
    // 0x8d0b44: b               #0x8d0b58
    // 0x8d0b48: mov             x7, x3
    // 0x8d0b4c: mov             x6, x2
    // 0x8d0b50: r3 = Null
    //     0x8d0b50: mov             x3, NULL
    // 0x8d0b54: r2 = false
    //     0x8d0b54: add             x2, NULL, #0x30  ; false
    // 0x8d0b58: tbnz            w1, #4, #0x8d0b64
    // 0x8d0b5c: r8 = false
    //     0x8d0b5c: add             x8, NULL, #0x30  ; false
    // 0x8d0b60: b               #0x8d0b68
    // 0x8d0b64: r8 = true
    //     0x8d0b64: add             x8, NULL, #0x20  ; true
    // 0x8d0b68: tbnz            w8, #4, #0x8d0bc8
    // 0x8d0b6c: tbnz            w4, #4, #0x8d0b7c
    // 0x8d0b70: mov             x4, x7
    // 0x8d0b74: mov             x1, x6
    // 0x8d0b78: b               #0x8d0bb0
    // 0x8d0b7c: tbnz            w6, #4, #0x8d0b8c
    // 0x8d0b80: mov             x4, x7
    // 0x8d0b84: mov             x1, x7
    // 0x8d0b88: b               #0x8d0b94
    // 0x8d0b8c: mov             x4, x0
    // 0x8d0b90: mov             x1, x0
    // 0x8d0b94: r16 = true
    //     0x8d0b94: add             x16, NULL, #0x20  ; true
    // 0x8d0b98: cmp             w4, w16
    // 0x8d0b9c: r16 = true
    //     0x8d0b9c: add             x16, NULL, #0x20  ; true
    // 0x8d0ba0: r17 = false
    //     0x8d0ba0: add             x17, NULL, #0x30  ; false
    // 0x8d0ba4: csel            x5, x16, x17, eq
    // 0x8d0ba8: mov             x4, x1
    // 0x8d0bac: r1 = true
    //     0x8d0bac: add             x1, NULL, #0x20  ; true
    // 0x8d0bb0: r16 = true
    //     0x8d0bb0: add             x16, NULL, #0x20  ; true
    // 0x8d0bb4: cmp             w5, w16
    // 0x8d0bb8: b.ne            #0x8d0bd0
    // 0x8d0bbc: r1 = Instance__ScrollState
    //     0x8d0bbc: add             x1, PP, #0xac, lsl #12  ; [pp+0xac330] Obj!_ScrollState@12c6341
    //     0x8d0bc0: ldr             x1, [x1, #0x330]
    // 0x8d0bc4: b               #0x8d0c04
    // 0x8d0bc8: mov             x4, x7
    // 0x8d0bcc: mov             x1, x6
    // 0x8d0bd0: tbnz            w8, #4, #0x8d0c64
    // 0x8d0bd4: tbnz            w2, #4, #0x8d0be8
    // 0x8d0bd8: r16 = true
    //     0x8d0bd8: add             x16, NULL, #0x20  ; true
    // 0x8d0bdc: cmp             w3, w16
    // 0x8d0be0: b.ne            #0x8d0c64
    // 0x8d0be4: b               #0x8d0bfc
    // 0x8d0be8: tbnz            w1, #4, #0x8d0bf0
    // 0x8d0bec: mov             x0, x4
    // 0x8d0bf0: r16 = false
    //     0x8d0bf0: add             x16, NULL, #0x30  ; false
    // 0x8d0bf4: cmp             w0, w16
    // 0x8d0bf8: b.ne            #0x8d0c64
    // 0x8d0bfc: r1 = Instance__ScrollState
    //     0x8d0bfc: add             x1, PP, #0xac, lsl #12  ; [pp+0xac338] Obj!_ScrollState@12c6321
    //     0x8d0c00: ldr             x1, [x1, #0x338]
    // 0x8d0c04: ldur            x3, [fp, #-8]
    // 0x8d0c08: ldur            x2, [fp, #-0x10]
    // 0x8d0c0c: mov             x0, x1
    // 0x8d0c10: StoreField: r2->field_13 = r0
    //     0x8d0c10: stur            w0, [x2, #0x13]
    //     0x8d0c14: ldurb           w16, [x2, #-1]
    //     0x8d0c18: ldurb           w17, [x0, #-1]
    //     0x8d0c1c: and             x16, x17, x16, lsr #2
    //     0x8d0c20: tst             x16, HEAP, lsr #32
    //     0x8d0c24: b.eq            #0x8d0c2c
    //     0x8d0c28: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x8d0c2c: ArrayLoad: r0 = r3[0]  ; List_4
    //     0x8d0c2c: ldur            w0, [x3, #0x17]
    // 0x8d0c30: DecompressPointer r0
    //     0x8d0c30: add             x0, x0, HEAP, lsl #32
    // 0x8d0c34: cmp             w0, w1
    // 0x8d0c38: b.eq            #0x8d0c54
    // 0x8d0c3c: r1 = Function '<anonymous closure>':.
    //     0x8d0c3c: add             x1, PP, #0xac, lsl #12  ; [pp+0xac348] AnonymousClosure: (0x8cf890), in [package:flutter/src/widgets/media_query.dart] _MediaQueryFromViewState::_updateData (0x8ce204)
    //     0x8d0c40: ldr             x1, [x1, #0x348]
    // 0x8d0c44: r0 = AllocateClosure()
    //     0x8d0c44: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8d0c48: ldur            x1, [fp, #-8]
    // 0x8d0c4c: mov             x2, x0
    // 0x8d0c50: r0 = setState()
    //     0x8d0c50: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8d0c54: r0 = Null
    //     0x8d0c54: mov             x0, NULL
    // 0x8d0c58: LeaveFrame
    //     0x8d0c58: mov             SP, fp
    //     0x8d0c5c: ldp             fp, lr, [SP], #0x10
    // 0x8d0c60: ret
    //     0x8d0c60: ret             
    // 0x8d0c64: r0 = ReachabilityError()
    //     0x8d0c64: bl              #0x8d0cdc  ; AllocateReachabilityErrorStub -> ReachabilityError (size=0x10)
    // 0x8d0c68: mov             x1, x0
    // 0x8d0c6c: r0 = "None of the patterns in the switch expression the matched input value. See https://github.com/dart-lang/language/issues/3488 for details."
    //     0x8d0c6c: add             x0, PP, #0xac, lsl #12  ; [pp+0xac350] "None of the patterns in the switch expression the matched input value. See https://github.com/dart-lang/language/issues/3488 for details."
    //     0x8d0c70: ldr             x0, [x0, #0x350]
    // 0x8d0c74: StoreField: r1->field_b = r0
    //     0x8d0c74: stur            w0, [x1, #0xb]
    // 0x8d0c78: mov             x0, x1
    // 0x8d0c7c: r0 = Throw()
    //     0x8d0c7c: bl              #0x13ddb2c  ; ThrowStub
    // 0x8d0c80: brk             #0
    // 0x8d0c84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d0c84: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d0c88: b               #0x8d09c0
    // 0x8d0c8c: r9 = _controller
    //     0x8d0c8c: add             x9, PP, #0xac, lsl #12  ; [pp+0xac358] Field <FadingEdgeScrollViewState._controller@464074463>: late (offset: 0x14)
    //     0x8d0c90: ldr             x9, [x9, #0x358]
    // 0x8d0c94: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d0c94: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d0c98: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8d0c98: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8d0c9c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8d0c9c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8d0ca0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8d0ca0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _updateScrollState(dynamic) {
    // ** addr: 0x8d0ca4, size: 0x38
    // 0x8d0ca4: EnterFrame
    //     0x8d0ca4: stp             fp, lr, [SP, #-0x10]!
    //     0x8d0ca8: mov             fp, SP
    // 0x8d0cac: ldr             x0, [fp, #0x10]
    // 0x8d0cb0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8d0cb0: ldur            w1, [x0, #0x17]
    // 0x8d0cb4: DecompressPointer r1
    //     0x8d0cb4: add             x1, x1, HEAP, lsl #32
    // 0x8d0cb8: CheckStackOverflow
    //     0x8d0cb8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d0cbc: cmp             SP, x16
    //     0x8d0cc0: b.ls            #0x8d0cd4
    // 0x8d0cc4: r0 = _updateScrollState()
    //     0x8d0cc4: bl              #0x8d09a4  ; [package:fading_edge_scrollview/src/fading_edge_scrollview.dart] FadingEdgeScrollViewState::_updateScrollState
    // 0x8d0cc8: LeaveFrame
    //     0x8d0cc8: mov             SP, fp
    //     0x8d0ccc: ldp             fp, lr, [SP], #0x10
    // 0x8d0cd0: ret
    //     0x8d0cd0: ret             
    // 0x8d0cd4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d0cd4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d0cd8: b               #0x8d0cc4
  }
  get _ _controllerIsReady(/* No info */) {
    // ** addr: 0x8d0d48, size: 0x9c
    // 0x8d0d48: EnterFrame
    //     0x8d0d48: stp             fp, lr, [SP, #-0x10]!
    //     0x8d0d4c: mov             fp, SP
    // 0x8d0d50: CheckStackOverflow
    //     0x8d0d50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d0d54: cmp             SP, x16
    //     0x8d0d58: b.ls            #0x8d0dd0
    // 0x8d0d5c: LoadField: r0 = r1->field_13
    //     0x8d0d5c: ldur            w0, [x1, #0x13]
    // 0x8d0d60: DecompressPointer r0
    //     0x8d0d60: add             x0, x0, HEAP, lsl #32
    // 0x8d0d64: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8d0d68: cmp             w0, w16
    // 0x8d0d6c: b.eq            #0x8d0dd8
    // 0x8d0d70: LoadField: r1 = r0->field_3b
    //     0x8d0d70: ldur            w1, [x0, #0x3b]
    // 0x8d0d74: DecompressPointer r1
    //     0x8d0d74: add             x1, x1, HEAP, lsl #32
    // 0x8d0d78: LoadField: r0 = r1->field_b
    //     0x8d0d78: ldur            w0, [x1, #0xb]
    // 0x8d0d7c: cbz             w0, #0x8d0dc0
    // 0x8d0d80: r0 = last()
    //     0x8d0d80: bl              #0xb22764  ; [dart:core] _GrowableList::last
    // 0x8d0d84: LoadField: r1 = r0->field_2f
    //     0x8d0d84: ldur            w1, [x0, #0x2f]
    // 0x8d0d88: DecompressPointer r1
    //     0x8d0d88: add             x1, x1, HEAP, lsl #32
    // 0x8d0d8c: cmp             w1, NULL
    // 0x8d0d90: b.eq            #0x8d0db4
    // 0x8d0d94: LoadField: r1 = r0->field_33
    //     0x8d0d94: ldur            w1, [x0, #0x33]
    // 0x8d0d98: DecompressPointer r1
    //     0x8d0d98: add             x1, x1, HEAP, lsl #32
    // 0x8d0d9c: cmp             w1, NULL
    // 0x8d0da0: r16 = true
    //     0x8d0da0: add             x16, NULL, #0x20  ; true
    // 0x8d0da4: r17 = false
    //     0x8d0da4: add             x17, NULL, #0x30  ; false
    // 0x8d0da8: csel            x2, x16, x17, ne
    // 0x8d0dac: mov             x1, x2
    // 0x8d0db0: b               #0x8d0db8
    // 0x8d0db4: r1 = false
    //     0x8d0db4: add             x1, NULL, #0x30  ; false
    // 0x8d0db8: mov             x0, x1
    // 0x8d0dbc: b               #0x8d0dc4
    // 0x8d0dc0: r0 = false
    //     0x8d0dc0: add             x0, NULL, #0x30  ; false
    // 0x8d0dc4: LeaveFrame
    //     0x8d0dc4: mov             SP, fp
    //     0x8d0dc8: ldp             fp, lr, [SP], #0x10
    // 0x8d0dcc: ret
    //     0x8d0dcc: ret             
    // 0x8d0dd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d0dd0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d0dd4: b               #0x8d0d5c
    // 0x8d0dd8: r9 = _controller
    //     0x8d0dd8: add             x9, PP, #0xac, lsl #12  ; [pp+0xac358] Field <FadingEdgeScrollViewState._controller@464074463>: late (offset: 0x14)
    //     0x8d0ddc: ldr             x9, [x9, #0x358]
    // 0x8d0de0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d0de0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ build(/* No info */) {
    // ** addr: 0xdd9c20, size: 0xcc
    // 0xdd9c20: EnterFrame
    //     0xdd9c20: stp             fp, lr, [SP, #-0x10]!
    //     0xdd9c24: mov             fp, SP
    // 0xdd9c28: AllocStack(0x20)
    //     0xdd9c28: sub             SP, SP, #0x20
    // 0xdd9c2c: SetupParameters(FadingEdgeScrollViewState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xdd9c2c: stur            x1, [fp, #-8]
    //     0xdd9c30: stur            x2, [fp, #-0x10]
    // 0xdd9c34: r1 = 2
    //     0xdd9c34: mov             x1, #2
    // 0xdd9c38: r0 = AllocateContext()
    //     0xdd9c38: bl              #0x13de838  ; AllocateContextStub
    // 0xdd9c3c: mov             x3, x0
    // 0xdd9c40: ldur            x0, [fp, #-8]
    // 0xdd9c44: stur            x3, [fp, #-0x18]
    // 0xdd9c48: StoreField: r3->field_f = r0
    //     0xdd9c48: stur            w0, [x3, #0xf]
    // 0xdd9c4c: ldur            x1, [fp, #-0x10]
    // 0xdd9c50: StoreField: r3->field_13 = r1
    //     0xdd9c50: stur            w1, [x3, #0x13]
    // 0xdd9c54: LoadField: r1 = r0->field_b
    //     0xdd9c54: ldur            w1, [x0, #0xb]
    // 0xdd9c58: DecompressPointer r1
    //     0xdd9c58: add             x1, x1, HEAP, lsl #32
    // 0xdd9c5c: cmp             w1, NULL
    // 0xdd9c60: b.eq            #0xdd9ce8
    // 0xdd9c64: LoadField: r0 = r1->field_b
    //     0xdd9c64: ldur            w0, [x1, #0xb]
    // 0xdd9c68: DecompressPointer r0
    //     0xdd9c68: add             x0, x0, HEAP, lsl #32
    // 0xdd9c6c: mov             x2, x3
    // 0xdd9c70: stur            x0, [fp, #-8]
    // 0xdd9c74: r1 = Function '<anonymous closure>':.
    //     0xdd9c74: add             x1, PP, #0xac, lsl #12  ; [pp+0xac320] AnonymousClosure: (0xdda1ac), in [package:fading_edge_scrollview/src/fading_edge_scrollview.dart] FadingEdgeScrollViewState::build (0xdd9c20)
    //     0xdd9c78: ldr             x1, [x1, #0x320]
    // 0xdd9c7c: r0 = AllocateClosure()
    //     0xdd9c7c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd9c80: r1 = <ScrollMetricsNotification>
    //     0xdd9c80: add             x1, PP, #0x97, lsl #12  ; [pp+0x970f8] TypeArguments: <ScrollMetricsNotification>
    //     0xdd9c84: ldr             x1, [x1, #0xf8]
    // 0xdd9c88: stur            x0, [fp, #-0x10]
    // 0xdd9c8c: r0 = NotificationListener()
    //     0xdd9c8c: bl              #0xd2ea9c  ; AllocateNotificationListenerStub -> NotificationListener<X0 bound Notification> (size=0x18)
    // 0xdd9c90: mov             x3, x0
    // 0xdd9c94: ldur            x0, [fp, #-0x10]
    // 0xdd9c98: stur            x3, [fp, #-0x20]
    // 0xdd9c9c: StoreField: r3->field_13 = r0
    //     0xdd9c9c: stur            w0, [x3, #0x13]
    // 0xdd9ca0: ldur            x0, [fp, #-8]
    // 0xdd9ca4: StoreField: r3->field_b = r0
    //     0xdd9ca4: stur            w0, [x3, #0xb]
    // 0xdd9ca8: ldur            x2, [fp, #-0x18]
    // 0xdd9cac: r1 = Function '<anonymous closure>':.
    //     0xdd9cac: add             x1, PP, #0xac, lsl #12  ; [pp+0xac328] AnonymousClosure: (0xdd9cec), in [package:fading_edge_scrollview/src/fading_edge_scrollview.dart] FadingEdgeScrollViewState::build (0xdd9c20)
    //     0xdd9cb0: ldr             x1, [x1, #0x328]
    // 0xdd9cb4: r0 = AllocateClosure()
    //     0xdd9cb4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd9cb8: stur            x0, [fp, #-8]
    // 0xdd9cbc: r0 = ShaderMask()
    //     0xdd9cbc: bl              #0xdcbaf0  ; AllocateShaderMaskStub -> ShaderMask (size=0x18)
    // 0xdd9cc0: ldur            x1, [fp, #-8]
    // 0xdd9cc4: StoreField: r0->field_f = r1
    //     0xdd9cc4: stur            w1, [x0, #0xf]
    // 0xdd9cc8: r1 = Instance_BlendMode
    //     0xdd9cc8: add             x1, PP, #0x93, lsl #12  ; [pp+0x93a28] Obj!BlendMode@12c8341
    //     0xdd9ccc: ldr             x1, [x1, #0xa28]
    // 0xdd9cd0: StoreField: r0->field_13 = r1
    //     0xdd9cd0: stur            w1, [x0, #0x13]
    // 0xdd9cd4: ldur            x1, [fp, #-0x20]
    // 0xdd9cd8: StoreField: r0->field_b = r1
    //     0xdd9cd8: stur            w1, [x0, #0xb]
    // 0xdd9cdc: LeaveFrame
    //     0xdd9cdc: mov             SP, fp
    //     0xdd9ce0: ldp             fp, lr, [SP], #0x10
    // 0xdd9ce4: ret
    //     0xdd9ce4: ret             
    // 0xdd9ce8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd9ce8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Shader <anonymous closure>(dynamic, Rect) {
    // ** addr: 0xdd9cec, size: 0xb8
    // 0xdd9cec: EnterFrame
    //     0xdd9cec: stp             fp, lr, [SP, #-0x10]!
    //     0xdd9cf0: mov             fp, SP
    // 0xdd9cf4: AllocStack(0x30)
    //     0xdd9cf4: sub             SP, SP, #0x30
    // 0xdd9cf8: SetupParameters([dynamic _ /* r0 */])
    //     0xdd9cf8: ldr             x0, [fp, #0x18]
    //     0xdd9cfc: ldur            w2, [x0, #0x17]
    //     0xdd9d00: add             x2, x2, HEAP, lsl #32
    //     0xdd9d04: stur            x2, [fp, #-8]
    // 0xdd9d08: CheckStackOverflow
    //     0xdd9d08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd9d0c: cmp             SP, x16
    //     0xdd9d10: b.ls            #0xdd9d9c
    // 0xdd9d14: LoadField: r1 = r2->field_f
    //     0xdd9d14: ldur            w1, [x2, #0xf]
    // 0xdd9d18: DecompressPointer r1
    //     0xdd9d18: add             x1, x1, HEAP, lsl #32
    // 0xdd9d1c: r0 = _createShaderGradient()
    //     0xdd9d1c: bl              #0xdd9da4  ; [package:fading_edge_scrollview/src/fading_edge_scrollview.dart] FadingEdgeScrollViewState::_createShaderGradient
    // 0xdd9d20: ldr             x1, [fp, #0x10]
    // 0xdd9d24: stur            x0, [fp, #-0x10]
    // 0xdd9d28: LoadField: d0 = r1->field_7
    //     0xdd9d28: ldur            d0, [x1, #7]
    // 0xdd9d2c: fneg            d1, d0
    // 0xdd9d30: stur            d1, [fp, #-0x28]
    // 0xdd9d34: LoadField: d0 = r1->field_f
    //     0xdd9d34: ldur            d0, [x1, #0xf]
    // 0xdd9d38: fneg            d2, d0
    // 0xdd9d3c: stur            d2, [fp, #-0x20]
    // 0xdd9d40: r0 = Offset()
    //     0xdd9d40: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xdd9d44: ldur            d0, [fp, #-0x28]
    // 0xdd9d48: StoreField: r0->field_7 = d0
    //     0xdd9d48: stur            d0, [x0, #7]
    // 0xdd9d4c: ldur            d0, [fp, #-0x20]
    // 0xdd9d50: StoreField: r0->field_f = d0
    //     0xdd9d50: stur            d0, [x0, #0xf]
    // 0xdd9d54: ldr             x1, [fp, #0x10]
    // 0xdd9d58: mov             x2, x0
    // 0xdd9d5c: r0 = shift()
    //     0xdd9d5c: bl              #0x8610a4  ; [dart:ui] Rect::shift
    // 0xdd9d60: mov             x2, x0
    // 0xdd9d64: ldur            x0, [fp, #-8]
    // 0xdd9d68: stur            x2, [fp, #-0x18]
    // 0xdd9d6c: LoadField: r1 = r0->field_13
    //     0xdd9d6c: ldur            w1, [x0, #0x13]
    // 0xdd9d70: DecompressPointer r1
    //     0xdd9d70: add             x1, x1, HEAP, lsl #32
    // 0xdd9d74: r0 = of()
    //     0xdd9d74: bl              #0x87371c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0xdd9d78: str             x0, [SP]
    // 0xdd9d7c: ldur            x1, [fp, #-0x10]
    // 0xdd9d80: ldur            x2, [fp, #-0x18]
    // 0xdd9d84: r4 = const [0, 0x3, 0x1, 0x2, textDirection, 0x2, null]
    //     0xdd9d84: add             x4, PP, #0x97, lsl #12  ; [pp+0x97638] List(7) [0, 0x3, 0x1, 0x2, "textDirection", 0x2, Null]
    //     0xdd9d88: ldr             x4, [x4, #0x638]
    // 0xdd9d8c: r0 = createShader()
    //     0xdd9d8c: bl              #0x1305638  ; [package:flutter/src/painting/gradient.dart] LinearGradient::createShader
    // 0xdd9d90: LeaveFrame
    //     0xdd9d90: mov             SP, fp
    //     0xdd9d94: ldp             fp, lr, [SP], #0x10
    // 0xdd9d98: ret
    //     0xdd9d98: ret             
    // 0xdd9d9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd9d9c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd9da0: b               #0xdd9d14
  }
  _ _createShaderGradient(/* No info */) {
    // ** addr: 0xdd9da4, size: 0x1a4
    // 0xdd9da4: EnterFrame
    //     0xdd9da4: stp             fp, lr, [SP, #-0x10]!
    //     0xdd9da8: mov             fp, SP
    // 0xdd9dac: AllocStack(0x28)
    //     0xdd9dac: sub             SP, SP, #0x28
    // 0xdd9db0: SetupParameters(FadingEdgeScrollViewState this /* r1 => r0, fp-0x8 */)
    //     0xdd9db0: mov             x0, x1
    //     0xdd9db4: stur            x1, [fp, #-8]
    // 0xdd9db8: CheckStackOverflow
    //     0xdd9db8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd9dbc: cmp             SP, x16
    //     0xdd9dc0: b.ls            #0xdd9f3c
    // 0xdd9dc4: mov             x1, x0
    // 0xdd9dc8: r0 = _gradientStart()
    //     0xdd9dc8: bl              #0xdda0d0  ; [package:fading_edge_scrollview/src/fading_edge_scrollview.dart] FadingEdgeScrollViewState::_gradientStart
    // 0xdd9dcc: ldur            x1, [fp, #-8]
    // 0xdd9dd0: stur            x0, [fp, #-0x10]
    // 0xdd9dd4: r0 = _gradientEnd()
    //     0xdd9dd4: bl              #0xdd9ff4  ; [package:fading_edge_scrollview/src/fading_edge_scrollview.dart] FadingEdgeScrollViewState::_gradientEnd
    // 0xdd9dd8: mov             x3, x0
    // 0xdd9ddc: ldur            x0, [fp, #-8]
    // 0xdd9de0: stur            x3, [fp, #-0x18]
    // 0xdd9de4: LoadField: r1 = r0->field_b
    //     0xdd9de4: ldur            w1, [x0, #0xb]
    // 0xdd9de8: DecompressPointer r1
    //     0xdd9de8: add             x1, x1, HEAP, lsl #32
    // 0xdd9dec: cmp             w1, NULL
    // 0xdd9df0: b.eq            #0xdd9f44
    // 0xdd9df4: r1 = Null
    //     0xdd9df4: mov             x1, NULL
    // 0xdd9df8: r2 = 8
    //     0xdd9df8: mov             x2, #8
    // 0xdd9dfc: r0 = AllocateArray()
    //     0xdd9dfc: bl              #0x13df928  ; AllocateArrayStub
    // 0xdd9e00: stur            x0, [fp, #-0x20]
    // 0xdd9e04: r16 = 0.000000
    //     0xdd9e04: ldr             x16, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xdd9e08: StoreField: r0->field_f = r16
    //     0xdd9e08: stur            w16, [x0, #0xf]
    // 0xdd9e0c: r16 = 0.000000
    //     0xdd9e0c: ldr             x16, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xdd9e10: StoreField: r0->field_13 = r16
    //     0xdd9e10: stur            w16, [x0, #0x13]
    // 0xdd9e14: r16 = 1.000000
    //     0xdd9e14: ldr             x16, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xdd9e18: ArrayStore: r0[0] = r16  ; List_4
    //     0xdd9e18: stur            w16, [x0, #0x17]
    // 0xdd9e1c: r16 = 1.000000
    //     0xdd9e1c: ldr             x16, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xdd9e20: StoreField: r0->field_1b = r16
    //     0xdd9e20: stur            w16, [x0, #0x1b]
    // 0xdd9e24: r1 = <double>
    //     0xdd9e24: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xdd9e28: r0 = AllocateGrowableArray()
    //     0xdd9e28: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xdd9e2c: mov             x4, x0
    // 0xdd9e30: ldur            x0, [fp, #-0x20]
    // 0xdd9e34: stur            x4, [fp, #-0x28]
    // 0xdd9e38: StoreField: r4->field_f = r0
    //     0xdd9e38: stur            w0, [x4, #0xf]
    // 0xdd9e3c: r0 = 8
    //     0xdd9e3c: mov             x0, #8
    // 0xdd9e40: StoreField: r4->field_b = r0
    //     0xdd9e40: stur            w0, [x4, #0xb]
    // 0xdd9e44: d0 = 0.000000
    //     0xdd9e44: eor             v0.16b, v0.16b, v0.16b
    // 0xdd9e48: fcmp            d0, d0
    // 0xdd9e4c: b.le            #0xdd9e98
    // 0xdd9e50: ldur            x1, [fp, #-8]
    // 0xdd9e54: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xdd9e54: ldur            w0, [x1, #0x17]
    // 0xdd9e58: DecompressPointer r0
    //     0xdd9e58: add             x0, x0, HEAP, lsl #32
    // 0xdd9e5c: r16 = Instance__ScrollState
    //     0xdd9e5c: add             x16, PP, #0xac, lsl #12  ; [pp+0xac330] Obj!_ScrollState@12c6341
    //     0xdd9e60: ldr             x16, [x16, #0x330]
    // 0xdd9e64: cmp             w0, w16
    // 0xdd9e68: b.ne            #0xdd9e74
    // 0xdd9e6c: r0 = true
    //     0xdd9e6c: add             x0, NULL, #0x20  ; true
    // 0xdd9e70: b               #0xdd9e90
    // 0xdd9e74: r16 = Instance__ScrollState
    //     0xdd9e74: add             x16, PP, #0xac, lsl #12  ; [pp+0xac338] Obj!_ScrollState@12c6321
    //     0xdd9e78: ldr             x16, [x16, #0x338]
    // 0xdd9e7c: cmp             w0, w16
    // 0xdd9e80: r16 = true
    //     0xdd9e80: add             x16, NULL, #0x20  ; true
    // 0xdd9e84: r17 = false
    //     0xdd9e84: add             x17, NULL, #0x30  ; false
    // 0xdd9e88: csel            x2, x16, x17, eq
    // 0xdd9e8c: mov             x0, x2
    // 0xdd9e90: mov             x2, x0
    // 0xdd9e94: b               #0xdd9ea0
    // 0xdd9e98: ldur            x1, [fp, #-8]
    // 0xdd9e9c: r2 = false
    //     0xdd9e9c: add             x2, NULL, #0x30  ; false
    // 0xdd9ea0: fcmp            d0, d0
    // 0xdd9ea4: b.le            #0xdd9eec
    // 0xdd9ea8: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xdd9ea8: ldur            w0, [x1, #0x17]
    // 0xdd9eac: DecompressPointer r0
    //     0xdd9eac: add             x0, x0, HEAP, lsl #32
    // 0xdd9eb0: r16 = Instance__ScrollState
    //     0xdd9eb0: add             x16, PP, #0xac, lsl #12  ; [pp+0xac340] Obj!_ScrollState@12c6361
    //     0xdd9eb4: ldr             x16, [x16, #0x340]
    // 0xdd9eb8: cmp             w0, w16
    // 0xdd9ebc: b.ne            #0xdd9ec8
    // 0xdd9ec0: r0 = true
    //     0xdd9ec0: add             x0, NULL, #0x20  ; true
    // 0xdd9ec4: b               #0xdd9ee4
    // 0xdd9ec8: r16 = Instance__ScrollState
    //     0xdd9ec8: add             x16, PP, #0xac, lsl #12  ; [pp+0xac338] Obj!_ScrollState@12c6321
    //     0xdd9ecc: ldr             x16, [x16, #0x338]
    // 0xdd9ed0: cmp             w0, w16
    // 0xdd9ed4: r16 = true
    //     0xdd9ed4: add             x16, NULL, #0x20  ; true
    // 0xdd9ed8: r17 = false
    //     0xdd9ed8: add             x17, NULL, #0x30  ; false
    // 0xdd9edc: csel            x3, x16, x17, eq
    // 0xdd9ee0: mov             x0, x3
    // 0xdd9ee4: mov             x3, x0
    // 0xdd9ee8: b               #0xdd9ef0
    // 0xdd9eec: r3 = false
    //     0xdd9eec: add             x3, NULL, #0x30  ; false
    // 0xdd9ef0: ldur            x5, [fp, #-0x10]
    // 0xdd9ef4: ldur            x0, [fp, #-0x18]
    // 0xdd9ef8: r0 = _getColors()
    //     0xdd9ef8: bl              #0xdd9f48  ; [package:fading_edge_scrollview/src/fading_edge_scrollview.dart] FadingEdgeScrollViewState::_getColors
    // 0xdd9efc: stur            x0, [fp, #-8]
    // 0xdd9f00: r0 = LinearGradient()
    //     0xdd9f00: bl              #0xb6a1d0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0xdd9f04: ldur            x1, [fp, #-0x10]
    // 0xdd9f08: StoreField: r0->field_13 = r1
    //     0xdd9f08: stur            w1, [x0, #0x13]
    // 0xdd9f0c: ldur            x1, [fp, #-0x18]
    // 0xdd9f10: ArrayStore: r0[0] = r1  ; List_4
    //     0xdd9f10: stur            w1, [x0, #0x17]
    // 0xdd9f14: r1 = Instance_TileMode
    //     0xdd9f14: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e900] Obj!TileMode@12c7f61
    //     0xdd9f18: ldr             x1, [x1, #0x900]
    // 0xdd9f1c: StoreField: r0->field_1b = r1
    //     0xdd9f1c: stur            w1, [x0, #0x1b]
    // 0xdd9f20: ldur            x1, [fp, #-8]
    // 0xdd9f24: StoreField: r0->field_7 = r1
    //     0xdd9f24: stur            w1, [x0, #7]
    // 0xdd9f28: ldur            x1, [fp, #-0x28]
    // 0xdd9f2c: StoreField: r0->field_b = r1
    //     0xdd9f2c: stur            w1, [x0, #0xb]
    // 0xdd9f30: LeaveFrame
    //     0xdd9f30: mov             SP, fp
    //     0xdd9f34: ldp             fp, lr, [SP], #0x10
    // 0xdd9f38: ret
    //     0xdd9f38: ret             
    // 0xdd9f3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd9f3c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd9f40: b               #0xdd9dc4
    // 0xdd9f44: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd9f44: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _getColors(/* No info */) {
    // ** addr: 0xdd9f48, size: 0xac
    // 0xdd9f48: EnterFrame
    //     0xdd9f48: stp             fp, lr, [SP, #-0x10]!
    //     0xdd9f4c: mov             fp, SP
    // 0xdd9f50: AllocStack(0x18)
    //     0xdd9f50: sub             SP, SP, #0x18
    // 0xdd9f54: tbnz            w2, #4, #0xdd9f64
    // 0xdd9f58: r0 = Instance_Color
    //     0xdd9f58: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xdd9f5c: ldr             x0, [x0, #0x810]
    // 0xdd9f60: b               #0xdd9f6c
    // 0xdd9f64: r0 = Instance_Color
    //     0xdd9f64: add             x0, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0xdd9f68: ldr             x0, [x0, #0xc38]
    // 0xdd9f6c: stur            x0, [fp, #-0x10]
    // 0xdd9f70: tbnz            w3, #4, #0xdd9f80
    // 0xdd9f74: r4 = Instance_Color
    //     0xdd9f74: add             x4, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xdd9f78: ldr             x4, [x4, #0x810]
    // 0xdd9f7c: b               #0xdd9f88
    // 0xdd9f80: r4 = Instance_Color
    //     0xdd9f80: add             x4, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0xdd9f84: ldr             x4, [x4, #0xc38]
    // 0xdd9f88: r3 = 8
    //     0xdd9f88: mov             x3, #8
    // 0xdd9f8c: mov             x2, x3
    // 0xdd9f90: stur            x4, [fp, #-8]
    // 0xdd9f94: r1 = Null
    //     0xdd9f94: mov             x1, NULL
    // 0xdd9f98: r0 = AllocateArray()
    //     0xdd9f98: bl              #0x13df928  ; AllocateArrayStub
    // 0xdd9f9c: mov             x2, x0
    // 0xdd9fa0: ldur            x0, [fp, #-0x10]
    // 0xdd9fa4: stur            x2, [fp, #-0x18]
    // 0xdd9fa8: StoreField: r2->field_f = r0
    //     0xdd9fa8: stur            w0, [x2, #0xf]
    // 0xdd9fac: r16 = Instance_Color
    //     0xdd9fac: add             x16, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0xdd9fb0: ldr             x16, [x16, #0xc38]
    // 0xdd9fb4: StoreField: r2->field_13 = r16
    //     0xdd9fb4: stur            w16, [x2, #0x13]
    // 0xdd9fb8: r16 = Instance_Color
    //     0xdd9fb8: add             x16, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0xdd9fbc: ldr             x16, [x16, #0xc38]
    // 0xdd9fc0: ArrayStore: r2[0] = r16  ; List_4
    //     0xdd9fc0: stur            w16, [x2, #0x17]
    // 0xdd9fc4: ldur            x0, [fp, #-8]
    // 0xdd9fc8: StoreField: r2->field_1b = r0
    //     0xdd9fc8: stur            w0, [x2, #0x1b]
    // 0xdd9fcc: r1 = <Color>
    //     0xdd9fcc: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xdd9fd0: ldr             x1, [x1, #0xa90]
    // 0xdd9fd4: r0 = AllocateGrowableArray()
    //     0xdd9fd4: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xdd9fd8: ldur            x1, [fp, #-0x18]
    // 0xdd9fdc: StoreField: r0->field_f = r1
    //     0xdd9fdc: stur            w1, [x0, #0xf]
    // 0xdd9fe0: r1 = 8
    //     0xdd9fe0: mov             x1, #8
    // 0xdd9fe4: StoreField: r0->field_b = r1
    //     0xdd9fe4: stur            w1, [x0, #0xb]
    // 0xdd9fe8: LeaveFrame
    //     0xdd9fe8: mov             SP, fp
    //     0xdd9fec: ldp             fp, lr, [SP], #0x10
    // 0xdd9ff0: ret
    //     0xdd9ff0: ret             
  }
  get _ _gradientEnd(/* No info */) {
    // ** addr: 0xdd9ff4, size: 0x5c
    // 0xdd9ff4: EnterFrame
    //     0xdd9ff4: stp             fp, lr, [SP, #-0x10]!
    //     0xdd9ff8: mov             fp, SP
    // 0xdd9ffc: CheckStackOverflow
    //     0xdd9ffc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdda000: cmp             SP, x16
    //     0xdda004: b.ls            #0xdda044
    // 0xdda008: LoadField: r0 = r1->field_b
    //     0xdda008: ldur            w0, [x1, #0xb]
    // 0xdda00c: DecompressPointer r0
    //     0xdda00c: add             x0, x0, HEAP, lsl #32
    // 0xdda010: cmp             w0, NULL
    // 0xdda014: b.eq            #0xdda04c
    // 0xdda018: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xdda018: ldur            w2, [x0, #0x17]
    // 0xdda01c: DecompressPointer r2
    //     0xdda01c: add             x2, x2, HEAP, lsl #32
    // 0xdda020: r16 = Instance_Axis
    //     0xdda020: ldr             x16, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xdda024: cmp             w2, w16
    // 0xdda028: b.ne            #0xdda034
    // 0xdda02c: r0 = _verticalEnd()
    //     0xdda02c: bl              #0xdda090  ; [package:fading_edge_scrollview/src/fading_edge_scrollview.dart] FadingEdgeScrollViewState::_verticalEnd
    // 0xdda030: b               #0xdda038
    // 0xdda034: r0 = _horizontalEnd()
    //     0xdda034: bl              #0xdda050  ; [package:fading_edge_scrollview/src/fading_edge_scrollview.dart] FadingEdgeScrollViewState::_horizontalEnd
    // 0xdda038: LeaveFrame
    //     0xdda038: mov             SP, fp
    //     0xdda03c: ldp             fp, lr, [SP], #0x10
    // 0xdda040: ret
    //     0xdda040: ret             
    // 0xdda044: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdda044: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdda048: b               #0xdda008
    // 0xdda04c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdda04c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _horizontalEnd(/* No info */) {
    // ** addr: 0xdda050, size: 0x40
    // 0xdda050: LoadField: r2 = r1->field_b
    //     0xdda050: ldur            w2, [x1, #0xb]
    // 0xdda054: DecompressPointer r2
    //     0xdda054: add             x2, x2, HEAP, lsl #32
    // 0xdda058: cmp             w2, NULL
    // 0xdda05c: b.eq            #0xdda084
    // 0xdda060: LoadField: r1 = r2->field_13
    //     0xdda060: ldur            w1, [x2, #0x13]
    // 0xdda064: DecompressPointer r1
    //     0xdda064: add             x1, x1, HEAP, lsl #32
    // 0xdda068: tbnz            w1, #4, #0xdda078
    // 0xdda06c: r0 = Instance_AlignmentDirectional
    //     0xdda06c: add             x0, PP, #0x28, lsl #12  ; [pp+0x28258] Obj!AlignmentDirectional@129e651
    //     0xdda070: ldr             x0, [x0, #0x258]
    // 0xdda074: b               #0xdda080
    // 0xdda078: r0 = Instance_AlignmentDirectional
    //     0xdda078: add             x0, PP, #0x99, lsl #12  ; [pp+0x99aa0] Obj!AlignmentDirectional@129e631
    //     0xdda07c: ldr             x0, [x0, #0xaa0]
    // 0xdda080: ret
    //     0xdda080: ret             
    // 0xdda084: EnterFrame
    //     0xdda084: stp             fp, lr, [SP, #-0x10]!
    //     0xdda088: mov             fp, SP
    // 0xdda08c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdda08c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _verticalEnd(/* No info */) {
    // ** addr: 0xdda090, size: 0x40
    // 0xdda090: LoadField: r2 = r1->field_b
    //     0xdda090: ldur            w2, [x1, #0xb]
    // 0xdda094: DecompressPointer r2
    //     0xdda094: add             x2, x2, HEAP, lsl #32
    // 0xdda098: cmp             w2, NULL
    // 0xdda09c: b.eq            #0xdda0c4
    // 0xdda0a0: LoadField: r1 = r2->field_13
    //     0xdda0a0: ldur            w1, [x2, #0x13]
    // 0xdda0a4: DecompressPointer r1
    //     0xdda0a4: add             x1, x1, HEAP, lsl #32
    // 0xdda0a8: tbnz            w1, #4, #0xdda0b8
    // 0xdda0ac: r0 = Instance_Alignment
    //     0xdda0ac: add             x0, PP, #0x19, lsl #12  ; [pp+0x197a8] Obj!Alignment@129e7d1
    //     0xdda0b0: ldr             x0, [x0, #0x7a8]
    // 0xdda0b4: b               #0xdda0c0
    // 0xdda0b8: r0 = Instance_Alignment
    //     0xdda0b8: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e1b8] Obj!Alignment@129e6f1
    //     0xdda0bc: ldr             x0, [x0, #0x1b8]
    // 0xdda0c0: ret
    //     0xdda0c0: ret             
    // 0xdda0c4: EnterFrame
    //     0xdda0c4: stp             fp, lr, [SP, #-0x10]!
    //     0xdda0c8: mov             fp, SP
    // 0xdda0cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdda0cc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _gradientStart(/* No info */) {
    // ** addr: 0xdda0d0, size: 0x5c
    // 0xdda0d0: EnterFrame
    //     0xdda0d0: stp             fp, lr, [SP, #-0x10]!
    //     0xdda0d4: mov             fp, SP
    // 0xdda0d8: CheckStackOverflow
    //     0xdda0d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdda0dc: cmp             SP, x16
    //     0xdda0e0: b.ls            #0xdda120
    // 0xdda0e4: LoadField: r0 = r1->field_b
    //     0xdda0e4: ldur            w0, [x1, #0xb]
    // 0xdda0e8: DecompressPointer r0
    //     0xdda0e8: add             x0, x0, HEAP, lsl #32
    // 0xdda0ec: cmp             w0, NULL
    // 0xdda0f0: b.eq            #0xdda128
    // 0xdda0f4: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xdda0f4: ldur            w2, [x0, #0x17]
    // 0xdda0f8: DecompressPointer r2
    //     0xdda0f8: add             x2, x2, HEAP, lsl #32
    // 0xdda0fc: r16 = Instance_Axis
    //     0xdda0fc: ldr             x16, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xdda100: cmp             w2, w16
    // 0xdda104: b.ne            #0xdda110
    // 0xdda108: r0 = _verticalStart()
    //     0xdda108: bl              #0xdda16c  ; [package:fading_edge_scrollview/src/fading_edge_scrollview.dart] FadingEdgeScrollViewState::_verticalStart
    // 0xdda10c: b               #0xdda114
    // 0xdda110: r0 = _horizontalStart()
    //     0xdda110: bl              #0xdda12c  ; [package:fading_edge_scrollview/src/fading_edge_scrollview.dart] FadingEdgeScrollViewState::_horizontalStart
    // 0xdda114: LeaveFrame
    //     0xdda114: mov             SP, fp
    //     0xdda118: ldp             fp, lr, [SP], #0x10
    // 0xdda11c: ret
    //     0xdda11c: ret             
    // 0xdda120: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdda120: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdda124: b               #0xdda0e4
    // 0xdda128: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdda128: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _horizontalStart(/* No info */) {
    // ** addr: 0xdda12c, size: 0x40
    // 0xdda12c: LoadField: r2 = r1->field_b
    //     0xdda12c: ldur            w2, [x1, #0xb]
    // 0xdda130: DecompressPointer r2
    //     0xdda130: add             x2, x2, HEAP, lsl #32
    // 0xdda134: cmp             w2, NULL
    // 0xdda138: b.eq            #0xdda160
    // 0xdda13c: LoadField: r1 = r2->field_13
    //     0xdda13c: ldur            w1, [x2, #0x13]
    // 0xdda140: DecompressPointer r1
    //     0xdda140: add             x1, x1, HEAP, lsl #32
    // 0xdda144: tbnz            w1, #4, #0xdda154
    // 0xdda148: r0 = Instance_AlignmentDirectional
    //     0xdda148: add             x0, PP, #0x99, lsl #12  ; [pp+0x99aa0] Obj!AlignmentDirectional@129e631
    //     0xdda14c: ldr             x0, [x0, #0xaa0]
    // 0xdda150: b               #0xdda15c
    // 0xdda154: r0 = Instance_AlignmentDirectional
    //     0xdda154: add             x0, PP, #0x28, lsl #12  ; [pp+0x28258] Obj!AlignmentDirectional@129e651
    //     0xdda158: ldr             x0, [x0, #0x258]
    // 0xdda15c: ret
    //     0xdda15c: ret             
    // 0xdda160: EnterFrame
    //     0xdda160: stp             fp, lr, [SP, #-0x10]!
    //     0xdda164: mov             fp, SP
    // 0xdda168: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdda168: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _verticalStart(/* No info */) {
    // ** addr: 0xdda16c, size: 0x40
    // 0xdda16c: LoadField: r2 = r1->field_b
    //     0xdda16c: ldur            w2, [x1, #0xb]
    // 0xdda170: DecompressPointer r2
    //     0xdda170: add             x2, x2, HEAP, lsl #32
    // 0xdda174: cmp             w2, NULL
    // 0xdda178: b.eq            #0xdda1a0
    // 0xdda17c: LoadField: r1 = r2->field_13
    //     0xdda17c: ldur            w1, [x2, #0x13]
    // 0xdda180: DecompressPointer r1
    //     0xdda180: add             x1, x1, HEAP, lsl #32
    // 0xdda184: tbnz            w1, #4, #0xdda194
    // 0xdda188: r0 = Instance_Alignment
    //     0xdda188: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e1b8] Obj!Alignment@129e6f1
    //     0xdda18c: ldr             x0, [x0, #0x1b8]
    // 0xdda190: b               #0xdda19c
    // 0xdda194: r0 = Instance_Alignment
    //     0xdda194: add             x0, PP, #0x19, lsl #12  ; [pp+0x197a8] Obj!Alignment@129e7d1
    //     0xdda198: ldr             x0, [x0, #0x7a8]
    // 0xdda19c: ret
    //     0xdda19c: ret             
    // 0xdda1a0: EnterFrame
    //     0xdda1a0: stp             fp, lr, [SP, #-0x10]!
    //     0xdda1a4: mov             fp, SP
    // 0xdda1a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdda1a8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] bool <anonymous closure>(dynamic, ScrollMetricsNotification) {
    // ** addr: 0xdda1ac, size: 0x48
    // 0xdda1ac: EnterFrame
    //     0xdda1ac: stp             fp, lr, [SP, #-0x10]!
    //     0xdda1b0: mov             fp, SP
    // 0xdda1b4: ldr             x0, [fp, #0x18]
    // 0xdda1b8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdda1b8: ldur            w1, [x0, #0x17]
    // 0xdda1bc: DecompressPointer r1
    //     0xdda1bc: add             x1, x1, HEAP, lsl #32
    // 0xdda1c0: CheckStackOverflow
    //     0xdda1c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdda1c4: cmp             SP, x16
    //     0xdda1c8: b.ls            #0xdda1ec
    // 0xdda1cc: LoadField: r0 = r1->field_f
    //     0xdda1cc: ldur            w0, [x1, #0xf]
    // 0xdda1d0: DecompressPointer r0
    //     0xdda1d0: add             x0, x0, HEAP, lsl #32
    // 0xdda1d4: mov             x1, x0
    // 0xdda1d8: r0 = _updateScrollState()
    //     0xdda1d8: bl              #0x8d09a4  ; [package:fading_edge_scrollview/src/fading_edge_scrollview.dart] FadingEdgeScrollViewState::_updateScrollState
    // 0xdda1dc: r0 = false
    //     0xdda1dc: add             x0, NULL, #0x30  ; false
    // 0xdda1e0: LeaveFrame
    //     0xdda1e0: mov             SP, fp
    //     0xdda1e4: ldp             fp, lr, [SP], #0x10
    // 0xdda1e8: ret
    //     0xdda1e8: ret             
    // 0xdda1ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdda1ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdda1f0: b               #0xdda1cc
  }
  _ initState(/* No info */) {
    // ** addr: 0xf8afe0, size: 0x128
    // 0xf8afe0: EnterFrame
    //     0xf8afe0: stp             fp, lr, [SP, #-0x10]!
    //     0xf8afe4: mov             fp, SP
    // 0xf8afe8: AllocStack(0x18)
    //     0xf8afe8: sub             SP, SP, #0x18
    // 0xf8afec: SetupParameters(FadingEdgeScrollViewState this /* r1 => r3, fp-0x10 */)
    //     0xf8afec: mov             x3, x1
    //     0xf8aff0: stur            x1, [fp, #-0x10]
    // 0xf8aff4: CheckStackOverflow
    //     0xf8aff4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf8aff8: cmp             SP, x16
    //     0xf8affc: b.ls            #0xf8b0f8
    // 0xf8b000: LoadField: r0 = r3->field_b
    //     0xf8b000: ldur            w0, [x3, #0xb]
    // 0xf8b004: DecompressPointer r0
    //     0xf8b004: add             x0, x0, HEAP, lsl #32
    // 0xf8b008: cmp             w0, NULL
    // 0xf8b00c: b.eq            #0xf8b100
    // 0xf8b010: LoadField: r4 = r0->field_f
    //     0xf8b010: ldur            w4, [x0, #0xf]
    // 0xf8b014: DecompressPointer r4
    //     0xf8b014: add             x4, x4, HEAP, lsl #32
    // 0xf8b018: mov             x0, x4
    // 0xf8b01c: stur            x4, [fp, #-8]
    // 0xf8b020: StoreField: r3->field_13 = r0
    //     0xf8b020: stur            w0, [x3, #0x13]
    //     0xf8b024: ldurb           w16, [x3, #-1]
    //     0xf8b028: ldurb           w17, [x0, #-1]
    //     0xf8b02c: and             x16, x17, x16, lsr #2
    //     0xf8b030: tst             x16, HEAP, lsr #32
    //     0xf8b034: b.eq            #0xf8b03c
    //     0xf8b038: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xf8b03c: mov             x2, x3
    // 0xf8b040: r1 = Function '_updateScrollState@464074463':.
    //     0xf8b040: add             x1, PP, #0xac, lsl #12  ; [pp+0xac360] AnonymousClosure: (0x8d0ca4), in [package:fading_edge_scrollview/src/fading_edge_scrollview.dart] FadingEdgeScrollViewState::_updateScrollState (0x8d09a4)
    //     0xf8b044: ldr             x1, [x1, #0x360]
    // 0xf8b048: r0 = AllocateClosure()
    //     0xf8b048: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf8b04c: ldur            x1, [fp, #-8]
    // 0xf8b050: mov             x2, x0
    // 0xf8b054: r0 = addListener()
    //     0xf8b054: bl              #0xd038e0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0xf8b058: r0 = LoadStaticField(0x6a0)
    //     0xf8b058: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf8b05c: ldr             x0, [x0, #0xd40]
    // 0xf8b060: cmp             w0, NULL
    // 0xf8b064: b.eq            #0xf8b104
    // 0xf8b068: LoadField: r2 = r0->field_f3
    //     0xf8b068: ldur            w2, [x0, #0xf3]
    // 0xf8b06c: DecompressPointer r2
    //     0xf8b06c: add             x2, x2, HEAP, lsl #32
    // 0xf8b070: stur            x2, [fp, #-8]
    // 0xf8b074: LoadField: r0 = r2->field_b
    //     0xf8b074: ldur            w0, [x2, #0xb]
    // 0xf8b078: LoadField: r1 = r2->field_f
    //     0xf8b078: ldur            w1, [x2, #0xf]
    // 0xf8b07c: DecompressPointer r1
    //     0xf8b07c: add             x1, x1, HEAP, lsl #32
    // 0xf8b080: LoadField: r3 = r1->field_b
    //     0xf8b080: ldur            w3, [x1, #0xb]
    // 0xf8b084: r4 = LoadInt32Instr(r0)
    //     0xf8b084: sbfx            x4, x0, #1, #0x1f
    // 0xf8b088: stur            x4, [fp, #-0x18]
    // 0xf8b08c: r0 = LoadInt32Instr(r3)
    //     0xf8b08c: sbfx            x0, x3, #1, #0x1f
    // 0xf8b090: cmp             x4, x0
    // 0xf8b094: b.ne            #0xf8b0a0
    // 0xf8b098: mov             x1, x2
    // 0xf8b09c: r0 = _growToNextCapacity()
    //     0xf8b09c: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xf8b0a0: ldur            x2, [fp, #-8]
    // 0xf8b0a4: ldur            x3, [fp, #-0x18]
    // 0xf8b0a8: add             x4, x3, #1
    // 0xf8b0ac: lsl             x5, x4, #1
    // 0xf8b0b0: StoreField: r2->field_b = r5
    //     0xf8b0b0: stur            w5, [x2, #0xb]
    // 0xf8b0b4: LoadField: r1 = r2->field_f
    //     0xf8b0b4: ldur            w1, [x2, #0xf]
    // 0xf8b0b8: DecompressPointer r1
    //     0xf8b0b8: add             x1, x1, HEAP, lsl #32
    // 0xf8b0bc: ldur            x0, [fp, #-0x10]
    // 0xf8b0c0: ArrayStore: r1[r3] = r0  ; List_4
    //     0xf8b0c0: add             x25, x1, x3, lsl #2
    //     0xf8b0c4: add             x25, x25, #0xf
    //     0xf8b0c8: str             w0, [x25]
    //     0xf8b0cc: tbz             w0, #0, #0xf8b0e8
    //     0xf8b0d0: ldurb           w16, [x1, #-1]
    //     0xf8b0d4: ldurb           w17, [x0, #-1]
    //     0xf8b0d8: and             x16, x17, x16, lsr #2
    //     0xf8b0dc: tst             x16, HEAP, lsr #32
    //     0xf8b0e0: b.eq            #0xf8b0e8
    //     0xf8b0e4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xf8b0e8: r0 = Null
    //     0xf8b0e8: mov             x0, NULL
    // 0xf8b0ec: LeaveFrame
    //     0xf8b0ec: mov             SP, fp
    //     0xf8b0f0: ldp             fp, lr, [SP], #0x10
    // 0xf8b0f4: ret
    //     0xf8b0f4: ret             
    // 0xf8b0f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf8b0f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf8b0fc: b               #0xf8b000
    // 0xf8b100: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf8b100: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf8b104: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf8b104: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10e2a00, size: 0x94
    // 0x10e2a00: EnterFrame
    //     0x10e2a00: stp             fp, lr, [SP, #-0x10]!
    //     0x10e2a04: mov             fp, SP
    // 0x10e2a08: AllocStack(0x10)
    //     0x10e2a08: sub             SP, SP, #0x10
    // 0x10e2a0c: SetupParameters(FadingEdgeScrollViewState this /* r1 => r0, fp-0x8 */)
    //     0x10e2a0c: mov             x0, x1
    //     0x10e2a10: stur            x1, [fp, #-8]
    // 0x10e2a14: CheckStackOverflow
    //     0x10e2a14: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e2a18: cmp             SP, x16
    //     0x10e2a1c: b.ls            #0x10e2a7c
    // 0x10e2a20: r1 = LoadStaticField(0x6a0)
    //     0x10e2a20: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x10e2a24: ldr             x1, [x1, #0xd40]
    // 0x10e2a28: cmp             w1, NULL
    // 0x10e2a2c: b.eq            #0x10e2a84
    // 0x10e2a30: mov             x2, x0
    // 0x10e2a34: r0 = removeObserver()
    //     0x10e2a34: bl              #0xb3ac3c  ; [dart:mixin_deduplication] _MixinApplication208&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding&PaintingBinding&SemanticsBinding&RendererBinding&WidgetsBinding::removeObserver
    // 0x10e2a38: ldur            x2, [fp, #-8]
    // 0x10e2a3c: LoadField: r0 = r2->field_13
    //     0x10e2a3c: ldur            w0, [x2, #0x13]
    // 0x10e2a40: DecompressPointer r0
    //     0x10e2a40: add             x0, x0, HEAP, lsl #32
    // 0x10e2a44: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10e2a48: cmp             w0, w16
    // 0x10e2a4c: b.eq            #0x10e2a88
    // 0x10e2a50: stur            x0, [fp, #-0x10]
    // 0x10e2a54: r1 = Function '_updateScrollState@464074463':.
    //     0x10e2a54: add             x1, PP, #0xac, lsl #12  ; [pp+0xac360] AnonymousClosure: (0x8d0ca4), in [package:fading_edge_scrollview/src/fading_edge_scrollview.dart] FadingEdgeScrollViewState::_updateScrollState (0x8d09a4)
    //     0x10e2a58: ldr             x1, [x1, #0x360]
    // 0x10e2a5c: r0 = AllocateClosure()
    //     0x10e2a5c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10e2a60: ldur            x1, [fp, #-0x10]
    // 0x10e2a64: mov             x2, x0
    // 0x10e2a68: r0 = removeListener()
    //     0x10e2a68: bl              #0xcff968  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x10e2a6c: r0 = Null
    //     0x10e2a6c: mov             x0, NULL
    // 0x10e2a70: LeaveFrame
    //     0x10e2a70: mov             SP, fp
    //     0x10e2a74: ldp             fp, lr, [SP], #0x10
    // 0x10e2a78: ret
    //     0x10e2a78: ret             
    // 0x10e2a7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e2a7c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e2a80: b               #0x10e2a20
    // 0x10e2a84: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10e2a84: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x10e2a88: r9 = _controller
    //     0x10e2a88: add             x9, PP, #0xac, lsl #12  ; [pp+0xac358] Field <FadingEdgeScrollViewState._controller@464074463>: late (offset: 0x14)
    //     0x10e2a8c: ldr             x9, [x9, #0x358]
    // 0x10e2a90: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x10e2a90: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 6531, size: 0x2c, field offset: 0xc
//   const constructor, 
class FadingEdgeScrollView extends StatefulWidget {

  factory _ FadingEdgeScrollView.fromScrollView(/* No info */) {
    // ** addr: 0xd8c2f4, size: 0x9c
    // 0xd8c2f4: EnterFrame
    //     0xd8c2f4: stp             fp, lr, [SP, #-0x10]!
    //     0xd8c2f8: mov             fp, SP
    // 0xd8c2fc: AllocStack(0x20)
    //     0xd8c2fc: sub             SP, SP, #0x20
    // 0xd8c300: SetupParameters(dynamic _ /* r2 => r2, fp-0x20 */)
    //     0xd8c300: stur            x2, [fp, #-0x20]
    // 0xd8c304: LoadField: r0 = r2->field_13
    //     0xd8c304: ldur            w0, [x2, #0x13]
    // 0xd8c308: DecompressPointer r0
    //     0xd8c308: add             x0, x0, HEAP, lsl #32
    // 0xd8c30c: stur            x0, [fp, #-0x18]
    // 0xd8c310: cmp             w0, NULL
    // 0xd8c314: b.eq            #0xd8c370
    // 0xd8c318: LoadField: r1 = r2->field_b
    //     0xd8c318: ldur            w1, [x2, #0xb]
    // 0xd8c31c: DecompressPointer r1
    //     0xd8c31c: add             x1, x1, HEAP, lsl #32
    // 0xd8c320: stur            x1, [fp, #-0x10]
    // 0xd8c324: LoadField: r3 = r2->field_f
    //     0xd8c324: ldur            w3, [x2, #0xf]
    // 0xd8c328: DecompressPointer r3
    //     0xd8c328: add             x3, x3, HEAP, lsl #32
    // 0xd8c32c: stur            x3, [fp, #-8]
    // 0xd8c330: r0 = FadingEdgeScrollView()
    //     0xd8c330: bl              #0xd8c390  ; AllocateFadingEdgeScrollViewStub -> FadingEdgeScrollView (size=0x2c)
    // 0xd8c334: mov             x1, x0
    // 0xd8c338: ldur            x0, [fp, #-0x20]
    // 0xd8c33c: StoreField: r1->field_b = r0
    //     0xd8c33c: stur            w0, [x1, #0xb]
    // 0xd8c340: ldur            x0, [fp, #-0x18]
    // 0xd8c344: StoreField: r1->field_f = r0
    //     0xd8c344: stur            w0, [x1, #0xf]
    // 0xd8c348: ldur            x0, [fp, #-8]
    // 0xd8c34c: StoreField: r1->field_13 = r0
    //     0xd8c34c: stur            w0, [x1, #0x13]
    // 0xd8c350: ldur            x0, [fp, #-0x10]
    // 0xd8c354: ArrayStore: r1[0] = r0  ; List_4
    //     0xd8c354: stur            w0, [x1, #0x17]
    // 0xd8c358: StoreField: r1->field_1b = rZR
    //     0xd8c358: stur            xzr, [x1, #0x1b]
    // 0xd8c35c: StoreField: r1->field_23 = rZR
    //     0xd8c35c: stur            xzr, [x1, #0x23]
    // 0xd8c360: mov             x0, x1
    // 0xd8c364: LeaveFrame
    //     0xd8c364: mov             SP, fp
    //     0xd8c368: ldp             fp, lr, [SP], #0x10
    // 0xd8c36c: ret
    //     0xd8c36c: ret             
    // 0xd8c370: r0 = _Exception()
    //     0xd8c370: bl              #0x8220c0  ; Allocate_ExceptionStub -> _Exception (size=0xc)
    // 0xd8c374: mov             x1, x0
    // 0xd8c378: r0 = "Child must have controller set"
    //     0xd8c378: add             x0, PP, #0x97, lsl #12  ; [pp+0x97928] "Child must have controller set"
    //     0xd8c37c: ldr             x0, [x0, #0x928]
    // 0xd8c380: StoreField: r1->field_7 = r0
    //     0xd8c380: stur            w0, [x1, #7]
    // 0xd8c384: mov             x0, x1
    // 0xd8c388: r0 = Throw()
    //     0xd8c388: bl              #0x13ddb2c  ; ThrowStub
    // 0xd8c38c: brk             #0
  }
  _ createState(/* No info */) {
    // ** addr: 0xfa0108, size: 0x38
    // 0xfa0108: EnterFrame
    //     0xfa0108: stp             fp, lr, [SP, #-0x10]!
    //     0xfa010c: mov             fp, SP
    // 0xfa0110: mov             x0, x1
    // 0xfa0114: r1 = <FadingEdgeScrollView>
    //     0xfa0114: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa1b70] TypeArguments: <FadingEdgeScrollView>
    //     0xfa0118: ldr             x1, [x1, #0xb70]
    // 0xfa011c: r0 = FadingEdgeScrollViewState()
    //     0xfa011c: bl              #0xfa0140  ; AllocateFadingEdgeScrollViewStateStub -> FadingEdgeScrollViewState (size=0x1c)
    // 0xfa0120: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa0124: StoreField: r0->field_13 = r1
    //     0xfa0124: stur            w1, [x0, #0x13]
    // 0xfa0128: r1 = Instance__ScrollState
    //     0xfa0128: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa1b78] Obj!_ScrollState@12c6381
    //     0xfa012c: ldr             x1, [x1, #0xb78]
    // 0xfa0130: ArrayStore: r0[0] = r1  ; List_4
    //     0xfa0130: stur            w1, [x0, #0x17]
    // 0xfa0134: LeaveFrame
    //     0xfa0134: mov             SP, fp
    //     0xfa0138: ldp             fp, lr, [SP], #0x10
    // 0xfa013c: ret
    //     0xfa013c: ret             
  }
}

// class id: 8332, size: 0x14, field offset: 0x14
enum _ScrollState extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11a934c, size: 0x64
    // 0x11a934c: EnterFrame
    //     0x11a934c: stp             fp, lr, [SP, #-0x10]!
    //     0x11a9350: mov             fp, SP
    // 0x11a9354: AllocStack(0x10)
    //     0x11a9354: sub             SP, SP, #0x10
    // 0x11a9358: SetupParameters(_ScrollState this /* r1 => r0, fp-0x8 */)
    //     0x11a9358: mov             x0, x1
    //     0x11a935c: stur            x1, [fp, #-8]
    // 0x11a9360: CheckStackOverflow
    //     0x11a9360: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a9364: cmp             SP, x16
    //     0x11a9368: b.ls            #0x11a93a8
    // 0x11a936c: r1 = Null
    //     0x11a936c: mov             x1, NULL
    // 0x11a9370: r2 = 4
    //     0x11a9370: mov             x2, #4
    // 0x11a9374: r0 = AllocateArray()
    //     0x11a9374: bl              #0x13df928  ; AllocateArrayStub
    // 0x11a9378: r16 = "_ScrollState."
    //     0x11a9378: add             x16, PP, #0xac, lsl #12  ; [pp+0xac368] "_ScrollState."
    //     0x11a937c: ldr             x16, [x16, #0x368]
    // 0x11a9380: StoreField: r0->field_f = r16
    //     0x11a9380: stur            w16, [x0, #0xf]
    // 0x11a9384: ldur            x1, [fp, #-8]
    // 0x11a9388: LoadField: r2 = r1->field_f
    //     0x11a9388: ldur            w2, [x1, #0xf]
    // 0x11a938c: DecompressPointer r2
    //     0x11a938c: add             x2, x2, HEAP, lsl #32
    // 0x11a9390: StoreField: r0->field_13 = r2
    //     0x11a9390: stur            w2, [x0, #0x13]
    // 0x11a9394: str             x0, [SP]
    // 0x11a9398: r0 = _interpolate()
    //     0x11a9398: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11a939c: LeaveFrame
    //     0x11a939c: mov             SP, fp
    //     0x11a93a0: ldp             fp, lr, [SP], #0x10
    // 0x11a93a4: ret
    //     0x11a93a4: ret             
    // 0x11a93a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a93a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a93ac: b               #0x11a936c
  }
}
