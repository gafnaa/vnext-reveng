// lib: , url: package:firebase_messaging_platform_interface/src/notification_settings.dart

// class id: 1048755, size: 0x8
class :: {
}

// class id: 3351, size: 0x8, field offset: 0x8
//   const constructor, 
class NotificationSettings extends Object {
}
