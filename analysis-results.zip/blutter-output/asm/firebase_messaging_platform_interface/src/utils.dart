// lib: , url: package:firebase_messaging_platform_interface/src/utils.dart

// class id: 1048760, size: 0x8
class :: {

  static _ convertAndroidNotificationPriorityToInt(/* No info */) {
    // ** addr: 0x13e92e4, size: 0x6c
    // 0x13e92e4: r16 = Instance_AndroidNotificationPriority
    //     0x13e92e4: ldr             x16, [PP, #0x66b0]  ; [pp+0x66b0] Obj!AndroidNotificationPriority@12c62c1
    // 0x13e92e8: cmp             w1, w16
    // 0x13e92ec: b.ne            #0x13e92f8
    // 0x13e92f0: r0 = -2
    //     0x13e92f0: mov             x0, #-2
    // 0x13e92f4: ret
    //     0x13e92f4: ret             
    // 0x13e92f8: r16 = Instance_AndroidNotificationPriority
    //     0x13e92f8: ldr             x16, [PP, #0x66b8]  ; [pp+0x66b8] Obj!AndroidNotificationPriority@12c62a1
    // 0x13e92fc: cmp             w1, w16
    // 0x13e9300: b.ne            #0x13e930c
    // 0x13e9304: r0 = -1
    //     0x13e9304: mov             x0, #-1
    // 0x13e9308: ret
    //     0x13e9308: ret             
    // 0x13e930c: r16 = Instance_AndroidNotificationPriority
    //     0x13e930c: ldr             x16, [PP, #0x66c0]  ; [pp+0x66c0] Obj!AndroidNotificationPriority@12c6281
    // 0x13e9310: cmp             w1, w16
    // 0x13e9314: b.ne            #0x13e9320
    // 0x13e9318: r0 = 0
    //     0x13e9318: mov             x0, #0
    // 0x13e931c: ret
    //     0x13e931c: ret             
    // 0x13e9320: r16 = Instance_AndroidNotificationPriority
    //     0x13e9320: ldr             x16, [PP, #0x66c8]  ; [pp+0x66c8] Obj!AndroidNotificationPriority@12c6261
    // 0x13e9324: cmp             w1, w16
    // 0x13e9328: b.ne            #0x13e9334
    // 0x13e932c: r0 = 1
    //     0x13e932c: mov             x0, #1
    // 0x13e9330: ret
    //     0x13e9330: ret             
    // 0x13e9334: r16 = Instance_AndroidNotificationPriority
    //     0x13e9334: ldr             x16, [PP, #0x66d0]  ; [pp+0x66d0] Obj!AndroidNotificationPriority@12c6241
    // 0x13e9338: cmp             w1, w16
    // 0x13e933c: b.ne            #0x13e9348
    // 0x13e9340: r0 = 2
    //     0x13e9340: mov             x0, #2
    // 0x13e9344: ret
    //     0x13e9344: ret             
    // 0x13e9348: r0 = 0
    //     0x13e9348: mov             x0, #0
    // 0x13e934c: ret
    //     0x13e934c: ret             
  }
  static _ convertToNotificationSettings(/* No info */) {
    // ** addr: 0x13e96b0, size: 0x448
    // 0x13e96b0: EnterFrame
    //     0x13e96b0: stp             fp, lr, [SP, #-0x10]!
    //     0x13e96b4: mov             fp, SP
    // 0x13e96b8: AllocStack(0x8)
    //     0x13e96b8: sub             SP, SP, #8
    // 0x13e96bc: SetupParameters(dynamic _ /* r1 => r3, fp-0x8 */)
    //     0x13e96bc: mov             x3, x1
    //     0x13e96c0: stur            x1, [fp, #-8]
    // 0x13e96c4: CheckStackOverflow
    //     0x13e96c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13e96c8: cmp             SP, x16
    //     0x13e96cc: b.ls            #0x13e9af0
    // 0x13e96d0: r0 = LoadClassIdInstr(r3)
    //     0x13e96d0: ldur            x0, [x3, #-1]
    //     0x13e96d4: ubfx            x0, x0, #0xc, #0x14
    // 0x13e96d8: mov             x1, x3
    // 0x13e96dc: r2 = "authorizationStatus"
    //     0x13e96dc: add             x2, PP, #8, lsl #12  ; [pp+0x8c40] "authorizationStatus"
    //     0x13e96e0: ldr             x2, [x2, #0xc40]
    // 0x13e96e4: r0 = GDT[cid_x0 + -0xd48]()
    //     0x13e96e4: sub             lr, x0, #0xd48
    //     0x13e96e8: ldr             lr, [x21, lr, lsl #3]
    //     0x13e96ec: blr             lr
    // 0x13e96f0: cmp             w0, NULL
    // 0x13e96f4: b.eq            #0x13e9730
    // 0x13e96f8: r1 = LoadInt32Instr(r0)
    //     0x13e96f8: sbfx            x1, x0, #1, #0x1f
    //     0x13e96fc: tbz             w0, #0, #0x13e9704
    //     0x13e9700: ldur            x1, [x0, #7]
    // 0x13e9704: cmp             x1, #0
    // 0x13e9708: b.gt            #0x13e9720
    // 0x13e970c: cmn             x1, #1
    // 0x13e9710: b.gt            #0x13e9730
    // 0x13e9714: cmn             w0, #2
    // 0x13e9718: b.ne            #0x13e9730
    // 0x13e971c: b               #0x13e9730
    // 0x13e9720: cmp             x1, #1
    // 0x13e9724: b.le            #0x13e9730
    // 0x13e9728: cmp             w0, #4
    // 0x13e972c: b.eq            #0x13e9730
    // 0x13e9730: ldur            x3, [fp, #-8]
    // 0x13e9734: r0 = LoadClassIdInstr(r3)
    //     0x13e9734: ldur            x0, [x3, #-1]
    //     0x13e9738: ubfx            x0, x0, #0xc, #0x14
    // 0x13e973c: mov             x1, x3
    // 0x13e9740: r2 = "timeSensitive"
    //     0x13e9740: add             x2, PP, #8, lsl #12  ; [pp+0x8c48] "timeSensitive"
    //     0x13e9744: ldr             x2, [x2, #0xc48]
    // 0x13e9748: r0 = GDT[cid_x0 + -0xd48]()
    //     0x13e9748: sub             lr, x0, #0xd48
    //     0x13e974c: ldr             lr, [x21, lr, lsl #3]
    //     0x13e9750: blr             lr
    // 0x13e9754: cmp             w0, NULL
    // 0x13e9758: b.eq            #0x13e978c
    // 0x13e975c: r1 = LoadInt32Instr(r0)
    //     0x13e975c: sbfx            x1, x0, #1, #0x1f
    //     0x13e9760: tbz             w0, #0, #0x13e9768
    //     0x13e9764: ldur            x1, [x0, #7]
    // 0x13e9768: cmp             x1, #0
    // 0x13e976c: b.gt            #0x13e9784
    // 0x13e9770: cmn             x1, #1
    // 0x13e9774: b.gt            #0x13e978c
    // 0x13e9778: cmn             w0, #2
    // 0x13e977c: b.ne            #0x13e978c
    // 0x13e9780: b               #0x13e978c
    // 0x13e9784: cmp             w0, #2
    // 0x13e9788: b.eq            #0x13e978c
    // 0x13e978c: ldur            x3, [fp, #-8]
    // 0x13e9790: r0 = LoadClassIdInstr(r3)
    //     0x13e9790: ldur            x0, [x3, #-1]
    //     0x13e9794: ubfx            x0, x0, #0xc, #0x14
    // 0x13e9798: mov             x1, x3
    // 0x13e979c: r2 = "criticalAlert"
    //     0x13e979c: add             x2, PP, #8, lsl #12  ; [pp+0x8c18] "criticalAlert"
    //     0x13e97a0: ldr             x2, [x2, #0xc18]
    // 0x13e97a4: r0 = GDT[cid_x0 + -0xd48]()
    //     0x13e97a4: sub             lr, x0, #0xd48
    //     0x13e97a8: ldr             lr, [x21, lr, lsl #3]
    //     0x13e97ac: blr             lr
    // 0x13e97b0: cmp             w0, NULL
    // 0x13e97b4: b.eq            #0x13e97e8
    // 0x13e97b8: r1 = LoadInt32Instr(r0)
    //     0x13e97b8: sbfx            x1, x0, #1, #0x1f
    //     0x13e97bc: tbz             w0, #0, #0x13e97c4
    //     0x13e97c0: ldur            x1, [x0, #7]
    // 0x13e97c4: cmp             x1, #0
    // 0x13e97c8: b.gt            #0x13e97e0
    // 0x13e97cc: cmn             x1, #1
    // 0x13e97d0: b.gt            #0x13e97e8
    // 0x13e97d4: cmn             w0, #2
    // 0x13e97d8: b.ne            #0x13e97e8
    // 0x13e97dc: b               #0x13e97e8
    // 0x13e97e0: cmp             w0, #2
    // 0x13e97e4: b.eq            #0x13e97e8
    // 0x13e97e8: ldur            x3, [fp, #-8]
    // 0x13e97ec: r0 = LoadClassIdInstr(r3)
    //     0x13e97ec: ldur            x0, [x3, #-1]
    //     0x13e97f0: ubfx            x0, x0, #0xc, #0x14
    // 0x13e97f4: mov             x1, x3
    // 0x13e97f8: r2 = "alert"
    //     0x13e97f8: add             x2, PP, #8, lsl #12  ; [pp+0x8c00] "alert"
    //     0x13e97fc: ldr             x2, [x2, #0xc00]
    // 0x13e9800: r0 = GDT[cid_x0 + -0xd48]()
    //     0x13e9800: sub             lr, x0, #0xd48
    //     0x13e9804: ldr             lr, [x21, lr, lsl #3]
    //     0x13e9808: blr             lr
    // 0x13e980c: cmp             w0, NULL
    // 0x13e9810: b.eq            #0x13e9844
    // 0x13e9814: r1 = LoadInt32Instr(r0)
    //     0x13e9814: sbfx            x1, x0, #1, #0x1f
    //     0x13e9818: tbz             w0, #0, #0x13e9820
    //     0x13e981c: ldur            x1, [x0, #7]
    // 0x13e9820: cmp             x1, #0
    // 0x13e9824: b.gt            #0x13e983c
    // 0x13e9828: cmn             x1, #1
    // 0x13e982c: b.gt            #0x13e9844
    // 0x13e9830: cmn             w0, #2
    // 0x13e9834: b.ne            #0x13e9844
    // 0x13e9838: b               #0x13e9844
    // 0x13e983c: cmp             w0, #2
    // 0x13e9840: b.eq            #0x13e9844
    // 0x13e9844: ldur            x3, [fp, #-8]
    // 0x13e9848: r0 = LoadClassIdInstr(r3)
    //     0x13e9848: ldur            x0, [x3, #-1]
    //     0x13e984c: ubfx            x0, x0, #0xc, #0x14
    // 0x13e9850: mov             x1, x3
    // 0x13e9854: r2 = "announcement"
    //     0x13e9854: add             x2, PP, #8, lsl #12  ; [pp+0x8c08] "announcement"
    //     0x13e9858: ldr             x2, [x2, #0xc08]
    // 0x13e985c: r0 = GDT[cid_x0 + -0xd48]()
    //     0x13e985c: sub             lr, x0, #0xd48
    //     0x13e9860: ldr             lr, [x21, lr, lsl #3]
    //     0x13e9864: blr             lr
    // 0x13e9868: cmp             w0, NULL
    // 0x13e986c: b.eq            #0x13e98a0
    // 0x13e9870: r1 = LoadInt32Instr(r0)
    //     0x13e9870: sbfx            x1, x0, #1, #0x1f
    //     0x13e9874: tbz             w0, #0, #0x13e987c
    //     0x13e9878: ldur            x1, [x0, #7]
    // 0x13e987c: cmp             x1, #0
    // 0x13e9880: b.gt            #0x13e9898
    // 0x13e9884: cmn             x1, #1
    // 0x13e9888: b.gt            #0x13e98a0
    // 0x13e988c: cmn             w0, #2
    // 0x13e9890: b.ne            #0x13e98a0
    // 0x13e9894: b               #0x13e98a0
    // 0x13e9898: cmp             w0, #2
    // 0x13e989c: b.eq            #0x13e98a0
    // 0x13e98a0: ldur            x3, [fp, #-8]
    // 0x13e98a4: r0 = LoadClassIdInstr(r3)
    //     0x13e98a4: ldur            x0, [x3, #-1]
    //     0x13e98a8: ubfx            x0, x0, #0xc, #0x14
    // 0x13e98ac: mov             x1, x3
    // 0x13e98b0: r2 = "badge"
    //     0x13e98b0: ldr             x2, [PP, #0x6560]  ; [pp+0x6560] "badge"
    // 0x13e98b4: r0 = GDT[cid_x0 + -0xd48]()
    //     0x13e98b4: sub             lr, x0, #0xd48
    //     0x13e98b8: ldr             lr, [x21, lr, lsl #3]
    //     0x13e98bc: blr             lr
    // 0x13e98c0: cmp             w0, NULL
    // 0x13e98c4: b.eq            #0x13e98f8
    // 0x13e98c8: r1 = LoadInt32Instr(r0)
    //     0x13e98c8: sbfx            x1, x0, #1, #0x1f
    //     0x13e98cc: tbz             w0, #0, #0x13e98d4
    //     0x13e98d0: ldur            x1, [x0, #7]
    // 0x13e98d4: cmp             x1, #0
    // 0x13e98d8: b.gt            #0x13e98f0
    // 0x13e98dc: cmn             x1, #1
    // 0x13e98e0: b.gt            #0x13e98f8
    // 0x13e98e4: cmn             w0, #2
    // 0x13e98e8: b.ne            #0x13e98f8
    // 0x13e98ec: b               #0x13e98f8
    // 0x13e98f0: cmp             w0, #2
    // 0x13e98f4: b.eq            #0x13e98f8
    // 0x13e98f8: ldur            x3, [fp, #-8]
    // 0x13e98fc: r0 = LoadClassIdInstr(r3)
    //     0x13e98fc: ldur            x0, [x3, #-1]
    //     0x13e9900: ubfx            x0, x0, #0xc, #0x14
    // 0x13e9904: mov             x1, x3
    // 0x13e9908: r2 = "carPlay"
    //     0x13e9908: add             x2, PP, #8, lsl #12  ; [pp+0x8c10] "carPlay"
    //     0x13e990c: ldr             x2, [x2, #0xc10]
    // 0x13e9910: r0 = GDT[cid_x0 + -0xd48]()
    //     0x13e9910: sub             lr, x0, #0xd48
    //     0x13e9914: ldr             lr, [x21, lr, lsl #3]
    //     0x13e9918: blr             lr
    // 0x13e991c: cmp             w0, NULL
    // 0x13e9920: b.eq            #0x13e9954
    // 0x13e9924: r1 = LoadInt32Instr(r0)
    //     0x13e9924: sbfx            x1, x0, #1, #0x1f
    //     0x13e9928: tbz             w0, #0, #0x13e9930
    //     0x13e992c: ldur            x1, [x0, #7]
    // 0x13e9930: cmp             x1, #0
    // 0x13e9934: b.gt            #0x13e994c
    // 0x13e9938: cmn             x1, #1
    // 0x13e993c: b.gt            #0x13e9954
    // 0x13e9940: cmn             w0, #2
    // 0x13e9944: b.ne            #0x13e9954
    // 0x13e9948: b               #0x13e9954
    // 0x13e994c: cmp             w0, #2
    // 0x13e9950: b.eq            #0x13e9954
    // 0x13e9954: ldur            x3, [fp, #-8]
    // 0x13e9958: r0 = LoadClassIdInstr(r3)
    //     0x13e9958: ldur            x0, [x3, #-1]
    //     0x13e995c: ubfx            x0, x0, #0xc, #0x14
    // 0x13e9960: mov             x1, x3
    // 0x13e9964: r2 = "lockScreen"
    //     0x13e9964: add             x2, PP, #8, lsl #12  ; [pp+0x8c50] "lockScreen"
    //     0x13e9968: ldr             x2, [x2, #0xc50]
    // 0x13e996c: r0 = GDT[cid_x0 + -0xd48]()
    //     0x13e996c: sub             lr, x0, #0xd48
    //     0x13e9970: ldr             lr, [x21, lr, lsl #3]
    //     0x13e9974: blr             lr
    // 0x13e9978: cmp             w0, NULL
    // 0x13e997c: b.eq            #0x13e99b0
    // 0x13e9980: r1 = LoadInt32Instr(r0)
    //     0x13e9980: sbfx            x1, x0, #1, #0x1f
    //     0x13e9984: tbz             w0, #0, #0x13e998c
    //     0x13e9988: ldur            x1, [x0, #7]
    // 0x13e998c: cmp             x1, #0
    // 0x13e9990: b.gt            #0x13e99a8
    // 0x13e9994: cmn             x1, #1
    // 0x13e9998: b.gt            #0x13e99b0
    // 0x13e999c: cmn             w0, #2
    // 0x13e99a0: b.ne            #0x13e99b0
    // 0x13e99a4: b               #0x13e99b0
    // 0x13e99a8: cmp             w0, #2
    // 0x13e99ac: b.eq            #0x13e99b0
    // 0x13e99b0: ldur            x3, [fp, #-8]
    // 0x13e99b4: r0 = LoadClassIdInstr(r3)
    //     0x13e99b4: ldur            x0, [x3, #-1]
    //     0x13e99b8: ubfx            x0, x0, #0xc, #0x14
    // 0x13e99bc: mov             x1, x3
    // 0x13e99c0: r2 = "notificationCenter"
    //     0x13e99c0: add             x2, PP, #8, lsl #12  ; [pp+0x8c58] "notificationCenter"
    //     0x13e99c4: ldr             x2, [x2, #0xc58]
    // 0x13e99c8: r0 = GDT[cid_x0 + -0xd48]()
    //     0x13e99c8: sub             lr, x0, #0xd48
    //     0x13e99cc: ldr             lr, [x21, lr, lsl #3]
    //     0x13e99d0: blr             lr
    // 0x13e99d4: cmp             w0, NULL
    // 0x13e99d8: b.eq            #0x13e9a0c
    // 0x13e99dc: r1 = LoadInt32Instr(r0)
    //     0x13e99dc: sbfx            x1, x0, #1, #0x1f
    //     0x13e99e0: tbz             w0, #0, #0x13e99e8
    //     0x13e99e4: ldur            x1, [x0, #7]
    // 0x13e99e8: cmp             x1, #0
    // 0x13e99ec: b.gt            #0x13e9a04
    // 0x13e99f0: cmn             x1, #1
    // 0x13e99f4: b.gt            #0x13e9a0c
    // 0x13e99f8: cmn             w0, #2
    // 0x13e99fc: b.ne            #0x13e9a0c
    // 0x13e9a00: b               #0x13e9a0c
    // 0x13e9a04: cmp             w0, #2
    // 0x13e9a08: b.eq            #0x13e9a0c
    // 0x13e9a0c: ldur            x3, [fp, #-8]
    // 0x13e9a10: r0 = LoadClassIdInstr(r3)
    //     0x13e9a10: ldur            x0, [x3, #-1]
    //     0x13e9a14: ubfx            x0, x0, #0xc, #0x14
    // 0x13e9a18: mov             x1, x3
    // 0x13e9a1c: r2 = "showPreviews"
    //     0x13e9a1c: add             x2, PP, #8, lsl #12  ; [pp+0x8c60] "showPreviews"
    //     0x13e9a20: ldr             x2, [x2, #0xc60]
    // 0x13e9a24: r0 = GDT[cid_x0 + -0xd48]()
    //     0x13e9a24: sub             lr, x0, #0xd48
    //     0x13e9a28: ldr             lr, [x21, lr, lsl #3]
    //     0x13e9a2c: blr             lr
    // 0x13e9a30: ldur            x3, [fp, #-8]
    // 0x13e9a34: r0 = LoadClassIdInstr(r3)
    //     0x13e9a34: ldur            x0, [x3, #-1]
    //     0x13e9a38: ubfx            x0, x0, #0xc, #0x14
    // 0x13e9a3c: mov             x1, x3
    // 0x13e9a40: r2 = "sound"
    //     0x13e9a40: ldr             x2, [PP, #0x65c8]  ; [pp+0x65c8] "sound"
    // 0x13e9a44: r0 = GDT[cid_x0 + -0xd48]()
    //     0x13e9a44: sub             lr, x0, #0xd48
    //     0x13e9a48: ldr             lr, [x21, lr, lsl #3]
    //     0x13e9a4c: blr             lr
    // 0x13e9a50: cmp             w0, NULL
    // 0x13e9a54: b.eq            #0x13e9a88
    // 0x13e9a58: r1 = LoadInt32Instr(r0)
    //     0x13e9a58: sbfx            x1, x0, #1, #0x1f
    //     0x13e9a5c: tbz             w0, #0, #0x13e9a64
    //     0x13e9a60: ldur            x1, [x0, #7]
    // 0x13e9a64: cmp             x1, #0
    // 0x13e9a68: b.gt            #0x13e9a80
    // 0x13e9a6c: cmn             x1, #1
    // 0x13e9a70: b.gt            #0x13e9a88
    // 0x13e9a74: cmn             w0, #2
    // 0x13e9a78: b.ne            #0x13e9a88
    // 0x13e9a7c: b               #0x13e9a88
    // 0x13e9a80: cmp             w0, #2
    // 0x13e9a84: b.eq            #0x13e9a88
    // 0x13e9a88: ldur            x1, [fp, #-8]
    // 0x13e9a8c: r0 = LoadClassIdInstr(r1)
    //     0x13e9a8c: ldur            x0, [x1, #-1]
    //     0x13e9a90: ubfx            x0, x0, #0xc, #0x14
    // 0x13e9a94: r2 = "providesAppNotificationSettings"
    //     0x13e9a94: add             x2, PP, #8, lsl #12  ; [pp+0x8c28] "providesAppNotificationSettings"
    //     0x13e9a98: ldr             x2, [x2, #0xc28]
    // 0x13e9a9c: r0 = GDT[cid_x0 + -0xd48]()
    //     0x13e9a9c: sub             lr, x0, #0xd48
    //     0x13e9aa0: ldr             lr, [x21, lr, lsl #3]
    //     0x13e9aa4: blr             lr
    // 0x13e9aa8: cmp             w0, NULL
    // 0x13e9aac: b.eq            #0x13e9ae0
    // 0x13e9ab0: r1 = LoadInt32Instr(r0)
    //     0x13e9ab0: sbfx            x1, x0, #1, #0x1f
    //     0x13e9ab4: tbz             w0, #0, #0x13e9abc
    //     0x13e9ab8: ldur            x1, [x0, #7]
    // 0x13e9abc: cmp             x1, #0
    // 0x13e9ac0: b.gt            #0x13e9ad8
    // 0x13e9ac4: cmn             x1, #1
    // 0x13e9ac8: b.gt            #0x13e9ae0
    // 0x13e9acc: cmn             w0, #2
    // 0x13e9ad0: b.ne            #0x13e9ae0
    // 0x13e9ad4: b               #0x13e9ae0
    // 0x13e9ad8: cmp             w0, #2
    // 0x13e9adc: b.eq            #0x13e9ae0
    // 0x13e9ae0: r0 = NotificationSettings()
    //     0x13e9ae0: bl              #0x13e9af8  ; AllocateNotificationSettingsStub -> NotificationSettings (size=0x8)
    // 0x13e9ae4: LeaveFrame
    //     0x13e9ae4: mov             SP, fp
    //     0x13e9ae8: ldp             fp, lr, [SP], #0x10
    // 0x13e9aec: ret
    //     0x13e9aec: ret             
    // 0x13e9af0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13e9af0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13e9af4: b               #0x13e96d0
  }
}
