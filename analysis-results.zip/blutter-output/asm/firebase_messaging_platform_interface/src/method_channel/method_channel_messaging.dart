// lib: , url: package:firebase_messaging_platform_interface/src/method_channel/method_channel_messaging.dart

// class id: 1048753, size: 0x8
class :: {

  static void _firebaseMessagingCallbackDispatcher() {
    // ** addr: 0x922e20, size: 0x68
    // 0x922e20: EnterFrame
    //     0x922e20: stp             fp, lr, [SP, #-0x10]!
    //     0x922e24: mov             fp, SP
    // 0x922e28: AllocStack(0x18)
    //     0x922e28: sub             SP, SP, #0x18
    // 0x922e2c: CheckStackOverflow
    //     0x922e2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x922e30: cmp             SP, x16
    //     0x922e34: b.ls            #0x922e80
    // 0x922e38: r0 = ensureInitialized()
    //     0x922e38: bl              #0x8397cc  ; [package:flutter/src/widgets/binding.dart] WidgetsFlutterBinding::ensureInitialized
    // 0x922e3c: r1 = Function '<anonymous closure>': static.
    //     0x922e3c: ldr             x1, [PP, #0x6240]  ; [pp+0x6240] AnonymousClosure: static (0x922e88), in [package:firebase_messaging_platform_interface/src/method_channel/method_channel_messaging.dart] ::_firebaseMessagingCallbackDispatcher (0x922e20)
    // 0x922e40: r2 = Null
    //     0x922e40: mov             x2, NULL
    // 0x922e44: r0 = AllocateClosure()
    //     0x922e44: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x922e48: mov             x2, x0
    // 0x922e4c: r1 = Instance_MethodChannel
    //     0x922e4c: ldr             x1, [PP, #0x6248]  ; [pp+0x6248] Obj!MethodChannel@129bb61
    // 0x922e50: r0 = setMethodCallHandler()
    //     0x922e50: bl              #0x83aa3c  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::setMethodCallHandler
    // 0x922e54: r16 = <void?>
    //     0x922e54: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x922e58: r30 = Instance_MethodChannel
    //     0x922e58: ldr             lr, [PP, #0x6248]  ; [pp+0x6248] Obj!MethodChannel@129bb61
    // 0x922e5c: stp             lr, x16, [SP, #8]
    // 0x922e60: r16 = "MessagingBackground#initialized"
    //     0x922e60: ldr             x16, [PP, #0x6250]  ; [pp+0x6250] "MessagingBackground#initialized"
    // 0x922e64: str             x16, [SP]
    // 0x922e68: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x922e68: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x922e6c: r0 = invokeMethod()
    //     0x922e6c: bl              #0x130b008  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0x922e70: r0 = Null
    //     0x922e70: mov             x0, NULL
    // 0x922e74: LeaveFrame
    //     0x922e74: mov             SP, fp
    //     0x922e78: ldp             fp, lr, [SP], #0x10
    // 0x922e7c: ret
    //     0x922e7c: ret             
    // 0x922e80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x922e80: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x922e84: b               #0x922e38
  }
  [closure] static Future<Null> <anonymous closure>(dynamic, MethodCall) async {
    // ** addr: 0x922e88, size: 0x230
    // 0x922e88: EnterFrame
    //     0x922e88: stp             fp, lr, [SP, #-0x10]!
    //     0x922e8c: mov             fp, SP
    // 0x922e90: AllocStack(0xb8)
    //     0x922e90: sub             SP, SP, #0xb8
    // 0x922e94: SetupParameters(dynamic _ /* r1 */, dynamic _ /* r2, fp-0x78 */)
    //     0x922e94: stur            NULL, [fp, #-8]
    //     0x922e98: mov             x0, #0
    //     0x922e9c: add             x1, fp, w0, sxtw #2
    //     0x922ea0: ldr             x1, [x1, #0x18]
    //     0x922ea4: add             x2, fp, w0, sxtw #2
    //     0x922ea8: ldr             x2, [x2, #0x10]
    //     0x922eac: stur            x2, [fp, #-0x78]
    //     0x922eb0: ldur            w3, [x1, #0x17]
    //     0x922eb4: add             x3, x3, HEAP, lsl #32
    //     0x922eb8: stur            x3, [fp, #-0x70]
    // 0x922ebc: CheckStackOverflow
    //     0x922ebc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x922ec0: cmp             SP, x16
    //     0x922ec4: b.ls            #0x9230ac
    // 0x922ec8: InitAsync() -> Future<Null?>?
    //     0x922ec8: ldr             x0, [PP, #0x70]  ; [pp+0x70] TypeArguments: <Null?>
    //     0x922ecc: bl              #0x7f5e44  ; InitAsyncStub
    // 0x922ed0: ldur            x1, [fp, #-0x78]
    // 0x922ed4: LoadField: r2 = r1->field_7
    //     0x922ed4: ldur            w2, [x1, #7]
    // 0x922ed8: DecompressPointer r2
    //     0x922ed8: add             x2, x2, HEAP, lsl #32
    // 0x922edc: stur            x2, [fp, #-0x80]
    // 0x922ee0: r0 = LoadClassIdInstr(r2)
    //     0x922ee0: ldur            x0, [x2, #-1]
    //     0x922ee4: ubfx            x0, x0, #0xc, #0x14
    // 0x922ee8: r16 = "MessagingBackground#onMessage"
    //     0x922ee8: ldr             x16, [PP, #0x6258]  ; [pp+0x6258] "MessagingBackground#onMessage"
    // 0x922eec: stp             x16, x2, [SP]
    // 0x922ef0: mov             lr, x0
    // 0x922ef4: ldr             lr, [x21, lr, lsl #3]
    // 0x922ef8: blr             lr
    // 0x922efc: tbnz            w0, #4, #0x923060
    // 0x922f00: ldur            x0, [fp, #-0x78]
    // 0x922f04: LoadField: r1 = r0->field_b
    //     0x922f04: ldur            w1, [x0, #0xb]
    // 0x922f08: DecompressPointer r1
    //     0x922f08: add             x1, x1, HEAP, lsl #32
    // 0x922f0c: stur            x1, [fp, #-0x88]
    // 0x922f10: r16 = "userCallbackHandle"
    //     0x922f10: ldr             x16, [PP, #0x6260]  ; [pp+0x6260] "userCallbackHandle"
    // 0x922f14: stp             x16, x1, [SP]
    // 0x922f18: r4 = 0
    //     0x922f18: mov             x4, #0
    // 0x922f1c: ldr             x0, [SP, #8]
    // 0x922f20: r16 = 139822029843448
    //     0x922f20: add             x16, PP, #6, lsl #12  ; [pp+0x6268] IMM: 0x7f2ada6babf8
    //     0x922f24: add             x16, x16, #0x268
    // 0x922f28: ldp             lr, x5, [x16]
    // 0x922f2c: blr             lr
    // 0x922f30: mov             x3, x0
    // 0x922f34: r2 = Null
    //     0x922f34: mov             x2, NULL
    // 0x922f38: r1 = Null
    //     0x922f38: mov             x1, NULL
    // 0x922f3c: stur            x3, [fp, #-0x90]
    // 0x922f40: branchIfSmi(r0, 0x922f64)
    //     0x922f40: tbz             w0, #0, #0x922f64
    // 0x922f44: r4 = LoadClassIdInstr(r0)
    //     0x922f44: ldur            x4, [x0, #-1]
    //     0x922f48: ubfx            x4, x4, #0xc, #0x14
    // 0x922f4c: sub             x4, x4, #0x3c
    // 0x922f50: cmp             x4, #1
    // 0x922f54: b.ls            #0x922f64
    // 0x922f58: r8 = int
    //     0x922f58: ldr             x8, [PP, #0x390]  ; [pp+0x390] Type: int
    // 0x922f5c: r3 = Null
    //     0x922f5c: ldr             x3, [PP, #0x6278]  ; [pp+0x6278] Null
    // 0x922f60: r0 = int()
    //     0x922f60: bl              #0x13ee980  ; IsType_int_Stub
    // 0x922f64: ldur            x0, [fp, #-0x90]
    // 0x922f68: r1 = LoadInt32Instr(r0)
    //     0x922f68: sbfx            x1, x0, #1, #0x1f
    //     0x922f6c: tbz             w0, #0, #0x922f74
    //     0x922f70: ldur            x1, [x0, #7]
    // 0x922f74: stur            x1, [fp, #-0x98]
    // 0x922f78: r0 = CallbackHandle()
    //     0x922f78: bl              #0x8cac08  ; AllocateCallbackHandleStub -> CallbackHandle (size=0x10)
    // 0x922f7c: mov             x1, x0
    // 0x922f80: ldur            x0, [fp, #-0x98]
    // 0x922f84: StoreField: r1->field_7 = r0
    //     0x922f84: stur            x0, [x1, #7]
    // 0x922f88: r0 = getCallbackFromHandle()
    //     0x922f88: bl              #0x9248ac  ; [dart:ui] PluginUtilities::getCallbackFromHandle
    // 0x922f8c: mov             x3, x0
    // 0x922f90: stur            x3, [fp, #-0x90]
    // 0x922f94: cmp             w3, NULL
    // 0x922f98: b.eq            #0x9230b4
    // 0x922f9c: mov             x0, x3
    // 0x922fa0: r2 = Null
    //     0x922fa0: mov             x2, NULL
    // 0x922fa4: r1 = Null
    //     0x922fa4: mov             x1, NULL
    // 0x922fa8: r8 = (dynamic this, RemoteMessage) => Future<void?>
    //     0x922fa8: ldr             x8, [PP, #0x6288]  ; [pp+0x6288] FunctionType: (dynamic this, RemoteMessage) => Future<void?>
    // 0x922fac: r3 = Null
    //     0x922fac: ldr             x3, [PP, #0x6290]  ; [pp+0x6290] Null
    // 0x922fb0: r0 = DefaultTypeTest()
    //     0x922fb0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x922fb4: ldur            x16, [fp, #-0x88]
    // 0x922fb8: r30 = "message"
    //     0x922fb8: ldr             lr, [PP, #0x62a0]  ; [pp+0x62a0] "message"
    // 0x922fbc: stp             lr, x16, [SP]
    // 0x922fc0: r4 = 0
    //     0x922fc0: mov             x4, #0
    // 0x922fc4: ldr             x0, [SP, #8]
    // 0x922fc8: r16 = 139822029843448
    //     0x922fc8: add             x16, PP, #6, lsl #12  ; [pp+0x62a8] IMM: 0x7f2ada6babf8
    //     0x922fcc: add             x16, x16, #0x2a8
    // 0x922fd0: ldp             lr, x5, [x16]
    // 0x922fd4: blr             lr
    // 0x922fd8: mov             x3, x0
    // 0x922fdc: r2 = Null
    //     0x922fdc: mov             x2, NULL
    // 0x922fe0: r1 = Null
    //     0x922fe0: mov             x1, NULL
    // 0x922fe4: stur            x3, [fp, #-0x88]
    // 0x922fe8: r8 = Map
    //     0x922fe8: ldr             x8, [PP, #0x1c8]  ; [pp+0x1c8] Type: Map
    // 0x922fec: r3 = Null
    //     0x922fec: ldr             x3, [PP, #0x62b8]  ; [pp+0x62b8] Null
    // 0x922ff0: r0 = Map()
    //     0x922ff0: bl              #0x13efa40  ; IsType_Map_Stub
    // 0x922ff4: ldur            x2, [fp, #-0x88]
    // 0x922ff8: r1 = <String, dynamic>
    //     0x922ff8: ldr             x1, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x922ffc: r0 = LinkedHashMap.from()
    //     0x922ffc: bl              #0x8ac2e4  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x923000: mov             x2, x0
    // 0x923004: r1 = Null
    //     0x923004: mov             x1, NULL
    // 0x923008: stur            x0, [fp, #-0x88]
    // 0x92300c: r0 = RemoteMessage.fromMap()
    //     0x92300c: bl              #0x9230b8  ; [package:firebase_messaging_platform_interface/src/remote_message.dart] RemoteMessage::RemoteMessage.fromMap
    // 0x923010: mov             x1, x0
    // 0x923014: stur            x1, [fp, #-0xa0]
    // 0x923018: ldur            x16, [fp, #-0x90]
    // 0x92301c: stp             x1, x16, [SP]
    // 0x923020: ldur            x0, [fp, #-0x90]
    // 0x923024: ClosureCall
    //     0x923024: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x923028: ldur            x2, [x0, #0x1f]
    //     0x92302c: blr             x2
    // 0x923030: mov             x1, x0
    // 0x923034: stur            x1, [fp, #-0xa8]
    // 0x923038: r0 = Await()
    //     0x923038: bl              #0x7f5c00  ; AwaitStub
    // 0x92303c: b               #0x923058
    // 0x923040: sub             SP, fp, #0xb8
    // 0x923044: stur            x0, [fp, #-0x70]
    // 0x923048: r1 = "FlutterFire Messaging: An error occurred in your background messaging handler:"
    //     0x923048: ldr             x1, [PP, #0x62c8]  ; [pp+0x62c8] "FlutterFire Messaging: An error occurred in your background messaging handler:"
    // 0x92304c: r0 = print()
    //     0x92304c: bl              #0x82a3d4  ; [dart:core] ::print
    // 0x923050: ldur            x1, [fp, #-0x70]
    // 0x923054: r0 = print()
    //     0x923054: bl              #0x82a3d4  ; [dart:core] ::print
    // 0x923058: r0 = Null
    //     0x923058: mov             x0, NULL
    // 0x92305c: r0 = ReturnAsyncNotFuture()
    //     0x92305c: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x923060: ldur            x0, [fp, #-0x80]
    // 0x923064: r1 = Null
    //     0x923064: mov             x1, NULL
    // 0x923068: r2 = 4
    //     0x923068: mov             x2, #4
    // 0x92306c: r0 = AllocateArray()
    //     0x92306c: bl              #0x13df928  ; AllocateArrayStub
    // 0x923070: mov             x1, x0
    // 0x923074: ldur            x0, [fp, #-0x80]
    // 0x923078: StoreField: r1->field_f = r0
    //     0x923078: stur            w0, [x1, #0xf]
    // 0x92307c: r16 = " has not been implemented"
    //     0x92307c: ldr             x16, [PP, #0x62d0]  ; [pp+0x62d0] " has not been implemented"
    // 0x923080: StoreField: r1->field_13 = r16
    //     0x923080: stur            w16, [x1, #0x13]
    // 0x923084: str             x1, [SP]
    // 0x923088: r0 = _interpolate()
    //     0x923088: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x92308c: stur            x0, [fp, #-0x70]
    // 0x923090: r0 = UnimplementedError()
    //     0x923090: bl              #0x7dd7c4  ; AllocateUnimplementedErrorStub -> UnimplementedError (size=0x10)
    // 0x923094: mov             x1, x0
    // 0x923098: ldur            x0, [fp, #-0x70]
    // 0x92309c: StoreField: r1->field_b = r0
    //     0x92309c: stur            w0, [x1, #0xb]
    // 0x9230a0: mov             x0, x1
    // 0x9230a4: r0 = Throw()
    //     0x9230a4: bl              #0x13ddb2c  ; ThrowStub
    // 0x9230a8: brk             #0
    // 0x9230ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9230ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9230b0: b               #0x922ec8
    // 0x9230b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9230b4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] static void _firebaseMessagingCallbackDispatcher(dynamic) {
    // ** addr: 0x924b80, size: 0x2c
    // 0x924b80: EnterFrame
    //     0x924b80: stp             fp, lr, [SP, #-0x10]!
    //     0x924b84: mov             fp, SP
    // 0x924b88: CheckStackOverflow
    //     0x924b88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x924b8c: cmp             SP, x16
    //     0x924b90: b.ls            #0x924ba4
    // 0x924b94: r0 = _firebaseMessagingCallbackDispatcher()
    //     0x924b94: bl              #0x922e20  ; [package:firebase_messaging_platform_interface/src/method_channel/method_channel_messaging.dart] ::_firebaseMessagingCallbackDispatcher
    // 0x924b98: LeaveFrame
    //     0x924b98: mov             SP, fp
    //     0x924b9c: ldp             fp, lr, [SP], #0x10
    // 0x924ba0: ret
    //     0x924ba0: ret             
    // 0x924ba4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x924ba4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x924ba8: b               #0x924b94
  }
}

// class id: 3698, size: 0xc, field offset: 0xc
class MethodChannelFirebaseMessaging extends FirebaseMessagingPlatform {

  static late StreamController<String> tokenStreamController; // offset: 0x110c

  _ getToken(/* No info */) async {
    // ** addr: 0x922c90, size: 0x148
    // 0x922c90: EnterFrame
    //     0x922c90: stp             fp, lr, [SP, #-0x10]!
    //     0x922c94: mov             fp, SP
    // 0x922c98: AllocStack(0x88)
    //     0x922c98: sub             SP, SP, #0x88
    // 0x922c9c: SetupParameters(MethodChannelFirebaseMessaging this /* r1 => r1, fp-0x60 */)
    //     0x922c9c: stur            NULL, [fp, #-8]
    //     0x922ca0: stur            x1, [fp, #-0x60]
    // 0x922ca4: CheckStackOverflow
    //     0x922ca4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x922ca8: cmp             SP, x16
    //     0x922cac: b.ls            #0x922dcc
    // 0x922cb0: InitAsync() -> Future<String?>
    //     0x922cb0: ldr             x0, [PP, #0xe28]  ; [pp+0xe28] TypeArguments: <String?>
    //     0x922cb4: bl              #0x7f5e44  ; InitAsyncStub
    // 0x922cb8: ldur            x1, [fp, #-0x60]
    // 0x922cbc: r0 = activate()
    //     0x922cbc: bl              #0x1309aa0  ; [package:flutter/src/services/mouse_cursor.dart] _NoopMouseCursorSession::activate
    // 0x922cc0: mov             x1, x0
    // 0x922cc4: stur            x1, [fp, #-0x68]
    // 0x922cc8: r0 = Await()
    //     0x922cc8: bl              #0x7f5c00  ; AwaitStub
    // 0x922ccc: ldur            x0, [fp, #-0x60]
    // 0x922cd0: r1 = Null
    //     0x922cd0: mov             x1, NULL
    // 0x922cd4: r2 = 4
    //     0x922cd4: mov             x2, #4
    // 0x922cd8: r0 = AllocateArray()
    //     0x922cd8: bl              #0x13df928  ; AllocateArrayStub
    // 0x922cdc: stur            x0, [fp, #-0x68]
    // 0x922ce0: r16 = "appName"
    //     0x922ce0: add             x16, PP, #8, lsl #12  ; [pp+0x8bb0] "appName"
    //     0x922ce4: ldr             x16, [x16, #0xbb0]
    // 0x922ce8: StoreField: r0->field_f = r16
    //     0x922ce8: stur            w16, [x0, #0xf]
    // 0x922cec: ldur            x1, [fp, #-0x60]
    // 0x922cf0: LoadField: r2 = r1->field_7
    //     0x922cf0: ldur            w2, [x1, #7]
    // 0x922cf4: DecompressPointer r2
    //     0x922cf4: add             x2, x2, HEAP, lsl #32
    // 0x922cf8: cmp             w2, NULL
    // 0x922cfc: b.ne            #0x922d08
    // 0x922d00: r0 = app()
    //     0x922d00: bl              #0x8c0c7c  ; [package:firebase_core/firebase_core.dart] Firebase::app
    // 0x922d04: b               #0x922d0c
    // 0x922d08: mov             x0, x2
    // 0x922d0c: LoadField: r1 = r0->field_7
    //     0x922d0c: ldur            w1, [x0, #7]
    // 0x922d10: DecompressPointer r1
    //     0x922d10: add             x1, x1, HEAP, lsl #32
    // 0x922d14: LoadField: r0 = r1->field_7
    //     0x922d14: ldur            w0, [x1, #7]
    // 0x922d18: DecompressPointer r0
    //     0x922d18: add             x0, x0, HEAP, lsl #32
    // 0x922d1c: ldur            x1, [fp, #-0x68]
    // 0x922d20: ArrayStore: r1[1] = r0  ; List_4
    //     0x922d20: add             x25, x1, #0x13
    //     0x922d24: str             w0, [x25]
    //     0x922d28: tbz             w0, #0, #0x922d44
    //     0x922d2c: ldurb           w16, [x1, #-1]
    //     0x922d30: ldurb           w17, [x0, #-1]
    //     0x922d34: and             x16, x17, x16, lsr #2
    //     0x922d38: tst             x16, HEAP, lsr #32
    //     0x922d3c: b.eq            #0x922d44
    //     0x922d40: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x922d44: r16 = <String, String>
    //     0x922d44: ldr             x16, [PP, #0x7c88]  ; [pp+0x7c88] TypeArguments: <String, String>
    // 0x922d48: ldur            lr, [fp, #-0x68]
    // 0x922d4c: stp             lr, x16, [SP]
    // 0x922d50: r0 = Map._fromLiteral()
    //     0x922d50: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x922d54: r16 = <String, String>
    //     0x922d54: ldr             x16, [PP, #0x7c88]  ; [pp+0x7c88] TypeArguments: <String, String>
    // 0x922d58: r30 = Instance_MethodChannel
    //     0x922d58: add             lr, PP, #8, lsl #12  ; [pp+0x8af0] Obj!MethodChannel@129bb81
    //     0x922d5c: ldr             lr, [lr, #0xaf0]
    // 0x922d60: stp             lr, x16, [SP, #0x10]
    // 0x922d64: r16 = "Messaging#getToken"
    //     0x922d64: add             x16, PP, #8, lsl #12  ; [pp+0x8be0] "Messaging#getToken"
    //     0x922d68: ldr             x16, [x16, #0xbe0]
    // 0x922d6c: stp             x0, x16, [SP]
    // 0x922d70: r4 = const [0x2, 0x3, 0x3, 0x3, null]
    //     0x922d70: ldr             x4, [PP, #0x3738]  ; [pp+0x3738] List(5) [0x2, 0x3, 0x3, 0x3, Null]
    // 0x922d74: r0 = invokeMapMethod()
    //     0x922d74: bl              #0x8492b0  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMapMethod
    // 0x922d78: mov             x1, x0
    // 0x922d7c: stur            x1, [fp, #-0x68]
    // 0x922d80: r0 = Await()
    //     0x922d80: bl              #0x7f5c00  ; AwaitStub
    // 0x922d84: mov             x3, x0
    // 0x922d88: stur            x3, [fp, #-0x68]
    // 0x922d8c: cmp             w3, NULL
    // 0x922d90: b.eq            #0x922dd4
    // 0x922d94: r0 = LoadClassIdInstr(r3)
    //     0x922d94: ldur            x0, [x3, #-1]
    //     0x922d98: ubfx            x0, x0, #0xc, #0x14
    // 0x922d9c: mov             x1, x3
    // 0x922da0: r2 = "token"
    //     0x922da0: add             x2, PP, #8, lsl #12  ; [pp+0x8be8] "token"
    //     0x922da4: ldr             x2, [x2, #0xbe8]
    // 0x922da8: r0 = GDT[cid_x0 + -0xd48]()
    //     0x922da8: sub             lr, x0, #0xd48
    //     0x922dac: ldr             lr, [x21, lr, lsl #3]
    //     0x922db0: blr             lr
    // 0x922db4: r0 = ReturnAsync()
    //     0x922db4: b               #0x82fdf0  ; ReturnAsyncStub
    // 0x922db8: sub             SP, fp, #0x88
    // 0x922dbc: mov             x2, x1
    // 0x922dc0: mov             x1, x0
    // 0x922dc4: r0 = convertPlatformException()
    //     0x922dc4: bl              #0x924bac  ; [package:firebase_messaging_platform_interface/src/method_channel/utils/exception.dart] ::convertPlatformException
    // 0x922dc8: brk             #0
    // 0x922dcc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x922dcc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x922dd0: b               #0x922cb0
    // 0x922dd4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x922dd4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ delegateFor(/* No info */) {
    // ** addr: 0x924d28, size: 0x98
    // 0x924d28: EnterFrame
    //     0x924d28: stp             fp, lr, [SP, #-0x10]!
    //     0x924d2c: mov             fp, SP
    // 0x924d30: AllocStack(0x10)
    //     0x924d30: sub             SP, SP, #0x10
    // 0x924d34: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x924d34: stur            x2, [fp, #-8]
    // 0x924d38: CheckStackOverflow
    //     0x924d38: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x924d3c: cmp             SP, x16
    //     0x924d40: b.ls            #0x924db8
    // 0x924d44: r0 = MethodChannelFirebaseMessaging()
    //     0x924d44: bl              #0x924dc0  ; AllocateMethodChannelFirebaseMessagingStub -> MethodChannelFirebaseMessaging (size=0xc)
    // 0x924d48: mov             x1, x0
    // 0x924d4c: ldur            x0, [fp, #-8]
    // 0x924d50: stur            x1, [fp, #-0x10]
    // 0x924d54: StoreField: r1->field_7 = r0
    //     0x924d54: stur            w0, [x1, #7]
    // 0x924d58: r0 = LoadStaticField(0x10e0)
    //     0x924d58: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x924d5c: ldr             x0, [x0, #0x21c0]
    // 0x924d60: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x924d64: cmp             w0, w16
    // 0x924d68: b.ne            #0x924d78
    // 0x924d6c: r2 = _token
    //     0x924d6c: add             x2, PP, #8, lsl #12  ; [pp+0x8b28] Field <FirebaseMessagingPlatform._token@1291004436>: static late final (offset: 0x10e0)
    //     0x924d70: ldr             x2, [x2, #0xb28]
    // 0x924d74: r0 = InitLateFinalStaticField()
    //     0x924d74: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x924d78: stur            x0, [fp, #-8]
    // 0x924d7c: r0 = LoadStaticField(0xde8)
    //     0x924d7c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x924d80: ldr             x0, [x0, #0x1bd0]
    // 0x924d84: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x924d88: cmp             w0, w16
    // 0x924d8c: b.ne            #0x924d98
    // 0x924d90: r2 = _instanceTokens
    //     0x924d90: ldr             x2, [PP, #0x68c0]  ; [pp+0x68c0] Field <PlatformInterface._instanceTokens@1171304592>: static late final (offset: 0xde8)
    // 0x924d94: r0 = InitLateFinalStaticField()
    //     0x924d94: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x924d98: mov             x1, x0
    // 0x924d9c: ldur            x2, [fp, #-0x10]
    // 0x924da0: ldur            x3, [fp, #-8]
    // 0x924da4: r0 = []=()
    //     0x924da4: bl              #0x7f6290  ; [dart:core] Expando::[]=
    // 0x924da8: ldur            x0, [fp, #-0x10]
    // 0x924dac: LeaveFrame
    //     0x924dac: mov             SP, fp
    //     0x924db0: ldp             fp, lr, [SP], #0x10
    // 0x924db4: ret
    //     0x924db4: ret             
    // 0x924db8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x924db8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x924dbc: b               #0x924d44
  }
  get _ instance(/* No info */) {
    // ** addr: 0x924e28, size: 0x8c
    // 0x924e28: EnterFrame
    //     0x924e28: stp             fp, lr, [SP, #-0x10]!
    //     0x924e2c: mov             fp, SP
    // 0x924e30: AllocStack(0x10)
    //     0x924e30: sub             SP, SP, #0x10
    // 0x924e34: CheckStackOverflow
    //     0x924e34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x924e38: cmp             SP, x16
    //     0x924e3c: b.ls            #0x924eac
    // 0x924e40: r0 = LoadStaticField(0x10e0)
    //     0x924e40: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x924e44: ldr             x0, [x0, #0x21c0]
    // 0x924e48: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x924e4c: cmp             w0, w16
    // 0x924e50: b.ne            #0x924e60
    // 0x924e54: r2 = _token
    //     0x924e54: add             x2, PP, #8, lsl #12  ; [pp+0x8b28] Field <FirebaseMessagingPlatform._token@1291004436>: static late final (offset: 0x10e0)
    //     0x924e58: ldr             x2, [x2, #0xb28]
    // 0x924e5c: r0 = InitLateFinalStaticField()
    //     0x924e5c: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x924e60: stur            x0, [fp, #-8]
    // 0x924e64: r0 = LoadStaticField(0xde8)
    //     0x924e64: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x924e68: ldr             x0, [x0, #0x1bd0]
    // 0x924e6c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x924e70: cmp             w0, w16
    // 0x924e74: b.ne            #0x924e80
    // 0x924e78: r2 = _instanceTokens
    //     0x924e78: ldr             x2, [PP, #0x68c0]  ; [pp+0x68c0] Field <PlatformInterface._instanceTokens@1171304592>: static late final (offset: 0xde8)
    // 0x924e7c: r0 = InitLateFinalStaticField()
    //     0x924e7c: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x924e80: stur            x0, [fp, #-0x10]
    // 0x924e84: r0 = MethodChannelFirebaseMessaging()
    //     0x924e84: bl              #0x924dc0  ; AllocateMethodChannelFirebaseMessagingStub -> MethodChannelFirebaseMessaging (size=0xc)
    // 0x924e88: ldur            x1, [fp, #-0x10]
    // 0x924e8c: mov             x2, x0
    // 0x924e90: ldur            x3, [fp, #-8]
    // 0x924e94: stur            x0, [fp, #-8]
    // 0x924e98: r0 = []=()
    //     0x924e98: bl              #0x7f6290  ; [dart:core] Expando::[]=
    // 0x924e9c: ldur            x0, [fp, #-8]
    // 0x924ea0: LeaveFrame
    //     0x924ea0: mov             SP, fp
    //     0x924ea4: ldp             fp, lr, [SP], #0x10
    // 0x924ea8: ret
    //     0x924ea8: ret             
    // 0x924eac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x924eac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x924eb0: b               #0x924e40
  }
  static void setMethodCallHandlers() {
    // ** addr: 0x924eb4, size: 0x4c
    // 0x924eb4: EnterFrame
    //     0x924eb4: stp             fp, lr, [SP, #-0x10]!
    //     0x924eb8: mov             fp, SP
    // 0x924ebc: CheckStackOverflow
    //     0x924ebc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x924ec0: cmp             SP, x16
    //     0x924ec4: b.ls            #0x924ef8
    // 0x924ec8: r1 = Function '<anonymous closure>': static.
    //     0x924ec8: add             x1, PP, #8, lsl #12  ; [pp+0x8b30] AnonymousClosure: static (0x924f00), in [package:firebase_messaging_platform_interface/src/method_channel/method_channel_messaging.dart] MethodChannelFirebaseMessaging::setMethodCallHandlers (0x924eb4)
    //     0x924ecc: ldr             x1, [x1, #0xb30]
    // 0x924ed0: r2 = Null
    //     0x924ed0: mov             x2, NULL
    // 0x924ed4: r0 = AllocateClosure()
    //     0x924ed4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x924ed8: mov             x2, x0
    // 0x924edc: r1 = Instance_MethodChannel
    //     0x924edc: add             x1, PP, #8, lsl #12  ; [pp+0x8af0] Obj!MethodChannel@129bb81
    //     0x924ee0: ldr             x1, [x1, #0xaf0]
    // 0x924ee4: r0 = setMethodCallHandler()
    //     0x924ee4: bl              #0x83aa3c  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::setMethodCallHandler
    // 0x924ee8: r0 = Null
    //     0x924ee8: mov             x0, NULL
    // 0x924eec: LeaveFrame
    //     0x924eec: mov             SP, fp
    //     0x924ef0: ldp             fp, lr, [SP], #0x10
    // 0x924ef4: ret
    //     0x924ef4: ret             
    // 0x924ef8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x924ef8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x924efc: b               #0x924ec8
  }
  [closure] static Future<void> <anonymous closure>(dynamic, MethodCall) async {
    // ** addr: 0x924f00, size: 0x2fc
    // 0x924f00: EnterFrame
    //     0x924f00: stp             fp, lr, [SP, #-0x10]!
    //     0x924f04: mov             fp, SP
    // 0x924f08: AllocStack(0x38)
    //     0x924f08: sub             SP, SP, #0x38
    // 0x924f0c: SetupParameters(dynamic _ /* r1 */, dynamic _ /* r2, fp-0x18 */)
    //     0x924f0c: stur            NULL, [fp, #-8]
    //     0x924f10: mov             x0, #0
    //     0x924f14: add             x1, fp, w0, sxtw #2
    //     0x924f18: ldr             x1, [x1, #0x18]
    //     0x924f1c: add             x2, fp, w0, sxtw #2
    //     0x924f20: ldr             x2, [x2, #0x10]
    //     0x924f24: stur            x2, [fp, #-0x18]
    //     0x924f28: ldur            w3, [x1, #0x17]
    //     0x924f2c: add             x3, x3, HEAP, lsl #32
    //     0x924f30: stur            x3, [fp, #-0x10]
    // 0x924f34: CheckStackOverflow
    //     0x924f34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x924f38: cmp             SP, x16
    //     0x924f3c: b.ls            #0x9251f4
    // 0x924f40: InitAsync() -> Future<void?>
    //     0x924f40: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0x924f44: bl              #0x7f5e44  ; InitAsyncStub
    // 0x924f48: ldur            x0, [fp, #-0x18]
    // 0x924f4c: LoadField: r1 = r0->field_7
    //     0x924f4c: ldur            w1, [x0, #7]
    // 0x924f50: DecompressPointer r1
    //     0x924f50: add             x1, x1, HEAP, lsl #32
    // 0x924f54: stur            x1, [fp, #-0x10]
    // 0x924f58: r16 = "Messaging#onTokenRefresh"
    //     0x924f58: add             x16, PP, #8, lsl #12  ; [pp+0x8b38] "Messaging#onTokenRefresh"
    //     0x924f5c: ldr             x16, [x16, #0xb38]
    // 0x924f60: stp             x1, x16, [SP]
    // 0x924f64: r0 = ==()
    //     0x924f64: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x924f68: tbnz            w0, #4, #0x924ff0
    // 0x924f6c: ldur            x0, [fp, #-0x18]
    // 0x924f70: r0 = LoadStaticField(0x110c)
    //     0x924f70: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x924f74: ldr             x0, [x0, #0x2218]
    // 0x924f78: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x924f7c: cmp             w0, w16
    // 0x924f80: b.ne            #0x924f90
    // 0x924f84: r2 = tokenStreamController
    //     0x924f84: add             x2, PP, #8, lsl #12  ; [pp+0x8b40] Field <MethodChannelFirebaseMessaging.tokenStreamController>: static late (offset: 0x110c)
    //     0x924f88: ldr             x2, [x2, #0xb40]
    // 0x924f8c: r0 = InitLateStaticField()
    //     0x924f8c: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0x924f90: mov             x3, x0
    // 0x924f94: ldur            x0, [fp, #-0x18]
    // 0x924f98: stur            x3, [fp, #-0x28]
    // 0x924f9c: LoadField: r4 = r0->field_b
    //     0x924f9c: ldur            w4, [x0, #0xb]
    // 0x924fa0: DecompressPointer r4
    //     0x924fa0: add             x4, x4, HEAP, lsl #32
    // 0x924fa4: mov             x0, x4
    // 0x924fa8: stur            x4, [fp, #-0x20]
    // 0x924fac: r2 = Null
    //     0x924fac: mov             x2, NULL
    // 0x924fb0: r1 = Null
    //     0x924fb0: mov             x1, NULL
    // 0x924fb4: r4 = 60
    //     0x924fb4: mov             x4, #0x3c
    // 0x924fb8: branchIfSmi(r0, 0x924fc4)
    //     0x924fb8: tbz             w0, #0, #0x924fc4
    // 0x924fbc: r4 = LoadClassIdInstr(r0)
    //     0x924fbc: ldur            x4, [x0, #-1]
    //     0x924fc0: ubfx            x4, x4, #0xc, #0x14
    // 0x924fc4: sub             x4, x4, #0x5e
    // 0x924fc8: cmp             x4, #1
    // 0x924fcc: b.ls            #0x924fe0
    // 0x924fd0: r8 = String
    //     0x924fd0: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x924fd4: r3 = Null
    //     0x924fd4: add             x3, PP, #8, lsl #12  ; [pp+0x8b48] Null
    //     0x924fd8: ldr             x3, [x3, #0xb48]
    // 0x924fdc: r0 = String()
    //     0x924fdc: bl              #0x13ee320  ; IsType_String_Stub
    // 0x924fe0: ldur            x1, [fp, #-0x28]
    // 0x924fe4: ldur            x2, [fp, #-0x20]
    // 0x924fe8: r0 = add()
    //     0x924fe8: bl              #0x7df8d8  ; [dart:async] _BroadcastStreamController::add
    // 0x924fec: b               #0x92511c
    // 0x924ff0: ldur            x0, [fp, #-0x18]
    // 0x924ff4: r16 = "Messaging#onMessage"
    //     0x924ff4: add             x16, PP, #8, lsl #12  ; [pp+0x8b58] "Messaging#onMessage"
    //     0x924ff8: ldr             x16, [x16, #0xb58]
    // 0x924ffc: ldur            lr, [fp, #-0x10]
    // 0x925000: stp             lr, x16, [SP]
    // 0x925004: r0 = ==()
    //     0x925004: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x925008: tbnz            w0, #4, #0x925088
    // 0x92500c: ldur            x0, [fp, #-0x18]
    // 0x925010: LoadField: r3 = r0->field_b
    //     0x925010: ldur            w3, [x0, #0xb]
    // 0x925014: DecompressPointer r3
    //     0x925014: add             x3, x3, HEAP, lsl #32
    // 0x925018: mov             x0, x3
    // 0x92501c: stur            x3, [fp, #-0x20]
    // 0x925020: r2 = Null
    //     0x925020: mov             x2, NULL
    // 0x925024: r1 = Null
    //     0x925024: mov             x1, NULL
    // 0x925028: r8 = Map
    //     0x925028: ldr             x8, [PP, #0x1c8]  ; [pp+0x1c8] Type: Map
    // 0x92502c: r3 = Null
    //     0x92502c: add             x3, PP, #8, lsl #12  ; [pp+0x8b60] Null
    //     0x925030: ldr             x3, [x3, #0xb60]
    // 0x925034: r0 = Map()
    //     0x925034: bl              #0x13efa40  ; IsType_Map_Stub
    // 0x925038: ldur            x2, [fp, #-0x20]
    // 0x92503c: r1 = <String, dynamic>
    //     0x92503c: ldr             x1, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x925040: r0 = LinkedHashMap.from()
    //     0x925040: bl              #0x8ac2e4  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x925044: stur            x0, [fp, #-0x20]
    // 0x925048: r0 = LoadStaticField(0x10e8)
    //     0x925048: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x92504c: ldr             x0, [x0, #0x21d0]
    // 0x925050: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x925054: cmp             w0, w16
    // 0x925058: b.ne            #0x925068
    // 0x92505c: r2 = onMessage
    //     0x92505c: add             x2, PP, #8, lsl #12  ; [pp+0x8ab0] Field <FirebaseMessagingPlatform.onMessage>: static late final (offset: 0x10e8)
    //     0x925060: ldr             x2, [x2, #0xab0]
    // 0x925064: r0 = InitLateFinalStaticField()
    //     0x925064: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x925068: ldur            x2, [fp, #-0x20]
    // 0x92506c: r1 = Null
    //     0x92506c: mov             x1, NULL
    // 0x925070: stur            x0, [fp, #-0x20]
    // 0x925074: r0 = RemoteMessage.fromMap()
    //     0x925074: bl              #0x9230b8  ; [package:firebase_messaging_platform_interface/src/remote_message.dart] RemoteMessage::RemoteMessage.fromMap
    // 0x925078: ldur            x1, [fp, #-0x20]
    // 0x92507c: mov             x2, x0
    // 0x925080: r0 = add()
    //     0x925080: bl              #0x7df8d8  ; [dart:async] _BroadcastStreamController::add
    // 0x925084: b               #0x92511c
    // 0x925088: ldur            x0, [fp, #-0x18]
    // 0x92508c: r16 = "Messaging#onMessageOpenedApp"
    //     0x92508c: add             x16, PP, #8, lsl #12  ; [pp+0x8b70] "Messaging#onMessageOpenedApp"
    //     0x925090: ldr             x16, [x16, #0xb70]
    // 0x925094: ldur            lr, [fp, #-0x10]
    // 0x925098: stp             lr, x16, [SP]
    // 0x92509c: r0 = ==()
    //     0x92509c: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x9250a0: tbnz            w0, #4, #0x925124
    // 0x9250a4: ldur            x0, [fp, #-0x18]
    // 0x9250a8: LoadField: r3 = r0->field_b
    //     0x9250a8: ldur            w3, [x0, #0xb]
    // 0x9250ac: DecompressPointer r3
    //     0x9250ac: add             x3, x3, HEAP, lsl #32
    // 0x9250b0: mov             x0, x3
    // 0x9250b4: stur            x3, [fp, #-0x20]
    // 0x9250b8: r2 = Null
    //     0x9250b8: mov             x2, NULL
    // 0x9250bc: r1 = Null
    //     0x9250bc: mov             x1, NULL
    // 0x9250c0: r8 = Map
    //     0x9250c0: ldr             x8, [PP, #0x1c8]  ; [pp+0x1c8] Type: Map
    // 0x9250c4: r3 = Null
    //     0x9250c4: add             x3, PP, #8, lsl #12  ; [pp+0x8b78] Null
    //     0x9250c8: ldr             x3, [x3, #0xb78]
    // 0x9250cc: r0 = Map()
    //     0x9250cc: bl              #0x13efa40  ; IsType_Map_Stub
    // 0x9250d0: ldur            x2, [fp, #-0x20]
    // 0x9250d4: r1 = <String, dynamic>
    //     0x9250d4: ldr             x1, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x9250d8: r0 = LinkedHashMap.from()
    //     0x9250d8: bl              #0x8ac2e4  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x9250dc: stur            x0, [fp, #-0x20]
    // 0x9250e0: r0 = LoadStaticField(0x10ec)
    //     0x9250e0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x9250e4: ldr             x0, [x0, #0x21d8]
    // 0x9250e8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9250ec: cmp             w0, w16
    // 0x9250f0: b.ne            #0x925100
    // 0x9250f4: r2 = onMessageOpenedApp
    //     0x9250f4: add             x2, PP, #8, lsl #12  ; [pp+0x8b88] Field <FirebaseMessagingPlatform.onMessageOpenedApp>: static late final (offset: 0x10ec)
    //     0x9250f8: ldr             x2, [x2, #0xb88]
    // 0x9250fc: r0 = InitLateFinalStaticField()
    //     0x9250fc: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x925100: ldur            x2, [fp, #-0x20]
    // 0x925104: r1 = Null
    //     0x925104: mov             x1, NULL
    // 0x925108: stur            x0, [fp, #-0x20]
    // 0x92510c: r0 = RemoteMessage.fromMap()
    //     0x92510c: bl              #0x9230b8  ; [package:firebase_messaging_platform_interface/src/remote_message.dart] RemoteMessage::RemoteMessage.fromMap
    // 0x925110: ldur            x1, [fp, #-0x20]
    // 0x925114: mov             x2, x0
    // 0x925118: r0 = add()
    //     0x925118: bl              #0x7df8d8  ; [dart:async] _BroadcastStreamController::add
    // 0x92511c: r0 = Null
    //     0x92511c: mov             x0, NULL
    // 0x925120: r0 = ReturnAsyncNotFuture()
    //     0x925120: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x925124: ldur            x0, [fp, #-0x18]
    // 0x925128: r16 = "Messaging#onBackgroundMessage"
    //     0x925128: add             x16, PP, #8, lsl #12  ; [pp+0x8b90] "Messaging#onBackgroundMessage"
    //     0x92512c: ldr             x16, [x16, #0xb90]
    // 0x925130: ldur            lr, [fp, #-0x10]
    // 0x925134: stp             lr, x16, [SP]
    // 0x925138: r0 = ==()
    //     0x925138: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x92513c: tbnz            w0, #4, #0x9251a8
    // 0x925140: ldur            x0, [fp, #-0x18]
    // 0x925144: LoadField: r3 = r0->field_b
    //     0x925144: ldur            w3, [x0, #0xb]
    // 0x925148: DecompressPointer r3
    //     0x925148: add             x3, x3, HEAP, lsl #32
    // 0x92514c: mov             x0, x3
    // 0x925150: stur            x3, [fp, #-0x20]
    // 0x925154: r2 = Null
    //     0x925154: mov             x2, NULL
    // 0x925158: r1 = Null
    //     0x925158: mov             x1, NULL
    // 0x92515c: r8 = Map
    //     0x92515c: ldr             x8, [PP, #0x1c8]  ; [pp+0x1c8] Type: Map
    // 0x925160: r3 = Null
    //     0x925160: add             x3, PP, #8, lsl #12  ; [pp+0x8b98] Null
    //     0x925164: ldr             x3, [x3, #0xb98]
    // 0x925168: r0 = Map()
    //     0x925168: bl              #0x13efa40  ; IsType_Map_Stub
    // 0x92516c: ldur            x2, [fp, #-0x20]
    // 0x925170: r1 = <String, dynamic>
    //     0x925170: ldr             x1, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x925174: r0 = LinkedHashMap.from()
    //     0x925174: bl              #0x8ac2e4  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x925178: r1 = LoadStaticField(0x10f0)
    //     0x925178: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x92517c: ldr             x1, [x1, #0x21e0]
    // 0x925180: cmp             w1, NULL
    // 0x925184: b.ne            #0x925190
    // 0x925188: r0 = Null
    //     0x925188: mov             x0, NULL
    // 0x92518c: b               #0x9251a4
    // 0x925190: mov             x2, x0
    // 0x925194: r1 = Null
    //     0x925194: mov             x1, NULL
    // 0x925198: r0 = RemoteMessage.fromMap()
    //     0x925198: bl              #0x9230b8  ; [package:firebase_messaging_platform_interface/src/remote_message.dart] RemoteMessage::RemoteMessage.fromMap
    // 0x92519c: mov             x1, x0
    // 0x9251a0: r0 = handleBackgroundMessage()
    //     0x9251a0: bl              #0x92522c  ; [package:simaster_ugm/app/data/firebase/firebase_api.dart] ::handleBackgroundMessage
    // 0x9251a4: r0 = ReturnAsync()
    //     0x9251a4: b               #0x82fdf0  ; ReturnAsyncStub
    // 0x9251a8: ldur            x0, [fp, #-0x10]
    // 0x9251ac: r1 = Null
    //     0x9251ac: mov             x1, NULL
    // 0x9251b0: r2 = 4
    //     0x9251b0: mov             x2, #4
    // 0x9251b4: r0 = AllocateArray()
    //     0x9251b4: bl              #0x13df928  ; AllocateArrayStub
    // 0x9251b8: mov             x1, x0
    // 0x9251bc: ldur            x0, [fp, #-0x10]
    // 0x9251c0: StoreField: r1->field_f = r0
    //     0x9251c0: stur            w0, [x1, #0xf]
    // 0x9251c4: r16 = " has not been implemented"
    //     0x9251c4: ldr             x16, [PP, #0x62d0]  ; [pp+0x62d0] " has not been implemented"
    // 0x9251c8: StoreField: r1->field_13 = r16
    //     0x9251c8: stur            w16, [x1, #0x13]
    // 0x9251cc: str             x1, [SP]
    // 0x9251d0: r0 = _interpolate()
    //     0x9251d0: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x9251d4: stur            x0, [fp, #-0x10]
    // 0x9251d8: r0 = UnimplementedError()
    //     0x9251d8: bl              #0x7dd7c4  ; AllocateUnimplementedErrorStub -> UnimplementedError (size=0x10)
    // 0x9251dc: mov             x1, x0
    // 0x9251e0: ldur            x0, [fp, #-0x10]
    // 0x9251e4: StoreField: r1->field_b = r0
    //     0x9251e4: stur            w0, [x1, #0xb]
    // 0x9251e8: mov             x0, x1
    // 0x9251ec: r0 = Throw()
    //     0x9251ec: bl              #0x13ddb2c  ; ThrowStub
    // 0x9251f0: brk             #0
    // 0x9251f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9251f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9251f8: b               #0x924f40
  }
  static StreamController<String> tokenStreamController() {
    // ** addr: 0x925390, size: 0x34
    // 0x925390: EnterFrame
    //     0x925390: stp             fp, lr, [SP, #-0x10]!
    //     0x925394: mov             fp, SP
    // 0x925398: CheckStackOverflow
    //     0x925398: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x92539c: cmp             SP, x16
    //     0x9253a0: b.ls            #0x9253bc
    // 0x9253a4: r1 = <String>
    //     0x9253a4: ldr             x1, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    // 0x9253a8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9253a8: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9253ac: r0 = StreamController.broadcast()
    //     0x9253ac: bl              #0x8c36b8  ; [dart:async] StreamController::StreamController.broadcast
    // 0x9253b0: LeaveFrame
    //     0x9253b0: mov             SP, fp
    //     0x9253b4: ldp             fp, lr, [SP], #0x10
    // 0x9253b8: ret
    //     0x9253b8: ret             
    // 0x9253bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9253bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9253c0: b               #0x9253a4
  }
  _ deleteToken(/* No info */) async {
    // ** addr: 0x1310c24, size: 0x114
    // 0x1310c24: EnterFrame
    //     0x1310c24: stp             fp, lr, [SP, #-0x10]!
    //     0x1310c28: mov             fp, SP
    // 0x1310c2c: AllocStack(0x88)
    //     0x1310c2c: sub             SP, SP, #0x88
    // 0x1310c30: SetupParameters(MethodChannelFirebaseMessaging this /* r1 => r1, fp-0x60 */)
    //     0x1310c30: stur            NULL, [fp, #-8]
    //     0x1310c34: stur            x1, [fp, #-0x60]
    // 0x1310c38: CheckStackOverflow
    //     0x1310c38: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1310c3c: cmp             SP, x16
    //     0x1310c40: b.ls            #0x1310d30
    // 0x1310c44: InitAsync() -> Future<void?>
    //     0x1310c44: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0x1310c48: bl              #0x7f5e44  ; InitAsyncStub
    // 0x1310c4c: ldur            x1, [fp, #-0x60]
    // 0x1310c50: r0 = activate()
    //     0x1310c50: bl              #0x1309aa0  ; [package:flutter/src/services/mouse_cursor.dart] _NoopMouseCursorSession::activate
    // 0x1310c54: mov             x1, x0
    // 0x1310c58: stur            x1, [fp, #-0x68]
    // 0x1310c5c: r0 = Await()
    //     0x1310c5c: bl              #0x7f5c00  ; AwaitStub
    // 0x1310c60: ldur            x0, [fp, #-0x60]
    // 0x1310c64: r1 = Null
    //     0x1310c64: mov             x1, NULL
    // 0x1310c68: r2 = 4
    //     0x1310c68: mov             x2, #4
    // 0x1310c6c: r0 = AllocateArray()
    //     0x1310c6c: bl              #0x13df928  ; AllocateArrayStub
    // 0x1310c70: stur            x0, [fp, #-0x68]
    // 0x1310c74: r16 = "appName"
    //     0x1310c74: add             x16, PP, #8, lsl #12  ; [pp+0x8bb0] "appName"
    //     0x1310c78: ldr             x16, [x16, #0xbb0]
    // 0x1310c7c: StoreField: r0->field_f = r16
    //     0x1310c7c: stur            w16, [x0, #0xf]
    // 0x1310c80: ldur            x1, [fp, #-0x60]
    // 0x1310c84: LoadField: r2 = r1->field_7
    //     0x1310c84: ldur            w2, [x1, #7]
    // 0x1310c88: DecompressPointer r2
    //     0x1310c88: add             x2, x2, HEAP, lsl #32
    // 0x1310c8c: cmp             w2, NULL
    // 0x1310c90: b.ne            #0x1310c9c
    // 0x1310c94: r0 = app()
    //     0x1310c94: bl              #0x8c0c7c  ; [package:firebase_core/firebase_core.dart] Firebase::app
    // 0x1310c98: b               #0x1310ca0
    // 0x1310c9c: mov             x0, x2
    // 0x1310ca0: LoadField: r1 = r0->field_7
    //     0x1310ca0: ldur            w1, [x0, #7]
    // 0x1310ca4: DecompressPointer r1
    //     0x1310ca4: add             x1, x1, HEAP, lsl #32
    // 0x1310ca8: LoadField: r0 = r1->field_7
    //     0x1310ca8: ldur            w0, [x1, #7]
    // 0x1310cac: DecompressPointer r0
    //     0x1310cac: add             x0, x0, HEAP, lsl #32
    // 0x1310cb0: ldur            x1, [fp, #-0x68]
    // 0x1310cb4: ArrayStore: r1[1] = r0  ; List_4
    //     0x1310cb4: add             x25, x1, #0x13
    //     0x1310cb8: str             w0, [x25]
    //     0x1310cbc: tbz             w0, #0, #0x1310cd8
    //     0x1310cc0: ldurb           w16, [x1, #-1]
    //     0x1310cc4: ldurb           w17, [x0, #-1]
    //     0x1310cc8: and             x16, x17, x16, lsr #2
    //     0x1310ccc: tst             x16, HEAP, lsr #32
    //     0x1310cd0: b.eq            #0x1310cd8
    //     0x1310cd4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1310cd8: r16 = <String, String>
    //     0x1310cd8: ldr             x16, [PP, #0x7c88]  ; [pp+0x7c88] TypeArguments: <String, String>
    // 0x1310cdc: ldur            lr, [fp, #-0x68]
    // 0x1310ce0: stp             lr, x16, [SP]
    // 0x1310ce4: r0 = Map._fromLiteral()
    //     0x1310ce4: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x1310ce8: r16 = Instance_MethodChannel
    //     0x1310ce8: add             x16, PP, #8, lsl #12  ; [pp+0x8af0] Obj!MethodChannel@129bb81
    //     0x1310cec: ldr             x16, [x16, #0xaf0]
    // 0x1310cf0: stp             x16, NULL, [SP, #0x10]
    // 0x1310cf4: r16 = "Messaging#deleteToken"
    //     0x1310cf4: add             x16, PP, #0x26, lsl #12  ; [pp+0x26dc0] "Messaging#deleteToken"
    //     0x1310cf8: ldr             x16, [x16, #0xdc0]
    // 0x1310cfc: stp             x0, x16, [SP]
    // 0x1310d00: r4 = const [0x2, 0x3, 0x3, 0x3, null]
    //     0x1310d00: ldr             x4, [PP, #0x3738]  ; [pp+0x3738] List(5) [0x2, 0x3, 0x3, 0x3, Null]
    // 0x1310d04: r0 = invokeMapMethod()
    //     0x1310d04: bl              #0x8492b0  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMapMethod
    // 0x1310d08: mov             x1, x0
    // 0x1310d0c: stur            x1, [fp, #-0x68]
    // 0x1310d10: r0 = Await()
    //     0x1310d10: bl              #0x7f5c00  ; AwaitStub
    // 0x1310d14: r0 = Null
    //     0x1310d14: mov             x0, NULL
    // 0x1310d18: r0 = ReturnAsyncNotFuture()
    //     0x1310d18: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x1310d1c: sub             SP, fp, #0x88
    // 0x1310d20: mov             x2, x1
    // 0x1310d24: mov             x1, x0
    // 0x1310d28: r0 = convertPlatformException()
    //     0x1310d28: bl              #0x924bac  ; [package:firebase_messaging_platform_interface/src/method_channel/utils/exception.dart] ::convertPlatformException
    // 0x1310d2c: brk             #0
    // 0x1310d30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1310d30: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1310d34: b               #0x1310c44
  }
  _ registerBackgroundMessageHandler(/* No info */) async {
    // ** addr: 0x13e7558, size: 0x124
    // 0x13e7558: EnterFrame
    //     0x13e7558: stp             fp, lr, [SP, #-0x10]!
    //     0x13e755c: mov             fp, SP
    // 0x13e7560: AllocStack(0x38)
    //     0x13e7560: sub             SP, SP, #0x38
    // 0x13e7564: SetupParameters(MethodChannelFirebaseMessaging this /* r1 => r1, fp-0x10 */)
    //     0x13e7564: stur            NULL, [fp, #-8]
    //     0x13e7568: stur            x1, [fp, #-0x10]
    // 0x13e756c: CheckStackOverflow
    //     0x13e756c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13e7570: cmp             SP, x16
    //     0x13e7574: b.ls            #0x13e766c
    // 0x13e7578: InitAsync() -> Future<void?>
    //     0x13e7578: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0x13e757c: bl              #0x7f5e44  ; InitAsyncStub
    // 0x13e7580: r0 = LoadStaticField(0x1108)
    //     0x13e7580: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x13e7584: ldr             x0, [x0, #0x2210]
    // 0x13e7588: tbz             w0, #4, #0x13e7664
    // 0x13e758c: r2 = true
    //     0x13e758c: add             x2, NULL, #0x20  ; true
    // 0x13e7590: StoreStaticField(0x1108, r2)
    //     0x13e7590: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x13e7594: str             x2, [x0, #0x2210]
    // 0x13e7598: r1 = Closure: () => void from Function '_firebaseMessagingCallbackDispatcher@1296184891': static.
    //     0x13e7598: add             x1, PP, #8, lsl #12  ; [pp+0x8ae0] Closure: () => void from Function '_firebaseMessagingCallbackDispatcher@1296184891': static. (0x7f2ada80bb80)
    //     0x13e759c: ldr             x1, [x1, #0xae0]
    // 0x13e75a0: r0 = getCallbackHandle()
    //     0x13e75a0: bl              #0x8caafc  ; [dart:ui] PluginUtilities::getCallbackHandle
    // 0x13e75a4: stur            x0, [fp, #-0x10]
    // 0x13e75a8: cmp             w0, NULL
    // 0x13e75ac: b.eq            #0x13e7674
    // 0x13e75b0: r1 = Closure: (RemoteMessage) => Future<void> from Function 'handleBackgroundMessage': static.
    //     0x13e75b0: add             x1, PP, #8, lsl #12  ; [pp+0x8ac0] Closure: (RemoteMessage) => Future<void> from Function 'handleBackgroundMessage': static. (0x7f2ada80c1fc)
    //     0x13e75b4: ldr             x1, [x1, #0xac0]
    // 0x13e75b8: r0 = getCallbackHandle()
    //     0x13e75b8: bl              #0x8caafc  ; [dart:ui] PluginUtilities::getCallbackHandle
    // 0x13e75bc: stur            x0, [fp, #-0x18]
    // 0x13e75c0: cmp             w0, NULL
    // 0x13e75c4: b.eq            #0x13e7678
    // 0x13e75c8: r1 = Null
    //     0x13e75c8: mov             x1, NULL
    // 0x13e75cc: r2 = 8
    //     0x13e75cc: mov             x2, #8
    // 0x13e75d0: r0 = AllocateArray()
    //     0x13e75d0: bl              #0x13df928  ; AllocateArrayStub
    // 0x13e75d4: mov             x2, x0
    // 0x13e75d8: r16 = "pluginCallbackHandle"
    //     0x13e75d8: add             x16, PP, #8, lsl #12  ; [pp+0x8ae8] "pluginCallbackHandle"
    //     0x13e75dc: ldr             x16, [x16, #0xae8]
    // 0x13e75e0: StoreField: r2->field_f = r16
    //     0x13e75e0: stur            w16, [x2, #0xf]
    // 0x13e75e4: ldur            x0, [fp, #-0x10]
    // 0x13e75e8: LoadField: r3 = r0->field_7
    //     0x13e75e8: ldur            x3, [x0, #7]
    // 0x13e75ec: r0 = BoxInt64Instr(r3)
    //     0x13e75ec: sbfiz           x0, x3, #1, #0x1f
    //     0x13e75f0: cmp             x3, x0, asr #1
    //     0x13e75f4: b.eq            #0x13e7600
    //     0x13e75f8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x13e75fc: stur            x3, [x0, #7]
    // 0x13e7600: StoreField: r2->field_13 = r0
    //     0x13e7600: stur            w0, [x2, #0x13]
    // 0x13e7604: r16 = "userCallbackHandle"
    //     0x13e7604: ldr             x16, [PP, #0x6260]  ; [pp+0x6260] "userCallbackHandle"
    // 0x13e7608: ArrayStore: r2[0] = r16  ; List_4
    //     0x13e7608: stur            w16, [x2, #0x17]
    // 0x13e760c: ldur            x0, [fp, #-0x18]
    // 0x13e7610: LoadField: r3 = r0->field_7
    //     0x13e7610: ldur            x3, [x0, #7]
    // 0x13e7614: r0 = BoxInt64Instr(r3)
    //     0x13e7614: sbfiz           x0, x3, #1, #0x1f
    //     0x13e7618: cmp             x3, x0, asr #1
    //     0x13e761c: b.eq            #0x13e7628
    //     0x13e7620: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x13e7624: stur            x3, [x0, #7]
    // 0x13e7628: StoreField: r2->field_1b = r0
    //     0x13e7628: stur            w0, [x2, #0x1b]
    // 0x13e762c: r16 = <String, int>
    //     0x13e762c: ldr             x16, [PP, #0xdc0]  ; [pp+0xdc0] TypeArguments: <String, int>
    // 0x13e7630: stp             x2, x16, [SP]
    // 0x13e7634: r0 = Map._fromLiteral()
    //     0x13e7634: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x13e7638: r16 = Instance_MethodChannel
    //     0x13e7638: add             x16, PP, #8, lsl #12  ; [pp+0x8af0] Obj!MethodChannel@129bb81
    //     0x13e763c: ldr             x16, [x16, #0xaf0]
    // 0x13e7640: stp             x16, NULL, [SP, #0x10]
    // 0x13e7644: r16 = "Messaging#startBackgroundIsolate"
    //     0x13e7644: add             x16, PP, #8, lsl #12  ; [pp+0x8af8] "Messaging#startBackgroundIsolate"
    //     0x13e7648: ldr             x16, [x16, #0xaf8]
    // 0x13e764c: stp             x0, x16, [SP]
    // 0x13e7650: r4 = const [0x2, 0x3, 0x3, 0x3, null]
    //     0x13e7650: ldr             x4, [PP, #0x3738]  ; [pp+0x3738] List(5) [0x2, 0x3, 0x3, 0x3, Null]
    // 0x13e7654: r0 = invokeMapMethod()
    //     0x13e7654: bl              #0x8492b0  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMapMethod
    // 0x13e7658: mov             x1, x0
    // 0x13e765c: stur            x1, [fp, #-0x10]
    // 0x13e7660: r0 = Await()
    //     0x13e7660: bl              #0x7f5c00  ; AwaitStub
    // 0x13e7664: r0 = Null
    //     0x13e7664: mov             x0, NULL
    // 0x13e7668: r0 = ReturnAsyncNotFuture()
    //     0x13e7668: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x13e766c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13e766c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13e7670: b               #0x13e7578
    // 0x13e7674: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x13e7674: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x13e7678: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x13e7678: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ getInitialMessage(/* No info */) async {
    // ** addr: 0x13e7714, size: 0x108
    // 0x13e7714: EnterFrame
    //     0x13e7714: stp             fp, lr, [SP, #-0x10]!
    //     0x13e7718: mov             fp, SP
    // 0x13e771c: AllocStack(0x88)
    //     0x13e771c: sub             SP, SP, #0x88
    // 0x13e7720: SetupParameters(MethodChannelFirebaseMessaging this /* r1 => r1, fp-0x60 */)
    //     0x13e7720: stur            NULL, [fp, #-8]
    //     0x13e7724: stur            x1, [fp, #-0x60]
    // 0x13e7728: CheckStackOverflow
    //     0x13e7728: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13e772c: cmp             SP, x16
    //     0x13e7730: b.ls            #0x13e7814
    // 0x13e7734: InitAsync() -> Future<RemoteMessage?>
    //     0x13e7734: add             x0, PP, #8, lsl #12  ; [pp+0x8ba8] TypeArguments: <RemoteMessage?>
    //     0x13e7738: ldr             x0, [x0, #0xba8]
    //     0x13e773c: bl              #0x7f5e44  ; InitAsyncStub
    // 0x13e7740: r1 = Null
    //     0x13e7740: mov             x1, NULL
    // 0x13e7744: r2 = 4
    //     0x13e7744: mov             x2, #4
    // 0x13e7748: r0 = AllocateArray()
    //     0x13e7748: bl              #0x13df928  ; AllocateArrayStub
    // 0x13e774c: stur            x0, [fp, #-0x68]
    // 0x13e7750: r16 = "appName"
    //     0x13e7750: add             x16, PP, #8, lsl #12  ; [pp+0x8bb0] "appName"
    //     0x13e7754: ldr             x16, [x16, #0xbb0]
    // 0x13e7758: StoreField: r0->field_f = r16
    //     0x13e7758: stur            w16, [x0, #0xf]
    // 0x13e775c: ldur            x1, [fp, #-0x60]
    // 0x13e7760: r0 = app()
    //     0x13e7760: bl              #0x922dd8  ; [package:firebase_messaging_platform_interface/src/platform_interface/platform_interface_messaging.dart] FirebaseMessagingPlatform::app
    // 0x13e7764: LoadField: r1 = r0->field_7
    //     0x13e7764: ldur            w1, [x0, #7]
    // 0x13e7768: DecompressPointer r1
    //     0x13e7768: add             x1, x1, HEAP, lsl #32
    // 0x13e776c: LoadField: r0 = r1->field_7
    //     0x13e776c: ldur            w0, [x1, #7]
    // 0x13e7770: DecompressPointer r0
    //     0x13e7770: add             x0, x0, HEAP, lsl #32
    // 0x13e7774: ldur            x1, [fp, #-0x68]
    // 0x13e7778: ArrayStore: r1[1] = r0  ; List_4
    //     0x13e7778: add             x25, x1, #0x13
    //     0x13e777c: str             w0, [x25]
    //     0x13e7780: tbz             w0, #0, #0x13e779c
    //     0x13e7784: ldurb           w16, [x1, #-1]
    //     0x13e7788: ldurb           w17, [x0, #-1]
    //     0x13e778c: and             x16, x17, x16, lsr #2
    //     0x13e7790: tst             x16, HEAP, lsr #32
    //     0x13e7794: b.eq            #0x13e779c
    //     0x13e7798: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x13e779c: r16 = <String, String>
    //     0x13e779c: ldr             x16, [PP, #0x7c88]  ; [pp+0x7c88] TypeArguments: <String, String>
    // 0x13e77a0: ldur            lr, [fp, #-0x68]
    // 0x13e77a4: stp             lr, x16, [SP]
    // 0x13e77a8: r0 = Map._fromLiteral()
    //     0x13e77a8: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x13e77ac: r16 = <String, dynamic>
    //     0x13e77ac: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x13e77b0: r30 = Instance_MethodChannel
    //     0x13e77b0: add             lr, PP, #8, lsl #12  ; [pp+0x8af0] Obj!MethodChannel@129bb81
    //     0x13e77b4: ldr             lr, [lr, #0xaf0]
    // 0x13e77b8: stp             lr, x16, [SP, #0x10]
    // 0x13e77bc: r16 = "Messaging#getInitialMessage"
    //     0x13e77bc: add             x16, PP, #8, lsl #12  ; [pp+0x8bb8] "Messaging#getInitialMessage"
    //     0x13e77c0: ldr             x16, [x16, #0xbb8]
    // 0x13e77c4: stp             x0, x16, [SP]
    // 0x13e77c8: r4 = const [0x2, 0x3, 0x3, 0x3, null]
    //     0x13e77c8: ldr             x4, [PP, #0x3738]  ; [pp+0x3738] List(5) [0x2, 0x3, 0x3, 0x3, Null]
    // 0x13e77cc: r0 = invokeMapMethod()
    //     0x13e77cc: bl              #0x8492b0  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMapMethod
    // 0x13e77d0: mov             x1, x0
    // 0x13e77d4: stur            x1, [fp, #-0x68]
    // 0x13e77d8: r0 = Await()
    //     0x13e77d8: bl              #0x7f5c00  ; AwaitStub
    // 0x13e77dc: stur            x0, [fp, #-0x60]
    // 0x13e77e0: cmp             w0, NULL
    // 0x13e77e4: b.ne            #0x13e77f0
    // 0x13e77e8: r0 = Null
    //     0x13e77e8: mov             x0, NULL
    // 0x13e77ec: r0 = ReturnAsyncNotFuture()
    //     0x13e77ec: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x13e77f0: mov             x2, x0
    // 0x13e77f4: r1 = Null
    //     0x13e77f4: mov             x1, NULL
    // 0x13e77f8: r0 = RemoteMessage.fromMap()
    //     0x13e77f8: bl              #0x9230b8  ; [package:firebase_messaging_platform_interface/src/remote_message.dart] RemoteMessage::RemoteMessage.fromMap
    // 0x13e77fc: r0 = ReturnAsyncNotFuture()
    //     0x13e77fc: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x13e7800: sub             SP, fp, #0x88
    // 0x13e7804: mov             x2, x1
    // 0x13e7808: mov             x1, x0
    // 0x13e780c: r0 = convertPlatformException()
    //     0x13e780c: bl              #0x924bac  ; [package:firebase_messaging_platform_interface/src/method_channel/utils/exception.dart] ::convertPlatformException
    // 0x13e7810: brk             #0
    // 0x13e7814: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13e7814: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13e7818: b               #0x13e7734
  }
  _ setForegroundNotificationPresentationOptions(/* No info */) async {
    // ** addr: 0x13e785c, size: 0x38
    // 0x13e785c: EnterFrame
    //     0x13e785c: stp             fp, lr, [SP, #-0x10]!
    //     0x13e7860: mov             fp, SP
    // 0x13e7864: AllocStack(0x80)
    //     0x13e7864: sub             SP, SP, #0x80
    // 0x13e7868: SetupParameters(MethodChannelFirebaseMessaging this /* r1 => r1, fp-0x80 */)
    //     0x13e7868: stur            NULL, [fp, #-8]
    //     0x13e786c: stur            x1, [fp, #-0x80]
    // 0x13e7870: CheckStackOverflow
    //     0x13e7870: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13e7874: cmp             SP, x16
    //     0x13e7878: b.ls            #0x13e788c
    // 0x13e787c: InitAsync() -> Future<void?>
    //     0x13e787c: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0x13e7880: bl              #0x7f5e44  ; InitAsyncStub
    // 0x13e7884: r0 = Null
    //     0x13e7884: mov             x0, NULL
    // 0x13e7888: r0 = ReturnAsyncNotFuture()
    //     0x13e7888: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x13e788c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13e788c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13e7890: b               #0x13e787c
  }
  _ requestPermission(/* No info */) async {
    // ** addr: 0x13e94a8, size: 0x208
    // 0x13e94a8: EnterFrame
    //     0x13e94a8: stp             fp, lr, [SP, #-0x10]!
    //     0x13e94ac: mov             fp, SP
    // 0x13e94b0: AllocStack(0xd0)
    //     0x13e94b0: sub             SP, SP, #0xd0
    // 0x13e94b4: SetupParameters(MethodChannelFirebaseMessaging this /* r1 => r1, fp-0xa8 */)
    //     0x13e94b4: stur            NULL, [fp, #-8]
    //     0x13e94b8: stur            x1, [fp, #-0xa8]
    // 0x13e94bc: CheckStackOverflow
    //     0x13e94bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13e94c0: cmp             SP, x16
    //     0x13e94c4: b.ls            #0x13e96a4
    // 0x13e94c8: InitAsync() -> Future<NotificationSettings>
    //     0x13e94c8: add             x0, PP, #8, lsl #12  ; [pp+0x8bf0] TypeArguments: <NotificationSettings>
    //     0x13e94cc: ldr             x0, [x0, #0xbf0]
    //     0x13e94d0: bl              #0x7f5e44  ; InitAsyncStub
    // 0x13e94d4: ldur            x0, [fp, #-0xa8]
    // 0x13e94d8: r1 = Null
    //     0x13e94d8: mov             x1, NULL
    // 0x13e94dc: r2 = 8
    //     0x13e94dc: mov             x2, #8
    // 0x13e94e0: r0 = AllocateArray()
    //     0x13e94e0: bl              #0x13df928  ; AllocateArrayStub
    // 0x13e94e4: stur            x0, [fp, #-0xb0]
    // 0x13e94e8: r16 = "appName"
    //     0x13e94e8: add             x16, PP, #8, lsl #12  ; [pp+0x8bb0] "appName"
    //     0x13e94ec: ldr             x16, [x16, #0xbb0]
    // 0x13e94f0: StoreField: r0->field_f = r16
    //     0x13e94f0: stur            w16, [x0, #0xf]
    // 0x13e94f4: ldur            x1, [fp, #-0xa8]
    // 0x13e94f8: LoadField: r2 = r1->field_7
    //     0x13e94f8: ldur            w2, [x1, #7]
    // 0x13e94fc: DecompressPointer r2
    //     0x13e94fc: add             x2, x2, HEAP, lsl #32
    // 0x13e9500: cmp             w2, NULL
    // 0x13e9504: b.ne            #0x13e9510
    // 0x13e9508: r0 = app()
    //     0x13e9508: bl              #0x8c0c7c  ; [package:firebase_core/firebase_core.dart] Firebase::app
    // 0x13e950c: b               #0x13e9514
    // 0x13e9510: mov             x0, x2
    // 0x13e9514: ldur            x3, [fp, #-0xb0]
    // 0x13e9518: LoadField: r1 = r0->field_7
    //     0x13e9518: ldur            w1, [x0, #7]
    // 0x13e951c: DecompressPointer r1
    //     0x13e951c: add             x1, x1, HEAP, lsl #32
    // 0x13e9520: LoadField: r0 = r1->field_7
    //     0x13e9520: ldur            w0, [x1, #7]
    // 0x13e9524: DecompressPointer r0
    //     0x13e9524: add             x0, x0, HEAP, lsl #32
    // 0x13e9528: mov             x1, x3
    // 0x13e952c: ArrayStore: r1[1] = r0  ; List_4
    //     0x13e952c: add             x25, x1, #0x13
    //     0x13e9530: str             w0, [x25]
    //     0x13e9534: tbz             w0, #0, #0x13e9550
    //     0x13e9538: ldurb           w16, [x1, #-1]
    //     0x13e953c: ldurb           w17, [x0, #-1]
    //     0x13e9540: and             x16, x17, x16, lsr #2
    //     0x13e9544: tst             x16, HEAP, lsr #32
    //     0x13e9548: b.eq            #0x13e9550
    //     0x13e954c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x13e9550: r16 = "permissions"
    //     0x13e9550: add             x16, PP, #8, lsl #12  ; [pp+0x8bf8] "permissions"
    //     0x13e9554: ldr             x16, [x16, #0xbf8]
    // 0x13e9558: ArrayStore: r3[0] = r16  ; List_4
    //     0x13e9558: stur            w16, [x3, #0x17]
    // 0x13e955c: r1 = Null
    //     0x13e955c: mov             x1, NULL
    // 0x13e9560: r2 = 32
    //     0x13e9560: mov             x2, #0x20
    // 0x13e9564: r0 = AllocateArray()
    //     0x13e9564: bl              #0x13df928  ; AllocateArrayStub
    // 0x13e9568: r16 = "alert"
    //     0x13e9568: add             x16, PP, #8, lsl #12  ; [pp+0x8c00] "alert"
    //     0x13e956c: ldr             x16, [x16, #0xc00]
    // 0x13e9570: StoreField: r0->field_f = r16
    //     0x13e9570: stur            w16, [x0, #0xf]
    // 0x13e9574: r16 = true
    //     0x13e9574: add             x16, NULL, #0x20  ; true
    // 0x13e9578: StoreField: r0->field_13 = r16
    //     0x13e9578: stur            w16, [x0, #0x13]
    // 0x13e957c: r16 = "announcement"
    //     0x13e957c: add             x16, PP, #8, lsl #12  ; [pp+0x8c08] "announcement"
    //     0x13e9580: ldr             x16, [x16, #0xc08]
    // 0x13e9584: ArrayStore: r0[0] = r16  ; List_4
    //     0x13e9584: stur            w16, [x0, #0x17]
    // 0x13e9588: r16 = false
    //     0x13e9588: add             x16, NULL, #0x30  ; false
    // 0x13e958c: StoreField: r0->field_1b = r16
    //     0x13e958c: stur            w16, [x0, #0x1b]
    // 0x13e9590: r16 = "badge"
    //     0x13e9590: ldr             x16, [PP, #0x6560]  ; [pp+0x6560] "badge"
    // 0x13e9594: StoreField: r0->field_1f = r16
    //     0x13e9594: stur            w16, [x0, #0x1f]
    // 0x13e9598: r16 = true
    //     0x13e9598: add             x16, NULL, #0x20  ; true
    // 0x13e959c: StoreField: r0->field_23 = r16
    //     0x13e959c: stur            w16, [x0, #0x23]
    // 0x13e95a0: r16 = "carPlay"
    //     0x13e95a0: add             x16, PP, #8, lsl #12  ; [pp+0x8c10] "carPlay"
    //     0x13e95a4: ldr             x16, [x16, #0xc10]
    // 0x13e95a8: StoreField: r0->field_27 = r16
    //     0x13e95a8: stur            w16, [x0, #0x27]
    // 0x13e95ac: r16 = false
    //     0x13e95ac: add             x16, NULL, #0x30  ; false
    // 0x13e95b0: StoreField: r0->field_2b = r16
    //     0x13e95b0: stur            w16, [x0, #0x2b]
    // 0x13e95b4: r16 = "criticalAlert"
    //     0x13e95b4: add             x16, PP, #8, lsl #12  ; [pp+0x8c18] "criticalAlert"
    //     0x13e95b8: ldr             x16, [x16, #0xc18]
    // 0x13e95bc: StoreField: r0->field_2f = r16
    //     0x13e95bc: stur            w16, [x0, #0x2f]
    // 0x13e95c0: r16 = false
    //     0x13e95c0: add             x16, NULL, #0x30  ; false
    // 0x13e95c4: StoreField: r0->field_33 = r16
    //     0x13e95c4: stur            w16, [x0, #0x33]
    // 0x13e95c8: r16 = "provisional"
    //     0x13e95c8: add             x16, PP, #8, lsl #12  ; [pp+0x8c20] "provisional"
    //     0x13e95cc: ldr             x16, [x16, #0xc20]
    // 0x13e95d0: StoreField: r0->field_37 = r16
    //     0x13e95d0: stur            w16, [x0, #0x37]
    // 0x13e95d4: r16 = false
    //     0x13e95d4: add             x16, NULL, #0x30  ; false
    // 0x13e95d8: StoreField: r0->field_3b = r16
    //     0x13e95d8: stur            w16, [x0, #0x3b]
    // 0x13e95dc: r16 = "sound"
    //     0x13e95dc: ldr             x16, [PP, #0x65c8]  ; [pp+0x65c8] "sound"
    // 0x13e95e0: StoreField: r0->field_3f = r16
    //     0x13e95e0: stur            w16, [x0, #0x3f]
    // 0x13e95e4: r16 = true
    //     0x13e95e4: add             x16, NULL, #0x20  ; true
    // 0x13e95e8: StoreField: r0->field_43 = r16
    //     0x13e95e8: stur            w16, [x0, #0x43]
    // 0x13e95ec: r16 = "providesAppNotificationSettings"
    //     0x13e95ec: add             x16, PP, #8, lsl #12  ; [pp+0x8c28] "providesAppNotificationSettings"
    //     0x13e95f0: ldr             x16, [x16, #0xc28]
    // 0x13e95f4: StoreField: r0->field_47 = r16
    //     0x13e95f4: stur            w16, [x0, #0x47]
    // 0x13e95f8: r16 = false
    //     0x13e95f8: add             x16, NULL, #0x30  ; false
    // 0x13e95fc: StoreField: r0->field_4b = r16
    //     0x13e95fc: stur            w16, [x0, #0x4b]
    // 0x13e9600: r16 = <String, bool>
    //     0x13e9600: add             x16, PP, #8, lsl #12  ; [pp+0x8c30] TypeArguments: <String, bool>
    //     0x13e9604: ldr             x16, [x16, #0xc30]
    // 0x13e9608: stp             x0, x16, [SP]
    // 0x13e960c: r0 = Map._fromLiteral()
    //     0x13e960c: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x13e9610: ldur            x1, [fp, #-0xb0]
    // 0x13e9614: ArrayStore: r1[3] = r0  ; List_4
    //     0x13e9614: add             x25, x1, #0x1b
    //     0x13e9618: str             w0, [x25]
    //     0x13e961c: tbz             w0, #0, #0x13e9638
    //     0x13e9620: ldurb           w16, [x1, #-1]
    //     0x13e9624: ldurb           w17, [x0, #-1]
    //     0x13e9628: and             x16, x17, x16, lsr #2
    //     0x13e962c: tst             x16, HEAP, lsr #32
    //     0x13e9630: b.eq            #0x13e9638
    //     0x13e9634: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x13e9638: r16 = <String, Object>
    //     0x13e9638: ldr             x16, [PP, #0x7aa0]  ; [pp+0x7aa0] TypeArguments: <String, Object>
    // 0x13e963c: ldur            lr, [fp, #-0xb0]
    // 0x13e9640: stp             lr, x16, [SP]
    // 0x13e9644: r0 = Map._fromLiteral()
    //     0x13e9644: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x13e9648: r16 = <String, int>
    //     0x13e9648: ldr             x16, [PP, #0xdc0]  ; [pp+0xdc0] TypeArguments: <String, int>
    // 0x13e964c: r30 = Instance_MethodChannel
    //     0x13e964c: add             lr, PP, #8, lsl #12  ; [pp+0x8af0] Obj!MethodChannel@129bb81
    //     0x13e9650: ldr             lr, [lr, #0xaf0]
    // 0x13e9654: stp             lr, x16, [SP, #0x10]
    // 0x13e9658: r16 = "Messaging#requestPermission"
    //     0x13e9658: add             x16, PP, #8, lsl #12  ; [pp+0x8c38] "Messaging#requestPermission"
    //     0x13e965c: ldr             x16, [x16, #0xc38]
    // 0x13e9660: stp             x0, x16, [SP]
    // 0x13e9664: r4 = const [0x2, 0x3, 0x3, 0x3, null]
    //     0x13e9664: ldr             x4, [PP, #0x3738]  ; [pp+0x3738] List(5) [0x2, 0x3, 0x3, 0x3, Null]
    // 0x13e9668: r0 = invokeMapMethod()
    //     0x13e9668: bl              #0x8492b0  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMapMethod
    // 0x13e966c: mov             x1, x0
    // 0x13e9670: stur            x1, [fp, #-0xb0]
    // 0x13e9674: r0 = Await()
    //     0x13e9674: bl              #0x7f5c00  ; AwaitStub
    // 0x13e9678: stur            x0, [fp, #-0xb0]
    // 0x13e967c: cmp             w0, NULL
    // 0x13e9680: b.eq            #0x13e96ac
    // 0x13e9684: mov             x1, x0
    // 0x13e9688: r0 = convertToNotificationSettings()
    //     0x13e9688: bl              #0x13e96b0  ; [package:firebase_messaging_platform_interface/src/utils.dart] ::convertToNotificationSettings
    // 0x13e968c: r0 = ReturnAsyncNotFuture()
    //     0x13e968c: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x13e9690: sub             SP, fp, #0xd0
    // 0x13e9694: mov             x2, x1
    // 0x13e9698: mov             x1, x0
    // 0x13e969c: r0 = convertPlatformException()
    //     0x13e969c: bl              #0x924bac  ; [package:firebase_messaging_platform_interface/src/method_channel/utils/exception.dart] ::convertPlatformException
    // 0x13e96a0: brk             #0
    // 0x13e96a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13e96a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13e96a8: b               #0x13e94c8
    // 0x13e96ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x13e96ac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}
