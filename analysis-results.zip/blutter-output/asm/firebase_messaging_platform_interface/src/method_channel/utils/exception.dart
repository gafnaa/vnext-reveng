// lib: , url: package:firebase_messaging_platform_interface/src/method_channel/utils/exception.dart

// class id: 1048754, size: 0x8
class :: {

  static Never convertPlatformException(Object, StackTrace) {
    // ** addr: 0x924bac, size: 0x2c
    // 0x924bac: EnterFrame
    //     0x924bac: stp             fp, lr, [SP, #-0x10]!
    //     0x924bb0: mov             fp, SP
    // 0x924bb4: CheckStackOverflow
    //     0x924bb4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x924bb8: cmp             SP, x16
    //     0x924bbc: b.ls            #0x924bd0
    // 0x924bc0: r3 = "firebase_messaging"
    //     0x924bc0: add             x3, PP, #8, lsl #12  ; [pp+0x8bc0] "firebase_messaging"
    //     0x924bc4: ldr             x3, [x3, #0xbc0]
    // 0x924bc8: r0 = convertPlatformExceptionToFirebaseException()
    //     0x924bc8: bl              #0x8c0778  ; [package:_flutterfire_internals/src/exception.dart] ::convertPlatformExceptionToFirebaseException
    // 0x924bcc: brk             #0
    // 0x924bd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x924bd0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x924bd4: b               #0x924bc0
  }
}
