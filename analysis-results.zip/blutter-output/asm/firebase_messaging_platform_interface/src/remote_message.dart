// lib: , url: package:firebase_messaging_platform_interface/src/remote_message.dart

// class id: 1048757, size: 0x8
class :: {
}

// class id: 3350, size: 0x40, field offset: 0x8
//   const constructor, 
class RemoteMessage extends Object {

  factory _ RemoteMessage.fromMap(/* No info */) {
    // ** addr: 0x9230b8, size: 0x69c
    // 0x9230b8: EnterFrame
    //     0x9230b8: stp             fp, lr, [SP, #-0x10]!
    //     0x9230bc: mov             fp, SP
    // 0x9230c0: AllocStack(0x88)
    //     0x9230c0: sub             SP, SP, #0x88
    // 0x9230c4: SetupParameters(dynamic _ /* r2 => r3, fp-0x8 */)
    //     0x9230c4: mov             x3, x2
    //     0x9230c8: stur            x2, [fp, #-8]
    // 0x9230cc: CheckStackOverflow
    //     0x9230cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9230d0: cmp             SP, x16
    //     0x9230d4: b.ls            #0x92374c
    // 0x9230d8: r0 = LoadClassIdInstr(r3)
    //     0x9230d8: ldur            x0, [x3, #-1]
    //     0x9230dc: ubfx            x0, x0, #0xc, #0x14
    // 0x9230e0: mov             x1, x3
    // 0x9230e4: r2 = "senderId"
    //     0x9230e4: ldr             x2, [PP, #0x62d8]  ; [pp+0x62d8] "senderId"
    // 0x9230e8: r0 = GDT[cid_x0 + -0xd48]()
    //     0x9230e8: sub             lr, x0, #0xd48
    //     0x9230ec: ldr             lr, [x21, lr, lsl #3]
    //     0x9230f0: blr             lr
    // 0x9230f4: mov             x3, x0
    // 0x9230f8: r2 = Null
    //     0x9230f8: mov             x2, NULL
    // 0x9230fc: r1 = Null
    //     0x9230fc: mov             x1, NULL
    // 0x923100: stur            x3, [fp, #-0x10]
    // 0x923104: r4 = 60
    //     0x923104: mov             x4, #0x3c
    // 0x923108: branchIfSmi(r0, 0x923114)
    //     0x923108: tbz             w0, #0, #0x923114
    // 0x92310c: r4 = LoadClassIdInstr(r0)
    //     0x92310c: ldur            x4, [x0, #-1]
    //     0x923110: ubfx            x4, x4, #0xc, #0x14
    // 0x923114: sub             x4, x4, #0x5e
    // 0x923118: cmp             x4, #1
    // 0x92311c: b.ls            #0x92312c
    // 0x923120: r8 = String?
    //     0x923120: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x923124: r3 = Null
    //     0x923124: ldr             x3, [PP, #0x62e0]  ; [pp+0x62e0] Null
    // 0x923128: r0 = String?()
    //     0x923128: bl              #0x7db310  ; IsType_String?_Stub
    // 0x92312c: ldur            x3, [fp, #-8]
    // 0x923130: r0 = LoadClassIdInstr(r3)
    //     0x923130: ldur            x0, [x3, #-1]
    //     0x923134: ubfx            x0, x0, #0xc, #0x14
    // 0x923138: mov             x1, x3
    // 0x92313c: r2 = "category"
    //     0x92313c: ldr             x2, [PP, #0x62f0]  ; [pp+0x62f0] "category"
    // 0x923140: r0 = GDT[cid_x0 + -0xd48]()
    //     0x923140: sub             lr, x0, #0xd48
    //     0x923144: ldr             lr, [x21, lr, lsl #3]
    //     0x923148: blr             lr
    // 0x92314c: mov             x3, x0
    // 0x923150: r2 = Null
    //     0x923150: mov             x2, NULL
    // 0x923154: r1 = Null
    //     0x923154: mov             x1, NULL
    // 0x923158: stur            x3, [fp, #-0x18]
    // 0x92315c: r4 = 60
    //     0x92315c: mov             x4, #0x3c
    // 0x923160: branchIfSmi(r0, 0x92316c)
    //     0x923160: tbz             w0, #0, #0x92316c
    // 0x923164: r4 = LoadClassIdInstr(r0)
    //     0x923164: ldur            x4, [x0, #-1]
    //     0x923168: ubfx            x4, x4, #0xc, #0x14
    // 0x92316c: sub             x4, x4, #0x5e
    // 0x923170: cmp             x4, #1
    // 0x923174: b.ls            #0x923184
    // 0x923178: r8 = String?
    //     0x923178: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x92317c: r3 = Null
    //     0x92317c: ldr             x3, [PP, #0x62f8]  ; [pp+0x62f8] Null
    // 0x923180: r0 = String?()
    //     0x923180: bl              #0x7db310  ; IsType_String?_Stub
    // 0x923184: ldur            x3, [fp, #-8]
    // 0x923188: r0 = LoadClassIdInstr(r3)
    //     0x923188: ldur            x0, [x3, #-1]
    //     0x92318c: ubfx            x0, x0, #0xc, #0x14
    // 0x923190: mov             x1, x3
    // 0x923194: r2 = "actionIdentifier"
    //     0x923194: ldr             x2, [PP, #0x6308]  ; [pp+0x6308] "actionIdentifier"
    // 0x923198: r0 = GDT[cid_x0 + -0xd48]()
    //     0x923198: sub             lr, x0, #0xd48
    //     0x92319c: ldr             lr, [x21, lr, lsl #3]
    //     0x9231a0: blr             lr
    // 0x9231a4: mov             x3, x0
    // 0x9231a8: r2 = Null
    //     0x9231a8: mov             x2, NULL
    // 0x9231ac: r1 = Null
    //     0x9231ac: mov             x1, NULL
    // 0x9231b0: stur            x3, [fp, #-0x20]
    // 0x9231b4: r4 = 60
    //     0x9231b4: mov             x4, #0x3c
    // 0x9231b8: branchIfSmi(r0, 0x9231c4)
    //     0x9231b8: tbz             w0, #0, #0x9231c4
    // 0x9231bc: r4 = LoadClassIdInstr(r0)
    //     0x9231bc: ldur            x4, [x0, #-1]
    //     0x9231c0: ubfx            x4, x4, #0xc, #0x14
    // 0x9231c4: sub             x4, x4, #0x5e
    // 0x9231c8: cmp             x4, #1
    // 0x9231cc: b.ls            #0x9231dc
    // 0x9231d0: r8 = String?
    //     0x9231d0: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x9231d4: r3 = Null
    //     0x9231d4: ldr             x3, [PP, #0x6310]  ; [pp+0x6310] Null
    // 0x9231d8: r0 = String?()
    //     0x9231d8: bl              #0x7db310  ; IsType_String?_Stub
    // 0x9231dc: ldur            x3, [fp, #-8]
    // 0x9231e0: r0 = LoadClassIdInstr(r3)
    //     0x9231e0: ldur            x0, [x3, #-1]
    //     0x9231e4: ubfx            x0, x0, #0xc, #0x14
    // 0x9231e8: mov             x1, x3
    // 0x9231ec: r2 = "collapseKey"
    //     0x9231ec: ldr             x2, [PP, #0x6320]  ; [pp+0x6320] "collapseKey"
    // 0x9231f0: r0 = GDT[cid_x0 + -0xd48]()
    //     0x9231f0: sub             lr, x0, #0xd48
    //     0x9231f4: ldr             lr, [x21, lr, lsl #3]
    //     0x9231f8: blr             lr
    // 0x9231fc: mov             x3, x0
    // 0x923200: r2 = Null
    //     0x923200: mov             x2, NULL
    // 0x923204: r1 = Null
    //     0x923204: mov             x1, NULL
    // 0x923208: stur            x3, [fp, #-0x28]
    // 0x92320c: r4 = 60
    //     0x92320c: mov             x4, #0x3c
    // 0x923210: branchIfSmi(r0, 0x92321c)
    //     0x923210: tbz             w0, #0, #0x92321c
    // 0x923214: r4 = LoadClassIdInstr(r0)
    //     0x923214: ldur            x4, [x0, #-1]
    //     0x923218: ubfx            x4, x4, #0xc, #0x14
    // 0x92321c: sub             x4, x4, #0x5e
    // 0x923220: cmp             x4, #1
    // 0x923224: b.ls            #0x923234
    // 0x923228: r8 = String?
    //     0x923228: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x92322c: r3 = Null
    //     0x92322c: ldr             x3, [PP, #0x6328]  ; [pp+0x6328] Null
    // 0x923230: r0 = String?()
    //     0x923230: bl              #0x7db310  ; IsType_String?_Stub
    // 0x923234: ldur            x3, [fp, #-8]
    // 0x923238: r0 = LoadClassIdInstr(r3)
    //     0x923238: ldur            x0, [x3, #-1]
    //     0x92323c: ubfx            x0, x0, #0xc, #0x14
    // 0x923240: mov             x1, x3
    // 0x923244: r2 = "contentAvailable"
    //     0x923244: ldr             x2, [PP, #0x6338]  ; [pp+0x6338] "contentAvailable"
    // 0x923248: r0 = GDT[cid_x0 + -0xd48]()
    //     0x923248: sub             lr, x0, #0xd48
    //     0x92324c: ldr             lr, [x21, lr, lsl #3]
    //     0x923250: blr             lr
    // 0x923254: cmp             w0, NULL
    // 0x923258: b.ne            #0x923264
    // 0x92325c: r4 = false
    //     0x92325c: add             x4, NULL, #0x30  ; false
    // 0x923260: b               #0x923268
    // 0x923264: mov             x4, x0
    // 0x923268: ldur            x3, [fp, #-8]
    // 0x92326c: mov             x0, x4
    // 0x923270: stur            x4, [fp, #-0x30]
    // 0x923274: r2 = Null
    //     0x923274: mov             x2, NULL
    // 0x923278: r1 = Null
    //     0x923278: mov             x1, NULL
    // 0x92327c: r4 = 60
    //     0x92327c: mov             x4, #0x3c
    // 0x923280: branchIfSmi(r0, 0x92328c)
    //     0x923280: tbz             w0, #0, #0x92328c
    // 0x923284: r4 = LoadClassIdInstr(r0)
    //     0x923284: ldur            x4, [x0, #-1]
    //     0x923288: ubfx            x4, x4, #0xc, #0x14
    // 0x92328c: cmp             x4, #0x3f
    // 0x923290: b.eq            #0x9232a0
    // 0x923294: r8 = bool
    //     0x923294: ldr             x8, [PP, #0xb18]  ; [pp+0xb18] Type: bool
    // 0x923298: r3 = Null
    //     0x923298: ldr             x3, [PP, #0x6340]  ; [pp+0x6340] Null
    // 0x92329c: r0 = bool()
    //     0x92329c: bl              #0x13ee15c  ; IsType_bool_Stub
    // 0x9232a0: ldur            x3, [fp, #-8]
    // 0x9232a4: r0 = LoadClassIdInstr(r3)
    //     0x9232a4: ldur            x0, [x3, #-1]
    //     0x9232a8: ubfx            x0, x0, #0xc, #0x14
    // 0x9232ac: mov             x1, x3
    // 0x9232b0: r2 = "data"
    //     0x9232b0: ldr             x2, [PP, #0x1370]  ; [pp+0x1370] "data"
    // 0x9232b4: r0 = GDT[cid_x0 + -0xd48]()
    //     0x9232b4: sub             lr, x0, #0xd48
    //     0x9232b8: ldr             lr, [x21, lr, lsl #3]
    //     0x9232bc: blr             lr
    // 0x9232c0: cmp             w0, NULL
    // 0x9232c4: b.ne            #0x9232e0
    // 0x9232c8: r16 = <String, dynamic>
    //     0x9232c8: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x9232cc: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x9232d0: stp             lr, x16, [SP]
    // 0x9232d4: r0 = Map._fromLiteral()
    //     0x9232d4: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x9232d8: mov             x4, x0
    // 0x9232dc: b               #0x92332c
    // 0x9232e0: ldur            x3, [fp, #-8]
    // 0x9232e4: r0 = LoadClassIdInstr(r3)
    //     0x9232e4: ldur            x0, [x3, #-1]
    //     0x9232e8: ubfx            x0, x0, #0xc, #0x14
    // 0x9232ec: mov             x1, x3
    // 0x9232f0: r2 = "data"
    //     0x9232f0: ldr             x2, [PP, #0x1370]  ; [pp+0x1370] "data"
    // 0x9232f4: r0 = GDT[cid_x0 + -0xd48]()
    //     0x9232f4: sub             lr, x0, #0xd48
    //     0x9232f8: ldr             lr, [x21, lr, lsl #3]
    //     0x9232fc: blr             lr
    // 0x923300: mov             x3, x0
    // 0x923304: r2 = Null
    //     0x923304: mov             x2, NULL
    // 0x923308: r1 = Null
    //     0x923308: mov             x1, NULL
    // 0x92330c: stur            x3, [fp, #-0x38]
    // 0x923310: r8 = Map
    //     0x923310: ldr             x8, [PP, #0x1c8]  ; [pp+0x1c8] Type: Map
    // 0x923314: r3 = Null
    //     0x923314: ldr             x3, [PP, #0x6350]  ; [pp+0x6350] Null
    // 0x923318: r0 = Map()
    //     0x923318: bl              #0x13efa40  ; IsType_Map_Stub
    // 0x92331c: ldur            x2, [fp, #-0x38]
    // 0x923320: r1 = <String, dynamic>
    //     0x923320: ldr             x1, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x923324: r0 = LinkedHashMap.from()
    //     0x923324: bl              #0x8ac2e4  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x923328: mov             x4, x0
    // 0x92332c: ldur            x3, [fp, #-8]
    // 0x923330: stur            x4, [fp, #-0x38]
    // 0x923334: r0 = LoadClassIdInstr(r3)
    //     0x923334: ldur            x0, [x3, #-1]
    //     0x923338: ubfx            x0, x0, #0xc, #0x14
    // 0x92333c: mov             x1, x3
    // 0x923340: r2 = "from"
    //     0x923340: ldr             x2, [PP, #0x6360]  ; [pp+0x6360] "from"
    // 0x923344: r0 = GDT[cid_x0 + -0xd48]()
    //     0x923344: sub             lr, x0, #0xd48
    //     0x923348: ldr             lr, [x21, lr, lsl #3]
    //     0x92334c: blr             lr
    // 0x923350: mov             x3, x0
    // 0x923354: r2 = Null
    //     0x923354: mov             x2, NULL
    // 0x923358: r1 = Null
    //     0x923358: mov             x1, NULL
    // 0x92335c: stur            x3, [fp, #-0x40]
    // 0x923360: r4 = 60
    //     0x923360: mov             x4, #0x3c
    // 0x923364: branchIfSmi(r0, 0x923370)
    //     0x923364: tbz             w0, #0, #0x923370
    // 0x923368: r4 = LoadClassIdInstr(r0)
    //     0x923368: ldur            x4, [x0, #-1]
    //     0x92336c: ubfx            x4, x4, #0xc, #0x14
    // 0x923370: sub             x4, x4, #0x5e
    // 0x923374: cmp             x4, #1
    // 0x923378: b.ls            #0x923388
    // 0x92337c: r8 = String?
    //     0x92337c: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x923380: r3 = Null
    //     0x923380: ldr             x3, [PP, #0x6368]  ; [pp+0x6368] Null
    // 0x923384: r0 = String?()
    //     0x923384: bl              #0x7db310  ; IsType_String?_Stub
    // 0x923388: ldur            x3, [fp, #-8]
    // 0x92338c: r0 = LoadClassIdInstr(r3)
    //     0x92338c: ldur            x0, [x3, #-1]
    //     0x923390: ubfx            x0, x0, #0xc, #0x14
    // 0x923394: mov             x1, x3
    // 0x923398: r2 = "messageId"
    //     0x923398: ldr             x2, [PP, #0x6378]  ; [pp+0x6378] "messageId"
    // 0x92339c: r0 = GDT[cid_x0 + -0xd48]()
    //     0x92339c: sub             lr, x0, #0xd48
    //     0x9233a0: ldr             lr, [x21, lr, lsl #3]
    //     0x9233a4: blr             lr
    // 0x9233a8: cmp             w0, NULL
    // 0x9233ac: b.ne            #0x9233b8
    // 0x9233b0: r4 = Null
    //     0x9233b0: mov             x4, NULL
    // 0x9233b4: b               #0x9233e8
    // 0x9233b8: r1 = 60
    //     0x9233b8: mov             x1, #0x3c
    // 0x9233bc: branchIfSmi(r0, 0x9233c8)
    //     0x9233bc: tbz             w0, #0, #0x9233c8
    // 0x9233c0: r1 = LoadClassIdInstr(r0)
    //     0x9233c0: ldur            x1, [x0, #-1]
    //     0x9233c4: ubfx            x1, x1, #0xc, #0x14
    // 0x9233c8: str             x0, [SP]
    // 0x9233cc: mov             x0, x1
    // 0x9233d0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x9233d0: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x9233d4: r0 = GDT[cid_x0 + 0x91c1]()
    //     0x9233d4: mov             x17, #0x91c1
    //     0x9233d8: add             lr, x0, x17
    //     0x9233dc: ldr             lr, [x21, lr, lsl #3]
    //     0x9233e0: blr             lr
    // 0x9233e4: mov             x4, x0
    // 0x9233e8: ldur            x3, [fp, #-8]
    // 0x9233ec: stur            x4, [fp, #-0x48]
    // 0x9233f0: r0 = LoadClassIdInstr(r3)
    //     0x9233f0: ldur            x0, [x3, #-1]
    //     0x9233f4: ubfx            x0, x0, #0xc, #0x14
    // 0x9233f8: mov             x1, x3
    // 0x9233fc: r2 = "messageType"
    //     0x9233fc: ldr             x2, [PP, #0x6380]  ; [pp+0x6380] "messageType"
    // 0x923400: r0 = GDT[cid_x0 + -0xd48]()
    //     0x923400: sub             lr, x0, #0xd48
    //     0x923404: ldr             lr, [x21, lr, lsl #3]
    //     0x923408: blr             lr
    // 0x92340c: mov             x3, x0
    // 0x923410: r2 = Null
    //     0x923410: mov             x2, NULL
    // 0x923414: r1 = Null
    //     0x923414: mov             x1, NULL
    // 0x923418: stur            x3, [fp, #-0x50]
    // 0x92341c: r4 = 60
    //     0x92341c: mov             x4, #0x3c
    // 0x923420: branchIfSmi(r0, 0x92342c)
    //     0x923420: tbz             w0, #0, #0x92342c
    // 0x923424: r4 = LoadClassIdInstr(r0)
    //     0x923424: ldur            x4, [x0, #-1]
    //     0x923428: ubfx            x4, x4, #0xc, #0x14
    // 0x92342c: sub             x4, x4, #0x5e
    // 0x923430: cmp             x4, #1
    // 0x923434: b.ls            #0x923444
    // 0x923438: r8 = String?
    //     0x923438: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x92343c: r3 = Null
    //     0x92343c: ldr             x3, [PP, #0x6388]  ; [pp+0x6388] Null
    // 0x923440: r0 = String?()
    //     0x923440: bl              #0x7db310  ; IsType_String?_Stub
    // 0x923444: ldur            x3, [fp, #-8]
    // 0x923448: r0 = LoadClassIdInstr(r3)
    //     0x923448: ldur            x0, [x3, #-1]
    //     0x92344c: ubfx            x0, x0, #0xc, #0x14
    // 0x923450: mov             x1, x3
    // 0x923454: r2 = "mutableContent"
    //     0x923454: ldr             x2, [PP, #0x6398]  ; [pp+0x6398] "mutableContent"
    // 0x923458: r0 = GDT[cid_x0 + -0xd48]()
    //     0x923458: sub             lr, x0, #0xd48
    //     0x92345c: ldr             lr, [x21, lr, lsl #3]
    //     0x923460: blr             lr
    // 0x923464: cmp             w0, NULL
    // 0x923468: b.ne            #0x923474
    // 0x92346c: r4 = false
    //     0x92346c: add             x4, NULL, #0x30  ; false
    // 0x923470: b               #0x923478
    // 0x923474: mov             x4, x0
    // 0x923478: ldur            x3, [fp, #-8]
    // 0x92347c: mov             x0, x4
    // 0x923480: stur            x4, [fp, #-0x58]
    // 0x923484: r2 = Null
    //     0x923484: mov             x2, NULL
    // 0x923488: r1 = Null
    //     0x923488: mov             x1, NULL
    // 0x92348c: r4 = 60
    //     0x92348c: mov             x4, #0x3c
    // 0x923490: branchIfSmi(r0, 0x92349c)
    //     0x923490: tbz             w0, #0, #0x92349c
    // 0x923494: r4 = LoadClassIdInstr(r0)
    //     0x923494: ldur            x4, [x0, #-1]
    //     0x923498: ubfx            x4, x4, #0xc, #0x14
    // 0x92349c: cmp             x4, #0x3f
    // 0x9234a0: b.eq            #0x9234b0
    // 0x9234a4: r8 = bool
    //     0x9234a4: ldr             x8, [PP, #0xb18]  ; [pp+0xb18] Type: bool
    // 0x9234a8: r3 = Null
    //     0x9234a8: ldr             x3, [PP, #0x63a0]  ; [pp+0x63a0] Null
    // 0x9234ac: r0 = bool()
    //     0x9234ac: bl              #0x13ee15c  ; IsType_bool_Stub
    // 0x9234b0: ldur            x3, [fp, #-8]
    // 0x9234b4: r0 = LoadClassIdInstr(r3)
    //     0x9234b4: ldur            x0, [x3, #-1]
    //     0x9234b8: ubfx            x0, x0, #0xc, #0x14
    // 0x9234bc: mov             x1, x3
    // 0x9234c0: r2 = "notification"
    //     0x9234c0: ldr             x2, [PP, #0x63b0]  ; [pp+0x63b0] "notification"
    // 0x9234c4: r0 = GDT[cid_x0 + -0xd48]()
    //     0x9234c4: sub             lr, x0, #0xd48
    //     0x9234c8: ldr             lr, [x21, lr, lsl #3]
    //     0x9234cc: blr             lr
    // 0x9234d0: cmp             w0, NULL
    // 0x9234d4: b.ne            #0x9234e0
    // 0x9234d8: r4 = Null
    //     0x9234d8: mov             x4, NULL
    // 0x9234dc: b               #0x923538
    // 0x9234e0: ldur            x3, [fp, #-8]
    // 0x9234e4: r0 = LoadClassIdInstr(r3)
    //     0x9234e4: ldur            x0, [x3, #-1]
    //     0x9234e8: ubfx            x0, x0, #0xc, #0x14
    // 0x9234ec: mov             x1, x3
    // 0x9234f0: r2 = "notification"
    //     0x9234f0: ldr             x2, [PP, #0x63b0]  ; [pp+0x63b0] "notification"
    // 0x9234f4: r0 = GDT[cid_x0 + -0xd48]()
    //     0x9234f4: sub             lr, x0, #0xd48
    //     0x9234f8: ldr             lr, [x21, lr, lsl #3]
    //     0x9234fc: blr             lr
    // 0x923500: mov             x3, x0
    // 0x923504: r2 = Null
    //     0x923504: mov             x2, NULL
    // 0x923508: r1 = Null
    //     0x923508: mov             x1, NULL
    // 0x92350c: stur            x3, [fp, #-0x60]
    // 0x923510: r8 = Map
    //     0x923510: ldr             x8, [PP, #0x1c8]  ; [pp+0x1c8] Type: Map
    // 0x923514: r3 = Null
    //     0x923514: ldr             x3, [PP, #0x63b8]  ; [pp+0x63b8] Null
    // 0x923518: r0 = Map()
    //     0x923518: bl              #0x13efa40  ; IsType_Map_Stub
    // 0x92351c: ldur            x2, [fp, #-0x60]
    // 0x923520: r1 = <String, dynamic>
    //     0x923520: ldr             x1, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x923524: r0 = LinkedHashMap.from()
    //     0x923524: bl              #0x8ac2e4  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x923528: mov             x2, x0
    // 0x92352c: r1 = Null
    //     0x92352c: mov             x1, NULL
    // 0x923530: r0 = RemoteNotification.fromMap()
    //     0x923530: bl              #0x923780  ; [package:firebase_messaging_platform_interface/src/remote_notification.dart] RemoteNotification::RemoteNotification.fromMap
    // 0x923534: mov             x4, x0
    // 0x923538: ldur            x3, [fp, #-8]
    // 0x92353c: stur            x4, [fp, #-0x60]
    // 0x923540: r0 = LoadClassIdInstr(r3)
    //     0x923540: ldur            x0, [x3, #-1]
    //     0x923544: ubfx            x0, x0, #0xc, #0x14
    // 0x923548: mov             x1, x3
    // 0x92354c: r2 = "sentTime"
    //     0x92354c: ldr             x2, [PP, #0x63c8]  ; [pp+0x63c8] "sentTime"
    // 0x923550: r0 = GDT[cid_x0 + -0xd48]()
    //     0x923550: sub             lr, x0, #0xd48
    //     0x923554: ldr             lr, [x21, lr, lsl #3]
    //     0x923558: blr             lr
    // 0x92355c: cmp             w0, NULL
    // 0x923560: b.ne            #0x92356c
    // 0x923564: r19 = Null
    //     0x923564: mov             x19, NULL
    // 0x923568: b               #0x9235f4
    // 0x92356c: ldur            x3, [fp, #-8]
    // 0x923570: r0 = LoadClassIdInstr(r3)
    //     0x923570: ldur            x0, [x3, #-1]
    //     0x923574: ubfx            x0, x0, #0xc, #0x14
    // 0x923578: mov             x1, x3
    // 0x92357c: r2 = "sentTime"
    //     0x92357c: ldr             x2, [PP, #0x63c8]  ; [pp+0x63c8] "sentTime"
    // 0x923580: r0 = GDT[cid_x0 + -0xd48]()
    //     0x923580: sub             lr, x0, #0xd48
    //     0x923584: ldr             lr, [x21, lr, lsl #3]
    //     0x923588: blr             lr
    // 0x92358c: r1 = 60
    //     0x92358c: mov             x1, #0x3c
    // 0x923590: branchIfSmi(r0, 0x92359c)
    //     0x923590: tbz             w0, #0, #0x92359c
    // 0x923594: r1 = LoadClassIdInstr(r0)
    //     0x923594: ldur            x1, [x0, #-1]
    //     0x923598: ubfx            x1, x1, #0xc, #0x14
    // 0x92359c: str             x0, [SP]
    // 0x9235a0: mov             x0, x1
    // 0x9235a4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x9235a4: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x9235a8: r0 = GDT[cid_x0 + 0x91c1]()
    //     0x9235a8: mov             x17, #0x91c1
    //     0x9235ac: add             lr, x0, x17
    //     0x9235b0: ldr             lr, [x21, lr, lsl #3]
    //     0x9235b4: blr             lr
    // 0x9235b8: mov             x1, x0
    // 0x9235bc: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9235bc: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9235c0: r0 = parse()
    //     0x9235c0: bl              #0x8220cc  ; [dart:core] int::parse
    // 0x9235c4: mov             x1, x0
    // 0x9235c8: r0 = _validateMilliseconds()
    //     0x9235c8: bl              #0x913d1c  ; [dart:core] DateTime::_validateMilliseconds
    // 0x9235cc: r16 = 1000
    //     0x9235cc: mov             x16, #0x3e8
    // 0x9235d0: mul             x2, x0, x16
    // 0x9235d4: stur            x2, [fp, #-0x68]
    // 0x9235d8: r0 = DateTime()
    //     0x9235d8: bl              #0x8174b8  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x9235dc: mov             x1, x0
    // 0x9235e0: ldur            x2, [fp, #-0x68]
    // 0x9235e4: r3 = false
    //     0x9235e4: add             x3, NULL, #0x30  ; false
    // 0x9235e8: stur            x0, [fp, #-0x70]
    // 0x9235ec: r0 = DateTime._withValue()
    //     0x9235ec: bl              #0x8c7610  ; [dart:core] DateTime::DateTime._withValue
    // 0x9235f0: ldur            x19, [fp, #-0x70]
    // 0x9235f4: ldur            x3, [fp, #-8]
    // 0x9235f8: ldur            x14, [fp, #-0x10]
    // 0x9235fc: ldur            x13, [fp, #-0x18]
    // 0x923600: ldur            x12, [fp, #-0x20]
    // 0x923604: ldur            x11, [fp, #-0x28]
    // 0x923608: ldur            x10, [fp, #-0x30]
    // 0x92360c: ldur            x9, [fp, #-0x38]
    // 0x923610: ldur            x8, [fp, #-0x40]
    // 0x923614: ldur            x7, [fp, #-0x48]
    // 0x923618: ldur            x6, [fp, #-0x50]
    // 0x92361c: ldur            x5, [fp, #-0x58]
    // 0x923620: ldur            x4, [fp, #-0x60]
    // 0x923624: stur            x19, [fp, #-0x70]
    // 0x923628: r0 = LoadClassIdInstr(r3)
    //     0x923628: ldur            x0, [x3, #-1]
    //     0x92362c: ubfx            x0, x0, #0xc, #0x14
    // 0x923630: mov             x1, x3
    // 0x923634: r2 = "threadId"
    //     0x923634: ldr             x2, [PP, #0x63d0]  ; [pp+0x63d0] "threadId"
    // 0x923638: r0 = GDT[cid_x0 + -0xd48]()
    //     0x923638: sub             lr, x0, #0xd48
    //     0x92363c: ldr             lr, [x21, lr, lsl #3]
    //     0x923640: blr             lr
    // 0x923644: mov             x3, x0
    // 0x923648: r2 = Null
    //     0x923648: mov             x2, NULL
    // 0x92364c: r1 = Null
    //     0x92364c: mov             x1, NULL
    // 0x923650: stur            x3, [fp, #-0x78]
    // 0x923654: r4 = 60
    //     0x923654: mov             x4, #0x3c
    // 0x923658: branchIfSmi(r0, 0x923664)
    //     0x923658: tbz             w0, #0, #0x923664
    // 0x92365c: r4 = LoadClassIdInstr(r0)
    //     0x92365c: ldur            x4, [x0, #-1]
    //     0x923660: ubfx            x4, x4, #0xc, #0x14
    // 0x923664: sub             x4, x4, #0x5e
    // 0x923668: cmp             x4, #1
    // 0x92366c: b.ls            #0x92367c
    // 0x923670: r8 = String?
    //     0x923670: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x923674: r3 = Null
    //     0x923674: ldr             x3, [PP, #0x63d8]  ; [pp+0x63d8] Null
    // 0x923678: r0 = String?()
    //     0x923678: bl              #0x7db310  ; IsType_String?_Stub
    // 0x92367c: ldur            x1, [fp, #-8]
    // 0x923680: r0 = LoadClassIdInstr(r1)
    //     0x923680: ldur            x0, [x1, #-1]
    //     0x923684: ubfx            x0, x0, #0xc, #0x14
    // 0x923688: r2 = "ttl"
    //     0x923688: ldr             x2, [PP, #0x63e8]  ; [pp+0x63e8] "ttl"
    // 0x92368c: r0 = GDT[cid_x0 + -0xd48]()
    //     0x92368c: sub             lr, x0, #0xd48
    //     0x923690: ldr             lr, [x21, lr, lsl #3]
    //     0x923694: blr             lr
    // 0x923698: mov             x3, x0
    // 0x92369c: r2 = Null
    //     0x92369c: mov             x2, NULL
    // 0x9236a0: r1 = Null
    //     0x9236a0: mov             x1, NULL
    // 0x9236a4: stur            x3, [fp, #-8]
    // 0x9236a8: branchIfSmi(r0, 0x9236cc)
    //     0x9236a8: tbz             w0, #0, #0x9236cc
    // 0x9236ac: r4 = LoadClassIdInstr(r0)
    //     0x9236ac: ldur            x4, [x0, #-1]
    //     0x9236b0: ubfx            x4, x4, #0xc, #0x14
    // 0x9236b4: sub             x4, x4, #0x3c
    // 0x9236b8: cmp             x4, #1
    // 0x9236bc: b.ls            #0x9236cc
    // 0x9236c0: r8 = int?
    //     0x9236c0: ldr             x8, [PP, #0x3d30]  ; [pp+0x3d30] Type: int?
    // 0x9236c4: r3 = Null
    //     0x9236c4: ldr             x3, [PP, #0x63f0]  ; [pp+0x63f0] Null
    // 0x9236c8: r0 = int?()
    //     0x9236c8: bl              #0x13ee944  ; IsType_int?_Stub
    // 0x9236cc: r0 = RemoteMessage()
    //     0x9236cc: bl              #0x923774  ; AllocateRemoteMessageStub -> RemoteMessage (size=0x40)
    // 0x9236d0: ldur            x1, [fp, #-0x10]
    // 0x9236d4: StoreField: r0->field_7 = r1
    //     0x9236d4: stur            w1, [x0, #7]
    // 0x9236d8: ldur            x1, [fp, #-0x18]
    // 0x9236dc: StoreField: r0->field_b = r1
    //     0x9236dc: stur            w1, [x0, #0xb]
    // 0x9236e0: ldur            x1, [fp, #-0x20]
    // 0x9236e4: StoreField: r0->field_f = r1
    //     0x9236e4: stur            w1, [x0, #0xf]
    // 0x9236e8: ldur            x1, [fp, #-0x28]
    // 0x9236ec: StoreField: r0->field_13 = r1
    //     0x9236ec: stur            w1, [x0, #0x13]
    // 0x9236f0: ldur            x1, [fp, #-0x30]
    // 0x9236f4: ArrayStore: r0[0] = r1  ; List_4
    //     0x9236f4: stur            w1, [x0, #0x17]
    // 0x9236f8: ldur            x1, [fp, #-0x38]
    // 0x9236fc: StoreField: r0->field_1b = r1
    //     0x9236fc: stur            w1, [x0, #0x1b]
    // 0x923700: ldur            x1, [fp, #-0x40]
    // 0x923704: StoreField: r0->field_1f = r1
    //     0x923704: stur            w1, [x0, #0x1f]
    // 0x923708: ldur            x1, [fp, #-0x48]
    // 0x92370c: StoreField: r0->field_23 = r1
    //     0x92370c: stur            w1, [x0, #0x23]
    // 0x923710: ldur            x1, [fp, #-0x50]
    // 0x923714: StoreField: r0->field_27 = r1
    //     0x923714: stur            w1, [x0, #0x27]
    // 0x923718: ldur            x1, [fp, #-0x58]
    // 0x92371c: StoreField: r0->field_2b = r1
    //     0x92371c: stur            w1, [x0, #0x2b]
    // 0x923720: ldur            x1, [fp, #-0x60]
    // 0x923724: StoreField: r0->field_2f = r1
    //     0x923724: stur            w1, [x0, #0x2f]
    // 0x923728: ldur            x1, [fp, #-0x70]
    // 0x92372c: StoreField: r0->field_33 = r1
    //     0x92372c: stur            w1, [x0, #0x33]
    // 0x923730: ldur            x1, [fp, #-0x78]
    // 0x923734: StoreField: r0->field_37 = r1
    //     0x923734: stur            w1, [x0, #0x37]
    // 0x923738: ldur            x1, [fp, #-8]
    // 0x92373c: StoreField: r0->field_3b = r1
    //     0x92373c: stur            w1, [x0, #0x3b]
    // 0x923740: LeaveFrame
    //     0x923740: mov             SP, fp
    //     0x923744: ldp             fp, lr, [SP], #0x10
    // 0x923748: ret
    //     0x923748: ret             
    // 0x92374c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x92374c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x923750: b               #0x9230d8
  }
  _ toMap(/* No info */) {
    // ** addr: 0x13e8a30, size: 0x264
    // 0x13e8a30: EnterFrame
    //     0x13e8a30: stp             fp, lr, [SP, #-0x10]!
    //     0x13e8a34: mov             fp, SP
    // 0x13e8a38: AllocStack(0x20)
    //     0x13e8a38: sub             SP, SP, #0x20
    // 0x13e8a3c: SetupParameters(RemoteMessage this /* r1 => r0, fp-0x8 */)
    //     0x13e8a3c: mov             x0, x1
    //     0x13e8a40: stur            x1, [fp, #-8]
    // 0x13e8a44: CheckStackOverflow
    //     0x13e8a44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13e8a48: cmp             SP, x16
    //     0x13e8a4c: b.ls            #0x13e8c8c
    // 0x13e8a50: r1 = Null
    //     0x13e8a50: mov             x1, NULL
    // 0x13e8a54: r2 = 56
    //     0x13e8a54: mov             x2, #0x38
    // 0x13e8a58: r0 = AllocateArray()
    //     0x13e8a58: bl              #0x13df928  ; AllocateArrayStub
    // 0x13e8a5c: stur            x0, [fp, #-0x10]
    // 0x13e8a60: r16 = "senderId"
    //     0x13e8a60: ldr             x16, [PP, #0x62d8]  ; [pp+0x62d8] "senderId"
    // 0x13e8a64: StoreField: r0->field_f = r16
    //     0x13e8a64: stur            w16, [x0, #0xf]
    // 0x13e8a68: ldur            x2, [fp, #-8]
    // 0x13e8a6c: LoadField: r1 = r2->field_7
    //     0x13e8a6c: ldur            w1, [x2, #7]
    // 0x13e8a70: DecompressPointer r1
    //     0x13e8a70: add             x1, x1, HEAP, lsl #32
    // 0x13e8a74: StoreField: r0->field_13 = r1
    //     0x13e8a74: stur            w1, [x0, #0x13]
    // 0x13e8a78: r16 = "category"
    //     0x13e8a78: ldr             x16, [PP, #0x62f0]  ; [pp+0x62f0] "category"
    // 0x13e8a7c: ArrayStore: r0[0] = r16  ; List_4
    //     0x13e8a7c: stur            w16, [x0, #0x17]
    // 0x13e8a80: LoadField: r1 = r2->field_b
    //     0x13e8a80: ldur            w1, [x2, #0xb]
    // 0x13e8a84: DecompressPointer r1
    //     0x13e8a84: add             x1, x1, HEAP, lsl #32
    // 0x13e8a88: StoreField: r0->field_1b = r1
    //     0x13e8a88: stur            w1, [x0, #0x1b]
    // 0x13e8a8c: r16 = "actionIdentifier"
    //     0x13e8a8c: ldr             x16, [PP, #0x6308]  ; [pp+0x6308] "actionIdentifier"
    // 0x13e8a90: StoreField: r0->field_1f = r16
    //     0x13e8a90: stur            w16, [x0, #0x1f]
    // 0x13e8a94: LoadField: r1 = r2->field_f
    //     0x13e8a94: ldur            w1, [x2, #0xf]
    // 0x13e8a98: DecompressPointer r1
    //     0x13e8a98: add             x1, x1, HEAP, lsl #32
    // 0x13e8a9c: StoreField: r0->field_23 = r1
    //     0x13e8a9c: stur            w1, [x0, #0x23]
    // 0x13e8aa0: r16 = "collapseKey"
    //     0x13e8aa0: ldr             x16, [PP, #0x6320]  ; [pp+0x6320] "collapseKey"
    // 0x13e8aa4: StoreField: r0->field_27 = r16
    //     0x13e8aa4: stur            w16, [x0, #0x27]
    // 0x13e8aa8: LoadField: r1 = r2->field_13
    //     0x13e8aa8: ldur            w1, [x2, #0x13]
    // 0x13e8aac: DecompressPointer r1
    //     0x13e8aac: add             x1, x1, HEAP, lsl #32
    // 0x13e8ab0: StoreField: r0->field_2b = r1
    //     0x13e8ab0: stur            w1, [x0, #0x2b]
    // 0x13e8ab4: r16 = "contentAvailable"
    //     0x13e8ab4: ldr             x16, [PP, #0x6338]  ; [pp+0x6338] "contentAvailable"
    // 0x13e8ab8: StoreField: r0->field_2f = r16
    //     0x13e8ab8: stur            w16, [x0, #0x2f]
    // 0x13e8abc: ArrayLoad: r1 = r2[0]  ; List_4
    //     0x13e8abc: ldur            w1, [x2, #0x17]
    // 0x13e8ac0: DecompressPointer r1
    //     0x13e8ac0: add             x1, x1, HEAP, lsl #32
    // 0x13e8ac4: StoreField: r0->field_33 = r1
    //     0x13e8ac4: stur            w1, [x0, #0x33]
    // 0x13e8ac8: r16 = "data"
    //     0x13e8ac8: ldr             x16, [PP, #0x1370]  ; [pp+0x1370] "data"
    // 0x13e8acc: StoreField: r0->field_37 = r16
    //     0x13e8acc: stur            w16, [x0, #0x37]
    // 0x13e8ad0: LoadField: r1 = r2->field_1b
    //     0x13e8ad0: ldur            w1, [x2, #0x1b]
    // 0x13e8ad4: DecompressPointer r1
    //     0x13e8ad4: add             x1, x1, HEAP, lsl #32
    // 0x13e8ad8: StoreField: r0->field_3b = r1
    //     0x13e8ad8: stur            w1, [x0, #0x3b]
    // 0x13e8adc: r16 = "from"
    //     0x13e8adc: ldr             x16, [PP, #0x6360]  ; [pp+0x6360] "from"
    // 0x13e8ae0: StoreField: r0->field_3f = r16
    //     0x13e8ae0: stur            w16, [x0, #0x3f]
    // 0x13e8ae4: LoadField: r1 = r2->field_1f
    //     0x13e8ae4: ldur            w1, [x2, #0x1f]
    // 0x13e8ae8: DecompressPointer r1
    //     0x13e8ae8: add             x1, x1, HEAP, lsl #32
    // 0x13e8aec: StoreField: r0->field_43 = r1
    //     0x13e8aec: stur            w1, [x0, #0x43]
    // 0x13e8af0: r16 = "messageId"
    //     0x13e8af0: ldr             x16, [PP, #0x6378]  ; [pp+0x6378] "messageId"
    // 0x13e8af4: StoreField: r0->field_47 = r16
    //     0x13e8af4: stur            w16, [x0, #0x47]
    // 0x13e8af8: LoadField: r1 = r2->field_23
    //     0x13e8af8: ldur            w1, [x2, #0x23]
    // 0x13e8afc: DecompressPointer r1
    //     0x13e8afc: add             x1, x1, HEAP, lsl #32
    // 0x13e8b00: StoreField: r0->field_4b = r1
    //     0x13e8b00: stur            w1, [x0, #0x4b]
    // 0x13e8b04: r16 = "messageType"
    //     0x13e8b04: ldr             x16, [PP, #0x6380]  ; [pp+0x6380] "messageType"
    // 0x13e8b08: StoreField: r0->field_4f = r16
    //     0x13e8b08: stur            w16, [x0, #0x4f]
    // 0x13e8b0c: LoadField: r1 = r2->field_27
    //     0x13e8b0c: ldur            w1, [x2, #0x27]
    // 0x13e8b10: DecompressPointer r1
    //     0x13e8b10: add             x1, x1, HEAP, lsl #32
    // 0x13e8b14: StoreField: r0->field_53 = r1
    //     0x13e8b14: stur            w1, [x0, #0x53]
    // 0x13e8b18: r16 = "mutableContent"
    //     0x13e8b18: ldr             x16, [PP, #0x6398]  ; [pp+0x6398] "mutableContent"
    // 0x13e8b1c: StoreField: r0->field_57 = r16
    //     0x13e8b1c: stur            w16, [x0, #0x57]
    // 0x13e8b20: LoadField: r1 = r2->field_2b
    //     0x13e8b20: ldur            w1, [x2, #0x2b]
    // 0x13e8b24: DecompressPointer r1
    //     0x13e8b24: add             x1, x1, HEAP, lsl #32
    // 0x13e8b28: StoreField: r0->field_5b = r1
    //     0x13e8b28: stur            w1, [x0, #0x5b]
    // 0x13e8b2c: r16 = "notification"
    //     0x13e8b2c: ldr             x16, [PP, #0x63b0]  ; [pp+0x63b0] "notification"
    // 0x13e8b30: StoreField: r0->field_5f = r16
    //     0x13e8b30: stur            w16, [x0, #0x5f]
    // 0x13e8b34: LoadField: r1 = r2->field_2f
    //     0x13e8b34: ldur            w1, [x2, #0x2f]
    // 0x13e8b38: DecompressPointer r1
    //     0x13e8b38: add             x1, x1, HEAP, lsl #32
    // 0x13e8b3c: cmp             w1, NULL
    // 0x13e8b40: b.ne            #0x13e8b54
    // 0x13e8b44: mov             x3, x2
    // 0x13e8b48: mov             x2, x0
    // 0x13e8b4c: r0 = Null
    //     0x13e8b4c: mov             x0, NULL
    // 0x13e8b50: b               #0x13e8b60
    // 0x13e8b54: r0 = toMap()
    //     0x13e8b54: bl              #0x13e8c94  ; [package:firebase_messaging_platform_interface/src/remote_notification.dart] RemoteNotification::toMap
    // 0x13e8b58: ldur            x3, [fp, #-8]
    // 0x13e8b5c: ldur            x2, [fp, #-0x10]
    // 0x13e8b60: mov             x1, x2
    // 0x13e8b64: ArrayStore: r1[21] = r0  ; List_4
    //     0x13e8b64: add             x25, x1, #0x63
    //     0x13e8b68: str             w0, [x25]
    //     0x13e8b6c: tbz             w0, #0, #0x13e8b88
    //     0x13e8b70: ldurb           w16, [x1, #-1]
    //     0x13e8b74: ldurb           w17, [x0, #-1]
    //     0x13e8b78: and             x16, x17, x16, lsr #2
    //     0x13e8b7c: tst             x16, HEAP, lsr #32
    //     0x13e8b80: b.eq            #0x13e8b88
    //     0x13e8b84: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x13e8b88: r16 = "sentTime"
    //     0x13e8b88: ldr             x16, [PP, #0x63c8]  ; [pp+0x63c8] "sentTime"
    // 0x13e8b8c: StoreField: r2->field_67 = r16
    //     0x13e8b8c: stur            w16, [x2, #0x67]
    // 0x13e8b90: LoadField: r0 = r3->field_33
    //     0x13e8b90: ldur            w0, [x3, #0x33]
    // 0x13e8b94: DecompressPointer r0
    //     0x13e8b94: add             x0, x0, HEAP, lsl #32
    // 0x13e8b98: cmp             w0, NULL
    // 0x13e8b9c: b.ne            #0x13e8ba8
    // 0x13e8ba0: r0 = Null
    //     0x13e8ba0: mov             x0, NULL
    // 0x13e8ba4: b               #0x13e8bdc
    // 0x13e8ba8: LoadField: r1 = r0->field_b
    //     0x13e8ba8: ldur            x1, [x0, #0xb]
    // 0x13e8bac: tbz             x1, #0x3f, #0x13e8bb8
    // 0x13e8bb0: r4 = 999
    //     0x13e8bb0: mov             x4, #0x3e7
    // 0x13e8bb4: b               #0x13e8bbc
    // 0x13e8bb8: r4 = 0
    //     0x13e8bb8: mov             x4, #0
    // 0x13e8bbc: r0 = 1000
    //     0x13e8bbc: mov             x0, #0x3e8
    // 0x13e8bc0: sub             x5, x1, x4
    // 0x13e8bc4: sdiv            x4, x5, x0
    // 0x13e8bc8: r0 = BoxInt64Instr(r4)
    //     0x13e8bc8: sbfiz           x0, x4, #1, #0x1f
    //     0x13e8bcc: cmp             x4, x0, asr #1
    //     0x13e8bd0: b.eq            #0x13e8bdc
    //     0x13e8bd4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x13e8bd8: stur            x4, [x0, #7]
    // 0x13e8bdc: mov             x1, x2
    // 0x13e8be0: ArrayStore: r1[23] = r0  ; List_4
    //     0x13e8be0: add             x25, x1, #0x6b
    //     0x13e8be4: str             w0, [x25]
    //     0x13e8be8: tbz             w0, #0, #0x13e8c04
    //     0x13e8bec: ldurb           w16, [x1, #-1]
    //     0x13e8bf0: ldurb           w17, [x0, #-1]
    //     0x13e8bf4: and             x16, x17, x16, lsr #2
    //     0x13e8bf8: tst             x16, HEAP, lsr #32
    //     0x13e8bfc: b.eq            #0x13e8c04
    //     0x13e8c00: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x13e8c04: r16 = "threadId"
    //     0x13e8c04: ldr             x16, [PP, #0x63d0]  ; [pp+0x63d0] "threadId"
    // 0x13e8c08: StoreField: r2->field_6f = r16
    //     0x13e8c08: stur            w16, [x2, #0x6f]
    // 0x13e8c0c: LoadField: r0 = r3->field_37
    //     0x13e8c0c: ldur            w0, [x3, #0x37]
    // 0x13e8c10: DecompressPointer r0
    //     0x13e8c10: add             x0, x0, HEAP, lsl #32
    // 0x13e8c14: mov             x1, x2
    // 0x13e8c18: ArrayStore: r1[25] = r0  ; List_4
    //     0x13e8c18: add             x25, x1, #0x73
    //     0x13e8c1c: str             w0, [x25]
    //     0x13e8c20: tbz             w0, #0, #0x13e8c3c
    //     0x13e8c24: ldurb           w16, [x1, #-1]
    //     0x13e8c28: ldurb           w17, [x0, #-1]
    //     0x13e8c2c: and             x16, x17, x16, lsr #2
    //     0x13e8c30: tst             x16, HEAP, lsr #32
    //     0x13e8c34: b.eq            #0x13e8c3c
    //     0x13e8c38: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x13e8c3c: r16 = "ttl"
    //     0x13e8c3c: ldr             x16, [PP, #0x63e8]  ; [pp+0x63e8] "ttl"
    // 0x13e8c40: StoreField: r2->field_77 = r16
    //     0x13e8c40: stur            w16, [x2, #0x77]
    // 0x13e8c44: LoadField: r0 = r3->field_3b
    //     0x13e8c44: ldur            w0, [x3, #0x3b]
    // 0x13e8c48: DecompressPointer r0
    //     0x13e8c48: add             x0, x0, HEAP, lsl #32
    // 0x13e8c4c: mov             x1, x2
    // 0x13e8c50: ArrayStore: r1[27] = r0  ; List_4
    //     0x13e8c50: add             x25, x1, #0x7b
    //     0x13e8c54: str             w0, [x25]
    //     0x13e8c58: tbz             w0, #0, #0x13e8c74
    //     0x13e8c5c: ldurb           w16, [x1, #-1]
    //     0x13e8c60: ldurb           w17, [x0, #-1]
    //     0x13e8c64: and             x16, x17, x16, lsr #2
    //     0x13e8c68: tst             x16, HEAP, lsr #32
    //     0x13e8c6c: b.eq            #0x13e8c74
    //     0x13e8c70: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x13e8c74: r16 = <String, dynamic>
    //     0x13e8c74: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x13e8c78: stp             x2, x16, [SP]
    // 0x13e8c7c: r0 = Map._fromLiteral()
    //     0x13e8c7c: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x13e8c80: LeaveFrame
    //     0x13e8c80: mov             SP, fp
    //     0x13e8c84: ldp             fp, lr, [SP], #0x10
    // 0x13e8c88: ret
    //     0x13e8c88: ret             
    // 0x13e8c8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13e8c8c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13e8c90: b               #0x13e8a50
  }
}
