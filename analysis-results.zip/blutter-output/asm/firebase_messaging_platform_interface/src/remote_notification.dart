// lib: , url: package:firebase_messaging_platform_interface/src/remote_notification.dart

// class id: 1048758, size: 0x8
class :: {

  static _ _toList(/* No info */) {
    // ** addr: 0x924830, size: 0x7c
    // 0x924830: EnterFrame
    //     0x924830: stp             fp, lr, [SP, #-0x10]!
    //     0x924834: mov             fp, SP
    // 0x924838: AllocStack(0x8)
    //     0x924838: sub             SP, SP, #8
    // 0x92483c: SetupParameters(dynamic _ /* r1 => r3, fp-0x8 */)
    //     0x92483c: mov             x3, x1
    //     0x924840: stur            x1, [fp, #-8]
    // 0x924844: CheckStackOverflow
    //     0x924844: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x924848: cmp             SP, x16
    //     0x92484c: b.ls            #0x9248a4
    // 0x924850: cmp             w3, NULL
    // 0x924854: b.ne            #0x924870
    // 0x924858: r1 = <String>
    //     0x924858: ldr             x1, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    // 0x92485c: r2 = 0
    //     0x92485c: mov             x2, #0
    // 0x924860: r0 = _GrowableList()
    //     0x924860: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x924864: LeaveFrame
    //     0x924864: mov             SP, fp
    //     0x924868: ldp             fp, lr, [SP], #0x10
    // 0x92486c: ret
    //     0x92486c: ret             
    // 0x924870: mov             x0, x3
    // 0x924874: r2 = Null
    //     0x924874: mov             x2, NULL
    // 0x924878: r1 = Null
    //     0x924878: mov             x1, NULL
    // 0x92487c: r8 = Iterable
    //     0x92487c: ldr             x8, [PP, #0x11a0]  ; [pp+0x11a0] Type: Iterable
    // 0x924880: r3 = Null
    //     0x924880: ldr             x3, [PP, #0x6760]  ; [pp+0x6760] Null
    // 0x924884: r0 = Iterable()
    //     0x924884: bl              #0x7e7350  ; IsType_Iterable_Stub
    // 0x924888: ldur            x2, [fp, #-8]
    // 0x92488c: r1 = <String>
    //     0x92488c: ldr             x1, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    // 0x924890: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x924890: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x924894: r0 = List.from()
    //     0x924894: bl              #0x876494  ; [dart:core] List::List.from
    // 0x924898: LeaveFrame
    //     0x924898: mov             SP, fp
    //     0x92489c: ldp             fp, lr, [SP], #0x10
    // 0x9248a0: ret
    //     0x9248a0: ret             
    // 0x9248a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9248a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9248a8: b               #0x924850
  }
}

// class id: 3345, size: 0x14, field offset: 0x8
//   const constructor, 
class WebNotification extends Object {

  factory _ WebNotification.fromMap(/* No info */) {
    // ** addr: 0x923bfc, size: 0x188
    // 0x923bfc: EnterFrame
    //     0x923bfc: stp             fp, lr, [SP, #-0x10]!
    //     0x923c00: mov             fp, SP
    // 0x923c04: AllocStack(0x18)
    //     0x923c04: sub             SP, SP, #0x18
    // 0x923c08: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0x923c08: mov             x0, x2
    //     0x923c0c: stur            x2, [fp, #-8]
    // 0x923c10: CheckStackOverflow
    //     0x923c10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x923c14: cmp             SP, x16
    //     0x923c18: b.ls            #0x923d7c
    // 0x923c1c: mov             x1, x0
    // 0x923c20: r2 = "analyticsLabel"
    //     0x923c20: ldr             x2, [PP, #0x6518]  ; [pp+0x6518] "analyticsLabel"
    // 0x923c24: r0 = _getValueOrData()
    //     0x923c24: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x923c28: ldur            x3, [fp, #-8]
    // 0x923c2c: LoadField: r1 = r3->field_f
    //     0x923c2c: ldur            w1, [x3, #0xf]
    // 0x923c30: DecompressPointer r1
    //     0x923c30: add             x1, x1, HEAP, lsl #32
    // 0x923c34: cmp             w1, w0
    // 0x923c38: b.ne            #0x923c44
    // 0x923c3c: r4 = Null
    //     0x923c3c: mov             x4, NULL
    // 0x923c40: b               #0x923c48
    // 0x923c44: mov             x4, x0
    // 0x923c48: mov             x0, x4
    // 0x923c4c: stur            x4, [fp, #-0x10]
    // 0x923c50: r2 = Null
    //     0x923c50: mov             x2, NULL
    // 0x923c54: r1 = Null
    //     0x923c54: mov             x1, NULL
    // 0x923c58: r4 = 60
    //     0x923c58: mov             x4, #0x3c
    // 0x923c5c: branchIfSmi(r0, 0x923c68)
    //     0x923c5c: tbz             w0, #0, #0x923c68
    // 0x923c60: r4 = LoadClassIdInstr(r0)
    //     0x923c60: ldur            x4, [x0, #-1]
    //     0x923c64: ubfx            x4, x4, #0xc, #0x14
    // 0x923c68: sub             x4, x4, #0x5e
    // 0x923c6c: cmp             x4, #1
    // 0x923c70: b.ls            #0x923c80
    // 0x923c74: r8 = String?
    //     0x923c74: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x923c78: r3 = Null
    //     0x923c78: ldr             x3, [PP, #0x6520]  ; [pp+0x6520] Null
    // 0x923c7c: r0 = String?()
    //     0x923c7c: bl              #0x7db310  ; IsType_String?_Stub
    // 0x923c80: ldur            x1, [fp, #-8]
    // 0x923c84: r2 = "image"
    //     0x923c84: ldr             x2, [PP, #0x6530]  ; [pp+0x6530] "image"
    // 0x923c88: r0 = _getValueOrData()
    //     0x923c88: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x923c8c: ldur            x3, [fp, #-8]
    // 0x923c90: LoadField: r1 = r3->field_f
    //     0x923c90: ldur            w1, [x3, #0xf]
    // 0x923c94: DecompressPointer r1
    //     0x923c94: add             x1, x1, HEAP, lsl #32
    // 0x923c98: cmp             w1, w0
    // 0x923c9c: b.ne            #0x923ca8
    // 0x923ca0: r4 = Null
    //     0x923ca0: mov             x4, NULL
    // 0x923ca4: b               #0x923cac
    // 0x923ca8: mov             x4, x0
    // 0x923cac: mov             x0, x4
    // 0x923cb0: stur            x4, [fp, #-0x18]
    // 0x923cb4: r2 = Null
    //     0x923cb4: mov             x2, NULL
    // 0x923cb8: r1 = Null
    //     0x923cb8: mov             x1, NULL
    // 0x923cbc: r4 = 60
    //     0x923cbc: mov             x4, #0x3c
    // 0x923cc0: branchIfSmi(r0, 0x923ccc)
    //     0x923cc0: tbz             w0, #0, #0x923ccc
    // 0x923cc4: r4 = LoadClassIdInstr(r0)
    //     0x923cc4: ldur            x4, [x0, #-1]
    //     0x923cc8: ubfx            x4, x4, #0xc, #0x14
    // 0x923ccc: sub             x4, x4, #0x5e
    // 0x923cd0: cmp             x4, #1
    // 0x923cd4: b.ls            #0x923ce4
    // 0x923cd8: r8 = String?
    //     0x923cd8: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x923cdc: r3 = Null
    //     0x923cdc: ldr             x3, [PP, #0x6538]  ; [pp+0x6538] Null
    // 0x923ce0: r0 = String?()
    //     0x923ce0: bl              #0x7db310  ; IsType_String?_Stub
    // 0x923ce4: ldur            x1, [fp, #-8]
    // 0x923ce8: r2 = "link"
    //     0x923ce8: ldr             x2, [PP, #0x6548]  ; [pp+0x6548] "link"
    // 0x923cec: r0 = _getValueOrData()
    //     0x923cec: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x923cf0: mov             x1, x0
    // 0x923cf4: ldur            x0, [fp, #-8]
    // 0x923cf8: LoadField: r2 = r0->field_f
    //     0x923cf8: ldur            w2, [x0, #0xf]
    // 0x923cfc: DecompressPointer r2
    //     0x923cfc: add             x2, x2, HEAP, lsl #32
    // 0x923d00: cmp             w2, w1
    // 0x923d04: b.ne            #0x923d10
    // 0x923d08: r5 = Null
    //     0x923d08: mov             x5, NULL
    // 0x923d0c: b               #0x923d14
    // 0x923d10: mov             x5, x1
    // 0x923d14: ldur            x4, [fp, #-0x10]
    // 0x923d18: ldur            x3, [fp, #-0x18]
    // 0x923d1c: mov             x0, x5
    // 0x923d20: stur            x5, [fp, #-8]
    // 0x923d24: r2 = Null
    //     0x923d24: mov             x2, NULL
    // 0x923d28: r1 = Null
    //     0x923d28: mov             x1, NULL
    // 0x923d2c: r4 = 60
    //     0x923d2c: mov             x4, #0x3c
    // 0x923d30: branchIfSmi(r0, 0x923d3c)
    //     0x923d30: tbz             w0, #0, #0x923d3c
    // 0x923d34: r4 = LoadClassIdInstr(r0)
    //     0x923d34: ldur            x4, [x0, #-1]
    //     0x923d38: ubfx            x4, x4, #0xc, #0x14
    // 0x923d3c: sub             x4, x4, #0x5e
    // 0x923d40: cmp             x4, #1
    // 0x923d44: b.ls            #0x923d54
    // 0x923d48: r8 = String?
    //     0x923d48: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x923d4c: r3 = Null
    //     0x923d4c: ldr             x3, [PP, #0x6550]  ; [pp+0x6550] Null
    // 0x923d50: r0 = String?()
    //     0x923d50: bl              #0x7db310  ; IsType_String?_Stub
    // 0x923d54: r0 = WebNotification()
    //     0x923d54: bl              #0x923d84  ; AllocateWebNotificationStub -> WebNotification (size=0x14)
    // 0x923d58: ldur            x1, [fp, #-0x10]
    // 0x923d5c: StoreField: r0->field_7 = r1
    //     0x923d5c: stur            w1, [x0, #7]
    // 0x923d60: ldur            x1, [fp, #-0x18]
    // 0x923d64: StoreField: r0->field_b = r1
    //     0x923d64: stur            w1, [x0, #0xb]
    // 0x923d68: ldur            x1, [fp, #-8]
    // 0x923d6c: StoreField: r0->field_f = r1
    //     0x923d6c: stur            w1, [x0, #0xf]
    // 0x923d70: LeaveFrame
    //     0x923d70: mov             SP, fp
    //     0x923d74: ldp             fp, lr, [SP], #0x10
    // 0x923d78: ret
    //     0x923d78: ret             
    // 0x923d7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x923d7c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x923d80: b               #0x923c1c
  }
  _ toMap(/* No info */) {
    // ** addr: 0x13e8e60, size: 0x8c
    // 0x13e8e60: EnterFrame
    //     0x13e8e60: stp             fp, lr, [SP, #-0x10]!
    //     0x13e8e64: mov             fp, SP
    // 0x13e8e68: AllocStack(0x18)
    //     0x13e8e68: sub             SP, SP, #0x18
    // 0x13e8e6c: SetupParameters(WebNotification this /* r1 => r0, fp-0x8 */)
    //     0x13e8e6c: mov             x0, x1
    //     0x13e8e70: stur            x1, [fp, #-8]
    // 0x13e8e74: CheckStackOverflow
    //     0x13e8e74: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13e8e78: cmp             SP, x16
    //     0x13e8e7c: b.ls            #0x13e8ee4
    // 0x13e8e80: r1 = Null
    //     0x13e8e80: mov             x1, NULL
    // 0x13e8e84: r2 = 12
    //     0x13e8e84: mov             x2, #0xc
    // 0x13e8e88: r0 = AllocateArray()
    //     0x13e8e88: bl              #0x13df928  ; AllocateArrayStub
    // 0x13e8e8c: r16 = "analyticsLabel"
    //     0x13e8e8c: ldr             x16, [PP, #0x6518]  ; [pp+0x6518] "analyticsLabel"
    // 0x13e8e90: StoreField: r0->field_f = r16
    //     0x13e8e90: stur            w16, [x0, #0xf]
    // 0x13e8e94: ldur            x1, [fp, #-8]
    // 0x13e8e98: LoadField: r2 = r1->field_7
    //     0x13e8e98: ldur            w2, [x1, #7]
    // 0x13e8e9c: DecompressPointer r2
    //     0x13e8e9c: add             x2, x2, HEAP, lsl #32
    // 0x13e8ea0: StoreField: r0->field_13 = r2
    //     0x13e8ea0: stur            w2, [x0, #0x13]
    // 0x13e8ea4: r16 = "image"
    //     0x13e8ea4: ldr             x16, [PP, #0x6530]  ; [pp+0x6530] "image"
    // 0x13e8ea8: ArrayStore: r0[0] = r16  ; List_4
    //     0x13e8ea8: stur            w16, [x0, #0x17]
    // 0x13e8eac: LoadField: r2 = r1->field_b
    //     0x13e8eac: ldur            w2, [x1, #0xb]
    // 0x13e8eb0: DecompressPointer r2
    //     0x13e8eb0: add             x2, x2, HEAP, lsl #32
    // 0x13e8eb4: StoreField: r0->field_1b = r2
    //     0x13e8eb4: stur            w2, [x0, #0x1b]
    // 0x13e8eb8: r16 = "link"
    //     0x13e8eb8: ldr             x16, [PP, #0x6548]  ; [pp+0x6548] "link"
    // 0x13e8ebc: StoreField: r0->field_1f = r16
    //     0x13e8ebc: stur            w16, [x0, #0x1f]
    // 0x13e8ec0: LoadField: r2 = r1->field_f
    //     0x13e8ec0: ldur            w2, [x1, #0xf]
    // 0x13e8ec4: DecompressPointer r2
    //     0x13e8ec4: add             x2, x2, HEAP, lsl #32
    // 0x13e8ec8: StoreField: r0->field_23 = r2
    //     0x13e8ec8: stur            w2, [x0, #0x23]
    // 0x13e8ecc: r16 = <String, dynamic>
    //     0x13e8ecc: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x13e8ed0: stp             x0, x16, [SP]
    // 0x13e8ed4: r0 = Map._fromLiteral()
    //     0x13e8ed4: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x13e8ed8: LeaveFrame
    //     0x13e8ed8: mov             SP, fp
    //     0x13e8edc: ldp             fp, lr, [SP], #0x10
    // 0x13e8ee0: ret
    //     0x13e8ee0: ret             
    // 0x13e8ee4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13e8ee4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13e8ee8: b               #0x13e8e80
  }
}

// class id: 3346, size: 0x14, field offset: 0x8
//   const constructor, 
class AppleNotificationSound extends Object {

  factory _ AppleNotificationSound.fromMap(/* No info */) {
    // ** addr: 0x924078, size: 0x1a0
    // 0x924078: EnterFrame
    //     0x924078: stp             fp, lr, [SP, #-0x10]!
    //     0x92407c: mov             fp, SP
    // 0x924080: AllocStack(0x18)
    //     0x924080: sub             SP, SP, #0x18
    // 0x924084: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0x924084: mov             x0, x2
    //     0x924088: stur            x2, [fp, #-8]
    // 0x92408c: CheckStackOverflow
    //     0x92408c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x924090: cmp             SP, x16
    //     0x924094: b.ls            #0x924210
    // 0x924098: mov             x1, x0
    // 0x92409c: r2 = "critical"
    //     0x92409c: ldr             x2, [PP, #0x65e0]  ; [pp+0x65e0] "critical"
    // 0x9240a0: r0 = _getValueOrData()
    //     0x9240a0: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x9240a4: ldur            x3, [fp, #-8]
    // 0x9240a8: LoadField: r1 = r3->field_f
    //     0x9240a8: ldur            w1, [x3, #0xf]
    // 0x9240ac: DecompressPointer r1
    //     0x9240ac: add             x1, x1, HEAP, lsl #32
    // 0x9240b0: cmp             w1, w0
    // 0x9240b4: b.ne            #0x9240bc
    // 0x9240b8: r0 = Null
    //     0x9240b8: mov             x0, NULL
    // 0x9240bc: cmp             w0, NULL
    // 0x9240c0: b.ne            #0x9240cc
    // 0x9240c4: r4 = false
    //     0x9240c4: add             x4, NULL, #0x30  ; false
    // 0x9240c8: b               #0x9240d0
    // 0x9240cc: mov             x4, x0
    // 0x9240d0: mov             x0, x4
    // 0x9240d4: stur            x4, [fp, #-0x10]
    // 0x9240d8: r2 = Null
    //     0x9240d8: mov             x2, NULL
    // 0x9240dc: r1 = Null
    //     0x9240dc: mov             x1, NULL
    // 0x9240e0: r4 = 60
    //     0x9240e0: mov             x4, #0x3c
    // 0x9240e4: branchIfSmi(r0, 0x9240f0)
    //     0x9240e4: tbz             w0, #0, #0x9240f0
    // 0x9240e8: r4 = LoadClassIdInstr(r0)
    //     0x9240e8: ldur            x4, [x0, #-1]
    //     0x9240ec: ubfx            x4, x4, #0xc, #0x14
    // 0x9240f0: cmp             x4, #0x3f
    // 0x9240f4: b.eq            #0x924104
    // 0x9240f8: r8 = bool
    //     0x9240f8: ldr             x8, [PP, #0xb18]  ; [pp+0xb18] Type: bool
    // 0x9240fc: r3 = Null
    //     0x9240fc: ldr             x3, [PP, #0x65e8]  ; [pp+0x65e8] Null
    // 0x924100: r0 = bool()
    //     0x924100: bl              #0x13ee15c  ; IsType_bool_Stub
    // 0x924104: ldur            x1, [fp, #-8]
    // 0x924108: r2 = "name"
    //     0x924108: ldr             x2, [PP, #0x6120]  ; [pp+0x6120] "name"
    // 0x92410c: r0 = _getValueOrData()
    //     0x92410c: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x924110: ldur            x3, [fp, #-8]
    // 0x924114: LoadField: r1 = r3->field_f
    //     0x924114: ldur            w1, [x3, #0xf]
    // 0x924118: DecompressPointer r1
    //     0x924118: add             x1, x1, HEAP, lsl #32
    // 0x92411c: cmp             w1, w0
    // 0x924120: b.ne            #0x92412c
    // 0x924124: r4 = Null
    //     0x924124: mov             x4, NULL
    // 0x924128: b               #0x924130
    // 0x92412c: mov             x4, x0
    // 0x924130: mov             x0, x4
    // 0x924134: stur            x4, [fp, #-0x18]
    // 0x924138: r2 = Null
    //     0x924138: mov             x2, NULL
    // 0x92413c: r1 = Null
    //     0x92413c: mov             x1, NULL
    // 0x924140: r4 = 60
    //     0x924140: mov             x4, #0x3c
    // 0x924144: branchIfSmi(r0, 0x924150)
    //     0x924144: tbz             w0, #0, #0x924150
    // 0x924148: r4 = LoadClassIdInstr(r0)
    //     0x924148: ldur            x4, [x0, #-1]
    //     0x92414c: ubfx            x4, x4, #0xc, #0x14
    // 0x924150: sub             x4, x4, #0x5e
    // 0x924154: cmp             x4, #1
    // 0x924158: b.ls            #0x924168
    // 0x92415c: r8 = String?
    //     0x92415c: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x924160: r3 = Null
    //     0x924160: ldr             x3, [PP, #0x65f8]  ; [pp+0x65f8] Null
    // 0x924164: r0 = String?()
    //     0x924164: bl              #0x7db310  ; IsType_String?_Stub
    // 0x924168: ldur            x1, [fp, #-8]
    // 0x92416c: r2 = "volume"
    //     0x92416c: ldr             x2, [PP, #0x6608]  ; [pp+0x6608] "volume"
    // 0x924170: r0 = _getValueOrData()
    //     0x924170: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x924174: mov             x1, x0
    // 0x924178: ldur            x0, [fp, #-8]
    // 0x92417c: LoadField: r2 = r0->field_f
    //     0x92417c: ldur            w2, [x0, #0xf]
    // 0x924180: DecompressPointer r2
    //     0x924180: add             x2, x2, HEAP, lsl #32
    // 0x924184: cmp             w2, w1
    // 0x924188: b.ne            #0x924194
    // 0x92418c: r0 = Null
    //     0x92418c: mov             x0, NULL
    // 0x924190: b               #0x924198
    // 0x924194: mov             x0, x1
    // 0x924198: cmp             w0, NULL
    // 0x92419c: b.ne            #0x9241a8
    // 0x9241a0: r5 = 0
    //     0x9241a0: mov             x5, #0
    // 0x9241a4: b               #0x9241ac
    // 0x9241a8: mov             x5, x0
    // 0x9241ac: ldur            x4, [fp, #-0x10]
    // 0x9241b0: ldur            x3, [fp, #-0x18]
    // 0x9241b4: mov             x0, x5
    // 0x9241b8: stur            x5, [fp, #-8]
    // 0x9241bc: r2 = Null
    //     0x9241bc: mov             x2, NULL
    // 0x9241c0: r1 = Null
    //     0x9241c0: mov             x1, NULL
    // 0x9241c4: branchIfSmi(r0, 0x9241e8)
    //     0x9241c4: tbz             w0, #0, #0x9241e8
    // 0x9241c8: r4 = LoadClassIdInstr(r0)
    //     0x9241c8: ldur            x4, [x0, #-1]
    //     0x9241cc: ubfx            x4, x4, #0xc, #0x14
    // 0x9241d0: sub             x4, x4, #0x3c
    // 0x9241d4: cmp             x4, #2
    // 0x9241d8: b.ls            #0x9241e8
    // 0x9241dc: r8 = num
    //     0x9241dc: ldr             x8, [PP, #0x398]  ; [pp+0x398] Type: num
    // 0x9241e0: r3 = Null
    //     0x9241e0: ldr             x3, [PP, #0x6610]  ; [pp+0x6610] Null
    // 0x9241e4: r0 = num()
    //     0x9241e4: bl              #0x13ee9b0  ; IsType_num_Stub
    // 0x9241e8: r0 = AppleNotificationSound()
    //     0x9241e8: bl              #0x924218  ; AllocateAppleNotificationSoundStub -> AppleNotificationSound (size=0x14)
    // 0x9241ec: ldur            x1, [fp, #-0x10]
    // 0x9241f0: StoreField: r0->field_7 = r1
    //     0x9241f0: stur            w1, [x0, #7]
    // 0x9241f4: ldur            x1, [fp, #-0x18]
    // 0x9241f8: StoreField: r0->field_b = r1
    //     0x9241f8: stur            w1, [x0, #0xb]
    // 0x9241fc: ldur            x1, [fp, #-8]
    // 0x924200: StoreField: r0->field_f = r1
    //     0x924200: stur            w1, [x0, #0xf]
    // 0x924204: LeaveFrame
    //     0x924204: mov             SP, fp
    //     0x924208: ldp             fp, lr, [SP], #0x10
    // 0x92420c: ret
    //     0x92420c: ret             
    // 0x924210: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x924210: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x924214: b               #0x924098
  }
  _ toMap(/* No info */) {
    // ** addr: 0x13e8ff8, size: 0x8c
    // 0x13e8ff8: EnterFrame
    //     0x13e8ff8: stp             fp, lr, [SP, #-0x10]!
    //     0x13e8ffc: mov             fp, SP
    // 0x13e9000: AllocStack(0x18)
    //     0x13e9000: sub             SP, SP, #0x18
    // 0x13e9004: SetupParameters(AppleNotificationSound this /* r1 => r0, fp-0x8 */)
    //     0x13e9004: mov             x0, x1
    //     0x13e9008: stur            x1, [fp, #-8]
    // 0x13e900c: CheckStackOverflow
    //     0x13e900c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13e9010: cmp             SP, x16
    //     0x13e9014: b.ls            #0x13e907c
    // 0x13e9018: r1 = Null
    //     0x13e9018: mov             x1, NULL
    // 0x13e901c: r2 = 12
    //     0x13e901c: mov             x2, #0xc
    // 0x13e9020: r0 = AllocateArray()
    //     0x13e9020: bl              #0x13df928  ; AllocateArrayStub
    // 0x13e9024: r16 = "critical"
    //     0x13e9024: ldr             x16, [PP, #0x65e0]  ; [pp+0x65e0] "critical"
    // 0x13e9028: StoreField: r0->field_f = r16
    //     0x13e9028: stur            w16, [x0, #0xf]
    // 0x13e902c: ldur            x1, [fp, #-8]
    // 0x13e9030: LoadField: r2 = r1->field_7
    //     0x13e9030: ldur            w2, [x1, #7]
    // 0x13e9034: DecompressPointer r2
    //     0x13e9034: add             x2, x2, HEAP, lsl #32
    // 0x13e9038: StoreField: r0->field_13 = r2
    //     0x13e9038: stur            w2, [x0, #0x13]
    // 0x13e903c: r16 = "name"
    //     0x13e903c: ldr             x16, [PP, #0x6120]  ; [pp+0x6120] "name"
    // 0x13e9040: ArrayStore: r0[0] = r16  ; List_4
    //     0x13e9040: stur            w16, [x0, #0x17]
    // 0x13e9044: LoadField: r2 = r1->field_b
    //     0x13e9044: ldur            w2, [x1, #0xb]
    // 0x13e9048: DecompressPointer r2
    //     0x13e9048: add             x2, x2, HEAP, lsl #32
    // 0x13e904c: StoreField: r0->field_1b = r2
    //     0x13e904c: stur            w2, [x0, #0x1b]
    // 0x13e9050: r16 = "volume"
    //     0x13e9050: ldr             x16, [PP, #0x6608]  ; [pp+0x6608] "volume"
    // 0x13e9054: StoreField: r0->field_1f = r16
    //     0x13e9054: stur            w16, [x0, #0x1f]
    // 0x13e9058: LoadField: r2 = r1->field_f
    //     0x13e9058: ldur            w2, [x1, #0xf]
    // 0x13e905c: DecompressPointer r2
    //     0x13e905c: add             x2, x2, HEAP, lsl #32
    // 0x13e9060: StoreField: r0->field_23 = r2
    //     0x13e9060: stur            w2, [x0, #0x23]
    // 0x13e9064: r16 = <String, dynamic>
    //     0x13e9064: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x13e9068: stp             x0, x16, [SP]
    // 0x13e906c: r0 = Map._fromLiteral()
    //     0x13e906c: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x13e9070: LeaveFrame
    //     0x13e9070: mov             SP, fp
    //     0x13e9074: ldp             fp, lr, [SP], #0x10
    // 0x13e9078: ret
    //     0x13e9078: ret             
    // 0x13e907c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13e907c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13e9080: b               #0x13e9018
  }
}

// class id: 3347, size: 0x20, field offset: 0x8
//   const constructor, 
class AppleNotification extends Object {

  factory _ AppleNotification.fromMap(/* No info */) {
    // ** addr: 0x923d90, size: 0x2dc
    // 0x923d90: EnterFrame
    //     0x923d90: stp             fp, lr, [SP, #-0x10]!
    //     0x923d94: mov             fp, SP
    // 0x923d98: AllocStack(0x30)
    //     0x923d98: sub             SP, SP, #0x30
    // 0x923d9c: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0x923d9c: mov             x0, x2
    //     0x923da0: stur            x2, [fp, #-8]
    // 0x923da4: CheckStackOverflow
    //     0x923da4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x923da8: cmp             SP, x16
    //     0x923dac: b.ls            #0x924064
    // 0x923db0: mov             x1, x0
    // 0x923db4: r2 = "badge"
    //     0x923db4: ldr             x2, [PP, #0x6560]  ; [pp+0x6560] "badge"
    // 0x923db8: r0 = _getValueOrData()
    //     0x923db8: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x923dbc: ldur            x3, [fp, #-8]
    // 0x923dc0: LoadField: r1 = r3->field_f
    //     0x923dc0: ldur            w1, [x3, #0xf]
    // 0x923dc4: DecompressPointer r1
    //     0x923dc4: add             x1, x1, HEAP, lsl #32
    // 0x923dc8: cmp             w1, w0
    // 0x923dcc: b.ne            #0x923dd8
    // 0x923dd0: r4 = Null
    //     0x923dd0: mov             x4, NULL
    // 0x923dd4: b               #0x923ddc
    // 0x923dd8: mov             x4, x0
    // 0x923ddc: mov             x0, x4
    // 0x923de0: stur            x4, [fp, #-0x10]
    // 0x923de4: r2 = Null
    //     0x923de4: mov             x2, NULL
    // 0x923de8: r1 = Null
    //     0x923de8: mov             x1, NULL
    // 0x923dec: r4 = 60
    //     0x923dec: mov             x4, #0x3c
    // 0x923df0: branchIfSmi(r0, 0x923dfc)
    //     0x923df0: tbz             w0, #0, #0x923dfc
    // 0x923df4: r4 = LoadClassIdInstr(r0)
    //     0x923df4: ldur            x4, [x0, #-1]
    //     0x923df8: ubfx            x4, x4, #0xc, #0x14
    // 0x923dfc: sub             x4, x4, #0x5e
    // 0x923e00: cmp             x4, #1
    // 0x923e04: b.ls            #0x923e14
    // 0x923e08: r8 = String?
    //     0x923e08: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x923e0c: r3 = Null
    //     0x923e0c: ldr             x3, [PP, #0x6568]  ; [pp+0x6568] Null
    // 0x923e10: r0 = String?()
    //     0x923e10: bl              #0x7db310  ; IsType_String?_Stub
    // 0x923e14: ldur            x1, [fp, #-8]
    // 0x923e18: r2 = "subtitle"
    //     0x923e18: ldr             x2, [PP, #0x6578]  ; [pp+0x6578] "subtitle"
    // 0x923e1c: r0 = _getValueOrData()
    //     0x923e1c: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x923e20: ldur            x3, [fp, #-8]
    // 0x923e24: LoadField: r1 = r3->field_f
    //     0x923e24: ldur            w1, [x3, #0xf]
    // 0x923e28: DecompressPointer r1
    //     0x923e28: add             x1, x1, HEAP, lsl #32
    // 0x923e2c: cmp             w1, w0
    // 0x923e30: b.ne            #0x923e3c
    // 0x923e34: r4 = Null
    //     0x923e34: mov             x4, NULL
    // 0x923e38: b               #0x923e40
    // 0x923e3c: mov             x4, x0
    // 0x923e40: mov             x0, x4
    // 0x923e44: stur            x4, [fp, #-0x18]
    // 0x923e48: r2 = Null
    //     0x923e48: mov             x2, NULL
    // 0x923e4c: r1 = Null
    //     0x923e4c: mov             x1, NULL
    // 0x923e50: r4 = 60
    //     0x923e50: mov             x4, #0x3c
    // 0x923e54: branchIfSmi(r0, 0x923e60)
    //     0x923e54: tbz             w0, #0, #0x923e60
    // 0x923e58: r4 = LoadClassIdInstr(r0)
    //     0x923e58: ldur            x4, [x0, #-1]
    //     0x923e5c: ubfx            x4, x4, #0xc, #0x14
    // 0x923e60: sub             x4, x4, #0x5e
    // 0x923e64: cmp             x4, #1
    // 0x923e68: b.ls            #0x923e78
    // 0x923e6c: r8 = String?
    //     0x923e6c: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x923e70: r3 = Null
    //     0x923e70: ldr             x3, [PP, #0x6580]  ; [pp+0x6580] Null
    // 0x923e74: r0 = String?()
    //     0x923e74: bl              #0x7db310  ; IsType_String?_Stub
    // 0x923e78: ldur            x1, [fp, #-8]
    // 0x923e7c: r2 = "subtitleLocArgs"
    //     0x923e7c: ldr             x2, [PP, #0x6590]  ; [pp+0x6590] "subtitleLocArgs"
    // 0x923e80: r0 = _getValueOrData()
    //     0x923e80: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x923e84: mov             x1, x0
    // 0x923e88: ldur            x0, [fp, #-8]
    // 0x923e8c: LoadField: r2 = r0->field_f
    //     0x923e8c: ldur            w2, [x0, #0xf]
    // 0x923e90: DecompressPointer r2
    //     0x923e90: add             x2, x2, HEAP, lsl #32
    // 0x923e94: cmp             w2, w1
    // 0x923e98: b.ne            #0x923ea0
    // 0x923e9c: r1 = Null
    //     0x923e9c: mov             x1, NULL
    // 0x923ea0: r0 = _toList()
    //     0x923ea0: bl              #0x924830  ; [package:firebase_messaging_platform_interface/src/remote_notification.dart] ::_toList
    // 0x923ea4: ldur            x1, [fp, #-8]
    // 0x923ea8: r2 = "subtitleLocKey"
    //     0x923ea8: ldr             x2, [PP, #0x6598]  ; [pp+0x6598] "subtitleLocKey"
    // 0x923eac: stur            x0, [fp, #-0x20]
    // 0x923eb0: r0 = _getValueOrData()
    //     0x923eb0: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x923eb4: ldur            x3, [fp, #-8]
    // 0x923eb8: LoadField: r1 = r3->field_f
    //     0x923eb8: ldur            w1, [x3, #0xf]
    // 0x923ebc: DecompressPointer r1
    //     0x923ebc: add             x1, x1, HEAP, lsl #32
    // 0x923ec0: cmp             w1, w0
    // 0x923ec4: b.ne            #0x923ed0
    // 0x923ec8: r4 = Null
    //     0x923ec8: mov             x4, NULL
    // 0x923ecc: b               #0x923ed4
    // 0x923ed0: mov             x4, x0
    // 0x923ed4: mov             x0, x4
    // 0x923ed8: stur            x4, [fp, #-0x28]
    // 0x923edc: r2 = Null
    //     0x923edc: mov             x2, NULL
    // 0x923ee0: r1 = Null
    //     0x923ee0: mov             x1, NULL
    // 0x923ee4: r4 = 60
    //     0x923ee4: mov             x4, #0x3c
    // 0x923ee8: branchIfSmi(r0, 0x923ef4)
    //     0x923ee8: tbz             w0, #0, #0x923ef4
    // 0x923eec: r4 = LoadClassIdInstr(r0)
    //     0x923eec: ldur            x4, [x0, #-1]
    //     0x923ef0: ubfx            x4, x4, #0xc, #0x14
    // 0x923ef4: sub             x4, x4, #0x5e
    // 0x923ef8: cmp             x4, #1
    // 0x923efc: b.ls            #0x923f0c
    // 0x923f00: r8 = String?
    //     0x923f00: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x923f04: r3 = Null
    //     0x923f04: ldr             x3, [PP, #0x65a0]  ; [pp+0x65a0] Null
    // 0x923f08: r0 = String?()
    //     0x923f08: bl              #0x7db310  ; IsType_String?_Stub
    // 0x923f0c: ldur            x1, [fp, #-8]
    // 0x923f10: r2 = "imageUrl"
    //     0x923f10: ldr             x2, [PP, #0x65b0]  ; [pp+0x65b0] "imageUrl"
    // 0x923f14: r0 = _getValueOrData()
    //     0x923f14: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x923f18: ldur            x3, [fp, #-8]
    // 0x923f1c: LoadField: r1 = r3->field_f
    //     0x923f1c: ldur            w1, [x3, #0xf]
    // 0x923f20: DecompressPointer r1
    //     0x923f20: add             x1, x1, HEAP, lsl #32
    // 0x923f24: cmp             w1, w0
    // 0x923f28: b.ne            #0x923f34
    // 0x923f2c: r4 = Null
    //     0x923f2c: mov             x4, NULL
    // 0x923f30: b               #0x923f38
    // 0x923f34: mov             x4, x0
    // 0x923f38: mov             x0, x4
    // 0x923f3c: stur            x4, [fp, #-0x30]
    // 0x923f40: r2 = Null
    //     0x923f40: mov             x2, NULL
    // 0x923f44: r1 = Null
    //     0x923f44: mov             x1, NULL
    // 0x923f48: r4 = 60
    //     0x923f48: mov             x4, #0x3c
    // 0x923f4c: branchIfSmi(r0, 0x923f58)
    //     0x923f4c: tbz             w0, #0, #0x923f58
    // 0x923f50: r4 = LoadClassIdInstr(r0)
    //     0x923f50: ldur            x4, [x0, #-1]
    //     0x923f54: ubfx            x4, x4, #0xc, #0x14
    // 0x923f58: sub             x4, x4, #0x5e
    // 0x923f5c: cmp             x4, #1
    // 0x923f60: b.ls            #0x923f70
    // 0x923f64: r8 = String?
    //     0x923f64: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x923f68: r3 = Null
    //     0x923f68: ldr             x3, [PP, #0x65b8]  ; [pp+0x65b8] Null
    // 0x923f6c: r0 = String?()
    //     0x923f6c: bl              #0x7db310  ; IsType_String?_Stub
    // 0x923f70: ldur            x1, [fp, #-8]
    // 0x923f74: r2 = "sound"
    //     0x923f74: ldr             x2, [PP, #0x65c8]  ; [pp+0x65c8] "sound"
    // 0x923f78: r0 = _getValueOrData()
    //     0x923f78: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x923f7c: mov             x1, x0
    // 0x923f80: ldur            x0, [fp, #-8]
    // 0x923f84: LoadField: r2 = r0->field_f
    //     0x923f84: ldur            w2, [x0, #0xf]
    // 0x923f88: DecompressPointer r2
    //     0x923f88: add             x2, x2, HEAP, lsl #32
    // 0x923f8c: cmp             w2, w1
    // 0x923f90: b.eq            #0x923f9c
    // 0x923f94: cmp             w1, NULL
    // 0x923f98: b.ne            #0x923fa4
    // 0x923f9c: r5 = Null
    //     0x923f9c: mov             x5, NULL
    // 0x923fa0: b               #0x92400c
    // 0x923fa4: mov             x1, x0
    // 0x923fa8: r2 = "sound"
    //     0x923fa8: ldr             x2, [PP, #0x65c8]  ; [pp+0x65c8] "sound"
    // 0x923fac: r0 = _getValueOrData()
    //     0x923fac: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x923fb0: mov             x1, x0
    // 0x923fb4: ldur            x0, [fp, #-8]
    // 0x923fb8: LoadField: r2 = r0->field_f
    //     0x923fb8: ldur            w2, [x0, #0xf]
    // 0x923fbc: DecompressPointer r2
    //     0x923fbc: add             x2, x2, HEAP, lsl #32
    // 0x923fc0: cmp             w2, w1
    // 0x923fc4: b.ne            #0x923fd0
    // 0x923fc8: r3 = Null
    //     0x923fc8: mov             x3, NULL
    // 0x923fcc: b               #0x923fd4
    // 0x923fd0: mov             x3, x1
    // 0x923fd4: mov             x0, x3
    // 0x923fd8: stur            x3, [fp, #-8]
    // 0x923fdc: r2 = Null
    //     0x923fdc: mov             x2, NULL
    // 0x923fe0: r1 = Null
    //     0x923fe0: mov             x1, NULL
    // 0x923fe4: r8 = Map
    //     0x923fe4: ldr             x8, [PP, #0x1c8]  ; [pp+0x1c8] Type: Map
    // 0x923fe8: r3 = Null
    //     0x923fe8: ldr             x3, [PP, #0x65d0]  ; [pp+0x65d0] Null
    // 0x923fec: r0 = Map()
    //     0x923fec: bl              #0x13efa40  ; IsType_Map_Stub
    // 0x923ff0: ldur            x2, [fp, #-8]
    // 0x923ff4: r1 = <String, dynamic>
    //     0x923ff4: ldr             x1, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x923ff8: r0 = LinkedHashMap.from()
    //     0x923ff8: bl              #0x8ac2e4  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x923ffc: mov             x2, x0
    // 0x924000: r1 = Null
    //     0x924000: mov             x1, NULL
    // 0x924004: r0 = AppleNotificationSound.fromMap()
    //     0x924004: bl              #0x924078  ; [package:firebase_messaging_platform_interface/src/remote_notification.dart] AppleNotificationSound::AppleNotificationSound.fromMap
    // 0x924008: mov             x5, x0
    // 0x92400c: ldur            x2, [fp, #-0x20]
    // 0x924010: ldur            x4, [fp, #-0x10]
    // 0x924014: ldur            x3, [fp, #-0x18]
    // 0x924018: ldur            x1, [fp, #-0x28]
    // 0x92401c: ldur            x0, [fp, #-0x30]
    // 0x924020: stur            x5, [fp, #-8]
    // 0x924024: r0 = AppleNotification()
    //     0x924024: bl              #0x92406c  ; AllocateAppleNotificationStub -> AppleNotification (size=0x20)
    // 0x924028: ldur            x1, [fp, #-0x10]
    // 0x92402c: StoreField: r0->field_7 = r1
    //     0x92402c: stur            w1, [x0, #7]
    // 0x924030: ldur            x1, [fp, #-8]
    // 0x924034: StoreField: r0->field_b = r1
    //     0x924034: stur            w1, [x0, #0xb]
    // 0x924038: ldur            x1, [fp, #-0x30]
    // 0x92403c: StoreField: r0->field_f = r1
    //     0x92403c: stur            w1, [x0, #0xf]
    // 0x924040: ldur            x1, [fp, #-0x18]
    // 0x924044: StoreField: r0->field_13 = r1
    //     0x924044: stur            w1, [x0, #0x13]
    // 0x924048: ldur            x1, [fp, #-0x20]
    // 0x92404c: ArrayStore: r0[0] = r1  ; List_4
    //     0x92404c: stur            w1, [x0, #0x17]
    // 0x924050: ldur            x1, [fp, #-0x28]
    // 0x924054: StoreField: r0->field_1b = r1
    //     0x924054: stur            w1, [x0, #0x1b]
    // 0x924058: LeaveFrame
    //     0x924058: mov             SP, fp
    //     0x92405c: ldp             fp, lr, [SP], #0x10
    // 0x924060: ret
    //     0x924060: ret             
    // 0x924064: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x924064: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x924068: b               #0x923db0
  }
  _ toMap(/* No info */) {
    // ** addr: 0x13e8eec, size: 0x10c
    // 0x13e8eec: EnterFrame
    //     0x13e8eec: stp             fp, lr, [SP, #-0x10]!
    //     0x13e8ef0: mov             fp, SP
    // 0x13e8ef4: AllocStack(0x20)
    //     0x13e8ef4: sub             SP, SP, #0x20
    // 0x13e8ef8: SetupParameters(AppleNotification this /* r1 => r0, fp-0x8 */)
    //     0x13e8ef8: mov             x0, x1
    //     0x13e8efc: stur            x1, [fp, #-8]
    // 0x13e8f00: CheckStackOverflow
    //     0x13e8f00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13e8f04: cmp             SP, x16
    //     0x13e8f08: b.ls            #0x13e8ff0
    // 0x13e8f0c: r1 = Null
    //     0x13e8f0c: mov             x1, NULL
    // 0x13e8f10: r2 = 24
    //     0x13e8f10: mov             x2, #0x18
    // 0x13e8f14: r0 = AllocateArray()
    //     0x13e8f14: bl              #0x13df928  ; AllocateArrayStub
    // 0x13e8f18: stur            x0, [fp, #-0x10]
    // 0x13e8f1c: r16 = "badge"
    //     0x13e8f1c: ldr             x16, [PP, #0x6560]  ; [pp+0x6560] "badge"
    // 0x13e8f20: StoreField: r0->field_f = r16
    //     0x13e8f20: stur            w16, [x0, #0xf]
    // 0x13e8f24: ldur            x1, [fp, #-8]
    // 0x13e8f28: LoadField: r2 = r1->field_7
    //     0x13e8f28: ldur            w2, [x1, #7]
    // 0x13e8f2c: DecompressPointer r2
    //     0x13e8f2c: add             x2, x2, HEAP, lsl #32
    // 0x13e8f30: StoreField: r0->field_13 = r2
    //     0x13e8f30: stur            w2, [x0, #0x13]
    // 0x13e8f34: r16 = "subtitle"
    //     0x13e8f34: ldr             x16, [PP, #0x6578]  ; [pp+0x6578] "subtitle"
    // 0x13e8f38: ArrayStore: r0[0] = r16  ; List_4
    //     0x13e8f38: stur            w16, [x0, #0x17]
    // 0x13e8f3c: LoadField: r2 = r1->field_13
    //     0x13e8f3c: ldur            w2, [x1, #0x13]
    // 0x13e8f40: DecompressPointer r2
    //     0x13e8f40: add             x2, x2, HEAP, lsl #32
    // 0x13e8f44: StoreField: r0->field_1b = r2
    //     0x13e8f44: stur            w2, [x0, #0x1b]
    // 0x13e8f48: r16 = "subtitleLocArgs"
    //     0x13e8f48: ldr             x16, [PP, #0x6590]  ; [pp+0x6590] "subtitleLocArgs"
    // 0x13e8f4c: StoreField: r0->field_1f = r16
    //     0x13e8f4c: stur            w16, [x0, #0x1f]
    // 0x13e8f50: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x13e8f50: ldur            w2, [x1, #0x17]
    // 0x13e8f54: DecompressPointer r2
    //     0x13e8f54: add             x2, x2, HEAP, lsl #32
    // 0x13e8f58: StoreField: r0->field_23 = r2
    //     0x13e8f58: stur            w2, [x0, #0x23]
    // 0x13e8f5c: r16 = "subtitleLocKey"
    //     0x13e8f5c: ldr             x16, [PP, #0x6598]  ; [pp+0x6598] "subtitleLocKey"
    // 0x13e8f60: StoreField: r0->field_27 = r16
    //     0x13e8f60: stur            w16, [x0, #0x27]
    // 0x13e8f64: LoadField: r2 = r1->field_1b
    //     0x13e8f64: ldur            w2, [x1, #0x1b]
    // 0x13e8f68: DecompressPointer r2
    //     0x13e8f68: add             x2, x2, HEAP, lsl #32
    // 0x13e8f6c: StoreField: r0->field_2b = r2
    //     0x13e8f6c: stur            w2, [x0, #0x2b]
    // 0x13e8f70: r16 = "imageUrl"
    //     0x13e8f70: ldr             x16, [PP, #0x65b0]  ; [pp+0x65b0] "imageUrl"
    // 0x13e8f74: StoreField: r0->field_2f = r16
    //     0x13e8f74: stur            w16, [x0, #0x2f]
    // 0x13e8f78: LoadField: r2 = r1->field_f
    //     0x13e8f78: ldur            w2, [x1, #0xf]
    // 0x13e8f7c: DecompressPointer r2
    //     0x13e8f7c: add             x2, x2, HEAP, lsl #32
    // 0x13e8f80: StoreField: r0->field_33 = r2
    //     0x13e8f80: stur            w2, [x0, #0x33]
    // 0x13e8f84: r16 = "sound"
    //     0x13e8f84: ldr             x16, [PP, #0x65c8]  ; [pp+0x65c8] "sound"
    // 0x13e8f88: StoreField: r0->field_37 = r16
    //     0x13e8f88: stur            w16, [x0, #0x37]
    // 0x13e8f8c: LoadField: r2 = r1->field_b
    //     0x13e8f8c: ldur            w2, [x1, #0xb]
    // 0x13e8f90: DecompressPointer r2
    //     0x13e8f90: add             x2, x2, HEAP, lsl #32
    // 0x13e8f94: cmp             w2, NULL
    // 0x13e8f98: b.ne            #0x13e8fa4
    // 0x13e8f9c: r0 = Null
    //     0x13e8f9c: mov             x0, NULL
    // 0x13e8fa0: b               #0x13e8fac
    // 0x13e8fa4: mov             x1, x2
    // 0x13e8fa8: r0 = toMap()
    //     0x13e8fa8: bl              #0x13e8ff8  ; [package:firebase_messaging_platform_interface/src/remote_notification.dart] AppleNotificationSound::toMap
    // 0x13e8fac: ldur            x1, [fp, #-0x10]
    // 0x13e8fb0: ArrayStore: r1[11] = r0  ; List_4
    //     0x13e8fb0: add             x25, x1, #0x3b
    //     0x13e8fb4: str             w0, [x25]
    //     0x13e8fb8: tbz             w0, #0, #0x13e8fd4
    //     0x13e8fbc: ldurb           w16, [x1, #-1]
    //     0x13e8fc0: ldurb           w17, [x0, #-1]
    //     0x13e8fc4: and             x16, x17, x16, lsr #2
    //     0x13e8fc8: tst             x16, HEAP, lsr #32
    //     0x13e8fcc: b.eq            #0x13e8fd4
    //     0x13e8fd0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x13e8fd4: r16 = <String, dynamic>
    //     0x13e8fd4: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x13e8fd8: ldur            lr, [fp, #-0x10]
    // 0x13e8fdc: stp             lr, x16, [SP]
    // 0x13e8fe0: r0 = Map._fromLiteral()
    //     0x13e8fe0: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x13e8fe4: LeaveFrame
    //     0x13e8fe4: mov             SP, fp
    //     0x13e8fe8: ldp             fp, lr, [SP], #0x10
    // 0x13e8fec: ret
    //     0x13e8fec: ret             
    // 0x13e8ff0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13e8ff0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13e8ff4: b               #0x13e8f0c
  }
}

// class id: 3348, size: 0x38, field offset: 0x8
//   const constructor, 
class AndroidNotification extends Object {

  factory _ AndroidNotification.fromMap(/* No info */) {
    // ** addr: 0x924224, size: 0x600
    // 0x924224: EnterFrame
    //     0x924224: stp             fp, lr, [SP, #-0x10]!
    //     0x924228: mov             fp, SP
    // 0x92422c: AllocStack(0x60)
    //     0x92422c: sub             SP, SP, #0x60
    // 0x924230: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0x924230: mov             x0, x2
    //     0x924234: stur            x2, [fp, #-8]
    // 0x924238: CheckStackOverflow
    //     0x924238: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x92423c: cmp             SP, x16
    //     0x924240: b.ls            #0x92481c
    // 0x924244: mov             x1, x0
    // 0x924248: r2 = "channelId"
    //     0x924248: ldr             x2, [PP, #0x6620]  ; [pp+0x6620] "channelId"
    // 0x92424c: r0 = _getValueOrData()
    //     0x92424c: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x924250: ldur            x3, [fp, #-8]
    // 0x924254: LoadField: r1 = r3->field_f
    //     0x924254: ldur            w1, [x3, #0xf]
    // 0x924258: DecompressPointer r1
    //     0x924258: add             x1, x1, HEAP, lsl #32
    // 0x92425c: cmp             w1, w0
    // 0x924260: b.ne            #0x92426c
    // 0x924264: r4 = Null
    //     0x924264: mov             x4, NULL
    // 0x924268: b               #0x924270
    // 0x92426c: mov             x4, x0
    // 0x924270: mov             x0, x4
    // 0x924274: stur            x4, [fp, #-0x10]
    // 0x924278: r2 = Null
    //     0x924278: mov             x2, NULL
    // 0x92427c: r1 = Null
    //     0x92427c: mov             x1, NULL
    // 0x924280: r4 = 60
    //     0x924280: mov             x4, #0x3c
    // 0x924284: branchIfSmi(r0, 0x924290)
    //     0x924284: tbz             w0, #0, #0x924290
    // 0x924288: r4 = LoadClassIdInstr(r0)
    //     0x924288: ldur            x4, [x0, #-1]
    //     0x92428c: ubfx            x4, x4, #0xc, #0x14
    // 0x924290: sub             x4, x4, #0x5e
    // 0x924294: cmp             x4, #1
    // 0x924298: b.ls            #0x9242a8
    // 0x92429c: r8 = String?
    //     0x92429c: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x9242a0: r3 = Null
    //     0x9242a0: ldr             x3, [PP, #0x6628]  ; [pp+0x6628] Null
    // 0x9242a4: r0 = String?()
    //     0x9242a4: bl              #0x7db310  ; IsType_String?_Stub
    // 0x9242a8: ldur            x1, [fp, #-8]
    // 0x9242ac: r2 = "clickAction"
    //     0x9242ac: ldr             x2, [PP, #0x6638]  ; [pp+0x6638] "clickAction"
    // 0x9242b0: r0 = _getValueOrData()
    //     0x9242b0: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x9242b4: ldur            x3, [fp, #-8]
    // 0x9242b8: LoadField: r1 = r3->field_f
    //     0x9242b8: ldur            w1, [x3, #0xf]
    // 0x9242bc: DecompressPointer r1
    //     0x9242bc: add             x1, x1, HEAP, lsl #32
    // 0x9242c0: cmp             w1, w0
    // 0x9242c4: b.ne            #0x9242d0
    // 0x9242c8: r4 = Null
    //     0x9242c8: mov             x4, NULL
    // 0x9242cc: b               #0x9242d4
    // 0x9242d0: mov             x4, x0
    // 0x9242d4: mov             x0, x4
    // 0x9242d8: stur            x4, [fp, #-0x18]
    // 0x9242dc: r2 = Null
    //     0x9242dc: mov             x2, NULL
    // 0x9242e0: r1 = Null
    //     0x9242e0: mov             x1, NULL
    // 0x9242e4: r4 = 60
    //     0x9242e4: mov             x4, #0x3c
    // 0x9242e8: branchIfSmi(r0, 0x9242f4)
    //     0x9242e8: tbz             w0, #0, #0x9242f4
    // 0x9242ec: r4 = LoadClassIdInstr(r0)
    //     0x9242ec: ldur            x4, [x0, #-1]
    //     0x9242f0: ubfx            x4, x4, #0xc, #0x14
    // 0x9242f4: sub             x4, x4, #0x5e
    // 0x9242f8: cmp             x4, #1
    // 0x9242fc: b.ls            #0x92430c
    // 0x924300: r8 = String?
    //     0x924300: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x924304: r3 = Null
    //     0x924304: ldr             x3, [PP, #0x6640]  ; [pp+0x6640] Null
    // 0x924308: r0 = String?()
    //     0x924308: bl              #0x7db310  ; IsType_String?_Stub
    // 0x92430c: ldur            x1, [fp, #-8]
    // 0x924310: r2 = "color"
    //     0x924310: ldr             x2, [PP, #0x4a70]  ; [pp+0x4a70] "color"
    // 0x924314: r0 = _getValueOrData()
    //     0x924314: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x924318: ldur            x3, [fp, #-8]
    // 0x92431c: LoadField: r1 = r3->field_f
    //     0x92431c: ldur            w1, [x3, #0xf]
    // 0x924320: DecompressPointer r1
    //     0x924320: add             x1, x1, HEAP, lsl #32
    // 0x924324: cmp             w1, w0
    // 0x924328: b.ne            #0x924334
    // 0x92432c: r4 = Null
    //     0x92432c: mov             x4, NULL
    // 0x924330: b               #0x924338
    // 0x924334: mov             x4, x0
    // 0x924338: mov             x0, x4
    // 0x92433c: stur            x4, [fp, #-0x20]
    // 0x924340: r2 = Null
    //     0x924340: mov             x2, NULL
    // 0x924344: r1 = Null
    //     0x924344: mov             x1, NULL
    // 0x924348: r4 = 60
    //     0x924348: mov             x4, #0x3c
    // 0x92434c: branchIfSmi(r0, 0x924358)
    //     0x92434c: tbz             w0, #0, #0x924358
    // 0x924350: r4 = LoadClassIdInstr(r0)
    //     0x924350: ldur            x4, [x0, #-1]
    //     0x924354: ubfx            x4, x4, #0xc, #0x14
    // 0x924358: sub             x4, x4, #0x5e
    // 0x92435c: cmp             x4, #1
    // 0x924360: b.ls            #0x924370
    // 0x924364: r8 = String?
    //     0x924364: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x924368: r3 = Null
    //     0x924368: ldr             x3, [PP, #0x6650]  ; [pp+0x6650] Null
    // 0x92436c: r0 = String?()
    //     0x92436c: bl              #0x7db310  ; IsType_String?_Stub
    // 0x924370: ldur            x1, [fp, #-8]
    // 0x924374: r2 = "count"
    //     0x924374: ldr             x2, [PP, #0x6660]  ; [pp+0x6660] "count"
    // 0x924378: r0 = _getValueOrData()
    //     0x924378: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x92437c: ldur            x3, [fp, #-8]
    // 0x924380: LoadField: r1 = r3->field_f
    //     0x924380: ldur            w1, [x3, #0xf]
    // 0x924384: DecompressPointer r1
    //     0x924384: add             x1, x1, HEAP, lsl #32
    // 0x924388: cmp             w1, w0
    // 0x92438c: b.ne            #0x924398
    // 0x924390: r4 = Null
    //     0x924390: mov             x4, NULL
    // 0x924394: b               #0x92439c
    // 0x924398: mov             x4, x0
    // 0x92439c: mov             x0, x4
    // 0x9243a0: stur            x4, [fp, #-0x28]
    // 0x9243a4: r2 = Null
    //     0x9243a4: mov             x2, NULL
    // 0x9243a8: r1 = Null
    //     0x9243a8: mov             x1, NULL
    // 0x9243ac: branchIfSmi(r0, 0x9243d0)
    //     0x9243ac: tbz             w0, #0, #0x9243d0
    // 0x9243b0: r4 = LoadClassIdInstr(r0)
    //     0x9243b0: ldur            x4, [x0, #-1]
    //     0x9243b4: ubfx            x4, x4, #0xc, #0x14
    // 0x9243b8: sub             x4, x4, #0x3c
    // 0x9243bc: cmp             x4, #1
    // 0x9243c0: b.ls            #0x9243d0
    // 0x9243c4: r8 = int?
    //     0x9243c4: ldr             x8, [PP, #0x3d30]  ; [pp+0x3d30] Type: int?
    // 0x9243c8: r3 = Null
    //     0x9243c8: ldr             x3, [PP, #0x6668]  ; [pp+0x6668] Null
    // 0x9243cc: r0 = int?()
    //     0x9243cc: bl              #0x13ee944  ; IsType_int?_Stub
    // 0x9243d0: ldur            x1, [fp, #-8]
    // 0x9243d4: r2 = "imageUrl"
    //     0x9243d4: ldr             x2, [PP, #0x65b0]  ; [pp+0x65b0] "imageUrl"
    // 0x9243d8: r0 = _getValueOrData()
    //     0x9243d8: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x9243dc: ldur            x3, [fp, #-8]
    // 0x9243e0: LoadField: r1 = r3->field_f
    //     0x9243e0: ldur            w1, [x3, #0xf]
    // 0x9243e4: DecompressPointer r1
    //     0x9243e4: add             x1, x1, HEAP, lsl #32
    // 0x9243e8: cmp             w1, w0
    // 0x9243ec: b.ne            #0x9243f8
    // 0x9243f0: r4 = Null
    //     0x9243f0: mov             x4, NULL
    // 0x9243f4: b               #0x9243fc
    // 0x9243f8: mov             x4, x0
    // 0x9243fc: mov             x0, x4
    // 0x924400: stur            x4, [fp, #-0x30]
    // 0x924404: r2 = Null
    //     0x924404: mov             x2, NULL
    // 0x924408: r1 = Null
    //     0x924408: mov             x1, NULL
    // 0x92440c: r4 = 60
    //     0x92440c: mov             x4, #0x3c
    // 0x924410: branchIfSmi(r0, 0x92441c)
    //     0x924410: tbz             w0, #0, #0x92441c
    // 0x924414: r4 = LoadClassIdInstr(r0)
    //     0x924414: ldur            x4, [x0, #-1]
    //     0x924418: ubfx            x4, x4, #0xc, #0x14
    // 0x92441c: sub             x4, x4, #0x5e
    // 0x924420: cmp             x4, #1
    // 0x924424: b.ls            #0x924434
    // 0x924428: r8 = String?
    //     0x924428: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x92442c: r3 = Null
    //     0x92442c: ldr             x3, [PP, #0x6678]  ; [pp+0x6678] Null
    // 0x924430: r0 = String?()
    //     0x924430: bl              #0x7db310  ; IsType_String?_Stub
    // 0x924434: ldur            x1, [fp, #-8]
    // 0x924438: r2 = "link"
    //     0x924438: ldr             x2, [PP, #0x6548]  ; [pp+0x6548] "link"
    // 0x92443c: r0 = _getValueOrData()
    //     0x92443c: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x924440: ldur            x3, [fp, #-8]
    // 0x924444: LoadField: r1 = r3->field_f
    //     0x924444: ldur            w1, [x3, #0xf]
    // 0x924448: DecompressPointer r1
    //     0x924448: add             x1, x1, HEAP, lsl #32
    // 0x92444c: cmp             w1, w0
    // 0x924450: b.ne            #0x92445c
    // 0x924454: r4 = Null
    //     0x924454: mov             x4, NULL
    // 0x924458: b               #0x924460
    // 0x92445c: mov             x4, x0
    // 0x924460: mov             x0, x4
    // 0x924464: stur            x4, [fp, #-0x38]
    // 0x924468: r2 = Null
    //     0x924468: mov             x2, NULL
    // 0x92446c: r1 = Null
    //     0x92446c: mov             x1, NULL
    // 0x924470: r4 = 60
    //     0x924470: mov             x4, #0x3c
    // 0x924474: branchIfSmi(r0, 0x924480)
    //     0x924474: tbz             w0, #0, #0x924480
    // 0x924478: r4 = LoadClassIdInstr(r0)
    //     0x924478: ldur            x4, [x0, #-1]
    //     0x92447c: ubfx            x4, x4, #0xc, #0x14
    // 0x924480: sub             x4, x4, #0x5e
    // 0x924484: cmp             x4, #1
    // 0x924488: b.ls            #0x924498
    // 0x92448c: r8 = String?
    //     0x92448c: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x924490: r3 = Null
    //     0x924490: ldr             x3, [PP, #0x6688]  ; [pp+0x6688] Null
    // 0x924494: r0 = String?()
    //     0x924494: bl              #0x7db310  ; IsType_String?_Stub
    // 0x924498: ldur            x1, [fp, #-8]
    // 0x92449c: r2 = "priority"
    //     0x92449c: ldr             x2, [PP, #0x6698]  ; [pp+0x6698] "priority"
    // 0x9244a0: r0 = _getValueOrData()
    //     0x9244a0: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x9244a4: ldur            x3, [fp, #-8]
    // 0x9244a8: LoadField: r1 = r3->field_f
    //     0x9244a8: ldur            w1, [x3, #0xf]
    // 0x9244ac: DecompressPointer r1
    //     0x9244ac: add             x1, x1, HEAP, lsl #32
    // 0x9244b0: cmp             w1, w0
    // 0x9244b4: b.ne            #0x9244c0
    // 0x9244b8: r4 = Null
    //     0x9244b8: mov             x4, NULL
    // 0x9244bc: b               #0x9244c4
    // 0x9244c0: mov             x4, x0
    // 0x9244c4: mov             x0, x4
    // 0x9244c8: stur            x4, [fp, #-0x40]
    // 0x9244cc: r2 = Null
    //     0x9244cc: mov             x2, NULL
    // 0x9244d0: r1 = Null
    //     0x9244d0: mov             x1, NULL
    // 0x9244d4: branchIfSmi(r0, 0x9244f8)
    //     0x9244d4: tbz             w0, #0, #0x9244f8
    // 0x9244d8: r4 = LoadClassIdInstr(r0)
    //     0x9244d8: ldur            x4, [x0, #-1]
    //     0x9244dc: ubfx            x4, x4, #0xc, #0x14
    // 0x9244e0: sub             x4, x4, #0x3c
    // 0x9244e4: cmp             x4, #1
    // 0x9244e8: b.ls            #0x9244f8
    // 0x9244ec: r8 = int?
    //     0x9244ec: ldr             x8, [PP, #0x3d30]  ; [pp+0x3d30] Type: int?
    // 0x9244f0: r3 = Null
    //     0x9244f0: ldr             x3, [PP, #0x66a0]  ; [pp+0x66a0] Null
    // 0x9244f4: r0 = int?()
    //     0x9244f4: bl              #0x13ee944  ; IsType_int?_Stub
    // 0x9244f8: ldur            x0, [fp, #-0x40]
    // 0x9244fc: cmn             w0, #4
    // 0x924500: b.ne            #0x92450c
    // 0x924504: r3 = Instance_AndroidNotificationPriority
    //     0x924504: ldr             x3, [PP, #0x66b0]  ; [pp+0x66b0] Obj!AndroidNotificationPriority@12c62c1
    // 0x924508: b               #0x92454c
    // 0x92450c: cmn             w0, #2
    // 0x924510: b.ne            #0x92451c
    // 0x924514: r3 = Instance_AndroidNotificationPriority
    //     0x924514: ldr             x3, [PP, #0x66b8]  ; [pp+0x66b8] Obj!AndroidNotificationPriority@12c62a1
    // 0x924518: b               #0x92454c
    // 0x92451c: cbnz            w0, #0x924528
    // 0x924520: r3 = Instance_AndroidNotificationPriority
    //     0x924520: ldr             x3, [PP, #0x66c0]  ; [pp+0x66c0] Obj!AndroidNotificationPriority@12c6281
    // 0x924524: b               #0x92454c
    // 0x924528: cmp             w0, #2
    // 0x92452c: b.ne            #0x924538
    // 0x924530: r3 = Instance_AndroidNotificationPriority
    //     0x924530: ldr             x3, [PP, #0x66c8]  ; [pp+0x66c8] Obj!AndroidNotificationPriority@12c6261
    // 0x924534: b               #0x92454c
    // 0x924538: cmp             w0, #4
    // 0x92453c: b.ne            #0x924548
    // 0x924540: r3 = Instance_AndroidNotificationPriority
    //     0x924540: ldr             x3, [PP, #0x66d0]  ; [pp+0x66d0] Obj!AndroidNotificationPriority@12c6241
    // 0x924544: b               #0x92454c
    // 0x924548: r3 = Instance_AndroidNotificationPriority
    //     0x924548: ldr             x3, [PP, #0x66c0]  ; [pp+0x66c0] Obj!AndroidNotificationPriority@12c6281
    // 0x92454c: ldur            x0, [fp, #-8]
    // 0x924550: mov             x1, x0
    // 0x924554: stur            x3, [fp, #-0x40]
    // 0x924558: r2 = "smallIcon"
    //     0x924558: ldr             x2, [PP, #0x66d8]  ; [pp+0x66d8] "smallIcon"
    // 0x92455c: r0 = _getValueOrData()
    //     0x92455c: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x924560: ldur            x3, [fp, #-8]
    // 0x924564: LoadField: r1 = r3->field_f
    //     0x924564: ldur            w1, [x3, #0xf]
    // 0x924568: DecompressPointer r1
    //     0x924568: add             x1, x1, HEAP, lsl #32
    // 0x92456c: cmp             w1, w0
    // 0x924570: b.ne            #0x92457c
    // 0x924574: r4 = Null
    //     0x924574: mov             x4, NULL
    // 0x924578: b               #0x924580
    // 0x92457c: mov             x4, x0
    // 0x924580: mov             x0, x4
    // 0x924584: stur            x4, [fp, #-0x48]
    // 0x924588: r2 = Null
    //     0x924588: mov             x2, NULL
    // 0x92458c: r1 = Null
    //     0x92458c: mov             x1, NULL
    // 0x924590: r4 = 60
    //     0x924590: mov             x4, #0x3c
    // 0x924594: branchIfSmi(r0, 0x9245a0)
    //     0x924594: tbz             w0, #0, #0x9245a0
    // 0x924598: r4 = LoadClassIdInstr(r0)
    //     0x924598: ldur            x4, [x0, #-1]
    //     0x92459c: ubfx            x4, x4, #0xc, #0x14
    // 0x9245a0: sub             x4, x4, #0x5e
    // 0x9245a4: cmp             x4, #1
    // 0x9245a8: b.ls            #0x9245b8
    // 0x9245ac: r8 = String?
    //     0x9245ac: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x9245b0: r3 = Null
    //     0x9245b0: ldr             x3, [PP, #0x66e0]  ; [pp+0x66e0] Null
    // 0x9245b4: r0 = String?()
    //     0x9245b4: bl              #0x7db310  ; IsType_String?_Stub
    // 0x9245b8: ldur            x1, [fp, #-8]
    // 0x9245bc: r2 = "sound"
    //     0x9245bc: ldr             x2, [PP, #0x65c8]  ; [pp+0x65c8] "sound"
    // 0x9245c0: r0 = _getValueOrData()
    //     0x9245c0: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x9245c4: ldur            x3, [fp, #-8]
    // 0x9245c8: LoadField: r1 = r3->field_f
    //     0x9245c8: ldur            w1, [x3, #0xf]
    // 0x9245cc: DecompressPointer r1
    //     0x9245cc: add             x1, x1, HEAP, lsl #32
    // 0x9245d0: cmp             w1, w0
    // 0x9245d4: b.ne            #0x9245e0
    // 0x9245d8: r4 = Null
    //     0x9245d8: mov             x4, NULL
    // 0x9245dc: b               #0x9245e4
    // 0x9245e0: mov             x4, x0
    // 0x9245e4: mov             x0, x4
    // 0x9245e8: stur            x4, [fp, #-0x50]
    // 0x9245ec: r2 = Null
    //     0x9245ec: mov             x2, NULL
    // 0x9245f0: r1 = Null
    //     0x9245f0: mov             x1, NULL
    // 0x9245f4: r4 = 60
    //     0x9245f4: mov             x4, #0x3c
    // 0x9245f8: branchIfSmi(r0, 0x924604)
    //     0x9245f8: tbz             w0, #0, #0x924604
    // 0x9245fc: r4 = LoadClassIdInstr(r0)
    //     0x9245fc: ldur            x4, [x0, #-1]
    //     0x924600: ubfx            x4, x4, #0xc, #0x14
    // 0x924604: sub             x4, x4, #0x5e
    // 0x924608: cmp             x4, #1
    // 0x92460c: b.ls            #0x92461c
    // 0x924610: r8 = String?
    //     0x924610: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x924614: r3 = Null
    //     0x924614: ldr             x3, [PP, #0x66f0]  ; [pp+0x66f0] Null
    // 0x924618: r0 = String?()
    //     0x924618: bl              #0x7db310  ; IsType_String?_Stub
    // 0x92461c: ldur            x1, [fp, #-8]
    // 0x924620: r2 = "ticker"
    //     0x924620: ldr             x2, [PP, #0x6700]  ; [pp+0x6700] "ticker"
    // 0x924624: r0 = _getValueOrData()
    //     0x924624: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x924628: ldur            x3, [fp, #-8]
    // 0x92462c: LoadField: r1 = r3->field_f
    //     0x92462c: ldur            w1, [x3, #0xf]
    // 0x924630: DecompressPointer r1
    //     0x924630: add             x1, x1, HEAP, lsl #32
    // 0x924634: cmp             w1, w0
    // 0x924638: b.ne            #0x924644
    // 0x92463c: r4 = Null
    //     0x92463c: mov             x4, NULL
    // 0x924640: b               #0x924648
    // 0x924644: mov             x4, x0
    // 0x924648: mov             x0, x4
    // 0x92464c: stur            x4, [fp, #-0x58]
    // 0x924650: r2 = Null
    //     0x924650: mov             x2, NULL
    // 0x924654: r1 = Null
    //     0x924654: mov             x1, NULL
    // 0x924658: r4 = 60
    //     0x924658: mov             x4, #0x3c
    // 0x92465c: branchIfSmi(r0, 0x924668)
    //     0x92465c: tbz             w0, #0, #0x924668
    // 0x924660: r4 = LoadClassIdInstr(r0)
    //     0x924660: ldur            x4, [x0, #-1]
    //     0x924664: ubfx            x4, x4, #0xc, #0x14
    // 0x924668: sub             x4, x4, #0x5e
    // 0x92466c: cmp             x4, #1
    // 0x924670: b.ls            #0x924680
    // 0x924674: r8 = String?
    //     0x924674: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x924678: r3 = Null
    //     0x924678: ldr             x3, [PP, #0x6708]  ; [pp+0x6708] Null
    // 0x92467c: r0 = String?()
    //     0x92467c: bl              #0x7db310  ; IsType_String?_Stub
    // 0x924680: ldur            x1, [fp, #-8]
    // 0x924684: r2 = "tag"
    //     0x924684: ldr             x2, [PP, #0x6718]  ; [pp+0x6718] "tag"
    // 0x924688: r0 = _getValueOrData()
    //     0x924688: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x92468c: ldur            x3, [fp, #-8]
    // 0x924690: LoadField: r1 = r3->field_f
    //     0x924690: ldur            w1, [x3, #0xf]
    // 0x924694: DecompressPointer r1
    //     0x924694: add             x1, x1, HEAP, lsl #32
    // 0x924698: cmp             w1, w0
    // 0x92469c: b.ne            #0x9246a8
    // 0x9246a0: r4 = Null
    //     0x9246a0: mov             x4, NULL
    // 0x9246a4: b               #0x9246ac
    // 0x9246a8: mov             x4, x0
    // 0x9246ac: mov             x0, x4
    // 0x9246b0: stur            x4, [fp, #-0x60]
    // 0x9246b4: r2 = Null
    //     0x9246b4: mov             x2, NULL
    // 0x9246b8: r1 = Null
    //     0x9246b8: mov             x1, NULL
    // 0x9246bc: r4 = 60
    //     0x9246bc: mov             x4, #0x3c
    // 0x9246c0: branchIfSmi(r0, 0x9246cc)
    //     0x9246c0: tbz             w0, #0, #0x9246cc
    // 0x9246c4: r4 = LoadClassIdInstr(r0)
    //     0x9246c4: ldur            x4, [x0, #-1]
    //     0x9246c8: ubfx            x4, x4, #0xc, #0x14
    // 0x9246cc: sub             x4, x4, #0x5e
    // 0x9246d0: cmp             x4, #1
    // 0x9246d4: b.ls            #0x9246e4
    // 0x9246d8: r8 = String?
    //     0x9246d8: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x9246dc: r3 = Null
    //     0x9246dc: ldr             x3, [PP, #0x6720]  ; [pp+0x6720] Null
    // 0x9246e0: r0 = String?()
    //     0x9246e0: bl              #0x7db310  ; IsType_String?_Stub
    // 0x9246e4: ldur            x1, [fp, #-8]
    // 0x9246e8: r2 = "visibility"
    //     0x9246e8: ldr             x2, [PP, #0x6730]  ; [pp+0x6730] "visibility"
    // 0x9246ec: r0 = _getValueOrData()
    //     0x9246ec: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x9246f0: mov             x1, x0
    // 0x9246f4: ldur            x0, [fp, #-8]
    // 0x9246f8: LoadField: r2 = r0->field_f
    //     0x9246f8: ldur            w2, [x0, #0xf]
    // 0x9246fc: DecompressPointer r2
    //     0x9246fc: add             x2, x2, HEAP, lsl #32
    // 0x924700: cmp             w2, w1
    // 0x924704: b.ne            #0x924710
    // 0x924708: r3 = Null
    //     0x924708: mov             x3, NULL
    // 0x92470c: b               #0x924714
    // 0x924710: mov             x3, x1
    // 0x924714: mov             x0, x3
    // 0x924718: stur            x3, [fp, #-8]
    // 0x92471c: r2 = Null
    //     0x92471c: mov             x2, NULL
    // 0x924720: r1 = Null
    //     0x924720: mov             x1, NULL
    // 0x924724: branchIfSmi(r0, 0x924748)
    //     0x924724: tbz             w0, #0, #0x924748
    // 0x924728: r4 = LoadClassIdInstr(r0)
    //     0x924728: ldur            x4, [x0, #-1]
    //     0x92472c: ubfx            x4, x4, #0xc, #0x14
    // 0x924730: sub             x4, x4, #0x3c
    // 0x924734: cmp             x4, #1
    // 0x924738: b.ls            #0x924748
    // 0x92473c: r8 = int?
    //     0x92473c: ldr             x8, [PP, #0x3d30]  ; [pp+0x3d30] Type: int?
    // 0x924740: r3 = Null
    //     0x924740: ldr             x3, [PP, #0x6738]  ; [pp+0x6738] Null
    // 0x924744: r0 = int?()
    //     0x924744: bl              #0x13ee944  ; IsType_int?_Stub
    // 0x924748: ldur            x0, [fp, #-8]
    // 0x92474c: cmn             w0, #2
    // 0x924750: b.ne            #0x92475c
    // 0x924754: r11 = Instance_AndroidNotificationVisibility
    //     0x924754: ldr             x11, [PP, #0x6748]  ; [pp+0x6748] Obj!AndroidNotificationVisibility@12c6221
    // 0x924758: b               #0x92477c
    // 0x92475c: cbnz            w0, #0x924768
    // 0x924760: r11 = Instance_AndroidNotificationVisibility
    //     0x924760: ldr             x11, [PP, #0x6750]  ; [pp+0x6750] Obj!AndroidNotificationVisibility@12c6201
    // 0x924764: b               #0x92477c
    // 0x924768: cmp             w0, #2
    // 0x92476c: b.ne            #0x924778
    // 0x924770: r11 = Instance_AndroidNotificationVisibility
    //     0x924770: ldr             x11, [PP, #0x6758]  ; [pp+0x6758] Obj!AndroidNotificationVisibility@12c61e1
    // 0x924774: b               #0x92477c
    // 0x924778: r11 = Instance_AndroidNotificationVisibility
    //     0x924778: ldr             x11, [PP, #0x6750]  ; [pp+0x6750] Obj!AndroidNotificationVisibility@12c6201
    // 0x92477c: ldur            x10, [fp, #-0x10]
    // 0x924780: ldur            x9, [fp, #-0x18]
    // 0x924784: ldur            x8, [fp, #-0x20]
    // 0x924788: ldur            x7, [fp, #-0x28]
    // 0x92478c: ldur            x6, [fp, #-0x30]
    // 0x924790: ldur            x5, [fp, #-0x38]
    // 0x924794: ldur            x4, [fp, #-0x40]
    // 0x924798: ldur            x3, [fp, #-0x48]
    // 0x92479c: ldur            x2, [fp, #-0x50]
    // 0x9247a0: ldur            x1, [fp, #-0x58]
    // 0x9247a4: ldur            x0, [fp, #-0x60]
    // 0x9247a8: stur            x11, [fp, #-8]
    // 0x9247ac: r0 = AndroidNotification()
    //     0x9247ac: bl              #0x924824  ; AllocateAndroidNotificationStub -> AndroidNotification (size=0x38)
    // 0x9247b0: ldur            x1, [fp, #-0x10]
    // 0x9247b4: StoreField: r0->field_7 = r1
    //     0x9247b4: stur            w1, [x0, #7]
    // 0x9247b8: ldur            x1, [fp, #-0x18]
    // 0x9247bc: StoreField: r0->field_b = r1
    //     0x9247bc: stur            w1, [x0, #0xb]
    // 0x9247c0: ldur            x1, [fp, #-0x20]
    // 0x9247c4: StoreField: r0->field_f = r1
    //     0x9247c4: stur            w1, [x0, #0xf]
    // 0x9247c8: ldur            x1, [fp, #-0x28]
    // 0x9247cc: StoreField: r0->field_13 = r1
    //     0x9247cc: stur            w1, [x0, #0x13]
    // 0x9247d0: ldur            x1, [fp, #-0x30]
    // 0x9247d4: ArrayStore: r0[0] = r1  ; List_4
    //     0x9247d4: stur            w1, [x0, #0x17]
    // 0x9247d8: ldur            x1, [fp, #-0x38]
    // 0x9247dc: StoreField: r0->field_1b = r1
    //     0x9247dc: stur            w1, [x0, #0x1b]
    // 0x9247e0: ldur            x1, [fp, #-0x40]
    // 0x9247e4: StoreField: r0->field_1f = r1
    //     0x9247e4: stur            w1, [x0, #0x1f]
    // 0x9247e8: ldur            x1, [fp, #-0x48]
    // 0x9247ec: StoreField: r0->field_23 = r1
    //     0x9247ec: stur            w1, [x0, #0x23]
    // 0x9247f0: ldur            x1, [fp, #-0x50]
    // 0x9247f4: StoreField: r0->field_27 = r1
    //     0x9247f4: stur            w1, [x0, #0x27]
    // 0x9247f8: ldur            x1, [fp, #-0x58]
    // 0x9247fc: StoreField: r0->field_2b = r1
    //     0x9247fc: stur            w1, [x0, #0x2b]
    // 0x924800: ldur            x1, [fp, #-0x60]
    // 0x924804: StoreField: r0->field_33 = r1
    //     0x924804: stur            w1, [x0, #0x33]
    // 0x924808: ldur            x1, [fp, #-8]
    // 0x92480c: StoreField: r0->field_2f = r1
    //     0x92480c: stur            w1, [x0, #0x2f]
    // 0x924810: LeaveFrame
    //     0x924810: mov             SP, fp
    //     0x924814: ldp             fp, lr, [SP], #0x10
    // 0x924818: ret
    //     0x924818: ret             
    // 0x92481c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x92481c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x924820: b               #0x924244
  }
  _ toMap(/* No info */) {
    // ** addr: 0x13e9084, size: 0x260
    // 0x13e9084: EnterFrame
    //     0x13e9084: stp             fp, lr, [SP, #-0x10]!
    //     0x13e9088: mov             fp, SP
    // 0x13e908c: AllocStack(0x20)
    //     0x13e908c: sub             SP, SP, #0x20
    // 0x13e9090: SetupParameters(AndroidNotification this /* r1 => r0, fp-0x8 */)
    //     0x13e9090: mov             x0, x1
    //     0x13e9094: stur            x1, [fp, #-8]
    // 0x13e9098: CheckStackOverflow
    //     0x13e9098: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13e909c: cmp             SP, x16
    //     0x13e90a0: b.ls            #0x13e92dc
    // 0x13e90a4: r1 = Null
    //     0x13e90a4: mov             x1, NULL
    // 0x13e90a8: r2 = 48
    //     0x13e90a8: mov             x2, #0x30
    // 0x13e90ac: r0 = AllocateArray()
    //     0x13e90ac: bl              #0x13df928  ; AllocateArrayStub
    // 0x13e90b0: stur            x0, [fp, #-0x10]
    // 0x13e90b4: r16 = "channelId"
    //     0x13e90b4: ldr             x16, [PP, #0x6620]  ; [pp+0x6620] "channelId"
    // 0x13e90b8: StoreField: r0->field_f = r16
    //     0x13e90b8: stur            w16, [x0, #0xf]
    // 0x13e90bc: ldur            x2, [fp, #-8]
    // 0x13e90c0: LoadField: r1 = r2->field_7
    //     0x13e90c0: ldur            w1, [x2, #7]
    // 0x13e90c4: DecompressPointer r1
    //     0x13e90c4: add             x1, x1, HEAP, lsl #32
    // 0x13e90c8: StoreField: r0->field_13 = r1
    //     0x13e90c8: stur            w1, [x0, #0x13]
    // 0x13e90cc: r16 = "clickAction"
    //     0x13e90cc: ldr             x16, [PP, #0x6638]  ; [pp+0x6638] "clickAction"
    // 0x13e90d0: ArrayStore: r0[0] = r16  ; List_4
    //     0x13e90d0: stur            w16, [x0, #0x17]
    // 0x13e90d4: LoadField: r1 = r2->field_b
    //     0x13e90d4: ldur            w1, [x2, #0xb]
    // 0x13e90d8: DecompressPointer r1
    //     0x13e90d8: add             x1, x1, HEAP, lsl #32
    // 0x13e90dc: StoreField: r0->field_1b = r1
    //     0x13e90dc: stur            w1, [x0, #0x1b]
    // 0x13e90e0: r16 = "color"
    //     0x13e90e0: ldr             x16, [PP, #0x4a70]  ; [pp+0x4a70] "color"
    // 0x13e90e4: StoreField: r0->field_1f = r16
    //     0x13e90e4: stur            w16, [x0, #0x1f]
    // 0x13e90e8: LoadField: r1 = r2->field_f
    //     0x13e90e8: ldur            w1, [x2, #0xf]
    // 0x13e90ec: DecompressPointer r1
    //     0x13e90ec: add             x1, x1, HEAP, lsl #32
    // 0x13e90f0: StoreField: r0->field_23 = r1
    //     0x13e90f0: stur            w1, [x0, #0x23]
    // 0x13e90f4: r16 = "count"
    //     0x13e90f4: ldr             x16, [PP, #0x6660]  ; [pp+0x6660] "count"
    // 0x13e90f8: StoreField: r0->field_27 = r16
    //     0x13e90f8: stur            w16, [x0, #0x27]
    // 0x13e90fc: LoadField: r1 = r2->field_13
    //     0x13e90fc: ldur            w1, [x2, #0x13]
    // 0x13e9100: DecompressPointer r1
    //     0x13e9100: add             x1, x1, HEAP, lsl #32
    // 0x13e9104: StoreField: r0->field_2b = r1
    //     0x13e9104: stur            w1, [x0, #0x2b]
    // 0x13e9108: r16 = "imageUrl"
    //     0x13e9108: ldr             x16, [PP, #0x65b0]  ; [pp+0x65b0] "imageUrl"
    // 0x13e910c: StoreField: r0->field_2f = r16
    //     0x13e910c: stur            w16, [x0, #0x2f]
    // 0x13e9110: ArrayLoad: r1 = r2[0]  ; List_4
    //     0x13e9110: ldur            w1, [x2, #0x17]
    // 0x13e9114: DecompressPointer r1
    //     0x13e9114: add             x1, x1, HEAP, lsl #32
    // 0x13e9118: StoreField: r0->field_33 = r1
    //     0x13e9118: stur            w1, [x0, #0x33]
    // 0x13e911c: r16 = "link"
    //     0x13e911c: ldr             x16, [PP, #0x6548]  ; [pp+0x6548] "link"
    // 0x13e9120: StoreField: r0->field_37 = r16
    //     0x13e9120: stur            w16, [x0, #0x37]
    // 0x13e9124: LoadField: r1 = r2->field_1b
    //     0x13e9124: ldur            w1, [x2, #0x1b]
    // 0x13e9128: DecompressPointer r1
    //     0x13e9128: add             x1, x1, HEAP, lsl #32
    // 0x13e912c: StoreField: r0->field_3b = r1
    //     0x13e912c: stur            w1, [x0, #0x3b]
    // 0x13e9130: r16 = "priority"
    //     0x13e9130: ldr             x16, [PP, #0x6698]  ; [pp+0x6698] "priority"
    // 0x13e9134: StoreField: r0->field_3f = r16
    //     0x13e9134: stur            w16, [x0, #0x3f]
    // 0x13e9138: LoadField: r1 = r2->field_1f
    //     0x13e9138: ldur            w1, [x2, #0x1f]
    // 0x13e913c: DecompressPointer r1
    //     0x13e913c: add             x1, x1, HEAP, lsl #32
    // 0x13e9140: r0 = convertAndroidNotificationPriorityToInt()
    //     0x13e9140: bl              #0x13e92e4  ; [package:firebase_messaging_platform_interface/src/utils.dart] ::convertAndroidNotificationPriorityToInt
    // 0x13e9144: mov             x2, x0
    // 0x13e9148: r0 = BoxInt64Instr(r2)
    //     0x13e9148: sbfiz           x0, x2, #1, #0x1f
    //     0x13e914c: cmp             x2, x0, asr #1
    //     0x13e9150: b.eq            #0x13e915c
    //     0x13e9154: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x13e9158: stur            x2, [x0, #7]
    // 0x13e915c: ldur            x1, [fp, #-0x10]
    // 0x13e9160: ArrayStore: r1[13] = r0  ; List_4
    //     0x13e9160: add             x25, x1, #0x43
    //     0x13e9164: str             w0, [x25]
    //     0x13e9168: tbz             w0, #0, #0x13e9184
    //     0x13e916c: ldurb           w16, [x1, #-1]
    //     0x13e9170: ldurb           w17, [x0, #-1]
    //     0x13e9174: and             x16, x17, x16, lsr #2
    //     0x13e9178: tst             x16, HEAP, lsr #32
    //     0x13e917c: b.eq            #0x13e9184
    //     0x13e9180: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x13e9184: ldur            x2, [fp, #-0x10]
    // 0x13e9188: r16 = "smallIcon"
    //     0x13e9188: ldr             x16, [PP, #0x66d8]  ; [pp+0x66d8] "smallIcon"
    // 0x13e918c: StoreField: r2->field_47 = r16
    //     0x13e918c: stur            w16, [x2, #0x47]
    // 0x13e9190: ldur            x3, [fp, #-8]
    // 0x13e9194: LoadField: r0 = r3->field_23
    //     0x13e9194: ldur            w0, [x3, #0x23]
    // 0x13e9198: DecompressPointer r0
    //     0x13e9198: add             x0, x0, HEAP, lsl #32
    // 0x13e919c: mov             x1, x2
    // 0x13e91a0: ArrayStore: r1[15] = r0  ; List_4
    //     0x13e91a0: add             x25, x1, #0x4b
    //     0x13e91a4: str             w0, [x25]
    //     0x13e91a8: tbz             w0, #0, #0x13e91c4
    //     0x13e91ac: ldurb           w16, [x1, #-1]
    //     0x13e91b0: ldurb           w17, [x0, #-1]
    //     0x13e91b4: and             x16, x17, x16, lsr #2
    //     0x13e91b8: tst             x16, HEAP, lsr #32
    //     0x13e91bc: b.eq            #0x13e91c4
    //     0x13e91c0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x13e91c4: r16 = "sound"
    //     0x13e91c4: ldr             x16, [PP, #0x65c8]  ; [pp+0x65c8] "sound"
    // 0x13e91c8: StoreField: r2->field_4f = r16
    //     0x13e91c8: stur            w16, [x2, #0x4f]
    // 0x13e91cc: LoadField: r0 = r3->field_27
    //     0x13e91cc: ldur            w0, [x3, #0x27]
    // 0x13e91d0: DecompressPointer r0
    //     0x13e91d0: add             x0, x0, HEAP, lsl #32
    // 0x13e91d4: mov             x1, x2
    // 0x13e91d8: ArrayStore: r1[17] = r0  ; List_4
    //     0x13e91d8: add             x25, x1, #0x53
    //     0x13e91dc: str             w0, [x25]
    //     0x13e91e0: tbz             w0, #0, #0x13e91fc
    //     0x13e91e4: ldurb           w16, [x1, #-1]
    //     0x13e91e8: ldurb           w17, [x0, #-1]
    //     0x13e91ec: and             x16, x17, x16, lsr #2
    //     0x13e91f0: tst             x16, HEAP, lsr #32
    //     0x13e91f4: b.eq            #0x13e91fc
    //     0x13e91f8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x13e91fc: r16 = "ticker"
    //     0x13e91fc: ldr             x16, [PP, #0x6700]  ; [pp+0x6700] "ticker"
    // 0x13e9200: StoreField: r2->field_57 = r16
    //     0x13e9200: stur            w16, [x2, #0x57]
    // 0x13e9204: LoadField: r0 = r3->field_2b
    //     0x13e9204: ldur            w0, [x3, #0x2b]
    // 0x13e9208: DecompressPointer r0
    //     0x13e9208: add             x0, x0, HEAP, lsl #32
    // 0x13e920c: mov             x1, x2
    // 0x13e9210: ArrayStore: r1[19] = r0  ; List_4
    //     0x13e9210: add             x25, x1, #0x5b
    //     0x13e9214: str             w0, [x25]
    //     0x13e9218: tbz             w0, #0, #0x13e9234
    //     0x13e921c: ldurb           w16, [x1, #-1]
    //     0x13e9220: ldurb           w17, [x0, #-1]
    //     0x13e9224: and             x16, x17, x16, lsr #2
    //     0x13e9228: tst             x16, HEAP, lsr #32
    //     0x13e922c: b.eq            #0x13e9234
    //     0x13e9230: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x13e9234: r16 = "tag"
    //     0x13e9234: ldr             x16, [PP, #0x6718]  ; [pp+0x6718] "tag"
    // 0x13e9238: StoreField: r2->field_5f = r16
    //     0x13e9238: stur            w16, [x2, #0x5f]
    // 0x13e923c: LoadField: r0 = r3->field_33
    //     0x13e923c: ldur            w0, [x3, #0x33]
    // 0x13e9240: DecompressPointer r0
    //     0x13e9240: add             x0, x0, HEAP, lsl #32
    // 0x13e9244: mov             x1, x2
    // 0x13e9248: ArrayStore: r1[21] = r0  ; List_4
    //     0x13e9248: add             x25, x1, #0x63
    //     0x13e924c: str             w0, [x25]
    //     0x13e9250: tbz             w0, #0, #0x13e926c
    //     0x13e9254: ldurb           w16, [x1, #-1]
    //     0x13e9258: ldurb           w17, [x0, #-1]
    //     0x13e925c: and             x16, x17, x16, lsr #2
    //     0x13e9260: tst             x16, HEAP, lsr #32
    //     0x13e9264: b.eq            #0x13e926c
    //     0x13e9268: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x13e926c: r16 = "visibility"
    //     0x13e926c: ldr             x16, [PP, #0x6730]  ; [pp+0x6730] "visibility"
    // 0x13e9270: StoreField: r2->field_67 = r16
    //     0x13e9270: stur            w16, [x2, #0x67]
    // 0x13e9274: LoadField: r0 = r3->field_2f
    //     0x13e9274: ldur            w0, [x3, #0x2f]
    // 0x13e9278: DecompressPointer r0
    //     0x13e9278: add             x0, x0, HEAP, lsl #32
    // 0x13e927c: r16 = Instance_AndroidNotificationVisibility
    //     0x13e927c: ldr             x16, [PP, #0x6748]  ; [pp+0x6748] Obj!AndroidNotificationVisibility@12c6221
    // 0x13e9280: cmp             w0, w16
    // 0x13e9284: b.ne            #0x13e9290
    // 0x13e9288: r0 = -1
    //     0x13e9288: mov             x0, #-1
    // 0x13e928c: b               #0x13e92bc
    // 0x13e9290: r16 = Instance_AndroidNotificationVisibility
    //     0x13e9290: ldr             x16, [PP, #0x6750]  ; [pp+0x6750] Obj!AndroidNotificationVisibility@12c6201
    // 0x13e9294: cmp             w0, w16
    // 0x13e9298: b.ne            #0x13e92a4
    // 0x13e929c: r0 = 0
    //     0x13e929c: mov             x0, #0
    // 0x13e92a0: b               #0x13e92bc
    // 0x13e92a4: r16 = Instance_AndroidNotificationVisibility
    //     0x13e92a4: ldr             x16, [PP, #0x6758]  ; [pp+0x6758] Obj!AndroidNotificationVisibility@12c61e1
    // 0x13e92a8: cmp             w0, w16
    // 0x13e92ac: b.ne            #0x13e92b8
    // 0x13e92b0: r0 = 1
    //     0x13e92b0: mov             x0, #1
    // 0x13e92b4: b               #0x13e92bc
    // 0x13e92b8: r0 = 0
    //     0x13e92b8: mov             x0, #0
    // 0x13e92bc: lsl             x1, x0, #1
    // 0x13e92c0: StoreField: r2->field_6b = r1
    //     0x13e92c0: stur            w1, [x2, #0x6b]
    // 0x13e92c4: r16 = <String, dynamic>
    //     0x13e92c4: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x13e92c8: stp             x2, x16, [SP]
    // 0x13e92cc: r0 = Map._fromLiteral()
    //     0x13e92cc: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x13e92d0: LeaveFrame
    //     0x13e92d0: mov             SP, fp
    //     0x13e92d4: ldp             fp, lr, [SP], #0x10
    // 0x13e92d8: ret
    //     0x13e92d8: ret             
    // 0x13e92dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13e92dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13e92e0: b               #0x13e90a4
  }
}

// class id: 3349, size: 0x2c, field offset: 0x8
//   const constructor, 
class RemoteNotification extends Object {

  factory _ RemoteNotification.fromMap(/* No info */) {
    // ** addr: 0x923780, size: 0x470
    // 0x923780: EnterFrame
    //     0x923780: stp             fp, lr, [SP, #-0x10]!
    //     0x923784: mov             fp, SP
    // 0x923788: AllocStack(0x48)
    //     0x923788: sub             SP, SP, #0x48
    // 0x92378c: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0x92378c: mov             x0, x2
    //     0x923790: stur            x2, [fp, #-8]
    // 0x923794: CheckStackOverflow
    //     0x923794: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x923798: cmp             SP, x16
    //     0x92379c: b.ls            #0x923be8
    // 0x9237a0: mov             x1, x0
    // 0x9237a4: r2 = "title"
    //     0x9237a4: ldr             x2, [PP, #0x6470]  ; [pp+0x6470] "title"
    // 0x9237a8: r0 = _getValueOrData()
    //     0x9237a8: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x9237ac: ldur            x3, [fp, #-8]
    // 0x9237b0: LoadField: r1 = r3->field_f
    //     0x9237b0: ldur            w1, [x3, #0xf]
    // 0x9237b4: DecompressPointer r1
    //     0x9237b4: add             x1, x1, HEAP, lsl #32
    // 0x9237b8: cmp             w1, w0
    // 0x9237bc: b.ne            #0x9237c8
    // 0x9237c0: r4 = Null
    //     0x9237c0: mov             x4, NULL
    // 0x9237c4: b               #0x9237cc
    // 0x9237c8: mov             x4, x0
    // 0x9237cc: mov             x0, x4
    // 0x9237d0: stur            x4, [fp, #-0x10]
    // 0x9237d4: r2 = Null
    //     0x9237d4: mov             x2, NULL
    // 0x9237d8: r1 = Null
    //     0x9237d8: mov             x1, NULL
    // 0x9237dc: r4 = 60
    //     0x9237dc: mov             x4, #0x3c
    // 0x9237e0: branchIfSmi(r0, 0x9237ec)
    //     0x9237e0: tbz             w0, #0, #0x9237ec
    // 0x9237e4: r4 = LoadClassIdInstr(r0)
    //     0x9237e4: ldur            x4, [x0, #-1]
    //     0x9237e8: ubfx            x4, x4, #0xc, #0x14
    // 0x9237ec: sub             x4, x4, #0x5e
    // 0x9237f0: cmp             x4, #1
    // 0x9237f4: b.ls            #0x923804
    // 0x9237f8: r8 = String?
    //     0x9237f8: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x9237fc: r3 = Null
    //     0x9237fc: ldr             x3, [PP, #0x6478]  ; [pp+0x6478] Null
    // 0x923800: r0 = String?()
    //     0x923800: bl              #0x7db310  ; IsType_String?_Stub
    // 0x923804: ldur            x1, [fp, #-8]
    // 0x923808: r2 = "titleLocArgs"
    //     0x923808: ldr             x2, [PP, #0x6488]  ; [pp+0x6488] "titleLocArgs"
    // 0x92380c: r0 = _getValueOrData()
    //     0x92380c: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x923810: mov             x1, x0
    // 0x923814: ldur            x0, [fp, #-8]
    // 0x923818: LoadField: r2 = r0->field_f
    //     0x923818: ldur            w2, [x0, #0xf]
    // 0x92381c: DecompressPointer r2
    //     0x92381c: add             x2, x2, HEAP, lsl #32
    // 0x923820: cmp             w2, w1
    // 0x923824: b.ne            #0x92382c
    // 0x923828: r1 = Null
    //     0x923828: mov             x1, NULL
    // 0x92382c: r0 = _toList()
    //     0x92382c: bl              #0x924830  ; [package:firebase_messaging_platform_interface/src/remote_notification.dart] ::_toList
    // 0x923830: ldur            x1, [fp, #-8]
    // 0x923834: r2 = "titleLocKey"
    //     0x923834: ldr             x2, [PP, #0x6490]  ; [pp+0x6490] "titleLocKey"
    // 0x923838: stur            x0, [fp, #-0x18]
    // 0x92383c: r0 = _getValueOrData()
    //     0x92383c: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x923840: ldur            x3, [fp, #-8]
    // 0x923844: LoadField: r1 = r3->field_f
    //     0x923844: ldur            w1, [x3, #0xf]
    // 0x923848: DecompressPointer r1
    //     0x923848: add             x1, x1, HEAP, lsl #32
    // 0x92384c: cmp             w1, w0
    // 0x923850: b.ne            #0x92385c
    // 0x923854: r4 = Null
    //     0x923854: mov             x4, NULL
    // 0x923858: b               #0x923860
    // 0x92385c: mov             x4, x0
    // 0x923860: mov             x0, x4
    // 0x923864: stur            x4, [fp, #-0x20]
    // 0x923868: r2 = Null
    //     0x923868: mov             x2, NULL
    // 0x92386c: r1 = Null
    //     0x92386c: mov             x1, NULL
    // 0x923870: r4 = 60
    //     0x923870: mov             x4, #0x3c
    // 0x923874: branchIfSmi(r0, 0x923880)
    //     0x923874: tbz             w0, #0, #0x923880
    // 0x923878: r4 = LoadClassIdInstr(r0)
    //     0x923878: ldur            x4, [x0, #-1]
    //     0x92387c: ubfx            x4, x4, #0xc, #0x14
    // 0x923880: sub             x4, x4, #0x5e
    // 0x923884: cmp             x4, #1
    // 0x923888: b.ls            #0x923898
    // 0x92388c: r8 = String?
    //     0x92388c: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x923890: r3 = Null
    //     0x923890: ldr             x3, [PP, #0x6498]  ; [pp+0x6498] Null
    // 0x923894: r0 = String?()
    //     0x923894: bl              #0x7db310  ; IsType_String?_Stub
    // 0x923898: ldur            x1, [fp, #-8]
    // 0x92389c: r2 = "body"
    //     0x92389c: ldr             x2, [PP, #0x64a8]  ; [pp+0x64a8] "body"
    // 0x9238a0: r0 = _getValueOrData()
    //     0x9238a0: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x9238a4: ldur            x3, [fp, #-8]
    // 0x9238a8: LoadField: r1 = r3->field_f
    //     0x9238a8: ldur            w1, [x3, #0xf]
    // 0x9238ac: DecompressPointer r1
    //     0x9238ac: add             x1, x1, HEAP, lsl #32
    // 0x9238b0: cmp             w1, w0
    // 0x9238b4: b.ne            #0x9238c0
    // 0x9238b8: r4 = Null
    //     0x9238b8: mov             x4, NULL
    // 0x9238bc: b               #0x9238c4
    // 0x9238c0: mov             x4, x0
    // 0x9238c4: mov             x0, x4
    // 0x9238c8: stur            x4, [fp, #-0x28]
    // 0x9238cc: r2 = Null
    //     0x9238cc: mov             x2, NULL
    // 0x9238d0: r1 = Null
    //     0x9238d0: mov             x1, NULL
    // 0x9238d4: r4 = 60
    //     0x9238d4: mov             x4, #0x3c
    // 0x9238d8: branchIfSmi(r0, 0x9238e4)
    //     0x9238d8: tbz             w0, #0, #0x9238e4
    // 0x9238dc: r4 = LoadClassIdInstr(r0)
    //     0x9238dc: ldur            x4, [x0, #-1]
    //     0x9238e0: ubfx            x4, x4, #0xc, #0x14
    // 0x9238e4: sub             x4, x4, #0x5e
    // 0x9238e8: cmp             x4, #1
    // 0x9238ec: b.ls            #0x9238fc
    // 0x9238f0: r8 = String?
    //     0x9238f0: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x9238f4: r3 = Null
    //     0x9238f4: ldr             x3, [PP, #0x64b0]  ; [pp+0x64b0] Null
    // 0x9238f8: r0 = String?()
    //     0x9238f8: bl              #0x7db310  ; IsType_String?_Stub
    // 0x9238fc: ldur            x1, [fp, #-8]
    // 0x923900: r2 = "bodyLocArgs"
    //     0x923900: ldr             x2, [PP, #0x64c0]  ; [pp+0x64c0] "bodyLocArgs"
    // 0x923904: r0 = _getValueOrData()
    //     0x923904: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x923908: mov             x1, x0
    // 0x92390c: ldur            x0, [fp, #-8]
    // 0x923910: LoadField: r2 = r0->field_f
    //     0x923910: ldur            w2, [x0, #0xf]
    // 0x923914: DecompressPointer r2
    //     0x923914: add             x2, x2, HEAP, lsl #32
    // 0x923918: cmp             w2, w1
    // 0x92391c: b.ne            #0x923924
    // 0x923920: r1 = Null
    //     0x923920: mov             x1, NULL
    // 0x923924: r0 = _toList()
    //     0x923924: bl              #0x924830  ; [package:firebase_messaging_platform_interface/src/remote_notification.dart] ::_toList
    // 0x923928: ldur            x1, [fp, #-8]
    // 0x92392c: r2 = "bodyLocKey"
    //     0x92392c: ldr             x2, [PP, #0x64c8]  ; [pp+0x64c8] "bodyLocKey"
    // 0x923930: stur            x0, [fp, #-0x30]
    // 0x923934: r0 = _getValueOrData()
    //     0x923934: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x923938: ldur            x3, [fp, #-8]
    // 0x92393c: LoadField: r1 = r3->field_f
    //     0x92393c: ldur            w1, [x3, #0xf]
    // 0x923940: DecompressPointer r1
    //     0x923940: add             x1, x1, HEAP, lsl #32
    // 0x923944: cmp             w1, w0
    // 0x923948: b.ne            #0x923954
    // 0x92394c: r4 = Null
    //     0x92394c: mov             x4, NULL
    // 0x923950: b               #0x923958
    // 0x923954: mov             x4, x0
    // 0x923958: mov             x0, x4
    // 0x92395c: stur            x4, [fp, #-0x38]
    // 0x923960: r2 = Null
    //     0x923960: mov             x2, NULL
    // 0x923964: r1 = Null
    //     0x923964: mov             x1, NULL
    // 0x923968: r4 = 60
    //     0x923968: mov             x4, #0x3c
    // 0x92396c: branchIfSmi(r0, 0x923978)
    //     0x92396c: tbz             w0, #0, #0x923978
    // 0x923970: r4 = LoadClassIdInstr(r0)
    //     0x923970: ldur            x4, [x0, #-1]
    //     0x923974: ubfx            x4, x4, #0xc, #0x14
    // 0x923978: sub             x4, x4, #0x5e
    // 0x92397c: cmp             x4, #1
    // 0x923980: b.ls            #0x923990
    // 0x923984: r8 = String?
    //     0x923984: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x923988: r3 = Null
    //     0x923988: ldr             x3, [PP, #0x64d0]  ; [pp+0x64d0] Null
    // 0x92398c: r0 = String?()
    //     0x92398c: bl              #0x7db310  ; IsType_String?_Stub
    // 0x923990: ldur            x1, [fp, #-8]
    // 0x923994: r2 = "android"
    //     0x923994: ldr             x2, [PP, #0x3d20]  ; [pp+0x3d20] "android"
    // 0x923998: r0 = _getValueOrData()
    //     0x923998: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x92399c: mov             x1, x0
    // 0x9239a0: ldur            x0, [fp, #-8]
    // 0x9239a4: LoadField: r2 = r0->field_f
    //     0x9239a4: ldur            w2, [x0, #0xf]
    // 0x9239a8: DecompressPointer r2
    //     0x9239a8: add             x2, x2, HEAP, lsl #32
    // 0x9239ac: cmp             w2, w1
    // 0x9239b0: b.eq            #0x923a24
    // 0x9239b4: cmp             w1, NULL
    // 0x9239b8: b.eq            #0x923a24
    // 0x9239bc: mov             x1, x0
    // 0x9239c0: r2 = "android"
    //     0x9239c0: ldr             x2, [PP, #0x3d20]  ; [pp+0x3d20] "android"
    // 0x9239c4: r0 = _getValueOrData()
    //     0x9239c4: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x9239c8: ldur            x3, [fp, #-8]
    // 0x9239cc: LoadField: r1 = r3->field_f
    //     0x9239cc: ldur            w1, [x3, #0xf]
    // 0x9239d0: DecompressPointer r1
    //     0x9239d0: add             x1, x1, HEAP, lsl #32
    // 0x9239d4: cmp             w1, w0
    // 0x9239d8: b.ne            #0x9239e4
    // 0x9239dc: r4 = Null
    //     0x9239dc: mov             x4, NULL
    // 0x9239e0: b               #0x9239e8
    // 0x9239e4: mov             x4, x0
    // 0x9239e8: mov             x0, x4
    // 0x9239ec: stur            x4, [fp, #-0x40]
    // 0x9239f0: r2 = Null
    //     0x9239f0: mov             x2, NULL
    // 0x9239f4: r1 = Null
    //     0x9239f4: mov             x1, NULL
    // 0x9239f8: r8 = Map
    //     0x9239f8: ldr             x8, [PP, #0x1c8]  ; [pp+0x1c8] Type: Map
    // 0x9239fc: r3 = Null
    //     0x9239fc: ldr             x3, [PP, #0x64e0]  ; [pp+0x64e0] Null
    // 0x923a00: r0 = Map()
    //     0x923a00: bl              #0x13efa40  ; IsType_Map_Stub
    // 0x923a04: ldur            x2, [fp, #-0x40]
    // 0x923a08: r1 = <String, dynamic>
    //     0x923a08: ldr             x1, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x923a0c: r0 = LinkedHashMap.from()
    //     0x923a0c: bl              #0x8ac2e4  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x923a10: mov             x2, x0
    // 0x923a14: r1 = Null
    //     0x923a14: mov             x1, NULL
    // 0x923a18: r0 = AndroidNotification.fromMap()
    //     0x923a18: bl              #0x924224  ; [package:firebase_messaging_platform_interface/src/remote_notification.dart] AndroidNotification::AndroidNotification.fromMap
    // 0x923a1c: mov             x3, x0
    // 0x923a20: b               #0x923a28
    // 0x923a24: r3 = Null
    //     0x923a24: mov             x3, NULL
    // 0x923a28: ldur            x0, [fp, #-8]
    // 0x923a2c: mov             x1, x0
    // 0x923a30: stur            x3, [fp, #-0x40]
    // 0x923a34: r2 = "apple"
    //     0x923a34: ldr             x2, [PP, #0x64f0]  ; [pp+0x64f0] "apple"
    // 0x923a38: r0 = _getValueOrData()
    //     0x923a38: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x923a3c: mov             x1, x0
    // 0x923a40: ldur            x0, [fp, #-8]
    // 0x923a44: LoadField: r2 = r0->field_f
    //     0x923a44: ldur            w2, [x0, #0xf]
    // 0x923a48: DecompressPointer r2
    //     0x923a48: add             x2, x2, HEAP, lsl #32
    // 0x923a4c: cmp             w2, w1
    // 0x923a50: b.eq            #0x923ac4
    // 0x923a54: cmp             w1, NULL
    // 0x923a58: b.eq            #0x923ac4
    // 0x923a5c: mov             x1, x0
    // 0x923a60: r2 = "apple"
    //     0x923a60: ldr             x2, [PP, #0x64f0]  ; [pp+0x64f0] "apple"
    // 0x923a64: r0 = _getValueOrData()
    //     0x923a64: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x923a68: ldur            x3, [fp, #-8]
    // 0x923a6c: LoadField: r1 = r3->field_f
    //     0x923a6c: ldur            w1, [x3, #0xf]
    // 0x923a70: DecompressPointer r1
    //     0x923a70: add             x1, x1, HEAP, lsl #32
    // 0x923a74: cmp             w1, w0
    // 0x923a78: b.ne            #0x923a84
    // 0x923a7c: r4 = Null
    //     0x923a7c: mov             x4, NULL
    // 0x923a80: b               #0x923a88
    // 0x923a84: mov             x4, x0
    // 0x923a88: mov             x0, x4
    // 0x923a8c: stur            x4, [fp, #-0x48]
    // 0x923a90: r2 = Null
    //     0x923a90: mov             x2, NULL
    // 0x923a94: r1 = Null
    //     0x923a94: mov             x1, NULL
    // 0x923a98: r8 = Map
    //     0x923a98: ldr             x8, [PP, #0x1c8]  ; [pp+0x1c8] Type: Map
    // 0x923a9c: r3 = Null
    //     0x923a9c: ldr             x3, [PP, #0x64f8]  ; [pp+0x64f8] Null
    // 0x923aa0: r0 = Map()
    //     0x923aa0: bl              #0x13efa40  ; IsType_Map_Stub
    // 0x923aa4: ldur            x2, [fp, #-0x48]
    // 0x923aa8: r1 = <String, dynamic>
    //     0x923aa8: ldr             x1, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x923aac: r0 = LinkedHashMap.from()
    //     0x923aac: bl              #0x8ac2e4  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x923ab0: mov             x2, x0
    // 0x923ab4: r1 = Null
    //     0x923ab4: mov             x1, NULL
    // 0x923ab8: r0 = AppleNotification.fromMap()
    //     0x923ab8: bl              #0x923d90  ; [package:firebase_messaging_platform_interface/src/remote_notification.dart] AppleNotification::AppleNotification.fromMap
    // 0x923abc: mov             x3, x0
    // 0x923ac0: b               #0x923ac8
    // 0x923ac4: r3 = Null
    //     0x923ac4: mov             x3, NULL
    // 0x923ac8: ldur            x0, [fp, #-8]
    // 0x923acc: mov             x1, x0
    // 0x923ad0: stur            x3, [fp, #-0x48]
    // 0x923ad4: r2 = "web"
    //     0x923ad4: ldr             x2, [PP, #0x4030]  ; [pp+0x4030] "web"
    // 0x923ad8: r0 = _getValueOrData()
    //     0x923ad8: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x923adc: mov             x1, x0
    // 0x923ae0: ldur            x0, [fp, #-8]
    // 0x923ae4: LoadField: r2 = r0->field_f
    //     0x923ae4: ldur            w2, [x0, #0xf]
    // 0x923ae8: DecompressPointer r2
    //     0x923ae8: add             x2, x2, HEAP, lsl #32
    // 0x923aec: cmp             w2, w1
    // 0x923af0: b.eq            #0x923b68
    // 0x923af4: cmp             w1, NULL
    // 0x923af8: b.eq            #0x923b68
    // 0x923afc: mov             x1, x0
    // 0x923b00: r2 = "web"
    //     0x923b00: ldr             x2, [PP, #0x4030]  ; [pp+0x4030] "web"
    // 0x923b04: r0 = _getValueOrData()
    //     0x923b04: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x923b08: mov             x1, x0
    // 0x923b0c: ldur            x0, [fp, #-8]
    // 0x923b10: LoadField: r2 = r0->field_f
    //     0x923b10: ldur            w2, [x0, #0xf]
    // 0x923b14: DecompressPointer r2
    //     0x923b14: add             x2, x2, HEAP, lsl #32
    // 0x923b18: cmp             w2, w1
    // 0x923b1c: b.ne            #0x923b28
    // 0x923b20: r3 = Null
    //     0x923b20: mov             x3, NULL
    // 0x923b24: b               #0x923b2c
    // 0x923b28: mov             x3, x1
    // 0x923b2c: mov             x0, x3
    // 0x923b30: stur            x3, [fp, #-8]
    // 0x923b34: r2 = Null
    //     0x923b34: mov             x2, NULL
    // 0x923b38: r1 = Null
    //     0x923b38: mov             x1, NULL
    // 0x923b3c: r8 = Map
    //     0x923b3c: ldr             x8, [PP, #0x1c8]  ; [pp+0x1c8] Type: Map
    // 0x923b40: r3 = Null
    //     0x923b40: ldr             x3, [PP, #0x6508]  ; [pp+0x6508] Null
    // 0x923b44: r0 = Map()
    //     0x923b44: bl              #0x13efa40  ; IsType_Map_Stub
    // 0x923b48: ldur            x2, [fp, #-8]
    // 0x923b4c: r1 = <String, dynamic>
    //     0x923b4c: ldr             x1, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x923b50: r0 = LinkedHashMap.from()
    //     0x923b50: bl              #0x8ac2e4  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x923b54: mov             x2, x0
    // 0x923b58: r1 = Null
    //     0x923b58: mov             x1, NULL
    // 0x923b5c: r0 = WebNotification.fromMap()
    //     0x923b5c: bl              #0x923bfc  ; [package:firebase_messaging_platform_interface/src/remote_notification.dart] WebNotification::WebNotification.fromMap
    // 0x923b60: mov             x8, x0
    // 0x923b64: b               #0x923b6c
    // 0x923b68: r8 = Null
    //     0x923b68: mov             x8, NULL
    // 0x923b6c: ldur            x6, [fp, #-0x18]
    // 0x923b70: ldur            x3, [fp, #-0x30]
    // 0x923b74: ldur            x1, [fp, #-0x40]
    // 0x923b78: ldur            x0, [fp, #-0x48]
    // 0x923b7c: ldur            x7, [fp, #-0x10]
    // 0x923b80: ldur            x5, [fp, #-0x20]
    // 0x923b84: ldur            x4, [fp, #-0x28]
    // 0x923b88: ldur            x2, [fp, #-0x38]
    // 0x923b8c: stur            x8, [fp, #-8]
    // 0x923b90: r0 = RemoteNotification()
    //     0x923b90: bl              #0x923bf0  ; AllocateRemoteNotificationStub -> RemoteNotification (size=0x2c)
    // 0x923b94: ldur            x1, [fp, #-0x40]
    // 0x923b98: StoreField: r0->field_7 = r1
    //     0x923b98: stur            w1, [x0, #7]
    // 0x923b9c: ldur            x1, [fp, #-0x48]
    // 0x923ba0: StoreField: r0->field_b = r1
    //     0x923ba0: stur            w1, [x0, #0xb]
    // 0x923ba4: ldur            x1, [fp, #-8]
    // 0x923ba8: StoreField: r0->field_f = r1
    //     0x923ba8: stur            w1, [x0, #0xf]
    // 0x923bac: ldur            x1, [fp, #-0x10]
    // 0x923bb0: StoreField: r0->field_13 = r1
    //     0x923bb0: stur            w1, [x0, #0x13]
    // 0x923bb4: ldur            x1, [fp, #-0x18]
    // 0x923bb8: ArrayStore: r0[0] = r1  ; List_4
    //     0x923bb8: stur            w1, [x0, #0x17]
    // 0x923bbc: ldur            x1, [fp, #-0x20]
    // 0x923bc0: StoreField: r0->field_1b = r1
    //     0x923bc0: stur            w1, [x0, #0x1b]
    // 0x923bc4: ldur            x1, [fp, #-0x28]
    // 0x923bc8: StoreField: r0->field_1f = r1
    //     0x923bc8: stur            w1, [x0, #0x1f]
    // 0x923bcc: ldur            x1, [fp, #-0x30]
    // 0x923bd0: StoreField: r0->field_23 = r1
    //     0x923bd0: stur            w1, [x0, #0x23]
    // 0x923bd4: ldur            x1, [fp, #-0x38]
    // 0x923bd8: StoreField: r0->field_27 = r1
    //     0x923bd8: stur            w1, [x0, #0x27]
    // 0x923bdc: LeaveFrame
    //     0x923bdc: mov             SP, fp
    //     0x923be0: ldp             fp, lr, [SP], #0x10
    // 0x923be4: ret
    //     0x923be4: ret             
    // 0x923be8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x923be8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x923bec: b               #0x9237a0
  }
  _ toMap(/* No info */) {
    // ** addr: 0x13e8c94, size: 0x1cc
    // 0x13e8c94: EnterFrame
    //     0x13e8c94: stp             fp, lr, [SP, #-0x10]!
    //     0x13e8c98: mov             fp, SP
    // 0x13e8c9c: AllocStack(0x20)
    //     0x13e8c9c: sub             SP, SP, #0x20
    // 0x13e8ca0: SetupParameters(RemoteNotification this /* r1 => r0, fp-0x8 */)
    //     0x13e8ca0: mov             x0, x1
    //     0x13e8ca4: stur            x1, [fp, #-8]
    // 0x13e8ca8: CheckStackOverflow
    //     0x13e8ca8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13e8cac: cmp             SP, x16
    //     0x13e8cb0: b.ls            #0x13e8e58
    // 0x13e8cb4: r1 = Null
    //     0x13e8cb4: mov             x1, NULL
    // 0x13e8cb8: r2 = 36
    //     0x13e8cb8: mov             x2, #0x24
    // 0x13e8cbc: r0 = AllocateArray()
    //     0x13e8cbc: bl              #0x13df928  ; AllocateArrayStub
    // 0x13e8cc0: stur            x0, [fp, #-0x10]
    // 0x13e8cc4: r16 = "title"
    //     0x13e8cc4: ldr             x16, [PP, #0x6470]  ; [pp+0x6470] "title"
    // 0x13e8cc8: StoreField: r0->field_f = r16
    //     0x13e8cc8: stur            w16, [x0, #0xf]
    // 0x13e8ccc: ldur            x2, [fp, #-8]
    // 0x13e8cd0: LoadField: r1 = r2->field_13
    //     0x13e8cd0: ldur            w1, [x2, #0x13]
    // 0x13e8cd4: DecompressPointer r1
    //     0x13e8cd4: add             x1, x1, HEAP, lsl #32
    // 0x13e8cd8: StoreField: r0->field_13 = r1
    //     0x13e8cd8: stur            w1, [x0, #0x13]
    // 0x13e8cdc: r16 = "titleLocArgs"
    //     0x13e8cdc: ldr             x16, [PP, #0x6488]  ; [pp+0x6488] "titleLocArgs"
    // 0x13e8ce0: ArrayStore: r0[0] = r16  ; List_4
    //     0x13e8ce0: stur            w16, [x0, #0x17]
    // 0x13e8ce4: ArrayLoad: r1 = r2[0]  ; List_4
    //     0x13e8ce4: ldur            w1, [x2, #0x17]
    // 0x13e8ce8: DecompressPointer r1
    //     0x13e8ce8: add             x1, x1, HEAP, lsl #32
    // 0x13e8cec: StoreField: r0->field_1b = r1
    //     0x13e8cec: stur            w1, [x0, #0x1b]
    // 0x13e8cf0: r16 = "titleLocKey"
    //     0x13e8cf0: ldr             x16, [PP, #0x6490]  ; [pp+0x6490] "titleLocKey"
    // 0x13e8cf4: StoreField: r0->field_1f = r16
    //     0x13e8cf4: stur            w16, [x0, #0x1f]
    // 0x13e8cf8: LoadField: r1 = r2->field_1b
    //     0x13e8cf8: ldur            w1, [x2, #0x1b]
    // 0x13e8cfc: DecompressPointer r1
    //     0x13e8cfc: add             x1, x1, HEAP, lsl #32
    // 0x13e8d00: StoreField: r0->field_23 = r1
    //     0x13e8d00: stur            w1, [x0, #0x23]
    // 0x13e8d04: r16 = "body"
    //     0x13e8d04: ldr             x16, [PP, #0x64a8]  ; [pp+0x64a8] "body"
    // 0x13e8d08: StoreField: r0->field_27 = r16
    //     0x13e8d08: stur            w16, [x0, #0x27]
    // 0x13e8d0c: LoadField: r1 = r2->field_1f
    //     0x13e8d0c: ldur            w1, [x2, #0x1f]
    // 0x13e8d10: DecompressPointer r1
    //     0x13e8d10: add             x1, x1, HEAP, lsl #32
    // 0x13e8d14: StoreField: r0->field_2b = r1
    //     0x13e8d14: stur            w1, [x0, #0x2b]
    // 0x13e8d18: r16 = "bodyLocArgs"
    //     0x13e8d18: ldr             x16, [PP, #0x64c0]  ; [pp+0x64c0] "bodyLocArgs"
    // 0x13e8d1c: StoreField: r0->field_2f = r16
    //     0x13e8d1c: stur            w16, [x0, #0x2f]
    // 0x13e8d20: LoadField: r1 = r2->field_23
    //     0x13e8d20: ldur            w1, [x2, #0x23]
    // 0x13e8d24: DecompressPointer r1
    //     0x13e8d24: add             x1, x1, HEAP, lsl #32
    // 0x13e8d28: StoreField: r0->field_33 = r1
    //     0x13e8d28: stur            w1, [x0, #0x33]
    // 0x13e8d2c: r16 = "bodyLocKey"
    //     0x13e8d2c: ldr             x16, [PP, #0x64c8]  ; [pp+0x64c8] "bodyLocKey"
    // 0x13e8d30: StoreField: r0->field_37 = r16
    //     0x13e8d30: stur            w16, [x0, #0x37]
    // 0x13e8d34: LoadField: r1 = r2->field_27
    //     0x13e8d34: ldur            w1, [x2, #0x27]
    // 0x13e8d38: DecompressPointer r1
    //     0x13e8d38: add             x1, x1, HEAP, lsl #32
    // 0x13e8d3c: StoreField: r0->field_3b = r1
    //     0x13e8d3c: stur            w1, [x0, #0x3b]
    // 0x13e8d40: r16 = "android"
    //     0x13e8d40: ldr             x16, [PP, #0x3d20]  ; [pp+0x3d20] "android"
    // 0x13e8d44: StoreField: r0->field_3f = r16
    //     0x13e8d44: stur            w16, [x0, #0x3f]
    // 0x13e8d48: LoadField: r1 = r2->field_7
    //     0x13e8d48: ldur            w1, [x2, #7]
    // 0x13e8d4c: DecompressPointer r1
    //     0x13e8d4c: add             x1, x1, HEAP, lsl #32
    // 0x13e8d50: cmp             w1, NULL
    // 0x13e8d54: b.ne            #0x13e8d68
    // 0x13e8d58: mov             x3, x2
    // 0x13e8d5c: mov             x2, x0
    // 0x13e8d60: r0 = Null
    //     0x13e8d60: mov             x0, NULL
    // 0x13e8d64: b               #0x13e8d74
    // 0x13e8d68: r0 = toMap()
    //     0x13e8d68: bl              #0x13e9084  ; [package:firebase_messaging_platform_interface/src/remote_notification.dart] AndroidNotification::toMap
    // 0x13e8d6c: ldur            x3, [fp, #-8]
    // 0x13e8d70: ldur            x2, [fp, #-0x10]
    // 0x13e8d74: mov             x1, x2
    // 0x13e8d78: ArrayStore: r1[13] = r0  ; List_4
    //     0x13e8d78: add             x25, x1, #0x43
    //     0x13e8d7c: str             w0, [x25]
    //     0x13e8d80: tbz             w0, #0, #0x13e8d9c
    //     0x13e8d84: ldurb           w16, [x1, #-1]
    //     0x13e8d88: ldurb           w17, [x0, #-1]
    //     0x13e8d8c: and             x16, x17, x16, lsr #2
    //     0x13e8d90: tst             x16, HEAP, lsr #32
    //     0x13e8d94: b.eq            #0x13e8d9c
    //     0x13e8d98: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x13e8d9c: r16 = "apple"
    //     0x13e8d9c: ldr             x16, [PP, #0x64f0]  ; [pp+0x64f0] "apple"
    // 0x13e8da0: StoreField: r2->field_47 = r16
    //     0x13e8da0: stur            w16, [x2, #0x47]
    // 0x13e8da4: LoadField: r1 = r3->field_b
    //     0x13e8da4: ldur            w1, [x3, #0xb]
    // 0x13e8da8: DecompressPointer r1
    //     0x13e8da8: add             x1, x1, HEAP, lsl #32
    // 0x13e8dac: cmp             w1, NULL
    // 0x13e8db0: b.ne            #0x13e8dbc
    // 0x13e8db4: r0 = Null
    //     0x13e8db4: mov             x0, NULL
    // 0x13e8db8: b               #0x13e8dc8
    // 0x13e8dbc: r0 = toMap()
    //     0x13e8dbc: bl              #0x13e8eec  ; [package:firebase_messaging_platform_interface/src/remote_notification.dart] AppleNotification::toMap
    // 0x13e8dc0: ldur            x3, [fp, #-8]
    // 0x13e8dc4: ldur            x2, [fp, #-0x10]
    // 0x13e8dc8: mov             x1, x2
    // 0x13e8dcc: ArrayStore: r1[15] = r0  ; List_4
    //     0x13e8dcc: add             x25, x1, #0x4b
    //     0x13e8dd0: str             w0, [x25]
    //     0x13e8dd4: tbz             w0, #0, #0x13e8df0
    //     0x13e8dd8: ldurb           w16, [x1, #-1]
    //     0x13e8ddc: ldurb           w17, [x0, #-1]
    //     0x13e8de0: and             x16, x17, x16, lsr #2
    //     0x13e8de4: tst             x16, HEAP, lsr #32
    //     0x13e8de8: b.eq            #0x13e8df0
    //     0x13e8dec: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x13e8df0: r16 = "web"
    //     0x13e8df0: ldr             x16, [PP, #0x4030]  ; [pp+0x4030] "web"
    // 0x13e8df4: StoreField: r2->field_4f = r16
    //     0x13e8df4: stur            w16, [x2, #0x4f]
    // 0x13e8df8: LoadField: r1 = r3->field_f
    //     0x13e8df8: ldur            w1, [x3, #0xf]
    // 0x13e8dfc: DecompressPointer r1
    //     0x13e8dfc: add             x1, x1, HEAP, lsl #32
    // 0x13e8e00: cmp             w1, NULL
    // 0x13e8e04: b.ne            #0x13e8e10
    // 0x13e8e08: r0 = Null
    //     0x13e8e08: mov             x0, NULL
    // 0x13e8e0c: b               #0x13e8e14
    // 0x13e8e10: r0 = toMap()
    //     0x13e8e10: bl              #0x13e8e60  ; [package:firebase_messaging_platform_interface/src/remote_notification.dart] WebNotification::toMap
    // 0x13e8e14: ldur            x1, [fp, #-0x10]
    // 0x13e8e18: ArrayStore: r1[17] = r0  ; List_4
    //     0x13e8e18: add             x25, x1, #0x53
    //     0x13e8e1c: str             w0, [x25]
    //     0x13e8e20: tbz             w0, #0, #0x13e8e3c
    //     0x13e8e24: ldurb           w16, [x1, #-1]
    //     0x13e8e28: ldurb           w17, [x0, #-1]
    //     0x13e8e2c: and             x16, x17, x16, lsr #2
    //     0x13e8e30: tst             x16, HEAP, lsr #32
    //     0x13e8e34: b.eq            #0x13e8e3c
    //     0x13e8e38: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x13e8e3c: r16 = <String, dynamic>
    //     0x13e8e3c: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x13e8e40: ldur            lr, [fp, #-0x10]
    // 0x13e8e44: stp             lr, x16, [SP]
    // 0x13e8e48: r0 = Map._fromLiteral()
    //     0x13e8e48: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x13e8e4c: LeaveFrame
    //     0x13e8e4c: mov             SP, fp
    //     0x13e8e50: ldp             fp, lr, [SP], #0x10
    // 0x13e8e54: ret
    //     0x13e8e54: ret             
    // 0x13e8e58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13e8e58: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13e8e5c: b               #0x13e8cb4
  }
}
