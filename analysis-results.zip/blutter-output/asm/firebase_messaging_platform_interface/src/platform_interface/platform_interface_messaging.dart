// lib: , url: package:firebase_messaging_platform_interface/src/platform_interface/platform_interface_messaging.dart

// class id: 1048756, size: 0x8
class :: {
}

// class id: 3697, size: 0xc, field offset: 0x8
abstract class FirebaseMessagingPlatform extends PlatformInterface {

  static late final StreamController<RemoteMessage> onMessage; // offset: 0x10e8
  static late final Object _token; // offset: 0x10e0
  static late final StreamController<RemoteMessage> onMessageOpenedApp; // offset: 0x10ec

  get _ app(/* No info */) {
    // ** addr: 0x922dd8, size: 0x48
    // 0x922dd8: EnterFrame
    //     0x922dd8: stp             fp, lr, [SP, #-0x10]!
    //     0x922ddc: mov             fp, SP
    // 0x922de0: CheckStackOverflow
    //     0x922de0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x922de4: cmp             SP, x16
    //     0x922de8: b.ls            #0x922e18
    // 0x922dec: LoadField: r0 = r1->field_7
    //     0x922dec: ldur            w0, [x1, #7]
    // 0x922df0: DecompressPointer r0
    //     0x922df0: add             x0, x0, HEAP, lsl #32
    // 0x922df4: cmp             w0, NULL
    // 0x922df8: b.ne            #0x922e0c
    // 0x922dfc: r0 = app()
    //     0x922dfc: bl              #0x8c0c7c  ; [package:firebase_core/firebase_core.dart] Firebase::app
    // 0x922e00: LeaveFrame
    //     0x922e00: mov             SP, fp
    //     0x922e04: ldp             fp, lr, [SP], #0x10
    // 0x922e08: ret
    //     0x922e08: ret             
    // 0x922e0c: LeaveFrame
    //     0x922e0c: mov             SP, fp
    //     0x922e10: ldp             fp, lr, [SP], #0x10
    // 0x922e14: ret
    //     0x922e14: ret             
    // 0x922e18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x922e18: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x922e1c: b               #0x922dec
  }
  factory _ FirebaseMessagingPlatform.instanceFor(/* No info */) {
    // ** addr: 0x924c70, size: 0xb8
    // 0x924c70: EnterFrame
    //     0x924c70: stp             fp, lr, [SP, #-0x10]!
    //     0x924c74: mov             fp, SP
    // 0x924c78: AllocStack(0x10)
    //     0x924c78: sub             SP, SP, #0x10
    // 0x924c7c: SetupParameters(dynamic _ /* r1 => r0 */, dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r1, fp-0x10 */)
    //     0x924c7c: mov             x0, x1
    //     0x924c80: mov             x1, x3
    //     0x924c84: stur            x2, [fp, #-8]
    //     0x924c88: stur            x3, [fp, #-0x10]
    // 0x924c8c: CheckStackOverflow
    //     0x924c8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x924c90: cmp             SP, x16
    //     0x924c94: b.ls            #0x924d20
    // 0x924c98: r0 = instance()
    //     0x924c98: bl              #0x924dcc  ; [package:firebase_messaging_platform_interface/src/platform_interface/platform_interface_messaging.dart] FirebaseMessagingPlatform::instance
    // 0x924c9c: mov             x1, x0
    // 0x924ca0: ldur            x2, [fp, #-8]
    // 0x924ca4: r0 = delegateFor()
    //     0x924ca4: bl              #0x924d28  ; [package:firebase_messaging_platform_interface/src/method_channel/method_channel_messaging.dart] MethodChannelFirebaseMessaging::delegateFor
    // 0x924ca8: mov             x3, x0
    // 0x924cac: ldur            x1, [fp, #-0x10]
    // 0x924cb0: stur            x3, [fp, #-8]
    // 0x924cb4: r0 = LoadClassIdInstr(r1)
    //     0x924cb4: ldur            x0, [x1, #-1]
    //     0x924cb8: ubfx            x0, x0, #0xc, #0x14
    // 0x924cbc: r2 = "AUTO_INIT_ENABLED"
    //     0x924cbc: add             x2, PP, #8, lsl #12  ; [pp+0x8bc8] "AUTO_INIT_ENABLED"
    //     0x924cc0: ldr             x2, [x2, #0xbc8]
    // 0x924cc4: r0 = GDT[cid_x0 + -0xd48]()
    //     0x924cc4: sub             lr, x0, #0xd48
    //     0x924cc8: ldr             lr, [x21, lr, lsl #3]
    //     0x924ccc: blr             lr
    // 0x924cd0: mov             x3, x0
    // 0x924cd4: r2 = Null
    //     0x924cd4: mov             x2, NULL
    // 0x924cd8: r1 = Null
    //     0x924cd8: mov             x1, NULL
    // 0x924cdc: stur            x3, [fp, #-0x10]
    // 0x924ce0: r4 = 60
    //     0x924ce0: mov             x4, #0x3c
    // 0x924ce4: branchIfSmi(r0, 0x924cf0)
    //     0x924ce4: tbz             w0, #0, #0x924cf0
    // 0x924ce8: r4 = LoadClassIdInstr(r0)
    //     0x924ce8: ldur            x4, [x0, #-1]
    //     0x924cec: ubfx            x4, x4, #0xc, #0x14
    // 0x924cf0: cmp             x4, #0x3f
    // 0x924cf4: b.eq            #0x924d08
    // 0x924cf8: r8 = bool?
    //     0x924cf8: ldr             x8, [PP, #0x5fd0]  ; [pp+0x5fd0] Type: bool?
    // 0x924cfc: r3 = Null
    //     0x924cfc: add             x3, PP, #8, lsl #12  ; [pp+0x8bd0] Null
    //     0x924d00: ldr             x3, [x3, #0xbd0]
    // 0x924d04: r0 = bool?()
    //     0x924d04: bl              #0x7ecd2c  ; IsType_bool?_Stub
    // 0x924d08: ldur            x1, [fp, #-8]
    // 0x924d0c: ldur            x2, [fp, #-0x10]
    // 0x924d10: r0 = asUnmodifiableView()
    //     0x924d10: bl              #0x13d9964  ; [dart:typed_data] _UnmodifiableByteDataView::asUnmodifiableView
    // 0x924d14: LeaveFrame
    //     0x924d14: mov             SP, fp
    //     0x924d18: ldp             fp, lr, [SP], #0x10
    // 0x924d1c: ret
    //     0x924d1c: ret             
    // 0x924d20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x924d20: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x924d24: b               #0x924c98
  }
  get _ instance(/* No info */) {
    // ** addr: 0x924dcc, size: 0x5c
    // 0x924dcc: EnterFrame
    //     0x924dcc: stp             fp, lr, [SP, #-0x10]!
    //     0x924dd0: mov             fp, SP
    // 0x924dd4: CheckStackOverflow
    //     0x924dd4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x924dd8: cmp             SP, x16
    //     0x924ddc: b.ls            #0x924e20
    // 0x924de0: r0 = LoadStaticField(0x10e4)
    //     0x924de0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x924de4: ldr             x0, [x0, #0x21c8]
    // 0x924de8: cmp             w0, NULL
    // 0x924dec: b.ne            #0x924df4
    // 0x924df0: r0 = setMethodCallHandlers()
    //     0x924df0: bl              #0x924eb4  ; [package:firebase_messaging_platform_interface/src/method_channel/method_channel_messaging.dart] MethodChannelFirebaseMessaging::setMethodCallHandlers
    // 0x924df4: r0 = LoadStaticField(0x10e4)
    //     0x924df4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x924df8: ldr             x0, [x0, #0x21c8]
    // 0x924dfc: cmp             w0, NULL
    // 0x924e00: b.ne            #0x924e14
    // 0x924e04: r0 = instance()
    //     0x924e04: bl              #0x924e28  ; [package:firebase_messaging_platform_interface/src/method_channel/method_channel_messaging.dart] MethodChannelFirebaseMessaging::instance
    // 0x924e08: mov             x2, x0
    // 0x924e0c: StoreStaticField(0x10e4, r2)
    //     0x924e0c: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x924e10: str             x2, [x1, #0x21c8]
    // 0x924e14: LeaveFrame
    //     0x924e14: mov             SP, fp
    //     0x924e18: ldp             fp, lr, [SP], #0x10
    // 0x924e1c: ret
    //     0x924e1c: ret             
    // 0x924e20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x924e20: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x924e24: b               #0x924de0
  }
  static StreamController<RemoteMessage> onMessage() {
    // ** addr: 0x925358, size: 0x38
    // 0x925358: EnterFrame
    //     0x925358: stp             fp, lr, [SP, #-0x10]!
    //     0x92535c: mov             fp, SP
    // 0x925360: CheckStackOverflow
    //     0x925360: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x925364: cmp             SP, x16
    //     0x925368: b.ls            #0x925388
    // 0x92536c: r1 = <RemoteMessage>
    //     0x92536c: add             x1, PP, #8, lsl #12  ; [pp+0x8ab8] TypeArguments: <RemoteMessage>
    //     0x925370: ldr             x1, [x1, #0xab8]
    // 0x925374: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x925374: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x925378: r0 = StreamController.broadcast()
    //     0x925378: bl              #0x8c36b8  ; [dart:async] StreamController::StreamController.broadcast
    // 0x92537c: LeaveFrame
    //     0x92537c: mov             SP, fp
    //     0x925380: ldp             fp, lr, [SP], #0x10
    // 0x925384: ret
    //     0x925384: ret             
    // 0x925388: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x925388: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x92538c: b               #0x92536c
  }
  set _ onBackgroundMessage=(/* No info */) {
    // ** addr: 0x13e7508, size: 0x50
    // 0x13e7508: EnterFrame
    //     0x13e7508: stp             fp, lr, [SP, #-0x10]!
    //     0x13e750c: mov             fp, SP
    // 0x13e7510: CheckStackOverflow
    //     0x13e7510: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13e7514: cmp             SP, x16
    //     0x13e7518: b.ls            #0x13e7550
    // 0x13e751c: r2 = Closure: (RemoteMessage) => Future<void> from Function 'handleBackgroundMessage': static.
    //     0x13e751c: add             x2, PP, #8, lsl #12  ; [pp+0x8ac0] Closure: (RemoteMessage) => Future<void> from Function 'handleBackgroundMessage': static. (0x7f2ada80c1fc)
    //     0x13e7520: ldr             x2, [x2, #0xac0]
    // 0x13e7524: StoreStaticField(0x10f0, r2)
    //     0x13e7524: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x13e7528: str             x2, [x0, #0x21e0]
    // 0x13e752c: r0 = instance()
    //     0x13e752c: bl              #0x924dcc  ; [package:firebase_messaging_platform_interface/src/platform_interface/platform_interface_messaging.dart] FirebaseMessagingPlatform::instance
    // 0x13e7530: mov             x1, x0
    // 0x13e7534: r2 = Closure: (RemoteMessage) => Future<void> from Function 'handleBackgroundMessage': static.
    //     0x13e7534: add             x2, PP, #8, lsl #12  ; [pp+0x8ac0] Closure: (RemoteMessage) => Future<void> from Function 'handleBackgroundMessage': static. (0x7f2ada80c1fc)
    //     0x13e7538: ldr             x2, [x2, #0xac0]
    // 0x13e753c: r0 = registerBackgroundMessageHandler()
    //     0x13e753c: bl              #0x13e7558  ; [package:firebase_messaging_platform_interface/src/method_channel/method_channel_messaging.dart] MethodChannelFirebaseMessaging::registerBackgroundMessageHandler
    // 0x13e7540: r0 = Null
    //     0x13e7540: mov             x0, NULL
    // 0x13e7544: LeaveFrame
    //     0x13e7544: mov             SP, fp
    //     0x13e7548: ldp             fp, lr, [SP], #0x10
    // 0x13e754c: ret
    //     0x13e754c: ret             
    // 0x13e7550: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13e7550: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13e7554: b               #0x13e751c
  }
}
