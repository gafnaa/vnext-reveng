// lib: , url: package:firebase_messaging_platform_interface/src/types.dart

// class id: 1048759, size: 0x8
class :: {
}

// class id: 8325, size: 0x14, field offset: 0x14
enum AndroidNotificationVisibility extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11a9478, size: 0x64
    // 0x11a9478: EnterFrame
    //     0x11a9478: stp             fp, lr, [SP, #-0x10]!
    //     0x11a947c: mov             fp, SP
    // 0x11a9480: AllocStack(0x10)
    //     0x11a9480: sub             SP, SP, #0x10
    // 0x11a9484: SetupParameters(AndroidNotificationVisibility this /* r1 => r0, fp-0x8 */)
    //     0x11a9484: mov             x0, x1
    //     0x11a9488: stur            x1, [fp, #-8]
    // 0x11a948c: CheckStackOverflow
    //     0x11a948c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a9490: cmp             SP, x16
    //     0x11a9494: b.ls            #0x11a94d4
    // 0x11a9498: r1 = Null
    //     0x11a9498: mov             x1, NULL
    // 0x11a949c: r2 = 4
    //     0x11a949c: mov             x2, #4
    // 0x11a94a0: r0 = AllocateArray()
    //     0x11a94a0: bl              #0x13df928  ; AllocateArrayStub
    // 0x11a94a4: r16 = "AndroidNotificationVisibility."
    //     0x11a94a4: add             x16, PP, #0x10, lsl #12  ; [pp+0x10c20] "AndroidNotificationVisibility."
    //     0x11a94a8: ldr             x16, [x16, #0xc20]
    // 0x11a94ac: StoreField: r0->field_f = r16
    //     0x11a94ac: stur            w16, [x0, #0xf]
    // 0x11a94b0: ldur            x1, [fp, #-8]
    // 0x11a94b4: LoadField: r2 = r1->field_f
    //     0x11a94b4: ldur            w2, [x1, #0xf]
    // 0x11a94b8: DecompressPointer r2
    //     0x11a94b8: add             x2, x2, HEAP, lsl #32
    // 0x11a94bc: StoreField: r0->field_13 = r2
    //     0x11a94bc: stur            w2, [x0, #0x13]
    // 0x11a94c0: str             x0, [SP]
    // 0x11a94c4: r0 = _interpolate()
    //     0x11a94c4: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11a94c8: LeaveFrame
    //     0x11a94c8: mov             SP, fp
    //     0x11a94cc: ldp             fp, lr, [SP], #0x10
    // 0x11a94d0: ret
    //     0x11a94d0: ret             
    // 0x11a94d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a94d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a94d8: b               #0x11a9498
  }
}

// class id: 8326, size: 0x14, field offset: 0x14
enum AndroidNotificationPriority extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11a9414, size: 0x64
    // 0x11a9414: EnterFrame
    //     0x11a9414: stp             fp, lr, [SP, #-0x10]!
    //     0x11a9418: mov             fp, SP
    // 0x11a941c: AllocStack(0x10)
    //     0x11a941c: sub             SP, SP, #0x10
    // 0x11a9420: SetupParameters(AndroidNotificationPriority this /* r1 => r0, fp-0x8 */)
    //     0x11a9420: mov             x0, x1
    //     0x11a9424: stur            x1, [fp, #-8]
    // 0x11a9428: CheckStackOverflow
    //     0x11a9428: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a942c: cmp             SP, x16
    //     0x11a9430: b.ls            #0x11a9470
    // 0x11a9434: r1 = Null
    //     0x11a9434: mov             x1, NULL
    // 0x11a9438: r2 = 4
    //     0x11a9438: mov             x2, #4
    // 0x11a943c: r0 = AllocateArray()
    //     0x11a943c: bl              #0x13df928  ; AllocateArrayStub
    // 0x11a9440: r16 = "AndroidNotificationPriority."
    //     0x11a9440: add             x16, PP, #0x10, lsl #12  ; [pp+0x10c28] "AndroidNotificationPriority."
    //     0x11a9444: ldr             x16, [x16, #0xc28]
    // 0x11a9448: StoreField: r0->field_f = r16
    //     0x11a9448: stur            w16, [x0, #0xf]
    // 0x11a944c: ldur            x1, [fp, #-8]
    // 0x11a9450: LoadField: r2 = r1->field_f
    //     0x11a9450: ldur            w2, [x1, #0xf]
    // 0x11a9454: DecompressPointer r2
    //     0x11a9454: add             x2, x2, HEAP, lsl #32
    // 0x11a9458: StoreField: r0->field_13 = r2
    //     0x11a9458: stur            w2, [x0, #0x13]
    // 0x11a945c: str             x0, [SP]
    // 0x11a9460: r0 = _interpolate()
    //     0x11a9460: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11a9464: LeaveFrame
    //     0x11a9464: mov             SP, fp
    //     0x11a9468: ldp             fp, lr, [SP], #0x10
    // 0x11a946c: ret
    //     0x11a946c: ret             
    // 0x11a9470: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a9470: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a9474: b               #0x11a9434
  }
}
