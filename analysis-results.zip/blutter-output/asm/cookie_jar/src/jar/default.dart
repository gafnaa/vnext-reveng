// lib: , url: package:cookie_jar/src/jar/default.dart

// class id: 1048667, size: 0x8
class :: {
}

// class id: 3560, size: 0x10, field offset: 0x8
class DefaultCookieJar extends Object
    implements CookieJar {

  _ loadForRequest(/* No info */) async {
    // ** addr: 0xd57c84, size: 0x664
    // 0xd57c84: EnterFrame
    //     0xd57c84: stp             fp, lr, [SP, #-0x10]!
    //     0xd57c88: mov             fp, SP
    // 0xd57c8c: AllocStack(0x98)
    //     0xd57c8c: sub             SP, SP, #0x98
    // 0xd57c90: SetupParameters(DefaultCookieJar this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0xd57c90: stur            NULL, [fp, #-8]
    //     0xd57c94: stur            x1, [fp, #-0x10]
    //     0xd57c98: stur            x2, [fp, #-0x18]
    // 0xd57c9c: CheckStackOverflow
    //     0xd57c9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd57ca0: cmp             SP, x16
    //     0xd57ca4: b.ls            #0xd582c0
    // 0xd57ca8: r1 = 4
    //     0xd57ca8: mov             x1, #4
    // 0xd57cac: r0 = AllocateContext()
    //     0xd57cac: bl              #0x13de838  ; AllocateContextStub
    // 0xd57cb0: mov             x2, x0
    // 0xd57cb4: ldur            x1, [fp, #-0x10]
    // 0xd57cb8: stur            x2, [fp, #-0x20]
    // 0xd57cbc: StoreField: r2->field_f = r1
    //     0xd57cbc: stur            w1, [x2, #0xf]
    // 0xd57cc0: ldur            x0, [fp, #-0x18]
    // 0xd57cc4: StoreField: r2->field_13 = r0
    //     0xd57cc4: stur            w0, [x2, #0x13]
    // 0xd57cc8: InitAsync() -> Future<List<Cookie>>
    //     0xd57cc8: add             x0, PP, #0x82, lsl #12  ; [pp+0x82260] TypeArguments: <List<Cookie>>
    //     0xd57ccc: ldr             x0, [x0, #0x260]
    //     0xd57cd0: bl              #0x7f5e44  ; InitAsyncStub
    // 0xd57cd4: r1 = <Cookie>
    //     0xd57cd4: add             x1, PP, #0xb, lsl #12  ; [pp+0xbe80] TypeArguments: <Cookie>
    //     0xd57cd8: ldr             x1, [x1, #0xe80]
    // 0xd57cdc: r2 = 0
    //     0xd57cdc: mov             x2, #0
    // 0xd57ce0: r0 = _GrowableList()
    //     0xd57ce0: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xd57ce4: mov             x3, x0
    // 0xd57ce8: ldur            x2, [fp, #-0x20]
    // 0xd57cec: stur            x3, [fp, #-0x18]
    // 0xd57cf0: ArrayStore: r2[0] = r0  ; List_4
    //     0xd57cf0: stur            w0, [x2, #0x17]
    //     0xd57cf4: ldurb           w16, [x2, #-1]
    //     0xd57cf8: ldurb           w17, [x0, #-1]
    //     0xd57cfc: and             x16, x17, x16, lsr #2
    //     0xd57d00: tst             x16, HEAP, lsr #32
    //     0xd57d04: b.eq            #0xd57d0c
    //     0xd57d08: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd57d0c: LoadField: r1 = r2->field_13
    //     0xd57d0c: ldur            w1, [x2, #0x13]
    // 0xd57d10: DecompressPointer r1
    //     0xd57d10: add             x1, x1, HEAP, lsl #32
    // 0xd57d14: r0 = LoadClassIdInstr(r1)
    //     0xd57d14: ldur            x0, [x1, #-1]
    //     0xd57d18: ubfx            x0, x0, #0xc, #0x14
    // 0xd57d1c: r0 = GDT[cid_x0 + -0xfe0]()
    //     0xd57d1c: sub             lr, x0, #0xfe0
    //     0xd57d20: ldr             lr, [x21, lr, lsl #3]
    //     0xd57d24: blr             lr
    // 0xd57d28: mov             x3, x0
    // 0xd57d2c: ldur            x2, [fp, #-0x20]
    // 0xd57d30: stur            x3, [fp, #-0x28]
    // 0xd57d34: StoreField: r2->field_1b = r0
    //     0xd57d34: stur            w0, [x2, #0x1b]
    //     0xd57d38: ldurb           w16, [x2, #-1]
    //     0xd57d3c: ldurb           w17, [x0, #-1]
    //     0xd57d40: and             x16, x17, x16, lsr #2
    //     0xd57d44: tst             x16, HEAP, lsr #32
    //     0xd57d48: b.eq            #0xd57d50
    //     0xd57d4c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd57d50: LoadField: r1 = r2->field_13
    //     0xd57d50: ldur            w1, [x2, #0x13]
    // 0xd57d54: DecompressPointer r1
    //     0xd57d54: add             x1, x1, HEAP, lsl #32
    // 0xd57d58: r0 = LoadClassIdInstr(r1)
    //     0xd57d58: ldur            x0, [x1, #-1]
    //     0xd57d5c: ubfx            x0, x0, #0xc, #0x14
    // 0xd57d60: r0 = GDT[cid_x0 + -0xf07]()
    //     0xd57d60: sub             lr, x0, #0xf07
    //     0xd57d64: ldr             lr, [x21, lr, lsl #3]
    //     0xd57d68: blr             lr
    // 0xd57d6c: ldur            x1, [fp, #-0x10]
    // 0xd57d70: stur            x0, [fp, #-0x30]
    // 0xd57d74: r0 = hostCookies()
    //     0xd57d74: bl              #0xd58628  ; [package:cookie_jar/src/jar/default.dart] DefaultCookieJar::hostCookies
    // 0xd57d78: r1 = LoadClassIdInstr(r0)
    //     0xd57d78: ldur            x1, [x0, #-1]
    //     0xd57d7c: ubfx            x1, x1, #0xc, #0x14
    // 0xd57d80: mov             x16, x0
    // 0xd57d84: mov             x0, x1
    // 0xd57d88: mov             x1, x16
    // 0xd57d8c: r0 = GDT[cid_x0 + 0x44d]()
    //     0xd57d8c: add             lr, x0, #0x44d
    //     0xd57d90: ldr             lr, [x21, lr, lsl #3]
    //     0xd57d94: blr             lr
    // 0xd57d98: r1 = LoadClassIdInstr(r0)
    //     0xd57d98: ldur            x1, [x0, #-1]
    //     0xd57d9c: ubfx            x1, x1, #0xc, #0x14
    // 0xd57da0: mov             x16, x0
    // 0xd57da4: mov             x0, x1
    // 0xd57da8: mov             x1, x16
    // 0xd57dac: r0 = GDT[cid_x0 + 0x12641]()
    //     0xd57dac: mov             x17, #0x2641
    //     0xd57db0: movk            x17, #1, lsl #16
    //     0xd57db4: add             lr, x0, x17
    //     0xd57db8: ldr             lr, [x21, lr, lsl #3]
    //     0xd57dbc: blr             lr
    // 0xd57dc0: mov             x2, x0
    // 0xd57dc4: stur            x2, [fp, #-0x38]
    // 0xd57dc8: ldur            x5, [fp, #-0x18]
    // 0xd57dcc: ldur            x4, [fp, #-0x20]
    // 0xd57dd0: ldur            x3, [fp, #-0x30]
    // 0xd57dd4: CheckStackOverflow
    //     0xd57dd4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd57dd8: cmp             SP, x16
    //     0xd57ddc: b.ls            #0xd582c8
    // 0xd57de0: r0 = LoadClassIdInstr(r2)
    //     0xd57de0: ldur            x0, [x2, #-1]
    //     0xd57de4: ubfx            x0, x0, #0xc, #0x14
    // 0xd57de8: mov             x1, x2
    // 0xd57dec: r0 = GDT[cid_x0 + 0x1845b]()
    //     0xd57dec: mov             x17, #0x845b
    //     0xd57df0: movk            x17, #1, lsl #16
    //     0xd57df4: add             lr, x0, x17
    //     0xd57df8: ldr             lr, [x21, lr, lsl #3]
    //     0xd57dfc: blr             lr
    // 0xd57e00: tbnz            w0, #4, #0xd58254
    // 0xd57e04: ldur            x3, [fp, #-0x30]
    // 0xd57e08: ldur            x2, [fp, #-0x38]
    // 0xd57e0c: r0 = LoadClassIdInstr(r2)
    //     0xd57e0c: ldur            x0, [x2, #-1]
    //     0xd57e10: ubfx            x0, x0, #0xc, #0x14
    // 0xd57e14: mov             x1, x2
    // 0xd57e18: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0xd57e18: mov             x17, #0x7d4c
    //     0xd57e1c: movk            x17, #1, lsl #16
    //     0xd57e20: add             lr, x0, x17
    //     0xd57e24: ldr             lr, [x21, lr, lsl #3]
    //     0xd57e28: blr             lr
    // 0xd57e2c: mov             x2, x0
    // 0xd57e30: ldur            x1, [fp, #-0x30]
    // 0xd57e34: stur            x2, [fp, #-0x40]
    // 0xd57e38: r0 = LoadClassIdInstr(r1)
    //     0xd57e38: ldur            x0, [x1, #-1]
    //     0xd57e3c: ubfx            x0, x0, #0xc, #0x14
    // 0xd57e40: stp             x2, x1, [SP]
    // 0xd57e44: mov             lr, x0
    // 0xd57e48: ldr             lr, [x21, lr, lsl #3]
    // 0xd57e4c: blr             lr
    // 0xd57e50: tbnz            w0, #4, #0xd58244
    // 0xd57e54: ldur            x1, [fp, #-0x10]
    // 0xd57e58: r0 = hostCookies()
    //     0xd57e58: bl              #0xd58628  ; [package:cookie_jar/src/jar/default.dart] DefaultCookieJar::hostCookies
    // 0xd57e5c: r1 = LoadClassIdInstr(r0)
    //     0xd57e5c: ldur            x1, [x0, #-1]
    //     0xd57e60: ubfx            x1, x1, #0xc, #0x14
    // 0xd57e64: mov             x16, x0
    // 0xd57e68: mov             x0, x1
    // 0xd57e6c: mov             x1, x16
    // 0xd57e70: ldur            x2, [fp, #-0x40]
    // 0xd57e74: r0 = GDT[cid_x0 + -0xd48]()
    //     0xd57e74: sub             lr, x0, #0xd48
    //     0xd57e78: ldr             lr, [x21, lr, lsl #3]
    //     0xd57e7c: blr             lr
    // 0xd57e80: cmp             w0, NULL
    // 0xd57e84: b.eq            #0xd582d0
    // 0xd57e88: r1 = LoadClassIdInstr(r0)
    //     0xd57e88: ldur            x1, [x0, #-1]
    //     0xd57e8c: ubfx            x1, x1, #0xc, #0x14
    // 0xd57e90: r16 = <String, Map<String, dynamic>>
    //     0xd57e90: add             x16, PP, #0x82, lsl #12  ; [pp+0x82118] TypeArguments: <String, Map<String, dynamic>>
    //     0xd57e94: ldr             x16, [x16, #0x118]
    // 0xd57e98: stp             x0, x16, [SP]
    // 0xd57e9c: mov             x0, x1
    // 0xd57ea0: r4 = const [0x2, 0x1, 0x1, 0x1, null]
    //     0xd57ea0: ldr             x4, [PP, #0x18e0]  ; [pp+0x18e0] List(5) [0x2, 0x1, 0x1, 0x1, Null]
    // 0xd57ea4: r0 = GDT[cid_x0 + 0xfb3]()
    //     0xd57ea4: add             lr, x0, #0xfb3
    //     0xd57ea8: ldr             lr, [x21, lr, lsl #3]
    //     0xd57eac: blr             lr
    // 0xd57eb0: mov             x2, x0
    // 0xd57eb4: stur            x2, [fp, #-0x40]
    // 0xd57eb8: r0 = LoadClassIdInstr(r2)
    //     0xd57eb8: ldur            x0, [x2, #-1]
    //     0xd57ebc: ubfx            x0, x0, #0xc, #0x14
    // 0xd57ec0: mov             x1, x2
    // 0xd57ec4: r0 = GDT[cid_x0 + 0x44d]()
    //     0xd57ec4: add             lr, x0, #0x44d
    //     0xd57ec8: ldr             lr, [x21, lr, lsl #3]
    //     0xd57ecc: blr             lr
    // 0xd57ed0: r1 = LoadClassIdInstr(r0)
    //     0xd57ed0: ldur            x1, [x0, #-1]
    //     0xd57ed4: ubfx            x1, x1, #0xc, #0x14
    // 0xd57ed8: mov             x16, x0
    // 0xd57edc: mov             x0, x1
    // 0xd57ee0: mov             x1, x16
    // 0xd57ee4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd57ee4: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd57ee8: r0 = GDT[cid_x0 + 0x126dc]()
    //     0xd57ee8: mov             x17, #0x26dc
    //     0xd57eec: movk            x17, #1, lsl #16
    //     0xd57ef0: add             lr, x0, x17
    //     0xd57ef4: ldr             lr, [x21, lr, lsl #3]
    //     0xd57ef8: blr             lr
    // 0xd57efc: r1 = Function '<anonymous closure>':.
    //     0xd57efc: add             x1, PP, #0x82, lsl #12  ; [pp+0x82268] AnonymousClosure: (0xd589a0), in [package:cookie_jar/src/jar/default.dart] DefaultCookieJar::loadForRequest (0xd57c84)
    //     0xd57f00: ldr             x1, [x1, #0x268]
    // 0xd57f04: r2 = Null
    //     0xd57f04: mov             x2, NULL
    // 0xd57f08: stur            x0, [fp, #-0x48]
    // 0xd57f0c: r0 = AllocateClosure()
    //     0xd57f0c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd57f10: str             x0, [SP]
    // 0xd57f14: ldur            x1, [fp, #-0x48]
    // 0xd57f18: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0xd57f18: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0xd57f1c: r0 = sort()
    //     0xd57f1c: bl              #0x9f9bf0  ; [dart:collection] ListBase::sort
    // 0xd57f20: ldur            x3, [fp, #-0x48]
    // 0xd57f24: LoadField: r4 = r3->field_7
    //     0xd57f24: ldur            w4, [x3, #7]
    // 0xd57f28: DecompressPointer r4
    //     0xd57f28: add             x4, x4, HEAP, lsl #32
    // 0xd57f2c: stur            x4, [fp, #-0x68]
    // 0xd57f30: LoadField: r0 = r3->field_b
    //     0xd57f30: ldur            w0, [x3, #0xb]
    // 0xd57f34: r5 = LoadInt32Instr(r0)
    //     0xd57f34: sbfx            x5, x0, #1, #0x1f
    // 0xd57f38: stur            x5, [fp, #-0x60]
    // 0xd57f3c: ldur            x8, [fp, #-0x18]
    // 0xd57f40: r0 = 0
    //     0xd57f40: mov             x0, #0
    // 0xd57f44: ldur            x7, [fp, #-0x20]
    // 0xd57f48: ldur            x6, [fp, #-0x40]
    // 0xd57f4c: CheckStackOverflow
    //     0xd57f4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd57f50: cmp             SP, x16
    //     0xd57f54: b.ls            #0xd582d4
    // 0xd57f58: LoadField: r1 = r3->field_b
    //     0xd57f58: ldur            w1, [x3, #0xb]
    // 0xd57f5c: r2 = LoadInt32Instr(r1)
    //     0xd57f5c: sbfx            x2, x1, #1, #0x1f
    // 0xd57f60: cmp             x5, x2
    // 0xd57f64: b.ne            #0xd582a0
    // 0xd57f68: cmp             x0, x2
    // 0xd57f6c: b.ge            #0xd5823c
    // 0xd57f70: LoadField: r1 = r3->field_f
    //     0xd57f70: ldur            w1, [x3, #0xf]
    // 0xd57f74: DecompressPointer r1
    //     0xd57f74: add             x1, x1, HEAP, lsl #32
    // 0xd57f78: ArrayLoad: r9 = r1[r0]  ; Unknown_4
    //     0xd57f78: add             x16, x1, x0, lsl #2
    //     0xd57f7c: ldur            w9, [x16, #0xf]
    // 0xd57f80: DecompressPointer r9
    //     0xd57f80: add             x9, x9, HEAP, lsl #32
    // 0xd57f84: stur            x9, [fp, #-0x58]
    // 0xd57f88: add             x10, x0, #1
    // 0xd57f8c: stur            x10, [fp, #-0x50]
    // 0xd57f90: cmp             w9, NULL
    // 0xd57f94: b.ne            #0xd57fc8
    // 0xd57f98: mov             x0, x9
    // 0xd57f9c: mov             x2, x4
    // 0xd57fa0: r1 = Null
    //     0xd57fa0: mov             x1, NULL
    // 0xd57fa4: cmp             w2, NULL
    // 0xd57fa8: b.eq            #0xd57fc8
    // 0xd57fac: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xd57fac: ldur            w4, [x2, #0x17]
    // 0xd57fb0: DecompressPointer r4
    //     0xd57fb0: add             x4, x4, HEAP, lsl #32
    // 0xd57fb4: r8 = X0
    //     0xd57fb4: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xd57fb8: LoadField: r9 = r4->field_7
    //     0xd57fb8: ldur            x9, [x4, #7]
    // 0xd57fbc: r3 = Null
    //     0xd57fbc: add             x3, PP, #0x82, lsl #12  ; [pp+0x82270] Null
    //     0xd57fc0: ldr             x3, [x3, #0x270]
    // 0xd57fc4: blr             x9
    // 0xd57fc8: ldur            x1, [fp, #-0x10]
    // 0xd57fcc: ldur            x2, [fp, #-0x28]
    // 0xd57fd0: ldur            x3, [fp, #-0x58]
    // 0xd57fd4: r0 = _isPathMatch()
    //     0xd57fd4: bl              #0xd584f4  ; [package:cookie_jar/src/jar/default.dart] DefaultCookieJar::_isPathMatch
    // 0xd57fd8: tbnz            w0, #4, #0xd58220
    // 0xd57fdc: ldur            x3, [fp, #-0x40]
    // 0xd57fe0: r0 = LoadClassIdInstr(r3)
    //     0xd57fe0: ldur            x0, [x3, #-1]
    //     0xd57fe4: ubfx            x0, x0, #0xc, #0x14
    // 0xd57fe8: mov             x1, x3
    // 0xd57fec: ldur            x2, [fp, #-0x58]
    // 0xd57ff0: r0 = GDT[cid_x0 + -0xd48]()
    //     0xd57ff0: sub             lr, x0, #0xd48
    //     0xd57ff4: ldr             lr, [x21, lr, lsl #3]
    //     0xd57ff8: blr             lr
    // 0xd57ffc: mov             x2, x0
    // 0xd58000: stur            x2, [fp, #-0x58]
    // 0xd58004: cmp             w2, NULL
    // 0xd58008: b.eq            #0xd582dc
    // 0xd5800c: r0 = LoadClassIdInstr(r2)
    //     0xd5800c: ldur            x0, [x2, #-1]
    //     0xd58010: ubfx            x0, x0, #0xc, #0x14
    // 0xd58014: mov             x1, x2
    // 0xd58018: r0 = GDT[cid_x0 + 0x44d]()
    //     0xd58018: add             lr, x0, #0x44d
    //     0xd5801c: ldr             lr, [x21, lr, lsl #3]
    //     0xd58020: blr             lr
    // 0xd58024: r1 = LoadClassIdInstr(r0)
    //     0xd58024: ldur            x1, [x0, #-1]
    //     0xd58028: ubfx            x1, x1, #0xc, #0x14
    // 0xd5802c: mov             x16, x0
    // 0xd58030: mov             x0, x1
    // 0xd58034: mov             x1, x16
    // 0xd58038: r0 = GDT[cid_x0 + 0x12641]()
    //     0xd58038: mov             x17, #0x2641
    //     0xd5803c: movk            x17, #1, lsl #16
    //     0xd58040: add             lr, x0, x17
    //     0xd58044: ldr             lr, [x21, lr, lsl #3]
    //     0xd58048: blr             lr
    // 0xd5804c: mov             x2, x0
    // 0xd58050: stur            x2, [fp, #-0x70]
    // 0xd58054: ldur            x5, [fp, #-0x18]
    // 0xd58058: ldur            x4, [fp, #-0x20]
    // 0xd5805c: ldur            x3, [fp, #-0x58]
    // 0xd58060: CheckStackOverflow
    //     0xd58060: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd58064: cmp             SP, x16
    //     0xd58068: b.ls            #0xd582e0
    // 0xd5806c: r0 = LoadClassIdInstr(r2)
    //     0xd5806c: ldur            x0, [x2, #-1]
    //     0xd58070: ubfx            x0, x0, #0xc, #0x14
    // 0xd58074: mov             x1, x2
    // 0xd58078: r0 = GDT[cid_x0 + 0x1845b]()
    //     0xd58078: mov             x17, #0x845b
    //     0xd5807c: movk            x17, #1, lsl #16
    //     0xd58080: add             lr, x0, x17
    //     0xd58084: ldr             lr, [x21, lr, lsl #3]
    //     0xd58088: blr             lr
    // 0xd5808c: tbnz            w0, #4, #0xd58218
    // 0xd58090: ldur            x4, [fp, #-0x20]
    // 0xd58094: ldur            x3, [fp, #-0x58]
    // 0xd58098: ldur            x2, [fp, #-0x70]
    // 0xd5809c: r0 = LoadClassIdInstr(r2)
    //     0xd5809c: ldur            x0, [x2, #-1]
    //     0xd580a0: ubfx            x0, x0, #0xc, #0x14
    // 0xd580a4: mov             x1, x2
    // 0xd580a8: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0xd580a8: mov             x17, #0x7d4c
    //     0xd580ac: movk            x17, #1, lsl #16
    //     0xd580b0: add             lr, x0, x17
    //     0xd580b4: ldr             lr, [x21, lr, lsl #3]
    //     0xd580b8: blr             lr
    // 0xd580bc: ldur            x3, [fp, #-0x58]
    // 0xd580c0: r1 = LoadClassIdInstr(r3)
    //     0xd580c0: ldur            x1, [x3, #-1]
    //     0xd580c4: ubfx            x1, x1, #0xc, #0x14
    // 0xd580c8: mov             x2, x0
    // 0xd580cc: mov             x0, x1
    // 0xd580d0: mov             x1, x3
    // 0xd580d4: r0 = GDT[cid_x0 + -0xd48]()
    //     0xd580d4: sub             lr, x0, #0xd48
    //     0xd580d8: ldr             lr, [x21, lr, lsl #3]
    //     0xd580dc: blr             lr
    // 0xd580e0: mov             x3, x0
    // 0xd580e4: r2 = Null
    //     0xd580e4: mov             x2, NULL
    // 0xd580e8: r1 = Null
    //     0xd580e8: mov             x1, NULL
    // 0xd580ec: stur            x3, [fp, #-0x78]
    // 0xd580f0: r4 = 60
    //     0xd580f0: mov             x4, #0x3c
    // 0xd580f4: branchIfSmi(r0, 0xd58100)
    //     0xd580f4: tbz             w0, #0, #0xd58100
    // 0xd580f8: r4 = LoadClassIdInstr(r0)
    //     0xd580f8: ldur            x4, [x0, #-1]
    //     0xd580fc: ubfx            x4, x4, #0xc, #0x14
    // 0xd58100: cmp             x4, #0xde7
    // 0xd58104: b.eq            #0xd5811c
    // 0xd58108: r8 = SerializableCookie
    //     0xd58108: add             x8, PP, #0x82, lsl #12  ; [pp+0x82120] Type: SerializableCookie
    //     0xd5810c: ldr             x8, [x8, #0x120]
    // 0xd58110: r3 = Null
    //     0xd58110: add             x3, PP, #0x82, lsl #12  ; [pp+0x82280] Null
    //     0xd58114: ldr             x3, [x3, #0x280]
    // 0xd58118: r0 = DefaultTypeTest()
    //     0xd58118: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xd5811c: ldur            x2, [fp, #-0x20]
    // 0xd58120: LoadField: r1 = r2->field_13
    //     0xd58120: ldur            w1, [x2, #0x13]
    // 0xd58124: DecompressPointer r1
    //     0xd58124: add             x1, x1, HEAP, lsl #32
    // 0xd58128: r0 = LoadClassIdInstr(r1)
    //     0xd58128: ldur            x0, [x1, #-1]
    //     0xd5812c: ubfx            x0, x0, #0xc, #0x14
    // 0xd58130: r0 = GDT[cid_x0 + -0xf55]()
    //     0xd58130: sub             lr, x0, #0xf55
    //     0xd58134: ldr             lr, [x21, lr, lsl #3]
    //     0xd58138: blr             lr
    // 0xd5813c: ldur            x1, [fp, #-0x78]
    // 0xd58140: LoadField: r2 = r1->field_7
    //     0xd58140: ldur            w2, [x1, #7]
    // 0xd58144: DecompressPointer r2
    //     0xd58144: add             x2, x2, HEAP, lsl #32
    // 0xd58148: stur            x2, [fp, #-0x80]
    // 0xd5814c: LoadField: r3 = r2->field_23
    //     0xd5814c: ldur            w3, [x2, #0x23]
    // 0xd58150: DecompressPointer r3
    //     0xd58150: add             x3, x3, HEAP, lsl #32
    // 0xd58154: tbnz            w3, #4, #0xd5817c
    // 0xd58158: r3 = LoadClassIdInstr(r0)
    //     0xd58158: ldur            x3, [x0, #-1]
    //     0xd5815c: ubfx            x3, x3, #0xc, #0x14
    // 0xd58160: r16 = "https"
    //     0xd58160: ldr             x16, [PP, #0x1078]  ; [pp+0x1078] "https"
    // 0xd58164: stp             x16, x0, [SP]
    // 0xd58168: mov             x0, x3
    // 0xd5816c: mov             lr, x0
    // 0xd58170: ldr             lr, [x21, lr, lsl #3]
    // 0xd58174: blr             lr
    // 0xd58178: tbz             w0, #4, #0xd5818c
    // 0xd5817c: ldur            x1, [fp, #-0x78]
    // 0xd58180: r0 = isExpired()
    //     0xd58180: bl              #0xd583a8  ; [package:cookie_jar/src/serializable_cookie.dart] SerializableCookie::isExpired
    // 0xd58184: eor             x1, x0, #0x10
    // 0xd58188: tbnz            w1, #4, #0xd58208
    // 0xd5818c: ldur            x0, [fp, #-0x18]
    // 0xd58190: LoadField: r1 = r0->field_b
    //     0xd58190: ldur            w1, [x0, #0xb]
    // 0xd58194: LoadField: r2 = r0->field_f
    //     0xd58194: ldur            w2, [x0, #0xf]
    // 0xd58198: DecompressPointer r2
    //     0xd58198: add             x2, x2, HEAP, lsl #32
    // 0xd5819c: LoadField: r3 = r2->field_b
    //     0xd5819c: ldur            w3, [x2, #0xb]
    // 0xd581a0: r2 = LoadInt32Instr(r1)
    //     0xd581a0: sbfx            x2, x1, #1, #0x1f
    // 0xd581a4: stur            x2, [fp, #-0x88]
    // 0xd581a8: r1 = LoadInt32Instr(r3)
    //     0xd581a8: sbfx            x1, x3, #1, #0x1f
    // 0xd581ac: cmp             x2, x1
    // 0xd581b0: b.ne            #0xd581bc
    // 0xd581b4: mov             x1, x0
    // 0xd581b8: r0 = _growToNextCapacity()
    //     0xd581b8: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xd581bc: ldur            x2, [fp, #-0x18]
    // 0xd581c0: ldur            x3, [fp, #-0x88]
    // 0xd581c4: add             x0, x3, #1
    // 0xd581c8: lsl             x1, x0, #1
    // 0xd581cc: StoreField: r2->field_b = r1
    //     0xd581cc: stur            w1, [x2, #0xb]
    // 0xd581d0: LoadField: r1 = r2->field_f
    //     0xd581d0: ldur            w1, [x2, #0xf]
    // 0xd581d4: DecompressPointer r1
    //     0xd581d4: add             x1, x1, HEAP, lsl #32
    // 0xd581d8: ldur            x0, [fp, #-0x80]
    // 0xd581dc: ArrayStore: r1[r3] = r0  ; List_4
    //     0xd581dc: add             x25, x1, x3, lsl #2
    //     0xd581e0: add             x25, x25, #0xf
    //     0xd581e4: str             w0, [x25]
    //     0xd581e8: tbz             w0, #0, #0xd58204
    //     0xd581ec: ldurb           w16, [x1, #-1]
    //     0xd581f0: ldurb           w17, [x0, #-1]
    //     0xd581f4: and             x16, x17, x16, lsr #2
    //     0xd581f8: tst             x16, HEAP, lsr #32
    //     0xd581fc: b.eq            #0xd58204
    //     0xd58200: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd58204: b               #0xd5820c
    // 0xd58208: ldur            x2, [fp, #-0x18]
    // 0xd5820c: mov             x5, x2
    // 0xd58210: ldur            x2, [fp, #-0x70]
    // 0xd58214: b               #0xd58058
    // 0xd58218: ldur            x2, [fp, #-0x18]
    // 0xd5821c: b               #0xd58224
    // 0xd58220: ldur            x2, [fp, #-0x18]
    // 0xd58224: ldur            x0, [fp, #-0x50]
    // 0xd58228: mov             x8, x2
    // 0xd5822c: ldur            x3, [fp, #-0x48]
    // 0xd58230: ldur            x4, [fp, #-0x68]
    // 0xd58234: ldur            x5, [fp, #-0x60]
    // 0xd58238: b               #0xd57f44
    // 0xd5823c: mov             x2, x8
    // 0xd58240: b               #0xd58248
    // 0xd58244: ldur            x2, [fp, #-0x18]
    // 0xd58248: mov             x5, x2
    // 0xd5824c: ldur            x2, [fp, #-0x38]
    // 0xd58250: b               #0xd57dcc
    // 0xd58254: ldur            x2, [fp, #-0x18]
    // 0xd58258: ldur            x1, [fp, #-0x10]
    // 0xd5825c: r0 = domainCookies()
    //     0xd5825c: bl              #0xd5836c  ; [package:cookie_jar/src/jar/default.dart] DefaultCookieJar::domainCookies
    // 0xd58260: ldur            x2, [fp, #-0x20]
    // 0xd58264: r1 = Function '<anonymous closure>':.
    //     0xd58264: add             x1, PP, #0x82, lsl #12  ; [pp+0x82290] AnonymousClosure: (0xd58664), in [package:cookie_jar/src/jar/default.dart] DefaultCookieJar::loadForRequest (0xd57c84)
    //     0xd58268: ldr             x1, [x1, #0x290]
    // 0xd5826c: stur            x0, [fp, #-0x10]
    // 0xd58270: r0 = AllocateClosure()
    //     0xd58270: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd58274: ldur            x1, [fp, #-0x10]
    // 0xd58278: r2 = LoadClassIdInstr(r1)
    //     0xd58278: ldur            x2, [x1, #-1]
    //     0xd5827c: ubfx            x2, x2, #0xc, #0x14
    // 0xd58280: mov             x16, x0
    // 0xd58284: mov             x0, x2
    // 0xd58288: mov             x2, x16
    // 0xd5828c: r0 = GDT[cid_x0 + 0x6c5]()
    //     0xd5828c: add             lr, x0, #0x6c5
    //     0xd58290: ldr             lr, [x21, lr, lsl #3]
    //     0xd58294: blr             lr
    // 0xd58298: ldur            x0, [fp, #-0x18]
    // 0xd5829c: r0 = ReturnAsyncNotFuture()
    //     0xd5829c: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xd582a0: mov             x0, x3
    // 0xd582a4: r0 = ConcurrentModificationError()
    //     0xd582a4: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xd582a8: mov             x1, x0
    // 0xd582ac: ldur            x0, [fp, #-0x48]
    // 0xd582b0: StoreField: r1->field_b = r0
    //     0xd582b0: stur            w0, [x1, #0xb]
    // 0xd582b4: mov             x0, x1
    // 0xd582b8: r0 = Throw()
    //     0xd582b8: bl              #0x13ddb2c  ; ThrowStub
    // 0xd582bc: brk             #0
    // 0xd582c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd582c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd582c4: b               #0xd57ca8
    // 0xd582c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd582c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd582cc: b               #0xd57de0
    // 0xd582d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd582d0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd582d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd582d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd582d8: b               #0xd57f58
    // 0xd582dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd582dc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd582e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd582e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd582e4: b               #0xd5806c
  }
  _ _check(/* No info */) {
    // ** addr: 0xd582e8, size: 0x84
    // 0xd582e8: EnterFrame
    //     0xd582e8: stp             fp, lr, [SP, #-0x10]!
    //     0xd582ec: mov             fp, SP
    // 0xd582f0: AllocStack(0x18)
    //     0xd582f0: sub             SP, SP, #0x18
    // 0xd582f4: SetupParameters(DefaultCookieJar this /* r1 => r0 */, dynamic _ /* r3 => r1, fp-0x8 */)
    //     0xd582f4: mov             x0, x1
    //     0xd582f8: mov             x1, x3
    //     0xd582fc: stur            x3, [fp, #-8]
    // 0xd58300: CheckStackOverflow
    //     0xd58300: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd58304: cmp             SP, x16
    //     0xd58308: b.ls            #0xd58364
    // 0xd5830c: LoadField: r0 = r1->field_7
    //     0xd5830c: ldur            w0, [x1, #7]
    // 0xd58310: DecompressPointer r0
    //     0xd58310: add             x0, x0, HEAP, lsl #32
    // 0xd58314: LoadField: r3 = r0->field_23
    //     0xd58314: ldur            w3, [x0, #0x23]
    // 0xd58318: DecompressPointer r3
    //     0xd58318: add             x3, x3, HEAP, lsl #32
    // 0xd5831c: tbnz            w3, #4, #0xd58348
    // 0xd58320: r0 = LoadClassIdInstr(r2)
    //     0xd58320: ldur            x0, [x2, #-1]
    //     0xd58324: ubfx            x0, x0, #0xc, #0x14
    // 0xd58328: r16 = "https"
    //     0xd58328: ldr             x16, [PP, #0x1078]  ; [pp+0x1078] "https"
    // 0xd5832c: stp             x16, x2, [SP]
    // 0xd58330: mov             lr, x0
    // 0xd58334: ldr             lr, [x21, lr, lsl #3]
    // 0xd58338: blr             lr
    // 0xd5833c: tbnz            w0, #4, #0xd58348
    // 0xd58340: r0 = true
    //     0xd58340: add             x0, NULL, #0x20  ; true
    // 0xd58344: b               #0xd58358
    // 0xd58348: ldur            x1, [fp, #-8]
    // 0xd5834c: r0 = isExpired()
    //     0xd5834c: bl              #0xd583a8  ; [package:cookie_jar/src/serializable_cookie.dart] SerializableCookie::isExpired
    // 0xd58350: eor             x1, x0, #0x10
    // 0xd58354: mov             x0, x1
    // 0xd58358: LeaveFrame
    //     0xd58358: mov             SP, fp
    //     0xd5835c: ldp             fp, lr, [SP], #0x10
    // 0xd58360: ret
    //     0xd58360: ret             
    // 0xd58364: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd58364: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd58368: b               #0xd5830c
  }
  get _ domainCookies(/* No info */) {
    // ** addr: 0xd5836c, size: 0x3c
    // 0xd5836c: LoadField: r2 = r1->field_b
    //     0xd5836c: ldur            w2, [x1, #0xb]
    // 0xd58370: DecompressPointer r2
    //     0xd58370: add             x2, x2, HEAP, lsl #32
    // 0xd58374: LoadField: r3 = r2->field_b
    //     0xd58374: ldur            w3, [x2, #0xb]
    // 0xd58378: r0 = LoadInt32Instr(r3)
    //     0xd58378: sbfx            x0, x3, #1, #0x1f
    // 0xd5837c: r1 = 0
    //     0xd5837c: mov             x1, #0
    // 0xd58380: cmp             x1, x0
    // 0xd58384: b.hs            #0xd5839c
    // 0xd58388: LoadField: r1 = r2->field_f
    //     0xd58388: ldur            w1, [x2, #0xf]
    // 0xd5838c: DecompressPointer r1
    //     0xd5838c: add             x1, x1, HEAP, lsl #32
    // 0xd58390: LoadField: r0 = r1->field_f
    //     0xd58390: ldur            w0, [x1, #0xf]
    // 0xd58394: DecompressPointer r0
    //     0xd58394: add             x0, x0, HEAP, lsl #32
    // 0xd58398: ret
    //     0xd58398: ret             
    // 0xd5839c: EnterFrame
    //     0xd5839c: stp             fp, lr, [SP, #-0x10]!
    //     0xd583a0: mov             fp, SP
    // 0xd583a4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xd583a4: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _isPathMatch(/* No info */) {
    // ** addr: 0xd584f4, size: 0x134
    // 0xd584f4: EnterFrame
    //     0xd584f4: stp             fp, lr, [SP, #-0x10]!
    //     0xd584f8: mov             fp, SP
    // 0xd584fc: AllocStack(0x40)
    //     0xd584fc: sub             SP, SP, #0x40
    // 0xd58500: SetupParameters(dynamic _ /* r3 => r3, fp-0x8 */)
    //     0xd58500: stur            x3, [fp, #-8]
    // 0xd58504: CheckStackOverflow
    //     0xd58504: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd58508: cmp             SP, x16
    //     0xd5850c: b.ls            #0xd58620
    // 0xd58510: r0 = LoadClassIdInstr(r2)
    //     0xd58510: ldur            x0, [x2, #-1]
    //     0xd58514: ubfx            x0, x0, #0xc, #0x14
    // 0xd58518: str             x2, [SP]
    // 0xd5851c: r0 = GDT[cid_x0 + -0xffc]()
    //     0xd5851c: sub             lr, x0, #0xffc
    //     0xd58520: ldr             lr, [x21, lr, lsl #3]
    //     0xd58524: blr             lr
    // 0xd58528: mov             x2, x0
    // 0xd5852c: ldur            x1, [fp, #-8]
    // 0xd58530: stur            x2, [fp, #-0x10]
    // 0xd58534: r0 = LoadClassIdInstr(r1)
    //     0xd58534: ldur            x0, [x1, #-1]
    //     0xd58538: ubfx            x0, x0, #0xc, #0x14
    // 0xd5853c: str             x1, [SP]
    // 0xd58540: r0 = GDT[cid_x0 + -0xffc]()
    //     0xd58540: sub             lr, x0, #0xffc
    //     0xd58544: ldr             lr, [x21, lr, lsl #3]
    //     0xd58548: blr             lr
    // 0xd5854c: stur            x0, [fp, #-0x18]
    // 0xd58550: r16 = "/"
    //     0xd58550: ldr             x16, [PP, #0xfe0]  ; [pp+0xfe0] "/"
    // 0xd58554: ldur            lr, [fp, #-8]
    // 0xd58558: stp             lr, x16, [SP]
    // 0xd5855c: r0 = ==()
    //     0xd5855c: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0xd58560: tbz             w0, #4, #0xd58588
    // 0xd58564: ldur            x1, [fp, #-0x10]
    // 0xd58568: r0 = LoadClassIdInstr(r1)
    //     0xd58568: ldur            x0, [x1, #-1]
    //     0xd5856c: ubfx            x0, x0, #0xc, #0x14
    // 0xd58570: ldur            x16, [fp, #-0x18]
    // 0xd58574: stp             x16, x1, [SP]
    // 0xd58578: mov             lr, x0
    // 0xd5857c: ldr             lr, [x21, lr, lsl #3]
    // 0xd58580: blr             lr
    // 0xd58584: tbnz            w0, #4, #0xd58598
    // 0xd58588: r0 = true
    //     0xd58588: add             x0, NULL, #0x20  ; true
    // 0xd5858c: LeaveFrame
    //     0xd5858c: mov             SP, fp
    //     0xd58590: ldp             fp, lr, [SP], #0x10
    // 0xd58594: ret
    //     0xd58594: ret             
    // 0xd58598: ldur            x1, [fp, #-0x10]
    // 0xd5859c: ldur            x2, [fp, #-0x18]
    // 0xd585a0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xd585a0: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xd585a4: r0 = startsWith()
    //     0xd585a4: bl              #0x7ea4f0  ; [dart:core] _StringBase::startsWith
    // 0xd585a8: tbnz            w0, #4, #0xd58610
    // 0xd585ac: ldur            x0, [fp, #-0x18]
    // 0xd585b0: LoadField: r1 = r0->field_7
    //     0xd585b0: ldur            w1, [x0, #7]
    // 0xd585b4: r2 = LoadInt32Instr(r1)
    //     0xd585b4: sbfx            x2, x1, #1, #0x1f
    // 0xd585b8: stur            x2, [fp, #-0x28]
    // 0xd585bc: sub             x1, x2, #1
    // 0xd585c0: stur            x1, [fp, #-0x20]
    // 0xd585c4: lsl             x3, x1, #1
    // 0xd585c8: stp             x3, x0, [SP, #8]
    // 0xd585cc: r16 = "/"
    //     0xd585cc: ldr             x16, [PP, #0xfe0]  ; [pp+0xfe0] "/"
    // 0xd585d0: str             x16, [SP]
    // 0xd585d4: r0 = _substringMatches()
    //     0xd585d4: bl              #0x7ea6d8  ; [dart:core] _StringBase::_substringMatches
    // 0xd585d8: tbnz            w0, #4, #0xd585e4
    // 0xd585dc: ldur            x2, [fp, #-0x20]
    // 0xd585e0: b               #0xd585e8
    // 0xd585e4: ldur            x2, [fp, #-0x28]
    // 0xd585e8: ldur            x1, [fp, #-0x10]
    // 0xd585ec: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xd585ec: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xd585f0: r0 = substring()
    //     0xd585f0: bl              #0x7e3f74  ; [dart:core] _StringBase::substring
    // 0xd585f4: mov             x1, x0
    // 0xd585f8: r2 = "/"
    //     0xd585f8: ldr             x2, [PP, #0xfe0]  ; [pp+0xfe0] "/"
    // 0xd585fc: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xd585fc: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xd58600: r0 = startsWith()
    //     0xd58600: bl              #0x7ea4f0  ; [dart:core] _StringBase::startsWith
    // 0xd58604: LeaveFrame
    //     0xd58604: mov             SP, fp
    //     0xd58608: ldp             fp, lr, [SP], #0x10
    // 0xd5860c: ret
    //     0xd5860c: ret             
    // 0xd58610: r0 = false
    //     0xd58610: add             x0, NULL, #0x30  ; false
    // 0xd58614: LeaveFrame
    //     0xd58614: mov             SP, fp
    //     0xd58618: ldp             fp, lr, [SP], #0x10
    // 0xd5861c: ret
    //     0xd5861c: ret             
    // 0xd58620: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd58620: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd58624: b               #0xd58510
  }
  get _ hostCookies(/* No info */) {
    // ** addr: 0xd58628, size: 0x3c
    // 0xd58628: LoadField: r2 = r1->field_b
    //     0xd58628: ldur            w2, [x1, #0xb]
    // 0xd5862c: DecompressPointer r2
    //     0xd5862c: add             x2, x2, HEAP, lsl #32
    // 0xd58630: LoadField: r3 = r2->field_b
    //     0xd58630: ldur            w3, [x2, #0xb]
    // 0xd58634: r0 = LoadInt32Instr(r3)
    //     0xd58634: sbfx            x0, x3, #1, #0x1f
    // 0xd58638: r1 = 1
    //     0xd58638: mov             x1, #1
    // 0xd5863c: cmp             x1, x0
    // 0xd58640: b.hs            #0xd58658
    // 0xd58644: LoadField: r1 = r2->field_f
    //     0xd58644: ldur            w1, [x2, #0xf]
    // 0xd58648: DecompressPointer r1
    //     0xd58648: add             x1, x1, HEAP, lsl #32
    // 0xd5864c: LoadField: r0 = r1->field_13
    //     0xd5864c: ldur            w0, [x1, #0x13]
    // 0xd58650: DecompressPointer r0
    //     0xd58650: add             x0, x0, HEAP, lsl #32
    // 0xd58654: ret
    //     0xd58654: ret             
    // 0xd58658: EnterFrame
    //     0xd58658: stp             fp, lr, [SP, #-0x10]!
    //     0xd5865c: mov             fp, SP
    // 0xd58660: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xd58660: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, String, Map<String, Map<String, SerializableCookie>>) {
    // ** addr: 0xd58664, size: 0xb4
    // 0xd58664: EnterFrame
    //     0xd58664: stp             fp, lr, [SP, #-0x10]!
    //     0xd58668: mov             fp, SP
    // 0xd5866c: AllocStack(0x10)
    //     0xd5866c: sub             SP, SP, #0x10
    // 0xd58670: SetupParameters([dynamic _ /* r0 */])
    //     0xd58670: ldr             x0, [fp, #0x20]
    //     0xd58674: ldur            w2, [x0, #0x17]
    //     0xd58678: add             x2, x2, HEAP, lsl #32
    //     0xd5867c: stur            x2, [fp, #-0x10]
    // 0xd58680: CheckStackOverflow
    //     0xd58680: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd58684: cmp             SP, x16
    //     0xd58688: b.ls            #0xd58710
    // 0xd5868c: LoadField: r3 = r2->field_f
    //     0xd5868c: ldur            w3, [x2, #0xf]
    // 0xd58690: DecompressPointer r3
    //     0xd58690: add             x3, x3, HEAP, lsl #32
    // 0xd58694: stur            x3, [fp, #-8]
    // 0xd58698: LoadField: r1 = r2->field_13
    //     0xd58698: ldur            w1, [x2, #0x13]
    // 0xd5869c: DecompressPointer r1
    //     0xd5869c: add             x1, x1, HEAP, lsl #32
    // 0xd586a0: r0 = LoadClassIdInstr(r1)
    //     0xd586a0: ldur            x0, [x1, #-1]
    //     0xd586a4: ubfx            x0, x0, #0xc, #0x14
    // 0xd586a8: r0 = GDT[cid_x0 + -0xf07]()
    //     0xd586a8: sub             lr, x0, #0xf07
    //     0xd586ac: ldr             lr, [x21, lr, lsl #3]
    //     0xd586b0: blr             lr
    // 0xd586b4: ldur            x1, [fp, #-8]
    // 0xd586b8: mov             x2, x0
    // 0xd586bc: ldr             x3, [fp, #0x18]
    // 0xd586c0: r0 = _isDomainMatch()
    //     0xd586c0: bl              #0xd58718  ; [package:cookie_jar/src/jar/default.dart] DefaultCookieJar::_isDomainMatch
    // 0xd586c4: tbnz            w0, #4, #0xd58700
    // 0xd586c8: ldr             x0, [fp, #0x10]
    // 0xd586cc: ldur            x2, [fp, #-0x10]
    // 0xd586d0: r1 = Function '<anonymous closure>':.
    //     0xd586d0: add             x1, PP, #0x82, lsl #12  ; [pp+0x82298] AnonymousClosure: (0xd587fc), in [package:cookie_jar/src/jar/default.dart] DefaultCookieJar::loadForRequest (0xd57c84)
    //     0xd586d4: ldr             x1, [x1, #0x298]
    // 0xd586d8: r0 = AllocateClosure()
    //     0xd586d8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd586dc: ldr             x1, [fp, #0x10]
    // 0xd586e0: r2 = LoadClassIdInstr(r1)
    //     0xd586e0: ldur            x2, [x1, #-1]
    //     0xd586e4: ubfx            x2, x2, #0xc, #0x14
    // 0xd586e8: mov             x16, x0
    // 0xd586ec: mov             x0, x2
    // 0xd586f0: mov             x2, x16
    // 0xd586f4: r0 = GDT[cid_x0 + 0x6c5]()
    //     0xd586f4: add             lr, x0, #0x6c5
    //     0xd586f8: ldr             lr, [x21, lr, lsl #3]
    //     0xd586fc: blr             lr
    // 0xd58700: r0 = Null
    //     0xd58700: mov             x0, NULL
    // 0xd58704: LeaveFrame
    //     0xd58704: mov             SP, fp
    //     0xd58708: ldp             fp, lr, [SP], #0x10
    // 0xd5870c: ret
    //     0xd5870c: ret             
    // 0xd58710: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd58710: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd58714: b               #0xd5868c
  }
  _ _isDomainMatch(/* No info */) {
    // ** addr: 0xd58718, size: 0xe4
    // 0xd58718: EnterFrame
    //     0xd58718: stp             fp, lr, [SP, #-0x10]!
    //     0xd5871c: mov             fp, SP
    // 0xd58720: AllocStack(0x30)
    //     0xd58720: sub             SP, SP, #0x30
    // 0xd58724: SetupParameters(DefaultCookieJar this /* r1 => r0 */, dynamic _ /* r2 => r1, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xd58724: mov             x0, x1
    //     0xd58728: mov             x1, x2
    //     0xd5872c: stur            x2, [fp, #-8]
    //     0xd58730: stur            x3, [fp, #-0x10]
    // 0xd58734: CheckStackOverflow
    //     0xd58734: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd58738: cmp             SP, x16
    //     0xd5873c: b.ls            #0xd587f4
    // 0xd58740: r0 = LoadClassIdInstr(r1)
    //     0xd58740: ldur            x0, [x1, #-1]
    //     0xd58744: ubfx            x0, x0, #0xc, #0x14
    // 0xd58748: stp             x3, x1, [SP]
    // 0xd5874c: mov             lr, x0
    // 0xd58750: ldr             lr, [x21, lr, lsl #3]
    // 0xd58754: blr             lr
    // 0xd58758: tbnz            w0, #4, #0xd5876c
    // 0xd5875c: r0 = true
    //     0xd5875c: add             x0, NULL, #0x20  ; true
    // 0xd58760: LeaveFrame
    //     0xd58760: mov             SP, fp
    //     0xd58764: ldp             fp, lr, [SP], #0x10
    // 0xd58768: ret
    //     0xd58768: ret             
    // 0xd5876c: ldur            x1, [fp, #-8]
    // 0xd58770: ldur            x0, [fp, #-0x10]
    // 0xd58774: LoadField: r2 = r1->field_7
    //     0xd58774: ldur            w2, [x1, #7]
    // 0xd58778: LoadField: r3 = r0->field_7
    //     0xd58778: ldur            w3, [x0, #7]
    // 0xd5877c: r4 = LoadInt32Instr(r2)
    //     0xd5877c: sbfx            x4, x2, #1, #0x1f
    // 0xd58780: r2 = LoadInt32Instr(r3)
    //     0xd58780: sbfx            x2, x3, #1, #0x1f
    // 0xd58784: sub             x3, x4, x2
    // 0xd58788: lsl             x2, x3, #1
    // 0xd5878c: stur            x2, [fp, #-0x18]
    // 0xd58790: stp             x2, x1, [SP, #8]
    // 0xd58794: str             x0, [SP]
    // 0xd58798: r0 = _substringMatches()
    //     0xd58798: bl              #0x7ea6d8  ; [dart:core] _StringBase::_substringMatches
    // 0xd5879c: tbnz            w0, #4, #0xd587e4
    // 0xd587a0: ldur            x16, [fp, #-0x18]
    // 0xd587a4: str             x16, [SP]
    // 0xd587a8: ldur            x1, [fp, #-8]
    // 0xd587ac: r2 = 0
    //     0xd587ac: mov             x2, #0
    // 0xd587b0: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0xd587b0: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0xd587b4: r0 = substring()
    //     0xd587b4: bl              #0x7e3f74  ; [dart:core] _StringBase::substring
    // 0xd587b8: LoadField: r1 = r0->field_7
    //     0xd587b8: ldur            w1, [x0, #7]
    // 0xd587bc: r2 = LoadInt32Instr(r1)
    //     0xd587bc: sbfx            x2, x1, #1, #0x1f
    // 0xd587c0: sub             x1, x2, #1
    // 0xd587c4: lsl             x2, x1, #1
    // 0xd587c8: stp             x2, x0, [SP, #8]
    // 0xd587cc: r16 = "."
    //     0xd587cc: ldr             x16, [PP, #0xfc8]  ; [pp+0xfc8] "."
    // 0xd587d0: str             x16, [SP]
    // 0xd587d4: r0 = _substringMatches()
    //     0xd587d4: bl              #0x7ea6d8  ; [dart:core] _StringBase::_substringMatches
    // 0xd587d8: LeaveFrame
    //     0xd587d8: mov             SP, fp
    //     0xd587dc: ldp             fp, lr, [SP], #0x10
    // 0xd587e0: ret
    //     0xd587e0: ret             
    // 0xd587e4: r0 = false
    //     0xd587e4: add             x0, NULL, #0x30  ; false
    // 0xd587e8: LeaveFrame
    //     0xd587e8: mov             SP, fp
    //     0xd587ec: ldp             fp, lr, [SP], #0x10
    // 0xd587f0: ret
    //     0xd587f0: ret             
    // 0xd587f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd587f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd587f8: b               #0xd58740
  }
  [closure] void <anonymous closure>(dynamic, String, Map<String, SerializableCookie>) {
    // ** addr: 0xd587fc, size: 0x94
    // 0xd587fc: EnterFrame
    //     0xd587fc: stp             fp, lr, [SP, #-0x10]!
    //     0xd58800: mov             fp, SP
    // 0xd58804: AllocStack(0x8)
    //     0xd58804: sub             SP, SP, #8
    // 0xd58808: SetupParameters([dynamic _ /* r0 */])
    //     0xd58808: ldr             x0, [fp, #0x20]
    //     0xd5880c: ldur            w4, [x0, #0x17]
    //     0xd58810: add             x4, x4, HEAP, lsl #32
    //     0xd58814: stur            x4, [fp, #-8]
    // 0xd58818: CheckStackOverflow
    //     0xd58818: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd5881c: cmp             SP, x16
    //     0xd58820: b.ls            #0xd58888
    // 0xd58824: LoadField: r1 = r4->field_f
    //     0xd58824: ldur            w1, [x4, #0xf]
    // 0xd58828: DecompressPointer r1
    //     0xd58828: add             x1, x1, HEAP, lsl #32
    // 0xd5882c: LoadField: r2 = r4->field_1b
    //     0xd5882c: ldur            w2, [x4, #0x1b]
    // 0xd58830: DecompressPointer r2
    //     0xd58830: add             x2, x2, HEAP, lsl #32
    // 0xd58834: ldr             x3, [fp, #0x18]
    // 0xd58838: r0 = _isPathMatch()
    //     0xd58838: bl              #0xd584f4  ; [package:cookie_jar/src/jar/default.dart] DefaultCookieJar::_isPathMatch
    // 0xd5883c: tbnz            w0, #4, #0xd58878
    // 0xd58840: ldr             x0, [fp, #0x10]
    // 0xd58844: ldur            x2, [fp, #-8]
    // 0xd58848: r1 = Function '<anonymous closure>':.
    //     0xd58848: add             x1, PP, #0x82, lsl #12  ; [pp+0x822a0] AnonymousClosure: (0xd58890), in [package:cookie_jar/src/jar/default.dart] DefaultCookieJar::loadForRequest (0xd57c84)
    //     0xd5884c: ldr             x1, [x1, #0x2a0]
    // 0xd58850: r0 = AllocateClosure()
    //     0xd58850: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd58854: ldr             x1, [fp, #0x10]
    // 0xd58858: r2 = LoadClassIdInstr(r1)
    //     0xd58858: ldur            x2, [x1, #-1]
    //     0xd5885c: ubfx            x2, x2, #0xc, #0x14
    // 0xd58860: mov             x16, x0
    // 0xd58864: mov             x0, x2
    // 0xd58868: mov             x2, x16
    // 0xd5886c: r0 = GDT[cid_x0 + 0x6c5]()
    //     0xd5886c: add             lr, x0, #0x6c5
    //     0xd58870: ldr             lr, [x21, lr, lsl #3]
    //     0xd58874: blr             lr
    // 0xd58878: r0 = Null
    //     0xd58878: mov             x0, NULL
    // 0xd5887c: LeaveFrame
    //     0xd5887c: mov             SP, fp
    //     0xd58880: ldp             fp, lr, [SP], #0x10
    // 0xd58884: ret
    //     0xd58884: ret             
    // 0xd58888: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd58888: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd5888c: b               #0xd58824
  }
  [closure] void <anonymous closure>(dynamic, String, SerializableCookie) {
    // ** addr: 0xd58890, size: 0x110
    // 0xd58890: EnterFrame
    //     0xd58890: stp             fp, lr, [SP, #-0x10]!
    //     0xd58894: mov             fp, SP
    // 0xd58898: AllocStack(0x20)
    //     0xd58898: sub             SP, SP, #0x20
    // 0xd5889c: SetupParameters([dynamic _ /* r0 */])
    //     0xd5889c: ldr             x0, [fp, #0x20]
    //     0xd588a0: ldur            w2, [x0, #0x17]
    //     0xd588a4: add             x2, x2, HEAP, lsl #32
    //     0xd588a8: stur            x2, [fp, #-0x10]
    // 0xd588ac: CheckStackOverflow
    //     0xd588ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd588b0: cmp             SP, x16
    //     0xd588b4: b.ls            #0xd58998
    // 0xd588b8: LoadField: r3 = r2->field_f
    //     0xd588b8: ldur            w3, [x2, #0xf]
    // 0xd588bc: DecompressPointer r3
    //     0xd588bc: add             x3, x3, HEAP, lsl #32
    // 0xd588c0: stur            x3, [fp, #-8]
    // 0xd588c4: LoadField: r1 = r2->field_13
    //     0xd588c4: ldur            w1, [x2, #0x13]
    // 0xd588c8: DecompressPointer r1
    //     0xd588c8: add             x1, x1, HEAP, lsl #32
    // 0xd588cc: r0 = LoadClassIdInstr(r1)
    //     0xd588cc: ldur            x0, [x1, #-1]
    //     0xd588d0: ubfx            x0, x0, #0xc, #0x14
    // 0xd588d4: r0 = GDT[cid_x0 + -0xf55]()
    //     0xd588d4: sub             lr, x0, #0xf55
    //     0xd588d8: ldr             lr, [x21, lr, lsl #3]
    //     0xd588dc: blr             lr
    // 0xd588e0: ldur            x1, [fp, #-8]
    // 0xd588e4: mov             x2, x0
    // 0xd588e8: ldr             x3, [fp, #0x10]
    // 0xd588ec: r0 = _check()
    //     0xd588ec: bl              #0xd582e8  ; [package:cookie_jar/src/jar/default.dart] DefaultCookieJar::_check
    // 0xd588f0: tbnz            w0, #4, #0xd58988
    // 0xd588f4: ldr             x1, [fp, #0x10]
    // 0xd588f8: ldur            x0, [fp, #-0x10]
    // 0xd588fc: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xd588fc: ldur            w2, [x0, #0x17]
    // 0xd58900: DecompressPointer r2
    //     0xd58900: add             x2, x2, HEAP, lsl #32
    // 0xd58904: stur            x2, [fp, #-0x20]
    // 0xd58908: LoadField: r0 = r1->field_7
    //     0xd58908: ldur            w0, [x1, #7]
    // 0xd5890c: DecompressPointer r0
    //     0xd5890c: add             x0, x0, HEAP, lsl #32
    // 0xd58910: stur            x0, [fp, #-8]
    // 0xd58914: LoadField: r1 = r2->field_b
    //     0xd58914: ldur            w1, [x2, #0xb]
    // 0xd58918: LoadField: r3 = r2->field_f
    //     0xd58918: ldur            w3, [x2, #0xf]
    // 0xd5891c: DecompressPointer r3
    //     0xd5891c: add             x3, x3, HEAP, lsl #32
    // 0xd58920: LoadField: r4 = r3->field_b
    //     0xd58920: ldur            w4, [x3, #0xb]
    // 0xd58924: r3 = LoadInt32Instr(r1)
    //     0xd58924: sbfx            x3, x1, #1, #0x1f
    // 0xd58928: stur            x3, [fp, #-0x18]
    // 0xd5892c: r1 = LoadInt32Instr(r4)
    //     0xd5892c: sbfx            x1, x4, #1, #0x1f
    // 0xd58930: cmp             x3, x1
    // 0xd58934: b.ne            #0xd58940
    // 0xd58938: mov             x1, x2
    // 0xd5893c: r0 = _growToNextCapacity()
    //     0xd5893c: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xd58940: ldur            x2, [fp, #-0x20]
    // 0xd58944: ldur            x3, [fp, #-0x18]
    // 0xd58948: add             x4, x3, #1
    // 0xd5894c: lsl             x5, x4, #1
    // 0xd58950: StoreField: r2->field_b = r5
    //     0xd58950: stur            w5, [x2, #0xb]
    // 0xd58954: LoadField: r1 = r2->field_f
    //     0xd58954: ldur            w1, [x2, #0xf]
    // 0xd58958: DecompressPointer r1
    //     0xd58958: add             x1, x1, HEAP, lsl #32
    // 0xd5895c: ldur            x0, [fp, #-8]
    // 0xd58960: ArrayStore: r1[r3] = r0  ; List_4
    //     0xd58960: add             x25, x1, x3, lsl #2
    //     0xd58964: add             x25, x25, #0xf
    //     0xd58968: str             w0, [x25]
    //     0xd5896c: tbz             w0, #0, #0xd58988
    //     0xd58970: ldurb           w16, [x1, #-1]
    //     0xd58974: ldurb           w17, [x0, #-1]
    //     0xd58978: and             x16, x17, x16, lsr #2
    //     0xd5897c: tst             x16, HEAP, lsr #32
    //     0xd58980: b.eq            #0xd58988
    //     0xd58984: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd58988: r0 = Null
    //     0xd58988: mov             x0, NULL
    // 0xd5898c: LeaveFrame
    //     0xd5898c: mov             SP, fp
    //     0xd58990: ldp             fp, lr, [SP], #0x10
    // 0xd58994: ret
    //     0xd58994: ret             
    // 0xd58998: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd58998: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd5899c: b               #0xd588b8
  }
  [closure] int <anonymous closure>(dynamic, String, String) {
    // ** addr: 0xd589a0, size: 0x44
    // 0xd589a0: EnterFrame
    //     0xd589a0: stp             fp, lr, [SP, #-0x10]!
    //     0xd589a4: mov             fp, SP
    // 0xd589a8: CheckStackOverflow
    //     0xd589a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd589ac: cmp             SP, x16
    //     0xd589b0: b.ls            #0xd589dc
    // 0xd589b4: ldr             x0, [fp, #0x10]
    // 0xd589b8: LoadField: r1 = r0->field_7
    //     0xd589b8: ldur            w1, [x0, #7]
    // 0xd589bc: ldr             x0, [fp, #0x18]
    // 0xd589c0: LoadField: r2 = r0->field_7
    //     0xd589c0: ldur            w2, [x0, #7]
    // 0xd589c4: r0 = compareTo()
    //     0xd589c4: bl              #0xa01d58  ; [dart:core] _IntegerImplementation::compareTo
    // 0xd589c8: lsl             x1, x0, #1
    // 0xd589cc: mov             x0, x1
    // 0xd589d0: LeaveFrame
    //     0xd589d0: mov             SP, fp
    //     0xd589d4: ldp             fp, lr, [SP], #0x10
    // 0xd589d8: ret
    //     0xd589d8: ret             
    // 0xd589dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd589dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd589e0: b               #0xd589b4
  }
  _ saveFromResponse(/* No info */) async {
    // ** addr: 0x11a4154, size: 0x590
    // 0x11a4154: EnterFrame
    //     0x11a4154: stp             fp, lr, [SP, #-0x10]!
    //     0x11a4158: mov             fp, SP
    // 0x11a415c: AllocStack(0x98)
    //     0x11a415c: sub             SP, SP, #0x98
    // 0x11a4160: SetupParameters(DefaultCookieJar this /* r1 => r2, fp-0x20 */, dynamic _ /* r2 => r1, fp-0x18 */)
    //     0x11a4160: stur            NULL, [fp, #-8]
    //     0x11a4164: stur            x1, [fp, #-0x10]
    //     0x11a4168: mov             x16, x2
    //     0x11a416c: mov             x2, x1
    //     0x11a4170: mov             x1, x16
    //     0x11a4174: stur            x1, [fp, #-0x18]
    //     0x11a4178: stur            x3, [fp, #-0x20]
    // 0x11a417c: CheckStackOverflow
    //     0x11a417c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a4180: cmp             SP, x16
    //     0x11a4184: b.ls            #0x11a46c8
    // 0x11a4188: InitAsync() -> Future<void?>
    //     0x11a4188: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0x11a418c: bl              #0x7f5e44  ; InitAsyncStub
    // 0x11a4190: ldur            x0, [fp, #-0x20]
    // 0x11a4194: LoadField: r1 = r0->field_b
    //     0x11a4194: ldur            w1, [x0, #0xb]
    // 0x11a4198: r2 = LoadInt32Instr(r1)
    //     0x11a4198: sbfx            x2, x1, #1, #0x1f
    // 0x11a419c: ldur            x1, [fp, #-0x10]
    // 0x11a41a0: stur            x2, [fp, #-0x48]
    // 0x11a41a4: LoadField: r3 = r1->field_b
    //     0x11a41a4: ldur            w3, [x1, #0xb]
    // 0x11a41a8: DecompressPointer r3
    //     0x11a41a8: add             x3, x3, HEAP, lsl #32
    // 0x11a41ac: stur            x3, [fp, #-0x40]
    // 0x11a41b0: r4 = 0
    //     0x11a41b0: mov             x4, #0
    // 0x11a41b4: ldur            x1, [fp, #-0x18]
    // 0x11a41b8: CheckStackOverflow
    //     0x11a41b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a41bc: cmp             SP, x16
    //     0x11a41c0: b.ls            #0x11a46d0
    // 0x11a41c4: LoadField: r5 = r0->field_b
    //     0x11a41c4: ldur            w5, [x0, #0xb]
    // 0x11a41c8: r6 = LoadInt32Instr(r5)
    //     0x11a41c8: sbfx            x6, x5, #1, #0x1f
    // 0x11a41cc: cmp             x2, x6
    // 0x11a41d0: b.ne            #0x11a46ac
    // 0x11a41d4: cmp             x4, x6
    // 0x11a41d8: b.ge            #0x11a467c
    // 0x11a41dc: LoadField: r5 = r0->field_f
    //     0x11a41dc: ldur            w5, [x0, #0xf]
    // 0x11a41e0: DecompressPointer r5
    //     0x11a41e0: add             x5, x5, HEAP, lsl #32
    // 0x11a41e4: ArrayLoad: r6 = r5[r4]  ; Unknown_4
    //     0x11a41e4: add             x16, x5, x4, lsl #2
    //     0x11a41e8: ldur            w6, [x16, #0xf]
    // 0x11a41ec: DecompressPointer r6
    //     0x11a41ec: add             x6, x6, HEAP, lsl #32
    // 0x11a41f0: stur            x6, [fp, #-0x38]
    // 0x11a41f4: add             x5, x4, #1
    // 0x11a41f8: stur            x5, [fp, #-0x30]
    // 0x11a41fc: ArrayLoad: r4 = r6[0]  ; List_4
    //     0x11a41fc: ldur            w4, [x6, #0x17]
    // 0x11a4200: DecompressPointer r4
    //     0x11a4200: add             x4, x4, HEAP, lsl #32
    // 0x11a4204: stur            x4, [fp, #-0x10]
    // 0x11a4208: cmp             w4, NULL
    // 0x11a420c: b.eq            #0x11a428c
    // 0x11a4210: LoadField: r7 = r4->field_7
    //     0x11a4210: ldur            w7, [x4, #7]
    // 0x11a4214: stur            x7, [fp, #-0x78]
    // 0x11a4218: r8 = LoadInt32Instr(r7)
    //     0x11a4218: sbfx            x8, x7, #1, #0x1f
    // 0x11a421c: stur            x8, [fp, #-0x28]
    // 0x11a4220: tbnz            x8, #0x3f, #0x11a4684
    // 0x11a4224: stp             xzr, x4, [SP, #8]
    // 0x11a4228: r16 = "."
    //     0x11a4228: ldr             x16, [PP, #0xfc8]  ; [pp+0xfc8] "."
    // 0x11a422c: str             x16, [SP]
    // 0x11a4230: r0 = _substringMatches()
    //     0x11a4230: bl              #0x7ea6d8  ; [dart:core] _StringBase::_substringMatches
    // 0x11a4234: tbnz            w0, #4, #0x11a4260
    // 0x11a4238: ldur            x3, [fp, #-0x28]
    // 0x11a423c: r1 = 1
    //     0x11a423c: mov             x1, #1
    // 0x11a4240: r2 = Null
    //     0x11a4240: mov             x2, NULL
    // 0x11a4244: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x11a4244: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x11a4248: r0 = checkValidRange()
    //     0x11a4248: bl              #0x7db068  ; [dart:core] RangeError::checkValidRange
    // 0x11a424c: ldur            x1, [fp, #-0x10]
    // 0x11a4250: mov             x3, x0
    // 0x11a4254: r2 = 1
    //     0x11a4254: mov             x2, #1
    // 0x11a4258: r0 = _substringUnchecked()
    //     0x11a4258: bl              #0x7e3ff8  ; [dart:core] _StringBase::_substringUnchecked
    // 0x11a425c: b               #0x11a4264
    // 0x11a4260: ldur            x0, [fp, #-0x10]
    // 0x11a4264: ldur            x2, [fp, #-0x38]
    // 0x11a4268: LoadField: r1 = r2->field_1b
    //     0x11a4268: ldur            w1, [x2, #0x1b]
    // 0x11a426c: DecompressPointer r1
    //     0x11a426c: add             x1, x1, HEAP, lsl #32
    // 0x11a4270: cmp             w1, NULL
    // 0x11a4274: b.ne            #0x11a427c
    // 0x11a4278: r1 = "/"
    //     0x11a4278: ldr             x1, [PP, #0xfe0]  ; [pp+0xfe0] "/"
    // 0x11a427c: mov             x6, x0
    // 0x11a4280: mov             x5, x1
    // 0x11a4284: r4 = 0
    //     0x11a4284: mov             x4, #0
    // 0x11a4288: b               #0x11a4364
    // 0x11a428c: mov             x3, x1
    // 0x11a4290: mov             x2, x6
    // 0x11a4294: r0 = LoadClassIdInstr(r3)
    //     0x11a4294: ldur            x0, [x3, #-1]
    //     0x11a4298: ubfx            x0, x0, #0xc, #0x14
    // 0x11a429c: mov             x1, x3
    // 0x11a42a0: r0 = GDT[cid_x0 + -0xf07]()
    //     0x11a42a0: sub             lr, x0, #0xf07
    //     0x11a42a4: ldr             lr, [x21, lr, lsl #3]
    //     0x11a42a8: blr             lr
    // 0x11a42ac: mov             x3, x0
    // 0x11a42b0: ldur            x2, [fp, #-0x38]
    // 0x11a42b4: stur            x3, [fp, #-0x10]
    // 0x11a42b8: LoadField: r0 = r2->field_1b
    //     0x11a42b8: ldur            w0, [x2, #0x1b]
    // 0x11a42bc: DecompressPointer r0
    //     0x11a42bc: add             x0, x0, HEAP, lsl #32
    // 0x11a42c0: cmp             w0, NULL
    // 0x11a42c4: b.ne            #0x11a4358
    // 0x11a42c8: ldur            x4, [fp, #-0x18]
    // 0x11a42cc: r0 = LoadClassIdInstr(r4)
    //     0x11a42cc: ldur            x0, [x4, #-1]
    //     0x11a42d0: ubfx            x0, x0, #0xc, #0x14
    // 0x11a42d4: mov             x1, x4
    // 0x11a42d8: r0 = GDT[cid_x0 + -0xfe0]()
    //     0x11a42d8: sub             lr, x0, #0xfe0
    //     0x11a42dc: ldr             lr, [x21, lr, lsl #3]
    //     0x11a42e0: blr             lr
    // 0x11a42e4: LoadField: r1 = r0->field_7
    //     0x11a42e4: ldur            w1, [x0, #7]
    // 0x11a42e8: cbnz            w1, #0x11a42f4
    // 0x11a42ec: r0 = "/"
    //     0x11a42ec: ldr             x0, [PP, #0xfe0]  ; [pp+0xfe0] "/"
    // 0x11a42f0: b               #0x11a4358
    // 0x11a42f4: r1 = LoadClassIdInstr(r0)
    //     0x11a42f4: ldur            x1, [x0, #-1]
    //     0x11a42f8: ubfx            x1, x1, #0xc, #0x14
    // 0x11a42fc: mov             x16, x0
    // 0x11a4300: mov             x0, x1
    // 0x11a4304: mov             x1, x16
    // 0x11a4308: r2 = "/"
    //     0x11a4308: ldr             x2, [PP, #0xfe0]  ; [pp+0xfe0] "/"
    // 0x11a430c: r0 = GDT[cid_x0 + -0xffe]()
    //     0x11a430c: sub             lr, x0, #0xffe
    //     0x11a4310: ldr             lr, [x21, lr, lsl #3]
    //     0x11a4314: blr             lr
    // 0x11a4318: mov             x3, x0
    // 0x11a431c: stur            x3, [fp, #-0x50]
    // 0x11a4320: LoadField: r0 = r3->field_b
    //     0x11a4320: ldur            w0, [x3, #0xb]
    // 0x11a4324: r1 = LoadInt32Instr(r0)
    //     0x11a4324: sbfx            x1, x0, #1, #0x1f
    // 0x11a4328: sub             x2, x1, #1
    // 0x11a432c: mov             x0, x1
    // 0x11a4330: mov             x1, x2
    // 0x11a4334: cmp             x1, x0
    // 0x11a4338: b.hs            #0x11a46d8
    // 0x11a433c: mov             x1, x3
    // 0x11a4340: r0 = length=()
    //     0x11a4340: bl              #0x9fa1d0  ; [dart:core] _GrowableList::length=
    // 0x11a4344: r16 = "/"
    //     0x11a4344: ldr             x16, [PP, #0xfe0]  ; [pp+0xfe0] "/"
    // 0x11a4348: str             x16, [SP]
    // 0x11a434c: ldur            x1, [fp, #-0x50]
    // 0x11a4350: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x11a4350: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x11a4354: r0 = join()
    //     0x11a4354: bl              #0xb99e34  ; [dart:core] _GrowableList::join
    // 0x11a4358: ldur            x6, [fp, #-0x10]
    // 0x11a435c: mov             x5, x0
    // 0x11a4360: r4 = 1
    //     0x11a4360: mov             x4, #1
    // 0x11a4364: ldur            x3, [fp, #-0x40]
    // 0x11a4368: stur            x6, [fp, #-0x10]
    // 0x11a436c: stur            x5, [fp, #-0x50]
    // 0x11a4370: stur            x4, [fp, #-0x28]
    // 0x11a4374: LoadField: r0 = r3->field_b
    //     0x11a4374: ldur            w0, [x3, #0xb]
    // 0x11a4378: r1 = LoadInt32Instr(r0)
    //     0x11a4378: sbfx            x1, x0, #1, #0x1f
    // 0x11a437c: mov             x0, x1
    // 0x11a4380: mov             x1, x4
    // 0x11a4384: cmp             x1, x0
    // 0x11a4388: b.hs            #0x11a46dc
    // 0x11a438c: LoadField: r0 = r3->field_f
    //     0x11a438c: ldur            w0, [x3, #0xf]
    // 0x11a4390: DecompressPointer r0
    //     0x11a4390: add             x0, x0, HEAP, lsl #32
    // 0x11a4394: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0x11a4394: add             x16, x0, x4, lsl #2
    //     0x11a4398: ldur            w1, [x16, #0xf]
    // 0x11a439c: DecompressPointer r1
    //     0x11a439c: add             x1, x1, HEAP, lsl #32
    // 0x11a43a0: r0 = LoadClassIdInstr(r1)
    //     0x11a43a0: ldur            x0, [x1, #-1]
    //     0x11a43a4: ubfx            x0, x0, #0xc, #0x14
    // 0x11a43a8: mov             x2, x6
    // 0x11a43ac: r0 = GDT[cid_x0 + -0xd48]()
    //     0x11a43ac: sub             lr, x0, #0xd48
    //     0x11a43b0: ldr             lr, [x21, lr, lsl #3]
    //     0x11a43b4: blr             lr
    // 0x11a43b8: cmp             w0, NULL
    // 0x11a43bc: b.ne            #0x11a43c8
    // 0x11a43c0: r0 = Null
    //     0x11a43c0: mov             x0, NULL
    // 0x11a43c4: b               #0x11a43f0
    // 0x11a43c8: r1 = LoadClassIdInstr(r0)
    //     0x11a43c8: ldur            x1, [x0, #-1]
    //     0x11a43cc: ubfx            x1, x1, #0xc, #0x14
    // 0x11a43d0: r16 = <String, Map<String, dynamic>>
    //     0x11a43d0: add             x16, PP, #0x82, lsl #12  ; [pp+0x82118] TypeArguments: <String, Map<String, dynamic>>
    //     0x11a43d4: ldr             x16, [x16, #0x118]
    // 0x11a43d8: stp             x0, x16, [SP]
    // 0x11a43dc: mov             x0, x1
    // 0x11a43e0: r4 = const [0x2, 0x1, 0x1, 0x1, null]
    //     0x11a43e0: ldr             x4, [PP, #0x18e0]  ; [pp+0x18e0] List(5) [0x2, 0x1, 0x1, 0x1, Null]
    // 0x11a43e4: r0 = GDT[cid_x0 + 0xfb3]()
    //     0x11a43e4: add             lr, x0, #0xfb3
    //     0x11a43e8: ldr             lr, [x21, lr, lsl #3]
    //     0x11a43ec: blr             lr
    // 0x11a43f0: cmp             w0, NULL
    // 0x11a43f4: b.ne            #0x11a4414
    // 0x11a43f8: r16 = <String, Map<String, dynamic>>
    //     0x11a43f8: add             x16, PP, #0x82, lsl #12  ; [pp+0x82118] TypeArguments: <String, Map<String, dynamic>>
    //     0x11a43fc: ldr             x16, [x16, #0x118]
    // 0x11a4400: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x11a4404: stp             lr, x16, [SP]
    // 0x11a4408: r0 = Map._fromLiteral()
    //     0x11a4408: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x11a440c: mov             x3, x0
    // 0x11a4410: b               #0x11a4418
    // 0x11a4414: mov             x3, x0
    // 0x11a4418: stur            x3, [fp, #-0x58]
    // 0x11a441c: r0 = LoadClassIdInstr(r3)
    //     0x11a441c: ldur            x0, [x3, #-1]
    //     0x11a4420: ubfx            x0, x0, #0xc, #0x14
    // 0x11a4424: mov             x1, x3
    // 0x11a4428: ldur            x2, [fp, #-0x50]
    // 0x11a442c: r0 = GDT[cid_x0 + -0xd48]()
    //     0x11a442c: sub             lr, x0, #0xd48
    //     0x11a4430: ldr             lr, [x21, lr, lsl #3]
    //     0x11a4434: blr             lr
    // 0x11a4438: cmp             w0, NULL
    // 0x11a443c: b.ne            #0x11a4458
    // 0x11a4440: r16 = <String, dynamic>
    //     0x11a4440: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x11a4444: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x11a4448: stp             lr, x16, [SP]
    // 0x11a444c: r0 = Map._fromLiteral()
    //     0x11a444c: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x11a4450: mov             x1, x0
    // 0x11a4454: b               #0x11a445c
    // 0x11a4458: mov             x1, x0
    // 0x11a445c: ldur            x0, [fp, #-0x38]
    // 0x11a4460: stur            x1, [fp, #-0x68]
    // 0x11a4464: LoadField: r2 = r0->field_7
    //     0x11a4464: ldur            w2, [x0, #7]
    // 0x11a4468: DecompressPointer r2
    //     0x11a4468: add             x2, x2, HEAP, lsl #32
    // 0x11a446c: stur            x2, [fp, #-0x60]
    // 0x11a4470: r0 = SerializableCookie()
    //     0x11a4470: bl              #0x11a46e4  ; AllocateSerializableCookieStub -> SerializableCookie (size=0x14)
    // 0x11a4474: stur            x0, [fp, #-0x70]
    // 0x11a4478: StoreField: r0->field_b = rZR
    //     0x11a4478: stur            xzr, [x0, #0xb]
    // 0x11a447c: ldur            x1, [fp, #-0x38]
    // 0x11a4480: StoreField: r0->field_7 = r1
    //     0x11a4480: stur            w1, [x0, #7]
    // 0x11a4484: r0 = _getCurrentMicros()
    //     0x11a4484: bl              #0x89fe10  ; [dart:core] DateTime::_getCurrentMicros
    // 0x11a4488: r1 = LoadInt32Instr(r0)
    //     0x11a4488: sbfx            x1, x0, #1, #0x1f
    //     0x11a448c: tbz             w0, #0, #0x11a4494
    //     0x11a4490: ldur            x1, [x0, #7]
    // 0x11a4494: tbz             x1, #0x3f, #0x11a44a0
    // 0x11a4498: r0 = 999
    //     0x11a4498: mov             x0, #0x3e7
    // 0x11a449c: b               #0x11a44a4
    // 0x11a44a0: r0 = 0
    //     0x11a44a0: mov             x0, #0
    // 0x11a44a4: ldur            x5, [fp, #-0x68]
    // 0x11a44a8: ldur            x3, [fp, #-0x70]
    // 0x11a44ac: ldur            x4, [fp, #-0x38]
    // 0x11a44b0: r6 = 1000
    //     0x11a44b0: mov             x6, #0x3e8
    // 0x11a44b4: sub             x2, x1, x0
    // 0x11a44b8: sdiv            x0, x2, x6
    // 0x11a44bc: sdiv            x1, x0, x6
    // 0x11a44c0: StoreField: r3->field_b = r1
    //     0x11a44c0: stur            x1, [x3, #0xb]
    // 0x11a44c4: r0 = LoadClassIdInstr(r5)
    //     0x11a44c4: ldur            x0, [x5, #-1]
    //     0x11a44c8: ubfx            x0, x0, #0xc, #0x14
    // 0x11a44cc: mov             x1, x5
    // 0x11a44d0: ldur            x2, [fp, #-0x60]
    // 0x11a44d4: r0 = GDT[cid_x0 + -0xd50]()
    //     0x11a44d4: sub             lr, x0, #0xd50
    //     0x11a44d8: ldr             lr, [x21, lr, lsl #3]
    //     0x11a44dc: blr             lr
    // 0x11a44e0: ldur            x3, [fp, #-0x38]
    // 0x11a44e4: LoadField: r2 = r3->field_7
    //     0x11a44e4: ldur            w2, [x3, #7]
    // 0x11a44e8: DecompressPointer r2
    //     0x11a44e8: add             x2, x2, HEAP, lsl #32
    // 0x11a44ec: ldur            x4, [fp, #-0x68]
    // 0x11a44f0: r0 = LoadClassIdInstr(r4)
    //     0x11a44f0: ldur            x0, [x4, #-1]
    //     0x11a44f4: ubfx            x0, x0, #0xc, #0x14
    // 0x11a44f8: mov             x1, x4
    // 0x11a44fc: r0 = GDT[cid_x0 + -0xd48]()
    //     0x11a44fc: sub             lr, x0, #0xd48
    //     0x11a4500: ldr             lr, [x21, lr, lsl #3]
    //     0x11a4504: blr             lr
    // 0x11a4508: mov             x3, x0
    // 0x11a450c: r2 = Null
    //     0x11a450c: mov             x2, NULL
    // 0x11a4510: r1 = Null
    //     0x11a4510: mov             x1, NULL
    // 0x11a4514: stur            x3, [fp, #-0x60]
    // 0x11a4518: r4 = 60
    //     0x11a4518: mov             x4, #0x3c
    // 0x11a451c: branchIfSmi(r0, 0x11a4528)
    //     0x11a451c: tbz             w0, #0, #0x11a4528
    // 0x11a4520: r4 = LoadClassIdInstr(r0)
    //     0x11a4520: ldur            x4, [x0, #-1]
    //     0x11a4524: ubfx            x4, x4, #0xc, #0x14
    // 0x11a4528: cmp             x4, #0xde7
    // 0x11a452c: b.eq            #0x11a4544
    // 0x11a4530: r8 = SerializableCookie
    //     0x11a4530: add             x8, PP, #0x82, lsl #12  ; [pp+0x82120] Type: SerializableCookie
    //     0x11a4534: ldr             x8, [x8, #0x120]
    // 0x11a4538: r3 = Null
    //     0x11a4538: add             x3, PP, #0x82, lsl #12  ; [pp+0x82128] Null
    //     0x11a453c: ldr             x3, [x3, #0x128]
    // 0x11a4540: r0 = DefaultTypeTest()
    //     0x11a4540: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x11a4544: ldur            x1, [fp, #-0x60]
    // 0x11a4548: r0 = isExpired()
    //     0x11a4548: bl              #0xd583a8  ; [package:cookie_jar/src/serializable_cookie.dart] SerializableCookie::isExpired
    // 0x11a454c: tbnz            w0, #4, #0x11a4580
    // 0x11a4550: ldur            x3, [fp, #-0x68]
    // 0x11a4554: ldur            x0, [fp, #-0x38]
    // 0x11a4558: LoadField: r2 = r0->field_7
    //     0x11a4558: ldur            w2, [x0, #7]
    // 0x11a455c: DecompressPointer r2
    //     0x11a455c: add             x2, x2, HEAP, lsl #32
    // 0x11a4560: r0 = LoadClassIdInstr(r3)
    //     0x11a4560: ldur            x0, [x3, #-1]
    //     0x11a4564: ubfx            x0, x0, #0xc, #0x14
    // 0x11a4568: mov             x1, x3
    // 0x11a456c: r0 = GDT[cid_x0 + 0x129dd]()
    //     0x11a456c: mov             x17, #0x29dd
    //     0x11a4570: movk            x17, #1, lsl #16
    //     0x11a4574: add             lr, x0, x17
    //     0x11a4578: ldr             lr, [x21, lr, lsl #3]
    //     0x11a457c: blr             lr
    // 0x11a4580: ldur            x3, [fp, #-0x28]
    // 0x11a4584: ldur            x2, [fp, #-0x40]
    // 0x11a4588: ldur            x1, [fp, #-0x58]
    // 0x11a458c: ldur            x0, [fp, #-0x68]
    // 0x11a4590: r4 = LoadClassIdInstr(r0)
    //     0x11a4590: ldur            x4, [x0, #-1]
    //     0x11a4594: ubfx            x4, x4, #0xc, #0x14
    // 0x11a4598: r16 = <String, SerializableCookie>
    //     0x11a4598: add             x16, PP, #0x82, lsl #12  ; [pp+0x82138] TypeArguments: <String, SerializableCookie>
    //     0x11a459c: ldr             x16, [x16, #0x138]
    // 0x11a45a0: stp             x0, x16, [SP]
    // 0x11a45a4: mov             x0, x4
    // 0x11a45a8: r4 = const [0x2, 0x1, 0x1, 0x1, null]
    //     0x11a45a8: ldr             x4, [PP, #0x18e0]  ; [pp+0x18e0] List(5) [0x2, 0x1, 0x1, 0x1, Null]
    // 0x11a45ac: r0 = GDT[cid_x0 + 0xfb3]()
    //     0x11a45ac: add             lr, x0, #0xfb3
    //     0x11a45b0: ldr             lr, [x21, lr, lsl #3]
    //     0x11a45b4: blr             lr
    // 0x11a45b8: ldur            x4, [fp, #-0x58]
    // 0x11a45bc: r1 = LoadClassIdInstr(r4)
    //     0x11a45bc: ldur            x1, [x4, #-1]
    //     0x11a45c0: ubfx            x1, x1, #0xc, #0x14
    // 0x11a45c4: mov             x3, x0
    // 0x11a45c8: mov             x0, x1
    // 0x11a45cc: mov             x1, x4
    // 0x11a45d0: ldur            x2, [fp, #-0x50]
    // 0x11a45d4: r0 = GDT[cid_x0 + -0xd50]()
    //     0x11a45d4: sub             lr, x0, #0xd50
    //     0x11a45d8: ldr             lr, [x21, lr, lsl #3]
    //     0x11a45dc: blr             lr
    // 0x11a45e0: ldur            x2, [fp, #-0x40]
    // 0x11a45e4: LoadField: r0 = r2->field_b
    //     0x11a45e4: ldur            w0, [x2, #0xb]
    // 0x11a45e8: r1 = LoadInt32Instr(r0)
    //     0x11a45e8: sbfx            x1, x0, #1, #0x1f
    // 0x11a45ec: mov             x0, x1
    // 0x11a45f0: ldur            x1, [fp, #-0x28]
    // 0x11a45f4: cmp             x1, x0
    // 0x11a45f8: b.hs            #0x11a46e0
    // 0x11a45fc: LoadField: r0 = r2->field_f
    //     0x11a45fc: ldur            w0, [x2, #0xf]
    // 0x11a4600: DecompressPointer r0
    //     0x11a4600: add             x0, x0, HEAP, lsl #32
    // 0x11a4604: ldur            x1, [fp, #-0x28]
    // 0x11a4608: ArrayLoad: r3 = r0[r1]  ; Unknown_4
    //     0x11a4608: add             x16, x0, x1, lsl #2
    //     0x11a460c: ldur            w3, [x16, #0xf]
    // 0x11a4610: DecompressPointer r3
    //     0x11a4610: add             x3, x3, HEAP, lsl #32
    // 0x11a4614: ldur            x0, [fp, #-0x58]
    // 0x11a4618: stur            x3, [fp, #-0x38]
    // 0x11a461c: r1 = LoadClassIdInstr(r0)
    //     0x11a461c: ldur            x1, [x0, #-1]
    //     0x11a4620: ubfx            x1, x1, #0xc, #0x14
    // 0x11a4624: r16 = <String, Map<String, SerializableCookie>>
    //     0x11a4624: add             x16, PP, #0x82, lsl #12  ; [pp+0x82140] TypeArguments: <String, Map<String, SerializableCookie>>
    //     0x11a4628: ldr             x16, [x16, #0x140]
    // 0x11a462c: stp             x0, x16, [SP]
    // 0x11a4630: mov             x0, x1
    // 0x11a4634: r4 = const [0x2, 0x1, 0x1, 0x1, null]
    //     0x11a4634: ldr             x4, [PP, #0x18e0]  ; [pp+0x18e0] List(5) [0x2, 0x1, 0x1, 0x1, Null]
    // 0x11a4638: r0 = GDT[cid_x0 + 0xfb3]()
    //     0x11a4638: add             lr, x0, #0xfb3
    //     0x11a463c: ldr             lr, [x21, lr, lsl #3]
    //     0x11a4640: blr             lr
    // 0x11a4644: ldur            x1, [fp, #-0x38]
    // 0x11a4648: r2 = LoadClassIdInstr(r1)
    //     0x11a4648: ldur            x2, [x1, #-1]
    //     0x11a464c: ubfx            x2, x2, #0xc, #0x14
    // 0x11a4650: mov             x3, x0
    // 0x11a4654: mov             x0, x2
    // 0x11a4658: ldur            x2, [fp, #-0x10]
    // 0x11a465c: r0 = GDT[cid_x0 + -0xd50]()
    //     0x11a465c: sub             lr, x0, #0xd50
    //     0x11a4660: ldr             lr, [x21, lr, lsl #3]
    //     0x11a4664: blr             lr
    // 0x11a4668: ldur            x4, [fp, #-0x30]
    // 0x11a466c: ldur            x0, [fp, #-0x20]
    // 0x11a4670: ldur            x3, [fp, #-0x40]
    // 0x11a4674: ldur            x2, [fp, #-0x48]
    // 0x11a4678: b               #0x11a41b4
    // 0x11a467c: r0 = Null
    //     0x11a467c: mov             x0, NULL
    // 0x11a4680: r0 = ReturnAsyncNotFuture()
    //     0x11a4680: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x11a4684: r0 = RangeError()
    //     0x11a4684: bl              #0x7db570  ; AllocateRangeErrorStub -> RangeError (size=0x24)
    // 0x11a4688: stur            x0, [fp, #-0x10]
    // 0x11a468c: stp             xzr, x0, [SP, #0x10]
    // 0x11a4690: ldur            x16, [fp, #-0x78]
    // 0x11a4694: stp             x16, xzr, [SP]
    // 0x11a4698: r4 = const [0, 0x4, 0x4, 0x4, null]
    //     0x11a4698: ldr             x4, [PP, #0x9d0]  ; [pp+0x9d0] List(5) [0, 0x4, 0x4, 0x4, Null]
    // 0x11a469c: r0 = RangeError.range()
    //     0x11a469c: bl              #0x7db3f0  ; [dart:core] RangeError::RangeError.range
    // 0x11a46a0: ldur            x0, [fp, #-0x10]
    // 0x11a46a4: r0 = Throw()
    //     0x11a46a4: bl              #0x13ddb2c  ; ThrowStub
    // 0x11a46a8: brk             #0
    // 0x11a46ac: r0 = ConcurrentModificationError()
    //     0x11a46ac: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x11a46b0: mov             x1, x0
    // 0x11a46b4: ldur            x0, [fp, #-0x20]
    // 0x11a46b8: StoreField: r1->field_b = r0
    //     0x11a46b8: stur            w0, [x1, #0xb]
    // 0x11a46bc: mov             x0, x1
    // 0x11a46c0: r0 = Throw()
    //     0x11a46c0: bl              #0x13ddb2c  ; ThrowStub
    // 0x11a46c4: brk             #0
    // 0x11a46c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a46c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a46cc: b               #0x11a4188
    // 0x11a46d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a46d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a46d4: b               #0x11a41c4
    // 0x11a46d8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x11a46d8: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x11a46dc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x11a46dc: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x11a46e0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x11a46e0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ DefaultCookieJar(/* No info */) {
    // ** addr: 0x11fb3a4, size: 0xcc
    // 0x11fb3a4: EnterFrame
    //     0x11fb3a4: stp             fp, lr, [SP, #-0x10]!
    //     0x11fb3a8: mov             fp, SP
    // 0x11fb3ac: AllocStack(0x30)
    //     0x11fb3ac: sub             SP, SP, #0x30
    // 0x11fb3b0: SetupParameters(DefaultCookieJar this /* r1 => r1, fp-0x8 */)
    //     0x11fb3b0: stur            x1, [fp, #-8]
    // 0x11fb3b4: CheckStackOverflow
    //     0x11fb3b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11fb3b8: cmp             SP, x16
    //     0x11fb3bc: b.ls            #0x11fb468
    // 0x11fb3c0: r16 = <String, Map<String, Map<String, SerializableCookie>>>
    //     0x11fb3c0: add             x16, PP, #0xa5, lsl #12  ; [pp+0xa59f8] TypeArguments: <String, Map<String, Map<String, SerializableCookie>>>
    //     0x11fb3c4: ldr             x16, [x16, #0x9f8]
    // 0x11fb3c8: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x11fb3cc: stp             lr, x16, [SP]
    // 0x11fb3d0: r0 = Map._fromLiteral()
    //     0x11fb3d0: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x11fb3d4: stur            x0, [fp, #-0x10]
    // 0x11fb3d8: r16 = <String, Map<String, Map<String, SerializableCookie>>>
    //     0x11fb3d8: add             x16, PP, #0xa5, lsl #12  ; [pp+0xa59f8] TypeArguments: <String, Map<String, Map<String, SerializableCookie>>>
    //     0x11fb3dc: ldr             x16, [x16, #0x9f8]
    // 0x11fb3e0: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x11fb3e4: stp             lr, x16, [SP]
    // 0x11fb3e8: r0 = Map._fromLiteral()
    //     0x11fb3e8: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x11fb3ec: r1 = Null
    //     0x11fb3ec: mov             x1, NULL
    // 0x11fb3f0: r2 = 4
    //     0x11fb3f0: mov             x2, #4
    // 0x11fb3f4: stur            x0, [fp, #-0x18]
    // 0x11fb3f8: r0 = AllocateArray()
    //     0x11fb3f8: bl              #0x13df928  ; AllocateArrayStub
    // 0x11fb3fc: mov             x2, x0
    // 0x11fb400: ldur            x0, [fp, #-0x10]
    // 0x11fb404: stur            x2, [fp, #-0x20]
    // 0x11fb408: StoreField: r2->field_f = r0
    //     0x11fb408: stur            w0, [x2, #0xf]
    // 0x11fb40c: ldur            x0, [fp, #-0x18]
    // 0x11fb410: StoreField: r2->field_13 = r0
    //     0x11fb410: stur            w0, [x2, #0x13]
    // 0x11fb414: r1 = <Map<String, Map<String, Map<String, SerializableCookie>>>>
    //     0x11fb414: add             x1, PP, #0xa5, lsl #12  ; [pp+0xa5a00] TypeArguments: <Map<String, Map<String, Map<String, SerializableCookie>>>>
    //     0x11fb418: ldr             x1, [x1, #0xa00]
    // 0x11fb41c: r0 = AllocateGrowableArray()
    //     0x11fb41c: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x11fb420: ldur            x1, [fp, #-0x20]
    // 0x11fb424: StoreField: r0->field_f = r1
    //     0x11fb424: stur            w1, [x0, #0xf]
    // 0x11fb428: r1 = 4
    //     0x11fb428: mov             x1, #4
    // 0x11fb42c: StoreField: r0->field_b = r1
    //     0x11fb42c: stur            w1, [x0, #0xb]
    // 0x11fb430: ldur            x1, [fp, #-8]
    // 0x11fb434: StoreField: r1->field_b = r0
    //     0x11fb434: stur            w0, [x1, #0xb]
    //     0x11fb438: ldurb           w16, [x1, #-1]
    //     0x11fb43c: ldurb           w17, [x0, #-1]
    //     0x11fb440: and             x16, x17, x16, lsr #2
    //     0x11fb444: tst             x16, HEAP, lsr #32
    //     0x11fb448: b.eq            #0x11fb450
    //     0x11fb44c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11fb450: r2 = false
    //     0x11fb450: add             x2, NULL, #0x30  ; false
    // 0x11fb454: StoreField: r1->field_7 = r2
    //     0x11fb454: stur            w2, [x1, #7]
    // 0x11fb458: r0 = Null
    //     0x11fb458: mov             x0, NULL
    // 0x11fb45c: LeaveFrame
    //     0x11fb45c: mov             SP, fp
    //     0x11fb460: ldp             fp, lr, [SP], #0x10
    // 0x11fb464: ret
    //     0x11fb464: ret             
    // 0x11fb468: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11fb468: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11fb46c: b               #0x11fb3c0
  }
}
