// lib: , url: package:cookie_jar/src/cookie_jar.dart

// class id: 1048666, size: 0x8
class :: {
}

// class id: 3561, size: 0x8, field offset: 0x8
abstract class CookieJar extends Object {

  factory _ CookieJar(/* No info */) {
    // ** addr: 0x11fb364, size: 0x40
    // 0x11fb364: EnterFrame
    //     0x11fb364: stp             fp, lr, [SP, #-0x10]!
    //     0x11fb368: mov             fp, SP
    // 0x11fb36c: AllocStack(0x8)
    //     0x11fb36c: sub             SP, SP, #8
    // 0x11fb370: CheckStackOverflow
    //     0x11fb370: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11fb374: cmp             SP, x16
    //     0x11fb378: b.ls            #0x11fb39c
    // 0x11fb37c: r0 = DefaultCookieJar()
    //     0x11fb37c: bl              #0x11fb470  ; AllocateDefaultCookieJarStub -> DefaultCookieJar (size=0x10)
    // 0x11fb380: mov             x1, x0
    // 0x11fb384: stur            x0, [fp, #-8]
    // 0x11fb388: r0 = DefaultCookieJar()
    //     0x11fb388: bl              #0x11fb3a4  ; [package:cookie_jar/src/jar/default.dart] DefaultCookieJar::DefaultCookieJar
    // 0x11fb38c: ldur            x0, [fp, #-8]
    // 0x11fb390: LeaveFrame
    //     0x11fb390: mov             SP, fp
    //     0x11fb394: ldp             fp, lr, [SP], #0x10
    // 0x11fb398: ret
    //     0x11fb398: ret             
    // 0x11fb39c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11fb39c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11fb3a0: b               #0x11fb37c
  }
}
