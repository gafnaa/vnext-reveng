// lib: , url: package:cookie_jar/src/serializable_cookie.dart

// class id: 1048668, size: 0x8
class :: {
}

// class id: 3559, size: 0x14, field offset: 0x8
class SerializableCookie extends Object {

  _ isExpired(/* No info */) {
    // ** addr: 0xd583a8, size: 0xfc
    // 0xd583a8: EnterFrame
    //     0xd583a8: stp             fp, lr, [SP, #-0x10]!
    //     0xd583ac: mov             fp, SP
    // 0xd583b0: AllocStack(0x10)
    //     0xd583b0: sub             SP, SP, #0x10
    // 0xd583b4: SetupParameters(SerializableCookie this /* r1 => r1, fp-0x8 */)
    //     0xd583b4: stur            x1, [fp, #-8]
    // 0xd583b8: CheckStackOverflow
    //     0xd583b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd583bc: cmp             SP, x16
    //     0xd583c0: b.ls            #0xd5849c
    // 0xd583c4: r0 = DateTime()
    //     0xd583c4: bl              #0x8174b8  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0xd583c8: mov             x1, x0
    // 0xd583cc: r0 = false
    //     0xd583cc: add             x0, NULL, #0x30  ; false
    // 0xd583d0: stur            x1, [fp, #-0x10]
    // 0xd583d4: StoreField: r1->field_7 = r0
    //     0xd583d4: stur            w0, [x1, #7]
    // 0xd583d8: r0 = _getCurrentMicros()
    //     0xd583d8: bl              #0x89fe10  ; [dart:core] DateTime::_getCurrentMicros
    // 0xd583dc: r1 = LoadInt32Instr(r0)
    //     0xd583dc: sbfx            x1, x0, #1, #0x1f
    //     0xd583e0: tbz             w0, #0, #0xd583e8
    //     0xd583e4: ldur            x1, [x0, #7]
    // 0xd583e8: ldur            x2, [fp, #-0x10]
    // 0xd583ec: StoreField: r2->field_b = r1
    //     0xd583ec: stur            x1, [x2, #0xb]
    // 0xd583f0: ldur            x0, [fp, #-8]
    // 0xd583f4: LoadField: r3 = r0->field_7
    //     0xd583f4: ldur            w3, [x0, #7]
    // 0xd583f8: DecompressPointer r3
    //     0xd583f8: add             x3, x3, HEAP, lsl #32
    // 0xd583fc: LoadField: r4 = r3->field_13
    //     0xd583fc: ldur            w4, [x3, #0x13]
    // 0xd58400: DecompressPointer r4
    //     0xd58400: add             x4, x4, HEAP, lsl #32
    // 0xd58404: cmp             w4, NULL
    // 0xd58408: b.eq            #0xd58420
    // 0xd5840c: r5 = LoadInt32Instr(r4)
    //     0xd5840c: sbfx            x5, x4, #1, #0x1f
    //     0xd58410: tbz             w4, #0, #0xd58418
    //     0xd58414: ldur            x5, [x4, #7]
    // 0xd58418: cmp             x5, #1
    // 0xd5841c: b.lt            #0xd58464
    // 0xd58420: cmp             w4, NULL
    // 0xd58424: b.eq            #0xd5846c
    // 0xd58428: tbz             x1, #0x3f, #0xd58434
    // 0xd5842c: r6 = 999
    //     0xd5842c: mov             x6, #0x3e7
    // 0xd58430: b               #0xd58438
    // 0xd58434: r6 = 0
    //     0xd58434: mov             x6, #0
    // 0xd58438: r5 = 1000
    //     0xd58438: mov             x5, #0x3e8
    // 0xd5843c: sub             x7, x1, x6
    // 0xd58440: sdiv            x1, x7, x5
    // 0xd58444: sdiv            x6, x1, x5
    // 0xd58448: LoadField: r1 = r0->field_b
    //     0xd58448: ldur            x1, [x0, #0xb]
    // 0xd5844c: sub             x0, x6, x1
    // 0xd58450: r1 = LoadInt32Instr(r4)
    //     0xd58450: sbfx            x1, x4, #1, #0x1f
    //     0xd58454: tbz             w4, #0, #0xd5845c
    //     0xd58458: ldur            x1, [x4, #7]
    // 0xd5845c: cmp             x0, x1
    // 0xd58460: b.lt            #0xd5846c
    // 0xd58464: r0 = true
    //     0xd58464: add             x0, NULL, #0x20  ; true
    // 0xd58468: b               #0xd58490
    // 0xd5846c: LoadField: r1 = r3->field_f
    //     0xd5846c: ldur            w1, [x3, #0xf]
    // 0xd58470: DecompressPointer r1
    //     0xd58470: add             x1, x1, HEAP, lsl #32
    // 0xd58474: cmp             w1, NULL
    // 0xd58478: b.eq            #0xd5848c
    // 0xd5847c: r0 = isAfter()
    //     0xd5847c: bl              #0xd183d4  ; [dart:core] DateTime::isAfter
    // 0xd58480: eor             x1, x0, #0x10
    // 0xd58484: mov             x0, x1
    // 0xd58488: b               #0xd58490
    // 0xd5848c: r0 = false
    //     0xd5848c: add             x0, NULL, #0x30  ; false
    // 0xd58490: LeaveFrame
    //     0xd58490: mov             SP, fp
    //     0xd58494: ldp             fp, lr, [SP], #0x10
    // 0xd58498: ret
    //     0xd58498: ret             
    // 0xd5849c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd5849c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd584a0: b               #0xd583c4
  }
  String toJson(SerializableCookie) {
    // ** addr: 0xd584bc, size: 0x50
    // 0xd584bc: EnterFrame
    //     0xd584bc: stp             fp, lr, [SP, #-0x10]!
    //     0xd584c0: mov             fp, SP
    // 0xd584c4: AllocStack(0x8)
    //     0xd584c4: sub             SP, SP, #8
    // 0xd584c8: CheckStackOverflow
    //     0xd584c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd584cc: cmp             SP, x16
    //     0xd584d0: b.ls            #0xd584ec
    // 0xd584d4: ldr             x16, [fp, #0x10]
    // 0xd584d8: str             x16, [SP]
    // 0xd584dc: r0 = toString()
    //     0xd584dc: bl              #0x110afe8  ; [package:cookie_jar/src/serializable_cookie.dart] SerializableCookie::toString
    // 0xd584e0: LeaveFrame
    //     0xd584e0: mov             SP, fp
    //     0xd584e4: ldp             fp, lr, [SP], #0x10
    // 0xd584e8: ret
    //     0xd584e8: ret             
    // 0xd584ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd584ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd584f0: b               #0xd584d4
  }
  String toString(SerializableCookie) {
    // ** addr: 0x110afe8, size: 0x88
    // 0x110afe8: EnterFrame
    //     0x110afe8: stp             fp, lr, [SP, #-0x10]!
    //     0x110afec: mov             fp, SP
    // 0x110aff0: AllocStack(0x10)
    //     0x110aff0: sub             SP, SP, #0x10
    // 0x110aff4: CheckStackOverflow
    //     0x110aff4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x110aff8: cmp             SP, x16
    //     0x110affc: b.ls            #0x110b068
    // 0x110b000: ldr             x0, [fp, #0x10]
    // 0x110b004: LoadField: r3 = r0->field_7
    //     0x110b004: ldur            w3, [x0, #7]
    // 0x110b008: DecompressPointer r3
    //     0x110b008: add             x3, x3, HEAP, lsl #32
    // 0x110b00c: stur            x3, [fp, #-8]
    // 0x110b010: r1 = Null
    //     0x110b010: mov             x1, NULL
    // 0x110b014: r2 = 6
    //     0x110b014: mov             x2, #6
    // 0x110b018: r0 = AllocateArray()
    //     0x110b018: bl              #0x13df928  ; AllocateArrayStub
    // 0x110b01c: mov             x2, x0
    // 0x110b020: ldur            x0, [fp, #-8]
    // 0x110b024: StoreField: r2->field_f = r0
    //     0x110b024: stur            w0, [x2, #0xf]
    // 0x110b028: r16 = ";_crt="
    //     0x110b028: add             x16, PP, #0x8a, lsl #12  ; [pp+0x8afe8] ";_crt="
    //     0x110b02c: ldr             x16, [x16, #0xfe8]
    // 0x110b030: StoreField: r2->field_13 = r16
    //     0x110b030: stur            w16, [x2, #0x13]
    // 0x110b034: ldr             x0, [fp, #0x10]
    // 0x110b038: LoadField: r3 = r0->field_b
    //     0x110b038: ldur            x3, [x0, #0xb]
    // 0x110b03c: r0 = BoxInt64Instr(r3)
    //     0x110b03c: sbfiz           x0, x3, #1, #0x1f
    //     0x110b040: cmp             x3, x0, asr #1
    //     0x110b044: b.eq            #0x110b050
    //     0x110b048: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x110b04c: stur            x3, [x0, #7]
    // 0x110b050: ArrayStore: r2[0] = r0  ; List_4
    //     0x110b050: stur            w0, [x2, #0x17]
    // 0x110b054: str             x2, [SP]
    // 0x110b058: r0 = _interpolate()
    //     0x110b058: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x110b05c: LeaveFrame
    //     0x110b05c: mov             SP, fp
    //     0x110b060: ldp             fp, lr, [SP], #0x10
    // 0x110b064: ret
    //     0x110b064: ret             
    // 0x110b068: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x110b068: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x110b06c: b               #0x110b000
  }
}
