// lib: bidi, url: package:bidi/bidi.dart

// class id: 1048615, size: 0x8
class :: {

  static _ getCharacterType(/* No info */) {
    // ** addr: 0x12c0c54, size: 0x60
    // 0x12c0c54: EnterFrame
    //     0x12c0c54: stp             fp, lr, [SP, #-0x10]!
    //     0x12c0c58: mov             fp, SP
    // 0x12c0c5c: mov             x2, x1
    // 0x12c0c60: CheckStackOverflow
    //     0x12c0c60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c0c64: cmp             SP, x16
    //     0x12c0c68: b.ls            #0x12c0cac
    // 0x12c0c6c: r0 = BoxInt64Instr(r2)
    //     0x12c0c6c: sbfiz           x0, x2, #1, #0x1f
    //     0x12c0c70: cmp             x2, x0, asr #1
    //     0x12c0c74: b.eq            #0x12c0c80
    //     0x12c0c78: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12c0c7c: stur            x2, [x0, #7]
    // 0x12c0c80: mov             x2, x0
    // 0x12c0c84: r1 = _ConstMap len:5850
    //     0x12c0c84: add             x1, PP, #0x80, lsl #12  ; [pp+0x80460] Map<int, CharacterType>(5850)
    //     0x12c0c88: ldr             x1, [x1, #0x460]
    // 0x12c0c8c: r0 = []()
    //     0x12c0c8c: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x12c0c90: cmp             w0, NULL
    // 0x12c0c94: b.ne            #0x12c0ca0
    // 0x12c0c98: r0 = Instance_CharacterType
    //     0x12c0c98: add             x0, PP, #0x80, lsl #12  ; [pp+0x804b8] Obj!CharacterType@12c6ee1
    //     0x12c0c9c: ldr             x0, [x0, #0x4b8]
    // 0x12c0ca0: LeaveFrame
    //     0x12c0ca0: mov             SP, fp
    //     0x12c0ca4: ldp             fp, lr, [SP], #0x10
    // 0x12c0ca8: ret
    //     0x12c0ca8: ret             
    // 0x12c0cac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c0cac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c0cb0: b               #0x12c0c6c
  }
  static _ _fixMirroredCharacters(/* No info */) {
    // ** addr: 0x12c1f30, size: 0x12c
    // 0x12c1f30: EnterFrame
    //     0x12c1f30: stp             fp, lr, [SP, #-0x10]!
    //     0x12c1f34: mov             fp, SP
    // 0x12c1f38: AllocStack(0x18)
    //     0x12c1f38: sub             SP, SP, #0x18
    // 0x12c1f3c: SetupParameters(dynamic _ /* r1 => r0, fp-0x18 */)
    //     0x12c1f3c: mov             x0, x1
    //     0x12c1f40: stur            x1, [fp, #-0x18]
    // 0x12c1f44: CheckStackOverflow
    //     0x12c1f44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c1f48: cmp             SP, x16
    //     0x12c1f4c: b.ls            #0x12c2034
    // 0x12c1f50: r2 = 0
    //     0x12c1f50: mov             x2, #0
    // 0x12c1f54: stur            x2, [fp, #-0x10]
    // 0x12c1f58: CheckStackOverflow
    //     0x12c1f58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c1f5c: cmp             SP, x16
    //     0x12c1f60: b.ls            #0x12c203c
    // 0x12c1f64: LoadField: r1 = r0->field_b
    //     0x12c1f64: ldur            w1, [x0, #0xb]
    // 0x12c1f68: r3 = LoadInt32Instr(r1)
    //     0x12c1f68: sbfx            x3, x1, #1, #0x1f
    // 0x12c1f6c: cmp             x2, x3
    // 0x12c1f70: b.ge            #0x12c2024
    // 0x12c1f74: LoadField: r1 = r0->field_f
    //     0x12c1f74: ldur            w1, [x0, #0xf]
    // 0x12c1f78: DecompressPointer r1
    //     0x12c1f78: add             x1, x1, HEAP, lsl #32
    // 0x12c1f7c: ArrayLoad: r3 = r1[r2]  ; Unknown_4
    //     0x12c1f7c: add             x16, x1, x2, lsl #2
    //     0x12c1f80: ldur            w3, [x16, #0xf]
    // 0x12c1f84: DecompressPointer r3
    //     0x12c1f84: add             x3, x3, HEAP, lsl #32
    // 0x12c1f88: stur            x3, [fp, #-8]
    // 0x12c1f8c: LoadField: r1 = r3->field_b
    //     0x12c1f8c: ldur            w1, [x3, #0xb]
    // 0x12c1f90: DecompressPointer r1
    //     0x12c1f90: add             x1, x1, HEAP, lsl #32
    // 0x12c1f94: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12c1f98: cmp             w1, w16
    // 0x12c1f9c: b.eq            #0x12c2044
    // 0x12c1fa0: r4 = LoadInt32Instr(r1)
    //     0x12c1fa0: sbfx            x4, x1, #1, #0x1f
    //     0x12c1fa4: tbz             w1, #0, #0x12c1fac
    //     0x12c1fa8: ldur            x4, [x1, #7]
    // 0x12c1fac: branchIfSmi(r4, 0x12c2014)
    //     0x12c1fac: tbz             w4, #0, #0x12c2014
    // 0x12c1fb0: LoadField: r1 = r3->field_7
    //     0x12c1fb0: ldur            w1, [x3, #7]
    // 0x12c1fb4: DecompressPointer r1
    //     0x12c1fb4: add             x1, x1, HEAP, lsl #32
    // 0x12c1fb8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12c1fbc: cmp             w1, w16
    // 0x12c1fc0: b.eq            #0x12c2050
    // 0x12c1fc4: r4 = LoadInt32Instr(r1)
    //     0x12c1fc4: sbfx            x4, x1, #1, #0x1f
    //     0x12c1fc8: tbz             w1, #0, #0x12c1fd0
    //     0x12c1fcc: ldur            x4, [x1, #7]
    // 0x12c1fd0: mov             x1, x4
    // 0x12c1fd4: r0 = _getCharacterMirror()
    //     0x12c1fd4: bl              #0x12c205c  ; [package:bidi/bidi.dart] ::_getCharacterMirror
    // 0x12c1fd8: mov             x2, x0
    // 0x12c1fdc: r0 = BoxInt64Instr(r2)
    //     0x12c1fdc: sbfiz           x0, x2, #1, #0x1f
    //     0x12c1fe0: cmp             x2, x0, asr #1
    //     0x12c1fe4: b.eq            #0x12c1ff0
    //     0x12c1fe8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12c1fec: stur            x2, [x0, #7]
    // 0x12c1ff0: ldur            x1, [fp, #-8]
    // 0x12c1ff4: StoreField: r1->field_7 = r0
    //     0x12c1ff4: stur            w0, [x1, #7]
    //     0x12c1ff8: tbz             w0, #0, #0x12c2014
    //     0x12c1ffc: ldurb           w16, [x1, #-1]
    //     0x12c2000: ldurb           w17, [x0, #-1]
    //     0x12c2004: and             x16, x17, x16, lsr #2
    //     0x12c2008: tst             x16, HEAP, lsr #32
    //     0x12c200c: b.eq            #0x12c2014
    //     0x12c2010: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x12c2014: ldur            x1, [fp, #-0x10]
    // 0x12c2018: add             x2, x1, #1
    // 0x12c201c: ldur            x0, [fp, #-0x18]
    // 0x12c2020: b               #0x12c1f54
    // 0x12c2024: r0 = Null
    //     0x12c2024: mov             x0, NULL
    // 0x12c2028: LeaveFrame
    //     0x12c2028: mov             SP, fp
    //     0x12c202c: ldp             fp, lr, [SP], #0x10
    // 0x12c2030: ret
    //     0x12c2030: ret             
    // 0x12c2034: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c2034: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c2038: b               #0x12c1f50
    // 0x12c203c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c203c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c2040: b               #0x12c1f64
    // 0x12c2044: r9 = embeddingLevel
    //     0x12c2044: add             x9, PP, #0x80, lsl #12  ; [pp+0x804e8] Field <_CharData@1190396231.embeddingLevel>: late (offset: 0xc)
    //     0x12c2048: ldr             x9, [x9, #0x4e8]
    // 0x12c204c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12c204c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12c2050: r9 = char
    //     0x12c2050: add             x9, PP, #0x80, lsl #12  ; [pp+0x804f0] Field <_CharData@1190396231.char>: late (offset: 0x8)
    //     0x12c2054: ldr             x9, [x9, #0x4f0]
    // 0x12c2058: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12c2058: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  static int _getCharacterMirror(int) {
    // ** addr: 0x12c205c, size: 0x2bfc
    // 0x12c205c: EnterFrame
    //     0x12c205c: stp             fp, lr, [SP, #-0x10]!
    //     0x12c2060: mov             fp, SP
    // 0x12c2064: mov             x2, x1
    // 0x12c2068: r17 = 10221
    //     0x12c2068: mov             x17, #0x27ed
    // 0x12c206c: cmp             x2, x17
    // 0x12c2070: b.gt            #0x12c3620
    // 0x12c2074: r17 = 8883
    //     0x12c2074: mov             x17, #0x22b3
    // 0x12c2078: cmp             x2, x17
    // 0x12c207c: b.gt            #0x12c2b78
    // 0x12c2080: r17 = 8811
    //     0x12c2080: mov             x17, #0x226b
    // 0x12c2084: cmp             x2, x17
    // 0x12c2088: b.gt            #0x12c2638
    // 0x12c208c: r17 = 8333
    //     0x12c208c: mov             x17, #0x208d
    // 0x12c2090: cmp             x2, x17
    // 0x12c2094: b.gt            #0x12c2378
    // 0x12c2098: cmp             x2, #0xf3b
    // 0x12c209c: b.gt            #0x12c221c
    // 0x12c20a0: cmp             x2, #0x5d
    // 0x12c20a4: b.gt            #0x12c216c
    // 0x12c20a8: cmp             x2, #0x3c
    // 0x12c20ac: b.gt            #0x12c2114
    // 0x12c20b0: cmp             x2, #0x29
    // 0x12c20b4: b.gt            #0x12c20fc
    // 0x12c20b8: cmp             x2, #0x28
    // 0x12c20bc: b.gt            #0x12c20ec
    // 0x12c20c0: r0 = BoxInt64Instr(r2)
    //     0x12c20c0: sbfiz           x0, x2, #1, #0x1f
    //     0x12c20c4: cmp             x2, x0, asr #1
    //     0x12c20c8: b.eq            #0x12c20d4
    //     0x12c20cc: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12c20d0: stur            x2, [x0, #7]
    // 0x12c20d4: cmp             w0, #0x50
    // 0x12c20d8: b.ne            #0x12c4c48
    // 0x12c20dc: r0 = 41
    //     0x12c20dc: mov             x0, #0x29
    // 0x12c20e0: LeaveFrame
    //     0x12c20e0: mov             SP, fp
    //     0x12c20e4: ldp             fp, lr, [SP], #0x10
    // 0x12c20e8: ret
    //     0x12c20e8: ret             
    // 0x12c20ec: r0 = 40
    //     0x12c20ec: mov             x0, #0x28
    // 0x12c20f0: LeaveFrame
    //     0x12c20f0: mov             SP, fp
    //     0x12c20f4: ldp             fp, lr, [SP], #0x10
    // 0x12c20f8: ret
    //     0x12c20f8: ret             
    // 0x12c20fc: cmp             x2, #0x3c
    // 0x12c2100: b.lt            #0x12c4c48
    // 0x12c2104: r0 = 62
    //     0x12c2104: mov             x0, #0x3e
    // 0x12c2108: LeaveFrame
    //     0x12c2108: mov             SP, fp
    //     0x12c210c: ldp             fp, lr, [SP], #0x10
    // 0x12c2110: ret
    //     0x12c2110: ret             
    // 0x12c2114: cmp             x2, #0x3e
    // 0x12c2118: b.lt            #0x12c4c48
    // 0x12c211c: cmp             x2, #0x5b
    // 0x12c2120: b.gt            #0x12c2154
    // 0x12c2124: cmp             x2, #0x3e
    // 0x12c2128: b.gt            #0x12c213c
    // 0x12c212c: r0 = 60
    //     0x12c212c: mov             x0, #0x3c
    // 0x12c2130: LeaveFrame
    //     0x12c2130: mov             SP, fp
    //     0x12c2134: ldp             fp, lr, [SP], #0x10
    // 0x12c2138: ret
    //     0x12c2138: ret             
    // 0x12c213c: cmp             x2, #0x5b
    // 0x12c2140: b.lt            #0x12c4c48
    // 0x12c2144: r0 = 93
    //     0x12c2144: mov             x0, #0x5d
    // 0x12c2148: LeaveFrame
    //     0x12c2148: mov             SP, fp
    //     0x12c214c: ldp             fp, lr, [SP], #0x10
    // 0x12c2150: ret
    //     0x12c2150: ret             
    // 0x12c2154: cmp             x2, #0x5d
    // 0x12c2158: b.lt            #0x12c4c48
    // 0x12c215c: r0 = 91
    //     0x12c215c: mov             x0, #0x5b
    // 0x12c2160: LeaveFrame
    //     0x12c2160: mov             SP, fp
    //     0x12c2164: ldp             fp, lr, [SP], #0x10
    // 0x12c2168: ret
    //     0x12c2168: ret             
    // 0x12c216c: cmp             x2, #0x7b
    // 0x12c2170: b.lt            #0x12c4c48
    // 0x12c2174: cmp             x2, #0xab
    // 0x12c2178: b.gt            #0x12c21cc
    // 0x12c217c: cmp             x2, #0x7d
    // 0x12c2180: b.gt            #0x12c21b4
    // 0x12c2184: cmp             x2, #0x7b
    // 0x12c2188: b.gt            #0x12c219c
    // 0x12c218c: r0 = 125
    //     0x12c218c: mov             x0, #0x7d
    // 0x12c2190: LeaveFrame
    //     0x12c2190: mov             SP, fp
    //     0x12c2194: ldp             fp, lr, [SP], #0x10
    // 0x12c2198: ret
    //     0x12c2198: ret             
    // 0x12c219c: cmp             x2, #0x7d
    // 0x12c21a0: b.lt            #0x12c4c48
    // 0x12c21a4: r0 = 123
    //     0x12c21a4: mov             x0, #0x7b
    // 0x12c21a8: LeaveFrame
    //     0x12c21a8: mov             SP, fp
    //     0x12c21ac: ldp             fp, lr, [SP], #0x10
    // 0x12c21b0: ret
    //     0x12c21b0: ret             
    // 0x12c21b4: cmp             x2, #0xab
    // 0x12c21b8: b.lt            #0x12c4c48
    // 0x12c21bc: r0 = 187
    //     0x12c21bc: mov             x0, #0xbb
    // 0x12c21c0: LeaveFrame
    //     0x12c21c0: mov             SP, fp
    //     0x12c21c4: ldp             fp, lr, [SP], #0x10
    // 0x12c21c8: ret
    //     0x12c21c8: ret             
    // 0x12c21cc: cmp             x2, #0xbb
    // 0x12c21d0: b.lt            #0x12c4c48
    // 0x12c21d4: cmp             x2, #0xf3a
    // 0x12c21d8: b.gt            #0x12c220c
    // 0x12c21dc: cmp             x2, #0xbb
    // 0x12c21e0: b.gt            #0x12c21f4
    // 0x12c21e4: r0 = 171
    //     0x12c21e4: mov             x0, #0xab
    // 0x12c21e8: LeaveFrame
    //     0x12c21e8: mov             SP, fp
    //     0x12c21ec: ldp             fp, lr, [SP], #0x10
    // 0x12c21f0: ret
    //     0x12c21f0: ret             
    // 0x12c21f4: cmp             x2, #0xf3a
    // 0x12c21f8: b.lt            #0x12c4c48
    // 0x12c21fc: r0 = 3899
    //     0x12c21fc: mov             x0, #0xf3b
    // 0x12c2200: LeaveFrame
    //     0x12c2200: mov             SP, fp
    //     0x12c2204: ldp             fp, lr, [SP], #0x10
    // 0x12c2208: ret
    //     0x12c2208: ret             
    // 0x12c220c: r0 = 3898
    //     0x12c220c: mov             x0, #0xf3a
    // 0x12c2210: LeaveFrame
    //     0x12c2210: mov             SP, fp
    //     0x12c2214: ldp             fp, lr, [SP], #0x10
    // 0x12c2218: ret
    //     0x12c2218: ret             
    // 0x12c221c: r17 = 8250
    //     0x12c221c: mov             x17, #0x203a
    // 0x12c2220: cmp             x2, x17
    // 0x12c2224: b.gt            #0x12c22d4
    // 0x12c2228: r17 = 5787
    //     0x12c2228: mov             x17, #0x169b
    // 0x12c222c: cmp             x2, x17
    // 0x12c2230: b.gt            #0x12c2280
    // 0x12c2234: cmp             x2, #0xf3d
    // 0x12c2238: b.gt            #0x12c2264
    // 0x12c223c: cmp             x2, #0xf3c
    // 0x12c2240: b.gt            #0x12c2254
    // 0x12c2244: r0 = 3901
    //     0x12c2244: mov             x0, #0xf3d
    // 0x12c2248: LeaveFrame
    //     0x12c2248: mov             SP, fp
    //     0x12c224c: ldp             fp, lr, [SP], #0x10
    // 0x12c2250: ret
    //     0x12c2250: ret             
    // 0x12c2254: r0 = 3900
    //     0x12c2254: mov             x0, #0xf3c
    // 0x12c2258: LeaveFrame
    //     0x12c2258: mov             SP, fp
    //     0x12c225c: ldp             fp, lr, [SP], #0x10
    // 0x12c2260: ret
    //     0x12c2260: ret             
    // 0x12c2264: r17 = 5787
    //     0x12c2264: mov             x17, #0x169b
    // 0x12c2268: cmp             x2, x17
    // 0x12c226c: b.lt            #0x12c4c48
    // 0x12c2270: r0 = 5788
    //     0x12c2270: mov             x0, #0x169c
    // 0x12c2274: LeaveFrame
    //     0x12c2274: mov             SP, fp
    //     0x12c2278: ldp             fp, lr, [SP], #0x10
    // 0x12c227c: ret
    //     0x12c227c: ret             
    // 0x12c2280: r17 = 8249
    //     0x12c2280: mov             x17, #0x2039
    // 0x12c2284: cmp             x2, x17
    // 0x12c2288: b.gt            #0x12c22c4
    // 0x12c228c: r17 = 5788
    //     0x12c228c: mov             x17, #0x169c
    // 0x12c2290: cmp             x2, x17
    // 0x12c2294: b.gt            #0x12c22a8
    // 0x12c2298: r0 = 5787
    //     0x12c2298: mov             x0, #0x169b
    // 0x12c229c: LeaveFrame
    //     0x12c229c: mov             SP, fp
    //     0x12c22a0: ldp             fp, lr, [SP], #0x10
    // 0x12c22a4: ret
    //     0x12c22a4: ret             
    // 0x12c22a8: r17 = 8249
    //     0x12c22a8: mov             x17, #0x2039
    // 0x12c22ac: cmp             x2, x17
    // 0x12c22b0: b.lt            #0x12c4c48
    // 0x12c22b4: r0 = 8250
    //     0x12c22b4: mov             x0, #0x203a
    // 0x12c22b8: LeaveFrame
    //     0x12c22b8: mov             SP, fp
    //     0x12c22bc: ldp             fp, lr, [SP], #0x10
    // 0x12c22c0: ret
    //     0x12c22c0: ret             
    // 0x12c22c4: r0 = 8249
    //     0x12c22c4: mov             x0, #0x2039
    // 0x12c22c8: LeaveFrame
    //     0x12c22c8: mov             SP, fp
    //     0x12c22cc: ldp             fp, lr, [SP], #0x10
    // 0x12c22d0: ret
    //     0x12c22d0: ret             
    // 0x12c22d4: r17 = 8261
    //     0x12c22d4: mov             x17, #0x2045
    // 0x12c22d8: cmp             x2, x17
    // 0x12c22dc: b.lt            #0x12c4c48
    // 0x12c22e0: r17 = 8317
    //     0x12c22e0: mov             x17, #0x207d
    // 0x12c22e4: cmp             x2, x17
    // 0x12c22e8: b.gt            #0x12c2340
    // 0x12c22ec: r17 = 8262
    //     0x12c22ec: mov             x17, #0x2046
    // 0x12c22f0: cmp             x2, x17
    // 0x12c22f4: b.gt            #0x12c2324
    // 0x12c22f8: r17 = 8261
    //     0x12c22f8: mov             x17, #0x2045
    // 0x12c22fc: cmp             x2, x17
    // 0x12c2300: b.gt            #0x12c2314
    // 0x12c2304: r0 = 8262
    //     0x12c2304: mov             x0, #0x2046
    // 0x12c2308: LeaveFrame
    //     0x12c2308: mov             SP, fp
    //     0x12c230c: ldp             fp, lr, [SP], #0x10
    // 0x12c2310: ret
    //     0x12c2310: ret             
    // 0x12c2314: r0 = 8261
    //     0x12c2314: mov             x0, #0x2045
    // 0x12c2318: LeaveFrame
    //     0x12c2318: mov             SP, fp
    //     0x12c231c: ldp             fp, lr, [SP], #0x10
    // 0x12c2320: ret
    //     0x12c2320: ret             
    // 0x12c2324: r17 = 8317
    //     0x12c2324: mov             x17, #0x207d
    // 0x12c2328: cmp             x2, x17
    // 0x12c232c: b.lt            #0x12c4c48
    // 0x12c2330: r0 = 8318
    //     0x12c2330: mov             x0, #0x207e
    // 0x12c2334: LeaveFrame
    //     0x12c2334: mov             SP, fp
    //     0x12c2338: ldp             fp, lr, [SP], #0x10
    // 0x12c233c: ret
    //     0x12c233c: ret             
    // 0x12c2340: r17 = 8318
    //     0x12c2340: mov             x17, #0x207e
    // 0x12c2344: cmp             x2, x17
    // 0x12c2348: b.gt            #0x12c235c
    // 0x12c234c: r0 = 8317
    //     0x12c234c: mov             x0, #0x207d
    // 0x12c2350: LeaveFrame
    //     0x12c2350: mov             SP, fp
    //     0x12c2354: ldp             fp, lr, [SP], #0x10
    // 0x12c2358: ret
    //     0x12c2358: ret             
    // 0x12c235c: r17 = 8333
    //     0x12c235c: mov             x17, #0x208d
    // 0x12c2360: cmp             x2, x17
    // 0x12c2364: b.lt            #0x12c4c48
    // 0x12c2368: r0 = 8334
    //     0x12c2368: mov             x0, #0x208e
    // 0x12c236c: LeaveFrame
    //     0x12c236c: mov             SP, fp
    //     0x12c2370: ldp             fp, lr, [SP], #0x10
    // 0x12c2374: ret
    //     0x12c2374: ret             
    // 0x12c2378: r17 = 8786
    //     0x12c2378: mov             x17, #0x2252
    // 0x12c237c: cmp             x2, x17
    // 0x12c2380: b.gt            #0x12c2504
    // 0x12c2384: r17 = 8716
    //     0x12c2384: mov             x17, #0x220c
    // 0x12c2388: cmp             x2, x17
    // 0x12c238c: b.gt            #0x12c2438
    // 0x12c2390: r17 = 8713
    //     0x12c2390: mov             x17, #0x2209
    // 0x12c2394: cmp             x2, x17
    // 0x12c2398: b.gt            #0x12c23f0
    // 0x12c239c: r17 = 8712
    //     0x12c239c: mov             x17, #0x2208
    // 0x12c23a0: cmp             x2, x17
    // 0x12c23a4: b.gt            #0x12c23e0
    // 0x12c23a8: r17 = 8334
    //     0x12c23a8: mov             x17, #0x208e
    // 0x12c23ac: cmp             x2, x17
    // 0x12c23b0: b.gt            #0x12c23c4
    // 0x12c23b4: r0 = 8333
    //     0x12c23b4: mov             x0, #0x208d
    // 0x12c23b8: LeaveFrame
    //     0x12c23b8: mov             SP, fp
    //     0x12c23bc: ldp             fp, lr, [SP], #0x10
    // 0x12c23c0: ret
    //     0x12c23c0: ret             
    // 0x12c23c4: r17 = 8712
    //     0x12c23c4: mov             x17, #0x2208
    // 0x12c23c8: cmp             x2, x17
    // 0x12c23cc: b.lt            #0x12c4c48
    // 0x12c23d0: r0 = 8715
    //     0x12c23d0: mov             x0, #0x220b
    // 0x12c23d4: LeaveFrame
    //     0x12c23d4: mov             SP, fp
    //     0x12c23d8: ldp             fp, lr, [SP], #0x10
    // 0x12c23dc: ret
    //     0x12c23dc: ret             
    // 0x12c23e0: r0 = 8716
    //     0x12c23e0: mov             x0, #0x220c
    // 0x12c23e4: LeaveFrame
    //     0x12c23e4: mov             SP, fp
    //     0x12c23e8: ldp             fp, lr, [SP], #0x10
    // 0x12c23ec: ret
    //     0x12c23ec: ret             
    // 0x12c23f0: r17 = 8715
    //     0x12c23f0: mov             x17, #0x220b
    // 0x12c23f4: cmp             x2, x17
    // 0x12c23f8: b.gt            #0x12c2428
    // 0x12c23fc: r17 = 8714
    //     0x12c23fc: mov             x17, #0x220a
    // 0x12c2400: cmp             x2, x17
    // 0x12c2404: b.gt            #0x12c2418
    // 0x12c2408: r0 = 8717
    //     0x12c2408: mov             x0, #0x220d
    // 0x12c240c: LeaveFrame
    //     0x12c240c: mov             SP, fp
    //     0x12c2410: ldp             fp, lr, [SP], #0x10
    // 0x12c2414: ret
    //     0x12c2414: ret             
    // 0x12c2418: r0 = 8712
    //     0x12c2418: mov             x0, #0x2208
    // 0x12c241c: LeaveFrame
    //     0x12c241c: mov             SP, fp
    //     0x12c2420: ldp             fp, lr, [SP], #0x10
    // 0x12c2424: ret
    //     0x12c2424: ret             
    // 0x12c2428: r0 = 8713
    //     0x12c2428: mov             x0, #0x2209
    // 0x12c242c: LeaveFrame
    //     0x12c242c: mov             SP, fp
    //     0x12c2430: ldp             fp, lr, [SP], #0x10
    // 0x12c2434: ret
    //     0x12c2434: ret             
    // 0x12c2438: r17 = 8764
    //     0x12c2438: mov             x17, #0x223c
    // 0x12c243c: cmp             x2, x17
    // 0x12c2440: b.gt            #0x12c24a4
    // 0x12c2444: r17 = 8725
    //     0x12c2444: mov             x17, #0x2215
    // 0x12c2448: cmp             x2, x17
    // 0x12c244c: b.gt            #0x12c2488
    // 0x12c2450: r17 = 8717
    //     0x12c2450: mov             x17, #0x220d
    // 0x12c2454: cmp             x2, x17
    // 0x12c2458: b.gt            #0x12c246c
    // 0x12c245c: r0 = 8714
    //     0x12c245c: mov             x0, #0x220a
    // 0x12c2460: LeaveFrame
    //     0x12c2460: mov             SP, fp
    //     0x12c2464: ldp             fp, lr, [SP], #0x10
    // 0x12c2468: ret
    //     0x12c2468: ret             
    // 0x12c246c: r17 = 8725
    //     0x12c246c: mov             x17, #0x2215
    // 0x12c2470: cmp             x2, x17
    // 0x12c2474: b.lt            #0x12c4c48
    // 0x12c2478: r0 = 10741
    //     0x12c2478: mov             x0, #0x29f5
    // 0x12c247c: LeaveFrame
    //     0x12c247c: mov             SP, fp
    //     0x12c2480: ldp             fp, lr, [SP], #0x10
    // 0x12c2484: ret
    //     0x12c2484: ret             
    // 0x12c2488: r17 = 8764
    //     0x12c2488: mov             x17, #0x223c
    // 0x12c248c: cmp             x2, x17
    // 0x12c2490: b.lt            #0x12c4c48
    // 0x12c2494: r0 = 8765
    //     0x12c2494: mov             x0, #0x223d
    // 0x12c2498: LeaveFrame
    //     0x12c2498: mov             SP, fp
    //     0x12c249c: ldp             fp, lr, [SP], #0x10
    // 0x12c24a0: ret
    //     0x12c24a0: ret             
    // 0x12c24a4: r17 = 8771
    //     0x12c24a4: mov             x17, #0x2243
    // 0x12c24a8: cmp             x2, x17
    // 0x12c24ac: b.gt            #0x12c24e8
    // 0x12c24b0: r17 = 8765
    //     0x12c24b0: mov             x17, #0x223d
    // 0x12c24b4: cmp             x2, x17
    // 0x12c24b8: b.gt            #0x12c24cc
    // 0x12c24bc: r0 = 8764
    //     0x12c24bc: mov             x0, #0x223c
    // 0x12c24c0: LeaveFrame
    //     0x12c24c0: mov             SP, fp
    //     0x12c24c4: ldp             fp, lr, [SP], #0x10
    // 0x12c24c8: ret
    //     0x12c24c8: ret             
    // 0x12c24cc: r17 = 8771
    //     0x12c24cc: mov             x17, #0x2243
    // 0x12c24d0: cmp             x2, x17
    // 0x12c24d4: b.lt            #0x12c4c48
    // 0x12c24d8: r0 = 8909
    //     0x12c24d8: mov             x0, #0x22cd
    // 0x12c24dc: LeaveFrame
    //     0x12c24dc: mov             SP, fp
    //     0x12c24e0: ldp             fp, lr, [SP], #0x10
    // 0x12c24e4: ret
    //     0x12c24e4: ret             
    // 0x12c24e8: r17 = 8786
    //     0x12c24e8: mov             x17, #0x2252
    // 0x12c24ec: cmp             x2, x17
    // 0x12c24f0: b.lt            #0x12c4c48
    // 0x12c24f4: r0 = 8787
    //     0x12c24f4: mov             x0, #0x2253
    // 0x12c24f8: LeaveFrame
    //     0x12c24f8: mov             SP, fp
    //     0x12c24fc: ldp             fp, lr, [SP], #0x10
    // 0x12c2500: ret
    //     0x12c2500: ret             
    // 0x12c2504: r17 = 8806
    //     0x12c2504: mov             x17, #0x2266
    // 0x12c2508: cmp             x2, x17
    // 0x12c250c: b.gt            #0x12c25b8
    // 0x12c2510: r17 = 8789
    //     0x12c2510: mov             x17, #0x2255
    // 0x12c2514: cmp             x2, x17
    // 0x12c2518: b.gt            #0x12c2564
    // 0x12c251c: r17 = 8788
    //     0x12c251c: mov             x17, #0x2254
    // 0x12c2520: cmp             x2, x17
    // 0x12c2524: b.gt            #0x12c2554
    // 0x12c2528: r17 = 8787
    //     0x12c2528: mov             x17, #0x2253
    // 0x12c252c: cmp             x2, x17
    // 0x12c2530: b.gt            #0x12c2544
    // 0x12c2534: r0 = 8786
    //     0x12c2534: mov             x0, #0x2252
    // 0x12c2538: LeaveFrame
    //     0x12c2538: mov             SP, fp
    //     0x12c253c: ldp             fp, lr, [SP], #0x10
    // 0x12c2540: ret
    //     0x12c2540: ret             
    // 0x12c2544: r0 = 8789
    //     0x12c2544: mov             x0, #0x2255
    // 0x12c2548: LeaveFrame
    //     0x12c2548: mov             SP, fp
    //     0x12c254c: ldp             fp, lr, [SP], #0x10
    // 0x12c2550: ret
    //     0x12c2550: ret             
    // 0x12c2554: r0 = 8788
    //     0x12c2554: mov             x0, #0x2254
    // 0x12c2558: LeaveFrame
    //     0x12c2558: mov             SP, fp
    //     0x12c255c: ldp             fp, lr, [SP], #0x10
    // 0x12c2560: ret
    //     0x12c2560: ret             
    // 0x12c2564: r17 = 8804
    //     0x12c2564: mov             x17, #0x2264
    // 0x12c2568: cmp             x2, x17
    // 0x12c256c: b.lt            #0x12c4c48
    // 0x12c2570: r17 = 8805
    //     0x12c2570: mov             x17, #0x2265
    // 0x12c2574: cmp             x2, x17
    // 0x12c2578: b.gt            #0x12c25a8
    // 0x12c257c: r17 = 8804
    //     0x12c257c: mov             x17, #0x2264
    // 0x12c2580: cmp             x2, x17
    // 0x12c2584: b.gt            #0x12c2598
    // 0x12c2588: r0 = 8805
    //     0x12c2588: mov             x0, #0x2265
    // 0x12c258c: LeaveFrame
    //     0x12c258c: mov             SP, fp
    //     0x12c2590: ldp             fp, lr, [SP], #0x10
    // 0x12c2594: ret
    //     0x12c2594: ret             
    // 0x12c2598: r0 = 8804
    //     0x12c2598: mov             x0, #0x2264
    // 0x12c259c: LeaveFrame
    //     0x12c259c: mov             SP, fp
    //     0x12c25a0: ldp             fp, lr, [SP], #0x10
    // 0x12c25a4: ret
    //     0x12c25a4: ret             
    // 0x12c25a8: r0 = 8807
    //     0x12c25a8: mov             x0, #0x2267
    // 0x12c25ac: LeaveFrame
    //     0x12c25ac: mov             SP, fp
    //     0x12c25b0: ldp             fp, lr, [SP], #0x10
    // 0x12c25b4: ret
    //     0x12c25b4: ret             
    // 0x12c25b8: r17 = 8809
    //     0x12c25b8: mov             x17, #0x2269
    // 0x12c25bc: cmp             x2, x17
    // 0x12c25c0: b.gt            #0x12c260c
    // 0x12c25c4: r17 = 8808
    //     0x12c25c4: mov             x17, #0x2268
    // 0x12c25c8: cmp             x2, x17
    // 0x12c25cc: b.gt            #0x12c25fc
    // 0x12c25d0: r17 = 8807
    //     0x12c25d0: mov             x17, #0x2267
    // 0x12c25d4: cmp             x2, x17
    // 0x12c25d8: b.gt            #0x12c25ec
    // 0x12c25dc: r0 = 8806
    //     0x12c25dc: mov             x0, #0x2266
    // 0x12c25e0: LeaveFrame
    //     0x12c25e0: mov             SP, fp
    //     0x12c25e4: ldp             fp, lr, [SP], #0x10
    // 0x12c25e8: ret
    //     0x12c25e8: ret             
    // 0x12c25ec: r0 = 8809
    //     0x12c25ec: mov             x0, #0x2269
    // 0x12c25f0: LeaveFrame
    //     0x12c25f0: mov             SP, fp
    //     0x12c25f4: ldp             fp, lr, [SP], #0x10
    // 0x12c25f8: ret
    //     0x12c25f8: ret             
    // 0x12c25fc: r0 = 8808
    //     0x12c25fc: mov             x0, #0x2268
    // 0x12c2600: LeaveFrame
    //     0x12c2600: mov             SP, fp
    //     0x12c2604: ldp             fp, lr, [SP], #0x10
    // 0x12c2608: ret
    //     0x12c2608: ret             
    // 0x12c260c: r17 = 8810
    //     0x12c260c: mov             x17, #0x226a
    // 0x12c2610: cmp             x2, x17
    // 0x12c2614: b.gt            #0x12c2628
    // 0x12c2618: r0 = 8811
    //     0x12c2618: mov             x0, #0x226b
    // 0x12c261c: LeaveFrame
    //     0x12c261c: mov             SP, fp
    //     0x12c2620: ldp             fp, lr, [SP], #0x10
    // 0x12c2624: ret
    //     0x12c2624: ret             
    // 0x12c2628: r0 = 8810
    //     0x12c2628: mov             x0, #0x226a
    // 0x12c262c: LeaveFrame
    //     0x12c262c: mov             SP, fp
    //     0x12c2630: ldp             fp, lr, [SP], #0x10
    // 0x12c2634: ret
    //     0x12c2634: ret             
    // 0x12c2638: r17 = 8814
    //     0x12c2638: mov             x17, #0x226e
    // 0x12c263c: cmp             x2, x17
    // 0x12c2640: b.lt            #0x12c4c48
    // 0x12c2644: r17 = 8836
    //     0x12c2644: mov             x17, #0x2284
    // 0x12c2648: cmp             x2, x17
    // 0x12c264c: b.gt            #0x12c28c8
    // 0x12c2650: r17 = 8825
    //     0x12c2650: mov             x17, #0x2279
    // 0x12c2654: cmp             x2, x17
    // 0x12c2658: b.gt            #0x12c27a0
    // 0x12c265c: r17 = 8819
    //     0x12c265c: mov             x17, #0x2273
    // 0x12c2660: cmp             x2, x17
    // 0x12c2664: b.gt            #0x12c2704
    // 0x12c2668: r17 = 8816
    //     0x12c2668: mov             x17, #0x2270
    // 0x12c266c: cmp             x2, x17
    // 0x12c2670: b.gt            #0x12c26bc
    // 0x12c2674: r17 = 8815
    //     0x12c2674: mov             x17, #0x226f
    // 0x12c2678: cmp             x2, x17
    // 0x12c267c: b.gt            #0x12c26ac
    // 0x12c2680: r17 = 8814
    //     0x12c2680: mov             x17, #0x226e
    // 0x12c2684: cmp             x2, x17
    // 0x12c2688: b.gt            #0x12c269c
    // 0x12c268c: r0 = 8815
    //     0x12c268c: mov             x0, #0x226f
    // 0x12c2690: LeaveFrame
    //     0x12c2690: mov             SP, fp
    //     0x12c2694: ldp             fp, lr, [SP], #0x10
    // 0x12c2698: ret
    //     0x12c2698: ret             
    // 0x12c269c: r0 = 8814
    //     0x12c269c: mov             x0, #0x226e
    // 0x12c26a0: LeaveFrame
    //     0x12c26a0: mov             SP, fp
    //     0x12c26a4: ldp             fp, lr, [SP], #0x10
    // 0x12c26a8: ret
    //     0x12c26a8: ret             
    // 0x12c26ac: r0 = 8817
    //     0x12c26ac: mov             x0, #0x2271
    // 0x12c26b0: LeaveFrame
    //     0x12c26b0: mov             SP, fp
    //     0x12c26b4: ldp             fp, lr, [SP], #0x10
    // 0x12c26b8: ret
    //     0x12c26b8: ret             
    // 0x12c26bc: r17 = 8818
    //     0x12c26bc: mov             x17, #0x2272
    // 0x12c26c0: cmp             x2, x17
    // 0x12c26c4: b.gt            #0x12c26f4
    // 0x12c26c8: r17 = 8817
    //     0x12c26c8: mov             x17, #0x2271
    // 0x12c26cc: cmp             x2, x17
    // 0x12c26d0: b.gt            #0x12c26e4
    // 0x12c26d4: r0 = 8816
    //     0x12c26d4: mov             x0, #0x2270
    // 0x12c26d8: LeaveFrame
    //     0x12c26d8: mov             SP, fp
    //     0x12c26dc: ldp             fp, lr, [SP], #0x10
    // 0x12c26e0: ret
    //     0x12c26e0: ret             
    // 0x12c26e4: r0 = 8819
    //     0x12c26e4: mov             x0, #0x2273
    // 0x12c26e8: LeaveFrame
    //     0x12c26e8: mov             SP, fp
    //     0x12c26ec: ldp             fp, lr, [SP], #0x10
    // 0x12c26f0: ret
    //     0x12c26f0: ret             
    // 0x12c26f4: r0 = 8818
    //     0x12c26f4: mov             x0, #0x2272
    // 0x12c26f8: LeaveFrame
    //     0x12c26f8: mov             SP, fp
    //     0x12c26fc: ldp             fp, lr, [SP], #0x10
    // 0x12c2700: ret
    //     0x12c2700: ret             
    // 0x12c2704: r17 = 8822
    //     0x12c2704: mov             x17, #0x2276
    // 0x12c2708: cmp             x2, x17
    // 0x12c270c: b.gt            #0x12c2758
    // 0x12c2710: r17 = 8821
    //     0x12c2710: mov             x17, #0x2275
    // 0x12c2714: cmp             x2, x17
    // 0x12c2718: b.gt            #0x12c2748
    // 0x12c271c: r17 = 8820
    //     0x12c271c: mov             x17, #0x2274
    // 0x12c2720: cmp             x2, x17
    // 0x12c2724: b.gt            #0x12c2738
    // 0x12c2728: r0 = 8821
    //     0x12c2728: mov             x0, #0x2275
    // 0x12c272c: LeaveFrame
    //     0x12c272c: mov             SP, fp
    //     0x12c2730: ldp             fp, lr, [SP], #0x10
    // 0x12c2734: ret
    //     0x12c2734: ret             
    // 0x12c2738: r0 = 8820
    //     0x12c2738: mov             x0, #0x2274
    // 0x12c273c: LeaveFrame
    //     0x12c273c: mov             SP, fp
    //     0x12c2740: ldp             fp, lr, [SP], #0x10
    // 0x12c2744: ret
    //     0x12c2744: ret             
    // 0x12c2748: r0 = 8823
    //     0x12c2748: mov             x0, #0x2277
    // 0x12c274c: LeaveFrame
    //     0x12c274c: mov             SP, fp
    //     0x12c2750: ldp             fp, lr, [SP], #0x10
    // 0x12c2754: ret
    //     0x12c2754: ret             
    // 0x12c2758: r17 = 8824
    //     0x12c2758: mov             x17, #0x2278
    // 0x12c275c: cmp             x2, x17
    // 0x12c2760: b.gt            #0x12c2790
    // 0x12c2764: r17 = 8823
    //     0x12c2764: mov             x17, #0x2277
    // 0x12c2768: cmp             x2, x17
    // 0x12c276c: b.gt            #0x12c2780
    // 0x12c2770: r0 = 8822
    //     0x12c2770: mov             x0, #0x2276
    // 0x12c2774: LeaveFrame
    //     0x12c2774: mov             SP, fp
    //     0x12c2778: ldp             fp, lr, [SP], #0x10
    // 0x12c277c: ret
    //     0x12c277c: ret             
    // 0x12c2780: r0 = 8825
    //     0x12c2780: mov             x0, #0x2279
    // 0x12c2784: LeaveFrame
    //     0x12c2784: mov             SP, fp
    //     0x12c2788: ldp             fp, lr, [SP], #0x10
    // 0x12c278c: ret
    //     0x12c278c: ret             
    // 0x12c2790: r0 = 8824
    //     0x12c2790: mov             x0, #0x2278
    // 0x12c2794: LeaveFrame
    //     0x12c2794: mov             SP, fp
    //     0x12c2798: ldp             fp, lr, [SP], #0x10
    // 0x12c279c: ret
    //     0x12c279c: ret             
    // 0x12c27a0: r17 = 8831
    //     0x12c27a0: mov             x17, #0x227f
    // 0x12c27a4: cmp             x2, x17
    // 0x12c27a8: b.gt            #0x12c2848
    // 0x12c27ac: r17 = 8828
    //     0x12c27ac: mov             x17, #0x227c
    // 0x12c27b0: cmp             x2, x17
    // 0x12c27b4: b.gt            #0x12c2800
    // 0x12c27b8: r17 = 8827
    //     0x12c27b8: mov             x17, #0x227b
    // 0x12c27bc: cmp             x2, x17
    // 0x12c27c0: b.gt            #0x12c27f0
    // 0x12c27c4: r17 = 8826
    //     0x12c27c4: mov             x17, #0x227a
    // 0x12c27c8: cmp             x2, x17
    // 0x12c27cc: b.gt            #0x12c27e0
    // 0x12c27d0: r0 = 8827
    //     0x12c27d0: mov             x0, #0x227b
    // 0x12c27d4: LeaveFrame
    //     0x12c27d4: mov             SP, fp
    //     0x12c27d8: ldp             fp, lr, [SP], #0x10
    // 0x12c27dc: ret
    //     0x12c27dc: ret             
    // 0x12c27e0: r0 = 8826
    //     0x12c27e0: mov             x0, #0x227a
    // 0x12c27e4: LeaveFrame
    //     0x12c27e4: mov             SP, fp
    //     0x12c27e8: ldp             fp, lr, [SP], #0x10
    // 0x12c27ec: ret
    //     0x12c27ec: ret             
    // 0x12c27f0: r0 = 8829
    //     0x12c27f0: mov             x0, #0x227d
    // 0x12c27f4: LeaveFrame
    //     0x12c27f4: mov             SP, fp
    //     0x12c27f8: ldp             fp, lr, [SP], #0x10
    // 0x12c27fc: ret
    //     0x12c27fc: ret             
    // 0x12c2800: r17 = 8830
    //     0x12c2800: mov             x17, #0x227e
    // 0x12c2804: cmp             x2, x17
    // 0x12c2808: b.gt            #0x12c2838
    // 0x12c280c: r17 = 8829
    //     0x12c280c: mov             x17, #0x227d
    // 0x12c2810: cmp             x2, x17
    // 0x12c2814: b.gt            #0x12c2828
    // 0x12c2818: r0 = 8828
    //     0x12c2818: mov             x0, #0x227c
    // 0x12c281c: LeaveFrame
    //     0x12c281c: mov             SP, fp
    //     0x12c2820: ldp             fp, lr, [SP], #0x10
    // 0x12c2824: ret
    //     0x12c2824: ret             
    // 0x12c2828: r0 = 8831
    //     0x12c2828: mov             x0, #0x227f
    // 0x12c282c: LeaveFrame
    //     0x12c282c: mov             SP, fp
    //     0x12c2830: ldp             fp, lr, [SP], #0x10
    // 0x12c2834: ret
    //     0x12c2834: ret             
    // 0x12c2838: r0 = 8830
    //     0x12c2838: mov             x0, #0x227e
    // 0x12c283c: LeaveFrame
    //     0x12c283c: mov             SP, fp
    //     0x12c2840: ldp             fp, lr, [SP], #0x10
    // 0x12c2844: ret
    //     0x12c2844: ret             
    // 0x12c2848: r17 = 8834
    //     0x12c2848: mov             x17, #0x2282
    // 0x12c284c: cmp             x2, x17
    // 0x12c2850: b.gt            #0x12c289c
    // 0x12c2854: r17 = 8833
    //     0x12c2854: mov             x17, #0x2281
    // 0x12c2858: cmp             x2, x17
    // 0x12c285c: b.gt            #0x12c288c
    // 0x12c2860: r17 = 8832
    //     0x12c2860: mov             x17, #0x2280
    // 0x12c2864: cmp             x2, x17
    // 0x12c2868: b.gt            #0x12c287c
    // 0x12c286c: r0 = 8833
    //     0x12c286c: mov             x0, #0x2281
    // 0x12c2870: LeaveFrame
    //     0x12c2870: mov             SP, fp
    //     0x12c2874: ldp             fp, lr, [SP], #0x10
    // 0x12c2878: ret
    //     0x12c2878: ret             
    // 0x12c287c: r0 = 8832
    //     0x12c287c: mov             x0, #0x2280
    // 0x12c2880: LeaveFrame
    //     0x12c2880: mov             SP, fp
    //     0x12c2884: ldp             fp, lr, [SP], #0x10
    // 0x12c2888: ret
    //     0x12c2888: ret             
    // 0x12c288c: r0 = 8835
    //     0x12c288c: mov             x0, #0x2283
    // 0x12c2890: LeaveFrame
    //     0x12c2890: mov             SP, fp
    //     0x12c2894: ldp             fp, lr, [SP], #0x10
    // 0x12c2898: ret
    //     0x12c2898: ret             
    // 0x12c289c: r17 = 8835
    //     0x12c289c: mov             x17, #0x2283
    // 0x12c28a0: cmp             x2, x17
    // 0x12c28a4: b.gt            #0x12c28b8
    // 0x12c28a8: r0 = 8834
    //     0x12c28a8: mov             x0, #0x2282
    // 0x12c28ac: LeaveFrame
    //     0x12c28ac: mov             SP, fp
    //     0x12c28b0: ldp             fp, lr, [SP], #0x10
    // 0x12c28b4: ret
    //     0x12c28b4: ret             
    // 0x12c28b8: r0 = 8837
    //     0x12c28b8: mov             x0, #0x2285
    // 0x12c28bc: LeaveFrame
    //     0x12c28bc: mov             SP, fp
    //     0x12c28c0: ldp             fp, lr, [SP], #0x10
    // 0x12c28c4: ret
    //     0x12c28c4: ret             
    // 0x12c28c8: r17 = 8850
    //     0x12c28c8: mov             x17, #0x2292
    // 0x12c28cc: cmp             x2, x17
    // 0x12c28d0: b.gt            #0x12c2a08
    // 0x12c28d4: r17 = 8842
    //     0x12c28d4: mov             x17, #0x228a
    // 0x12c28d8: cmp             x2, x17
    // 0x12c28dc: b.gt            #0x12c297c
    // 0x12c28e0: r17 = 8839
    //     0x12c28e0: mov             x17, #0x2287
    // 0x12c28e4: cmp             x2, x17
    // 0x12c28e8: b.gt            #0x12c2934
    // 0x12c28ec: r17 = 8838
    //     0x12c28ec: mov             x17, #0x2286
    // 0x12c28f0: cmp             x2, x17
    // 0x12c28f4: b.gt            #0x12c2924
    // 0x12c28f8: r17 = 8837
    //     0x12c28f8: mov             x17, #0x2285
    // 0x12c28fc: cmp             x2, x17
    // 0x12c2900: b.gt            #0x12c2914
    // 0x12c2904: r0 = 8836
    //     0x12c2904: mov             x0, #0x2284
    // 0x12c2908: LeaveFrame
    //     0x12c2908: mov             SP, fp
    //     0x12c290c: ldp             fp, lr, [SP], #0x10
    // 0x12c2910: ret
    //     0x12c2910: ret             
    // 0x12c2914: r0 = 8839
    //     0x12c2914: mov             x0, #0x2287
    // 0x12c2918: LeaveFrame
    //     0x12c2918: mov             SP, fp
    //     0x12c291c: ldp             fp, lr, [SP], #0x10
    // 0x12c2920: ret
    //     0x12c2920: ret             
    // 0x12c2924: r0 = 8838
    //     0x12c2924: mov             x0, #0x2286
    // 0x12c2928: LeaveFrame
    //     0x12c2928: mov             SP, fp
    //     0x12c292c: ldp             fp, lr, [SP], #0x10
    // 0x12c2930: ret
    //     0x12c2930: ret             
    // 0x12c2934: r17 = 8841
    //     0x12c2934: mov             x17, #0x2289
    // 0x12c2938: cmp             x2, x17
    // 0x12c293c: b.gt            #0x12c296c
    // 0x12c2940: r17 = 8840
    //     0x12c2940: mov             x17, #0x2288
    // 0x12c2944: cmp             x2, x17
    // 0x12c2948: b.gt            #0x12c295c
    // 0x12c294c: r0 = 8841
    //     0x12c294c: mov             x0, #0x2289
    // 0x12c2950: LeaveFrame
    //     0x12c2950: mov             SP, fp
    //     0x12c2954: ldp             fp, lr, [SP], #0x10
    // 0x12c2958: ret
    //     0x12c2958: ret             
    // 0x12c295c: r0 = 8840
    //     0x12c295c: mov             x0, #0x2288
    // 0x12c2960: LeaveFrame
    //     0x12c2960: mov             SP, fp
    //     0x12c2964: ldp             fp, lr, [SP], #0x10
    // 0x12c2968: ret
    //     0x12c2968: ret             
    // 0x12c296c: r0 = 8843
    //     0x12c296c: mov             x0, #0x228b
    // 0x12c2970: LeaveFrame
    //     0x12c2970: mov             SP, fp
    //     0x12c2974: ldp             fp, lr, [SP], #0x10
    // 0x12c2978: ret
    //     0x12c2978: ret             
    // 0x12c297c: r17 = 8848
    //     0x12c297c: mov             x17, #0x2290
    // 0x12c2980: cmp             x2, x17
    // 0x12c2984: b.gt            #0x12c29dc
    // 0x12c2988: r17 = 8847
    //     0x12c2988: mov             x17, #0x228f
    // 0x12c298c: cmp             x2, x17
    // 0x12c2990: b.gt            #0x12c29cc
    // 0x12c2994: r17 = 8843
    //     0x12c2994: mov             x17, #0x228b
    // 0x12c2998: cmp             x2, x17
    // 0x12c299c: b.gt            #0x12c29b0
    // 0x12c29a0: r0 = 8842
    //     0x12c29a0: mov             x0, #0x228a
    // 0x12c29a4: LeaveFrame
    //     0x12c29a4: mov             SP, fp
    //     0x12c29a8: ldp             fp, lr, [SP], #0x10
    // 0x12c29ac: ret
    //     0x12c29ac: ret             
    // 0x12c29b0: r17 = 8847
    //     0x12c29b0: mov             x17, #0x228f
    // 0x12c29b4: cmp             x2, x17
    // 0x12c29b8: b.lt            #0x12c4c48
    // 0x12c29bc: r0 = 8848
    //     0x12c29bc: mov             x0, #0x2290
    // 0x12c29c0: LeaveFrame
    //     0x12c29c0: mov             SP, fp
    //     0x12c29c4: ldp             fp, lr, [SP], #0x10
    // 0x12c29c8: ret
    //     0x12c29c8: ret             
    // 0x12c29cc: r0 = 8847
    //     0x12c29cc: mov             x0, #0x228f
    // 0x12c29d0: LeaveFrame
    //     0x12c29d0: mov             SP, fp
    //     0x12c29d4: ldp             fp, lr, [SP], #0x10
    // 0x12c29d8: ret
    //     0x12c29d8: ret             
    // 0x12c29dc: r17 = 8849
    //     0x12c29dc: mov             x17, #0x2291
    // 0x12c29e0: cmp             x2, x17
    // 0x12c29e4: b.gt            #0x12c29f8
    // 0x12c29e8: r0 = 8850
    //     0x12c29e8: mov             x0, #0x2292
    // 0x12c29ec: LeaveFrame
    //     0x12c29ec: mov             SP, fp
    //     0x12c29f0: ldp             fp, lr, [SP], #0x10
    // 0x12c29f4: ret
    //     0x12c29f4: ret             
    // 0x12c29f8: r0 = 8849
    //     0x12c29f8: mov             x0, #0x2291
    // 0x12c29fc: LeaveFrame
    //     0x12c29fc: mov             SP, fp
    //     0x12c2a00: ldp             fp, lr, [SP], #0x10
    // 0x12c2a04: ret
    //     0x12c2a04: ret             
    // 0x12c2a08: r17 = 8856
    //     0x12c2a08: mov             x17, #0x2298
    // 0x12c2a0c: cmp             x2, x17
    // 0x12c2a10: b.lt            #0x12c4c48
    // 0x12c2a14: r17 = 8873
    //     0x12c2a14: mov             x17, #0x22a9
    // 0x12c2a18: cmp             x2, x17
    // 0x12c2a1c: b.gt            #0x12c2ae0
    // 0x12c2a20: r17 = 8867
    //     0x12c2a20: mov             x17, #0x22a3
    // 0x12c2a24: cmp             x2, x17
    // 0x12c2a28: b.gt            #0x12c2a80
    // 0x12c2a2c: r17 = 8866
    //     0x12c2a2c: mov             x17, #0x22a2
    // 0x12c2a30: cmp             x2, x17
    // 0x12c2a34: b.gt            #0x12c2a70
    // 0x12c2a38: r17 = 8856
    //     0x12c2a38: mov             x17, #0x2298
    // 0x12c2a3c: cmp             x2, x17
    // 0x12c2a40: b.gt            #0x12c2a54
    // 0x12c2a44: r0 = 10680
    //     0x12c2a44: mov             x0, #0x29b8
    // 0x12c2a48: LeaveFrame
    //     0x12c2a48: mov             SP, fp
    //     0x12c2a4c: ldp             fp, lr, [SP], #0x10
    // 0x12c2a50: ret
    //     0x12c2a50: ret             
    // 0x12c2a54: r17 = 8866
    //     0x12c2a54: mov             x17, #0x22a2
    // 0x12c2a58: cmp             x2, x17
    // 0x12c2a5c: b.lt            #0x12c4c48
    // 0x12c2a60: r0 = 8867
    //     0x12c2a60: mov             x0, #0x22a3
    // 0x12c2a64: LeaveFrame
    //     0x12c2a64: mov             SP, fp
    //     0x12c2a68: ldp             fp, lr, [SP], #0x10
    // 0x12c2a6c: ret
    //     0x12c2a6c: ret             
    // 0x12c2a70: r0 = 8866
    //     0x12c2a70: mov             x0, #0x22a2
    // 0x12c2a74: LeaveFrame
    //     0x12c2a74: mov             SP, fp
    //     0x12c2a78: ldp             fp, lr, [SP], #0x10
    // 0x12c2a7c: ret
    //     0x12c2a7c: ret             
    // 0x12c2a80: r17 = 8870
    //     0x12c2a80: mov             x17, #0x22a6
    // 0x12c2a84: cmp             x2, x17
    // 0x12c2a88: b.lt            #0x12c4c48
    // 0x12c2a8c: r17 = 8872
    //     0x12c2a8c: mov             x17, #0x22a8
    // 0x12c2a90: cmp             x2, x17
    // 0x12c2a94: b.gt            #0x12c2ad0
    // 0x12c2a98: r17 = 8870
    //     0x12c2a98: mov             x17, #0x22a6
    // 0x12c2a9c: cmp             x2, x17
    // 0x12c2aa0: b.gt            #0x12c2ab4
    // 0x12c2aa4: r0 = 10974
    //     0x12c2aa4: mov             x0, #0x2ade
    // 0x12c2aa8: LeaveFrame
    //     0x12c2aa8: mov             SP, fp
    //     0x12c2aac: ldp             fp, lr, [SP], #0x10
    // 0x12c2ab0: ret
    //     0x12c2ab0: ret             
    // 0x12c2ab4: r17 = 8872
    //     0x12c2ab4: mov             x17, #0x22a8
    // 0x12c2ab8: cmp             x2, x17
    // 0x12c2abc: b.lt            #0x12c4c48
    // 0x12c2ac0: r0 = 10980
    //     0x12c2ac0: mov             x0, #0x2ae4
    // 0x12c2ac4: LeaveFrame
    //     0x12c2ac4: mov             SP, fp
    //     0x12c2ac8: ldp             fp, lr, [SP], #0x10
    // 0x12c2acc: ret
    //     0x12c2acc: ret             
    // 0x12c2ad0: r0 = 10979
    //     0x12c2ad0: mov             x0, #0x2ae3
    // 0x12c2ad4: LeaveFrame
    //     0x12c2ad4: mov             SP, fp
    //     0x12c2ad8: ldp             fp, lr, [SP], #0x10
    // 0x12c2adc: ret
    //     0x12c2adc: ret             
    // 0x12c2ae0: r17 = 8875
    //     0x12c2ae0: mov             x17, #0x22ab
    // 0x12c2ae4: cmp             x2, x17
    // 0x12c2ae8: b.lt            #0x12c4c48
    // 0x12c2aec: r17 = 8881
    //     0x12c2aec: mov             x17, #0x22b1
    // 0x12c2af0: cmp             x2, x17
    // 0x12c2af4: b.gt            #0x12c2b4c
    // 0x12c2af8: r17 = 8880
    //     0x12c2af8: mov             x17, #0x22b0
    // 0x12c2afc: cmp             x2, x17
    // 0x12c2b00: b.gt            #0x12c2b3c
    // 0x12c2b04: r17 = 8875
    //     0x12c2b04: mov             x17, #0x22ab
    // 0x12c2b08: cmp             x2, x17
    // 0x12c2b0c: b.gt            #0x12c2b20
    // 0x12c2b10: r0 = 10981
    //     0x12c2b10: mov             x0, #0x2ae5
    // 0x12c2b14: LeaveFrame
    //     0x12c2b14: mov             SP, fp
    //     0x12c2b18: ldp             fp, lr, [SP], #0x10
    // 0x12c2b1c: ret
    //     0x12c2b1c: ret             
    // 0x12c2b20: r17 = 8880
    //     0x12c2b20: mov             x17, #0x22b0
    // 0x12c2b24: cmp             x2, x17
    // 0x12c2b28: b.lt            #0x12c4c48
    // 0x12c2b2c: r0 = 8881
    //     0x12c2b2c: mov             x0, #0x22b1
    // 0x12c2b30: LeaveFrame
    //     0x12c2b30: mov             SP, fp
    //     0x12c2b34: ldp             fp, lr, [SP], #0x10
    // 0x12c2b38: ret
    //     0x12c2b38: ret             
    // 0x12c2b3c: r0 = 8880
    //     0x12c2b3c: mov             x0, #0x22b0
    // 0x12c2b40: LeaveFrame
    //     0x12c2b40: mov             SP, fp
    //     0x12c2b44: ldp             fp, lr, [SP], #0x10
    // 0x12c2b48: ret
    //     0x12c2b48: ret             
    // 0x12c2b4c: r17 = 8882
    //     0x12c2b4c: mov             x17, #0x22b2
    // 0x12c2b50: cmp             x2, x17
    // 0x12c2b54: b.gt            #0x12c2b68
    // 0x12c2b58: r0 = 8883
    //     0x12c2b58: mov             x0, #0x22b3
    // 0x12c2b5c: LeaveFrame
    //     0x12c2b5c: mov             SP, fp
    //     0x12c2b60: ldp             fp, lr, [SP], #0x10
    // 0x12c2b64: ret
    //     0x12c2b64: ret             
    // 0x12c2b68: r0 = 8882
    //     0x12c2b68: mov             x0, #0x22b2
    // 0x12c2b6c: LeaveFrame
    //     0x12c2b6c: mov             SP, fp
    //     0x12c2b70: ldp             fp, lr, [SP], #0x10
    // 0x12c2b74: ret
    //     0x12c2b74: ret             
    // 0x12c2b78: r17 = 8957
    //     0x12c2b78: mov             x17, #0x22fd
    // 0x12c2b7c: cmp             x2, x17
    // 0x12c2b80: b.gt            #0x12c30c8
    // 0x12c2b84: r17 = 8929
    //     0x12c2b84: mov             x17, #0x22e1
    // 0x12c2b88: cmp             x2, x17
    // 0x12c2b8c: b.gt            #0x12c2e2c
    // 0x12c2b90: r17 = 8918
    //     0x12c2b90: mov             x17, #0x22d6
    // 0x12c2b94: cmp             x2, x17
    // 0x12c2b98: b.gt            #0x12c2d04
    // 0x12c2b9c: r17 = 8906
    //     0x12c2b9c: mov             x17, #0x22ca
    // 0x12c2ba0: cmp             x2, x17
    // 0x12c2ba4: b.gt            #0x12c2c50
    // 0x12c2ba8: r17 = 8886
    //     0x12c2ba8: mov             x17, #0x22b6
    // 0x12c2bac: cmp             x2, x17
    // 0x12c2bb0: b.gt            #0x12c2bfc
    // 0x12c2bb4: r17 = 8885
    //     0x12c2bb4: mov             x17, #0x22b5
    // 0x12c2bb8: cmp             x2, x17
    // 0x12c2bbc: b.gt            #0x12c2bec
    // 0x12c2bc0: r17 = 8884
    //     0x12c2bc0: mov             x17, #0x22b4
    // 0x12c2bc4: cmp             x2, x17
    // 0x12c2bc8: b.gt            #0x12c2bdc
    // 0x12c2bcc: r0 = 8885
    //     0x12c2bcc: mov             x0, #0x22b5
    // 0x12c2bd0: LeaveFrame
    //     0x12c2bd0: mov             SP, fp
    //     0x12c2bd4: ldp             fp, lr, [SP], #0x10
    // 0x12c2bd8: ret
    //     0x12c2bd8: ret             
    // 0x12c2bdc: r0 = 8884
    //     0x12c2bdc: mov             x0, #0x22b4
    // 0x12c2be0: LeaveFrame
    //     0x12c2be0: mov             SP, fp
    //     0x12c2be4: ldp             fp, lr, [SP], #0x10
    // 0x12c2be8: ret
    //     0x12c2be8: ret             
    // 0x12c2bec: r0 = 8887
    //     0x12c2bec: mov             x0, #0x22b7
    // 0x12c2bf0: LeaveFrame
    //     0x12c2bf0: mov             SP, fp
    //     0x12c2bf4: ldp             fp, lr, [SP], #0x10
    // 0x12c2bf8: ret
    //     0x12c2bf8: ret             
    // 0x12c2bfc: r17 = 8905
    //     0x12c2bfc: mov             x17, #0x22c9
    // 0x12c2c00: cmp             x2, x17
    // 0x12c2c04: b.gt            #0x12c2c40
    // 0x12c2c08: r17 = 8887
    //     0x12c2c08: mov             x17, #0x22b7
    // 0x12c2c0c: cmp             x2, x17
    // 0x12c2c10: b.gt            #0x12c2c24
    // 0x12c2c14: r0 = 8886
    //     0x12c2c14: mov             x0, #0x22b6
    // 0x12c2c18: LeaveFrame
    //     0x12c2c18: mov             SP, fp
    //     0x12c2c1c: ldp             fp, lr, [SP], #0x10
    // 0x12c2c20: ret
    //     0x12c2c20: ret             
    // 0x12c2c24: r17 = 8905
    //     0x12c2c24: mov             x17, #0x22c9
    // 0x12c2c28: cmp             x2, x17
    // 0x12c2c2c: b.lt            #0x12c4c48
    // 0x12c2c30: r0 = 8906
    //     0x12c2c30: mov             x0, #0x22ca
    // 0x12c2c34: LeaveFrame
    //     0x12c2c34: mov             SP, fp
    //     0x12c2c38: ldp             fp, lr, [SP], #0x10
    // 0x12c2c3c: ret
    //     0x12c2c3c: ret             
    // 0x12c2c40: r0 = 8905
    //     0x12c2c40: mov             x0, #0x22c9
    // 0x12c2c44: LeaveFrame
    //     0x12c2c44: mov             SP, fp
    //     0x12c2c48: ldp             fp, lr, [SP], #0x10
    // 0x12c2c4c: ret
    //     0x12c2c4c: ret             
    // 0x12c2c50: r17 = 8909
    //     0x12c2c50: mov             x17, #0x22cd
    // 0x12c2c54: cmp             x2, x17
    // 0x12c2c58: b.gt            #0x12c2ca4
    // 0x12c2c5c: r17 = 8908
    //     0x12c2c5c: mov             x17, #0x22cc
    // 0x12c2c60: cmp             x2, x17
    // 0x12c2c64: b.gt            #0x12c2c94
    // 0x12c2c68: r17 = 8907
    //     0x12c2c68: mov             x17, #0x22cb
    // 0x12c2c6c: cmp             x2, x17
    // 0x12c2c70: b.gt            #0x12c2c84
    // 0x12c2c74: r0 = 8908
    //     0x12c2c74: mov             x0, #0x22cc
    // 0x12c2c78: LeaveFrame
    //     0x12c2c78: mov             SP, fp
    //     0x12c2c7c: ldp             fp, lr, [SP], #0x10
    // 0x12c2c80: ret
    //     0x12c2c80: ret             
    // 0x12c2c84: r0 = 8907
    //     0x12c2c84: mov             x0, #0x22cb
    // 0x12c2c88: LeaveFrame
    //     0x12c2c88: mov             SP, fp
    //     0x12c2c8c: ldp             fp, lr, [SP], #0x10
    // 0x12c2c90: ret
    //     0x12c2c90: ret             
    // 0x12c2c94: r0 = 8771
    //     0x12c2c94: mov             x0, #0x2243
    // 0x12c2c98: LeaveFrame
    //     0x12c2c98: mov             SP, fp
    //     0x12c2c9c: ldp             fp, lr, [SP], #0x10
    // 0x12c2ca0: ret
    //     0x12c2ca0: ret             
    // 0x12c2ca4: r17 = 8912
    //     0x12c2ca4: mov             x17, #0x22d0
    // 0x12c2ca8: cmp             x2, x17
    // 0x12c2cac: b.lt            #0x12c4c48
    // 0x12c2cb0: r17 = 8913
    //     0x12c2cb0: mov             x17, #0x22d1
    // 0x12c2cb4: cmp             x2, x17
    // 0x12c2cb8: b.gt            #0x12c2ce8
    // 0x12c2cbc: r17 = 8912
    //     0x12c2cbc: mov             x17, #0x22d0
    // 0x12c2cc0: cmp             x2, x17
    // 0x12c2cc4: b.gt            #0x12c2cd8
    // 0x12c2cc8: r0 = 8913
    //     0x12c2cc8: mov             x0, #0x22d1
    // 0x12c2ccc: LeaveFrame
    //     0x12c2ccc: mov             SP, fp
    //     0x12c2cd0: ldp             fp, lr, [SP], #0x10
    // 0x12c2cd4: ret
    //     0x12c2cd4: ret             
    // 0x12c2cd8: r0 = 8912
    //     0x12c2cd8: mov             x0, #0x22d0
    // 0x12c2cdc: LeaveFrame
    //     0x12c2cdc: mov             SP, fp
    //     0x12c2ce0: ldp             fp, lr, [SP], #0x10
    // 0x12c2ce4: ret
    //     0x12c2ce4: ret             
    // 0x12c2ce8: r17 = 8918
    //     0x12c2ce8: mov             x17, #0x22d6
    // 0x12c2cec: cmp             x2, x17
    // 0x12c2cf0: b.lt            #0x12c4c48
    // 0x12c2cf4: r0 = 8919
    //     0x12c2cf4: mov             x0, #0x22d7
    // 0x12c2cf8: LeaveFrame
    //     0x12c2cf8: mov             SP, fp
    //     0x12c2cfc: ldp             fp, lr, [SP], #0x10
    // 0x12c2d00: ret
    //     0x12c2d00: ret             
    // 0x12c2d04: r17 = 8924
    //     0x12c2d04: mov             x17, #0x22dc
    // 0x12c2d08: cmp             x2, x17
    // 0x12c2d0c: b.gt            #0x12c2dac
    // 0x12c2d10: r17 = 8921
    //     0x12c2d10: mov             x17, #0x22d9
    // 0x12c2d14: cmp             x2, x17
    // 0x12c2d18: b.gt            #0x12c2d64
    // 0x12c2d1c: r17 = 8920
    //     0x12c2d1c: mov             x17, #0x22d8
    // 0x12c2d20: cmp             x2, x17
    // 0x12c2d24: b.gt            #0x12c2d54
    // 0x12c2d28: r17 = 8919
    //     0x12c2d28: mov             x17, #0x22d7
    // 0x12c2d2c: cmp             x2, x17
    // 0x12c2d30: b.gt            #0x12c2d44
    // 0x12c2d34: r0 = 8918
    //     0x12c2d34: mov             x0, #0x22d6
    // 0x12c2d38: LeaveFrame
    //     0x12c2d38: mov             SP, fp
    //     0x12c2d3c: ldp             fp, lr, [SP], #0x10
    // 0x12c2d40: ret
    //     0x12c2d40: ret             
    // 0x12c2d44: r0 = 8921
    //     0x12c2d44: mov             x0, #0x22d9
    // 0x12c2d48: LeaveFrame
    //     0x12c2d48: mov             SP, fp
    //     0x12c2d4c: ldp             fp, lr, [SP], #0x10
    // 0x12c2d50: ret
    //     0x12c2d50: ret             
    // 0x12c2d54: r0 = 8920
    //     0x12c2d54: mov             x0, #0x22d8
    // 0x12c2d58: LeaveFrame
    //     0x12c2d58: mov             SP, fp
    //     0x12c2d5c: ldp             fp, lr, [SP], #0x10
    // 0x12c2d60: ret
    //     0x12c2d60: ret             
    // 0x12c2d64: r17 = 8923
    //     0x12c2d64: mov             x17, #0x22db
    // 0x12c2d68: cmp             x2, x17
    // 0x12c2d6c: b.gt            #0x12c2d9c
    // 0x12c2d70: r17 = 8922
    //     0x12c2d70: mov             x17, #0x22da
    // 0x12c2d74: cmp             x2, x17
    // 0x12c2d78: b.gt            #0x12c2d8c
    // 0x12c2d7c: r0 = 8923
    //     0x12c2d7c: mov             x0, #0x22db
    // 0x12c2d80: LeaveFrame
    //     0x12c2d80: mov             SP, fp
    //     0x12c2d84: ldp             fp, lr, [SP], #0x10
    // 0x12c2d88: ret
    //     0x12c2d88: ret             
    // 0x12c2d8c: r0 = 8922
    //     0x12c2d8c: mov             x0, #0x22da
    // 0x12c2d90: LeaveFrame
    //     0x12c2d90: mov             SP, fp
    //     0x12c2d94: ldp             fp, lr, [SP], #0x10
    // 0x12c2d98: ret
    //     0x12c2d98: ret             
    // 0x12c2d9c: r0 = 8925
    //     0x12c2d9c: mov             x0, #0x22dd
    // 0x12c2da0: LeaveFrame
    //     0x12c2da0: mov             SP, fp
    //     0x12c2da4: ldp             fp, lr, [SP], #0x10
    // 0x12c2da8: ret
    //     0x12c2da8: ret             
    // 0x12c2dac: r17 = 8927
    //     0x12c2dac: mov             x17, #0x22df
    // 0x12c2db0: cmp             x2, x17
    // 0x12c2db4: b.gt            #0x12c2e00
    // 0x12c2db8: r17 = 8926
    //     0x12c2db8: mov             x17, #0x22de
    // 0x12c2dbc: cmp             x2, x17
    // 0x12c2dc0: b.gt            #0x12c2df0
    // 0x12c2dc4: r17 = 8925
    //     0x12c2dc4: mov             x17, #0x22dd
    // 0x12c2dc8: cmp             x2, x17
    // 0x12c2dcc: b.gt            #0x12c2de0
    // 0x12c2dd0: r0 = 8924
    //     0x12c2dd0: mov             x0, #0x22dc
    // 0x12c2dd4: LeaveFrame
    //     0x12c2dd4: mov             SP, fp
    //     0x12c2dd8: ldp             fp, lr, [SP], #0x10
    // 0x12c2ddc: ret
    //     0x12c2ddc: ret             
    // 0x12c2de0: r0 = 8927
    //     0x12c2de0: mov             x0, #0x22df
    // 0x12c2de4: LeaveFrame
    //     0x12c2de4: mov             SP, fp
    //     0x12c2de8: ldp             fp, lr, [SP], #0x10
    // 0x12c2dec: ret
    //     0x12c2dec: ret             
    // 0x12c2df0: r0 = 8926
    //     0x12c2df0: mov             x0, #0x22de
    // 0x12c2df4: LeaveFrame
    //     0x12c2df4: mov             SP, fp
    //     0x12c2df8: ldp             fp, lr, [SP], #0x10
    // 0x12c2dfc: ret
    //     0x12c2dfc: ret             
    // 0x12c2e00: r17 = 8928
    //     0x12c2e00: mov             x17, #0x22e0
    // 0x12c2e04: cmp             x2, x17
    // 0x12c2e08: b.gt            #0x12c2e1c
    // 0x12c2e0c: r0 = 8929
    //     0x12c2e0c: mov             x0, #0x22e1
    // 0x12c2e10: LeaveFrame
    //     0x12c2e10: mov             SP, fp
    //     0x12c2e14: ldp             fp, lr, [SP], #0x10
    // 0x12c2e18: ret
    //     0x12c2e18: ret             
    // 0x12c2e1c: r0 = 8928
    //     0x12c2e1c: mov             x0, #0x22e0
    // 0x12c2e20: LeaveFrame
    //     0x12c2e20: mov             SP, fp
    //     0x12c2e24: ldp             fp, lr, [SP], #0x10
    // 0x12c2e28: ret
    //     0x12c2e28: ret             
    // 0x12c2e2c: r17 = 8941
    //     0x12c2e2c: mov             x17, #0x22ed
    // 0x12c2e30: cmp             x2, x17
    // 0x12c2e34: b.gt            #0x12c2f7c
    // 0x12c2e38: r17 = 8935
    //     0x12c2e38: mov             x17, #0x22e7
    // 0x12c2e3c: cmp             x2, x17
    // 0x12c2e40: b.gt            #0x12c2ee0
    // 0x12c2e44: r17 = 8932
    //     0x12c2e44: mov             x17, #0x22e4
    // 0x12c2e48: cmp             x2, x17
    // 0x12c2e4c: b.gt            #0x12c2e98
    // 0x12c2e50: r17 = 8931
    //     0x12c2e50: mov             x17, #0x22e3
    // 0x12c2e54: cmp             x2, x17
    // 0x12c2e58: b.gt            #0x12c2e88
    // 0x12c2e5c: r17 = 8930
    //     0x12c2e5c: mov             x17, #0x22e2
    // 0x12c2e60: cmp             x2, x17
    // 0x12c2e64: b.gt            #0x12c2e78
    // 0x12c2e68: r0 = 8931
    //     0x12c2e68: mov             x0, #0x22e3
    // 0x12c2e6c: LeaveFrame
    //     0x12c2e6c: mov             SP, fp
    //     0x12c2e70: ldp             fp, lr, [SP], #0x10
    // 0x12c2e74: ret
    //     0x12c2e74: ret             
    // 0x12c2e78: r0 = 8930
    //     0x12c2e78: mov             x0, #0x22e2
    // 0x12c2e7c: LeaveFrame
    //     0x12c2e7c: mov             SP, fp
    //     0x12c2e80: ldp             fp, lr, [SP], #0x10
    // 0x12c2e84: ret
    //     0x12c2e84: ret             
    // 0x12c2e88: r0 = 8933
    //     0x12c2e88: mov             x0, #0x22e5
    // 0x12c2e8c: LeaveFrame
    //     0x12c2e8c: mov             SP, fp
    //     0x12c2e90: ldp             fp, lr, [SP], #0x10
    // 0x12c2e94: ret
    //     0x12c2e94: ret             
    // 0x12c2e98: r17 = 8934
    //     0x12c2e98: mov             x17, #0x22e6
    // 0x12c2e9c: cmp             x2, x17
    // 0x12c2ea0: b.gt            #0x12c2ed0
    // 0x12c2ea4: r17 = 8933
    //     0x12c2ea4: mov             x17, #0x22e5
    // 0x12c2ea8: cmp             x2, x17
    // 0x12c2eac: b.gt            #0x12c2ec0
    // 0x12c2eb0: r0 = 8932
    //     0x12c2eb0: mov             x0, #0x22e4
    // 0x12c2eb4: LeaveFrame
    //     0x12c2eb4: mov             SP, fp
    //     0x12c2eb8: ldp             fp, lr, [SP], #0x10
    // 0x12c2ebc: ret
    //     0x12c2ebc: ret             
    // 0x12c2ec0: r0 = 8935
    //     0x12c2ec0: mov             x0, #0x22e7
    // 0x12c2ec4: LeaveFrame
    //     0x12c2ec4: mov             SP, fp
    //     0x12c2ec8: ldp             fp, lr, [SP], #0x10
    // 0x12c2ecc: ret
    //     0x12c2ecc: ret             
    // 0x12c2ed0: r0 = 8934
    //     0x12c2ed0: mov             x0, #0x22e6
    // 0x12c2ed4: LeaveFrame
    //     0x12c2ed4: mov             SP, fp
    //     0x12c2ed8: ldp             fp, lr, [SP], #0x10
    // 0x12c2edc: ret
    //     0x12c2edc: ret             
    // 0x12c2ee0: r17 = 8938
    //     0x12c2ee0: mov             x17, #0x22ea
    // 0x12c2ee4: cmp             x2, x17
    // 0x12c2ee8: b.gt            #0x12c2f34
    // 0x12c2eec: r17 = 8937
    //     0x12c2eec: mov             x17, #0x22e9
    // 0x12c2ef0: cmp             x2, x17
    // 0x12c2ef4: b.gt            #0x12c2f24
    // 0x12c2ef8: r17 = 8936
    //     0x12c2ef8: mov             x17, #0x22e8
    // 0x12c2efc: cmp             x2, x17
    // 0x12c2f00: b.gt            #0x12c2f14
    // 0x12c2f04: r0 = 8937
    //     0x12c2f04: mov             x0, #0x22e9
    // 0x12c2f08: LeaveFrame
    //     0x12c2f08: mov             SP, fp
    //     0x12c2f0c: ldp             fp, lr, [SP], #0x10
    // 0x12c2f10: ret
    //     0x12c2f10: ret             
    // 0x12c2f14: r0 = 8936
    //     0x12c2f14: mov             x0, #0x22e8
    // 0x12c2f18: LeaveFrame
    //     0x12c2f18: mov             SP, fp
    //     0x12c2f1c: ldp             fp, lr, [SP], #0x10
    // 0x12c2f20: ret
    //     0x12c2f20: ret             
    // 0x12c2f24: r0 = 8939
    //     0x12c2f24: mov             x0, #0x22eb
    // 0x12c2f28: LeaveFrame
    //     0x12c2f28: mov             SP, fp
    //     0x12c2f2c: ldp             fp, lr, [SP], #0x10
    // 0x12c2f30: ret
    //     0x12c2f30: ret             
    // 0x12c2f34: r17 = 8940
    //     0x12c2f34: mov             x17, #0x22ec
    // 0x12c2f38: cmp             x2, x17
    // 0x12c2f3c: b.gt            #0x12c2f6c
    // 0x12c2f40: r17 = 8939
    //     0x12c2f40: mov             x17, #0x22eb
    // 0x12c2f44: cmp             x2, x17
    // 0x12c2f48: b.gt            #0x12c2f5c
    // 0x12c2f4c: r0 = 8938
    //     0x12c2f4c: mov             x0, #0x22ea
    // 0x12c2f50: LeaveFrame
    //     0x12c2f50: mov             SP, fp
    //     0x12c2f54: ldp             fp, lr, [SP], #0x10
    // 0x12c2f58: ret
    //     0x12c2f58: ret             
    // 0x12c2f5c: r0 = 8941
    //     0x12c2f5c: mov             x0, #0x22ed
    // 0x12c2f60: LeaveFrame
    //     0x12c2f60: mov             SP, fp
    //     0x12c2f64: ldp             fp, lr, [SP], #0x10
    // 0x12c2f68: ret
    //     0x12c2f68: ret             
    // 0x12c2f6c: r0 = 8940
    //     0x12c2f6c: mov             x0, #0x22ec
    // 0x12c2f70: LeaveFrame
    //     0x12c2f70: mov             SP, fp
    //     0x12c2f74: ldp             fp, lr, [SP], #0x10
    // 0x12c2f78: ret
    //     0x12c2f78: ret             
    // 0x12c2f7c: r17 = 8944
    //     0x12c2f7c: mov             x17, #0x22f0
    // 0x12c2f80: cmp             x2, x17
    // 0x12c2f84: b.lt            #0x12c4c48
    // 0x12c2f88: r17 = 8950
    //     0x12c2f88: mov             x17, #0x22f6
    // 0x12c2f8c: cmp             x2, x17
    // 0x12c2f90: b.gt            #0x12c303c
    // 0x12c2f94: r17 = 8946
    //     0x12c2f94: mov             x17, #0x22f2
    // 0x12c2f98: cmp             x2, x17
    // 0x12c2f9c: b.gt            #0x12c2fe8
    // 0x12c2fa0: r17 = 8945
    //     0x12c2fa0: mov             x17, #0x22f1
    // 0x12c2fa4: cmp             x2, x17
    // 0x12c2fa8: b.gt            #0x12c2fd8
    // 0x12c2fac: r17 = 8944
    //     0x12c2fac: mov             x17, #0x22f0
    // 0x12c2fb0: cmp             x2, x17
    // 0x12c2fb4: b.gt            #0x12c2fc8
    // 0x12c2fb8: r0 = 8945
    //     0x12c2fb8: mov             x0, #0x22f1
    // 0x12c2fbc: LeaveFrame
    //     0x12c2fbc: mov             SP, fp
    //     0x12c2fc0: ldp             fp, lr, [SP], #0x10
    // 0x12c2fc4: ret
    //     0x12c2fc4: ret             
    // 0x12c2fc8: r0 = 8944
    //     0x12c2fc8: mov             x0, #0x22f0
    // 0x12c2fcc: LeaveFrame
    //     0x12c2fcc: mov             SP, fp
    //     0x12c2fd0: ldp             fp, lr, [SP], #0x10
    // 0x12c2fd4: ret
    //     0x12c2fd4: ret             
    // 0x12c2fd8: r0 = 8954
    //     0x12c2fd8: mov             x0, #0x22fa
    // 0x12c2fdc: LeaveFrame
    //     0x12c2fdc: mov             SP, fp
    //     0x12c2fe0: ldp             fp, lr, [SP], #0x10
    // 0x12c2fe4: ret
    //     0x12c2fe4: ret             
    // 0x12c2fe8: r17 = 8948
    //     0x12c2fe8: mov             x17, #0x22f4
    // 0x12c2fec: cmp             x2, x17
    // 0x12c2ff0: b.gt            #0x12c3020
    // 0x12c2ff4: r17 = 8947
    //     0x12c2ff4: mov             x17, #0x22f3
    // 0x12c2ff8: cmp             x2, x17
    // 0x12c2ffc: b.gt            #0x12c3010
    // 0x12c3000: r0 = 8955
    //     0x12c3000: mov             x0, #0x22fb
    // 0x12c3004: LeaveFrame
    //     0x12c3004: mov             SP, fp
    //     0x12c3008: ldp             fp, lr, [SP], #0x10
    // 0x12c300c: ret
    //     0x12c300c: ret             
    // 0x12c3010: r0 = 8956
    //     0x12c3010: mov             x0, #0x22fc
    // 0x12c3014: LeaveFrame
    //     0x12c3014: mov             SP, fp
    //     0x12c3018: ldp             fp, lr, [SP], #0x10
    // 0x12c301c: ret
    //     0x12c301c: ret             
    // 0x12c3020: r17 = 8950
    //     0x12c3020: mov             x17, #0x22f6
    // 0x12c3024: cmp             x2, x17
    // 0x12c3028: b.lt            #0x12c4c48
    // 0x12c302c: r0 = 8957
    //     0x12c302c: mov             x0, #0x22fd
    // 0x12c3030: LeaveFrame
    //     0x12c3030: mov             SP, fp
    //     0x12c3034: ldp             fp, lr, [SP], #0x10
    // 0x12c3038: ret
    //     0x12c3038: ret             
    // 0x12c303c: r17 = 8955
    //     0x12c303c: mov             x17, #0x22fb
    // 0x12c3040: cmp             x2, x17
    // 0x12c3044: b.gt            #0x12c309c
    // 0x12c3048: r17 = 8954
    //     0x12c3048: mov             x17, #0x22fa
    // 0x12c304c: cmp             x2, x17
    // 0x12c3050: b.gt            #0x12c308c
    // 0x12c3054: r17 = 8951
    //     0x12c3054: mov             x17, #0x22f7
    // 0x12c3058: cmp             x2, x17
    // 0x12c305c: b.gt            #0x12c3070
    // 0x12c3060: r0 = 8958
    //     0x12c3060: mov             x0, #0x22fe
    // 0x12c3064: LeaveFrame
    //     0x12c3064: mov             SP, fp
    //     0x12c3068: ldp             fp, lr, [SP], #0x10
    // 0x12c306c: ret
    //     0x12c306c: ret             
    // 0x12c3070: r17 = 8954
    //     0x12c3070: mov             x17, #0x22fa
    // 0x12c3074: cmp             x2, x17
    // 0x12c3078: b.lt            #0x12c4c48
    // 0x12c307c: r0 = 8946
    //     0x12c307c: mov             x0, #0x22f2
    // 0x12c3080: LeaveFrame
    //     0x12c3080: mov             SP, fp
    //     0x12c3084: ldp             fp, lr, [SP], #0x10
    // 0x12c3088: ret
    //     0x12c3088: ret             
    // 0x12c308c: r0 = 8947
    //     0x12c308c: mov             x0, #0x22f3
    // 0x12c3090: LeaveFrame
    //     0x12c3090: mov             SP, fp
    //     0x12c3094: ldp             fp, lr, [SP], #0x10
    // 0x12c3098: ret
    //     0x12c3098: ret             
    // 0x12c309c: r17 = 8956
    //     0x12c309c: mov             x17, #0x22fc
    // 0x12c30a0: cmp             x2, x17
    // 0x12c30a4: b.gt            #0x12c30b8
    // 0x12c30a8: r0 = 8948
    //     0x12c30a8: mov             x0, #0x22f4
    // 0x12c30ac: LeaveFrame
    //     0x12c30ac: mov             SP, fp
    //     0x12c30b0: ldp             fp, lr, [SP], #0x10
    // 0x12c30b4: ret
    //     0x12c30b4: ret             
    // 0x12c30b8: r0 = 8950
    //     0x12c30b8: mov             x0, #0x22f6
    // 0x12c30bc: LeaveFrame
    //     0x12c30bc: mov             SP, fp
    //     0x12c30c0: ldp             fp, lr, [SP], #0x10
    // 0x12c30c4: ret
    //     0x12c30c4: ret             
    // 0x12c30c8: r17 = 10180
    //     0x12c30c8: mov             x17, #0x27c4
    // 0x12c30cc: cmp             x2, x17
    // 0x12c30d0: b.gt            #0x12c337c
    // 0x12c30d4: r17 = 10092
    //     0x12c30d4: mov             x17, #0x276c
    // 0x12c30d8: cmp             x2, x17
    // 0x12c30dc: b.gt            #0x12c3248
    // 0x12c30e0: r17 = 9001
    //     0x12c30e0: mov             x17, #0x2329
    // 0x12c30e4: cmp             x2, x17
    // 0x12c30e8: b.gt            #0x12c31a0
    // 0x12c30ec: r17 = 8969
    //     0x12c30ec: mov             x17, #0x2309
    // 0x12c30f0: cmp             x2, x17
    // 0x12c30f4: b.gt            #0x12c314c
    // 0x12c30f8: r17 = 8968
    //     0x12c30f8: mov             x17, #0x2308
    // 0x12c30fc: cmp             x2, x17
    // 0x12c3100: b.gt            #0x12c313c
    // 0x12c3104: r17 = 8958
    //     0x12c3104: mov             x17, #0x22fe
    // 0x12c3108: cmp             x2, x17
    // 0x12c310c: b.gt            #0x12c3120
    // 0x12c3110: r0 = 8951
    //     0x12c3110: mov             x0, #0x22f7
    // 0x12c3114: LeaveFrame
    //     0x12c3114: mov             SP, fp
    //     0x12c3118: ldp             fp, lr, [SP], #0x10
    // 0x12c311c: ret
    //     0x12c311c: ret             
    // 0x12c3120: r17 = 8968
    //     0x12c3120: mov             x17, #0x2308
    // 0x12c3124: cmp             x2, x17
    // 0x12c3128: b.lt            #0x12c4c48
    // 0x12c312c: r0 = 8969
    //     0x12c312c: mov             x0, #0x2309
    // 0x12c3130: LeaveFrame
    //     0x12c3130: mov             SP, fp
    //     0x12c3134: ldp             fp, lr, [SP], #0x10
    // 0x12c3138: ret
    //     0x12c3138: ret             
    // 0x12c313c: r0 = 8968
    //     0x12c313c: mov             x0, #0x2308
    // 0x12c3140: LeaveFrame
    //     0x12c3140: mov             SP, fp
    //     0x12c3144: ldp             fp, lr, [SP], #0x10
    // 0x12c3148: ret
    //     0x12c3148: ret             
    // 0x12c314c: r17 = 8971
    //     0x12c314c: mov             x17, #0x230b
    // 0x12c3150: cmp             x2, x17
    // 0x12c3154: b.gt            #0x12c3184
    // 0x12c3158: r17 = 8970
    //     0x12c3158: mov             x17, #0x230a
    // 0x12c315c: cmp             x2, x17
    // 0x12c3160: b.gt            #0x12c3174
    // 0x12c3164: r0 = 8971
    //     0x12c3164: mov             x0, #0x230b
    // 0x12c3168: LeaveFrame
    //     0x12c3168: mov             SP, fp
    //     0x12c316c: ldp             fp, lr, [SP], #0x10
    // 0x12c3170: ret
    //     0x12c3170: ret             
    // 0x12c3174: r0 = 8970
    //     0x12c3174: mov             x0, #0x230a
    // 0x12c3178: LeaveFrame
    //     0x12c3178: mov             SP, fp
    //     0x12c317c: ldp             fp, lr, [SP], #0x10
    // 0x12c3180: ret
    //     0x12c3180: ret             
    // 0x12c3184: r17 = 9001
    //     0x12c3184: mov             x17, #0x2329
    // 0x12c3188: cmp             x2, x17
    // 0x12c318c: b.lt            #0x12c4c48
    // 0x12c3190: r0 = 9002
    //     0x12c3190: mov             x0, #0x232a
    // 0x12c3194: LeaveFrame
    //     0x12c3194: mov             SP, fp
    //     0x12c3198: ldp             fp, lr, [SP], #0x10
    // 0x12c319c: ret
    //     0x12c319c: ret             
    // 0x12c31a0: r17 = 10089
    //     0x12c31a0: mov             x17, #0x2769
    // 0x12c31a4: cmp             x2, x17
    // 0x12c31a8: b.gt            #0x12c3200
    // 0x12c31ac: r17 = 10088
    //     0x12c31ac: mov             x17, #0x2768
    // 0x12c31b0: cmp             x2, x17
    // 0x12c31b4: b.gt            #0x12c31f0
    // 0x12c31b8: r17 = 9002
    //     0x12c31b8: mov             x17, #0x232a
    // 0x12c31bc: cmp             x2, x17
    // 0x12c31c0: b.gt            #0x12c31d4
    // 0x12c31c4: r0 = 9001
    //     0x12c31c4: mov             x0, #0x2329
    // 0x12c31c8: LeaveFrame
    //     0x12c31c8: mov             SP, fp
    //     0x12c31cc: ldp             fp, lr, [SP], #0x10
    // 0x12c31d0: ret
    //     0x12c31d0: ret             
    // 0x12c31d4: r17 = 10088
    //     0x12c31d4: mov             x17, #0x2768
    // 0x12c31d8: cmp             x2, x17
    // 0x12c31dc: b.lt            #0x12c4c48
    // 0x12c31e0: r0 = 10089
    //     0x12c31e0: mov             x0, #0x2769
    // 0x12c31e4: LeaveFrame
    //     0x12c31e4: mov             SP, fp
    //     0x12c31e8: ldp             fp, lr, [SP], #0x10
    // 0x12c31ec: ret
    //     0x12c31ec: ret             
    // 0x12c31f0: r0 = 10088
    //     0x12c31f0: mov             x0, #0x2768
    // 0x12c31f4: LeaveFrame
    //     0x12c31f4: mov             SP, fp
    //     0x12c31f8: ldp             fp, lr, [SP], #0x10
    // 0x12c31fc: ret
    //     0x12c31fc: ret             
    // 0x12c3200: r17 = 10091
    //     0x12c3200: mov             x17, #0x276b
    // 0x12c3204: cmp             x2, x17
    // 0x12c3208: b.gt            #0x12c3238
    // 0x12c320c: r17 = 10090
    //     0x12c320c: mov             x17, #0x276a
    // 0x12c3210: cmp             x2, x17
    // 0x12c3214: b.gt            #0x12c3228
    // 0x12c3218: r0 = 10091
    //     0x12c3218: mov             x0, #0x276b
    // 0x12c321c: LeaveFrame
    //     0x12c321c: mov             SP, fp
    //     0x12c3220: ldp             fp, lr, [SP], #0x10
    // 0x12c3224: ret
    //     0x12c3224: ret             
    // 0x12c3228: r0 = 10090
    //     0x12c3228: mov             x0, #0x276a
    // 0x12c322c: LeaveFrame
    //     0x12c322c: mov             SP, fp
    //     0x12c3230: ldp             fp, lr, [SP], #0x10
    // 0x12c3234: ret
    //     0x12c3234: ret             
    // 0x12c3238: r0 = 10093
    //     0x12c3238: mov             x0, #0x276d
    // 0x12c323c: LeaveFrame
    //     0x12c323c: mov             SP, fp
    //     0x12c3240: ldp             fp, lr, [SP], #0x10
    // 0x12c3244: ret
    //     0x12c3244: ret             
    // 0x12c3248: r17 = 10098
    //     0x12c3248: mov             x17, #0x2772
    // 0x12c324c: cmp             x2, x17
    // 0x12c3250: b.gt            #0x12c32f0
    // 0x12c3254: r17 = 10095
    //     0x12c3254: mov             x17, #0x276f
    // 0x12c3258: cmp             x2, x17
    // 0x12c325c: b.gt            #0x12c32a8
    // 0x12c3260: r17 = 10094
    //     0x12c3260: mov             x17, #0x276e
    // 0x12c3264: cmp             x2, x17
    // 0x12c3268: b.gt            #0x12c3298
    // 0x12c326c: r17 = 10093
    //     0x12c326c: mov             x17, #0x276d
    // 0x12c3270: cmp             x2, x17
    // 0x12c3274: b.gt            #0x12c3288
    // 0x12c3278: r0 = 10092
    //     0x12c3278: mov             x0, #0x276c
    // 0x12c327c: LeaveFrame
    //     0x12c327c: mov             SP, fp
    //     0x12c3280: ldp             fp, lr, [SP], #0x10
    // 0x12c3284: ret
    //     0x12c3284: ret             
    // 0x12c3288: r0 = 10095
    //     0x12c3288: mov             x0, #0x276f
    // 0x12c328c: LeaveFrame
    //     0x12c328c: mov             SP, fp
    //     0x12c3290: ldp             fp, lr, [SP], #0x10
    // 0x12c3294: ret
    //     0x12c3294: ret             
    // 0x12c3298: r0 = 10094
    //     0x12c3298: mov             x0, #0x276e
    // 0x12c329c: LeaveFrame
    //     0x12c329c: mov             SP, fp
    //     0x12c32a0: ldp             fp, lr, [SP], #0x10
    // 0x12c32a4: ret
    //     0x12c32a4: ret             
    // 0x12c32a8: r17 = 10097
    //     0x12c32a8: mov             x17, #0x2771
    // 0x12c32ac: cmp             x2, x17
    // 0x12c32b0: b.gt            #0x12c32e0
    // 0x12c32b4: r17 = 10096
    //     0x12c32b4: mov             x17, #0x2770
    // 0x12c32b8: cmp             x2, x17
    // 0x12c32bc: b.gt            #0x12c32d0
    // 0x12c32c0: r0 = 10097
    //     0x12c32c0: mov             x0, #0x2771
    // 0x12c32c4: LeaveFrame
    //     0x12c32c4: mov             SP, fp
    //     0x12c32c8: ldp             fp, lr, [SP], #0x10
    // 0x12c32cc: ret
    //     0x12c32cc: ret             
    // 0x12c32d0: r0 = 10096
    //     0x12c32d0: mov             x0, #0x2770
    // 0x12c32d4: LeaveFrame
    //     0x12c32d4: mov             SP, fp
    //     0x12c32d8: ldp             fp, lr, [SP], #0x10
    // 0x12c32dc: ret
    //     0x12c32dc: ret             
    // 0x12c32e0: r0 = 10099
    //     0x12c32e0: mov             x0, #0x2773
    // 0x12c32e4: LeaveFrame
    //     0x12c32e4: mov             SP, fp
    //     0x12c32e8: ldp             fp, lr, [SP], #0x10
    // 0x12c32ec: ret
    //     0x12c32ec: ret             
    // 0x12c32f0: r17 = 10101
    //     0x12c32f0: mov             x17, #0x2775
    // 0x12c32f4: cmp             x2, x17
    // 0x12c32f8: b.gt            #0x12c3344
    // 0x12c32fc: r17 = 10100
    //     0x12c32fc: mov             x17, #0x2774
    // 0x12c3300: cmp             x2, x17
    // 0x12c3304: b.gt            #0x12c3334
    // 0x12c3308: r17 = 10099
    //     0x12c3308: mov             x17, #0x2773
    // 0x12c330c: cmp             x2, x17
    // 0x12c3310: b.gt            #0x12c3324
    // 0x12c3314: r0 = 10098
    //     0x12c3314: mov             x0, #0x2772
    // 0x12c3318: LeaveFrame
    //     0x12c3318: mov             SP, fp
    //     0x12c331c: ldp             fp, lr, [SP], #0x10
    // 0x12c3320: ret
    //     0x12c3320: ret             
    // 0x12c3324: r0 = 10101
    //     0x12c3324: mov             x0, #0x2775
    // 0x12c3328: LeaveFrame
    //     0x12c3328: mov             SP, fp
    //     0x12c332c: ldp             fp, lr, [SP], #0x10
    // 0x12c3330: ret
    //     0x12c3330: ret             
    // 0x12c3334: r0 = 10100
    //     0x12c3334: mov             x0, #0x2774
    // 0x12c3338: LeaveFrame
    //     0x12c3338: mov             SP, fp
    //     0x12c333c: ldp             fp, lr, [SP], #0x10
    // 0x12c3340: ret
    //     0x12c3340: ret             
    // 0x12c3344: r17 = 10179
    //     0x12c3344: mov             x17, #0x27c3
    // 0x12c3348: cmp             x2, x17
    // 0x12c334c: b.lt            #0x12c4c48
    // 0x12c3350: r17 = 10179
    //     0x12c3350: mov             x17, #0x27c3
    // 0x12c3354: cmp             x2, x17
    // 0x12c3358: b.gt            #0x12c336c
    // 0x12c335c: r0 = 10180
    //     0x12c335c: mov             x0, #0x27c4
    // 0x12c3360: LeaveFrame
    //     0x12c3360: mov             SP, fp
    //     0x12c3364: ldp             fp, lr, [SP], #0x10
    // 0x12c3368: ret
    //     0x12c3368: ret             
    // 0x12c336c: r0 = 10179
    //     0x12c336c: mov             x0, #0x27c3
    // 0x12c3370: LeaveFrame
    //     0x12c3370: mov             SP, fp
    //     0x12c3374: ldp             fp, lr, [SP], #0x10
    // 0x12c3378: ret
    //     0x12c3378: ret             
    // 0x12c337c: r17 = 10210
    //     0x12c337c: mov             x17, #0x27e2
    // 0x12c3380: cmp             x2, x17
    // 0x12c3384: b.gt            #0x12c34f8
    // 0x12c3388: r17 = 10189
    //     0x12c3388: mov             x17, #0x27cd
    // 0x12c338c: cmp             x2, x17
    // 0x12c3390: b.gt            #0x12c3454
    // 0x12c3394: r17 = 10184
    //     0x12c3394: mov             x17, #0x27c8
    // 0x12c3398: cmp             x2, x17
    // 0x12c339c: b.gt            #0x12c33f4
    // 0x12c33a0: r17 = 10182
    //     0x12c33a0: mov             x17, #0x27c6
    // 0x12c33a4: cmp             x2, x17
    // 0x12c33a8: b.gt            #0x12c33d8
    // 0x12c33ac: r17 = 10181
    //     0x12c33ac: mov             x17, #0x27c5
    // 0x12c33b0: cmp             x2, x17
    // 0x12c33b4: b.gt            #0x12c33c8
    // 0x12c33b8: r0 = 10182
    //     0x12c33b8: mov             x0, #0x27c6
    // 0x12c33bc: LeaveFrame
    //     0x12c33bc: mov             SP, fp
    //     0x12c33c0: ldp             fp, lr, [SP], #0x10
    // 0x12c33c4: ret
    //     0x12c33c4: ret             
    // 0x12c33c8: r0 = 10181
    //     0x12c33c8: mov             x0, #0x27c5
    // 0x12c33cc: LeaveFrame
    //     0x12c33cc: mov             SP, fp
    //     0x12c33d0: ldp             fp, lr, [SP], #0x10
    // 0x12c33d4: ret
    //     0x12c33d4: ret             
    // 0x12c33d8: r17 = 10184
    //     0x12c33d8: mov             x17, #0x27c8
    // 0x12c33dc: cmp             x2, x17
    // 0x12c33e0: b.lt            #0x12c4c48
    // 0x12c33e4: r0 = 10185
    //     0x12c33e4: mov             x0, #0x27c9
    // 0x12c33e8: LeaveFrame
    //     0x12c33e8: mov             SP, fp
    //     0x12c33ec: ldp             fp, lr, [SP], #0x10
    // 0x12c33f0: ret
    //     0x12c33f0: ret             
    // 0x12c33f4: r17 = 10187
    //     0x12c33f4: mov             x17, #0x27cb
    // 0x12c33f8: cmp             x2, x17
    // 0x12c33fc: b.gt            #0x12c3438
    // 0x12c3400: r17 = 10185
    //     0x12c3400: mov             x17, #0x27c9
    // 0x12c3404: cmp             x2, x17
    // 0x12c3408: b.gt            #0x12c341c
    // 0x12c340c: r0 = 10184
    //     0x12c340c: mov             x0, #0x27c8
    // 0x12c3410: LeaveFrame
    //     0x12c3410: mov             SP, fp
    //     0x12c3414: ldp             fp, lr, [SP], #0x10
    // 0x12c3418: ret
    //     0x12c3418: ret             
    // 0x12c341c: r17 = 10187
    //     0x12c341c: mov             x17, #0x27cb
    // 0x12c3420: cmp             x2, x17
    // 0x12c3424: b.lt            #0x12c4c48
    // 0x12c3428: r0 = 10189
    //     0x12c3428: mov             x0, #0x27cd
    // 0x12c342c: LeaveFrame
    //     0x12c342c: mov             SP, fp
    //     0x12c3430: ldp             fp, lr, [SP], #0x10
    // 0x12c3434: ret
    //     0x12c3434: ret             
    // 0x12c3438: r17 = 10189
    //     0x12c3438: mov             x17, #0x27cd
    // 0x12c343c: cmp             x2, x17
    // 0x12c3440: b.lt            #0x12c4c48
    // 0x12c3444: r0 = 10187
    //     0x12c3444: mov             x0, #0x27cb
    // 0x12c3448: LeaveFrame
    //     0x12c3448: mov             SP, fp
    //     0x12c344c: ldp             fp, lr, [SP], #0x10
    // 0x12c3450: ret
    //     0x12c3450: ret             
    // 0x12c3454: r17 = 10197
    //     0x12c3454: mov             x17, #0x27d5
    // 0x12c3458: cmp             x2, x17
    // 0x12c345c: b.lt            #0x12c4c48
    // 0x12c3460: r17 = 10205
    //     0x12c3460: mov             x17, #0x27dd
    // 0x12c3464: cmp             x2, x17
    // 0x12c3468: b.gt            #0x12c34c0
    // 0x12c346c: r17 = 10198
    //     0x12c346c: mov             x17, #0x27d6
    // 0x12c3470: cmp             x2, x17
    // 0x12c3474: b.gt            #0x12c34a4
    // 0x12c3478: r17 = 10197
    //     0x12c3478: mov             x17, #0x27d5
    // 0x12c347c: cmp             x2, x17
    // 0x12c3480: b.gt            #0x12c3494
    // 0x12c3484: r0 = 10198
    //     0x12c3484: mov             x0, #0x27d6
    // 0x12c3488: LeaveFrame
    //     0x12c3488: mov             SP, fp
    //     0x12c348c: ldp             fp, lr, [SP], #0x10
    // 0x12c3490: ret
    //     0x12c3490: ret             
    // 0x12c3494: r0 = 10197
    //     0x12c3494: mov             x0, #0x27d5
    // 0x12c3498: LeaveFrame
    //     0x12c3498: mov             SP, fp
    //     0x12c349c: ldp             fp, lr, [SP], #0x10
    // 0x12c34a0: ret
    //     0x12c34a0: ret             
    // 0x12c34a4: r17 = 10205
    //     0x12c34a4: mov             x17, #0x27dd
    // 0x12c34a8: cmp             x2, x17
    // 0x12c34ac: b.lt            #0x12c4c48
    // 0x12c34b0: r0 = 10206
    //     0x12c34b0: mov             x0, #0x27de
    // 0x12c34b4: LeaveFrame
    //     0x12c34b4: mov             SP, fp
    //     0x12c34b8: ldp             fp, lr, [SP], #0x10
    // 0x12c34bc: ret
    //     0x12c34bc: ret             
    // 0x12c34c0: r17 = 10206
    //     0x12c34c0: mov             x17, #0x27de
    // 0x12c34c4: cmp             x2, x17
    // 0x12c34c8: b.gt            #0x12c34dc
    // 0x12c34cc: r0 = 10205
    //     0x12c34cc: mov             x0, #0x27dd
    // 0x12c34d0: LeaveFrame
    //     0x12c34d0: mov             SP, fp
    //     0x12c34d4: ldp             fp, lr, [SP], #0x10
    // 0x12c34d8: ret
    //     0x12c34d8: ret             
    // 0x12c34dc: r17 = 10210
    //     0x12c34dc: mov             x17, #0x27e2
    // 0x12c34e0: cmp             x2, x17
    // 0x12c34e4: b.lt            #0x12c4c48
    // 0x12c34e8: r0 = 10211
    //     0x12c34e8: mov             x0, #0x27e3
    // 0x12c34ec: LeaveFrame
    //     0x12c34ec: mov             SP, fp
    //     0x12c34f0: ldp             fp, lr, [SP], #0x10
    // 0x12c34f4: ret
    //     0x12c34f4: ret             
    // 0x12c34f8: r17 = 10216
    //     0x12c34f8: mov             x17, #0x27e8
    // 0x12c34fc: cmp             x2, x17
    // 0x12c3500: b.gt            #0x12c35a0
    // 0x12c3504: r17 = 10213
    //     0x12c3504: mov             x17, #0x27e5
    // 0x12c3508: cmp             x2, x17
    // 0x12c350c: b.gt            #0x12c3558
    // 0x12c3510: r17 = 10212
    //     0x12c3510: mov             x17, #0x27e4
    // 0x12c3514: cmp             x2, x17
    // 0x12c3518: b.gt            #0x12c3548
    // 0x12c351c: r17 = 10211
    //     0x12c351c: mov             x17, #0x27e3
    // 0x12c3520: cmp             x2, x17
    // 0x12c3524: b.gt            #0x12c3538
    // 0x12c3528: r0 = 10210
    //     0x12c3528: mov             x0, #0x27e2
    // 0x12c352c: LeaveFrame
    //     0x12c352c: mov             SP, fp
    //     0x12c3530: ldp             fp, lr, [SP], #0x10
    // 0x12c3534: ret
    //     0x12c3534: ret             
    // 0x12c3538: r0 = 10213
    //     0x12c3538: mov             x0, #0x27e5
    // 0x12c353c: LeaveFrame
    //     0x12c353c: mov             SP, fp
    //     0x12c3540: ldp             fp, lr, [SP], #0x10
    // 0x12c3544: ret
    //     0x12c3544: ret             
    // 0x12c3548: r0 = 10212
    //     0x12c3548: mov             x0, #0x27e4
    // 0x12c354c: LeaveFrame
    //     0x12c354c: mov             SP, fp
    //     0x12c3550: ldp             fp, lr, [SP], #0x10
    // 0x12c3554: ret
    //     0x12c3554: ret             
    // 0x12c3558: r17 = 10215
    //     0x12c3558: mov             x17, #0x27e7
    // 0x12c355c: cmp             x2, x17
    // 0x12c3560: b.gt            #0x12c3590
    // 0x12c3564: r17 = 10214
    //     0x12c3564: mov             x17, #0x27e6
    // 0x12c3568: cmp             x2, x17
    // 0x12c356c: b.gt            #0x12c3580
    // 0x12c3570: r0 = 10215
    //     0x12c3570: mov             x0, #0x27e7
    // 0x12c3574: LeaveFrame
    //     0x12c3574: mov             SP, fp
    //     0x12c3578: ldp             fp, lr, [SP], #0x10
    // 0x12c357c: ret
    //     0x12c357c: ret             
    // 0x12c3580: r0 = 10214
    //     0x12c3580: mov             x0, #0x27e6
    // 0x12c3584: LeaveFrame
    //     0x12c3584: mov             SP, fp
    //     0x12c3588: ldp             fp, lr, [SP], #0x10
    // 0x12c358c: ret
    //     0x12c358c: ret             
    // 0x12c3590: r0 = 10217
    //     0x12c3590: mov             x0, #0x27e9
    // 0x12c3594: LeaveFrame
    //     0x12c3594: mov             SP, fp
    //     0x12c3598: ldp             fp, lr, [SP], #0x10
    // 0x12c359c: ret
    //     0x12c359c: ret             
    // 0x12c35a0: r17 = 10219
    //     0x12c35a0: mov             x17, #0x27eb
    // 0x12c35a4: cmp             x2, x17
    // 0x12c35a8: b.gt            #0x12c35f4
    // 0x12c35ac: r17 = 10218
    //     0x12c35ac: mov             x17, #0x27ea
    // 0x12c35b0: cmp             x2, x17
    // 0x12c35b4: b.gt            #0x12c35e4
    // 0x12c35b8: r17 = 10217
    //     0x12c35b8: mov             x17, #0x27e9
    // 0x12c35bc: cmp             x2, x17
    // 0x12c35c0: b.gt            #0x12c35d4
    // 0x12c35c4: r0 = 10216
    //     0x12c35c4: mov             x0, #0x27e8
    // 0x12c35c8: LeaveFrame
    //     0x12c35c8: mov             SP, fp
    //     0x12c35cc: ldp             fp, lr, [SP], #0x10
    // 0x12c35d0: ret
    //     0x12c35d0: ret             
    // 0x12c35d4: r0 = 10219
    //     0x12c35d4: mov             x0, #0x27eb
    // 0x12c35d8: LeaveFrame
    //     0x12c35d8: mov             SP, fp
    //     0x12c35dc: ldp             fp, lr, [SP], #0x10
    // 0x12c35e0: ret
    //     0x12c35e0: ret             
    // 0x12c35e4: r0 = 10218
    //     0x12c35e4: mov             x0, #0x27ea
    // 0x12c35e8: LeaveFrame
    //     0x12c35e8: mov             SP, fp
    //     0x12c35ec: ldp             fp, lr, [SP], #0x10
    // 0x12c35f0: ret
    //     0x12c35f0: ret             
    // 0x12c35f4: r17 = 10220
    //     0x12c35f4: mov             x17, #0x27ec
    // 0x12c35f8: cmp             x2, x17
    // 0x12c35fc: b.gt            #0x12c3610
    // 0x12c3600: r0 = 10221
    //     0x12c3600: mov             x0, #0x27ed
    // 0x12c3604: LeaveFrame
    //     0x12c3604: mov             SP, fp
    //     0x12c3608: ldp             fp, lr, [SP], #0x10
    // 0x12c360c: ret
    //     0x12c360c: ret             
    // 0x12c3610: r0 = 10220
    //     0x12c3610: mov             x0, #0x27ec
    // 0x12c3614: LeaveFrame
    //     0x12c3614: mov             SP, fp
    //     0x12c3618: ldp             fp, lr, [SP], #0x10
    // 0x12c361c: ret
    //     0x12c361c: ret             
    // 0x12c3620: r17 = 10931
    //     0x12c3620: mov             x17, #0x2ab3
    // 0x12c3624: cmp             x2, x17
    // 0x12c3628: b.gt            #0x12c411c
    // 0x12c362c: r17 = 10796
    //     0x12c362c: mov             x17, #0x2a2c
    // 0x12c3630: cmp             x2, x17
    // 0x12c3634: b.gt            #0x12c3bb8
    // 0x12c3638: r17 = 10647
    //     0x12c3638: mov             x17, #0x2997
    // 0x12c363c: cmp             x2, x17
    // 0x12c3640: b.gt            #0x12c38c8
    // 0x12c3644: r17 = 10636
    //     0x12c3644: mov             x17, #0x298c
    // 0x12c3648: cmp             x2, x17
    // 0x12c364c: b.gt            #0x12c37a0
    // 0x12c3650: r17 = 10630
    //     0x12c3650: mov             x17, #0x2986
    // 0x12c3654: cmp             x2, x17
    // 0x12c3658: b.gt            #0x12c3704
    // 0x12c365c: r17 = 10627
    //     0x12c365c: mov             x17, #0x2983
    // 0x12c3660: cmp             x2, x17
    // 0x12c3664: b.gt            #0x12c36bc
    // 0x12c3668: r17 = 10223
    //     0x12c3668: mov             x17, #0x27ef
    // 0x12c366c: cmp             x2, x17
    // 0x12c3670: b.gt            #0x12c36a0
    // 0x12c3674: r17 = 10222
    //     0x12c3674: mov             x17, #0x27ee
    // 0x12c3678: cmp             x2, x17
    // 0x12c367c: b.gt            #0x12c3690
    // 0x12c3680: r0 = 10223
    //     0x12c3680: mov             x0, #0x27ef
    // 0x12c3684: LeaveFrame
    //     0x12c3684: mov             SP, fp
    //     0x12c3688: ldp             fp, lr, [SP], #0x10
    // 0x12c368c: ret
    //     0x12c368c: ret             
    // 0x12c3690: r0 = 10222
    //     0x12c3690: mov             x0, #0x27ee
    // 0x12c3694: LeaveFrame
    //     0x12c3694: mov             SP, fp
    //     0x12c3698: ldp             fp, lr, [SP], #0x10
    // 0x12c369c: ret
    //     0x12c369c: ret             
    // 0x12c36a0: r17 = 10627
    //     0x12c36a0: mov             x17, #0x2983
    // 0x12c36a4: cmp             x2, x17
    // 0x12c36a8: b.lt            #0x12c4c48
    // 0x12c36ac: r0 = 10628
    //     0x12c36ac: mov             x0, #0x2984
    // 0x12c36b0: LeaveFrame
    //     0x12c36b0: mov             SP, fp
    //     0x12c36b4: ldp             fp, lr, [SP], #0x10
    // 0x12c36b8: ret
    //     0x12c36b8: ret             
    // 0x12c36bc: r17 = 10629
    //     0x12c36bc: mov             x17, #0x2985
    // 0x12c36c0: cmp             x2, x17
    // 0x12c36c4: b.gt            #0x12c36f4
    // 0x12c36c8: r17 = 10628
    //     0x12c36c8: mov             x17, #0x2984
    // 0x12c36cc: cmp             x2, x17
    // 0x12c36d0: b.gt            #0x12c36e4
    // 0x12c36d4: r0 = 10627
    //     0x12c36d4: mov             x0, #0x2983
    // 0x12c36d8: LeaveFrame
    //     0x12c36d8: mov             SP, fp
    //     0x12c36dc: ldp             fp, lr, [SP], #0x10
    // 0x12c36e0: ret
    //     0x12c36e0: ret             
    // 0x12c36e4: r0 = 10630
    //     0x12c36e4: mov             x0, #0x2986
    // 0x12c36e8: LeaveFrame
    //     0x12c36e8: mov             SP, fp
    //     0x12c36ec: ldp             fp, lr, [SP], #0x10
    // 0x12c36f0: ret
    //     0x12c36f0: ret             
    // 0x12c36f4: r0 = 10629
    //     0x12c36f4: mov             x0, #0x2985
    // 0x12c36f8: LeaveFrame
    //     0x12c36f8: mov             SP, fp
    //     0x12c36fc: ldp             fp, lr, [SP], #0x10
    // 0x12c3700: ret
    //     0x12c3700: ret             
    // 0x12c3704: r17 = 10633
    //     0x12c3704: mov             x17, #0x2989
    // 0x12c3708: cmp             x2, x17
    // 0x12c370c: b.gt            #0x12c3758
    // 0x12c3710: r17 = 10632
    //     0x12c3710: mov             x17, #0x2988
    // 0x12c3714: cmp             x2, x17
    // 0x12c3718: b.gt            #0x12c3748
    // 0x12c371c: r17 = 10631
    //     0x12c371c: mov             x17, #0x2987
    // 0x12c3720: cmp             x2, x17
    // 0x12c3724: b.gt            #0x12c3738
    // 0x12c3728: r0 = 10632
    //     0x12c3728: mov             x0, #0x2988
    // 0x12c372c: LeaveFrame
    //     0x12c372c: mov             SP, fp
    //     0x12c3730: ldp             fp, lr, [SP], #0x10
    // 0x12c3734: ret
    //     0x12c3734: ret             
    // 0x12c3738: r0 = 10631
    //     0x12c3738: mov             x0, #0x2987
    // 0x12c373c: LeaveFrame
    //     0x12c373c: mov             SP, fp
    //     0x12c3740: ldp             fp, lr, [SP], #0x10
    // 0x12c3744: ret
    //     0x12c3744: ret             
    // 0x12c3748: r0 = 10634
    //     0x12c3748: mov             x0, #0x298a
    // 0x12c374c: LeaveFrame
    //     0x12c374c: mov             SP, fp
    //     0x12c3750: ldp             fp, lr, [SP], #0x10
    // 0x12c3754: ret
    //     0x12c3754: ret             
    // 0x12c3758: r17 = 10635
    //     0x12c3758: mov             x17, #0x298b
    // 0x12c375c: cmp             x2, x17
    // 0x12c3760: b.gt            #0x12c3790
    // 0x12c3764: r17 = 10634
    //     0x12c3764: mov             x17, #0x298a
    // 0x12c3768: cmp             x2, x17
    // 0x12c376c: b.gt            #0x12c3780
    // 0x12c3770: r0 = 10633
    //     0x12c3770: mov             x0, #0x2989
    // 0x12c3774: LeaveFrame
    //     0x12c3774: mov             SP, fp
    //     0x12c3778: ldp             fp, lr, [SP], #0x10
    // 0x12c377c: ret
    //     0x12c377c: ret             
    // 0x12c3780: r0 = 10636
    //     0x12c3780: mov             x0, #0x298c
    // 0x12c3784: LeaveFrame
    //     0x12c3784: mov             SP, fp
    //     0x12c3788: ldp             fp, lr, [SP], #0x10
    // 0x12c378c: ret
    //     0x12c378c: ret             
    // 0x12c3790: r0 = 10635
    //     0x12c3790: mov             x0, #0x298b
    // 0x12c3794: LeaveFrame
    //     0x12c3794: mov             SP, fp
    //     0x12c3798: ldp             fp, lr, [SP], #0x10
    // 0x12c379c: ret
    //     0x12c379c: ret             
    // 0x12c37a0: r17 = 10642
    //     0x12c37a0: mov             x17, #0x2992
    // 0x12c37a4: cmp             x2, x17
    // 0x12c37a8: b.gt            #0x12c3848
    // 0x12c37ac: r17 = 10639
    //     0x12c37ac: mov             x17, #0x298f
    // 0x12c37b0: cmp             x2, x17
    // 0x12c37b4: b.gt            #0x12c3800
    // 0x12c37b8: r17 = 10638
    //     0x12c37b8: mov             x17, #0x298e
    // 0x12c37bc: cmp             x2, x17
    // 0x12c37c0: b.gt            #0x12c37f0
    // 0x12c37c4: r17 = 10637
    //     0x12c37c4: mov             x17, #0x298d
    // 0x12c37c8: cmp             x2, x17
    // 0x12c37cc: b.gt            #0x12c37e0
    // 0x12c37d0: r0 = 10640
    //     0x12c37d0: mov             x0, #0x2990
    // 0x12c37d4: LeaveFrame
    //     0x12c37d4: mov             SP, fp
    //     0x12c37d8: ldp             fp, lr, [SP], #0x10
    // 0x12c37dc: ret
    //     0x12c37dc: ret             
    // 0x12c37e0: r0 = 10639
    //     0x12c37e0: mov             x0, #0x298f
    // 0x12c37e4: LeaveFrame
    //     0x12c37e4: mov             SP, fp
    //     0x12c37e8: ldp             fp, lr, [SP], #0x10
    // 0x12c37ec: ret
    //     0x12c37ec: ret             
    // 0x12c37f0: r0 = 10638
    //     0x12c37f0: mov             x0, #0x298e
    // 0x12c37f4: LeaveFrame
    //     0x12c37f4: mov             SP, fp
    //     0x12c37f8: ldp             fp, lr, [SP], #0x10
    // 0x12c37fc: ret
    //     0x12c37fc: ret             
    // 0x12c3800: r17 = 10641
    //     0x12c3800: mov             x17, #0x2991
    // 0x12c3804: cmp             x2, x17
    // 0x12c3808: b.gt            #0x12c3838
    // 0x12c380c: r17 = 10640
    //     0x12c380c: mov             x17, #0x2990
    // 0x12c3810: cmp             x2, x17
    // 0x12c3814: b.gt            #0x12c3828
    // 0x12c3818: r0 = 10637
    //     0x12c3818: mov             x0, #0x298d
    // 0x12c381c: LeaveFrame
    //     0x12c381c: mov             SP, fp
    //     0x12c3820: ldp             fp, lr, [SP], #0x10
    // 0x12c3824: ret
    //     0x12c3824: ret             
    // 0x12c3828: r0 = 10642
    //     0x12c3828: mov             x0, #0x2992
    // 0x12c382c: LeaveFrame
    //     0x12c382c: mov             SP, fp
    //     0x12c3830: ldp             fp, lr, [SP], #0x10
    // 0x12c3834: ret
    //     0x12c3834: ret             
    // 0x12c3838: r0 = 10641
    //     0x12c3838: mov             x0, #0x2991
    // 0x12c383c: LeaveFrame
    //     0x12c383c: mov             SP, fp
    //     0x12c3840: ldp             fp, lr, [SP], #0x10
    // 0x12c3844: ret
    //     0x12c3844: ret             
    // 0x12c3848: r17 = 10645
    //     0x12c3848: mov             x17, #0x2995
    // 0x12c384c: cmp             x2, x17
    // 0x12c3850: b.gt            #0x12c389c
    // 0x12c3854: r17 = 10644
    //     0x12c3854: mov             x17, #0x2994
    // 0x12c3858: cmp             x2, x17
    // 0x12c385c: b.gt            #0x12c388c
    // 0x12c3860: r17 = 10643
    //     0x12c3860: mov             x17, #0x2993
    // 0x12c3864: cmp             x2, x17
    // 0x12c3868: b.gt            #0x12c387c
    // 0x12c386c: r0 = 10644
    //     0x12c386c: mov             x0, #0x2994
    // 0x12c3870: LeaveFrame
    //     0x12c3870: mov             SP, fp
    //     0x12c3874: ldp             fp, lr, [SP], #0x10
    // 0x12c3878: ret
    //     0x12c3878: ret             
    // 0x12c387c: r0 = 10643
    //     0x12c387c: mov             x0, #0x2993
    // 0x12c3880: LeaveFrame
    //     0x12c3880: mov             SP, fp
    //     0x12c3884: ldp             fp, lr, [SP], #0x10
    // 0x12c3888: ret
    //     0x12c3888: ret             
    // 0x12c388c: r0 = 10646
    //     0x12c388c: mov             x0, #0x2996
    // 0x12c3890: LeaveFrame
    //     0x12c3890: mov             SP, fp
    //     0x12c3894: ldp             fp, lr, [SP], #0x10
    // 0x12c3898: ret
    //     0x12c3898: ret             
    // 0x12c389c: r17 = 10646
    //     0x12c389c: mov             x17, #0x2996
    // 0x12c38a0: cmp             x2, x17
    // 0x12c38a4: b.gt            #0x12c38b8
    // 0x12c38a8: r0 = 10645
    //     0x12c38a8: mov             x0, #0x2995
    // 0x12c38ac: LeaveFrame
    //     0x12c38ac: mov             SP, fp
    //     0x12c38b0: ldp             fp, lr, [SP], #0x10
    // 0x12c38b4: ret
    //     0x12c38b4: ret             
    // 0x12c38b8: r0 = 10648
    //     0x12c38b8: mov             x0, #0x2998
    // 0x12c38bc: LeaveFrame
    //     0x12c38bc: mov             SP, fp
    //     0x12c38c0: ldp             fp, lr, [SP], #0x10
    // 0x12c38c4: ret
    //     0x12c38c4: ret             
    // 0x12c38c8: r17 = 10709
    //     0x12c38c8: mov             x17, #0x29d5
    // 0x12c38cc: cmp             x2, x17
    // 0x12c38d0: b.gt            #0x12c3a54
    // 0x12c38d4: r17 = 10693
    //     0x12c38d4: mov             x17, #0x29c5
    // 0x12c38d8: cmp             x2, x17
    // 0x12c38dc: b.gt            #0x12c39a0
    // 0x12c38e0: r17 = 10688
    //     0x12c38e0: mov             x17, #0x29c0
    // 0x12c38e4: cmp             x2, x17
    // 0x12c38e8: b.gt            #0x12c394c
    // 0x12c38ec: r17 = 10680
    //     0x12c38ec: mov             x17, #0x29b8
    // 0x12c38f0: cmp             x2, x17
    // 0x12c38f4: b.gt            #0x12c3930
    // 0x12c38f8: r17 = 10648
    //     0x12c38f8: mov             x17, #0x2998
    // 0x12c38fc: cmp             x2, x17
    // 0x12c3900: b.gt            #0x12c3914
    // 0x12c3904: r0 = 10647
    //     0x12c3904: mov             x0, #0x2997
    // 0x12c3908: LeaveFrame
    //     0x12c3908: mov             SP, fp
    //     0x12c390c: ldp             fp, lr, [SP], #0x10
    // 0x12c3910: ret
    //     0x12c3910: ret             
    // 0x12c3914: r17 = 10680
    //     0x12c3914: mov             x17, #0x29b8
    // 0x12c3918: cmp             x2, x17
    // 0x12c391c: b.lt            #0x12c4c48
    // 0x12c3920: r0 = 8856
    //     0x12c3920: mov             x0, #0x2298
    // 0x12c3924: LeaveFrame
    //     0x12c3924: mov             SP, fp
    //     0x12c3928: ldp             fp, lr, [SP], #0x10
    // 0x12c392c: ret
    //     0x12c392c: ret             
    // 0x12c3930: r17 = 10688
    //     0x12c3930: mov             x17, #0x29c0
    // 0x12c3934: cmp             x2, x17
    // 0x12c3938: b.lt            #0x12c4c48
    // 0x12c393c: r0 = 10689
    //     0x12c393c: mov             x0, #0x29c1
    // 0x12c3940: LeaveFrame
    //     0x12c3940: mov             SP, fp
    //     0x12c3944: ldp             fp, lr, [SP], #0x10
    // 0x12c3948: ret
    //     0x12c3948: ret             
    // 0x12c394c: r17 = 10692
    //     0x12c394c: mov             x17, #0x29c4
    // 0x12c3950: cmp             x2, x17
    // 0x12c3954: b.gt            #0x12c3990
    // 0x12c3958: r17 = 10689
    //     0x12c3958: mov             x17, #0x29c1
    // 0x12c395c: cmp             x2, x17
    // 0x12c3960: b.gt            #0x12c3974
    // 0x12c3964: r0 = 10688
    //     0x12c3964: mov             x0, #0x29c0
    // 0x12c3968: LeaveFrame
    //     0x12c3968: mov             SP, fp
    //     0x12c396c: ldp             fp, lr, [SP], #0x10
    // 0x12c3970: ret
    //     0x12c3970: ret             
    // 0x12c3974: r17 = 10692
    //     0x12c3974: mov             x17, #0x29c4
    // 0x12c3978: cmp             x2, x17
    // 0x12c397c: b.lt            #0x12c4c48
    // 0x12c3980: r0 = 10693
    //     0x12c3980: mov             x0, #0x29c5
    // 0x12c3984: LeaveFrame
    //     0x12c3984: mov             SP, fp
    //     0x12c3988: ldp             fp, lr, [SP], #0x10
    // 0x12c398c: ret
    //     0x12c398c: ret             
    // 0x12c3990: r0 = 10692
    //     0x12c3990: mov             x0, #0x29c4
    // 0x12c3994: LeaveFrame
    //     0x12c3994: mov             SP, fp
    //     0x12c3998: ldp             fp, lr, [SP], #0x10
    // 0x12c399c: ret
    //     0x12c399c: ret             
    // 0x12c39a0: r17 = 10703
    //     0x12c39a0: mov             x17, #0x29cf
    // 0x12c39a4: cmp             x2, x17
    // 0x12c39a8: b.lt            #0x12c4c48
    // 0x12c39ac: r17 = 10705
    //     0x12c39ac: mov             x17, #0x29d1
    // 0x12c39b0: cmp             x2, x17
    // 0x12c39b4: b.gt            #0x12c3a00
    // 0x12c39b8: r17 = 10704
    //     0x12c39b8: mov             x17, #0x29d0
    // 0x12c39bc: cmp             x2, x17
    // 0x12c39c0: b.gt            #0x12c39f0
    // 0x12c39c4: r17 = 10703
    //     0x12c39c4: mov             x17, #0x29cf
    // 0x12c39c8: cmp             x2, x17
    // 0x12c39cc: b.gt            #0x12c39e0
    // 0x12c39d0: r0 = 10704
    //     0x12c39d0: mov             x0, #0x29d0
    // 0x12c39d4: LeaveFrame
    //     0x12c39d4: mov             SP, fp
    //     0x12c39d8: ldp             fp, lr, [SP], #0x10
    // 0x12c39dc: ret
    //     0x12c39dc: ret             
    // 0x12c39e0: r0 = 10703
    //     0x12c39e0: mov             x0, #0x29cf
    // 0x12c39e4: LeaveFrame
    //     0x12c39e4: mov             SP, fp
    //     0x12c39e8: ldp             fp, lr, [SP], #0x10
    // 0x12c39ec: ret
    //     0x12c39ec: ret             
    // 0x12c39f0: r0 = 10706
    //     0x12c39f0: mov             x0, #0x29d2
    // 0x12c39f4: LeaveFrame
    //     0x12c39f4: mov             SP, fp
    //     0x12c39f8: ldp             fp, lr, [SP], #0x10
    // 0x12c39fc: ret
    //     0x12c39fc: ret             
    // 0x12c3a00: r17 = 10708
    //     0x12c3a00: mov             x17, #0x29d4
    // 0x12c3a04: cmp             x2, x17
    // 0x12c3a08: b.gt            #0x12c3a44
    // 0x12c3a0c: r17 = 10706
    //     0x12c3a0c: mov             x17, #0x29d2
    // 0x12c3a10: cmp             x2, x17
    // 0x12c3a14: b.gt            #0x12c3a28
    // 0x12c3a18: r0 = 10705
    //     0x12c3a18: mov             x0, #0x29d1
    // 0x12c3a1c: LeaveFrame
    //     0x12c3a1c: mov             SP, fp
    //     0x12c3a20: ldp             fp, lr, [SP], #0x10
    // 0x12c3a24: ret
    //     0x12c3a24: ret             
    // 0x12c3a28: r17 = 10708
    //     0x12c3a28: mov             x17, #0x29d4
    // 0x12c3a2c: cmp             x2, x17
    // 0x12c3a30: b.lt            #0x12c4c48
    // 0x12c3a34: r0 = 10709
    //     0x12c3a34: mov             x0, #0x29d5
    // 0x12c3a38: LeaveFrame
    //     0x12c3a38: mov             SP, fp
    //     0x12c3a3c: ldp             fp, lr, [SP], #0x10
    // 0x12c3a40: ret
    //     0x12c3a40: ret             
    // 0x12c3a44: r0 = 10708
    //     0x12c3a44: mov             x0, #0x29d4
    // 0x12c3a48: LeaveFrame
    //     0x12c3a48: mov             SP, fp
    //     0x12c3a4c: ldp             fp, lr, [SP], #0x10
    // 0x12c3a50: ret
    //     0x12c3a50: ret             
    // 0x12c3a54: r17 = 10712
    //     0x12c3a54: mov             x17, #0x29d8
    // 0x12c3a58: cmp             x2, x17
    // 0x12c3a5c: b.lt            #0x12c4c48
    // 0x12c3a60: r17 = 10744
    //     0x12c3a60: mov             x17, #0x29f8
    // 0x12c3a64: cmp             x2, x17
    // 0x12c3a68: b.gt            #0x12c3b20
    // 0x12c3a6c: r17 = 10714
    //     0x12c3a6c: mov             x17, #0x29da
    // 0x12c3a70: cmp             x2, x17
    // 0x12c3a74: b.gt            #0x12c3ac0
    // 0x12c3a78: r17 = 10713
    //     0x12c3a78: mov             x17, #0x29d9
    // 0x12c3a7c: cmp             x2, x17
    // 0x12c3a80: b.gt            #0x12c3ab0
    // 0x12c3a84: r17 = 10712
    //     0x12c3a84: mov             x17, #0x29d8
    // 0x12c3a88: cmp             x2, x17
    // 0x12c3a8c: b.gt            #0x12c3aa0
    // 0x12c3a90: r0 = 10713
    //     0x12c3a90: mov             x0, #0x29d9
    // 0x12c3a94: LeaveFrame
    //     0x12c3a94: mov             SP, fp
    //     0x12c3a98: ldp             fp, lr, [SP], #0x10
    // 0x12c3a9c: ret
    //     0x12c3a9c: ret             
    // 0x12c3aa0: r0 = 10712
    //     0x12c3aa0: mov             x0, #0x29d8
    // 0x12c3aa4: LeaveFrame
    //     0x12c3aa4: mov             SP, fp
    //     0x12c3aa8: ldp             fp, lr, [SP], #0x10
    // 0x12c3aac: ret
    //     0x12c3aac: ret             
    // 0x12c3ab0: r0 = 10715
    //     0x12c3ab0: mov             x0, #0x29db
    // 0x12c3ab4: LeaveFrame
    //     0x12c3ab4: mov             SP, fp
    //     0x12c3ab8: ldp             fp, lr, [SP], #0x10
    // 0x12c3abc: ret
    //     0x12c3abc: ret             
    // 0x12c3ac0: r17 = 10741
    //     0x12c3ac0: mov             x17, #0x29f5
    // 0x12c3ac4: cmp             x2, x17
    // 0x12c3ac8: b.gt            #0x12c3b04
    // 0x12c3acc: r17 = 10715
    //     0x12c3acc: mov             x17, #0x29db
    // 0x12c3ad0: cmp             x2, x17
    // 0x12c3ad4: b.gt            #0x12c3ae8
    // 0x12c3ad8: r0 = 10714
    //     0x12c3ad8: mov             x0, #0x29da
    // 0x12c3adc: LeaveFrame
    //     0x12c3adc: mov             SP, fp
    //     0x12c3ae0: ldp             fp, lr, [SP], #0x10
    // 0x12c3ae4: ret
    //     0x12c3ae4: ret             
    // 0x12c3ae8: r17 = 10741
    //     0x12c3ae8: mov             x17, #0x29f5
    // 0x12c3aec: cmp             x2, x17
    // 0x12c3af0: b.lt            #0x12c4c48
    // 0x12c3af4: r0 = 8725
    //     0x12c3af4: mov             x0, #0x2215
    // 0x12c3af8: LeaveFrame
    //     0x12c3af8: mov             SP, fp
    //     0x12c3afc: ldp             fp, lr, [SP], #0x10
    // 0x12c3b00: ret
    //     0x12c3b00: ret             
    // 0x12c3b04: r17 = 10744
    //     0x12c3b04: mov             x17, #0x29f8
    // 0x12c3b08: cmp             x2, x17
    // 0x12c3b0c: b.lt            #0x12c4c48
    // 0x12c3b10: r0 = 10745
    //     0x12c3b10: mov             x0, #0x29f9
    // 0x12c3b14: LeaveFrame
    //     0x12c3b14: mov             SP, fp
    //     0x12c3b18: ldp             fp, lr, [SP], #0x10
    // 0x12c3b1c: ret
    //     0x12c3b1c: ret             
    // 0x12c3b20: r17 = 10749
    //     0x12c3b20: mov             x17, #0x29fd
    // 0x12c3b24: cmp             x2, x17
    // 0x12c3b28: b.gt            #0x12c3b80
    // 0x12c3b2c: r17 = 10748
    //     0x12c3b2c: mov             x17, #0x29fc
    // 0x12c3b30: cmp             x2, x17
    // 0x12c3b34: b.gt            #0x12c3b70
    // 0x12c3b38: r17 = 10745
    //     0x12c3b38: mov             x17, #0x29f9
    // 0x12c3b3c: cmp             x2, x17
    // 0x12c3b40: b.gt            #0x12c3b54
    // 0x12c3b44: r0 = 10744
    //     0x12c3b44: mov             x0, #0x29f8
    // 0x12c3b48: LeaveFrame
    //     0x12c3b48: mov             SP, fp
    //     0x12c3b4c: ldp             fp, lr, [SP], #0x10
    // 0x12c3b50: ret
    //     0x12c3b50: ret             
    // 0x12c3b54: r17 = 10748
    //     0x12c3b54: mov             x17, #0x29fc
    // 0x12c3b58: cmp             x2, x17
    // 0x12c3b5c: b.lt            #0x12c4c48
    // 0x12c3b60: r0 = 10749
    //     0x12c3b60: mov             x0, #0x29fd
    // 0x12c3b64: LeaveFrame
    //     0x12c3b64: mov             SP, fp
    //     0x12c3b68: ldp             fp, lr, [SP], #0x10
    // 0x12c3b6c: ret
    //     0x12c3b6c: ret             
    // 0x12c3b70: r0 = 10748
    //     0x12c3b70: mov             x0, #0x29fc
    // 0x12c3b74: LeaveFrame
    //     0x12c3b74: mov             SP, fp
    //     0x12c3b78: ldp             fp, lr, [SP], #0x10
    // 0x12c3b7c: ret
    //     0x12c3b7c: ret             
    // 0x12c3b80: r17 = 10795
    //     0x12c3b80: mov             x17, #0x2a2b
    // 0x12c3b84: cmp             x2, x17
    // 0x12c3b88: b.lt            #0x12c4c48
    // 0x12c3b8c: r17 = 10795
    //     0x12c3b8c: mov             x17, #0x2a2b
    // 0x12c3b90: cmp             x2, x17
    // 0x12c3b94: b.gt            #0x12c3ba8
    // 0x12c3b98: r0 = 10796
    //     0x12c3b98: mov             x0, #0x2a2c
    // 0x12c3b9c: LeaveFrame
    //     0x12c3b9c: mov             SP, fp
    //     0x12c3ba0: ldp             fp, lr, [SP], #0x10
    // 0x12c3ba4: ret
    //     0x12c3ba4: ret             
    // 0x12c3ba8: r0 = 10795
    //     0x12c3ba8: mov             x0, #0x2a2b
    // 0x12c3bac: LeaveFrame
    //     0x12c3bac: mov             SP, fp
    //     0x12c3bb0: ldp             fp, lr, [SP], #0x10
    // 0x12c3bb4: ret
    //     0x12c3bb4: ret             
    // 0x12c3bb8: r17 = 10899
    //     0x12c3bb8: mov             x17, #0x2a93
    // 0x12c3bbc: cmp             x2, x17
    // 0x12c3bc0: b.gt            #0x12c3e90
    // 0x12c3bc4: r17 = 10878
    //     0x12c3bc4: mov             x17, #0x2a7e
    // 0x12c3bc8: cmp             x2, x17
    // 0x12c3bcc: b.gt            #0x12c3d50
    // 0x12c3bd0: r17 = 10813
    //     0x12c3bd0: mov             x17, #0x2a3d
    // 0x12c3bd4: cmp             x2, x17
    // 0x12c3bd8: b.gt            #0x12c3c90
    // 0x12c3bdc: r17 = 10804
    //     0x12c3bdc: mov             x17, #0x2a34
    // 0x12c3be0: cmp             x2, x17
    // 0x12c3be4: b.gt            #0x12c3c3c
    // 0x12c3be8: r17 = 10798
    //     0x12c3be8: mov             x17, #0x2a2e
    // 0x12c3bec: cmp             x2, x17
    // 0x12c3bf0: b.gt            #0x12c3c20
    // 0x12c3bf4: r17 = 10797
    //     0x12c3bf4: mov             x17, #0x2a2d
    // 0x12c3bf8: cmp             x2, x17
    // 0x12c3bfc: b.gt            #0x12c3c10
    // 0x12c3c00: r0 = 10798
    //     0x12c3c00: mov             x0, #0x2a2e
    // 0x12c3c04: LeaveFrame
    //     0x12c3c04: mov             SP, fp
    //     0x12c3c08: ldp             fp, lr, [SP], #0x10
    // 0x12c3c0c: ret
    //     0x12c3c0c: ret             
    // 0x12c3c10: r0 = 10797
    //     0x12c3c10: mov             x0, #0x2a2d
    // 0x12c3c14: LeaveFrame
    //     0x12c3c14: mov             SP, fp
    //     0x12c3c18: ldp             fp, lr, [SP], #0x10
    // 0x12c3c1c: ret
    //     0x12c3c1c: ret             
    // 0x12c3c20: r17 = 10804
    //     0x12c3c20: mov             x17, #0x2a34
    // 0x12c3c24: cmp             x2, x17
    // 0x12c3c28: b.lt            #0x12c4c48
    // 0x12c3c2c: r0 = 10805
    //     0x12c3c2c: mov             x0, #0x2a35
    // 0x12c3c30: LeaveFrame
    //     0x12c3c30: mov             SP, fp
    //     0x12c3c34: ldp             fp, lr, [SP], #0x10
    // 0x12c3c38: ret
    //     0x12c3c38: ret             
    // 0x12c3c3c: r17 = 10812
    //     0x12c3c3c: mov             x17, #0x2a3c
    // 0x12c3c40: cmp             x2, x17
    // 0x12c3c44: b.gt            #0x12c3c80
    // 0x12c3c48: r17 = 10805
    //     0x12c3c48: mov             x17, #0x2a35
    // 0x12c3c4c: cmp             x2, x17
    // 0x12c3c50: b.gt            #0x12c3c64
    // 0x12c3c54: r0 = 10804
    //     0x12c3c54: mov             x0, #0x2a34
    // 0x12c3c58: LeaveFrame
    //     0x12c3c58: mov             SP, fp
    //     0x12c3c5c: ldp             fp, lr, [SP], #0x10
    // 0x12c3c60: ret
    //     0x12c3c60: ret             
    // 0x12c3c64: r17 = 10812
    //     0x12c3c64: mov             x17, #0x2a3c
    // 0x12c3c68: cmp             x2, x17
    // 0x12c3c6c: b.lt            #0x12c4c48
    // 0x12c3c70: r0 = 10813
    //     0x12c3c70: mov             x0, #0x2a3d
    // 0x12c3c74: LeaveFrame
    //     0x12c3c74: mov             SP, fp
    //     0x12c3c78: ldp             fp, lr, [SP], #0x10
    // 0x12c3c7c: ret
    //     0x12c3c7c: ret             
    // 0x12c3c80: r0 = 10812
    //     0x12c3c80: mov             x0, #0x2a3c
    // 0x12c3c84: LeaveFrame
    //     0x12c3c84: mov             SP, fp
    //     0x12c3c88: ldp             fp, lr, [SP], #0x10
    // 0x12c3c8c: ret
    //     0x12c3c8c: ret             
    // 0x12c3c90: r17 = 10852
    //     0x12c3c90: mov             x17, #0x2a64
    // 0x12c3c94: cmp             x2, x17
    // 0x12c3c98: b.lt            #0x12c4c48
    // 0x12c3c9c: r17 = 10873
    //     0x12c3c9c: mov             x17, #0x2a79
    // 0x12c3ca0: cmp             x2, x17
    // 0x12c3ca4: b.gt            #0x12c3cfc
    // 0x12c3ca8: r17 = 10853
    //     0x12c3ca8: mov             x17, #0x2a65
    // 0x12c3cac: cmp             x2, x17
    // 0x12c3cb0: b.gt            #0x12c3ce0
    // 0x12c3cb4: r17 = 10852
    //     0x12c3cb4: mov             x17, #0x2a64
    // 0x12c3cb8: cmp             x2, x17
    // 0x12c3cbc: b.gt            #0x12c3cd0
    // 0x12c3cc0: r0 = 10853
    //     0x12c3cc0: mov             x0, #0x2a65
    // 0x12c3cc4: LeaveFrame
    //     0x12c3cc4: mov             SP, fp
    //     0x12c3cc8: ldp             fp, lr, [SP], #0x10
    // 0x12c3ccc: ret
    //     0x12c3ccc: ret             
    // 0x12c3cd0: r0 = 10852
    //     0x12c3cd0: mov             x0, #0x2a64
    // 0x12c3cd4: LeaveFrame
    //     0x12c3cd4: mov             SP, fp
    //     0x12c3cd8: ldp             fp, lr, [SP], #0x10
    // 0x12c3cdc: ret
    //     0x12c3cdc: ret             
    // 0x12c3ce0: r17 = 10873
    //     0x12c3ce0: mov             x17, #0x2a79
    // 0x12c3ce4: cmp             x2, x17
    // 0x12c3ce8: b.lt            #0x12c4c48
    // 0x12c3cec: r0 = 10874
    //     0x12c3cec: mov             x0, #0x2a7a
    // 0x12c3cf0: LeaveFrame
    //     0x12c3cf0: mov             SP, fp
    //     0x12c3cf4: ldp             fp, lr, [SP], #0x10
    // 0x12c3cf8: ret
    //     0x12c3cf8: ret             
    // 0x12c3cfc: r17 = 10877
    //     0x12c3cfc: mov             x17, #0x2a7d
    // 0x12c3d00: cmp             x2, x17
    // 0x12c3d04: b.gt            #0x12c3d40
    // 0x12c3d08: r17 = 10874
    //     0x12c3d08: mov             x17, #0x2a7a
    // 0x12c3d0c: cmp             x2, x17
    // 0x12c3d10: b.gt            #0x12c3d24
    // 0x12c3d14: r0 = 10873
    //     0x12c3d14: mov             x0, #0x2a79
    // 0x12c3d18: LeaveFrame
    //     0x12c3d18: mov             SP, fp
    //     0x12c3d1c: ldp             fp, lr, [SP], #0x10
    // 0x12c3d20: ret
    //     0x12c3d20: ret             
    // 0x12c3d24: r17 = 10877
    //     0x12c3d24: mov             x17, #0x2a7d
    // 0x12c3d28: cmp             x2, x17
    // 0x12c3d2c: b.lt            #0x12c4c48
    // 0x12c3d30: r0 = 10878
    //     0x12c3d30: mov             x0, #0x2a7e
    // 0x12c3d34: LeaveFrame
    //     0x12c3d34: mov             SP, fp
    //     0x12c3d38: ldp             fp, lr, [SP], #0x10
    // 0x12c3d3c: ret
    //     0x12c3d3c: ret             
    // 0x12c3d40: r0 = 10877
    //     0x12c3d40: mov             x0, #0x2a7d
    // 0x12c3d44: LeaveFrame
    //     0x12c3d44: mov             SP, fp
    //     0x12c3d48: ldp             fp, lr, [SP], #0x10
    // 0x12c3d4c: ret
    //     0x12c3d4c: ret             
    // 0x12c3d50: r17 = 10884
    //     0x12c3d50: mov             x17, #0x2a84
    // 0x12c3d54: cmp             x2, x17
    // 0x12c3d58: b.gt            #0x12c3df8
    // 0x12c3d5c: r17 = 10881
    //     0x12c3d5c: mov             x17, #0x2a81
    // 0x12c3d60: cmp             x2, x17
    // 0x12c3d64: b.gt            #0x12c3db0
    // 0x12c3d68: r17 = 10880
    //     0x12c3d68: mov             x17, #0x2a80
    // 0x12c3d6c: cmp             x2, x17
    // 0x12c3d70: b.gt            #0x12c3da0
    // 0x12c3d74: r17 = 10879
    //     0x12c3d74: mov             x17, #0x2a7f
    // 0x12c3d78: cmp             x2, x17
    // 0x12c3d7c: b.gt            #0x12c3d90
    // 0x12c3d80: r0 = 10880
    //     0x12c3d80: mov             x0, #0x2a80
    // 0x12c3d84: LeaveFrame
    //     0x12c3d84: mov             SP, fp
    //     0x12c3d88: ldp             fp, lr, [SP], #0x10
    // 0x12c3d8c: ret
    //     0x12c3d8c: ret             
    // 0x12c3d90: r0 = 10879
    //     0x12c3d90: mov             x0, #0x2a7f
    // 0x12c3d94: LeaveFrame
    //     0x12c3d94: mov             SP, fp
    //     0x12c3d98: ldp             fp, lr, [SP], #0x10
    // 0x12c3d9c: ret
    //     0x12c3d9c: ret             
    // 0x12c3da0: r0 = 10882
    //     0x12c3da0: mov             x0, #0x2a82
    // 0x12c3da4: LeaveFrame
    //     0x12c3da4: mov             SP, fp
    //     0x12c3da8: ldp             fp, lr, [SP], #0x10
    // 0x12c3dac: ret
    //     0x12c3dac: ret             
    // 0x12c3db0: r17 = 10883
    //     0x12c3db0: mov             x17, #0x2a83
    // 0x12c3db4: cmp             x2, x17
    // 0x12c3db8: b.gt            #0x12c3de8
    // 0x12c3dbc: r17 = 10882
    //     0x12c3dbc: mov             x17, #0x2a82
    // 0x12c3dc0: cmp             x2, x17
    // 0x12c3dc4: b.gt            #0x12c3dd8
    // 0x12c3dc8: r0 = 10881
    //     0x12c3dc8: mov             x0, #0x2a81
    // 0x12c3dcc: LeaveFrame
    //     0x12c3dcc: mov             SP, fp
    //     0x12c3dd0: ldp             fp, lr, [SP], #0x10
    // 0x12c3dd4: ret
    //     0x12c3dd4: ret             
    // 0x12c3dd8: r0 = 10884
    //     0x12c3dd8: mov             x0, #0x2a84
    // 0x12c3ddc: LeaveFrame
    //     0x12c3ddc: mov             SP, fp
    //     0x12c3de0: ldp             fp, lr, [SP], #0x10
    // 0x12c3de4: ret
    //     0x12c3de4: ret             
    // 0x12c3de8: r0 = 10883
    //     0x12c3de8: mov             x0, #0x2a83
    // 0x12c3dec: LeaveFrame
    //     0x12c3dec: mov             SP, fp
    //     0x12c3df0: ldp             fp, lr, [SP], #0x10
    // 0x12c3df4: ret
    //     0x12c3df4: ret             
    // 0x12c3df8: r17 = 10891
    //     0x12c3df8: mov             x17, #0x2a8b
    // 0x12c3dfc: cmp             x2, x17
    // 0x12c3e00: b.lt            #0x12c4c48
    // 0x12c3e04: r17 = 10897
    //     0x12c3e04: mov             x17, #0x2a91
    // 0x12c3e08: cmp             x2, x17
    // 0x12c3e0c: b.gt            #0x12c3e64
    // 0x12c3e10: r17 = 10892
    //     0x12c3e10: mov             x17, #0x2a8c
    // 0x12c3e14: cmp             x2, x17
    // 0x12c3e18: b.gt            #0x12c3e48
    // 0x12c3e1c: r17 = 10891
    //     0x12c3e1c: mov             x17, #0x2a8b
    // 0x12c3e20: cmp             x2, x17
    // 0x12c3e24: b.gt            #0x12c3e38
    // 0x12c3e28: r0 = 10892
    //     0x12c3e28: mov             x0, #0x2a8c
    // 0x12c3e2c: LeaveFrame
    //     0x12c3e2c: mov             SP, fp
    //     0x12c3e30: ldp             fp, lr, [SP], #0x10
    // 0x12c3e34: ret
    //     0x12c3e34: ret             
    // 0x12c3e38: r0 = 10891
    //     0x12c3e38: mov             x0, #0x2a8b
    // 0x12c3e3c: LeaveFrame
    //     0x12c3e3c: mov             SP, fp
    //     0x12c3e40: ldp             fp, lr, [SP], #0x10
    // 0x12c3e44: ret
    //     0x12c3e44: ret             
    // 0x12c3e48: r17 = 10897
    //     0x12c3e48: mov             x17, #0x2a91
    // 0x12c3e4c: cmp             x2, x17
    // 0x12c3e50: b.lt            #0x12c4c48
    // 0x12c3e54: r0 = 10898
    //     0x12c3e54: mov             x0, #0x2a92
    // 0x12c3e58: LeaveFrame
    //     0x12c3e58: mov             SP, fp
    //     0x12c3e5c: ldp             fp, lr, [SP], #0x10
    // 0x12c3e60: ret
    //     0x12c3e60: ret             
    // 0x12c3e64: r17 = 10898
    //     0x12c3e64: mov             x17, #0x2a92
    // 0x12c3e68: cmp             x2, x17
    // 0x12c3e6c: b.gt            #0x12c3e80
    // 0x12c3e70: r0 = 10897
    //     0x12c3e70: mov             x0, #0x2a91
    // 0x12c3e74: LeaveFrame
    //     0x12c3e74: mov             SP, fp
    //     0x12c3e78: ldp             fp, lr, [SP], #0x10
    // 0x12c3e7c: ret
    //     0x12c3e7c: ret             
    // 0x12c3e80: r0 = 10900
    //     0x12c3e80: mov             x0, #0x2a94
    // 0x12c3e84: LeaveFrame
    //     0x12c3e84: mov             SP, fp
    //     0x12c3e88: ldp             fp, lr, [SP], #0x10
    // 0x12c3e8c: ret
    //     0x12c3e8c: ret             
    // 0x12c3e90: r17 = 10914
    //     0x12c3e90: mov             x17, #0x2aa2
    // 0x12c3e94: cmp             x2, x17
    // 0x12c3e98: b.gt            #0x12c3fd0
    // 0x12c3e9c: r17 = 10905
    //     0x12c3e9c: mov             x17, #0x2a99
    // 0x12c3ea0: cmp             x2, x17
    // 0x12c3ea4: b.gt            #0x12c3f44
    // 0x12c3ea8: r17 = 10902
    //     0x12c3ea8: mov             x17, #0x2a96
    // 0x12c3eac: cmp             x2, x17
    // 0x12c3eb0: b.gt            #0x12c3efc
    // 0x12c3eb4: r17 = 10901
    //     0x12c3eb4: mov             x17, #0x2a95
    // 0x12c3eb8: cmp             x2, x17
    // 0x12c3ebc: b.gt            #0x12c3eec
    // 0x12c3ec0: r17 = 10900
    //     0x12c3ec0: mov             x17, #0x2a94
    // 0x12c3ec4: cmp             x2, x17
    // 0x12c3ec8: b.gt            #0x12c3edc
    // 0x12c3ecc: r0 = 10899
    //     0x12c3ecc: mov             x0, #0x2a93
    // 0x12c3ed0: LeaveFrame
    //     0x12c3ed0: mov             SP, fp
    //     0x12c3ed4: ldp             fp, lr, [SP], #0x10
    // 0x12c3ed8: ret
    //     0x12c3ed8: ret             
    // 0x12c3edc: r0 = 10902
    //     0x12c3edc: mov             x0, #0x2a96
    // 0x12c3ee0: LeaveFrame
    //     0x12c3ee0: mov             SP, fp
    //     0x12c3ee4: ldp             fp, lr, [SP], #0x10
    // 0x12c3ee8: ret
    //     0x12c3ee8: ret             
    // 0x12c3eec: r0 = 10901
    //     0x12c3eec: mov             x0, #0x2a95
    // 0x12c3ef0: LeaveFrame
    //     0x12c3ef0: mov             SP, fp
    //     0x12c3ef4: ldp             fp, lr, [SP], #0x10
    // 0x12c3ef8: ret
    //     0x12c3ef8: ret             
    // 0x12c3efc: r17 = 10904
    //     0x12c3efc: mov             x17, #0x2a98
    // 0x12c3f00: cmp             x2, x17
    // 0x12c3f04: b.gt            #0x12c3f34
    // 0x12c3f08: r17 = 10903
    //     0x12c3f08: mov             x17, #0x2a97
    // 0x12c3f0c: cmp             x2, x17
    // 0x12c3f10: b.gt            #0x12c3f24
    // 0x12c3f14: r0 = 10904
    //     0x12c3f14: mov             x0, #0x2a98
    // 0x12c3f18: LeaveFrame
    //     0x12c3f18: mov             SP, fp
    //     0x12c3f1c: ldp             fp, lr, [SP], #0x10
    // 0x12c3f20: ret
    //     0x12c3f20: ret             
    // 0x12c3f24: r0 = 10903
    //     0x12c3f24: mov             x0, #0x2a97
    // 0x12c3f28: LeaveFrame
    //     0x12c3f28: mov             SP, fp
    //     0x12c3f2c: ldp             fp, lr, [SP], #0x10
    // 0x12c3f30: ret
    //     0x12c3f30: ret             
    // 0x12c3f34: r0 = 10906
    //     0x12c3f34: mov             x0, #0x2a9a
    // 0x12c3f38: LeaveFrame
    //     0x12c3f38: mov             SP, fp
    //     0x12c3f3c: ldp             fp, lr, [SP], #0x10
    // 0x12c3f40: ret
    //     0x12c3f40: ret             
    // 0x12c3f44: r17 = 10908
    //     0x12c3f44: mov             x17, #0x2a9c
    // 0x12c3f48: cmp             x2, x17
    // 0x12c3f4c: b.gt            #0x12c3f98
    // 0x12c3f50: r17 = 10907
    //     0x12c3f50: mov             x17, #0x2a9b
    // 0x12c3f54: cmp             x2, x17
    // 0x12c3f58: b.gt            #0x12c3f88
    // 0x12c3f5c: r17 = 10906
    //     0x12c3f5c: mov             x17, #0x2a9a
    // 0x12c3f60: cmp             x2, x17
    // 0x12c3f64: b.gt            #0x12c3f78
    // 0x12c3f68: r0 = 10905
    //     0x12c3f68: mov             x0, #0x2a99
    // 0x12c3f6c: LeaveFrame
    //     0x12c3f6c: mov             SP, fp
    //     0x12c3f70: ldp             fp, lr, [SP], #0x10
    // 0x12c3f74: ret
    //     0x12c3f74: ret             
    // 0x12c3f78: r0 = 10908
    //     0x12c3f78: mov             x0, #0x2a9c
    // 0x12c3f7c: LeaveFrame
    //     0x12c3f7c: mov             SP, fp
    //     0x12c3f80: ldp             fp, lr, [SP], #0x10
    // 0x12c3f84: ret
    //     0x12c3f84: ret             
    // 0x12c3f88: r0 = 10907
    //     0x12c3f88: mov             x0, #0x2a9b
    // 0x12c3f8c: LeaveFrame
    //     0x12c3f8c: mov             SP, fp
    //     0x12c3f90: ldp             fp, lr, [SP], #0x10
    // 0x12c3f94: ret
    //     0x12c3f94: ret             
    // 0x12c3f98: r17 = 10913
    //     0x12c3f98: mov             x17, #0x2aa1
    // 0x12c3f9c: cmp             x2, x17
    // 0x12c3fa0: b.lt            #0x12c4c48
    // 0x12c3fa4: r17 = 10913
    //     0x12c3fa4: mov             x17, #0x2aa1
    // 0x12c3fa8: cmp             x2, x17
    // 0x12c3fac: b.gt            #0x12c3fc0
    // 0x12c3fb0: r0 = 10914
    //     0x12c3fb0: mov             x0, #0x2aa2
    // 0x12c3fb4: LeaveFrame
    //     0x12c3fb4: mov             SP, fp
    //     0x12c3fb8: ldp             fp, lr, [SP], #0x10
    // 0x12c3fbc: ret
    //     0x12c3fbc: ret             
    // 0x12c3fc0: r0 = 10913
    //     0x12c3fc0: mov             x0, #0x2aa1
    // 0x12c3fc4: LeaveFrame
    //     0x12c3fc4: mov             SP, fp
    //     0x12c3fc8: ldp             fp, lr, [SP], #0x10
    // 0x12c3fcc: ret
    //     0x12c3fcc: ret             
    // 0x12c3fd0: r17 = 10918
    //     0x12c3fd0: mov             x17, #0x2aa6
    // 0x12c3fd4: cmp             x2, x17
    // 0x12c3fd8: b.lt            #0x12c4c48
    // 0x12c3fdc: r17 = 10923
    //     0x12c3fdc: mov             x17, #0x2aab
    // 0x12c3fe0: cmp             x2, x17
    // 0x12c3fe4: b.gt            #0x12c4084
    // 0x12c3fe8: r17 = 10920
    //     0x12c3fe8: mov             x17, #0x2aa8
    // 0x12c3fec: cmp             x2, x17
    // 0x12c3ff0: b.gt            #0x12c403c
    // 0x12c3ff4: r17 = 10919
    //     0x12c3ff4: mov             x17, #0x2aa7
    // 0x12c3ff8: cmp             x2, x17
    // 0x12c3ffc: b.gt            #0x12c402c
    // 0x12c4000: r17 = 10918
    //     0x12c4000: mov             x17, #0x2aa6
    // 0x12c4004: cmp             x2, x17
    // 0x12c4008: b.gt            #0x12c401c
    // 0x12c400c: r0 = 10919
    //     0x12c400c: mov             x0, #0x2aa7
    // 0x12c4010: LeaveFrame
    //     0x12c4010: mov             SP, fp
    //     0x12c4014: ldp             fp, lr, [SP], #0x10
    // 0x12c4018: ret
    //     0x12c4018: ret             
    // 0x12c401c: r0 = 10918
    //     0x12c401c: mov             x0, #0x2aa6
    // 0x12c4020: LeaveFrame
    //     0x12c4020: mov             SP, fp
    //     0x12c4024: ldp             fp, lr, [SP], #0x10
    // 0x12c4028: ret
    //     0x12c4028: ret             
    // 0x12c402c: r0 = 10921
    //     0x12c402c: mov             x0, #0x2aa9
    // 0x12c4030: LeaveFrame
    //     0x12c4030: mov             SP, fp
    //     0x12c4034: ldp             fp, lr, [SP], #0x10
    // 0x12c4038: ret
    //     0x12c4038: ret             
    // 0x12c403c: r17 = 10922
    //     0x12c403c: mov             x17, #0x2aaa
    // 0x12c4040: cmp             x2, x17
    // 0x12c4044: b.gt            #0x12c4074
    // 0x12c4048: r17 = 10921
    //     0x12c4048: mov             x17, #0x2aa9
    // 0x12c404c: cmp             x2, x17
    // 0x12c4050: b.gt            #0x12c4064
    // 0x12c4054: r0 = 10920
    //     0x12c4054: mov             x0, #0x2aa8
    // 0x12c4058: LeaveFrame
    //     0x12c4058: mov             SP, fp
    //     0x12c405c: ldp             fp, lr, [SP], #0x10
    // 0x12c4060: ret
    //     0x12c4060: ret             
    // 0x12c4064: r0 = 10923
    //     0x12c4064: mov             x0, #0x2aab
    // 0x12c4068: LeaveFrame
    //     0x12c4068: mov             SP, fp
    //     0x12c406c: ldp             fp, lr, [SP], #0x10
    // 0x12c4070: ret
    //     0x12c4070: ret             
    // 0x12c4074: r0 = 10922
    //     0x12c4074: mov             x0, #0x2aaa
    // 0x12c4078: LeaveFrame
    //     0x12c4078: mov             SP, fp
    //     0x12c407c: ldp             fp, lr, [SP], #0x10
    // 0x12c4080: ret
    //     0x12c4080: ret             
    // 0x12c4084: r17 = 10927
    //     0x12c4084: mov             x17, #0x2aaf
    // 0x12c4088: cmp             x2, x17
    // 0x12c408c: b.gt            #0x12c40e4
    // 0x12c4090: r17 = 10925
    //     0x12c4090: mov             x17, #0x2aad
    // 0x12c4094: cmp             x2, x17
    // 0x12c4098: b.gt            #0x12c40c8
    // 0x12c409c: r17 = 10924
    //     0x12c409c: mov             x17, #0x2aac
    // 0x12c40a0: cmp             x2, x17
    // 0x12c40a4: b.gt            #0x12c40b8
    // 0x12c40a8: r0 = 10925
    //     0x12c40a8: mov             x0, #0x2aad
    // 0x12c40ac: LeaveFrame
    //     0x12c40ac: mov             SP, fp
    //     0x12c40b0: ldp             fp, lr, [SP], #0x10
    // 0x12c40b4: ret
    //     0x12c40b4: ret             
    // 0x12c40b8: r0 = 10924
    //     0x12c40b8: mov             x0, #0x2aac
    // 0x12c40bc: LeaveFrame
    //     0x12c40bc: mov             SP, fp
    //     0x12c40c0: ldp             fp, lr, [SP], #0x10
    // 0x12c40c4: ret
    //     0x12c40c4: ret             
    // 0x12c40c8: r17 = 10927
    //     0x12c40c8: mov             x17, #0x2aaf
    // 0x12c40cc: cmp             x2, x17
    // 0x12c40d0: b.lt            #0x12c4c48
    // 0x12c40d4: r0 = 10928
    //     0x12c40d4: mov             x0, #0x2ab0
    // 0x12c40d8: LeaveFrame
    //     0x12c40d8: mov             SP, fp
    //     0x12c40dc: ldp             fp, lr, [SP], #0x10
    // 0x12c40e0: ret
    //     0x12c40e0: ret             
    // 0x12c40e4: r17 = 10928
    //     0x12c40e4: mov             x17, #0x2ab0
    // 0x12c40e8: cmp             x2, x17
    // 0x12c40ec: b.gt            #0x12c4100
    // 0x12c40f0: r0 = 10927
    //     0x12c40f0: mov             x0, #0x2aaf
    // 0x12c40f4: LeaveFrame
    //     0x12c40f4: mov             SP, fp
    //     0x12c40f8: ldp             fp, lr, [SP], #0x10
    // 0x12c40fc: ret
    //     0x12c40fc: ret             
    // 0x12c4100: r17 = 10931
    //     0x12c4100: mov             x17, #0x2ab3
    // 0x12c4104: cmp             x2, x17
    // 0x12c4108: b.lt            #0x12c4c48
    // 0x12c410c: r0 = 10932
    //     0x12c410c: mov             x0, #0x2ab4
    // 0x12c4110: LeaveFrame
    //     0x12c4110: mov             SP, fp
    //     0x12c4114: ldp             fp, lr, [SP], #0x10
    // 0x12c4118: ret
    //     0x12c4118: ret             
    // 0x12c411c: r17 = 11810
    //     0x12c411c: mov             x17, #0x2e22
    // 0x12c4120: cmp             x2, x17
    // 0x12c4124: b.gt            #0x12c46a8
    // 0x12c4128: r17 = 10966
    //     0x12c4128: mov             x17, #0x2ad6
    // 0x12c412c: cmp             x2, x17
    // 0x12c4130: b.gt            #0x12c43c4
    // 0x12c4134: r17 = 10949
    //     0x12c4134: mov             x17, #0x2ac5
    // 0x12c4138: cmp             x2, x17
    // 0x12c413c: b.gt            #0x12c4290
    // 0x12c4140: r17 = 10943
    //     0x12c4140: mov             x17, #0x2abf
    // 0x12c4144: cmp             x2, x17
    // 0x12c4148: b.gt            #0x12c41f4
    // 0x12c414c: r17 = 10940
    //     0x12c414c: mov             x17, #0x2abc
    // 0x12c4150: cmp             x2, x17
    // 0x12c4154: b.gt            #0x12c41ac
    // 0x12c4158: r17 = 10939
    //     0x12c4158: mov             x17, #0x2abb
    // 0x12c415c: cmp             x2, x17
    // 0x12c4160: b.gt            #0x12c419c
    // 0x12c4164: r17 = 10932
    //     0x12c4164: mov             x17, #0x2ab4
    // 0x12c4168: cmp             x2, x17
    // 0x12c416c: b.gt            #0x12c4180
    // 0x12c4170: r0 = 10931
    //     0x12c4170: mov             x0, #0x2ab3
    // 0x12c4174: LeaveFrame
    //     0x12c4174: mov             SP, fp
    //     0x12c4178: ldp             fp, lr, [SP], #0x10
    // 0x12c417c: ret
    //     0x12c417c: ret             
    // 0x12c4180: r17 = 10939
    //     0x12c4180: mov             x17, #0x2abb
    // 0x12c4184: cmp             x2, x17
    // 0x12c4188: b.lt            #0x12c4c48
    // 0x12c418c: r0 = 10940
    //     0x12c418c: mov             x0, #0x2abc
    // 0x12c4190: LeaveFrame
    //     0x12c4190: mov             SP, fp
    //     0x12c4194: ldp             fp, lr, [SP], #0x10
    // 0x12c4198: ret
    //     0x12c4198: ret             
    // 0x12c419c: r0 = 10939
    //     0x12c419c: mov             x0, #0x2abb
    // 0x12c41a0: LeaveFrame
    //     0x12c41a0: mov             SP, fp
    //     0x12c41a4: ldp             fp, lr, [SP], #0x10
    // 0x12c41a8: ret
    //     0x12c41a8: ret             
    // 0x12c41ac: r17 = 10942
    //     0x12c41ac: mov             x17, #0x2abe
    // 0x12c41b0: cmp             x2, x17
    // 0x12c41b4: b.gt            #0x12c41e4
    // 0x12c41b8: r17 = 10941
    //     0x12c41b8: mov             x17, #0x2abd
    // 0x12c41bc: cmp             x2, x17
    // 0x12c41c0: b.gt            #0x12c41d4
    // 0x12c41c4: r0 = 10942
    //     0x12c41c4: mov             x0, #0x2abe
    // 0x12c41c8: LeaveFrame
    //     0x12c41c8: mov             SP, fp
    //     0x12c41cc: ldp             fp, lr, [SP], #0x10
    // 0x12c41d0: ret
    //     0x12c41d0: ret             
    // 0x12c41d4: r0 = 10941
    //     0x12c41d4: mov             x0, #0x2abd
    // 0x12c41d8: LeaveFrame
    //     0x12c41d8: mov             SP, fp
    //     0x12c41dc: ldp             fp, lr, [SP], #0x10
    // 0x12c41e0: ret
    //     0x12c41e0: ret             
    // 0x12c41e4: r0 = 10944
    //     0x12c41e4: mov             x0, #0x2ac0
    // 0x12c41e8: LeaveFrame
    //     0x12c41e8: mov             SP, fp
    //     0x12c41ec: ldp             fp, lr, [SP], #0x10
    // 0x12c41f0: ret
    //     0x12c41f0: ret             
    // 0x12c41f4: r17 = 10946
    //     0x12c41f4: mov             x17, #0x2ac2
    // 0x12c41f8: cmp             x2, x17
    // 0x12c41fc: b.gt            #0x12c4248
    // 0x12c4200: r17 = 10945
    //     0x12c4200: mov             x17, #0x2ac1
    // 0x12c4204: cmp             x2, x17
    // 0x12c4208: b.gt            #0x12c4238
    // 0x12c420c: r17 = 10944
    //     0x12c420c: mov             x17, #0x2ac0
    // 0x12c4210: cmp             x2, x17
    // 0x12c4214: b.gt            #0x12c4228
    // 0x12c4218: r0 = 10943
    //     0x12c4218: mov             x0, #0x2abf
    // 0x12c421c: LeaveFrame
    //     0x12c421c: mov             SP, fp
    //     0x12c4220: ldp             fp, lr, [SP], #0x10
    // 0x12c4224: ret
    //     0x12c4224: ret             
    // 0x12c4228: r0 = 10946
    //     0x12c4228: mov             x0, #0x2ac2
    // 0x12c422c: LeaveFrame
    //     0x12c422c: mov             SP, fp
    //     0x12c4230: ldp             fp, lr, [SP], #0x10
    // 0x12c4234: ret
    //     0x12c4234: ret             
    // 0x12c4238: r0 = 10945
    //     0x12c4238: mov             x0, #0x2ac1
    // 0x12c423c: LeaveFrame
    //     0x12c423c: mov             SP, fp
    //     0x12c4240: ldp             fp, lr, [SP], #0x10
    // 0x12c4244: ret
    //     0x12c4244: ret             
    // 0x12c4248: r17 = 10948
    //     0x12c4248: mov             x17, #0x2ac4
    // 0x12c424c: cmp             x2, x17
    // 0x12c4250: b.gt            #0x12c4280
    // 0x12c4254: r17 = 10947
    //     0x12c4254: mov             x17, #0x2ac3
    // 0x12c4258: cmp             x2, x17
    // 0x12c425c: b.gt            #0x12c4270
    // 0x12c4260: r0 = 10948
    //     0x12c4260: mov             x0, #0x2ac4
    // 0x12c4264: LeaveFrame
    //     0x12c4264: mov             SP, fp
    //     0x12c4268: ldp             fp, lr, [SP], #0x10
    // 0x12c426c: ret
    //     0x12c426c: ret             
    // 0x12c4270: r0 = 10947
    //     0x12c4270: mov             x0, #0x2ac3
    // 0x12c4274: LeaveFrame
    //     0x12c4274: mov             SP, fp
    //     0x12c4278: ldp             fp, lr, [SP], #0x10
    // 0x12c427c: ret
    //     0x12c427c: ret             
    // 0x12c4280: r0 = 10950
    //     0x12c4280: mov             x0, #0x2ac6
    // 0x12c4284: LeaveFrame
    //     0x12c4284: mov             SP, fp
    //     0x12c4288: ldp             fp, lr, [SP], #0x10
    // 0x12c428c: ret
    //     0x12c428c: ret             
    // 0x12c4290: r17 = 10961
    //     0x12c4290: mov             x17, #0x2ad1
    // 0x12c4294: cmp             x2, x17
    // 0x12c4298: b.gt            #0x12c4344
    // 0x12c429c: r17 = 10958
    //     0x12c429c: mov             x17, #0x2ace
    // 0x12c42a0: cmp             x2, x17
    // 0x12c42a4: b.gt            #0x12c42fc
    // 0x12c42a8: r17 = 10957
    //     0x12c42a8: mov             x17, #0x2acd
    // 0x12c42ac: cmp             x2, x17
    // 0x12c42b0: b.gt            #0x12c42ec
    // 0x12c42b4: r17 = 10950
    //     0x12c42b4: mov             x17, #0x2ac6
    // 0x12c42b8: cmp             x2, x17
    // 0x12c42bc: b.gt            #0x12c42d0
    // 0x12c42c0: r0 = 10949
    //     0x12c42c0: mov             x0, #0x2ac5
    // 0x12c42c4: LeaveFrame
    //     0x12c42c4: mov             SP, fp
    //     0x12c42c8: ldp             fp, lr, [SP], #0x10
    // 0x12c42cc: ret
    //     0x12c42cc: ret             
    // 0x12c42d0: r17 = 10957
    //     0x12c42d0: mov             x17, #0x2acd
    // 0x12c42d4: cmp             x2, x17
    // 0x12c42d8: b.lt            #0x12c4c48
    // 0x12c42dc: r0 = 10958
    //     0x12c42dc: mov             x0, #0x2ace
    // 0x12c42e0: LeaveFrame
    //     0x12c42e0: mov             SP, fp
    //     0x12c42e4: ldp             fp, lr, [SP], #0x10
    // 0x12c42e8: ret
    //     0x12c42e8: ret             
    // 0x12c42ec: r0 = 10957
    //     0x12c42ec: mov             x0, #0x2acd
    // 0x12c42f0: LeaveFrame
    //     0x12c42f0: mov             SP, fp
    //     0x12c42f4: ldp             fp, lr, [SP], #0x10
    // 0x12c42f8: ret
    //     0x12c42f8: ret             
    // 0x12c42fc: r17 = 10960
    //     0x12c42fc: mov             x17, #0x2ad0
    // 0x12c4300: cmp             x2, x17
    // 0x12c4304: b.gt            #0x12c4334
    // 0x12c4308: r17 = 10959
    //     0x12c4308: mov             x17, #0x2acf
    // 0x12c430c: cmp             x2, x17
    // 0x12c4310: b.gt            #0x12c4324
    // 0x12c4314: r0 = 10960
    //     0x12c4314: mov             x0, #0x2ad0
    // 0x12c4318: LeaveFrame
    //     0x12c4318: mov             SP, fp
    //     0x12c431c: ldp             fp, lr, [SP], #0x10
    // 0x12c4320: ret
    //     0x12c4320: ret             
    // 0x12c4324: r0 = 10959
    //     0x12c4324: mov             x0, #0x2acf
    // 0x12c4328: LeaveFrame
    //     0x12c4328: mov             SP, fp
    //     0x12c432c: ldp             fp, lr, [SP], #0x10
    // 0x12c4330: ret
    //     0x12c4330: ret             
    // 0x12c4334: r0 = 10962
    //     0x12c4334: mov             x0, #0x2ad2
    // 0x12c4338: LeaveFrame
    //     0x12c4338: mov             SP, fp
    //     0x12c433c: ldp             fp, lr, [SP], #0x10
    // 0x12c4340: ret
    //     0x12c4340: ret             
    // 0x12c4344: r17 = 10964
    //     0x12c4344: mov             x17, #0x2ad4
    // 0x12c4348: cmp             x2, x17
    // 0x12c434c: b.gt            #0x12c4398
    // 0x12c4350: r17 = 10963
    //     0x12c4350: mov             x17, #0x2ad3
    // 0x12c4354: cmp             x2, x17
    // 0x12c4358: b.gt            #0x12c4388
    // 0x12c435c: r17 = 10962
    //     0x12c435c: mov             x17, #0x2ad2
    // 0x12c4360: cmp             x2, x17
    // 0x12c4364: b.gt            #0x12c4378
    // 0x12c4368: r0 = 10961
    //     0x12c4368: mov             x0, #0x2ad1
    // 0x12c436c: LeaveFrame
    //     0x12c436c: mov             SP, fp
    //     0x12c4370: ldp             fp, lr, [SP], #0x10
    // 0x12c4374: ret
    //     0x12c4374: ret             
    // 0x12c4378: r0 = 10964
    //     0x12c4378: mov             x0, #0x2ad4
    // 0x12c437c: LeaveFrame
    //     0x12c437c: mov             SP, fp
    //     0x12c4380: ldp             fp, lr, [SP], #0x10
    // 0x12c4384: ret
    //     0x12c4384: ret             
    // 0x12c4388: r0 = 10963
    //     0x12c4388: mov             x0, #0x2ad3
    // 0x12c438c: LeaveFrame
    //     0x12c438c: mov             SP, fp
    //     0x12c4390: ldp             fp, lr, [SP], #0x10
    // 0x12c4394: ret
    //     0x12c4394: ret             
    // 0x12c4398: r17 = 10965
    //     0x12c4398: mov             x17, #0x2ad5
    // 0x12c439c: cmp             x2, x17
    // 0x12c43a0: b.gt            #0x12c43b4
    // 0x12c43a4: r0 = 10966
    //     0x12c43a4: mov             x0, #0x2ad6
    // 0x12c43a8: LeaveFrame
    //     0x12c43a8: mov             SP, fp
    //     0x12c43ac: ldp             fp, lr, [SP], #0x10
    // 0x12c43b0: ret
    //     0x12c43b0: ret             
    // 0x12c43b4: r0 = 10965
    //     0x12c43b4: mov             x0, #0x2ad5
    // 0x12c43b8: LeaveFrame
    //     0x12c43b8: mov             SP, fp
    //     0x12c43bc: ldp             fp, lr, [SP], #0x10
    // 0x12c43c0: ret
    //     0x12c43c0: ret             
    // 0x12c43c4: r17 = 10974
    //     0x12c43c4: mov             x17, #0x2ade
    // 0x12c43c8: cmp             x2, x17
    // 0x12c43cc: b.lt            #0x12c4c48
    // 0x12c43d0: r17 = 11779
    //     0x12c43d0: mov             x17, #0x2e03
    // 0x12c43d4: cmp             x2, x17
    // 0x12c43d8: b.gt            #0x12c4550
    // 0x12c43dc: r17 = 10989
    //     0x12c43dc: mov             x17, #0x2aed
    // 0x12c43e0: cmp             x2, x17
    // 0x12c43e4: b.gt            #0x12c449c
    // 0x12c43e8: r17 = 10980
    //     0x12c43e8: mov             x17, #0x2ae4
    // 0x12c43ec: cmp             x2, x17
    // 0x12c43f0: b.gt            #0x12c4448
    // 0x12c43f4: r17 = 10979
    //     0x12c43f4: mov             x17, #0x2ae3
    // 0x12c43f8: cmp             x2, x17
    // 0x12c43fc: b.gt            #0x12c4438
    // 0x12c4400: r17 = 10974
    //     0x12c4400: mov             x17, #0x2ade
    // 0x12c4404: cmp             x2, x17
    // 0x12c4408: b.gt            #0x12c441c
    // 0x12c440c: r0 = 8870
    //     0x12c440c: mov             x0, #0x22a6
    // 0x12c4410: LeaveFrame
    //     0x12c4410: mov             SP, fp
    //     0x12c4414: ldp             fp, lr, [SP], #0x10
    // 0x12c4418: ret
    //     0x12c4418: ret             
    // 0x12c441c: r17 = 10979
    //     0x12c441c: mov             x17, #0x2ae3
    // 0x12c4420: cmp             x2, x17
    // 0x12c4424: b.lt            #0x12c4c48
    // 0x12c4428: r0 = 8873
    //     0x12c4428: mov             x0, #0x22a9
    // 0x12c442c: LeaveFrame
    //     0x12c442c: mov             SP, fp
    //     0x12c4430: ldp             fp, lr, [SP], #0x10
    // 0x12c4434: ret
    //     0x12c4434: ret             
    // 0x12c4438: r0 = 8872
    //     0x12c4438: mov             x0, #0x22a8
    // 0x12c443c: LeaveFrame
    //     0x12c443c: mov             SP, fp
    //     0x12c4440: ldp             fp, lr, [SP], #0x10
    // 0x12c4444: ret
    //     0x12c4444: ret             
    // 0x12c4448: r17 = 10988
    //     0x12c4448: mov             x17, #0x2aec
    // 0x12c444c: cmp             x2, x17
    // 0x12c4450: b.gt            #0x12c448c
    // 0x12c4454: r17 = 10981
    //     0x12c4454: mov             x17, #0x2ae5
    // 0x12c4458: cmp             x2, x17
    // 0x12c445c: b.gt            #0x12c4470
    // 0x12c4460: r0 = 8875
    //     0x12c4460: mov             x0, #0x22ab
    // 0x12c4464: LeaveFrame
    //     0x12c4464: mov             SP, fp
    //     0x12c4468: ldp             fp, lr, [SP], #0x10
    // 0x12c446c: ret
    //     0x12c446c: ret             
    // 0x12c4470: r17 = 10988
    //     0x12c4470: mov             x17, #0x2aec
    // 0x12c4474: cmp             x2, x17
    // 0x12c4478: b.lt            #0x12c4c48
    // 0x12c447c: r0 = 10989
    //     0x12c447c: mov             x0, #0x2aed
    // 0x12c4480: LeaveFrame
    //     0x12c4480: mov             SP, fp
    //     0x12c4484: ldp             fp, lr, [SP], #0x10
    // 0x12c4488: ret
    //     0x12c4488: ret             
    // 0x12c448c: r0 = 10988
    //     0x12c448c: mov             x0, #0x2aec
    // 0x12c4490: LeaveFrame
    //     0x12c4490: mov             SP, fp
    //     0x12c4494: ldp             fp, lr, [SP], #0x10
    // 0x12c4498: ret
    //     0x12c4498: ret             
    // 0x12c449c: r17 = 10999
    //     0x12c449c: mov             x17, #0x2af7
    // 0x12c44a0: cmp             x2, x17
    // 0x12c44a4: b.lt            #0x12c4c48
    // 0x12c44a8: r17 = 11001
    //     0x12c44a8: mov             x17, #0x2af9
    // 0x12c44ac: cmp             x2, x17
    // 0x12c44b0: b.gt            #0x12c44fc
    // 0x12c44b4: r17 = 11000
    //     0x12c44b4: mov             x17, #0x2af8
    // 0x12c44b8: cmp             x2, x17
    // 0x12c44bc: b.gt            #0x12c44ec
    // 0x12c44c0: r17 = 10999
    //     0x12c44c0: mov             x17, #0x2af7
    // 0x12c44c4: cmp             x2, x17
    // 0x12c44c8: b.gt            #0x12c44dc
    // 0x12c44cc: r0 = 11000
    //     0x12c44cc: mov             x0, #0x2af8
    // 0x12c44d0: LeaveFrame
    //     0x12c44d0: mov             SP, fp
    //     0x12c44d4: ldp             fp, lr, [SP], #0x10
    // 0x12c44d8: ret
    //     0x12c44d8: ret             
    // 0x12c44dc: r0 = 10999
    //     0x12c44dc: mov             x0, #0x2af7
    // 0x12c44e0: LeaveFrame
    //     0x12c44e0: mov             SP, fp
    //     0x12c44e4: ldp             fp, lr, [SP], #0x10
    // 0x12c44e8: ret
    //     0x12c44e8: ret             
    // 0x12c44ec: r0 = 11002
    //     0x12c44ec: mov             x0, #0x2afa
    // 0x12c44f0: LeaveFrame
    //     0x12c44f0: mov             SP, fp
    //     0x12c44f4: ldp             fp, lr, [SP], #0x10
    // 0x12c44f8: ret
    //     0x12c44f8: ret             
    // 0x12c44fc: r17 = 11778
    //     0x12c44fc: mov             x17, #0x2e02
    // 0x12c4500: cmp             x2, x17
    // 0x12c4504: b.gt            #0x12c4540
    // 0x12c4508: r17 = 11002
    //     0x12c4508: mov             x17, #0x2afa
    // 0x12c450c: cmp             x2, x17
    // 0x12c4510: b.gt            #0x12c4524
    // 0x12c4514: r0 = 11001
    //     0x12c4514: mov             x0, #0x2af9
    // 0x12c4518: LeaveFrame
    //     0x12c4518: mov             SP, fp
    //     0x12c451c: ldp             fp, lr, [SP], #0x10
    // 0x12c4520: ret
    //     0x12c4520: ret             
    // 0x12c4524: r17 = 11778
    //     0x12c4524: mov             x17, #0x2e02
    // 0x12c4528: cmp             x2, x17
    // 0x12c452c: b.lt            #0x12c4c48
    // 0x12c4530: r0 = 11779
    //     0x12c4530: mov             x0, #0x2e03
    // 0x12c4534: LeaveFrame
    //     0x12c4534: mov             SP, fp
    //     0x12c4538: ldp             fp, lr, [SP], #0x10
    // 0x12c453c: ret
    //     0x12c453c: ret             
    // 0x12c4540: r0 = 11778
    //     0x12c4540: mov             x0, #0x2e02
    // 0x12c4544: LeaveFrame
    //     0x12c4544: mov             SP, fp
    //     0x12c4548: ldp             fp, lr, [SP], #0x10
    // 0x12c454c: ret
    //     0x12c454c: ret             
    // 0x12c4550: r17 = 11789
    //     0x12c4550: mov             x17, #0x2e0d
    // 0x12c4554: cmp             x2, x17
    // 0x12c4558: b.gt            #0x12c4610
    // 0x12c455c: r17 = 11785
    //     0x12c455c: mov             x17, #0x2e09
    // 0x12c4560: cmp             x2, x17
    // 0x12c4564: b.gt            #0x12c45bc
    // 0x12c4568: r17 = 11781
    //     0x12c4568: mov             x17, #0x2e05
    // 0x12c456c: cmp             x2, x17
    // 0x12c4570: b.gt            #0x12c45a0
    // 0x12c4574: r17 = 11780
    //     0x12c4574: mov             x17, #0x2e04
    // 0x12c4578: cmp             x2, x17
    // 0x12c457c: b.gt            #0x12c4590
    // 0x12c4580: r0 = 11781
    //     0x12c4580: mov             x0, #0x2e05
    // 0x12c4584: LeaveFrame
    //     0x12c4584: mov             SP, fp
    //     0x12c4588: ldp             fp, lr, [SP], #0x10
    // 0x12c458c: ret
    //     0x12c458c: ret             
    // 0x12c4590: r0 = 11780
    //     0x12c4590: mov             x0, #0x2e04
    // 0x12c4594: LeaveFrame
    //     0x12c4594: mov             SP, fp
    //     0x12c4598: ldp             fp, lr, [SP], #0x10
    // 0x12c459c: ret
    //     0x12c459c: ret             
    // 0x12c45a0: r17 = 11785
    //     0x12c45a0: mov             x17, #0x2e09
    // 0x12c45a4: cmp             x2, x17
    // 0x12c45a8: b.lt            #0x12c4c48
    // 0x12c45ac: r0 = 11786
    //     0x12c45ac: mov             x0, #0x2e0a
    // 0x12c45b0: LeaveFrame
    //     0x12c45b0: mov             SP, fp
    //     0x12c45b4: ldp             fp, lr, [SP], #0x10
    // 0x12c45b8: ret
    //     0x12c45b8: ret             
    // 0x12c45bc: r17 = 11788
    //     0x12c45bc: mov             x17, #0x2e0c
    // 0x12c45c0: cmp             x2, x17
    // 0x12c45c4: b.gt            #0x12c4600
    // 0x12c45c8: r17 = 11786
    //     0x12c45c8: mov             x17, #0x2e0a
    // 0x12c45cc: cmp             x2, x17
    // 0x12c45d0: b.gt            #0x12c45e4
    // 0x12c45d4: r0 = 11785
    //     0x12c45d4: mov             x0, #0x2e09
    // 0x12c45d8: LeaveFrame
    //     0x12c45d8: mov             SP, fp
    //     0x12c45dc: ldp             fp, lr, [SP], #0x10
    // 0x12c45e0: ret
    //     0x12c45e0: ret             
    // 0x12c45e4: r17 = 11788
    //     0x12c45e4: mov             x17, #0x2e0c
    // 0x12c45e8: cmp             x2, x17
    // 0x12c45ec: b.lt            #0x12c4c48
    // 0x12c45f0: r0 = 11789
    //     0x12c45f0: mov             x0, #0x2e0d
    // 0x12c45f4: LeaveFrame
    //     0x12c45f4: mov             SP, fp
    //     0x12c45f8: ldp             fp, lr, [SP], #0x10
    // 0x12c45fc: ret
    //     0x12c45fc: ret             
    // 0x12c4600: r0 = 11788
    //     0x12c4600: mov             x0, #0x2e0c
    // 0x12c4604: LeaveFrame
    //     0x12c4604: mov             SP, fp
    //     0x12c4608: ldp             fp, lr, [SP], #0x10
    // 0x12c460c: ret
    //     0x12c460c: ret             
    // 0x12c4610: r17 = 11804
    //     0x12c4610: mov             x17, #0x2e1c
    // 0x12c4614: cmp             x2, x17
    // 0x12c4618: b.lt            #0x12c4c48
    // 0x12c461c: r17 = 11808
    //     0x12c461c: mov             x17, #0x2e20
    // 0x12c4620: cmp             x2, x17
    // 0x12c4624: b.gt            #0x12c467c
    // 0x12c4628: r17 = 11805
    //     0x12c4628: mov             x17, #0x2e1d
    // 0x12c462c: cmp             x2, x17
    // 0x12c4630: b.gt            #0x12c4660
    // 0x12c4634: r17 = 11804
    //     0x12c4634: mov             x17, #0x2e1c
    // 0x12c4638: cmp             x2, x17
    // 0x12c463c: b.gt            #0x12c4650
    // 0x12c4640: r0 = 11805
    //     0x12c4640: mov             x0, #0x2e1d
    // 0x12c4644: LeaveFrame
    //     0x12c4644: mov             SP, fp
    //     0x12c4648: ldp             fp, lr, [SP], #0x10
    // 0x12c464c: ret
    //     0x12c464c: ret             
    // 0x12c4650: r0 = 11804
    //     0x12c4650: mov             x0, #0x2e1c
    // 0x12c4654: LeaveFrame
    //     0x12c4654: mov             SP, fp
    //     0x12c4658: ldp             fp, lr, [SP], #0x10
    // 0x12c465c: ret
    //     0x12c465c: ret             
    // 0x12c4660: r17 = 11808
    //     0x12c4660: mov             x17, #0x2e20
    // 0x12c4664: cmp             x2, x17
    // 0x12c4668: b.lt            #0x12c4c48
    // 0x12c466c: r0 = 11809
    //     0x12c466c: mov             x0, #0x2e21
    // 0x12c4670: LeaveFrame
    //     0x12c4670: mov             SP, fp
    //     0x12c4674: ldp             fp, lr, [SP], #0x10
    // 0x12c4678: ret
    //     0x12c4678: ret             
    // 0x12c467c: r17 = 11809
    //     0x12c467c: mov             x17, #0x2e21
    // 0x12c4680: cmp             x2, x17
    // 0x12c4684: b.gt            #0x12c4698
    // 0x12c4688: r0 = 11808
    //     0x12c4688: mov             x0, #0x2e20
    // 0x12c468c: LeaveFrame
    //     0x12c468c: mov             SP, fp
    //     0x12c4690: ldp             fp, lr, [SP], #0x10
    // 0x12c4694: ret
    //     0x12c4694: ret             
    // 0x12c4698: r0 = 11811
    //     0x12c4698: mov             x0, #0x2e23
    // 0x12c469c: LeaveFrame
    //     0x12c469c: mov             SP, fp
    //     0x12c46a0: ldp             fp, lr, [SP], #0x10
    // 0x12c46a4: ret
    //     0x12c46a4: ret             
    // 0x12c46a8: r17 = 12313
    //     0x12c46a8: mov             x17, #0x3019
    // 0x12c46ac: cmp             x2, x17
    // 0x12c46b0: b.gt            #0x12c4944
    // 0x12c46b4: r17 = 12300
    //     0x12c46b4: mov             x17, #0x300c
    // 0x12c46b8: cmp             x2, x17
    // 0x12c46bc: b.gt            #0x12c4810
    // 0x12c46c0: r17 = 11816
    //     0x12c46c0: mov             x17, #0x2e28
    // 0x12c46c4: cmp             x2, x17
    // 0x12c46c8: b.gt            #0x12c4768
    // 0x12c46cc: r17 = 11813
    //     0x12c46cc: mov             x17, #0x2e25
    // 0x12c46d0: cmp             x2, x17
    // 0x12c46d4: b.gt            #0x12c4720
    // 0x12c46d8: r17 = 11812
    //     0x12c46d8: mov             x17, #0x2e24
    // 0x12c46dc: cmp             x2, x17
    // 0x12c46e0: b.gt            #0x12c4710
    // 0x12c46e4: r17 = 11811
    //     0x12c46e4: mov             x17, #0x2e23
    // 0x12c46e8: cmp             x2, x17
    // 0x12c46ec: b.gt            #0x12c4700
    // 0x12c46f0: r0 = 11810
    //     0x12c46f0: mov             x0, #0x2e22
    // 0x12c46f4: LeaveFrame
    //     0x12c46f4: mov             SP, fp
    //     0x12c46f8: ldp             fp, lr, [SP], #0x10
    // 0x12c46fc: ret
    //     0x12c46fc: ret             
    // 0x12c4700: r0 = 11813
    //     0x12c4700: mov             x0, #0x2e25
    // 0x12c4704: LeaveFrame
    //     0x12c4704: mov             SP, fp
    //     0x12c4708: ldp             fp, lr, [SP], #0x10
    // 0x12c470c: ret
    //     0x12c470c: ret             
    // 0x12c4710: r0 = 11812
    //     0x12c4710: mov             x0, #0x2e24
    // 0x12c4714: LeaveFrame
    //     0x12c4714: mov             SP, fp
    //     0x12c4718: ldp             fp, lr, [SP], #0x10
    // 0x12c471c: ret
    //     0x12c471c: ret             
    // 0x12c4720: r17 = 11815
    //     0x12c4720: mov             x17, #0x2e27
    // 0x12c4724: cmp             x2, x17
    // 0x12c4728: b.gt            #0x12c4758
    // 0x12c472c: r17 = 11814
    //     0x12c472c: mov             x17, #0x2e26
    // 0x12c4730: cmp             x2, x17
    // 0x12c4734: b.gt            #0x12c4748
    // 0x12c4738: r0 = 11815
    //     0x12c4738: mov             x0, #0x2e27
    // 0x12c473c: LeaveFrame
    //     0x12c473c: mov             SP, fp
    //     0x12c4740: ldp             fp, lr, [SP], #0x10
    // 0x12c4744: ret
    //     0x12c4744: ret             
    // 0x12c4748: r0 = 11814
    //     0x12c4748: mov             x0, #0x2e26
    // 0x12c474c: LeaveFrame
    //     0x12c474c: mov             SP, fp
    //     0x12c4750: ldp             fp, lr, [SP], #0x10
    // 0x12c4754: ret
    //     0x12c4754: ret             
    // 0x12c4758: r0 = 11817
    //     0x12c4758: mov             x0, #0x2e29
    // 0x12c475c: LeaveFrame
    //     0x12c475c: mov             SP, fp
    //     0x12c4760: ldp             fp, lr, [SP], #0x10
    // 0x12c4764: ret
    //     0x12c4764: ret             
    // 0x12c4768: r17 = 12297
    //     0x12c4768: mov             x17, #0x3009
    // 0x12c476c: cmp             x2, x17
    // 0x12c4770: b.gt            #0x12c47c8
    // 0x12c4774: r17 = 12296
    //     0x12c4774: mov             x17, #0x3008
    // 0x12c4778: cmp             x2, x17
    // 0x12c477c: b.gt            #0x12c47b8
    // 0x12c4780: r17 = 11817
    //     0x12c4780: mov             x17, #0x2e29
    // 0x12c4784: cmp             x2, x17
    // 0x12c4788: b.gt            #0x12c479c
    // 0x12c478c: r0 = 11816
    //     0x12c478c: mov             x0, #0x2e28
    // 0x12c4790: LeaveFrame
    //     0x12c4790: mov             SP, fp
    //     0x12c4794: ldp             fp, lr, [SP], #0x10
    // 0x12c4798: ret
    //     0x12c4798: ret             
    // 0x12c479c: r17 = 12296
    //     0x12c479c: mov             x17, #0x3008
    // 0x12c47a0: cmp             x2, x17
    // 0x12c47a4: b.lt            #0x12c4c48
    // 0x12c47a8: r0 = 12297
    //     0x12c47a8: mov             x0, #0x3009
    // 0x12c47ac: LeaveFrame
    //     0x12c47ac: mov             SP, fp
    //     0x12c47b0: ldp             fp, lr, [SP], #0x10
    // 0x12c47b4: ret
    //     0x12c47b4: ret             
    // 0x12c47b8: r0 = 12296
    //     0x12c47b8: mov             x0, #0x3008
    // 0x12c47bc: LeaveFrame
    //     0x12c47bc: mov             SP, fp
    //     0x12c47c0: ldp             fp, lr, [SP], #0x10
    // 0x12c47c4: ret
    //     0x12c47c4: ret             
    // 0x12c47c8: r17 = 12299
    //     0x12c47c8: mov             x17, #0x300b
    // 0x12c47cc: cmp             x2, x17
    // 0x12c47d0: b.gt            #0x12c4800
    // 0x12c47d4: r17 = 12298
    //     0x12c47d4: mov             x17, #0x300a
    // 0x12c47d8: cmp             x2, x17
    // 0x12c47dc: b.gt            #0x12c47f0
    // 0x12c47e0: r0 = 12299
    //     0x12c47e0: mov             x0, #0x300b
    // 0x12c47e4: LeaveFrame
    //     0x12c47e4: mov             SP, fp
    //     0x12c47e8: ldp             fp, lr, [SP], #0x10
    // 0x12c47ec: ret
    //     0x12c47ec: ret             
    // 0x12c47f0: r0 = 12298
    //     0x12c47f0: mov             x0, #0x300a
    // 0x12c47f4: LeaveFrame
    //     0x12c47f4: mov             SP, fp
    //     0x12c47f8: ldp             fp, lr, [SP], #0x10
    // 0x12c47fc: ret
    //     0x12c47fc: ret             
    // 0x12c4800: r0 = 12301
    //     0x12c4800: mov             x0, #0x300d
    // 0x12c4804: LeaveFrame
    //     0x12c4804: mov             SP, fp
    //     0x12c4808: ldp             fp, lr, [SP], #0x10
    // 0x12c480c: ret
    //     0x12c480c: ret             
    // 0x12c4810: r17 = 12308
    //     0x12c4810: mov             x17, #0x3014
    // 0x12c4814: cmp             x2, x17
    // 0x12c4818: b.gt            #0x12c48c4
    // 0x12c481c: r17 = 12303
    //     0x12c481c: mov             x17, #0x300f
    // 0x12c4820: cmp             x2, x17
    // 0x12c4824: b.gt            #0x12c4870
    // 0x12c4828: r17 = 12302
    //     0x12c4828: mov             x17, #0x300e
    // 0x12c482c: cmp             x2, x17
    // 0x12c4830: b.gt            #0x12c4860
    // 0x12c4834: r17 = 12301
    //     0x12c4834: mov             x17, #0x300d
    // 0x12c4838: cmp             x2, x17
    // 0x12c483c: b.gt            #0x12c4850
    // 0x12c4840: r0 = 12300
    //     0x12c4840: mov             x0, #0x300c
    // 0x12c4844: LeaveFrame
    //     0x12c4844: mov             SP, fp
    //     0x12c4848: ldp             fp, lr, [SP], #0x10
    // 0x12c484c: ret
    //     0x12c484c: ret             
    // 0x12c4850: r0 = 12303
    //     0x12c4850: mov             x0, #0x300f
    // 0x12c4854: LeaveFrame
    //     0x12c4854: mov             SP, fp
    //     0x12c4858: ldp             fp, lr, [SP], #0x10
    // 0x12c485c: ret
    //     0x12c485c: ret             
    // 0x12c4860: r0 = 12302
    //     0x12c4860: mov             x0, #0x300e
    // 0x12c4864: LeaveFrame
    //     0x12c4864: mov             SP, fp
    //     0x12c4868: ldp             fp, lr, [SP], #0x10
    // 0x12c486c: ret
    //     0x12c486c: ret             
    // 0x12c4870: r17 = 12305
    //     0x12c4870: mov             x17, #0x3011
    // 0x12c4874: cmp             x2, x17
    // 0x12c4878: b.gt            #0x12c48a8
    // 0x12c487c: r17 = 12304
    //     0x12c487c: mov             x17, #0x3010
    // 0x12c4880: cmp             x2, x17
    // 0x12c4884: b.gt            #0x12c4898
    // 0x12c4888: r0 = 12305
    //     0x12c4888: mov             x0, #0x3011
    // 0x12c488c: LeaveFrame
    //     0x12c488c: mov             SP, fp
    //     0x12c4890: ldp             fp, lr, [SP], #0x10
    // 0x12c4894: ret
    //     0x12c4894: ret             
    // 0x12c4898: r0 = 12304
    //     0x12c4898: mov             x0, #0x3010
    // 0x12c489c: LeaveFrame
    //     0x12c489c: mov             SP, fp
    //     0x12c48a0: ldp             fp, lr, [SP], #0x10
    // 0x12c48a4: ret
    //     0x12c48a4: ret             
    // 0x12c48a8: r17 = 12308
    //     0x12c48a8: mov             x17, #0x3014
    // 0x12c48ac: cmp             x2, x17
    // 0x12c48b0: b.lt            #0x12c4c48
    // 0x12c48b4: r0 = 12309
    //     0x12c48b4: mov             x0, #0x3015
    // 0x12c48b8: LeaveFrame
    //     0x12c48b8: mov             SP, fp
    //     0x12c48bc: ldp             fp, lr, [SP], #0x10
    // 0x12c48c0: ret
    //     0x12c48c0: ret             
    // 0x12c48c4: r17 = 12311
    //     0x12c48c4: mov             x17, #0x3017
    // 0x12c48c8: cmp             x2, x17
    // 0x12c48cc: b.gt            #0x12c4918
    // 0x12c48d0: r17 = 12310
    //     0x12c48d0: mov             x17, #0x3016
    // 0x12c48d4: cmp             x2, x17
    // 0x12c48d8: b.gt            #0x12c4908
    // 0x12c48dc: r17 = 12309
    //     0x12c48dc: mov             x17, #0x3015
    // 0x12c48e0: cmp             x2, x17
    // 0x12c48e4: b.gt            #0x12c48f8
    // 0x12c48e8: r0 = 12308
    //     0x12c48e8: mov             x0, #0x3014
    // 0x12c48ec: LeaveFrame
    //     0x12c48ec: mov             SP, fp
    //     0x12c48f0: ldp             fp, lr, [SP], #0x10
    // 0x12c48f4: ret
    //     0x12c48f4: ret             
    // 0x12c48f8: r0 = 12311
    //     0x12c48f8: mov             x0, #0x3017
    // 0x12c48fc: LeaveFrame
    //     0x12c48fc: mov             SP, fp
    //     0x12c4900: ldp             fp, lr, [SP], #0x10
    // 0x12c4904: ret
    //     0x12c4904: ret             
    // 0x12c4908: r0 = 12310
    //     0x12c4908: mov             x0, #0x3016
    // 0x12c490c: LeaveFrame
    //     0x12c490c: mov             SP, fp
    //     0x12c4910: ldp             fp, lr, [SP], #0x10
    // 0x12c4914: ret
    //     0x12c4914: ret             
    // 0x12c4918: r17 = 12312
    //     0x12c4918: mov             x17, #0x3018
    // 0x12c491c: cmp             x2, x17
    // 0x12c4920: b.gt            #0x12c4934
    // 0x12c4924: r0 = 12313
    //     0x12c4924: mov             x0, #0x3019
    // 0x12c4928: LeaveFrame
    //     0x12c4928: mov             SP, fp
    //     0x12c492c: ldp             fp, lr, [SP], #0x10
    // 0x12c4930: ret
    //     0x12c4930: ret             
    // 0x12c4934: r0 = 12312
    //     0x12c4934: mov             x0, #0x3018
    // 0x12c4938: LeaveFrame
    //     0x12c4938: mov             SP, fp
    //     0x12c493c: ldp             fp, lr, [SP], #0x10
    // 0x12c4940: ret
    //     0x12c4940: ret             
    // 0x12c4944: r17 = 65288
    //     0x12c4944: mov             x17, #0xff08
    // 0x12c4948: cmp             x2, x17
    // 0x12c494c: b.gt            #0x12c4a9c
    // 0x12c4950: r17 = 65116
    //     0x12c4950: mov             x17, #0xfe5c
    // 0x12c4954: cmp             x2, x17
    // 0x12c4958: b.gt            #0x12c4a04
    // 0x12c495c: r17 = 65113
    //     0x12c495c: mov             x17, #0xfe59
    // 0x12c4960: cmp             x2, x17
    // 0x12c4964: b.gt            #0x12c49bc
    // 0x12c4968: r17 = 12315
    //     0x12c4968: mov             x17, #0x301b
    // 0x12c496c: cmp             x2, x17
    // 0x12c4970: b.gt            #0x12c49a0
    // 0x12c4974: r17 = 12314
    //     0x12c4974: mov             x17, #0x301a
    // 0x12c4978: cmp             x2, x17
    // 0x12c497c: b.gt            #0x12c4990
    // 0x12c4980: r0 = 12315
    //     0x12c4980: mov             x0, #0x301b
    // 0x12c4984: LeaveFrame
    //     0x12c4984: mov             SP, fp
    //     0x12c4988: ldp             fp, lr, [SP], #0x10
    // 0x12c498c: ret
    //     0x12c498c: ret             
    // 0x12c4990: r0 = 12314
    //     0x12c4990: mov             x0, #0x301a
    // 0x12c4994: LeaveFrame
    //     0x12c4994: mov             SP, fp
    //     0x12c4998: ldp             fp, lr, [SP], #0x10
    // 0x12c499c: ret
    //     0x12c499c: ret             
    // 0x12c49a0: r17 = 65113
    //     0x12c49a0: mov             x17, #0xfe59
    // 0x12c49a4: cmp             x2, x17
    // 0x12c49a8: b.lt            #0x12c4c48
    // 0x12c49ac: r0 = 65114
    //     0x12c49ac: mov             x0, #0xfe5a
    // 0x12c49b0: LeaveFrame
    //     0x12c49b0: mov             SP, fp
    //     0x12c49b4: ldp             fp, lr, [SP], #0x10
    // 0x12c49b8: ret
    //     0x12c49b8: ret             
    // 0x12c49bc: r17 = 65115
    //     0x12c49bc: mov             x17, #0xfe5b
    // 0x12c49c0: cmp             x2, x17
    // 0x12c49c4: b.gt            #0x12c49f4
    // 0x12c49c8: r17 = 65114
    //     0x12c49c8: mov             x17, #0xfe5a
    // 0x12c49cc: cmp             x2, x17
    // 0x12c49d0: b.gt            #0x12c49e4
    // 0x12c49d4: r0 = 65113
    //     0x12c49d4: mov             x0, #0xfe59
    // 0x12c49d8: LeaveFrame
    //     0x12c49d8: mov             SP, fp
    //     0x12c49dc: ldp             fp, lr, [SP], #0x10
    // 0x12c49e0: ret
    //     0x12c49e0: ret             
    // 0x12c49e4: r0 = 65116
    //     0x12c49e4: mov             x0, #0xfe5c
    // 0x12c49e8: LeaveFrame
    //     0x12c49e8: mov             SP, fp
    //     0x12c49ec: ldp             fp, lr, [SP], #0x10
    // 0x12c49f0: ret
    //     0x12c49f0: ret             
    // 0x12c49f4: r0 = 65115
    //     0x12c49f4: mov             x0, #0xfe5b
    // 0x12c49f8: LeaveFrame
    //     0x12c49f8: mov             SP, fp
    //     0x12c49fc: ldp             fp, lr, [SP], #0x10
    // 0x12c4a00: ret
    //     0x12c4a00: ret             
    // 0x12c4a04: r17 = 65124
    //     0x12c4a04: mov             x17, #0xfe64
    // 0x12c4a08: cmp             x2, x17
    // 0x12c4a0c: b.gt            #0x12c4a64
    // 0x12c4a10: r17 = 65118
    //     0x12c4a10: mov             x17, #0xfe5e
    // 0x12c4a14: cmp             x2, x17
    // 0x12c4a18: b.gt            #0x12c4a48
    // 0x12c4a1c: r17 = 65117
    //     0x12c4a1c: mov             x17, #0xfe5d
    // 0x12c4a20: cmp             x2, x17
    // 0x12c4a24: b.gt            #0x12c4a38
    // 0x12c4a28: r0 = 65118
    //     0x12c4a28: mov             x0, #0xfe5e
    // 0x12c4a2c: LeaveFrame
    //     0x12c4a2c: mov             SP, fp
    //     0x12c4a30: ldp             fp, lr, [SP], #0x10
    // 0x12c4a34: ret
    //     0x12c4a34: ret             
    // 0x12c4a38: r0 = 65117
    //     0x12c4a38: mov             x0, #0xfe5d
    // 0x12c4a3c: LeaveFrame
    //     0x12c4a3c: mov             SP, fp
    //     0x12c4a40: ldp             fp, lr, [SP], #0x10
    // 0x12c4a44: ret
    //     0x12c4a44: ret             
    // 0x12c4a48: r17 = 65124
    //     0x12c4a48: mov             x17, #0xfe64
    // 0x12c4a4c: cmp             x2, x17
    // 0x12c4a50: b.lt            #0x12c4c48
    // 0x12c4a54: r0 = 65125
    //     0x12c4a54: mov             x0, #0xfe65
    // 0x12c4a58: LeaveFrame
    //     0x12c4a58: mov             SP, fp
    //     0x12c4a5c: ldp             fp, lr, [SP], #0x10
    // 0x12c4a60: ret
    //     0x12c4a60: ret             
    // 0x12c4a64: r17 = 65125
    //     0x12c4a64: mov             x17, #0xfe65
    // 0x12c4a68: cmp             x2, x17
    // 0x12c4a6c: b.gt            #0x12c4a80
    // 0x12c4a70: r0 = 65124
    //     0x12c4a70: mov             x0, #0xfe64
    // 0x12c4a74: LeaveFrame
    //     0x12c4a74: mov             SP, fp
    //     0x12c4a78: ldp             fp, lr, [SP], #0x10
    // 0x12c4a7c: ret
    //     0x12c4a7c: ret             
    // 0x12c4a80: r17 = 65288
    //     0x12c4a80: mov             x17, #0xff08
    // 0x12c4a84: cmp             x2, x17
    // 0x12c4a88: b.lt            #0x12c4c48
    // 0x12c4a8c: r0 = 65289
    //     0x12c4a8c: mov             x0, #0xff09
    // 0x12c4a90: LeaveFrame
    //     0x12c4a90: mov             SP, fp
    //     0x12c4a94: ldp             fp, lr, [SP], #0x10
    // 0x12c4a98: ret
    //     0x12c4a98: ret             
    // 0x12c4a9c: r17 = 65371
    //     0x12c4a9c: mov             x17, #0xff5b
    // 0x12c4aa0: cmp             x2, x17
    // 0x12c4aa4: b.gt            #0x12c4b80
    // 0x12c4aa8: r17 = 65310
    //     0x12c4aa8: mov             x17, #0xff1e
    // 0x12c4aac: cmp             x2, x17
    // 0x12c4ab0: b.gt            #0x12c4b14
    // 0x12c4ab4: r17 = 65308
    //     0x12c4ab4: mov             x17, #0xff1c
    // 0x12c4ab8: cmp             x2, x17
    // 0x12c4abc: b.gt            #0x12c4af8
    // 0x12c4ac0: r17 = 65289
    //     0x12c4ac0: mov             x17, #0xff09
    // 0x12c4ac4: cmp             x2, x17
    // 0x12c4ac8: b.gt            #0x12c4adc
    // 0x12c4acc: r0 = 65288
    //     0x12c4acc: mov             x0, #0xff08
    // 0x12c4ad0: LeaveFrame
    //     0x12c4ad0: mov             SP, fp
    //     0x12c4ad4: ldp             fp, lr, [SP], #0x10
    // 0x12c4ad8: ret
    //     0x12c4ad8: ret             
    // 0x12c4adc: r17 = 65308
    //     0x12c4adc: mov             x17, #0xff1c
    // 0x12c4ae0: cmp             x2, x17
    // 0x12c4ae4: b.lt            #0x12c4c48
    // 0x12c4ae8: r0 = 65310
    //     0x12c4ae8: mov             x0, #0xff1e
    // 0x12c4aec: LeaveFrame
    //     0x12c4aec: mov             SP, fp
    //     0x12c4af0: ldp             fp, lr, [SP], #0x10
    // 0x12c4af4: ret
    //     0x12c4af4: ret             
    // 0x12c4af8: r17 = 65310
    //     0x12c4af8: mov             x17, #0xff1e
    // 0x12c4afc: cmp             x2, x17
    // 0x12c4b00: b.lt            #0x12c4c48
    // 0x12c4b04: r0 = 65308
    //     0x12c4b04: mov             x0, #0xff1c
    // 0x12c4b08: LeaveFrame
    //     0x12c4b08: mov             SP, fp
    //     0x12c4b0c: ldp             fp, lr, [SP], #0x10
    // 0x12c4b10: ret
    //     0x12c4b10: ret             
    // 0x12c4b14: r17 = 65339
    //     0x12c4b14: mov             x17, #0xff3b
    // 0x12c4b18: cmp             x2, x17
    // 0x12c4b1c: b.lt            #0x12c4c48
    // 0x12c4b20: r17 = 65341
    //     0x12c4b20: mov             x17, #0xff3d
    // 0x12c4b24: cmp             x2, x17
    // 0x12c4b28: b.gt            #0x12c4b64
    // 0x12c4b2c: r17 = 65339
    //     0x12c4b2c: mov             x17, #0xff3b
    // 0x12c4b30: cmp             x2, x17
    // 0x12c4b34: b.gt            #0x12c4b48
    // 0x12c4b38: r0 = 65341
    //     0x12c4b38: mov             x0, #0xff3d
    // 0x12c4b3c: LeaveFrame
    //     0x12c4b3c: mov             SP, fp
    //     0x12c4b40: ldp             fp, lr, [SP], #0x10
    // 0x12c4b44: ret
    //     0x12c4b44: ret             
    // 0x12c4b48: r17 = 65341
    //     0x12c4b48: mov             x17, #0xff3d
    // 0x12c4b4c: cmp             x2, x17
    // 0x12c4b50: b.lt            #0x12c4c48
    // 0x12c4b54: r0 = 65339
    //     0x12c4b54: mov             x0, #0xff3b
    // 0x12c4b58: LeaveFrame
    //     0x12c4b58: mov             SP, fp
    //     0x12c4b5c: ldp             fp, lr, [SP], #0x10
    // 0x12c4b60: ret
    //     0x12c4b60: ret             
    // 0x12c4b64: r17 = 65371
    //     0x12c4b64: mov             x17, #0xff5b
    // 0x12c4b68: cmp             x2, x17
    // 0x12c4b6c: b.lt            #0x12c4c48
    // 0x12c4b70: r0 = 65373
    //     0x12c4b70: mov             x0, #0xff5d
    // 0x12c4b74: LeaveFrame
    //     0x12c4b74: mov             SP, fp
    //     0x12c4b78: ldp             fp, lr, [SP], #0x10
    // 0x12c4b7c: ret
    //     0x12c4b7c: ret             
    // 0x12c4b80: r17 = 65373
    //     0x12c4b80: mov             x17, #0xff5d
    // 0x12c4b84: cmp             x2, x17
    // 0x12c4b88: b.lt            #0x12c4c48
    // 0x12c4b8c: r17 = 65376
    //     0x12c4b8c: mov             x17, #0xff60
    // 0x12c4b90: cmp             x2, x17
    // 0x12c4b94: b.gt            #0x12c4bec
    // 0x12c4b98: r17 = 65375
    //     0x12c4b98: mov             x17, #0xff5f
    // 0x12c4b9c: cmp             x2, x17
    // 0x12c4ba0: b.gt            #0x12c4bdc
    // 0x12c4ba4: r17 = 65373
    //     0x12c4ba4: mov             x17, #0xff5d
    // 0x12c4ba8: cmp             x2, x17
    // 0x12c4bac: b.gt            #0x12c4bc0
    // 0x12c4bb0: r0 = 65371
    //     0x12c4bb0: mov             x0, #0xff5b
    // 0x12c4bb4: LeaveFrame
    //     0x12c4bb4: mov             SP, fp
    //     0x12c4bb8: ldp             fp, lr, [SP], #0x10
    // 0x12c4bbc: ret
    //     0x12c4bbc: ret             
    // 0x12c4bc0: r17 = 65375
    //     0x12c4bc0: mov             x17, #0xff5f
    // 0x12c4bc4: cmp             x2, x17
    // 0x12c4bc8: b.lt            #0x12c4c48
    // 0x12c4bcc: r0 = 65376
    //     0x12c4bcc: mov             x0, #0xff60
    // 0x12c4bd0: LeaveFrame
    //     0x12c4bd0: mov             SP, fp
    //     0x12c4bd4: ldp             fp, lr, [SP], #0x10
    // 0x12c4bd8: ret
    //     0x12c4bd8: ret             
    // 0x12c4bdc: r0 = 65375
    //     0x12c4bdc: mov             x0, #0xff5f
    // 0x12c4be0: LeaveFrame
    //     0x12c4be0: mov             SP, fp
    //     0x12c4be4: ldp             fp, lr, [SP], #0x10
    // 0x12c4be8: ret
    //     0x12c4be8: ret             
    // 0x12c4bec: r17 = 65378
    //     0x12c4bec: mov             x17, #0xff62
    // 0x12c4bf0: cmp             x2, x17
    // 0x12c4bf4: b.lt            #0x12c4c48
    // 0x12c4bf8: r17 = 65378
    //     0x12c4bf8: mov             x17, #0xff62
    // 0x12c4bfc: cmp             x2, x17
    // 0x12c4c00: b.gt            #0x12c4c14
    // 0x12c4c04: r0 = 65379
    //     0x12c4c04: mov             x0, #0xff63
    // 0x12c4c08: LeaveFrame
    //     0x12c4c08: mov             SP, fp
    //     0x12c4c0c: ldp             fp, lr, [SP], #0x10
    // 0x12c4c10: ret
    //     0x12c4c10: ret             
    // 0x12c4c14: r0 = BoxInt64Instr(r2)
    //     0x12c4c14: sbfiz           x0, x2, #1, #0x1f
    //     0x12c4c18: cmp             x2, x0, asr #1
    //     0x12c4c1c: b.eq            #0x12c4c28
    //     0x12c4c20: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12c4c24: stur            x2, [x0, #7]
    // 0x12c4c28: r17 = 130758
    //     0x12c4c28: mov             x17, #0xfec6
    //     0x12c4c2c: movk            x17, #1, lsl #16
    // 0x12c4c30: cmp             w0, w17
    // 0x12c4c34: b.ne            #0x12c4c48
    // 0x12c4c38: r0 = 65378
    //     0x12c4c38: mov             x0, #0xff62
    // 0x12c4c3c: LeaveFrame
    //     0x12c4c3c: mov             SP, fp
    //     0x12c4c40: ldp             fp, lr, [SP], #0x10
    // 0x12c4c44: ret
    //     0x12c4c44: ret             
    // 0x12c4c48: mov             x0, x2
    // 0x12c4c4c: LeaveFrame
    //     0x12c4c4c: mov             SP, fp
    //     0x12c4c50: ldp             fp, lr, [SP], #0x10
    // 0x12c4c54: ret
    //     0x12c4c54: ret             
  }
  static _ _reorderString(/* No info */) {
    // ** addr: 0x12c4c58, size: 0x4bc
    // 0x12c4c58: EnterFrame
    //     0x12c4c58: stp             fp, lr, [SP, #-0x10]!
    //     0x12c4c5c: mov             fp, SP
    // 0x12c4c60: AllocStack(0x50)
    //     0x12c4c60: sub             SP, SP, #0x50
    // 0x12c4c64: SetupParameters(dynamic _ /* r1 => r3 */)
    //     0x12c4c64: mov             x3, x1
    // 0x12c4c68: LoadField: r0 = r3->field_b
    //     0x12c4c68: ldur            w0, [x3, #0xb]
    // 0x12c4c6c: r4 = LoadInt32Instr(r0)
    //     0x12c4c6c: sbfx            x4, x0, #1, #0x1f
    // 0x12c4c70: stur            x4, [fp, #-0x50]
    // 0x12c4c74: LoadField: r5 = r3->field_f
    //     0x12c4c74: ldur            w5, [x3, #0xf]
    // 0x12c4c78: DecompressPointer r5
    //     0x12c4c78: add             x5, x5, HEAP, lsl #32
    // 0x12c4c7c: stur            x5, [fp, #-0x48]
    // 0x12c4c80: lsl             x6, x2, #1
    // 0x12c4c84: r8 = 0
    //     0x12c4c84: mov             x8, #0
    // 0x12c4c88: r7 = 0
    //     0x12c4c88: mov             x7, #0
    // 0x12c4c8c: CheckStackOverflow
    //     0x12c4c8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c4c90: cmp             SP, x16
    //     0x12c4c94: b.ls            #0x12c508c
    // 0x12c4c98: cmp             x7, x4
    // 0x12c4c9c: b.ge            #0x12c4d5c
    // 0x12c4ca0: ArrayLoad: r10 = r5[r7]  ; Unknown_4
    //     0x12c4ca0: add             x16, x5, x7, lsl #2
    //     0x12c4ca4: ldur            w10, [x16, #0xf]
    // 0x12c4ca8: DecompressPointer r10
    //     0x12c4ca8: add             x10, x10, HEAP, lsl #32
    // 0x12c4cac: LoadField: r0 = r10->field_f
    //     0x12c4cac: ldur            w0, [x10, #0xf]
    // 0x12c4cb0: DecompressPointer r0
    //     0x12c4cb0: add             x0, x0, HEAP, lsl #32
    // 0x12c4cb4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12c4cb8: cmp             w0, w16
    // 0x12c4cbc: b.eq            #0x12c5094
    // 0x12c4cc0: r16 = Instance_CharacterType
    //     0x12c4cc0: add             x16, PP, #0x80, lsl #12  ; [pp+0x80500] Obj!CharacterType@12c6f21
    //     0x12c4cc4: ldr             x16, [x16, #0x500]
    // 0x12c4cc8: cmp             w0, w16
    // 0x12c4ccc: b.eq            #0x12c4ce0
    // 0x12c4cd0: r16 = Instance_CharacterType
    //     0x12c4cd0: add             x16, PP, #0x80, lsl #12  ; [pp+0x80468] Obj!CharacterType@12c7081
    //     0x12c4cd4: ldr             x16, [x16, #0x468]
    // 0x12c4cd8: cmp             w0, w16
    // 0x12c4cdc: b.ne            #0x12c4d24
    // 0x12c4ce0: mov             x9, x8
    // 0x12c4ce4: CheckStackOverflow
    //     0x12c4ce4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c4ce8: cmp             SP, x16
    //     0x12c4cec: b.ls            #0x12c50a0
    // 0x12c4cf0: cmp             x9, x7
    // 0x12c4cf4: b.gt            #0x12c4d24
    // 0x12c4cf8: mov             x0, x4
    // 0x12c4cfc: mov             x1, x9
    // 0x12c4d00: cmp             x1, x0
    // 0x12c4d04: b.hs            #0x12c50a8
    // 0x12c4d08: ArrayLoad: r0 = r5[r9]  ; Unknown_4
    //     0x12c4d08: add             x16, x5, x9, lsl #2
    //     0x12c4d0c: ldur            w0, [x16, #0xf]
    // 0x12c4d10: DecompressPointer r0
    //     0x12c4d10: add             x0, x0, HEAP, lsl #32
    // 0x12c4d14: StoreField: r0->field_b = r6
    //     0x12c4d14: stur            w6, [x0, #0xb]
    // 0x12c4d18: add             x0, x9, #1
    // 0x12c4d1c: mov             x9, x0
    // 0x12c4d20: b               #0x12c4ce4
    // 0x12c4d24: LoadField: r0 = r10->field_f
    //     0x12c4d24: ldur            w0, [x10, #0xf]
    // 0x12c4d28: DecompressPointer r0
    //     0x12c4d28: add             x0, x0, HEAP, lsl #32
    // 0x12c4d2c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12c4d30: cmp             w0, w16
    // 0x12c4d34: b.eq            #0x12c50ac
    // 0x12c4d38: r16 = Instance_CharacterType
    //     0x12c4d38: add             x16, PP, #0x80, lsl #12  ; [pp+0x80508] Obj!CharacterType@12c6f01
    //     0x12c4d3c: ldr             x16, [x16, #0x508]
    // 0x12c4d40: cmp             w0, w16
    // 0x12c4d44: b.eq            #0x12c4d50
    // 0x12c4d48: add             x0, x7, #1
    // 0x12c4d4c: mov             x8, x0
    // 0x12c4d50: add             x0, x7, #1
    // 0x12c4d54: mov             x7, x0
    // 0x12c4d58: b               #0x12c4c8c
    // 0x12c4d5c: lsl             x0, x2, #1
    // 0x12c4d60: mov             x1, x8
    // 0x12c4d64: CheckStackOverflow
    //     0x12c4d64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c4d68: cmp             SP, x16
    //     0x12c4d6c: b.ls            #0x12c50b8
    // 0x12c4d70: cmp             x1, x4
    // 0x12c4d74: b.ge            #0x12c4d94
    // 0x12c4d78: ArrayLoad: r2 = r5[r1]  ; Unknown_4
    //     0x12c4d78: add             x16, x5, x1, lsl #2
    //     0x12c4d7c: ldur            w2, [x16, #0xf]
    // 0x12c4d80: DecompressPointer r2
    //     0x12c4d80: add             x2, x2, HEAP, lsl #32
    // 0x12c4d84: StoreField: r2->field_b = r0
    //     0x12c4d84: stur            w0, [x2, #0xb]
    // 0x12c4d88: add             x2, x1, #1
    // 0x12c4d8c: mov             x1, x2
    // 0x12c4d90: b               #0x12c4d64
    // 0x12c4d94: LoadField: r6 = r3->field_7
    //     0x12c4d94: ldur            w6, [x3, #7]
    // 0x12c4d98: DecompressPointer r6
    //     0x12c4d98: add             x6, x6, HEAP, lsl #32
    // 0x12c4d9c: stur            x6, [fp, #-0x40]
    // 0x12c4da0: r1 = 0
    //     0x12c4da0: mov             x1, #0
    // 0x12c4da4: r3 = 63
    //     0x12c4da4: mov             x3, #0x3f
    // 0x12c4da8: r0 = 0
    //     0x12c4da8: mov             x0, #0
    // 0x12c4dac: stur            x3, [fp, #-0x38]
    // 0x12c4db0: CheckStackOverflow
    //     0x12c4db0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c4db4: cmp             SP, x16
    //     0x12c4db8: b.ls            #0x12c50c0
    // 0x12c4dbc: cmp             x0, x4
    // 0x12c4dc0: b.ge            #0x12c4e18
    // 0x12c4dc4: ArrayLoad: r2 = r5[r0]  ; Unknown_4
    //     0x12c4dc4: add             x16, x5, x0, lsl #2
    //     0x12c4dc8: ldur            w2, [x16, #0xf]
    // 0x12c4dcc: DecompressPointer r2
    //     0x12c4dcc: add             x2, x2, HEAP, lsl #32
    // 0x12c4dd0: add             x7, x0, #1
    // 0x12c4dd4: LoadField: r0 = r2->field_b
    //     0x12c4dd4: ldur            w0, [x2, #0xb]
    // 0x12c4dd8: DecompressPointer r0
    //     0x12c4dd8: add             x0, x0, HEAP, lsl #32
    // 0x12c4ddc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12c4de0: cmp             w0, w16
    // 0x12c4de4: b.eq            #0x12c50c8
    // 0x12c4de8: r2 = LoadInt32Instr(r0)
    //     0x12c4de8: sbfx            x2, x0, #1, #0x1f
    //     0x12c4dec: tbz             w0, #0, #0x12c4df4
    //     0x12c4df0: ldur            x2, [x0, #7]
    // 0x12c4df4: cmp             x2, x1
    // 0x12c4df8: b.le            #0x12c4e00
    // 0x12c4dfc: mov             x1, x2
    // 0x12c4e00: branchIfSmi(r2, 0x12c4e10)
    //     0x12c4e00: tbz             w2, #0, #0x12c4e10
    // 0x12c4e04: cmp             x2, x3
    // 0x12c4e08: b.ge            #0x12c4e10
    // 0x12c4e0c: mov             x3, x2
    // 0x12c4e10: mov             x0, x7
    // 0x12c4e14: b               #0x12c4dac
    // 0x12c4e18: mov             x7, x1
    // 0x12c4e1c: stur            x7, [fp, #-0x30]
    // 0x12c4e20: CheckStackOverflow
    //     0x12c4e20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c4e24: cmp             SP, x16
    //     0x12c4e28: b.ls            #0x12c50d4
    // 0x12c4e2c: cmp             x7, x3
    // 0x12c4e30: b.lt            #0x12c507c
    // 0x12c4e34: r0 = 0
    //     0x12c4e34: mov             x0, #0
    // 0x12c4e38: CheckStackOverflow
    //     0x12c4e38: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c4e3c: cmp             SP, x16
    //     0x12c4e40: b.ls            #0x12c50dc
    // 0x12c4e44: cmp             x0, x4
    // 0x12c4e48: b.ge            #0x12c5060
    // 0x12c4e4c: ArrayLoad: r1 = r5[r0]  ; Unknown_4
    //     0x12c4e4c: add             x16, x5, x0, lsl #2
    //     0x12c4e50: ldur            w1, [x16, #0xf]
    // 0x12c4e54: DecompressPointer r1
    //     0x12c4e54: add             x1, x1, HEAP, lsl #32
    // 0x12c4e58: LoadField: r2 = r1->field_b
    //     0x12c4e58: ldur            w2, [x1, #0xb]
    // 0x12c4e5c: DecompressPointer r2
    //     0x12c4e5c: add             x2, x2, HEAP, lsl #32
    // 0x12c4e60: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12c4e64: cmp             w2, w16
    // 0x12c4e68: b.eq            #0x12c50e4
    // 0x12c4e6c: r1 = LoadInt32Instr(r2)
    //     0x12c4e6c: sbfx            x1, x2, #1, #0x1f
    //     0x12c4e70: tbz             w2, #0, #0x12c4e78
    //     0x12c4e74: ldur            x1, [x2, #7]
    // 0x12c4e78: cmp             x1, x7
    // 0x12c4e7c: b.lt            #0x12c5040
    // 0x12c4e80: add             x1, x0, #1
    // 0x12c4e84: mov             x8, x1
    // 0x12c4e88: stur            x8, [fp, #-0x28]
    // 0x12c4e8c: CheckStackOverflow
    //     0x12c4e8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c4e90: cmp             SP, x16
    //     0x12c4e94: b.ls            #0x12c50f0
    // 0x12c4e98: cmp             x8, x4
    // 0x12c4e9c: b.ge            #0x12c4ee0
    // 0x12c4ea0: ArrayLoad: r1 = r5[r8]  ; Unknown_4
    //     0x12c4ea0: add             x16, x5, x8, lsl #2
    //     0x12c4ea4: ldur            w1, [x16, #0xf]
    // 0x12c4ea8: DecompressPointer r1
    //     0x12c4ea8: add             x1, x1, HEAP, lsl #32
    // 0x12c4eac: LoadField: r2 = r1->field_b
    //     0x12c4eac: ldur            w2, [x1, #0xb]
    // 0x12c4eb0: DecompressPointer r2
    //     0x12c4eb0: add             x2, x2, HEAP, lsl #32
    // 0x12c4eb4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12c4eb8: cmp             w2, w16
    // 0x12c4ebc: b.eq            #0x12c50f8
    // 0x12c4ec0: r1 = LoadInt32Instr(r2)
    //     0x12c4ec0: sbfx            x1, x2, #1, #0x1f
    //     0x12c4ec4: tbz             w2, #0, #0x12c4ecc
    //     0x12c4ec8: ldur            x1, [x2, #7]
    // 0x12c4ecc: cmp             x1, x7
    // 0x12c4ed0: b.lt            #0x12c4ee0
    // 0x12c4ed4: add             x1, x8, #1
    // 0x12c4ed8: mov             x8, x1
    // 0x12c4edc: b               #0x12c4e88
    // 0x12c4ee0: sub             x1, x8, #1
    // 0x12c4ee4: mov             x10, x0
    // 0x12c4ee8: mov             x9, x1
    // 0x12c4eec: stur            x10, [fp, #-0x18]
    // 0x12c4ef0: stur            x9, [fp, #-0x20]
    // 0x12c4ef4: CheckStackOverflow
    //     0x12c4ef4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c4ef8: cmp             SP, x16
    //     0x12c4efc: b.ls            #0x12c5104
    // 0x12c4f00: cmp             x10, x9
    // 0x12c4f04: b.ge            #0x12c5038
    // 0x12c4f08: mov             x0, x4
    // 0x12c4f0c: mov             x1, x10
    // 0x12c4f10: cmp             x1, x0
    // 0x12c4f14: b.hs            #0x12c510c
    // 0x12c4f18: ArrayLoad: r11 = r5[r10]  ; Unknown_4
    //     0x12c4f18: add             x16, x5, x10, lsl #2
    //     0x12c4f1c: ldur            w11, [x16, #0xf]
    // 0x12c4f20: DecompressPointer r11
    //     0x12c4f20: add             x11, x11, HEAP, lsl #32
    // 0x12c4f24: mov             x0, x4
    // 0x12c4f28: mov             x1, x9
    // 0x12c4f2c: stur            x11, [fp, #-0x10]
    // 0x12c4f30: cmp             x1, x0
    // 0x12c4f34: b.hs            #0x12c5110
    // 0x12c4f38: ArrayLoad: r12 = r5[r9]  ; Unknown_4
    //     0x12c4f38: add             x16, x5, x9, lsl #2
    //     0x12c4f3c: ldur            w12, [x16, #0xf]
    // 0x12c4f40: DecompressPointer r12
    //     0x12c4f40: add             x12, x12, HEAP, lsl #32
    // 0x12c4f44: mov             x0, x12
    // 0x12c4f48: mov             x2, x6
    // 0x12c4f4c: stur            x12, [fp, #-8]
    // 0x12c4f50: r1 = Null
    //     0x12c4f50: mov             x1, NULL
    // 0x12c4f54: cmp             w2, NULL
    // 0x12c4f58: b.eq            #0x12c4f78
    // 0x12c4f5c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x12c4f5c: ldur            w4, [x2, #0x17]
    // 0x12c4f60: DecompressPointer r4
    //     0x12c4f60: add             x4, x4, HEAP, lsl #32
    // 0x12c4f64: r8 = X0
    //     0x12c4f64: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x12c4f68: LoadField: r9 = r4->field_7
    //     0x12c4f68: ldur            x9, [x4, #7]
    // 0x12c4f6c: r3 = Null
    //     0x12c4f6c: add             x3, PP, #0x80, lsl #12  ; [pp+0x80510] Null
    //     0x12c4f70: ldr             x3, [x3, #0x510]
    // 0x12c4f74: blr             x9
    // 0x12c4f78: ldur            x1, [fp, #-0x48]
    // 0x12c4f7c: ldur            x0, [fp, #-8]
    // 0x12c4f80: ldur            x3, [fp, #-0x18]
    // 0x12c4f84: ArrayStore: r1[r3] = r0  ; List_4
    //     0x12c4f84: add             x25, x1, x3, lsl #2
    //     0x12c4f88: add             x25, x25, #0xf
    //     0x12c4f8c: str             w0, [x25]
    //     0x12c4f90: tbz             w0, #0, #0x12c4fac
    //     0x12c4f94: ldurb           w16, [x1, #-1]
    //     0x12c4f98: ldurb           w17, [x0, #-1]
    //     0x12c4f9c: and             x16, x17, x16, lsr #2
    //     0x12c4fa0: tst             x16, HEAP, lsr #32
    //     0x12c4fa4: b.eq            #0x12c4fac
    //     0x12c4fa8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12c4fac: ldur            x0, [fp, #-0x10]
    // 0x12c4fb0: ldur            x2, [fp, #-0x40]
    // 0x12c4fb4: r1 = Null
    //     0x12c4fb4: mov             x1, NULL
    // 0x12c4fb8: cmp             w2, NULL
    // 0x12c4fbc: b.eq            #0x12c4fdc
    // 0x12c4fc0: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x12c4fc0: ldur            w4, [x2, #0x17]
    // 0x12c4fc4: DecompressPointer r4
    //     0x12c4fc4: add             x4, x4, HEAP, lsl #32
    // 0x12c4fc8: r8 = X0
    //     0x12c4fc8: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x12c4fcc: LoadField: r9 = r4->field_7
    //     0x12c4fcc: ldur            x9, [x4, #7]
    // 0x12c4fd0: r3 = Null
    //     0x12c4fd0: add             x3, PP, #0x80, lsl #12  ; [pp+0x80520] Null
    //     0x12c4fd4: ldr             x3, [x3, #0x520]
    // 0x12c4fd8: blr             x9
    // 0x12c4fdc: ldur            x1, [fp, #-0x48]
    // 0x12c4fe0: ldur            x0, [fp, #-0x10]
    // 0x12c4fe4: ldur            x2, [fp, #-0x20]
    // 0x12c4fe8: ArrayStore: r1[r2] = r0  ; List_4
    //     0x12c4fe8: add             x25, x1, x2, lsl #2
    //     0x12c4fec: add             x25, x25, #0xf
    //     0x12c4ff0: str             w0, [x25]
    //     0x12c4ff4: tbz             w0, #0, #0x12c5010
    //     0x12c4ff8: ldurb           w16, [x1, #-1]
    //     0x12c4ffc: ldurb           w17, [x0, #-1]
    //     0x12c5000: and             x16, x17, x16, lsr #2
    //     0x12c5004: tst             x16, HEAP, lsr #32
    //     0x12c5008: b.eq            #0x12c5010
    //     0x12c500c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12c5010: ldur            x1, [fp, #-0x18]
    // 0x12c5014: add             x10, x1, #1
    // 0x12c5018: sub             x9, x2, #1
    // 0x12c501c: ldur            x3, [fp, #-0x38]
    // 0x12c5020: ldur            x7, [fp, #-0x30]
    // 0x12c5024: ldur            x8, [fp, #-0x28]
    // 0x12c5028: ldur            x5, [fp, #-0x48]
    // 0x12c502c: ldur            x6, [fp, #-0x40]
    // 0x12c5030: ldur            x4, [fp, #-0x50]
    // 0x12c5034: b               #0x12c4eec
    // 0x12c5038: ldur            x1, [fp, #-0x28]
    // 0x12c503c: b               #0x12c5044
    // 0x12c5040: mov             x1, x0
    // 0x12c5044: add             x0, x1, #1
    // 0x12c5048: ldur            x3, [fp, #-0x38]
    // 0x12c504c: ldur            x7, [fp, #-0x30]
    // 0x12c5050: ldur            x5, [fp, #-0x48]
    // 0x12c5054: ldur            x6, [fp, #-0x40]
    // 0x12c5058: ldur            x4, [fp, #-0x50]
    // 0x12c505c: b               #0x12c4e38
    // 0x12c5060: mov             x1, x7
    // 0x12c5064: sub             x7, x1, #1
    // 0x12c5068: ldur            x3, [fp, #-0x38]
    // 0x12c506c: ldur            x5, [fp, #-0x48]
    // 0x12c5070: ldur            x6, [fp, #-0x40]
    // 0x12c5074: ldur            x4, [fp, #-0x50]
    // 0x12c5078: b               #0x12c4e1c
    // 0x12c507c: r0 = Null
    //     0x12c507c: mov             x0, NULL
    // 0x12c5080: LeaveFrame
    //     0x12c5080: mov             SP, fp
    //     0x12c5084: ldp             fp, lr, [SP], #0x10
    // 0x12c5088: ret
    //     0x12c5088: ret             
    // 0x12c508c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c508c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c5090: b               #0x12c4c98
    // 0x12c5094: r9 = type
    //     0x12c5094: add             x9, PP, #0x80, lsl #12  ; [pp+0x804e0] Field <_CharData@1190396231.type>: late (offset: 0x10)
    //     0x12c5098: ldr             x9, [x9, #0x4e0]
    // 0x12c509c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12c509c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12c50a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c50a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c50a4: b               #0x12c4cf0
    // 0x12c50a8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c50a8: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c50ac: r9 = type
    //     0x12c50ac: add             x9, PP, #0x80, lsl #12  ; [pp+0x804e0] Field <_CharData@1190396231.type>: late (offset: 0x10)
    //     0x12c50b0: ldr             x9, [x9, #0x4e0]
    // 0x12c50b4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12c50b4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12c50b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c50b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c50bc: b               #0x12c4d70
    // 0x12c50c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c50c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c50c4: b               #0x12c4dbc
    // 0x12c50c8: r9 = embeddingLevel
    //     0x12c50c8: add             x9, PP, #0x80, lsl #12  ; [pp+0x804e8] Field <_CharData@1190396231.embeddingLevel>: late (offset: 0xc)
    //     0x12c50cc: ldr             x9, [x9, #0x4e8]
    // 0x12c50d0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12c50d0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12c50d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c50d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c50d8: b               #0x12c4e2c
    // 0x12c50dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c50dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c50e0: b               #0x12c4e44
    // 0x12c50e4: r9 = embeddingLevel
    //     0x12c50e4: add             x9, PP, #0x80, lsl #12  ; [pp+0x804e8] Field <_CharData@1190396231.embeddingLevel>: late (offset: 0xc)
    //     0x12c50e8: ldr             x9, [x9, #0x4e8]
    // 0x12c50ec: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12c50ec: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12c50f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c50f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c50f4: b               #0x12c4e98
    // 0x12c50f8: r9 = embeddingLevel
    //     0x12c50f8: add             x9, PP, #0x80, lsl #12  ; [pp+0x804e8] Field <_CharData@1190396231.embeddingLevel>: late (offset: 0xc)
    //     0x12c50fc: ldr             x9, [x9, #0x4e8]
    // 0x12c5100: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12c5100: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12c5104: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c5104: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c5108: b               #0x12c4f00
    // 0x12c510c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c510c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c5110: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c5110: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  static _ _resolveImplicitTypes(/* No info */) {
    // ** addr: 0x12c5114, size: 0x29c
    // 0x12c5114: EnterFrame
    //     0x12c5114: stp             fp, lr, [SP, #-0x10]!
    //     0x12c5118: mov             fp, SP
    // 0x12c511c: tbnz            w5, #0, #0x12c5264
    // 0x12c5120: LoadField: r4 = r1->field_b
    //     0x12c5120: ldur            w4, [x1, #0xb]
    // 0x12c5124: r5 = LoadInt32Instr(r4)
    //     0x12c5124: sbfx            x5, x4, #1, #0x1f
    // 0x12c5128: LoadField: r4 = r1->field_f
    //     0x12c5128: ldur            w4, [x1, #0xf]
    // 0x12c512c: DecompressPointer r4
    //     0x12c512c: add             x4, x4, HEAP, lsl #32
    // 0x12c5130: CheckStackOverflow
    //     0x12c5130: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c5134: cmp             SP, x16
    //     0x12c5138: b.ls            #0x12c535c
    // 0x12c513c: cmp             x2, x3
    // 0x12c5140: b.ge            #0x12c534c
    // 0x12c5144: mov             x0, x5
    // 0x12c5148: mov             x1, x2
    // 0x12c514c: cmp             x1, x0
    // 0x12c5150: b.hs            #0x12c5364
    // 0x12c5154: ArrayLoad: r6 = r4[r2]  ; Unknown_4
    //     0x12c5154: add             x16, x4, x2, lsl #2
    //     0x12c5158: ldur            w6, [x16, #0xf]
    // 0x12c515c: DecompressPointer r6
    //     0x12c515c: add             x6, x6, HEAP, lsl #32
    // 0x12c5160: LoadField: r7 = r6->field_f
    //     0x12c5160: ldur            w7, [x6, #0xf]
    // 0x12c5164: DecompressPointer r7
    //     0x12c5164: add             x7, x7, HEAP, lsl #32
    // 0x12c5168: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12c516c: cmp             w7, w16
    // 0x12c5170: b.eq            #0x12c5368
    // 0x12c5174: r16 = Instance_CharacterType
    //     0x12c5174: add             x16, PP, #0x80, lsl #12  ; [pp+0x804d0] Obj!CharacterType@12c7061
    //     0x12c5178: ldr             x16, [x16, #0x4d0]
    // 0x12c517c: cmp             w7, w16
    // 0x12c5180: b.ne            #0x12c51e0
    // 0x12c5184: LoadField: r8 = r6->field_b
    //     0x12c5184: ldur            w8, [x6, #0xb]
    // 0x12c5188: DecompressPointer r8
    //     0x12c5188: add             x8, x8, HEAP, lsl #32
    // 0x12c518c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12c5190: cmp             w8, w16
    // 0x12c5194: b.eq            #0x12c5374
    // 0x12c5198: r10 = LoadInt32Instr(r8)
    //     0x12c5198: sbfx            x10, x8, #1, #0x1f
    //     0x12c519c: tbz             w8, #0, #0x12c51a4
    //     0x12c51a0: ldur            x10, [x8, #7]
    // 0x12c51a4: add             x8, x10, #1
    // 0x12c51a8: r0 = BoxInt64Instr(r8)
    //     0x12c51a8: sbfiz           x0, x8, #1, #0x1f
    //     0x12c51ac: cmp             x8, x0, asr #1
    //     0x12c51b0: b.eq            #0x12c51bc
    //     0x12c51b4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12c51b8: stur            x8, [x0, #7]
    // 0x12c51bc: StoreField: r6->field_b = r0
    //     0x12c51bc: stur            w0, [x6, #0xb]
    //     0x12c51c0: tbz             w0, #0, #0x12c51dc
    //     0x12c51c4: ldurb           w16, [x6, #-1]
    //     0x12c51c8: ldurb           w17, [x0, #-1]
    //     0x12c51cc: and             x16, x17, x16, lsr #2
    //     0x12c51d0: tst             x16, HEAP, lsr #32
    //     0x12c51d4: b.eq            #0x12c51dc
    //     0x12c51d8: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0x12c51dc: b               #0x12c5258
    // 0x12c51e0: r16 = Instance_CharacterType
    //     0x12c51e0: add             x16, PP, #0x80, lsl #12  ; [pp+0x80530] Obj!CharacterType@12c6f61
    //     0x12c51e4: ldr             x16, [x16, #0x530]
    // 0x12c51e8: cmp             w7, w16
    // 0x12c51ec: b.eq            #0x12c5200
    // 0x12c51f0: r16 = Instance_CharacterType
    //     0x12c51f0: add             x16, PP, #0x80, lsl #12  ; [pp+0x80538] Obj!CharacterType@12c6f41
    //     0x12c51f4: ldr             x16, [x16, #0x538]
    // 0x12c51f8: cmp             w7, w16
    // 0x12c51fc: b.ne            #0x12c5258
    // 0x12c5200: LoadField: r7 = r6->field_b
    //     0x12c5200: ldur            w7, [x6, #0xb]
    // 0x12c5204: DecompressPointer r7
    //     0x12c5204: add             x7, x7, HEAP, lsl #32
    // 0x12c5208: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12c520c: cmp             w7, w16
    // 0x12c5210: b.eq            #0x12c5380
    // 0x12c5214: r8 = LoadInt32Instr(r7)
    //     0x12c5214: sbfx            x8, x7, #1, #0x1f
    //     0x12c5218: tbz             w7, #0, #0x12c5220
    //     0x12c521c: ldur            x8, [x7, #7]
    // 0x12c5220: add             x7, x8, #2
    // 0x12c5224: r0 = BoxInt64Instr(r7)
    //     0x12c5224: sbfiz           x0, x7, #1, #0x1f
    //     0x12c5228: cmp             x7, x0, asr #1
    //     0x12c522c: b.eq            #0x12c5238
    //     0x12c5230: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12c5234: stur            x7, [x0, #7]
    // 0x12c5238: StoreField: r6->field_b = r0
    //     0x12c5238: stur            w0, [x6, #0xb]
    //     0x12c523c: tbz             w0, #0, #0x12c5258
    //     0x12c5240: ldurb           w16, [x6, #-1]
    //     0x12c5244: ldurb           w17, [x0, #-1]
    //     0x12c5248: and             x16, x17, x16, lsr #2
    //     0x12c524c: tst             x16, HEAP, lsr #32
    //     0x12c5250: b.eq            #0x12c5258
    //     0x12c5254: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0x12c5258: add             x0, x2, #1
    // 0x12c525c: mov             x2, x0
    // 0x12c5260: b               #0x12c5130
    // 0x12c5264: LoadField: r4 = r1->field_b
    //     0x12c5264: ldur            w4, [x1, #0xb]
    // 0x12c5268: r5 = LoadInt32Instr(r4)
    //     0x12c5268: sbfx            x5, x4, #1, #0x1f
    // 0x12c526c: LoadField: r4 = r1->field_f
    //     0x12c526c: ldur            w4, [x1, #0xf]
    // 0x12c5270: DecompressPointer r4
    //     0x12c5270: add             x4, x4, HEAP, lsl #32
    // 0x12c5274: CheckStackOverflow
    //     0x12c5274: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c5278: cmp             SP, x16
    //     0x12c527c: b.ls            #0x12c538c
    // 0x12c5280: cmp             x2, x3
    // 0x12c5284: b.ge            #0x12c534c
    // 0x12c5288: mov             x0, x5
    // 0x12c528c: mov             x1, x2
    // 0x12c5290: cmp             x1, x0
    // 0x12c5294: b.hs            #0x12c5394
    // 0x12c5298: ArrayLoad: r6 = r4[r2]  ; Unknown_4
    //     0x12c5298: add             x16, x4, x2, lsl #2
    //     0x12c529c: ldur            w6, [x16, #0xf]
    // 0x12c52a0: DecompressPointer r6
    //     0x12c52a0: add             x6, x6, HEAP, lsl #32
    // 0x12c52a4: LoadField: r7 = r6->field_f
    //     0x12c52a4: ldur            w7, [x6, #0xf]
    // 0x12c52a8: DecompressPointer r7
    //     0x12c52a8: add             x7, x7, HEAP, lsl #32
    // 0x12c52ac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12c52b0: cmp             w7, w16
    // 0x12c52b4: b.eq            #0x12c5398
    // 0x12c52b8: r16 = Instance_CharacterType
    //     0x12c52b8: add             x16, PP, #0x80, lsl #12  ; [pp+0x804b8] Obj!CharacterType@12c6ee1
    //     0x12c52bc: ldr             x16, [x16, #0x4b8]
    // 0x12c52c0: cmp             w7, w16
    // 0x12c52c4: b.eq            #0x12c52e8
    // 0x12c52c8: r16 = Instance_CharacterType
    //     0x12c52c8: add             x16, PP, #0x80, lsl #12  ; [pp+0x80530] Obj!CharacterType@12c6f61
    //     0x12c52cc: ldr             x16, [x16, #0x530]
    // 0x12c52d0: cmp             w7, w16
    // 0x12c52d4: b.eq            #0x12c52e8
    // 0x12c52d8: r16 = Instance_CharacterType
    //     0x12c52d8: add             x16, PP, #0x80, lsl #12  ; [pp+0x80538] Obj!CharacterType@12c6f41
    //     0x12c52dc: ldr             x16, [x16, #0x538]
    // 0x12c52e0: cmp             w7, w16
    // 0x12c52e4: b.ne            #0x12c5340
    // 0x12c52e8: LoadField: r7 = r6->field_b
    //     0x12c52e8: ldur            w7, [x6, #0xb]
    // 0x12c52ec: DecompressPointer r7
    //     0x12c52ec: add             x7, x7, HEAP, lsl #32
    // 0x12c52f0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12c52f4: cmp             w7, w16
    // 0x12c52f8: b.eq            #0x12c53a4
    // 0x12c52fc: r8 = LoadInt32Instr(r7)
    //     0x12c52fc: sbfx            x8, x7, #1, #0x1f
    //     0x12c5300: tbz             w7, #0, #0x12c5308
    //     0x12c5304: ldur            x8, [x7, #7]
    // 0x12c5308: add             x7, x8, #1
    // 0x12c530c: r0 = BoxInt64Instr(r7)
    //     0x12c530c: sbfiz           x0, x7, #1, #0x1f
    //     0x12c5310: cmp             x7, x0, asr #1
    //     0x12c5314: b.eq            #0x12c5320
    //     0x12c5318: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12c531c: stur            x7, [x0, #7]
    // 0x12c5320: StoreField: r6->field_b = r0
    //     0x12c5320: stur            w0, [x6, #0xb]
    //     0x12c5324: tbz             w0, #0, #0x12c5340
    //     0x12c5328: ldurb           w16, [x6, #-1]
    //     0x12c532c: ldurb           w17, [x0, #-1]
    //     0x12c5330: and             x16, x17, x16, lsr #2
    //     0x12c5334: tst             x16, HEAP, lsr #32
    //     0x12c5338: b.eq            #0x12c5340
    //     0x12c533c: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0x12c5340: add             x0, x2, #1
    // 0x12c5344: mov             x2, x0
    // 0x12c5348: b               #0x12c5274
    // 0x12c534c: r0 = Null
    //     0x12c534c: mov             x0, NULL
    // 0x12c5350: LeaveFrame
    //     0x12c5350: mov             SP, fp
    //     0x12c5354: ldp             fp, lr, [SP], #0x10
    // 0x12c5358: ret
    //     0x12c5358: ret             
    // 0x12c535c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c535c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c5360: b               #0x12c513c
    // 0x12c5364: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c5364: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c5368: r9 = type
    //     0x12c5368: add             x9, PP, #0x80, lsl #12  ; [pp+0x804e0] Field <_CharData@1190396231.type>: late (offset: 0x10)
    //     0x12c536c: ldr             x9, [x9, #0x4e0]
    // 0x12c5370: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12c5370: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12c5374: r9 = embeddingLevel
    //     0x12c5374: add             x9, PP, #0x80, lsl #12  ; [pp+0x804e8] Field <_CharData@1190396231.embeddingLevel>: late (offset: 0xc)
    //     0x12c5378: ldr             x9, [x9, #0x4e8]
    // 0x12c537c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12c537c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12c5380: r9 = embeddingLevel
    //     0x12c5380: add             x9, PP, #0x80, lsl #12  ; [pp+0x804e8] Field <_CharData@1190396231.embeddingLevel>: late (offset: 0xc)
    //     0x12c5384: ldr             x9, [x9, #0x4e8]
    // 0x12c5388: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12c5388: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12c538c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c538c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c5390: b               #0x12c5280
    // 0x12c5394: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c5394: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c5398: r9 = type
    //     0x12c5398: add             x9, PP, #0x80, lsl #12  ; [pp+0x804e0] Field <_CharData@1190396231.type>: late (offset: 0x10)
    //     0x12c539c: ldr             x9, [x9, #0x4e0]
    // 0x12c53a0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12c53a0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12c53a4: r9 = embeddingLevel
    //     0x12c53a4: add             x9, PP, #0x80, lsl #12  ; [pp+0x804e8] Field <_CharData@1190396231.embeddingLevel>: late (offset: 0xc)
    //     0x12c53a8: ldr             x9, [x9, #0x4e8]
    // 0x12c53ac: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12c53ac: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  static _ _resolveNeutralTypes(/* No info */) {
    // ** addr: 0x12c53b0, size: 0x384
    // 0x12c53b0: EnterFrame
    //     0x12c53b0: stp             fp, lr, [SP, #-0x10]!
    //     0x12c53b4: mov             fp, SP
    // 0x12c53b8: AllocStack(0x40)
    //     0x12c53b8: sub             SP, SP, #0x40
    // 0x12c53bc: SetupParameters(dynamic _ /* r1 => r8, fp-0x10 */, dynamic _ /* r2 => r4, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */, dynamic _ /* r5 => r5, fp-0x28 */, dynamic _ /* r6 => r6, fp-0x30 */, dynamic _ /* r7 => r7, fp-0x38 */)
    //     0x12c53bc: mov             x8, x1
    //     0x12c53c0: mov             x4, x2
    //     0x12c53c4: stur            x1, [fp, #-0x10]
    //     0x12c53c8: stur            x2, [fp, #-0x18]
    //     0x12c53cc: stur            x3, [fp, #-0x20]
    //     0x12c53d0: stur            x5, [fp, #-0x28]
    //     0x12c53d4: stur            x6, [fp, #-0x30]
    //     0x12c53d8: stur            x7, [fp, #-0x38]
    // 0x12c53dc: CheckStackOverflow
    //     0x12c53dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c53e0: cmp             SP, x16
    //     0x12c53e4: b.ls            #0x12c56e8
    // 0x12c53e8: mov             x11, x4
    // 0x12c53ec: r10 = 8
    //     0x12c53ec: mov             x10, #8
    // 0x12c53f0: stur            x11, [fp, #-8]
    // 0x12c53f4: CheckStackOverflow
    //     0x12c53f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c53f8: cmp             SP, x16
    //     0x12c53fc: b.ls            #0x12c56f0
    // 0x12c5400: cmp             x11, x3
    // 0x12c5404: b.ge            #0x12c56d8
    // 0x12c5408: LoadField: r0 = r8->field_b
    //     0x12c5408: ldur            w0, [x8, #0xb]
    // 0x12c540c: r1 = LoadInt32Instr(r0)
    //     0x12c540c: sbfx            x1, x0, #1, #0x1f
    // 0x12c5410: mov             x0, x1
    // 0x12c5414: mov             x1, x11
    // 0x12c5418: cmp             x1, x0
    // 0x12c541c: b.hs            #0x12c56f8
    // 0x12c5420: LoadField: r0 = r8->field_f
    //     0x12c5420: ldur            w0, [x8, #0xf]
    // 0x12c5424: DecompressPointer r0
    //     0x12c5424: add             x0, x0, HEAP, lsl #32
    // 0x12c5428: ArrayLoad: r1 = r0[r11]  ; Unknown_4
    //     0x12c5428: add             x16, x0, x11, lsl #2
    //     0x12c542c: ldur            w1, [x16, #0xf]
    // 0x12c5430: DecompressPointer r1
    //     0x12c5430: add             x1, x1, HEAP, lsl #32
    // 0x12c5434: LoadField: r0 = r1->field_f
    //     0x12c5434: ldur            w0, [x1, #0xf]
    // 0x12c5438: DecompressPointer r0
    //     0x12c5438: add             x0, x0, HEAP, lsl #32
    // 0x12c543c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12c5440: cmp             w0, w16
    // 0x12c5444: b.eq            #0x12c56fc
    // 0x12c5448: r16 = Instance_CharacterType
    //     0x12c5448: add             x16, PP, #0x80, lsl #12  ; [pp+0x80508] Obj!CharacterType@12c6f01
    //     0x12c544c: ldr             x16, [x16, #0x508]
    // 0x12c5450: cmp             w0, w16
    // 0x12c5454: b.eq            #0x12c5488
    // 0x12c5458: r16 = Instance_CharacterType
    //     0x12c5458: add             x16, PP, #0x80, lsl #12  ; [pp+0x80540] Obj!CharacterType@12c6f81
    //     0x12c545c: ldr             x16, [x16, #0x540]
    // 0x12c5460: cmp             w0, w16
    // 0x12c5464: b.eq            #0x12c5488
    // 0x12c5468: r16 = Instance_CharacterType
    //     0x12c5468: add             x16, PP, #0x80, lsl #12  ; [pp+0x80468] Obj!CharacterType@12c7081
    //     0x12c546c: ldr             x16, [x16, #0x468]
    // 0x12c5470: cmp             w0, w16
    // 0x12c5474: b.eq            #0x12c5488
    // 0x12c5478: r16 = Instance_CharacterType
    //     0x12c5478: add             x16, PP, #0x80, lsl #12  ; [pp+0x80500] Obj!CharacterType@12c6f21
    //     0x12c547c: ldr             x16, [x16, #0x500]
    // 0x12c5480: cmp             w0, w16
    // 0x12c5484: b.ne            #0x12c56a8
    // 0x12c5488: mov             x2, x10
    // 0x12c548c: r1 = Null
    //     0x12c548c: mov             x1, NULL
    // 0x12c5490: r0 = AllocateArray()
    //     0x12c5490: bl              #0x13df928  ; AllocateArrayStub
    // 0x12c5494: stur            x0, [fp, #-0x40]
    // 0x12c5498: r16 = Instance_CharacterType
    //     0x12c5498: add             x16, PP, #0x80, lsl #12  ; [pp+0x80468] Obj!CharacterType@12c7081
    //     0x12c549c: ldr             x16, [x16, #0x468]
    // 0x12c54a0: StoreField: r0->field_f = r16
    //     0x12c54a0: stur            w16, [x0, #0xf]
    // 0x12c54a4: r16 = Instance_CharacterType
    //     0x12c54a4: add             x16, PP, #0x80, lsl #12  ; [pp+0x80500] Obj!CharacterType@12c6f21
    //     0x12c54a8: ldr             x16, [x16, #0x500]
    // 0x12c54ac: StoreField: r0->field_13 = r16
    //     0x12c54ac: stur            w16, [x0, #0x13]
    // 0x12c54b0: r16 = Instance_CharacterType
    //     0x12c54b0: add             x16, PP, #0x80, lsl #12  ; [pp+0x80508] Obj!CharacterType@12c6f01
    //     0x12c54b4: ldr             x16, [x16, #0x508]
    // 0x12c54b8: ArrayStore: r0[0] = r16  ; List_4
    //     0x12c54b8: stur            w16, [x0, #0x17]
    // 0x12c54bc: r16 = Instance_CharacterType
    //     0x12c54bc: add             x16, PP, #0x80, lsl #12  ; [pp+0x80540] Obj!CharacterType@12c6f81
    //     0x12c54c0: ldr             x16, [x16, #0x540]
    // 0x12c54c4: StoreField: r0->field_1b = r16
    //     0x12c54c4: stur            w16, [x0, #0x1b]
    // 0x12c54c8: r1 = <CharacterType>
    //     0x12c54c8: add             x1, PP, #0x80, lsl #12  ; [pp+0x80548] TypeArguments: <CharacterType>
    //     0x12c54cc: ldr             x1, [x1, #0x548]
    // 0x12c54d0: r0 = AllocateGrowableArray()
    //     0x12c54d0: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x12c54d4: mov             x1, x0
    // 0x12c54d8: ldur            x0, [fp, #-0x40]
    // 0x12c54dc: StoreField: r1->field_f = r0
    //     0x12c54dc: stur            w0, [x1, #0xf]
    // 0x12c54e0: r0 = 8
    //     0x12c54e0: mov             x0, #8
    // 0x12c54e4: StoreField: r1->field_b = r0
    //     0x12c54e4: stur            w0, [x1, #0xb]
    // 0x12c54e8: mov             x5, x1
    // 0x12c54ec: ldur            x1, [fp, #-0x10]
    // 0x12c54f0: ldur            x2, [fp, #-8]
    // 0x12c54f4: ldur            x3, [fp, #-0x20]
    // 0x12c54f8: r0 = _findRunLimit()
    //     0x12c54f8: bl              #0x12c5734  ; [package:bidi/bidi.dart] ::_findRunLimit
    // 0x12c54fc: mov             x4, x0
    // 0x12c5500: ldur            x2, [fp, #-0x18]
    // 0x12c5504: ldur            x3, [fp, #-8]
    // 0x12c5508: cmp             x3, x2
    // 0x12c550c: b.ne            #0x12c551c
    // 0x12c5510: ldur            x7, [fp, #-0x28]
    // 0x12c5514: ldur            x5, [fp, #-0x10]
    // 0x12c5518: b               #0x12c558c
    // 0x12c551c: ldur            x5, [fp, #-0x10]
    // 0x12c5520: sub             x6, x3, #1
    // 0x12c5524: LoadField: r7 = r5->field_b
    //     0x12c5524: ldur            w7, [x5, #0xb]
    // 0x12c5528: r0 = LoadInt32Instr(r7)
    //     0x12c5528: sbfx            x0, x7, #1, #0x1f
    // 0x12c552c: mov             x1, x6
    // 0x12c5530: cmp             x1, x0
    // 0x12c5534: b.hs            #0x12c5708
    // 0x12c5538: LoadField: r7 = r5->field_f
    //     0x12c5538: ldur            w7, [x5, #0xf]
    // 0x12c553c: DecompressPointer r7
    //     0x12c553c: add             x7, x7, HEAP, lsl #32
    // 0x12c5540: ArrayLoad: r8 = r7[r6]  ; Unknown_4
    //     0x12c5540: add             x16, x7, x6, lsl #2
    //     0x12c5544: ldur            w8, [x16, #0xf]
    // 0x12c5548: DecompressPointer r8
    //     0x12c5548: add             x8, x8, HEAP, lsl #32
    // 0x12c554c: LoadField: r6 = r8->field_f
    //     0x12c554c: ldur            w6, [x8, #0xf]
    // 0x12c5550: DecompressPointer r6
    //     0x12c5550: add             x6, x6, HEAP, lsl #32
    // 0x12c5554: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12c5558: cmp             w6, w16
    // 0x12c555c: b.eq            #0x12c570c
    // 0x12c5560: r16 = Instance_CharacterType
    //     0x12c5560: add             x16, PP, #0x80, lsl #12  ; [pp+0x80530] Obj!CharacterType@12c6f61
    //     0x12c5564: ldr             x16, [x16, #0x530]
    // 0x12c5568: cmp             w6, w16
    // 0x12c556c: b.eq            #0x12c5580
    // 0x12c5570: r16 = Instance_CharacterType
    //     0x12c5570: add             x16, PP, #0x80, lsl #12  ; [pp+0x80538] Obj!CharacterType@12c6f41
    //     0x12c5574: ldr             x16, [x16, #0x538]
    // 0x12c5578: cmp             w6, w16
    // 0x12c557c: b.ne            #0x12c5588
    // 0x12c5580: r6 = Instance_CharacterType
    //     0x12c5580: add             x6, PP, #0x80, lsl #12  ; [pp+0x804d0] Obj!CharacterType@12c7061
    //     0x12c5584: ldr             x6, [x6, #0x4d0]
    // 0x12c5588: mov             x7, x6
    // 0x12c558c: ldur            x6, [fp, #-0x20]
    // 0x12c5590: cmp             x4, x6
    // 0x12c5594: b.ne            #0x12c55a0
    // 0x12c5598: ldur            x8, [fp, #-0x30]
    // 0x12c559c: b               #0x12c5604
    // 0x12c55a0: LoadField: r8 = r5->field_b
    //     0x12c55a0: ldur            w8, [x5, #0xb]
    // 0x12c55a4: r0 = LoadInt32Instr(r8)
    //     0x12c55a4: sbfx            x0, x8, #1, #0x1f
    // 0x12c55a8: mov             x1, x4
    // 0x12c55ac: cmp             x1, x0
    // 0x12c55b0: b.hs            #0x12c5718
    // 0x12c55b4: LoadField: r8 = r5->field_f
    //     0x12c55b4: ldur            w8, [x5, #0xf]
    // 0x12c55b8: DecompressPointer r8
    //     0x12c55b8: add             x8, x8, HEAP, lsl #32
    // 0x12c55bc: ArrayLoad: r10 = r8[r4]  ; Unknown_4
    //     0x12c55bc: add             x16, x8, x4, lsl #2
    //     0x12c55c0: ldur            w10, [x16, #0xf]
    // 0x12c55c4: DecompressPointer r10
    //     0x12c55c4: add             x10, x10, HEAP, lsl #32
    // 0x12c55c8: LoadField: r8 = r10->field_f
    //     0x12c55c8: ldur            w8, [x10, #0xf]
    // 0x12c55cc: DecompressPointer r8
    //     0x12c55cc: add             x8, x8, HEAP, lsl #32
    // 0x12c55d0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12c55d4: cmp             w8, w16
    // 0x12c55d8: b.eq            #0x12c571c
    // 0x12c55dc: r16 = Instance_CharacterType
    //     0x12c55dc: add             x16, PP, #0x80, lsl #12  ; [pp+0x80530] Obj!CharacterType@12c6f61
    //     0x12c55e0: ldr             x16, [x16, #0x530]
    // 0x12c55e4: cmp             w8, w16
    // 0x12c55e8: b.eq            #0x12c55fc
    // 0x12c55ec: r16 = Instance_CharacterType
    //     0x12c55ec: add             x16, PP, #0x80, lsl #12  ; [pp+0x80538] Obj!CharacterType@12c6f41
    //     0x12c55f0: ldr             x16, [x16, #0x538]
    // 0x12c55f4: cmp             w8, w16
    // 0x12c55f8: b.ne            #0x12c5604
    // 0x12c55fc: r8 = Instance_CharacterType
    //     0x12c55fc: add             x8, PP, #0x80, lsl #12  ; [pp+0x804d0] Obj!CharacterType@12c7061
    //     0x12c5600: ldr             x8, [x8, #0x4d0]
    // 0x12c5604: cmp             w7, w8
    // 0x12c5608: b.ne            #0x12c5618
    // 0x12c560c: mov             x8, x7
    // 0x12c5610: ldur            x7, [fp, #-0x38]
    // 0x12c5614: b               #0x12c5634
    // 0x12c5618: ldur            x7, [fp, #-0x38]
    // 0x12c561c: tbnz            w7, #0, #0x12c562c
    // 0x12c5620: r8 = Instance_CharacterType
    //     0x12c5620: add             x8, PP, #0x80, lsl #12  ; [pp+0x804b8] Obj!CharacterType@12c6ee1
    //     0x12c5624: ldr             x8, [x8, #0x4b8]
    // 0x12c5628: b               #0x12c5634
    // 0x12c562c: r8 = Instance_CharacterType
    //     0x12c562c: add             x8, PP, #0x80, lsl #12  ; [pp+0x804d0] Obj!CharacterType@12c7061
    //     0x12c5630: ldr             x8, [x8, #0x4d0]
    // 0x12c5634: LoadField: r9 = r5->field_b
    //     0x12c5634: ldur            w9, [x5, #0xb]
    // 0x12c5638: r10 = LoadInt32Instr(r9)
    //     0x12c5638: sbfx            x10, x9, #1, #0x1f
    // 0x12c563c: LoadField: r9 = r5->field_f
    //     0x12c563c: ldur            w9, [x5, #0xf]
    // 0x12c5640: DecompressPointer r9
    //     0x12c5640: add             x9, x9, HEAP, lsl #32
    // 0x12c5644: CheckStackOverflow
    //     0x12c5644: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c5648: cmp             SP, x16
    //     0x12c564c: b.ls            #0x12c5728
    // 0x12c5650: cmp             x3, x4
    // 0x12c5654: b.ge            #0x12c56a0
    // 0x12c5658: mov             x0, x10
    // 0x12c565c: mov             x1, x3
    // 0x12c5660: cmp             x1, x0
    // 0x12c5664: b.hs            #0x12c5730
    // 0x12c5668: ArrayLoad: r1 = r9[r3]  ; Unknown_4
    //     0x12c5668: add             x16, x9, x3, lsl #2
    //     0x12c566c: ldur            w1, [x16, #0xf]
    // 0x12c5670: DecompressPointer r1
    //     0x12c5670: add             x1, x1, HEAP, lsl #32
    // 0x12c5674: mov             x0, x8
    // 0x12c5678: StoreField: r1->field_f = r0
    //     0x12c5678: stur            w0, [x1, #0xf]
    //     0x12c567c: ldurb           w16, [x1, #-1]
    //     0x12c5680: ldurb           w17, [x0, #-1]
    //     0x12c5684: and             x16, x17, x16, lsr #2
    //     0x12c5688: tst             x16, HEAP, lsr #32
    //     0x12c568c: b.eq            #0x12c5694
    //     0x12c5690: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x12c5694: add             x0, x3, #1
    // 0x12c5698: mov             x3, x0
    // 0x12c569c: b               #0x12c5644
    // 0x12c56a0: mov             x1, x4
    // 0x12c56a4: b               #0x12c56bc
    // 0x12c56a8: mov             x5, x8
    // 0x12c56ac: mov             x2, x4
    // 0x12c56b0: mov             x6, x3
    // 0x12c56b4: mov             x3, x11
    // 0x12c56b8: mov             x1, x3
    // 0x12c56bc: add             x11, x1, #1
    // 0x12c56c0: mov             x8, x5
    // 0x12c56c4: mov             x4, x2
    // 0x12c56c8: mov             x3, x6
    // 0x12c56cc: ldur            x5, [fp, #-0x28]
    // 0x12c56d0: ldur            x6, [fp, #-0x30]
    // 0x12c56d4: b               #0x12c53ec
    // 0x12c56d8: r0 = Null
    //     0x12c56d8: mov             x0, NULL
    // 0x12c56dc: LeaveFrame
    //     0x12c56dc: mov             SP, fp
    //     0x12c56e0: ldp             fp, lr, [SP], #0x10
    // 0x12c56e4: ret
    //     0x12c56e4: ret             
    // 0x12c56e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c56e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c56ec: b               #0x12c53e8
    // 0x12c56f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c56f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c56f4: b               #0x12c5400
    // 0x12c56f8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c56f8: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c56fc: r9 = type
    //     0x12c56fc: add             x9, PP, #0x80, lsl #12  ; [pp+0x804e0] Field <_CharData@1190396231.type>: late (offset: 0x10)
    //     0x12c5700: ldr             x9, [x9, #0x4e0]
    // 0x12c5704: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12c5704: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12c5708: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c5708: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c570c: r9 = type
    //     0x12c570c: add             x9, PP, #0x80, lsl #12  ; [pp+0x804e0] Field <_CharData@1190396231.type>: late (offset: 0x10)
    //     0x12c5710: ldr             x9, [x9, #0x4e0]
    // 0x12c5714: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12c5714: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12c5718: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c5718: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c571c: r9 = type
    //     0x12c571c: add             x9, PP, #0x80, lsl #12  ; [pp+0x804e0] Field <_CharData@1190396231.type>: late (offset: 0x10)
    //     0x12c5720: ldr             x9, [x9, #0x4e0]
    // 0x12c5724: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12c5724: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12c5728: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c5728: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c572c: b               #0x12c5650
    // 0x12c5730: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c5730: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  static _ _findRunLimit(/* No info */) {
    // ** addr: 0x12c5734, size: 0x10c
    // 0x12c5734: EnterFrame
    //     0x12c5734: stp             fp, lr, [SP, #-0x10]!
    //     0x12c5738: mov             fp, SP
    // 0x12c573c: mov             x0, x2
    // 0x12c5740: mov             x2, x3
    // 0x12c5744: sub             x3, x0, #1
    // 0x12c5748: LoadField: r4 = r1->field_b
    //     0x12c5748: ldur            w4, [x1, #0xb]
    // 0x12c574c: r6 = LoadInt32Instr(r4)
    //     0x12c574c: sbfx            x6, x4, #1, #0x1f
    // 0x12c5750: LoadField: r4 = r1->field_f
    //     0x12c5750: ldur            w4, [x1, #0xf]
    // 0x12c5754: DecompressPointer r4
    //     0x12c5754: add             x4, x4, HEAP, lsl #32
    // 0x12c5758: LoadField: r7 = r5->field_b
    //     0x12c5758: ldur            w7, [x5, #0xb]
    // 0x12c575c: r8 = LoadInt32Instr(r7)
    //     0x12c575c: sbfx            x8, x7, #1, #0x1f
    // 0x12c5760: LoadField: r7 = r5->field_f
    //     0x12c5760: ldur            w7, [x5, #0xf]
    // 0x12c5764: DecompressPointer r7
    //     0x12c5764: add             x7, x7, HEAP, lsl #32
    // 0x12c5768: CheckStackOverflow
    //     0x12c5768: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c576c: cmp             SP, x16
    //     0x12c5770: b.ls            #0x12c5820
    // 0x12c5774: add             x5, x3, #1
    // 0x12c5778: cmp             x5, x2
    // 0x12c577c: b.ge            #0x12c5810
    // 0x12c5780: mov             x0, x6
    // 0x12c5784: mov             x1, x5
    // 0x12c5788: cmp             x1, x0
    // 0x12c578c: b.hs            #0x12c5828
    // 0x12c5790: ArrayLoad: r1 = r4[r5]  ; Unknown_4
    //     0x12c5790: add             x16, x4, x5, lsl #2
    //     0x12c5794: ldur            w1, [x16, #0xf]
    // 0x12c5798: DecompressPointer r1
    //     0x12c5798: add             x1, x1, HEAP, lsl #32
    // 0x12c579c: LoadField: r3 = r1->field_f
    //     0x12c579c: ldur            w3, [x1, #0xf]
    // 0x12c57a0: DecompressPointer r3
    //     0x12c57a0: add             x3, x3, HEAP, lsl #32
    // 0x12c57a4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12c57a8: cmp             w3, w16
    // 0x12c57ac: b.eq            #0x12c582c
    // 0x12c57b0: r9 = false
    //     0x12c57b0: add             x9, NULL, #0x30  ; false
    // 0x12c57b4: r1 = 0
    //     0x12c57b4: mov             x1, #0
    // 0x12c57b8: CheckStackOverflow
    //     0x12c57b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c57bc: cmp             SP, x16
    //     0x12c57c0: b.ls            #0x12c5838
    // 0x12c57c4: cmp             x1, x8
    // 0x12c57c8: b.ge            #0x12c57f4
    // 0x12c57cc: tbz             w9, #4, #0x12c57f4
    // 0x12c57d0: ArrayLoad: r10 = r7[r1]  ; Unknown_4
    //     0x12c57d0: add             x16, x7, x1, lsl #2
    //     0x12c57d4: ldur            w10, [x16, #0xf]
    // 0x12c57d8: DecompressPointer r10
    //     0x12c57d8: add             x10, x10, HEAP, lsl #32
    // 0x12c57dc: cmp             w3, w10
    // 0x12c57e0: b.ne            #0x12c57e8
    // 0x12c57e4: r9 = true
    //     0x12c57e4: add             x9, NULL, #0x20  ; true
    // 0x12c57e8: add             x0, x1, #1
    // 0x12c57ec: mov             x1, x0
    // 0x12c57f0: b               #0x12c57b8
    // 0x12c57f4: tbnz            w9, #4, #0x12c5800
    // 0x12c57f8: mov             x3, x5
    // 0x12c57fc: b               #0x12c5768
    // 0x12c5800: mov             x0, x5
    // 0x12c5804: LeaveFrame
    //     0x12c5804: mov             SP, fp
    //     0x12c5808: ldp             fp, lr, [SP], #0x10
    // 0x12c580c: ret
    //     0x12c580c: ret             
    // 0x12c5810: mov             x0, x2
    // 0x12c5814: LeaveFrame
    //     0x12c5814: mov             SP, fp
    //     0x12c5818: ldp             fp, lr, [SP], #0x10
    // 0x12c581c: ret
    //     0x12c581c: ret             
    // 0x12c5820: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c5820: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c5824: b               #0x12c5774
    // 0x12c5828: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c5828: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c582c: r9 = type
    //     0x12c582c: add             x9, PP, #0x80, lsl #12  ; [pp+0x804e0] Field <_CharData@1190396231.type>: late (offset: 0x10)
    //     0x12c5830: ldr             x9, [x9, #0x4e0]
    // 0x12c5834: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12c5834: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12c5838: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c5838: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c583c: b               #0x12c57c4
  }
  static _ _resolveWeakTypes(/* No info */) {
    // ** addr: 0x12c5840, size: 0x894
    // 0x12c5840: EnterFrame
    //     0x12c5840: stp             fp, lr, [SP, #-0x10]!
    //     0x12c5844: mov             fp, SP
    // 0x12c5848: AllocStack(0x38)
    //     0x12c5848: sub             SP, SP, #0x38
    // 0x12c584c: SetupParameters(dynamic _ /* r1 => r8, fp-0x10 */, dynamic _ /* r2 => r4, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */, dynamic _ /* r5 => r5, fp-0x28 */, dynamic _ /* r6 => r6, fp-0x30 */)
    //     0x12c584c: mov             x8, x1
    //     0x12c5850: mov             x4, x2
    //     0x12c5854: stur            x1, [fp, #-0x10]
    //     0x12c5858: stur            x2, [fp, #-0x18]
    //     0x12c585c: stur            x3, [fp, #-0x20]
    //     0x12c5860: stur            x5, [fp, #-0x28]
    //     0x12c5864: stur            x6, [fp, #-0x30]
    // 0x12c5868: CheckStackOverflow
    //     0x12c5868: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c586c: cmp             SP, x16
    //     0x12c5870: b.ls            #0x12c5fd8
    // 0x12c5874: ldr             x0, [fp, #0x10]
    // 0x12c5878: tbnz            w0, #4, #0x12c591c
    // 0x12c587c: LoadField: r0 = r8->field_b
    //     0x12c587c: ldur            w0, [x8, #0xb]
    // 0x12c5880: r2 = LoadInt32Instr(r0)
    //     0x12c5880: sbfx            x2, x0, #1, #0x1f
    // 0x12c5884: LoadField: r10 = r8->field_f
    //     0x12c5884: ldur            w10, [x8, #0xf]
    // 0x12c5888: DecompressPointer r10
    //     0x12c5888: add             x10, x10, HEAP, lsl #32
    // 0x12c588c: mov             x12, x5
    // 0x12c5890: mov             x11, x4
    // 0x12c5894: CheckStackOverflow
    //     0x12c5894: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c5898: cmp             SP, x16
    //     0x12c589c: b.ls            #0x12c5fe0
    // 0x12c58a0: cmp             x11, x3
    // 0x12c58a4: b.ge            #0x12c591c
    // 0x12c58a8: mov             x0, x2
    // 0x12c58ac: mov             x1, x11
    // 0x12c58b0: cmp             x1, x0
    // 0x12c58b4: b.hs            #0x12c5fe8
    // 0x12c58b8: ArrayLoad: r1 = r10[r11]  ; Unknown_4
    //     0x12c58b8: add             x16, x10, x11, lsl #2
    //     0x12c58bc: ldur            w1, [x16, #0xf]
    // 0x12c58c0: DecompressPointer r1
    //     0x12c58c0: add             x1, x1, HEAP, lsl #32
    // 0x12c58c4: LoadField: r0 = r1->field_f
    //     0x12c58c4: ldur            w0, [x1, #0xf]
    // 0x12c58c8: DecompressPointer r0
    //     0x12c58c8: add             x0, x0, HEAP, lsl #32
    // 0x12c58cc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12c58d0: cmp             w0, w16
    // 0x12c58d4: b.eq            #0x12c5fec
    // 0x12c58d8: r16 = Instance_CharacterType
    //     0x12c58d8: add             x16, PP, #0x80, lsl #12  ; [pp+0x80550] Obj!CharacterType@12c7021
    //     0x12c58dc: ldr             x16, [x16, #0x550]
    // 0x12c58e0: cmp             w0, w16
    // 0x12c58e4: b.ne            #0x12c590c
    // 0x12c58e8: mov             x0, x12
    // 0x12c58ec: StoreField: r1->field_f = r0
    //     0x12c58ec: stur            w0, [x1, #0xf]
    //     0x12c58f0: ldurb           w16, [x1, #-1]
    //     0x12c58f4: ldurb           w17, [x0, #-1]
    //     0x12c58f8: and             x16, x17, x16, lsr #2
    //     0x12c58fc: tst             x16, HEAP, lsr #32
    //     0x12c5900: b.eq            #0x12c5908
    //     0x12c5904: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x12c5908: b               #0x12c5910
    // 0x12c590c: mov             x12, x0
    // 0x12c5910: add             x0, x11, #1
    // 0x12c5914: mov             x11, x0
    // 0x12c5918: b               #0x12c5894
    // 0x12c591c: LoadField: r2 = r8->field_b
    //     0x12c591c: ldur            w2, [x8, #0xb]
    // 0x12c5920: r10 = LoadInt32Instr(r2)
    //     0x12c5920: sbfx            x10, x2, #1, #0x1f
    // 0x12c5924: LoadField: r11 = r8->field_f
    //     0x12c5924: ldur            w11, [x8, #0xf]
    // 0x12c5928: DecompressPointer r11
    //     0x12c5928: add             x11, x11, HEAP, lsl #32
    // 0x12c592c: mov             x12, x4
    // 0x12c5930: r13 = Instance_CharacterType
    //     0x12c5930: add             x13, PP, #0x80, lsl #12  ; [pp+0x80538] Obj!CharacterType@12c6f41
    //     0x12c5934: ldr             x13, [x13, #0x538]
    // 0x12c5938: CheckStackOverflow
    //     0x12c5938: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c593c: cmp             SP, x16
    //     0x12c5940: b.ls            #0x12c5ff8
    // 0x12c5944: cmp             x12, x3
    // 0x12c5948: b.ge            #0x12c5a08
    // 0x12c594c: mov             x0, x10
    // 0x12c5950: mov             x1, x12
    // 0x12c5954: cmp             x1, x0
    // 0x12c5958: b.hs            #0x12c6000
    // 0x12c595c: ArrayLoad: r1 = r11[r12]  ; Unknown_4
    //     0x12c595c: add             x16, x11, x12, lsl #2
    //     0x12c5960: ldur            w1, [x16, #0xf]
    // 0x12c5964: DecompressPointer r1
    //     0x12c5964: add             x1, x1, HEAP, lsl #32
    // 0x12c5968: LoadField: r0 = r1->field_f
    //     0x12c5968: ldur            w0, [x1, #0xf]
    // 0x12c596c: DecompressPointer r0
    //     0x12c596c: add             x0, x0, HEAP, lsl #32
    // 0x12c5970: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12c5974: cmp             w0, w16
    // 0x12c5978: b.eq            #0x12c6004
    // 0x12c597c: r16 = Instance_CharacterType
    //     0x12c597c: add             x16, PP, #0x80, lsl #12  ; [pp+0x804b8] Obj!CharacterType@12c6ee1
    //     0x12c5980: ldr             x16, [x16, #0x4b8]
    // 0x12c5984: cmp             w0, w16
    // 0x12c5988: b.eq            #0x12c599c
    // 0x12c598c: r16 = Instance_CharacterType
    //     0x12c598c: add             x16, PP, #0x80, lsl #12  ; [pp+0x804d0] Obj!CharacterType@12c7061
    //     0x12c5990: ldr             x16, [x16, #0x4d0]
    // 0x12c5994: cmp             w0, w16
    // 0x12c5998: b.ne            #0x12c59a8
    // 0x12c599c: r13 = Instance_CharacterType
    //     0x12c599c: add             x13, PP, #0x80, lsl #12  ; [pp+0x80538] Obj!CharacterType@12c6f41
    //     0x12c59a0: ldr             x13, [x13, #0x538]
    // 0x12c59a4: b               #0x12c59fc
    // 0x12c59a8: r16 = Instance_CharacterType
    //     0x12c59a8: add             x16, PP, #0x80, lsl #12  ; [pp+0x80558] Obj!CharacterType@12c7001
    //     0x12c59ac: ldr             x16, [x16, #0x558]
    // 0x12c59b0: cmp             w0, w16
    // 0x12c59b4: b.ne            #0x12c59c4
    // 0x12c59b8: r0 = Instance_CharacterType
    //     0x12c59b8: add             x0, PP, #0x80, lsl #12  ; [pp+0x80530] Obj!CharacterType@12c6f61
    //     0x12c59bc: ldr             x0, [x0, #0x530]
    // 0x12c59c0: b               #0x12c59f8
    // 0x12c59c4: r16 = Instance_CharacterType
    //     0x12c59c4: add             x16, PP, #0x80, lsl #12  ; [pp+0x80538] Obj!CharacterType@12c6f41
    //     0x12c59c8: ldr             x16, [x16, #0x538]
    // 0x12c59cc: cmp             w0, w16
    // 0x12c59d0: b.ne            #0x12c59f4
    // 0x12c59d4: mov             x0, x13
    // 0x12c59d8: StoreField: r1->field_f = r0
    //     0x12c59d8: stur            w0, [x1, #0xf]
    //     0x12c59dc: ldurb           w16, [x1, #-1]
    //     0x12c59e0: ldurb           w17, [x0, #-1]
    //     0x12c59e4: and             x16, x17, x16, lsr #2
    //     0x12c59e8: tst             x16, HEAP, lsr #32
    //     0x12c59ec: b.eq            #0x12c59f4
    //     0x12c59f0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x12c59f4: mov             x0, x13
    // 0x12c59f8: mov             x13, x0
    // 0x12c59fc: add             x0, x12, #1
    // 0x12c5a00: mov             x12, x0
    // 0x12c5a04: b               #0x12c5938
    // 0x12c5a08: tbnz            w7, #4, #0x12c5a80
    // 0x12c5a0c: r7 = LoadInt32Instr(r2)
    //     0x12c5a0c: sbfx            x7, x2, #1, #0x1f
    // 0x12c5a10: mov             x12, x4
    // 0x12c5a14: r10 = Instance_CharacterType
    //     0x12c5a14: add             x10, PP, #0x80, lsl #12  ; [pp+0x804d0] Obj!CharacterType@12c7061
    //     0x12c5a18: ldr             x10, [x10, #0x4d0]
    // 0x12c5a1c: CheckStackOverflow
    //     0x12c5a1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c5a20: cmp             SP, x16
    //     0x12c5a24: b.ls            #0x12c6010
    // 0x12c5a28: cmp             x12, x3
    // 0x12c5a2c: b.ge            #0x12c5a80
    // 0x12c5a30: mov             x0, x7
    // 0x12c5a34: mov             x1, x12
    // 0x12c5a38: cmp             x1, x0
    // 0x12c5a3c: b.hs            #0x12c6018
    // 0x12c5a40: ArrayLoad: r0 = r11[r12]  ; Unknown_4
    //     0x12c5a40: add             x16, x11, x12, lsl #2
    //     0x12c5a44: ldur            w0, [x16, #0xf]
    // 0x12c5a48: DecompressPointer r0
    //     0x12c5a48: add             x0, x0, HEAP, lsl #32
    // 0x12c5a4c: LoadField: r1 = r0->field_f
    //     0x12c5a4c: ldur            w1, [x0, #0xf]
    // 0x12c5a50: DecompressPointer r1
    //     0x12c5a50: add             x1, x1, HEAP, lsl #32
    // 0x12c5a54: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12c5a58: cmp             w1, w16
    // 0x12c5a5c: b.eq            #0x12c601c
    // 0x12c5a60: r16 = Instance_CharacterType
    //     0x12c5a60: add             x16, PP, #0x80, lsl #12  ; [pp+0x80558] Obj!CharacterType@12c7001
    //     0x12c5a64: ldr             x16, [x16, #0x558]
    // 0x12c5a68: cmp             w1, w16
    // 0x12c5a6c: b.ne            #0x12c5a74
    // 0x12c5a70: StoreField: r0->field_f = r10
    //     0x12c5a70: stur            w10, [x0, #0xf]
    // 0x12c5a74: add             x0, x12, #1
    // 0x12c5a78: mov             x12, x0
    // 0x12c5a7c: b               #0x12c5a1c
    // 0x12c5a80: add             x0, x4, #1
    // 0x12c5a84: sub             x7, x3, #1
    // 0x12c5a88: r10 = LoadInt32Instr(r2)
    //     0x12c5a88: sbfx            x10, x2, #1, #0x1f
    // 0x12c5a8c: mov             x13, x0
    // 0x12c5a90: r12 = Instance_CharacterType
    //     0x12c5a90: add             x12, PP, #0x80, lsl #12  ; [pp+0x80538] Obj!CharacterType@12c6f41
    //     0x12c5a94: ldr             x12, [x12, #0x538]
    // 0x12c5a98: r2 = Instance_CharacterType
    //     0x12c5a98: add             x2, PP, #0x80, lsl #12  ; [pp+0x80530] Obj!CharacterType@12c6f61
    //     0x12c5a9c: ldr             x2, [x2, #0x530]
    // 0x12c5aa0: CheckStackOverflow
    //     0x12c5aa0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c5aa4: cmp             SP, x16
    //     0x12c5aa8: b.ls            #0x12c6028
    // 0x12c5aac: cmp             x13, x7
    // 0x12c5ab0: b.ge            #0x12c5bd4
    // 0x12c5ab4: mov             x0, x10
    // 0x12c5ab8: mov             x1, x13
    // 0x12c5abc: cmp             x1, x0
    // 0x12c5ac0: b.hs            #0x12c6030
    // 0x12c5ac4: ArrayLoad: r14 = r11[r13]  ; Unknown_4
    //     0x12c5ac4: add             x16, x11, x13, lsl #2
    //     0x12c5ac8: ldur            w14, [x16, #0xf]
    // 0x12c5acc: DecompressPointer r14
    //     0x12c5acc: add             x14, x14, HEAP, lsl #32
    // 0x12c5ad0: LoadField: r19 = r14->field_f
    //     0x12c5ad0: ldur            w19, [x14, #0xf]
    // 0x12c5ad4: DecompressPointer r19
    //     0x12c5ad4: add             x19, x19, HEAP, lsl #32
    // 0x12c5ad8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12c5adc: cmp             w19, w16
    // 0x12c5ae0: b.eq            #0x12c6034
    // 0x12c5ae4: r16 = Instance_CharacterType
    //     0x12c5ae4: add             x16, PP, #0x80, lsl #12  ; [pp+0x80560] Obj!CharacterType@12c6fe1
    //     0x12c5ae8: ldr             x16, [x16, #0x560]
    // 0x12c5aec: cmp             w19, w16
    // 0x12c5af0: b.eq            #0x12c5b04
    // 0x12c5af4: r16 = Instance_CharacterType
    //     0x12c5af4: add             x16, PP, #0x80, lsl #12  ; [pp+0x80568] Obj!CharacterType@12c6fc1
    //     0x12c5af8: ldr             x16, [x16, #0x568]
    // 0x12c5afc: cmp             w19, w16
    // 0x12c5b00: b.ne            #0x12c5bc8
    // 0x12c5b04: sub             x9, x13, #1
    // 0x12c5b08: mov             x0, x10
    // 0x12c5b0c: mov             x1, x9
    // 0x12c5b10: cmp             x1, x0
    // 0x12c5b14: b.hs            #0x12c6040
    // 0x12c5b18: ArrayLoad: r0 = r11[r9]  ; Unknown_4
    //     0x12c5b18: add             x16, x11, x9, lsl #2
    //     0x12c5b1c: ldur            w0, [x16, #0xf]
    // 0x12c5b20: DecompressPointer r0
    //     0x12c5b20: add             x0, x0, HEAP, lsl #32
    // 0x12c5b24: LoadField: r20 = r0->field_f
    //     0x12c5b24: ldur            w20, [x0, #0xf]
    // 0x12c5b28: DecompressPointer r20
    //     0x12c5b28: add             x20, x20, HEAP, lsl #32
    // 0x12c5b2c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12c5b30: cmp             w20, w16
    // 0x12c5b34: b.eq            #0x12c6044
    // 0x12c5b38: add             x9, x13, #1
    // 0x12c5b3c: mov             x0, x10
    // 0x12c5b40: mov             x1, x9
    // 0x12c5b44: cmp             x1, x0
    // 0x12c5b48: b.hs            #0x12c6050
    // 0x12c5b4c: ArrayLoad: r0 = r11[r9]  ; Unknown_4
    //     0x12c5b4c: add             x16, x11, x9, lsl #2
    //     0x12c5b50: ldur            w0, [x16, #0xf]
    // 0x12c5b54: DecompressPointer r0
    //     0x12c5b54: add             x0, x0, HEAP, lsl #32
    // 0x12c5b58: LoadField: r1 = r0->field_f
    //     0x12c5b58: ldur            w1, [x0, #0xf]
    // 0x12c5b5c: DecompressPointer r1
    //     0x12c5b5c: add             x1, x1, HEAP, lsl #32
    // 0x12c5b60: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12c5b64: cmp             w1, w16
    // 0x12c5b68: b.eq            #0x12c6054
    // 0x12c5b6c: r16 = Instance_CharacterType
    //     0x12c5b6c: add             x16, PP, #0x80, lsl #12  ; [pp+0x80538] Obj!CharacterType@12c6f41
    //     0x12c5b70: ldr             x16, [x16, #0x538]
    // 0x12c5b74: cmp             w20, w16
    // 0x12c5b78: b.ne            #0x12c5b94
    // 0x12c5b7c: r16 = Instance_CharacterType
    //     0x12c5b7c: add             x16, PP, #0x80, lsl #12  ; [pp+0x80538] Obj!CharacterType@12c6f41
    //     0x12c5b80: ldr             x16, [x16, #0x538]
    // 0x12c5b84: cmp             w1, w16
    // 0x12c5b88: b.ne            #0x12c5b94
    // 0x12c5b8c: StoreField: r14->field_f = r12
    //     0x12c5b8c: stur            w12, [x14, #0xf]
    // 0x12c5b90: b               #0x12c5bc8
    // 0x12c5b94: r16 = Instance_CharacterType
    //     0x12c5b94: add             x16, PP, #0x80, lsl #12  ; [pp+0x80568] Obj!CharacterType@12c6fc1
    //     0x12c5b98: ldr             x16, [x16, #0x568]
    // 0x12c5b9c: cmp             w19, w16
    // 0x12c5ba0: b.ne            #0x12c5bc8
    // 0x12c5ba4: r16 = Instance_CharacterType
    //     0x12c5ba4: add             x16, PP, #0x80, lsl #12  ; [pp+0x80530] Obj!CharacterType@12c6f61
    //     0x12c5ba8: ldr             x16, [x16, #0x530]
    // 0x12c5bac: cmp             w20, w16
    // 0x12c5bb0: b.ne            #0x12c5bc8
    // 0x12c5bb4: r16 = Instance_CharacterType
    //     0x12c5bb4: add             x16, PP, #0x80, lsl #12  ; [pp+0x80530] Obj!CharacterType@12c6f61
    //     0x12c5bb8: ldr             x16, [x16, #0x530]
    // 0x12c5bbc: cmp             w1, w16
    // 0x12c5bc0: b.ne            #0x12c5bc8
    // 0x12c5bc4: StoreField: r14->field_f = r2
    //     0x12c5bc4: stur            w2, [x14, #0xf]
    // 0x12c5bc8: add             x0, x13, #1
    // 0x12c5bcc: mov             x13, x0
    // 0x12c5bd0: b               #0x12c5aa0
    // 0x12c5bd4: mov             x10, x4
    // 0x12c5bd8: r7 = 2
    //     0x12c5bd8: mov             x7, #2
    // 0x12c5bdc: stur            x10, [fp, #-8]
    // 0x12c5be0: CheckStackOverflow
    //     0x12c5be0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c5be4: cmp             SP, x16
    //     0x12c5be8: b.ls            #0x12c6060
    // 0x12c5bec: cmp             x10, x3
    // 0x12c5bf0: b.ge            #0x12c5e2c
    // 0x12c5bf4: LoadField: r0 = r8->field_b
    //     0x12c5bf4: ldur            w0, [x8, #0xb]
    // 0x12c5bf8: r1 = LoadInt32Instr(r0)
    //     0x12c5bf8: sbfx            x1, x0, #1, #0x1f
    // 0x12c5bfc: mov             x0, x1
    // 0x12c5c00: mov             x1, x10
    // 0x12c5c04: cmp             x1, x0
    // 0x12c5c08: b.hs            #0x12c6068
    // 0x12c5c0c: LoadField: r0 = r8->field_f
    //     0x12c5c0c: ldur            w0, [x8, #0xf]
    // 0x12c5c10: DecompressPointer r0
    //     0x12c5c10: add             x0, x0, HEAP, lsl #32
    // 0x12c5c14: ArrayLoad: r1 = r0[r10]  ; Unknown_4
    //     0x12c5c14: add             x16, x0, x10, lsl #2
    //     0x12c5c18: ldur            w1, [x16, #0xf]
    // 0x12c5c1c: DecompressPointer r1
    //     0x12c5c1c: add             x1, x1, HEAP, lsl #32
    // 0x12c5c20: LoadField: r0 = r1->field_f
    //     0x12c5c20: ldur            w0, [x1, #0xf]
    // 0x12c5c24: DecompressPointer r0
    //     0x12c5c24: add             x0, x0, HEAP, lsl #32
    // 0x12c5c28: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12c5c2c: cmp             w0, w16
    // 0x12c5c30: b.eq            #0x12c606c
    // 0x12c5c34: r16 = Instance_CharacterType
    //     0x12c5c34: add             x16, PP, #0x80, lsl #12  ; [pp+0x80570] Obj!CharacterType@12c6fa1
    //     0x12c5c38: ldr             x16, [x16, #0x570]
    // 0x12c5c3c: cmp             w0, w16
    // 0x12c5c40: b.ne            #0x12c5df0
    // 0x12c5c44: mov             x2, x7
    // 0x12c5c48: r1 = Null
    //     0x12c5c48: mov             x1, NULL
    // 0x12c5c4c: r0 = AllocateArray()
    //     0x12c5c4c: bl              #0x13df928  ; AllocateArrayStub
    // 0x12c5c50: stur            x0, [fp, #-0x38]
    // 0x12c5c54: r16 = Instance_CharacterType
    //     0x12c5c54: add             x16, PP, #0x80, lsl #12  ; [pp+0x80570] Obj!CharacterType@12c6fa1
    //     0x12c5c58: ldr             x16, [x16, #0x570]
    // 0x12c5c5c: StoreField: r0->field_f = r16
    //     0x12c5c5c: stur            w16, [x0, #0xf]
    // 0x12c5c60: r1 = <CharacterType>
    //     0x12c5c60: add             x1, PP, #0x80, lsl #12  ; [pp+0x80548] TypeArguments: <CharacterType>
    //     0x12c5c64: ldr             x1, [x1, #0x548]
    // 0x12c5c68: r0 = AllocateGrowableArray()
    //     0x12c5c68: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x12c5c6c: mov             x1, x0
    // 0x12c5c70: ldur            x0, [fp, #-0x38]
    // 0x12c5c74: StoreField: r1->field_f = r0
    //     0x12c5c74: stur            w0, [x1, #0xf]
    // 0x12c5c78: r0 = 2
    //     0x12c5c78: mov             x0, #2
    // 0x12c5c7c: StoreField: r1->field_b = r0
    //     0x12c5c7c: stur            w0, [x1, #0xb]
    // 0x12c5c80: mov             x5, x1
    // 0x12c5c84: ldur            x1, [fp, #-0x10]
    // 0x12c5c88: ldur            x2, [fp, #-8]
    // 0x12c5c8c: ldur            x3, [fp, #-0x20]
    // 0x12c5c90: r0 = _findRunLimit()
    //     0x12c5c90: bl              #0x12c5734  ; [package:bidi/bidi.dart] ::_findRunLimit
    // 0x12c5c94: mov             x4, x0
    // 0x12c5c98: ldur            x2, [fp, #-0x18]
    // 0x12c5c9c: ldur            x3, [fp, #-8]
    // 0x12c5ca0: cmp             x3, x2
    // 0x12c5ca4: b.ne            #0x12c5cb4
    // 0x12c5ca8: ldur            x6, [fp, #-0x28]
    // 0x12c5cac: ldur            x5, [fp, #-0x10]
    // 0x12c5cb0: b               #0x12c5cf8
    // 0x12c5cb4: ldur            x5, [fp, #-0x10]
    // 0x12c5cb8: sub             x6, x3, #1
    // 0x12c5cbc: LoadField: r7 = r5->field_b
    //     0x12c5cbc: ldur            w7, [x5, #0xb]
    // 0x12c5cc0: r0 = LoadInt32Instr(r7)
    //     0x12c5cc0: sbfx            x0, x7, #1, #0x1f
    // 0x12c5cc4: mov             x1, x6
    // 0x12c5cc8: cmp             x1, x0
    // 0x12c5ccc: b.hs            #0x12c6078
    // 0x12c5cd0: LoadField: r7 = r5->field_f
    //     0x12c5cd0: ldur            w7, [x5, #0xf]
    // 0x12c5cd4: DecompressPointer r7
    //     0x12c5cd4: add             x7, x7, HEAP, lsl #32
    // 0x12c5cd8: ArrayLoad: r8 = r7[r6]  ; Unknown_4
    //     0x12c5cd8: add             x16, x7, x6, lsl #2
    //     0x12c5cdc: ldur            w8, [x16, #0xf]
    // 0x12c5ce0: DecompressPointer r8
    //     0x12c5ce0: add             x8, x8, HEAP, lsl #32
    // 0x12c5ce4: LoadField: r6 = r8->field_f
    //     0x12c5ce4: ldur            w6, [x8, #0xf]
    // 0x12c5ce8: DecompressPointer r6
    //     0x12c5ce8: add             x6, x6, HEAP, lsl #32
    // 0x12c5cec: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12c5cf0: cmp             w6, w16
    // 0x12c5cf4: b.eq            #0x12c607c
    // 0x12c5cf8: r16 = Instance_CharacterType
    //     0x12c5cf8: add             x16, PP, #0x80, lsl #12  ; [pp+0x80538] Obj!CharacterType@12c6f41
    //     0x12c5cfc: ldr             x16, [x16, #0x538]
    // 0x12c5d00: cmp             w6, w16
    // 0x12c5d04: b.eq            #0x12c5d88
    // 0x12c5d08: ldur            x6, [fp, #-0x20]
    // 0x12c5d0c: cmp             x4, x6
    // 0x12c5d10: b.ne            #0x12c5d2c
    // 0x12c5d14: ldur            x7, [fp, #-0x30]
    // 0x12c5d18: r16 = Instance_CharacterType
    //     0x12c5d18: add             x16, PP, #0x80, lsl #12  ; [pp+0x80538] Obj!CharacterType@12c6f41
    //     0x12c5d1c: ldr             x16, [x16, #0x538]
    // 0x12c5d20: cmp             w7, w16
    // 0x12c5d24: b.ne            #0x12c5d7c
    // 0x12c5d28: b               #0x12c5d90
    // 0x12c5d2c: ldur            x7, [fp, #-0x30]
    // 0x12c5d30: LoadField: r8 = r5->field_b
    //     0x12c5d30: ldur            w8, [x5, #0xb]
    // 0x12c5d34: r0 = LoadInt32Instr(r8)
    //     0x12c5d34: sbfx            x0, x8, #1, #0x1f
    // 0x12c5d38: mov             x1, x4
    // 0x12c5d3c: cmp             x1, x0
    // 0x12c5d40: b.hs            #0x12c6088
    // 0x12c5d44: LoadField: r8 = r5->field_f
    //     0x12c5d44: ldur            w8, [x5, #0xf]
    // 0x12c5d48: DecompressPointer r8
    //     0x12c5d48: add             x8, x8, HEAP, lsl #32
    // 0x12c5d4c: ArrayLoad: r10 = r8[r4]  ; Unknown_4
    //     0x12c5d4c: add             x16, x8, x4, lsl #2
    //     0x12c5d50: ldur            w10, [x16, #0xf]
    // 0x12c5d54: DecompressPointer r10
    //     0x12c5d54: add             x10, x10, HEAP, lsl #32
    // 0x12c5d58: LoadField: r8 = r10->field_f
    //     0x12c5d58: ldur            w8, [x10, #0xf]
    // 0x12c5d5c: DecompressPointer r8
    //     0x12c5d5c: add             x8, x8, HEAP, lsl #32
    // 0x12c5d60: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12c5d64: cmp             w8, w16
    // 0x12c5d68: b.eq            #0x12c608c
    // 0x12c5d6c: r16 = Instance_CharacterType
    //     0x12c5d6c: add             x16, PP, #0x80, lsl #12  ; [pp+0x80538] Obj!CharacterType@12c6f41
    //     0x12c5d70: ldr             x16, [x16, #0x538]
    // 0x12c5d74: cmp             w8, w16
    // 0x12c5d78: b.eq            #0x12c5d90
    // 0x12c5d7c: r10 = Instance_CharacterType
    //     0x12c5d7c: add             x10, PP, #0x80, lsl #12  ; [pp+0x80538] Obj!CharacterType@12c6f41
    //     0x12c5d80: ldr             x10, [x10, #0x538]
    // 0x12c5d84: b               #0x12c5de8
    // 0x12c5d88: ldur            x6, [fp, #-0x20]
    // 0x12c5d8c: ldur            x7, [fp, #-0x30]
    // 0x12c5d90: LoadField: r8 = r5->field_b
    //     0x12c5d90: ldur            w8, [x5, #0xb]
    // 0x12c5d94: r9 = LoadInt32Instr(r8)
    //     0x12c5d94: sbfx            x9, x8, #1, #0x1f
    // 0x12c5d98: LoadField: r8 = r5->field_f
    //     0x12c5d98: ldur            w8, [x5, #0xf]
    // 0x12c5d9c: DecompressPointer r8
    //     0x12c5d9c: add             x8, x8, HEAP, lsl #32
    // 0x12c5da0: r10 = Instance_CharacterType
    //     0x12c5da0: add             x10, PP, #0x80, lsl #12  ; [pp+0x80538] Obj!CharacterType@12c6f41
    //     0x12c5da4: ldr             x10, [x10, #0x538]
    // 0x12c5da8: CheckStackOverflow
    //     0x12c5da8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c5dac: cmp             SP, x16
    //     0x12c5db0: b.ls            #0x12c6098
    // 0x12c5db4: cmp             x3, x4
    // 0x12c5db8: b.ge            #0x12c5de8
    // 0x12c5dbc: mov             x0, x9
    // 0x12c5dc0: mov             x1, x3
    // 0x12c5dc4: cmp             x1, x0
    // 0x12c5dc8: b.hs            #0x12c60a0
    // 0x12c5dcc: ArrayLoad: r11 = r8[r3]  ; Unknown_4
    //     0x12c5dcc: add             x16, x8, x3, lsl #2
    //     0x12c5dd0: ldur            w11, [x16, #0xf]
    // 0x12c5dd4: DecompressPointer r11
    //     0x12c5dd4: add             x11, x11, HEAP, lsl #32
    // 0x12c5dd8: StoreField: r11->field_f = r10
    //     0x12c5dd8: stur            w10, [x11, #0xf]
    // 0x12c5ddc: add             x0, x3, #1
    // 0x12c5de0: mov             x3, x0
    // 0x12c5de4: b               #0x12c5da8
    // 0x12c5de8: mov             x3, x4
    // 0x12c5dec: b               #0x12c5e08
    // 0x12c5df0: mov             x5, x8
    // 0x12c5df4: mov             x2, x4
    // 0x12c5df8: mov             x7, x6
    // 0x12c5dfc: mov             x6, x3
    // 0x12c5e00: mov             x3, x10
    // 0x12c5e04: mov             x10, x12
    // 0x12c5e08: add             x0, x3, #1
    // 0x12c5e0c: mov             x12, x10
    // 0x12c5e10: mov             x10, x0
    // 0x12c5e14: mov             x8, x5
    // 0x12c5e18: mov             x4, x2
    // 0x12c5e1c: mov             x3, x6
    // 0x12c5e20: ldur            x5, [fp, #-0x28]
    // 0x12c5e24: mov             x6, x7
    // 0x12c5e28: b               #0x12c5bd8
    // 0x12c5e2c: mov             x5, x8
    // 0x12c5e30: mov             x2, x4
    // 0x12c5e34: mov             x6, x3
    // 0x12c5e38: LoadField: r3 = r5->field_b
    //     0x12c5e38: ldur            w3, [x5, #0xb]
    // 0x12c5e3c: r4 = LoadInt32Instr(r3)
    //     0x12c5e3c: sbfx            x4, x3, #1, #0x1f
    // 0x12c5e40: LoadField: r7 = r5->field_f
    //     0x12c5e40: ldur            w7, [x5, #0xf]
    // 0x12c5e44: DecompressPointer r7
    //     0x12c5e44: add             x7, x7, HEAP, lsl #32
    // 0x12c5e48: mov             x8, x2
    // 0x12c5e4c: r5 = Instance_CharacterType
    //     0x12c5e4c: add             x5, PP, #0x80, lsl #12  ; [pp+0x80540] Obj!CharacterType@12c6f81
    //     0x12c5e50: ldr             x5, [x5, #0x540]
    // 0x12c5e54: CheckStackOverflow
    //     0x12c5e54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c5e58: cmp             SP, x16
    //     0x12c5e5c: b.ls            #0x12c60a4
    // 0x12c5e60: cmp             x8, x6
    // 0x12c5e64: b.ge            #0x12c5ed8
    // 0x12c5e68: mov             x0, x4
    // 0x12c5e6c: mov             x1, x8
    // 0x12c5e70: cmp             x1, x0
    // 0x12c5e74: b.hs            #0x12c60ac
    // 0x12c5e78: ArrayLoad: r10 = r7[r8]  ; Unknown_4
    //     0x12c5e78: add             x16, x7, x8, lsl #2
    //     0x12c5e7c: ldur            w10, [x16, #0xf]
    // 0x12c5e80: DecompressPointer r10
    //     0x12c5e80: add             x10, x10, HEAP, lsl #32
    // 0x12c5e84: LoadField: r11 = r10->field_f
    //     0x12c5e84: ldur            w11, [x10, #0xf]
    // 0x12c5e88: DecompressPointer r11
    //     0x12c5e88: add             x11, x11, HEAP, lsl #32
    // 0x12c5e8c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12c5e90: cmp             w11, w16
    // 0x12c5e94: b.eq            #0x12c60b0
    // 0x12c5e98: r16 = Instance_CharacterType
    //     0x12c5e98: add             x16, PP, #0x80, lsl #12  ; [pp+0x80560] Obj!CharacterType@12c6fe1
    //     0x12c5e9c: ldr             x16, [x16, #0x560]
    // 0x12c5ea0: cmp             w11, w16
    // 0x12c5ea4: b.eq            #0x12c5ec8
    // 0x12c5ea8: r16 = Instance_CharacterType
    //     0x12c5ea8: add             x16, PP, #0x80, lsl #12  ; [pp+0x80570] Obj!CharacterType@12c6fa1
    //     0x12c5eac: ldr             x16, [x16, #0x570]
    // 0x12c5eb0: cmp             w11, w16
    // 0x12c5eb4: b.eq            #0x12c5ec8
    // 0x12c5eb8: r16 = Instance_CharacterType
    //     0x12c5eb8: add             x16, PP, #0x80, lsl #12  ; [pp+0x80568] Obj!CharacterType@12c6fc1
    //     0x12c5ebc: ldr             x16, [x16, #0x568]
    // 0x12c5ec0: cmp             w11, w16
    // 0x12c5ec4: b.ne            #0x12c5ecc
    // 0x12c5ec8: StoreField: r10->field_f = r5
    //     0x12c5ec8: stur            w5, [x10, #0xf]
    // 0x12c5ecc: add             x0, x8, #1
    // 0x12c5ed0: mov             x8, x0
    // 0x12c5ed4: b               #0x12c5e54
    // 0x12c5ed8: ldur            x4, [fp, #-0x28]
    // 0x12c5edc: r16 = Instance_CharacterType
    //     0x12c5edc: add             x16, PP, #0x80, lsl #12  ; [pp+0x804b8] Obj!CharacterType@12c6ee1
    //     0x12c5ee0: ldr             x16, [x16, #0x4b8]
    // 0x12c5ee4: cmp             w4, w16
    // 0x12c5ee8: b.ne            #0x12c5ef8
    // 0x12c5eec: r4 = Instance_CharacterType
    //     0x12c5eec: add             x4, PP, #0x80, lsl #12  ; [pp+0x804b8] Obj!CharacterType@12c6ee1
    //     0x12c5ef0: ldr             x4, [x4, #0x4b8]
    // 0x12c5ef4: b               #0x12c5f00
    // 0x12c5ef8: r4 = Instance_CharacterType
    //     0x12c5ef8: add             x4, PP, #0x80, lsl #12  ; [pp+0x80538] Obj!CharacterType@12c6f41
    //     0x12c5efc: ldr             x4, [x4, #0x538]
    // 0x12c5f00: r5 = LoadInt32Instr(r3)
    //     0x12c5f00: sbfx            x5, x3, #1, #0x1f
    // 0x12c5f04: mov             x3, x4
    // 0x12c5f08: CheckStackOverflow
    //     0x12c5f08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c5f0c: cmp             SP, x16
    //     0x12c5f10: b.ls            #0x12c60bc
    // 0x12c5f14: cmp             x2, x6
    // 0x12c5f18: b.ge            #0x12c5fc8
    // 0x12c5f1c: mov             x0, x5
    // 0x12c5f20: mov             x1, x2
    // 0x12c5f24: cmp             x1, x0
    // 0x12c5f28: b.hs            #0x12c60c4
    // 0x12c5f2c: ArrayLoad: r1 = r7[r2]  ; Unknown_4
    //     0x12c5f2c: add             x16, x7, x2, lsl #2
    //     0x12c5f30: ldur            w1, [x16, #0xf]
    // 0x12c5f34: DecompressPointer r1
    //     0x12c5f34: add             x1, x1, HEAP, lsl #32
    // 0x12c5f38: LoadField: r4 = r1->field_f
    //     0x12c5f38: ldur            w4, [x1, #0xf]
    // 0x12c5f3c: DecompressPointer r4
    //     0x12c5f3c: add             x4, x4, HEAP, lsl #32
    // 0x12c5f40: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12c5f44: cmp             w4, w16
    // 0x12c5f48: b.eq            #0x12c60c8
    // 0x12c5f4c: r16 = Instance_CharacterType
    //     0x12c5f4c: add             x16, PP, #0x80, lsl #12  ; [pp+0x804d0] Obj!CharacterType@12c7061
    //     0x12c5f50: ldr             x16, [x16, #0x4d0]
    // 0x12c5f54: cmp             w4, w16
    // 0x12c5f58: b.ne            #0x12c5f68
    // 0x12c5f5c: r3 = Instance_CharacterType
    //     0x12c5f5c: add             x3, PP, #0x80, lsl #12  ; [pp+0x80538] Obj!CharacterType@12c6f41
    //     0x12c5f60: ldr             x3, [x3, #0x538]
    // 0x12c5f64: b               #0x12c5fbc
    // 0x12c5f68: r16 = Instance_CharacterType
    //     0x12c5f68: add             x16, PP, #0x80, lsl #12  ; [pp+0x804b8] Obj!CharacterType@12c6ee1
    //     0x12c5f6c: ldr             x16, [x16, #0x4b8]
    // 0x12c5f70: cmp             w4, w16
    // 0x12c5f74: b.ne            #0x12c5f84
    // 0x12c5f78: r1 = Instance_CharacterType
    //     0x12c5f78: add             x1, PP, #0x80, lsl #12  ; [pp+0x804b8] Obj!CharacterType@12c6ee1
    //     0x12c5f7c: ldr             x1, [x1, #0x4b8]
    // 0x12c5f80: b               #0x12c5fb8
    // 0x12c5f84: r16 = Instance_CharacterType
    //     0x12c5f84: add             x16, PP, #0x80, lsl #12  ; [pp+0x80538] Obj!CharacterType@12c6f41
    //     0x12c5f88: ldr             x16, [x16, #0x538]
    // 0x12c5f8c: cmp             w4, w16
    // 0x12c5f90: b.ne            #0x12c5fb4
    // 0x12c5f94: mov             x0, x3
    // 0x12c5f98: StoreField: r1->field_f = r0
    //     0x12c5f98: stur            w0, [x1, #0xf]
    //     0x12c5f9c: ldurb           w16, [x1, #-1]
    //     0x12c5fa0: ldurb           w17, [x0, #-1]
    //     0x12c5fa4: and             x16, x17, x16, lsr #2
    //     0x12c5fa8: tst             x16, HEAP, lsr #32
    //     0x12c5fac: b.eq            #0x12c5fb4
    //     0x12c5fb0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x12c5fb4: mov             x1, x3
    // 0x12c5fb8: mov             x3, x1
    // 0x12c5fbc: add             x0, x2, #1
    // 0x12c5fc0: mov             x2, x0
    // 0x12c5fc4: b               #0x12c5f08
    // 0x12c5fc8: r0 = Null
    //     0x12c5fc8: mov             x0, NULL
    // 0x12c5fcc: LeaveFrame
    //     0x12c5fcc: mov             SP, fp
    //     0x12c5fd0: ldp             fp, lr, [SP], #0x10
    // 0x12c5fd4: ret
    //     0x12c5fd4: ret             
    // 0x12c5fd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c5fd8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c5fdc: b               #0x12c5874
    // 0x12c5fe0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c5fe0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c5fe4: b               #0x12c58a0
    // 0x12c5fe8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c5fe8: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c5fec: r9 = type
    //     0x12c5fec: add             x9, PP, #0x80, lsl #12  ; [pp+0x804e0] Field <_CharData@1190396231.type>: late (offset: 0x10)
    //     0x12c5ff0: ldr             x9, [x9, #0x4e0]
    // 0x12c5ff4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12c5ff4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12c5ff8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c5ff8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c5ffc: b               #0x12c5944
    // 0x12c6000: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c6000: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c6004: r9 = type
    //     0x12c6004: add             x9, PP, #0x80, lsl #12  ; [pp+0x804e0] Field <_CharData@1190396231.type>: late (offset: 0x10)
    //     0x12c6008: ldr             x9, [x9, #0x4e0]
    // 0x12c600c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12c600c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12c6010: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c6010: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c6014: b               #0x12c5a28
    // 0x12c6018: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c6018: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c601c: r9 = type
    //     0x12c601c: add             x9, PP, #0x80, lsl #12  ; [pp+0x804e0] Field <_CharData@1190396231.type>: late (offset: 0x10)
    //     0x12c6020: ldr             x9, [x9, #0x4e0]
    // 0x12c6024: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12c6024: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12c6028: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c6028: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c602c: b               #0x12c5aac
    // 0x12c6030: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c6030: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c6034: r9 = type
    //     0x12c6034: add             x9, PP, #0x80, lsl #12  ; [pp+0x804e0] Field <_CharData@1190396231.type>: late (offset: 0x10)
    //     0x12c6038: ldr             x9, [x9, #0x4e0]
    // 0x12c603c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12c603c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12c6040: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c6040: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c6044: r9 = type
    //     0x12c6044: add             x9, PP, #0x80, lsl #12  ; [pp+0x804e0] Field <_CharData@1190396231.type>: late (offset: 0x10)
    //     0x12c6048: ldr             x9, [x9, #0x4e0]
    // 0x12c604c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12c604c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12c6050: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c6050: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c6054: r9 = type
    //     0x12c6054: add             x9, PP, #0x80, lsl #12  ; [pp+0x804e0] Field <_CharData@1190396231.type>: late (offset: 0x10)
    //     0x12c6058: ldr             x9, [x9, #0x4e0]
    // 0x12c605c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12c605c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12c6060: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c6060: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c6064: b               #0x12c5bec
    // 0x12c6068: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c6068: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c606c: r9 = type
    //     0x12c606c: add             x9, PP, #0x80, lsl #12  ; [pp+0x804e0] Field <_CharData@1190396231.type>: late (offset: 0x10)
    //     0x12c6070: ldr             x9, [x9, #0x4e0]
    // 0x12c6074: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12c6074: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12c6078: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c6078: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c607c: r9 = type
    //     0x12c607c: add             x9, PP, #0x80, lsl #12  ; [pp+0x804e0] Field <_CharData@1190396231.type>: late (offset: 0x10)
    //     0x12c6080: ldr             x9, [x9, #0x4e0]
    // 0x12c6084: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12c6084: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12c6088: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c6088: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c608c: r9 = type
    //     0x12c608c: add             x9, PP, #0x80, lsl #12  ; [pp+0x804e0] Field <_CharData@1190396231.type>: late (offset: 0x10)
    //     0x12c6090: ldr             x9, [x9, #0x4e0]
    // 0x12c6094: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12c6094: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12c6098: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c6098: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c609c: b               #0x12c5db4
    // 0x12c60a0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c60a0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c60a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c60a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c60a8: b               #0x12c5e60
    // 0x12c60ac: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c60ac: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c60b0: r9 = type
    //     0x12c60b0: add             x9, PP, #0x80, lsl #12  ; [pp+0x804e0] Field <_CharData@1190396231.type>: late (offset: 0x10)
    //     0x12c60b4: ldr             x9, [x9, #0x4e0]
    // 0x12c60b8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12c60b8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12c60bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c60bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c60c0: b               #0x12c5f14
    // 0x12c60c4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c60c4: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c60c8: r9 = type
    //     0x12c60c8: add             x9, PP, #0x80, lsl #12  ; [pp+0x804e0] Field <_CharData@1190396231.type>: late (offset: 0x10)
    //     0x12c60cc: ldr             x9, [x9, #0x4e0]
    // 0x12c60d0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12c60d0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  static _ getShapeJoiningType(/* No info */) {
    // ** addr: 0x12c7770, size: 0xce8
    // 0x12c7770: EnterFrame
    //     0x12c7770: stp             fp, lr, [SP, #-0x10]!
    //     0x12c7774: mov             fp, SP
    // 0x12c7778: mov             x2, x1
    // 0x12c777c: CheckStackOverflow
    //     0x12c777c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c7780: cmp             SP, x16
    //     0x12c7784: b.ls            #0x12c8450
    // 0x12c7788: cmp             x2, #0x600
    // 0x12c778c: b.lt            #0x12c77ac
    // 0x12c7790: cmp             x2, #0x605
    // 0x12c7794: b.gt            #0x12c77ac
    // 0x12c7798: r0 = Instance_ShapeJoiningType
    //     0x12c7798: add             x0, PP, #0x80, lsl #12  ; [pp+0x80598] Obj!ShapeJoiningType@12c6e61
    //     0x12c779c: ldr             x0, [x0, #0x598]
    // 0x12c77a0: LeaveFrame
    //     0x12c77a0: mov             SP, fp
    //     0x12c77a4: ldp             fp, lr, [SP], #0x10
    // 0x12c77a8: ret
    //     0x12c77a8: ret             
    // 0x12c77ac: cmp             x2, #0x608
    // 0x12c77b0: b.ne            #0x12c77c8
    // 0x12c77b4: r0 = Instance_ShapeJoiningType
    //     0x12c77b4: add             x0, PP, #0x80, lsl #12  ; [pp+0x80598] Obj!ShapeJoiningType@12c6e61
    //     0x12c77b8: ldr             x0, [x0, #0x598]
    // 0x12c77bc: LeaveFrame
    //     0x12c77bc: mov             SP, fp
    //     0x12c77c0: ldp             fp, lr, [SP], #0x10
    // 0x12c77c4: ret
    //     0x12c77c4: ret             
    // 0x12c77c8: cmp             x2, #0x60b
    // 0x12c77cc: b.ne            #0x12c77e4
    // 0x12c77d0: r0 = Instance_ShapeJoiningType
    //     0x12c77d0: add             x0, PP, #0x80, lsl #12  ; [pp+0x80598] Obj!ShapeJoiningType@12c6e61
    //     0x12c77d4: ldr             x0, [x0, #0x598]
    // 0x12c77d8: LeaveFrame
    //     0x12c77d8: mov             SP, fp
    //     0x12c77dc: ldp             fp, lr, [SP], #0x10
    // 0x12c77e0: ret
    //     0x12c77e0: ret             
    // 0x12c77e4: cmp             x2, #0x620
    // 0x12c77e8: b.ne            #0x12c7800
    // 0x12c77ec: r0 = Instance_ShapeJoiningType
    //     0x12c77ec: add             x0, PP, #0x80, lsl #12  ; [pp+0x805b0] Obj!ShapeJoiningType@12c6e21
    //     0x12c77f0: ldr             x0, [x0, #0x5b0]
    // 0x12c77f4: LeaveFrame
    //     0x12c77f4: mov             SP, fp
    //     0x12c77f8: ldp             fp, lr, [SP], #0x10
    // 0x12c77fc: ret
    //     0x12c77fc: ret             
    // 0x12c7800: cmp             x2, #0x621
    // 0x12c7804: b.ne            #0x12c781c
    // 0x12c7808: r0 = Instance_ShapeJoiningType
    //     0x12c7808: add             x0, PP, #0x80, lsl #12  ; [pp+0x80598] Obj!ShapeJoiningType@12c6e61
    //     0x12c780c: ldr             x0, [x0, #0x598]
    // 0x12c7810: LeaveFrame
    //     0x12c7810: mov             SP, fp
    //     0x12c7814: ldp             fp, lr, [SP], #0x10
    // 0x12c7818: ret
    //     0x12c7818: ret             
    // 0x12c781c: cmp             x2, #0x622
    // 0x12c7820: b.lt            #0x12c7840
    // 0x12c7824: cmp             x2, #0x625
    // 0x12c7828: b.gt            #0x12c7840
    // 0x12c782c: r0 = Instance_ShapeJoiningType
    //     0x12c782c: add             x0, PP, #0x80, lsl #12  ; [pp+0x805a8] Obj!ShapeJoiningType@12c6e41
    //     0x12c7830: ldr             x0, [x0, #0x5a8]
    // 0x12c7834: LeaveFrame
    //     0x12c7834: mov             SP, fp
    //     0x12c7838: ldp             fp, lr, [SP], #0x10
    // 0x12c783c: ret
    //     0x12c783c: ret             
    // 0x12c7840: cmp             x2, #0x626
    // 0x12c7844: b.ne            #0x12c785c
    // 0x12c7848: r0 = Instance_ShapeJoiningType
    //     0x12c7848: add             x0, PP, #0x80, lsl #12  ; [pp+0x805b0] Obj!ShapeJoiningType@12c6e21
    //     0x12c784c: ldr             x0, [x0, #0x5b0]
    // 0x12c7850: LeaveFrame
    //     0x12c7850: mov             SP, fp
    //     0x12c7854: ldp             fp, lr, [SP], #0x10
    // 0x12c7858: ret
    //     0x12c7858: ret             
    // 0x12c785c: cmp             x2, #0x627
    // 0x12c7860: b.ne            #0x12c7878
    // 0x12c7864: r0 = Instance_ShapeJoiningType
    //     0x12c7864: add             x0, PP, #0x80, lsl #12  ; [pp+0x805a8] Obj!ShapeJoiningType@12c6e41
    //     0x12c7868: ldr             x0, [x0, #0x5a8]
    // 0x12c786c: LeaveFrame
    //     0x12c786c: mov             SP, fp
    //     0x12c7870: ldp             fp, lr, [SP], #0x10
    // 0x12c7874: ret
    //     0x12c7874: ret             
    // 0x12c7878: cmp             x2, #0x628
    // 0x12c787c: b.ne            #0x12c7894
    // 0x12c7880: r0 = Instance_ShapeJoiningType
    //     0x12c7880: add             x0, PP, #0x80, lsl #12  ; [pp+0x805b0] Obj!ShapeJoiningType@12c6e21
    //     0x12c7884: ldr             x0, [x0, #0x5b0]
    // 0x12c7888: LeaveFrame
    //     0x12c7888: mov             SP, fp
    //     0x12c788c: ldp             fp, lr, [SP], #0x10
    // 0x12c7890: ret
    //     0x12c7890: ret             
    // 0x12c7894: cmp             x2, #0x629
    // 0x12c7898: b.ne            #0x12c78b0
    // 0x12c789c: r0 = Instance_ShapeJoiningType
    //     0x12c789c: add             x0, PP, #0x80, lsl #12  ; [pp+0x805a8] Obj!ShapeJoiningType@12c6e41
    //     0x12c78a0: ldr             x0, [x0, #0x5a8]
    // 0x12c78a4: LeaveFrame
    //     0x12c78a4: mov             SP, fp
    //     0x12c78a8: ldp             fp, lr, [SP], #0x10
    // 0x12c78ac: ret
    //     0x12c78ac: ret             
    // 0x12c78b0: cmp             x2, #0x62a
    // 0x12c78b4: b.lt            #0x12c78d4
    // 0x12c78b8: cmp             x2, #0x62e
    // 0x12c78bc: b.gt            #0x12c78d4
    // 0x12c78c0: r0 = Instance_ShapeJoiningType
    //     0x12c78c0: add             x0, PP, #0x80, lsl #12  ; [pp+0x805b0] Obj!ShapeJoiningType@12c6e21
    //     0x12c78c4: ldr             x0, [x0, #0x5b0]
    // 0x12c78c8: LeaveFrame
    //     0x12c78c8: mov             SP, fp
    //     0x12c78cc: ldp             fp, lr, [SP], #0x10
    // 0x12c78d0: ret
    //     0x12c78d0: ret             
    // 0x12c78d4: cmp             x2, #0x62f
    // 0x12c78d8: b.lt            #0x12c78f8
    // 0x12c78dc: cmp             x2, #0x632
    // 0x12c78e0: b.gt            #0x12c78f8
    // 0x12c78e4: r0 = Instance_ShapeJoiningType
    //     0x12c78e4: add             x0, PP, #0x80, lsl #12  ; [pp+0x805a8] Obj!ShapeJoiningType@12c6e41
    //     0x12c78e8: ldr             x0, [x0, #0x5a8]
    // 0x12c78ec: LeaveFrame
    //     0x12c78ec: mov             SP, fp
    //     0x12c78f0: ldp             fp, lr, [SP], #0x10
    // 0x12c78f4: ret
    //     0x12c78f4: ret             
    // 0x12c78f8: cmp             x2, #0x633
    // 0x12c78fc: b.lt            #0x12c791c
    // 0x12c7900: cmp             x2, #0x63f
    // 0x12c7904: b.gt            #0x12c791c
    // 0x12c7908: r0 = Instance_ShapeJoiningType
    //     0x12c7908: add             x0, PP, #0x80, lsl #12  ; [pp+0x805b0] Obj!ShapeJoiningType@12c6e21
    //     0x12c790c: ldr             x0, [x0, #0x5b0]
    // 0x12c7910: LeaveFrame
    //     0x12c7910: mov             SP, fp
    //     0x12c7914: ldp             fp, lr, [SP], #0x10
    // 0x12c7918: ret
    //     0x12c7918: ret             
    // 0x12c791c: cmp             x2, #0x640
    // 0x12c7920: b.ne            #0x12c7938
    // 0x12c7924: r0 = Instance_ShapeJoiningType
    //     0x12c7924: add             x0, PP, #0x80, lsl #12  ; [pp+0x805b8] Obj!ShapeJoiningType@12c6e01
    //     0x12c7928: ldr             x0, [x0, #0x5b8]
    // 0x12c792c: LeaveFrame
    //     0x12c792c: mov             SP, fp
    //     0x12c7930: ldp             fp, lr, [SP], #0x10
    // 0x12c7934: ret
    //     0x12c7934: ret             
    // 0x12c7938: cmp             x2, #0x641
    // 0x12c793c: b.lt            #0x12c795c
    // 0x12c7940: cmp             x2, #0x647
    // 0x12c7944: b.gt            #0x12c795c
    // 0x12c7948: r0 = Instance_ShapeJoiningType
    //     0x12c7948: add             x0, PP, #0x80, lsl #12  ; [pp+0x805b0] Obj!ShapeJoiningType@12c6e21
    //     0x12c794c: ldr             x0, [x0, #0x5b0]
    // 0x12c7950: LeaveFrame
    //     0x12c7950: mov             SP, fp
    //     0x12c7954: ldp             fp, lr, [SP], #0x10
    // 0x12c7958: ret
    //     0x12c7958: ret             
    // 0x12c795c: cmp             x2, #0x648
    // 0x12c7960: b.ne            #0x12c7978
    // 0x12c7964: r0 = Instance_ShapeJoiningType
    //     0x12c7964: add             x0, PP, #0x80, lsl #12  ; [pp+0x805a8] Obj!ShapeJoiningType@12c6e41
    //     0x12c7968: ldr             x0, [x0, #0x5a8]
    // 0x12c796c: LeaveFrame
    //     0x12c796c: mov             SP, fp
    //     0x12c7970: ldp             fp, lr, [SP], #0x10
    // 0x12c7974: ret
    //     0x12c7974: ret             
    // 0x12c7978: cmp             x2, #0x649
    // 0x12c797c: b.lt            #0x12c799c
    // 0x12c7980: cmp             x2, #0x64a
    // 0x12c7984: b.gt            #0x12c799c
    // 0x12c7988: r0 = Instance_ShapeJoiningType
    //     0x12c7988: add             x0, PP, #0x80, lsl #12  ; [pp+0x805b0] Obj!ShapeJoiningType@12c6e21
    //     0x12c798c: ldr             x0, [x0, #0x5b0]
    // 0x12c7990: LeaveFrame
    //     0x12c7990: mov             SP, fp
    //     0x12c7994: ldp             fp, lr, [SP], #0x10
    // 0x12c7998: ret
    //     0x12c7998: ret             
    // 0x12c799c: cmp             x2, #0x66e
    // 0x12c79a0: b.lt            #0x12c79c0
    // 0x12c79a4: cmp             x2, #0x66f
    // 0x12c79a8: b.gt            #0x12c79c0
    // 0x12c79ac: r0 = Instance_ShapeJoiningType
    //     0x12c79ac: add             x0, PP, #0x80, lsl #12  ; [pp+0x805b0] Obj!ShapeJoiningType@12c6e21
    //     0x12c79b0: ldr             x0, [x0, #0x5b0]
    // 0x12c79b4: LeaveFrame
    //     0x12c79b4: mov             SP, fp
    //     0x12c79b8: ldp             fp, lr, [SP], #0x10
    // 0x12c79bc: ret
    //     0x12c79bc: ret             
    // 0x12c79c0: cmp             x2, #0x671
    // 0x12c79c4: b.lt            #0x12c79e4
    // 0x12c79c8: cmp             x2, #0x673
    // 0x12c79cc: b.gt            #0x12c79e4
    // 0x12c79d0: r0 = Instance_ShapeJoiningType
    //     0x12c79d0: add             x0, PP, #0x80, lsl #12  ; [pp+0x805a8] Obj!ShapeJoiningType@12c6e41
    //     0x12c79d4: ldr             x0, [x0, #0x5a8]
    // 0x12c79d8: LeaveFrame
    //     0x12c79d8: mov             SP, fp
    //     0x12c79dc: ldp             fp, lr, [SP], #0x10
    // 0x12c79e0: ret
    //     0x12c79e0: ret             
    // 0x12c79e4: cmp             x2, #0x674
    // 0x12c79e8: b.ne            #0x12c7a00
    // 0x12c79ec: r0 = Instance_ShapeJoiningType
    //     0x12c79ec: add             x0, PP, #0x80, lsl #12  ; [pp+0x80598] Obj!ShapeJoiningType@12c6e61
    //     0x12c79f0: ldr             x0, [x0, #0x598]
    // 0x12c79f4: LeaveFrame
    //     0x12c79f4: mov             SP, fp
    //     0x12c79f8: ldp             fp, lr, [SP], #0x10
    // 0x12c79fc: ret
    //     0x12c79fc: ret             
    // 0x12c7a00: cmp             x2, #0x675
    // 0x12c7a04: b.lt            #0x12c7a24
    // 0x12c7a08: cmp             x2, #0x677
    // 0x12c7a0c: b.gt            #0x12c7a24
    // 0x12c7a10: r0 = Instance_ShapeJoiningType
    //     0x12c7a10: add             x0, PP, #0x80, lsl #12  ; [pp+0x805a8] Obj!ShapeJoiningType@12c6e41
    //     0x12c7a14: ldr             x0, [x0, #0x5a8]
    // 0x12c7a18: LeaveFrame
    //     0x12c7a18: mov             SP, fp
    //     0x12c7a1c: ldp             fp, lr, [SP], #0x10
    // 0x12c7a20: ret
    //     0x12c7a20: ret             
    // 0x12c7a24: cmp             x2, #0x678
    // 0x12c7a28: b.lt            #0x12c7a48
    // 0x12c7a2c: cmp             x2, #0x687
    // 0x12c7a30: b.gt            #0x12c7a48
    // 0x12c7a34: r0 = Instance_ShapeJoiningType
    //     0x12c7a34: add             x0, PP, #0x80, lsl #12  ; [pp+0x805b0] Obj!ShapeJoiningType@12c6e21
    //     0x12c7a38: ldr             x0, [x0, #0x5b0]
    // 0x12c7a3c: LeaveFrame
    //     0x12c7a3c: mov             SP, fp
    //     0x12c7a40: ldp             fp, lr, [SP], #0x10
    // 0x12c7a44: ret
    //     0x12c7a44: ret             
    // 0x12c7a48: cmp             x2, #0x688
    // 0x12c7a4c: b.lt            #0x12c7a6c
    // 0x12c7a50: cmp             x2, #0x699
    // 0x12c7a54: b.gt            #0x12c7a6c
    // 0x12c7a58: r0 = Instance_ShapeJoiningType
    //     0x12c7a58: add             x0, PP, #0x80, lsl #12  ; [pp+0x805a8] Obj!ShapeJoiningType@12c6e41
    //     0x12c7a5c: ldr             x0, [x0, #0x5a8]
    // 0x12c7a60: LeaveFrame
    //     0x12c7a60: mov             SP, fp
    //     0x12c7a64: ldp             fp, lr, [SP], #0x10
    // 0x12c7a68: ret
    //     0x12c7a68: ret             
    // 0x12c7a6c: cmp             x2, #0x69a
    // 0x12c7a70: b.lt            #0x12c7a90
    // 0x12c7a74: cmp             x2, #0x6bf
    // 0x12c7a78: b.gt            #0x12c7a90
    // 0x12c7a7c: r0 = Instance_ShapeJoiningType
    //     0x12c7a7c: add             x0, PP, #0x80, lsl #12  ; [pp+0x805b0] Obj!ShapeJoiningType@12c6e21
    //     0x12c7a80: ldr             x0, [x0, #0x5b0]
    // 0x12c7a84: LeaveFrame
    //     0x12c7a84: mov             SP, fp
    //     0x12c7a88: ldp             fp, lr, [SP], #0x10
    // 0x12c7a8c: ret
    //     0x12c7a8c: ret             
    // 0x12c7a90: cmp             x2, #0x6c0
    // 0x12c7a94: b.ne            #0x12c7aac
    // 0x12c7a98: r0 = Instance_ShapeJoiningType
    //     0x12c7a98: add             x0, PP, #0x80, lsl #12  ; [pp+0x805a8] Obj!ShapeJoiningType@12c6e41
    //     0x12c7a9c: ldr             x0, [x0, #0x5a8]
    // 0x12c7aa0: LeaveFrame
    //     0x12c7aa0: mov             SP, fp
    //     0x12c7aa4: ldp             fp, lr, [SP], #0x10
    // 0x12c7aa8: ret
    //     0x12c7aa8: ret             
    // 0x12c7aac: cmp             x2, #0x6c1
    // 0x12c7ab0: b.lt            #0x12c7ad0
    // 0x12c7ab4: cmp             x2, #0x6c2
    // 0x12c7ab8: b.gt            #0x12c7ad0
    // 0x12c7abc: r0 = Instance_ShapeJoiningType
    //     0x12c7abc: add             x0, PP, #0x80, lsl #12  ; [pp+0x805b0] Obj!ShapeJoiningType@12c6e21
    //     0x12c7ac0: ldr             x0, [x0, #0x5b0]
    // 0x12c7ac4: LeaveFrame
    //     0x12c7ac4: mov             SP, fp
    //     0x12c7ac8: ldp             fp, lr, [SP], #0x10
    // 0x12c7acc: ret
    //     0x12c7acc: ret             
    // 0x12c7ad0: cmp             x2, #0x6c3
    // 0x12c7ad4: b.lt            #0x12c7af4
    // 0x12c7ad8: cmp             x2, #0x6cb
    // 0x12c7adc: b.gt            #0x12c7af4
    // 0x12c7ae0: r0 = Instance_ShapeJoiningType
    //     0x12c7ae0: add             x0, PP, #0x80, lsl #12  ; [pp+0x805a8] Obj!ShapeJoiningType@12c6e41
    //     0x12c7ae4: ldr             x0, [x0, #0x5a8]
    // 0x12c7ae8: LeaveFrame
    //     0x12c7ae8: mov             SP, fp
    //     0x12c7aec: ldp             fp, lr, [SP], #0x10
    // 0x12c7af0: ret
    //     0x12c7af0: ret             
    // 0x12c7af4: cmp             x2, #0x6cc
    // 0x12c7af8: b.ne            #0x12c7b10
    // 0x12c7afc: r0 = Instance_ShapeJoiningType
    //     0x12c7afc: add             x0, PP, #0x80, lsl #12  ; [pp+0x805b0] Obj!ShapeJoiningType@12c6e21
    //     0x12c7b00: ldr             x0, [x0, #0x5b0]
    // 0x12c7b04: LeaveFrame
    //     0x12c7b04: mov             SP, fp
    //     0x12c7b08: ldp             fp, lr, [SP], #0x10
    // 0x12c7b0c: ret
    //     0x12c7b0c: ret             
    // 0x12c7b10: cmp             x2, #0x6cd
    // 0x12c7b14: b.ne            #0x12c7b2c
    // 0x12c7b18: r0 = Instance_ShapeJoiningType
    //     0x12c7b18: add             x0, PP, #0x80, lsl #12  ; [pp+0x805a8] Obj!ShapeJoiningType@12c6e41
    //     0x12c7b1c: ldr             x0, [x0, #0x5a8]
    // 0x12c7b20: LeaveFrame
    //     0x12c7b20: mov             SP, fp
    //     0x12c7b24: ldp             fp, lr, [SP], #0x10
    // 0x12c7b28: ret
    //     0x12c7b28: ret             
    // 0x12c7b2c: cmp             x2, #0x6ce
    // 0x12c7b30: b.ne            #0x12c7b48
    // 0x12c7b34: r0 = Instance_ShapeJoiningType
    //     0x12c7b34: add             x0, PP, #0x80, lsl #12  ; [pp+0x805b0] Obj!ShapeJoiningType@12c6e21
    //     0x12c7b38: ldr             x0, [x0, #0x5b0]
    // 0x12c7b3c: LeaveFrame
    //     0x12c7b3c: mov             SP, fp
    //     0x12c7b40: ldp             fp, lr, [SP], #0x10
    // 0x12c7b44: ret
    //     0x12c7b44: ret             
    // 0x12c7b48: cmp             x2, #0x6cf
    // 0x12c7b4c: b.ne            #0x12c7b64
    // 0x12c7b50: r0 = Instance_ShapeJoiningType
    //     0x12c7b50: add             x0, PP, #0x80, lsl #12  ; [pp+0x805a8] Obj!ShapeJoiningType@12c6e41
    //     0x12c7b54: ldr             x0, [x0, #0x5a8]
    // 0x12c7b58: LeaveFrame
    //     0x12c7b58: mov             SP, fp
    //     0x12c7b5c: ldp             fp, lr, [SP], #0x10
    // 0x12c7b60: ret
    //     0x12c7b60: ret             
    // 0x12c7b64: cmp             x2, #0x6d0
    // 0x12c7b68: b.lt            #0x12c7b88
    // 0x12c7b6c: cmp             x2, #0x6d1
    // 0x12c7b70: b.gt            #0x12c7b88
    // 0x12c7b74: r0 = Instance_ShapeJoiningType
    //     0x12c7b74: add             x0, PP, #0x80, lsl #12  ; [pp+0x805b0] Obj!ShapeJoiningType@12c6e21
    //     0x12c7b78: ldr             x0, [x0, #0x5b0]
    // 0x12c7b7c: LeaveFrame
    //     0x12c7b7c: mov             SP, fp
    //     0x12c7b80: ldp             fp, lr, [SP], #0x10
    // 0x12c7b84: ret
    //     0x12c7b84: ret             
    // 0x12c7b88: cmp             x2, #0x6d2
    // 0x12c7b8c: b.lt            #0x12c7bac
    // 0x12c7b90: cmp             x2, #0x6d3
    // 0x12c7b94: b.gt            #0x12c7bac
    // 0x12c7b98: r0 = Instance_ShapeJoiningType
    //     0x12c7b98: add             x0, PP, #0x80, lsl #12  ; [pp+0x805a8] Obj!ShapeJoiningType@12c6e41
    //     0x12c7b9c: ldr             x0, [x0, #0x5a8]
    // 0x12c7ba0: LeaveFrame
    //     0x12c7ba0: mov             SP, fp
    //     0x12c7ba4: ldp             fp, lr, [SP], #0x10
    // 0x12c7ba8: ret
    //     0x12c7ba8: ret             
    // 0x12c7bac: cmp             x2, #0x6d5
    // 0x12c7bb0: b.ne            #0x12c7bc8
    // 0x12c7bb4: r0 = Instance_ShapeJoiningType
    //     0x12c7bb4: add             x0, PP, #0x80, lsl #12  ; [pp+0x805a8] Obj!ShapeJoiningType@12c6e41
    //     0x12c7bb8: ldr             x0, [x0, #0x5a8]
    // 0x12c7bbc: LeaveFrame
    //     0x12c7bbc: mov             SP, fp
    //     0x12c7bc0: ldp             fp, lr, [SP], #0x10
    // 0x12c7bc4: ret
    //     0x12c7bc4: ret             
    // 0x12c7bc8: cmp             x2, #0x6dd
    // 0x12c7bcc: b.ne            #0x12c7be4
    // 0x12c7bd0: r0 = Instance_ShapeJoiningType
    //     0x12c7bd0: add             x0, PP, #0x80, lsl #12  ; [pp+0x80598] Obj!ShapeJoiningType@12c6e61
    //     0x12c7bd4: ldr             x0, [x0, #0x598]
    // 0x12c7bd8: LeaveFrame
    //     0x12c7bd8: mov             SP, fp
    //     0x12c7bdc: ldp             fp, lr, [SP], #0x10
    // 0x12c7be0: ret
    //     0x12c7be0: ret             
    // 0x12c7be4: cmp             x2, #0x6ee
    // 0x12c7be8: b.lt            #0x12c7c08
    // 0x12c7bec: cmp             x2, #0x6ef
    // 0x12c7bf0: b.gt            #0x12c7c08
    // 0x12c7bf4: r0 = Instance_ShapeJoiningType
    //     0x12c7bf4: add             x0, PP, #0x80, lsl #12  ; [pp+0x805a8] Obj!ShapeJoiningType@12c6e41
    //     0x12c7bf8: ldr             x0, [x0, #0x5a8]
    // 0x12c7bfc: LeaveFrame
    //     0x12c7bfc: mov             SP, fp
    //     0x12c7c00: ldp             fp, lr, [SP], #0x10
    // 0x12c7c04: ret
    //     0x12c7c04: ret             
    // 0x12c7c08: cmp             x2, #0x6fa
    // 0x12c7c0c: b.lt            #0x12c7c2c
    // 0x12c7c10: cmp             x2, #0x6fc
    // 0x12c7c14: b.gt            #0x12c7c2c
    // 0x12c7c18: r0 = Instance_ShapeJoiningType
    //     0x12c7c18: add             x0, PP, #0x80, lsl #12  ; [pp+0x805b0] Obj!ShapeJoiningType@12c6e21
    //     0x12c7c1c: ldr             x0, [x0, #0x5b0]
    // 0x12c7c20: LeaveFrame
    //     0x12c7c20: mov             SP, fp
    //     0x12c7c24: ldp             fp, lr, [SP], #0x10
    // 0x12c7c28: ret
    //     0x12c7c28: ret             
    // 0x12c7c2c: cmp             x2, #0x6ff
    // 0x12c7c30: b.ne            #0x12c7c48
    // 0x12c7c34: r0 = Instance_ShapeJoiningType
    //     0x12c7c34: add             x0, PP, #0x80, lsl #12  ; [pp+0x805b0] Obj!ShapeJoiningType@12c6e21
    //     0x12c7c38: ldr             x0, [x0, #0x5b0]
    // 0x12c7c3c: LeaveFrame
    //     0x12c7c3c: mov             SP, fp
    //     0x12c7c40: ldp             fp, lr, [SP], #0x10
    // 0x12c7c44: ret
    //     0x12c7c44: ret             
    // 0x12c7c48: cmp             x2, #0x710
    // 0x12c7c4c: b.ne            #0x12c7c64
    // 0x12c7c50: r0 = Instance_ShapeJoiningType
    //     0x12c7c50: add             x0, PP, #0x80, lsl #12  ; [pp+0x805a8] Obj!ShapeJoiningType@12c6e41
    //     0x12c7c54: ldr             x0, [x0, #0x5a8]
    // 0x12c7c58: LeaveFrame
    //     0x12c7c58: mov             SP, fp
    //     0x12c7c5c: ldp             fp, lr, [SP], #0x10
    // 0x12c7c60: ret
    //     0x12c7c60: ret             
    // 0x12c7c64: cmp             x2, #0x712
    // 0x12c7c68: b.lt            #0x12c7c88
    // 0x12c7c6c: cmp             x2, #0x714
    // 0x12c7c70: b.gt            #0x12c7c88
    // 0x12c7c74: r0 = Instance_ShapeJoiningType
    //     0x12c7c74: add             x0, PP, #0x80, lsl #12  ; [pp+0x805b0] Obj!ShapeJoiningType@12c6e21
    //     0x12c7c78: ldr             x0, [x0, #0x5b0]
    // 0x12c7c7c: LeaveFrame
    //     0x12c7c7c: mov             SP, fp
    //     0x12c7c80: ldp             fp, lr, [SP], #0x10
    // 0x12c7c84: ret
    //     0x12c7c84: ret             
    // 0x12c7c88: cmp             x2, #0x715
    // 0x12c7c8c: b.lt            #0x12c7cac
    // 0x12c7c90: cmp             x2, #0x719
    // 0x12c7c94: b.gt            #0x12c7cac
    // 0x12c7c98: r0 = Instance_ShapeJoiningType
    //     0x12c7c98: add             x0, PP, #0x80, lsl #12  ; [pp+0x805a8] Obj!ShapeJoiningType@12c6e41
    //     0x12c7c9c: ldr             x0, [x0, #0x5a8]
    // 0x12c7ca0: LeaveFrame
    //     0x12c7ca0: mov             SP, fp
    //     0x12c7ca4: ldp             fp, lr, [SP], #0x10
    // 0x12c7ca8: ret
    //     0x12c7ca8: ret             
    // 0x12c7cac: cmp             x2, #0x71a
    // 0x12c7cb0: b.lt            #0x12c7cd0
    // 0x12c7cb4: cmp             x2, #0x71d
    // 0x12c7cb8: b.gt            #0x12c7cd0
    // 0x12c7cbc: r0 = Instance_ShapeJoiningType
    //     0x12c7cbc: add             x0, PP, #0x80, lsl #12  ; [pp+0x805b0] Obj!ShapeJoiningType@12c6e21
    //     0x12c7cc0: ldr             x0, [x0, #0x5b0]
    // 0x12c7cc4: LeaveFrame
    //     0x12c7cc4: mov             SP, fp
    //     0x12c7cc8: ldp             fp, lr, [SP], #0x10
    // 0x12c7ccc: ret
    //     0x12c7ccc: ret             
    // 0x12c7cd0: cmp             x2, #0x71e
    // 0x12c7cd4: b.ne            #0x12c7cec
    // 0x12c7cd8: r0 = Instance_ShapeJoiningType
    //     0x12c7cd8: add             x0, PP, #0x80, lsl #12  ; [pp+0x805a8] Obj!ShapeJoiningType@12c6e41
    //     0x12c7cdc: ldr             x0, [x0, #0x5a8]
    // 0x12c7ce0: LeaveFrame
    //     0x12c7ce0: mov             SP, fp
    //     0x12c7ce4: ldp             fp, lr, [SP], #0x10
    // 0x12c7ce8: ret
    //     0x12c7ce8: ret             
    // 0x12c7cec: cmp             x2, #0x71f
    // 0x12c7cf0: b.lt            #0x12c7d10
    // 0x12c7cf4: cmp             x2, #0x727
    // 0x12c7cf8: b.gt            #0x12c7d10
    // 0x12c7cfc: r0 = Instance_ShapeJoiningType
    //     0x12c7cfc: add             x0, PP, #0x80, lsl #12  ; [pp+0x805b0] Obj!ShapeJoiningType@12c6e21
    //     0x12c7d00: ldr             x0, [x0, #0x5b0]
    // 0x12c7d04: LeaveFrame
    //     0x12c7d04: mov             SP, fp
    //     0x12c7d08: ldp             fp, lr, [SP], #0x10
    // 0x12c7d0c: ret
    //     0x12c7d0c: ret             
    // 0x12c7d10: cmp             x2, #0x728
    // 0x12c7d14: b.ne            #0x12c7d2c
    // 0x12c7d18: r0 = Instance_ShapeJoiningType
    //     0x12c7d18: add             x0, PP, #0x80, lsl #12  ; [pp+0x805a8] Obj!ShapeJoiningType@12c6e41
    //     0x12c7d1c: ldr             x0, [x0, #0x5a8]
    // 0x12c7d20: LeaveFrame
    //     0x12c7d20: mov             SP, fp
    //     0x12c7d24: ldp             fp, lr, [SP], #0x10
    // 0x12c7d28: ret
    //     0x12c7d28: ret             
    // 0x12c7d2c: cmp             x2, #0x729
    // 0x12c7d30: b.ne            #0x12c7d48
    // 0x12c7d34: r0 = Instance_ShapeJoiningType
    //     0x12c7d34: add             x0, PP, #0x80, lsl #12  ; [pp+0x805b0] Obj!ShapeJoiningType@12c6e21
    //     0x12c7d38: ldr             x0, [x0, #0x5b0]
    // 0x12c7d3c: LeaveFrame
    //     0x12c7d3c: mov             SP, fp
    //     0x12c7d40: ldp             fp, lr, [SP], #0x10
    // 0x12c7d44: ret
    //     0x12c7d44: ret             
    // 0x12c7d48: cmp             x2, #0x72a
    // 0x12c7d4c: b.ne            #0x12c7d64
    // 0x12c7d50: r0 = Instance_ShapeJoiningType
    //     0x12c7d50: add             x0, PP, #0x80, lsl #12  ; [pp+0x805a8] Obj!ShapeJoiningType@12c6e41
    //     0x12c7d54: ldr             x0, [x0, #0x5a8]
    // 0x12c7d58: LeaveFrame
    //     0x12c7d58: mov             SP, fp
    //     0x12c7d5c: ldp             fp, lr, [SP], #0x10
    // 0x12c7d60: ret
    //     0x12c7d60: ret             
    // 0x12c7d64: cmp             x2, #0x72b
    // 0x12c7d68: b.ne            #0x12c7d80
    // 0x12c7d6c: r0 = Instance_ShapeJoiningType
    //     0x12c7d6c: add             x0, PP, #0x80, lsl #12  ; [pp+0x805b0] Obj!ShapeJoiningType@12c6e21
    //     0x12c7d70: ldr             x0, [x0, #0x5b0]
    // 0x12c7d74: LeaveFrame
    //     0x12c7d74: mov             SP, fp
    //     0x12c7d78: ldp             fp, lr, [SP], #0x10
    // 0x12c7d7c: ret
    //     0x12c7d7c: ret             
    // 0x12c7d80: cmp             x2, #0x72c
    // 0x12c7d84: b.ne            #0x12c7d9c
    // 0x12c7d88: r0 = Instance_ShapeJoiningType
    //     0x12c7d88: add             x0, PP, #0x80, lsl #12  ; [pp+0x805a8] Obj!ShapeJoiningType@12c6e41
    //     0x12c7d8c: ldr             x0, [x0, #0x5a8]
    // 0x12c7d90: LeaveFrame
    //     0x12c7d90: mov             SP, fp
    //     0x12c7d94: ldp             fp, lr, [SP], #0x10
    // 0x12c7d98: ret
    //     0x12c7d98: ret             
    // 0x12c7d9c: cmp             x2, #0x72d
    // 0x12c7da0: b.lt            #0x12c7dc0
    // 0x12c7da4: cmp             x2, #0x72e
    // 0x12c7da8: b.gt            #0x12c7dc0
    // 0x12c7dac: r0 = Instance_ShapeJoiningType
    //     0x12c7dac: add             x0, PP, #0x80, lsl #12  ; [pp+0x805b0] Obj!ShapeJoiningType@12c6e21
    //     0x12c7db0: ldr             x0, [x0, #0x5b0]
    // 0x12c7db4: LeaveFrame
    //     0x12c7db4: mov             SP, fp
    //     0x12c7db8: ldp             fp, lr, [SP], #0x10
    // 0x12c7dbc: ret
    //     0x12c7dbc: ret             
    // 0x12c7dc0: cmp             x2, #0x72f
    // 0x12c7dc4: b.ne            #0x12c7ddc
    // 0x12c7dc8: r0 = Instance_ShapeJoiningType
    //     0x12c7dc8: add             x0, PP, #0x80, lsl #12  ; [pp+0x805a8] Obj!ShapeJoiningType@12c6e41
    //     0x12c7dcc: ldr             x0, [x0, #0x5a8]
    // 0x12c7dd0: LeaveFrame
    //     0x12c7dd0: mov             SP, fp
    //     0x12c7dd4: ldp             fp, lr, [SP], #0x10
    // 0x12c7dd8: ret
    //     0x12c7dd8: ret             
    // 0x12c7ddc: cmp             x2, #0x74d
    // 0x12c7de0: b.ne            #0x12c7df8
    // 0x12c7de4: r0 = Instance_ShapeJoiningType
    //     0x12c7de4: add             x0, PP, #0x80, lsl #12  ; [pp+0x805a8] Obj!ShapeJoiningType@12c6e41
    //     0x12c7de8: ldr             x0, [x0, #0x5a8]
    // 0x12c7dec: LeaveFrame
    //     0x12c7dec: mov             SP, fp
    //     0x12c7df0: ldp             fp, lr, [SP], #0x10
    // 0x12c7df4: ret
    //     0x12c7df4: ret             
    // 0x12c7df8: cmp             x2, #0x74e
    // 0x12c7dfc: b.lt            #0x12c7e1c
    // 0x12c7e00: cmp             x2, #0x758
    // 0x12c7e04: b.gt            #0x12c7e1c
    // 0x12c7e08: r0 = Instance_ShapeJoiningType
    //     0x12c7e08: add             x0, PP, #0x80, lsl #12  ; [pp+0x805b0] Obj!ShapeJoiningType@12c6e21
    //     0x12c7e0c: ldr             x0, [x0, #0x5b0]
    // 0x12c7e10: LeaveFrame
    //     0x12c7e10: mov             SP, fp
    //     0x12c7e14: ldp             fp, lr, [SP], #0x10
    // 0x12c7e18: ret
    //     0x12c7e18: ret             
    // 0x12c7e1c: cmp             x2, #0x759
    // 0x12c7e20: b.lt            #0x12c7e40
    // 0x12c7e24: cmp             x2, #0x75b
    // 0x12c7e28: b.gt            #0x12c7e40
    // 0x12c7e2c: r0 = Instance_ShapeJoiningType
    //     0x12c7e2c: add             x0, PP, #0x80, lsl #12  ; [pp+0x805a8] Obj!ShapeJoiningType@12c6e41
    //     0x12c7e30: ldr             x0, [x0, #0x5a8]
    // 0x12c7e34: LeaveFrame
    //     0x12c7e34: mov             SP, fp
    //     0x12c7e38: ldp             fp, lr, [SP], #0x10
    // 0x12c7e3c: ret
    //     0x12c7e3c: ret             
    // 0x12c7e40: cmp             x2, #0x75c
    // 0x12c7e44: b.lt            #0x12c7e64
    // 0x12c7e48: cmp             x2, #0x76a
    // 0x12c7e4c: b.gt            #0x12c7e64
    // 0x12c7e50: r0 = Instance_ShapeJoiningType
    //     0x12c7e50: add             x0, PP, #0x80, lsl #12  ; [pp+0x805b0] Obj!ShapeJoiningType@12c6e21
    //     0x12c7e54: ldr             x0, [x0, #0x5b0]
    // 0x12c7e58: LeaveFrame
    //     0x12c7e58: mov             SP, fp
    //     0x12c7e5c: ldp             fp, lr, [SP], #0x10
    // 0x12c7e60: ret
    //     0x12c7e60: ret             
    // 0x12c7e64: cmp             x2, #0x76b
    // 0x12c7e68: b.lt            #0x12c7e88
    // 0x12c7e6c: cmp             x2, #0x76c
    // 0x12c7e70: b.gt            #0x12c7e88
    // 0x12c7e74: r0 = Instance_ShapeJoiningType
    //     0x12c7e74: add             x0, PP, #0x80, lsl #12  ; [pp+0x805a8] Obj!ShapeJoiningType@12c6e41
    //     0x12c7e78: ldr             x0, [x0, #0x5a8]
    // 0x12c7e7c: LeaveFrame
    //     0x12c7e7c: mov             SP, fp
    //     0x12c7e80: ldp             fp, lr, [SP], #0x10
    // 0x12c7e84: ret
    //     0x12c7e84: ret             
    // 0x12c7e88: cmp             x2, #0x76d
    // 0x12c7e8c: b.lt            #0x12c7eac
    // 0x12c7e90: cmp             x2, #0x770
    // 0x12c7e94: b.gt            #0x12c7eac
    // 0x12c7e98: r0 = Instance_ShapeJoiningType
    //     0x12c7e98: add             x0, PP, #0x80, lsl #12  ; [pp+0x805b0] Obj!ShapeJoiningType@12c6e21
    //     0x12c7e9c: ldr             x0, [x0, #0x5b0]
    // 0x12c7ea0: LeaveFrame
    //     0x12c7ea0: mov             SP, fp
    //     0x12c7ea4: ldp             fp, lr, [SP], #0x10
    // 0x12c7ea8: ret
    //     0x12c7ea8: ret             
    // 0x12c7eac: cmp             x2, #0x771
    // 0x12c7eb0: b.ne            #0x12c7ec8
    // 0x12c7eb4: r0 = Instance_ShapeJoiningType
    //     0x12c7eb4: add             x0, PP, #0x80, lsl #12  ; [pp+0x805a8] Obj!ShapeJoiningType@12c6e41
    //     0x12c7eb8: ldr             x0, [x0, #0x5a8]
    // 0x12c7ebc: LeaveFrame
    //     0x12c7ebc: mov             SP, fp
    //     0x12c7ec0: ldp             fp, lr, [SP], #0x10
    // 0x12c7ec4: ret
    //     0x12c7ec4: ret             
    // 0x12c7ec8: cmp             x2, #0x772
    // 0x12c7ecc: b.ne            #0x12c7ee4
    // 0x12c7ed0: r0 = Instance_ShapeJoiningType
    //     0x12c7ed0: add             x0, PP, #0x80, lsl #12  ; [pp+0x805b0] Obj!ShapeJoiningType@12c6e21
    //     0x12c7ed4: ldr             x0, [x0, #0x5b0]
    // 0x12c7ed8: LeaveFrame
    //     0x12c7ed8: mov             SP, fp
    //     0x12c7edc: ldp             fp, lr, [SP], #0x10
    // 0x12c7ee0: ret
    //     0x12c7ee0: ret             
    // 0x12c7ee4: cmp             x2, #0x773
    // 0x12c7ee8: b.lt            #0x12c7f08
    // 0x12c7eec: cmp             x2, #0x774
    // 0x12c7ef0: b.gt            #0x12c7f08
    // 0x12c7ef4: r0 = Instance_ShapeJoiningType
    //     0x12c7ef4: add             x0, PP, #0x80, lsl #12  ; [pp+0x805a8] Obj!ShapeJoiningType@12c6e41
    //     0x12c7ef8: ldr             x0, [x0, #0x5a8]
    // 0x12c7efc: LeaveFrame
    //     0x12c7efc: mov             SP, fp
    //     0x12c7f00: ldp             fp, lr, [SP], #0x10
    // 0x12c7f04: ret
    //     0x12c7f04: ret             
    // 0x12c7f08: cmp             x2, #0x775
    // 0x12c7f0c: b.lt            #0x12c7f2c
    // 0x12c7f10: cmp             x2, #0x777
    // 0x12c7f14: b.gt            #0x12c7f2c
    // 0x12c7f18: r0 = Instance_ShapeJoiningType
    //     0x12c7f18: add             x0, PP, #0x80, lsl #12  ; [pp+0x805b0] Obj!ShapeJoiningType@12c6e21
    //     0x12c7f1c: ldr             x0, [x0, #0x5b0]
    // 0x12c7f20: LeaveFrame
    //     0x12c7f20: mov             SP, fp
    //     0x12c7f24: ldp             fp, lr, [SP], #0x10
    // 0x12c7f28: ret
    //     0x12c7f28: ret             
    // 0x12c7f2c: cmp             x2, #0x778
    // 0x12c7f30: b.lt            #0x12c7f50
    // 0x12c7f34: cmp             x2, #0x779
    // 0x12c7f38: b.gt            #0x12c7f50
    // 0x12c7f3c: r0 = Instance_ShapeJoiningType
    //     0x12c7f3c: add             x0, PP, #0x80, lsl #12  ; [pp+0x805a8] Obj!ShapeJoiningType@12c6e41
    //     0x12c7f40: ldr             x0, [x0, #0x5a8]
    // 0x12c7f44: LeaveFrame
    //     0x12c7f44: mov             SP, fp
    //     0x12c7f48: ldp             fp, lr, [SP], #0x10
    // 0x12c7f4c: ret
    //     0x12c7f4c: ret             
    // 0x12c7f50: cmp             x2, #0x77a
    // 0x12c7f54: b.lt            #0x12c7f74
    // 0x12c7f58: cmp             x2, #0x77f
    // 0x12c7f5c: b.gt            #0x12c7f74
    // 0x12c7f60: r0 = Instance_ShapeJoiningType
    //     0x12c7f60: add             x0, PP, #0x80, lsl #12  ; [pp+0x805b0] Obj!ShapeJoiningType@12c6e21
    //     0x12c7f64: ldr             x0, [x0, #0x5b0]
    // 0x12c7f68: LeaveFrame
    //     0x12c7f68: mov             SP, fp
    //     0x12c7f6c: ldp             fp, lr, [SP], #0x10
    // 0x12c7f70: ret
    //     0x12c7f70: ret             
    // 0x12c7f74: cmp             x2, #0x7ca
    // 0x12c7f78: b.lt            #0x12c7f98
    // 0x12c7f7c: cmp             x2, #0x7ea
    // 0x12c7f80: b.gt            #0x12c7f98
    // 0x12c7f84: r0 = Instance_ShapeJoiningType
    //     0x12c7f84: add             x0, PP, #0x80, lsl #12  ; [pp+0x805b0] Obj!ShapeJoiningType@12c6e21
    //     0x12c7f88: ldr             x0, [x0, #0x5b0]
    // 0x12c7f8c: LeaveFrame
    //     0x12c7f8c: mov             SP, fp
    //     0x12c7f90: ldp             fp, lr, [SP], #0x10
    // 0x12c7f94: ret
    //     0x12c7f94: ret             
    // 0x12c7f98: cmp             x2, #0x7fa
    // 0x12c7f9c: b.ne            #0x12c7fb4
    // 0x12c7fa0: r0 = Instance_ShapeJoiningType
    //     0x12c7fa0: add             x0, PP, #0x80, lsl #12  ; [pp+0x805b8] Obj!ShapeJoiningType@12c6e01
    //     0x12c7fa4: ldr             x0, [x0, #0x5b8]
    // 0x12c7fa8: LeaveFrame
    //     0x12c7fa8: mov             SP, fp
    //     0x12c7fac: ldp             fp, lr, [SP], #0x10
    // 0x12c7fb0: ret
    //     0x12c7fb0: ret             
    // 0x12c7fb4: cmp             x2, #0x840
    // 0x12c7fb8: b.ne            #0x12c7fd0
    // 0x12c7fbc: r0 = Instance_ShapeJoiningType
    //     0x12c7fbc: add             x0, PP, #0x80, lsl #12  ; [pp+0x805a8] Obj!ShapeJoiningType@12c6e41
    //     0x12c7fc0: ldr             x0, [x0, #0x5a8]
    // 0x12c7fc4: LeaveFrame
    //     0x12c7fc4: mov             SP, fp
    //     0x12c7fc8: ldp             fp, lr, [SP], #0x10
    // 0x12c7fcc: ret
    //     0x12c7fcc: ret             
    // 0x12c7fd0: cmp             x2, #0x841
    // 0x12c7fd4: b.lt            #0x12c7ff4
    // 0x12c7fd8: cmp             x2, #0x845
    // 0x12c7fdc: b.gt            #0x12c7ff4
    // 0x12c7fe0: r0 = Instance_ShapeJoiningType
    //     0x12c7fe0: add             x0, PP, #0x80, lsl #12  ; [pp+0x805b0] Obj!ShapeJoiningType@12c6e21
    //     0x12c7fe4: ldr             x0, [x0, #0x5b0]
    // 0x12c7fe8: LeaveFrame
    //     0x12c7fe8: mov             SP, fp
    //     0x12c7fec: ldp             fp, lr, [SP], #0x10
    // 0x12c7ff0: ret
    //     0x12c7ff0: ret             
    // 0x12c7ff4: cmp             x2, #0x846
    // 0x12c7ff8: b.ne            #0x12c8010
    // 0x12c7ffc: r0 = Instance_ShapeJoiningType
    //     0x12c7ffc: add             x0, PP, #0x80, lsl #12  ; [pp+0x805a8] Obj!ShapeJoiningType@12c6e41
    //     0x12c8000: ldr             x0, [x0, #0x5a8]
    // 0x12c8004: LeaveFrame
    //     0x12c8004: mov             SP, fp
    //     0x12c8008: ldp             fp, lr, [SP], #0x10
    // 0x12c800c: ret
    //     0x12c800c: ret             
    // 0x12c8010: cmp             x2, #0x847
    // 0x12c8014: b.lt            #0x12c8034
    // 0x12c8018: cmp             x2, #0x848
    // 0x12c801c: b.gt            #0x12c8034
    // 0x12c8020: r0 = Instance_ShapeJoiningType
    //     0x12c8020: add             x0, PP, #0x80, lsl #12  ; [pp+0x805b0] Obj!ShapeJoiningType@12c6e21
    //     0x12c8024: ldr             x0, [x0, #0x5b0]
    // 0x12c8028: LeaveFrame
    //     0x12c8028: mov             SP, fp
    //     0x12c802c: ldp             fp, lr, [SP], #0x10
    // 0x12c8030: ret
    //     0x12c8030: ret             
    // 0x12c8034: cmp             x2, #0x849
    // 0x12c8038: b.ne            #0x12c8050
    // 0x12c803c: r0 = Instance_ShapeJoiningType
    //     0x12c803c: add             x0, PP, #0x80, lsl #12  ; [pp+0x805a8] Obj!ShapeJoiningType@12c6e41
    //     0x12c8040: ldr             x0, [x0, #0x5a8]
    // 0x12c8044: LeaveFrame
    //     0x12c8044: mov             SP, fp
    //     0x12c8048: ldp             fp, lr, [SP], #0x10
    // 0x12c804c: ret
    //     0x12c804c: ret             
    // 0x12c8050: cmp             x2, #0x84a
    // 0x12c8054: b.lt            #0x12c8074
    // 0x12c8058: cmp             x2, #0x84e
    // 0x12c805c: b.gt            #0x12c8074
    // 0x12c8060: r0 = Instance_ShapeJoiningType
    //     0x12c8060: add             x0, PP, #0x80, lsl #12  ; [pp+0x805b0] Obj!ShapeJoiningType@12c6e21
    //     0x12c8064: ldr             x0, [x0, #0x5b0]
    // 0x12c8068: LeaveFrame
    //     0x12c8068: mov             SP, fp
    //     0x12c806c: ldp             fp, lr, [SP], #0x10
    // 0x12c8070: ret
    //     0x12c8070: ret             
    // 0x12c8074: cmp             x2, #0x84f
    // 0x12c8078: b.ne            #0x12c8090
    // 0x12c807c: r0 = Instance_ShapeJoiningType
    //     0x12c807c: add             x0, PP, #0x80, lsl #12  ; [pp+0x805a8] Obj!ShapeJoiningType@12c6e41
    //     0x12c8080: ldr             x0, [x0, #0x5a8]
    // 0x12c8084: LeaveFrame
    //     0x12c8084: mov             SP, fp
    //     0x12c8088: ldp             fp, lr, [SP], #0x10
    // 0x12c808c: ret
    //     0x12c808c: ret             
    // 0x12c8090: cmp             x2, #0x850
    // 0x12c8094: b.lt            #0x12c80b4
    // 0x12c8098: cmp             x2, #0x853
    // 0x12c809c: b.gt            #0x12c80b4
    // 0x12c80a0: r0 = Instance_ShapeJoiningType
    //     0x12c80a0: add             x0, PP, #0x80, lsl #12  ; [pp+0x805b0] Obj!ShapeJoiningType@12c6e21
    //     0x12c80a4: ldr             x0, [x0, #0x5b0]
    // 0x12c80a8: LeaveFrame
    //     0x12c80a8: mov             SP, fp
    //     0x12c80ac: ldp             fp, lr, [SP], #0x10
    // 0x12c80b0: ret
    //     0x12c80b0: ret             
    // 0x12c80b4: cmp             x2, #0x854
    // 0x12c80b8: b.ne            #0x12c80d0
    // 0x12c80bc: r0 = Instance_ShapeJoiningType
    //     0x12c80bc: add             x0, PP, #0x80, lsl #12  ; [pp+0x805a8] Obj!ShapeJoiningType@12c6e41
    //     0x12c80c0: ldr             x0, [x0, #0x5a8]
    // 0x12c80c4: LeaveFrame
    //     0x12c80c4: mov             SP, fp
    //     0x12c80c8: ldp             fp, lr, [SP], #0x10
    // 0x12c80cc: ret
    //     0x12c80cc: ret             
    // 0x12c80d0: cmp             x2, #0x855
    // 0x12c80d4: b.ne            #0x12c80ec
    // 0x12c80d8: r0 = Instance_ShapeJoiningType
    //     0x12c80d8: add             x0, PP, #0x80, lsl #12  ; [pp+0x805b0] Obj!ShapeJoiningType@12c6e21
    //     0x12c80dc: ldr             x0, [x0, #0x5b0]
    // 0x12c80e0: LeaveFrame
    //     0x12c80e0: mov             SP, fp
    //     0x12c80e4: ldp             fp, lr, [SP], #0x10
    // 0x12c80e8: ret
    //     0x12c80e8: ret             
    // 0x12c80ec: cmp             x2, #0x856
    // 0x12c80f0: b.lt            #0x12c8110
    // 0x12c80f4: cmp             x2, #0x858
    // 0x12c80f8: b.gt            #0x12c8110
    // 0x12c80fc: r0 = Instance_ShapeJoiningType
    //     0x12c80fc: add             x0, PP, #0x80, lsl #12  ; [pp+0x80598] Obj!ShapeJoiningType@12c6e61
    //     0x12c8100: ldr             x0, [x0, #0x598]
    // 0x12c8104: LeaveFrame
    //     0x12c8104: mov             SP, fp
    //     0x12c8108: ldp             fp, lr, [SP], #0x10
    // 0x12c810c: ret
    //     0x12c810c: ret             
    // 0x12c8110: cmp             x2, #0x8a0
    // 0x12c8114: b.lt            #0x12c8134
    // 0x12c8118: cmp             x2, #0x8a9
    // 0x12c811c: b.gt            #0x12c8134
    // 0x12c8120: r0 = Instance_ShapeJoiningType
    //     0x12c8120: add             x0, PP, #0x80, lsl #12  ; [pp+0x805b0] Obj!ShapeJoiningType@12c6e21
    //     0x12c8124: ldr             x0, [x0, #0x5b0]
    // 0x12c8128: LeaveFrame
    //     0x12c8128: mov             SP, fp
    //     0x12c812c: ldp             fp, lr, [SP], #0x10
    // 0x12c8130: ret
    //     0x12c8130: ret             
    // 0x12c8134: cmp             x2, #0x8aa
    // 0x12c8138: b.lt            #0x12c8158
    // 0x12c813c: cmp             x2, #0x8ac
    // 0x12c8140: b.gt            #0x12c8158
    // 0x12c8144: r0 = Instance_ShapeJoiningType
    //     0x12c8144: add             x0, PP, #0x80, lsl #12  ; [pp+0x805a8] Obj!ShapeJoiningType@12c6e41
    //     0x12c8148: ldr             x0, [x0, #0x5a8]
    // 0x12c814c: LeaveFrame
    //     0x12c814c: mov             SP, fp
    //     0x12c8150: ldp             fp, lr, [SP], #0x10
    // 0x12c8154: ret
    //     0x12c8154: ret             
    // 0x12c8158: cmp             x2, #0x8ad
    // 0x12c815c: b.ne            #0x12c8174
    // 0x12c8160: r0 = Instance_ShapeJoiningType
    //     0x12c8160: add             x0, PP, #0x80, lsl #12  ; [pp+0x80598] Obj!ShapeJoiningType@12c6e61
    //     0x12c8164: ldr             x0, [x0, #0x598]
    // 0x12c8168: LeaveFrame
    //     0x12c8168: mov             SP, fp
    //     0x12c816c: ldp             fp, lr, [SP], #0x10
    // 0x12c8170: ret
    //     0x12c8170: ret             
    // 0x12c8174: cmp             x2, #0x8ae
    // 0x12c8178: b.ne            #0x12c8190
    // 0x12c817c: r0 = Instance_ShapeJoiningType
    //     0x12c817c: add             x0, PP, #0x80, lsl #12  ; [pp+0x805a8] Obj!ShapeJoiningType@12c6e41
    //     0x12c8180: ldr             x0, [x0, #0x5a8]
    // 0x12c8184: LeaveFrame
    //     0x12c8184: mov             SP, fp
    //     0x12c8188: ldp             fp, lr, [SP], #0x10
    // 0x12c818c: ret
    //     0x12c818c: ret             
    // 0x12c8190: cmp             x2, #0x8af
    // 0x12c8194: b.lt            #0x12c81b4
    // 0x12c8198: cmp             x2, #0x8b0
    // 0x12c819c: b.gt            #0x12c81b4
    // 0x12c81a0: r0 = Instance_ShapeJoiningType
    //     0x12c81a0: add             x0, PP, #0x80, lsl #12  ; [pp+0x805b0] Obj!ShapeJoiningType@12c6e21
    //     0x12c81a4: ldr             x0, [x0, #0x5b0]
    // 0x12c81a8: LeaveFrame
    //     0x12c81a8: mov             SP, fp
    //     0x12c81ac: ldp             fp, lr, [SP], #0x10
    // 0x12c81b0: ret
    //     0x12c81b0: ret             
    // 0x12c81b4: cmp             x2, #0x8b1
    // 0x12c81b8: b.lt            #0x12c81d8
    // 0x12c81bc: cmp             x2, #0x8b2
    // 0x12c81c0: b.gt            #0x12c81d8
    // 0x12c81c4: r0 = Instance_ShapeJoiningType
    //     0x12c81c4: add             x0, PP, #0x80, lsl #12  ; [pp+0x805a8] Obj!ShapeJoiningType@12c6e41
    //     0x12c81c8: ldr             x0, [x0, #0x5a8]
    // 0x12c81cc: LeaveFrame
    //     0x12c81cc: mov             SP, fp
    //     0x12c81d0: ldp             fp, lr, [SP], #0x10
    // 0x12c81d4: ret
    //     0x12c81d4: ret             
    // 0x12c81d8: r17 = 6150
    //     0x12c81d8: mov             x17, #0x1806
    // 0x12c81dc: cmp             x2, x17
    // 0x12c81e0: b.ne            #0x12c81f8
    // 0x12c81e4: r0 = Instance_ShapeJoiningType
    //     0x12c81e4: add             x0, PP, #0x80, lsl #12  ; [pp+0x80598] Obj!ShapeJoiningType@12c6e61
    //     0x12c81e8: ldr             x0, [x0, #0x598]
    // 0x12c81ec: LeaveFrame
    //     0x12c81ec: mov             SP, fp
    //     0x12c81f0: ldp             fp, lr, [SP], #0x10
    // 0x12c81f4: ret
    //     0x12c81f4: ret             
    // 0x12c81f8: r17 = 6151
    //     0x12c81f8: mov             x17, #0x1807
    // 0x12c81fc: cmp             x2, x17
    // 0x12c8200: b.ne            #0x12c8218
    // 0x12c8204: r0 = Instance_ShapeJoiningType
    //     0x12c8204: add             x0, PP, #0x80, lsl #12  ; [pp+0x805b0] Obj!ShapeJoiningType@12c6e21
    //     0x12c8208: ldr             x0, [x0, #0x5b0]
    // 0x12c820c: LeaveFrame
    //     0x12c820c: mov             SP, fp
    //     0x12c8210: ldp             fp, lr, [SP], #0x10
    // 0x12c8214: ret
    //     0x12c8214: ret             
    // 0x12c8218: r17 = 6154
    //     0x12c8218: mov             x17, #0x180a
    // 0x12c821c: cmp             x2, x17
    // 0x12c8220: b.ne            #0x12c8238
    // 0x12c8224: r0 = Instance_ShapeJoiningType
    //     0x12c8224: add             x0, PP, #0x80, lsl #12  ; [pp+0x805b8] Obj!ShapeJoiningType@12c6e01
    //     0x12c8228: ldr             x0, [x0, #0x5b8]
    // 0x12c822c: LeaveFrame
    //     0x12c822c: mov             SP, fp
    //     0x12c8230: ldp             fp, lr, [SP], #0x10
    // 0x12c8234: ret
    //     0x12c8234: ret             
    // 0x12c8238: r17 = 6158
    //     0x12c8238: mov             x17, #0x180e
    // 0x12c823c: cmp             x2, x17
    // 0x12c8240: b.ne            #0x12c8258
    // 0x12c8244: r0 = Instance_ShapeJoiningType
    //     0x12c8244: add             x0, PP, #0x80, lsl #12  ; [pp+0x80598] Obj!ShapeJoiningType@12c6e61
    //     0x12c8248: ldr             x0, [x0, #0x598]
    // 0x12c824c: LeaveFrame
    //     0x12c824c: mov             SP, fp
    //     0x12c8250: ldp             fp, lr, [SP], #0x10
    // 0x12c8254: ret
    //     0x12c8254: ret             
    // 0x12c8258: r17 = 6176
    //     0x12c8258: mov             x17, #0x1820
    // 0x12c825c: cmp             x2, x17
    // 0x12c8260: b.lt            #0x12c8284
    // 0x12c8264: r17 = 6263
    //     0x12c8264: mov             x17, #0x1877
    // 0x12c8268: cmp             x2, x17
    // 0x12c826c: b.gt            #0x12c8284
    // 0x12c8270: r0 = Instance_ShapeJoiningType
    //     0x12c8270: add             x0, PP, #0x80, lsl #12  ; [pp+0x805b0] Obj!ShapeJoiningType@12c6e21
    //     0x12c8274: ldr             x0, [x0, #0x5b0]
    // 0x12c8278: LeaveFrame
    //     0x12c8278: mov             SP, fp
    //     0x12c827c: ldp             fp, lr, [SP], #0x10
    // 0x12c8280: ret
    //     0x12c8280: ret             
    // 0x12c8284: r17 = 6272
    //     0x12c8284: mov             x17, #0x1880
    // 0x12c8288: cmp             x2, x17
    // 0x12c828c: b.lt            #0x12c82b0
    // 0x12c8290: r17 = 6278
    //     0x12c8290: mov             x17, #0x1886
    // 0x12c8294: cmp             x2, x17
    // 0x12c8298: b.gt            #0x12c82b0
    // 0x12c829c: r0 = Instance_ShapeJoiningType
    //     0x12c829c: add             x0, PP, #0x80, lsl #12  ; [pp+0x80598] Obj!ShapeJoiningType@12c6e61
    //     0x12c82a0: ldr             x0, [x0, #0x598]
    // 0x12c82a4: LeaveFrame
    //     0x12c82a4: mov             SP, fp
    //     0x12c82a8: ldp             fp, lr, [SP], #0x10
    // 0x12c82ac: ret
    //     0x12c82ac: ret             
    // 0x12c82b0: r17 = 6279
    //     0x12c82b0: mov             x17, #0x1887
    // 0x12c82b4: cmp             x2, x17
    // 0x12c82b8: b.lt            #0x12c82dc
    // 0x12c82bc: r17 = 6312
    //     0x12c82bc: mov             x17, #0x18a8
    // 0x12c82c0: cmp             x2, x17
    // 0x12c82c4: b.gt            #0x12c82dc
    // 0x12c82c8: r0 = Instance_ShapeJoiningType
    //     0x12c82c8: add             x0, PP, #0x80, lsl #12  ; [pp+0x805b0] Obj!ShapeJoiningType@12c6e21
    //     0x12c82cc: ldr             x0, [x0, #0x5b0]
    // 0x12c82d0: LeaveFrame
    //     0x12c82d0: mov             SP, fp
    //     0x12c82d4: ldp             fp, lr, [SP], #0x10
    // 0x12c82d8: ret
    //     0x12c82d8: ret             
    // 0x12c82dc: r17 = 6314
    //     0x12c82dc: mov             x17, #0x18aa
    // 0x12c82e0: cmp             x2, x17
    // 0x12c82e4: b.ne            #0x12c82fc
    // 0x12c82e8: r0 = Instance_ShapeJoiningType
    //     0x12c82e8: add             x0, PP, #0x80, lsl #12  ; [pp+0x805b0] Obj!ShapeJoiningType@12c6e21
    //     0x12c82ec: ldr             x0, [x0, #0x5b0]
    // 0x12c82f0: LeaveFrame
    //     0x12c82f0: mov             SP, fp
    //     0x12c82f4: ldp             fp, lr, [SP], #0x10
    // 0x12c82f8: ret
    //     0x12c82f8: ret             
    // 0x12c82fc: r17 = 8204
    //     0x12c82fc: mov             x17, #0x200c
    // 0x12c8300: cmp             x2, x17
    // 0x12c8304: b.ne            #0x12c831c
    // 0x12c8308: r0 = Instance_ShapeJoiningType
    //     0x12c8308: add             x0, PP, #0x80, lsl #12  ; [pp+0x80598] Obj!ShapeJoiningType@12c6e61
    //     0x12c830c: ldr             x0, [x0, #0x598]
    // 0x12c8310: LeaveFrame
    //     0x12c8310: mov             SP, fp
    //     0x12c8314: ldp             fp, lr, [SP], #0x10
    // 0x12c8318: ret
    //     0x12c8318: ret             
    // 0x12c831c: r17 = 8205
    //     0x12c831c: mov             x17, #0x200d
    // 0x12c8320: cmp             x2, x17
    // 0x12c8324: b.ne            #0x12c833c
    // 0x12c8328: r0 = Instance_ShapeJoiningType
    //     0x12c8328: add             x0, PP, #0x80, lsl #12  ; [pp+0x805b8] Obj!ShapeJoiningType@12c6e01
    //     0x12c832c: ldr             x0, [x0, #0x5b8]
    // 0x12c8330: LeaveFrame
    //     0x12c8330: mov             SP, fp
    //     0x12c8334: ldp             fp, lr, [SP], #0x10
    // 0x12c8338: ret
    //     0x12c8338: ret             
    // 0x12c833c: r17 = 8294
    //     0x12c833c: mov             x17, #0x2066
    // 0x12c8340: cmp             x2, x17
    // 0x12c8344: b.lt            #0x12c8368
    // 0x12c8348: r17 = 8297
    //     0x12c8348: mov             x17, #0x2069
    // 0x12c834c: cmp             x2, x17
    // 0x12c8350: b.gt            #0x12c8368
    // 0x12c8354: r0 = Instance_ShapeJoiningType
    //     0x12c8354: add             x0, PP, #0x80, lsl #12  ; [pp+0x80598] Obj!ShapeJoiningType@12c6e61
    //     0x12c8358: ldr             x0, [x0, #0x598]
    // 0x12c835c: LeaveFrame
    //     0x12c835c: mov             SP, fp
    //     0x12c8360: ldp             fp, lr, [SP], #0x10
    // 0x12c8364: ret
    //     0x12c8364: ret             
    // 0x12c8368: r17 = 43072
    //     0x12c8368: mov             x17, #0xa840
    // 0x12c836c: cmp             x2, x17
    // 0x12c8370: b.lt            #0x12c8394
    // 0x12c8374: r17 = 43121
    //     0x12c8374: mov             x17, #0xa871
    // 0x12c8378: cmp             x2, x17
    // 0x12c837c: b.gt            #0x12c8394
    // 0x12c8380: r0 = Instance_ShapeJoiningType
    //     0x12c8380: add             x0, PP, #0x80, lsl #12  ; [pp+0x805b0] Obj!ShapeJoiningType@12c6e21
    //     0x12c8384: ldr             x0, [x0, #0x5b0]
    // 0x12c8388: LeaveFrame
    //     0x12c8388: mov             SP, fp
    //     0x12c838c: ldp             fp, lr, [SP], #0x10
    // 0x12c8390: ret
    //     0x12c8390: ret             
    // 0x12c8394: r17 = 43122
    //     0x12c8394: mov             x17, #0xa872
    // 0x12c8398: cmp             x2, x17
    // 0x12c839c: b.ne            #0x12c83b4
    // 0x12c83a0: r0 = Instance_ShapeJoiningType
    //     0x12c83a0: add             x0, PP, #0x80, lsl #12  ; [pp+0x805c0] Obj!ShapeJoiningType@12c6de1
    //     0x12c83a4: ldr             x0, [x0, #0x5c0]
    // 0x12c83a8: LeaveFrame
    //     0x12c83a8: mov             SP, fp
    //     0x12c83ac: ldp             fp, lr, [SP], #0x10
    // 0x12c83b0: ret
    //     0x12c83b0: ret             
    // 0x12c83b4: r17 = 43123
    //     0x12c83b4: mov             x17, #0xa873
    // 0x12c83b8: cmp             x2, x17
    // 0x12c83bc: b.ne            #0x12c83d4
    // 0x12c83c0: r0 = Instance_ShapeJoiningType
    //     0x12c83c0: add             x0, PP, #0x80, lsl #12  ; [pp+0x80598] Obj!ShapeJoiningType@12c6e61
    //     0x12c83c4: ldr             x0, [x0, #0x598]
    // 0x12c83c8: LeaveFrame
    //     0x12c83c8: mov             SP, fp
    //     0x12c83cc: ldp             fp, lr, [SP], #0x10
    // 0x12c83d0: ret
    //     0x12c83d0: ret             
    // 0x12c83d4: r0 = BoxInt64Instr(r2)
    //     0x12c83d4: sbfiz           x0, x2, #1, #0x1f
    //     0x12c83d8: cmp             x2, x0, asr #1
    //     0x12c83dc: b.eq            #0x12c83e8
    //     0x12c83e0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12c83e4: stur            x2, [x0, #7]
    // 0x12c83e8: mov             x2, x0
    // 0x12c83ec: r1 = _ConstMap len:16375
    //     0x12c83ec: add             x1, PP, #0x80, lsl #12  ; [pp+0x805e8] Map<int, CharacterCategory>(16375)
    //     0x12c83f0: ldr             x1, [x1, #0x5e8]
    // 0x12c83f4: r0 = []()
    //     0x12c83f4: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x12c83f8: r16 = Instance_CharacterCategory
    //     0x12c83f8: add             x16, PP, #0x80, lsl #12  ; [pp+0x805f0] Obj!CharacterCategory@12c67e1
    //     0x12c83fc: ldr             x16, [x16, #0x5f0]
    // 0x12c8400: cmp             w0, w16
    // 0x12c8404: b.eq            #0x12c8428
    // 0x12c8408: r16 = Instance_CharacterCategory
    //     0x12c8408: add             x16, PP, #0x80, lsl #12  ; [pp+0x805f8] Obj!CharacterCategory@12c67c1
    //     0x12c840c: ldr             x16, [x16, #0x5f8]
    // 0x12c8410: cmp             w0, w16
    // 0x12c8414: b.eq            #0x12c8428
    // 0x12c8418: r16 = Instance_CharacterCategory
    //     0x12c8418: add             x16, PP, #0x80, lsl #12  ; [pp+0x80600] Obj!CharacterCategory@12c67a1
    //     0x12c841c: ldr             x16, [x16, #0x600]
    // 0x12c8420: cmp             w0, w16
    // 0x12c8424: b.ne            #0x12c843c
    // 0x12c8428: r0 = Instance_ShapeJoiningType
    //     0x12c8428: add             x0, PP, #0x80, lsl #12  ; [pp+0x805d8] Obj!ShapeJoiningType@12c6dc1
    //     0x12c842c: ldr             x0, [x0, #0x5d8]
    // 0x12c8430: LeaveFrame
    //     0x12c8430: mov             SP, fp
    //     0x12c8434: ldp             fp, lr, [SP], #0x10
    // 0x12c8438: ret
    //     0x12c8438: ret             
    // 0x12c843c: r0 = Instance_ShapeJoiningType
    //     0x12c843c: add             x0, PP, #0x80, lsl #12  ; [pp+0x80598] Obj!ShapeJoiningType@12c6e61
    //     0x12c8440: ldr             x0, [x0, #0x598]
    // 0x12c8444: LeaveFrame
    //     0x12c8444: mov             SP, fp
    //     0x12c8448: ldp             fp, lr, [SP], #0x10
    // 0x12c844c: ret
    //     0x12c844c: ret             
    // 0x12c8450: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c8450: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c8454: b               #0x12c7788
  }
  static _ _calculateEmbeddingLevel(/* No info */) {
    // ** addr: 0x12c8458, size: 0x120
    // 0x12c8458: EnterFrame
    //     0x12c8458: stp             fp, lr, [SP, #-0x10]!
    //     0x12c845c: mov             fp, SP
    // 0x12c8460: AllocStack(0x18)
    //     0x12c8460: sub             SP, SP, #0x18
    // 0x12c8464: CheckStackOverflow
    //     0x12c8464: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c8468: cmp             SP, x16
    //     0x12c846c: b.ls            #0x12c8568
    // 0x12c8470: LoadField: r0 = r1->field_7
    //     0x12c8470: ldur            w0, [x1, #7]
    // 0x12c8474: DecompressPointer r0
    //     0x12c8474: add             x0, x0, HEAP, lsl #32
    // 0x12c8478: stur            x0, [fp, #-0x18]
    // 0x12c847c: LoadField: r1 = r0->field_b
    //     0x12c847c: ldur            w1, [x0, #0xb]
    // 0x12c8480: r3 = LoadInt32Instr(r1)
    //     0x12c8480: sbfx            x3, x1, #1, #0x1f
    // 0x12c8484: stur            x3, [fp, #-0x10]
    // 0x12c8488: r1 = 0
    //     0x12c8488: mov             x1, #0
    // 0x12c848c: CheckStackOverflow
    //     0x12c848c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c8490: cmp             SP, x16
    //     0x12c8494: b.ls            #0x12c8570
    // 0x12c8498: LoadField: r2 = r0->field_b
    //     0x12c8498: ldur            w2, [x0, #0xb]
    // 0x12c849c: r4 = LoadInt32Instr(r2)
    //     0x12c849c: sbfx            x4, x2, #1, #0x1f
    // 0x12c84a0: cmp             x3, x4
    // 0x12c84a4: b.ne            #0x12c854c
    // 0x12c84a8: cmp             x1, x4
    // 0x12c84ac: b.ge            #0x12c853c
    // 0x12c84b0: LoadField: r2 = r0->field_f
    //     0x12c84b0: ldur            w2, [x0, #0xf]
    // 0x12c84b4: DecompressPointer r2
    //     0x12c84b4: add             x2, x2, HEAP, lsl #32
    // 0x12c84b8: ArrayLoad: r4 = r2[r1]  ; Unknown_4
    //     0x12c84b8: add             x16, x2, x1, lsl #2
    //     0x12c84bc: ldur            w4, [x16, #0xf]
    // 0x12c84c0: DecompressPointer r4
    //     0x12c84c0: add             x4, x4, HEAP, lsl #32
    // 0x12c84c4: add             x5, x1, #1
    // 0x12c84c8: mov             x2, x4
    // 0x12c84cc: stur            x5, [fp, #-8]
    // 0x12c84d0: r1 = _ConstMap len:5850
    //     0x12c84d0: add             x1, PP, #0x80, lsl #12  ; [pp+0x80460] Map<int, CharacterType>(5850)
    //     0x12c84d4: ldr             x1, [x1, #0x460]
    // 0x12c84d8: r0 = []()
    //     0x12c84d8: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x12c84dc: cmp             w0, NULL
    // 0x12c84e0: b.ne            #0x12c84ec
    // 0x12c84e4: r0 = Instance_CharacterType
    //     0x12c84e4: add             x0, PP, #0x80, lsl #12  ; [pp+0x804b8] Obj!CharacterType@12c6ee1
    //     0x12c84e8: ldr             x0, [x0, #0x4b8]
    // 0x12c84ec: r16 = Instance_CharacterType
    //     0x12c84ec: add             x16, PP, #0x80, lsl #12  ; [pp+0x804d0] Obj!CharacterType@12c7061
    //     0x12c84f0: ldr             x16, [x16, #0x4d0]
    // 0x12c84f4: cmp             w0, w16
    // 0x12c84f8: b.eq            #0x12c8534
    // 0x12c84fc: r16 = Instance_CharacterType
    //     0x12c84fc: add             x16, PP, #0x80, lsl #12  ; [pp+0x80558] Obj!CharacterType@12c7001
    //     0x12c8500: ldr             x16, [x16, #0x558]
    // 0x12c8504: cmp             w0, w16
    // 0x12c8508: b.eq            #0x12c8534
    // 0x12c850c: r16 = Instance_CharacterType
    //     0x12c850c: add             x16, PP, #0x80, lsl #12  ; [pp+0x804b8] Obj!CharacterType@12c6ee1
    //     0x12c8510: ldr             x16, [x16, #0x4b8]
    // 0x12c8514: cmp             w0, w16
    // 0x12c8518: b.eq            #0x12c852c
    // 0x12c851c: ldur            x1, [fp, #-8]
    // 0x12c8520: ldur            x0, [fp, #-0x18]
    // 0x12c8524: ldur            x3, [fp, #-0x10]
    // 0x12c8528: b               #0x12c848c
    // 0x12c852c: r0 = 0
    //     0x12c852c: mov             x0, #0
    // 0x12c8530: b               #0x12c8540
    // 0x12c8534: r0 = 1
    //     0x12c8534: mov             x0, #1
    // 0x12c8538: b               #0x12c8540
    // 0x12c853c: r0 = 0
    //     0x12c853c: mov             x0, #0
    // 0x12c8540: LeaveFrame
    //     0x12c8540: mov             SP, fp
    //     0x12c8544: ldp             fp, lr, [SP], #0x10
    // 0x12c8548: ret
    //     0x12c8548: ret             
    // 0x12c854c: r0 = ConcurrentModificationError()
    //     0x12c854c: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x12c8550: mov             x1, x0
    // 0x12c8554: ldur            x0, [fp, #-0x18]
    // 0x12c8558: StoreField: r1->field_b = r0
    //     0x12c8558: stur            w0, [x1, #0xb]
    // 0x12c855c: mov             x0, x1
    // 0x12c8560: r0 = Throw()
    //     0x12c8560: bl              #0x13ddb2c  ; ThrowStub
    // 0x12c8564: brk             #0
    // 0x12c8568: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c8568: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c856c: b               #0x12c8470
    // 0x12c8570: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c8570: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c8574: b               #0x12c8498
  }
  static _ getDecompositionType(/* No info */) {
    // ** addr: 0x12c8cb4, size: 0x50
    // 0x12c8cb4: EnterFrame
    //     0x12c8cb4: stp             fp, lr, [SP, #-0x10]!
    //     0x12c8cb8: mov             fp, SP
    // 0x12c8cbc: mov             x2, x1
    // 0x12c8cc0: CheckStackOverflow
    //     0x12c8cc0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c8cc4: cmp             SP, x16
    //     0x12c8cc8: b.ls            #0x12c8cfc
    // 0x12c8ccc: r0 = BoxInt64Instr(r2)
    //     0x12c8ccc: sbfiz           x0, x2, #1, #0x1f
    //     0x12c8cd0: cmp             x2, x0, asr #1
    //     0x12c8cd4: b.eq            #0x12c8ce0
    //     0x12c8cd8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12c8cdc: stur            x2, [x0, #7]
    // 0x12c8ce0: mov             x2, x0
    // 0x12c8ce4: r1 = _ConstMap len:2390
    //     0x12c8ce4: add             x1, PP, #0x80, lsl #12  ; [pp+0x80618] Map<int, DecompositionType>(2390)
    //     0x12c8ce8: ldr             x1, [x1, #0x618]
    // 0x12c8cec: r0 = []()
    //     0x12c8cec: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x12c8cf0: LeaveFrame
    //     0x12c8cf0: mov             SP, fp
    //     0x12c8cf4: ldp             fp, lr, [SP], #0x10
    // 0x12c8cf8: ret
    //     0x12c8cf8: ret             
    // 0x12c8cfc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c8cfc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c8d00: b               #0x12c8ccc
  }
  static _ compose(/* No info */) {
    // ** addr: 0x12c8d04, size: 0x58
    // 0x12c8d04: EnterFrame
    //     0x12c8d04: stp             fp, lr, [SP, #-0x10]!
    //     0x12c8d08: mov             fp, SP
    // 0x12c8d0c: mov             x2, x1
    // 0x12c8d10: CheckStackOverflow
    //     0x12c8d10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c8d14: cmp             SP, x16
    //     0x12c8d18: b.ls            #0x12c8d54
    // 0x12c8d1c: r1 = _ConstMap len:3115
    //     0x12c8d1c: add             x1, PP, #0x80, lsl #12  ; [pp+0x80620] Map<String, int>(3115)
    //     0x12c8d20: ldr             x1, [x1, #0x620]
    // 0x12c8d24: r0 = []()
    //     0x12c8d24: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x12c8d28: cmp             w0, NULL
    // 0x12c8d2c: b.ne            #0x12c8d38
    // 0x12c8d30: r0 = 65535
    //     0x12c8d30: mov             x0, #0xffff
    // 0x12c8d34: b               #0x12c8d48
    // 0x12c8d38: r1 = LoadInt32Instr(r0)
    //     0x12c8d38: sbfx            x1, x0, #1, #0x1f
    //     0x12c8d3c: tbz             w0, #0, #0x12c8d44
    //     0x12c8d40: ldur            x1, [x0, #7]
    // 0x12c8d44: mov             x0, x1
    // 0x12c8d48: LeaveFrame
    //     0x12c8d48: mov             SP, fp
    //     0x12c8d4c: ldp             fp, lr, [SP], #0x10
    // 0x12c8d50: ret
    //     0x12c8d50: ret             
    // 0x12c8d54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c8d54: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c8d58: b               #0x12c8d1c
  }
  static _ _getCanonicalClass(/* No info */) {
    // ** addr: 0x12c8d68, size: 0x60
    // 0x12c8d68: EnterFrame
    //     0x12c8d68: stp             fp, lr, [SP, #-0x10]!
    //     0x12c8d6c: mov             fp, SP
    // 0x12c8d70: mov             x2, x1
    // 0x12c8d74: CheckStackOverflow
    //     0x12c8d74: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c8d78: cmp             SP, x16
    //     0x12c8d7c: b.ls            #0x12c8dc0
    // 0x12c8d80: r0 = BoxInt64Instr(r2)
    //     0x12c8d80: sbfiz           x0, x2, #1, #0x1f
    //     0x12c8d84: cmp             x2, x0, asr #1
    //     0x12c8d88: b.eq            #0x12c8d94
    //     0x12c8d8c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12c8d90: stur            x2, [x0, #7]
    // 0x12c8d94: mov             x2, x0
    // 0x12c8d98: r1 = _ConstMap len:642
    //     0x12c8d98: add             x1, PP, #0x80, lsl #12  ; [pp+0x80610] Map<int, _CanonicalClass>(642)
    //     0x12c8d9c: ldr             x1, [x1, #0x610]
    // 0x12c8da0: r0 = []()
    //     0x12c8da0: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x12c8da4: cmp             w0, NULL
    // 0x12c8da8: b.ne            #0x12c8db4
    // 0x12c8dac: r0 = Instance__CanonicalClass
    //     0x12c8dac: add             x0, PP, #0x80, lsl #12  ; [pp+0x80608] Obj!_CanonicalClass@12a0401
    //     0x12c8db0: ldr             x0, [x0, #0x608]
    // 0x12c8db4: LeaveFrame
    //     0x12c8db4: mov             SP, fp
    //     0x12c8db8: ldp             fp, lr, [SP], #0x10
    // 0x12c8dbc: ret
    //     0x12c8dbc: ret             
    // 0x12c8dc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c8dc0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c8dc4: b               #0x12c8d80
  }
  static _ _getRecursiveDecomposition(/* No info */) {
    // ** addr: 0x12c91c0, size: 0x1ac
    // 0x12c91c0: EnterFrame
    //     0x12c91c0: stp             fp, lr, [SP, #-0x10]!
    //     0x12c91c4: mov             fp, SP
    // 0x12c91c8: AllocStack(0x38)
    //     0x12c91c8: sub             SP, SP, #0x38
    // 0x12c91cc: SetupParameters(dynamic _ /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x12c91cc: mov             x0, x2
    //     0x12c91d0: stur            x2, [fp, #-0x10]
    //     0x12c91d4: mov             x2, x1
    //     0x12c91d8: stur            x1, [fp, #-8]
    //     0x12c91dc: stur            x3, [fp, #-0x18]
    // 0x12c91e0: CheckStackOverflow
    //     0x12c91e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c91e4: cmp             SP, x16
    //     0x12c91e8: b.ls            #0x12c935c
    // 0x12c91ec: mov             x1, x0
    // 0x12c91f0: r0 = getDecompositionMapping()
    //     0x12c91f0: bl              #0x12c936c  ; [package:bidi/bidi.dart] ::getDecompositionMapping
    // 0x12c91f4: stur            x0, [fp, #-0x20]
    // 0x12c91f8: cmp             w0, NULL
    // 0x12c91fc: b.eq            #0x12c92bc
    // 0x12c9200: ldur            x2, [fp, #-8]
    // 0x12c9204: tbnz            w2, #4, #0x12c9218
    // 0x12c9208: ldur            x1, [fp, #-0x10]
    // 0x12c920c: r0 = getDecompositionType()
    //     0x12c920c: bl              #0x12c8cb4  ; [package:bidi/bidi.dart] ::getDecompositionType
    // 0x12c9210: cmp             w0, NULL
    // 0x12c9214: b.ne            #0x12c92bc
    // 0x12c9218: r2 = 0
    //     0x12c9218: mov             x2, #0
    // 0x12c921c: ldur            x1, [fp, #-0x20]
    // 0x12c9220: stur            x2, [fp, #-0x28]
    // 0x12c9224: CheckStackOverflow
    //     0x12c9224: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c9228: cmp             SP, x16
    //     0x12c922c: b.ls            #0x12c9364
    // 0x12c9230: r0 = LoadClassIdInstr(r1)
    //     0x12c9230: ldur            x0, [x1, #-1]
    //     0x12c9234: ubfx            x0, x0, #0xc, #0x14
    // 0x12c9238: str             x1, [SP]
    // 0x12c923c: r0 = GDT[cid_x0 + 0xf078]()
    //     0x12c923c: mov             x17, #0xf078
    //     0x12c9240: add             lr, x0, x17
    //     0x12c9244: ldr             lr, [x21, lr, lsl #3]
    //     0x12c9248: blr             lr
    // 0x12c924c: r1 = LoadInt32Instr(r0)
    //     0x12c924c: sbfx            x1, x0, #1, #0x1f
    //     0x12c9250: tbz             w0, #0, #0x12c9258
    //     0x12c9254: ldur            x1, [x0, #7]
    // 0x12c9258: ldur            x2, [fp, #-0x28]
    // 0x12c925c: cmp             x2, x1
    // 0x12c9260: b.ge            #0x12c934c
    // 0x12c9264: ldur            x3, [fp, #-0x20]
    // 0x12c9268: r0 = BoxInt64Instr(r2)
    //     0x12c9268: sbfiz           x0, x2, #1, #0x1f
    //     0x12c926c: cmp             x2, x0, asr #1
    //     0x12c9270: b.eq            #0x12c927c
    //     0x12c9274: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12c9278: stur            x2, [x0, #7]
    // 0x12c927c: r1 = LoadClassIdInstr(r3)
    //     0x12c927c: ldur            x1, [x3, #-1]
    //     0x12c9280: ubfx            x1, x1, #0xc, #0x14
    // 0x12c9284: stp             x0, x3, [SP]
    // 0x12c9288: mov             x0, x1
    // 0x12c928c: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x12c928c: sub             lr, x0, #0xdfd
    //     0x12c9290: ldr             lr, [x21, lr, lsl #3]
    //     0x12c9294: blr             lr
    // 0x12c9298: r2 = LoadInt32Instr(r0)
    //     0x12c9298: sbfx            x2, x0, #1, #0x1f
    //     0x12c929c: tbz             w0, #0, #0x12c92a4
    //     0x12c92a0: ldur            x2, [x0, #7]
    // 0x12c92a4: ldur            x1, [fp, #-8]
    // 0x12c92a8: ldur            x3, [fp, #-0x18]
    // 0x12c92ac: r0 = _getRecursiveDecomposition()
    //     0x12c92ac: bl              #0x12c91c0  ; [package:bidi/bidi.dart] ::_getRecursiveDecomposition
    // 0x12c92b0: ldur            x0, [fp, #-0x28]
    // 0x12c92b4: add             x2, x0, #1
    // 0x12c92b8: b               #0x12c921c
    // 0x12c92bc: ldur            x0, [fp, #-0x18]
    // 0x12c92c0: LoadField: r1 = r0->field_b
    //     0x12c92c0: ldur            w1, [x0, #0xb]
    // 0x12c92c4: LoadField: r2 = r0->field_f
    //     0x12c92c4: ldur            w2, [x0, #0xf]
    // 0x12c92c8: DecompressPointer r2
    //     0x12c92c8: add             x2, x2, HEAP, lsl #32
    // 0x12c92cc: LoadField: r3 = r2->field_b
    //     0x12c92cc: ldur            w3, [x2, #0xb]
    // 0x12c92d0: r2 = LoadInt32Instr(r1)
    //     0x12c92d0: sbfx            x2, x1, #1, #0x1f
    // 0x12c92d4: stur            x2, [fp, #-0x28]
    // 0x12c92d8: r1 = LoadInt32Instr(r3)
    //     0x12c92d8: sbfx            x1, x3, #1, #0x1f
    // 0x12c92dc: cmp             x2, x1
    // 0x12c92e0: b.ne            #0x12c92ec
    // 0x12c92e4: mov             x1, x0
    // 0x12c92e8: r0 = _growToNextCapacity()
    //     0x12c92e8: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x12c92ec: ldur            x4, [fp, #-0x10]
    // 0x12c92f0: ldur            x2, [fp, #-0x18]
    // 0x12c92f4: ldur            x3, [fp, #-0x28]
    // 0x12c92f8: add             x5, x3, #1
    // 0x12c92fc: lsl             x6, x5, #1
    // 0x12c9300: StoreField: r2->field_b = r6
    //     0x12c9300: stur            w6, [x2, #0xb]
    // 0x12c9304: LoadField: r5 = r2->field_f
    //     0x12c9304: ldur            w5, [x2, #0xf]
    // 0x12c9308: DecompressPointer r5
    //     0x12c9308: add             x5, x5, HEAP, lsl #32
    // 0x12c930c: r0 = BoxInt64Instr(r4)
    //     0x12c930c: sbfiz           x0, x4, #1, #0x1f
    //     0x12c9310: cmp             x4, x0, asr #1
    //     0x12c9314: b.eq            #0x12c9320
    //     0x12c9318: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12c931c: stur            x4, [x0, #7]
    // 0x12c9320: mov             x1, x5
    // 0x12c9324: ArrayStore: r1[r3] = r0  ; List_4
    //     0x12c9324: add             x25, x1, x3, lsl #2
    //     0x12c9328: add             x25, x25, #0xf
    //     0x12c932c: str             w0, [x25]
    //     0x12c9330: tbz             w0, #0, #0x12c934c
    //     0x12c9334: ldurb           w16, [x1, #-1]
    //     0x12c9338: ldurb           w17, [x0, #-1]
    //     0x12c933c: and             x16, x17, x16, lsr #2
    //     0x12c9340: tst             x16, HEAP, lsr #32
    //     0x12c9344: b.eq            #0x12c934c
    //     0x12c9348: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12c934c: r0 = Null
    //     0x12c934c: mov             x0, NULL
    // 0x12c9350: LeaveFrame
    //     0x12c9350: mov             SP, fp
    //     0x12c9354: ldp             fp, lr, [SP], #0x10
    // 0x12c9358: ret
    //     0x12c9358: ret             
    // 0x12c935c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c935c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c9360: b               #0x12c91ec
    // 0x12c9364: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c9364: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c9368: b               #0x12c9230
  }
  static _ getDecompositionMapping(/* No info */) {
    // ** addr: 0x12c936c, size: 0x50
    // 0x12c936c: EnterFrame
    //     0x12c936c: stp             fp, lr, [SP, #-0x10]!
    //     0x12c9370: mov             fp, SP
    // 0x12c9374: mov             x2, x1
    // 0x12c9378: CheckStackOverflow
    //     0x12c9378: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c937c: cmp             SP, x16
    //     0x12c9380: b.ls            #0x12c93b4
    // 0x12c9384: r0 = BoxInt64Instr(r2)
    //     0x12c9384: sbfiz           x0, x2, #1, #0x1f
    //     0x12c9388: cmp             x2, x0, asr #1
    //     0x12c938c: b.eq            #0x12c9398
    //     0x12c9390: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12c9394: stur            x2, [x0, #7]
    // 0x12c9398: mov             x2, x0
    // 0x12c939c: r1 = _ConstMap len:3883
    //     0x12c939c: add             x1, PP, #0x80, lsl #12  ; [pp+0x80628] Map<int, List<int>>(3883)
    //     0x12c93a0: ldr             x1, [x1, #0x628]
    // 0x12c93a4: r0 = []()
    //     0x12c93a4: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x12c93a8: LeaveFrame
    //     0x12c93a8: mov             SP, fp
    //     0x12c93ac: ldp             fp, lr, [SP], #0x10
    // 0x12c93b0: ret
    //     0x12c93b0: ret             
    // 0x12c93b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c93b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c93b8: b               #0x12c9384
  }
}

// class id: 3607, size: 0x10, field offset: 0x8
class _Stack<X0> extends Object {
}

// class id: 3608, size: 0x18, field offset: 0x8
//   const constructor, 
class Normalization extends Object {

  _ _performShaping(/* No info */) {
    // ** addr: 0x12c60e0, size: 0x1690
    // 0x12c60e0: EnterFrame
    //     0x12c60e0: stp             fp, lr, [SP, #-0x10]!
    //     0x12c60e4: mov             fp, SP
    // 0x12c60e8: AllocStack(0x68)
    //     0x12c60e8: sub             SP, SP, #0x68
    // 0x12c60ec: SetupParameters(Normalization this /* r1 => r0, fp-0x18 */)
    //     0x12c60ec: mov             x0, x1
    //     0x12c60f0: stur            x1, [fp, #-0x18]
    // 0x12c60f4: CheckStackOverflow
    //     0x12c60f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c60f8: cmp             SP, x16
    //     0x12c60fc: b.ls            #0x12c75ec
    // 0x12c6100: LoadField: r3 = r0->field_7
    //     0x12c6100: ldur            w3, [x0, #7]
    // 0x12c6104: DecompressPointer r3
    //     0x12c6104: add             x3, x3, HEAP, lsl #32
    // 0x12c6108: stur            x3, [fp, #-0x10]
    // 0x12c610c: LoadField: r4 = r3->field_b
    //     0x12c610c: ldur            w4, [x3, #0xb]
    // 0x12c6110: mov             x2, x4
    // 0x12c6114: stur            x4, [fp, #-8]
    // 0x12c6118: r1 = <LetterForm>
    //     0x12c6118: add             x1, PP, #0x80, lsl #12  ; [pp+0x80588] TypeArguments: <LetterForm>
    //     0x12c611c: ldr             x1, [x1, #0x588]
    // 0x12c6120: r0 = AllocateArray()
    //     0x12c6120: bl              #0x13df928  ; AllocateArrayStub
    // 0x12c6124: mov             x2, x0
    // 0x12c6128: ldur            x0, [fp, #-8]
    // 0x12c612c: stur            x2, [fp, #-0x40]
    // 0x12c6130: r3 = LoadInt32Instr(r0)
    //     0x12c6130: sbfx            x3, x0, #1, #0x1f
    // 0x12c6134: stur            x3, [fp, #-0x38]
    // 0x12c6138: r0 = 0
    //     0x12c6138: mov             x0, #0
    // 0x12c613c: CheckStackOverflow
    //     0x12c613c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c6140: cmp             SP, x16
    //     0x12c6144: b.ls            #0x12c75f4
    // 0x12c6148: cmp             x0, x3
    // 0x12c614c: b.ge            #0x12c616c
    // 0x12c6150: add             x1, x2, x0, lsl #2
    // 0x12c6154: r16 = Instance_LetterForm
    //     0x12c6154: add             x16, PP, #0x80, lsl #12  ; [pp+0x80590] Obj!LetterForm@12c6ba1
    //     0x12c6158: ldr             x16, [x16, #0x590]
    // 0x12c615c: StoreField: r1->field_f = r16
    //     0x12c615c: stur            w16, [x1, #0xf]
    // 0x12c6160: add             x1, x0, #1
    // 0x12c6164: mov             x0, x1
    // 0x12c6168: b               #0x12c613c
    // 0x12c616c: r7 = Instance_ShapeJoiningType
    //     0x12c616c: add             x7, PP, #0x80, lsl #12  ; [pp+0x80598] Obj!ShapeJoiningType@12c6e61
    //     0x12c6170: ldr             x7, [x7, #0x598]
    // 0x12c6174: r6 = Instance_LetterForm
    //     0x12c6174: add             x6, PP, #0x80, lsl #12  ; [pp+0x805a0] Obj!LetterForm@12c6b81
    //     0x12c6178: ldr             x6, [x6, #0x5a0]
    // 0x12c617c: r5 = 0
    //     0x12c617c: mov             x5, #0
    // 0x12c6180: r4 = 0
    //     0x12c6180: mov             x4, #0
    // 0x12c6184: ldur            x0, [fp, #-0x10]
    // 0x12c6188: stur            x7, [fp, #-8]
    // 0x12c618c: stur            x6, [fp, #-0x20]
    // 0x12c6190: stur            x5, [fp, #-0x28]
    // 0x12c6194: stur            x4, [fp, #-0x30]
    // 0x12c6198: CheckStackOverflow
    //     0x12c6198: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c619c: cmp             SP, x16
    //     0x12c61a0: b.ls            #0x12c75fc
    // 0x12c61a4: LoadField: r1 = r0->field_b
    //     0x12c61a4: ldur            w1, [x0, #0xb]
    // 0x12c61a8: r8 = LoadInt32Instr(r1)
    //     0x12c61a8: sbfx            x8, x1, #1, #0x1f
    // 0x12c61ac: cmp             x4, x8
    // 0x12c61b0: b.ge            #0x12c63dc
    // 0x12c61b4: LoadField: r1 = r0->field_f
    //     0x12c61b4: ldur            w1, [x0, #0xf]
    // 0x12c61b8: DecompressPointer r1
    //     0x12c61b8: add             x1, x1, HEAP, lsl #32
    // 0x12c61bc: ArrayLoad: r8 = r1[r4]  ; Unknown_4
    //     0x12c61bc: add             x16, x1, x4, lsl #2
    //     0x12c61c0: ldur            w8, [x16, #0xf]
    // 0x12c61c4: DecompressPointer r8
    //     0x12c61c4: add             x8, x8, HEAP, lsl #32
    // 0x12c61c8: r1 = LoadInt32Instr(r8)
    //     0x12c61c8: sbfx            x1, x8, #1, #0x1f
    //     0x12c61cc: tbz             w8, #0, #0x12c61d4
    //     0x12c61d0: ldur            x1, [x8, #7]
    // 0x12c61d4: r0 = getShapeJoiningType()
    //     0x12c61d4: bl              #0x12c7770  ; [package:bidi/bidi.dart] ::getShapeJoiningType
    // 0x12c61d8: mov             x2, x0
    // 0x12c61dc: r16 = Instance_ShapeJoiningType
    //     0x12c61dc: add             x16, PP, #0x80, lsl #12  ; [pp+0x805a8] Obj!ShapeJoiningType@12c6e41
    //     0x12c61e0: ldr             x16, [x16, #0x5a8]
    // 0x12c61e4: cmp             w2, w16
    // 0x12c61e8: b.eq            #0x12c620c
    // 0x12c61ec: r16 = Instance_ShapeJoiningType
    //     0x12c61ec: add             x16, PP, #0x80, lsl #12  ; [pp+0x805b0] Obj!ShapeJoiningType@12c6e21
    //     0x12c61f0: ldr             x16, [x16, #0x5b0]
    // 0x12c61f4: cmp             w2, w16
    // 0x12c61f8: b.eq            #0x12c620c
    // 0x12c61fc: r16 = Instance_ShapeJoiningType
    //     0x12c61fc: add             x16, PP, #0x80, lsl #12  ; [pp+0x805b8] Obj!ShapeJoiningType@12c6e01
    //     0x12c6200: ldr             x16, [x16, #0x5b8]
    // 0x12c6204: cmp             w2, w16
    // 0x12c6208: b.ne            #0x12c6340
    // 0x12c620c: ldur            x3, [fp, #-8]
    // 0x12c6210: r16 = Instance_ShapeJoiningType
    //     0x12c6210: add             x16, PP, #0x80, lsl #12  ; [pp+0x805c0] Obj!ShapeJoiningType@12c6de1
    //     0x12c6214: ldr             x16, [x16, #0x5c0]
    // 0x12c6218: cmp             w3, w16
    // 0x12c621c: b.eq            #0x12c6240
    // 0x12c6220: r16 = Instance_ShapeJoiningType
    //     0x12c6220: add             x16, PP, #0x80, lsl #12  ; [pp+0x805b0] Obj!ShapeJoiningType@12c6e21
    //     0x12c6224: ldr             x16, [x16, #0x5b0]
    // 0x12c6228: cmp             w3, w16
    // 0x12c622c: b.eq            #0x12c6240
    // 0x12c6230: r16 = Instance_ShapeJoiningType
    //     0x12c6230: add             x16, PP, #0x80, lsl #12  ; [pp+0x805b8] Obj!ShapeJoiningType@12c6e01
    //     0x12c6234: ldr             x16, [x16, #0x5b8]
    // 0x12c6238: cmp             w3, w16
    // 0x12c623c: b.ne            #0x12c632c
    // 0x12c6240: ldur            x6, [fp, #-0x20]
    // 0x12c6244: r16 = Instance_LetterForm
    //     0x12c6244: add             x16, PP, #0x80, lsl #12  ; [pp+0x805a0] Obj!LetterForm@12c6b81
    //     0x12c6248: ldr             x16, [x16, #0x5a0]
    // 0x12c624c: cmp             w6, w16
    // 0x12c6250: b.ne            #0x12c62ac
    // 0x12c6254: r16 = Instance_ShapeJoiningType
    //     0x12c6254: add             x16, PP, #0x80, lsl #12  ; [pp+0x805b0] Obj!ShapeJoiningType@12c6e21
    //     0x12c6258: ldr             x16, [x16, #0x5b0]
    // 0x12c625c: cmp             w3, w16
    // 0x12c6260: b.eq            #0x12c6274
    // 0x12c6264: r16 = Instance_ShapeJoiningType
    //     0x12c6264: add             x16, PP, #0x80, lsl #12  ; [pp+0x805c0] Obj!ShapeJoiningType@12c6de1
    //     0x12c6268: ldr             x16, [x16, #0x5c0]
    // 0x12c626c: cmp             w3, w16
    // 0x12c6270: b.ne            #0x12c62a0
    // 0x12c6274: ldur            x5, [fp, #-0x28]
    // 0x12c6278: ldur            x8, [fp, #-0x40]
    // 0x12c627c: ldur            x0, [fp, #-0x38]
    // 0x12c6280: mov             x1, x5
    // 0x12c6284: cmp             x1, x0
    // 0x12c6288: b.hs            #0x12c7604
    // 0x12c628c: add             x0, x8, x5, lsl #2
    // 0x12c6290: r16 = Instance_LetterForm
    //     0x12c6290: add             x16, PP, #0x80, lsl #12  ; [pp+0x80590] Obj!LetterForm@12c6ba1
    //     0x12c6294: ldr             x16, [x16, #0x590]
    // 0x12c6298: StoreField: r0->field_f = r16
    //     0x12c6298: stur            w16, [x0, #0xf]
    // 0x12c629c: b               #0x12c62f4
    // 0x12c62a0: ldur            x5, [fp, #-0x28]
    // 0x12c62a4: ldur            x8, [fp, #-0x40]
    // 0x12c62a8: b               #0x12c62b4
    // 0x12c62ac: ldur            x5, [fp, #-0x28]
    // 0x12c62b0: ldur            x8, [fp, #-0x40]
    // 0x12c62b4: r16 = Instance_LetterForm
    //     0x12c62b4: add             x16, PP, #0x80, lsl #12  ; [pp+0x805c8] Obj!LetterForm@12c6b61
    //     0x12c62b8: ldr             x16, [x16, #0x5c8]
    // 0x12c62bc: cmp             w6, w16
    // 0x12c62c0: b.ne            #0x12c62f4
    // 0x12c62c4: r16 = Instance_ShapeJoiningType
    //     0x12c62c4: add             x16, PP, #0x80, lsl #12  ; [pp+0x805b0] Obj!ShapeJoiningType@12c6e21
    //     0x12c62c8: ldr             x16, [x16, #0x5b0]
    // 0x12c62cc: cmp             w3, w16
    // 0x12c62d0: b.ne            #0x12c62f4
    // 0x12c62d4: ldur            x0, [fp, #-0x38]
    // 0x12c62d8: mov             x1, x5
    // 0x12c62dc: cmp             x1, x0
    // 0x12c62e0: b.hs            #0x12c7608
    // 0x12c62e4: add             x0, x8, x5, lsl #2
    // 0x12c62e8: r16 = Instance_LetterForm
    //     0x12c62e8: add             x16, PP, #0x80, lsl #12  ; [pp+0x805d0] Obj!LetterForm@12c6b41
    //     0x12c62ec: ldr             x16, [x16, #0x5d0]
    // 0x12c62f0: StoreField: r0->field_f = r16
    //     0x12c62f0: stur            w16, [x0, #0xf]
    // 0x12c62f4: ldur            x9, [fp, #-0x30]
    // 0x12c62f8: ldur            x0, [fp, #-0x38]
    // 0x12c62fc: mov             x1, x9
    // 0x12c6300: cmp             x1, x0
    // 0x12c6304: b.hs            #0x12c760c
    // 0x12c6308: add             x0, x8, x9, lsl #2
    // 0x12c630c: r16 = Instance_LetterForm
    //     0x12c630c: add             x16, PP, #0x80, lsl #12  ; [pp+0x805c8] Obj!LetterForm@12c6b61
    //     0x12c6310: ldr             x16, [x16, #0x5c8]
    // 0x12c6314: StoreField: r0->field_f = r16
    //     0x12c6314: stur            w16, [x0, #0xf]
    // 0x12c6318: mov             x7, x2
    // 0x12c631c: mov             x5, x9
    // 0x12c6320: r6 = Instance_LetterForm
    //     0x12c6320: add             x6, PP, #0x80, lsl #12  ; [pp+0x805c8] Obj!LetterForm@12c6b61
    //     0x12c6324: ldr             x6, [x6, #0x5c8]
    // 0x12c6328: b               #0x12c63cc
    // 0x12c632c: ldur            x6, [fp, #-0x20]
    // 0x12c6330: ldur            x5, [fp, #-0x28]
    // 0x12c6334: ldur            x9, [fp, #-0x30]
    // 0x12c6338: ldur            x8, [fp, #-0x40]
    // 0x12c633c: b               #0x12c6354
    // 0x12c6340: ldur            x3, [fp, #-8]
    // 0x12c6344: ldur            x6, [fp, #-0x20]
    // 0x12c6348: ldur            x5, [fp, #-0x28]
    // 0x12c634c: ldur            x9, [fp, #-0x30]
    // 0x12c6350: ldur            x8, [fp, #-0x40]
    // 0x12c6354: r16 = Instance_ShapeJoiningType
    //     0x12c6354: add             x16, PP, #0x80, lsl #12  ; [pp+0x805d8] Obj!ShapeJoiningType@12c6dc1
    //     0x12c6358: ldr             x16, [x16, #0x5d8]
    // 0x12c635c: cmp             w2, w16
    // 0x12c6360: b.eq            #0x12c6394
    // 0x12c6364: ldur            x0, [fp, #-0x38]
    // 0x12c6368: mov             x1, x9
    // 0x12c636c: cmp             x1, x0
    // 0x12c6370: b.hs            #0x12c7610
    // 0x12c6374: add             x0, x8, x9, lsl #2
    // 0x12c6378: r16 = Instance_LetterForm
    //     0x12c6378: add             x16, PP, #0x80, lsl #12  ; [pp+0x805a0] Obj!LetterForm@12c6b81
    //     0x12c637c: ldr             x16, [x16, #0x5a0]
    // 0x12c6380: StoreField: r0->field_f = r16
    //     0x12c6380: stur            w16, [x0, #0xf]
    // 0x12c6384: mov             x0, x9
    // 0x12c6388: r1 = Instance_LetterForm
    //     0x12c6388: add             x1, PP, #0x80, lsl #12  ; [pp+0x805a0] Obj!LetterForm@12c6b81
    //     0x12c638c: ldr             x1, [x1, #0x5a0]
    // 0x12c6390: b               #0x12c63c0
    // 0x12c6394: ldur            x0, [fp, #-0x38]
    // 0x12c6398: mov             x1, x9
    // 0x12c639c: cmp             x1, x0
    // 0x12c63a0: b.hs            #0x12c7614
    // 0x12c63a4: add             x0, x8, x9, lsl #2
    // 0x12c63a8: r16 = Instance_LetterForm
    //     0x12c63a8: add             x16, PP, #0x80, lsl #12  ; [pp+0x805a0] Obj!LetterForm@12c6b81
    //     0x12c63ac: ldr             x16, [x16, #0x5a0]
    // 0x12c63b0: StoreField: r0->field_f = r16
    //     0x12c63b0: stur            w16, [x0, #0xf]
    // 0x12c63b4: mov             x2, x3
    // 0x12c63b8: mov             x1, x6
    // 0x12c63bc: mov             x0, x5
    // 0x12c63c0: mov             x7, x2
    // 0x12c63c4: mov             x6, x1
    // 0x12c63c8: mov             x5, x0
    // 0x12c63cc: add             x4, x9, #1
    // 0x12c63d0: mov             x2, x8
    // 0x12c63d4: ldur            x3, [fp, #-0x38]
    // 0x12c63d8: b               #0x12c6184
    // 0x12c63dc: ldur            x0, [fp, #-0x18]
    // 0x12c63e0: mov             x8, x2
    // 0x12c63e4: r1 = <int>
    //     0x12c63e4: ldr             x1, [PP, #0x50]  ; [pp+0x50] TypeArguments: <int>
    // 0x12c63e8: r2 = 0
    //     0x12c63e8: mov             x2, #0
    // 0x12c63ec: r0 = _GrowableList()
    //     0x12c63ec: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x12c63f0: mov             x2, x0
    // 0x12c63f4: ldur            x0, [fp, #-0x18]
    // 0x12c63f8: stur            x2, [fp, #-0x60]
    // 0x12c63fc: LoadField: r3 = r0->field_b
    //     0x12c63fc: ldur            w3, [x0, #0xb]
    // 0x12c6400: DecompressPointer r3
    //     0x12c6400: add             x3, x3, HEAP, lsl #32
    // 0x12c6404: stur            x3, [fp, #-0x20]
    // 0x12c6408: r8 = 0
    //     0x12c6408: mov             x8, #0
    // 0x12c640c: r7 = 65535
    //     0x12c640c: mov             x7, #0xffff
    // 0x12c6410: r6 = 0
    //     0x12c6410: mov             x6, #0
    // 0x12c6414: r5 = 0
    //     0x12c6414: mov             x5, #0
    // 0x12c6418: ldur            x4, [fp, #-0x10]
    // 0x12c641c: ldur            x0, [fp, #-0x40]
    // 0x12c6420: stur            x8, [fp, #-0x30]
    // 0x12c6424: stur            x7, [fp, #-0x48]
    // 0x12c6428: stur            x6, [fp, #-0x50]
    // 0x12c642c: stur            x5, [fp, #-0x58]
    // 0x12c6430: CheckStackOverflow
    //     0x12c6430: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c6434: cmp             SP, x16
    //     0x12c6438: b.ls            #0x12c7618
    // 0x12c643c: LoadField: r1 = r4->field_b
    //     0x12c643c: ldur            w1, [x4, #0xb]
    // 0x12c6440: r9 = LoadInt32Instr(r1)
    //     0x12c6440: sbfx            x9, x1, #1, #0x1f
    // 0x12c6444: cmp             x5, x9
    // 0x12c6448: b.ge            #0x12c75dc
    // 0x12c644c: LoadField: r1 = r4->field_f
    //     0x12c644c: ldur            w1, [x4, #0xf]
    // 0x12c6450: DecompressPointer r1
    //     0x12c6450: add             x1, x1, HEAP, lsl #32
    // 0x12c6454: ArrayLoad: r9 = r1[r5]  ; Unknown_4
    //     0x12c6454: add             x16, x1, x5, lsl #2
    //     0x12c6458: ldur            w9, [x16, #0xf]
    // 0x12c645c: DecompressPointer r9
    //     0x12c645c: add             x9, x9, HEAP, lsl #32
    // 0x12c6460: stur            x9, [fp, #-8]
    // 0x12c6464: r10 = LoadInt32Instr(r9)
    //     0x12c6464: sbfx            x10, x9, #1, #0x1f
    //     0x12c6468: tbz             w9, #0, #0x12c6470
    //     0x12c646c: ldur            x10, [x9, #7]
    // 0x12c6470: mov             x1, x10
    // 0x12c6474: stur            x10, [fp, #-0x28]
    // 0x12c6478: r0 = getShapeJoiningType()
    //     0x12c6478: bl              #0x12c7770  ; [package:bidi/bidi.dart] ::getShapeJoiningType
    // 0x12c647c: mov             x1, x0
    // 0x12c6480: ldur            x0, [fp, #-0x48]
    // 0x12c6484: cmp             x0, #0x644
    // 0x12c6488: b.ne            #0x12c64d4
    // 0x12c648c: ldur            x3, [fp, #-0x28]
    // 0x12c6490: cmp             x3, #0x627
    // 0x12c6494: b.eq            #0x12c64d8
    // 0x12c6498: cmp             x3, #0x622
    // 0x12c649c: b.eq            #0x12c64d8
    // 0x12c64a0: cmp             x3, #0x623
    // 0x12c64a4: b.eq            #0x12c64d8
    // 0x12c64a8: cmp             x3, #0x625
    // 0x12c64ac: b.eq            #0x12c64d8
    // 0x12c64b0: r16 = Instance_ShapeJoiningType
    //     0x12c64b0: add             x16, PP, #0x80, lsl #12  ; [pp+0x805d8] Obj!ShapeJoiningType@12c6dc1
    //     0x12c64b4: ldr             x16, [x16, #0x5d8]
    // 0x12c64b8: cmp             w1, w16
    // 0x12c64bc: b.eq            #0x12c64d8
    // 0x12c64c0: ldur            x6, [fp, #-0x30]
    // 0x12c64c4: ldur            x5, [fp, #-0x50]
    // 0x12c64c8: ldur            x4, [fp, #-0x60]
    // 0x12c64cc: r7 = 65535
    //     0x12c64cc: mov             x7, #0xffff
    // 0x12c64d0: b               #0x12c6518
    // 0x12c64d4: ldur            x3, [fp, #-0x28]
    // 0x12c64d8: cmp             x3, #0x644
    // 0x12c64dc: b.ne            #0x12c64fc
    // 0x12c64e0: ldur            x4, [fp, #-0x60]
    // 0x12c64e4: LoadField: r0 = r4->field_b
    //     0x12c64e4: ldur            w0, [x4, #0xb]
    // 0x12c64e8: r1 = LoadInt32Instr(r0)
    //     0x12c64e8: sbfx            x1, x0, #1, #0x1f
    // 0x12c64ec: ldur            x2, [fp, #-0x58]
    // 0x12c64f0: mov             x0, x1
    // 0x12c64f4: mov             x1, x3
    // 0x12c64f8: b               #0x12c650c
    // 0x12c64fc: ldur            x4, [fp, #-0x60]
    // 0x12c6500: ldur            x2, [fp, #-0x30]
    // 0x12c6504: mov             x1, x0
    // 0x12c6508: ldur            x0, [fp, #-0x50]
    // 0x12c650c: mov             x6, x2
    // 0x12c6510: mov             x7, x1
    // 0x12c6514: mov             x5, x0
    // 0x12c6518: stur            x6, [fp, #-0x30]
    // 0x12c651c: stur            x7, [fp, #-0x48]
    // 0x12c6520: stur            x5, [fp, #-0x50]
    // 0x12c6524: cmp             x7, #0x644
    // 0x12c6528: b.ne            #0x12c74b8
    // 0x12c652c: ldur            x8, [fp, #-0x40]
    // 0x12c6530: ldur            x0, [fp, #-0x38]
    // 0x12c6534: mov             x1, x6
    // 0x12c6538: cmp             x1, x0
    // 0x12c653c: b.hs            #0x12c7620
    // 0x12c6540: ArrayLoad: r0 = r8[r6]  ; Unknown_4
    //     0x12c6540: add             x16, x8, x6, lsl #2
    //     0x12c6544: ldur            w0, [x16, #0xf]
    // 0x12c6548: DecompressPointer r0
    //     0x12c6548: add             x0, x0, HEAP, lsl #32
    // 0x12c654c: r16 = Instance_LetterForm
    //     0x12c654c: add             x16, PP, #0x80, lsl #12  ; [pp+0x805d0] Obj!LetterForm@12c6b41
    //     0x12c6550: ldr             x16, [x16, #0x5d0]
    // 0x12c6554: cmp             w0, w16
    // 0x12c6558: b.ne            #0x12c6cfc
    // 0x12c655c: cmp             x3, #0x623
    // 0x12c6560: b.gt            #0x12c6968
    // 0x12c6564: cmp             x3, #0x622
    // 0x12c6568: b.gt            #0x12c67b4
    // 0x12c656c: ldur            x1, [fp, #-8]
    // 0x12c6570: cmp             w1, #0xc44
    // 0x12c6574: b.ne            #0x12c67ac
    // 0x12c6578: ldur            x3, [fp, #-0x20]
    // 0x12c657c: LoadField: r0 = r4->field_b
    //     0x12c657c: ldur            w0, [x4, #0xb]
    // 0x12c6580: r1 = LoadInt32Instr(r0)
    //     0x12c6580: sbfx            x1, x0, #1, #0x1f
    // 0x12c6584: mov             x0, x1
    // 0x12c6588: mov             x1, x5
    // 0x12c658c: cmp             x1, x0
    // 0x12c6590: b.hs            #0x12c7624
    // 0x12c6594: LoadField: r0 = r4->field_f
    //     0x12c6594: ldur            w0, [x4, #0xf]
    // 0x12c6598: DecompressPointer r0
    //     0x12c6598: add             x0, x0, HEAP, lsl #32
    // 0x12c659c: add             x1, x0, x5, lsl #2
    // 0x12c65a0: r16 = 130540
    //     0x12c65a0: mov             x16, #0xfdec
    //     0x12c65a4: movk            x16, #1, lsl #16
    // 0x12c65a8: StoreField: r1->field_f = r16
    //     0x12c65a8: stur            w16, [x1, #0xf]
    // 0x12c65ac: LoadField: r0 = r3->field_b
    //     0x12c65ac: ldur            w0, [x3, #0xb]
    // 0x12c65b0: r2 = LoadInt32Instr(r0)
    //     0x12c65b0: sbfx            x2, x0, #1, #0x1f
    // 0x12c65b4: mov             x0, x2
    // 0x12c65b8: mov             x1, x5
    // 0x12c65bc: cmp             x1, x0
    // 0x12c65c0: b.hs            #0x12c7628
    // 0x12c65c4: LoadField: r9 = r3->field_f
    //     0x12c65c4: ldur            w9, [x3, #0xf]
    // 0x12c65c8: DecompressPointer r9
    //     0x12c65c8: add             x9, x9, HEAP, lsl #32
    // 0x12c65cc: sub             x10, x2, #1
    // 0x12c65d0: cmp             x5, x10
    // 0x12c65d4: b.ge            #0x12c6714
    // 0x12c65d8: add             x11, x5, #1
    // 0x12c65dc: sub             x0, x10, x5
    // 0x12c65e0: cmp             x11, x5
    // 0x12c65e4: b.ge            #0x12c6684
    // 0x12c65e8: add             x1, x11, x0
    // 0x12c65ec: sub             x12, x1, #1
    // 0x12c65f0: add             x1, x5, x0
    // 0x12c65f4: sub             x0, x1, #1
    // 0x12c65f8: mov             x13, x12
    // 0x12c65fc: mov             x12, x0
    // 0x12c6600: CheckStackOverflow
    //     0x12c6600: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c6604: cmp             SP, x16
    //     0x12c6608: b.ls            #0x12c762c
    // 0x12c660c: cmp             x13, x11
    // 0x12c6610: b.lt            #0x12c6714
    // 0x12c6614: mov             x0, x2
    // 0x12c6618: mov             x1, x13
    // 0x12c661c: cmp             x1, x0
    // 0x12c6620: b.hs            #0x12c7634
    // 0x12c6624: ArrayLoad: r14 = r9[r13]  ; Unknown_4
    //     0x12c6624: add             x16, x9, x13, lsl #2
    //     0x12c6628: ldur            w14, [x16, #0xf]
    // 0x12c662c: DecompressPointer r14
    //     0x12c662c: add             x14, x14, HEAP, lsl #32
    // 0x12c6630: mov             x0, x2
    // 0x12c6634: mov             x1, x12
    // 0x12c6638: cmp             x1, x0
    // 0x12c663c: b.hs            #0x12c7638
    // 0x12c6640: mov             x1, x9
    // 0x12c6644: mov             x0, x14
    // 0x12c6648: ArrayStore: r1[r12] = r0  ; List_4
    //     0x12c6648: add             x25, x1, x12, lsl #2
    //     0x12c664c: add             x25, x25, #0xf
    //     0x12c6650: str             w0, [x25]
    //     0x12c6654: tbz             w0, #0, #0x12c6670
    //     0x12c6658: ldurb           w16, [x1, #-1]
    //     0x12c665c: ldurb           w17, [x0, #-1]
    //     0x12c6660: and             x16, x17, x16, lsr #2
    //     0x12c6664: tst             x16, HEAP, lsr #32
    //     0x12c6668: b.eq            #0x12c6670
    //     0x12c666c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12c6670: sub             x0, x13, #1
    // 0x12c6674: sub             x1, x12, #1
    // 0x12c6678: mov             x13, x0
    // 0x12c667c: mov             x12, x1
    // 0x12c6680: b               #0x12c6600
    // 0x12c6684: add             x12, x11, x0
    // 0x12c6688: mov             x13, x11
    // 0x12c668c: mov             x11, x5
    // 0x12c6690: CheckStackOverflow
    //     0x12c6690: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c6694: cmp             SP, x16
    //     0x12c6698: b.ls            #0x12c763c
    // 0x12c669c: cmp             x13, x12
    // 0x12c66a0: b.ge            #0x12c6714
    // 0x12c66a4: mov             x0, x2
    // 0x12c66a8: mov             x1, x13
    // 0x12c66ac: cmp             x1, x0
    // 0x12c66b0: b.hs            #0x12c7644
    // 0x12c66b4: ArrayLoad: r14 = r9[r13]  ; Unknown_4
    //     0x12c66b4: add             x16, x9, x13, lsl #2
    //     0x12c66b8: ldur            w14, [x16, #0xf]
    // 0x12c66bc: DecompressPointer r14
    //     0x12c66bc: add             x14, x14, HEAP, lsl #32
    // 0x12c66c0: mov             x0, x2
    // 0x12c66c4: mov             x1, x11
    // 0x12c66c8: cmp             x1, x0
    // 0x12c66cc: b.hs            #0x12c7648
    // 0x12c66d0: mov             x1, x9
    // 0x12c66d4: mov             x0, x14
    // 0x12c66d8: ArrayStore: r1[r11] = r0  ; List_4
    //     0x12c66d8: add             x25, x1, x11, lsl #2
    //     0x12c66dc: add             x25, x25, #0xf
    //     0x12c66e0: str             w0, [x25]
    //     0x12c66e4: tbz             w0, #0, #0x12c6700
    //     0x12c66e8: ldurb           w16, [x1, #-1]
    //     0x12c66ec: ldurb           w17, [x0, #-1]
    //     0x12c66f0: and             x16, x17, x16, lsr #2
    //     0x12c66f4: tst             x16, HEAP, lsr #32
    //     0x12c66f8: b.eq            #0x12c6700
    //     0x12c66fc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12c6700: add             x0, x13, #1
    // 0x12c6704: add             x1, x11, #1
    // 0x12c6708: mov             x13, x0
    // 0x12c670c: mov             x11, x1
    // 0x12c6710: b               #0x12c6690
    // 0x12c6714: mov             x1, x3
    // 0x12c6718: mov             x2, x10
    // 0x12c671c: r0 = length=()
    //     0x12c671c: bl              #0x9fa1d0  ; [dart:core] _GrowableList::length=
    // 0x12c6720: ldur            x4, [fp, #-0x20]
    // 0x12c6724: LoadField: r0 = r4->field_b
    //     0x12c6724: ldur            w0, [x4, #0xb]
    // 0x12c6728: r1 = LoadInt32Instr(r0)
    //     0x12c6728: sbfx            x1, x0, #1, #0x1f
    // 0x12c672c: mov             x0, x1
    // 0x12c6730: ldur            x1, [fp, #-0x50]
    // 0x12c6734: cmp             x1, x0
    // 0x12c6738: b.hs            #0x12c764c
    // 0x12c673c: LoadField: r2 = r4->field_f
    //     0x12c673c: ldur            w2, [x4, #0xf]
    // 0x12c6740: DecompressPointer r2
    //     0x12c6740: add             x2, x2, HEAP, lsl #32
    // 0x12c6744: ldur            x5, [fp, #-0x50]
    // 0x12c6748: ArrayLoad: r0 = r2[r5]  ; Unknown_4
    //     0x12c6748: add             x16, x2, x5, lsl #2
    //     0x12c674c: ldur            w0, [x16, #0xf]
    // 0x12c6750: DecompressPointer r0
    //     0x12c6750: add             x0, x0, HEAP, lsl #32
    // 0x12c6754: r1 = LoadInt32Instr(r0)
    //     0x12c6754: sbfx            x1, x0, #1, #0x1f
    //     0x12c6758: tbz             w0, #0, #0x12c6760
    //     0x12c675c: ldur            x1, [x0, #7]
    // 0x12c6760: add             x3, x1, #1
    // 0x12c6764: r0 = BoxInt64Instr(r3)
    //     0x12c6764: sbfiz           x0, x3, #1, #0x1f
    //     0x12c6768: cmp             x3, x0, asr #1
    //     0x12c676c: b.eq            #0x12c6778
    //     0x12c6770: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12c6774: stur            x3, [x0, #7]
    // 0x12c6778: mov             x1, x2
    // 0x12c677c: ArrayStore: r1[r5] = r0  ; List_4
    //     0x12c677c: add             x25, x1, x5, lsl #2
    //     0x12c6780: add             x25, x25, #0xf
    //     0x12c6784: str             w0, [x25]
    //     0x12c6788: tbz             w0, #0, #0x12c67a4
    //     0x12c678c: ldurb           w16, [x1, #-1]
    //     0x12c6790: ldurb           w17, [x0, #-1]
    //     0x12c6794: and             x16, x17, x16, lsr #2
    //     0x12c6798: tst             x16, HEAP, lsr #32
    //     0x12c679c: b.eq            #0x12c67a4
    //     0x12c67a0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12c67a4: ldur            x2, [fp, #-0x60]
    // 0x12c67a8: b               #0x12c75c0
    // 0x12c67ac: ldur            x4, [fp, #-0x20]
    // 0x12c67b0: b               #0x12c74b8
    // 0x12c67b4: mov             x3, x4
    // 0x12c67b8: ldur            x4, [fp, #-0x20]
    // 0x12c67bc: LoadField: r0 = r3->field_b
    //     0x12c67bc: ldur            w0, [x3, #0xb]
    // 0x12c67c0: r1 = LoadInt32Instr(r0)
    //     0x12c67c0: sbfx            x1, x0, #1, #0x1f
    // 0x12c67c4: mov             x0, x1
    // 0x12c67c8: mov             x1, x5
    // 0x12c67cc: cmp             x1, x0
    // 0x12c67d0: b.hs            #0x12c7650
    // 0x12c67d4: LoadField: r0 = r3->field_f
    //     0x12c67d4: ldur            w0, [x3, #0xf]
    // 0x12c67d8: DecompressPointer r0
    //     0x12c67d8: add             x0, x0, HEAP, lsl #32
    // 0x12c67dc: add             x1, x0, x5, lsl #2
    // 0x12c67e0: r16 = 130544
    //     0x12c67e0: mov             x16, #0xfdf0
    //     0x12c67e4: movk            x16, #1, lsl #16
    // 0x12c67e8: StoreField: r1->field_f = r16
    //     0x12c67e8: stur            w16, [x1, #0xf]
    // 0x12c67ec: LoadField: r0 = r4->field_b
    //     0x12c67ec: ldur            w0, [x4, #0xb]
    // 0x12c67f0: r2 = LoadInt32Instr(r0)
    //     0x12c67f0: sbfx            x2, x0, #1, #0x1f
    // 0x12c67f4: mov             x0, x2
    // 0x12c67f8: mov             x1, x5
    // 0x12c67fc: cmp             x1, x0
    // 0x12c6800: b.hs            #0x12c7654
    // 0x12c6804: LoadField: r6 = r4->field_f
    //     0x12c6804: ldur            w6, [x4, #0xf]
    // 0x12c6808: DecompressPointer r6
    //     0x12c6808: add             x6, x6, HEAP, lsl #32
    // 0x12c680c: sub             x7, x2, #1
    // 0x12c6810: cmp             x5, x7
    // 0x12c6814: b.ge            #0x12c6954
    // 0x12c6818: add             x8, x5, #1
    // 0x12c681c: sub             x0, x7, x5
    // 0x12c6820: cmp             x8, x5
    // 0x12c6824: b.ge            #0x12c68c4
    // 0x12c6828: add             x1, x8, x0
    // 0x12c682c: sub             x9, x1, #1
    // 0x12c6830: add             x1, x5, x0
    // 0x12c6834: sub             x0, x1, #1
    // 0x12c6838: mov             x10, x9
    // 0x12c683c: mov             x9, x0
    // 0x12c6840: CheckStackOverflow
    //     0x12c6840: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c6844: cmp             SP, x16
    //     0x12c6848: b.ls            #0x12c7658
    // 0x12c684c: cmp             x10, x8
    // 0x12c6850: b.lt            #0x12c6954
    // 0x12c6854: mov             x0, x2
    // 0x12c6858: mov             x1, x10
    // 0x12c685c: cmp             x1, x0
    // 0x12c6860: b.hs            #0x12c7660
    // 0x12c6864: ArrayLoad: r11 = r6[r10]  ; Unknown_4
    //     0x12c6864: add             x16, x6, x10, lsl #2
    //     0x12c6868: ldur            w11, [x16, #0xf]
    // 0x12c686c: DecompressPointer r11
    //     0x12c686c: add             x11, x11, HEAP, lsl #32
    // 0x12c6870: mov             x0, x2
    // 0x12c6874: mov             x1, x9
    // 0x12c6878: cmp             x1, x0
    // 0x12c687c: b.hs            #0x12c7664
    // 0x12c6880: mov             x1, x6
    // 0x12c6884: mov             x0, x11
    // 0x12c6888: ArrayStore: r1[r9] = r0  ; List_4
    //     0x12c6888: add             x25, x1, x9, lsl #2
    //     0x12c688c: add             x25, x25, #0xf
    //     0x12c6890: str             w0, [x25]
    //     0x12c6894: tbz             w0, #0, #0x12c68b0
    //     0x12c6898: ldurb           w16, [x1, #-1]
    //     0x12c689c: ldurb           w17, [x0, #-1]
    //     0x12c68a0: and             x16, x17, x16, lsr #2
    //     0x12c68a4: tst             x16, HEAP, lsr #32
    //     0x12c68a8: b.eq            #0x12c68b0
    //     0x12c68ac: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12c68b0: sub             x0, x10, #1
    // 0x12c68b4: sub             x1, x9, #1
    // 0x12c68b8: mov             x10, x0
    // 0x12c68bc: mov             x9, x1
    // 0x12c68c0: b               #0x12c6840
    // 0x12c68c4: add             x9, x8, x0
    // 0x12c68c8: mov             x10, x8
    // 0x12c68cc: mov             x8, x5
    // 0x12c68d0: CheckStackOverflow
    //     0x12c68d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c68d4: cmp             SP, x16
    //     0x12c68d8: b.ls            #0x12c7668
    // 0x12c68dc: cmp             x10, x9
    // 0x12c68e0: b.ge            #0x12c6954
    // 0x12c68e4: mov             x0, x2
    // 0x12c68e8: mov             x1, x10
    // 0x12c68ec: cmp             x1, x0
    // 0x12c68f0: b.hs            #0x12c7670
    // 0x12c68f4: ArrayLoad: r11 = r6[r10]  ; Unknown_4
    //     0x12c68f4: add             x16, x6, x10, lsl #2
    //     0x12c68f8: ldur            w11, [x16, #0xf]
    // 0x12c68fc: DecompressPointer r11
    //     0x12c68fc: add             x11, x11, HEAP, lsl #32
    // 0x12c6900: mov             x0, x2
    // 0x12c6904: mov             x1, x8
    // 0x12c6908: cmp             x1, x0
    // 0x12c690c: b.hs            #0x12c7674
    // 0x12c6910: mov             x1, x6
    // 0x12c6914: mov             x0, x11
    // 0x12c6918: ArrayStore: r1[r8] = r0  ; List_4
    //     0x12c6918: add             x25, x1, x8, lsl #2
    //     0x12c691c: add             x25, x25, #0xf
    //     0x12c6920: str             w0, [x25]
    //     0x12c6924: tbz             w0, #0, #0x12c6940
    //     0x12c6928: ldurb           w16, [x1, #-1]
    //     0x12c692c: ldurb           w17, [x0, #-1]
    //     0x12c6930: and             x16, x17, x16, lsr #2
    //     0x12c6934: tst             x16, HEAP, lsr #32
    //     0x12c6938: b.eq            #0x12c6940
    //     0x12c693c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12c6940: add             x0, x10, #1
    // 0x12c6944: add             x1, x8, #1
    // 0x12c6948: mov             x10, x0
    // 0x12c694c: mov             x8, x1
    // 0x12c6950: b               #0x12c68d0
    // 0x12c6954: mov             x1, x4
    // 0x12c6958: mov             x2, x7
    // 0x12c695c: r0 = length=()
    //     0x12c695c: bl              #0x9fa1d0  ; [dart:core] _GrowableList::length=
    // 0x12c6960: ldur            x2, [fp, #-0x60]
    // 0x12c6964: b               #0x12c75c0
    // 0x12c6968: ldur            x1, [fp, #-8]
    // 0x12c696c: cmp             x3, #0x625
    // 0x12c6970: b.lt            #0x12c74b8
    // 0x12c6974: cmp             x3, #0x625
    // 0x12c6978: b.gt            #0x12c6b34
    // 0x12c697c: ldur            x5, [fp, #-0x60]
    // 0x12c6980: ldur            x4, [fp, #-0x50]
    // 0x12c6984: ldur            x3, [fp, #-0x20]
    // 0x12c6988: LoadField: r0 = r5->field_b
    //     0x12c6988: ldur            w0, [x5, #0xb]
    // 0x12c698c: r1 = LoadInt32Instr(r0)
    //     0x12c698c: sbfx            x1, x0, #1, #0x1f
    // 0x12c6990: mov             x0, x1
    // 0x12c6994: mov             x1, x4
    // 0x12c6998: cmp             x1, x0
    // 0x12c699c: b.hs            #0x12c7678
    // 0x12c69a0: LoadField: r0 = r5->field_f
    //     0x12c69a0: ldur            w0, [x5, #0xf]
    // 0x12c69a4: DecompressPointer r0
    //     0x12c69a4: add             x0, x0, HEAP, lsl #32
    // 0x12c69a8: add             x1, x0, x4, lsl #2
    // 0x12c69ac: r16 = 130548
    //     0x12c69ac: mov             x16, #0xfdf4
    //     0x12c69b0: movk            x16, #1, lsl #16
    // 0x12c69b4: StoreField: r1->field_f = r16
    //     0x12c69b4: stur            w16, [x1, #0xf]
    // 0x12c69b8: LoadField: r0 = r3->field_b
    //     0x12c69b8: ldur            w0, [x3, #0xb]
    // 0x12c69bc: r2 = LoadInt32Instr(r0)
    //     0x12c69bc: sbfx            x2, x0, #1, #0x1f
    // 0x12c69c0: mov             x0, x2
    // 0x12c69c4: mov             x1, x4
    // 0x12c69c8: cmp             x1, x0
    // 0x12c69cc: b.hs            #0x12c767c
    // 0x12c69d0: LoadField: r6 = r3->field_f
    //     0x12c69d0: ldur            w6, [x3, #0xf]
    // 0x12c69d4: DecompressPointer r6
    //     0x12c69d4: add             x6, x6, HEAP, lsl #32
    // 0x12c69d8: sub             x7, x2, #1
    // 0x12c69dc: cmp             x4, x7
    // 0x12c69e0: b.ge            #0x12c6b20
    // 0x12c69e4: add             x8, x4, #1
    // 0x12c69e8: sub             x0, x7, x4
    // 0x12c69ec: cmp             x8, x4
    // 0x12c69f0: b.ge            #0x12c6a90
    // 0x12c69f4: add             x1, x8, x0
    // 0x12c69f8: sub             x9, x1, #1
    // 0x12c69fc: add             x1, x4, x0
    // 0x12c6a00: sub             x0, x1, #1
    // 0x12c6a04: mov             x10, x9
    // 0x12c6a08: mov             x9, x0
    // 0x12c6a0c: CheckStackOverflow
    //     0x12c6a0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c6a10: cmp             SP, x16
    //     0x12c6a14: b.ls            #0x12c7680
    // 0x12c6a18: cmp             x10, x8
    // 0x12c6a1c: b.lt            #0x12c6b20
    // 0x12c6a20: mov             x0, x2
    // 0x12c6a24: mov             x1, x10
    // 0x12c6a28: cmp             x1, x0
    // 0x12c6a2c: b.hs            #0x12c7688
    // 0x12c6a30: ArrayLoad: r11 = r6[r10]  ; Unknown_4
    //     0x12c6a30: add             x16, x6, x10, lsl #2
    //     0x12c6a34: ldur            w11, [x16, #0xf]
    // 0x12c6a38: DecompressPointer r11
    //     0x12c6a38: add             x11, x11, HEAP, lsl #32
    // 0x12c6a3c: mov             x0, x2
    // 0x12c6a40: mov             x1, x9
    // 0x12c6a44: cmp             x1, x0
    // 0x12c6a48: b.hs            #0x12c768c
    // 0x12c6a4c: mov             x1, x6
    // 0x12c6a50: mov             x0, x11
    // 0x12c6a54: ArrayStore: r1[r9] = r0  ; List_4
    //     0x12c6a54: add             x25, x1, x9, lsl #2
    //     0x12c6a58: add             x25, x25, #0xf
    //     0x12c6a5c: str             w0, [x25]
    //     0x12c6a60: tbz             w0, #0, #0x12c6a7c
    //     0x12c6a64: ldurb           w16, [x1, #-1]
    //     0x12c6a68: ldurb           w17, [x0, #-1]
    //     0x12c6a6c: and             x16, x17, x16, lsr #2
    //     0x12c6a70: tst             x16, HEAP, lsr #32
    //     0x12c6a74: b.eq            #0x12c6a7c
    //     0x12c6a78: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12c6a7c: sub             x0, x10, #1
    // 0x12c6a80: sub             x1, x9, #1
    // 0x12c6a84: mov             x10, x0
    // 0x12c6a88: mov             x9, x1
    // 0x12c6a8c: b               #0x12c6a0c
    // 0x12c6a90: add             x9, x8, x0
    // 0x12c6a94: mov             x10, x8
    // 0x12c6a98: mov             x8, x4
    // 0x12c6a9c: CheckStackOverflow
    //     0x12c6a9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c6aa0: cmp             SP, x16
    //     0x12c6aa4: b.ls            #0x12c7690
    // 0x12c6aa8: cmp             x10, x9
    // 0x12c6aac: b.ge            #0x12c6b20
    // 0x12c6ab0: mov             x0, x2
    // 0x12c6ab4: mov             x1, x10
    // 0x12c6ab8: cmp             x1, x0
    // 0x12c6abc: b.hs            #0x12c7698
    // 0x12c6ac0: ArrayLoad: r11 = r6[r10]  ; Unknown_4
    //     0x12c6ac0: add             x16, x6, x10, lsl #2
    //     0x12c6ac4: ldur            w11, [x16, #0xf]
    // 0x12c6ac8: DecompressPointer r11
    //     0x12c6ac8: add             x11, x11, HEAP, lsl #32
    // 0x12c6acc: mov             x0, x2
    // 0x12c6ad0: mov             x1, x8
    // 0x12c6ad4: cmp             x1, x0
    // 0x12c6ad8: b.hs            #0x12c769c
    // 0x12c6adc: mov             x1, x6
    // 0x12c6ae0: mov             x0, x11
    // 0x12c6ae4: ArrayStore: r1[r8] = r0  ; List_4
    //     0x12c6ae4: add             x25, x1, x8, lsl #2
    //     0x12c6ae8: add             x25, x25, #0xf
    //     0x12c6aec: str             w0, [x25]
    //     0x12c6af0: tbz             w0, #0, #0x12c6b0c
    //     0x12c6af4: ldurb           w16, [x1, #-1]
    //     0x12c6af8: ldurb           w17, [x0, #-1]
    //     0x12c6afc: and             x16, x17, x16, lsr #2
    //     0x12c6b00: tst             x16, HEAP, lsr #32
    //     0x12c6b04: b.eq            #0x12c6b0c
    //     0x12c6b08: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12c6b0c: add             x0, x10, #1
    // 0x12c6b10: add             x1, x8, #1
    // 0x12c6b14: mov             x10, x0
    // 0x12c6b18: mov             x8, x1
    // 0x12c6b1c: b               #0x12c6a9c
    // 0x12c6b20: mov             x1, x3
    // 0x12c6b24: mov             x2, x7
    // 0x12c6b28: r0 = length=()
    //     0x12c6b28: bl              #0x9fa1d0  ; [dart:core] _GrowableList::length=
    // 0x12c6b2c: ldur            x2, [fp, #-0x60]
    // 0x12c6b30: b               #0x12c75c0
    // 0x12c6b34: cmp             x3, #0x627
    // 0x12c6b38: b.lt            #0x12c74b8
    // 0x12c6b3c: cmp             w1, #0xc4e
    // 0x12c6b40: b.ne            #0x12c74b8
    // 0x12c6b44: ldur            x5, [fp, #-0x60]
    // 0x12c6b48: ldur            x4, [fp, #-0x50]
    // 0x12c6b4c: ldur            x3, [fp, #-0x20]
    // 0x12c6b50: LoadField: r0 = r5->field_b
    //     0x12c6b50: ldur            w0, [x5, #0xb]
    // 0x12c6b54: r1 = LoadInt32Instr(r0)
    //     0x12c6b54: sbfx            x1, x0, #1, #0x1f
    // 0x12c6b58: mov             x0, x1
    // 0x12c6b5c: mov             x1, x4
    // 0x12c6b60: cmp             x1, x0
    // 0x12c6b64: b.hs            #0x12c76a0
    // 0x12c6b68: LoadField: r0 = r5->field_f
    //     0x12c6b68: ldur            w0, [x5, #0xf]
    // 0x12c6b6c: DecompressPointer r0
    //     0x12c6b6c: add             x0, x0, HEAP, lsl #32
    // 0x12c6b70: add             x1, x0, x4, lsl #2
    // 0x12c6b74: r16 = 130552
    //     0x12c6b74: mov             x16, #0xfdf8
    //     0x12c6b78: movk            x16, #1, lsl #16
    // 0x12c6b7c: StoreField: r1->field_f = r16
    //     0x12c6b7c: stur            w16, [x1, #0xf]
    // 0x12c6b80: LoadField: r0 = r3->field_b
    //     0x12c6b80: ldur            w0, [x3, #0xb]
    // 0x12c6b84: r2 = LoadInt32Instr(r0)
    //     0x12c6b84: sbfx            x2, x0, #1, #0x1f
    // 0x12c6b88: mov             x0, x2
    // 0x12c6b8c: mov             x1, x4
    // 0x12c6b90: cmp             x1, x0
    // 0x12c6b94: b.hs            #0x12c76a4
    // 0x12c6b98: LoadField: r6 = r3->field_f
    //     0x12c6b98: ldur            w6, [x3, #0xf]
    // 0x12c6b9c: DecompressPointer r6
    //     0x12c6b9c: add             x6, x6, HEAP, lsl #32
    // 0x12c6ba0: sub             x7, x2, #1
    // 0x12c6ba4: cmp             x4, x7
    // 0x12c6ba8: b.ge            #0x12c6ce8
    // 0x12c6bac: add             x8, x4, #1
    // 0x12c6bb0: sub             x0, x7, x4
    // 0x12c6bb4: cmp             x8, x4
    // 0x12c6bb8: b.ge            #0x12c6c58
    // 0x12c6bbc: add             x1, x8, x0
    // 0x12c6bc0: sub             x9, x1, #1
    // 0x12c6bc4: add             x1, x4, x0
    // 0x12c6bc8: sub             x0, x1, #1
    // 0x12c6bcc: mov             x10, x9
    // 0x12c6bd0: mov             x9, x0
    // 0x12c6bd4: CheckStackOverflow
    //     0x12c6bd4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c6bd8: cmp             SP, x16
    //     0x12c6bdc: b.ls            #0x12c76a8
    // 0x12c6be0: cmp             x10, x8
    // 0x12c6be4: b.lt            #0x12c6ce8
    // 0x12c6be8: mov             x0, x2
    // 0x12c6bec: mov             x1, x10
    // 0x12c6bf0: cmp             x1, x0
    // 0x12c6bf4: b.hs            #0x12c76b0
    // 0x12c6bf8: ArrayLoad: r11 = r6[r10]  ; Unknown_4
    //     0x12c6bf8: add             x16, x6, x10, lsl #2
    //     0x12c6bfc: ldur            w11, [x16, #0xf]
    // 0x12c6c00: DecompressPointer r11
    //     0x12c6c00: add             x11, x11, HEAP, lsl #32
    // 0x12c6c04: mov             x0, x2
    // 0x12c6c08: mov             x1, x9
    // 0x12c6c0c: cmp             x1, x0
    // 0x12c6c10: b.hs            #0x12c76b4
    // 0x12c6c14: mov             x1, x6
    // 0x12c6c18: mov             x0, x11
    // 0x12c6c1c: ArrayStore: r1[r9] = r0  ; List_4
    //     0x12c6c1c: add             x25, x1, x9, lsl #2
    //     0x12c6c20: add             x25, x25, #0xf
    //     0x12c6c24: str             w0, [x25]
    //     0x12c6c28: tbz             w0, #0, #0x12c6c44
    //     0x12c6c2c: ldurb           w16, [x1, #-1]
    //     0x12c6c30: ldurb           w17, [x0, #-1]
    //     0x12c6c34: and             x16, x17, x16, lsr #2
    //     0x12c6c38: tst             x16, HEAP, lsr #32
    //     0x12c6c3c: b.eq            #0x12c6c44
    //     0x12c6c40: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12c6c44: sub             x0, x10, #1
    // 0x12c6c48: sub             x1, x9, #1
    // 0x12c6c4c: mov             x10, x0
    // 0x12c6c50: mov             x9, x1
    // 0x12c6c54: b               #0x12c6bd4
    // 0x12c6c58: add             x9, x8, x0
    // 0x12c6c5c: mov             x10, x8
    // 0x12c6c60: mov             x8, x4
    // 0x12c6c64: CheckStackOverflow
    //     0x12c6c64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c6c68: cmp             SP, x16
    //     0x12c6c6c: b.ls            #0x12c76b8
    // 0x12c6c70: cmp             x10, x9
    // 0x12c6c74: b.ge            #0x12c6ce8
    // 0x12c6c78: mov             x0, x2
    // 0x12c6c7c: mov             x1, x10
    // 0x12c6c80: cmp             x1, x0
    // 0x12c6c84: b.hs            #0x12c76c0
    // 0x12c6c88: ArrayLoad: r11 = r6[r10]  ; Unknown_4
    //     0x12c6c88: add             x16, x6, x10, lsl #2
    //     0x12c6c8c: ldur            w11, [x16, #0xf]
    // 0x12c6c90: DecompressPointer r11
    //     0x12c6c90: add             x11, x11, HEAP, lsl #32
    // 0x12c6c94: mov             x0, x2
    // 0x12c6c98: mov             x1, x8
    // 0x12c6c9c: cmp             x1, x0
    // 0x12c6ca0: b.hs            #0x12c76c4
    // 0x12c6ca4: mov             x1, x6
    // 0x12c6ca8: mov             x0, x11
    // 0x12c6cac: ArrayStore: r1[r8] = r0  ; List_4
    //     0x12c6cac: add             x25, x1, x8, lsl #2
    //     0x12c6cb0: add             x25, x25, #0xf
    //     0x12c6cb4: str             w0, [x25]
    //     0x12c6cb8: tbz             w0, #0, #0x12c6cd4
    //     0x12c6cbc: ldurb           w16, [x1, #-1]
    //     0x12c6cc0: ldurb           w17, [x0, #-1]
    //     0x12c6cc4: and             x16, x17, x16, lsr #2
    //     0x12c6cc8: tst             x16, HEAP, lsr #32
    //     0x12c6ccc: b.eq            #0x12c6cd4
    //     0x12c6cd0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12c6cd4: add             x0, x10, #1
    // 0x12c6cd8: add             x1, x8, #1
    // 0x12c6cdc: mov             x10, x0
    // 0x12c6ce0: mov             x8, x1
    // 0x12c6ce4: b               #0x12c6c64
    // 0x12c6ce8: mov             x1, x3
    // 0x12c6cec: mov             x2, x7
    // 0x12c6cf0: r0 = length=()
    //     0x12c6cf0: bl              #0x9fa1d0  ; [dart:core] _GrowableList::length=
    // 0x12c6cf4: ldur            x2, [fp, #-0x60]
    // 0x12c6cf8: b               #0x12c75c0
    // 0x12c6cfc: ldur            x1, [fp, #-8]
    // 0x12c6d00: r16 = Instance_LetterForm
    //     0x12c6d00: add             x16, PP, #0x80, lsl #12  ; [pp+0x80590] Obj!LetterForm@12c6ba1
    //     0x12c6d04: ldr             x16, [x16, #0x590]
    // 0x12c6d08: cmp             w0, w16
    // 0x12c6d0c: b.ne            #0x12c74b8
    // 0x12c6d10: cmp             x3, #0x623
    // 0x12c6d14: b.gt            #0x12c7128
    // 0x12c6d18: cmp             x3, #0x622
    // 0x12c6d1c: b.gt            #0x12c6f70
    // 0x12c6d20: cmp             w1, #0xc44
    // 0x12c6d24: b.ne            #0x12c6f64
    // 0x12c6d28: ldur            x5, [fp, #-0x60]
    // 0x12c6d2c: ldur            x4, [fp, #-0x50]
    // 0x12c6d30: ldur            x3, [fp, #-0x20]
    // 0x12c6d34: LoadField: r0 = r5->field_b
    //     0x12c6d34: ldur            w0, [x5, #0xb]
    // 0x12c6d38: r1 = LoadInt32Instr(r0)
    //     0x12c6d38: sbfx            x1, x0, #1, #0x1f
    // 0x12c6d3c: mov             x0, x1
    // 0x12c6d40: mov             x1, x4
    // 0x12c6d44: cmp             x1, x0
    // 0x12c6d48: b.hs            #0x12c76c8
    // 0x12c6d4c: LoadField: r0 = r5->field_f
    //     0x12c6d4c: ldur            w0, [x5, #0xf]
    // 0x12c6d50: DecompressPointer r0
    //     0x12c6d50: add             x0, x0, HEAP, lsl #32
    // 0x12c6d54: add             x1, x0, x4, lsl #2
    // 0x12c6d58: r16 = 130538
    //     0x12c6d58: mov             x16, #0xfdea
    //     0x12c6d5c: movk            x16, #1, lsl #16
    // 0x12c6d60: StoreField: r1->field_f = r16
    //     0x12c6d60: stur            w16, [x1, #0xf]
    // 0x12c6d64: LoadField: r0 = r3->field_b
    //     0x12c6d64: ldur            w0, [x3, #0xb]
    // 0x12c6d68: r2 = LoadInt32Instr(r0)
    //     0x12c6d68: sbfx            x2, x0, #1, #0x1f
    // 0x12c6d6c: mov             x0, x2
    // 0x12c6d70: mov             x1, x4
    // 0x12c6d74: cmp             x1, x0
    // 0x12c6d78: b.hs            #0x12c76cc
    // 0x12c6d7c: LoadField: r6 = r3->field_f
    //     0x12c6d7c: ldur            w6, [x3, #0xf]
    // 0x12c6d80: DecompressPointer r6
    //     0x12c6d80: add             x6, x6, HEAP, lsl #32
    // 0x12c6d84: sub             x7, x2, #1
    // 0x12c6d88: cmp             x4, x7
    // 0x12c6d8c: b.ge            #0x12c6ecc
    // 0x12c6d90: add             x8, x4, #1
    // 0x12c6d94: sub             x0, x7, x4
    // 0x12c6d98: cmp             x8, x4
    // 0x12c6d9c: b.ge            #0x12c6e3c
    // 0x12c6da0: add             x1, x8, x0
    // 0x12c6da4: sub             x9, x1, #1
    // 0x12c6da8: add             x1, x4, x0
    // 0x12c6dac: sub             x0, x1, #1
    // 0x12c6db0: mov             x10, x9
    // 0x12c6db4: mov             x9, x0
    // 0x12c6db8: CheckStackOverflow
    //     0x12c6db8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c6dbc: cmp             SP, x16
    //     0x12c6dc0: b.ls            #0x12c76d0
    // 0x12c6dc4: cmp             x10, x8
    // 0x12c6dc8: b.lt            #0x12c6ecc
    // 0x12c6dcc: mov             x0, x2
    // 0x12c6dd0: mov             x1, x10
    // 0x12c6dd4: cmp             x1, x0
    // 0x12c6dd8: b.hs            #0x12c76d8
    // 0x12c6ddc: ArrayLoad: r11 = r6[r10]  ; Unknown_4
    //     0x12c6ddc: add             x16, x6, x10, lsl #2
    //     0x12c6de0: ldur            w11, [x16, #0xf]
    // 0x12c6de4: DecompressPointer r11
    //     0x12c6de4: add             x11, x11, HEAP, lsl #32
    // 0x12c6de8: mov             x0, x2
    // 0x12c6dec: mov             x1, x9
    // 0x12c6df0: cmp             x1, x0
    // 0x12c6df4: b.hs            #0x12c76dc
    // 0x12c6df8: mov             x1, x6
    // 0x12c6dfc: mov             x0, x11
    // 0x12c6e00: ArrayStore: r1[r9] = r0  ; List_4
    //     0x12c6e00: add             x25, x1, x9, lsl #2
    //     0x12c6e04: add             x25, x25, #0xf
    //     0x12c6e08: str             w0, [x25]
    //     0x12c6e0c: tbz             w0, #0, #0x12c6e28
    //     0x12c6e10: ldurb           w16, [x1, #-1]
    //     0x12c6e14: ldurb           w17, [x0, #-1]
    //     0x12c6e18: and             x16, x17, x16, lsr #2
    //     0x12c6e1c: tst             x16, HEAP, lsr #32
    //     0x12c6e20: b.eq            #0x12c6e28
    //     0x12c6e24: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12c6e28: sub             x0, x10, #1
    // 0x12c6e2c: sub             x1, x9, #1
    // 0x12c6e30: mov             x10, x0
    // 0x12c6e34: mov             x9, x1
    // 0x12c6e38: b               #0x12c6db8
    // 0x12c6e3c: add             x9, x8, x0
    // 0x12c6e40: mov             x10, x8
    // 0x12c6e44: mov             x8, x4
    // 0x12c6e48: CheckStackOverflow
    //     0x12c6e48: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c6e4c: cmp             SP, x16
    //     0x12c6e50: b.ls            #0x12c76e0
    // 0x12c6e54: cmp             x10, x9
    // 0x12c6e58: b.ge            #0x12c6ecc
    // 0x12c6e5c: mov             x0, x2
    // 0x12c6e60: mov             x1, x10
    // 0x12c6e64: cmp             x1, x0
    // 0x12c6e68: b.hs            #0x12c76e8
    // 0x12c6e6c: ArrayLoad: r11 = r6[r10]  ; Unknown_4
    //     0x12c6e6c: add             x16, x6, x10, lsl #2
    //     0x12c6e70: ldur            w11, [x16, #0xf]
    // 0x12c6e74: DecompressPointer r11
    //     0x12c6e74: add             x11, x11, HEAP, lsl #32
    // 0x12c6e78: mov             x0, x2
    // 0x12c6e7c: mov             x1, x8
    // 0x12c6e80: cmp             x1, x0
    // 0x12c6e84: b.hs            #0x12c76ec
    // 0x12c6e88: mov             x1, x6
    // 0x12c6e8c: mov             x0, x11
    // 0x12c6e90: ArrayStore: r1[r8] = r0  ; List_4
    //     0x12c6e90: add             x25, x1, x8, lsl #2
    //     0x12c6e94: add             x25, x25, #0xf
    //     0x12c6e98: str             w0, [x25]
    //     0x12c6e9c: tbz             w0, #0, #0x12c6eb8
    //     0x12c6ea0: ldurb           w16, [x1, #-1]
    //     0x12c6ea4: ldurb           w17, [x0, #-1]
    //     0x12c6ea8: and             x16, x17, x16, lsr #2
    //     0x12c6eac: tst             x16, HEAP, lsr #32
    //     0x12c6eb0: b.eq            #0x12c6eb8
    //     0x12c6eb4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12c6eb8: add             x0, x10, #1
    // 0x12c6ebc: add             x1, x8, #1
    // 0x12c6ec0: mov             x10, x0
    // 0x12c6ec4: mov             x8, x1
    // 0x12c6ec8: b               #0x12c6e48
    // 0x12c6ecc: mov             x1, x3
    // 0x12c6ed0: mov             x2, x7
    // 0x12c6ed4: r0 = length=()
    //     0x12c6ed4: bl              #0x9fa1d0  ; [dart:core] _GrowableList::length=
    // 0x12c6ed8: ldur            x4, [fp, #-0x20]
    // 0x12c6edc: LoadField: r0 = r4->field_b
    //     0x12c6edc: ldur            w0, [x4, #0xb]
    // 0x12c6ee0: r1 = LoadInt32Instr(r0)
    //     0x12c6ee0: sbfx            x1, x0, #1, #0x1f
    // 0x12c6ee4: mov             x0, x1
    // 0x12c6ee8: ldur            x1, [fp, #-0x50]
    // 0x12c6eec: cmp             x1, x0
    // 0x12c6ef0: b.hs            #0x12c76f0
    // 0x12c6ef4: LoadField: r2 = r4->field_f
    //     0x12c6ef4: ldur            w2, [x4, #0xf]
    // 0x12c6ef8: DecompressPointer r2
    //     0x12c6ef8: add             x2, x2, HEAP, lsl #32
    // 0x12c6efc: ldur            x5, [fp, #-0x50]
    // 0x12c6f00: ArrayLoad: r0 = r2[r5]  ; Unknown_4
    //     0x12c6f00: add             x16, x2, x5, lsl #2
    //     0x12c6f04: ldur            w0, [x16, #0xf]
    // 0x12c6f08: DecompressPointer r0
    //     0x12c6f08: add             x0, x0, HEAP, lsl #32
    // 0x12c6f0c: r1 = LoadInt32Instr(r0)
    //     0x12c6f0c: sbfx            x1, x0, #1, #0x1f
    //     0x12c6f10: tbz             w0, #0, #0x12c6f18
    //     0x12c6f14: ldur            x1, [x0, #7]
    // 0x12c6f18: add             x3, x1, #1
    // 0x12c6f1c: r0 = BoxInt64Instr(r3)
    //     0x12c6f1c: sbfiz           x0, x3, #1, #0x1f
    //     0x12c6f20: cmp             x3, x0, asr #1
    //     0x12c6f24: b.eq            #0x12c6f30
    //     0x12c6f28: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12c6f2c: stur            x3, [x0, #7]
    // 0x12c6f30: mov             x1, x2
    // 0x12c6f34: ArrayStore: r1[r5] = r0  ; List_4
    //     0x12c6f34: add             x25, x1, x5, lsl #2
    //     0x12c6f38: add             x25, x25, #0xf
    //     0x12c6f3c: str             w0, [x25]
    //     0x12c6f40: tbz             w0, #0, #0x12c6f5c
    //     0x12c6f44: ldurb           w16, [x1, #-1]
    //     0x12c6f48: ldurb           w17, [x0, #-1]
    //     0x12c6f4c: and             x16, x17, x16, lsr #2
    //     0x12c6f50: tst             x16, HEAP, lsr #32
    //     0x12c6f54: b.eq            #0x12c6f5c
    //     0x12c6f58: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12c6f5c: ldur            x2, [fp, #-0x60]
    // 0x12c6f60: b               #0x12c75c0
    // 0x12c6f64: ldur            x5, [fp, #-0x50]
    // 0x12c6f68: ldur            x4, [fp, #-0x20]
    // 0x12c6f6c: b               #0x12c74b8
    // 0x12c6f70: ldur            x3, [fp, #-0x60]
    // 0x12c6f74: ldur            x5, [fp, #-0x50]
    // 0x12c6f78: ldur            x4, [fp, #-0x20]
    // 0x12c6f7c: LoadField: r0 = r3->field_b
    //     0x12c6f7c: ldur            w0, [x3, #0xb]
    // 0x12c6f80: r1 = LoadInt32Instr(r0)
    //     0x12c6f80: sbfx            x1, x0, #1, #0x1f
    // 0x12c6f84: mov             x0, x1
    // 0x12c6f88: mov             x1, x5
    // 0x12c6f8c: cmp             x1, x0
    // 0x12c6f90: b.hs            #0x12c76f4
    // 0x12c6f94: LoadField: r0 = r3->field_f
    //     0x12c6f94: ldur            w0, [x3, #0xf]
    // 0x12c6f98: DecompressPointer r0
    //     0x12c6f98: add             x0, x0, HEAP, lsl #32
    // 0x12c6f9c: add             x1, x0, x5, lsl #2
    // 0x12c6fa0: r16 = 130542
    //     0x12c6fa0: mov             x16, #0xfdee
    //     0x12c6fa4: movk            x16, #1, lsl #16
    // 0x12c6fa8: StoreField: r1->field_f = r16
    //     0x12c6fa8: stur            w16, [x1, #0xf]
    // 0x12c6fac: LoadField: r0 = r4->field_b
    //     0x12c6fac: ldur            w0, [x4, #0xb]
    // 0x12c6fb0: r2 = LoadInt32Instr(r0)
    //     0x12c6fb0: sbfx            x2, x0, #1, #0x1f
    // 0x12c6fb4: mov             x0, x2
    // 0x12c6fb8: mov             x1, x5
    // 0x12c6fbc: cmp             x1, x0
    // 0x12c6fc0: b.hs            #0x12c76f8
    // 0x12c6fc4: LoadField: r6 = r4->field_f
    //     0x12c6fc4: ldur            w6, [x4, #0xf]
    // 0x12c6fc8: DecompressPointer r6
    //     0x12c6fc8: add             x6, x6, HEAP, lsl #32
    // 0x12c6fcc: sub             x7, x2, #1
    // 0x12c6fd0: cmp             x5, x7
    // 0x12c6fd4: b.ge            #0x12c7114
    // 0x12c6fd8: add             x8, x5, #1
    // 0x12c6fdc: sub             x0, x7, x5
    // 0x12c6fe0: cmp             x8, x5
    // 0x12c6fe4: b.ge            #0x12c7084
    // 0x12c6fe8: add             x1, x8, x0
    // 0x12c6fec: sub             x9, x1, #1
    // 0x12c6ff0: add             x1, x5, x0
    // 0x12c6ff4: sub             x0, x1, #1
    // 0x12c6ff8: mov             x10, x9
    // 0x12c6ffc: mov             x9, x0
    // 0x12c7000: CheckStackOverflow
    //     0x12c7000: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c7004: cmp             SP, x16
    //     0x12c7008: b.ls            #0x12c76fc
    // 0x12c700c: cmp             x10, x8
    // 0x12c7010: b.lt            #0x12c7114
    // 0x12c7014: mov             x0, x2
    // 0x12c7018: mov             x1, x10
    // 0x12c701c: cmp             x1, x0
    // 0x12c7020: b.hs            #0x12c7704
    // 0x12c7024: ArrayLoad: r11 = r6[r10]  ; Unknown_4
    //     0x12c7024: add             x16, x6, x10, lsl #2
    //     0x12c7028: ldur            w11, [x16, #0xf]
    // 0x12c702c: DecompressPointer r11
    //     0x12c702c: add             x11, x11, HEAP, lsl #32
    // 0x12c7030: mov             x0, x2
    // 0x12c7034: mov             x1, x9
    // 0x12c7038: cmp             x1, x0
    // 0x12c703c: b.hs            #0x12c7708
    // 0x12c7040: mov             x1, x6
    // 0x12c7044: mov             x0, x11
    // 0x12c7048: ArrayStore: r1[r9] = r0  ; List_4
    //     0x12c7048: add             x25, x1, x9, lsl #2
    //     0x12c704c: add             x25, x25, #0xf
    //     0x12c7050: str             w0, [x25]
    //     0x12c7054: tbz             w0, #0, #0x12c7070
    //     0x12c7058: ldurb           w16, [x1, #-1]
    //     0x12c705c: ldurb           w17, [x0, #-1]
    //     0x12c7060: and             x16, x17, x16, lsr #2
    //     0x12c7064: tst             x16, HEAP, lsr #32
    //     0x12c7068: b.eq            #0x12c7070
    //     0x12c706c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12c7070: sub             x0, x10, #1
    // 0x12c7074: sub             x1, x9, #1
    // 0x12c7078: mov             x10, x0
    // 0x12c707c: mov             x9, x1
    // 0x12c7080: b               #0x12c7000
    // 0x12c7084: add             x9, x8, x0
    // 0x12c7088: mov             x10, x8
    // 0x12c708c: mov             x8, x5
    // 0x12c7090: CheckStackOverflow
    //     0x12c7090: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c7094: cmp             SP, x16
    //     0x12c7098: b.ls            #0x12c770c
    // 0x12c709c: cmp             x10, x9
    // 0x12c70a0: b.ge            #0x12c7114
    // 0x12c70a4: mov             x0, x2
    // 0x12c70a8: mov             x1, x10
    // 0x12c70ac: cmp             x1, x0
    // 0x12c70b0: b.hs            #0x12c7714
    // 0x12c70b4: ArrayLoad: r11 = r6[r10]  ; Unknown_4
    //     0x12c70b4: add             x16, x6, x10, lsl #2
    //     0x12c70b8: ldur            w11, [x16, #0xf]
    // 0x12c70bc: DecompressPointer r11
    //     0x12c70bc: add             x11, x11, HEAP, lsl #32
    // 0x12c70c0: mov             x0, x2
    // 0x12c70c4: mov             x1, x8
    // 0x12c70c8: cmp             x1, x0
    // 0x12c70cc: b.hs            #0x12c7718
    // 0x12c70d0: mov             x1, x6
    // 0x12c70d4: mov             x0, x11
    // 0x12c70d8: ArrayStore: r1[r8] = r0  ; List_4
    //     0x12c70d8: add             x25, x1, x8, lsl #2
    //     0x12c70dc: add             x25, x25, #0xf
    //     0x12c70e0: str             w0, [x25]
    //     0x12c70e4: tbz             w0, #0, #0x12c7100
    //     0x12c70e8: ldurb           w16, [x1, #-1]
    //     0x12c70ec: ldurb           w17, [x0, #-1]
    //     0x12c70f0: and             x16, x17, x16, lsr #2
    //     0x12c70f4: tst             x16, HEAP, lsr #32
    //     0x12c70f8: b.eq            #0x12c7100
    //     0x12c70fc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12c7100: add             x0, x10, #1
    // 0x12c7104: add             x1, x8, #1
    // 0x12c7108: mov             x10, x0
    // 0x12c710c: mov             x8, x1
    // 0x12c7110: b               #0x12c7090
    // 0x12c7114: mov             x1, x4
    // 0x12c7118: mov             x2, x7
    // 0x12c711c: r0 = length=()
    //     0x12c711c: bl              #0x9fa1d0  ; [dart:core] _GrowableList::length=
    // 0x12c7120: ldur            x2, [fp, #-0x60]
    // 0x12c7124: b               #0x12c75c0
    // 0x12c7128: cmp             x3, #0x625
    // 0x12c712c: b.lt            #0x12c74b8
    // 0x12c7130: cmp             x3, #0x625
    // 0x12c7134: b.gt            #0x12c72f0
    // 0x12c7138: ldur            x5, [fp, #-0x60]
    // 0x12c713c: ldur            x4, [fp, #-0x50]
    // 0x12c7140: ldur            x3, [fp, #-0x20]
    // 0x12c7144: LoadField: r0 = r5->field_b
    //     0x12c7144: ldur            w0, [x5, #0xb]
    // 0x12c7148: r1 = LoadInt32Instr(r0)
    //     0x12c7148: sbfx            x1, x0, #1, #0x1f
    // 0x12c714c: mov             x0, x1
    // 0x12c7150: mov             x1, x4
    // 0x12c7154: cmp             x1, x0
    // 0x12c7158: b.hs            #0x12c771c
    // 0x12c715c: LoadField: r0 = r5->field_f
    //     0x12c715c: ldur            w0, [x5, #0xf]
    // 0x12c7160: DecompressPointer r0
    //     0x12c7160: add             x0, x0, HEAP, lsl #32
    // 0x12c7164: add             x1, x0, x4, lsl #2
    // 0x12c7168: r16 = 130546
    //     0x12c7168: mov             x16, #0xfdf2
    //     0x12c716c: movk            x16, #1, lsl #16
    // 0x12c7170: StoreField: r1->field_f = r16
    //     0x12c7170: stur            w16, [x1, #0xf]
    // 0x12c7174: LoadField: r0 = r3->field_b
    //     0x12c7174: ldur            w0, [x3, #0xb]
    // 0x12c7178: r2 = LoadInt32Instr(r0)
    //     0x12c7178: sbfx            x2, x0, #1, #0x1f
    // 0x12c717c: mov             x0, x2
    // 0x12c7180: mov             x1, x4
    // 0x12c7184: cmp             x1, x0
    // 0x12c7188: b.hs            #0x12c7720
    // 0x12c718c: LoadField: r6 = r3->field_f
    //     0x12c718c: ldur            w6, [x3, #0xf]
    // 0x12c7190: DecompressPointer r6
    //     0x12c7190: add             x6, x6, HEAP, lsl #32
    // 0x12c7194: sub             x7, x2, #1
    // 0x12c7198: cmp             x4, x7
    // 0x12c719c: b.ge            #0x12c72dc
    // 0x12c71a0: add             x8, x4, #1
    // 0x12c71a4: sub             x0, x7, x4
    // 0x12c71a8: cmp             x8, x4
    // 0x12c71ac: b.ge            #0x12c724c
    // 0x12c71b0: add             x1, x8, x0
    // 0x12c71b4: sub             x9, x1, #1
    // 0x12c71b8: add             x1, x4, x0
    // 0x12c71bc: sub             x0, x1, #1
    // 0x12c71c0: mov             x10, x9
    // 0x12c71c4: mov             x9, x0
    // 0x12c71c8: CheckStackOverflow
    //     0x12c71c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c71cc: cmp             SP, x16
    //     0x12c71d0: b.ls            #0x12c7724
    // 0x12c71d4: cmp             x10, x8
    // 0x12c71d8: b.lt            #0x12c72dc
    // 0x12c71dc: mov             x0, x2
    // 0x12c71e0: mov             x1, x10
    // 0x12c71e4: cmp             x1, x0
    // 0x12c71e8: b.hs            #0x12c772c
    // 0x12c71ec: ArrayLoad: r11 = r6[r10]  ; Unknown_4
    //     0x12c71ec: add             x16, x6, x10, lsl #2
    //     0x12c71f0: ldur            w11, [x16, #0xf]
    // 0x12c71f4: DecompressPointer r11
    //     0x12c71f4: add             x11, x11, HEAP, lsl #32
    // 0x12c71f8: mov             x0, x2
    // 0x12c71fc: mov             x1, x9
    // 0x12c7200: cmp             x1, x0
    // 0x12c7204: b.hs            #0x12c7730
    // 0x12c7208: mov             x1, x6
    // 0x12c720c: mov             x0, x11
    // 0x12c7210: ArrayStore: r1[r9] = r0  ; List_4
    //     0x12c7210: add             x25, x1, x9, lsl #2
    //     0x12c7214: add             x25, x25, #0xf
    //     0x12c7218: str             w0, [x25]
    //     0x12c721c: tbz             w0, #0, #0x12c7238
    //     0x12c7220: ldurb           w16, [x1, #-1]
    //     0x12c7224: ldurb           w17, [x0, #-1]
    //     0x12c7228: and             x16, x17, x16, lsr #2
    //     0x12c722c: tst             x16, HEAP, lsr #32
    //     0x12c7230: b.eq            #0x12c7238
    //     0x12c7234: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12c7238: sub             x0, x10, #1
    // 0x12c723c: sub             x1, x9, #1
    // 0x12c7240: mov             x10, x0
    // 0x12c7244: mov             x9, x1
    // 0x12c7248: b               #0x12c71c8
    // 0x12c724c: add             x9, x8, x0
    // 0x12c7250: mov             x10, x8
    // 0x12c7254: mov             x8, x4
    // 0x12c7258: CheckStackOverflow
    //     0x12c7258: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c725c: cmp             SP, x16
    //     0x12c7260: b.ls            #0x12c7734
    // 0x12c7264: cmp             x10, x9
    // 0x12c7268: b.ge            #0x12c72dc
    // 0x12c726c: mov             x0, x2
    // 0x12c7270: mov             x1, x10
    // 0x12c7274: cmp             x1, x0
    // 0x12c7278: b.hs            #0x12c773c
    // 0x12c727c: ArrayLoad: r11 = r6[r10]  ; Unknown_4
    //     0x12c727c: add             x16, x6, x10, lsl #2
    //     0x12c7280: ldur            w11, [x16, #0xf]
    // 0x12c7284: DecompressPointer r11
    //     0x12c7284: add             x11, x11, HEAP, lsl #32
    // 0x12c7288: mov             x0, x2
    // 0x12c728c: mov             x1, x8
    // 0x12c7290: cmp             x1, x0
    // 0x12c7294: b.hs            #0x12c7740
    // 0x12c7298: mov             x1, x6
    // 0x12c729c: mov             x0, x11
    // 0x12c72a0: ArrayStore: r1[r8] = r0  ; List_4
    //     0x12c72a0: add             x25, x1, x8, lsl #2
    //     0x12c72a4: add             x25, x25, #0xf
    //     0x12c72a8: str             w0, [x25]
    //     0x12c72ac: tbz             w0, #0, #0x12c72c8
    //     0x12c72b0: ldurb           w16, [x1, #-1]
    //     0x12c72b4: ldurb           w17, [x0, #-1]
    //     0x12c72b8: and             x16, x17, x16, lsr #2
    //     0x12c72bc: tst             x16, HEAP, lsr #32
    //     0x12c72c0: b.eq            #0x12c72c8
    //     0x12c72c4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12c72c8: add             x0, x10, #1
    // 0x12c72cc: add             x1, x8, #1
    // 0x12c72d0: mov             x10, x0
    // 0x12c72d4: mov             x8, x1
    // 0x12c72d8: b               #0x12c7258
    // 0x12c72dc: mov             x1, x3
    // 0x12c72e0: mov             x2, x7
    // 0x12c72e4: r0 = length=()
    //     0x12c72e4: bl              #0x9fa1d0  ; [dart:core] _GrowableList::length=
    // 0x12c72e8: ldur            x2, [fp, #-0x60]
    // 0x12c72ec: b               #0x12c75c0
    // 0x12c72f0: cmp             x3, #0x627
    // 0x12c72f4: b.lt            #0x12c74b8
    // 0x12c72f8: cmp             w1, #0xc4e
    // 0x12c72fc: b.ne            #0x12c74b8
    // 0x12c7300: ldur            x5, [fp, #-0x60]
    // 0x12c7304: ldur            x4, [fp, #-0x50]
    // 0x12c7308: ldur            x3, [fp, #-0x20]
    // 0x12c730c: LoadField: r0 = r5->field_b
    //     0x12c730c: ldur            w0, [x5, #0xb]
    // 0x12c7310: r1 = LoadInt32Instr(r0)
    //     0x12c7310: sbfx            x1, x0, #1, #0x1f
    // 0x12c7314: mov             x0, x1
    // 0x12c7318: mov             x1, x4
    // 0x12c731c: cmp             x1, x0
    // 0x12c7320: b.hs            #0x12c7744
    // 0x12c7324: LoadField: r0 = r5->field_f
    //     0x12c7324: ldur            w0, [x5, #0xf]
    // 0x12c7328: DecompressPointer r0
    //     0x12c7328: add             x0, x0, HEAP, lsl #32
    // 0x12c732c: add             x1, x0, x4, lsl #2
    // 0x12c7330: r16 = 130550
    //     0x12c7330: mov             x16, #0xfdf6
    //     0x12c7334: movk            x16, #1, lsl #16
    // 0x12c7338: StoreField: r1->field_f = r16
    //     0x12c7338: stur            w16, [x1, #0xf]
    // 0x12c733c: LoadField: r0 = r3->field_b
    //     0x12c733c: ldur            w0, [x3, #0xb]
    // 0x12c7340: r2 = LoadInt32Instr(r0)
    //     0x12c7340: sbfx            x2, x0, #1, #0x1f
    // 0x12c7344: mov             x0, x2
    // 0x12c7348: mov             x1, x4
    // 0x12c734c: cmp             x1, x0
    // 0x12c7350: b.hs            #0x12c7748
    // 0x12c7354: LoadField: r6 = r3->field_f
    //     0x12c7354: ldur            w6, [x3, #0xf]
    // 0x12c7358: DecompressPointer r6
    //     0x12c7358: add             x6, x6, HEAP, lsl #32
    // 0x12c735c: sub             x7, x2, #1
    // 0x12c7360: cmp             x4, x7
    // 0x12c7364: b.ge            #0x12c74a4
    // 0x12c7368: add             x8, x4, #1
    // 0x12c736c: sub             x0, x7, x4
    // 0x12c7370: cmp             x8, x4
    // 0x12c7374: b.ge            #0x12c7414
    // 0x12c7378: add             x1, x8, x0
    // 0x12c737c: sub             x9, x1, #1
    // 0x12c7380: add             x1, x4, x0
    // 0x12c7384: sub             x0, x1, #1
    // 0x12c7388: mov             x10, x9
    // 0x12c738c: mov             x9, x0
    // 0x12c7390: CheckStackOverflow
    //     0x12c7390: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c7394: cmp             SP, x16
    //     0x12c7398: b.ls            #0x12c774c
    // 0x12c739c: cmp             x10, x8
    // 0x12c73a0: b.lt            #0x12c74a4
    // 0x12c73a4: mov             x0, x2
    // 0x12c73a8: mov             x1, x10
    // 0x12c73ac: cmp             x1, x0
    // 0x12c73b0: b.hs            #0x12c7754
    // 0x12c73b4: ArrayLoad: r11 = r6[r10]  ; Unknown_4
    //     0x12c73b4: add             x16, x6, x10, lsl #2
    //     0x12c73b8: ldur            w11, [x16, #0xf]
    // 0x12c73bc: DecompressPointer r11
    //     0x12c73bc: add             x11, x11, HEAP, lsl #32
    // 0x12c73c0: mov             x0, x2
    // 0x12c73c4: mov             x1, x9
    // 0x12c73c8: cmp             x1, x0
    // 0x12c73cc: b.hs            #0x12c7758
    // 0x12c73d0: mov             x1, x6
    // 0x12c73d4: mov             x0, x11
    // 0x12c73d8: ArrayStore: r1[r9] = r0  ; List_4
    //     0x12c73d8: add             x25, x1, x9, lsl #2
    //     0x12c73dc: add             x25, x25, #0xf
    //     0x12c73e0: str             w0, [x25]
    //     0x12c73e4: tbz             w0, #0, #0x12c7400
    //     0x12c73e8: ldurb           w16, [x1, #-1]
    //     0x12c73ec: ldurb           w17, [x0, #-1]
    //     0x12c73f0: and             x16, x17, x16, lsr #2
    //     0x12c73f4: tst             x16, HEAP, lsr #32
    //     0x12c73f8: b.eq            #0x12c7400
    //     0x12c73fc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12c7400: sub             x0, x10, #1
    // 0x12c7404: sub             x1, x9, #1
    // 0x12c7408: mov             x10, x0
    // 0x12c740c: mov             x9, x1
    // 0x12c7410: b               #0x12c7390
    // 0x12c7414: add             x9, x8, x0
    // 0x12c7418: mov             x10, x8
    // 0x12c741c: mov             x8, x4
    // 0x12c7420: CheckStackOverflow
    //     0x12c7420: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c7424: cmp             SP, x16
    //     0x12c7428: b.ls            #0x12c775c
    // 0x12c742c: cmp             x10, x9
    // 0x12c7430: b.ge            #0x12c74a4
    // 0x12c7434: mov             x0, x2
    // 0x12c7438: mov             x1, x10
    // 0x12c743c: cmp             x1, x0
    // 0x12c7440: b.hs            #0x12c7764
    // 0x12c7444: ArrayLoad: r11 = r6[r10]  ; Unknown_4
    //     0x12c7444: add             x16, x6, x10, lsl #2
    //     0x12c7448: ldur            w11, [x16, #0xf]
    // 0x12c744c: DecompressPointer r11
    //     0x12c744c: add             x11, x11, HEAP, lsl #32
    // 0x12c7450: mov             x0, x2
    // 0x12c7454: mov             x1, x8
    // 0x12c7458: cmp             x1, x0
    // 0x12c745c: b.hs            #0x12c7768
    // 0x12c7460: mov             x1, x6
    // 0x12c7464: mov             x0, x11
    // 0x12c7468: ArrayStore: r1[r8] = r0  ; List_4
    //     0x12c7468: add             x25, x1, x8, lsl #2
    //     0x12c746c: add             x25, x25, #0xf
    //     0x12c7470: str             w0, [x25]
    //     0x12c7474: tbz             w0, #0, #0x12c7490
    //     0x12c7478: ldurb           w16, [x1, #-1]
    //     0x12c747c: ldurb           w17, [x0, #-1]
    //     0x12c7480: and             x16, x17, x16, lsr #2
    //     0x12c7484: tst             x16, HEAP, lsr #32
    //     0x12c7488: b.eq            #0x12c7490
    //     0x12c748c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12c7490: add             x0, x10, #1
    // 0x12c7494: add             x1, x8, #1
    // 0x12c7498: mov             x10, x0
    // 0x12c749c: mov             x8, x1
    // 0x12c74a0: b               #0x12c7420
    // 0x12c74a4: mov             x1, x3
    // 0x12c74a8: mov             x2, x7
    // 0x12c74ac: r0 = length=()
    //     0x12c74ac: bl              #0x9fa1d0  ; [dart:core] _GrowableList::length=
    // 0x12c74b0: ldur            x2, [fp, #-0x60]
    // 0x12c74b4: b               #0x12c75c0
    // 0x12c74b8: ldur            x5, [fp, #-0x58]
    // 0x12c74bc: ldur            x4, [fp, #-0x40]
    // 0x12c74c0: ldur            x0, [fp, #-0x38]
    // 0x12c74c4: mov             x1, x5
    // 0x12c74c8: cmp             x1, x0
    // 0x12c74cc: b.hs            #0x12c776c
    // 0x12c74d0: ArrayLoad: r0 = r4[r5]  ; Unknown_4
    //     0x12c74d0: add             x16, x4, x5, lsl #2
    //     0x12c74d4: ldur            w0, [x16, #0xf]
    // 0x12c74d8: DecompressPointer r0
    //     0x12c74d8: add             x0, x0, HEAP, lsl #32
    // 0x12c74dc: LoadField: r1 = r0->field_7
    //     0x12c74dc: ldur            x1, [x0, #7]
    // 0x12c74e0: lsl             x0, x1, #0x10
    // 0x12c74e4: orr             x2, x3, x0
    // 0x12c74e8: r0 = BoxInt64Instr(r2)
    //     0x12c74e8: sbfiz           x0, x2, #1, #0x1f
    //     0x12c74ec: cmp             x2, x0, asr #1
    //     0x12c74f0: b.eq            #0x12c74fc
    //     0x12c74f4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12c74f8: stur            x2, [x0, #7]
    // 0x12c74fc: mov             x2, x0
    // 0x12c7500: r1 = _ConstMap len:242
    //     0x12c7500: add             x1, PP, #0x80, lsl #12  ; [pp+0x805e0] Map<int, int>(242)
    //     0x12c7504: ldr             x1, [x1, #0x5e0]
    // 0x12c7508: r0 = []()
    //     0x12c7508: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x12c750c: cmp             w0, NULL
    // 0x12c7510: b.eq            #0x12c7528
    // 0x12c7514: r1 = LoadInt32Instr(r0)
    //     0x12c7514: sbfx            x1, x0, #1, #0x1f
    //     0x12c7518: tbz             w0, #0, #0x12c7520
    //     0x12c751c: ldur            x1, [x0, #7]
    // 0x12c7520: mov             x2, x1
    // 0x12c7524: b               #0x12c752c
    // 0x12c7528: ldur            x2, [fp, #-0x28]
    // 0x12c752c: ldur            x0, [fp, #-0x60]
    // 0x12c7530: stur            x2, [fp, #-0x68]
    // 0x12c7534: LoadField: r1 = r0->field_b
    //     0x12c7534: ldur            w1, [x0, #0xb]
    // 0x12c7538: LoadField: r3 = r0->field_f
    //     0x12c7538: ldur            w3, [x0, #0xf]
    // 0x12c753c: DecompressPointer r3
    //     0x12c753c: add             x3, x3, HEAP, lsl #32
    // 0x12c7540: LoadField: r4 = r3->field_b
    //     0x12c7540: ldur            w4, [x3, #0xb]
    // 0x12c7544: r3 = LoadInt32Instr(r1)
    //     0x12c7544: sbfx            x3, x1, #1, #0x1f
    // 0x12c7548: stur            x3, [fp, #-0x28]
    // 0x12c754c: r1 = LoadInt32Instr(r4)
    //     0x12c754c: sbfx            x1, x4, #1, #0x1f
    // 0x12c7550: cmp             x3, x1
    // 0x12c7554: b.ne            #0x12c7560
    // 0x12c7558: mov             x1, x0
    // 0x12c755c: r0 = _growToNextCapacity()
    //     0x12c755c: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x12c7560: ldur            x2, [fp, #-0x60]
    // 0x12c7564: ldur            x3, [fp, #-0x68]
    // 0x12c7568: ldur            x4, [fp, #-0x28]
    // 0x12c756c: add             x5, x4, #1
    // 0x12c7570: lsl             x6, x5, #1
    // 0x12c7574: StoreField: r2->field_b = r6
    //     0x12c7574: stur            w6, [x2, #0xb]
    // 0x12c7578: LoadField: r5 = r2->field_f
    //     0x12c7578: ldur            w5, [x2, #0xf]
    // 0x12c757c: DecompressPointer r5
    //     0x12c757c: add             x5, x5, HEAP, lsl #32
    // 0x12c7580: r0 = BoxInt64Instr(r3)
    //     0x12c7580: sbfiz           x0, x3, #1, #0x1f
    //     0x12c7584: cmp             x3, x0, asr #1
    //     0x12c7588: b.eq            #0x12c7594
    //     0x12c758c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12c7590: stur            x3, [x0, #7]
    // 0x12c7594: mov             x1, x5
    // 0x12c7598: ArrayStore: r1[r4] = r0  ; List_4
    //     0x12c7598: add             x25, x1, x4, lsl #2
    //     0x12c759c: add             x25, x25, #0xf
    //     0x12c75a0: str             w0, [x25]
    //     0x12c75a4: tbz             w0, #0, #0x12c75c0
    //     0x12c75a8: ldurb           w16, [x1, #-1]
    //     0x12c75ac: ldurb           w17, [x0, #-1]
    //     0x12c75b0: and             x16, x17, x16, lsr #2
    //     0x12c75b4: tst             x16, HEAP, lsr #32
    //     0x12c75b8: b.eq            #0x12c75c0
    //     0x12c75bc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12c75c0: ldur            x1, [fp, #-0x58]
    // 0x12c75c4: add             x5, x1, #1
    // 0x12c75c8: ldur            x8, [fp, #-0x30]
    // 0x12c75cc: ldur            x7, [fp, #-0x48]
    // 0x12c75d0: ldur            x6, [fp, #-0x50]
    // 0x12c75d4: ldur            x3, [fp, #-0x20]
    // 0x12c75d8: b               #0x12c6418
    // 0x12c75dc: mov             x0, x2
    // 0x12c75e0: LeaveFrame
    //     0x12c75e0: mov             SP, fp
    //     0x12c75e4: ldp             fp, lr, [SP], #0x10
    // 0x12c75e8: ret
    //     0x12c75e8: ret             
    // 0x12c75ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c75ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c75f0: b               #0x12c6100
    // 0x12c75f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c75f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c75f8: b               #0x12c6148
    // 0x12c75fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c75fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c7600: b               #0x12c61a4
    // 0x12c7604: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c7604: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c7608: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c7608: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c760c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c760c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c7610: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c7610: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c7614: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c7614: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c7618: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c7618: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c761c: b               #0x12c643c
    // 0x12c7620: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c7620: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c7624: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c7624: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c7628: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c7628: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c762c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c762c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c7630: b               #0x12c660c
    // 0x12c7634: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c7634: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c7638: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c7638: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c763c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c763c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c7640: b               #0x12c669c
    // 0x12c7644: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c7644: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c7648: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c7648: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c764c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c764c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c7650: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c7650: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c7654: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c7654: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c7658: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c7658: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c765c: b               #0x12c684c
    // 0x12c7660: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c7660: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c7664: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c7664: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c7668: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c7668: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c766c: b               #0x12c68dc
    // 0x12c7670: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c7670: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c7674: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c7674: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c7678: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c7678: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c767c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c767c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c7680: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c7680: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c7684: b               #0x12c6a18
    // 0x12c7688: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c7688: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c768c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c768c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c7690: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c7690: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c7694: b               #0x12c6aa8
    // 0x12c7698: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c7698: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c769c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c769c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c76a0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c76a0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c76a4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c76a4: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c76a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c76a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c76ac: b               #0x12c6be0
    // 0x12c76b0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c76b0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c76b4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c76b4: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c76b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c76b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c76bc: b               #0x12c6c70
    // 0x12c76c0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c76c0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c76c4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c76c4: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c76c8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c76c8: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c76cc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c76cc: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c76d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c76d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c76d4: b               #0x12c6dc4
    // 0x12c76d8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c76d8: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c76dc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c76dc: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c76e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c76e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c76e4: b               #0x12c6e54
    // 0x12c76e8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c76e8: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c76ec: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c76ec: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c76f0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c76f0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c76f4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c76f4: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c76f8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c76f8: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c76fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c76fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c7700: b               #0x12c700c
    // 0x12c7704: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c7704: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c7708: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c7708: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c770c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c770c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c7710: b               #0x12c709c
    // 0x12c7714: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c7714: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c7718: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c7718: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c771c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c771c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c7720: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c7720: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c7724: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c7724: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c7728: b               #0x12c71d4
    // 0x12c772c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c772c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c7730: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c7730: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c7734: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c7734: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c7738: b               #0x12c7264
    // 0x12c773c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c773c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c7740: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c7740: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c7744: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c7744: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c7748: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c7748: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c774c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c774c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c7750: b               #0x12c739c
    // 0x12c7754: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c7754: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c7758: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c7758: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c775c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c775c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c7760: b               #0x12c742c
    // 0x12c7764: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c7764: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c7768: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c7768: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c776c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c776c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _compose(/* No info */) {
    // ** addr: 0x12c8578, size: 0x73c
    // 0x12c8578: EnterFrame
    //     0x12c8578: stp             fp, lr, [SP, #-0x10]!
    //     0x12c857c: mov             fp, SP
    // 0x12c8580: AllocStack(0x78)
    //     0x12c8580: sub             SP, SP, #0x78
    // 0x12c8584: SetupParameters(Normalization this /* r1 => r2 */)
    //     0x12c8584: mov             x2, x1
    // 0x12c8588: CheckStackOverflow
    //     0x12c8588: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c858c: cmp             SP, x16
    //     0x12c8590: b.ls            #0x12c8c7c
    // 0x12c8594: LoadField: r3 = r2->field_7
    //     0x12c8594: ldur            w3, [x2, #7]
    // 0x12c8598: DecompressPointer r3
    //     0x12c8598: add             x3, x3, HEAP, lsl #32
    // 0x12c859c: stur            x3, [fp, #-0x18]
    // 0x12c85a0: LoadField: r0 = r3->field_b
    //     0x12c85a0: ldur            w0, [x3, #0xb]
    // 0x12c85a4: r1 = LoadInt32Instr(r0)
    //     0x12c85a4: sbfx            x1, x0, #1, #0x1f
    // 0x12c85a8: cbnz            w0, #0x12c85bc
    // 0x12c85ac: r0 = Null
    //     0x12c85ac: mov             x0, NULL
    // 0x12c85b0: LeaveFrame
    //     0x12c85b0: mov             SP, fp
    //     0x12c85b4: ldp             fp, lr, [SP], #0x10
    // 0x12c85b8: ret
    //     0x12c85b8: ret             
    // 0x12c85bc: mov             x0, x1
    // 0x12c85c0: r1 = 0
    //     0x12c85c0: mov             x1, #0
    // 0x12c85c4: cmp             x1, x0
    // 0x12c85c8: b.hs            #0x12c8c84
    // 0x12c85cc: LoadField: r0 = r3->field_f
    //     0x12c85cc: ldur            w0, [x3, #0xf]
    // 0x12c85d0: DecompressPointer r0
    //     0x12c85d0: add             x0, x0, HEAP, lsl #32
    // 0x12c85d4: LoadField: r4 = r0->field_f
    //     0x12c85d4: ldur            w4, [x0, #0xf]
    // 0x12c85d8: DecompressPointer r4
    //     0x12c85d8: add             x4, x4, HEAP, lsl #32
    // 0x12c85dc: LoadField: r5 = r2->field_b
    //     0x12c85dc: ldur            w5, [x2, #0xb]
    // 0x12c85e0: DecompressPointer r5
    //     0x12c85e0: add             x5, x5, HEAP, lsl #32
    // 0x12c85e4: stur            x5, [fp, #-0x10]
    // 0x12c85e8: LoadField: r0 = r5->field_b
    //     0x12c85e8: ldur            w0, [x5, #0xb]
    // 0x12c85ec: r1 = LoadInt32Instr(r0)
    //     0x12c85ec: sbfx            x1, x0, #1, #0x1f
    // 0x12c85f0: mov             x0, x1
    // 0x12c85f4: r1 = 0
    //     0x12c85f4: mov             x1, #0
    // 0x12c85f8: cmp             x1, x0
    // 0x12c85fc: b.hs            #0x12c8c88
    // 0x12c8600: LoadField: r2 = r5->field_f
    //     0x12c8600: ldur            w2, [x5, #0xf]
    // 0x12c8604: DecompressPointer r2
    //     0x12c8604: add             x2, x2, HEAP, lsl #32
    // 0x12c8608: LoadField: r0 = r2->field_f
    //     0x12c8608: ldur            w0, [x2, #0xf]
    // 0x12c860c: DecompressPointer r0
    //     0x12c860c: add             x0, x0, HEAP, lsl #32
    // 0x12c8610: r1 = LoadInt32Instr(r0)
    //     0x12c8610: sbfx            x1, x0, #1, #0x1f
    //     0x12c8614: tbz             w0, #0, #0x12c861c
    //     0x12c8618: ldur            x1, [x0, #7]
    // 0x12c861c: add             x6, x1, #1
    // 0x12c8620: r0 = BoxInt64Instr(r6)
    //     0x12c8620: sbfiz           x0, x6, #1, #0x1f
    //     0x12c8624: cmp             x6, x0, asr #1
    //     0x12c8628: b.eq            #0x12c8634
    //     0x12c862c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12c8630: stur            x6, [x0, #7]
    // 0x12c8634: mov             x1, x2
    // 0x12c8638: ArrayStore: r1[0] = r0  ; List_4
    //     0x12c8638: add             x25, x1, #0xf
    //     0x12c863c: str             w0, [x25]
    //     0x12c8640: tbz             w0, #0, #0x12c865c
    //     0x12c8644: ldurb           w16, [x1, #-1]
    //     0x12c8648: ldurb           w17, [x0, #-1]
    //     0x12c864c: and             x16, x17, x16, lsr #2
    //     0x12c8650: tst             x16, HEAP, lsr #32
    //     0x12c8654: b.eq            #0x12c865c
    //     0x12c8658: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12c865c: r0 = LoadInt32Instr(r4)
    //     0x12c865c: sbfx            x0, x4, #1, #0x1f
    //     0x12c8660: tbz             w4, #0, #0x12c8668
    //     0x12c8664: ldur            x0, [x4, #7]
    // 0x12c8668: mov             x1, x0
    // 0x12c866c: stur            x0, [fp, #-8]
    // 0x12c8670: r0 = _getCanonicalClass()
    //     0x12c8670: bl              #0x12c8d68  ; [package:bidi/bidi.dart] ::_getCanonicalClass
    // 0x12c8674: r16 = Instance__CanonicalClass
    //     0x12c8674: add             x16, PP, #0x80, lsl #12  ; [pp+0x80608] Obj!_CanonicalClass@12a0401
    //     0x12c8678: ldr             x16, [x16, #0x608]
    // 0x12c867c: cmp             w0, w16
    // 0x12c8680: b.eq            #0x12c8698
    // 0x12c8684: r0 = _CanonicalClass()
    //     0x12c8684: bl              #0x12c8d5c  ; Allocate_CanonicalClassStub -> _CanonicalClass (size=0x10)
    // 0x12c8688: mov             x1, x0
    // 0x12c868c: r0 = 256
    //     0x12c868c: mov             x0, #0x100
    // 0x12c8690: StoreField: r1->field_7 = r0
    //     0x12c8690: stur            x0, [x1, #7]
    // 0x12c8694: mov             x0, x1
    // 0x12c8698: ldur            x3, [fp, #-0x18]
    // 0x12c869c: LoadField: r1 = r3->field_b
    //     0x12c869c: ldur            w1, [x3, #0xb]
    // 0x12c86a0: r2 = LoadInt32Instr(r1)
    //     0x12c86a0: sbfx            x2, x1, #1, #0x1f
    // 0x12c86a4: r4 = LoadInt32Instr(r1)
    //     0x12c86a4: sbfx            x4, x1, #1, #0x1f
    // 0x12c86a8: ldur            x8, [fp, #-8]
    // 0x12c86ac: mov             x7, x0
    // 0x12c86b0: mov             x6, x2
    // 0x12c86b4: mov             x0, x4
    // 0x12c86b8: r10 = 0
    //     0x12c86b8: mov             x10, #0
    // 0x12c86bc: r9 = 1
    //     0x12c86bc: mov             x9, #1
    // 0x12c86c0: r5 = 1
    //     0x12c86c0: mov             x5, #1
    // 0x12c86c4: ldur            x4, [fp, #-0x10]
    // 0x12c86c8: stur            x10, [fp, #-8]
    // 0x12c86cc: stur            x9, [fp, #-0x28]
    // 0x12c86d0: stur            x8, [fp, #-0x30]
    // 0x12c86d4: stur            x7, [fp, #-0x38]
    // 0x12c86d8: stur            x6, [fp, #-0x40]
    // 0x12c86dc: stur            x5, [fp, #-0x48]
    // 0x12c86e0: CheckStackOverflow
    //     0x12c86e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c86e4: cmp             SP, x16
    //     0x12c86e8: b.ls            #0x12c8c8c
    // 0x12c86ec: cmp             x5, x0
    // 0x12c86f0: b.ge            #0x12c8c2c
    // 0x12c86f4: mov             x1, x5
    // 0x12c86f8: cmp             x1, x0
    // 0x12c86fc: b.hs            #0x12c8c94
    // 0x12c8700: LoadField: r0 = r3->field_f
    //     0x12c8700: ldur            w0, [x3, #0xf]
    // 0x12c8704: DecompressPointer r0
    //     0x12c8704: add             x0, x0, HEAP, lsl #32
    // 0x12c8708: ArrayLoad: r11 = r0[r5]  ; Unknown_4
    //     0x12c8708: add             x16, x0, x5, lsl #2
    //     0x12c870c: ldur            w11, [x16, #0xf]
    // 0x12c8710: DecompressPointer r11
    //     0x12c8710: add             x11, x11, HEAP, lsl #32
    // 0x12c8714: mov             x2, x11
    // 0x12c8718: stur            x11, [fp, #-0x20]
    // 0x12c871c: r1 = _ConstMap len:642
    //     0x12c871c: add             x1, PP, #0x80, lsl #12  ; [pp+0x80610] Map<int, _CanonicalClass>(642)
    //     0x12c8720: ldr             x1, [x1, #0x610]
    // 0x12c8724: r0 = []()
    //     0x12c8724: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x12c8728: cmp             w0, NULL
    // 0x12c872c: b.ne            #0x12c873c
    // 0x12c8730: r3 = Instance__CanonicalClass
    //     0x12c8730: add             x3, PP, #0x80, lsl #12  ; [pp+0x80608] Obj!_CanonicalClass@12a0401
    //     0x12c8734: ldr             x3, [x3, #0x608]
    // 0x12c8738: b               #0x12c8740
    // 0x12c873c: mov             x3, x0
    // 0x12c8740: stur            x3, [fp, #-0x68]
    // 0x12c8744: LoadField: r4 = r3->field_7
    //     0x12c8744: ldur            x4, [x3, #7]
    // 0x12c8748: stur            x4, [fp, #-0x60]
    // 0x12c874c: cmp             x4, #0x1c
    // 0x12c8750: b.lt            #0x12c876c
    // 0x12c8754: cmp             x4, #0x23
    // 0x12c8758: r16 = true
    //     0x12c8758: add             x16, NULL, #0x20  ; true
    // 0x12c875c: r17 = false
    //     0x12c875c: add             x17, NULL, #0x30  ; false
    // 0x12c8760: csel            x0, x16, x17, le
    // 0x12c8764: mov             x6, x0
    // 0x12c8768: b               #0x12c8770
    // 0x12c876c: r6 = false
    //     0x12c876c: add             x6, NULL, #0x30  ; false
    // 0x12c8770: ldur            x5, [fp, #-0x30]
    // 0x12c8774: stur            x6, [fp, #-0x58]
    // 0x12c8778: tbz             x5, #0x3f, #0x12c8784
    // 0x12c877c: ldur            x7, [fp, #-0x20]
    // 0x12c8780: b               #0x12c87b8
    // 0x12c8784: r17 = 65535
    //     0x12c8784: mov             x17, #0xffff
    // 0x12c8788: cmp             x5, x17
    // 0x12c878c: b.le            #0x12c8798
    // 0x12c8790: ldur            x7, [fp, #-0x20]
    // 0x12c8794: b               #0x12c87b8
    // 0x12c8798: ldur            x7, [fp, #-0x20]
    // 0x12c879c: r0 = LoadInt32Instr(r7)
    //     0x12c879c: sbfx            x0, x7, #1, #0x1f
    //     0x12c87a0: tbz             w7, #0, #0x12c87a8
    //     0x12c87a4: ldur            x0, [x7, #7]
    // 0x12c87a8: tbnz            x0, #0x3f, #0x12c87b8
    // 0x12c87ac: r17 = 65535
    //     0x12c87ac: mov             x17, #0xffff
    // 0x12c87b0: cmp             x0, x17
    // 0x12c87b4: b.le            #0x12c87c0
    // 0x12c87b8: r3 = 65535
    //     0x12c87b8: mov             x3, #0xffff
    // 0x12c87bc: b               #0x12c8834
    // 0x12c87c0: r8 = 4
    //     0x12c87c0: mov             x8, #4
    // 0x12c87c4: r0 = BoxInt64Instr(r5)
    //     0x12c87c4: sbfiz           x0, x5, #1, #0x1f
    //     0x12c87c8: cmp             x5, x0, asr #1
    //     0x12c87cc: b.eq            #0x12c87d8
    //     0x12c87d0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12c87d4: stur            x5, [x0, #7]
    // 0x12c87d8: mov             x2, x8
    // 0x12c87dc: r1 = Null
    //     0x12c87dc: mov             x1, NULL
    // 0x12c87e0: stur            x0, [fp, #-0x50]
    // 0x12c87e4: r0 = AllocateArray()
    //     0x12c87e4: bl              #0x13df928  ; AllocateArrayStub
    // 0x12c87e8: mov             x2, x0
    // 0x12c87ec: ldur            x0, [fp, #-0x50]
    // 0x12c87f0: stur            x2, [fp, #-0x70]
    // 0x12c87f4: StoreField: r2->field_f = r0
    //     0x12c87f4: stur            w0, [x2, #0xf]
    // 0x12c87f8: ldur            x0, [fp, #-0x20]
    // 0x12c87fc: StoreField: r2->field_13 = r0
    //     0x12c87fc: stur            w0, [x2, #0x13]
    // 0x12c8800: r1 = <int>
    //     0x12c8800: ldr             x1, [PP, #0x50]  ; [pp+0x50] TypeArguments: <int>
    // 0x12c8804: r0 = AllocateGrowableArray()
    //     0x12c8804: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x12c8808: mov             x1, x0
    // 0x12c880c: ldur            x0, [fp, #-0x70]
    // 0x12c8810: StoreField: r1->field_f = r0
    //     0x12c8810: stur            w0, [x1, #0xf]
    // 0x12c8814: r0 = 4
    //     0x12c8814: mov             x0, #4
    // 0x12c8818: StoreField: r1->field_b = r0
    //     0x12c8818: stur            w0, [x1, #0xb]
    // 0x12c881c: r2 = 0
    //     0x12c881c: mov             x2, #0
    // 0x12c8820: r3 = Null
    //     0x12c8820: mov             x3, NULL
    // 0x12c8824: r0 = createFromCharCodes()
    //     0x12c8824: bl              #0x7e5490  ; [dart:core] _StringBase::createFromCharCodes
    // 0x12c8828: mov             x1, x0
    // 0x12c882c: r0 = compose()
    //     0x12c882c: bl              #0x12c8d04  ; [package:bidi/bidi.dart] ::compose
    // 0x12c8830: mov             x3, x0
    // 0x12c8834: stur            x3, [fp, #-0x78]
    // 0x12c8838: r0 = BoxInt64Instr(r3)
    //     0x12c8838: sbfiz           x0, x3, #1, #0x1f
    //     0x12c883c: cmp             x3, x0, asr #1
    //     0x12c8840: b.eq            #0x12c884c
    //     0x12c8844: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12c8848: stur            x3, [x0, #7]
    // 0x12c884c: mov             x2, x0
    // 0x12c8850: r1 = _ConstMap len:2390
    //     0x12c8850: add             x1, PP, #0x80, lsl #12  ; [pp+0x80618] Map<int, DecompositionType>(2390)
    //     0x12c8854: ldr             x1, [x1, #0x618]
    // 0x12c8858: stur            x0, [fp, #-0x50]
    // 0x12c885c: r0 = []()
    //     0x12c885c: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x12c8860: cmp             w0, NULL
    // 0x12c8864: b.ne            #0x12c8870
    // 0x12c8868: ldur            x0, [fp, #-0x58]
    // 0x12c886c: b               #0x12c8878
    // 0x12c8870: ldur            x0, [fp, #-0x58]
    // 0x12c8874: tbnz            w0, #4, #0x12c89c0
    // 0x12c8878: ldur            x2, [fp, #-0x78]
    // 0x12c887c: r17 = 65535
    //     0x12c887c: mov             x17, #0xffff
    // 0x12c8880: cmp             x2, x17
    // 0x12c8884: b.eq            #0x12c89b0
    // 0x12c8888: ldur            x3, [fp, #-0x38]
    // 0x12c888c: ldur            x1, [fp, #-0x60]
    // 0x12c8890: LoadField: r4 = r3->field_7
    //     0x12c8890: ldur            x4, [x3, #7]
    // 0x12c8894: cmp             x4, x1
    // 0x12c8898: b.lt            #0x12c88ac
    // 0x12c889c: r16 = Instance__CanonicalClass
    //     0x12c889c: add             x16, PP, #0x80, lsl #12  ; [pp+0x80608] Obj!_CanonicalClass@12a0401
    //     0x12c88a0: ldr             x16, [x16, #0x608]
    // 0x12c88a4: cmp             w3, w16
    // 0x12c88a8: b.ne            #0x12c89a0
    // 0x12c88ac: ldur            x4, [fp, #-0x18]
    // 0x12c88b0: ldur            x5, [fp, #-0x10]
    // 0x12c88b4: ldur            x6, [fp, #-8]
    // 0x12c88b8: LoadField: r7 = r4->field_b
    //     0x12c88b8: ldur            w7, [x4, #0xb]
    // 0x12c88bc: r0 = LoadInt32Instr(r7)
    //     0x12c88bc: sbfx            x0, x7, #1, #0x1f
    // 0x12c88c0: mov             x1, x6
    // 0x12c88c4: cmp             x1, x0
    // 0x12c88c8: b.hs            #0x12c8c98
    // 0x12c88cc: LoadField: r1 = r4->field_f
    //     0x12c88cc: ldur            w1, [x4, #0xf]
    // 0x12c88d0: DecompressPointer r1
    //     0x12c88d0: add             x1, x1, HEAP, lsl #32
    // 0x12c88d4: ldur            x0, [fp, #-0x50]
    // 0x12c88d8: ArrayStore: r1[r6] = r0  ; List_4
    //     0x12c88d8: add             x25, x1, x6, lsl #2
    //     0x12c88dc: add             x25, x25, #0xf
    //     0x12c88e0: str             w0, [x25]
    //     0x12c88e4: tbz             w0, #0, #0x12c8900
    //     0x12c88e8: ldurb           w16, [x1, #-1]
    //     0x12c88ec: ldurb           w17, [x0, #-1]
    //     0x12c88f0: and             x16, x17, x16, lsr #2
    //     0x12c88f4: tst             x16, HEAP, lsr #32
    //     0x12c88f8: b.eq            #0x12c8900
    //     0x12c88fc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12c8900: LoadField: r0 = r5->field_b
    //     0x12c8900: ldur            w0, [x5, #0xb]
    // 0x12c8904: r1 = LoadInt32Instr(r0)
    //     0x12c8904: sbfx            x1, x0, #1, #0x1f
    // 0x12c8908: mov             x0, x1
    // 0x12c890c: mov             x1, x6
    // 0x12c8910: cmp             x1, x0
    // 0x12c8914: b.hs            #0x12c8c9c
    // 0x12c8918: LoadField: r8 = r5->field_f
    //     0x12c8918: ldur            w8, [x5, #0xf]
    // 0x12c891c: DecompressPointer r8
    //     0x12c891c: add             x8, x8, HEAP, lsl #32
    // 0x12c8920: ArrayLoad: r0 = r8[r6]  ; Unknown_4
    //     0x12c8920: add             x16, x8, x6, lsl #2
    //     0x12c8924: ldur            w0, [x16, #0xf]
    // 0x12c8928: DecompressPointer r0
    //     0x12c8928: add             x0, x0, HEAP, lsl #32
    // 0x12c892c: r1 = LoadInt32Instr(r0)
    //     0x12c892c: sbfx            x1, x0, #1, #0x1f
    //     0x12c8930: tbz             w0, #0, #0x12c8938
    //     0x12c8934: ldur            x1, [x0, #7]
    // 0x12c8938: add             x9, x1, #1
    // 0x12c893c: r0 = BoxInt64Instr(r9)
    //     0x12c893c: sbfiz           x0, x9, #1, #0x1f
    //     0x12c8940: cmp             x9, x0, asr #1
    //     0x12c8944: b.eq            #0x12c8950
    //     0x12c8948: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12c894c: stur            x9, [x0, #7]
    // 0x12c8950: mov             x1, x8
    // 0x12c8954: ArrayStore: r1[r6] = r0  ; List_4
    //     0x12c8954: add             x25, x1, x6, lsl #2
    //     0x12c8958: add             x25, x25, #0xf
    //     0x12c895c: str             w0, [x25]
    //     0x12c8960: tbz             w0, #0, #0x12c897c
    //     0x12c8964: ldurb           w16, [x1, #-1]
    //     0x12c8968: ldurb           w17, [x0, #-1]
    //     0x12c896c: and             x16, x17, x16, lsr #2
    //     0x12c8970: tst             x16, HEAP, lsr #32
    //     0x12c8974: b.eq            #0x12c897c
    //     0x12c8978: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12c897c: r0 = LoadInt32Instr(r7)
    //     0x12c897c: sbfx            x0, x7, #1, #0x1f
    // 0x12c8980: mov             x10, x6
    // 0x12c8984: ldur            x9, [fp, #-0x28]
    // 0x12c8988: mov             x8, x2
    // 0x12c898c: mov             x7, x3
    // 0x12c8990: ldur            x6, [fp, #-0x40]
    // 0x12c8994: ldur            x2, [fp, #-0x48]
    // 0x12c8998: mov             x1, x4
    // 0x12c899c: b               #0x12c8c20
    // 0x12c89a0: ldur            x4, [fp, #-0x18]
    // 0x12c89a4: ldur            x5, [fp, #-0x10]
    // 0x12c89a8: ldur            x6, [fp, #-8]
    // 0x12c89ac: b               #0x12c89cc
    // 0x12c89b0: ldur            x4, [fp, #-0x18]
    // 0x12c89b4: ldur            x5, [fp, #-0x10]
    // 0x12c89b8: ldur            x6, [fp, #-8]
    // 0x12c89bc: b               #0x12c89cc
    // 0x12c89c0: ldur            x4, [fp, #-0x18]
    // 0x12c89c4: ldur            x5, [fp, #-0x10]
    // 0x12c89c8: ldur            x6, [fp, #-8]
    // 0x12c89cc: ldur            x7, [fp, #-0x68]
    // 0x12c89d0: r16 = Instance__CanonicalClass
    //     0x12c89d0: add             x16, PP, #0x80, lsl #12  ; [pp+0x80608] Obj!_CanonicalClass@12a0401
    //     0x12c89d4: ldr             x16, [x16, #0x608]
    // 0x12c89d8: cmp             w7, w16
    // 0x12c89dc: b.eq            #0x12c89e4
    // 0x12c89e0: tbnz            w0, #4, #0x12c8a00
    // 0x12c89e4: ldur            x2, [fp, #-0x20]
    // 0x12c89e8: r0 = LoadInt32Instr(r2)
    //     0x12c89e8: sbfx            x0, x2, #1, #0x1f
    //     0x12c89ec: tbz             w2, #0, #0x12c89f4
    //     0x12c89f0: ldur            x0, [x2, #7]
    // 0x12c89f4: ldur            x9, [fp, #-0x28]
    // 0x12c89f8: mov             x8, x0
    // 0x12c89fc: b               #0x12c8a0c
    // 0x12c8a00: ldur            x2, [fp, #-0x20]
    // 0x12c8a04: mov             x9, x6
    // 0x12c8a08: ldur            x8, [fp, #-0x30]
    // 0x12c8a0c: ldur            x6, [fp, #-0x28]
    // 0x12c8a10: stur            x9, [fp, #-0x30]
    // 0x12c8a14: stur            x8, [fp, #-0x60]
    // 0x12c8a18: LoadField: r0 = r4->field_b
    //     0x12c8a18: ldur            w0, [x4, #0xb]
    // 0x12c8a1c: r1 = LoadInt32Instr(r0)
    //     0x12c8a1c: sbfx            x1, x0, #1, #0x1f
    // 0x12c8a20: mov             x0, x1
    // 0x12c8a24: mov             x1, x6
    // 0x12c8a28: cmp             x1, x0
    // 0x12c8a2c: b.hs            #0x12c8ca0
    // 0x12c8a30: LoadField: r1 = r4->field_f
    //     0x12c8a30: ldur            w1, [x4, #0xf]
    // 0x12c8a34: DecompressPointer r1
    //     0x12c8a34: add             x1, x1, HEAP, lsl #32
    // 0x12c8a38: mov             x0, x2
    // 0x12c8a3c: ArrayStore: r1[r6] = r0  ; List_4
    //     0x12c8a3c: add             x25, x1, x6, lsl #2
    //     0x12c8a40: add             x25, x25, #0xf
    //     0x12c8a44: str             w0, [x25]
    //     0x12c8a48: tbz             w0, #0, #0x12c8a64
    //     0x12c8a4c: ldurb           w16, [x1, #-1]
    //     0x12c8a50: ldurb           w17, [x0, #-1]
    //     0x12c8a54: and             x16, x17, x16, lsr #2
    //     0x12c8a58: tst             x16, HEAP, lsr #32
    //     0x12c8a5c: b.eq            #0x12c8a64
    //     0x12c8a60: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12c8a64: LoadField: r0 = r5->field_b
    //     0x12c8a64: ldur            w0, [x5, #0xb]
    // 0x12c8a68: r1 = LoadInt32Instr(r0)
    //     0x12c8a68: sbfx            x1, x0, #1, #0x1f
    // 0x12c8a6c: mov             x0, x1
    // 0x12c8a70: mov             x1, x6
    // 0x12c8a74: cmp             x1, x0
    // 0x12c8a78: b.hs            #0x12c8ca4
    // 0x12c8a7c: LoadField: r2 = r5->field_f
    //     0x12c8a7c: ldur            w2, [x5, #0xf]
    // 0x12c8a80: DecompressPointer r2
    //     0x12c8a80: add             x2, x2, HEAP, lsl #32
    // 0x12c8a84: ArrayLoad: r0 = r2[r6]  ; Unknown_4
    //     0x12c8a84: add             x16, x2, x6, lsl #2
    //     0x12c8a88: ldur            w0, [x16, #0xf]
    // 0x12c8a8c: DecompressPointer r0
    //     0x12c8a8c: add             x0, x0, HEAP, lsl #32
    // 0x12c8a90: r1 = LoadInt32Instr(r0)
    //     0x12c8a90: sbfx            x1, x0, #1, #0x1f
    //     0x12c8a94: tbz             w0, #0, #0x12c8a9c
    //     0x12c8a98: ldur            x1, [x0, #7]
    // 0x12c8a9c: tbz             x1, #0x3f, #0x12c8b7c
    // 0x12c8aa0: mov             x10, x6
    // 0x12c8aa4: stur            x10, [fp, #-8]
    // 0x12c8aa8: CheckStackOverflow
    //     0x12c8aa8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c8aac: cmp             SP, x16
    //     0x12c8ab0: b.ls            #0x12c8ca8
    // 0x12c8ab4: LoadField: r0 = r5->field_b
    //     0x12c8ab4: ldur            w0, [x5, #0xb]
    // 0x12c8ab8: r1 = LoadInt32Instr(r0)
    //     0x12c8ab8: sbfx            x1, x0, #1, #0x1f
    // 0x12c8abc: mov             x0, x1
    // 0x12c8ac0: mov             x1, x10
    // 0x12c8ac4: cmp             x1, x0
    // 0x12c8ac8: b.hs            #0x12c8cb0
    // 0x12c8acc: LoadField: r2 = r5->field_f
    //     0x12c8acc: ldur            w2, [x5, #0xf]
    // 0x12c8ad0: DecompressPointer r2
    //     0x12c8ad0: add             x2, x2, HEAP, lsl #32
    // 0x12c8ad4: ArrayLoad: r0 = r2[r10]  ; Unknown_4
    //     0x12c8ad4: add             x16, x2, x10, lsl #2
    //     0x12c8ad8: ldur            w0, [x16, #0xf]
    // 0x12c8adc: DecompressPointer r0
    //     0x12c8adc: add             x0, x0, HEAP, lsl #32
    // 0x12c8ae0: r1 = LoadInt32Instr(r0)
    //     0x12c8ae0: sbfx            x1, x0, #1, #0x1f
    //     0x12c8ae4: tbz             w0, #0, #0x12c8aec
    //     0x12c8ae8: ldur            x1, [x0, #7]
    // 0x12c8aec: tbz             x1, #0x3f, #0x12c8b74
    // 0x12c8af0: r1 = LoadInt32Instr(r0)
    //     0x12c8af0: sbfx            x1, x0, #1, #0x1f
    //     0x12c8af4: tbz             w0, #0, #0x12c8afc
    //     0x12c8af8: ldur            x1, [x0, #7]
    // 0x12c8afc: add             x3, x1, #1
    // 0x12c8b00: r0 = BoxInt64Instr(r3)
    //     0x12c8b00: sbfiz           x0, x3, #1, #0x1f
    //     0x12c8b04: cmp             x3, x0, asr #1
    //     0x12c8b08: b.eq            #0x12c8b14
    //     0x12c8b0c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12c8b10: stur            x3, [x0, #7]
    // 0x12c8b14: mov             x1, x2
    // 0x12c8b18: ArrayStore: r1[r10] = r0  ; List_4
    //     0x12c8b18: add             x25, x1, x10, lsl #2
    //     0x12c8b1c: add             x25, x25, #0xf
    //     0x12c8b20: str             w0, [x25]
    //     0x12c8b24: tbz             w0, #0, #0x12c8b40
    //     0x12c8b28: ldurb           w16, [x1, #-1]
    //     0x12c8b2c: ldurb           w17, [x0, #-1]
    //     0x12c8b30: and             x16, x17, x16, lsr #2
    //     0x12c8b34: tst             x16, HEAP, lsr #32
    //     0x12c8b38: b.eq            #0x12c8b40
    //     0x12c8b3c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12c8b40: mov             x1, x5
    // 0x12c8b44: mov             x2, x6
    // 0x12c8b48: r3 = 0
    //     0x12c8b48: mov             x3, #0
    // 0x12c8b4c: r0 = insert()
    //     0x12c8b4c: bl              #0xa0d864  ; [dart:core] _GrowableList::insert
    // 0x12c8b50: ldur            x0, [fp, #-8]
    // 0x12c8b54: add             x10, x0, #1
    // 0x12c8b58: ldur            x4, [fp, #-0x18]
    // 0x12c8b5c: ldur            x5, [fp, #-0x10]
    // 0x12c8b60: ldur            x6, [fp, #-0x28]
    // 0x12c8b64: ldur            x9, [fp, #-0x30]
    // 0x12c8b68: ldur            x8, [fp, #-0x60]
    // 0x12c8b6c: ldur            x7, [fp, #-0x68]
    // 0x12c8b70: b               #0x12c8aa4
    // 0x12c8b74: ldur            x3, [fp, #-0x28]
    // 0x12c8b78: b               #0x12c8bd0
    // 0x12c8b7c: mov             x3, x6
    // 0x12c8b80: r1 = LoadInt32Instr(r0)
    //     0x12c8b80: sbfx            x1, x0, #1, #0x1f
    //     0x12c8b84: tbz             w0, #0, #0x12c8b8c
    //     0x12c8b88: ldur            x1, [x0, #7]
    // 0x12c8b8c: add             x4, x1, #1
    // 0x12c8b90: r0 = BoxInt64Instr(r4)
    //     0x12c8b90: sbfiz           x0, x4, #1, #0x1f
    //     0x12c8b94: cmp             x4, x0, asr #1
    //     0x12c8b98: b.eq            #0x12c8ba4
    //     0x12c8b9c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12c8ba0: stur            x4, [x0, #7]
    // 0x12c8ba4: mov             x1, x2
    // 0x12c8ba8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x12c8ba8: add             x25, x1, x3, lsl #2
    //     0x12c8bac: add             x25, x25, #0xf
    //     0x12c8bb0: str             w0, [x25]
    //     0x12c8bb4: tbz             w0, #0, #0x12c8bd0
    //     0x12c8bb8: ldurb           w16, [x1, #-1]
    //     0x12c8bbc: ldurb           w17, [x0, #-1]
    //     0x12c8bc0: and             x16, x17, x16, lsr #2
    //     0x12c8bc4: tst             x16, HEAP, lsr #32
    //     0x12c8bc8: b.eq            #0x12c8bd0
    //     0x12c8bcc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12c8bd0: ldur            x1, [fp, #-0x18]
    // 0x12c8bd4: ldur            x2, [fp, #-0x40]
    // 0x12c8bd8: LoadField: r0 = r1->field_b
    //     0x12c8bd8: ldur            w0, [x1, #0xb]
    // 0x12c8bdc: r4 = LoadInt32Instr(r0)
    //     0x12c8bdc: sbfx            x4, x0, #1, #0x1f
    // 0x12c8be0: cmp             x4, x2
    // 0x12c8be4: b.eq            #0x12c8bf8
    // 0x12c8be8: ldur            x11, [fp, #-0x48]
    // 0x12c8bec: sub             x5, x4, x2
    // 0x12c8bf0: add             x2, x11, x5
    // 0x12c8bf4: b               #0x12c8c04
    // 0x12c8bf8: ldur            x11, [fp, #-0x48]
    // 0x12c8bfc: mov             x4, x2
    // 0x12c8c00: mov             x2, x11
    // 0x12c8c04: add             x9, x3, #1
    // 0x12c8c08: r3 = LoadInt32Instr(r0)
    //     0x12c8c08: sbfx            x3, x0, #1, #0x1f
    // 0x12c8c0c: ldur            x10, [fp, #-0x30]
    // 0x12c8c10: ldur            x8, [fp, #-0x60]
    // 0x12c8c14: ldur            x7, [fp, #-0x68]
    // 0x12c8c18: mov             x6, x4
    // 0x12c8c1c: mov             x0, x3
    // 0x12c8c20: add             x5, x2, #1
    // 0x12c8c24: mov             x3, x1
    // 0x12c8c28: b               #0x12c86c4
    // 0x12c8c2c: mov             x1, x3
    // 0x12c8c30: mov             x3, x9
    // 0x12c8c34: mov             x2, x3
    // 0x12c8c38: r0 = length=()
    //     0x12c8c38: bl              #0x9fa1d0  ; [dart:core] _GrowableList::length=
    // 0x12c8c3c: ldur            x1, [fp, #-0x10]
    // 0x12c8c40: ldur            x2, [fp, #-0x28]
    // 0x12c8c44: r0 = take()
    //     0x12c8c44: bl              #0x82e2ec  ; [dart:collection] ListBase::take
    // 0x12c8c48: mov             x1, x0
    // 0x12c8c4c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x12c8c4c: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x12c8c50: r0 = toList()
    //     0x12c8c50: bl              #0xb0813c  ; [dart:_internal] SubListIterable::toList
    // 0x12c8c54: ldur            x1, [fp, #-0x10]
    // 0x12c8c58: stur            x0, [fp, #-0x18]
    // 0x12c8c5c: r0 = clear()
    //     0x12c8c5c: bl              #0xa16074  ; [dart:core] _GrowableList::clear
    // 0x12c8c60: ldur            x1, [fp, #-0x10]
    // 0x12c8c64: ldur            x2, [fp, #-0x18]
    // 0x12c8c68: r0 = addAll()
    //     0x12c8c68: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0x12c8c6c: r0 = Null
    //     0x12c8c6c: mov             x0, NULL
    // 0x12c8c70: LeaveFrame
    //     0x12c8c70: mov             SP, fp
    //     0x12c8c74: ldp             fp, lr, [SP], #0x10
    // 0x12c8c78: ret
    //     0x12c8c78: ret             
    // 0x12c8c7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c8c7c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c8c80: b               #0x12c8594
    // 0x12c8c84: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c8c84: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c8c88: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c8c88: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c8c8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c8c8c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c8c90: b               #0x12c86ec
    // 0x12c8c94: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c8c94: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c8c98: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c8c98: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c8c9c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c8c9c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c8ca0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c8ca0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c8ca4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c8ca4: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c8ca8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c8ca8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c8cac: b               #0x12c8ab4
    // 0x12c8cb0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c8cb0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  factory _ Normalization.decompose(/* No info */) {
    // ** addr: 0x12c8dc8, size: 0x3ec
    // 0x12c8dc8: EnterFrame
    //     0x12c8dc8: stp             fp, lr, [SP, #-0x10]!
    //     0x12c8dcc: mov             fp, SP
    // 0x12c8dd0: AllocStack(0x80)
    //     0x12c8dd0: sub             SP, SP, #0x80
    // 0x12c8dd4: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0x12c8dd4: mov             x0, x2
    //     0x12c8dd8: stur            x2, [fp, #-8]
    // 0x12c8ddc: CheckStackOverflow
    //     0x12c8ddc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c8de0: cmp             SP, x16
    //     0x12c8de4: b.ls            #0x12c9190
    // 0x12c8de8: r1 = <int>
    //     0x12c8de8: ldr             x1, [PP, #0x50]  ; [pp+0x50] TypeArguments: <int>
    // 0x12c8dec: r2 = 0
    //     0x12c8dec: mov             x2, #0
    // 0x12c8df0: r0 = _GrowableList()
    //     0x12c8df0: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x12c8df4: r1 = <int>
    //     0x12c8df4: ldr             x1, [PP, #0x50]  ; [pp+0x50] TypeArguments: <int>
    // 0x12c8df8: r2 = 0
    //     0x12c8df8: mov             x2, #0
    // 0x12c8dfc: stur            x0, [fp, #-0x10]
    // 0x12c8e00: r0 = _GrowableList()
    //     0x12c8e00: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x12c8e04: mov             x1, x0
    // 0x12c8e08: stur            x1, [fp, #-0x30]
    // 0x12c8e0c: r6 = false
    //     0x12c8e0c: add             x6, NULL, #0x30  ; false
    // 0x12c8e10: r5 = false
    //     0x12c8e10: add             x5, NULL, #0x30  ; false
    // 0x12c8e14: r4 = 0
    //     0x12c8e14: mov             x4, #0
    // 0x12c8e18: ldur            x3, [fp, #-8]
    // 0x12c8e1c: ldur            x2, [fp, #-0x10]
    // 0x12c8e20: stur            x6, [fp, #-0x18]
    // 0x12c8e24: stur            x5, [fp, #-0x20]
    // 0x12c8e28: stur            x4, [fp, #-0x28]
    // 0x12c8e2c: CheckStackOverflow
    //     0x12c8e2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c8e30: cmp             SP, x16
    //     0x12c8e34: b.ls            #0x12c9198
    // 0x12c8e38: r0 = LoadClassIdInstr(r3)
    //     0x12c8e38: ldur            x0, [x3, #-1]
    //     0x12c8e3c: ubfx            x0, x0, #0xc, #0x14
    // 0x12c8e40: str             x3, [SP]
    // 0x12c8e44: r0 = GDT[cid_x0 + 0xf078]()
    //     0x12c8e44: mov             x17, #0xf078
    //     0x12c8e48: add             lr, x0, x17
    //     0x12c8e4c: ldr             lr, [x21, lr, lsl #3]
    //     0x12c8e50: blr             lr
    // 0x12c8e54: r1 = LoadInt32Instr(r0)
    //     0x12c8e54: sbfx            x1, x0, #1, #0x1f
    //     0x12c8e58: tbz             w0, #0, #0x12c8e60
    //     0x12c8e5c: ldur            x1, [x0, #7]
    // 0x12c8e60: ldur            x2, [fp, #-0x28]
    // 0x12c8e64: cmp             x2, x1
    // 0x12c8e68: b.ge            #0x12c9150
    // 0x12c8e6c: ldur            x3, [fp, #-8]
    // 0x12c8e70: r0 = BoxInt64Instr(r2)
    //     0x12c8e70: sbfiz           x0, x2, #1, #0x1f
    //     0x12c8e74: cmp             x2, x0, asr #1
    //     0x12c8e78: b.eq            #0x12c8e84
    //     0x12c8e7c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12c8e80: stur            x2, [x0, #7]
    // 0x12c8e84: mov             x1, x0
    // 0x12c8e88: stur            x1, [fp, #-0x38]
    // 0x12c8e8c: r0 = LoadClassIdInstr(r3)
    //     0x12c8e8c: ldur            x0, [x3, #-1]
    //     0x12c8e90: ubfx            x0, x0, #0xc, #0x14
    // 0x12c8e94: stp             x1, x3, [SP]
    // 0x12c8e98: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x12c8e98: sub             lr, x0, #0xdfd
    //     0x12c8e9c: ldr             lr, [x21, lr, lsl #3]
    //     0x12c8ea0: blr             lr
    // 0x12c8ea4: r1 = LoadInt32Instr(r0)
    //     0x12c8ea4: sbfx            x1, x0, #1, #0x1f
    //     0x12c8ea8: tbz             w0, #0, #0x12c8eb0
    //     0x12c8eac: ldur            x1, [x0, #7]
    // 0x12c8eb0: r0 = getCharacterType()
    //     0x12c8eb0: bl              #0x12c0c54  ; [package:bidi/bidi.dart] ::getCharacterType
    // 0x12c8eb4: stur            x0, [fp, #-0x40]
    // 0x12c8eb8: r16 = Instance_CharacterType
    //     0x12c8eb8: add             x16, PP, #0x80, lsl #12  ; [pp+0x80558] Obj!CharacterType@12c7001
    //     0x12c8ebc: ldr             x16, [x16, #0x558]
    // 0x12c8ec0: cmp             w0, w16
    // 0x12c8ec4: b.ne            #0x12c8ed0
    // 0x12c8ec8: r2 = true
    //     0x12c8ec8: add             x2, NULL, #0x20  ; true
    // 0x12c8ecc: b               #0x12c8eec
    // 0x12c8ed0: r16 = Instance_CharacterType
    //     0x12c8ed0: add             x16, PP, #0x80, lsl #12  ; [pp+0x80530] Obj!CharacterType@12c6f61
    //     0x12c8ed4: ldr             x16, [x16, #0x530]
    // 0x12c8ed8: cmp             w0, w16
    // 0x12c8edc: r16 = true
    //     0x12c8edc: add             x16, NULL, #0x20  ; true
    // 0x12c8ee0: r17 = false
    //     0x12c8ee0: add             x17, NULL, #0x30  ; false
    // 0x12c8ee4: csel            x1, x16, x17, eq
    // 0x12c8ee8: mov             x2, x1
    // 0x12c8eec: ldur            x3, [fp, #-8]
    // 0x12c8ef0: ldur            x4, [fp, #-0x30]
    // 0x12c8ef4: ldur            x1, [fp, #-0x18]
    // 0x12c8ef8: r0 = |()
    //     0x12c8ef8: bl              #0xa56c3c  ; [dart:core] bool::|
    // 0x12c8efc: mov             x3, x0
    // 0x12c8f00: ldur            x0, [fp, #-0x40]
    // 0x12c8f04: stur            x3, [fp, #-0x48]
    // 0x12c8f08: r16 = Instance_CharacterType
    //     0x12c8f08: add             x16, PP, #0x80, lsl #12  ; [pp+0x80550] Obj!CharacterType@12c7021
    //     0x12c8f0c: ldr             x16, [x16, #0x550]
    // 0x12c8f10: cmp             w0, w16
    // 0x12c8f14: r16 = true
    //     0x12c8f14: add             x16, NULL, #0x20  ; true
    // 0x12c8f18: r17 = false
    //     0x12c8f18: add             x17, NULL, #0x30  ; false
    // 0x12c8f1c: csel            x2, x16, x17, eq
    // 0x12c8f20: ldur            x1, [fp, #-0x20]
    // 0x12c8f24: r0 = |()
    //     0x12c8f24: bl              #0xa56c3c  ; [dart:core] bool::|
    // 0x12c8f28: r1 = <int>
    //     0x12c8f28: ldr             x1, [PP, #0x50]  ; [pp+0x50] TypeArguments: <int>
    // 0x12c8f2c: r2 = 0
    //     0x12c8f2c: mov             x2, #0
    // 0x12c8f30: stur            x0, [fp, #-0x40]
    // 0x12c8f34: r0 = _GrowableList()
    //     0x12c8f34: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x12c8f38: mov             x2, x0
    // 0x12c8f3c: ldur            x1, [fp, #-8]
    // 0x12c8f40: stur            x2, [fp, #-0x50]
    // 0x12c8f44: r0 = LoadClassIdInstr(r1)
    //     0x12c8f44: ldur            x0, [x1, #-1]
    //     0x12c8f48: ubfx            x0, x0, #0xc, #0x14
    // 0x12c8f4c: ldur            x16, [fp, #-0x38]
    // 0x12c8f50: stp             x16, x1, [SP]
    // 0x12c8f54: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x12c8f54: sub             lr, x0, #0xdfd
    //     0x12c8f58: ldr             lr, [x21, lr, lsl #3]
    //     0x12c8f5c: blr             lr
    // 0x12c8f60: r2 = LoadInt32Instr(r0)
    //     0x12c8f60: sbfx            x2, x0, #1, #0x1f
    //     0x12c8f64: tbz             w0, #0, #0x12c8f6c
    //     0x12c8f68: ldur            x2, [x0, #7]
    // 0x12c8f6c: ldur            x3, [fp, #-0x50]
    // 0x12c8f70: r1 = false
    //     0x12c8f70: add             x1, NULL, #0x30  ; false
    // 0x12c8f74: r0 = _getRecursiveDecomposition()
    //     0x12c8f74: bl              #0x12c91c0  ; [package:bidi/bidi.dart] ::_getRecursiveDecomposition
    // 0x12c8f78: ldur            x0, [fp, #-0x50]
    // 0x12c8f7c: LoadField: r1 = r0->field_b
    //     0x12c8f7c: ldur            w1, [x0, #0xb]
    // 0x12c8f80: r2 = LoadInt32Instr(r1)
    //     0x12c8f80: sbfx            x2, x1, #1, #0x1f
    // 0x12c8f84: r3 = 1
    //     0x12c8f84: mov             x3, #1
    // 0x12c8f88: sub             x4, x3, x2
    // 0x12c8f8c: ldur            x2, [fp, #-0x30]
    // 0x12c8f90: stur            x4, [fp, #-0x60]
    // 0x12c8f94: LoadField: r1 = r2->field_b
    //     0x12c8f94: ldur            w1, [x2, #0xb]
    // 0x12c8f98: LoadField: r5 = r2->field_f
    //     0x12c8f98: ldur            w5, [x2, #0xf]
    // 0x12c8f9c: DecompressPointer r5
    //     0x12c8f9c: add             x5, x5, HEAP, lsl #32
    // 0x12c8fa0: LoadField: r6 = r5->field_b
    //     0x12c8fa0: ldur            w6, [x5, #0xb]
    // 0x12c8fa4: r5 = LoadInt32Instr(r1)
    //     0x12c8fa4: sbfx            x5, x1, #1, #0x1f
    // 0x12c8fa8: stur            x5, [fp, #-0x58]
    // 0x12c8fac: r1 = LoadInt32Instr(r6)
    //     0x12c8fac: sbfx            x1, x6, #1, #0x1f
    // 0x12c8fb0: cmp             x5, x1
    // 0x12c8fb4: b.ne            #0x12c8fc0
    // 0x12c8fb8: mov             x1, x2
    // 0x12c8fbc: r0 = _growToNextCapacity()
    //     0x12c8fbc: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x12c8fc0: ldur            x3, [fp, #-0x30]
    // 0x12c8fc4: ldur            x0, [fp, #-0x60]
    // 0x12c8fc8: ldur            x1, [fp, #-0x58]
    // 0x12c8fcc: add             x2, x1, #1
    // 0x12c8fd0: lsl             x4, x2, #1
    // 0x12c8fd4: StoreField: r3->field_b = r4
    //     0x12c8fd4: stur            w4, [x3, #0xb]
    // 0x12c8fd8: LoadField: r2 = r3->field_f
    //     0x12c8fd8: ldur            w2, [x3, #0xf]
    // 0x12c8fdc: DecompressPointer r2
    //     0x12c8fdc: add             x2, x2, HEAP, lsl #32
    // 0x12c8fe0: lsl             x4, x0, #1
    // 0x12c8fe4: ArrayStore: r2[r1] = r4  ; Unknown_4
    //     0x12c8fe4: add             x0, x2, x1, lsl #2
    //     0x12c8fe8: stur            w4, [x0, #0xf]
    // 0x12c8fec: r5 = 0
    //     0x12c8fec: mov             x5, #0
    // 0x12c8ff0: ldur            x4, [fp, #-0x10]
    // 0x12c8ff4: ldur            x0, [fp, #-0x50]
    // 0x12c8ff8: stur            x5, [fp, #-0x58]
    // 0x12c8ffc: CheckStackOverflow
    //     0x12c8ffc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c9000: cmp             SP, x16
    //     0x12c9004: b.ls            #0x12c91a0
    // 0x12c9008: LoadField: r1 = r0->field_b
    //     0x12c9008: ldur            w1, [x0, #0xb]
    // 0x12c900c: r2 = LoadInt32Instr(r1)
    //     0x12c900c: sbfx            x2, x1, #1, #0x1f
    // 0x12c9010: cmp             x5, x2
    // 0x12c9014: b.ge            #0x12c9138
    // 0x12c9018: LoadField: r1 = r0->field_f
    //     0x12c9018: ldur            w1, [x0, #0xf]
    // 0x12c901c: DecompressPointer r1
    //     0x12c901c: add             x1, x1, HEAP, lsl #32
    // 0x12c9020: ArrayLoad: r6 = r1[r5]  ; Unknown_4
    //     0x12c9020: add             x16, x1, x5, lsl #2
    //     0x12c9024: ldur            w6, [x16, #0xf]
    // 0x12c9028: DecompressPointer r6
    //     0x12c9028: add             x6, x6, HEAP, lsl #32
    // 0x12c902c: mov             x2, x6
    // 0x12c9030: stur            x6, [fp, #-0x38]
    // 0x12c9034: r1 = _ConstMap len:642
    //     0x12c9034: add             x1, PP, #0x80, lsl #12  ; [pp+0x80610] Map<int, _CanonicalClass>(642)
    //     0x12c9038: ldr             x1, [x1, #0x610]
    // 0x12c903c: r0 = []()
    //     0x12c903c: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x12c9040: cmp             w0, NULL
    // 0x12c9044: b.ne            #0x12c9050
    // 0x12c9048: r0 = Instance__CanonicalClass
    //     0x12c9048: add             x0, PP, #0x80, lsl #12  ; [pp+0x80608] Obj!_CanonicalClass@12a0401
    //     0x12c904c: ldr             x0, [x0, #0x608]
    // 0x12c9050: ldur            x3, [fp, #-0x10]
    // 0x12c9054: LoadField: r1 = r3->field_b
    //     0x12c9054: ldur            w1, [x3, #0xb]
    // 0x12c9058: r16 = Instance__CanonicalClass
    //     0x12c9058: add             x16, PP, #0x80, lsl #12  ; [pp+0x80608] Obj!_CanonicalClass@12a0401
    //     0x12c905c: ldr             x16, [x16, #0x608]
    // 0x12c9060: cmp             w0, w16
    // 0x12c9064: b.eq            #0x12c9110
    // 0x12c9068: r2 = LoadInt32Instr(r1)
    //     0x12c9068: sbfx            x2, x1, #1, #0x1f
    // 0x12c906c: LoadField: r4 = r0->field_7
    //     0x12c906c: ldur            x4, [x0, #7]
    // 0x12c9070: stur            x4, [fp, #-0x70]
    // 0x12c9074: mov             x5, x2
    // 0x12c9078: stur            x5, [fp, #-0x68]
    // 0x12c907c: CheckStackOverflow
    //     0x12c907c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c9080: cmp             SP, x16
    //     0x12c9084: b.ls            #0x12c91a8
    // 0x12c9088: cmp             x5, #0
    // 0x12c908c: b.le            #0x12c9108
    // 0x12c9090: sub             x6, x5, #1
    // 0x12c9094: stur            x6, [fp, #-0x60]
    // 0x12c9098: LoadField: r0 = r3->field_b
    //     0x12c9098: ldur            w0, [x3, #0xb]
    // 0x12c909c: r1 = LoadInt32Instr(r0)
    //     0x12c909c: sbfx            x1, x0, #1, #0x1f
    // 0x12c90a0: mov             x0, x1
    // 0x12c90a4: mov             x1, x6
    // 0x12c90a8: cmp             x1, x0
    // 0x12c90ac: b.hs            #0x12c91b0
    // 0x12c90b0: LoadField: r0 = r3->field_f
    //     0x12c90b0: ldur            w0, [x3, #0xf]
    // 0x12c90b4: DecompressPointer r0
    //     0x12c90b4: add             x0, x0, HEAP, lsl #32
    // 0x12c90b8: ArrayLoad: r2 = r0[r6]  ; Unknown_4
    //     0x12c90b8: add             x16, x0, x6, lsl #2
    //     0x12c90bc: ldur            w2, [x16, #0xf]
    // 0x12c90c0: DecompressPointer r2
    //     0x12c90c0: add             x2, x2, HEAP, lsl #32
    // 0x12c90c4: r1 = _ConstMap len:642
    //     0x12c90c4: add             x1, PP, #0x80, lsl #12  ; [pp+0x80610] Map<int, _CanonicalClass>(642)
    //     0x12c90c8: ldr             x1, [x1, #0x610]
    // 0x12c90cc: r0 = []()
    //     0x12c90cc: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x12c90d0: cmp             w0, NULL
    // 0x12c90d4: b.ne            #0x12c90e4
    // 0x12c90d8: r1 = Instance__CanonicalClass
    //     0x12c90d8: add             x1, PP, #0x80, lsl #12  ; [pp+0x80608] Obj!_CanonicalClass@12a0401
    //     0x12c90dc: ldr             x1, [x1, #0x608]
    // 0x12c90e0: b               #0x12c90e8
    // 0x12c90e4: mov             x1, x0
    // 0x12c90e8: ldur            x0, [fp, #-0x70]
    // 0x12c90ec: LoadField: r2 = r1->field_7
    //     0x12c90ec: ldur            x2, [x1, #7]
    // 0x12c90f0: cmp             x2, x0
    // 0x12c90f4: b.le            #0x12c9108
    // 0x12c90f8: ldur            x5, [fp, #-0x60]
    // 0x12c90fc: ldur            x3, [fp, #-0x10]
    // 0x12c9100: mov             x4, x0
    // 0x12c9104: b               #0x12c9078
    // 0x12c9108: ldur            x2, [fp, #-0x68]
    // 0x12c910c: b               #0x12c9118
    // 0x12c9110: r0 = LoadInt32Instr(r1)
    //     0x12c9110: sbfx            x0, x1, #1, #0x1f
    // 0x12c9114: mov             x2, x0
    // 0x12c9118: ldur            x0, [fp, #-0x58]
    // 0x12c911c: ldur            x1, [fp, #-0x10]
    // 0x12c9120: ldur            x3, [fp, #-0x38]
    // 0x12c9124: r0 = insert()
    //     0x12c9124: bl              #0xa0d864  ; [dart:core] _GrowableList::insert
    // 0x12c9128: ldur            x0, [fp, #-0x58]
    // 0x12c912c: add             x5, x0, #1
    // 0x12c9130: ldur            x3, [fp, #-0x30]
    // 0x12c9134: b               #0x12c8ff0
    // 0x12c9138: ldur            x0, [fp, #-0x28]
    // 0x12c913c: add             x4, x0, #1
    // 0x12c9140: ldur            x6, [fp, #-0x48]
    // 0x12c9144: ldur            x5, [fp, #-0x40]
    // 0x12c9148: ldur            x1, [fp, #-0x30]
    // 0x12c914c: b               #0x12c8e18
    // 0x12c9150: ldur            x0, [fp, #-0x10]
    // 0x12c9154: ldur            x1, [fp, #-0x30]
    // 0x12c9158: ldur            x3, [fp, #-0x18]
    // 0x12c915c: ldur            x2, [fp, #-0x20]
    // 0x12c9160: r0 = Normalization()
    //     0x12c9160: bl              #0x12c91b4  ; AllocateNormalizationStub -> Normalization (size=0x18)
    // 0x12c9164: ldur            x1, [fp, #-0x10]
    // 0x12c9168: StoreField: r0->field_7 = r1
    //     0x12c9168: stur            w1, [x0, #7]
    // 0x12c916c: ldur            x1, [fp, #-0x30]
    // 0x12c9170: StoreField: r0->field_b = r1
    //     0x12c9170: stur            w1, [x0, #0xb]
    // 0x12c9174: ldur            x1, [fp, #-0x18]
    // 0x12c9178: StoreField: r0->field_f = r1
    //     0x12c9178: stur            w1, [x0, #0xf]
    // 0x12c917c: ldur            x1, [fp, #-0x20]
    // 0x12c9180: StoreField: r0->field_13 = r1
    //     0x12c9180: stur            w1, [x0, #0x13]
    // 0x12c9184: LeaveFrame
    //     0x12c9184: mov             SP, fp
    //     0x12c9188: ldp             fp, lr, [SP], #0x10
    // 0x12c918c: ret
    //     0x12c918c: ret             
    // 0x12c9190: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c9190: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c9194: b               #0x12c8de8
    // 0x12c9198: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c9198: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c919c: b               #0x12c8e38
    // 0x12c91a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c91a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c91a4: b               #0x12c9008
    // 0x12c91a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c91a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c91ac: b               #0x12c9088
    // 0x12c91b0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c91b0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
}

// class id: 3609, size: 0x18, field offset: 0x8
class _CharData extends Object {

  late CharacterType type; // offset: 0x10
  late int embeddingLevel; // offset: 0xc
  late int char; // offset: 0x8
  late int index; // offset: 0x14
}

// class id: 3610, size: 0x20, field offset: 0x8
class Paragraph extends Object {

  _ Paragraph._(/* No info */) {
    // ** addr: 0x12c0cc0, size: 0x170
    // 0x12c0cc0: EnterFrame
    //     0x12c0cc0: stp             fp, lr, [SP, #-0x10]!
    //     0x12c0cc4: mov             fp, SP
    // 0x12c0cc8: AllocStack(0x28)
    //     0x12c0cc8: sub             SP, SP, #0x28
    // 0x12c0ccc: SetupParameters(Paragraph this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x12c0ccc: mov             x4, x1
    //     0x12c0cd0: mov             x0, x2
    //     0x12c0cd4: stur            x1, [fp, #-8]
    //     0x12c0cd8: stur            x2, [fp, #-0x10]
    //     0x12c0cdc: stur            x3, [fp, #-0x18]
    // 0x12c0ce0: CheckStackOverflow
    //     0x12c0ce0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c0ce4: cmp             SP, x16
    //     0x12c0ce8: b.ls            #0x12c0e28
    // 0x12c0cec: r1 = <int>
    //     0x12c0cec: ldr             x1, [PP, #0x50]  ; [pp+0x50] TypeArguments: <int>
    // 0x12c0cf0: r2 = 0
    //     0x12c0cf0: mov             x2, #0
    // 0x12c0cf4: r0 = _GrowableList()
    //     0x12c0cf4: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x12c0cf8: mov             x4, x0
    // 0x12c0cfc: ldur            x3, [fp, #-8]
    // 0x12c0d00: stur            x4, [fp, #-0x20]
    // 0x12c0d04: StoreField: r3->field_f = r0
    //     0x12c0d04: stur            w0, [x3, #0xf]
    //     0x12c0d08: ldurb           w16, [x3, #-1]
    //     0x12c0d0c: ldurb           w17, [x0, #-1]
    //     0x12c0d10: and             x16, x17, x16, lsr #2
    //     0x12c0d14: tst             x16, HEAP, lsr #32
    //     0x12c0d18: b.eq            #0x12c0d20
    //     0x12c0d1c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x12c0d20: r1 = <int>
    //     0x12c0d20: ldr             x1, [PP, #0x50]  ; [pp+0x50] TypeArguments: <int>
    // 0x12c0d24: r2 = 0
    //     0x12c0d24: mov             x2, #0
    // 0x12c0d28: r0 = _GrowableList()
    //     0x12c0d28: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x12c0d2c: ldur            x3, [fp, #-8]
    // 0x12c0d30: StoreField: r3->field_13 = r0
    //     0x12c0d30: stur            w0, [x3, #0x13]
    //     0x12c0d34: ldurb           w16, [x3, #-1]
    //     0x12c0d38: ldurb           w17, [x0, #-1]
    //     0x12c0d3c: and             x16, x17, x16, lsr #2
    //     0x12c0d40: tst             x16, HEAP, lsr #32
    //     0x12c0d44: b.eq            #0x12c0d4c
    //     0x12c0d48: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x12c0d4c: r1 = <int>
    //     0x12c0d4c: ldr             x1, [PP, #0x50]  ; [pp+0x50] TypeArguments: <int>
    // 0x12c0d50: r2 = 0
    //     0x12c0d50: mov             x2, #0
    // 0x12c0d54: r0 = _GrowableList()
    //     0x12c0d54: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x12c0d58: ldur            x3, [fp, #-8]
    // 0x12c0d5c: StoreField: r3->field_1b = r0
    //     0x12c0d5c: stur            w0, [x3, #0x1b]
    //     0x12c0d60: ldurb           w16, [x3, #-1]
    //     0x12c0d64: ldurb           w17, [x0, #-1]
    //     0x12c0d68: and             x16, x17, x16, lsr #2
    //     0x12c0d6c: tst             x16, HEAP, lsr #32
    //     0x12c0d70: b.eq            #0x12c0d78
    //     0x12c0d74: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x12c0d78: ldur            x0, [fp, #-0x18]
    // 0x12c0d7c: StoreField: r3->field_7 = r0
    //     0x12c0d7c: stur            x0, [x3, #7]
    // 0x12c0d80: ldur            x2, [fp, #-0x10]
    // 0x12c0d84: r1 = Null
    //     0x12c0d84: mov             x1, NULL
    // 0x12c0d88: r0 = Normalization.decompose()
    //     0x12c0d88: bl              #0x12c8dc8  ; [package:bidi/bidi.dart] Normalization::Normalization.decompose
    // 0x12c0d8c: mov             x3, x0
    // 0x12c0d90: ldur            x2, [fp, #-8]
    // 0x12c0d94: stur            x3, [fp, #-0x28]
    // 0x12c0d98: ArrayStore: r2[0] = r0  ; List_4
    //     0x12c0d98: stur            w0, [x2, #0x17]
    //     0x12c0d9c: ldurb           w16, [x2, #-1]
    //     0x12c0da0: ldurb           w17, [x0, #-1]
    //     0x12c0da4: and             x16, x17, x16, lsr #2
    //     0x12c0da8: tst             x16, HEAP, lsr #32
    //     0x12c0dac: b.eq            #0x12c0db4
    //     0x12c0db0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x12c0db4: ldur            x1, [fp, #-0x20]
    // 0x12c0db8: r0 = clear()
    //     0x12c0db8: bl              #0xa16074  ; [dart:core] _GrowableList::clear
    // 0x12c0dbc: ldur            x2, [fp, #-0x10]
    // 0x12c0dc0: r0 = LoadClassIdInstr(r2)
    //     0x12c0dc0: ldur            x0, [x2, #-1]
    //     0x12c0dc4: ubfx            x0, x0, #0xc, #0x14
    // 0x12c0dc8: mov             x1, x2
    // 0x12c0dcc: r0 = GDT[cid_x0 + 0x131a1]()
    //     0x12c0dcc: mov             x17, #0x31a1
    //     0x12c0dd0: movk            x17, #1, lsl #16
    //     0x12c0dd4: add             lr, x0, x17
    //     0x12c0dd8: ldr             lr, [x21, lr, lsl #3]
    //     0x12c0ddc: blr             lr
    // 0x12c0de0: tbnz            w0, #4, #0x12c0df0
    // 0x12c0de4: ldur            x1, [fp, #-0x20]
    // 0x12c0de8: ldur            x2, [fp, #-0x10]
    // 0x12c0dec: r0 = addAll()
    //     0x12c0dec: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0x12c0df0: ldur            x1, [fp, #-0x28]
    // 0x12c0df4: r0 = _compose()
    //     0x12c0df4: bl              #0x12c8578  ; [package:bidi/bidi.dart] Normalization::_compose
    // 0x12c0df8: ldur            x1, [fp, #-0x28]
    // 0x12c0dfc: r0 = _calculateEmbeddingLevel()
    //     0x12c0dfc: bl              #0x12c8458  ; [package:bidi/bidi.dart] ::_calculateEmbeddingLevel
    // 0x12c0e00: ldur            x1, [fp, #-8]
    // 0x12c0e04: ldur            x2, [fp, #-0x28]
    // 0x12c0e08: mov             x3, x0
    // 0x12c0e0c: r0 = _recalculateCharactersEmbeddingLevels()
    //     0x12c0e0c: bl              #0x12c1390  ; [package:bidi/bidi.dart] Paragraph::_recalculateCharactersEmbeddingLevels
    // 0x12c0e10: ldur            x1, [fp, #-8]
    // 0x12c0e14: r0 = _removeBidiMarkers()
    //     0x12c0e14: bl              #0x12c0e30  ; [package:bidi/bidi.dart] Paragraph::_removeBidiMarkers
    // 0x12c0e18: r0 = Null
    //     0x12c0e18: mov             x0, NULL
    // 0x12c0e1c: LeaveFrame
    //     0x12c0e1c: mov             SP, fp
    //     0x12c0e20: ldp             fp, lr, [SP], #0x10
    // 0x12c0e24: ret
    //     0x12c0e24: ret             
    // 0x12c0e28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c0e28: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c0e2c: b               #0x12c0cec
  }
  _ _removeBidiMarkers(/* No info */) {
    // ** addr: 0x12c0e30, size: 0x560
    // 0x12c0e30: EnterFrame
    //     0x12c0e30: stp             fp, lr, [SP, #-0x10]!
    //     0x12c0e34: mov             fp, SP
    // 0x12c0e38: AllocStack(0x70)
    //     0x12c0e38: sub             SP, SP, #0x70
    // 0x12c0e3c: r0 = 14
    //     0x12c0e3c: mov             x0, #0xe
    // 0x12c0e40: mov             x3, x1
    // 0x12c0e44: stur            x1, [fp, #-8]
    // 0x12c0e48: CheckStackOverflow
    //     0x12c0e48: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c0e4c: cmp             SP, x16
    //     0x12c0e50: b.ls            #0x12c1338
    // 0x12c0e54: mov             x2, x0
    // 0x12c0e58: r1 = Null
    //     0x12c0e58: mov             x1, NULL
    // 0x12c0e5c: r0 = AllocateArray()
    //     0x12c0e5c: bl              #0x13df928  ; AllocateArrayStub
    // 0x12c0e60: stur            x0, [fp, #-0x10]
    // 0x12c0e64: r16 = 16414
    //     0x12c0e64: mov             x16, #0x401e
    // 0x12c0e68: StoreField: r0->field_f = r16
    //     0x12c0e68: stur            w16, [x0, #0xf]
    // 0x12c0e6c: r16 = 16470
    //     0x12c0e6c: mov             x16, #0x4056
    // 0x12c0e70: StoreField: r0->field_13 = r16
    //     0x12c0e70: stur            w16, [x0, #0x13]
    // 0x12c0e74: r16 = 16476
    //     0x12c0e74: mov             x16, #0x405c
    // 0x12c0e78: ArrayStore: r0[0] = r16  ; List_4
    //     0x12c0e78: stur            w16, [x0, #0x17]
    // 0x12c0e7c: r16 = 16412
    //     0x12c0e7c: mov             x16, #0x401c
    // 0x12c0e80: StoreField: r0->field_1b = r16
    //     0x12c0e80: stur            w16, [x0, #0x1b]
    // 0x12c0e84: r16 = 16468
    //     0x12c0e84: mov             x16, #0x4054
    // 0x12c0e88: StoreField: r0->field_1f = r16
    //     0x12c0e88: stur            w16, [x0, #0x1f]
    // 0x12c0e8c: r16 = 16474
    //     0x12c0e8c: mov             x16, #0x405a
    // 0x12c0e90: StoreField: r0->field_23 = r16
    //     0x12c0e90: stur            w16, [x0, #0x23]
    // 0x12c0e94: r16 = 16472
    //     0x12c0e94: mov             x16, #0x4058
    // 0x12c0e98: StoreField: r0->field_27 = r16
    //     0x12c0e98: stur            w16, [x0, #0x27]
    // 0x12c0e9c: r1 = <int>
    //     0x12c0e9c: ldr             x1, [PP, #0x50]  ; [pp+0x50] TypeArguments: <int>
    // 0x12c0ea0: r0 = AllocateGrowableArray()
    //     0x12c0ea0: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x12c0ea4: mov             x2, x0
    // 0x12c0ea8: ldur            x0, [fp, #-0x10]
    // 0x12c0eac: stur            x2, [fp, #-0x18]
    // 0x12c0eb0: StoreField: r2->field_f = r0
    //     0x12c0eb0: stur            w0, [x2, #0xf]
    // 0x12c0eb4: r0 = 14
    //     0x12c0eb4: mov             x0, #0xe
    // 0x12c0eb8: StoreField: r2->field_b = r0
    //     0x12c0eb8: stur            w0, [x2, #0xb]
    // 0x12c0ebc: ldur            x0, [fp, #-8]
    // 0x12c0ec0: LoadField: r3 = r0->field_13
    //     0x12c0ec0: ldur            w3, [x0, #0x13]
    // 0x12c0ec4: DecompressPointer r3
    //     0x12c0ec4: add             x3, x3, HEAP, lsl #32
    // 0x12c0ec8: mov             x1, x3
    // 0x12c0ecc: stur            x3, [fp, #-0x10]
    // 0x12c0ed0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x12c0ed0: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x12c0ed4: r0 = toList()
    //     0x12c0ed4: bl              #0xbb6108  ; [dart:core] _GrowableList::toList
    // 0x12c0ed8: mov             x3, x0
    // 0x12c0edc: ldur            x0, [fp, #-8]
    // 0x12c0ee0: stur            x3, [fp, #-0x30]
    // 0x12c0ee4: LoadField: r4 = r0->field_1b
    //     0x12c0ee4: ldur            w4, [x0, #0x1b]
    // 0x12c0ee8: DecompressPointer r4
    //     0x12c0ee8: add             x4, x4, HEAP, lsl #32
    // 0x12c0eec: stur            x4, [fp, #-0x28]
    // 0x12c0ef0: LoadField: r0 = r3->field_7
    //     0x12c0ef0: ldur            w0, [x3, #7]
    // 0x12c0ef4: DecompressPointer r0
    //     0x12c0ef4: add             x0, x0, HEAP, lsl #32
    // 0x12c0ef8: stur            x0, [fp, #-8]
    // 0x12c0efc: r5 = 0
    //     0x12c0efc: mov             x5, #0
    // 0x12c0f00: stur            x5, [fp, #-0x20]
    // 0x12c0f04: CheckStackOverflow
    //     0x12c0f04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c0f08: cmp             SP, x16
    //     0x12c0f0c: b.ls            #0x12c1340
    // 0x12c0f10: LoadField: r1 = r3->field_b
    //     0x12c0f10: ldur            w1, [x3, #0xb]
    // 0x12c0f14: r2 = LoadInt32Instr(r1)
    //     0x12c0f14: sbfx            x2, x1, #1, #0x1f
    // 0x12c0f18: cmp             x5, x2
    // 0x12c0f1c: b.ge            #0x12c1314
    // 0x12c0f20: LoadField: r1 = r3->field_f
    //     0x12c0f20: ldur            w1, [x3, #0xf]
    // 0x12c0f24: DecompressPointer r1
    //     0x12c0f24: add             x1, x1, HEAP, lsl #32
    // 0x12c0f28: ArrayLoad: r2 = r1[r5]  ; Unknown_4
    //     0x12c0f28: add             x16, x1, x5, lsl #2
    //     0x12c0f2c: ldur            w2, [x16, #0xf]
    // 0x12c0f30: DecompressPointer r2
    //     0x12c0f30: add             x2, x2, HEAP, lsl #32
    // 0x12c0f34: ldur            x1, [fp, #-0x18]
    // 0x12c0f38: r0 = contains()
    //     0x12c0f38: bl              #0xbaf414  ; [dart:collection] ListBase::contains
    // 0x12c0f3c: tbnz            w0, #4, #0x12c12f8
    // 0x12c0f40: ldur            x3, [fp, #-0x30]
    // 0x12c0f44: ldur            x4, [fp, #-0x20]
    // 0x12c0f48: LoadField: r0 = r3->field_b
    //     0x12c0f48: ldur            w0, [x3, #0xb]
    // 0x12c0f4c: r5 = LoadInt32Instr(r0)
    //     0x12c0f4c: sbfx            x5, x0, #1, #0x1f
    // 0x12c0f50: mov             x0, x5
    // 0x12c0f54: mov             x1, x4
    // 0x12c0f58: stur            x5, [fp, #-0x68]
    // 0x12c0f5c: cmp             x1, x0
    // 0x12c0f60: b.hs            #0x12c1348
    // 0x12c0f64: LoadField: r6 = r3->field_f
    //     0x12c0f64: ldur            w6, [x3, #0xf]
    // 0x12c0f68: DecompressPointer r6
    //     0x12c0f68: add             x6, x6, HEAP, lsl #32
    // 0x12c0f6c: stur            x6, [fp, #-0x60]
    // 0x12c0f70: sub             x7, x5, #1
    // 0x12c0f74: stur            x7, [fp, #-0x58]
    // 0x12c0f78: cmp             x4, x7
    // 0x12c0f7c: b.ge            #0x12c1160
    // 0x12c0f80: add             x8, x4, #1
    // 0x12c0f84: stur            x8, [fp, #-0x50]
    // 0x12c0f88: sub             x0, x7, x4
    // 0x12c0f8c: cmp             x8, x4
    // 0x12c0f90: b.ge            #0x12c1084
    // 0x12c0f94: add             x1, x8, x0
    // 0x12c0f98: sub             x2, x1, #1
    // 0x12c0f9c: add             x1, x4, x0
    // 0x12c0fa0: sub             x0, x1, #1
    // 0x12c0fa4: mov             x10, x2
    // 0x12c0fa8: mov             x9, x0
    // 0x12c0fac: stur            x10, [fp, #-0x40]
    // 0x12c0fb0: stur            x9, [fp, #-0x48]
    // 0x12c0fb4: CheckStackOverflow
    //     0x12c0fb4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c0fb8: cmp             SP, x16
    //     0x12c0fbc: b.ls            #0x12c134c
    // 0x12c0fc0: cmp             x10, x8
    // 0x12c0fc4: b.lt            #0x12c1160
    // 0x12c0fc8: mov             x0, x5
    // 0x12c0fcc: mov             x1, x10
    // 0x12c0fd0: cmp             x1, x0
    // 0x12c0fd4: b.hs            #0x12c1354
    // 0x12c0fd8: ArrayLoad: r11 = r6[r10]  ; Unknown_4
    //     0x12c0fd8: add             x16, x6, x10, lsl #2
    //     0x12c0fdc: ldur            w11, [x16, #0xf]
    // 0x12c0fe0: DecompressPointer r11
    //     0x12c0fe0: add             x11, x11, HEAP, lsl #32
    // 0x12c0fe4: mov             x0, x11
    // 0x12c0fe8: ldur            x2, [fp, #-8]
    // 0x12c0fec: stur            x11, [fp, #-0x38]
    // 0x12c0ff0: r1 = Null
    //     0x12c0ff0: mov             x1, NULL
    // 0x12c0ff4: cmp             w2, NULL
    // 0x12c0ff8: b.eq            #0x12c1018
    // 0x12c0ffc: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x12c0ffc: ldur            w4, [x2, #0x17]
    // 0x12c1000: DecompressPointer r4
    //     0x12c1000: add             x4, x4, HEAP, lsl #32
    // 0x12c1004: r8 = X0
    //     0x12c1004: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x12c1008: LoadField: r9 = r4->field_7
    //     0x12c1008: ldur            x9, [x4, #7]
    // 0x12c100c: r3 = Null
    //     0x12c100c: add             x3, PP, #0x80, lsl #12  ; [pp+0x80480] Null
    //     0x12c1010: ldr             x3, [x3, #0x480]
    // 0x12c1014: blr             x9
    // 0x12c1018: ldur            x0, [fp, #-0x68]
    // 0x12c101c: ldur            x1, [fp, #-0x48]
    // 0x12c1020: cmp             x1, x0
    // 0x12c1024: b.hs            #0x12c1358
    // 0x12c1028: ldur            x1, [fp, #-0x60]
    // 0x12c102c: ldur            x0, [fp, #-0x38]
    // 0x12c1030: ldur            x2, [fp, #-0x48]
    // 0x12c1034: ArrayStore: r1[r2] = r0  ; List_4
    //     0x12c1034: add             x25, x1, x2, lsl #2
    //     0x12c1038: add             x25, x25, #0xf
    //     0x12c103c: str             w0, [x25]
    //     0x12c1040: tbz             w0, #0, #0x12c105c
    //     0x12c1044: ldurb           w16, [x1, #-1]
    //     0x12c1048: ldurb           w17, [x0, #-1]
    //     0x12c104c: and             x16, x17, x16, lsr #2
    //     0x12c1050: tst             x16, HEAP, lsr #32
    //     0x12c1054: b.eq            #0x12c105c
    //     0x12c1058: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12c105c: ldur            x0, [fp, #-0x40]
    // 0x12c1060: sub             x10, x0, #1
    // 0x12c1064: sub             x9, x2, #1
    // 0x12c1068: ldur            x3, [fp, #-0x30]
    // 0x12c106c: ldur            x4, [fp, #-0x20]
    // 0x12c1070: ldur            x7, [fp, #-0x58]
    // 0x12c1074: ldur            x8, [fp, #-0x50]
    // 0x12c1078: ldur            x6, [fp, #-0x60]
    // 0x12c107c: ldur            x5, [fp, #-0x68]
    // 0x12c1080: b               #0x12c0fac
    // 0x12c1084: mov             x1, x8
    // 0x12c1088: add             x3, x1, x0
    // 0x12c108c: stur            x3, [fp, #-0x70]
    // 0x12c1090: mov             x6, x1
    // 0x12c1094: ldur            x5, [fp, #-0x20]
    // 0x12c1098: ldur            x4, [fp, #-0x60]
    // 0x12c109c: stur            x6, [fp, #-0x40]
    // 0x12c10a0: stur            x5, [fp, #-0x48]
    // 0x12c10a4: CheckStackOverflow
    //     0x12c10a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c10a8: cmp             SP, x16
    //     0x12c10ac: b.ls            #0x12c135c
    // 0x12c10b0: cmp             x6, x3
    // 0x12c10b4: b.ge            #0x12c1160
    // 0x12c10b8: ldur            x0, [fp, #-0x68]
    // 0x12c10bc: mov             x1, x6
    // 0x12c10c0: cmp             x1, x0
    // 0x12c10c4: b.hs            #0x12c1364
    // 0x12c10c8: ArrayLoad: r7 = r4[r6]  ; Unknown_4
    //     0x12c10c8: add             x16, x4, x6, lsl #2
    //     0x12c10cc: ldur            w7, [x16, #0xf]
    // 0x12c10d0: DecompressPointer r7
    //     0x12c10d0: add             x7, x7, HEAP, lsl #32
    // 0x12c10d4: mov             x0, x7
    // 0x12c10d8: ldur            x2, [fp, #-8]
    // 0x12c10dc: stur            x7, [fp, #-0x38]
    // 0x12c10e0: r1 = Null
    //     0x12c10e0: mov             x1, NULL
    // 0x12c10e4: cmp             w2, NULL
    // 0x12c10e8: b.eq            #0x12c1108
    // 0x12c10ec: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x12c10ec: ldur            w4, [x2, #0x17]
    // 0x12c10f0: DecompressPointer r4
    //     0x12c10f0: add             x4, x4, HEAP, lsl #32
    // 0x12c10f4: r8 = X0
    //     0x12c10f4: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x12c10f8: LoadField: r9 = r4->field_7
    //     0x12c10f8: ldur            x9, [x4, #7]
    // 0x12c10fc: r3 = Null
    //     0x12c10fc: add             x3, PP, #0x80, lsl #12  ; [pp+0x80490] Null
    //     0x12c1100: ldr             x3, [x3, #0x490]
    // 0x12c1104: blr             x9
    // 0x12c1108: ldur            x0, [fp, #-0x68]
    // 0x12c110c: ldur            x1, [fp, #-0x48]
    // 0x12c1110: cmp             x1, x0
    // 0x12c1114: b.hs            #0x12c1368
    // 0x12c1118: ldur            x1, [fp, #-0x60]
    // 0x12c111c: ldur            x0, [fp, #-0x38]
    // 0x12c1120: ldur            x2, [fp, #-0x48]
    // 0x12c1124: ArrayStore: r1[r2] = r0  ; List_4
    //     0x12c1124: add             x25, x1, x2, lsl #2
    //     0x12c1128: add             x25, x25, #0xf
    //     0x12c112c: str             w0, [x25]
    //     0x12c1130: tbz             w0, #0, #0x12c114c
    //     0x12c1134: ldurb           w16, [x1, #-1]
    //     0x12c1138: ldurb           w17, [x0, #-1]
    //     0x12c113c: and             x16, x17, x16, lsr #2
    //     0x12c1140: tst             x16, HEAP, lsr #32
    //     0x12c1144: b.eq            #0x12c114c
    //     0x12c1148: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12c114c: ldur            x0, [fp, #-0x40]
    // 0x12c1150: add             x6, x0, #1
    // 0x12c1154: add             x5, x2, #1
    // 0x12c1158: ldur            x3, [fp, #-0x70]
    // 0x12c115c: b               #0x12c1098
    // 0x12c1160: ldur            x0, [fp, #-0x20]
    // 0x12c1164: ldur            x3, [fp, #-0x28]
    // 0x12c1168: ldur            x1, [fp, #-0x30]
    // 0x12c116c: ldur            x2, [fp, #-0x58]
    // 0x12c1170: r0 = length=()
    //     0x12c1170: bl              #0x9fa1d0  ; [dart:core] _GrowableList::length=
    // 0x12c1174: ldur            x3, [fp, #-0x28]
    // 0x12c1178: LoadField: r0 = r3->field_b
    //     0x12c1178: ldur            w0, [x3, #0xb]
    // 0x12c117c: r2 = LoadInt32Instr(r0)
    //     0x12c117c: sbfx            x2, x0, #1, #0x1f
    // 0x12c1180: mov             x0, x2
    // 0x12c1184: ldur            x1, [fp, #-0x20]
    // 0x12c1188: cmp             x1, x0
    // 0x12c118c: b.hs            #0x12c136c
    // 0x12c1190: LoadField: r4 = r3->field_f
    //     0x12c1190: ldur            w4, [x3, #0xf]
    // 0x12c1194: DecompressPointer r4
    //     0x12c1194: add             x4, x4, HEAP, lsl #32
    // 0x12c1198: sub             x5, x2, #1
    // 0x12c119c: ldur            x6, [fp, #-0x20]
    // 0x12c11a0: cmp             x6, x5
    // 0x12c11a4: b.ge            #0x12c12e4
    // 0x12c11a8: add             x7, x6, #1
    // 0x12c11ac: sub             x0, x5, x6
    // 0x12c11b0: cmp             x7, x6
    // 0x12c11b4: b.ge            #0x12c1254
    // 0x12c11b8: add             x1, x7, x0
    // 0x12c11bc: sub             x8, x1, #1
    // 0x12c11c0: add             x1, x6, x0
    // 0x12c11c4: sub             x0, x1, #1
    // 0x12c11c8: mov             x9, x8
    // 0x12c11cc: mov             x8, x0
    // 0x12c11d0: CheckStackOverflow
    //     0x12c11d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c11d4: cmp             SP, x16
    //     0x12c11d8: b.ls            #0x12c1370
    // 0x12c11dc: cmp             x9, x7
    // 0x12c11e0: b.lt            #0x12c12e4
    // 0x12c11e4: mov             x0, x2
    // 0x12c11e8: mov             x1, x9
    // 0x12c11ec: cmp             x1, x0
    // 0x12c11f0: b.hs            #0x12c1378
    // 0x12c11f4: ArrayLoad: r10 = r4[r9]  ; Unknown_4
    //     0x12c11f4: add             x16, x4, x9, lsl #2
    //     0x12c11f8: ldur            w10, [x16, #0xf]
    // 0x12c11fc: DecompressPointer r10
    //     0x12c11fc: add             x10, x10, HEAP, lsl #32
    // 0x12c1200: mov             x0, x2
    // 0x12c1204: mov             x1, x8
    // 0x12c1208: cmp             x1, x0
    // 0x12c120c: b.hs            #0x12c137c
    // 0x12c1210: mov             x1, x4
    // 0x12c1214: mov             x0, x10
    // 0x12c1218: ArrayStore: r1[r8] = r0  ; List_4
    //     0x12c1218: add             x25, x1, x8, lsl #2
    //     0x12c121c: add             x25, x25, #0xf
    //     0x12c1220: str             w0, [x25]
    //     0x12c1224: tbz             w0, #0, #0x12c1240
    //     0x12c1228: ldurb           w16, [x1, #-1]
    //     0x12c122c: ldurb           w17, [x0, #-1]
    //     0x12c1230: and             x16, x17, x16, lsr #2
    //     0x12c1234: tst             x16, HEAP, lsr #32
    //     0x12c1238: b.eq            #0x12c1240
    //     0x12c123c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12c1240: sub             x0, x9, #1
    // 0x12c1244: sub             x1, x8, #1
    // 0x12c1248: mov             x9, x0
    // 0x12c124c: mov             x8, x1
    // 0x12c1250: b               #0x12c11d0
    // 0x12c1254: add             x8, x7, x0
    // 0x12c1258: mov             x9, x7
    // 0x12c125c: mov             x7, x6
    // 0x12c1260: CheckStackOverflow
    //     0x12c1260: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c1264: cmp             SP, x16
    //     0x12c1268: b.ls            #0x12c1380
    // 0x12c126c: cmp             x9, x8
    // 0x12c1270: b.ge            #0x12c12e4
    // 0x12c1274: mov             x0, x2
    // 0x12c1278: mov             x1, x9
    // 0x12c127c: cmp             x1, x0
    // 0x12c1280: b.hs            #0x12c1388
    // 0x12c1284: ArrayLoad: r10 = r4[r9]  ; Unknown_4
    //     0x12c1284: add             x16, x4, x9, lsl #2
    //     0x12c1288: ldur            w10, [x16, #0xf]
    // 0x12c128c: DecompressPointer r10
    //     0x12c128c: add             x10, x10, HEAP, lsl #32
    // 0x12c1290: mov             x0, x2
    // 0x12c1294: mov             x1, x7
    // 0x12c1298: cmp             x1, x0
    // 0x12c129c: b.hs            #0x12c138c
    // 0x12c12a0: mov             x1, x4
    // 0x12c12a4: mov             x0, x10
    // 0x12c12a8: ArrayStore: r1[r7] = r0  ; List_4
    //     0x12c12a8: add             x25, x1, x7, lsl #2
    //     0x12c12ac: add             x25, x25, #0xf
    //     0x12c12b0: str             w0, [x25]
    //     0x12c12b4: tbz             w0, #0, #0x12c12d0
    //     0x12c12b8: ldurb           w16, [x1, #-1]
    //     0x12c12bc: ldurb           w17, [x0, #-1]
    //     0x12c12c0: and             x16, x17, x16, lsr #2
    //     0x12c12c4: tst             x16, HEAP, lsr #32
    //     0x12c12c8: b.eq            #0x12c12d0
    //     0x12c12cc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12c12d0: add             x0, x9, #1
    // 0x12c12d4: add             x1, x7, #1
    // 0x12c12d8: mov             x9, x0
    // 0x12c12dc: mov             x7, x1
    // 0x12c12e0: b               #0x12c1260
    // 0x12c12e4: mov             x1, x3
    // 0x12c12e8: mov             x2, x5
    // 0x12c12ec: r0 = length=()
    //     0x12c12ec: bl              #0x9fa1d0  ; [dart:core] _GrowableList::length=
    // 0x12c12f0: ldur            x5, [fp, #-0x20]
    // 0x12c12f4: b               #0x12c1304
    // 0x12c12f8: ldur            x0, [fp, #-0x20]
    // 0x12c12fc: add             x1, x0, #1
    // 0x12c1300: mov             x5, x1
    // 0x12c1304: ldur            x3, [fp, #-0x30]
    // 0x12c1308: ldur            x4, [fp, #-0x28]
    // 0x12c130c: ldur            x0, [fp, #-8]
    // 0x12c1310: b               #0x12c0f00
    // 0x12c1314: ldur            x1, [fp, #-0x10]
    // 0x12c1318: r0 = clear()
    //     0x12c1318: bl              #0xa16074  ; [dart:core] _GrowableList::clear
    // 0x12c131c: ldur            x1, [fp, #-0x10]
    // 0x12c1320: ldur            x2, [fp, #-0x30]
    // 0x12c1324: r0 = addAll()
    //     0x12c1324: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0x12c1328: r0 = Null
    //     0x12c1328: mov             x0, NULL
    // 0x12c132c: LeaveFrame
    //     0x12c132c: mov             SP, fp
    //     0x12c1330: ldp             fp, lr, [SP], #0x10
    // 0x12c1334: ret
    //     0x12c1334: ret             
    // 0x12c1338: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c1338: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c133c: b               #0x12c0e54
    // 0x12c1340: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c1340: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c1344: b               #0x12c0f10
    // 0x12c1348: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c1348: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c134c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c134c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c1350: b               #0x12c0fc0
    // 0x12c1354: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c1354: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c1358: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c1358: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c135c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c135c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c1360: b               #0x12c10b0
    // 0x12c1364: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c1364: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c1368: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c1368: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c136c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c136c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c1370: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c1370: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c1374: b               #0x12c11dc
    // 0x12c1378: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c1378: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c137c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c137c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c1380: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c1380: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c1384: b               #0x12c126c
    // 0x12c1388: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c1388: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c138c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c138c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _recalculateCharactersEmbeddingLevels(/* No info */) {
    // ** addr: 0x12c1390, size: 0xb80
    // 0x12c1390: EnterFrame
    //     0x12c1390: stp             fp, lr, [SP, #-0x10]!
    //     0x12c1394: mov             fp, SP
    // 0x12c1398: AllocStack(0x88)
    //     0x12c1398: sub             SP, SP, #0x88
    // 0x12c139c: SetupParameters(Paragraph this /* r1 => r2, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */)
    //     0x12c139c: mov             x0, x2
    //     0x12c13a0: stur            x2, [fp, #-0x18]
    //     0x12c13a4: mov             x2, x1
    //     0x12c13a8: stur            x1, [fp, #-0x10]
    //     0x12c13ac: stur            x3, [fp, #-0x20]
    // 0x12c13b0: CheckStackOverflow
    //     0x12c13b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c13b4: cmp             SP, x16
    //     0x12c13b8: b.ls            #0x12c1e78
    // 0x12c13bc: LoadField: r7 = r0->field_f
    //     0x12c13bc: ldur            w7, [x0, #0xf]
    // 0x12c13c0: DecompressPointer r7
    //     0x12c13c0: add             x7, x7, HEAP, lsl #32
    // 0x12c13c4: stur            x7, [fp, #-8]
    // 0x12c13c8: tbnz            w7, #4, #0x12c1400
    // 0x12c13cc: mov             x1, x0
    // 0x12c13d0: r0 = _performShaping()
    //     0x12c13d0: bl              #0x12c60e0  ; [package:bidi/bidi.dart] Normalization::_performShaping
    // 0x12c13d4: mov             x2, x0
    // 0x12c13d8: ldur            x0, [fp, #-0x18]
    // 0x12c13dc: stur            x2, [fp, #-0x30]
    // 0x12c13e0: LoadField: r3 = r0->field_7
    //     0x12c13e0: ldur            w3, [x0, #7]
    // 0x12c13e4: DecompressPointer r3
    //     0x12c13e4: add             x3, x3, HEAP, lsl #32
    // 0x12c13e8: mov             x1, x3
    // 0x12c13ec: stur            x3, [fp, #-0x28]
    // 0x12c13f0: r0 = clear()
    //     0x12c13f0: bl              #0xa16074  ; [dart:core] _GrowableList::clear
    // 0x12c13f4: ldur            x1, [fp, #-0x28]
    // 0x12c13f8: ldur            x2, [fp, #-0x30]
    // 0x12c13fc: r0 = addAll()
    //     0x12c13fc: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0x12c1400: ldur            x0, [fp, #-0x18]
    // 0x12c1404: LoadField: r3 = r0->field_7
    //     0x12c1404: ldur            w3, [x0, #7]
    // 0x12c1408: DecompressPointer r3
    //     0x12c1408: add             x3, x3, HEAP, lsl #32
    // 0x12c140c: stur            x3, [fp, #-0x30]
    // 0x12c1410: LoadField: r4 = r0->field_b
    //     0x12c1410: ldur            w4, [x0, #0xb]
    // 0x12c1414: DecompressPointer r4
    //     0x12c1414: add             x4, x4, HEAP, lsl #32
    // 0x12c1418: stur            x4, [fp, #-0x28]
    // 0x12c141c: LoadField: r1 = r3->field_b
    //     0x12c141c: ldur            w1, [x3, #0xb]
    // 0x12c1420: r2 = LoadInt32Instr(r1)
    //     0x12c1420: sbfx            x2, x1, #1, #0x1f
    // 0x12c1424: r1 = <_CharData>
    //     0x12c1424: add             x1, PP, #0x80, lsl #12  ; [pp+0x804a0] TypeArguments: <_CharData>
    //     0x12c1428: ldr             x1, [x1, #0x4a0]
    // 0x12c142c: r0 = _GrowableList()
    //     0x12c142c: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x12c1430: stur            x0, [fp, #-0x50]
    // 0x12c1434: LoadField: r1 = r0->field_b
    //     0x12c1434: ldur            w1, [x0, #0xb]
    // 0x12c1438: r2 = LoadInt32Instr(r1)
    //     0x12c1438: sbfx            x2, x1, #1, #0x1f
    // 0x12c143c: stur            x2, [fp, #-0x48]
    // 0x12c1440: LoadField: r1 = r0->field_f
    //     0x12c1440: ldur            w1, [x0, #0xf]
    // 0x12c1444: DecompressPointer r1
    //     0x12c1444: add             x1, x1, HEAP, lsl #32
    // 0x12c1448: stur            x1, [fp, #-0x40]
    // 0x12c144c: r3 = 0
    //     0x12c144c: mov             x3, #0
    // 0x12c1450: stur            x3, [fp, #-0x38]
    // 0x12c1454: CheckStackOverflow
    //     0x12c1454: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c1458: cmp             SP, x16
    //     0x12c145c: b.ls            #0x12c1e80
    // 0x12c1460: cmp             x3, x2
    // 0x12c1464: b.ge            #0x12c14c8
    // 0x12c1468: r0 = _CharData()
    //     0x12c1468: bl              #0x12c60d4  ; Allocate_CharDataStub -> _CharData (size=0x18)
    // 0x12c146c: ldr             x2, [THR, #0x90]  ; THR::object_sentinel
    // 0x12c1470: StoreField: r0->field_7 = r2
    //     0x12c1470: stur            w2, [x0, #7]
    // 0x12c1474: StoreField: r0->field_b = r2
    //     0x12c1474: stur            w2, [x0, #0xb]
    // 0x12c1478: StoreField: r0->field_f = r2
    //     0x12c1478: stur            w2, [x0, #0xf]
    // 0x12c147c: StoreField: r0->field_13 = r2
    //     0x12c147c: stur            w2, [x0, #0x13]
    // 0x12c1480: ldur            x1, [fp, #-0x40]
    // 0x12c1484: ldur            x3, [fp, #-0x38]
    // 0x12c1488: ArrayStore: r1[r3] = r0  ; List_4
    //     0x12c1488: add             x25, x1, x3, lsl #2
    //     0x12c148c: add             x25, x25, #0xf
    //     0x12c1490: str             w0, [x25]
    //     0x12c1494: tbz             w0, #0, #0x12c14b0
    //     0x12c1498: ldurb           w16, [x1, #-1]
    //     0x12c149c: ldurb           w17, [x0, #-1]
    //     0x12c14a0: and             x16, x17, x16, lsr #2
    //     0x12c14a4: tst             x16, HEAP, lsr #32
    //     0x12c14a8: b.eq            #0x12c14b0
    //     0x12c14ac: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12c14b0: add             x0, x3, #1
    // 0x12c14b4: mov             x3, x0
    // 0x12c14b8: ldur            x0, [fp, #-0x50]
    // 0x12c14bc: ldur            x1, [fp, #-0x40]
    // 0x12c14c0: ldur            x2, [fp, #-0x48]
    // 0x12c14c4: b               #0x12c1450
    // 0x12c14c8: r1 = <DirectionOverride>
    //     0x12c14c8: add             x1, PP, #0x80, lsl #12  ; [pp+0x804a8] TypeArguments: <DirectionOverride>
    //     0x12c14cc: ldr             x1, [x1, #0x4a8]
    // 0x12c14d0: r0 = ListQueue()
    //     0x12c14d0: bl              #0x8217c0  ; AllocateListQueueStub -> ListQueue<X0> (size=0x28)
    // 0x12c14d4: mov             x1, x0
    // 0x12c14d8: stur            x0, [fp, #-0x40]
    // 0x12c14dc: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x12c14dc: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x12c14e0: r0 = ListQueue()
    //     0x12c14e0: bl              #0x821650  ; [dart:collection] ListQueue::ListQueue
    // 0x12c14e4: r1 = <int>
    //     0x12c14e4: ldr             x1, [PP, #0x50]  ; [pp+0x50] TypeArguments: <int>
    // 0x12c14e8: r0 = ListQueue()
    //     0x12c14e8: bl              #0x8217c0  ; AllocateListQueueStub -> ListQueue<X0> (size=0x28)
    // 0x12c14ec: mov             x1, x0
    // 0x12c14f0: stur            x0, [fp, #-0x58]
    // 0x12c14f4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x12c14f4: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x12c14f8: r0 = ListQueue()
    //     0x12c14f8: bl              #0x821650  ; [dart:collection] ListQueue::ListQueue
    // 0x12c14fc: ldur            x10, [fp, #-0x20]
    // 0x12c1500: ldur            x4, [fp, #-0x50]
    // 0x12c1504: r9 = Instance_DirectionOverride
    //     0x12c1504: add             x9, PP, #0x80, lsl #12  ; [pp+0x804b0] Obj!DirectionOverride@12c6ec1
    //     0x12c1508: ldr             x9, [x9, #0x4b0]
    // 0x12c150c: r8 = 0
    //     0x12c150c: mov             x8, #0
    // 0x12c1510: r7 = 0
    //     0x12c1510: mov             x7, #0
    // 0x12c1514: ldur            x5, [fp, #-0x30]
    // 0x12c1518: ldur            x6, [fp, #-0x28]
    // 0x12c151c: ldur            x3, [fp, #-0x58]
    // 0x12c1520: stur            x10, [fp, #-0x38]
    // 0x12c1524: stur            x9, [fp, #-0x70]
    // 0x12c1528: stur            x8, [fp, #-0x48]
    // 0x12c152c: stur            x7, [fp, #-0x78]
    // 0x12c1530: CheckStackOverflow
    //     0x12c1530: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c1534: cmp             SP, x16
    //     0x12c1538: b.ls            #0x12c1e88
    // 0x12c153c: LoadField: r0 = r5->field_b
    //     0x12c153c: ldur            w0, [x5, #0xb]
    // 0x12c1540: r1 = LoadInt32Instr(r0)
    //     0x12c1540: sbfx            x1, x0, #1, #0x1f
    // 0x12c1544: cmp             x7, x1
    // 0x12c1548: b.ge            #0x12c1a30
    // 0x12c154c: LoadField: r0 = r5->field_f
    //     0x12c154c: ldur            w0, [x5, #0xf]
    // 0x12c1550: DecompressPointer r0
    //     0x12c1550: add             x0, x0, HEAP, lsl #32
    // 0x12c1554: ArrayLoad: r11 = r0[r7]  ; Unknown_4
    //     0x12c1554: add             x16, x0, x7, lsl #2
    //     0x12c1558: ldur            w11, [x16, #0xf]
    // 0x12c155c: DecompressPointer r11
    //     0x12c155c: add             x11, x11, HEAP, lsl #32
    // 0x12c1560: stur            x11, [fp, #-0x68]
    // 0x12c1564: LoadField: r0 = r4->field_b
    //     0x12c1564: ldur            w0, [x4, #0xb]
    // 0x12c1568: r1 = LoadInt32Instr(r0)
    //     0x12c1568: sbfx            x1, x0, #1, #0x1f
    // 0x12c156c: mov             x0, x1
    // 0x12c1570: mov             x1, x7
    // 0x12c1574: cmp             x1, x0
    // 0x12c1578: b.hs            #0x12c1e90
    // 0x12c157c: LoadField: r0 = r4->field_f
    //     0x12c157c: ldur            w0, [x4, #0xf]
    // 0x12c1580: DecompressPointer r0
    //     0x12c1580: add             x0, x0, HEAP, lsl #32
    // 0x12c1584: ArrayLoad: r12 = r0[r7]  ; Unknown_4
    //     0x12c1584: add             x16, x0, x7, lsl #2
    //     0x12c1588: ldur            w12, [x16, #0xf]
    // 0x12c158c: DecompressPointer r12
    //     0x12c158c: add             x12, x12, HEAP, lsl #32
    // 0x12c1590: mov             x2, x11
    // 0x12c1594: stur            x12, [fp, #-0x60]
    // 0x12c1598: r1 = _ConstMap len:5850
    //     0x12c1598: add             x1, PP, #0x80, lsl #12  ; [pp+0x80460] Map<int, CharacterType>(5850)
    //     0x12c159c: ldr             x1, [x1, #0x460]
    // 0x12c15a0: r0 = []()
    //     0x12c15a0: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x12c15a4: cmp             w0, NULL
    // 0x12c15a8: b.ne            #0x12c15b4
    // 0x12c15ac: r0 = Instance_CharacterType
    //     0x12c15ac: add             x0, PP, #0x80, lsl #12  ; [pp+0x804b8] Obj!CharacterType@12c6ee1
    //     0x12c15b0: ldr             x0, [x0, #0x4b8]
    // 0x12c15b4: ldur            x4, [fp, #-0x28]
    // 0x12c15b8: ldur            x2, [fp, #-0x48]
    // 0x12c15bc: ldur            x5, [fp, #-0x78]
    // 0x12c15c0: ldur            x3, [fp, #-0x50]
    // 0x12c15c4: ldur            x6, [fp, #-0x68]
    // 0x12c15c8: ldur            x1, [fp, #-0x60]
    // 0x12c15cc: StoreField: r1->field_f = r0
    //     0x12c15cc: stur            w0, [x1, #0xf]
    //     0x12c15d0: ldurb           w16, [x1, #-1]
    //     0x12c15d4: ldurb           w17, [x0, #-1]
    //     0x12c15d8: and             x16, x17, x16, lsr #2
    //     0x12c15dc: tst             x16, HEAP, lsr #32
    //     0x12c15e0: b.eq            #0x12c15e8
    //     0x12c15e4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x12c15e8: LoadField: r0 = r3->field_b
    //     0x12c15e8: ldur            w0, [x3, #0xb]
    // 0x12c15ec: r1 = LoadInt32Instr(r0)
    //     0x12c15ec: sbfx            x1, x0, #1, #0x1f
    // 0x12c15f0: mov             x0, x1
    // 0x12c15f4: mov             x1, x5
    // 0x12c15f8: cmp             x1, x0
    // 0x12c15fc: b.hs            #0x12c1e94
    // 0x12c1600: LoadField: r0 = r3->field_f
    //     0x12c1600: ldur            w0, [x3, #0xf]
    // 0x12c1604: DecompressPointer r0
    //     0x12c1604: add             x0, x0, HEAP, lsl #32
    // 0x12c1608: ArrayLoad: r7 = r0[r5]  ; Unknown_4
    //     0x12c1608: add             x16, x0, x5, lsl #2
    //     0x12c160c: ldur            w7, [x16, #0xf]
    // 0x12c1610: DecompressPointer r7
    //     0x12c1610: add             x7, x7, HEAP, lsl #32
    // 0x12c1614: mov             x0, x6
    // 0x12c1618: StoreField: r7->field_7 = r0
    //     0x12c1618: stur            w0, [x7, #7]
    //     0x12c161c: tbz             w0, #0, #0x12c1638
    //     0x12c1620: ldurb           w16, [x7, #-1]
    //     0x12c1624: ldurb           w17, [x0, #-1]
    //     0x12c1628: and             x16, x17, x16, lsr #2
    //     0x12c162c: tst             x16, HEAP, lsr #32
    //     0x12c1630: b.eq            #0x12c1638
    //     0x12c1634: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0x12c1638: r0 = BoxInt64Instr(r2)
    //     0x12c1638: sbfiz           x0, x2, #1, #0x1f
    //     0x12c163c: cmp             x2, x0, asr #1
    //     0x12c1640: b.eq            #0x12c164c
    //     0x12c1644: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12c1648: stur            x2, [x0, #7]
    // 0x12c164c: StoreField: r7->field_13 = r0
    //     0x12c164c: stur            w0, [x7, #0x13]
    //     0x12c1650: tbz             w0, #0, #0x12c166c
    //     0x12c1654: ldurb           w16, [x7, #-1]
    //     0x12c1658: ldurb           w17, [x0, #-1]
    //     0x12c165c: and             x16, x17, x16, lsr #2
    //     0x12c1660: tst             x16, HEAP, lsr #32
    //     0x12c1664: b.eq            #0x12c166c
    //     0x12c1668: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0x12c166c: LoadField: r0 = r4->field_b
    //     0x12c166c: ldur            w0, [x4, #0xb]
    // 0x12c1670: r1 = LoadInt32Instr(r0)
    //     0x12c1670: sbfx            x1, x0, #1, #0x1f
    // 0x12c1674: mov             x0, x1
    // 0x12c1678: mov             x1, x5
    // 0x12c167c: cmp             x1, x0
    // 0x12c1680: b.hs            #0x12c1e98
    // 0x12c1684: LoadField: r0 = r4->field_f
    //     0x12c1684: ldur            w0, [x4, #0xf]
    // 0x12c1688: DecompressPointer r0
    //     0x12c1688: add             x0, x0, HEAP, lsl #32
    // 0x12c168c: ArrayLoad: r1 = r0[r5]  ; Unknown_4
    //     0x12c168c: add             x16, x0, x5, lsl #2
    //     0x12c1690: ldur            w1, [x16, #0xf]
    // 0x12c1694: DecompressPointer r1
    //     0x12c1694: add             x1, x1, HEAP, lsl #32
    // 0x12c1698: r0 = LoadInt32Instr(r1)
    //     0x12c1698: sbfx            x0, x1, #1, #0x1f
    //     0x12c169c: tbz             w1, #0, #0x12c16a4
    //     0x12c16a0: ldur            x0, [x1, #7]
    // 0x12c16a4: add             x8, x2, x0
    // 0x12c16a8: stur            x8, [fp, #-0x80]
    // 0x12c16ac: r9 = LoadInt32Instr(r6)
    //     0x12c16ac: sbfx            x9, x6, #1, #0x1f
    //     0x12c16b0: tbz             w6, #0, #0x12c16b8
    //     0x12c16b4: ldur            x9, [x6, #7]
    // 0x12c16b8: stur            x9, [fp, #-0x48]
    // 0x12c16bc: r17 = 8235
    //     0x12c16bc: mov             x17, #0x202b
    // 0x12c16c0: cmp             x9, x17
    // 0x12c16c4: b.eq            #0x12c16d4
    // 0x12c16c8: r17 = 8238
    //     0x12c16c8: mov             x17, #0x202e
    // 0x12c16cc: cmp             x9, x17
    // 0x12c16d0: b.ne            #0x12c175c
    // 0x12c16d4: ldur            x6, [fp, #-0x38]
    // 0x12c16d8: cmp             x6, #0x3c
    // 0x12c16dc: b.ge            #0x12c1740
    // 0x12c16e0: r0 = BoxInt64Instr(r6)
    //     0x12c16e0: sbfiz           x0, x6, #1, #0x1f
    //     0x12c16e4: cmp             x6, x0, asr #1
    //     0x12c16e8: b.eq            #0x12c16f4
    //     0x12c16ec: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12c16f0: stur            x6, [x0, #7]
    // 0x12c16f4: ldur            x1, [fp, #-0x58]
    // 0x12c16f8: mov             x2, x0
    // 0x12c16fc: r0 = addLast()
    //     0x12c16fc: bl              #0x820860  ; [dart:collection] ListQueue::addLast
    // 0x12c1700: ldur            x1, [fp, #-0x40]
    // 0x12c1704: ldur            x2, [fp, #-0x70]
    // 0x12c1708: r0 = addLast()
    //     0x12c1708: bl              #0x820860  ; [dart:collection] ListQueue::addLast
    // 0x12c170c: ldur            x3, [fp, #-0x38]
    // 0x12c1710: add             x0, x3, #1
    // 0x12c1714: orr             x1, x0, #1
    // 0x12c1718: ldur            x4, [fp, #-0x48]
    // 0x12c171c: r17 = 8235
    //     0x12c171c: mov             x17, #0x202b
    // 0x12c1720: cmp             x4, x17
    // 0x12c1724: b.ne            #0x12c1734
    // 0x12c1728: r0 = Instance_DirectionOverride
    //     0x12c1728: add             x0, PP, #0x80, lsl #12  ; [pp+0x804b0] Obj!DirectionOverride@12c6ec1
    //     0x12c172c: ldr             x0, [x0, #0x4b0]
    // 0x12c1730: b               #0x12c174c
    // 0x12c1734: r0 = Instance_DirectionOverride
    //     0x12c1734: add             x0, PP, #0x80, lsl #12  ; [pp+0x804c0] Obj!DirectionOverride@12c6ea1
    //     0x12c1738: ldr             x0, [x0, #0x4c0]
    // 0x12c173c: b               #0x12c174c
    // 0x12c1740: mov             x3, x6
    // 0x12c1744: mov             x1, x3
    // 0x12c1748: ldur            x0, [fp, #-0x70]
    // 0x12c174c: mov             x10, x1
    // 0x12c1750: mov             x2, x0
    // 0x12c1754: r0 = true
    //     0x12c1754: add             x0, NULL, #0x20  ; true
    // 0x12c1758: b               #0x12c1954
    // 0x12c175c: ldur            x3, [fp, #-0x38]
    // 0x12c1760: mov             x4, x9
    // 0x12c1764: r17 = 8234
    //     0x12c1764: mov             x17, #0x202a
    // 0x12c1768: cmp             x4, x17
    // 0x12c176c: b.eq            #0x12c177c
    // 0x12c1770: r17 = 8237
    //     0x12c1770: mov             x17, #0x202d
    // 0x12c1774: cmp             x4, x17
    // 0x12c1778: b.ne            #0x12c1800
    // 0x12c177c: cmp             x3, #0x3b
    // 0x12c1780: b.ge            #0x12c17e4
    // 0x12c1784: r0 = BoxInt64Instr(r3)
    //     0x12c1784: sbfiz           x0, x3, #1, #0x1f
    //     0x12c1788: cmp             x3, x0, asr #1
    //     0x12c178c: b.eq            #0x12c1798
    //     0x12c1790: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12c1794: stur            x3, [x0, #7]
    // 0x12c1798: ldur            x1, [fp, #-0x58]
    // 0x12c179c: mov             x2, x0
    // 0x12c17a0: r0 = addLast()
    //     0x12c17a0: bl              #0x820860  ; [dart:collection] ListQueue::addLast
    // 0x12c17a4: ldur            x1, [fp, #-0x40]
    // 0x12c17a8: ldur            x2, [fp, #-0x70]
    // 0x12c17ac: r0 = addLast()
    //     0x12c17ac: bl              #0x820860  ; [dart:collection] ListQueue::addLast
    // 0x12c17b0: ldur            x4, [fp, #-0x38]
    // 0x12c17b4: orr             x0, x4, #1
    // 0x12c17b8: add             x1, x0, #1
    // 0x12c17bc: ldur            x0, [fp, #-0x48]
    // 0x12c17c0: r17 = 8234
    //     0x12c17c0: mov             x17, #0x202a
    // 0x12c17c4: cmp             x0, x17
    // 0x12c17c8: b.ne            #0x12c17d8
    // 0x12c17cc: r0 = Instance_DirectionOverride
    //     0x12c17cc: add             x0, PP, #0x80, lsl #12  ; [pp+0x804b0] Obj!DirectionOverride@12c6ec1
    //     0x12c17d0: ldr             x0, [x0, #0x4b0]
    // 0x12c17d4: b               #0x12c17f0
    // 0x12c17d8: r0 = Instance_DirectionOverride
    //     0x12c17d8: add             x0, PP, #0x80, lsl #12  ; [pp+0x804c8] Obj!DirectionOverride@12c6e81
    //     0x12c17dc: ldr             x0, [x0, #0x4c8]
    // 0x12c17e0: b               #0x12c17f0
    // 0x12c17e4: mov             x4, x3
    // 0x12c17e8: mov             x1, x4
    // 0x12c17ec: ldur            x0, [fp, #-0x70]
    // 0x12c17f0: mov             x2, x1
    // 0x12c17f4: mov             x1, x0
    // 0x12c17f8: r0 = true
    //     0x12c17f8: add             x0, NULL, #0x20  ; true
    // 0x12c17fc: b               #0x12c194c
    // 0x12c1800: mov             x0, x4
    // 0x12c1804: mov             x4, x3
    // 0x12c1808: r17 = 8236
    //     0x12c1808: mov             x17, #0x202c
    // 0x12c180c: cmp             x0, x17
    // 0x12c1810: b.eq            #0x12c18b4
    // 0x12c1814: ldur            x2, [fp, #-0x70]
    // 0x12c1818: r0 = BoxInt64Instr(r4)
    //     0x12c1818: sbfiz           x0, x4, #1, #0x1f
    //     0x12c181c: cmp             x4, x0, asr #1
    //     0x12c1820: b.eq            #0x12c182c
    //     0x12c1824: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12c1828: stur            x4, [x0, #7]
    // 0x12c182c: StoreField: r7->field_b = r0
    //     0x12c182c: stur            w0, [x7, #0xb]
    //     0x12c1830: tbz             w0, #0, #0x12c184c
    //     0x12c1834: ldurb           w16, [x7, #-1]
    //     0x12c1838: ldurb           w17, [x0, #-1]
    //     0x12c183c: and             x16, x17, x16, lsr #2
    //     0x12c1840: tst             x16, HEAP, lsr #32
    //     0x12c1844: b.eq            #0x12c184c
    //     0x12c1848: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0x12c184c: r16 = Instance_DirectionOverride
    //     0x12c184c: add             x16, PP, #0x80, lsl #12  ; [pp+0x804c8] Obj!DirectionOverride@12c6e81
    //     0x12c1850: ldr             x16, [x16, #0x4c8]
    // 0x12c1854: cmp             w2, w16
    // 0x12c1858: b.ne            #0x12c1874
    // 0x12c185c: r0 = Instance_CharacterType
    //     0x12c185c: add             x0, PP, #0x80, lsl #12  ; [pp+0x804b8] Obj!CharacterType@12c6ee1
    //     0x12c1860: ldr             x0, [x0, #0x4b8]
    // 0x12c1864: StoreField: r7->field_f = r0
    //     0x12c1864: stur            w0, [x7, #0xf]
    // 0x12c1868: r3 = Instance_CharacterType
    //     0x12c1868: add             x3, PP, #0x80, lsl #12  ; [pp+0x804d0] Obj!CharacterType@12c7061
    //     0x12c186c: ldr             x3, [x3, #0x4d0]
    // 0x12c1870: b               #0x12c18a4
    // 0x12c1874: r0 = Instance_CharacterType
    //     0x12c1874: add             x0, PP, #0x80, lsl #12  ; [pp+0x804b8] Obj!CharacterType@12c6ee1
    //     0x12c1878: ldr             x0, [x0, #0x4b8]
    // 0x12c187c: r16 = Instance_DirectionOverride
    //     0x12c187c: add             x16, PP, #0x80, lsl #12  ; [pp+0x804c0] Obj!DirectionOverride@12c6ea1
    //     0x12c1880: ldr             x16, [x16, #0x4c0]
    // 0x12c1884: cmp             w2, w16
    // 0x12c1888: b.ne            #0x12c189c
    // 0x12c188c: r3 = Instance_CharacterType
    //     0x12c188c: add             x3, PP, #0x80, lsl #12  ; [pp+0x804d0] Obj!CharacterType@12c7061
    //     0x12c1890: ldr             x3, [x3, #0x4d0]
    // 0x12c1894: StoreField: r7->field_f = r3
    //     0x12c1894: stur            w3, [x7, #0xf]
    // 0x12c1898: b               #0x12c18a4
    // 0x12c189c: r3 = Instance_CharacterType
    //     0x12c189c: add             x3, PP, #0x80, lsl #12  ; [pp+0x804d0] Obj!CharacterType@12c7061
    //     0x12c18a0: ldr             x3, [x3, #0x4d0]
    // 0x12c18a4: mov             x1, x2
    // 0x12c18a8: mov             x2, x4
    // 0x12c18ac: r0 = false
    //     0x12c18ac: add             x0, NULL, #0x30  ; false
    // 0x12c18b0: b               #0x12c194c
    // 0x12c18b4: ldur            x2, [fp, #-0x70]
    // 0x12c18b8: ldur            x5, [fp, #-0x58]
    // 0x12c18bc: r3 = Instance_CharacterType
    //     0x12c18bc: add             x3, PP, #0x80, lsl #12  ; [pp+0x804d0] Obj!CharacterType@12c7061
    //     0x12c18c0: ldr             x3, [x3, #0x4d0]
    // 0x12c18c4: r0 = Instance_CharacterType
    //     0x12c18c4: add             x0, PP, #0x80, lsl #12  ; [pp+0x804b8] Obj!CharacterType@12c6ee1
    //     0x12c18c8: ldr             x0, [x0, #0x4b8]
    // 0x12c18cc: ArrayLoad: r1 = r5[0]  ; List_8
    //     0x12c18cc: ldur            x1, [x5, #0x17]
    // 0x12c18d0: LoadField: r6 = r5->field_f
    //     0x12c18d0: ldur            x6, [x5, #0xf]
    // 0x12c18d4: sub             x7, x1, x6
    // 0x12c18d8: LoadField: r1 = r5->field_b
    //     0x12c18d8: ldur            w1, [x5, #0xb]
    // 0x12c18dc: DecompressPointer r1
    //     0x12c18dc: add             x1, x1, HEAP, lsl #32
    // 0x12c18e0: LoadField: r6 = r1->field_b
    //     0x12c18e0: ldur            w6, [x1, #0xb]
    // 0x12c18e4: r1 = LoadInt32Instr(r6)
    //     0x12c18e4: sbfx            x1, x6, #1, #0x1f
    // 0x12c18e8: sub             x6, x1, #1
    // 0x12c18ec: and             x1, x7, x6
    // 0x12c18f0: cmp             x1, #0
    // 0x12c18f4: b.le            #0x12c1938
    // 0x12c18f8: mov             x1, x5
    // 0x12c18fc: r0 = last()
    //     0x12c18fc: bl              #0xae739c  ; [dart:collection] ListQueue::last
    // 0x12c1900: ldur            x1, [fp, #-0x58]
    // 0x12c1904: stur            x0, [fp, #-0x60]
    // 0x12c1908: r0 = removeLast()
    //     0x12c1908: bl              #0x8a2154  ; [dart:collection] ListQueue::removeLast
    // 0x12c190c: ldur            x1, [fp, #-0x40]
    // 0x12c1910: r0 = last()
    //     0x12c1910: bl              #0xae739c  ; [dart:collection] ListQueue::last
    // 0x12c1914: ldur            x1, [fp, #-0x40]
    // 0x12c1918: stur            x0, [fp, #-0x68]
    // 0x12c191c: r0 = removeLast()
    //     0x12c191c: bl              #0x8a2154  ; [dart:collection] ListQueue::removeLast
    // 0x12c1920: ldur            x0, [fp, #-0x60]
    // 0x12c1924: r1 = LoadInt32Instr(r0)
    //     0x12c1924: sbfx            x1, x0, #1, #0x1f
    //     0x12c1928: tbz             w0, #0, #0x12c1930
    //     0x12c192c: ldur            x1, [x0, #7]
    // 0x12c1930: ldur            x0, [fp, #-0x68]
    // 0x12c1934: b               #0x12c1940
    // 0x12c1938: mov             x1, x4
    // 0x12c193c: mov             x0, x2
    // 0x12c1940: mov             x2, x1
    // 0x12c1944: mov             x1, x0
    // 0x12c1948: r0 = true
    //     0x12c1948: add             x0, NULL, #0x20  ; true
    // 0x12c194c: mov             x10, x2
    // 0x12c1950: mov             x2, x1
    // 0x12c1954: tbnz            w0, #4, #0x12c1964
    // 0x12c1958: ldur            x3, [fp, #-0x78]
    // 0x12c195c: ldur            x11, [fp, #-0x50]
    // 0x12c1960: b               #0x12c19bc
    // 0x12c1964: ldur            x3, [fp, #-0x78]
    // 0x12c1968: ldur            x11, [fp, #-0x50]
    // 0x12c196c: LoadField: r0 = r11->field_b
    //     0x12c196c: ldur            w0, [x11, #0xb]
    // 0x12c1970: r1 = LoadInt32Instr(r0)
    //     0x12c1970: sbfx            x1, x0, #1, #0x1f
    // 0x12c1974: mov             x0, x1
    // 0x12c1978: mov             x1, x3
    // 0x12c197c: cmp             x1, x0
    // 0x12c1980: b.hs            #0x12c1e9c
    // 0x12c1984: LoadField: r0 = r11->field_f
    //     0x12c1984: ldur            w0, [x11, #0xf]
    // 0x12c1988: DecompressPointer r0
    //     0x12c1988: add             x0, x0, HEAP, lsl #32
    // 0x12c198c: ArrayLoad: r1 = r0[r3]  ; Unknown_4
    //     0x12c198c: add             x16, x0, x3, lsl #2
    //     0x12c1990: ldur            w1, [x16, #0xf]
    // 0x12c1994: DecompressPointer r1
    //     0x12c1994: add             x1, x1, HEAP, lsl #32
    // 0x12c1998: LoadField: r0 = r1->field_f
    //     0x12c1998: ldur            w0, [x1, #0xf]
    // 0x12c199c: DecompressPointer r0
    //     0x12c199c: add             x0, x0, HEAP, lsl #32
    // 0x12c19a0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12c19a4: cmp             w0, w16
    // 0x12c19a8: b.eq            #0x12c1ea0
    // 0x12c19ac: r16 = Instance_CharacterType
    //     0x12c19ac: add             x16, PP, #0x80, lsl #12  ; [pp+0x804d8] Obj!CharacterType@12c7041
    //     0x12c19b0: ldr             x16, [x16, #0x4d8]
    // 0x12c19b4: cmp             w0, w16
    // 0x12c19b8: b.ne            #0x12c1a1c
    // 0x12c19bc: LoadField: r0 = r11->field_b
    //     0x12c19bc: ldur            w0, [x11, #0xb]
    // 0x12c19c0: r1 = LoadInt32Instr(r0)
    //     0x12c19c0: sbfx            x1, x0, #1, #0x1f
    // 0x12c19c4: mov             x0, x1
    // 0x12c19c8: mov             x1, x3
    // 0x12c19cc: cmp             x1, x0
    // 0x12c19d0: b.hs            #0x12c1eac
    // 0x12c19d4: LoadField: r0 = r11->field_f
    //     0x12c19d4: ldur            w0, [x11, #0xf]
    // 0x12c19d8: DecompressPointer r0
    //     0x12c19d8: add             x0, x0, HEAP, lsl #32
    // 0x12c19dc: ArrayLoad: r4 = r0[r3]  ; Unknown_4
    //     0x12c19dc: add             x16, x0, x3, lsl #2
    //     0x12c19e0: ldur            w4, [x16, #0xf]
    // 0x12c19e4: DecompressPointer r4
    //     0x12c19e4: add             x4, x4, HEAP, lsl #32
    // 0x12c19e8: r0 = BoxInt64Instr(r10)
    //     0x12c19e8: sbfiz           x0, x10, #1, #0x1f
    //     0x12c19ec: cmp             x10, x0, asr #1
    //     0x12c19f0: b.eq            #0x12c19fc
    //     0x12c19f4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12c19f8: stur            x10, [x0, #7]
    // 0x12c19fc: StoreField: r4->field_b = r0
    //     0x12c19fc: stur            w0, [x4, #0xb]
    //     0x12c1a00: tbz             w0, #0, #0x12c1a1c
    //     0x12c1a04: ldurb           w16, [x4, #-1]
    //     0x12c1a08: ldurb           w17, [x0, #-1]
    //     0x12c1a0c: and             x16, x17, x16, lsr #2
    //     0x12c1a10: tst             x16, HEAP, lsr #32
    //     0x12c1a14: b.eq            #0x12c1a1c
    //     0x12c1a18: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0x12c1a1c: add             x7, x3, #1
    // 0x12c1a20: mov             x9, x2
    // 0x12c1a24: ldur            x8, [fp, #-0x80]
    // 0x12c1a28: mov             x4, x11
    // 0x12c1a2c: b               #0x12c1514
    // 0x12c1a30: ldur            x0, [fp, #-0x18]
    // 0x12c1a34: mov             x11, x4
    // 0x12c1a38: mov             x4, x10
    // 0x12c1a3c: LoadField: r8 = r0->field_13
    //     0x12c1a3c: ldur            w8, [x0, #0x13]
    // 0x12c1a40: DecompressPointer r8
    //     0x12c1a40: add             x8, x8, HEAP, lsl #32
    // 0x12c1a44: stur            x8, [fp, #-0x40]
    // 0x12c1a48: mov             x2, x4
    // 0x12c1a4c: r12 = 0
    //     0x12c1a4c: mov             x12, #0
    // 0x12c1a50: ldur            x10, [fp, #-0x30]
    // 0x12c1a54: stur            x12, [fp, #-0x80]
    // 0x12c1a58: CheckStackOverflow
    //     0x12c1a58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c1a5c: cmp             SP, x16
    //     0x12c1a60: b.ls            #0x12c1eb0
    // 0x12c1a64: LoadField: r0 = r10->field_b
    //     0x12c1a64: ldur            w0, [x10, #0xb]
    // 0x12c1a68: r3 = LoadInt32Instr(r0)
    //     0x12c1a68: sbfx            x3, x0, #1, #0x1f
    // 0x12c1a6c: cmp             x12, x3
    // 0x12c1a70: b.ge            #0x12c1c30
    // 0x12c1a74: LoadField: r0 = r11->field_b
    //     0x12c1a74: ldur            w0, [x11, #0xb]
    // 0x12c1a78: r5 = LoadInt32Instr(r0)
    //     0x12c1a78: sbfx            x5, x0, #1, #0x1f
    // 0x12c1a7c: mov             x0, x5
    // 0x12c1a80: mov             x1, x12
    // 0x12c1a84: cmp             x1, x0
    // 0x12c1a88: b.hs            #0x12c1eb8
    // 0x12c1a8c: LoadField: r6 = r11->field_f
    //     0x12c1a8c: ldur            w6, [x11, #0xf]
    // 0x12c1a90: DecompressPointer r6
    //     0x12c1a90: add             x6, x6, HEAP, lsl #32
    // 0x12c1a94: ArrayLoad: r0 = r6[r12]  ; Unknown_4
    //     0x12c1a94: add             x16, x6, x12, lsl #2
    //     0x12c1a98: ldur            w0, [x16, #0xf]
    // 0x12c1a9c: DecompressPointer r0
    //     0x12c1a9c: add             x0, x0, HEAP, lsl #32
    // 0x12c1aa0: LoadField: r1 = r0->field_b
    //     0x12c1aa0: ldur            w1, [x0, #0xb]
    // 0x12c1aa4: DecompressPointer r1
    //     0x12c1aa4: add             x1, x1, HEAP, lsl #32
    // 0x12c1aa8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12c1aac: cmp             w1, w16
    // 0x12c1ab0: b.eq            #0x12c1ebc
    // 0x12c1ab4: r13 = LoadInt32Instr(r1)
    //     0x12c1ab4: sbfx            x13, x1, #1, #0x1f
    //     0x12c1ab8: tbz             w1, #0, #0x12c1ac0
    //     0x12c1abc: ldur            x13, [x1, #7]
    // 0x12c1ac0: stur            x13, [fp, #-0x78]
    // 0x12c1ac4: cmp             x2, x13
    // 0x12c1ac8: csel            x0, x13, x2, lt
    // 0x12c1acc: tbnz            w0, #0, #0x12c1adc
    // 0x12c1ad0: r14 = Instance_CharacterType
    //     0x12c1ad0: add             x14, PP, #0x80, lsl #12  ; [pp+0x804b8] Obj!CharacterType@12c6ee1
    //     0x12c1ad4: ldr             x14, [x14, #0x4b8]
    // 0x12c1ad8: b               #0x12c1ae4
    // 0x12c1adc: r14 = Instance_CharacterType
    //     0x12c1adc: add             x14, PP, #0x80, lsl #12  ; [pp+0x804d0] Obj!CharacterType@12c7061
    //     0x12c1ae0: ldr             x14, [x14, #0x4d0]
    // 0x12c1ae4: stur            x14, [fp, #-0x28]
    // 0x12c1ae8: add             x0, x12, #1
    // 0x12c1aec: mov             x19, x0
    // 0x12c1af0: stur            x19, [fp, #-0x48]
    // 0x12c1af4: CheckStackOverflow
    //     0x12c1af4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c1af8: cmp             SP, x16
    //     0x12c1afc: b.ls            #0x12c1ec8
    // 0x12c1b00: cmp             x19, x3
    // 0x12c1b04: b.ge            #0x12c1b58
    // 0x12c1b08: mov             x0, x5
    // 0x12c1b0c: mov             x1, x19
    // 0x12c1b10: cmp             x1, x0
    // 0x12c1b14: b.hs            #0x12c1ed0
    // 0x12c1b18: ArrayLoad: r0 = r6[r19]  ; Unknown_4
    //     0x12c1b18: add             x16, x6, x19, lsl #2
    //     0x12c1b1c: ldur            w0, [x16, #0xf]
    // 0x12c1b20: DecompressPointer r0
    //     0x12c1b20: add             x0, x0, HEAP, lsl #32
    // 0x12c1b24: LoadField: r1 = r0->field_b
    //     0x12c1b24: ldur            w1, [x0, #0xb]
    // 0x12c1b28: DecompressPointer r1
    //     0x12c1b28: add             x1, x1, HEAP, lsl #32
    // 0x12c1b2c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12c1b30: cmp             w1, w16
    // 0x12c1b34: b.eq            #0x12c1ed4
    // 0x12c1b38: r0 = LoadInt32Instr(r1)
    //     0x12c1b38: sbfx            x0, x1, #1, #0x1f
    //     0x12c1b3c: tbz             w1, #0, #0x12c1b44
    //     0x12c1b40: ldur            x0, [x1, #7]
    // 0x12c1b44: cmp             x0, x13
    // 0x12c1b48: b.ne            #0x12c1b58
    // 0x12c1b4c: add             x0, x19, #1
    // 0x12c1b50: mov             x19, x0
    // 0x12c1b54: b               #0x12c1af0
    // 0x12c1b58: cmp             x19, x3
    // 0x12c1b5c: b.ge            #0x12c1ba0
    // 0x12c1b60: mov             x0, x5
    // 0x12c1b64: mov             x1, x19
    // 0x12c1b68: cmp             x1, x0
    // 0x12c1b6c: b.hs            #0x12c1ee0
    // 0x12c1b70: ArrayLoad: r0 = r6[r19]  ; Unknown_4
    //     0x12c1b70: add             x16, x6, x19, lsl #2
    //     0x12c1b74: ldur            w0, [x16, #0xf]
    // 0x12c1b78: DecompressPointer r0
    //     0x12c1b78: add             x0, x0, HEAP, lsl #32
    // 0x12c1b7c: LoadField: r1 = r0->field_b
    //     0x12c1b7c: ldur            w1, [x0, #0xb]
    // 0x12c1b80: DecompressPointer r1
    //     0x12c1b80: add             x1, x1, HEAP, lsl #32
    // 0x12c1b84: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12c1b88: cmp             w1, w16
    // 0x12c1b8c: b.eq            #0x12c1ee4
    // 0x12c1b90: r0 = LoadInt32Instr(r1)
    //     0x12c1b90: sbfx            x0, x1, #1, #0x1f
    //     0x12c1b94: tbz             w1, #0, #0x12c1b9c
    //     0x12c1b98: ldur            x0, [x1, #7]
    // 0x12c1b9c: b               #0x12c1ba4
    // 0x12c1ba0: mov             x0, x4
    // 0x12c1ba4: cmp             x0, x13
    // 0x12c1ba8: csel            x1, x13, x0, lt
    // 0x12c1bac: tbnz            w1, #0, #0x12c1bbc
    // 0x12c1bb0: r0 = Instance_CharacterType
    //     0x12c1bb0: add             x0, PP, #0x80, lsl #12  ; [pp+0x804b8] Obj!CharacterType@12c6ee1
    //     0x12c1bb4: ldr             x0, [x0, #0x4b8]
    // 0x12c1bb8: b               #0x12c1bc4
    // 0x12c1bbc: r0 = Instance_CharacterType
    //     0x12c1bbc: add             x0, PP, #0x80, lsl #12  ; [pp+0x804d0] Obj!CharacterType@12c7061
    //     0x12c1bc0: ldr             x0, [x0, #0x4d0]
    // 0x12c1bc4: stur            x0, [fp, #-0x18]
    // 0x12c1bc8: str             x8, [SP]
    // 0x12c1bcc: mov             x1, x11
    // 0x12c1bd0: mov             x2, x12
    // 0x12c1bd4: mov             x3, x19
    // 0x12c1bd8: mov             x5, x14
    // 0x12c1bdc: mov             x6, x0
    // 0x12c1be0: ldur            x7, [fp, #-8]
    // 0x12c1be4: r0 = _resolveWeakTypes()
    //     0x12c1be4: bl              #0x12c5840  ; [package:bidi/bidi.dart] ::_resolveWeakTypes
    // 0x12c1be8: ldur            x1, [fp, #-0x50]
    // 0x12c1bec: ldur            x2, [fp, #-0x80]
    // 0x12c1bf0: ldur            x3, [fp, #-0x48]
    // 0x12c1bf4: ldur            x5, [fp, #-0x28]
    // 0x12c1bf8: ldur            x6, [fp, #-0x18]
    // 0x12c1bfc: ldur            x7, [fp, #-0x78]
    // 0x12c1c00: r0 = _resolveNeutralTypes()
    //     0x12c1c00: bl              #0x12c53b0  ; [package:bidi/bidi.dart] ::_resolveNeutralTypes
    // 0x12c1c04: ldur            x1, [fp, #-0x50]
    // 0x12c1c08: ldur            x2, [fp, #-0x80]
    // 0x12c1c0c: ldur            x3, [fp, #-0x48]
    // 0x12c1c10: ldur            x5, [fp, #-0x78]
    // 0x12c1c14: r0 = _resolveImplicitTypes()
    //     0x12c1c14: bl              #0x12c5114  ; [package:bidi/bidi.dart] ::_resolveImplicitTypes
    // 0x12c1c18: ldur            x2, [fp, #-0x78]
    // 0x12c1c1c: ldur            x12, [fp, #-0x48]
    // 0x12c1c20: ldur            x4, [fp, #-0x38]
    // 0x12c1c24: ldur            x8, [fp, #-0x40]
    // 0x12c1c28: ldur            x11, [fp, #-0x50]
    // 0x12c1c2c: b               #0x12c1a50
    // 0x12c1c30: mov             x0, x11
    // 0x12c1c34: mov             x1, x0
    // 0x12c1c38: ldur            x2, [fp, #-0x20]
    // 0x12c1c3c: r0 = _reorderString()
    //     0x12c1c3c: bl              #0x12c4c58  ; [package:bidi/bidi.dart] ::_reorderString
    // 0x12c1c40: ldur            x1, [fp, #-0x50]
    // 0x12c1c44: r0 = _fixMirroredCharacters()
    //     0x12c1c44: bl              #0x12c1f30  ; [package:bidi/bidi.dart] ::_fixMirroredCharacters
    // 0x12c1c48: r1 = <int>
    //     0x12c1c48: ldr             x1, [PP, #0x50]  ; [pp+0x50] TypeArguments: <int>
    // 0x12c1c4c: r2 = 0
    //     0x12c1c4c: mov             x2, #0
    // 0x12c1c50: r0 = _GrowableList()
    //     0x12c1c50: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x12c1c54: r1 = <int>
    //     0x12c1c54: ldr             x1, [PP, #0x50]  ; [pp+0x50] TypeArguments: <int>
    // 0x12c1c58: r2 = 0
    //     0x12c1c58: mov             x2, #0
    // 0x12c1c5c: stur            x0, [fp, #-8]
    // 0x12c1c60: r0 = _GrowableList()
    //     0x12c1c60: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x12c1c64: mov             x2, x0
    // 0x12c1c68: ldur            x0, [fp, #-0x50]
    // 0x12c1c6c: stur            x2, [fp, #-0x30]
    // 0x12c1c70: LoadField: r1 = r0->field_b
    //     0x12c1c70: ldur            w1, [x0, #0xb]
    // 0x12c1c74: r3 = LoadInt32Instr(r1)
    //     0x12c1c74: sbfx            x3, x1, #1, #0x1f
    // 0x12c1c78: stur            x3, [fp, #-0x48]
    // 0x12c1c7c: ldur            x4, [fp, #-8]
    // 0x12c1c80: r1 = 0
    //     0x12c1c80: mov             x1, #0
    // 0x12c1c84: CheckStackOverflow
    //     0x12c1c84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c1c88: cmp             SP, x16
    //     0x12c1c8c: b.ls            #0x12c1ef0
    // 0x12c1c90: LoadField: r5 = r0->field_b
    //     0x12c1c90: ldur            w5, [x0, #0xb]
    // 0x12c1c94: r6 = LoadInt32Instr(r5)
    //     0x12c1c94: sbfx            x6, x5, #1, #0x1f
    // 0x12c1c98: cmp             x3, x6
    // 0x12c1c9c: b.ne            #0x12c1e5c
    // 0x12c1ca0: cmp             x1, x6
    // 0x12c1ca4: b.ge            #0x12c1e00
    // 0x12c1ca8: LoadField: r5 = r0->field_f
    //     0x12c1ca8: ldur            w5, [x0, #0xf]
    // 0x12c1cac: DecompressPointer r5
    //     0x12c1cac: add             x5, x5, HEAP, lsl #32
    // 0x12c1cb0: ArrayLoad: r6 = r5[r1]  ; Unknown_4
    //     0x12c1cb0: add             x16, x5, x1, lsl #2
    //     0x12c1cb4: ldur            w6, [x16, #0xf]
    // 0x12c1cb8: DecompressPointer r6
    //     0x12c1cb8: add             x6, x6, HEAP, lsl #32
    // 0x12c1cbc: stur            x6, [fp, #-0x28]
    // 0x12c1cc0: add             x5, x1, #1
    // 0x12c1cc4: stur            x5, [fp, #-0x38]
    // 0x12c1cc8: LoadField: r7 = r6->field_7
    //     0x12c1cc8: ldur            w7, [x6, #7]
    // 0x12c1ccc: DecompressPointer r7
    //     0x12c1ccc: add             x7, x7, HEAP, lsl #32
    // 0x12c1cd0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12c1cd4: cmp             w7, w16
    // 0x12c1cd8: b.eq            #0x12c1ef8
    // 0x12c1cdc: stur            x7, [fp, #-0x18]
    // 0x12c1ce0: LoadField: r1 = r2->field_b
    //     0x12c1ce0: ldur            w1, [x2, #0xb]
    // 0x12c1ce4: LoadField: r8 = r2->field_f
    //     0x12c1ce4: ldur            w8, [x2, #0xf]
    // 0x12c1ce8: DecompressPointer r8
    //     0x12c1ce8: add             x8, x8, HEAP, lsl #32
    // 0x12c1cec: LoadField: r9 = r8->field_b
    //     0x12c1cec: ldur            w9, [x8, #0xb]
    // 0x12c1cf0: r8 = LoadInt32Instr(r1)
    //     0x12c1cf0: sbfx            x8, x1, #1, #0x1f
    // 0x12c1cf4: stur            x8, [fp, #-0x20]
    // 0x12c1cf8: r1 = LoadInt32Instr(r9)
    //     0x12c1cf8: sbfx            x1, x9, #1, #0x1f
    // 0x12c1cfc: cmp             x8, x1
    // 0x12c1d00: b.ne            #0x12c1d0c
    // 0x12c1d04: mov             x1, x2
    // 0x12c1d08: r0 = _growToNextCapacity()
    //     0x12c1d08: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x12c1d0c: ldur            x3, [fp, #-8]
    // 0x12c1d10: ldur            x2, [fp, #-0x30]
    // 0x12c1d14: ldur            x5, [fp, #-0x20]
    // 0x12c1d18: ldur            x4, [fp, #-0x28]
    // 0x12c1d1c: add             x0, x5, #1
    // 0x12c1d20: lsl             x1, x0, #1
    // 0x12c1d24: StoreField: r2->field_b = r1
    //     0x12c1d24: stur            w1, [x2, #0xb]
    // 0x12c1d28: LoadField: r1 = r2->field_f
    //     0x12c1d28: ldur            w1, [x2, #0xf]
    // 0x12c1d2c: DecompressPointer r1
    //     0x12c1d2c: add             x1, x1, HEAP, lsl #32
    // 0x12c1d30: ldur            x0, [fp, #-0x18]
    // 0x12c1d34: ArrayStore: r1[r5] = r0  ; List_4
    //     0x12c1d34: add             x25, x1, x5, lsl #2
    //     0x12c1d38: add             x25, x25, #0xf
    //     0x12c1d3c: str             w0, [x25]
    //     0x12c1d40: tbz             w0, #0, #0x12c1d5c
    //     0x12c1d44: ldurb           w16, [x1, #-1]
    //     0x12c1d48: ldurb           w17, [x0, #-1]
    //     0x12c1d4c: and             x16, x17, x16, lsr #2
    //     0x12c1d50: tst             x16, HEAP, lsr #32
    //     0x12c1d54: b.eq            #0x12c1d5c
    //     0x12c1d58: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12c1d5c: LoadField: r0 = r4->field_13
    //     0x12c1d5c: ldur            w0, [x4, #0x13]
    // 0x12c1d60: DecompressPointer r0
    //     0x12c1d60: add             x0, x0, HEAP, lsl #32
    // 0x12c1d64: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12c1d68: cmp             w0, w16
    // 0x12c1d6c: b.eq            #0x12c1f04
    // 0x12c1d70: stur            x0, [fp, #-0x18]
    // 0x12c1d74: LoadField: r1 = r3->field_b
    //     0x12c1d74: ldur            w1, [x3, #0xb]
    // 0x12c1d78: LoadField: r4 = r3->field_f
    //     0x12c1d78: ldur            w4, [x3, #0xf]
    // 0x12c1d7c: DecompressPointer r4
    //     0x12c1d7c: add             x4, x4, HEAP, lsl #32
    // 0x12c1d80: LoadField: r5 = r4->field_b
    //     0x12c1d80: ldur            w5, [x4, #0xb]
    // 0x12c1d84: r4 = LoadInt32Instr(r1)
    //     0x12c1d84: sbfx            x4, x1, #1, #0x1f
    // 0x12c1d88: stur            x4, [fp, #-0x20]
    // 0x12c1d8c: r1 = LoadInt32Instr(r5)
    //     0x12c1d8c: sbfx            x1, x5, #1, #0x1f
    // 0x12c1d90: cmp             x4, x1
    // 0x12c1d94: b.ne            #0x12c1da0
    // 0x12c1d98: mov             x1, x3
    // 0x12c1d9c: r0 = _growToNextCapacity()
    //     0x12c1d9c: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x12c1da0: ldur            x2, [fp, #-8]
    // 0x12c1da4: ldur            x3, [fp, #-0x20]
    // 0x12c1da8: add             x0, x3, #1
    // 0x12c1dac: lsl             x1, x0, #1
    // 0x12c1db0: StoreField: r2->field_b = r1
    //     0x12c1db0: stur            w1, [x2, #0xb]
    // 0x12c1db4: LoadField: r1 = r2->field_f
    //     0x12c1db4: ldur            w1, [x2, #0xf]
    // 0x12c1db8: DecompressPointer r1
    //     0x12c1db8: add             x1, x1, HEAP, lsl #32
    // 0x12c1dbc: ldur            x0, [fp, #-0x18]
    // 0x12c1dc0: ArrayStore: r1[r3] = r0  ; List_4
    //     0x12c1dc0: add             x25, x1, x3, lsl #2
    //     0x12c1dc4: add             x25, x25, #0xf
    //     0x12c1dc8: str             w0, [x25]
    //     0x12c1dcc: tbz             w0, #0, #0x12c1de8
    //     0x12c1dd0: ldurb           w16, [x1, #-1]
    //     0x12c1dd4: ldurb           w17, [x0, #-1]
    //     0x12c1dd8: and             x16, x17, x16, lsr #2
    //     0x12c1ddc: tst             x16, HEAP, lsr #32
    //     0x12c1de0: b.eq            #0x12c1de8
    //     0x12c1de4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12c1de8: ldur            x1, [fp, #-0x38]
    // 0x12c1dec: mov             x4, x2
    // 0x12c1df0: ldur            x2, [fp, #-0x30]
    // 0x12c1df4: ldur            x0, [fp, #-0x50]
    // 0x12c1df8: ldur            x3, [fp, #-0x48]
    // 0x12c1dfc: b               #0x12c1c84
    // 0x12c1e00: ldur            x0, [fp, #-0x10]
    // 0x12c1e04: mov             x2, x4
    // 0x12c1e08: LoadField: r3 = r0->field_13
    //     0x12c1e08: ldur            w3, [x0, #0x13]
    // 0x12c1e0c: DecompressPointer r3
    //     0x12c1e0c: add             x3, x3, HEAP, lsl #32
    // 0x12c1e10: mov             x1, x3
    // 0x12c1e14: stur            x3, [fp, #-0x18]
    // 0x12c1e18: r0 = clear()
    //     0x12c1e18: bl              #0xa16074  ; [dart:core] _GrowableList::clear
    // 0x12c1e1c: ldur            x1, [fp, #-0x18]
    // 0x12c1e20: ldur            x2, [fp, #-0x30]
    // 0x12c1e24: r0 = addAll()
    //     0x12c1e24: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0x12c1e28: ldur            x0, [fp, #-0x10]
    // 0x12c1e2c: LoadField: r2 = r0->field_1b
    //     0x12c1e2c: ldur            w2, [x0, #0x1b]
    // 0x12c1e30: DecompressPointer r2
    //     0x12c1e30: add             x2, x2, HEAP, lsl #32
    // 0x12c1e34: mov             x1, x2
    // 0x12c1e38: stur            x2, [fp, #-0x18]
    // 0x12c1e3c: r0 = clear()
    //     0x12c1e3c: bl              #0xa16074  ; [dart:core] _GrowableList::clear
    // 0x12c1e40: ldur            x1, [fp, #-0x18]
    // 0x12c1e44: ldur            x2, [fp, #-8]
    // 0x12c1e48: r0 = addAll()
    //     0x12c1e48: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0x12c1e4c: r0 = Null
    //     0x12c1e4c: mov             x0, NULL
    // 0x12c1e50: LeaveFrame
    //     0x12c1e50: mov             SP, fp
    //     0x12c1e54: ldp             fp, lr, [SP], #0x10
    // 0x12c1e58: ret
    //     0x12c1e58: ret             
    // 0x12c1e5c: r0 = ConcurrentModificationError()
    //     0x12c1e5c: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x12c1e60: mov             x1, x0
    // 0x12c1e64: ldur            x0, [fp, #-0x50]
    // 0x12c1e68: StoreField: r1->field_b = r0
    //     0x12c1e68: stur            w0, [x1, #0xb]
    // 0x12c1e6c: mov             x0, x1
    // 0x12c1e70: r0 = Throw()
    //     0x12c1e70: bl              #0x13ddb2c  ; ThrowStub
    // 0x12c1e74: brk             #0
    // 0x12c1e78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c1e78: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c1e7c: b               #0x12c13bc
    // 0x12c1e80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c1e80: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c1e84: b               #0x12c1460
    // 0x12c1e88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c1e88: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c1e8c: b               #0x12c153c
    // 0x12c1e90: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c1e90: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c1e94: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c1e94: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c1e98: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c1e98: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c1e9c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c1e9c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c1ea0: r9 = type
    //     0x12c1ea0: add             x9, PP, #0x80, lsl #12  ; [pp+0x804e0] Field <_CharData@1190396231.type>: late (offset: 0x10)
    //     0x12c1ea4: ldr             x9, [x9, #0x4e0]
    // 0x12c1ea8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12c1ea8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12c1eac: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c1eac: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c1eb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c1eb0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c1eb4: b               #0x12c1a64
    // 0x12c1eb8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c1eb8: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c1ebc: r9 = embeddingLevel
    //     0x12c1ebc: add             x9, PP, #0x80, lsl #12  ; [pp+0x804e8] Field <_CharData@1190396231.embeddingLevel>: late (offset: 0xc)
    //     0x12c1ec0: ldr             x9, [x9, #0x4e8]
    // 0x12c1ec4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12c1ec4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12c1ec8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c1ec8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c1ecc: b               #0x12c1b00
    // 0x12c1ed0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c1ed0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c1ed4: r9 = embeddingLevel
    //     0x12c1ed4: add             x9, PP, #0x80, lsl #12  ; [pp+0x804e8] Field <_CharData@1190396231.embeddingLevel>: late (offset: 0xc)
    //     0x12c1ed8: ldr             x9, [x9, #0x4e8]
    // 0x12c1edc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12c1edc: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12c1ee0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12c1ee0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12c1ee4: r9 = embeddingLevel
    //     0x12c1ee4: add             x9, PP, #0x80, lsl #12  ; [pp+0x804e8] Field <_CharData@1190396231.embeddingLevel>: late (offset: 0xc)
    //     0x12c1ee8: ldr             x9, [x9, #0x4e8]
    // 0x12c1eec: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12c1eec: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12c1ef0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c1ef0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c1ef4: b               #0x12c1c90
    // 0x12c1ef8: r9 = char
    //     0x12c1ef8: add             x9, PP, #0x80, lsl #12  ; [pp+0x804f0] Field <_CharData@1190396231.char>: late (offset: 0x8)
    //     0x12c1efc: ldr             x9, [x9, #0x4f0]
    // 0x12c1f00: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12c1f00: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12c1f04: r9 = index
    //     0x12c1f04: add             x9, PP, #0x80, lsl #12  ; [pp+0x804f8] Field <_CharData@1190396231.index>: late (offset: 0x14)
    //     0x12c1f08: ldr             x9, [x9, #0x4f8]
    // 0x12c1f0c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12c1f0c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 3611, size: 0x10, field offset: 0x8
//   const constructor, 
class _CanonicalClass extends Object {

  _Mint field_8;
}

// class id: 3612, size: 0xc, field offset: 0x8
class BidiString extends Object {

  factory _ BidiString.fromLogical(/* No info */) {
    // ** addr: 0x12c0938, size: 0x31c
    // 0x12c0938: EnterFrame
    //     0x12c0938: stp             fp, lr, [SP, #-0x10]!
    //     0x12c093c: mov             fp, SP
    // 0x12c0940: AllocStack(0x48)
    //     0x12c0940: sub             SP, SP, #0x48
    // 0x12c0944: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0x12c0944: mov             x0, x2
    //     0x12c0948: stur            x2, [fp, #-8]
    // 0x12c094c: CheckStackOverflow
    //     0x12c094c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c0950: cmp             SP, x16
    //     0x12c0954: b.ls            #0x12c0c44
    // 0x12c0958: r1 = <Paragraph>
    //     0x12c0958: add             x1, PP, #0x80, lsl #12  ; [pp+0x80458] TypeArguments: <Paragraph>
    //     0x12c095c: ldr             x1, [x1, #0x458]
    // 0x12c0960: r2 = 0
    //     0x12c0960: mov             x2, #0
    // 0x12c0964: r0 = _GrowableList()
    //     0x12c0964: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x12c0968: r1 = <int>
    //     0x12c0968: ldr             x1, [PP, #0x50]  ; [pp+0x50] TypeArguments: <int>
    // 0x12c096c: r2 = 0
    //     0x12c096c: mov             x2, #0
    // 0x12c0970: stur            x0, [fp, #-0x10]
    // 0x12c0974: r0 = _GrowableList()
    //     0x12c0974: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x12c0978: mov             x1, x0
    // 0x12c097c: ldur            x0, [fp, #-8]
    // 0x12c0980: LoadField: r2 = r0->field_7
    //     0x12c0980: ldur            w2, [x0, #7]
    // 0x12c0984: r3 = LoadInt32Instr(r2)
    //     0x12c0984: sbfx            x3, x2, #1, #0x1f
    // 0x12c0988: stur            x3, [fp, #-0x40]
    // 0x12c098c: r4 = LoadClassIdInstr(r0)
    //     0x12c098c: ldur            x4, [x0, #-1]
    //     0x12c0990: ubfx            x4, x4, #0xc, #0x14
    // 0x12c0994: lsl             x4, x4, #1
    // 0x12c0998: stur            x4, [fp, #-0x38]
    // 0x12c099c: mov             x7, x1
    // 0x12c09a0: r6 = 0
    //     0x12c09a0: mov             x6, #0
    // 0x12c09a4: ldur            x5, [fp, #-0x10]
    // 0x12c09a8: stur            x7, [fp, #-0x28]
    // 0x12c09ac: stur            x6, [fp, #-0x30]
    // 0x12c09b0: CheckStackOverflow
    //     0x12c09b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12c09b4: cmp             SP, x16
    //     0x12c09b8: b.ls            #0x12c0c4c
    // 0x12c09bc: cmp             x6, x3
    // 0x12c09c0: b.ge            #0x12c0b84
    // 0x12c09c4: cmp             w4, #0xbc
    // 0x12c09c8: b.ne            #0x12c09dc
    // 0x12c09cc: ArrayLoad: r1 = r0[r6]  ; TypedUnsigned_1
    //     0x12c09cc: add             x16, x0, x6
    //     0x12c09d0: ldrb            w1, [x16, #0xf]
    // 0x12c09d4: mov             x8, x1
    // 0x12c09d8: b               #0x12c09e8
    // 0x12c09dc: add             x16, x0, x6, lsl #1
    // 0x12c09e0: ldurh           w1, [x16, #0xf]
    // 0x12c09e4: mov             x8, x1
    // 0x12c09e8: stur            x8, [fp, #-0x20]
    // 0x12c09ec: lsl             x9, x8, #1
    // 0x12c09f0: mov             x2, x9
    // 0x12c09f4: stur            x9, [fp, #-0x18]
    // 0x12c09f8: r1 = _ConstMap len:5850
    //     0x12c09f8: add             x1, PP, #0x80, lsl #12  ; [pp+0x80460] Map<int, CharacterType>(5850)
    //     0x12c09fc: ldr             x1, [x1, #0x460]
    // 0x12c0a00: r0 = []()
    //     0x12c0a00: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x12c0a04: cmp             w0, NULL
    // 0x12c0a08: b.ne            #0x12c0a14
    // 0x12c0a0c: r3 = const []
    //     0x12c0a0c: ldr             x3, [PP, #0x940]  ; [pp+0x940] List(0) []
    // 0x12c0a10: b               #0x12c0ad8
    // 0x12c0a14: r16 = Instance_CharacterType
    //     0x12c0a14: add             x16, PP, #0x80, lsl #12  ; [pp+0x80468] Obj!CharacterType@12c7081
    //     0x12c0a18: ldr             x16, [x16, #0x468]
    // 0x12c0a1c: cmp             w0, w16
    // 0x12c0a20: b.ne            #0x12c0ad4
    // 0x12c0a24: ldur            x1, [fp, #-0x10]
    // 0x12c0a28: r0 = Paragraph()
    //     0x12c0a28: bl              #0x12c93bc  ; AllocateParagraphStub -> Paragraph (size=0x20)
    // 0x12c0a2c: mov             x1, x0
    // 0x12c0a30: ldur            x2, [fp, #-0x28]
    // 0x12c0a34: ldur            x3, [fp, #-0x20]
    // 0x12c0a38: stur            x0, [fp, #-0x48]
    // 0x12c0a3c: r0 = Paragraph._()
    //     0x12c0a3c: bl              #0x12c0cc0  ; [package:bidi/bidi.dart] Paragraph::Paragraph._
    // 0x12c0a40: ldur            x0, [fp, #-0x10]
    // 0x12c0a44: LoadField: r1 = r0->field_b
    //     0x12c0a44: ldur            w1, [x0, #0xb]
    // 0x12c0a48: LoadField: r2 = r0->field_f
    //     0x12c0a48: ldur            w2, [x0, #0xf]
    // 0x12c0a4c: DecompressPointer r2
    //     0x12c0a4c: add             x2, x2, HEAP, lsl #32
    // 0x12c0a50: LoadField: r3 = r2->field_b
    //     0x12c0a50: ldur            w3, [x2, #0xb]
    // 0x12c0a54: r2 = LoadInt32Instr(r1)
    //     0x12c0a54: sbfx            x2, x1, #1, #0x1f
    // 0x12c0a58: stur            x2, [fp, #-0x20]
    // 0x12c0a5c: r1 = LoadInt32Instr(r3)
    //     0x12c0a5c: sbfx            x1, x3, #1, #0x1f
    // 0x12c0a60: cmp             x2, x1
    // 0x12c0a64: b.ne            #0x12c0a70
    // 0x12c0a68: mov             x1, x0
    // 0x12c0a6c: r0 = _growToNextCapacity()
    //     0x12c0a6c: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x12c0a70: ldur            x2, [fp, #-0x10]
    // 0x12c0a74: ldur            x3, [fp, #-0x20]
    // 0x12c0a78: add             x0, x3, #1
    // 0x12c0a7c: lsl             x1, x0, #1
    // 0x12c0a80: StoreField: r2->field_b = r1
    //     0x12c0a80: stur            w1, [x2, #0xb]
    // 0x12c0a84: LoadField: r1 = r2->field_f
    //     0x12c0a84: ldur            w1, [x2, #0xf]
    // 0x12c0a88: DecompressPointer r1
    //     0x12c0a88: add             x1, x1, HEAP, lsl #32
    // 0x12c0a8c: ldur            x0, [fp, #-0x48]
    // 0x12c0a90: ArrayStore: r1[r3] = r0  ; List_4
    //     0x12c0a90: add             x25, x1, x3, lsl #2
    //     0x12c0a94: add             x25, x25, #0xf
    //     0x12c0a98: str             w0, [x25]
    //     0x12c0a9c: tbz             w0, #0, #0x12c0ab8
    //     0x12c0aa0: ldurb           w16, [x1, #-1]
    //     0x12c0aa4: ldurb           w17, [x0, #-1]
    //     0x12c0aa8: and             x16, x17, x16, lsr #2
    //     0x12c0aac: tst             x16, HEAP, lsr #32
    //     0x12c0ab0: b.eq            #0x12c0ab8
    //     0x12c0ab4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12c0ab8: r1 = <int>
    //     0x12c0ab8: ldr             x1, [PP, #0x50]  ; [pp+0x50] TypeArguments: <int>
    // 0x12c0abc: r0 = AllocateGrowableArray()
    //     0x12c0abc: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x12c0ac0: r3 = const []
    //     0x12c0ac0: ldr             x3, [PP, #0x940]  ; [pp+0x940] List(0) []
    // 0x12c0ac4: StoreField: r0->field_f = r3
    //     0x12c0ac4: stur            w3, [x0, #0xf]
    // 0x12c0ac8: StoreField: r0->field_b = rZR
    //     0x12c0ac8: stur            wzr, [x0, #0xb]
    // 0x12c0acc: mov             x7, x0
    // 0x12c0ad0: b               #0x12c0b6c
    // 0x12c0ad4: r3 = const []
    //     0x12c0ad4: ldr             x3, [PP, #0x940]  ; [pp+0x940] List(0) []
    // 0x12c0ad8: ldur            x4, [fp, #-0x28]
    // 0x12c0adc: LoadField: r2 = r4->field_7
    //     0x12c0adc: ldur            w2, [x4, #7]
    // 0x12c0ae0: DecompressPointer r2
    //     0x12c0ae0: add             x2, x2, HEAP, lsl #32
    // 0x12c0ae4: ldur            x0, [fp, #-0x18]
    // 0x12c0ae8: r1 = Null
    //     0x12c0ae8: mov             x1, NULL
    // 0x12c0aec: cmp             w2, NULL
    // 0x12c0af0: b.eq            #0x12c0b10
    // 0x12c0af4: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x12c0af4: ldur            w4, [x2, #0x17]
    // 0x12c0af8: DecompressPointer r4
    //     0x12c0af8: add             x4, x4, HEAP, lsl #32
    // 0x12c0afc: r8 = X0
    //     0x12c0afc: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x12c0b00: LoadField: r9 = r4->field_7
    //     0x12c0b00: ldur            x9, [x4, #7]
    // 0x12c0b04: r3 = Null
    //     0x12c0b04: add             x3, PP, #0x80, lsl #12  ; [pp+0x80470] Null
    //     0x12c0b08: ldr             x3, [x3, #0x470]
    // 0x12c0b0c: blr             x9
    // 0x12c0b10: ldur            x0, [fp, #-0x28]
    // 0x12c0b14: LoadField: r1 = r0->field_b
    //     0x12c0b14: ldur            w1, [x0, #0xb]
    // 0x12c0b18: LoadField: r2 = r0->field_f
    //     0x12c0b18: ldur            w2, [x0, #0xf]
    // 0x12c0b1c: DecompressPointer r2
    //     0x12c0b1c: add             x2, x2, HEAP, lsl #32
    // 0x12c0b20: LoadField: r3 = r2->field_b
    //     0x12c0b20: ldur            w3, [x2, #0xb]
    // 0x12c0b24: r2 = LoadInt32Instr(r1)
    //     0x12c0b24: sbfx            x2, x1, #1, #0x1f
    // 0x12c0b28: stur            x2, [fp, #-0x20]
    // 0x12c0b2c: r1 = LoadInt32Instr(r3)
    //     0x12c0b2c: sbfx            x1, x3, #1, #0x1f
    // 0x12c0b30: cmp             x2, x1
    // 0x12c0b34: b.ne            #0x12c0b40
    // 0x12c0b38: mov             x1, x0
    // 0x12c0b3c: r0 = _growToNextCapacity()
    //     0x12c0b3c: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x12c0b40: ldur            x0, [fp, #-0x28]
    // 0x12c0b44: ldur            x2, [fp, #-0x18]
    // 0x12c0b48: ldur            x1, [fp, #-0x20]
    // 0x12c0b4c: add             x3, x1, #1
    // 0x12c0b50: lsl             x4, x3, #1
    // 0x12c0b54: StoreField: r0->field_b = r4
    //     0x12c0b54: stur            w4, [x0, #0xb]
    // 0x12c0b58: LoadField: r3 = r0->field_f
    //     0x12c0b58: ldur            w3, [x0, #0xf]
    // 0x12c0b5c: DecompressPointer r3
    //     0x12c0b5c: add             x3, x3, HEAP, lsl #32
    // 0x12c0b60: ArrayStore: r3[r1] = r2  ; Unknown_4
    //     0x12c0b60: add             x4, x3, x1, lsl #2
    //     0x12c0b64: stur            w2, [x4, #0xf]
    // 0x12c0b68: mov             x7, x0
    // 0x12c0b6c: ldur            x0, [fp, #-0x30]
    // 0x12c0b70: add             x6, x0, #1
    // 0x12c0b74: ldur            x0, [fp, #-8]
    // 0x12c0b78: ldur            x4, [fp, #-0x38]
    // 0x12c0b7c: ldur            x3, [fp, #-0x40]
    // 0x12c0b80: b               #0x12c09a4
    // 0x12c0b84: mov             x0, x7
    // 0x12c0b88: LoadField: r1 = r0->field_b
    //     0x12c0b88: ldur            w1, [x0, #0xb]
    // 0x12c0b8c: cbz             w1, #0x12c0c28
    // 0x12c0b90: ldur            x1, [fp, #-0x10]
    // 0x12c0b94: r0 = Paragraph()
    //     0x12c0b94: bl              #0x12c93bc  ; AllocateParagraphStub -> Paragraph (size=0x20)
    // 0x12c0b98: mov             x1, x0
    // 0x12c0b9c: ldur            x2, [fp, #-0x28]
    // 0x12c0ba0: r3 = 65535
    //     0x12c0ba0: mov             x3, #0xffff
    // 0x12c0ba4: stur            x0, [fp, #-8]
    // 0x12c0ba8: r0 = Paragraph._()
    //     0x12c0ba8: bl              #0x12c0cc0  ; [package:bidi/bidi.dart] Paragraph::Paragraph._
    // 0x12c0bac: ldur            x0, [fp, #-0x10]
    // 0x12c0bb0: LoadField: r1 = r0->field_b
    //     0x12c0bb0: ldur            w1, [x0, #0xb]
    // 0x12c0bb4: LoadField: r2 = r0->field_f
    //     0x12c0bb4: ldur            w2, [x0, #0xf]
    // 0x12c0bb8: DecompressPointer r2
    //     0x12c0bb8: add             x2, x2, HEAP, lsl #32
    // 0x12c0bbc: LoadField: r3 = r2->field_b
    //     0x12c0bbc: ldur            w3, [x2, #0xb]
    // 0x12c0bc0: r2 = LoadInt32Instr(r1)
    //     0x12c0bc0: sbfx            x2, x1, #1, #0x1f
    // 0x12c0bc4: stur            x2, [fp, #-0x20]
    // 0x12c0bc8: r1 = LoadInt32Instr(r3)
    //     0x12c0bc8: sbfx            x1, x3, #1, #0x1f
    // 0x12c0bcc: cmp             x2, x1
    // 0x12c0bd0: b.ne            #0x12c0bdc
    // 0x12c0bd4: mov             x1, x0
    // 0x12c0bd8: r0 = _growToNextCapacity()
    //     0x12c0bd8: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x12c0bdc: ldur            x2, [fp, #-0x10]
    // 0x12c0be0: ldur            x3, [fp, #-0x20]
    // 0x12c0be4: add             x0, x3, #1
    // 0x12c0be8: lsl             x1, x0, #1
    // 0x12c0bec: StoreField: r2->field_b = r1
    //     0x12c0bec: stur            w1, [x2, #0xb]
    // 0x12c0bf0: LoadField: r1 = r2->field_f
    //     0x12c0bf0: ldur            w1, [x2, #0xf]
    // 0x12c0bf4: DecompressPointer r1
    //     0x12c0bf4: add             x1, x1, HEAP, lsl #32
    // 0x12c0bf8: ldur            x0, [fp, #-8]
    // 0x12c0bfc: ArrayStore: r1[r3] = r0  ; List_4
    //     0x12c0bfc: add             x25, x1, x3, lsl #2
    //     0x12c0c00: add             x25, x25, #0xf
    //     0x12c0c04: str             w0, [x25]
    //     0x12c0c08: tbz             w0, #0, #0x12c0c24
    //     0x12c0c0c: ldurb           w16, [x1, #-1]
    //     0x12c0c10: ldurb           w17, [x0, #-1]
    //     0x12c0c14: and             x16, x17, x16, lsr #2
    //     0x12c0c18: tst             x16, HEAP, lsr #32
    //     0x12c0c1c: b.eq            #0x12c0c24
    //     0x12c0c20: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12c0c24: b               #0x12c0c2c
    // 0x12c0c28: ldur            x2, [fp, #-0x10]
    // 0x12c0c2c: r0 = BidiString()
    //     0x12c0c2c: bl              #0x12c0cb4  ; AllocateBidiStringStub -> BidiString (size=0xc)
    // 0x12c0c30: ldur            x1, [fp, #-0x10]
    // 0x12c0c34: StoreField: r0->field_7 = r1
    //     0x12c0c34: stur            w1, [x0, #7]
    // 0x12c0c38: LeaveFrame
    //     0x12c0c38: mov             SP, fp
    //     0x12c0c3c: ldp             fp, lr, [SP], #0x10
    // 0x12c0c40: ret
    //     0x12c0c40: ret             
    // 0x12c0c44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c0c44: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c0c48: b               #0x12c0958
    // 0x12c0c4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12c0c4c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12c0c50: b               #0x12c09bc
  }
}

// class id: 8342, size: 0x14, field offset: 0x14
enum CharacterCategory extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11a8fc8, size: 0x64
    // 0x11a8fc8: EnterFrame
    //     0x11a8fc8: stp             fp, lr, [SP, #-0x10]!
    //     0x11a8fcc: mov             fp, SP
    // 0x11a8fd0: AllocStack(0x10)
    //     0x11a8fd0: sub             SP, SP, #0x10
    // 0x11a8fd4: SetupParameters(CharacterCategory this /* r1 => r0, fp-0x8 */)
    //     0x11a8fd4: mov             x0, x1
    //     0x11a8fd8: stur            x1, [fp, #-8]
    // 0x11a8fdc: CheckStackOverflow
    //     0x11a8fdc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a8fe0: cmp             SP, x16
    //     0x11a8fe4: b.ls            #0x11a9024
    // 0x11a8fe8: r1 = Null
    //     0x11a8fe8: mov             x1, NULL
    // 0x11a8fec: r2 = 4
    //     0x11a8fec: mov             x2, #4
    // 0x11a8ff0: r0 = AllocateArray()
    //     0x11a8ff0: bl              #0x13df928  ; AllocateArrayStub
    // 0x11a8ff4: r16 = "CharacterCategory."
    //     0x11a8ff4: add             x16, PP, #0x8b, lsl #12  ; [pp+0x8b048] "CharacterCategory."
    //     0x11a8ff8: ldr             x16, [x16, #0x48]
    // 0x11a8ffc: StoreField: r0->field_f = r16
    //     0x11a8ffc: stur            w16, [x0, #0xf]
    // 0x11a9000: ldur            x1, [fp, #-8]
    // 0x11a9004: LoadField: r2 = r1->field_f
    //     0x11a9004: ldur            w2, [x1, #0xf]
    // 0x11a9008: DecompressPointer r2
    //     0x11a9008: add             x2, x2, HEAP, lsl #32
    // 0x11a900c: StoreField: r0->field_13 = r2
    //     0x11a900c: stur            w2, [x0, #0x13]
    // 0x11a9010: str             x0, [SP]
    // 0x11a9014: r0 = _interpolate()
    //     0x11a9014: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11a9018: LeaveFrame
    //     0x11a9018: mov             SP, fp
    //     0x11a901c: ldp             fp, lr, [SP], #0x10
    // 0x11a9020: ret
    //     0x11a9020: ret             
    // 0x11a9024: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a9024: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a9028: b               #0x11a8fe8
  }
}

// class id: 8343, size: 0x14, field offset: 0x14
enum LetterForm extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11a8f40, size: 0x64
    // 0x11a8f40: EnterFrame
    //     0x11a8f40: stp             fp, lr, [SP, #-0x10]!
    //     0x11a8f44: mov             fp, SP
    // 0x11a8f48: AllocStack(0x10)
    //     0x11a8f48: sub             SP, SP, #0x10
    // 0x11a8f4c: SetupParameters(LetterForm this /* r1 => r0, fp-0x8 */)
    //     0x11a8f4c: mov             x0, x1
    //     0x11a8f50: stur            x1, [fp, #-8]
    // 0x11a8f54: CheckStackOverflow
    //     0x11a8f54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a8f58: cmp             SP, x16
    //     0x11a8f5c: b.ls            #0x11a8f9c
    // 0x11a8f60: r1 = Null
    //     0x11a8f60: mov             x1, NULL
    // 0x11a8f64: r2 = 4
    //     0x11a8f64: mov             x2, #4
    // 0x11a8f68: r0 = AllocateArray()
    //     0x11a8f68: bl              #0x13df928  ; AllocateArrayStub
    // 0x11a8f6c: r16 = "LetterForm."
    //     0x11a8f6c: add             x16, PP, #0x8b, lsl #12  ; [pp+0x8b030] "LetterForm."
    //     0x11a8f70: ldr             x16, [x16, #0x30]
    // 0x11a8f74: StoreField: r0->field_f = r16
    //     0x11a8f74: stur            w16, [x0, #0xf]
    // 0x11a8f78: ldur            x1, [fp, #-8]
    // 0x11a8f7c: LoadField: r2 = r1->field_f
    //     0x11a8f7c: ldur            w2, [x1, #0xf]
    // 0x11a8f80: DecompressPointer r2
    //     0x11a8f80: add             x2, x2, HEAP, lsl #32
    // 0x11a8f84: StoreField: r0->field_13 = r2
    //     0x11a8f84: stur            w2, [x0, #0x13]
    // 0x11a8f88: str             x0, [SP]
    // 0x11a8f8c: r0 = _interpolate()
    //     0x11a8f8c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11a8f90: LeaveFrame
    //     0x11a8f90: mov             SP, fp
    //     0x11a8f94: ldp             fp, lr, [SP], #0x10
    // 0x11a8f98: ret
    //     0x11a8f98: ret             
    // 0x11a8f9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a8f9c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a8fa0: b               #0x11a8f60
  }
}

// class id: 8344, size: 0x14, field offset: 0x14
enum DecompositionType extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11a8edc, size: 0x64
    // 0x11a8edc: EnterFrame
    //     0x11a8edc: stp             fp, lr, [SP, #-0x10]!
    //     0x11a8ee0: mov             fp, SP
    // 0x11a8ee4: AllocStack(0x10)
    //     0x11a8ee4: sub             SP, SP, #0x10
    // 0x11a8ee8: SetupParameters(DecompositionType this /* r1 => r0, fp-0x8 */)
    //     0x11a8ee8: mov             x0, x1
    //     0x11a8eec: stur            x1, [fp, #-8]
    // 0x11a8ef0: CheckStackOverflow
    //     0x11a8ef0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a8ef4: cmp             SP, x16
    //     0x11a8ef8: b.ls            #0x11a8f38
    // 0x11a8efc: r1 = Null
    //     0x11a8efc: mov             x1, NULL
    // 0x11a8f00: r2 = 4
    //     0x11a8f00: mov             x2, #4
    // 0x11a8f04: r0 = AllocateArray()
    //     0x11a8f04: bl              #0x13df928  ; AllocateArrayStub
    // 0x11a8f08: r16 = "DecompositionType."
    //     0x11a8f08: add             x16, PP, #0x8b, lsl #12  ; [pp+0x8b028] "DecompositionType."
    //     0x11a8f0c: ldr             x16, [x16, #0x28]
    // 0x11a8f10: StoreField: r0->field_f = r16
    //     0x11a8f10: stur            w16, [x0, #0xf]
    // 0x11a8f14: ldur            x1, [fp, #-8]
    // 0x11a8f18: LoadField: r2 = r1->field_f
    //     0x11a8f18: ldur            w2, [x1, #0xf]
    // 0x11a8f1c: DecompressPointer r2
    //     0x11a8f1c: add             x2, x2, HEAP, lsl #32
    // 0x11a8f20: StoreField: r0->field_13 = r2
    //     0x11a8f20: stur            w2, [x0, #0x13]
    // 0x11a8f24: str             x0, [SP]
    // 0x11a8f28: r0 = _interpolate()
    //     0x11a8f28: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11a8f2c: LeaveFrame
    //     0x11a8f2c: mov             SP, fp
    //     0x11a8f30: ldp             fp, lr, [SP], #0x10
    // 0x11a8f34: ret
    //     0x11a8f34: ret             
    // 0x11a8f38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a8f38: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a8f3c: b               #0x11a8efc
  }
}

// class id: 8345, size: 0x14, field offset: 0x14
enum ShapeJoiningType extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11a8e78, size: 0x64
    // 0x11a8e78: EnterFrame
    //     0x11a8e78: stp             fp, lr, [SP, #-0x10]!
    //     0x11a8e7c: mov             fp, SP
    // 0x11a8e80: AllocStack(0x10)
    //     0x11a8e80: sub             SP, SP, #0x10
    // 0x11a8e84: SetupParameters(ShapeJoiningType this /* r1 => r0, fp-0x8 */)
    //     0x11a8e84: mov             x0, x1
    //     0x11a8e88: stur            x1, [fp, #-8]
    // 0x11a8e8c: CheckStackOverflow
    //     0x11a8e8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a8e90: cmp             SP, x16
    //     0x11a8e94: b.ls            #0x11a8ed4
    // 0x11a8e98: r1 = Null
    //     0x11a8e98: mov             x1, NULL
    // 0x11a8e9c: r2 = 4
    //     0x11a8e9c: mov             x2, #4
    // 0x11a8ea0: r0 = AllocateArray()
    //     0x11a8ea0: bl              #0x13df928  ; AllocateArrayStub
    // 0x11a8ea4: r16 = "ShapeJoiningType."
    //     0x11a8ea4: add             x16, PP, #0x8b, lsl #12  ; [pp+0x8b040] "ShapeJoiningType."
    //     0x11a8ea8: ldr             x16, [x16, #0x40]
    // 0x11a8eac: StoreField: r0->field_f = r16
    //     0x11a8eac: stur            w16, [x0, #0xf]
    // 0x11a8eb0: ldur            x1, [fp, #-8]
    // 0x11a8eb4: LoadField: r2 = r1->field_f
    //     0x11a8eb4: ldur            w2, [x1, #0xf]
    // 0x11a8eb8: DecompressPointer r2
    //     0x11a8eb8: add             x2, x2, HEAP, lsl #32
    // 0x11a8ebc: StoreField: r0->field_13 = r2
    //     0x11a8ebc: stur            w2, [x0, #0x13]
    // 0x11a8ec0: str             x0, [SP]
    // 0x11a8ec4: r0 = _interpolate()
    //     0x11a8ec4: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11a8ec8: LeaveFrame
    //     0x11a8ec8: mov             SP, fp
    //     0x11a8ecc: ldp             fp, lr, [SP], #0x10
    // 0x11a8ed0: ret
    //     0x11a8ed0: ret             
    // 0x11a8ed4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a8ed4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a8ed8: b               #0x11a8e98
  }
}

// class id: 8346, size: 0x14, field offset: 0x14
enum DirectionOverride extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11a8df0, size: 0x64
    // 0x11a8df0: EnterFrame
    //     0x11a8df0: stp             fp, lr, [SP, #-0x10]!
    //     0x11a8df4: mov             fp, SP
    // 0x11a8df8: AllocStack(0x10)
    //     0x11a8df8: sub             SP, SP, #0x10
    // 0x11a8dfc: SetupParameters(DirectionOverride this /* r1 => r0, fp-0x8 */)
    //     0x11a8dfc: mov             x0, x1
    //     0x11a8e00: stur            x1, [fp, #-8]
    // 0x11a8e04: CheckStackOverflow
    //     0x11a8e04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a8e08: cmp             SP, x16
    //     0x11a8e0c: b.ls            #0x11a8e4c
    // 0x11a8e10: r1 = Null
    //     0x11a8e10: mov             x1, NULL
    // 0x11a8e14: r2 = 4
    //     0x11a8e14: mov             x2, #4
    // 0x11a8e18: r0 = AllocateArray()
    //     0x11a8e18: bl              #0x13df928  ; AllocateArrayStub
    // 0x11a8e1c: r16 = "DirectionOverride."
    //     0x11a8e1c: add             x16, PP, #0x8b, lsl #12  ; [pp+0x8b020] "DirectionOverride."
    //     0x11a8e20: ldr             x16, [x16, #0x20]
    // 0x11a8e24: StoreField: r0->field_f = r16
    //     0x11a8e24: stur            w16, [x0, #0xf]
    // 0x11a8e28: ldur            x1, [fp, #-8]
    // 0x11a8e2c: LoadField: r2 = r1->field_f
    //     0x11a8e2c: ldur            w2, [x1, #0xf]
    // 0x11a8e30: DecompressPointer r2
    //     0x11a8e30: add             x2, x2, HEAP, lsl #32
    // 0x11a8e34: StoreField: r0->field_13 = r2
    //     0x11a8e34: stur            w2, [x0, #0x13]
    // 0x11a8e38: str             x0, [SP]
    // 0x11a8e3c: r0 = _interpolate()
    //     0x11a8e3c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11a8e40: LeaveFrame
    //     0x11a8e40: mov             SP, fp
    //     0x11a8e44: ldp             fp, lr, [SP], #0x10
    // 0x11a8e48: ret
    //     0x11a8e48: ret             
    // 0x11a8e4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a8e4c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a8e50: b               #0x11a8e10
  }
}

// class id: 8347, size: 0x14, field offset: 0x14
enum CharacterType extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11a8d68, size: 0x64
    // 0x11a8d68: EnterFrame
    //     0x11a8d68: stp             fp, lr, [SP, #-0x10]!
    //     0x11a8d6c: mov             fp, SP
    // 0x11a8d70: AllocStack(0x10)
    //     0x11a8d70: sub             SP, SP, #0x10
    // 0x11a8d74: SetupParameters(CharacterType this /* r1 => r0, fp-0x8 */)
    //     0x11a8d74: mov             x0, x1
    //     0x11a8d78: stur            x1, [fp, #-8]
    // 0x11a8d7c: CheckStackOverflow
    //     0x11a8d7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a8d80: cmp             SP, x16
    //     0x11a8d84: b.ls            #0x11a8dc4
    // 0x11a8d88: r1 = Null
    //     0x11a8d88: mov             x1, NULL
    // 0x11a8d8c: r2 = 4
    //     0x11a8d8c: mov             x2, #4
    // 0x11a8d90: r0 = AllocateArray()
    //     0x11a8d90: bl              #0x13df928  ; AllocateArrayStub
    // 0x11a8d94: r16 = "CharacterType."
    //     0x11a8d94: add             x16, PP, #0x8b, lsl #12  ; [pp+0x8b038] "CharacterType."
    //     0x11a8d98: ldr             x16, [x16, #0x38]
    // 0x11a8d9c: StoreField: r0->field_f = r16
    //     0x11a8d9c: stur            w16, [x0, #0xf]
    // 0x11a8da0: ldur            x1, [fp, #-8]
    // 0x11a8da4: LoadField: r2 = r1->field_f
    //     0x11a8da4: ldur            w2, [x1, #0xf]
    // 0x11a8da8: DecompressPointer r2
    //     0x11a8da8: add             x2, x2, HEAP, lsl #32
    // 0x11a8dac: StoreField: r0->field_13 = r2
    //     0x11a8dac: stur            w2, [x0, #0x13]
    // 0x11a8db0: str             x0, [SP]
    // 0x11a8db4: r0 = _interpolate()
    //     0x11a8db4: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11a8db8: LeaveFrame
    //     0x11a8db8: mov             SP, fp
    //     0x11a8dbc: ldp             fp, lr, [SP], #0x10
    // 0x11a8dc0: ret
    //     0x11a8dc0: ret             
    // 0x11a8dc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a8dc4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a8dc8: b               #0x11a8d88
  }
}
