// lib: device_marketing_names, url: package:device_marketing_names/src/logic/get_names.dart

// class id: 1048692, size: 0x8
class :: {
}

// class id: 3417, size: 0x8, field offset: 0x8
class DeviceMarketingNames extends Object {

  static late final DeviceMarketingNames _instance; // offset: 0x1080

  static DeviceMarketingNames _instance() {
    // ** addr: 0x9ec2a8, size: 0x18
    // 0x9ec2a8: EnterFrame
    //     0x9ec2a8: stp             fp, lr, [SP, #-0x10]!
    //     0x9ec2ac: mov             fp, SP
    // 0x9ec2b0: r0 = DeviceMarketingNames()
    //     0x9ec2b0: bl              #0x9ec2c0  ; AllocateDeviceMarketingNamesStub -> DeviceMarketingNames (size=0x8)
    // 0x9ec2b4: LeaveFrame
    //     0x9ec2b4: mov             SP, fp
    //     0x9ec2b8: ldp             fp, lr, [SP], #0x10
    // 0x9ec2bc: ret
    //     0x9ec2bc: ret             
  }
}
