// lib: , url: package:connectivity_plus/connectivity_plus.dart

// class id: 1048660, size: 0x8
class :: {
}

// class id: 3563, size: 0x8, field offset: 0x8
class Connectivity extends Object {

  factory _ Connectivity(/* No info */) {
    // ** addr: 0x91ff50, size: 0x34
    // 0x91ff50: EnterFrame
    //     0x91ff50: stp             fp, lr, [SP, #-0x10]!
    //     0x91ff54: mov             fp, SP
    // 0x91ff58: r0 = LoadStaticField(0xe08)
    //     0x91ff58: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x91ff5c: ldr             x0, [x0, #0x1c10]
    // 0x91ff60: cmp             w0, NULL
    // 0x91ff64: b.ne            #0x91ff78
    // 0x91ff68: r0 = Connectivity()
    //     0x91ff68: bl              #0x920530  ; AllocateConnectivityStub -> Connectivity (size=0x8)
    // 0x91ff6c: mov             x2, x0
    // 0x91ff70: StoreStaticField(0xe08, r2)
    //     0x91ff70: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x91ff74: str             x2, [x1, #0x1c10]
    // 0x91ff78: LeaveFrame
    //     0x91ff78: mov             SP, fp
    //     0x91ff7c: ldp             fp, lr, [SP], #0x10
    // 0x91ff80: ret
    //     0x91ff80: ret             
  }
  _ checkConnectivity(/* No info */) {
    // ** addr: 0x91ffc0, size: 0x50
    // 0x91ffc0: EnterFrame
    //     0x91ffc0: stp             fp, lr, [SP, #-0x10]!
    //     0x91ffc4: mov             fp, SP
    // 0x91ffc8: CheckStackOverflow
    //     0x91ffc8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91ffcc: cmp             SP, x16
    //     0x91ffd0: b.ls            #0x920008
    // 0x91ffd4: r0 = LoadStaticField(0xf68)
    //     0x91ffd4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x91ffd8: ldr             x0, [x0, #0x1ed0]
    // 0x91ffdc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x91ffe0: cmp             w0, w16
    // 0x91ffe4: b.ne            #0x91fff4
    // 0x91ffe8: r2 = _instance
    //     0x91ffe8: add             x2, PP, #0x15, lsl #12  ; [pp+0x15330] Field <ConnectivityPlatform._instance@1232483631>: static late (offset: 0xf68)
    //     0x91ffec: ldr             x2, [x2, #0x330]
    // 0x91fff0: r0 = InitLateStaticField()
    //     0x91fff0: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0x91fff4: mov             x1, x0
    // 0x91fff8: r0 = checkConnectivity()
    //     0x91fff8: bl              #0x920010  ; [package:connectivity_plus_platform_interface/method_channel_connectivity.dart] MethodChannelConnectivity::checkConnectivity
    // 0x91fffc: LeaveFrame
    //     0x91fffc: mov             SP, fp
    //     0x920000: ldp             fp, lr, [SP], #0x10
    // 0x920004: ret
    //     0x920004: ret             
    // 0x920008: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x920008: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x92000c: b               #0x91ffd4
  }
  get _ onConnectivityChanged(/* No info */) {
    // ** addr: 0xf98ca4, size: 0x74
    // 0xf98ca4: EnterFrame
    //     0xf98ca4: stp             fp, lr, [SP, #-0x10]!
    //     0xf98ca8: mov             fp, SP
    // 0xf98cac: AllocStack(0x8)
    //     0xf98cac: sub             SP, SP, #8
    // 0xf98cb0: CheckStackOverflow
    //     0xf98cb0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf98cb4: cmp             SP, x16
    //     0xf98cb8: b.ls            #0xf98d10
    // 0xf98cbc: r0 = LoadStaticField(0xf68)
    //     0xf98cbc: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf98cc0: ldr             x0, [x0, #0x1ed0]
    // 0xf98cc4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf98cc8: cmp             w0, w16
    // 0xf98ccc: b.ne            #0xf98cdc
    // 0xf98cd0: r2 = _instance
    //     0xf98cd0: add             x2, PP, #0x15, lsl #12  ; [pp+0x15330] Field <ConnectivityPlatform._instance@1232483631>: static late (offset: 0xf68)
    //     0xf98cd4: ldr             x2, [x2, #0x330]
    // 0xf98cd8: r0 = InitLateStaticField()
    //     0xf98cd8: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0xf98cdc: mov             x1, x0
    // 0xf98ce0: r0 = onConnectivityChanged()
    //     0xf98ce0: bl              #0xf98d90  ; [package:connectivity_plus_platform_interface/method_channel_connectivity.dart] MethodChannelConnectivity::onConnectivityChanged
    // 0xf98ce4: r1 = Function '<anonymous closure>':.
    //     0xf98ce4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15338] AnonymousClosure: (0xf98eb4), in [package:connectivity_plus/connectivity_plus.dart] Connectivity::onConnectivityChanged (0xf98ca4)
    //     0xf98ce8: ldr             x1, [x1, #0x338]
    // 0xf98cec: r2 = Null
    //     0xf98cec: mov             x2, NULL
    // 0xf98cf0: stur            x0, [fp, #-8]
    // 0xf98cf4: r0 = AllocateClosure()
    //     0xf98cf4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf98cf8: ldur            x1, [fp, #-8]
    // 0xf98cfc: mov             x2, x0
    // 0xf98d00: r0 = distinct()
    //     0xf98d00: bl              #0xf98d18  ; [dart:async] Stream::distinct
    // 0xf98d04: LeaveFrame
    //     0xf98d04: mov             SP, fp
    //     0xf98d08: ldp             fp, lr, [SP], #0x10
    // 0xf98d0c: ret
    //     0xf98d0c: ret             
    // 0xf98d10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf98d10: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf98d14: b               #0xf98cbc
  }
  [closure] bool <anonymous closure>(dynamic, List<ConnectivityResult>, List<ConnectivityResult>) {
    // ** addr: 0xf98eb4, size: 0x4c
    // 0xf98eb4: EnterFrame
    //     0xf98eb4: stp             fp, lr, [SP, #-0x10]!
    //     0xf98eb8: mov             fp, SP
    // 0xf98ebc: AllocStack(0x18)
    //     0xf98ebc: sub             SP, SP, #0x18
    // 0xf98ec0: CheckStackOverflow
    //     0xf98ec0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf98ec4: cmp             SP, x16
    //     0xf98ec8: b.ls            #0xf98ef8
    // 0xf98ecc: r16 = <ConnectivityResult>
    //     0xf98ecc: add             x16, PP, #0x15, lsl #12  ; [pp+0x15340] TypeArguments: <ConnectivityResult>
    //     0xf98ed0: ldr             x16, [x16, #0x340]
    // 0xf98ed4: ldr             lr, [fp, #0x18]
    // 0xf98ed8: stp             lr, x16, [SP, #8]
    // 0xf98edc: ldr             x16, [fp, #0x10]
    // 0xf98ee0: str             x16, [SP]
    // 0xf98ee4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xf98ee4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xf98ee8: r0 = ListExtensions.equals()
    //     0xf98ee8: bl              #0xf98f00  ; [package:collection/src/list_extensions.dart] ::ListExtensions.equals
    // 0xf98eec: LeaveFrame
    //     0xf98eec: mov             SP, fp
    //     0xf98ef0: ldp             fp, lr, [SP], #0x10
    // 0xf98ef4: ret
    //     0xf98ef4: ret             
    // 0xf98ef8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf98ef8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf98efc: b               #0xf98ecc
  }
}
