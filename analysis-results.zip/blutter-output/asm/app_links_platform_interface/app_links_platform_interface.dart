// lib: , url: package:app_links_platform_interface/app_links_platform_interface.dart

// class id: 1048601, size: 0x8
class :: {
}

// class id: 3711, size: 0x8, field offset: 0x8
abstract class AppLinksPlatform extends PlatformInterface {

  static late AppLinksPlatform _instance; // offset: 0xf08
  static late final Object _token; // offset: 0xf04

  static AppLinksPlatform _instance() {
    // ** addr: 0xf7d8b4, size: 0x98
    // 0xf7d8b4: EnterFrame
    //     0xf7d8b4: stp             fp, lr, [SP, #-0x10]!
    //     0xf7d8b8: mov             fp, SP
    // 0xf7d8bc: AllocStack(0x10)
    //     0xf7d8bc: sub             SP, SP, #0x10
    // 0xf7d8c0: CheckStackOverflow
    //     0xf7d8c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf7d8c4: cmp             SP, x16
    //     0xf7d8c8: b.ls            #0xf7d944
    // 0xf7d8cc: r0 = AppLinksMethodChannel()
    //     0xf7d8cc: bl              #0xf7d94c  ; AllocateAppLinksMethodChannelStub -> AppLinksMethodChannel (size=0xc)
    // 0xf7d8d0: mov             x1, x0
    // 0xf7d8d4: r0 = Instance_EventChannel
    //     0xf7d8d4: add             x0, PP, #0x83, lsl #12  ; [pp+0x836e8] Obj!EventChannel@129ba81
    //     0xf7d8d8: ldr             x0, [x0, #0x6e8]
    // 0xf7d8dc: stur            x1, [fp, #-8]
    // 0xf7d8e0: StoreField: r1->field_7 = r0
    //     0xf7d8e0: stur            w0, [x1, #7]
    // 0xf7d8e4: r0 = LoadStaticField(0xf04)
    //     0xf7d8e4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf7d8e8: ldr             x0, [x0, #0x1e08]
    // 0xf7d8ec: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf7d8f0: cmp             w0, w16
    // 0xf7d8f4: b.ne            #0xf7d904
    // 0xf7d8f8: r2 = _token
    //     0xf7d8f8: add             x2, PP, #0x83, lsl #12  ; [pp+0x83720] Field <AppLinksPlatform._token@1165069159>: static late final (offset: 0xf04)
    //     0xf7d8fc: ldr             x2, [x2, #0x720]
    // 0xf7d900: r0 = InitLateFinalStaticField()
    //     0xf7d900: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xf7d904: stur            x0, [fp, #-0x10]
    // 0xf7d908: r0 = LoadStaticField(0xde8)
    //     0xf7d908: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf7d90c: ldr             x0, [x0, #0x1bd0]
    // 0xf7d910: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf7d914: cmp             w0, w16
    // 0xf7d918: b.ne            #0xf7d924
    // 0xf7d91c: r2 = _instanceTokens
    //     0xf7d91c: ldr             x2, [PP, #0x68c0]  ; [pp+0x68c0] Field <PlatformInterface._instanceTokens@1171304592>: static late final (offset: 0xde8)
    // 0xf7d920: r0 = InitLateFinalStaticField()
    //     0xf7d920: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xf7d924: mov             x1, x0
    // 0xf7d928: ldur            x2, [fp, #-8]
    // 0xf7d92c: ldur            x3, [fp, #-0x10]
    // 0xf7d930: r0 = []=()
    //     0xf7d930: bl              #0x7f6290  ; [dart:core] Expando::[]=
    // 0xf7d934: ldur            x0, [fp, #-8]
    // 0xf7d938: LeaveFrame
    //     0xf7d938: mov             SP, fp
    //     0xf7d93c: ldp             fp, lr, [SP], #0x10
    // 0xf7d940: ret
    //     0xf7d940: ret             
    // 0xf7d944: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf7d944: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf7d948: b               #0xf7d8cc
  }
}
