// lib: , url: package:app_links_platform_interface/app_links_method_channel.dart

// class id: 1048600, size: 0x8
class :: {
}

// class id: 3712, size: 0xc, field offset: 0x8
class AppLinksMethodChannel extends AppLinksPlatform {

  get _ uriLinkStream(/* No info */) {
    // ** addr: 0xf7d64c, size: 0xb0
    // 0xf7d64c: EnterFrame
    //     0xf7d64c: stp             fp, lr, [SP, #-0x10]!
    //     0xf7d650: mov             fp, SP
    // 0xf7d654: AllocStack(0x30)
    //     0xf7d654: sub             SP, SP, #0x30
    // 0xf7d658: CheckStackOverflow
    //     0xf7d658: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf7d65c: cmp             SP, x16
    //     0xf7d660: b.ls            #0xf7d6f4
    // 0xf7d664: r0 = stringLinkStream()
    //     0xf7d664: bl              #0xf7d6fc  ; [package:app_links_platform_interface/app_links_method_channel.dart] AppLinksMethodChannel::stringLinkStream
    // 0xf7d668: r1 = <String, Uri>
    //     0xf7d668: add             x1, PP, #0x83, lsl #12  ; [pp+0x836d8] TypeArguments: <String, Uri>
    //     0xf7d66c: ldr             x1, [x1, #0x6d8]
    // 0xf7d670: stur            x0, [fp, #-8]
    // 0xf7d674: r0 = _StreamHandlerTransformer()
    //     0xf7d674: bl              #0x90ebf8  ; Allocate_StreamHandlerTransformerStub -> _StreamHandlerTransformer<X0, X1> (size=0x10)
    // 0xf7d678: stur            x0, [fp, #-0x10]
    // 0xf7d67c: r1 = 2
    //     0xf7d67c: mov             x1, #2
    // 0xf7d680: r0 = AllocateContext()
    //     0xf7d680: bl              #0x13de838  ; AllocateContextStub
    // 0xf7d684: mov             x3, x0
    // 0xf7d688: ldur            x0, [fp, #-0x10]
    // 0xf7d68c: stur            x3, [fp, #-0x18]
    // 0xf7d690: StoreField: r3->field_f = r0
    //     0xf7d690: stur            w0, [x3, #0xf]
    // 0xf7d694: r1 = Function '<anonymous closure>':.
    //     0xf7d694: add             x1, PP, #0x83, lsl #12  ; [pp+0x836e0] AnonymousClosure: (0xf7d82c), in [package:app_links_platform_interface/app_links_method_channel.dart] AppLinksMethodChannel::uriLinkStream (0xf7d64c)
    //     0xf7d698: ldr             x1, [x1, #0x6e0]
    // 0xf7d69c: r2 = Null
    //     0xf7d69c: mov             x2, NULL
    // 0xf7d6a0: r0 = AllocateClosure()
    //     0xf7d6a0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf7d6a4: ldur            x2, [fp, #-0x18]
    // 0xf7d6a8: StoreField: r2->field_13 = r0
    //     0xf7d6a8: stur            w0, [x2, #0x13]
    // 0xf7d6ac: r1 = Function '<anonymous closure>':.
    //     0xf7d6ac: add             x1, PP, #0x16, lsl #12  ; [pp+0x16710] AnonymousClosure: (0x90ec04), of [dart:async] _StreamHandlerTransformer<X0, X1>
    //     0xf7d6b0: ldr             x1, [x1, #0x710]
    // 0xf7d6b4: r3 = <String, Uri>
    //     0xf7d6b4: add             x3, PP, #0x83, lsl #12  ; [pp+0x836d8] TypeArguments: <String, Uri>
    //     0xf7d6b8: ldr             x3, [x3, #0x6d8]
    // 0xf7d6bc: r0 = AllocateClosureTA()
    //     0xf7d6bc: bl              #0x13dea48  ; AllocateClosureTAStub
    // 0xf7d6c0: mov             x1, x0
    // 0xf7d6c4: ldur            x0, [fp, #-0x10]
    // 0xf7d6c8: StoreField: r0->field_b = r1
    //     0xf7d6c8: stur            w1, [x0, #0xb]
    // 0xf7d6cc: r16 = <Uri>
    //     0xf7d6cc: add             x16, PP, #0x83, lsl #12  ; [pp+0x836a0] TypeArguments: <Uri>
    //     0xf7d6d0: ldr             x16, [x16, #0x6a0]
    // 0xf7d6d4: ldur            lr, [fp, #-8]
    // 0xf7d6d8: stp             lr, x16, [SP, #8]
    // 0xf7d6dc: str             x0, [SP]
    // 0xf7d6e0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xf7d6e0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xf7d6e4: r0 = transform()
    //     0xf7d6e4: bl              #0x819be0  ; [dart:async] Stream::transform
    // 0xf7d6e8: LeaveFrame
    //     0xf7d6e8: mov             SP, fp
    //     0xf7d6ec: ldp             fp, lr, [SP], #0x10
    // 0xf7d6f0: ret
    //     0xf7d6f0: ret             
    // 0xf7d6f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf7d6f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf7d6f8: b               #0xf7d664
  }
  get _ stringLinkStream(/* No info */) {
    // ** addr: 0xf7d6fc, size: 0x84
    // 0xf7d6fc: EnterFrame
    //     0xf7d6fc: stp             fp, lr, [SP, #-0x10]!
    //     0xf7d700: mov             fp, SP
    // 0xf7d704: AllocStack(0x20)
    //     0xf7d704: sub             SP, SP, #0x20
    // 0xf7d708: CheckStackOverflow
    //     0xf7d708: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf7d70c: cmp             SP, x16
    //     0xf7d710: b.ls            #0xf7d778
    // 0xf7d714: r1 = Instance_EventChannel
    //     0xf7d714: add             x1, PP, #0x83, lsl #12  ; [pp+0x836e8] Obj!EventChannel@129ba81
    //     0xf7d718: ldr             x1, [x1, #0x6e8]
    // 0xf7d71c: r0 = receiveBroadcastStream()
    //     0xf7d71c: bl              #0x8c35d4  ; [package:flutter/src/services/platform_channel.dart] EventChannel::receiveBroadcastStream
    // 0xf7d720: r1 = Function '<anonymous closure>':.
    //     0xf7d720: add             x1, PP, #0x83, lsl #12  ; [pp+0x836f0] AnonymousClosure: (0xf7d7d0), in [package:app_links_platform_interface/app_links_method_channel.dart] AppLinksMethodChannel::stringLinkStream (0xf7d6fc)
    //     0xf7d724: ldr             x1, [x1, #0x6f0]
    // 0xf7d728: r2 = Null
    //     0xf7d728: mov             x2, NULL
    // 0xf7d72c: stur            x0, [fp, #-8]
    // 0xf7d730: r0 = AllocateClosure()
    //     0xf7d730: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf7d734: ldur            x1, [fp, #-8]
    // 0xf7d738: mov             x2, x0
    // 0xf7d73c: r0 = where()
    //     0xf7d73c: bl              #0x8c3cb0  ; [dart:async] Stream::where
    // 0xf7d740: r1 = Function '<anonymous closure>':.
    //     0xf7d740: add             x1, PP, #0x83, lsl #12  ; [pp+0x836f8] AnonymousClosure: (0xf7d780), in [package:app_links_platform_interface/app_links_method_channel.dart] AppLinksMethodChannel::stringLinkStream (0xf7d6fc)
    //     0xf7d744: ldr             x1, [x1, #0x6f8]
    // 0xf7d748: r2 = Null
    //     0xf7d748: mov             x2, NULL
    // 0xf7d74c: stur            x0, [fp, #-8]
    // 0xf7d750: r0 = AllocateClosure()
    //     0xf7d750: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf7d754: r16 = <String>
    //     0xf7d754: ldr             x16, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    // 0xf7d758: ldur            lr, [fp, #-8]
    // 0xf7d75c: stp             lr, x16, [SP, #8]
    // 0xf7d760: str             x0, [SP]
    // 0xf7d764: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xf7d764: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xf7d768: r0 = map()
    //     0xf7d768: bl              #0x8c354c  ; [dart:async] Stream::map
    // 0xf7d76c: LeaveFrame
    //     0xf7d76c: mov             SP, fp
    //     0xf7d770: ldp             fp, lr, [SP], #0x10
    // 0xf7d774: ret
    //     0xf7d774: ret             
    // 0xf7d778: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf7d778: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf7d77c: b               #0xf7d714
  }
  [closure] String <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0xf7d780, size: 0x50
    // 0xf7d780: EnterFrame
    //     0xf7d780: stp             fp, lr, [SP, #-0x10]!
    //     0xf7d784: mov             fp, SP
    // 0xf7d788: ldr             x0, [fp, #0x10]
    // 0xf7d78c: r2 = Null
    //     0xf7d78c: mov             x2, NULL
    // 0xf7d790: r1 = Null
    //     0xf7d790: mov             x1, NULL
    // 0xf7d794: r4 = 60
    //     0xf7d794: mov             x4, #0x3c
    // 0xf7d798: branchIfSmi(r0, 0xf7d7a4)
    //     0xf7d798: tbz             w0, #0, #0xf7d7a4
    // 0xf7d79c: r4 = LoadClassIdInstr(r0)
    //     0xf7d79c: ldur            x4, [x0, #-1]
    //     0xf7d7a0: ubfx            x4, x4, #0xc, #0x14
    // 0xf7d7a4: sub             x4, x4, #0x5e
    // 0xf7d7a8: cmp             x4, #1
    // 0xf7d7ac: b.ls            #0xf7d7c0
    // 0xf7d7b0: r8 = String
    //     0xf7d7b0: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0xf7d7b4: r3 = Null
    //     0xf7d7b4: add             x3, PP, #0x83, lsl #12  ; [pp+0x83700] Null
    //     0xf7d7b8: ldr             x3, [x3, #0x700]
    // 0xf7d7bc: r0 = String()
    //     0xf7d7bc: bl              #0x13ee320  ; IsType_String_Stub
    // 0xf7d7c0: ldr             x0, [fp, #0x10]
    // 0xf7d7c4: LeaveFrame
    //     0xf7d7c4: mov             SP, fp
    //     0xf7d7c8: ldp             fp, lr, [SP], #0x10
    // 0xf7d7cc: ret
    //     0xf7d7cc: ret             
  }
  [closure] bool <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0xf7d7d0, size: 0x5c
    // 0xf7d7d0: EnterFrame
    //     0xf7d7d0: stp             fp, lr, [SP, #-0x10]!
    //     0xf7d7d4: mov             fp, SP
    // 0xf7d7d8: AllocStack(0x8)
    //     0xf7d7d8: sub             SP, SP, #8
    // 0xf7d7dc: CheckStackOverflow
    //     0xf7d7dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf7d7e0: cmp             SP, x16
    //     0xf7d7e4: b.ls            #0xf7d824
    // 0xf7d7e8: ldr             x0, [fp, #0x10]
    // 0xf7d7ec: cmp             w0, NULL
    // 0xf7d7f0: b.eq            #0xf7d814
    // 0xf7d7f4: str             x0, [SP]
    // 0xf7d7f8: r4 = 0
    //     0xf7d7f8: mov             x4, #0
    // 0xf7d7fc: ldr             x0, [SP]
    // 0xf7d800: r16 = 139822029843448
    //     0xf7d800: add             x16, PP, #0x83, lsl #12  ; [pp+0x83710] IMM: 0x7f2ada6babf8
    //     0xf7d804: add             x16, x16, #0x710
    // 0xf7d808: ldp             lr, x5, [x16]
    // 0xf7d80c: blr             lr
    // 0xf7d810: b               #0xf7d818
    // 0xf7d814: r0 = false
    //     0xf7d814: add             x0, NULL, #0x30  ; false
    // 0xf7d818: LeaveFrame
    //     0xf7d818: mov             SP, fp
    //     0xf7d81c: ldp             fp, lr, [SP], #0x10
    // 0xf7d820: ret
    //     0xf7d820: ret             
    // 0xf7d824: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf7d824: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf7d828: b               #0xf7d7e8
  }
  [closure] void <anonymous closure>(dynamic, String, EventSink<Uri>) {
    // ** addr: 0xf7d82c, size: 0x68
    // 0xf7d82c: EnterFrame
    //     0xf7d82c: stp             fp, lr, [SP, #-0x10]!
    //     0xf7d830: mov             fp, SP
    // 0xf7d834: CheckStackOverflow
    //     0xf7d834: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf7d838: cmp             SP, x16
    //     0xf7d83c: b.ls            #0xf7d88c
    // 0xf7d840: ldr             x1, [fp, #0x18]
    // 0xf7d844: r0 = tryParse()
    //     0xf7d844: bl              #0x8e2130  ; [dart:core] Uri::tryParse
    // 0xf7d848: cmp             w0, NULL
    // 0xf7d84c: b.eq            #0xf7d87c
    // 0xf7d850: ldr             x1, [fp, #0x10]
    // 0xf7d854: r2 = LoadClassIdInstr(r1)
    //     0xf7d854: ldur            x2, [x1, #-1]
    //     0xf7d858: ubfx            x2, x2, #0xc, #0x14
    // 0xf7d85c: mov             x16, x0
    // 0xf7d860: mov             x0, x2
    // 0xf7d864: mov             x2, x16
    // 0xf7d868: r0 = GDT[cid_x0 + 0x1847a]()
    //     0xf7d868: mov             x17, #0x847a
    //     0xf7d86c: movk            x17, #1, lsl #16
    //     0xf7d870: add             lr, x0, x17
    //     0xf7d874: ldr             lr, [x21, lr, lsl #3]
    //     0xf7d878: blr             lr
    // 0xf7d87c: r0 = Null
    //     0xf7d87c: mov             x0, NULL
    // 0xf7d880: LeaveFrame
    //     0xf7d880: mov             SP, fp
    //     0xf7d884: ldp             fp, lr, [SP], #0x10
    // 0xf7d888: ret
    //     0xf7d888: ret             
    // 0xf7d88c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf7d88c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf7d890: b               #0xf7d840
  }
}
