// lib: , url: package:firebase_crashlytics_platform_interface/src/platform_interface/platform_interface_crashlytics.dart

// class id: 1048751, size: 0x8
class :: {
}

// class id: 3699, size: 0x8, field offset: 0x8
abstract class FirebaseCrashlyticsPlatform extends PlatformInterface {

  static late final Object _token; // offset: 0x10c4

  factory _ FirebaseCrashlyticsPlatform.instanceFor(/* No info */) {
    // ** addr: 0x8c0b38, size: 0x90
    // 0x8c0b38: EnterFrame
    //     0x8c0b38: stp             fp, lr, [SP, #-0x10]!
    //     0x8c0b3c: mov             fp, SP
    // 0x8c0b40: AllocStack(0x10)
    //     0x8c0b40: sub             SP, SP, #0x10
    // 0x8c0b44: SetupParameters(dynamic _ /* r1 => r0 */, dynamic _ /* r2 => r1, fp-0x8 */)
    //     0x8c0b44: mov             x0, x1
    //     0x8c0b48: mov             x1, x2
    //     0x8c0b4c: stur            x2, [fp, #-8]
    // 0x8c0b50: CheckStackOverflow
    //     0x8c0b50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c0b54: cmp             SP, x16
    //     0x8c0b58: b.ls            #0x8c0bc0
    // 0x8c0b5c: r0 = instance()
    //     0x8c0b5c: bl              #0x8c0bc8  ; [package:firebase_crashlytics_platform_interface/src/platform_interface/platform_interface_crashlytics.dart] FirebaseCrashlyticsPlatform::instance
    // 0x8c0b60: mov             x3, x0
    // 0x8c0b64: ldur            x1, [fp, #-8]
    // 0x8c0b68: stur            x3, [fp, #-0x10]
    // 0x8c0b6c: r0 = LoadClassIdInstr(r1)
    //     0x8c0b6c: ldur            x0, [x1, #-1]
    //     0x8c0b70: ubfx            x0, x0, #0xc, #0x14
    // 0x8c0b74: r2 = "isCrashlyticsCollectionEnabled"
    //     0x8c0b74: ldr             x2, [PP, #0x7ad0]  ; [pp+0x7ad0] "isCrashlyticsCollectionEnabled"
    // 0x8c0b78: r0 = GDT[cid_x0 + -0xd48]()
    //     0x8c0b78: sub             lr, x0, #0xd48
    //     0x8c0b7c: ldr             lr, [x21, lr, lsl #3]
    //     0x8c0b80: blr             lr
    // 0x8c0b84: r2 = Null
    //     0x8c0b84: mov             x2, NULL
    // 0x8c0b88: r1 = Null
    //     0x8c0b88: mov             x1, NULL
    // 0x8c0b8c: r4 = 60
    //     0x8c0b8c: mov             x4, #0x3c
    // 0x8c0b90: branchIfSmi(r0, 0x8c0b9c)
    //     0x8c0b90: tbz             w0, #0, #0x8c0b9c
    // 0x8c0b94: r4 = LoadClassIdInstr(r0)
    //     0x8c0b94: ldur            x4, [x0, #-1]
    //     0x8c0b98: ubfx            x4, x4, #0xc, #0x14
    // 0x8c0b9c: cmp             x4, #0x3f
    // 0x8c0ba0: b.eq            #0x8c0bb0
    // 0x8c0ba4: r8 = bool
    //     0x8c0ba4: ldr             x8, [PP, #0xb18]  ; [pp+0xb18] Type: bool
    // 0x8c0ba8: r3 = Null
    //     0x8c0ba8: ldr             x3, [PP, #0x7ad8]  ; [pp+0x7ad8] Null
    // 0x8c0bac: r0 = bool()
    //     0x8c0bac: bl              #0x13ee15c  ; IsType_bool_Stub
    // 0x8c0bb0: ldur            x0, [fp, #-0x10]
    // 0x8c0bb4: LeaveFrame
    //     0x8c0bb4: mov             SP, fp
    //     0x8c0bb8: ldp             fp, lr, [SP], #0x10
    // 0x8c0bbc: ret
    //     0x8c0bbc: ret             
    // 0x8c0bc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c0bc0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c0bc4: b               #0x8c0b5c
  }
  get _ instance(/* No info */) {
    // ** addr: 0x8c0bc8, size: 0xa8
    // 0x8c0bc8: EnterFrame
    //     0x8c0bc8: stp             fp, lr, [SP, #-0x10]!
    //     0x8c0bcc: mov             fp, SP
    // 0x8c0bd0: AllocStack(0x10)
    //     0x8c0bd0: sub             SP, SP, #0x10
    // 0x8c0bd4: CheckStackOverflow
    //     0x8c0bd4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c0bd8: cmp             SP, x16
    //     0x8c0bdc: b.ls            #0x8c0c68
    // 0x8c0be0: r0 = LoadStaticField(0x10c8)
    //     0x8c0be0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8c0be4: ldr             x0, [x0, #0x2190]
    // 0x8c0be8: cmp             w0, NULL
    // 0x8c0bec: b.ne            #0x8c0c5c
    // 0x8c0bf0: r0 = app()
    //     0x8c0bf0: bl              #0x8c0c7c  ; [package:firebase_core/firebase_core.dart] Firebase::app
    // 0x8c0bf4: r0 = LoadStaticField(0x10c4)
    //     0x8c0bf4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8c0bf8: ldr             x0, [x0, #0x2188]
    // 0x8c0bfc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8c0c00: cmp             w0, w16
    // 0x8c0c04: b.ne            #0x8c0c10
    // 0x8c0c08: r2 = _token
    //     0x8c0c08: ldr             x2, [PP, #0x7ae8]  ; [pp+0x7ae8] Field <FirebaseCrashlyticsPlatform._token@1284020068>: static late final (offset: 0x10c4)
    // 0x8c0c0c: r0 = InitLateFinalStaticField()
    //     0x8c0c0c: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8c0c10: stur            x0, [fp, #-8]
    // 0x8c0c14: r0 = LoadStaticField(0xde8)
    //     0x8c0c14: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8c0c18: ldr             x0, [x0, #0x1bd0]
    // 0x8c0c1c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8c0c20: cmp             w0, w16
    // 0x8c0c24: b.ne            #0x8c0c30
    // 0x8c0c28: r2 = _instanceTokens
    //     0x8c0c28: ldr             x2, [PP, #0x68c0]  ; [pp+0x68c0] Field <PlatformInterface._instanceTokens@1171304592>: static late final (offset: 0xde8)
    // 0x8c0c2c: r0 = InitLateFinalStaticField()
    //     0x8c0c2c: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8c0c30: stur            x0, [fp, #-0x10]
    // 0x8c0c34: r0 = MethodChannelFirebaseCrashlytics()
    //     0x8c0c34: bl              #0x8c0c70  ; AllocateMethodChannelFirebaseCrashlyticsStub -> MethodChannelFirebaseCrashlytics (size=0x8)
    // 0x8c0c38: ldur            x1, [fp, #-0x10]
    // 0x8c0c3c: mov             x2, x0
    // 0x8c0c40: ldur            x3, [fp, #-8]
    // 0x8c0c44: stur            x0, [fp, #-8]
    // 0x8c0c48: r0 = []=()
    //     0x8c0c48: bl              #0x7f6290  ; [dart:core] Expando::[]=
    // 0x8c0c4c: ldur            x2, [fp, #-8]
    // 0x8c0c50: StoreStaticField(0x10c8, r2)
    //     0x8c0c50: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x8c0c54: str             x2, [x1, #0x2190]
    // 0x8c0c58: ldur            x0, [fp, #-8]
    // 0x8c0c5c: LeaveFrame
    //     0x8c0c5c: mov             SP, fp
    //     0x8c0c60: ldp             fp, lr, [SP], #0x10
    // 0x8c0c64: ret
    //     0x8c0c64: ret             
    // 0x8c0c68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c0c68: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c0c6c: b               #0x8c0be0
  }
}
