// lib: , url: package:firebase_crashlytics_platform_interface/src/method_channel/method_channel_crashlytics.dart

// class id: 1048749, size: 0x8
class :: {
}

// class id: 3700, size: 0x8, field offset: 0x8
class MethodChannelFirebaseCrashlytics extends FirebaseCrashlyticsPlatform {

  static late MethodChannel channel; // offset: 0x10c0

  _ log(/* No info */) async {
    // ** addr: 0x8c0668, size: 0xe8
    // 0x8c0668: EnterFrame
    //     0x8c0668: stp             fp, lr, [SP, #-0x10]!
    //     0x8c066c: mov             fp, SP
    // 0x8c0670: AllocStack(0x90)
    //     0x8c0670: sub             SP, SP, #0x90
    // 0x8c0674: SetupParameters(MethodChannelFirebaseCrashlytics this /* r1 => r1, fp-0x68 */, dynamic _ /* r2 => r2, fp-0x70 */)
    //     0x8c0674: stur            NULL, [fp, #-8]
    //     0x8c0678: stur            x1, [fp, #-0x68]
    //     0x8c067c: stur            x2, [fp, #-0x70]
    // 0x8c0680: CheckStackOverflow
    //     0x8c0680: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c0684: cmp             SP, x16
    //     0x8c0688: b.ls            #0x8c0748
    // 0x8c068c: InitAsync() -> Future<void?>
    //     0x8c068c: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0x8c0690: bl              #0x7f5e44  ; InitAsyncStub
    // 0x8c0694: ldur            x0, [fp, #-0x70]
    // 0x8c0698: r0 = LoadStaticField(0x10c0)
    //     0x8c0698: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8c069c: ldr             x0, [x0, #0x2180]
    // 0x8c06a0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8c06a4: cmp             w0, w16
    // 0x8c06a8: b.ne            #0x8c06b4
    // 0x8c06ac: r2 = channel
    //     0x8c06ac: ldr             x2, [PP, #0x7a48]  ; [pp+0x7a48] Field <MethodChannelFirebaseCrashlytics.channel>: static late (offset: 0x10c0)
    // 0x8c06b0: r0 = InitLateStaticField()
    //     0x8c06b0: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0x8c06b4: r1 = Null
    //     0x8c06b4: mov             x1, NULL
    // 0x8c06b8: r2 = 4
    //     0x8c06b8: mov             x2, #4
    // 0x8c06bc: r0 = AllocateArray()
    //     0x8c06bc: bl              #0x13df928  ; AllocateArrayStub
    // 0x8c06c0: r16 = "message"
    //     0x8c06c0: ldr             x16, [PP, #0x62a0]  ; [pp+0x62a0] "message"
    // 0x8c06c4: StoreField: r0->field_f = r16
    //     0x8c06c4: stur            w16, [x0, #0xf]
    // 0x8c06c8: ldur            x1, [fp, #-0x70]
    // 0x8c06cc: StoreField: r0->field_13 = r1
    //     0x8c06cc: stur            w1, [x0, #0x13]
    // 0x8c06d0: r16 = <String, dynamic>
    //     0x8c06d0: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x8c06d4: stp             x0, x16, [SP]
    // 0x8c06d8: r0 = Map._fromLiteral()
    //     0x8c06d8: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x8c06dc: r16 = <void?>
    //     0x8c06dc: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x8c06e0: r30 = Instance_MethodChannel
    //     0x8c06e0: ldr             lr, [PP, #0x7a70]  ; [pp+0x7a70] Obj!MethodChannel@129bb01
    // 0x8c06e4: stp             lr, x16, [SP, #0x10]
    // 0x8c06e8: r16 = "Crashlytics#log"
    //     0x8c06e8: ldr             x16, [PP, #0x7ca0]  ; [pp+0x7ca0] "Crashlytics#log"
    // 0x8c06ec: stp             x0, x16, [SP]
    // 0x8c06f0: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x8c06f0: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x8c06f4: r0 = invokeMethod()
    //     0x8c06f4: bl              #0x130b008  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0x8c06f8: mov             x1, x0
    // 0x8c06fc: stur            x1, [fp, #-0x68]
    // 0x8c0700: r0 = Await()
    //     0x8c0700: bl              #0x7f5c00  ; AwaitStub
    // 0x8c0704: r0 = Null
    //     0x8c0704: mov             x0, NULL
    // 0x8c0708: r0 = ReturnAsyncNotFuture()
    //     0x8c0708: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x8c070c: sub             SP, fp, #0x90
    // 0x8c0710: mov             x2, x1
    // 0x8c0714: mov             x1, x0
    // 0x8c0718: r0 = 60
    //     0x8c0718: mov             x0, #0x3c
    // 0x8c071c: branchIfSmi(r1, 0x8c0728)
    //     0x8c071c: tbz             w1, #0, #0x8c0728
    // 0x8c0720: r0 = LoadClassIdInstr(r1)
    //     0x8c0720: ldur            x0, [x1, #-1]
    //     0x8c0724: ubfx            x0, x0, #0xc, #0x14
    // 0x8c0728: cmp             x0, #0xae4
    // 0x8c072c: b.ne            #0x8c0738
    // 0x8c0730: r0 = convertPlatformException()
    //     0x8c0730: bl              #0x8c0750  ; [package:firebase_crashlytics_platform_interface/src/method_channel/utils/exception.dart] ::convertPlatformException
    // 0x8c0734: brk             #0
    // 0x8c0738: mov             x0, x1
    // 0x8c073c: mov             x1, x2
    // 0x8c0740: r0 = ReThrow()
    //     0x8c0740: bl              #0x13ddb00  ; ReThrowStub
    // 0x8c0744: brk             #0
    // 0x8c0748: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c0748: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c074c: b               #0x8c068c
  }
  static MethodChannel channel() {
    // ** addr: 0x8c0aa8, size: 0x8
    // 0x8c0aa8: r0 = Instance_MethodChannel
    //     0x8c0aa8: ldr             x0, [PP, #0x7a70]  ; [pp+0x7a70] Obj!MethodChannel@129bb01
    // 0x8c0aac: ret
    //     0x8c0aac: ret             
  }
  _ recordError(/* No info */) async {
    // ** addr: 0x8e5cc0, size: 0x198
    // 0x8e5cc0: EnterFrame
    //     0x8e5cc0: stp             fp, lr, [SP, #-0x10]!
    //     0x8e5cc4: mov             fp, SP
    // 0x8e5cc8: AllocStack(0xf0)
    //     0x8e5cc8: sub             SP, SP, #0xf0
    // 0x8e5ccc: SetupParameters(MethodChannelFirebaseCrashlytics this /* r2 => r2, fp-0xb0 */, dynamic _ /* r3 => r3, fp-0xb8 */, dynamic _ /* r5 => r5, fp-0xc0 */, dynamic _ /* r6 => r6, fp-0xc8 */, dynamic _ /* r7 => r7, fp-0xd0 */, dynamic _ /* r1, fp-0xa8 */, dynamic _ /* r4, fp-0xa0 */)
    //     0x8e5ccc: stur            NULL, [fp, #-8]
    //     0x8e5cd0: mov             x0, #0
    //     0x8e5cd4: stur            x2, [fp, #-0xb0]
    //     0x8e5cd8: stur            x3, [fp, #-0xb8]
    //     0x8e5cdc: stur            x5, [fp, #-0xc0]
    //     0x8e5ce0: stur            x6, [fp, #-0xc8]
    //     0x8e5ce4: stur            x7, [fp, #-0xd0]
    //     0x8e5ce8: add             x1, fp, w0, sxtw #2
    //     0x8e5cec: ldr             x1, [x1, #0x18]
    //     0x8e5cf0: stur            x1, [fp, #-0xa8]
    //     0x8e5cf4: add             x4, fp, w0, sxtw #2
    //     0x8e5cf8: ldr             x4, [x4, #0x10]
    //     0x8e5cfc: stur            x4, [fp, #-0xa0]
    // 0x8e5d00: CheckStackOverflow
    //     0x8e5d00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8e5d04: cmp             SP, x16
    //     0x8e5d08: b.ls            #0x8e5e50
    // 0x8e5d0c: InitAsync() -> Future<void?>
    //     0x8e5d0c: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0x8e5d10: bl              #0x7f5e44  ; InitAsyncStub
    // 0x8e5d14: ldur            x3, [fp, #-0xb0]
    // 0x8e5d18: ldur            x2, [fp, #-0xb8]
    // 0x8e5d1c: ldur            x1, [fp, #-0xc0]
    // 0x8e5d20: ldur            x0, [fp, #-0xc8]
    // 0x8e5d24: ldur            x4, [fp, #-0xa8]
    // 0x8e5d28: r0 = LoadStaticField(0x10c0)
    //     0x8e5d28: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8e5d2c: ldr             x0, [x0, #0x2180]
    // 0x8e5d30: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8e5d34: cmp             w0, w16
    // 0x8e5d38: b.ne            #0x8e5d44
    // 0x8e5d3c: r2 = channel
    //     0x8e5d3c: ldr             x2, [PP, #0x7a48]  ; [pp+0x7a48] Field <MethodChannelFirebaseCrashlytics.channel>: static late (offset: 0x10c0)
    // 0x8e5d40: r0 = InitLateStaticField()
    //     0x8e5d40: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0x8e5d44: r1 = Null
    //     0x8e5d44: mov             x1, NULL
    // 0x8e5d48: r2 = 28
    //     0x8e5d48: mov             x2, #0x1c
    // 0x8e5d4c: r0 = AllocateArray()
    //     0x8e5d4c: bl              #0x13df928  ; AllocateArrayStub
    // 0x8e5d50: r16 = "exception"
    //     0x8e5d50: ldr             x16, [PP, #0x7a50]  ; [pp+0x7a50] "exception"
    // 0x8e5d54: StoreField: r0->field_f = r16
    //     0x8e5d54: stur            w16, [x0, #0xf]
    // 0x8e5d58: ldur            x1, [fp, #-0xb8]
    // 0x8e5d5c: StoreField: r0->field_13 = r1
    //     0x8e5d5c: stur            w1, [x0, #0x13]
    // 0x8e5d60: r16 = "information"
    //     0x8e5d60: ldr             x16, [PP, #0x7a28]  ; [pp+0x7a28] "information"
    // 0x8e5d64: ArrayStore: r0[0] = r16  ; List_4
    //     0x8e5d64: stur            w16, [x0, #0x17]
    // 0x8e5d68: ldur            x1, [fp, #-0xc8]
    // 0x8e5d6c: StoreField: r0->field_1b = r1
    //     0x8e5d6c: stur            w1, [x0, #0x1b]
    // 0x8e5d70: r16 = "reason"
    //     0x8e5d70: ldr             x16, [PP, #0x7a40]  ; [pp+0x7a40] "reason"
    // 0x8e5d74: StoreField: r0->field_1f = r16
    //     0x8e5d74: stur            w16, [x0, #0x1f]
    // 0x8e5d78: ldur            x1, [fp, #-0xa8]
    // 0x8e5d7c: StoreField: r0->field_23 = r1
    //     0x8e5d7c: stur            w1, [x0, #0x23]
    // 0x8e5d80: r16 = "fatal"
    //     0x8e5d80: ldr             x16, [PP, #0x7a20]  ; [pp+0x7a20] "fatal"
    // 0x8e5d84: StoreField: r0->field_27 = r16
    //     0x8e5d84: stur            w16, [x0, #0x27]
    // 0x8e5d88: ldur            x1, [fp, #-0xc0]
    // 0x8e5d8c: StoreField: r0->field_2b = r1
    //     0x8e5d8c: stur            w1, [x0, #0x2b]
    // 0x8e5d90: r16 = "buildId"
    //     0x8e5d90: ldr             x16, [PP, #0x7a58]  ; [pp+0x7a58] "buildId"
    // 0x8e5d94: StoreField: r0->field_2f = r16
    //     0x8e5d94: stur            w16, [x0, #0x2f]
    // 0x8e5d98: ldur            x1, [fp, #-0xb0]
    // 0x8e5d9c: cmp             w1, NULL
    // 0x8e5da0: b.ne            #0x8e5dac
    // 0x8e5da4: r3 = ""
    //     0x8e5da4: ldr             x3, [PP, #0x900]  ; [pp+0x900] ""
    // 0x8e5da8: b               #0x8e5db0
    // 0x8e5dac: mov             x3, x1
    // 0x8e5db0: ldur            x1, [fp, #-0xd0]
    // 0x8e5db4: ldur            x2, [fp, #-0xa0]
    // 0x8e5db8: stur            x3, [fp, #-0xa8]
    // 0x8e5dbc: StoreField: r0->field_33 = r3
    //     0x8e5dbc: stur            w3, [x0, #0x33]
    // 0x8e5dc0: r16 = "loadingUnits"
    //     0x8e5dc0: ldr             x16, [PP, #0x7a60]  ; [pp+0x7a60] "loadingUnits"
    // 0x8e5dc4: StoreField: r0->field_37 = r16
    //     0x8e5dc4: stur            w16, [x0, #0x37]
    // 0x8e5dc8: StoreField: r0->field_3b = r1
    //     0x8e5dc8: stur            w1, [x0, #0x3b]
    // 0x8e5dcc: r16 = "stackTraceElements"
    //     0x8e5dcc: ldr             x16, [PP, #0x7a68]  ; [pp+0x7a68] "stackTraceElements"
    // 0x8e5dd0: StoreField: r0->field_3f = r16
    //     0x8e5dd0: stur            w16, [x0, #0x3f]
    // 0x8e5dd4: StoreField: r0->field_43 = r2
    //     0x8e5dd4: stur            w2, [x0, #0x43]
    // 0x8e5dd8: r16 = <String, dynamic>
    //     0x8e5dd8: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x8e5ddc: stp             x0, x16, [SP]
    // 0x8e5de0: r0 = Map._fromLiteral()
    //     0x8e5de0: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x8e5de4: r16 = <void?>
    //     0x8e5de4: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x8e5de8: r30 = Instance_MethodChannel
    //     0x8e5de8: ldr             lr, [PP, #0x7a70]  ; [pp+0x7a70] Obj!MethodChannel@129bb01
    // 0x8e5dec: stp             lr, x16, [SP, #0x10]
    // 0x8e5df0: r16 = "Crashlytics#recordError"
    //     0x8e5df0: ldr             x16, [PP, #0x7a78]  ; [pp+0x7a78] "Crashlytics#recordError"
    // 0x8e5df4: stp             x0, x16, [SP]
    // 0x8e5df8: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x8e5df8: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x8e5dfc: r0 = invokeMethod()
    //     0x8e5dfc: bl              #0x130b008  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0x8e5e00: mov             x1, x0
    // 0x8e5e04: stur            x1, [fp, #-0xb0]
    // 0x8e5e08: r0 = Await()
    //     0x8e5e08: bl              #0x7f5c00  ; AwaitStub
    // 0x8e5e0c: r0 = Null
    //     0x8e5e0c: mov             x0, NULL
    // 0x8e5e10: r0 = ReturnAsyncNotFuture()
    //     0x8e5e10: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x8e5e14: sub             SP, fp, #0xf0
    // 0x8e5e18: mov             x2, x1
    // 0x8e5e1c: mov             x1, x0
    // 0x8e5e20: r0 = 60
    //     0x8e5e20: mov             x0, #0x3c
    // 0x8e5e24: branchIfSmi(r1, 0x8e5e30)
    //     0x8e5e24: tbz             w1, #0, #0x8e5e30
    // 0x8e5e28: r0 = LoadClassIdInstr(r1)
    //     0x8e5e28: ldur            x0, [x1, #-1]
    //     0x8e5e2c: ubfx            x0, x0, #0xc, #0x14
    // 0x8e5e30: cmp             x0, #0xae4
    // 0x8e5e34: b.ne            #0x8e5e40
    // 0x8e5e38: r0 = convertPlatformException()
    //     0x8e5e38: bl              #0x8c0750  ; [package:firebase_crashlytics_platform_interface/src/method_channel/utils/exception.dart] ::convertPlatformException
    // 0x8e5e3c: brk             #0
    // 0x8e5e40: mov             x0, x1
    // 0x8e5e44: mov             x1, x2
    // 0x8e5e48: r0 = ReThrow()
    //     0x8e5e48: bl              #0x13ddb00  ; ReThrowStub
    // 0x8e5e4c: brk             #0
    // 0x8e5e50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8e5e50: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8e5e54: b               #0x8e5d0c
  }
  _ setCustomKey(/* No info */) async {
    // ** addr: 0x8e8680, size: 0x100
    // 0x8e8680: EnterFrame
    //     0x8e8680: stp             fp, lr, [SP, #-0x10]!
    //     0x8e8684: mov             fp, SP
    // 0x8e8688: AllocStack(0xa0)
    //     0x8e8688: sub             SP, SP, #0xa0
    // 0x8e868c: SetupParameters(MethodChannelFirebaseCrashlytics this /* r1 => r1, fp-0x70 */, dynamic _ /* r2 => r2, fp-0x78 */, dynamic _ /* r3 => r3, fp-0x80 */)
    //     0x8e868c: stur            NULL, [fp, #-8]
    //     0x8e8690: stur            x1, [fp, #-0x70]
    //     0x8e8694: stur            x2, [fp, #-0x78]
    //     0x8e8698: stur            x3, [fp, #-0x80]
    // 0x8e869c: CheckStackOverflow
    //     0x8e869c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8e86a0: cmp             SP, x16
    //     0x8e86a4: b.ls            #0x8e8778
    // 0x8e86a8: InitAsync() -> Future<void?>
    //     0x8e86a8: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0x8e86ac: bl              #0x7f5e44  ; InitAsyncStub
    // 0x8e86b0: ldur            x1, [fp, #-0x78]
    // 0x8e86b4: ldur            x0, [fp, #-0x80]
    // 0x8e86b8: r0 = LoadStaticField(0x10c0)
    //     0x8e86b8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8e86bc: ldr             x0, [x0, #0x2180]
    // 0x8e86c0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8e86c4: cmp             w0, w16
    // 0x8e86c8: b.ne            #0x8e86d4
    // 0x8e86cc: r2 = channel
    //     0x8e86cc: ldr             x2, [PP, #0x7a48]  ; [pp+0x7a48] Field <MethodChannelFirebaseCrashlytics.channel>: static late (offset: 0x10c0)
    // 0x8e86d0: r0 = InitLateStaticField()
    //     0x8e86d0: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0x8e86d4: r1 = Null
    //     0x8e86d4: mov             x1, NULL
    // 0x8e86d8: r2 = 8
    //     0x8e86d8: mov             x2, #8
    // 0x8e86dc: r0 = AllocateArray()
    //     0x8e86dc: bl              #0x13df928  ; AllocateArrayStub
    // 0x8e86e0: r16 = "key"
    //     0x8e86e0: ldr             x16, [PP, #0xf18]  ; [pp+0xf18] "key"
    // 0x8e86e4: StoreField: r0->field_f = r16
    //     0x8e86e4: stur            w16, [x0, #0xf]
    // 0x8e86e8: ldur            x1, [fp, #-0x78]
    // 0x8e86ec: StoreField: r0->field_13 = r1
    //     0x8e86ec: stur            w1, [x0, #0x13]
    // 0x8e86f0: r16 = "value"
    //     0x8e86f0: ldr             x16, [PP, #0x50c8]  ; [pp+0x50c8] "value"
    // 0x8e86f4: ArrayStore: r0[0] = r16  ; List_4
    //     0x8e86f4: stur            w16, [x0, #0x17]
    // 0x8e86f8: ldur            x2, [fp, #-0x80]
    // 0x8e86fc: StoreField: r0->field_1b = r2
    //     0x8e86fc: stur            w2, [x0, #0x1b]
    // 0x8e8700: r16 = <String, dynamic>
    //     0x8e8700: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x8e8704: stp             x0, x16, [SP]
    // 0x8e8708: r0 = Map._fromLiteral()
    //     0x8e8708: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x8e870c: r16 = <void?>
    //     0x8e870c: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x8e8710: r30 = Instance_MethodChannel
    //     0x8e8710: ldr             lr, [PP, #0x7a70]  ; [pp+0x7a70] Obj!MethodChannel@129bb01
    // 0x8e8714: stp             lr, x16, [SP, #0x10]
    // 0x8e8718: r16 = "Crashlytics#setCustomKey"
    //     0x8e8718: ldr             x16, [PP, #0x7ca8]  ; [pp+0x7ca8] "Crashlytics#setCustomKey"
    // 0x8e871c: stp             x0, x16, [SP]
    // 0x8e8720: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x8e8720: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x8e8724: r0 = invokeMethod()
    //     0x8e8724: bl              #0x130b008  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0x8e8728: mov             x1, x0
    // 0x8e872c: stur            x1, [fp, #-0x70]
    // 0x8e8730: r0 = Await()
    //     0x8e8730: bl              #0x7f5c00  ; AwaitStub
    // 0x8e8734: r0 = Null
    //     0x8e8734: mov             x0, NULL
    // 0x8e8738: r0 = ReturnAsyncNotFuture()
    //     0x8e8738: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x8e873c: sub             SP, fp, #0xa0
    // 0x8e8740: mov             x2, x1
    // 0x8e8744: mov             x1, x0
    // 0x8e8748: r0 = 60
    //     0x8e8748: mov             x0, #0x3c
    // 0x8e874c: branchIfSmi(r1, 0x8e8758)
    //     0x8e874c: tbz             w1, #0, #0x8e8758
    // 0x8e8750: r0 = LoadClassIdInstr(r1)
    //     0x8e8750: ldur            x0, [x1, #-1]
    //     0x8e8754: ubfx            x0, x0, #0xc, #0x14
    // 0x8e8758: cmp             x0, #0xae4
    // 0x8e875c: b.ne            #0x8e8768
    // 0x8e8760: r0 = convertPlatformException()
    //     0x8e8760: bl              #0x8c0750  ; [package:firebase_crashlytics_platform_interface/src/method_channel/utils/exception.dart] ::convertPlatformException
    // 0x8e8764: brk             #0
    // 0x8e8768: mov             x0, x1
    // 0x8e876c: mov             x1, x2
    // 0x8e8770: r0 = ReThrow()
    //     0x8e8770: bl              #0x13ddb00  ; ReThrowStub
    // 0x8e8774: brk             #0
    // 0x8e8778: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8e8778: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8e877c: b               #0x8e86a8
  }
  _ setUserIdentifier(/* No info */) async {
    // ** addr: 0x13e66ac, size: 0xec
    // 0x13e66ac: EnterFrame
    //     0x13e66ac: stp             fp, lr, [SP, #-0x10]!
    //     0x13e66b0: mov             fp, SP
    // 0x13e66b4: AllocStack(0x90)
    //     0x13e66b4: sub             SP, SP, #0x90
    // 0x13e66b8: SetupParameters(MethodChannelFirebaseCrashlytics this /* r1 => r1, fp-0x68 */, dynamic _ /* r2 => r2, fp-0x70 */)
    //     0x13e66b8: stur            NULL, [fp, #-8]
    //     0x13e66bc: stur            x1, [fp, #-0x68]
    //     0x13e66c0: stur            x2, [fp, #-0x70]
    // 0x13e66c4: CheckStackOverflow
    //     0x13e66c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13e66c8: cmp             SP, x16
    //     0x13e66cc: b.ls            #0x13e6790
    // 0x13e66d0: InitAsync() -> Future<void?>
    //     0x13e66d0: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0x13e66d4: bl              #0x7f5e44  ; InitAsyncStub
    // 0x13e66d8: ldur            x0, [fp, #-0x70]
    // 0x13e66dc: r0 = LoadStaticField(0x10c0)
    //     0x13e66dc: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x13e66e0: ldr             x0, [x0, #0x2180]
    // 0x13e66e4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x13e66e8: cmp             w0, w16
    // 0x13e66ec: b.ne            #0x13e66f8
    // 0x13e66f0: r2 = channel
    //     0x13e66f0: ldr             x2, [PP, #0x7a48]  ; [pp+0x7a48] Field <MethodChannelFirebaseCrashlytics.channel>: static late (offset: 0x10c0)
    // 0x13e66f4: r0 = InitLateStaticField()
    //     0x13e66f4: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0x13e66f8: r1 = Null
    //     0x13e66f8: mov             x1, NULL
    // 0x13e66fc: r2 = 4
    //     0x13e66fc: mov             x2, #4
    // 0x13e6700: r0 = AllocateArray()
    //     0x13e6700: bl              #0x13df928  ; AllocateArrayStub
    // 0x13e6704: r16 = "identifier"
    //     0x13e6704: ldr             x16, [PP, #0x5420]  ; [pp+0x5420] "identifier"
    // 0x13e6708: StoreField: r0->field_f = r16
    //     0x13e6708: stur            w16, [x0, #0xf]
    // 0x13e670c: ldur            x1, [fp, #-0x70]
    // 0x13e6710: StoreField: r0->field_13 = r1
    //     0x13e6710: stur            w1, [x0, #0x13]
    // 0x13e6714: r16 = <String, dynamic>
    //     0x13e6714: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x13e6718: stp             x0, x16, [SP]
    // 0x13e671c: r0 = Map._fromLiteral()
    //     0x13e671c: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x13e6720: r16 = <void?>
    //     0x13e6720: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x13e6724: r30 = Instance_MethodChannel
    //     0x13e6724: ldr             lr, [PP, #0x7a70]  ; [pp+0x7a70] Obj!MethodChannel@129bb01
    // 0x13e6728: stp             lr, x16, [SP, #0x10]
    // 0x13e672c: r16 = "Crashlytics#setUserIdentifier"
    //     0x13e672c: add             x16, PP, #8, lsl #12  ; [pp+0x8050] "Crashlytics#setUserIdentifier"
    //     0x13e6730: ldr             x16, [x16, #0x50]
    // 0x13e6734: stp             x0, x16, [SP]
    // 0x13e6738: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x13e6738: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x13e673c: r0 = invokeMethod()
    //     0x13e673c: bl              #0x130b008  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0x13e6740: mov             x1, x0
    // 0x13e6744: stur            x1, [fp, #-0x68]
    // 0x13e6748: r0 = Await()
    //     0x13e6748: bl              #0x7f5c00  ; AwaitStub
    // 0x13e674c: r0 = Null
    //     0x13e674c: mov             x0, NULL
    // 0x13e6750: r0 = ReturnAsyncNotFuture()
    //     0x13e6750: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x13e6754: sub             SP, fp, #0x90
    // 0x13e6758: mov             x2, x1
    // 0x13e675c: mov             x1, x0
    // 0x13e6760: r0 = 60
    //     0x13e6760: mov             x0, #0x3c
    // 0x13e6764: branchIfSmi(r1, 0x13e6770)
    //     0x13e6764: tbz             w1, #0, #0x13e6770
    // 0x13e6768: r0 = LoadClassIdInstr(r1)
    //     0x13e6768: ldur            x0, [x1, #-1]
    //     0x13e676c: ubfx            x0, x0, #0xc, #0x14
    // 0x13e6770: cmp             x0, #0xae4
    // 0x13e6774: b.ne            #0x13e6780
    // 0x13e6778: r0 = convertPlatformException()
    //     0x13e6778: bl              #0x8c0750  ; [package:firebase_crashlytics_platform_interface/src/method_channel/utils/exception.dart] ::convertPlatformException
    // 0x13e677c: brk             #0
    // 0x13e6780: mov             x0, x1
    // 0x13e6784: mov             x1, x2
    // 0x13e6788: r0 = ReThrow()
    //     0x13e6788: bl              #0x13ddb00  ; ReThrowStub
    // 0x13e678c: brk             #0
    // 0x13e6790: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13e6790: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13e6794: b               #0x13e66d0
  }
}
