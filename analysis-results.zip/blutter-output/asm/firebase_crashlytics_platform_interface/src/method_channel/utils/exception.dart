// lib: , url: package:firebase_crashlytics_platform_interface/src/method_channel/utils/exception.dart

// class id: 1048750, size: 0x8
class :: {

  static Never convertPlatformException(Object, StackTrace) {
    // ** addr: 0x8c0750, size: 0x28
    // 0x8c0750: EnterFrame
    //     0x8c0750: stp             fp, lr, [SP, #-0x10]!
    //     0x8c0754: mov             fp, SP
    // 0x8c0758: CheckStackOverflow
    //     0x8c0758: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c075c: cmp             SP, x16
    //     0x8c0760: b.ls            #0x8c0770
    // 0x8c0764: r3 = "firebase_crashlytics"
    //     0x8c0764: ldr             x3, [PP, #0x7a80]  ; [pp+0x7a80] "firebase_crashlytics"
    // 0x8c0768: r0 = convertPlatformExceptionToFirebaseException()
    //     0x8c0768: bl              #0x8c0778  ; [package:_flutterfire_internals/src/exception.dart] ::convertPlatformExceptionToFirebaseException
    // 0x8c076c: brk             #0
    // 0x8c0770: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c0770: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c0774: b               #0x8c0764
  }
}
