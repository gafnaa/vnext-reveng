// lib: , url: package:firebase_messaging/firebase_messaging.dart

// class id: 1048752, size: 0x8
class :: {
}

// class id: 3369, size: 0x18, field offset: 0x10
class FirebaseMessaging extends FirebasePlugin {

  static late Map<String, FirebaseMessaging> _firebaseMessagingInstances; // offset: 0x10dc

  _ getToken(/* No info */) {
    // ** addr: 0x922c5c, size: 0x34
    // 0x922c5c: EnterFrame
    //     0x922c5c: stp             fp, lr, [SP, #-0x10]!
    //     0x922c60: mov             fp, SP
    // 0x922c64: CheckStackOverflow
    //     0x922c64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x922c68: cmp             SP, x16
    //     0x922c6c: b.ls            #0x922c88
    // 0x922c70: r0 = _delegate()
    //     0x922c70: bl              #0x924bd8  ; [package:firebase_messaging/firebase_messaging.dart] FirebaseMessaging::_delegate
    // 0x922c74: mov             x1, x0
    // 0x922c78: r0 = getToken()
    //     0x922c78: bl              #0x922c90  ; [package:firebase_messaging_platform_interface/src/method_channel/method_channel_messaging.dart] MethodChannelFirebaseMessaging::getToken
    // 0x922c7c: LeaveFrame
    //     0x922c7c: mov             SP, fp
    //     0x922c80: ldp             fp, lr, [SP], #0x10
    // 0x922c84: ret
    //     0x922c84: ret             
    // 0x922c88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x922c88: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x922c8c: b               #0x922c70
  }
  get _ _delegate(/* No info */) {
    // ** addr: 0x924bd8, size: 0x98
    // 0x924bd8: EnterFrame
    //     0x924bd8: stp             fp, lr, [SP, #-0x10]!
    //     0x924bdc: mov             fp, SP
    // 0x924be0: AllocStack(0x10)
    //     0x924be0: sub             SP, SP, #0x10
    // 0x924be4: SetupParameters(FirebaseMessaging this /* r1 => r0, fp-0x10 */)
    //     0x924be4: mov             x0, x1
    //     0x924be8: stur            x1, [fp, #-0x10]
    // 0x924bec: CheckStackOverflow
    //     0x924bec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x924bf0: cmp             SP, x16
    //     0x924bf4: b.ls            #0x924c68
    // 0x924bf8: LoadField: r1 = r0->field_f
    //     0x924bf8: ldur            w1, [x0, #0xf]
    // 0x924bfc: DecompressPointer r1
    //     0x924bfc: add             x1, x1, HEAP, lsl #32
    // 0x924c00: cmp             w1, NULL
    // 0x924c04: b.ne            #0x924c58
    // 0x924c08: LoadField: r2 = r0->field_13
    //     0x924c08: ldur            w2, [x0, #0x13]
    // 0x924c0c: DecompressPointer r2
    //     0x924c0c: add             x2, x2, HEAP, lsl #32
    // 0x924c10: mov             x1, x0
    // 0x924c14: stur            x2, [fp, #-8]
    // 0x924c18: r0 = pluginConstants()
    //     0x924c18: bl              #0x8c12e8  ; [package:firebase_core_platform_interface/firebase_core_platform_interface.dart] FirebasePlugin::pluginConstants
    // 0x924c1c: ldur            x2, [fp, #-8]
    // 0x924c20: mov             x3, x0
    // 0x924c24: r1 = Null
    //     0x924c24: mov             x1, NULL
    // 0x924c28: r0 = FirebaseMessagingPlatform.instanceFor()
    //     0x924c28: bl              #0x924c70  ; [package:firebase_messaging_platform_interface/src/platform_interface/platform_interface_messaging.dart] FirebaseMessagingPlatform::FirebaseMessagingPlatform.instanceFor
    // 0x924c2c: mov             x1, x0
    // 0x924c30: ldur            x2, [fp, #-0x10]
    // 0x924c34: StoreField: r2->field_f = r0
    //     0x924c34: stur            w0, [x2, #0xf]
    //     0x924c38: ldurb           w16, [x2, #-1]
    //     0x924c3c: ldurb           w17, [x0, #-1]
    //     0x924c40: and             x16, x17, x16, lsr #2
    //     0x924c44: tst             x16, HEAP, lsr #32
    //     0x924c48: b.eq            #0x924c50
    //     0x924c4c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x924c50: mov             x0, x1
    // 0x924c54: b               #0x924c5c
    // 0x924c58: mov             x0, x1
    // 0x924c5c: LeaveFrame
    //     0x924c5c: mov             SP, fp
    //     0x924c60: ldp             fp, lr, [SP], #0x10
    // 0x924c64: ret
    //     0x924c64: ret             
    // 0x924c68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x924c68: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x924c6c: b               #0x924bf8
  }
  factory _ FirebaseMessaging._instanceFor(/* No info */) {
    // ** addr: 0x9253c4, size: 0xa8
    // 0x9253c4: EnterFrame
    //     0x9253c4: stp             fp, lr, [SP, #-0x10]!
    //     0x9253c8: mov             fp, SP
    // 0x9253cc: AllocStack(0x18)
    //     0x9253cc: sub             SP, SP, #0x18
    // 0x9253d0: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x9253d0: stur            x2, [fp, #-8]
    // 0x9253d4: CheckStackOverflow
    //     0x9253d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9253d8: cmp             SP, x16
    //     0x9253dc: b.ls            #0x925464
    // 0x9253e0: r1 = 1
    //     0x9253e0: mov             x1, #1
    // 0x9253e4: r0 = AllocateContext()
    //     0x9253e4: bl              #0x13de838  ; AllocateContextStub
    // 0x9253e8: mov             x1, x0
    // 0x9253ec: ldur            x0, [fp, #-8]
    // 0x9253f0: stur            x1, [fp, #-0x10]
    // 0x9253f4: StoreField: r1->field_f = r0
    //     0x9253f4: stur            w0, [x1, #0xf]
    // 0x9253f8: r0 = LoadStaticField(0x10dc)
    //     0x9253f8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x9253fc: ldr             x0, [x0, #0x21b8]
    // 0x925400: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x925404: cmp             w0, w16
    // 0x925408: b.ne            #0x925418
    // 0x92540c: r2 = _firebaseMessagingInstances
    //     0x92540c: add             x2, PP, #8, lsl #12  ; [pp+0x8c68] Field <FirebaseMessaging._firebaseMessagingInstances@1290057947>: static late (offset: 0x10dc)
    //     0x925410: ldr             x2, [x2, #0xc68]
    // 0x925414: r0 = InitLateStaticField()
    //     0x925414: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0x925418: ldur            x2, [fp, #-0x10]
    // 0x92541c: stur            x0, [fp, #-0x18]
    // 0x925420: LoadField: r1 = r2->field_f
    //     0x925420: ldur            w1, [x2, #0xf]
    // 0x925424: DecompressPointer r1
    //     0x925424: add             x1, x1, HEAP, lsl #32
    // 0x925428: LoadField: r3 = r1->field_7
    //     0x925428: ldur            w3, [x1, #7]
    // 0x92542c: DecompressPointer r3
    //     0x92542c: add             x3, x3, HEAP, lsl #32
    // 0x925430: LoadField: r4 = r3->field_7
    //     0x925430: ldur            w4, [x3, #7]
    // 0x925434: DecompressPointer r4
    //     0x925434: add             x4, x4, HEAP, lsl #32
    // 0x925438: stur            x4, [fp, #-8]
    // 0x92543c: r1 = Function '<anonymous closure>': static.
    //     0x92543c: add             x1, PP, #8, lsl #12  ; [pp+0x8c70] AnonymousClosure: static (0x92546c), in [package:firebase_messaging/firebase_messaging.dart] FirebaseMessaging::FirebaseMessaging._instanceFor (0x9253c4)
    //     0x925440: ldr             x1, [x1, #0xc70]
    // 0x925444: r0 = AllocateClosure()
    //     0x925444: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x925448: ldur            x1, [fp, #-0x18]
    // 0x92544c: ldur            x2, [fp, #-8]
    // 0x925450: mov             x3, x0
    // 0x925454: r0 = putIfAbsent()
    //     0x925454: bl              #0xa1be20  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::putIfAbsent
    // 0x925458: LeaveFrame
    //     0x925458: mov             SP, fp
    //     0x92545c: ldp             fp, lr, [SP], #0x10
    // 0x925460: ret
    //     0x925460: ret             
    // 0x925464: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x925464: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x925468: b               #0x9253e0
  }
  [closure] static FirebaseMessaging <anonymous closure>(dynamic) {
    // ** addr: 0x92546c, size: 0x5c
    // 0x92546c: EnterFrame
    //     0x92546c: stp             fp, lr, [SP, #-0x10]!
    //     0x925470: mov             fp, SP
    // 0x925474: AllocStack(0x8)
    //     0x925474: sub             SP, SP, #8
    // 0x925478: SetupParameters([dynamic _ /* r0 */])
    //     0x925478: ldr             x0, [fp, #0x10]
    //     0x92547c: ldur            w1, [x0, #0x17]
    //     0x925480: add             x1, x1, HEAP, lsl #32
    // 0x925484: LoadField: r0 = r1->field_f
    //     0x925484: ldur            w0, [x1, #0xf]
    // 0x925488: DecompressPointer r0
    //     0x925488: add             x0, x0, HEAP, lsl #32
    // 0x92548c: stur            x0, [fp, #-8]
    // 0x925490: r0 = FirebaseMessaging()
    //     0x925490: bl              #0x9254c8  ; AllocateFirebaseMessagingStub -> FirebaseMessaging (size=0x18)
    // 0x925494: ldur            x1, [fp, #-8]
    // 0x925498: StoreField: r0->field_13 = r1
    //     0x925498: stur            w1, [x0, #0x13]
    // 0x92549c: LoadField: r2 = r1->field_7
    //     0x92549c: ldur            w2, [x1, #7]
    // 0x9254a0: DecompressPointer r2
    //     0x9254a0: add             x2, x2, HEAP, lsl #32
    // 0x9254a4: LoadField: r1 = r2->field_7
    //     0x9254a4: ldur            w1, [x2, #7]
    // 0x9254a8: DecompressPointer r1
    //     0x9254a8: add             x1, x1, HEAP, lsl #32
    // 0x9254ac: StoreField: r0->field_7 = r1
    //     0x9254ac: stur            w1, [x0, #7]
    // 0x9254b0: r1 = "plugins.flutter.io/firebase_messaging"
    //     0x9254b0: add             x1, PP, #8, lsl #12  ; [pp+0x8c78] "plugins.flutter.io/firebase_messaging"
    //     0x9254b4: ldr             x1, [x1, #0xc78]
    // 0x9254b8: StoreField: r0->field_b = r1
    //     0x9254b8: stur            w1, [x0, #0xb]
    // 0x9254bc: LeaveFrame
    //     0x9254bc: mov             SP, fp
    //     0x9254c0: ldp             fp, lr, [SP], #0x10
    // 0x9254c4: ret
    //     0x9254c4: ret             
  }
  static Map<String, FirebaseMessaging> _firebaseMessagingInstances() {
    // ** addr: 0x9254d4, size: 0x40
    // 0x9254d4: EnterFrame
    //     0x9254d4: stp             fp, lr, [SP, #-0x10]!
    //     0x9254d8: mov             fp, SP
    // 0x9254dc: AllocStack(0x10)
    //     0x9254dc: sub             SP, SP, #0x10
    // 0x9254e0: CheckStackOverflow
    //     0x9254e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9254e4: cmp             SP, x16
    //     0x9254e8: b.ls            #0x92550c
    // 0x9254ec: r16 = <String, FirebaseMessaging>
    //     0x9254ec: add             x16, PP, #8, lsl #12  ; [pp+0x8c80] TypeArguments: <String, FirebaseMessaging>
    //     0x9254f0: ldr             x16, [x16, #0xc80]
    // 0x9254f4: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x9254f8: stp             lr, x16, [SP]
    // 0x9254fc: r0 = Map._fromLiteral()
    //     0x9254fc: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x925500: LeaveFrame
    //     0x925500: mov             SP, fp
    //     0x925504: ldp             fp, lr, [SP], #0x10
    // 0x925508: ret
    //     0x925508: ret             
    // 0x92550c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x92550c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x925510: b               #0x9254ec
  }
  _ deleteToken(/* No info */) {
    // ** addr: 0x1310bf0, size: 0x34
    // 0x1310bf0: EnterFrame
    //     0x1310bf0: stp             fp, lr, [SP, #-0x10]!
    //     0x1310bf4: mov             fp, SP
    // 0x1310bf8: CheckStackOverflow
    //     0x1310bf8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1310bfc: cmp             SP, x16
    //     0x1310c00: b.ls            #0x1310c1c
    // 0x1310c04: r0 = _delegate()
    //     0x1310c04: bl              #0x924bd8  ; [package:firebase_messaging/firebase_messaging.dart] FirebaseMessaging::_delegate
    // 0x1310c08: mov             x1, x0
    // 0x1310c0c: r0 = deleteToken()
    //     0x1310c0c: bl              #0x1310c24  ; [package:firebase_messaging_platform_interface/src/method_channel/method_channel_messaging.dart] MethodChannelFirebaseMessaging::deleteToken
    // 0x1310c10: LeaveFrame
    //     0x1310c10: mov             SP, fp
    //     0x1310c14: ldp             fp, lr, [SP], #0x10
    // 0x1310c18: ret
    //     0x1310c18: ret             
    // 0x1310c1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1310c1c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1310c20: b               #0x1310c04
  }
  get _ onMessage(/* No info */) {
    // ** addr: 0x13e746c, size: 0x64
    // 0x13e746c: EnterFrame
    //     0x13e746c: stp             fp, lr, [SP, #-0x10]!
    //     0x13e7470: mov             fp, SP
    // 0x13e7474: AllocStack(0x8)
    //     0x13e7474: sub             SP, SP, #8
    // 0x13e7478: CheckStackOverflow
    //     0x13e7478: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13e747c: cmp             SP, x16
    //     0x13e7480: b.ls            #0x13e74c8
    // 0x13e7484: r0 = LoadStaticField(0x10e8)
    //     0x13e7484: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x13e7488: ldr             x0, [x0, #0x21d0]
    // 0x13e748c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x13e7490: cmp             w0, w16
    // 0x13e7494: b.ne            #0x13e74a4
    // 0x13e7498: r2 = onMessage
    //     0x13e7498: add             x2, PP, #8, lsl #12  ; [pp+0x8ab0] Field <FirebaseMessagingPlatform.onMessage>: static late final (offset: 0x10e8)
    //     0x13e749c: ldr             x2, [x2, #0xab0]
    // 0x13e74a0: r0 = InitLateFinalStaticField()
    //     0x13e74a0: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x13e74a4: r1 = <RemoteMessage>
    //     0x13e74a4: add             x1, PP, #8, lsl #12  ; [pp+0x8ab8] TypeArguments: <RemoteMessage>
    //     0x13e74a8: ldr             x1, [x1, #0xab8]
    // 0x13e74ac: stur            x0, [fp, #-8]
    // 0x13e74b0: r0 = _BroadcastStream()
    //     0x13e74b0: bl              #0xea2bf4  ; Allocate_BroadcastStreamStub -> _BroadcastStream<X0> (size=0x10)
    // 0x13e74b4: ldur            x1, [fp, #-8]
    // 0x13e74b8: StoreField: r0->field_b = r1
    //     0x13e74b8: stur            w1, [x0, #0xb]
    // 0x13e74bc: LeaveFrame
    //     0x13e74bc: mov             SP, fp
    //     0x13e74c0: ldp             fp, lr, [SP], #0x10
    // 0x13e74c4: ret
    //     0x13e74c4: ret             
    // 0x13e74c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13e74c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13e74cc: b               #0x13e7484
  }
  static void onBackgroundMessage() {
    // ** addr: 0x13e74d0, size: 0x38
    // 0x13e74d0: EnterFrame
    //     0x13e74d0: stp             fp, lr, [SP, #-0x10]!
    //     0x13e74d4: mov             fp, SP
    // 0x13e74d8: CheckStackOverflow
    //     0x13e74d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13e74dc: cmp             SP, x16
    //     0x13e74e0: b.ls            #0x13e7500
    // 0x13e74e4: r1 = Closure: (RemoteMessage) => Future<void> from Function 'handleBackgroundMessage': static.
    //     0x13e74e4: add             x1, PP, #8, lsl #12  ; [pp+0x8ac0] Closure: (RemoteMessage) => Future<void> from Function 'handleBackgroundMessage': static. (0x7f2ada80c1fc)
    //     0x13e74e8: ldr             x1, [x1, #0xac0]
    // 0x13e74ec: r0 = onBackgroundMessage=()
    //     0x13e74ec: bl              #0x13e7508  ; [package:firebase_messaging_platform_interface/src/platform_interface/platform_interface_messaging.dart] FirebaseMessagingPlatform::onBackgroundMessage=
    // 0x13e74f0: r0 = Null
    //     0x13e74f0: mov             x0, NULL
    // 0x13e74f4: LeaveFrame
    //     0x13e74f4: mov             SP, fp
    //     0x13e74f8: ldp             fp, lr, [SP], #0x10
    // 0x13e74fc: ret
    //     0x13e74fc: ret             
    // 0x13e7500: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13e7500: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13e7504: b               #0x13e74e4
  }
  get _ onMessageOpenedApp(/* No info */) {
    // ** addr: 0x13e767c, size: 0x64
    // 0x13e767c: EnterFrame
    //     0x13e767c: stp             fp, lr, [SP, #-0x10]!
    //     0x13e7680: mov             fp, SP
    // 0x13e7684: AllocStack(0x8)
    //     0x13e7684: sub             SP, SP, #8
    // 0x13e7688: CheckStackOverflow
    //     0x13e7688: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13e768c: cmp             SP, x16
    //     0x13e7690: b.ls            #0x13e76d8
    // 0x13e7694: r0 = LoadStaticField(0x10ec)
    //     0x13e7694: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x13e7698: ldr             x0, [x0, #0x21d8]
    // 0x13e769c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x13e76a0: cmp             w0, w16
    // 0x13e76a4: b.ne            #0x13e76b4
    // 0x13e76a8: r2 = onMessageOpenedApp
    //     0x13e76a8: add             x2, PP, #8, lsl #12  ; [pp+0x8b88] Field <FirebaseMessagingPlatform.onMessageOpenedApp>: static late final (offset: 0x10ec)
    //     0x13e76ac: ldr             x2, [x2, #0xb88]
    // 0x13e76b0: r0 = InitLateFinalStaticField()
    //     0x13e76b0: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x13e76b4: r1 = <RemoteMessage>
    //     0x13e76b4: add             x1, PP, #8, lsl #12  ; [pp+0x8ab8] TypeArguments: <RemoteMessage>
    //     0x13e76b8: ldr             x1, [x1, #0xab8]
    // 0x13e76bc: stur            x0, [fp, #-8]
    // 0x13e76c0: r0 = _BroadcastStream()
    //     0x13e76c0: bl              #0xea2bf4  ; Allocate_BroadcastStreamStub -> _BroadcastStream<X0> (size=0x10)
    // 0x13e76c4: ldur            x1, [fp, #-8]
    // 0x13e76c8: StoreField: r0->field_b = r1
    //     0x13e76c8: stur            w1, [x0, #0xb]
    // 0x13e76cc: LeaveFrame
    //     0x13e76cc: mov             SP, fp
    //     0x13e76d0: ldp             fp, lr, [SP], #0x10
    // 0x13e76d4: ret
    //     0x13e76d4: ret             
    // 0x13e76d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13e76d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13e76dc: b               #0x13e7694
  }
  _ getInitialMessage(/* No info */) {
    // ** addr: 0x13e76e0, size: 0x34
    // 0x13e76e0: EnterFrame
    //     0x13e76e0: stp             fp, lr, [SP, #-0x10]!
    //     0x13e76e4: mov             fp, SP
    // 0x13e76e8: CheckStackOverflow
    //     0x13e76e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13e76ec: cmp             SP, x16
    //     0x13e76f0: b.ls            #0x13e770c
    // 0x13e76f4: r0 = _delegate()
    //     0x13e76f4: bl              #0x924bd8  ; [package:firebase_messaging/firebase_messaging.dart] FirebaseMessaging::_delegate
    // 0x13e76f8: mov             x1, x0
    // 0x13e76fc: r0 = getInitialMessage()
    //     0x13e76fc: bl              #0x13e7714  ; [package:firebase_messaging_platform_interface/src/method_channel/method_channel_messaging.dart] MethodChannelFirebaseMessaging::getInitialMessage
    // 0x13e7700: LeaveFrame
    //     0x13e7700: mov             SP, fp
    //     0x13e7704: ldp             fp, lr, [SP], #0x10
    // 0x13e7708: ret
    //     0x13e7708: ret             
    // 0x13e770c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13e770c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13e7710: b               #0x13e76f4
  }
  _ setForegroundNotificationPresentationOptions(/* No info */) {
    // ** addr: 0x13e781c, size: 0x40
    // 0x13e781c: EnterFrame
    //     0x13e781c: stp             fp, lr, [SP, #-0x10]!
    //     0x13e7820: mov             fp, SP
    // 0x13e7824: CheckStackOverflow
    //     0x13e7824: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13e7828: cmp             SP, x16
    //     0x13e782c: b.ls            #0x13e7854
    // 0x13e7830: r0 = _delegate()
    //     0x13e7830: bl              #0x924bd8  ; [package:firebase_messaging/firebase_messaging.dart] FirebaseMessaging::_delegate
    // 0x13e7834: mov             x1, x0
    // 0x13e7838: r2 = true
    //     0x13e7838: add             x2, NULL, #0x20  ; true
    // 0x13e783c: r3 = true
    //     0x13e783c: add             x3, NULL, #0x20  ; true
    // 0x13e7840: r5 = true
    //     0x13e7840: add             x5, NULL, #0x20  ; true
    // 0x13e7844: r0 = setForegroundNotificationPresentationOptions()
    //     0x13e7844: bl              #0x13e785c  ; [package:firebase_messaging_platform_interface/src/method_channel/method_channel_messaging.dart] MethodChannelFirebaseMessaging::setForegroundNotificationPresentationOptions
    // 0x13e7848: LeaveFrame
    //     0x13e7848: mov             SP, fp
    //     0x13e784c: ldp             fp, lr, [SP], #0x10
    // 0x13e7850: ret
    //     0x13e7850: ret             
    // 0x13e7854: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13e7854: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13e7858: b               #0x13e7830
  }
  _ requestPermission(/* No info */) {
    // ** addr: 0x13e9448, size: 0x60
    // 0x13e9448: EnterFrame
    //     0x13e9448: stp             fp, lr, [SP, #-0x10]!
    //     0x13e944c: mov             fp, SP
    // 0x13e9450: AllocStack(0x18)
    //     0x13e9450: sub             SP, SP, #0x18
    // 0x13e9454: CheckStackOverflow
    //     0x13e9454: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13e9458: cmp             SP, x16
    //     0x13e945c: b.ls            #0x13e94a0
    // 0x13e9460: r0 = _delegate()
    //     0x13e9460: bl              #0x924bd8  ; [package:firebase_messaging/firebase_messaging.dart] FirebaseMessaging::_delegate
    // 0x13e9464: r16 = false
    //     0x13e9464: add             x16, NULL, #0x30  ; false
    // 0x13e9468: r30 = false
    //     0x13e9468: add             lr, NULL, #0x30  ; false
    // 0x13e946c: stp             lr, x16, [SP, #8]
    // 0x13e9470: r16 = true
    //     0x13e9470: add             x16, NULL, #0x20  ; true
    // 0x13e9474: str             x16, [SP]
    // 0x13e9478: mov             x1, x0
    // 0x13e947c: r2 = true
    //     0x13e947c: add             x2, NULL, #0x20  ; true
    // 0x13e9480: r3 = false
    //     0x13e9480: add             x3, NULL, #0x30  ; false
    // 0x13e9484: r5 = true
    //     0x13e9484: add             x5, NULL, #0x20  ; true
    // 0x13e9488: r6 = false
    //     0x13e9488: add             x6, NULL, #0x30  ; false
    // 0x13e948c: r7 = false
    //     0x13e948c: add             x7, NULL, #0x30  ; false
    // 0x13e9490: r0 = requestPermission()
    //     0x13e9490: bl              #0x13e94a8  ; [package:firebase_messaging_platform_interface/src/method_channel/method_channel_messaging.dart] MethodChannelFirebaseMessaging::requestPermission
    // 0x13e9494: LeaveFrame
    //     0x13e9494: mov             SP, fp
    //     0x13e9498: ldp             fp, lr, [SP], #0x10
    // 0x13e949c: ret
    //     0x13e949c: ret             
    // 0x13e94a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13e94a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13e94a4: b               #0x13e9460
  }
}
