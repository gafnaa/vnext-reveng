// lib: , url: package:async/src/stream_queue.dart

// class id: 1048613, size: 0x8
class :: {
}

// class id: 3614, size: 0x10, field offset: 0x8
class _NextRequest<X0> extends Object
    implements _EventRequest<X0> {

  _ _NextRequest(/* No info */) {
    // ** addr: 0xd98b40, size: 0xac
    // 0xd98b40: EnterFrame
    //     0xd98b40: stp             fp, lr, [SP, #-0x10]!
    //     0xd98b44: mov             fp, SP
    // 0xd98b48: AllocStack(0x18)
    //     0xd98b48: sub             SP, SP, #0x18
    // 0xd98b4c: SetupParameters(_NextRequest<X0> this /* r1 => r0, fp-0x10 */)
    //     0xd98b4c: mov             x0, x1
    //     0xd98b50: stur            x1, [fp, #-0x10]
    // 0xd98b54: CheckStackOverflow
    //     0xd98b54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd98b58: cmp             SP, x16
    //     0xd98b5c: b.ls            #0xd98be4
    // 0xd98b60: LoadField: r2 = r0->field_7
    //     0xd98b60: ldur            w2, [x0, #7]
    // 0xd98b64: DecompressPointer r2
    //     0xd98b64: add             x2, x2, HEAP, lsl #32
    // 0xd98b68: mov             x1, x2
    // 0xd98b6c: stur            x2, [fp, #-8]
    // 0xd98b70: r0 = _Future()
    //     0xd98b70: bl              #0x7f5dd4  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0xd98b74: stur            x0, [fp, #-0x18]
    // 0xd98b78: StoreField: r0->field_b = rZR
    //     0xd98b78: stur            xzr, [x0, #0xb]
    // 0xd98b7c: r0 = LoadStaticField(0x364)
    //     0xd98b7c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xd98b80: ldr             x0, [x0, #0x6c8]
    // 0xd98b84: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd98b88: cmp             w0, w16
    // 0xd98b8c: b.ne            #0xd98b98
    // 0xd98b90: r2 = _current
    //     0xd98b90: ldr             x2, [PP, #0x2c0]  ; [pp+0x2c0] Field <Zone._current@5048458>: static late (offset: 0x364)
    // 0xd98b94: r0 = InitLateStaticField()
    //     0xd98b94: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0xd98b98: mov             x1, x0
    // 0xd98b9c: ldur            x0, [fp, #-0x18]
    // 0xd98ba0: StoreField: r0->field_13 = r1
    //     0xd98ba0: stur            w1, [x0, #0x13]
    // 0xd98ba4: ldur            x1, [fp, #-8]
    // 0xd98ba8: r0 = _AsyncCompleter()
    //     0xd98ba8: bl              #0x7f5dc8  ; Allocate_AsyncCompleterStub -> _AsyncCompleter<X0> (size=0x10)
    // 0xd98bac: ldur            x1, [fp, #-0x18]
    // 0xd98bb0: StoreField: r0->field_b = r1
    //     0xd98bb0: stur            w1, [x0, #0xb]
    // 0xd98bb4: ldur            x1, [fp, #-0x10]
    // 0xd98bb8: StoreField: r1->field_b = r0
    //     0xd98bb8: stur            w0, [x1, #0xb]
    //     0xd98bbc: ldurb           w16, [x1, #-1]
    //     0xd98bc0: ldurb           w17, [x0, #-1]
    //     0xd98bc4: and             x16, x17, x16, lsr #2
    //     0xd98bc8: tst             x16, HEAP, lsr #32
    //     0xd98bcc: b.eq            #0xd98bd4
    //     0xd98bd0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd98bd4: r0 = Null
    //     0xd98bd4: mov             x0, NULL
    // 0xd98bd8: LeaveFrame
    //     0xd98bd8: mov             SP, fp
    //     0xd98bdc: ldp             fp, lr, [SP], #0x10
    // 0xd98be0: ret
    //     0xd98be0: ret             
    // 0xd98be4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd98be4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd98be8: b               #0xd98b60
  }
  _ update(/* No info */) {
    // ** addr: 0x12e60f4, size: 0x114
    // 0x12e60f4: EnterFrame
    //     0x12e60f4: stp             fp, lr, [SP, #-0x10]!
    //     0x12e60f8: mov             fp, SP
    // 0x12e60fc: AllocStack(0x20)
    //     0x12e60fc: sub             SP, SP, #0x20
    // 0x12e6100: SetupParameters(_NextRequest<X0> this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x12e6100: mov             x5, x1
    //     0x12e6104: mov             x4, x2
    //     0x12e6108: stur            x1, [fp, #-8]
    //     0x12e610c: stur            x2, [fp, #-0x10]
    //     0x12e6110: stur            x3, [fp, #-0x18]
    // 0x12e6114: CheckStackOverflow
    //     0x12e6114: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e6118: cmp             SP, x16
    //     0x12e611c: b.ls            #0x12e6200
    // 0x12e6120: LoadField: r2 = r5->field_7
    //     0x12e6120: ldur            w2, [x5, #7]
    // 0x12e6124: DecompressPointer r2
    //     0x12e6124: add             x2, x2, HEAP, lsl #32
    // 0x12e6128: mov             x0, x4
    // 0x12e612c: r1 = Null
    //     0x12e612c: mov             x1, NULL
    // 0x12e6130: r8 = QueueList<Result<X0>>
    //     0x12e6130: add             x8, PP, #0xc9, lsl #12  ; [pp+0xc97a0] Type: QueueList<Result<X0>>
    //     0x12e6134: ldr             x8, [x8, #0x7a0]
    // 0x12e6138: LoadField: r9 = r8->field_7
    //     0x12e6138: ldur            x9, [x8, #7]
    // 0x12e613c: r3 = Null
    //     0x12e613c: add             x3, PP, #0xc9, lsl #12  ; [pp+0xc97a8] Null
    //     0x12e6140: ldr             x3, [x3, #0x7a8]
    // 0x12e6144: blr             x9
    // 0x12e6148: ldur            x16, [fp, #-0x10]
    // 0x12e614c: str             x16, [SP]
    // 0x12e6150: r0 = length()
    //     0x12e6150: bl              #0xc15fe0  ; [package:collection/src/queue_list.dart] QueueList::length
    // 0x12e6154: cbz             w0, #0x12e6198
    // 0x12e6158: ldur            x0, [fp, #-8]
    // 0x12e615c: ldur            x1, [fp, #-0x10]
    // 0x12e6160: r0 = removeFirst()
    //     0x12e6160: bl              #0x12e6208  ; [package:collection/src/queue_list.dart] QueueList::removeFirst
    // 0x12e6164: mov             x1, x0
    // 0x12e6168: ldur            x0, [fp, #-8]
    // 0x12e616c: LoadField: r2 = r0->field_b
    //     0x12e616c: ldur            w2, [x0, #0xb]
    // 0x12e6170: DecompressPointer r2
    //     0x12e6170: add             x2, x2, HEAP, lsl #32
    // 0x12e6174: r0 = LoadClassIdInstr(r1)
    //     0x12e6174: ldur            x0, [x1, #-1]
    //     0x12e6178: ubfx            x0, x0, #0xc, #0x14
    // 0x12e617c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x12e617c: sub             lr, x0, #1, lsl #12
    //     0x12e6180: ldr             lr, [x21, lr, lsl #3]
    //     0x12e6184: blr             lr
    // 0x12e6188: r0 = true
    //     0x12e6188: add             x0, NULL, #0x20  ; true
    // 0x12e618c: LeaveFrame
    //     0x12e618c: mov             SP, fp
    //     0x12e6190: ldp             fp, lr, [SP], #0x10
    // 0x12e6194: ret
    //     0x12e6194: ret             
    // 0x12e6198: ldur            x0, [fp, #-8]
    // 0x12e619c: ldur            x1, [fp, #-0x18]
    // 0x12e61a0: tbnz            w1, #4, #0x12e61f0
    // 0x12e61a4: LoadField: r1 = r0->field_b
    //     0x12e61a4: ldur            w1, [x0, #0xb]
    // 0x12e61a8: DecompressPointer r1
    //     0x12e61a8: add             x1, x1, HEAP, lsl #32
    // 0x12e61ac: stur            x1, [fp, #-0x10]
    // 0x12e61b0: r0 = StateError()
    //     0x12e61b0: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x12e61b4: mov             x1, x0
    // 0x12e61b8: r0 = "No elements"
    //     0x12e61b8: add             x0, PP, #0xc9, lsl #12  ; [pp+0xc97b8] "No elements"
    //     0x12e61bc: ldr             x0, [x0, #0x7b8]
    // 0x12e61c0: stur            x1, [fp, #-8]
    // 0x12e61c4: StoreField: r1->field_b = r0
    //     0x12e61c4: stur            w0, [x1, #0xb]
    // 0x12e61c8: r0 = current()
    //     0x12e61c8: bl              #0x7f0e88  ; [dart:core] StackTrace::current
    // 0x12e61cc: str             x0, [SP]
    // 0x12e61d0: ldur            x1, [fp, #-0x10]
    // 0x12e61d4: ldur            x2, [fp, #-8]
    // 0x12e61d8: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x12e61d8: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x12e61dc: r0 = completeError()
    //     0x12e61dc: bl              #0x7f6b94  ; [dart:async] _Completer::completeError
    // 0x12e61e0: r0 = true
    //     0x12e61e0: add             x0, NULL, #0x20  ; true
    // 0x12e61e4: LeaveFrame
    //     0x12e61e4: mov             SP, fp
    //     0x12e61e8: ldp             fp, lr, [SP], #0x10
    // 0x12e61ec: ret
    //     0x12e61ec: ret             
    // 0x12e61f0: r0 = false
    //     0x12e61f0: add             x0, NULL, #0x30  ; false
    // 0x12e61f4: LeaveFrame
    //     0x12e61f4: mov             SP, fp
    //     0x12e61f8: ldp             fp, lr, [SP], #0x10
    // 0x12e61fc: ret
    //     0x12e61fc: ret             
    // 0x12e6200: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e6200: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e6204: b               #0x12e6120
  }
}

// class id: 3615, size: 0xc, field offset: 0x8
abstract class _EventRequest<X0> extends Object {
}

// class id: 3616, size: 0x2c, field offset: 0x8
class StreamQueue<X0> extends Object {

  _ cancel(/* No info */) {
    // ** addr: 0xd98420, size: 0xc4
    // 0xd98420: EnterFrame
    //     0xd98420: stp             fp, lr, [SP, #-0x10]!
    //     0xd98424: mov             fp, SP
    // 0xd98428: AllocStack(0x18)
    //     0xd98428: sub             SP, SP, #0x18
    // 0xd9842c: SetupParameters(StreamQueue<X0> this /* r1 => r0, fp-0x8 */)
    //     0xd9842c: mov             x0, x1
    //     0xd98430: stur            x1, [fp, #-8]
    // 0xd98434: CheckStackOverflow
    //     0xd98434: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd98438: cmp             SP, x16
    //     0xd9843c: b.ls            #0xd984dc
    // 0xd98440: mov             x1, x0
    // 0xd98444: r0 = _checkNotClosed()
    //     0xd98444: bl              #0xd98cbc  ; [package:async/src/stream_queue.dart] StreamQueue::_checkNotClosed
    // 0xd98448: ldur            x1, [fp, #-8]
    // 0xd9844c: r0 = true
    //     0xd9844c: add             x0, NULL, #0x20  ; true
    // 0xd98450: ArrayStore: r1[0] = r0  ; List_4
    //     0xd98450: stur            w0, [x1, #0x17]
    // 0xd98454: LoadField: r0 = r1->field_13
    //     0xd98454: ldur            w0, [x1, #0x13]
    // 0xd98458: DecompressPointer r0
    //     0xd98458: add             x0, x0, HEAP, lsl #32
    // 0xd9845c: tbnz            w0, #4, #0xd984c8
    // 0xd98460: LoadField: r0 = r1->field_23
    //     0xd98460: ldur            w0, [x1, #0x23]
    // 0xd98464: DecompressPointer r0
    //     0xd98464: add             x0, x0, HEAP, lsl #32
    // 0xd98468: str             x0, [SP]
    // 0xd9846c: r0 = length()
    //     0xd9846c: bl              #0xc15fe0  ; [package:collection/src/queue_list.dart] QueueList::length
    // 0xd98470: cbnz            w0, #0xd984c8
    // 0xd98474: r1 = Null
    //     0xd98474: mov             x1, NULL
    // 0xd98478: r0 = _Future()
    //     0xd98478: bl              #0x7f5dd4  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0xd9847c: stur            x0, [fp, #-0x10]
    // 0xd98480: StoreField: r0->field_b = rZR
    //     0xd98480: stur            xzr, [x0, #0xb]
    // 0xd98484: r0 = LoadStaticField(0x364)
    //     0xd98484: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xd98488: ldr             x0, [x0, #0x6c8]
    // 0xd9848c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd98490: cmp             w0, w16
    // 0xd98494: b.ne            #0xd984a0
    // 0xd98498: r2 = _current
    //     0xd98498: ldr             x2, [PP, #0x2c0]  ; [pp+0x2c0] Field <Zone._current@5048458>: static late (offset: 0x364)
    // 0xd9849c: r0 = InitLateStaticField()
    //     0xd9849c: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0xd984a0: mov             x1, x0
    // 0xd984a4: ldur            x0, [fp, #-0x10]
    // 0xd984a8: StoreField: r0->field_13 = r1
    //     0xd984a8: stur            w1, [x0, #0x13]
    // 0xd984ac: mov             x1, x0
    // 0xd984b0: r2 = Null
    //     0xd984b0: mov             x2, NULL
    // 0xd984b4: r0 = _asyncComplete()
    //     0xd984b4: bl              #0x7eee44  ; [dart:async] _Future::_asyncComplete
    // 0xd984b8: ldur            x0, [fp, #-0x10]
    // 0xd984bc: LeaveFrame
    //     0xd984bc: mov             SP, fp
    //     0xd984c0: ldp             fp, lr, [SP], #0x10
    // 0xd984c4: ret
    //     0xd984c4: ret             
    // 0xd984c8: ldur            x1, [fp, #-8]
    // 0xd984cc: r0 = _cancel()
    //     0xd984cc: bl              #0xd98bf8  ; [package:async/src/stream_queue.dart] StreamQueue::_cancel
    // 0xd984d0: LeaveFrame
    //     0xd984d0: mov             SP, fp
    //     0xd984d4: ldp             fp, lr, [SP], #0x10
    // 0xd984d8: ret
    //     0xd984d8: ret             
    // 0xd984dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd984dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd984e0: b               #0xd98440
  }
  Future<X0> dyn:get:next(StreamQueue<X0>) {
    // ** addr: 0xd984fc, size: 0x48
    // 0xd984fc: EnterFrame
    //     0xd984fc: stp             fp, lr, [SP, #-0x10]!
    //     0xd98500: mov             fp, SP
    // 0xd98504: CheckStackOverflow
    //     0xd98504: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd98508: cmp             SP, x16
    //     0xd9850c: b.ls            #0xd98524
    // 0xd98510: ldr             x1, [fp, #0x10]
    // 0xd98514: r0 = next()
    //     0xd98514: bl              #0xd9852c  ; [package:async/src/stream_queue.dart] StreamQueue::next
    // 0xd98518: LeaveFrame
    //     0xd98518: mov             SP, fp
    //     0xd9851c: ldp             fp, lr, [SP], #0x10
    // 0xd98520: ret
    //     0xd98520: ret             
    // 0xd98524: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd98524: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd98528: b               #0xd98510
  }
  Future<X0> next(StreamQueue<X0>) {
    // ** addr: 0xd9852c, size: 0x78
    // 0xd9852c: EnterFrame
    //     0xd9852c: stp             fp, lr, [SP, #-0x10]!
    //     0xd98530: mov             fp, SP
    // 0xd98534: AllocStack(0x10)
    //     0xd98534: sub             SP, SP, #0x10
    // 0xd98538: SetupParameters(StreamQueue<X0> this /* r1 => r0, fp-0x8 */)
    //     0xd98538: mov             x0, x1
    //     0xd9853c: stur            x1, [fp, #-8]
    // 0xd98540: CheckStackOverflow
    //     0xd98540: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd98544: cmp             SP, x16
    //     0xd98548: b.ls            #0xd9859c
    // 0xd9854c: mov             x1, x0
    // 0xd98550: r0 = _checkNotClosed()
    //     0xd98550: bl              #0xd98cbc  ; [package:async/src/stream_queue.dart] StreamQueue::_checkNotClosed
    // 0xd98554: ldur            x0, [fp, #-8]
    // 0xd98558: LoadField: r1 = r0->field_7
    //     0xd98558: ldur            w1, [x0, #7]
    // 0xd9855c: DecompressPointer r1
    //     0xd9855c: add             x1, x1, HEAP, lsl #32
    // 0xd98560: r0 = _NextRequest()
    //     0xd98560: bl              #0xd98bec  ; Allocate_NextRequestStub -> _NextRequest<X0> (size=0x10)
    // 0xd98564: mov             x1, x0
    // 0xd98568: stur            x0, [fp, #-0x10]
    // 0xd9856c: r0 = _NextRequest()
    //     0xd9856c: bl              #0xd98b40  ; [package:async/src/stream_queue.dart] _NextRequest::_NextRequest
    // 0xd98570: ldur            x1, [fp, #-8]
    // 0xd98574: ldur            x2, [fp, #-0x10]
    // 0xd98578: r0 = _addRequest()
    //     0xd98578: bl              #0xd985a4  ; [package:async/src/stream_queue.dart] StreamQueue::_addRequest
    // 0xd9857c: ldur            x1, [fp, #-0x10]
    // 0xd98580: LoadField: r2 = r1->field_b
    //     0xd98580: ldur            w2, [x1, #0xb]
    // 0xd98584: DecompressPointer r2
    //     0xd98584: add             x2, x2, HEAP, lsl #32
    // 0xd98588: LoadField: r0 = r2->field_b
    //     0xd98588: ldur            w0, [x2, #0xb]
    // 0xd9858c: DecompressPointer r0
    //     0xd9858c: add             x0, x0, HEAP, lsl #32
    // 0xd98590: LeaveFrame
    //     0xd98590: mov             SP, fp
    //     0xd98594: ldp             fp, lr, [SP], #0x10
    // 0xd98598: ret
    //     0xd98598: ret             
    // 0xd9859c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd9859c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd985a0: b               #0xd9854c
  }
  _ _addRequest(/* No info */) {
    // ** addr: 0xd985a4, size: 0x9c
    // 0xd985a4: EnterFrame
    //     0xd985a4: stp             fp, lr, [SP, #-0x10]!
    //     0xd985a8: mov             fp, SP
    // 0xd985ac: AllocStack(0x18)
    //     0xd985ac: sub             SP, SP, #0x18
    // 0xd985b0: SetupParameters(StreamQueue<X0> this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */)
    //     0xd985b0: mov             x4, x1
    //     0xd985b4: mov             x0, x2
    //     0xd985b8: stur            x1, [fp, #-0x10]
    //     0xd985bc: stur            x2, [fp, #-0x18]
    // 0xd985c0: CheckStackOverflow
    //     0xd985c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd985c4: cmp             SP, x16
    //     0xd985c8: b.ls            #0xd98638
    // 0xd985cc: LoadField: r5 = r4->field_27
    //     0xd985cc: ldur            w5, [x4, #0x27]
    // 0xd985d0: DecompressPointer r5
    //     0xd985d0: add             x5, x5, HEAP, lsl #32
    // 0xd985d4: stur            x5, [fp, #-8]
    // 0xd985d8: LoadField: r1 = r5->field_f
    //     0xd985d8: ldur            x1, [x5, #0xf]
    // 0xd985dc: ArrayLoad: r2 = r5[0]  ; List_8
    //     0xd985dc: ldur            x2, [x5, #0x17]
    // 0xd985e0: cmp             x1, x2
    // 0xd985e4: b.ne            #0xd9861c
    // 0xd985e8: LoadField: r2 = r4->field_23
    //     0xd985e8: ldur            w2, [x4, #0x23]
    // 0xd985ec: DecompressPointer r2
    //     0xd985ec: add             x2, x2, HEAP, lsl #32
    // 0xd985f0: LoadField: r3 = r4->field_13
    //     0xd985f0: ldur            w3, [x4, #0x13]
    // 0xd985f4: DecompressPointer r3
    //     0xd985f4: add             x3, x3, HEAP, lsl #32
    // 0xd985f8: mov             x1, x0
    // 0xd985fc: r0 = update()
    //     0xd985fc: bl              #0x12e60f4  ; [package:async/src/stream_queue.dart] _NextRequest::update
    // 0xd98600: tbnz            w0, #4, #0xd98614
    // 0xd98604: r0 = Null
    //     0xd98604: mov             x0, NULL
    // 0xd98608: LeaveFrame
    //     0xd98608: mov             SP, fp
    //     0xd9860c: ldp             fp, lr, [SP], #0x10
    // 0xd98610: ret
    //     0xd98610: ret             
    // 0xd98614: ldur            x1, [fp, #-0x10]
    // 0xd98618: r0 = _ensureListening()
    //     0xd98618: bl              #0xd98640  ; [package:async/src/stream_queue.dart] StreamQueue::_ensureListening
    // 0xd9861c: ldur            x1, [fp, #-8]
    // 0xd98620: ldur            x2, [fp, #-0x18]
    // 0xd98624: r0 = _add()
    //     0xd98624: bl              #0x820990  ; [dart:collection] ListQueue::_add
    // 0xd98628: r0 = Null
    //     0xd98628: mov             x0, NULL
    // 0xd9862c: LeaveFrame
    //     0xd9862c: mov             SP, fp
    //     0xd98630: ldp             fp, lr, [SP], #0x10
    // 0xd98634: ret
    //     0xd98634: ret             
    // 0xd98638: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd98638: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd9863c: b               #0xd985cc
  }
  _ _ensureListening(/* No info */) {
    // ** addr: 0xd98640, size: 0x114
    // 0xd98640: EnterFrame
    //     0xd98640: stp             fp, lr, [SP, #-0x10]!
    //     0xd98644: mov             fp, SP
    // 0xd98648: AllocStack(0x30)
    //     0xd98648: sub             SP, SP, #0x30
    // 0xd9864c: SetupParameters(StreamQueue<X0> this /* r1 => r1, fp-0x8 */)
    //     0xd9864c: stur            x1, [fp, #-8]
    // 0xd98650: CheckStackOverflow
    //     0xd98650: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd98654: cmp             SP, x16
    //     0xd98658: b.ls            #0xd9874c
    // 0xd9865c: r1 = 1
    //     0xd9865c: mov             x1, #1
    // 0xd98660: r0 = AllocateContext()
    //     0xd98660: bl              #0x13de838  ; AllocateContextStub
    // 0xd98664: mov             x4, x0
    // 0xd98668: ldur            x0, [fp, #-8]
    // 0xd9866c: stur            x4, [fp, #-0x18]
    // 0xd98670: StoreField: r4->field_f = r0
    //     0xd98670: stur            w0, [x4, #0xf]
    // 0xd98674: LoadField: r1 = r0->field_13
    //     0xd98674: ldur            w1, [x0, #0x13]
    // 0xd98678: DecompressPointer r1
    //     0xd98678: add             x1, x1, HEAP, lsl #32
    // 0xd9867c: tbnz            w1, #4, #0xd98690
    // 0xd98680: r0 = Null
    //     0xd98680: mov             x0, NULL
    // 0xd98684: LeaveFrame
    //     0xd98684: mov             SP, fp
    //     0xd98688: ldp             fp, lr, [SP], #0x10
    // 0xd9868c: ret
    //     0xd9868c: ret             
    // 0xd98690: LoadField: r1 = r0->field_f
    //     0xd98690: ldur            w1, [x0, #0xf]
    // 0xd98694: DecompressPointer r1
    //     0xd98694: add             x1, x1, HEAP, lsl #32
    // 0xd98698: cmp             w1, NULL
    // 0xd9869c: b.ne            #0xd98728
    // 0xd986a0: LoadField: r5 = r0->field_b
    //     0xd986a0: ldur            w5, [x0, #0xb]
    // 0xd986a4: DecompressPointer r5
    //     0xd986a4: add             x5, x5, HEAP, lsl #32
    // 0xd986a8: stur            x5, [fp, #-0x10]
    // 0xd986ac: LoadField: r3 = r0->field_7
    //     0xd986ac: ldur            w3, [x0, #7]
    // 0xd986b0: DecompressPointer r3
    //     0xd986b0: add             x3, x3, HEAP, lsl #32
    // 0xd986b4: mov             x2, x4
    // 0xd986b8: r1 = Function '<anonymous closure>':.
    //     0xd986b8: add             x1, PP, #0xc9, lsl #12  ; [pp+0xc9788] AnonymousClosure: (0xd98ac8), in [package:async/src/stream_queue.dart] StreamQueue::_ensureListening (0xd98640)
    //     0xd986bc: ldr             x1, [x1, #0x788]
    // 0xd986c0: r0 = AllocateClosureTA()
    //     0xd986c0: bl              #0x13dea48  ; AllocateClosureTAStub
    // 0xd986c4: ldur            x2, [fp, #-0x18]
    // 0xd986c8: r1 = Function '<anonymous closure>':.
    //     0xd986c8: add             x1, PP, #0xc9, lsl #12  ; [pp+0xc9790] AnonymousClosure: (0xd989c8), in [package:async/src/stream_queue.dart] StreamQueue::_ensureListening (0xd98640)
    //     0xd986cc: ldr             x1, [x1, #0x790]
    // 0xd986d0: stur            x0, [fp, #-0x20]
    // 0xd986d4: r0 = AllocateClosure()
    //     0xd986d4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd986d8: ldur            x2, [fp, #-0x18]
    // 0xd986dc: r1 = Function '<anonymous closure>':.
    //     0xd986dc: add             x1, PP, #0xc9, lsl #12  ; [pp+0xc9798] AnonymousClosure: (0xd98754), in [package:async/src/stream_queue.dart] StreamQueue::_ensureListening (0xd98640)
    //     0xd986e0: ldr             x1, [x1, #0x798]
    // 0xd986e4: stur            x0, [fp, #-0x18]
    // 0xd986e8: r0 = AllocateClosure()
    //     0xd986e8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd986ec: ldur            x16, [fp, #-0x18]
    // 0xd986f0: stp             x0, x16, [SP]
    // 0xd986f4: ldur            x1, [fp, #-0x10]
    // 0xd986f8: ldur            x2, [fp, #-0x20]
    // 0xd986fc: r4 = const [0, 0x4, 0x2, 0x2, onDone, 0x3, onError, 0x2, null]
    //     0xd986fc: ldr             x4, [PP, #0x220]  ; [pp+0x220] List(9) [0, 0x4, 0x2, 0x2, "onDone", 0x3, "onError", 0x2, Null]
    // 0xd98700: r0 = listen()
    //     0xd98700: bl              #0x123bb50  ; [dart:isolate] _ReceivePortImpl::listen
    // 0xd98704: ldur            x1, [fp, #-8]
    // 0xd98708: StoreField: r1->field_f = r0
    //     0xd98708: stur            w0, [x1, #0xf]
    //     0xd9870c: ldurb           w16, [x1, #-1]
    //     0xd98710: ldurb           w17, [x0, #-1]
    //     0xd98714: and             x16, x17, x16, lsr #2
    //     0xd98718: tst             x16, HEAP, lsr #32
    //     0xd9871c: b.eq            #0xd98724
    //     0xd98720: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd98724: b               #0xd9873c
    // 0xd98728: r0 = LoadClassIdInstr(r1)
    //     0xd98728: ldur            x0, [x1, #-1]
    //     0xd9872c: ubfx            x0, x0, #0xc, #0x14
    // 0xd98730: r0 = GDT[cid_x0 + 0x5d3]()
    //     0xd98730: add             lr, x0, #0x5d3
    //     0xd98734: ldr             lr, [x21, lr, lsl #3]
    //     0xd98738: blr             lr
    // 0xd9873c: r0 = Null
    //     0xd9873c: mov             x0, NULL
    // 0xd98740: LeaveFrame
    //     0xd98740: mov             SP, fp
    //     0xd98744: ldp             fp, lr, [SP], #0x10
    // 0xd98748: ret
    //     0xd98748: ret             
    // 0xd9874c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd9874c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd98750: b               #0xd9865c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xd98754, size: 0x4c
    // 0xd98754: EnterFrame
    //     0xd98754: stp             fp, lr, [SP, #-0x10]!
    //     0xd98758: mov             fp, SP
    // 0xd9875c: ldr             x0, [fp, #0x10]
    // 0xd98760: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd98760: ldur            w1, [x0, #0x17]
    // 0xd98764: DecompressPointer r1
    //     0xd98764: add             x1, x1, HEAP, lsl #32
    // 0xd98768: CheckStackOverflow
    //     0xd98768: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd9876c: cmp             SP, x16
    //     0xd98770: b.ls            #0xd98798
    // 0xd98774: LoadField: r0 = r1->field_f
    //     0xd98774: ldur            w0, [x1, #0xf]
    // 0xd98778: DecompressPointer r0
    //     0xd98778: add             x0, x0, HEAP, lsl #32
    // 0xd9877c: StoreField: r0->field_f = rNULL
    //     0xd9877c: stur            NULL, [x0, #0xf]
    // 0xd98780: mov             x1, x0
    // 0xd98784: r0 = _close()
    //     0xd98784: bl              #0xd987a0  ; [package:async/src/stream_queue.dart] StreamQueue::_close
    // 0xd98788: r0 = Null
    //     0xd98788: mov             x0, NULL
    // 0xd9878c: LeaveFrame
    //     0xd9878c: mov             SP, fp
    //     0xd98790: ldp             fp, lr, [SP], #0x10
    // 0xd98794: ret
    //     0xd98794: ret             
    // 0xd98798: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd98798: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd9879c: b               #0xd98774
  }
  _ _close(/* No info */) {
    // ** addr: 0xd987a0, size: 0x38
    // 0xd987a0: EnterFrame
    //     0xd987a0: stp             fp, lr, [SP, #-0x10]!
    //     0xd987a4: mov             fp, SP
    // 0xd987a8: r0 = true
    //     0xd987a8: add             x0, NULL, #0x20  ; true
    // 0xd987ac: CheckStackOverflow
    //     0xd987ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd987b0: cmp             SP, x16
    //     0xd987b4: b.ls            #0xd987d0
    // 0xd987b8: StoreField: r1->field_13 = r0
    //     0xd987b8: stur            w0, [x1, #0x13]
    // 0xd987bc: r0 = _updateRequests()
    //     0xd987bc: bl              #0xd987d8  ; [package:async/src/stream_queue.dart] StreamQueue::_updateRequests
    // 0xd987c0: r0 = Null
    //     0xd987c0: mov             x0, NULL
    // 0xd987c4: LeaveFrame
    //     0xd987c4: mov             SP, fp
    //     0xd987c8: ldp             fp, lr, [SP], #0x10
    // 0xd987cc: ret
    //     0xd987cc: ret             
    // 0xd987d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd987d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd987d4: b               #0xd987b8
  }
  _ _updateRequests(/* No info */) {
    // ** addr: 0xd987d8, size: 0x168
    // 0xd987d8: EnterFrame
    //     0xd987d8: stp             fp, lr, [SP, #-0x10]!
    //     0xd987dc: mov             fp, SP
    // 0xd987e0: AllocStack(0x20)
    //     0xd987e0: sub             SP, SP, #0x20
    // 0xd987e4: SetupParameters(StreamQueue<X0> this /* r1 => r3, fp-0x20 */)
    //     0xd987e4: mov             x3, x1
    //     0xd987e8: stur            x1, [fp, #-0x20]
    // 0xd987ec: CheckStackOverflow
    //     0xd987ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd987f0: cmp             SP, x16
    //     0xd987f4: b.ls            #0xd9892c
    // 0xd987f8: LoadField: r4 = r3->field_27
    //     0xd987f8: ldur            w4, [x3, #0x27]
    // 0xd987fc: DecompressPointer r4
    //     0xd987fc: add             x4, x4, HEAP, lsl #32
    // 0xd98800: stur            x4, [fp, #-0x18]
    // 0xd98804: LoadField: r5 = r3->field_23
    //     0xd98804: ldur            w5, [x3, #0x23]
    // 0xd98808: DecompressPointer r5
    //     0xd98808: add             x5, x5, HEAP, lsl #32
    // 0xd9880c: stur            x5, [fp, #-0x10]
    // 0xd98810: CheckStackOverflow
    //     0xd98810: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd98814: cmp             SP, x16
    //     0xd98818: b.ls            #0xd98934
    // 0xd9881c: LoadField: r2 = r4->field_f
    //     0xd9881c: ldur            x2, [x4, #0xf]
    // 0xd98820: ArrayLoad: r0 = r4[0]  ; List_8
    //     0xd98820: ldur            x0, [x4, #0x17]
    // 0xd98824: cmp             x2, x0
    // 0xd98828: b.eq            #0xd988fc
    // 0xd9882c: cmp             x2, x0
    // 0xd98830: b.eq            #0xd98920
    // 0xd98834: LoadField: r6 = r4->field_b
    //     0xd98834: ldur            w6, [x4, #0xb]
    // 0xd98838: DecompressPointer r6
    //     0xd98838: add             x6, x6, HEAP, lsl #32
    // 0xd9883c: LoadField: r0 = r6->field_b
    //     0xd9883c: ldur            w0, [x6, #0xb]
    // 0xd98840: r1 = LoadInt32Instr(r0)
    //     0xd98840: sbfx            x1, x0, #1, #0x1f
    // 0xd98844: mov             x0, x1
    // 0xd98848: mov             x1, x2
    // 0xd9884c: cmp             x1, x0
    // 0xd98850: b.hs            #0xd9893c
    // 0xd98854: ArrayLoad: r7 = r6[r2]  ; Unknown_4
    //     0xd98854: add             x16, x6, x2, lsl #2
    //     0xd98858: ldur            w7, [x16, #0xf]
    // 0xd9885c: DecompressPointer r7
    //     0xd9885c: add             x7, x7, HEAP, lsl #32
    // 0xd98860: stur            x7, [fp, #-8]
    // 0xd98864: cmp             w7, NULL
    // 0xd98868: b.ne            #0xd988a8
    // 0xd9886c: mov             x0, x7
    // 0xd98870: r2 = Null
    //     0xd98870: mov             x2, NULL
    // 0xd98874: r1 = Null
    //     0xd98874: mov             x1, NULL
    // 0xd98878: r4 = 60
    //     0xd98878: mov             x4, #0x3c
    // 0xd9887c: branchIfSmi(r0, 0xd98888)
    //     0xd9887c: tbz             w0, #0, #0xd98888
    // 0xd98880: r4 = LoadClassIdInstr(r0)
    //     0xd98880: ldur            x4, [x0, #-1]
    //     0xd98884: ubfx            x4, x4, #0xc, #0x14
    // 0xd98888: sub             x4, x4, #0xe1d
    // 0xd9888c: cmp             x4, #1
    // 0xd98890: b.ls            #0xd988a8
    // 0xd98894: r8 = _EventRequest
    //     0xd98894: add             x8, PP, #0xc6, lsl #12  ; [pp+0xc6a20] Type: _EventRequest
    //     0xd98898: ldr             x8, [x8, #0xa20]
    // 0xd9889c: r3 = Null
    //     0xd9889c: add             x3, PP, #0xc6, lsl #12  ; [pp+0xc6a28] Null
    //     0xd988a0: ldr             x3, [x3, #0xa28]
    // 0xd988a4: r0 = _EventRequest()
    //     0xd988a4: bl              #0xd989a4  ; IsType__EventRequest_Stub
    // 0xd988a8: ldur            x4, [fp, #-0x20]
    // 0xd988ac: ldur            x1, [fp, #-8]
    // 0xd988b0: LoadField: r3 = r4->field_13
    //     0xd988b0: ldur            w3, [x4, #0x13]
    // 0xd988b4: DecompressPointer r3
    //     0xd988b4: add             x3, x3, HEAP, lsl #32
    // 0xd988b8: r0 = LoadClassIdInstr(r1)
    //     0xd988b8: ldur            x0, [x1, #-1]
    //     0xd988bc: ubfx            x0, x0, #0xc, #0x14
    // 0xd988c0: ldur            x2, [fp, #-0x10]
    // 0xd988c4: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd988c4: sub             lr, x0, #1, lsl #12
    //     0xd988c8: ldr             lr, [x21, lr, lsl #3]
    //     0xd988cc: blr             lr
    // 0xd988d0: tbnz            w0, #4, #0xd988ec
    // 0xd988d4: ldur            x1, [fp, #-0x18]
    // 0xd988d8: r0 = removeFirst()
    //     0xd988d8: bl              #0x820d24  ; [dart:collection] ListQueue::removeFirst
    // 0xd988dc: ldur            x3, [fp, #-0x20]
    // 0xd988e0: ldur            x4, [fp, #-0x18]
    // 0xd988e4: ldur            x5, [fp, #-0x10]
    // 0xd988e8: b               #0xd98810
    // 0xd988ec: r0 = Null
    //     0xd988ec: mov             x0, NULL
    // 0xd988f0: LeaveFrame
    //     0xd988f0: mov             SP, fp
    //     0xd988f4: ldp             fp, lr, [SP], #0x10
    // 0xd988f8: ret
    //     0xd988f8: ret             
    // 0xd988fc: mov             x1, x3
    // 0xd98900: LoadField: r0 = r1->field_13
    //     0xd98900: ldur            w0, [x1, #0x13]
    // 0xd98904: DecompressPointer r0
    //     0xd98904: add             x0, x0, HEAP, lsl #32
    // 0xd98908: tbz             w0, #4, #0xd98910
    // 0xd9890c: r0 = _pause()
    //     0xd9890c: bl              #0xd98940  ; [package:async/src/stream_queue.dart] StreamQueue::_pause
    // 0xd98910: r0 = Null
    //     0xd98910: mov             x0, NULL
    // 0xd98914: LeaveFrame
    //     0xd98914: mov             SP, fp
    //     0xd98918: ldp             fp, lr, [SP], #0x10
    // 0xd9891c: ret
    //     0xd9891c: ret             
    // 0xd98920: r0 = noElement()
    //     0xd98920: bl              #0x7e3da8  ; [dart:_internal] IterableElementError::noElement
    // 0xd98924: r0 = Throw()
    //     0xd98924: bl              #0x13ddb2c  ; ThrowStub
    // 0xd98928: brk             #0
    // 0xd9892c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd9892c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd98930: b               #0xd987f8
    // 0xd98934: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd98934: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd98938: b               #0xd9881c
    // 0xd9893c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xd9893c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _pause(/* No info */) {
    // ** addr: 0xd98940, size: 0x64
    // 0xd98940: EnterFrame
    //     0xd98940: stp             fp, lr, [SP, #-0x10]!
    //     0xd98944: mov             fp, SP
    // 0xd98948: CheckStackOverflow
    //     0xd98948: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd9894c: cmp             SP, x16
    //     0xd98950: b.ls            #0xd98998
    // 0xd98954: LoadField: r0 = r1->field_f
    //     0xd98954: ldur            w0, [x1, #0xf]
    // 0xd98958: DecompressPointer r0
    //     0xd98958: add             x0, x0, HEAP, lsl #32
    // 0xd9895c: cmp             w0, NULL
    // 0xd98960: b.eq            #0xd989a0
    // 0xd98964: r1 = LoadClassIdInstr(r0)
    //     0xd98964: ldur            x1, [x0, #-1]
    //     0xd98968: ubfx            x1, x1, #0xc, #0x14
    // 0xd9896c: mov             x16, x0
    // 0xd98970: mov             x0, x1
    // 0xd98974: mov             x1, x16
    // 0xd98978: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd98978: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd9897c: r0 = GDT[cid_x0 + 0x61e]()
    //     0xd9897c: add             lr, x0, #0x61e
    //     0xd98980: ldr             lr, [x21, lr, lsl #3]
    //     0xd98984: blr             lr
    // 0xd98988: r0 = Null
    //     0xd98988: mov             x0, NULL
    // 0xd9898c: LeaveFrame
    //     0xd9898c: mov             SP, fp
    //     0xd98990: ldp             fp, lr, [SP], #0x10
    // 0xd98994: ret
    //     0xd98994: ret             
    // 0xd98998: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd98998: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd9899c: b               #0xd98954
    // 0xd989a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd989a0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Null <anonymous closure>(dynamic, Object, StackTrace) {
    // ** addr: 0xd989c8, size: 0x68
    // 0xd989c8: EnterFrame
    //     0xd989c8: stp             fp, lr, [SP, #-0x10]!
    //     0xd989cc: mov             fp, SP
    // 0xd989d0: AllocStack(0x8)
    //     0xd989d0: sub             SP, SP, #8
    // 0xd989d4: SetupParameters([dynamic _ /* r0 */])
    //     0xd989d4: ldr             x0, [fp, #0x20]
    //     0xd989d8: ldur            w1, [x0, #0x17]
    //     0xd989dc: add             x1, x1, HEAP, lsl #32
    // 0xd989e0: CheckStackOverflow
    //     0xd989e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd989e4: cmp             SP, x16
    //     0xd989e8: b.ls            #0xd98a28
    // 0xd989ec: LoadField: r0 = r1->field_f
    //     0xd989ec: ldur            w0, [x1, #0xf]
    // 0xd989f0: DecompressPointer r0
    //     0xd989f0: add             x0, x0, HEAP, lsl #32
    // 0xd989f4: stur            x0, [fp, #-8]
    // 0xd989f8: LoadField: r1 = r0->field_7
    //     0xd989f8: ldur            w1, [x0, #7]
    // 0xd989fc: DecompressPointer r1
    //     0xd989fc: add             x1, x1, HEAP, lsl #32
    // 0xd98a00: ldr             x2, [fp, #0x18]
    // 0xd98a04: ldr             x3, [fp, #0x10]
    // 0xd98a08: r0 = Result.error()
    //     0xd98a08: bl              #0xd98a88  ; [package:async/src/result/result.dart] Result::Result.error
    // 0xd98a0c: ldur            x1, [fp, #-8]
    // 0xd98a10: mov             x2, x0
    // 0xd98a14: r0 = _addResult()
    //     0xd98a14: bl              #0xd98a30  ; [package:async/src/stream_queue.dart] StreamQueue::_addResult
    // 0xd98a18: r0 = Null
    //     0xd98a18: mov             x0, NULL
    // 0xd98a1c: LeaveFrame
    //     0xd98a1c: mov             SP, fp
    //     0xd98a20: ldp             fp, lr, [SP], #0x10
    // 0xd98a24: ret
    //     0xd98a24: ret             
    // 0xd98a28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd98a28: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd98a2c: b               #0xd989ec
  }
  _ _addResult(/* No info */) {
    // ** addr: 0xd98a30, size: 0x58
    // 0xd98a30: EnterFrame
    //     0xd98a30: stp             fp, lr, [SP, #-0x10]!
    //     0xd98a34: mov             fp, SP
    // 0xd98a38: AllocStack(0x8)
    //     0xd98a38: sub             SP, SP, #8
    // 0xd98a3c: SetupParameters(StreamQueue<X0> this /* r1 => r0, fp-0x8 */)
    //     0xd98a3c: mov             x0, x1
    //     0xd98a40: stur            x1, [fp, #-8]
    // 0xd98a44: CheckStackOverflow
    //     0xd98a44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd98a48: cmp             SP, x16
    //     0xd98a4c: b.ls            #0xd98a80
    // 0xd98a50: LoadField: r1 = r0->field_1b
    //     0xd98a50: ldur            x1, [x0, #0x1b]
    // 0xd98a54: add             x3, x1, #1
    // 0xd98a58: StoreField: r0->field_1b = r3
    //     0xd98a58: stur            x3, [x0, #0x1b]
    // 0xd98a5c: LoadField: r1 = r0->field_23
    //     0xd98a5c: ldur            w1, [x0, #0x23]
    // 0xd98a60: DecompressPointer r1
    //     0xd98a60: add             x1, x1, HEAP, lsl #32
    // 0xd98a64: r0 = _add()
    //     0xd98a64: bl              #0x9f0a6c  ; [package:collection/src/queue_list.dart] QueueList::_add
    // 0xd98a68: ldur            x1, [fp, #-8]
    // 0xd98a6c: r0 = _updateRequests()
    //     0xd98a6c: bl              #0xd987d8  ; [package:async/src/stream_queue.dart] StreamQueue::_updateRequests
    // 0xd98a70: r0 = Null
    //     0xd98a70: mov             x0, NULL
    // 0xd98a74: LeaveFrame
    //     0xd98a74: mov             SP, fp
    //     0xd98a78: ldp             fp, lr, [SP], #0x10
    // 0xd98a7c: ret
    //     0xd98a7c: ret             
    // 0xd98a80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd98a80: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd98a84: b               #0xd98a50
  }
  [closure] void <anonymous closure>(dynamic, X0) {
    // ** addr: 0xd98ac8, size: 0x6c
    // 0xd98ac8: EnterFrame
    //     0xd98ac8: stp             fp, lr, [SP, #-0x10]!
    //     0xd98acc: mov             fp, SP
    // 0xd98ad0: AllocStack(0x8)
    //     0xd98ad0: sub             SP, SP, #8
    // 0xd98ad4: SetupParameters([dynamic _ /* r0 */])
    //     0xd98ad4: ldr             x0, [fp, #0x18]
    //     0xd98ad8: ldur            w1, [x0, #0x17]
    //     0xd98adc: add             x1, x1, HEAP, lsl #32
    // 0xd98ae0: CheckStackOverflow
    //     0xd98ae0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd98ae4: cmp             SP, x16
    //     0xd98ae8: b.ls            #0xd98b2c
    // 0xd98aec: LoadField: r0 = r1->field_f
    //     0xd98aec: ldur            w0, [x1, #0xf]
    // 0xd98af0: DecompressPointer r0
    //     0xd98af0: add             x0, x0, HEAP, lsl #32
    // 0xd98af4: stur            x0, [fp, #-8]
    // 0xd98af8: LoadField: r1 = r0->field_7
    //     0xd98af8: ldur            w1, [x0, #7]
    // 0xd98afc: DecompressPointer r1
    //     0xd98afc: add             x1, x1, HEAP, lsl #32
    // 0xd98b00: r0 = ValueResult()
    //     0xd98b00: bl              #0xd98b34  ; AllocateValueResultStub -> ValueResult<X0> (size=0x10)
    // 0xd98b04: mov             x1, x0
    // 0xd98b08: ldr             x0, [fp, #0x10]
    // 0xd98b0c: StoreField: r1->field_b = r0
    //     0xd98b0c: stur            w0, [x1, #0xb]
    // 0xd98b10: mov             x2, x1
    // 0xd98b14: ldur            x1, [fp, #-8]
    // 0xd98b18: r0 = _addResult()
    //     0xd98b18: bl              #0xd98a30  ; [package:async/src/stream_queue.dart] StreamQueue::_addResult
    // 0xd98b1c: r0 = Null
    //     0xd98b1c: mov             x0, NULL
    // 0xd98b20: LeaveFrame
    //     0xd98b20: mov             SP, fp
    //     0xd98b24: ldp             fp, lr, [SP], #0x10
    // 0xd98b28: ret
    //     0xd98b28: ret             
    // 0xd98b2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd98b2c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd98b30: b               #0xd98aec
  }
  _ _cancel(/* No info */) {
    // ** addr: 0xd98bf8, size: 0xc4
    // 0xd98bf8: EnterFrame
    //     0xd98bf8: stp             fp, lr, [SP, #-0x10]!
    //     0xd98bfc: mov             fp, SP
    // 0xd98c00: AllocStack(0x8)
    //     0xd98c00: sub             SP, SP, #8
    // 0xd98c04: SetupParameters(StreamQueue<X0> this /* r1 => r0, fp-0x8 */)
    //     0xd98c04: mov             x0, x1
    //     0xd98c08: stur            x1, [fp, #-8]
    // 0xd98c0c: CheckStackOverflow
    //     0xd98c0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd98c10: cmp             SP, x16
    //     0xd98c14: b.ls            #0xd98cb4
    // 0xd98c18: LoadField: r1 = r0->field_13
    //     0xd98c18: ldur            w1, [x0, #0x13]
    // 0xd98c1c: DecompressPointer r1
    //     0xd98c1c: add             x1, x1, HEAP, lsl #32
    // 0xd98c20: tbnz            w1, #4, #0xd98c34
    // 0xd98c24: r0 = Null
    //     0xd98c24: mov             x0, NULL
    // 0xd98c28: LeaveFrame
    //     0xd98c28: mov             SP, fp
    //     0xd98c2c: ldp             fp, lr, [SP], #0x10
    // 0xd98c30: ret
    //     0xd98c30: ret             
    // 0xd98c34: LoadField: r1 = r0->field_f
    //     0xd98c34: ldur            w1, [x0, #0xf]
    // 0xd98c38: DecompressPointer r1
    //     0xd98c38: add             x1, x1, HEAP, lsl #32
    // 0xd98c3c: cmp             w1, NULL
    // 0xd98c40: b.ne            #0xd98c80
    // 0xd98c44: LoadField: r1 = r0->field_b
    //     0xd98c44: ldur            w1, [x0, #0xb]
    // 0xd98c48: DecompressPointer r1
    //     0xd98c48: add             x1, x1, HEAP, lsl #32
    // 0xd98c4c: r2 = Null
    //     0xd98c4c: mov             x2, NULL
    // 0xd98c50: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xd98c50: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xd98c54: r0 = listen()
    //     0xd98c54: bl              #0x123bb50  ; [dart:isolate] _ReceivePortImpl::listen
    // 0xd98c58: mov             x1, x0
    // 0xd98c5c: ldur            x2, [fp, #-8]
    // 0xd98c60: StoreField: r2->field_f = r0
    //     0xd98c60: stur            w0, [x2, #0xf]
    //     0xd98c64: ldurb           w16, [x2, #-1]
    //     0xd98c68: ldurb           w17, [x0, #-1]
    //     0xd98c6c: and             x16, x17, x16, lsr #2
    //     0xd98c70: tst             x16, HEAP, lsr #32
    //     0xd98c74: b.eq            #0xd98c7c
    //     0xd98c78: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd98c7c: b               #0xd98c84
    // 0xd98c80: mov             x2, x0
    // 0xd98c84: r0 = LoadClassIdInstr(r1)
    //     0xd98c84: ldur            x0, [x1, #-1]
    //     0xd98c88: ubfx            x0, x0, #0xc, #0x14
    // 0xd98c8c: r0 = GDT[cid_x0 + 0x549]()
    //     0xd98c8c: add             lr, x0, #0x549
    //     0xd98c90: ldr             lr, [x21, lr, lsl #3]
    //     0xd98c94: blr             lr
    // 0xd98c98: ldur            x1, [fp, #-8]
    // 0xd98c9c: stur            x0, [fp, #-8]
    // 0xd98ca0: r0 = _close()
    //     0xd98ca0: bl              #0xd987a0  ; [package:async/src/stream_queue.dart] StreamQueue::_close
    // 0xd98ca4: ldur            x0, [fp, #-8]
    // 0xd98ca8: LeaveFrame
    //     0xd98ca8: mov             SP, fp
    //     0xd98cac: ldp             fp, lr, [SP], #0x10
    // 0xd98cb0: ret
    //     0xd98cb0: ret             
    // 0xd98cb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd98cb4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd98cb8: b               #0xd98c18
  }
  _ _checkNotClosed(/* No info */) {
    // ** addr: 0xd98cbc, size: 0x44
    // 0xd98cbc: EnterFrame
    //     0xd98cbc: stp             fp, lr, [SP, #-0x10]!
    //     0xd98cc0: mov             fp, SP
    // 0xd98cc4: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xd98cc4: ldur            w0, [x1, #0x17]
    // 0xd98cc8: DecompressPointer r0
    //     0xd98cc8: add             x0, x0, HEAP, lsl #32
    // 0xd98ccc: tbz             w0, #4, #0xd98ce0
    // 0xd98cd0: r0 = Null
    //     0xd98cd0: mov             x0, NULL
    // 0xd98cd4: LeaveFrame
    //     0xd98cd4: mov             SP, fp
    //     0xd98cd8: ldp             fp, lr, [SP], #0x10
    // 0xd98cdc: ret
    //     0xd98cdc: ret             
    // 0xd98ce0: r0 = StateError()
    //     0xd98ce0: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xd98ce4: mov             x1, x0
    // 0xd98ce8: r0 = "Already cancelled"
    //     0xd98ce8: add             x0, PP, #0xc6, lsl #12  ; [pp+0xc6a38] "Already cancelled"
    //     0xd98cec: ldr             x0, [x0, #0xa38]
    // 0xd98cf0: StoreField: r1->field_b = r0
    //     0xd98cf0: stur            w0, [x1, #0xb]
    // 0xd98cf4: mov             x0, x1
    // 0xd98cf8: r0 = Throw()
    //     0xd98cf8: bl              #0x13ddb2c  ; ThrowStub
    // 0xd98cfc: brk             #0
  }
  factory _ StreamQueue(/* No info */) {
    // ** addr: 0xd98d3c, size: 0x48
    // 0xd98d3c: EnterFrame
    //     0xd98d3c: stp             fp, lr, [SP, #-0x10]!
    //     0xd98d40: mov             fp, SP
    // 0xd98d44: AllocStack(0x8)
    //     0xd98d44: sub             SP, SP, #8
    // 0xd98d48: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0xd98d48: stur            x2, [fp, #-8]
    // 0xd98d4c: CheckStackOverflow
    //     0xd98d4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd98d50: cmp             SP, x16
    //     0xd98d54: b.ls            #0xd98d7c
    // 0xd98d58: r0 = StreamQueue()
    //     0xd98d58: bl              #0xd98ed8  ; AllocateStreamQueueStub -> StreamQueue<X0> (size=0x2c)
    // 0xd98d5c: mov             x1, x0
    // 0xd98d60: ldur            x2, [fp, #-8]
    // 0xd98d64: stur            x0, [fp, #-8]
    // 0xd98d68: r0 = StreamQueue._()
    //     0xd98d68: bl              #0xd98d84  ; [package:async/src/stream_queue.dart] StreamQueue::StreamQueue._
    // 0xd98d6c: ldur            x0, [fp, #-8]
    // 0xd98d70: LeaveFrame
    //     0xd98d70: mov             SP, fp
    //     0xd98d74: ldp             fp, lr, [SP], #0x10
    // 0xd98d78: ret
    //     0xd98d78: ret             
    // 0xd98d7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd98d7c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd98d80: b               #0xd98d58
  }
  _ StreamQueue._(/* No info */) {
    // ** addr: 0xd98d84, size: 0x148
    // 0xd98d84: EnterFrame
    //     0xd98d84: stp             fp, lr, [SP, #-0x10]!
    //     0xd98d88: mov             fp, SP
    // 0xd98d8c: AllocStack(0x18)
    //     0xd98d8c: sub             SP, SP, #0x18
    // 0xd98d90: r0 = false
    //     0xd98d90: add             x0, NULL, #0x30  ; false
    // 0xd98d94: mov             x5, x1
    // 0xd98d98: mov             x4, x2
    // 0xd98d9c: stur            x1, [fp, #-8]
    // 0xd98da0: stur            x2, [fp, #-0x10]
    // 0xd98da4: CheckStackOverflow
    //     0xd98da4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd98da8: cmp             SP, x16
    //     0xd98dac: b.ls            #0xd98ec4
    // 0xd98db0: StoreField: r5->field_13 = r0
    //     0xd98db0: stur            w0, [x5, #0x13]
    // 0xd98db4: ArrayStore: r5[0] = r0  ; List_4
    //     0xd98db4: stur            w0, [x5, #0x17]
    // 0xd98db8: StoreField: r5->field_1b = rZR
    //     0xd98db8: stur            xzr, [x5, #0x1b]
    // 0xd98dbc: LoadField: r2 = r5->field_7
    //     0xd98dbc: ldur            w2, [x5, #7]
    // 0xd98dc0: DecompressPointer r2
    //     0xd98dc0: add             x2, x2, HEAP, lsl #32
    // 0xd98dc4: r1 = Null
    //     0xd98dc4: mov             x1, NULL
    // 0xd98dc8: r3 = <Result<X0>>
    //     0xd98dc8: add             x3, PP, #0xc6, lsl #12  ; [pp+0xc6a10] TypeArguments: <Result<X0>>
    //     0xd98dcc: ldr             x3, [x3, #0xa10]
    // 0xd98dd0: r30 = InstantiateTypeArgumentsStub
    //     0xd98dd0: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0xd98dd4: LoadField: r30 = r30->field_7
    //     0xd98dd4: ldur            lr, [lr, #7]
    // 0xd98dd8: blr             lr
    // 0xd98ddc: mov             x2, x0
    // 0xd98de0: r1 = Null
    //     0xd98de0: mov             x1, NULL
    // 0xd98de4: r3 = <X0?>
    //     0xd98de4: ldr             x3, [PP, #0xbf8]  ; [pp+0xbf8] TypeArguments: <X0?>
    // 0xd98de8: stur            x0, [fp, #-0x18]
    // 0xd98dec: r0 = Null
    //     0xd98dec: mov             x0, NULL
    // 0xd98df0: cmp             x2, x0
    // 0xd98df4: b.eq            #0xd98e04
    // 0xd98df8: r30 = InstantiateTypeArgumentsMayShareInstantiatorTAStub
    //     0xd98df8: ldr             lr, [PP, #0xc00]  ; [pp+0xc00] Stub: InstantiateTypeArgumentsMayShareInstantiatorTA (0x7c0e60)
    // 0xd98dfc: LoadField: r30 = r30->field_7
    //     0xd98dfc: ldur            lr, [lr, #7]
    // 0xd98e00: blr             lr
    // 0xd98e04: ldur            x1, [fp, #-0x18]
    // 0xd98e08: stur            x0, [fp, #-0x18]
    // 0xd98e0c: r0 = QueueList()
    //     0xd98e0c: bl              #0xd98ecc  ; AllocateQueueListStub -> QueueList<X0> (size=0x20)
    // 0xd98e10: ldur            x1, [fp, #-0x18]
    // 0xd98e14: r2 = 16
    //     0xd98e14: mov             x2, #0x10
    // 0xd98e18: stur            x0, [fp, #-0x18]
    // 0xd98e1c: r0 = AllocateArray()
    //     0xd98e1c: bl              #0x13df928  ; AllocateArrayStub
    // 0xd98e20: mov             x1, x0
    // 0xd98e24: ldur            x0, [fp, #-0x18]
    // 0xd98e28: StoreField: r0->field_b = r1
    //     0xd98e28: stur            w1, [x0, #0xb]
    // 0xd98e2c: StoreField: r0->field_f = rZR
    //     0xd98e2c: stur            xzr, [x0, #0xf]
    // 0xd98e30: ArrayStore: r0[0] = rZR  ; List_8
    //     0xd98e30: stur            xzr, [x0, #0x17]
    // 0xd98e34: ldur            x2, [fp, #-8]
    // 0xd98e38: StoreField: r2->field_23 = r0
    //     0xd98e38: stur            w0, [x2, #0x23]
    //     0xd98e3c: ldurb           w16, [x2, #-1]
    //     0xd98e40: ldurb           w17, [x0, #-1]
    //     0xd98e44: and             x16, x17, x16, lsr #2
    //     0xd98e48: tst             x16, HEAP, lsr #32
    //     0xd98e4c: b.eq            #0xd98e54
    //     0xd98e50: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd98e54: r1 = <_EventRequest>
    //     0xd98e54: add             x1, PP, #0xc6, lsl #12  ; [pp+0xc6a18] TypeArguments: <_EventRequest>
    //     0xd98e58: ldr             x1, [x1, #0xa18]
    // 0xd98e5c: r0 = ListQueue()
    //     0xd98e5c: bl              #0x8217c0  ; AllocateListQueueStub -> ListQueue<X0> (size=0x28)
    // 0xd98e60: mov             x1, x0
    // 0xd98e64: stur            x0, [fp, #-0x18]
    // 0xd98e68: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd98e68: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd98e6c: r0 = ListQueue()
    //     0xd98e6c: bl              #0x821650  ; [dart:collection] ListQueue::ListQueue
    // 0xd98e70: ldur            x0, [fp, #-0x18]
    // 0xd98e74: ldur            x1, [fp, #-8]
    // 0xd98e78: StoreField: r1->field_27 = r0
    //     0xd98e78: stur            w0, [x1, #0x27]
    //     0xd98e7c: ldurb           w16, [x1, #-1]
    //     0xd98e80: ldurb           w17, [x0, #-1]
    //     0xd98e84: and             x16, x17, x16, lsr #2
    //     0xd98e88: tst             x16, HEAP, lsr #32
    //     0xd98e8c: b.eq            #0xd98e94
    //     0xd98e90: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd98e94: ldur            x0, [fp, #-0x10]
    // 0xd98e98: StoreField: r1->field_b = r0
    //     0xd98e98: stur            w0, [x1, #0xb]
    //     0xd98e9c: ldurb           w16, [x1, #-1]
    //     0xd98ea0: ldurb           w17, [x0, #-1]
    //     0xd98ea4: and             x16, x17, x16, lsr #2
    //     0xd98ea8: tst             x16, HEAP, lsr #32
    //     0xd98eac: b.eq            #0xd98eb4
    //     0xd98eb0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd98eb4: r0 = Null
    //     0xd98eb4: mov             x0, NULL
    // 0xd98eb8: LeaveFrame
    //     0xd98eb8: mov             SP, fp
    //     0xd98ebc: ldp             fp, lr, [SP], #0x10
    // 0xd98ec0: ret
    //     0xd98ec0: ret             
    // 0xd98ec4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd98ec4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd98ec8: b               #0xd98db0
  }
}
