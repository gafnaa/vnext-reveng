// lib: , url: package:async/src/result/result.dart

// class id: 1048610, size: 0x8
class :: {
}

// class id: 3618, size: 0xc, field offset: 0x8
abstract class Result<X0> extends Object {

  factory _ Result.error(/* No info */) {
    // ** addr: 0xd98a88, size: 0x34
    // 0xd98a88: EnterFrame
    //     0xd98a88: stp             fp, lr, [SP, #-0x10]!
    //     0xd98a8c: mov             fp, SP
    // 0xd98a90: AllocStack(0x10)
    //     0xd98a90: sub             SP, SP, #0x10
    // 0xd98a94: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xd98a94: stur            x2, [fp, #-8]
    //     0xd98a98: stur            x3, [fp, #-0x10]
    // 0xd98a9c: r0 = ErrorResult()
    //     0xd98a9c: bl              #0xd98abc  ; AllocateErrorResultStub -> ErrorResult (size=0x10)
    // 0xd98aa0: ldur            x1, [fp, #-8]
    // 0xd98aa4: StoreField: r0->field_7 = r1
    //     0xd98aa4: stur            w1, [x0, #7]
    // 0xd98aa8: ldur            x1, [fp, #-0x10]
    // 0xd98aac: StoreField: r0->field_b = r1
    //     0xd98aac: stur            w1, [x0, #0xb]
    // 0xd98ab0: LeaveFrame
    //     0xd98ab0: mov             SP, fp
    //     0xd98ab4: ldp             fp, lr, [SP], #0x10
    // 0xd98ab8: ret
    //     0xd98ab8: ret             
  }
}
