// lib: , url: package:async/src/result/error.dart

// class id: 1048609, size: 0x8
class :: {
}

// class id: 3619, size: 0x10, field offset: 0x8
class ErrorResult extends Object
    implements Result<X0> {

  get _ hashCode(/* No info */) {
    // ** addr: 0x1149110, size: 0xb4
    // 0x1149110: EnterFrame
    //     0x1149110: stp             fp, lr, [SP, #-0x10]!
    //     0x1149114: mov             fp, SP
    // 0x1149118: AllocStack(0x10)
    //     0x1149118: sub             SP, SP, #0x10
    // 0x114911c: CheckStackOverflow
    //     0x114911c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1149120: cmp             SP, x16
    //     0x1149124: b.ls            #0x11491bc
    // 0x1149128: ldr             x1, [fp, #0x10]
    // 0x114912c: LoadField: r0 = r1->field_7
    //     0x114912c: ldur            w0, [x1, #7]
    // 0x1149130: DecompressPointer r0
    //     0x1149130: add             x0, x0, HEAP, lsl #32
    // 0x1149134: r2 = 60
    //     0x1149134: mov             x2, #0x3c
    // 0x1149138: branchIfSmi(r0, 0x1149144)
    //     0x1149138: tbz             w0, #0, #0x1149144
    // 0x114913c: r2 = LoadClassIdInstr(r0)
    //     0x114913c: ldur            x2, [x0, #-1]
    //     0x1149140: ubfx            x2, x2, #0xc, #0x14
    // 0x1149144: str             x0, [SP]
    // 0x1149148: mov             x0, x2
    // 0x114914c: r0 = GDT[cid_x0 + 0x70de]()
    //     0x114914c: mov             x17, #0x70de
    //     0x1149150: add             lr, x0, x17
    //     0x1149154: ldr             lr, [x21, lr, lsl #3]
    //     0x1149158: blr             lr
    // 0x114915c: mov             x1, x0
    // 0x1149160: ldr             x0, [fp, #0x10]
    // 0x1149164: stur            x1, [fp, #-8]
    // 0x1149168: LoadField: r2 = r0->field_b
    //     0x1149168: ldur            w2, [x0, #0xb]
    // 0x114916c: DecompressPointer r2
    //     0x114916c: add             x2, x2, HEAP, lsl #32
    // 0x1149170: str             x2, [SP]
    // 0x1149174: r0 = _getHash()
    //     0x1149174: bl              #0x84c644  ; [dart:core] ::_getHash
    // 0x1149178: ldur            x2, [fp, #-8]
    // 0x114917c: r3 = LoadInt32Instr(r2)
    //     0x114917c: sbfx            x3, x2, #1, #0x1f
    //     0x1149180: tbz             w2, #0, #0x1149188
    //     0x1149184: ldur            x3, [x2, #7]
    // 0x1149188: r2 = LoadInt32Instr(r0)
    //     0x1149188: sbfx            x2, x0, #1, #0x1f
    // 0x114918c: eor             x4, x3, x2
    // 0x1149190: r16 = 492929599
    //     0x1149190: mov             x16, #0x823f
    //     0x1149194: movk            x16, #0x1d61, lsl #16
    // 0x1149198: eor             x2, x4, x16
    // 0x114919c: r0 = BoxInt64Instr(r2)
    //     0x114919c: sbfiz           x0, x2, #1, #0x1f
    //     0x11491a0: cmp             x2, x0, asr #1
    //     0x11491a4: b.eq            #0x11491b0
    //     0x11491a8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x11491ac: stur            x2, [x0, #7]
    // 0x11491b0: LeaveFrame
    //     0x11491b0: mov             SP, fp
    //     0x11491b4: ldp             fp, lr, [SP], #0x10
    // 0x11491b8: ret
    //     0x11491b8: ret             
    // 0x11491bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11491bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11491c0: b               #0x1149128
  }
  _ ==(/* No info */) {
    // ** addr: 0x1291f38, size: 0xd0
    // 0x1291f38: EnterFrame
    //     0x1291f38: stp             fp, lr, [SP, #-0x10]!
    //     0x1291f3c: mov             fp, SP
    // 0x1291f40: AllocStack(0x10)
    //     0x1291f40: sub             SP, SP, #0x10
    // 0x1291f44: CheckStackOverflow
    //     0x1291f44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1291f48: cmp             SP, x16
    //     0x1291f4c: b.ls            #0x1292000
    // 0x1291f50: ldr             x1, [fp, #0x10]
    // 0x1291f54: cmp             w1, NULL
    // 0x1291f58: b.ne            #0x1291f6c
    // 0x1291f5c: r0 = false
    //     0x1291f5c: add             x0, NULL, #0x30  ; false
    // 0x1291f60: LeaveFrame
    //     0x1291f60: mov             SP, fp
    //     0x1291f64: ldp             fp, lr, [SP], #0x10
    // 0x1291f68: ret
    //     0x1291f68: ret             
    // 0x1291f6c: r0 = 60
    //     0x1291f6c: mov             x0, #0x3c
    // 0x1291f70: branchIfSmi(r1, 0x1291f7c)
    //     0x1291f70: tbz             w1, #0, #0x1291f7c
    // 0x1291f74: r0 = LoadClassIdInstr(r1)
    //     0x1291f74: ldur            x0, [x1, #-1]
    //     0x1291f78: ubfx            x0, x0, #0xc, #0x14
    // 0x1291f7c: cmp             x0, #0xe23
    // 0x1291f80: b.ne            #0x1291ff0
    // 0x1291f84: ldr             x2, [fp, #0x18]
    // 0x1291f88: LoadField: r0 = r2->field_7
    //     0x1291f88: ldur            w0, [x2, #7]
    // 0x1291f8c: DecompressPointer r0
    //     0x1291f8c: add             x0, x0, HEAP, lsl #32
    // 0x1291f90: LoadField: r3 = r1->field_7
    //     0x1291f90: ldur            w3, [x1, #7]
    // 0x1291f94: DecompressPointer r3
    //     0x1291f94: add             x3, x3, HEAP, lsl #32
    // 0x1291f98: r4 = 60
    //     0x1291f98: mov             x4, #0x3c
    // 0x1291f9c: branchIfSmi(r0, 0x1291fa8)
    //     0x1291f9c: tbz             w0, #0, #0x1291fa8
    // 0x1291fa0: r4 = LoadClassIdInstr(r0)
    //     0x1291fa0: ldur            x4, [x0, #-1]
    //     0x1291fa4: ubfx            x4, x4, #0xc, #0x14
    // 0x1291fa8: stp             x3, x0, [SP]
    // 0x1291fac: mov             x0, x4
    // 0x1291fb0: mov             lr, x0
    // 0x1291fb4: ldr             lr, [x21, lr, lsl #3]
    // 0x1291fb8: blr             lr
    // 0x1291fbc: tbnz            w0, #4, #0x1291ff0
    // 0x1291fc0: ldr             x2, [fp, #0x18]
    // 0x1291fc4: ldr             x1, [fp, #0x10]
    // 0x1291fc8: LoadField: r3 = r2->field_b
    //     0x1291fc8: ldur            w3, [x2, #0xb]
    // 0x1291fcc: DecompressPointer r3
    //     0x1291fcc: add             x3, x3, HEAP, lsl #32
    // 0x1291fd0: LoadField: r2 = r1->field_b
    //     0x1291fd0: ldur            w2, [x1, #0xb]
    // 0x1291fd4: DecompressPointer r2
    //     0x1291fd4: add             x2, x2, HEAP, lsl #32
    // 0x1291fd8: cmp             w3, w2
    // 0x1291fdc: r16 = true
    //     0x1291fdc: add             x16, NULL, #0x20  ; true
    // 0x1291fe0: r17 = false
    //     0x1291fe0: add             x17, NULL, #0x30  ; false
    // 0x1291fe4: csel            x1, x16, x17, eq
    // 0x1291fe8: mov             x0, x1
    // 0x1291fec: b               #0x1291ff4
    // 0x1291ff0: r0 = false
    //     0x1291ff0: add             x0, NULL, #0x30  ; false
    // 0x1291ff4: LeaveFrame
    //     0x1291ff4: mov             SP, fp
    //     0x1291ff8: ldp             fp, lr, [SP], #0x10
    // 0x1291ffc: ret
    //     0x1291ffc: ret             
    // 0x1292000: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1292000: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1292004: b               #0x1291f50
  }
  _ complete(/* No info */) {
    // ** addr: 0x12e601c, size: 0x54
    // 0x12e601c: EnterFrame
    //     0x12e601c: stp             fp, lr, [SP, #-0x10]!
    //     0x12e6020: mov             fp, SP
    // 0x12e6024: AllocStack(0x8)
    //     0x12e6024: sub             SP, SP, #8
    // 0x12e6028: SetupParameters(ErrorResult this /* r1 => r0 */, dynamic _ /* r2 => r1 */)
    //     0x12e6028: mov             x0, x1
    //     0x12e602c: mov             x1, x2
    // 0x12e6030: CheckStackOverflow
    //     0x12e6030: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e6034: cmp             SP, x16
    //     0x12e6038: b.ls            #0x12e6068
    // 0x12e603c: LoadField: r2 = r0->field_7
    //     0x12e603c: ldur            w2, [x0, #7]
    // 0x12e6040: DecompressPointer r2
    //     0x12e6040: add             x2, x2, HEAP, lsl #32
    // 0x12e6044: LoadField: r3 = r0->field_b
    //     0x12e6044: ldur            w3, [x0, #0xb]
    // 0x12e6048: DecompressPointer r3
    //     0x12e6048: add             x3, x3, HEAP, lsl #32
    // 0x12e604c: str             x3, [SP]
    // 0x12e6050: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x12e6050: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x12e6054: r0 = completeError()
    //     0x12e6054: bl              #0x7f6b94  ; [dart:async] _Completer::completeError
    // 0x12e6058: r0 = Null
    //     0x12e6058: mov             x0, NULL
    // 0x12e605c: LeaveFrame
    //     0x12e605c: mov             SP, fp
    //     0x12e6060: ldp             fp, lr, [SP], #0x10
    // 0x12e6064: ret
    //     0x12e6064: ret             
    // 0x12e6068: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e6068: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e606c: b               #0x12e603c
  }
}
