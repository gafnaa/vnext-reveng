// lib: , url: package:async/src/result/value.dart

// class id: 1048611, size: 0x8
class :: {
}

// class id: 3617, size: 0x10, field offset: 0x8
class ValueResult<X0> extends Object
    implements Result<X0> {

  get _ hashCode(/* No info */) {
    // ** addr: 0x11491c4, size: 0x88
    // 0x11491c4: EnterFrame
    //     0x11491c4: stp             fp, lr, [SP, #-0x10]!
    //     0x11491c8: mov             fp, SP
    // 0x11491cc: AllocStack(0x8)
    //     0x11491cc: sub             SP, SP, #8
    // 0x11491d0: CheckStackOverflow
    //     0x11491d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11491d4: cmp             SP, x16
    //     0x11491d8: b.ls            #0x1149244
    // 0x11491dc: ldr             x0, [fp, #0x10]
    // 0x11491e0: LoadField: r1 = r0->field_b
    //     0x11491e0: ldur            w1, [x0, #0xb]
    // 0x11491e4: DecompressPointer r1
    //     0x11491e4: add             x1, x1, HEAP, lsl #32
    // 0x11491e8: r0 = 60
    //     0x11491e8: mov             x0, #0x3c
    // 0x11491ec: branchIfSmi(r1, 0x11491f8)
    //     0x11491ec: tbz             w1, #0, #0x11491f8
    // 0x11491f0: r0 = LoadClassIdInstr(r1)
    //     0x11491f0: ldur            x0, [x1, #-1]
    //     0x11491f4: ubfx            x0, x0, #0xc, #0x14
    // 0x11491f8: str             x1, [SP]
    // 0x11491fc: r0 = GDT[cid_x0 + 0x70de]()
    //     0x11491fc: mov             x17, #0x70de
    //     0x1149200: add             lr, x0, x17
    //     0x1149204: ldr             lr, [x21, lr, lsl #3]
    //     0x1149208: blr             lr
    // 0x114920c: r2 = LoadInt32Instr(r0)
    //     0x114920c: sbfx            x2, x0, #1, #0x1f
    //     0x1149210: tbz             w0, #0, #0x1149218
    //     0x1149214: ldur            x2, [x0, #7]
    // 0x1149218: r16 = 842997089
    //     0x1149218: mov             x16, #0x1d61
    //     0x114921c: movk            x16, #0x323f, lsl #16
    // 0x1149220: eor             x3, x2, x16
    // 0x1149224: r0 = BoxInt64Instr(r3)
    //     0x1149224: sbfiz           x0, x3, #1, #0x1f
    //     0x1149228: cmp             x3, x0, asr #1
    //     0x114922c: b.eq            #0x1149238
    //     0x1149230: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1149234: stur            x3, [x0, #7]
    // 0x1149238: LeaveFrame
    //     0x1149238: mov             SP, fp
    //     0x114923c: ldp             fp, lr, [SP], #0x10
    // 0x1149240: ret
    //     0x1149240: ret             
    // 0x1149244: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1149244: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1149248: b               #0x11491dc
  }
  _ ==(/* No info */) {
    // ** addr: 0x1292008, size: 0x9c
    // 0x1292008: EnterFrame
    //     0x1292008: stp             fp, lr, [SP, #-0x10]!
    //     0x129200c: mov             fp, SP
    // 0x1292010: AllocStack(0x10)
    //     0x1292010: sub             SP, SP, #0x10
    // 0x1292014: CheckStackOverflow
    //     0x1292014: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1292018: cmp             SP, x16
    //     0x129201c: b.ls            #0x129209c
    // 0x1292020: ldr             x0, [fp, #0x10]
    // 0x1292024: cmp             w0, NULL
    // 0x1292028: b.ne            #0x129203c
    // 0x129202c: r0 = false
    //     0x129202c: add             x0, NULL, #0x30  ; false
    // 0x1292030: LeaveFrame
    //     0x1292030: mov             SP, fp
    //     0x1292034: ldp             fp, lr, [SP], #0x10
    // 0x1292038: ret
    //     0x1292038: ret             
    // 0x129203c: r1 = 60
    //     0x129203c: mov             x1, #0x3c
    // 0x1292040: branchIfSmi(r0, 0x129204c)
    //     0x1292040: tbz             w0, #0, #0x129204c
    // 0x1292044: r1 = LoadClassIdInstr(r0)
    //     0x1292044: ldur            x1, [x0, #-1]
    //     0x1292048: ubfx            x1, x1, #0xc, #0x14
    // 0x129204c: cmp             x1, #0xe21
    // 0x1292050: b.ne            #0x129208c
    // 0x1292054: ldr             x1, [fp, #0x18]
    // 0x1292058: LoadField: r2 = r1->field_b
    //     0x1292058: ldur            w2, [x1, #0xb]
    // 0x129205c: DecompressPointer r2
    //     0x129205c: add             x2, x2, HEAP, lsl #32
    // 0x1292060: LoadField: r1 = r0->field_b
    //     0x1292060: ldur            w1, [x0, #0xb]
    // 0x1292064: DecompressPointer r1
    //     0x1292064: add             x1, x1, HEAP, lsl #32
    // 0x1292068: r0 = 60
    //     0x1292068: mov             x0, #0x3c
    // 0x129206c: branchIfSmi(r2, 0x1292078)
    //     0x129206c: tbz             w2, #0, #0x1292078
    // 0x1292070: r0 = LoadClassIdInstr(r2)
    //     0x1292070: ldur            x0, [x2, #-1]
    //     0x1292074: ubfx            x0, x0, #0xc, #0x14
    // 0x1292078: stp             x1, x2, [SP]
    // 0x129207c: mov             lr, x0
    // 0x1292080: ldr             lr, [x21, lr, lsl #3]
    // 0x1292084: blr             lr
    // 0x1292088: b               #0x1292090
    // 0x129208c: r0 = false
    //     0x129208c: add             x0, NULL, #0x30  ; false
    // 0x1292090: LeaveFrame
    //     0x1292090: mov             SP, fp
    //     0x1292094: ldp             fp, lr, [SP], #0x10
    // 0x1292098: ret
    //     0x1292098: ret             
    // 0x129209c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x129209c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12920a0: b               #0x1292020
  }
  _ complete(/* No info */) {
    // ** addr: 0x12e6070, size: 0x84
    // 0x12e6070: EnterFrame
    //     0x12e6070: stp             fp, lr, [SP, #-0x10]!
    //     0x12e6074: mov             fp, SP
    // 0x12e6078: AllocStack(0x18)
    //     0x12e6078: sub             SP, SP, #0x18
    // 0x12e607c: SetupParameters(ValueResult<X0> this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x12e607c: mov             x4, x1
    //     0x12e6080: mov             x3, x2
    //     0x12e6084: stur            x1, [fp, #-8]
    //     0x12e6088: stur            x2, [fp, #-0x10]
    // 0x12e608c: CheckStackOverflow
    //     0x12e608c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e6090: cmp             SP, x16
    //     0x12e6094: b.ls            #0x12e60ec
    // 0x12e6098: LoadField: r2 = r4->field_7
    //     0x12e6098: ldur            w2, [x4, #7]
    // 0x12e609c: DecompressPointer r2
    //     0x12e609c: add             x2, x2, HEAP, lsl #32
    // 0x12e60a0: mov             x0, x3
    // 0x12e60a4: r1 = Null
    //     0x12e60a4: mov             x1, NULL
    // 0x12e60a8: r8 = Completer<X0>
    //     0x12e60a8: add             x8, PP, #0xcf, lsl #12  ; [pp+0xcf780] Type: Completer<X0>
    //     0x12e60ac: ldr             x8, [x8, #0x780]
    // 0x12e60b0: LoadField: r9 = r8->field_7
    //     0x12e60b0: ldur            x9, [x8, #7]
    // 0x12e60b4: r3 = Null
    //     0x12e60b4: add             x3, PP, #0xcf, lsl #12  ; [pp+0xcf788] Null
    //     0x12e60b8: ldr             x3, [x3, #0x788]
    // 0x12e60bc: blr             x9
    // 0x12e60c0: ldur            x0, [fp, #-8]
    // 0x12e60c4: LoadField: r1 = r0->field_b
    //     0x12e60c4: ldur            w1, [x0, #0xb]
    // 0x12e60c8: DecompressPointer r1
    //     0x12e60c8: add             x1, x1, HEAP, lsl #32
    // 0x12e60cc: str             x1, [SP]
    // 0x12e60d0: ldur            x1, [fp, #-0x10]
    // 0x12e60d4: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x12e60d4: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x12e60d8: r0 = complete()
    //     0x12e60d8: bl              #0x128a5ec  ; [dart:async] _AsyncCompleter::complete
    // 0x12e60dc: r0 = Null
    //     0x12e60dc: mov             x0, NULL
    // 0x12e60e0: LeaveFrame
    //     0x12e60e0: mov             SP, fp
    //     0x12e60e4: ldp             fp, lr, [SP], #0x10
    // 0x12e60e8: ret
    //     0x12e60e8: ret             
    // 0x12e60ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e60ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e60f0: b               #0x12e6098
  }
}
