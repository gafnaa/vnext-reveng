// lib: , url: package:async/src/delegate/stream_sink.dart

// class id: 1048607, size: 0x8
class :: {
}

// class id: 3622, size: 0x10, field offset: 0x8
abstract class DelegatingStreamSink<X0> extends Object
    implements StreamSink<X0> {

  _ add(/* No info */) {
    // ** addr: 0x8d97e0, size: 0x88
    // 0x8d97e0: EnterFrame
    //     0x8d97e0: stp             fp, lr, [SP, #-0x10]!
    //     0x8d97e4: mov             fp, SP
    // 0x8d97e8: AllocStack(0x10)
    //     0x8d97e8: sub             SP, SP, #0x10
    // 0x8d97ec: SetupParameters(DelegatingStreamSink<X0> this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x8d97ec: mov             x4, x1
    //     0x8d97f0: mov             x3, x2
    //     0x8d97f4: stur            x1, [fp, #-8]
    //     0x8d97f8: stur            x2, [fp, #-0x10]
    // 0x8d97fc: CheckStackOverflow
    //     0x8d97fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d9800: cmp             SP, x16
    //     0x8d9804: b.ls            #0x8d9860
    // 0x8d9808: LoadField: r2 = r4->field_7
    //     0x8d9808: ldur            w2, [x4, #7]
    // 0x8d980c: DecompressPointer r2
    //     0x8d980c: add             x2, x2, HEAP, lsl #32
    // 0x8d9810: mov             x0, x3
    // 0x8d9814: r1 = Null
    //     0x8d9814: mov             x1, NULL
    // 0x8d9818: cmp             w2, NULL
    // 0x8d981c: b.eq            #0x8d983c
    // 0x8d9820: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x8d9820: ldur            w4, [x2, #0x17]
    // 0x8d9824: DecompressPointer r4
    //     0x8d9824: add             x4, x4, HEAP, lsl #32
    // 0x8d9828: r8 = X0
    //     0x8d9828: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x8d982c: LoadField: r9 = r4->field_7
    //     0x8d982c: ldur            x9, [x4, #7]
    // 0x8d9830: r3 = Null
    //     0x8d9830: add             x3, PP, #0x7e, lsl #12  ; [pp+0x7ee80] Null
    //     0x8d9834: ldr             x3, [x3, #0xe80]
    // 0x8d9838: blr             x9
    // 0x8d983c: ldur            x0, [fp, #-8]
    // 0x8d9840: LoadField: r1 = r0->field_b
    //     0x8d9840: ldur            w1, [x0, #0xb]
    // 0x8d9844: DecompressPointer r1
    //     0x8d9844: add             x1, x1, HEAP, lsl #32
    // 0x8d9848: ldur            x2, [fp, #-0x10]
    // 0x8d984c: r0 = add()
    //     0x8d984c: bl              #0xa05394  ; [package:stream_channel/src/guarantee_channel.dart] _GuaranteeSink::add
    // 0x8d9850: r0 = Null
    //     0x8d9850: mov             x0, NULL
    // 0x8d9854: LeaveFrame
    //     0x8d9854: mov             SP, fp
    //     0x8d9858: ldp             fp, lr, [SP], #0x10
    // 0x8d985c: ret
    //     0x8d985c: ret             
    // 0x8d9860: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d9860: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d9864: b               #0x8d9808
  }
  [closure] void add(dynamic, Object?) {
    // ** addr: 0x8d9868, size: 0x3c
    // 0x8d9868: EnterFrame
    //     0x8d9868: stp             fp, lr, [SP, #-0x10]!
    //     0x8d986c: mov             fp, SP
    // 0x8d9870: ldr             x0, [fp, #0x18]
    // 0x8d9874: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8d9874: ldur            w1, [x0, #0x17]
    // 0x8d9878: DecompressPointer r1
    //     0x8d9878: add             x1, x1, HEAP, lsl #32
    // 0x8d987c: CheckStackOverflow
    //     0x8d987c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d9880: cmp             SP, x16
    //     0x8d9884: b.ls            #0x8d989c
    // 0x8d9888: ldr             x2, [fp, #0x10]
    // 0x8d988c: r0 = add()
    //     0x8d988c: bl              #0x8d97e0  ; [package:async/src/delegate/stream_sink.dart] DelegatingStreamSink::add
    // 0x8d9890: LeaveFrame
    //     0x8d9890: mov             SP, fp
    //     0x8d9894: ldp             fp, lr, [SP], #0x10
    // 0x8d9898: ret
    //     0x8d9898: ret             
    // 0x8d989c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d989c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d98a0: b               #0x8d9888
  }
  dynamic add(dynamic) {
    // ** addr: 0x8d98a4, size: 0x24
    // 0x8d98a4: EnterFrame
    //     0x8d98a4: stp             fp, lr, [SP, #-0x10]!
    //     0x8d98a8: mov             fp, SP
    // 0x8d98ac: ldr             x2, [fp, #0x10]
    // 0x8d98b0: r1 = Function 'add':.
    //     0x8d98b0: add             x1, PP, #0x7e, lsl #12  ; [pp+0x7ee68] AnonymousClosure: (0x8d9868), in [package:async/src/delegate/stream_sink.dart] DelegatingStreamSink::add (0x8d97e0)
    //     0x8d98b4: ldr             x1, [x1, #0xe68]
    // 0x8d98b8: r0 = AllocateClosure()
    //     0x8d98b8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8d98bc: LeaveFrame
    //     0x8d98bc: mov             SP, fp
    //     0x8d98c0: ldp             fp, lr, [SP], #0x10
    // 0x8d98c4: ret
    //     0x8d98c4: ret             
  }
  _ close(/* No info */) {
    // ** addr: 0x8dd2b8, size: 0x38
    // 0x8dd2b8: EnterFrame
    //     0x8dd2b8: stp             fp, lr, [SP, #-0x10]!
    //     0x8dd2bc: mov             fp, SP
    // 0x8dd2c0: CheckStackOverflow
    //     0x8dd2c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8dd2c4: cmp             SP, x16
    //     0x8dd2c8: b.ls            #0x8dd2e8
    // 0x8dd2cc: LoadField: r0 = r1->field_b
    //     0x8dd2cc: ldur            w0, [x1, #0xb]
    // 0x8dd2d0: DecompressPointer r0
    //     0x8dd2d0: add             x0, x0, HEAP, lsl #32
    // 0x8dd2d4: mov             x1, x0
    // 0x8dd2d8: r0 = close()
    //     0x8dd2d8: bl              #0xa07344  ; [package:stream_channel/src/guarantee_channel.dart] _GuaranteeSink::close
    // 0x8dd2dc: LeaveFrame
    //     0x8dd2dc: mov             SP, fp
    //     0x8dd2e0: ldp             fp, lr, [SP], #0x10
    // 0x8dd2e4: ret
    //     0x8dd2e4: ret             
    // 0x8dd2e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8dd2e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8dd2ec: b               #0x8dd2cc
  }
  _ addError(/* No info */) {
    // ** addr: 0x9fab30, size: 0x68
    // 0x9fab30: EnterFrame
    //     0x9fab30: stp             fp, lr, [SP, #-0x10]!
    //     0x9fab34: mov             fp, SP
    // 0x9fab38: AllocStack(0x8)
    //     0x9fab38: sub             SP, SP, #8
    // 0x9fab3c: SetupParameters([dynamic _ = Null /* r0 */])
    //     0x9fab3c: ldur            w0, [x4, #0x13]
    //     0x9fab40: sub             x3, x0, #4
    //     0x9fab44: cmp             w3, #2
    //     0x9fab48: b.lt            #0x9fab58
    //     0x9fab4c: add             x0, fp, w3, sxtw #2
    //     0x9fab50: ldr             x0, [x0, #8]
    //     0x9fab54: b               #0x9fab5c
    //     0x9fab58: mov             x0, NULL
    // 0x9fab5c: CheckStackOverflow
    //     0x9fab5c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9fab60: cmp             SP, x16
    //     0x9fab64: b.ls            #0x9fab90
    // 0x9fab68: LoadField: r3 = r1->field_b
    //     0x9fab68: ldur            w3, [x1, #0xb]
    // 0x9fab6c: DecompressPointer r3
    //     0x9fab6c: add             x3, x3, HEAP, lsl #32
    // 0x9fab70: str             x0, [SP]
    // 0x9fab74: mov             x1, x3
    // 0x9fab78: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x9fab78: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x9fab7c: r0 = addError()
    //     0x9fab7c: bl              #0xa0c25c  ; [package:stream_channel/src/guarantee_channel.dart] _GuaranteeSink::addError
    // 0x9fab80: r0 = Null
    //     0x9fab80: mov             x0, NULL
    // 0x9fab84: LeaveFrame
    //     0x9fab84: mov             SP, fp
    //     0x9fab88: ldp             fp, lr, [SP], #0x10
    // 0x9fab8c: ret
    //     0x9fab8c: ret             
    // 0x9fab90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9fab90: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9fab94: b               #0x9fab68
  }
  [closure] void addError(dynamic, Object, [StackTrace?]) {
    // ** addr: 0x9fab98, size: 0x78
    // 0x9fab98: EnterFrame
    //     0x9fab98: stp             fp, lr, [SP, #-0x10]!
    //     0x9fab9c: mov             fp, SP
    // 0x9faba0: AllocStack(0x8)
    //     0x9faba0: sub             SP, SP, #8
    // 0x9faba4: SetupParameters(DelegatingStreamSink<X0> this /* r0 */, dynamic _ /* r2 */, [dynamic _ = Null /* r1 */])
    //     0x9faba4: ldur            w0, [x4, #0x13]
    //     0x9faba8: sub             x1, x0, #4
    //     0x9fabac: add             x0, fp, w1, sxtw #2
    //     0x9fabb0: ldr             x0, [x0, #0x18]
    //     0x9fabb4: add             x2, fp, w1, sxtw #2
    //     0x9fabb8: ldr             x2, [x2, #0x10]
    //     0x9fabbc: cmp             w1, #2
    //     0x9fabc0: b.lt            #0x9fabd4
    //     0x9fabc4: add             x3, fp, w1, sxtw #2
    //     0x9fabc8: ldr             x3, [x3, #8]
    //     0x9fabcc: mov             x1, x3
    //     0x9fabd0: b               #0x9fabd8
    //     0x9fabd4: mov             x1, NULL
    //     0x9fabd8: ldur            w3, [x0, #0x17]
    //     0x9fabdc: add             x3, x3, HEAP, lsl #32
    // 0x9fabe0: CheckStackOverflow
    //     0x9fabe0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9fabe4: cmp             SP, x16
    //     0x9fabe8: b.ls            #0x9fac08
    // 0x9fabec: str             x1, [SP]
    // 0x9fabf0: mov             x1, x3
    // 0x9fabf4: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x9fabf4: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x9fabf8: r0 = addError()
    //     0x9fabf8: bl              #0x9fab30  ; [package:async/src/delegate/stream_sink.dart] DelegatingStreamSink::addError
    // 0x9fabfc: LeaveFrame
    //     0x9fabfc: mov             SP, fp
    //     0x9fac00: ldp             fp, lr, [SP], #0x10
    // 0x9fac04: ret
    //     0x9fac04: ret             
    // 0x9fac08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9fac08: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9fac0c: b               #0x9fabec
  }
  dynamic addError(dynamic) {
    // ** addr: 0xa0bc64, size: 0x24
    // 0xa0bc64: EnterFrame
    //     0xa0bc64: stp             fp, lr, [SP, #-0x10]!
    //     0xa0bc68: mov             fp, SP
    // 0xa0bc6c: ldr             x2, [fp, #0x10]
    // 0xa0bc70: r1 = Function 'addError':.
    //     0xa0bc70: add             x1, PP, #0x8b, lsl #12  ; [pp+0x8b050] AnonymousClosure: (0x9fab98), in [package:async/src/delegate/stream_sink.dart] DelegatingStreamSink::addError (0x9fab30)
    //     0xa0bc74: ldr             x1, [x1, #0x50]
    // 0xa0bc78: r0 = AllocateClosure()
    //     0xa0bc78: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xa0bc7c: LeaveFrame
    //     0xa0bc7c: mov             SP, fp
    //     0xa0bc80: ldp             fp, lr, [SP], #0x10
    // 0xa0bc84: ret
    //     0xa0bc84: ret             
  }
  _ addStream(/* No info */) {
    // ** addr: 0xa0c1c4, size: 0x74
    // 0xa0c1c4: EnterFrame
    //     0xa0c1c4: stp             fp, lr, [SP, #-0x10]!
    //     0xa0c1c8: mov             fp, SP
    // 0xa0c1cc: AllocStack(0x10)
    //     0xa0c1cc: sub             SP, SP, #0x10
    // 0xa0c1d0: SetupParameters(DelegatingStreamSink<X0> this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xa0c1d0: mov             x4, x1
    //     0xa0c1d4: mov             x3, x2
    //     0xa0c1d8: stur            x1, [fp, #-8]
    //     0xa0c1dc: stur            x2, [fp, #-0x10]
    // 0xa0c1e0: CheckStackOverflow
    //     0xa0c1e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xa0c1e4: cmp             SP, x16
    //     0xa0c1e8: b.ls            #0xa0c230
    // 0xa0c1ec: LoadField: r2 = r4->field_7
    //     0xa0c1ec: ldur            w2, [x4, #7]
    // 0xa0c1f0: DecompressPointer r2
    //     0xa0c1f0: add             x2, x2, HEAP, lsl #32
    // 0xa0c1f4: mov             x0, x3
    // 0xa0c1f8: r1 = Null
    //     0xa0c1f8: mov             x1, NULL
    // 0xa0c1fc: r8 = Stream<X0>
    //     0xa0c1fc: ldr             x8, [PP, #0x73f8]  ; [pp+0x73f8] Type: Stream<X0>
    // 0xa0c200: LoadField: r9 = r8->field_7
    //     0xa0c200: ldur            x9, [x8, #7]
    // 0xa0c204: r3 = Null
    //     0xa0c204: add             x3, PP, #0x7e, lsl #12  ; [pp+0x7ee70] Null
    //     0xa0c208: ldr             x3, [x3, #0xe70]
    // 0xa0c20c: blr             x9
    // 0xa0c210: ldur            x0, [fp, #-8]
    // 0xa0c214: LoadField: r1 = r0->field_b
    //     0xa0c214: ldur            w1, [x0, #0xb]
    // 0xa0c218: DecompressPointer r1
    //     0xa0c218: add             x1, x1, HEAP, lsl #32
    // 0xa0c21c: ldur            x2, [fp, #-0x10]
    // 0xa0c220: r0 = addStream()
    //     0xa0c220: bl              #0xa107d8  ; [package:stream_channel/src/guarantee_channel.dart] _GuaranteeSink::addStream
    // 0xa0c224: LeaveFrame
    //     0xa0c224: mov             SP, fp
    //     0xa0c228: ldp             fp, lr, [SP], #0x10
    // 0xa0c22c: ret
    //     0xa0c22c: ret             
    // 0xa0c230: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0c230: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0c234: b               #0xa0c1ec
  }
}
