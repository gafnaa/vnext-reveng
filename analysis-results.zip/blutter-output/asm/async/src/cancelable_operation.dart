// lib: , url: package:async/src/cancelable_operation.dart

// class id: 1048606, size: 0x8
class :: {
}

// class id: 3625, size: 0x24, field offset: 0x8
class CancelableCompleter<X0> extends Object {

  late final CancelableOperation<X0> operation; // offset: 0x20

  _ complete(/* No info */) {
    // ** addr: 0x8f51fc, size: 0x1d4
    // 0x8f51fc: EnterFrame
    //     0x8f51fc: stp             fp, lr, [SP, #-0x10]!
    //     0x8f5200: mov             fp, SP
    // 0x8f5204: AllocStack(0x40)
    //     0x8f5204: sub             SP, SP, #0x40
    // 0x8f5208: SetupParameters(CancelableCompleter<X0> this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x8f5208: mov             x0, x2
    //     0x8f520c: stur            x1, [fp, #-8]
    //     0x8f5210: stur            x2, [fp, #-0x10]
    // 0x8f5214: CheckStackOverflow
    //     0x8f5214: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f5218: cmp             SP, x16
    //     0x8f521c: b.ls            #0x8f53c8
    // 0x8f5220: r1 = 1
    //     0x8f5220: mov             x1, #1
    // 0x8f5224: r0 = AllocateContext()
    //     0x8f5224: bl              #0x13de838  ; AllocateContextStub
    // 0x8f5228: mov             x4, x0
    // 0x8f522c: ldur            x3, [fp, #-8]
    // 0x8f5230: stur            x4, [fp, #-0x20]
    // 0x8f5234: StoreField: r4->field_f = r3
    //     0x8f5234: stur            w3, [x4, #0xf]
    // 0x8f5238: LoadField: r5 = r3->field_7
    //     0x8f5238: ldur            w5, [x3, #7]
    // 0x8f523c: DecompressPointer r5
    //     0x8f523c: add             x5, x5, HEAP, lsl #32
    // 0x8f5240: ldur            x0, [fp, #-0x10]
    // 0x8f5244: mov             x2, x5
    // 0x8f5248: stur            x5, [fp, #-0x18]
    // 0x8f524c: r1 = Null
    //     0x8f524c: mov             x1, NULL
    // 0x8f5250: r8 = FutureOr<X0>?
    //     0x8f5250: ldr             x8, [PP, #0xa90]  ; [pp+0xa90] Type: FutureOr<X0>?
    // 0x8f5254: LoadField: r9 = r8->field_7
    //     0x8f5254: ldur            x9, [x8, #7]
    // 0x8f5258: r3 = Null
    //     0x8f5258: add             x3, PP, #0x16, lsl #12  ; [pp+0x16418] Null
    //     0x8f525c: ldr             x3, [x3, #0x418]
    // 0x8f5260: blr             x9
    // 0x8f5264: ldur            x3, [fp, #-8]
    // 0x8f5268: LoadField: r0 = r3->field_1b
    //     0x8f5268: ldur            w0, [x3, #0x1b]
    // 0x8f526c: DecompressPointer r0
    //     0x8f526c: add             x0, x0, HEAP, lsl #32
    // 0x8f5270: tbnz            w0, #4, #0x8f53a8
    // 0x8f5274: r0 = false
    //     0x8f5274: add             x0, NULL, #0x30  ; false
    // 0x8f5278: StoreField: r3->field_1b = r0
    //     0x8f5278: stur            w0, [x3, #0x1b]
    // 0x8f527c: ldur            x0, [fp, #-0x10]
    // 0x8f5280: ldur            x2, [fp, #-0x18]
    // 0x8f5284: r1 = Null
    //     0x8f5284: mov             x1, NULL
    // 0x8f5288: cmp             w0, NULL
    // 0x8f528c: b.eq            #0x8f52d8
    // 0x8f5290: branchIfSmi(r0, 0x8f52d8)
    //     0x8f5290: tbz             w0, #0, #0x8f52d8
    // 0x8f5294: r3 = SubtypeTestCache
    //     0x8f5294: add             x3, PP, #0x16, lsl #12  ; [pp+0x16428] SubtypeTestCache
    //     0x8f5298: ldr             x3, [x3, #0x428]
    // 0x8f529c: r30 = Subtype3TestCacheStub
    //     0x8f529c: ldr             lr, [PP, #0x28]  ; [pp+0x28] Stub: Subtype3TestCache (0x7d2c74)
    // 0x8f52a0: LoadField: r30 = r30->field_7
    //     0x8f52a0: ldur            lr, [lr, #7]
    // 0x8f52a4: blr             lr
    // 0x8f52a8: cmp             w7, NULL
    // 0x8f52ac: b.eq            #0x8f52b8
    // 0x8f52b0: tbnz            w7, #4, #0x8f52d8
    // 0x8f52b4: b               #0x8f52e0
    // 0x8f52b8: r8 = Future<X0>
    //     0x8f52b8: add             x8, PP, #0x16, lsl #12  ; [pp+0x16430] Type: Future<X0>
    //     0x8f52bc: ldr             x8, [x8, #0x430]
    // 0x8f52c0: r3 = SubtypeTestCache
    //     0x8f52c0: add             x3, PP, #0x16, lsl #12  ; [pp+0x16438] SubtypeTestCache
    //     0x8f52c4: ldr             x3, [x3, #0x438]
    // 0x8f52c8: r30 = InstanceOfStub
    //     0x8f52c8: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x8f52cc: LoadField: r30 = r30->field_7
    //     0x8f52cc: ldur            lr, [lr, #7]
    // 0x8f52d0: blr             lr
    // 0x8f52d4: b               #0x8f52e4
    // 0x8f52d8: r0 = false
    //     0x8f52d8: add             x0, NULL, #0x30  ; false
    // 0x8f52dc: b               #0x8f52e4
    // 0x8f52e0: r0 = true
    //     0x8f52e0: add             x0, NULL, #0x20  ; true
    // 0x8f52e4: tbz             w0, #4, #0x8f531c
    // 0x8f52e8: ldur            x1, [fp, #-8]
    // 0x8f52ec: r0 = _completeNow()
    //     0x8f52ec: bl              #0x8f5554  ; [package:async/src/cancelable_operation.dart] CancelableCompleter::_completeNow
    // 0x8f52f0: cmp             w0, NULL
    // 0x8f52f4: b.eq            #0x8f530c
    // 0x8f52f8: ldur            x16, [fp, #-0x10]
    // 0x8f52fc: str             x16, [SP]
    // 0x8f5300: mov             x1, x0
    // 0x8f5304: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x8f5304: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x8f5308: r0 = complete()
    //     0x8f5308: bl              #0x128a5ec  ; [dart:async] _AsyncCompleter::complete
    // 0x8f530c: r0 = Null
    //     0x8f530c: mov             x0, NULL
    // 0x8f5310: LeaveFrame
    //     0x8f5310: mov             SP, fp
    //     0x8f5314: ldp             fp, lr, [SP], #0x10
    // 0x8f5318: ret
    //     0x8f5318: ret             
    // 0x8f531c: ldur            x0, [fp, #-8]
    // 0x8f5320: LoadField: r1 = r0->field_b
    //     0x8f5320: ldur            w1, [x0, #0xb]
    // 0x8f5324: DecompressPointer r1
    //     0x8f5324: add             x1, x1, HEAP, lsl #32
    // 0x8f5328: cmp             w1, NULL
    // 0x8f532c: b.ne            #0x8f5354
    // 0x8f5330: ldur            x16, [fp, #-0x18]
    // 0x8f5334: ldur            lr, [fp, #-0x10]
    // 0x8f5338: stp             lr, x16, [SP]
    // 0x8f533c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8f533c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8f5340: r0 = FutureExtensions.ignore()
    //     0x8f5340: bl              #0x8f53d0  ; [dart:async] ::FutureExtensions.ignore
    // 0x8f5344: r0 = Null
    //     0x8f5344: mov             x0, NULL
    // 0x8f5348: LeaveFrame
    //     0x8f5348: mov             SP, fp
    //     0x8f534c: ldp             fp, lr, [SP], #0x10
    // 0x8f5350: ret
    //     0x8f5350: ret             
    // 0x8f5354: ldur            x2, [fp, #-0x20]
    // 0x8f5358: ldur            x3, [fp, #-0x18]
    // 0x8f535c: r1 = Function '<anonymous closure>':.
    //     0x8f535c: add             x1, PP, #0x16, lsl #12  ; [pp+0x16440] AnonymousClosure: (0x8f55e0), in [package:async/src/cancelable_operation.dart] CancelableCompleter::complete (0x8f51fc)
    //     0x8f5360: ldr             x1, [x1, #0x440]
    // 0x8f5364: r0 = AllocateClosureTA()
    //     0x8f5364: bl              #0x13dea48  ; AllocateClosureTAStub
    // 0x8f5368: ldur            x2, [fp, #-0x20]
    // 0x8f536c: r1 = Function '<anonymous closure>':.
    //     0x8f536c: add             x1, PP, #0x16, lsl #12  ; [pp+0x16448] AnonymousClosure: (0x8f5574), in [package:async/src/cancelable_operation.dart] CancelableCompleter::complete (0x8f51fc)
    //     0x8f5370: ldr             x1, [x1, #0x448]
    // 0x8f5374: stur            x0, [fp, #-8]
    // 0x8f5378: r0 = AllocateClosure()
    //     0x8f5378: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8f537c: r16 = <Null?>
    //     0x8f537c: ldr             x16, [PP, #0x70]  ; [pp+0x70] TypeArguments: <Null?>
    // 0x8f5380: ldur            lr, [fp, #-0x10]
    // 0x8f5384: stp             lr, x16, [SP, #0x10]
    // 0x8f5388: ldur            x16, [fp, #-8]
    // 0x8f538c: stp             x0, x16, [SP]
    // 0x8f5390: r4 = const [0x1, 0x3, 0x3, 0x2, onError, 0x2, null]
    //     0x8f5390: ldr             x4, [PP, #0x538]  ; [pp+0x538] List(7) [0x1, 0x3, 0x3, 0x2, "onError", 0x2, Null]
    // 0x8f5394: r0 = then()
    //     0x8f5394: bl              #0x1293070  ; [dart:async] _Future::then
    // 0x8f5398: r0 = Null
    //     0x8f5398: mov             x0, NULL
    // 0x8f539c: LeaveFrame
    //     0x8f539c: mov             SP, fp
    //     0x8f53a0: ldp             fp, lr, [SP], #0x10
    // 0x8f53a4: ret
    //     0x8f53a4: ret             
    // 0x8f53a8: r0 = StateError()
    //     0x8f53a8: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x8f53ac: mov             x1, x0
    // 0x8f53b0: r0 = "Operation already completed"
    //     0x8f53b0: add             x0, PP, #0x16, lsl #12  ; [pp+0x16450] "Operation already completed"
    //     0x8f53b4: ldr             x0, [x0, #0x450]
    // 0x8f53b8: StoreField: r1->field_b = r0
    //     0x8f53b8: stur            w0, [x1, #0xb]
    // 0x8f53bc: mov             x0, x1
    // 0x8f53c0: r0 = Throw()
    //     0x8f53c0: bl              #0x13ddb2c  ; ThrowStub
    // 0x8f53c4: brk             #0
    // 0x8f53c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f53c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f53cc: b               #0x8f5220
  }
  _ _completeNow(/* No info */) {
    // ** addr: 0x8f5554, size: 0x20
    // 0x8f5554: LoadField: r0 = r1->field_b
    //     0x8f5554: ldur            w0, [x1, #0xb]
    // 0x8f5558: DecompressPointer r0
    //     0x8f5558: add             x0, x0, HEAP, lsl #32
    // 0x8f555c: cmp             w0, NULL
    // 0x8f5560: b.ne            #0x8f556c
    // 0x8f5564: r0 = Null
    //     0x8f5564: mov             x0, NULL
    // 0x8f5568: ret
    //     0x8f5568: ret             
    // 0x8f556c: StoreField: r1->field_f = rNULL
    //     0x8f556c: stur            NULL, [x1, #0xf]
    // 0x8f5570: ret
    //     0x8f5570: ret             
  }
  [closure] Null <anonymous closure>(dynamic, Object, StackTrace) {
    // ** addr: 0x8f5574, size: 0x6c
    // 0x8f5574: EnterFrame
    //     0x8f5574: stp             fp, lr, [SP, #-0x10]!
    //     0x8f5578: mov             fp, SP
    // 0x8f557c: AllocStack(0x8)
    //     0x8f557c: sub             SP, SP, #8
    // 0x8f5580: SetupParameters([dynamic _ /* r0 */])
    //     0x8f5580: ldr             x0, [fp, #0x20]
    //     0x8f5584: ldur            w1, [x0, #0x17]
    //     0x8f5588: add             x1, x1, HEAP, lsl #32
    // 0x8f558c: CheckStackOverflow
    //     0x8f558c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f5590: cmp             SP, x16
    //     0x8f5594: b.ls            #0x8f55d8
    // 0x8f5598: LoadField: r0 = r1->field_f
    //     0x8f5598: ldur            w0, [x1, #0xf]
    // 0x8f559c: DecompressPointer r0
    //     0x8f559c: add             x0, x0, HEAP, lsl #32
    // 0x8f55a0: mov             x1, x0
    // 0x8f55a4: r0 = _completeNow()
    //     0x8f55a4: bl              #0x8f5554  ; [package:async/src/cancelable_operation.dart] CancelableCompleter::_completeNow
    // 0x8f55a8: cmp             w0, NULL
    // 0x8f55ac: b.eq            #0x8f55c8
    // 0x8f55b0: ldr             x16, [fp, #0x10]
    // 0x8f55b4: str             x16, [SP]
    // 0x8f55b8: mov             x1, x0
    // 0x8f55bc: ldr             x2, [fp, #0x18]
    // 0x8f55c0: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x8f55c0: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x8f55c4: r0 = completeError()
    //     0x8f55c4: bl              #0x7f6b94  ; [dart:async] _Completer::completeError
    // 0x8f55c8: r0 = Null
    //     0x8f55c8: mov             x0, NULL
    // 0x8f55cc: LeaveFrame
    //     0x8f55cc: mov             SP, fp
    //     0x8f55d0: ldp             fp, lr, [SP], #0x10
    // 0x8f55d4: ret
    //     0x8f55d4: ret             
    // 0x8f55d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f55d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f55dc: b               #0x8f5598
  }
  [closure] Null <anonymous closure>(dynamic, X0) {
    // ** addr: 0x8f55e0, size: 0x68
    // 0x8f55e0: EnterFrame
    //     0x8f55e0: stp             fp, lr, [SP, #-0x10]!
    //     0x8f55e4: mov             fp, SP
    // 0x8f55e8: AllocStack(0x8)
    //     0x8f55e8: sub             SP, SP, #8
    // 0x8f55ec: SetupParameters([dynamic _ /* r0 */])
    //     0x8f55ec: ldr             x0, [fp, #0x18]
    //     0x8f55f0: ldur            w1, [x0, #0x17]
    //     0x8f55f4: add             x1, x1, HEAP, lsl #32
    // 0x8f55f8: CheckStackOverflow
    //     0x8f55f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f55fc: cmp             SP, x16
    //     0x8f5600: b.ls            #0x8f5640
    // 0x8f5604: LoadField: r0 = r1->field_f
    //     0x8f5604: ldur            w0, [x1, #0xf]
    // 0x8f5608: DecompressPointer r0
    //     0x8f5608: add             x0, x0, HEAP, lsl #32
    // 0x8f560c: mov             x1, x0
    // 0x8f5610: r0 = _completeNow()
    //     0x8f5610: bl              #0x8f5554  ; [package:async/src/cancelable_operation.dart] CancelableCompleter::_completeNow
    // 0x8f5614: cmp             w0, NULL
    // 0x8f5618: b.eq            #0x8f5630
    // 0x8f561c: ldr             x16, [fp, #0x10]
    // 0x8f5620: str             x16, [SP]
    // 0x8f5624: mov             x1, x0
    // 0x8f5628: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x8f5628: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x8f562c: r0 = complete()
    //     0x8f562c: bl              #0x128a5ec  ; [dart:async] _AsyncCompleter::complete
    // 0x8f5630: r0 = Null
    //     0x8f5630: mov             x0, NULL
    // 0x8f5634: LeaveFrame
    //     0x8f5634: mov             SP, fp
    //     0x8f5638: ldp             fp, lr, [SP], #0x10
    // 0x8f563c: ret
    //     0x8f563c: ret             
    // 0x8f5640: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f5640: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f5644: b               #0x8f5604
  }
  _ CancelableCompleter(/* No info */) {
    // ** addr: 0x8f5648, size: 0x110
    // 0x8f5648: EnterFrame
    //     0x8f5648: stp             fp, lr, [SP, #-0x10]!
    //     0x8f564c: mov             fp, SP
    // 0x8f5650: AllocStack(0x20)
    //     0x8f5650: sub             SP, SP, #0x20
    // 0x8f5654: r2 = true
    //     0x8f5654: add             x2, NULL, #0x20  ; true
    // 0x8f5658: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x8f565c: mov             x3, x1
    // 0x8f5660: stur            x1, [fp, #-0x10]
    // 0x8f5664: CheckStackOverflow
    //     0x8f5664: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f5668: cmp             SP, x16
    //     0x8f566c: b.ls            #0x8f5750
    // 0x8f5670: StoreField: r3->field_1b = r2
    //     0x8f5670: stur            w2, [x3, #0x1b]
    // 0x8f5674: StoreField: r3->field_1f = r0
    //     0x8f5674: stur            w0, [x3, #0x1f]
    // 0x8f5678: LoadField: r0 = r3->field_7
    //     0x8f5678: ldur            w0, [x3, #7]
    // 0x8f567c: DecompressPointer r0
    //     0x8f567c: add             x0, x0, HEAP, lsl #32
    // 0x8f5680: mov             x1, x0
    // 0x8f5684: stur            x0, [fp, #-8]
    // 0x8f5688: r0 = _Future()
    //     0x8f5688: bl              #0x7f5dd4  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0x8f568c: stur            x0, [fp, #-0x18]
    // 0x8f5690: StoreField: r0->field_b = rZR
    //     0x8f5690: stur            xzr, [x0, #0xb]
    // 0x8f5694: r0 = LoadStaticField(0x364)
    //     0x8f5694: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8f5698: ldr             x0, [x0, #0x6c8]
    // 0x8f569c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8f56a0: cmp             w0, w16
    // 0x8f56a4: b.ne            #0x8f56b0
    // 0x8f56a8: r2 = _current
    //     0x8f56a8: ldr             x2, [PP, #0x2c0]  ; [pp+0x2c0] Field <Zone._current@5048458>: static late (offset: 0x364)
    // 0x8f56ac: r0 = InitLateStaticField()
    //     0x8f56ac: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0x8f56b0: mov             x2, x0
    // 0x8f56b4: ldur            x0, [fp, #-0x18]
    // 0x8f56b8: stur            x2, [fp, #-0x20]
    // 0x8f56bc: StoreField: r0->field_13 = r2
    //     0x8f56bc: stur            w2, [x0, #0x13]
    // 0x8f56c0: ldur            x1, [fp, #-8]
    // 0x8f56c4: r0 = _AsyncCompleter()
    //     0x8f56c4: bl              #0x7f5dc8  ; Allocate_AsyncCompleterStub -> _AsyncCompleter<X0> (size=0x10)
    // 0x8f56c8: mov             x1, x0
    // 0x8f56cc: ldur            x0, [fp, #-0x18]
    // 0x8f56d0: StoreField: r1->field_b = r0
    //     0x8f56d0: stur            w0, [x1, #0xb]
    // 0x8f56d4: mov             x0, x1
    // 0x8f56d8: ldur            x2, [fp, #-0x10]
    // 0x8f56dc: StoreField: r2->field_b = r0
    //     0x8f56dc: stur            w0, [x2, #0xb]
    //     0x8f56e0: ldurb           w16, [x2, #-1]
    //     0x8f56e4: ldurb           w17, [x0, #-1]
    //     0x8f56e8: and             x16, x17, x16, lsr #2
    //     0x8f56ec: tst             x16, HEAP, lsr #32
    //     0x8f56f0: b.eq            #0x8f56f8
    //     0x8f56f4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x8f56f8: r1 = <Object?>
    //     0x8f56f8: ldr             x1, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0x8f56fc: r0 = _Future()
    //     0x8f56fc: bl              #0x7f5dd4  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0x8f5700: stur            x0, [fp, #-8]
    // 0x8f5704: StoreField: r0->field_b = rZR
    //     0x8f5704: stur            xzr, [x0, #0xb]
    // 0x8f5708: ldur            x1, [fp, #-0x20]
    // 0x8f570c: StoreField: r0->field_13 = r1
    //     0x8f570c: stur            w1, [x0, #0x13]
    // 0x8f5710: r1 = <Object?>
    //     0x8f5710: ldr             x1, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0x8f5714: r0 = _AsyncCompleter()
    //     0x8f5714: bl              #0x7f5dc8  ; Allocate_AsyncCompleterStub -> _AsyncCompleter<X0> (size=0x10)
    // 0x8f5718: ldur            x1, [fp, #-8]
    // 0x8f571c: StoreField: r0->field_b = r1
    //     0x8f571c: stur            w1, [x0, #0xb]
    // 0x8f5720: ldur            x1, [fp, #-0x10]
    // 0x8f5724: StoreField: r1->field_f = r0
    //     0x8f5724: stur            w0, [x1, #0xf]
    //     0x8f5728: ldurb           w16, [x1, #-1]
    //     0x8f572c: ldurb           w17, [x0, #-1]
    //     0x8f5730: and             x16, x17, x16, lsr #2
    //     0x8f5734: tst             x16, HEAP, lsr #32
    //     0x8f5738: b.eq            #0x8f5740
    //     0x8f573c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8f5740: r0 = Null
    //     0x8f5740: mov             x0, NULL
    // 0x8f5744: LeaveFrame
    //     0x8f5744: mov             SP, fp
    //     0x8f5748: ldp             fp, lr, [SP], #0x10
    // 0x8f574c: ret
    //     0x8f574c: ret             
    // 0x8f5750: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f5750: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f5754: b               #0x8f5670
  }
  CancelableOperation<X0> operation(CancelableCompleter<X0>) {
    // ** addr: 0x8f5764, size: 0x2c
    // 0x8f5764: EnterFrame
    //     0x8f5764: stp             fp, lr, [SP, #-0x10]!
    //     0x8f5768: mov             fp, SP
    // 0x8f576c: ldr             x0, [fp, #0x10]
    // 0x8f5770: LoadField: r1 = r0->field_7
    //     0x8f5770: ldur            w1, [x0, #7]
    // 0x8f5774: DecompressPointer r1
    //     0x8f5774: add             x1, x1, HEAP, lsl #32
    // 0x8f5778: r0 = CancelableOperation()
    //     0x8f5778: bl              #0x8f5790  ; AllocateCancelableOperationStub -> CancelableOperation<X0> (size=0x10)
    // 0x8f577c: ldr             x1, [fp, #0x10]
    // 0x8f5780: StoreField: r0->field_b = r1
    //     0x8f5780: stur            w1, [x0, #0xb]
    // 0x8f5784: LeaveFrame
    //     0x8f5784: mov             SP, fp
    //     0x8f5788: ldp             fp, lr, [SP], #0x10
    // 0x8f578c: ret
    //     0x8f578c: ret             
  }
  _ _cancel(/* No info */) {
    // ** addr: 0xce6df0, size: 0xc8
    // 0xce6df0: EnterFrame
    //     0xce6df0: stp             fp, lr, [SP, #-0x10]!
    //     0xce6df4: mov             fp, SP
    // 0xce6df8: AllocStack(0x18)
    //     0xce6df8: sub             SP, SP, #0x18
    // 0xce6dfc: CheckStackOverflow
    //     0xce6dfc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce6e00: cmp             SP, x16
    //     0xce6e04: b.ls            #0xce6eb0
    // 0xce6e08: LoadField: r0 = r1->field_f
    //     0xce6e08: ldur            w0, [x1, #0xf]
    // 0xce6e0c: DecompressPointer r0
    //     0xce6e0c: add             x0, x0, HEAP, lsl #32
    // 0xce6e10: stur            x0, [fp, #-0x10]
    // 0xce6e14: cmp             w0, NULL
    // 0xce6e18: b.ne            #0xce6e70
    // 0xce6e1c: r1 = <void?>
    //     0xce6e1c: ldr             x1, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xce6e20: r0 = _Future()
    //     0xce6e20: bl              #0x7f5dd4  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0xce6e24: stur            x0, [fp, #-8]
    // 0xce6e28: StoreField: r0->field_b = rZR
    //     0xce6e28: stur            xzr, [x0, #0xb]
    // 0xce6e2c: r0 = LoadStaticField(0x364)
    //     0xce6e2c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xce6e30: ldr             x0, [x0, #0x6c8]
    // 0xce6e34: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xce6e38: cmp             w0, w16
    // 0xce6e3c: b.ne            #0xce6e48
    // 0xce6e40: r2 = _current
    //     0xce6e40: ldr             x2, [PP, #0x2c0]  ; [pp+0x2c0] Field <Zone._current@5048458>: static late (offset: 0x364)
    // 0xce6e44: r0 = InitLateStaticField()
    //     0xce6e44: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0xce6e48: mov             x1, x0
    // 0xce6e4c: ldur            x0, [fp, #-8]
    // 0xce6e50: StoreField: r0->field_13 = r1
    //     0xce6e50: stur            w1, [x0, #0x13]
    // 0xce6e54: mov             x1, x0
    // 0xce6e58: r2 = Null
    //     0xce6e58: mov             x2, NULL
    // 0xce6e5c: r0 = _asyncComplete()
    //     0xce6e5c: bl              #0x7eee44  ; [dart:async] _Future::_asyncComplete
    // 0xce6e60: ldur            x0, [fp, #-8]
    // 0xce6e64: LeaveFrame
    //     0xce6e64: mov             SP, fp
    //     0xce6e68: ldp             fp, lr, [SP], #0x10
    // 0xce6e6c: ret
    //     0xce6e6c: ret             
    // 0xce6e70: LoadField: r2 = r1->field_b
    //     0xce6e70: ldur            w2, [x1, #0xb]
    // 0xce6e74: DecompressPointer r2
    //     0xce6e74: add             x2, x2, HEAP, lsl #32
    // 0xce6e78: cmp             w2, NULL
    // 0xce6e7c: b.eq            #0xce6e98
    // 0xce6e80: StoreField: r1->field_b = rNULL
    //     0xce6e80: stur            NULL, [x1, #0xb]
    // 0xce6e84: r0 = _invokeCancelCallbacks()
    //     0xce6e84: bl              #0xce6eb8  ; [package:async/src/cancelable_operation.dart] CancelableCompleter::_invokeCancelCallbacks
    // 0xce6e88: str             x0, [SP]
    // 0xce6e8c: ldur            x1, [fp, #-0x10]
    // 0xce6e90: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0xce6e90: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0xce6e94: r0 = complete()
    //     0xce6e94: bl              #0x128a5ec  ; [dart:async] _AsyncCompleter::complete
    // 0xce6e98: ldur            x1, [fp, #-0x10]
    // 0xce6e9c: LoadField: r0 = r1->field_b
    //     0xce6e9c: ldur            w0, [x1, #0xb]
    // 0xce6ea0: DecompressPointer r0
    //     0xce6ea0: add             x0, x0, HEAP, lsl #32
    // 0xce6ea4: LeaveFrame
    //     0xce6ea4: mov             SP, fp
    //     0xce6ea8: ldp             fp, lr, [SP], #0x10
    // 0xce6eac: ret
    //     0xce6eac: ret             
    // 0xce6eb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce6eb0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce6eb4: b               #0xce6e08
  }
  _ _invokeCancelCallbacks(/* No info */) async {
    // ** addr: 0xce6eb8, size: 0x6c
    // 0xce6eb8: EnterFrame
    //     0xce6eb8: stp             fp, lr, [SP, #-0x10]!
    //     0xce6ebc: mov             fp, SP
    // 0xce6ec0: AllocStack(0x20)
    //     0xce6ec0: sub             SP, SP, #0x20
    // 0xce6ec4: SetupParameters(CancelableCompleter<X0> this /* r1 => r1, fp-0x10 */)
    //     0xce6ec4: stur            NULL, [fp, #-8]
    //     0xce6ec8: stur            x1, [fp, #-0x10]
    // 0xce6ecc: CheckStackOverflow
    //     0xce6ecc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce6ed0: cmp             SP, x16
    //     0xce6ed4: b.ls            #0xce6f1c
    // 0xce6ed8: InitAsync() -> Future<Object?>
    //     0xce6ed8: ldr             x0, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    //     0xce6edc: bl              #0x7f5e44  ; InitAsyncStub
    // 0xce6ee0: r1 = <Future<Object?>>
    //     0xce6ee0: add             x1, PP, #0xb0, lsl #12  ; [pp+0xb0d10] TypeArguments: <Future<Object?>>
    //     0xce6ee4: ldr             x1, [x1, #0xd10]
    // 0xce6ee8: r2 = 0
    //     0xce6ee8: mov             x2, #0
    // 0xce6eec: r0 = _GrowableList()
    //     0xce6eec: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xce6ef0: LoadField: r1 = r0->field_b
    //     0xce6ef0: ldur            w1, [x0, #0xb]
    // 0xce6ef4: cbz             w1, #0xce6f14
    // 0xce6ef8: r16 = <Object?>
    //     0xce6ef8: ldr             x16, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0xce6efc: stp             x0, x16, [SP]
    // 0xce6f00: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xce6f00: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xce6f04: r0 = wait()
    //     0xce6f04: bl              #0x841938  ; [dart:async] Future::wait
    // 0xce6f08: mov             x1, x0
    // 0xce6f0c: stur            x1, [fp, #-0x10]
    // 0xce6f10: r0 = Await()
    //     0xce6f10: bl              #0x7f5c00  ; AwaitStub
    // 0xce6f14: r0 = Null
    //     0xce6f14: mov             x0, NULL
    // 0xce6f18: r0 = ReturnAsyncNotFuture()
    //     0xce6f18: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xce6f1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce6f1c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce6f20: b               #0xce6ed8
  }
}

// class id: 3626, size: 0x10, field offset: 0x8
class CancelableOperation<X0> extends Object {

  Future<X0> value(CancelableOperation<X0>) {
    // ** addr: 0x8f50a8, size: 0x9c
    // 0x8f50a8: EnterFrame
    //     0x8f50a8: stp             fp, lr, [SP, #-0x10]!
    //     0x8f50ac: mov             fp, SP
    // 0x8f50b0: AllocStack(0x8)
    //     0x8f50b0: sub             SP, SP, #8
    // 0x8f50b4: CheckStackOverflow
    //     0x8f50b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f50b8: cmp             SP, x16
    //     0x8f50bc: b.ls            #0x8f513c
    // 0x8f50c0: LoadField: r0 = r1->field_b
    //     0x8f50c0: ldur            w0, [x1, #0xb]
    // 0x8f50c4: DecompressPointer r0
    //     0x8f50c4: add             x0, x0, HEAP, lsl #32
    // 0x8f50c8: LoadField: r2 = r0->field_b
    //     0x8f50c8: ldur            w2, [x0, #0xb]
    // 0x8f50cc: DecompressPointer r2
    //     0x8f50cc: add             x2, x2, HEAP, lsl #32
    // 0x8f50d0: cmp             w2, NULL
    // 0x8f50d4: b.ne            #0x8f50e0
    // 0x8f50d8: r0 = Null
    //     0x8f50d8: mov             x0, NULL
    // 0x8f50dc: b               #0x8f50e8
    // 0x8f50e0: LoadField: r0 = r2->field_b
    //     0x8f50e0: ldur            w0, [x2, #0xb]
    // 0x8f50e4: DecompressPointer r0
    //     0x8f50e4: add             x0, x0, HEAP, lsl #32
    // 0x8f50e8: cmp             w0, NULL
    // 0x8f50ec: b.ne            #0x8f5130
    // 0x8f50f0: LoadField: r0 = r1->field_7
    //     0x8f50f0: ldur            w0, [x1, #7]
    // 0x8f50f4: DecompressPointer r0
    //     0x8f50f4: add             x0, x0, HEAP, lsl #32
    // 0x8f50f8: mov             x1, x0
    // 0x8f50fc: r0 = _Future()
    //     0x8f50fc: bl              #0x7f5dd4  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0x8f5100: stur            x0, [fp, #-8]
    // 0x8f5104: StoreField: r0->field_b = rZR
    //     0x8f5104: stur            xzr, [x0, #0xb]
    // 0x8f5108: r0 = LoadStaticField(0x364)
    //     0x8f5108: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8f510c: ldr             x0, [x0, #0x6c8]
    // 0x8f5110: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8f5114: cmp             w0, w16
    // 0x8f5118: b.ne            #0x8f5124
    // 0x8f511c: r2 = _current
    //     0x8f511c: ldr             x2, [PP, #0x2c0]  ; [pp+0x2c0] Field <Zone._current@5048458>: static late (offset: 0x364)
    // 0x8f5120: r0 = InitLateStaticField()
    //     0x8f5120: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0x8f5124: ldur            x1, [fp, #-8]
    // 0x8f5128: StoreField: r1->field_13 = r0
    //     0x8f5128: stur            w0, [x1, #0x13]
    // 0x8f512c: mov             x0, x1
    // 0x8f5130: LeaveFrame
    //     0x8f5130: mov             SP, fp
    //     0x8f5134: ldp             fp, lr, [SP], #0x10
    // 0x8f5138: ret
    //     0x8f5138: ret             
    // 0x8f513c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f513c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f5140: b               #0x8f50c0
  }
  Future<X0> dyn:get:value(CancelableOperation<X0>) {
    // ** addr: 0x8f515c, size: 0x48
    // 0x8f515c: EnterFrame
    //     0x8f515c: stp             fp, lr, [SP, #-0x10]!
    //     0x8f5160: mov             fp, SP
    // 0x8f5164: CheckStackOverflow
    //     0x8f5164: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f5168: cmp             SP, x16
    //     0x8f516c: b.ls            #0x8f5184
    // 0x8f5170: ldr             x1, [fp, #0x10]
    // 0x8f5174: r0 = value()
    //     0x8f5174: bl              #0x8f50a8  ; [package:async/src/cancelable_operation.dart] CancelableOperation::value
    // 0x8f5178: LeaveFrame
    //     0x8f5178: mov             SP, fp
    //     0x8f517c: ldp             fp, lr, [SP], #0x10
    // 0x8f5180: ret
    //     0x8f5180: ret             
    // 0x8f5184: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f5184: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f5188: b               #0x8f5170
  }
  factory _ CancelableOperation.fromFuture(/* No info */) {
    // ** addr: 0x8f518c, size: 0x70
    // 0x8f518c: EnterFrame
    //     0x8f518c: stp             fp, lr, [SP, #-0x10]!
    //     0x8f5190: mov             fp, SP
    // 0x8f5194: AllocStack(0x10)
    //     0x8f5194: sub             SP, SP, #0x10
    // 0x8f5198: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x8f5198: stur            x2, [fp, #-8]
    // 0x8f519c: CheckStackOverflow
    //     0x8f519c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f51a0: cmp             SP, x16
    //     0x8f51a4: b.ls            #0x8f51f4
    // 0x8f51a8: r0 = CancelableCompleter()
    //     0x8f51a8: bl              #0x8f5758  ; AllocateCancelableCompleterStub -> CancelableCompleter<X0> (size=0x24)
    // 0x8f51ac: mov             x1, x0
    // 0x8f51b0: stur            x0, [fp, #-0x10]
    // 0x8f51b4: r0 = CancelableCompleter()
    //     0x8f51b4: bl              #0x8f5648  ; [package:async/src/cancelable_operation.dart] CancelableCompleter::CancelableCompleter
    // 0x8f51b8: ldur            x1, [fp, #-0x10]
    // 0x8f51bc: ldur            x2, [fp, #-8]
    // 0x8f51c0: r0 = complete()
    //     0x8f51c0: bl              #0x8f51fc  ; [package:async/src/cancelable_operation.dart] CancelableCompleter::complete
    // 0x8f51c4: ldur            x1, [fp, #-0x10]
    // 0x8f51c8: LoadField: r0 = r1->field_1f
    //     0x8f51c8: ldur            w0, [x1, #0x1f]
    // 0x8f51cc: DecompressPointer r0
    //     0x8f51cc: add             x0, x0, HEAP, lsl #32
    // 0x8f51d0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8f51d4: cmp             w0, w16
    // 0x8f51d8: b.ne            #0x8f51e8
    // 0x8f51dc: r2 = operation
    //     0x8f51dc: add             x2, PP, #0x16, lsl #12  ; [pp+0x16410] Field <CancelableCompleter.operation>: late final (offset: 0x20)
    //     0x8f51e0: ldr             x2, [x2, #0x410]
    // 0x8f51e4: r0 = InitLateFinalInstanceField()
    //     0x8f51e4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x8f51e8: LeaveFrame
    //     0x8f51e8: mov             SP, fp
    //     0x8f51ec: ldp             fp, lr, [SP], #0x10
    // 0x8f51f0: ret
    //     0x8f51f0: ret             
    // 0x8f51f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f51f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f51f8: b               #0x8f51a8
  }
  _ cancel(/* No info */) {
    // ** addr: 0xce6db8, size: 0x38
    // 0xce6db8: EnterFrame
    //     0xce6db8: stp             fp, lr, [SP, #-0x10]!
    //     0xce6dbc: mov             fp, SP
    // 0xce6dc0: CheckStackOverflow
    //     0xce6dc0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce6dc4: cmp             SP, x16
    //     0xce6dc8: b.ls            #0xce6de8
    // 0xce6dcc: LoadField: r0 = r1->field_b
    //     0xce6dcc: ldur            w0, [x1, #0xb]
    // 0xce6dd0: DecompressPointer r0
    //     0xce6dd0: add             x0, x0, HEAP, lsl #32
    // 0xce6dd4: mov             x1, x0
    // 0xce6dd8: r0 = _cancel()
    //     0xce6dd8: bl              #0xce6df0  ; [package:async/src/cancelable_operation.dart] CancelableCompleter::_cancel
    // 0xce6ddc: LeaveFrame
    //     0xce6ddc: mov             SP, fp
    //     0xce6de0: ldp             fp, lr, [SP], #0x10
    // 0xce6de4: ret
    //     0xce6de4: ret             
    // 0xce6de8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce6de8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce6dec: b               #0xce6dcc
  }
}
