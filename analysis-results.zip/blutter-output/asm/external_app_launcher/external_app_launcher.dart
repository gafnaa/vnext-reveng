// lib: , url: package:external_app_launcher/external_app_launcher.dart

// class id: 1048720, size: 0x8
class :: {
}

// class id: 3392, size: 0x8, field offset: 0x8
abstract class LaunchApp extends Object {

  static _ openApp(/* No info */) async {
    // ** addr: 0xfd78c0, size: 0xe0
    // 0xfd78c0: EnterFrame
    //     0xfd78c0: stp             fp, lr, [SP, #-0x10]!
    //     0xfd78c4: mov             fp, SP
    // 0xfd78c8: AllocStack(0x30)
    //     0xfd78c8: sub             SP, SP, #0x30
    // 0xfd78cc: SetupParameters()
    //     0xfd78cc: stur            NULL, [fp, #-8]
    // 0xfd78d0: CheckStackOverflow
    //     0xfd78d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfd78d4: cmp             SP, x16
    //     0xfd78d8: b.ls            #0xfd7998
    // 0xfd78dc: InitAsync() -> Future<int>
    //     0xfd78dc: ldr             x0, [PP, #0x50]  ; [pp+0x50] TypeArguments: <int>
    //     0xfd78e0: bl              #0x7f5e44  ; InitAsyncStub
    // 0xfd78e4: r1 = Null
    //     0xfd78e4: mov             x1, NULL
    // 0xfd78e8: r2 = 12
    //     0xfd78e8: mov             x2, #0xc
    // 0xfd78ec: r0 = AllocateArray()
    //     0xfd78ec: bl              #0x13df928  ; AllocateArrayStub
    // 0xfd78f0: r16 = "package_name"
    //     0xfd78f0: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a3d0] "package_name"
    //     0xfd78f4: ldr             x16, [x16, #0x3d0]
    // 0xfd78f8: StoreField: r0->field_f = r16
    //     0xfd78f8: stur            w16, [x0, #0xf]
    // 0xfd78fc: r16 = "id.ac.ugm.student.vnext.pitugm"
    //     0xfd78fc: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a3d8] "id.ac.ugm.student.vnext.pitugm"
    //     0xfd7900: ldr             x16, [x16, #0x3d8]
    // 0xfd7904: StoreField: r0->field_13 = r16
    //     0xfd7904: stur            w16, [x0, #0x13]
    // 0xfd7908: r16 = "open_store"
    //     0xfd7908: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a3e0] "open_store"
    //     0xfd790c: ldr             x16, [x16, #0x3e0]
    // 0xfd7910: ArrayStore: r0[0] = r16  ; List_4
    //     0xfd7910: stur            w16, [x0, #0x17]
    // 0xfd7914: r16 = "open it"
    //     0xfd7914: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a3e8] "open it"
    //     0xfd7918: ldr             x16, [x16, #0x3e8]
    // 0xfd791c: StoreField: r0->field_1b = r16
    //     0xfd791c: stur            w16, [x0, #0x1b]
    // 0xfd7920: r16 = "app_store_link"
    //     0xfd7920: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a3f0] "app_store_link"
    //     0xfd7924: ldr             x16, [x16, #0x3f0]
    // 0xfd7928: StoreField: r0->field_1f = r16
    //     0xfd7928: stur            w16, [x0, #0x1f]
    // 0xfd792c: StoreField: r0->field_23 = rNULL
    //     0xfd792c: stur            NULL, [x0, #0x23]
    // 0xfd7930: r16 = <String, String?>
    //     0xfd7930: ldr             x16, [PP, #0x7cf0]  ; [pp+0x7cf0] TypeArguments: <String, String?>
    // 0xfd7934: stp             x0, x16, [SP]
    // 0xfd7938: r0 = Map._fromLiteral()
    //     0xfd7938: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xfd793c: r16 = Instance_MethodChannel
    //     0xfd793c: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a3f8] Obj!MethodChannel@129bcc1
    //     0xfd7940: ldr             x16, [x16, #0x3f8]
    // 0xfd7944: stp             x16, NULL, [SP, #0x10]
    // 0xfd7948: r16 = "openApp"
    //     0xfd7948: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a400] "openApp"
    //     0xfd794c: ldr             x16, [x16, #0x400]
    // 0xfd7950: stp             x0, x16, [SP]
    // 0xfd7954: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xfd7954: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xfd7958: r0 = invokeMethod()
    //     0xfd7958: bl              #0x130b008  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xfd795c: r1 = Function '<anonymous closure>': static.
    //     0xfd795c: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a408] AnonymousClosure: static (0xfd79a0), in [package:external_app_launcher/external_app_launcher.dart] LaunchApp::openApp (0xfd78c0)
    //     0xfd7960: ldr             x1, [x1, #0x408]
    // 0xfd7964: r2 = Null
    //     0xfd7964: mov             x2, NULL
    // 0xfd7968: stur            x0, [fp, #-0x10]
    // 0xfd796c: r0 = AllocateClosure()
    //     0xfd796c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfd7970: r16 = <int>
    //     0xfd7970: ldr             x16, [PP, #0x50]  ; [pp+0x50] TypeArguments: <int>
    // 0xfd7974: ldur            lr, [fp, #-0x10]
    // 0xfd7978: stp             lr, x16, [SP, #8]
    // 0xfd797c: str             x0, [SP]
    // 0xfd7980: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xfd7980: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xfd7984: r0 = then()
    //     0xfd7984: bl              #0x1293070  ; [dart:async] _Future::then
    // 0xfd7988: mov             x1, x0
    // 0xfd798c: stur            x1, [fp, #-0x10]
    // 0xfd7990: r0 = Await()
    //     0xfd7990: bl              #0x7f5c00  ; AwaitStub
    // 0xfd7994: r0 = ReturnAsync()
    //     0xfd7994: b               #0x82fdf0  ; ReturnAsyncStub
    // 0xfd7998: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfd7998: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfd799c: b               #0xfd78dc
  }
  [closure] static int <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0xfd79a0, size: 0xc4
    // 0xfd79a0: EnterFrame
    //     0xfd79a0: stp             fp, lr, [SP, #-0x10]!
    //     0xfd79a4: mov             fp, SP
    // 0xfd79a8: AllocStack(0x10)
    //     0xfd79a8: sub             SP, SP, #0x10
    // 0xfd79ac: CheckStackOverflow
    //     0xfd79ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfd79b0: cmp             SP, x16
    //     0xfd79b4: b.ls            #0xfd7a5c
    // 0xfd79b8: ldr             x1, [fp, #0x10]
    // 0xfd79bc: r0 = 60
    //     0xfd79bc: mov             x0, #0x3c
    // 0xfd79c0: branchIfSmi(r1, 0xfd79cc)
    //     0xfd79c0: tbz             w1, #0, #0xfd79cc
    // 0xfd79c4: r0 = LoadClassIdInstr(r1)
    //     0xfd79c4: ldur            x0, [x1, #-1]
    //     0xfd79c8: ubfx            x0, x0, #0xc, #0x14
    // 0xfd79cc: r16 = "app_opened"
    //     0xfd79cc: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a410] "app_opened"
    //     0xfd79d0: ldr             x16, [x16, #0x410]
    // 0xfd79d4: stp             x16, x1, [SP]
    // 0xfd79d8: mov             lr, x0
    // 0xfd79dc: ldr             lr, [x21, lr, lsl #3]
    // 0xfd79e0: blr             lr
    // 0xfd79e4: tbnz            w0, #4, #0xfd7a04
    // 0xfd79e8: r1 = "app opened successfully"
    //     0xfd79e8: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a418] "app opened successfully"
    //     0xfd79ec: ldr             x1, [x1, #0x418]
    // 0xfd79f0: r0 = print()
    //     0xfd79f0: bl              #0x82a3d4  ; [dart:core] ::print
    // 0xfd79f4: r0 = 2
    //     0xfd79f4: mov             x0, #2
    // 0xfd79f8: LeaveFrame
    //     0xfd79f8: mov             SP, fp
    //     0xfd79fc: ldp             fp, lr, [SP], #0x10
    // 0xfd7a00: ret
    //     0xfd7a00: ret             
    // 0xfd7a04: ldr             x1, [fp, #0x10]
    // 0xfd7a08: r0 = 60
    //     0xfd7a08: mov             x0, #0x3c
    // 0xfd7a0c: branchIfSmi(r1, 0xfd7a18)
    //     0xfd7a0c: tbz             w1, #0, #0xfd7a18
    // 0xfd7a10: r0 = LoadClassIdInstr(r1)
    //     0xfd7a10: ldur            x0, [x1, #-1]
    //     0xfd7a14: ubfx            x0, x0, #0xc, #0x14
    // 0xfd7a18: r16 = "navigated_to_store"
    //     0xfd7a18: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a420] "navigated_to_store"
    //     0xfd7a1c: ldr             x16, [x16, #0x420]
    // 0xfd7a20: stp             x16, x1, [SP]
    // 0xfd7a24: mov             lr, x0
    // 0xfd7a28: ldr             lr, [x21, lr, lsl #3]
    // 0xfd7a2c: blr             lr
    // 0xfd7a30: tbnz            w0, #4, #0xfd7a44
    // 0xfd7a34: r1 = "Redirecting to Google Play Store as the app is not present on the device"
    //     0xfd7a34: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a428] "Redirecting to Google Play Store as the app is not present on the device"
    //     0xfd7a38: ldr             x1, [x1, #0x428]
    // 0xfd7a3c: r0 = print()
    //     0xfd7a3c: bl              #0x82a3d4  ; [dart:core] ::print
    // 0xfd7a40: b               #0xfd7a4c
    // 0xfd7a44: ldr             x1, [fp, #0x10]
    // 0xfd7a48: r0 = print()
    //     0xfd7a48: bl              #0x82a3d4  ; [dart:core] ::print
    // 0xfd7a4c: r0 = 0
    //     0xfd7a4c: mov             x0, #0
    // 0xfd7a50: LeaveFrame
    //     0xfd7a50: mov             SP, fp
    //     0xfd7a54: ldp             fp, lr, [SP], #0x10
    // 0xfd7a58: ret
    //     0xfd7a58: ret             
    // 0xfd7a5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfd7a5c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfd7a60: b               #0xfd79b8
  }
  static dynamic isAppInstalled() async {
    // ** addr: 0xfd7a64, size: 0x8c
    // 0xfd7a64: EnterFrame
    //     0xfd7a64: stp             fp, lr, [SP, #-0x10]!
    //     0xfd7a68: mov             fp, SP
    // 0xfd7a6c: AllocStack(0x30)
    //     0xfd7a6c: sub             SP, SP, #0x30
    // 0xfd7a70: SetupParameters()
    //     0xfd7a70: stur            NULL, [fp, #-8]
    // 0xfd7a74: CheckStackOverflow
    //     0xfd7a74: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfd7a78: cmp             SP, x16
    //     0xfd7a7c: b.ls            #0xfd7ae8
    // 0xfd7a80: InitAsync() -> Future
    //     0xfd7a80: mov             x0, NULL
    //     0xfd7a84: bl              #0x7f5e44  ; InitAsyncStub
    // 0xfd7a88: r1 = Null
    //     0xfd7a88: mov             x1, NULL
    // 0xfd7a8c: r2 = 4
    //     0xfd7a8c: mov             x2, #4
    // 0xfd7a90: r0 = AllocateArray()
    //     0xfd7a90: bl              #0x13df928  ; AllocateArrayStub
    // 0xfd7a94: r16 = "package_name"
    //     0xfd7a94: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a3d0] "package_name"
    //     0xfd7a98: ldr             x16, [x16, #0x3d0]
    // 0xfd7a9c: StoreField: r0->field_f = r16
    //     0xfd7a9c: stur            w16, [x0, #0xf]
    // 0xfd7aa0: r16 = "id.ac.ugm.student.vnext.pitugm"
    //     0xfd7aa0: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a3d8] "id.ac.ugm.student.vnext.pitugm"
    //     0xfd7aa4: ldr             x16, [x16, #0x3d8]
    // 0xfd7aa8: StoreField: r0->field_13 = r16
    //     0xfd7aa8: stur            w16, [x0, #0x13]
    // 0xfd7aac: r16 = <String, String>
    //     0xfd7aac: ldr             x16, [PP, #0x7c88]  ; [pp+0x7c88] TypeArguments: <String, String>
    // 0xfd7ab0: stp             x0, x16, [SP]
    // 0xfd7ab4: r0 = Map._fromLiteral()
    //     0xfd7ab4: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xfd7ab8: r16 = Instance_MethodChannel
    //     0xfd7ab8: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a3f8] Obj!MethodChannel@129bcc1
    //     0xfd7abc: ldr             x16, [x16, #0x3f8]
    // 0xfd7ac0: stp             x16, NULL, [SP, #0x10]
    // 0xfd7ac4: r16 = "isAppInstalled"
    //     0xfd7ac4: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a430] "isAppInstalled"
    //     0xfd7ac8: ldr             x16, [x16, #0x430]
    // 0xfd7acc: stp             x0, x16, [SP]
    // 0xfd7ad0: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xfd7ad0: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xfd7ad4: r0 = invokeMethod()
    //     0xfd7ad4: bl              #0x130b008  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xfd7ad8: mov             x1, x0
    // 0xfd7adc: stur            x1, [fp, #-0x10]
    // 0xfd7ae0: r0 = Await()
    //     0xfd7ae0: bl              #0x7f5c00  ; AwaitStub
    // 0xfd7ae4: r0 = ReturnAsync()
    //     0xfd7ae4: b               #0x82fdf0  ; ReturnAsyncStub
    // 0xfd7ae8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfd7ae8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfd7aec: b               #0xfd7a80
  }
}
