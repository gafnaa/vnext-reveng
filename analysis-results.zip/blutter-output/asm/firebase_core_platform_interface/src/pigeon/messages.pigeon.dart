// lib: , url: package:firebase_core_platform_interface/src/pigeon/messages.pigeon.dart

// class id: 1048746, size: 0x8
class :: {

  static int _deepHash(Object?) {
    // ** addr: 0x1149b58, size: 0xbb4
    // 0x1149b58: EnterFrame
    //     0x1149b58: stp             fp, lr, [SP, #-0x10]!
    //     0x1149b5c: mov             fp, SP
    // 0x1149b60: AllocStack(0x88)
    //     0x1149b60: sub             SP, SP, #0x88
    // 0x1149b64: SetupParameters(dynamic _ /* r1 => r3, fp-0x8 */)
    //     0x1149b64: mov             x3, x1
    //     0x1149b68: stur            x1, [fp, #-8]
    // 0x1149b6c: CheckStackOverflow
    //     0x1149b6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1149b70: cmp             SP, x16
    //     0x1149b74: b.ls            #0x114a6ec
    // 0x1149b78: mov             x0, x3
    // 0x1149b7c: r2 = Null
    //     0x1149b7c: mov             x2, NULL
    // 0x1149b80: r1 = Null
    //     0x1149b80: mov             x1, NULL
    // 0x1149b84: cmp             w0, NULL
    // 0x1149b88: b.eq            #0x1149c2c
    // 0x1149b8c: branchIfSmi(r0, 0x1149c2c)
    //     0x1149b8c: tbz             w0, #0, #0x1149c2c
    // 0x1149b90: r3 = LoadClassIdInstr(r0)
    //     0x1149b90: ldur            x3, [x0, #-1]
    //     0x1149b94: ubfx            x3, x3, #0xc, #0x14
    // 0x1149b98: r17 = 7631
    //     0x1149b98: mov             x17, #0x1dcf
    // 0x1149b9c: cmp             x3, x17
    // 0x1149ba0: b.eq            #0x1149c34
    // 0x1149ba4: sub             x3, x3, #0x5a
    // 0x1149ba8: cmp             x3, #2
    // 0x1149bac: b.ls            #0x1149c34
    // 0x1149bb0: r4 = LoadClassIdInstr(r0)
    //     0x1149bb0: ldur            x4, [x0, #-1]
    //     0x1149bb4: ubfx            x4, x4, #0xc, #0x14
    // 0x1149bb8: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x1149bbc: ldr             x3, [x3, #0x18]
    // 0x1149bc0: ldr             x3, [x3, x4, lsl #3]
    // 0x1149bc4: LoadField: r3 = r3->field_2b
    //     0x1149bc4: ldur            w3, [x3, #0x2b]
    // 0x1149bc8: DecompressPointer r3
    //     0x1149bc8: add             x3, x3, HEAP, lsl #32
    // 0x1149bcc: cmp             w3, NULL
    // 0x1149bd0: b.eq            #0x1149c2c
    // 0x1149bd4: LoadField: r3 = r3->field_f
    //     0x1149bd4: ldur            w3, [x3, #0xf]
    // 0x1149bd8: lsr             x3, x3, #3
    // 0x1149bdc: r17 = 7631
    //     0x1149bdc: mov             x17, #0x1dcf
    // 0x1149be0: cmp             x3, x17
    // 0x1149be4: b.eq            #0x1149c34
    // 0x1149be8: r3 = SubtypeTestCache
    //     0x1149be8: add             x3, PP, #0xc, lsl #12  ; [pp+0xce30] SubtypeTestCache
    //     0x1149bec: ldr             x3, [x3, #0xe30]
    // 0x1149bf0: r30 = Subtype1TestCacheStub
    //     0x1149bf0: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x1149bf4: LoadField: r30 = r30->field_7
    //     0x1149bf4: ldur            lr, [lr, #7]
    // 0x1149bf8: blr             lr
    // 0x1149bfc: cmp             w7, NULL
    // 0x1149c00: b.eq            #0x1149c0c
    // 0x1149c04: tbnz            w7, #4, #0x1149c2c
    // 0x1149c08: b               #0x1149c34
    // 0x1149c0c: r8 = List
    //     0x1149c0c: add             x8, PP, #0xc, lsl #12  ; [pp+0xce38] Type: List
    //     0x1149c10: ldr             x8, [x8, #0xe38]
    // 0x1149c14: r3 = SubtypeTestCache
    //     0x1149c14: add             x3, PP, #0xc, lsl #12  ; [pp+0xce40] SubtypeTestCache
    //     0x1149c18: ldr             x3, [x3, #0xe40]
    // 0x1149c1c: r30 = InstanceOfStub
    //     0x1149c1c: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x1149c20: LoadField: r30 = r30->field_7
    //     0x1149c20: ldur            lr, [lr, #7]
    // 0x1149c24: blr             lr
    // 0x1149c28: b               #0x1149c38
    // 0x1149c2c: r0 = false
    //     0x1149c2c: add             x0, NULL, #0x30  ; false
    // 0x1149c30: b               #0x1149c38
    // 0x1149c34: r0 = true
    //     0x1149c34: add             x0, NULL, #0x20  ; true
    // 0x1149c38: tbnz            w0, #4, #0x1149c88
    // 0x1149c3c: ldur            x3, [fp, #-8]
    // 0x1149c40: r0 = LoadClassIdInstr(r3)
    //     0x1149c40: ldur            x0, [x3, #-1]
    //     0x1149c44: ubfx            x0, x0, #0xc, #0x14
    // 0x1149c48: r16 = <Object?>
    //     0x1149c48: ldr             x16, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0x1149c4c: stp             x3, x16, [SP, #8]
    // 0x1149c50: r16 = Closure: (Object?) => int from Function '_deepHash@1280305088': static.
    //     0x1149c50: add             x16, PP, #0xc, lsl #12  ; [pp+0xce48] Closure: (Object?) => int from Function '_deepHash@1280305088': static. (0x7f2adb03170c)
    //     0x1149c54: ldr             x16, [x16, #0xe48]
    // 0x1149c58: str             x16, [SP]
    // 0x1149c5c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x1149c5c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x1149c60: r0 = GDT[cid_x0 + 0x12caa]()
    //     0x1149c60: mov             x17, #0x2caa
    //     0x1149c64: movk            x17, #1, lsl #16
    //     0x1149c68: add             lr, x0, x17
    //     0x1149c6c: ldr             lr, [x21, lr, lsl #3]
    //     0x1149c70: blr             lr
    // 0x1149c74: mov             x1, x0
    // 0x1149c78: r0 = hashAll()
    //     0x1149c78: bl              #0x112b348  ; [dart:core] Object::hashAll
    // 0x1149c7c: LeaveFrame
    //     0x1149c7c: mov             SP, fp
    //     0x1149c80: ldp             fp, lr, [SP], #0x10
    // 0x1149c84: ret
    //     0x1149c84: ret             
    // 0x1149c88: ldur            x3, [fp, #-8]
    // 0x1149c8c: mov             x0, x3
    // 0x1149c90: r2 = Null
    //     0x1149c90: mov             x2, NULL
    // 0x1149c94: r1 = Null
    //     0x1149c94: mov             x1, NULL
    // 0x1149c98: cmp             w0, NULL
    // 0x1149c9c: b.eq            #0x1149d34
    // 0x1149ca0: branchIfSmi(r0, 0x1149d34)
    //     0x1149ca0: tbz             w0, #0, #0x1149d34
    // 0x1149ca4: r3 = LoadClassIdInstr(r0)
    //     0x1149ca4: ldur            x3, [x0, #-1]
    //     0x1149ca8: ubfx            x3, x3, #0xc, #0x14
    // 0x1149cac: r17 = 7630
    //     0x1149cac: mov             x17, #0x1dce
    // 0x1149cb0: cmp             x3, x17
    // 0x1149cb4: b.eq            #0x1149d3c
    // 0x1149cb8: r4 = LoadClassIdInstr(r0)
    //     0x1149cb8: ldur            x4, [x0, #-1]
    //     0x1149cbc: ubfx            x4, x4, #0xc, #0x14
    // 0x1149cc0: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x1149cc4: ldr             x3, [x3, #0x18]
    // 0x1149cc8: ldr             x3, [x3, x4, lsl #3]
    // 0x1149ccc: LoadField: r3 = r3->field_2b
    //     0x1149ccc: ldur            w3, [x3, #0x2b]
    // 0x1149cd0: DecompressPointer r3
    //     0x1149cd0: add             x3, x3, HEAP, lsl #32
    // 0x1149cd4: cmp             w3, NULL
    // 0x1149cd8: b.eq            #0x1149d34
    // 0x1149cdc: LoadField: r3 = r3->field_f
    //     0x1149cdc: ldur            w3, [x3, #0xf]
    // 0x1149ce0: lsr             x3, x3, #3
    // 0x1149ce4: r17 = 7630
    //     0x1149ce4: mov             x17, #0x1dce
    // 0x1149ce8: cmp             x3, x17
    // 0x1149cec: b.eq            #0x1149d3c
    // 0x1149cf0: r3 = SubtypeTestCache
    //     0x1149cf0: add             x3, PP, #0xc, lsl #12  ; [pp+0xce50] SubtypeTestCache
    //     0x1149cf4: ldr             x3, [x3, #0xe50]
    // 0x1149cf8: r30 = Subtype1TestCacheStub
    //     0x1149cf8: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x1149cfc: LoadField: r30 = r30->field_7
    //     0x1149cfc: ldur            lr, [lr, #7]
    // 0x1149d00: blr             lr
    // 0x1149d04: cmp             w7, NULL
    // 0x1149d08: b.eq            #0x1149d14
    // 0x1149d0c: tbnz            w7, #4, #0x1149d34
    // 0x1149d10: b               #0x1149d3c
    // 0x1149d14: r8 = Map
    //     0x1149d14: add             x8, PP, #0xc, lsl #12  ; [pp+0xce58] Type: Map
    //     0x1149d18: ldr             x8, [x8, #0xe58]
    // 0x1149d1c: r3 = SubtypeTestCache
    //     0x1149d1c: add             x3, PP, #0xc, lsl #12  ; [pp+0xce60] SubtypeTestCache
    //     0x1149d20: ldr             x3, [x3, #0xe60]
    // 0x1149d24: r30 = InstanceOfStub
    //     0x1149d24: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x1149d28: LoadField: r30 = r30->field_7
    //     0x1149d28: ldur            lr, [lr, #7]
    // 0x1149d2c: blr             lr
    // 0x1149d30: b               #0x1149d40
    // 0x1149d34: r0 = false
    //     0x1149d34: add             x0, NULL, #0x30  ; false
    // 0x1149d38: b               #0x1149d40
    // 0x1149d3c: r0 = true
    //     0x1149d3c: add             x0, NULL, #0x20  ; true
    // 0x1149d40: tbnz            w0, #4, #0x114a5e0
    // 0x1149d44: ldur            x1, [fp, #-8]
    // 0x1149d48: r0 = LoadClassIdInstr(r1)
    //     0x1149d48: ldur            x0, [x1, #-1]
    //     0x1149d4c: ubfx            x0, x0, #0xc, #0x14
    // 0x1149d50: r0 = GDT[cid_x0 + 0xfc4]()
    //     0x1149d50: add             lr, x0, #0xfc4
    //     0x1149d54: ldr             lr, [x21, lr, lsl #3]
    //     0x1149d58: blr             lr
    // 0x1149d5c: r1 = LoadClassIdInstr(r0)
    //     0x1149d5c: ldur            x1, [x0, #-1]
    //     0x1149d60: ubfx            x1, x1, #0xc, #0x14
    // 0x1149d64: mov             x16, x0
    // 0x1149d68: mov             x0, x1
    // 0x1149d6c: mov             x1, x16
    // 0x1149d70: r0 = GDT[cid_x0 + 0x12641]()
    //     0x1149d70: mov             x17, #0x2641
    //     0x1149d74: movk            x17, #1, lsl #16
    //     0x1149d78: add             lr, x0, x17
    //     0x1149d7c: ldr             lr, [x21, lr, lsl #3]
    //     0x1149d80: blr             lr
    // 0x1149d84: mov             x2, x0
    // 0x1149d88: d0 = 0.000000
    //     0x1149d88: eor             v0.16b, v0.16b, v0.16b
    // 0x1149d8c: stur            x2, [fp, #-0x38]
    // 0x1149d90: mov             x16, v0.d[0]
    // 0x1149d94: and             x16, x16, #0x7ff0000000000000
    // 0x1149d98: r17 = 9218868437227405312
    //     0x1149d98: mov             x17, #0x7ff0000000000000
    // 0x1149d9c: cmp             x16, x17
    // 0x1149da0: b.eq            #0x1149dd0
    // 0x1149da4: fcvtzs          x16, d0
    // 0x1149da8: scvtf           d1, x16
    // 0x1149dac: fcmp            d1, d0
    // 0x1149db0: b.ne            #0x1149dd0
    // 0x1149db4: r17 = 11601
    //     0x1149db4: mov             x17, #0x2d51
    // 0x1149db8: mul             x3, x16, x17
    // 0x1149dbc: umulh           x16, x16, x17
    // 0x1149dc0: eor             x3, x3, x16
    // 0x1149dc4: r3 = 0
    //     0x1149dc4: eor             x3, x3, x3, lsr #32
    // 0x1149dc8: and             x3, x3, #0x3fffffff
    // 0x1149dcc: b               #0x1149ddc
    // 0x1149dd0: r3 = 0.000000
    //     0x1149dd0: fmov            x3, d0
    // 0x1149dd4: r3 = 0
    //     0x1149dd4: eor             x3, x3, x3, lsr #32
    // 0x1149dd8: and             x3, x3, #0x3fffffff
    // 0x1149ddc: stur            x3, [fp, #-0x30]
    // 0x1149de0: r0 = 9221120237041090560
    //     0x1149de0: add             x0, PP, #0xc, lsl #12  ; [pp+0xce68] 0x7ff8000000000000
    //     0x1149de4: ldr             x0, [x0, #0xe68]
    // 0x1149de8: LoadField: r16 = r0->field_7
    //     0x1149de8: ldur            x16, [x0, #7]
    // 0x1149dec: r17 = 11601
    //     0x1149dec: mov             x17, #0x2d51
    // 0x1149df0: mul             x1, x16, x17
    // 0x1149df4: umulh           x16, x16, x17
    // 0x1149df8: eor             x1, x1, x16
    // 0x1149dfc: r1 = 0
    //     0x1149dfc: eor             x1, x1, x1, lsr #32
    // 0x1149e00: ubfiz           x1, x1, #1, #0x1e
    // 0x1149e04: r4 = LoadInt32Instr(r1)
    //     0x1149e04: sbfx            x4, x1, #1, #0x1f
    // 0x1149e08: stur            x4, [fp, #-0x28]
    // 0x1149e0c: mov             x16, v0.d[0]
    // 0x1149e10: and             x16, x16, #0x7ff0000000000000
    // 0x1149e14: r17 = 9218868437227405312
    //     0x1149e14: mov             x17, #0x7ff0000000000000
    // 0x1149e18: cmp             x16, x17
    // 0x1149e1c: b.eq            #0x1149e4c
    // 0x1149e20: fcvtzs          x16, d0
    // 0x1149e24: scvtf           d1, x16
    // 0x1149e28: fcmp            d1, d0
    // 0x1149e2c: b.ne            #0x1149e4c
    // 0x1149e30: r17 = 11601
    //     0x1149e30: mov             x17, #0x2d51
    // 0x1149e34: mul             x5, x16, x17
    // 0x1149e38: umulh           x16, x16, x17
    // 0x1149e3c: eor             x5, x5, x16
    // 0x1149e40: r5 = 0
    //     0x1149e40: eor             x5, x5, x5, lsr #32
    // 0x1149e44: and             x5, x5, #0x3fffffff
    // 0x1149e48: b               #0x1149e58
    // 0x1149e4c: r5 = 0.000000
    //     0x1149e4c: fmov            x5, d0
    // 0x1149e50: r5 = 0
    //     0x1149e50: eor             x5, x5, x5, lsr #32
    // 0x1149e54: and             x5, x5, #0x3fffffff
    // 0x1149e58: stur            x5, [fp, #-0x20]
    // 0x1149e5c: LoadField: r16 = r0->field_7
    //     0x1149e5c: ldur            x16, [x0, #7]
    // 0x1149e60: r17 = 11601
    //     0x1149e60: mov             x17, #0x2d51
    // 0x1149e64: mul             x1, x16, x17
    // 0x1149e68: umulh           x16, x16, x17
    // 0x1149e6c: eor             x1, x1, x16
    // 0x1149e70: r1 = 0
    //     0x1149e70: eor             x1, x1, x1, lsr #32
    // 0x1149e74: ubfiz           x1, x1, #1, #0x1e
    // 0x1149e78: r6 = LoadInt32Instr(r1)
    //     0x1149e78: sbfx            x6, x1, #1, #0x1f
    // 0x1149e7c: stur            x6, [fp, #-0x18]
    // 0x1149e80: r7 = 0
    //     0x1149e80: mov             x7, #0
    // 0x1149e84: stur            x7, [fp, #-0x10]
    // 0x1149e88: CheckStackOverflow
    //     0x1149e88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1149e8c: cmp             SP, x16
    //     0x1149e90: b.ls            #0x114a6f4
    // 0x1149e94: r0 = LoadClassIdInstr(r2)
    //     0x1149e94: ldur            x0, [x2, #-1]
    //     0x1149e98: ubfx            x0, x0, #0xc, #0x14
    // 0x1149e9c: mov             x1, x2
    // 0x1149ea0: r0 = GDT[cid_x0 + 0x1845b]()
    //     0x1149ea0: mov             x17, #0x845b
    //     0x1149ea4: movk            x17, #1, lsl #16
    //     0x1149ea8: add             lr, x0, x17
    //     0x1149eac: ldr             lr, [x21, lr, lsl #3]
    //     0x1149eb0: blr             lr
    // 0x1149eb4: tbnz            w0, #4, #0x114a5cc
    // 0x1149eb8: ldur            x2, [fp, #-0x38]
    // 0x1149ebc: r0 = LoadClassIdInstr(r2)
    //     0x1149ebc: ldur            x0, [x2, #-1]
    //     0x1149ec0: ubfx            x0, x0, #0xc, #0x14
    // 0x1149ec4: mov             x1, x2
    // 0x1149ec8: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0x1149ec8: mov             x17, #0x7d4c
    //     0x1149ecc: movk            x17, #1, lsl #16
    //     0x1149ed0: add             lr, x0, x17
    //     0x1149ed4: ldr             lr, [x21, lr, lsl #3]
    //     0x1149ed8: blr             lr
    // 0x1149edc: mov             x3, x0
    // 0x1149ee0: stur            x3, [fp, #-0x48]
    // 0x1149ee4: LoadField: r4 = r3->field_b
    //     0x1149ee4: ldur            w4, [x3, #0xb]
    // 0x1149ee8: DecompressPointer r4
    //     0x1149ee8: add             x4, x4, HEAP, lsl #32
    // 0x1149eec: mov             x0, x4
    // 0x1149ef0: stur            x4, [fp, #-0x40]
    // 0x1149ef4: r2 = Null
    //     0x1149ef4: mov             x2, NULL
    // 0x1149ef8: r1 = Null
    //     0x1149ef8: mov             x1, NULL
    // 0x1149efc: cmp             w0, NULL
    // 0x1149f00: b.eq            #0x1149fa4
    // 0x1149f04: branchIfSmi(r0, 0x1149fa4)
    //     0x1149f04: tbz             w0, #0, #0x1149fa4
    // 0x1149f08: r3 = LoadClassIdInstr(r0)
    //     0x1149f08: ldur            x3, [x0, #-1]
    //     0x1149f0c: ubfx            x3, x3, #0xc, #0x14
    // 0x1149f10: r17 = 7631
    //     0x1149f10: mov             x17, #0x1dcf
    // 0x1149f14: cmp             x3, x17
    // 0x1149f18: b.eq            #0x1149fac
    // 0x1149f1c: sub             x3, x3, #0x5a
    // 0x1149f20: cmp             x3, #2
    // 0x1149f24: b.ls            #0x1149fac
    // 0x1149f28: r4 = LoadClassIdInstr(r0)
    //     0x1149f28: ldur            x4, [x0, #-1]
    //     0x1149f2c: ubfx            x4, x4, #0xc, #0x14
    // 0x1149f30: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x1149f34: ldr             x3, [x3, #0x18]
    // 0x1149f38: ldr             x3, [x3, x4, lsl #3]
    // 0x1149f3c: LoadField: r3 = r3->field_2b
    //     0x1149f3c: ldur            w3, [x3, #0x2b]
    // 0x1149f40: DecompressPointer r3
    //     0x1149f40: add             x3, x3, HEAP, lsl #32
    // 0x1149f44: cmp             w3, NULL
    // 0x1149f48: b.eq            #0x1149fa4
    // 0x1149f4c: LoadField: r3 = r3->field_f
    //     0x1149f4c: ldur            w3, [x3, #0xf]
    // 0x1149f50: lsr             x3, x3, #3
    // 0x1149f54: r17 = 7631
    //     0x1149f54: mov             x17, #0x1dcf
    // 0x1149f58: cmp             x3, x17
    // 0x1149f5c: b.eq            #0x1149fac
    // 0x1149f60: r3 = SubtypeTestCache
    //     0x1149f60: add             x3, PP, #0xc, lsl #12  ; [pp+0xce70] SubtypeTestCache
    //     0x1149f64: ldr             x3, [x3, #0xe70]
    // 0x1149f68: r30 = Subtype1TestCacheStub
    //     0x1149f68: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x1149f6c: LoadField: r30 = r30->field_7
    //     0x1149f6c: ldur            lr, [lr, #7]
    // 0x1149f70: blr             lr
    // 0x1149f74: cmp             w7, NULL
    // 0x1149f78: b.eq            #0x1149f84
    // 0x1149f7c: tbnz            w7, #4, #0x1149fa4
    // 0x1149f80: b               #0x1149fac
    // 0x1149f84: r8 = List
    //     0x1149f84: add             x8, PP, #0xc, lsl #12  ; [pp+0xce78] Type: List
    //     0x1149f88: ldr             x8, [x8, #0xe78]
    // 0x1149f8c: r3 = SubtypeTestCache
    //     0x1149f8c: add             x3, PP, #0xc, lsl #12  ; [pp+0xce80] SubtypeTestCache
    //     0x1149f90: ldr             x3, [x3, #0xe80]
    // 0x1149f94: r30 = InstanceOfStub
    //     0x1149f94: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x1149f98: LoadField: r30 = r30->field_7
    //     0x1149f98: ldur            lr, [lr, #7]
    // 0x1149f9c: blr             lr
    // 0x1149fa0: b               #0x1149fb0
    // 0x1149fa4: r0 = false
    //     0x1149fa4: add             x0, NULL, #0x30  ; false
    // 0x1149fa8: b               #0x1149fb0
    // 0x1149fac: r0 = true
    //     0x1149fac: add             x0, NULL, #0x20  ; true
    // 0x1149fb0: tbnz            w0, #4, #0x1149ffc
    // 0x1149fb4: ldur            x3, [fp, #-0x40]
    // 0x1149fb8: r0 = LoadClassIdInstr(r3)
    //     0x1149fb8: ldur            x0, [x3, #-1]
    //     0x1149fbc: ubfx            x0, x0, #0xc, #0x14
    // 0x1149fc0: r16 = <Object?>
    //     0x1149fc0: ldr             x16, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0x1149fc4: stp             x3, x16, [SP, #8]
    // 0x1149fc8: r16 = Closure: (Object?) => int from Function '_deepHash@1280305088': static.
    //     0x1149fc8: add             x16, PP, #0xc, lsl #12  ; [pp+0xce48] Closure: (Object?) => int from Function '_deepHash@1280305088': static. (0x7f2adb03170c)
    //     0x1149fcc: ldr             x16, [x16, #0xe48]
    // 0x1149fd0: str             x16, [SP]
    // 0x1149fd4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x1149fd4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x1149fd8: r0 = GDT[cid_x0 + 0x12caa]()
    //     0x1149fd8: mov             x17, #0x2caa
    //     0x1149fdc: movk            x17, #1, lsl #16
    //     0x1149fe0: add             lr, x0, x17
    //     0x1149fe4: ldr             lr, [x21, lr, lsl #3]
    //     0x1149fe8: blr             lr
    // 0x1149fec: mov             x1, x0
    // 0x1149ff0: r0 = hashAll()
    //     0x1149ff0: bl              #0x112b348  ; [dart:core] Object::hashAll
    // 0x1149ff4: mov             x1, x0
    // 0x1149ff8: b               #0x114a238
    // 0x1149ffc: ldur            x3, [fp, #-0x40]
    // 0x114a000: mov             x0, x3
    // 0x114a004: r2 = Null
    //     0x114a004: mov             x2, NULL
    // 0x114a008: r1 = Null
    //     0x114a008: mov             x1, NULL
    // 0x114a00c: cmp             w0, NULL
    // 0x114a010: b.eq            #0x114a0a8
    // 0x114a014: branchIfSmi(r0, 0x114a0a8)
    //     0x114a014: tbz             w0, #0, #0x114a0a8
    // 0x114a018: r3 = LoadClassIdInstr(r0)
    //     0x114a018: ldur            x3, [x0, #-1]
    //     0x114a01c: ubfx            x3, x3, #0xc, #0x14
    // 0x114a020: r17 = 7630
    //     0x114a020: mov             x17, #0x1dce
    // 0x114a024: cmp             x3, x17
    // 0x114a028: b.eq            #0x114a0b0
    // 0x114a02c: r4 = LoadClassIdInstr(r0)
    //     0x114a02c: ldur            x4, [x0, #-1]
    //     0x114a030: ubfx            x4, x4, #0xc, #0x14
    // 0x114a034: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x114a038: ldr             x3, [x3, #0x18]
    // 0x114a03c: ldr             x3, [x3, x4, lsl #3]
    // 0x114a040: LoadField: r3 = r3->field_2b
    //     0x114a040: ldur            w3, [x3, #0x2b]
    // 0x114a044: DecompressPointer r3
    //     0x114a044: add             x3, x3, HEAP, lsl #32
    // 0x114a048: cmp             w3, NULL
    // 0x114a04c: b.eq            #0x114a0a8
    // 0x114a050: LoadField: r3 = r3->field_f
    //     0x114a050: ldur            w3, [x3, #0xf]
    // 0x114a054: lsr             x3, x3, #3
    // 0x114a058: r17 = 7630
    //     0x114a058: mov             x17, #0x1dce
    // 0x114a05c: cmp             x3, x17
    // 0x114a060: b.eq            #0x114a0b0
    // 0x114a064: r3 = SubtypeTestCache
    //     0x114a064: add             x3, PP, #0xc, lsl #12  ; [pp+0xce88] SubtypeTestCache
    //     0x114a068: ldr             x3, [x3, #0xe88]
    // 0x114a06c: r30 = Subtype1TestCacheStub
    //     0x114a06c: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x114a070: LoadField: r30 = r30->field_7
    //     0x114a070: ldur            lr, [lr, #7]
    // 0x114a074: blr             lr
    // 0x114a078: cmp             w7, NULL
    // 0x114a07c: b.eq            #0x114a088
    // 0x114a080: tbnz            w7, #4, #0x114a0a8
    // 0x114a084: b               #0x114a0b0
    // 0x114a088: r8 = Map
    //     0x114a088: add             x8, PP, #0xc, lsl #12  ; [pp+0xce90] Type: Map
    //     0x114a08c: ldr             x8, [x8, #0xe90]
    // 0x114a090: r3 = SubtypeTestCache
    //     0x114a090: add             x3, PP, #0xc, lsl #12  ; [pp+0xce98] SubtypeTestCache
    //     0x114a094: ldr             x3, [x3, #0xe98]
    // 0x114a098: r30 = InstanceOfStub
    //     0x114a098: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x114a09c: LoadField: r30 = r30->field_7
    //     0x114a09c: ldur            lr, [lr, #7]
    // 0x114a0a0: blr             lr
    // 0x114a0a4: b               #0x114a0b4
    // 0x114a0a8: r0 = false
    //     0x114a0a8: add             x0, NULL, #0x30  ; false
    // 0x114a0ac: b               #0x114a0b4
    // 0x114a0b0: r0 = true
    //     0x114a0b0: add             x0, NULL, #0x20  ; true
    // 0x114a0b4: tbnz            w0, #4, #0x114a1b4
    // 0x114a0b8: ldur            x1, [fp, #-0x40]
    // 0x114a0bc: r0 = LoadClassIdInstr(r1)
    //     0x114a0bc: ldur            x0, [x1, #-1]
    //     0x114a0c0: ubfx            x0, x0, #0xc, #0x14
    // 0x114a0c4: r0 = GDT[cid_x0 + 0xfc4]()
    //     0x114a0c4: add             lr, x0, #0xfc4
    //     0x114a0c8: ldr             lr, [x21, lr, lsl #3]
    //     0x114a0cc: blr             lr
    // 0x114a0d0: r1 = LoadClassIdInstr(r0)
    //     0x114a0d0: ldur            x1, [x0, #-1]
    //     0x114a0d4: ubfx            x1, x1, #0xc, #0x14
    // 0x114a0d8: mov             x16, x0
    // 0x114a0dc: mov             x0, x1
    // 0x114a0e0: mov             x1, x16
    // 0x114a0e4: r0 = GDT[cid_x0 + 0x12641]()
    //     0x114a0e4: mov             x17, #0x2641
    //     0x114a0e8: movk            x17, #1, lsl #16
    //     0x114a0ec: add             lr, x0, x17
    //     0x114a0f0: ldr             lr, [x21, lr, lsl #3]
    //     0x114a0f4: blr             lr
    // 0x114a0f8: mov             x2, x0
    // 0x114a0fc: stur            x2, [fp, #-0x58]
    // 0x114a100: r3 = 0
    //     0x114a100: mov             x3, #0
    // 0x114a104: stur            x3, [fp, #-0x50]
    // 0x114a108: CheckStackOverflow
    //     0x114a108: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x114a10c: cmp             SP, x16
    //     0x114a110: b.ls            #0x114a6fc
    // 0x114a114: r0 = LoadClassIdInstr(r2)
    //     0x114a114: ldur            x0, [x2, #-1]
    //     0x114a118: ubfx            x0, x0, #0xc, #0x14
    // 0x114a11c: mov             x1, x2
    // 0x114a120: r0 = GDT[cid_x0 + 0x1845b]()
    //     0x114a120: mov             x17, #0x845b
    //     0x114a124: movk            x17, #1, lsl #16
    //     0x114a128: add             lr, x0, x17
    //     0x114a12c: ldr             lr, [x21, lr, lsl #3]
    //     0x114a130: blr             lr
    // 0x114a134: tbnz            w0, #4, #0x114a1a8
    // 0x114a138: ldur            x2, [fp, #-0x58]
    // 0x114a13c: ldur            x3, [fp, #-0x50]
    // 0x114a140: r0 = LoadClassIdInstr(r2)
    //     0x114a140: ldur            x0, [x2, #-1]
    //     0x114a144: ubfx            x0, x0, #0xc, #0x14
    // 0x114a148: mov             x1, x2
    // 0x114a14c: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0x114a14c: mov             x17, #0x7d4c
    //     0x114a150: movk            x17, #1, lsl #16
    //     0x114a154: add             lr, x0, x17
    //     0x114a158: ldr             lr, [x21, lr, lsl #3]
    //     0x114a15c: blr             lr
    // 0x114a160: stur            x0, [fp, #-0x60]
    // 0x114a164: LoadField: r1 = r0->field_b
    //     0x114a164: ldur            w1, [x0, #0xb]
    // 0x114a168: DecompressPointer r1
    //     0x114a168: add             x1, x1, HEAP, lsl #32
    // 0x114a16c: r0 = _deepHash()
    //     0x114a16c: bl              #0x1149b58  ; [package:firebase_core_platform_interface/src/pigeon/messages.pigeon.dart] ::_deepHash
    // 0x114a170: r16 = 31
    //     0x114a170: mov             x16, #0x1f
    // 0x114a174: mul             x2, x0, x16
    // 0x114a178: ldur            x0, [fp, #-0x60]
    // 0x114a17c: stur            x2, [fp, #-0x68]
    // 0x114a180: LoadField: r1 = r0->field_f
    //     0x114a180: ldur            w1, [x0, #0xf]
    // 0x114a184: DecompressPointer r1
    //     0x114a184: add             x1, x1, HEAP, lsl #32
    // 0x114a188: r0 = _deepHash()
    //     0x114a188: bl              #0x1149b58  ; [package:firebase_core_platform_interface/src/pigeon/messages.pigeon.dart] ::_deepHash
    // 0x114a18c: mov             x1, x0
    // 0x114a190: ldur            x0, [fp, #-0x68]
    // 0x114a194: eor             x2, x0, x1
    // 0x114a198: ldur            x0, [fp, #-0x50]
    // 0x114a19c: add             x3, x0, x2
    // 0x114a1a0: ldur            x2, [fp, #-0x58]
    // 0x114a1a4: b               #0x114a104
    // 0x114a1a8: ldur            x0, [fp, #-0x50]
    // 0x114a1ac: mov             x1, x0
    // 0x114a1b0: b               #0x114a238
    // 0x114a1b4: ldur            x1, [fp, #-0x40]
    // 0x114a1b8: r0 = 60
    //     0x114a1b8: mov             x0, #0x3c
    // 0x114a1bc: branchIfSmi(r1, 0x114a1c8)
    //     0x114a1bc: tbz             w1, #0, #0x114a1c8
    // 0x114a1c0: r0 = LoadClassIdInstr(r1)
    //     0x114a1c0: ldur            x0, [x1, #-1]
    //     0x114a1c4: ubfx            x0, x0, #0xc, #0x14
    // 0x114a1c8: cmp             x0, #0x3e
    // 0x114a1cc: b.ne            #0x114a1e4
    // 0x114a1d0: LoadField: d0 = r1->field_7
    //     0x114a1d0: ldur            d0, [x1, #7]
    // 0x114a1d4: fcmp            d0, d0
    // 0x114a1d8: b.vc            #0x114a1e4
    // 0x114a1dc: ldur            x1, [fp, #-0x18]
    // 0x114a1e0: b               #0x114a238
    // 0x114a1e4: cmp             x0, #0x3e
    // 0x114a1e8: b.ne            #0x114a204
    // 0x114a1ec: d0 = 0.000000
    //     0x114a1ec: eor             v0.16b, v0.16b, v0.16b
    // 0x114a1f0: LoadField: d1 = r1->field_7
    //     0x114a1f0: ldur            d1, [x1, #7]
    // 0x114a1f4: fcmp            d1, d0
    // 0x114a1f8: b.ne            #0x114a208
    // 0x114a1fc: ldur            x1, [fp, #-0x20]
    // 0x114a200: b               #0x114a238
    // 0x114a204: d0 = 0.000000
    //     0x114a204: eor             v0.16b, v0.16b, v0.16b
    // 0x114a208: r0 = 60
    //     0x114a208: mov             x0, #0x3c
    // 0x114a20c: branchIfSmi(r1, 0x114a218)
    //     0x114a20c: tbz             w1, #0, #0x114a218
    // 0x114a210: r0 = LoadClassIdInstr(r1)
    //     0x114a210: ldur            x0, [x1, #-1]
    //     0x114a214: ubfx            x0, x0, #0xc, #0x14
    // 0x114a218: str             x1, [SP]
    // 0x114a21c: r0 = GDT[cid_x0 + 0x70de]()
    //     0x114a21c: mov             x17, #0x70de
    //     0x114a220: add             lr, x0, x17
    //     0x114a224: ldr             lr, [x21, lr, lsl #3]
    //     0x114a228: blr             lr
    // 0x114a22c: r1 = LoadInt32Instr(r0)
    //     0x114a22c: sbfx            x1, x0, #1, #0x1f
    //     0x114a230: tbz             w0, #0, #0x114a238
    //     0x114a234: ldur            x1, [x0, #7]
    // 0x114a238: ldur            x0, [fp, #-0x48]
    // 0x114a23c: r16 = 31
    //     0x114a23c: mov             x16, #0x1f
    // 0x114a240: mul             x3, x1, x16
    // 0x114a244: stur            x3, [fp, #-0x50]
    // 0x114a248: LoadField: r4 = r0->field_f
    //     0x114a248: ldur            w4, [x0, #0xf]
    // 0x114a24c: DecompressPointer r4
    //     0x114a24c: add             x4, x4, HEAP, lsl #32
    // 0x114a250: mov             x0, x4
    // 0x114a254: stur            x4, [fp, #-0x40]
    // 0x114a258: r2 = Null
    //     0x114a258: mov             x2, NULL
    // 0x114a25c: r1 = Null
    //     0x114a25c: mov             x1, NULL
    // 0x114a260: cmp             w0, NULL
    // 0x114a264: b.eq            #0x114a308
    // 0x114a268: branchIfSmi(r0, 0x114a308)
    //     0x114a268: tbz             w0, #0, #0x114a308
    // 0x114a26c: r3 = LoadClassIdInstr(r0)
    //     0x114a26c: ldur            x3, [x0, #-1]
    //     0x114a270: ubfx            x3, x3, #0xc, #0x14
    // 0x114a274: r17 = 7631
    //     0x114a274: mov             x17, #0x1dcf
    // 0x114a278: cmp             x3, x17
    // 0x114a27c: b.eq            #0x114a310
    // 0x114a280: sub             x3, x3, #0x5a
    // 0x114a284: cmp             x3, #2
    // 0x114a288: b.ls            #0x114a310
    // 0x114a28c: r4 = LoadClassIdInstr(r0)
    //     0x114a28c: ldur            x4, [x0, #-1]
    //     0x114a290: ubfx            x4, x4, #0xc, #0x14
    // 0x114a294: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x114a298: ldr             x3, [x3, #0x18]
    // 0x114a29c: ldr             x3, [x3, x4, lsl #3]
    // 0x114a2a0: LoadField: r3 = r3->field_2b
    //     0x114a2a0: ldur            w3, [x3, #0x2b]
    // 0x114a2a4: DecompressPointer r3
    //     0x114a2a4: add             x3, x3, HEAP, lsl #32
    // 0x114a2a8: cmp             w3, NULL
    // 0x114a2ac: b.eq            #0x114a308
    // 0x114a2b0: LoadField: r3 = r3->field_f
    //     0x114a2b0: ldur            w3, [x3, #0xf]
    // 0x114a2b4: lsr             x3, x3, #3
    // 0x114a2b8: r17 = 7631
    //     0x114a2b8: mov             x17, #0x1dcf
    // 0x114a2bc: cmp             x3, x17
    // 0x114a2c0: b.eq            #0x114a310
    // 0x114a2c4: r3 = SubtypeTestCache
    //     0x114a2c4: add             x3, PP, #0xc, lsl #12  ; [pp+0xcea0] SubtypeTestCache
    //     0x114a2c8: ldr             x3, [x3, #0xea0]
    // 0x114a2cc: r30 = Subtype1TestCacheStub
    //     0x114a2cc: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x114a2d0: LoadField: r30 = r30->field_7
    //     0x114a2d0: ldur            lr, [lr, #7]
    // 0x114a2d4: blr             lr
    // 0x114a2d8: cmp             w7, NULL
    // 0x114a2dc: b.eq            #0x114a2e8
    // 0x114a2e0: tbnz            w7, #4, #0x114a308
    // 0x114a2e4: b               #0x114a310
    // 0x114a2e8: r8 = List
    //     0x114a2e8: add             x8, PP, #0xc, lsl #12  ; [pp+0xcea8] Type: List
    //     0x114a2ec: ldr             x8, [x8, #0xea8]
    // 0x114a2f0: r3 = SubtypeTestCache
    //     0x114a2f0: add             x3, PP, #0xc, lsl #12  ; [pp+0xceb0] SubtypeTestCache
    //     0x114a2f4: ldr             x3, [x3, #0xeb0]
    // 0x114a2f8: r30 = InstanceOfStub
    //     0x114a2f8: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x114a2fc: LoadField: r30 = r30->field_7
    //     0x114a2fc: ldur            lr, [lr, #7]
    // 0x114a300: blr             lr
    // 0x114a304: b               #0x114a314
    // 0x114a308: r0 = false
    //     0x114a308: add             x0, NULL, #0x30  ; false
    // 0x114a30c: b               #0x114a314
    // 0x114a310: r0 = true
    //     0x114a310: add             x0, NULL, #0x20  ; true
    // 0x114a314: tbnz            w0, #4, #0x114a360
    // 0x114a318: ldur            x3, [fp, #-0x40]
    // 0x114a31c: r0 = LoadClassIdInstr(r3)
    //     0x114a31c: ldur            x0, [x3, #-1]
    //     0x114a320: ubfx            x0, x0, #0xc, #0x14
    // 0x114a324: r16 = <Object?>
    //     0x114a324: ldr             x16, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0x114a328: stp             x3, x16, [SP, #8]
    // 0x114a32c: r16 = Closure: (Object?) => int from Function '_deepHash@1280305088': static.
    //     0x114a32c: add             x16, PP, #0xc, lsl #12  ; [pp+0xce48] Closure: (Object?) => int from Function '_deepHash@1280305088': static. (0x7f2adb03170c)
    //     0x114a330: ldr             x16, [x16, #0xe48]
    // 0x114a334: str             x16, [SP]
    // 0x114a338: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x114a338: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x114a33c: r0 = GDT[cid_x0 + 0x12caa]()
    //     0x114a33c: mov             x17, #0x2caa
    //     0x114a340: movk            x17, #1, lsl #16
    //     0x114a344: add             lr, x0, x17
    //     0x114a348: ldr             lr, [x21, lr, lsl #3]
    //     0x114a34c: blr             lr
    // 0x114a350: mov             x1, x0
    // 0x114a354: r0 = hashAll()
    //     0x114a354: bl              #0x112b348  ; [dart:core] Object::hashAll
    // 0x114a358: mov             x2, x0
    // 0x114a35c: b               #0x114a5a0
    // 0x114a360: ldur            x3, [fp, #-0x40]
    // 0x114a364: mov             x0, x3
    // 0x114a368: r2 = Null
    //     0x114a368: mov             x2, NULL
    // 0x114a36c: r1 = Null
    //     0x114a36c: mov             x1, NULL
    // 0x114a370: cmp             w0, NULL
    // 0x114a374: b.eq            #0x114a40c
    // 0x114a378: branchIfSmi(r0, 0x114a40c)
    //     0x114a378: tbz             w0, #0, #0x114a40c
    // 0x114a37c: r3 = LoadClassIdInstr(r0)
    //     0x114a37c: ldur            x3, [x0, #-1]
    //     0x114a380: ubfx            x3, x3, #0xc, #0x14
    // 0x114a384: r17 = 7630
    //     0x114a384: mov             x17, #0x1dce
    // 0x114a388: cmp             x3, x17
    // 0x114a38c: b.eq            #0x114a414
    // 0x114a390: r4 = LoadClassIdInstr(r0)
    //     0x114a390: ldur            x4, [x0, #-1]
    //     0x114a394: ubfx            x4, x4, #0xc, #0x14
    // 0x114a398: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x114a39c: ldr             x3, [x3, #0x18]
    // 0x114a3a0: ldr             x3, [x3, x4, lsl #3]
    // 0x114a3a4: LoadField: r3 = r3->field_2b
    //     0x114a3a4: ldur            w3, [x3, #0x2b]
    // 0x114a3a8: DecompressPointer r3
    //     0x114a3a8: add             x3, x3, HEAP, lsl #32
    // 0x114a3ac: cmp             w3, NULL
    // 0x114a3b0: b.eq            #0x114a40c
    // 0x114a3b4: LoadField: r3 = r3->field_f
    //     0x114a3b4: ldur            w3, [x3, #0xf]
    // 0x114a3b8: lsr             x3, x3, #3
    // 0x114a3bc: r17 = 7630
    //     0x114a3bc: mov             x17, #0x1dce
    // 0x114a3c0: cmp             x3, x17
    // 0x114a3c4: b.eq            #0x114a414
    // 0x114a3c8: r3 = SubtypeTestCache
    //     0x114a3c8: add             x3, PP, #0xc, lsl #12  ; [pp+0xceb8] SubtypeTestCache
    //     0x114a3cc: ldr             x3, [x3, #0xeb8]
    // 0x114a3d0: r30 = Subtype1TestCacheStub
    //     0x114a3d0: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x114a3d4: LoadField: r30 = r30->field_7
    //     0x114a3d4: ldur            lr, [lr, #7]
    // 0x114a3d8: blr             lr
    // 0x114a3dc: cmp             w7, NULL
    // 0x114a3e0: b.eq            #0x114a3ec
    // 0x114a3e4: tbnz            w7, #4, #0x114a40c
    // 0x114a3e8: b               #0x114a414
    // 0x114a3ec: r8 = Map
    //     0x114a3ec: add             x8, PP, #0xc, lsl #12  ; [pp+0xcec0] Type: Map
    //     0x114a3f0: ldr             x8, [x8, #0xec0]
    // 0x114a3f4: r3 = SubtypeTestCache
    //     0x114a3f4: add             x3, PP, #0xc, lsl #12  ; [pp+0xcec8] SubtypeTestCache
    //     0x114a3f8: ldr             x3, [x3, #0xec8]
    // 0x114a3fc: r30 = InstanceOfStub
    //     0x114a3fc: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x114a400: LoadField: r30 = r30->field_7
    //     0x114a400: ldur            lr, [lr, #7]
    // 0x114a404: blr             lr
    // 0x114a408: b               #0x114a418
    // 0x114a40c: r0 = false
    //     0x114a40c: add             x0, NULL, #0x30  ; false
    // 0x114a410: b               #0x114a418
    // 0x114a414: r0 = true
    //     0x114a414: add             x0, NULL, #0x20  ; true
    // 0x114a418: tbnz            w0, #4, #0x114a518
    // 0x114a41c: ldur            x1, [fp, #-0x40]
    // 0x114a420: r0 = LoadClassIdInstr(r1)
    //     0x114a420: ldur            x0, [x1, #-1]
    //     0x114a424: ubfx            x0, x0, #0xc, #0x14
    // 0x114a428: r0 = GDT[cid_x0 + 0xfc4]()
    //     0x114a428: add             lr, x0, #0xfc4
    //     0x114a42c: ldr             lr, [x21, lr, lsl #3]
    //     0x114a430: blr             lr
    // 0x114a434: r1 = LoadClassIdInstr(r0)
    //     0x114a434: ldur            x1, [x0, #-1]
    //     0x114a438: ubfx            x1, x1, #0xc, #0x14
    // 0x114a43c: mov             x16, x0
    // 0x114a440: mov             x0, x1
    // 0x114a444: mov             x1, x16
    // 0x114a448: r0 = GDT[cid_x0 + 0x12641]()
    //     0x114a448: mov             x17, #0x2641
    //     0x114a44c: movk            x17, #1, lsl #16
    //     0x114a450: add             lr, x0, x17
    //     0x114a454: ldr             lr, [x21, lr, lsl #3]
    //     0x114a458: blr             lr
    // 0x114a45c: mov             x2, x0
    // 0x114a460: stur            x2, [fp, #-0x48]
    // 0x114a464: r3 = 0
    //     0x114a464: mov             x3, #0
    // 0x114a468: stur            x3, [fp, #-0x68]
    // 0x114a46c: CheckStackOverflow
    //     0x114a46c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x114a470: cmp             SP, x16
    //     0x114a474: b.ls            #0x114a704
    // 0x114a478: r0 = LoadClassIdInstr(r2)
    //     0x114a478: ldur            x0, [x2, #-1]
    //     0x114a47c: ubfx            x0, x0, #0xc, #0x14
    // 0x114a480: mov             x1, x2
    // 0x114a484: r0 = GDT[cid_x0 + 0x1845b]()
    //     0x114a484: mov             x17, #0x845b
    //     0x114a488: movk            x17, #1, lsl #16
    //     0x114a48c: add             lr, x0, x17
    //     0x114a490: ldr             lr, [x21, lr, lsl #3]
    //     0x114a494: blr             lr
    // 0x114a498: tbnz            w0, #4, #0x114a50c
    // 0x114a49c: ldur            x2, [fp, #-0x48]
    // 0x114a4a0: ldur            x3, [fp, #-0x68]
    // 0x114a4a4: r0 = LoadClassIdInstr(r2)
    //     0x114a4a4: ldur            x0, [x2, #-1]
    //     0x114a4a8: ubfx            x0, x0, #0xc, #0x14
    // 0x114a4ac: mov             x1, x2
    // 0x114a4b0: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0x114a4b0: mov             x17, #0x7d4c
    //     0x114a4b4: movk            x17, #1, lsl #16
    //     0x114a4b8: add             lr, x0, x17
    //     0x114a4bc: ldr             lr, [x21, lr, lsl #3]
    //     0x114a4c0: blr             lr
    // 0x114a4c4: stur            x0, [fp, #-0x58]
    // 0x114a4c8: LoadField: r1 = r0->field_b
    //     0x114a4c8: ldur            w1, [x0, #0xb]
    // 0x114a4cc: DecompressPointer r1
    //     0x114a4cc: add             x1, x1, HEAP, lsl #32
    // 0x114a4d0: r0 = _deepHash()
    //     0x114a4d0: bl              #0x1149b58  ; [package:firebase_core_platform_interface/src/pigeon/messages.pigeon.dart] ::_deepHash
    // 0x114a4d4: r16 = 31
    //     0x114a4d4: mov             x16, #0x1f
    // 0x114a4d8: mul             x2, x0, x16
    // 0x114a4dc: ldur            x0, [fp, #-0x58]
    // 0x114a4e0: stur            x2, [fp, #-0x70]
    // 0x114a4e4: LoadField: r1 = r0->field_f
    //     0x114a4e4: ldur            w1, [x0, #0xf]
    // 0x114a4e8: DecompressPointer r1
    //     0x114a4e8: add             x1, x1, HEAP, lsl #32
    // 0x114a4ec: r0 = _deepHash()
    //     0x114a4ec: bl              #0x1149b58  ; [package:firebase_core_platform_interface/src/pigeon/messages.pigeon.dart] ::_deepHash
    // 0x114a4f0: mov             x1, x0
    // 0x114a4f4: ldur            x0, [fp, #-0x70]
    // 0x114a4f8: eor             x2, x0, x1
    // 0x114a4fc: ldur            x0, [fp, #-0x68]
    // 0x114a500: add             x3, x0, x2
    // 0x114a504: ldur            x2, [fp, #-0x48]
    // 0x114a508: b               #0x114a468
    // 0x114a50c: ldur            x0, [fp, #-0x68]
    // 0x114a510: mov             x2, x0
    // 0x114a514: b               #0x114a5a0
    // 0x114a518: ldur            x1, [fp, #-0x40]
    // 0x114a51c: r0 = 60
    //     0x114a51c: mov             x0, #0x3c
    // 0x114a520: branchIfSmi(r1, 0x114a52c)
    //     0x114a520: tbz             w1, #0, #0x114a52c
    // 0x114a524: r0 = LoadClassIdInstr(r1)
    //     0x114a524: ldur            x0, [x1, #-1]
    //     0x114a528: ubfx            x0, x0, #0xc, #0x14
    // 0x114a52c: cmp             x0, #0x3e
    // 0x114a530: b.ne            #0x114a548
    // 0x114a534: LoadField: d0 = r1->field_7
    //     0x114a534: ldur            d0, [x1, #7]
    // 0x114a538: fcmp            d0, d0
    // 0x114a53c: b.vc            #0x114a548
    // 0x114a540: ldur            x2, [fp, #-0x28]
    // 0x114a544: b               #0x114a5a0
    // 0x114a548: cmp             x0, #0x3e
    // 0x114a54c: b.ne            #0x114a568
    // 0x114a550: d0 = 0.000000
    //     0x114a550: eor             v0.16b, v0.16b, v0.16b
    // 0x114a554: LoadField: d1 = r1->field_7
    //     0x114a554: ldur            d1, [x1, #7]
    // 0x114a558: fcmp            d1, d0
    // 0x114a55c: b.ne            #0x114a56c
    // 0x114a560: ldur            x2, [fp, #-0x30]
    // 0x114a564: b               #0x114a5a0
    // 0x114a568: d0 = 0.000000
    //     0x114a568: eor             v0.16b, v0.16b, v0.16b
    // 0x114a56c: r0 = 60
    //     0x114a56c: mov             x0, #0x3c
    // 0x114a570: branchIfSmi(r1, 0x114a57c)
    //     0x114a570: tbz             w1, #0, #0x114a57c
    // 0x114a574: r0 = LoadClassIdInstr(r1)
    //     0x114a574: ldur            x0, [x1, #-1]
    //     0x114a578: ubfx            x0, x0, #0xc, #0x14
    // 0x114a57c: str             x1, [SP]
    // 0x114a580: r0 = GDT[cid_x0 + 0x70de]()
    //     0x114a580: mov             x17, #0x70de
    //     0x114a584: add             lr, x0, x17
    //     0x114a588: ldr             lr, [x21, lr, lsl #3]
    //     0x114a58c: blr             lr
    // 0x114a590: r1 = LoadInt32Instr(r0)
    //     0x114a590: sbfx            x1, x0, #1, #0x1f
    //     0x114a594: tbz             w0, #0, #0x114a59c
    //     0x114a598: ldur            x1, [x0, #7]
    // 0x114a59c: mov             x2, x1
    // 0x114a5a0: ldur            x1, [fp, #-0x10]
    // 0x114a5a4: ldur            x0, [fp, #-0x50]
    // 0x114a5a8: eor             x3, x0, x2
    // 0x114a5ac: add             x7, x1, x3
    // 0x114a5b0: ldur            x2, [fp, #-0x38]
    // 0x114a5b4: ldur            x5, [fp, #-0x20]
    // 0x114a5b8: ldur            x3, [fp, #-0x30]
    // 0x114a5bc: ldur            x6, [fp, #-0x18]
    // 0x114a5c0: ldur            x4, [fp, #-0x28]
    // 0x114a5c4: d0 = 0.000000
    //     0x114a5c4: eor             v0.16b, v0.16b, v0.16b
    // 0x114a5c8: b               #0x1149e84
    // 0x114a5cc: ldur            x1, [fp, #-0x10]
    // 0x114a5d0: mov             x0, x1
    // 0x114a5d4: LeaveFrame
    //     0x114a5d4: mov             SP, fp
    //     0x114a5d8: ldp             fp, lr, [SP], #0x10
    // 0x114a5dc: ret
    //     0x114a5dc: ret             
    // 0x114a5e0: ldur            x1, [fp, #-8]
    // 0x114a5e4: r0 = 9221120237041090560
    //     0x114a5e4: add             x0, PP, #0xc, lsl #12  ; [pp+0xce68] 0x7ff8000000000000
    //     0x114a5e8: ldr             x0, [x0, #0xe68]
    // 0x114a5ec: r2 = 60
    //     0x114a5ec: mov             x2, #0x3c
    // 0x114a5f0: branchIfSmi(r1, 0x114a5fc)
    //     0x114a5f0: tbz             w1, #0, #0x114a5fc
    // 0x114a5f4: r2 = LoadClassIdInstr(r1)
    //     0x114a5f4: ldur            x2, [x1, #-1]
    //     0x114a5f8: ubfx            x2, x2, #0xc, #0x14
    // 0x114a5fc: cmp             x2, #0x3e
    // 0x114a600: b.ne            #0x114a63c
    // 0x114a604: LoadField: d0 = r1->field_7
    //     0x114a604: ldur            d0, [x1, #7]
    // 0x114a608: fcmp            d0, d0
    // 0x114a60c: b.vc            #0x114a63c
    // 0x114a610: LoadField: r16 = r0->field_7
    //     0x114a610: ldur            x16, [x0, #7]
    // 0x114a614: r17 = 11601
    //     0x114a614: mov             x17, #0x2d51
    // 0x114a618: mul             x1, x16, x17
    // 0x114a61c: umulh           x16, x16, x17
    // 0x114a620: eor             x1, x1, x16
    // 0x114a624: r1 = 0
    //     0x114a624: eor             x1, x1, x1, lsr #32
    // 0x114a628: ubfiz           x1, x1, #1, #0x1e
    // 0x114a62c: r0 = LoadInt32Instr(r1)
    //     0x114a62c: sbfx            x0, x1, #1, #0x1f
    // 0x114a630: LeaveFrame
    //     0x114a630: mov             SP, fp
    //     0x114a634: ldp             fp, lr, [SP], #0x10
    // 0x114a638: ret
    //     0x114a638: ret             
    // 0x114a63c: cmp             x2, #0x3e
    // 0x114a640: b.ne            #0x114a6ac
    // 0x114a644: d0 = 0.000000
    //     0x114a644: eor             v0.16b, v0.16b, v0.16b
    // 0x114a648: LoadField: d1 = r1->field_7
    //     0x114a648: ldur            d1, [x1, #7]
    // 0x114a64c: fcmp            d1, d0
    // 0x114a650: b.ne            #0x114a6ac
    // 0x114a654: mov             x16, v0.d[0]
    // 0x114a658: and             x16, x16, #0x7ff0000000000000
    // 0x114a65c: r17 = 9218868437227405312
    //     0x114a65c: mov             x17, #0x7ff0000000000000
    // 0x114a660: cmp             x16, x17
    // 0x114a664: b.eq            #0x114a694
    // 0x114a668: fcvtzs          x16, d0
    // 0x114a66c: scvtf           d1, x16
    // 0x114a670: fcmp            d1, d0
    // 0x114a674: b.ne            #0x114a694
    // 0x114a678: r17 = 11601
    //     0x114a678: mov             x17, #0x2d51
    // 0x114a67c: mul             x0, x16, x17
    // 0x114a680: umulh           x16, x16, x17
    // 0x114a684: eor             x0, x0, x16
    // 0x114a688: r0 = 0
    //     0x114a688: eor             x0, x0, x0, lsr #32
    // 0x114a68c: and             x0, x0, #0x3fffffff
    // 0x114a690: b               #0x114a6a0
    // 0x114a694: r0 = 0.000000
    //     0x114a694: fmov            x0, d0
    // 0x114a698: r0 = 0
    //     0x114a698: eor             x0, x0, x0, lsr #32
    // 0x114a69c: and             x0, x0, #0x3fffffff
    // 0x114a6a0: LeaveFrame
    //     0x114a6a0: mov             SP, fp
    //     0x114a6a4: ldp             fp, lr, [SP], #0x10
    // 0x114a6a8: ret
    //     0x114a6a8: ret             
    // 0x114a6ac: r0 = 60
    //     0x114a6ac: mov             x0, #0x3c
    // 0x114a6b0: branchIfSmi(r1, 0x114a6bc)
    //     0x114a6b0: tbz             w1, #0, #0x114a6bc
    // 0x114a6b4: r0 = LoadClassIdInstr(r1)
    //     0x114a6b4: ldur            x0, [x1, #-1]
    //     0x114a6b8: ubfx            x0, x0, #0xc, #0x14
    // 0x114a6bc: str             x1, [SP]
    // 0x114a6c0: r0 = GDT[cid_x0 + 0x70de]()
    //     0x114a6c0: mov             x17, #0x70de
    //     0x114a6c4: add             lr, x0, x17
    //     0x114a6c8: ldr             lr, [x21, lr, lsl #3]
    //     0x114a6cc: blr             lr
    // 0x114a6d0: r1 = LoadInt32Instr(r0)
    //     0x114a6d0: sbfx            x1, x0, #1, #0x1f
    //     0x114a6d4: tbz             w0, #0, #0x114a6dc
    //     0x114a6d8: ldur            x1, [x0, #7]
    // 0x114a6dc: mov             x0, x1
    // 0x114a6e0: LeaveFrame
    //     0x114a6e0: mov             SP, fp
    //     0x114a6e4: ldp             fp, lr, [SP], #0x10
    // 0x114a6e8: ret
    //     0x114a6e8: ret             
    // 0x114a6ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x114a6ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x114a6f0: b               #0x1149b78
    // 0x114a6f4: r0 = StackOverflowSharedWithFPURegs()
    //     0x114a6f4: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x114a6f8: b               #0x1149e94
    // 0x114a6fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x114a6fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x114a700: b               #0x114a114
    // 0x114a704: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x114a704: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x114a708: b               #0x114a478
  }
  [closure] static int _deepHash(dynamic, Object?) {
    // ** addr: 0x114a70c, size: 0x48
    // 0x114a70c: EnterFrame
    //     0x114a70c: stp             fp, lr, [SP, #-0x10]!
    //     0x114a710: mov             fp, SP
    // 0x114a714: CheckStackOverflow
    //     0x114a714: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x114a718: cmp             SP, x16
    //     0x114a71c: b.ls            #0x114a74c
    // 0x114a720: ldr             x1, [fp, #0x10]
    // 0x114a724: r0 = _deepHash()
    //     0x114a724: bl              #0x1149b58  ; [package:firebase_core_platform_interface/src/pigeon/messages.pigeon.dart] ::_deepHash
    // 0x114a728: mov             x2, x0
    // 0x114a72c: r0 = BoxInt64Instr(r2)
    //     0x114a72c: sbfiz           x0, x2, #1, #0x1f
    //     0x114a730: cmp             x2, x0, asr #1
    //     0x114a734: b.eq            #0x114a740
    //     0x114a738: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x114a73c: stur            x2, [x0, #7]
    // 0x114a740: LeaveFrame
    //     0x114a740: mov             SP, fp
    //     0x114a744: ldp             fp, lr, [SP], #0x10
    // 0x114a748: ret
    //     0x114a748: ret             
    // 0x114a74c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x114a74c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x114a750: b               #0x114a720
  }
  static bool _deepEquals(Object?, Object?) {
    // ** addr: 0x12941bc, size: 0x78c
    // 0x12941bc: EnterFrame
    //     0x12941bc: stp             fp, lr, [SP, #-0x10]!
    //     0x12941c0: mov             fp, SP
    // 0x12941c4: AllocStack(0x50)
    //     0x12941c4: sub             SP, SP, #0x50
    // 0x12941c8: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0x12941c8: mov             x0, x1
    //     0x12941cc: stur            x1, [fp, #-8]
    //     0x12941d0: mov             x1, x2
    //     0x12941d4: stur            x2, [fp, #-0x10]
    // 0x12941d8: CheckStackOverflow
    //     0x12941d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12941dc: cmp             SP, x16
    //     0x12941e0: b.ls            #0x1294930
    // 0x12941e4: r1 = 1
    //     0x12941e4: mov             x1, #1
    // 0x12941e8: r0 = AllocateContext()
    //     0x12941e8: bl              #0x13de838  ; AllocateContextStub
    // 0x12941ec: mov             x3, x0
    // 0x12941f0: ldur            x2, [fp, #-0x10]
    // 0x12941f4: stur            x3, [fp, #-0x18]
    // 0x12941f8: StoreField: r3->field_f = r2
    //     0x12941f8: stur            w2, [x3, #0xf]
    // 0x12941fc: ldur            x0, [fp, #-8]
    // 0x1294200: mov             x1, x2
    // 0x1294204: stp             x1, x0, [SP, #-0x10]!
    // 0x1294208: r30 = OptimizedIdenticalWithNumberCheckStub
    //     0x1294208: ldr             lr, [PP, #0x428]  ; [pp+0x428] Stub: OptimizedIdenticalWithNumberCheck (0x7d32ac)
    // 0x129420c: LoadField: r30 = r30->field_7
    //     0x129420c: ldur            lr, [lr, #7]
    // 0x1294210: blr             lr
    // 0x1294214: ldp             x1, x0, [SP], #0x10
    // 0x1294218: b.ne            #0x129422c
    // 0x129421c: r0 = true
    //     0x129421c: add             x0, NULL, #0x20  ; true
    // 0x1294220: LeaveFrame
    //     0x1294220: mov             SP, fp
    //     0x1294224: ldp             fp, lr, [SP], #0x10
    // 0x1294228: ret
    //     0x1294228: ret             
    // 0x129422c: ldur            x3, [fp, #-8]
    // 0x1294230: r0 = 60
    //     0x1294230: mov             x0, #0x3c
    // 0x1294234: branchIfSmi(r3, 0x1294240)
    //     0x1294234: tbz             w3, #0, #0x1294240
    // 0x1294238: r0 = LoadClassIdInstr(r3)
    //     0x1294238: ldur            x0, [x3, #-1]
    //     0x129423c: ubfx            x0, x0, #0xc, #0x14
    // 0x1294240: cmp             x0, #0x3e
    // 0x1294244: b.ne            #0x12942a0
    // 0x1294248: ldur            x4, [fp, #-0x10]
    // 0x129424c: r0 = 60
    //     0x129424c: mov             x0, #0x3c
    // 0x1294250: branchIfSmi(r4, 0x129425c)
    //     0x1294250: tbz             w4, #0, #0x129425c
    // 0x1294254: r0 = LoadClassIdInstr(r4)
    //     0x1294254: ldur            x0, [x4, #-1]
    //     0x1294258: ubfx            x0, x0, #0xc, #0x14
    // 0x129425c: cmp             x0, #0x3e
    // 0x1294260: b.ne            #0x12942a4
    // 0x1294264: LoadField: d0 = r3->field_7
    //     0x1294264: ldur            d0, [x3, #7]
    // 0x1294268: fcmp            d0, d0
    // 0x129426c: b.vc            #0x129428c
    // 0x1294270: LoadField: d0 = r4->field_7
    //     0x1294270: ldur            d0, [x4, #7]
    // 0x1294274: fcmp            d0, d0
    // 0x1294278: b.vc            #0x129428c
    // 0x129427c: r0 = true
    //     0x129427c: add             x0, NULL, #0x20  ; true
    // 0x1294280: LeaveFrame
    //     0x1294280: mov             SP, fp
    //     0x1294284: ldp             fp, lr, [SP], #0x10
    // 0x1294288: ret
    //     0x1294288: ret             
    // 0x129428c: stp             x4, x3, [SP]
    // 0x1294290: r0 = ==()
    //     0x1294290: bl              #0x12b7c00  ; [dart:core] _Double::==
    // 0x1294294: LeaveFrame
    //     0x1294294: mov             SP, fp
    //     0x1294298: ldp             fp, lr, [SP], #0x10
    // 0x129429c: ret
    //     0x129429c: ret             
    // 0x12942a0: ldur            x4, [fp, #-0x10]
    // 0x12942a4: mov             x0, x3
    // 0x12942a8: r2 = Null
    //     0x12942a8: mov             x2, NULL
    // 0x12942ac: r1 = Null
    //     0x12942ac: mov             x1, NULL
    // 0x12942b0: cmp             w0, NULL
    // 0x12942b4: b.eq            #0x1294358
    // 0x12942b8: branchIfSmi(r0, 0x1294358)
    //     0x12942b8: tbz             w0, #0, #0x1294358
    // 0x12942bc: r3 = LoadClassIdInstr(r0)
    //     0x12942bc: ldur            x3, [x0, #-1]
    //     0x12942c0: ubfx            x3, x3, #0xc, #0x14
    // 0x12942c4: r17 = 7631
    //     0x12942c4: mov             x17, #0x1dcf
    // 0x12942c8: cmp             x3, x17
    // 0x12942cc: b.eq            #0x1294360
    // 0x12942d0: sub             x3, x3, #0x5a
    // 0x12942d4: cmp             x3, #2
    // 0x12942d8: b.ls            #0x1294360
    // 0x12942dc: r4 = LoadClassIdInstr(r0)
    //     0x12942dc: ldur            x4, [x0, #-1]
    //     0x12942e0: ubfx            x4, x4, #0xc, #0x14
    // 0x12942e4: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x12942e8: ldr             x3, [x3, #0x18]
    // 0x12942ec: ldr             x3, [x3, x4, lsl #3]
    // 0x12942f0: LoadField: r3 = r3->field_2b
    //     0x12942f0: ldur            w3, [x3, #0x2b]
    // 0x12942f4: DecompressPointer r3
    //     0x12942f4: add             x3, x3, HEAP, lsl #32
    // 0x12942f8: cmp             w3, NULL
    // 0x12942fc: b.eq            #0x1294358
    // 0x1294300: LoadField: r3 = r3->field_f
    //     0x1294300: ldur            w3, [x3, #0xf]
    // 0x1294304: lsr             x3, x3, #3
    // 0x1294308: r17 = 7631
    //     0x1294308: mov             x17, #0x1dcf
    // 0x129430c: cmp             x3, x17
    // 0x1294310: b.eq            #0x1294360
    // 0x1294314: r3 = SubtypeTestCache
    //     0x1294314: add             x3, PP, #0xc, lsl #12  ; [pp+0xced0] SubtypeTestCache
    //     0x1294318: ldr             x3, [x3, #0xed0]
    // 0x129431c: r30 = Subtype1TestCacheStub
    //     0x129431c: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x1294320: LoadField: r30 = r30->field_7
    //     0x1294320: ldur            lr, [lr, #7]
    // 0x1294324: blr             lr
    // 0x1294328: cmp             w7, NULL
    // 0x129432c: b.eq            #0x1294338
    // 0x1294330: tbnz            w7, #4, #0x1294358
    // 0x1294334: b               #0x1294360
    // 0x1294338: r8 = List
    //     0x1294338: add             x8, PP, #0xc, lsl #12  ; [pp+0xced8] Type: List
    //     0x129433c: ldr             x8, [x8, #0xed8]
    // 0x1294340: r3 = SubtypeTestCache
    //     0x1294340: add             x3, PP, #0xc, lsl #12  ; [pp+0xcee0] SubtypeTestCache
    //     0x1294344: ldr             x3, [x3, #0xee0]
    // 0x1294348: r30 = InstanceOfStub
    //     0x1294348: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x129434c: LoadField: r30 = r30->field_7
    //     0x129434c: ldur            lr, [lr, #7]
    // 0x1294350: blr             lr
    // 0x1294354: b               #0x1294364
    // 0x1294358: r0 = false
    //     0x1294358: add             x0, NULL, #0x30  ; false
    // 0x129435c: b               #0x1294364
    // 0x1294360: r0 = true
    //     0x1294360: add             x0, NULL, #0x20  ; true
    // 0x1294364: tbnz            w0, #4, #0x1294504
    // 0x1294368: ldur            x0, [fp, #-0x10]
    // 0x129436c: r2 = Null
    //     0x129436c: mov             x2, NULL
    // 0x1294370: r1 = Null
    //     0x1294370: mov             x1, NULL
    // 0x1294374: cmp             w0, NULL
    // 0x1294378: b.eq            #0x129441c
    // 0x129437c: branchIfSmi(r0, 0x129441c)
    //     0x129437c: tbz             w0, #0, #0x129441c
    // 0x1294380: r3 = LoadClassIdInstr(r0)
    //     0x1294380: ldur            x3, [x0, #-1]
    //     0x1294384: ubfx            x3, x3, #0xc, #0x14
    // 0x1294388: r17 = 7631
    //     0x1294388: mov             x17, #0x1dcf
    // 0x129438c: cmp             x3, x17
    // 0x1294390: b.eq            #0x1294424
    // 0x1294394: sub             x3, x3, #0x5a
    // 0x1294398: cmp             x3, #2
    // 0x129439c: b.ls            #0x1294424
    // 0x12943a0: r4 = LoadClassIdInstr(r0)
    //     0x12943a0: ldur            x4, [x0, #-1]
    //     0x12943a4: ubfx            x4, x4, #0xc, #0x14
    // 0x12943a8: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x12943ac: ldr             x3, [x3, #0x18]
    // 0x12943b0: ldr             x3, [x3, x4, lsl #3]
    // 0x12943b4: LoadField: r3 = r3->field_2b
    //     0x12943b4: ldur            w3, [x3, #0x2b]
    // 0x12943b8: DecompressPointer r3
    //     0x12943b8: add             x3, x3, HEAP, lsl #32
    // 0x12943bc: cmp             w3, NULL
    // 0x12943c0: b.eq            #0x129441c
    // 0x12943c4: LoadField: r3 = r3->field_f
    //     0x12943c4: ldur            w3, [x3, #0xf]
    // 0x12943c8: lsr             x3, x3, #3
    // 0x12943cc: r17 = 7631
    //     0x12943cc: mov             x17, #0x1dcf
    // 0x12943d0: cmp             x3, x17
    // 0x12943d4: b.eq            #0x1294424
    // 0x12943d8: r3 = SubtypeTestCache
    //     0x12943d8: add             x3, PP, #0xc, lsl #12  ; [pp+0xcee8] SubtypeTestCache
    //     0x12943dc: ldr             x3, [x3, #0xee8]
    // 0x12943e0: r30 = Subtype1TestCacheStub
    //     0x12943e0: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x12943e4: LoadField: r30 = r30->field_7
    //     0x12943e4: ldur            lr, [lr, #7]
    // 0x12943e8: blr             lr
    // 0x12943ec: cmp             w7, NULL
    // 0x12943f0: b.eq            #0x12943fc
    // 0x12943f4: tbnz            w7, #4, #0x129441c
    // 0x12943f8: b               #0x1294424
    // 0x12943fc: r8 = List
    //     0x12943fc: add             x8, PP, #0xc, lsl #12  ; [pp+0xcef0] Type: List
    //     0x1294400: ldr             x8, [x8, #0xef0]
    // 0x1294404: r3 = SubtypeTestCache
    //     0x1294404: add             x3, PP, #0xc, lsl #12  ; [pp+0xcef8] SubtypeTestCache
    //     0x1294408: ldr             x3, [x3, #0xef8]
    // 0x129440c: r30 = InstanceOfStub
    //     0x129440c: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x1294410: LoadField: r30 = r30->field_7
    //     0x1294410: ldur            lr, [lr, #7]
    // 0x1294414: blr             lr
    // 0x1294418: b               #0x1294428
    // 0x129441c: r0 = false
    //     0x129441c: add             x0, NULL, #0x30  ; false
    // 0x1294420: b               #0x1294428
    // 0x1294424: r0 = true
    //     0x1294424: add             x0, NULL, #0x20  ; true
    // 0x1294428: tbnz            w0, #4, #0x12944fc
    // 0x129442c: ldur            x1, [fp, #-8]
    // 0x1294430: ldur            x2, [fp, #-0x18]
    // 0x1294434: r0 = LoadClassIdInstr(r1)
    //     0x1294434: ldur            x0, [x1, #-1]
    //     0x1294438: ubfx            x0, x0, #0xc, #0x14
    // 0x129443c: str             x1, [SP]
    // 0x1294440: r0 = GDT[cid_x0 + 0xf078]()
    //     0x1294440: mov             x17, #0xf078
    //     0x1294444: add             lr, x0, x17
    //     0x1294448: ldr             lr, [x21, lr, lsl #3]
    //     0x129444c: blr             lr
    // 0x1294450: mov             x1, x0
    // 0x1294454: ldur            x2, [fp, #-0x18]
    // 0x1294458: stur            x1, [fp, #-0x20]
    // 0x129445c: LoadField: r0 = r2->field_f
    //     0x129445c: ldur            w0, [x2, #0xf]
    // 0x1294460: DecompressPointer r0
    //     0x1294460: add             x0, x0, HEAP, lsl #32
    // 0x1294464: r3 = LoadClassIdInstr(r0)
    //     0x1294464: ldur            x3, [x0, #-1]
    //     0x1294468: ubfx            x3, x3, #0xc, #0x14
    // 0x129446c: str             x0, [SP]
    // 0x1294470: mov             x0, x3
    // 0x1294474: r0 = GDT[cid_x0 + 0xf078]()
    //     0x1294474: mov             x17, #0xf078
    //     0x1294478: add             lr, x0, x17
    //     0x129447c: ldr             lr, [x21, lr, lsl #3]
    //     0x1294480: blr             lr
    // 0x1294484: mov             x1, x0
    // 0x1294488: ldur            x0, [fp, #-0x20]
    // 0x129448c: r2 = LoadInt32Instr(r0)
    //     0x129448c: sbfx            x2, x0, #1, #0x1f
    //     0x1294490: tbz             w0, #0, #0x1294498
    //     0x1294494: ldur            x2, [x0, #7]
    // 0x1294498: r0 = LoadInt32Instr(r1)
    //     0x1294498: sbfx            x0, x1, #1, #0x1f
    //     0x129449c: tbz             w1, #0, #0x12944a4
    //     0x12944a0: ldur            x0, [x1, #7]
    // 0x12944a4: cmp             x2, x0
    // 0x12944a8: b.ne            #0x12944ec
    // 0x12944ac: ldur            x0, [fp, #-8]
    // 0x12944b0: r1 = <(int, dynamic), dynamic>
    //     0x12944b0: add             x1, PP, #0xc, lsl #12  ; [pp+0xcf08] TypeArguments: <(int, dynamic), dynamic>
    //     0x12944b4: ldr             x1, [x1, #0xf08]
    // 0x12944b8: r0 = EfficientLengthIndexedIterable()
    //     0x12944b8: bl              #0xb060f0  ; AllocateEfficientLengthIndexedIterableStub -> EfficientLengthIndexedIterable<C1X0> (size=0x18)
    // 0x12944bc: ldur            x3, [fp, #-8]
    // 0x12944c0: stur            x0, [fp, #-0x20]
    // 0x12944c4: StoreField: r0->field_b = r3
    //     0x12944c4: stur            w3, [x0, #0xb]
    // 0x12944c8: StoreField: r0->field_f = rZR
    //     0x12944c8: stur            xzr, [x0, #0xf]
    // 0x12944cc: ldur            x2, [fp, #-0x18]
    // 0x12944d0: r1 = Function '<anonymous closure>': static.
    //     0x12944d0: add             x1, PP, #0xc, lsl #12  ; [pp+0xcf10] AnonymousClosure: static (0x1294ab0), in [package:firebase_core_platform_interface/src/pigeon/messages.pigeon.dart] ::_deepEquals (0x12941bc)
    //     0x12944d4: ldr             x1, [x1, #0xf10]
    // 0x12944d8: r0 = AllocateClosure()
    //     0x12944d8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x12944dc: ldur            x1, [fp, #-0x20]
    // 0x12944e0: mov             x2, x0
    // 0x12944e4: r0 = every()
    //     0x12944e4: bl              #0x1294948  ; [dart:core] Iterable::every
    // 0x12944e8: b               #0x12944f0
    // 0x12944ec: r0 = false
    //     0x12944ec: add             x0, NULL, #0x30  ; false
    // 0x12944f0: LeaveFrame
    //     0x12944f0: mov             SP, fp
    //     0x12944f4: ldp             fp, lr, [SP], #0x10
    // 0x12944f8: ret
    //     0x12944f8: ret             
    // 0x12944fc: ldur            x3, [fp, #-8]
    // 0x1294500: b               #0x1294508
    // 0x1294504: ldur            x3, [fp, #-8]
    // 0x1294508: mov             x0, x3
    // 0x129450c: r2 = Null
    //     0x129450c: mov             x2, NULL
    // 0x1294510: r1 = Null
    //     0x1294510: mov             x1, NULL
    // 0x1294514: cmp             w0, NULL
    // 0x1294518: b.eq            #0x12945b0
    // 0x129451c: branchIfSmi(r0, 0x12945b0)
    //     0x129451c: tbz             w0, #0, #0x12945b0
    // 0x1294520: r3 = LoadClassIdInstr(r0)
    //     0x1294520: ldur            x3, [x0, #-1]
    //     0x1294524: ubfx            x3, x3, #0xc, #0x14
    // 0x1294528: r17 = 7630
    //     0x1294528: mov             x17, #0x1dce
    // 0x129452c: cmp             x3, x17
    // 0x1294530: b.eq            #0x12945b8
    // 0x1294534: r4 = LoadClassIdInstr(r0)
    //     0x1294534: ldur            x4, [x0, #-1]
    //     0x1294538: ubfx            x4, x4, #0xc, #0x14
    // 0x129453c: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x1294540: ldr             x3, [x3, #0x18]
    // 0x1294544: ldr             x3, [x3, x4, lsl #3]
    // 0x1294548: LoadField: r3 = r3->field_2b
    //     0x1294548: ldur            w3, [x3, #0x2b]
    // 0x129454c: DecompressPointer r3
    //     0x129454c: add             x3, x3, HEAP, lsl #32
    // 0x1294550: cmp             w3, NULL
    // 0x1294554: b.eq            #0x12945b0
    // 0x1294558: LoadField: r3 = r3->field_f
    //     0x1294558: ldur            w3, [x3, #0xf]
    // 0x129455c: lsr             x3, x3, #3
    // 0x1294560: r17 = 7630
    //     0x1294560: mov             x17, #0x1dce
    // 0x1294564: cmp             x3, x17
    // 0x1294568: b.eq            #0x12945b8
    // 0x129456c: r3 = SubtypeTestCache
    //     0x129456c: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf18] SubtypeTestCache
    //     0x1294570: ldr             x3, [x3, #0xf18]
    // 0x1294574: r30 = Subtype1TestCacheStub
    //     0x1294574: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x1294578: LoadField: r30 = r30->field_7
    //     0x1294578: ldur            lr, [lr, #7]
    // 0x129457c: blr             lr
    // 0x1294580: cmp             w7, NULL
    // 0x1294584: b.eq            #0x1294590
    // 0x1294588: tbnz            w7, #4, #0x12945b0
    // 0x129458c: b               #0x12945b8
    // 0x1294590: r8 = Map
    //     0x1294590: add             x8, PP, #0xc, lsl #12  ; [pp+0xcf20] Type: Map
    //     0x1294594: ldr             x8, [x8, #0xf20]
    // 0x1294598: r3 = SubtypeTestCache
    //     0x1294598: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf28] SubtypeTestCache
    //     0x129459c: ldr             x3, [x3, #0xf28]
    // 0x12945a0: r30 = InstanceOfStub
    //     0x12945a0: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x12945a4: LoadField: r30 = r30->field_7
    //     0x12945a4: ldur            lr, [lr, #7]
    // 0x12945a8: blr             lr
    // 0x12945ac: b               #0x12945bc
    // 0x12945b0: r0 = false
    //     0x12945b0: add             x0, NULL, #0x30  ; false
    // 0x12945b4: b               #0x12945bc
    // 0x12945b8: r0 = true
    //     0x12945b8: add             x0, NULL, #0x20  ; true
    // 0x12945bc: tbnz            w0, #4, #0x12948fc
    // 0x12945c0: ldur            x0, [fp, #-0x10]
    // 0x12945c4: r2 = Null
    //     0x12945c4: mov             x2, NULL
    // 0x12945c8: r1 = Null
    //     0x12945c8: mov             x1, NULL
    // 0x12945cc: cmp             w0, NULL
    // 0x12945d0: b.eq            #0x1294668
    // 0x12945d4: branchIfSmi(r0, 0x1294668)
    //     0x12945d4: tbz             w0, #0, #0x1294668
    // 0x12945d8: r3 = LoadClassIdInstr(r0)
    //     0x12945d8: ldur            x3, [x0, #-1]
    //     0x12945dc: ubfx            x3, x3, #0xc, #0x14
    // 0x12945e0: r17 = 7630
    //     0x12945e0: mov             x17, #0x1dce
    // 0x12945e4: cmp             x3, x17
    // 0x12945e8: b.eq            #0x1294670
    // 0x12945ec: r4 = LoadClassIdInstr(r0)
    //     0x12945ec: ldur            x4, [x0, #-1]
    //     0x12945f0: ubfx            x4, x4, #0xc, #0x14
    // 0x12945f4: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x12945f8: ldr             x3, [x3, #0x18]
    // 0x12945fc: ldr             x3, [x3, x4, lsl #3]
    // 0x1294600: LoadField: r3 = r3->field_2b
    //     0x1294600: ldur            w3, [x3, #0x2b]
    // 0x1294604: DecompressPointer r3
    //     0x1294604: add             x3, x3, HEAP, lsl #32
    // 0x1294608: cmp             w3, NULL
    // 0x129460c: b.eq            #0x1294668
    // 0x1294610: LoadField: r3 = r3->field_f
    //     0x1294610: ldur            w3, [x3, #0xf]
    // 0x1294614: lsr             x3, x3, #3
    // 0x1294618: r17 = 7630
    //     0x1294618: mov             x17, #0x1dce
    // 0x129461c: cmp             x3, x17
    // 0x1294620: b.eq            #0x1294670
    // 0x1294624: r3 = SubtypeTestCache
    //     0x1294624: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf30] SubtypeTestCache
    //     0x1294628: ldr             x3, [x3, #0xf30]
    // 0x129462c: r30 = Subtype1TestCacheStub
    //     0x129462c: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x1294630: LoadField: r30 = r30->field_7
    //     0x1294630: ldur            lr, [lr, #7]
    // 0x1294634: blr             lr
    // 0x1294638: cmp             w7, NULL
    // 0x129463c: b.eq            #0x1294648
    // 0x1294640: tbnz            w7, #4, #0x1294668
    // 0x1294644: b               #0x1294670
    // 0x1294648: r8 = Map
    //     0x1294648: add             x8, PP, #0xc, lsl #12  ; [pp+0xcf38] Type: Map
    //     0x129464c: ldr             x8, [x8, #0xf38]
    // 0x1294650: r3 = SubtypeTestCache
    //     0x1294650: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf40] SubtypeTestCache
    //     0x1294654: ldr             x3, [x3, #0xf40]
    // 0x1294658: r30 = InstanceOfStub
    //     0x1294658: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x129465c: LoadField: r30 = r30->field_7
    //     0x129465c: ldur            lr, [lr, #7]
    // 0x1294660: blr             lr
    // 0x1294664: b               #0x1294674
    // 0x1294668: r0 = false
    //     0x1294668: add             x0, NULL, #0x30  ; false
    // 0x129466c: b               #0x1294674
    // 0x1294670: r0 = true
    //     0x1294670: add             x0, NULL, #0x20  ; true
    // 0x1294674: tbnz            w0, #4, #0x12948f4
    // 0x1294678: ldur            x1, [fp, #-8]
    // 0x129467c: ldur            x2, [fp, #-0x18]
    // 0x1294680: r0 = LoadClassIdInstr(r1)
    //     0x1294680: ldur            x0, [x1, #-1]
    //     0x1294684: ubfx            x0, x0, #0xc, #0x14
    // 0x1294688: str             x1, [SP]
    // 0x129468c: r0 = GDT[cid_x0 + 0xf078]()
    //     0x129468c: mov             x17, #0xf078
    //     0x1294690: add             lr, x0, x17
    //     0x1294694: ldr             lr, [x21, lr, lsl #3]
    //     0x1294698: blr             lr
    // 0x129469c: mov             x2, x0
    // 0x12946a0: ldur            x1, [fp, #-0x18]
    // 0x12946a4: stur            x2, [fp, #-0x20]
    // 0x12946a8: LoadField: r0 = r1->field_f
    //     0x12946a8: ldur            w0, [x1, #0xf]
    // 0x12946ac: DecompressPointer r0
    //     0x12946ac: add             x0, x0, HEAP, lsl #32
    // 0x12946b0: r3 = LoadClassIdInstr(r0)
    //     0x12946b0: ldur            x3, [x0, #-1]
    //     0x12946b4: ubfx            x3, x3, #0xc, #0x14
    // 0x12946b8: str             x0, [SP]
    // 0x12946bc: mov             x0, x3
    // 0x12946c0: r0 = GDT[cid_x0 + 0xf078]()
    //     0x12946c0: mov             x17, #0xf078
    //     0x12946c4: add             lr, x0, x17
    //     0x12946c8: ldr             lr, [x21, lr, lsl #3]
    //     0x12946cc: blr             lr
    // 0x12946d0: mov             x1, x0
    // 0x12946d4: ldur            x0, [fp, #-0x20]
    // 0x12946d8: r2 = LoadInt32Instr(r0)
    //     0x12946d8: sbfx            x2, x0, #1, #0x1f
    //     0x12946dc: tbz             w0, #0, #0x12946e4
    //     0x12946e0: ldur            x2, [x0, #7]
    // 0x12946e4: r0 = LoadInt32Instr(r1)
    //     0x12946e4: sbfx            x0, x1, #1, #0x1f
    //     0x12946e8: tbz             w1, #0, #0x12946f0
    //     0x12946ec: ldur            x0, [x1, #7]
    // 0x12946f0: cmp             x2, x0
    // 0x12946f4: b.eq            #0x1294708
    // 0x12946f8: r0 = false
    //     0x12946f8: add             x0, NULL, #0x30  ; false
    // 0x12946fc: LeaveFrame
    //     0x12946fc: mov             SP, fp
    //     0x1294700: ldp             fp, lr, [SP], #0x10
    // 0x1294704: ret
    //     0x1294704: ret             
    // 0x1294708: ldur            x1, [fp, #-8]
    // 0x129470c: r0 = LoadClassIdInstr(r1)
    //     0x129470c: ldur            x0, [x1, #-1]
    //     0x1294710: ubfx            x0, x0, #0xc, #0x14
    // 0x1294714: r0 = GDT[cid_x0 + 0xfc4]()
    //     0x1294714: add             lr, x0, #0xfc4
    //     0x1294718: ldr             lr, [x21, lr, lsl #3]
    //     0x129471c: blr             lr
    // 0x1294720: r1 = LoadClassIdInstr(r0)
    //     0x1294720: ldur            x1, [x0, #-1]
    //     0x1294724: ubfx            x1, x1, #0xc, #0x14
    // 0x1294728: mov             x16, x0
    // 0x129472c: mov             x0, x1
    // 0x1294730: mov             x1, x16
    // 0x1294734: r0 = GDT[cid_x0 + 0x12641]()
    //     0x1294734: mov             x17, #0x2641
    //     0x1294738: movk            x17, #1, lsl #16
    //     0x129473c: add             lr, x0, x17
    //     0x1294740: ldr             lr, [x21, lr, lsl #3]
    //     0x1294744: blr             lr
    // 0x1294748: mov             x2, x0
    // 0x129474c: stur            x2, [fp, #-0x20]
    // 0x1294750: ldur            x3, [fp, #-0x18]
    // 0x1294754: CheckStackOverflow
    //     0x1294754: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1294758: cmp             SP, x16
    //     0x129475c: b.ls            #0x1294938
    // 0x1294760: r0 = LoadClassIdInstr(r2)
    //     0x1294760: ldur            x0, [x2, #-1]
    //     0x1294764: ubfx            x0, x0, #0xc, #0x14
    // 0x1294768: mov             x1, x2
    // 0x129476c: r0 = GDT[cid_x0 + 0x1845b]()
    //     0x129476c: mov             x17, #0x845b
    //     0x1294770: movk            x17, #1, lsl #16
    //     0x1294774: add             lr, x0, x17
    //     0x1294778: ldr             lr, [x21, lr, lsl #3]
    //     0x129477c: blr             lr
    // 0x1294780: tbnz            w0, #4, #0x12948e4
    // 0x1294784: ldur            x3, [fp, #-0x18]
    // 0x1294788: ldur            x2, [fp, #-0x20]
    // 0x129478c: r0 = LoadClassIdInstr(r2)
    //     0x129478c: ldur            x0, [x2, #-1]
    //     0x1294790: ubfx            x0, x0, #0xc, #0x14
    // 0x1294794: mov             x1, x2
    // 0x1294798: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0x1294798: mov             x17, #0x7d4c
    //     0x129479c: movk            x17, #1, lsl #16
    //     0x12947a0: add             lr, x0, x17
    //     0x12947a4: ldr             lr, [x21, lr, lsl #3]
    //     0x12947a8: blr             lr
    // 0x12947ac: mov             x3, x0
    // 0x12947b0: ldur            x2, [fp, #-0x18]
    // 0x12947b4: stur            x3, [fp, #-0x28]
    // 0x12947b8: LoadField: r1 = r2->field_f
    //     0x12947b8: ldur            w1, [x2, #0xf]
    // 0x12947bc: DecompressPointer r1
    //     0x12947bc: add             x1, x1, HEAP, lsl #32
    // 0x12947c0: r0 = LoadClassIdInstr(r1)
    //     0x12947c0: ldur            x0, [x1, #-1]
    //     0x12947c4: ubfx            x0, x0, #0xc, #0x14
    // 0x12947c8: r0 = GDT[cid_x0 + 0xfc4]()
    //     0x12947c8: add             lr, x0, #0xfc4
    //     0x12947cc: ldr             lr, [x21, lr, lsl #3]
    //     0x12947d0: blr             lr
    // 0x12947d4: r1 = LoadClassIdInstr(r0)
    //     0x12947d4: ldur            x1, [x0, #-1]
    //     0x12947d8: ubfx            x1, x1, #0xc, #0x14
    // 0x12947dc: mov             x16, x0
    // 0x12947e0: mov             x0, x1
    // 0x12947e4: mov             x1, x16
    // 0x12947e8: r0 = GDT[cid_x0 + 0x12641]()
    //     0x12947e8: mov             x17, #0x2641
    //     0x12947ec: movk            x17, #1, lsl #16
    //     0x12947f0: add             lr, x0, x17
    //     0x12947f4: ldr             lr, [x21, lr, lsl #3]
    //     0x12947f8: blr             lr
    // 0x12947fc: mov             x3, x0
    // 0x1294800: ldur            x2, [fp, #-0x28]
    // 0x1294804: stur            x3, [fp, #-0x38]
    // 0x1294808: LoadField: r4 = r2->field_b
    //     0x1294808: ldur            w4, [x2, #0xb]
    // 0x129480c: DecompressPointer r4
    //     0x129480c: add             x4, x4, HEAP, lsl #32
    // 0x1294810: stur            x4, [fp, #-0x30]
    // 0x1294814: CheckStackOverflow
    //     0x1294814: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1294818: cmp             SP, x16
    //     0x129481c: b.ls            #0x1294940
    // 0x1294820: r0 = LoadClassIdInstr(r3)
    //     0x1294820: ldur            x0, [x3, #-1]
    //     0x1294824: ubfx            x0, x0, #0xc, #0x14
    // 0x1294828: mov             x1, x3
    // 0x129482c: r0 = GDT[cid_x0 + 0x1845b]()
    //     0x129482c: mov             x17, #0x845b
    //     0x1294830: movk            x17, #1, lsl #16
    //     0x1294834: add             lr, x0, x17
    //     0x1294838: ldr             lr, [x21, lr, lsl #3]
    //     0x129483c: blr             lr
    // 0x1294840: tbnz            w0, #4, #0x12948d4
    // 0x1294844: ldur            x2, [fp, #-0x38]
    // 0x1294848: r0 = LoadClassIdInstr(r2)
    //     0x1294848: ldur            x0, [x2, #-1]
    //     0x129484c: ubfx            x0, x0, #0xc, #0x14
    // 0x1294850: mov             x1, x2
    // 0x1294854: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0x1294854: mov             x17, #0x7d4c
    //     0x1294858: movk            x17, #1, lsl #16
    //     0x129485c: add             lr, x0, x17
    //     0x1294860: ldr             lr, [x21, lr, lsl #3]
    //     0x1294864: blr             lr
    // 0x1294868: stur            x0, [fp, #-0x40]
    // 0x129486c: LoadField: r2 = r0->field_b
    //     0x129486c: ldur            w2, [x0, #0xb]
    // 0x1294870: DecompressPointer r2
    //     0x1294870: add             x2, x2, HEAP, lsl #32
    // 0x1294874: ldur            x1, [fp, #-0x30]
    // 0x1294878: r0 = _deepEquals()
    //     0x1294878: bl              #0x12941bc  ; [package:firebase_core_platform_interface/src/pigeon/messages.pigeon.dart] ::_deepEquals
    // 0x129487c: tbz             w0, #4, #0x1294890
    // 0x1294880: ldur            x2, [fp, #-0x28]
    // 0x1294884: ldur            x3, [fp, #-0x38]
    // 0x1294888: ldur            x4, [fp, #-0x30]
    // 0x129488c: b               #0x1294814
    // 0x1294890: ldur            x1, [fp, #-0x28]
    // 0x1294894: ldur            x0, [fp, #-0x40]
    // 0x1294898: LoadField: r2 = r1->field_f
    //     0x1294898: ldur            w2, [x1, #0xf]
    // 0x129489c: DecompressPointer r2
    //     0x129489c: add             x2, x2, HEAP, lsl #32
    // 0x12948a0: LoadField: r1 = r0->field_f
    //     0x12948a0: ldur            w1, [x0, #0xf]
    // 0x12948a4: DecompressPointer r1
    //     0x12948a4: add             x1, x1, HEAP, lsl #32
    // 0x12948a8: mov             x16, x1
    // 0x12948ac: mov             x1, x2
    // 0x12948b0: mov             x2, x16
    // 0x12948b4: r0 = _deepEquals()
    //     0x12948b4: bl              #0x12941bc  ; [package:firebase_core_platform_interface/src/pigeon/messages.pigeon.dart] ::_deepEquals
    // 0x12948b8: tbnz            w0, #4, #0x12948c4
    // 0x12948bc: ldur            x2, [fp, #-0x20]
    // 0x12948c0: b               #0x1294750
    // 0x12948c4: r0 = false
    //     0x12948c4: add             x0, NULL, #0x30  ; false
    // 0x12948c8: LeaveFrame
    //     0x12948c8: mov             SP, fp
    //     0x12948cc: ldp             fp, lr, [SP], #0x10
    // 0x12948d0: ret
    //     0x12948d0: ret             
    // 0x12948d4: r0 = false
    //     0x12948d4: add             x0, NULL, #0x30  ; false
    // 0x12948d8: LeaveFrame
    //     0x12948d8: mov             SP, fp
    //     0x12948dc: ldp             fp, lr, [SP], #0x10
    // 0x12948e0: ret
    //     0x12948e0: ret             
    // 0x12948e4: r0 = true
    //     0x12948e4: add             x0, NULL, #0x20  ; true
    // 0x12948e8: LeaveFrame
    //     0x12948e8: mov             SP, fp
    //     0x12948ec: ldp             fp, lr, [SP], #0x10
    // 0x12948f0: ret
    //     0x12948f0: ret             
    // 0x12948f4: ldur            x1, [fp, #-8]
    // 0x12948f8: b               #0x1294900
    // 0x12948fc: ldur            x1, [fp, #-8]
    // 0x1294900: r0 = 60
    //     0x1294900: mov             x0, #0x3c
    // 0x1294904: branchIfSmi(r1, 0x1294910)
    //     0x1294904: tbz             w1, #0, #0x1294910
    // 0x1294908: r0 = LoadClassIdInstr(r1)
    //     0x1294908: ldur            x0, [x1, #-1]
    //     0x129490c: ubfx            x0, x0, #0xc, #0x14
    // 0x1294910: ldur            x16, [fp, #-0x10]
    // 0x1294914: stp             x16, x1, [SP]
    // 0x1294918: mov             lr, x0
    // 0x129491c: ldr             lr, [x21, lr, lsl #3]
    // 0x1294920: blr             lr
    // 0x1294924: LeaveFrame
    //     0x1294924: mov             SP, fp
    //     0x1294928: ldp             fp, lr, [SP], #0x10
    // 0x129492c: ret
    //     0x129492c: ret             
    // 0x1294930: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1294930: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1294934: b               #0x12941e4
    // 0x1294938: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1294938: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x129493c: b               #0x1294760
    // 0x1294940: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1294940: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1294944: b               #0x1294820
  }
  [closure] static bool <anonymous closure>(dynamic, (int, dynamic)) {
    // ** addr: 0x1294ab0, size: 0x7c
    // 0x1294ab0: EnterFrame
    //     0x1294ab0: stp             fp, lr, [SP, #-0x10]!
    //     0x1294ab4: mov             fp, SP
    // 0x1294ab8: AllocStack(0x18)
    //     0x1294ab8: sub             SP, SP, #0x18
    // 0x1294abc: SetupParameters([dynamic _ /* r0 */])
    //     0x1294abc: ldr             x0, [fp, #0x18]
    //     0x1294ac0: ldur            w1, [x0, #0x17]
    //     0x1294ac4: add             x1, x1, HEAP, lsl #32
    // 0x1294ac8: CheckStackOverflow
    //     0x1294ac8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1294acc: cmp             SP, x16
    //     0x1294ad0: b.ls            #0x1294b24
    // 0x1294ad4: ldr             x0, [fp, #0x10]
    // 0x1294ad8: LoadField: r2 = r0->field_13
    //     0x1294ad8: ldur            w2, [x0, #0x13]
    // 0x1294adc: DecompressPointer r2
    //     0x1294adc: add             x2, x2, HEAP, lsl #32
    // 0x1294ae0: stur            x2, [fp, #-8]
    // 0x1294ae4: LoadField: r3 = r1->field_f
    //     0x1294ae4: ldur            w3, [x1, #0xf]
    // 0x1294ae8: DecompressPointer r3
    //     0x1294ae8: add             x3, x3, HEAP, lsl #32
    // 0x1294aec: LoadField: r1 = r0->field_f
    //     0x1294aec: ldur            w1, [x0, #0xf]
    // 0x1294af0: DecompressPointer r1
    //     0x1294af0: add             x1, x1, HEAP, lsl #32
    // 0x1294af4: r0 = LoadClassIdInstr(r3)
    //     0x1294af4: ldur            x0, [x3, #-1]
    //     0x1294af8: ubfx            x0, x0, #0xc, #0x14
    // 0x1294afc: stp             x1, x3, [SP]
    // 0x1294b00: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x1294b00: sub             lr, x0, #0xdfd
    //     0x1294b04: ldr             lr, [x21, lr, lsl #3]
    //     0x1294b08: blr             lr
    // 0x1294b0c: ldur            x1, [fp, #-8]
    // 0x1294b10: mov             x2, x0
    // 0x1294b14: r0 = _deepEquals()
    //     0x1294b14: bl              #0x12941bc  ; [package:firebase_core_platform_interface/src/pigeon/messages.pigeon.dart] ::_deepEquals
    // 0x1294b18: LeaveFrame
    //     0x1294b18: mov             SP, fp
    //     0x1294b1c: ldp             fp, lr, [SP], #0x10
    // 0x1294b20: ret
    //     0x1294b20: ret             
    // 0x1294b24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1294b24: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1294b28: b               #0x1294ad4
  }
  static _ _extractReplyValueOrThrow(/* No info */) {
    // ** addr: 0x13ea66c, size: 0x270
    // 0x13ea66c: EnterFrame
    //     0x13ea66c: stp             fp, lr, [SP, #-0x10]!
    //     0x13ea670: mov             fp, SP
    // 0x13ea674: AllocStack(0x28)
    //     0x13ea674: sub             SP, SP, #0x28
    // 0x13ea678: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x13ea678: mov             x0, x2
    //     0x13ea67c: stur            x1, [fp, #-8]
    //     0x13ea680: stur            x2, [fp, #-0x10]
    // 0x13ea684: CheckStackOverflow
    //     0x13ea684: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13ea688: cmp             SP, x16
    //     0x13ea68c: b.ls            #0x13ea8d0
    // 0x13ea690: cmp             w1, NULL
    // 0x13ea694: b.eq            #0x13ea734
    // 0x13ea698: r0 = LoadClassIdInstr(r1)
    //     0x13ea698: ldur            x0, [x1, #-1]
    //     0x13ea69c: ubfx            x0, x0, #0xc, #0x14
    // 0x13ea6a0: str             x1, [SP]
    // 0x13ea6a4: r0 = GDT[cid_x0 + 0xf078]()
    //     0x13ea6a4: mov             x17, #0xf078
    //     0x13ea6a8: add             lr, x0, x17
    //     0x13ea6ac: ldr             lr, [x21, lr, lsl #3]
    //     0x13ea6b0: blr             lr
    // 0x13ea6b4: r1 = LoadInt32Instr(r0)
    //     0x13ea6b4: sbfx            x1, x0, #1, #0x1f
    //     0x13ea6b8: tbz             w0, #0, #0x13ea6c0
    //     0x13ea6bc: ldur            x1, [x0, #7]
    // 0x13ea6c0: cmp             x1, #1
    // 0x13ea6c4: b.gt            #0x13ea790
    // 0x13ea6c8: ldur            x2, [fp, #-8]
    // 0x13ea6cc: r0 = LoadClassIdInstr(r2)
    //     0x13ea6cc: ldur            x0, [x2, #-1]
    //     0x13ea6d0: ubfx            x0, x0, #0xc, #0x14
    // 0x13ea6d4: mov             x1, x2
    // 0x13ea6d8: r0 = GDT[cid_x0 + 0x131a1]()
    //     0x13ea6d8: mov             x17, #0x31a1
    //     0x13ea6dc: movk            x17, #1, lsl #16
    //     0x13ea6e0: add             lr, x0, x17
    //     0x13ea6e4: ldr             lr, [x21, lr, lsl #3]
    //     0x13ea6e8: blr             lr
    // 0x13ea6ec: tbnz            w0, #4, #0x13ea714
    // 0x13ea6f0: ldur            x1, [fp, #-8]
    // 0x13ea6f4: r0 = LoadClassIdInstr(r1)
    //     0x13ea6f4: ldur            x0, [x1, #-1]
    //     0x13ea6f8: ubfx            x0, x0, #0xc, #0x14
    // 0x13ea6fc: stp             xzr, x1, [SP]
    // 0x13ea700: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x13ea700: sub             lr, x0, #0xdfd
    //     0x13ea704: ldr             lr, [x21, lr, lsl #3]
    //     0x13ea708: blr             lr
    // 0x13ea70c: cmp             w0, NULL
    // 0x13ea710: b.eq            #0x13ea8a4
    // 0x13ea714: r16 = <Object?>
    //     0x13ea714: ldr             x16, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0x13ea718: ldur            lr, [fp, #-8]
    // 0x13ea71c: stp             lr, x16, [SP]
    // 0x13ea720: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x13ea720: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x13ea724: r0 = IterableExtensions.firstOrNull()
    //     0x13ea724: bl              #0x8bf918  ; [dart:collection] ::IterableExtensions.firstOrNull
    // 0x13ea728: LeaveFrame
    //     0x13ea728: mov             SP, fp
    //     0x13ea72c: ldp             fp, lr, [SP], #0x10
    // 0x13ea730: ret
    //     0x13ea730: ret             
    // 0x13ea734: r1 = Null
    //     0x13ea734: mov             x1, NULL
    // 0x13ea738: r2 = 6
    //     0x13ea738: mov             x2, #6
    // 0x13ea73c: r0 = AllocateArray()
    //     0x13ea73c: bl              #0x13df928  ; AllocateArrayStub
    // 0x13ea740: r16 = "Unable to establish connection on channel: \""
    //     0x13ea740: add             x16, PP, #8, lsl #12  ; [pp+0x8d48] "Unable to establish connection on channel: \""
    //     0x13ea744: ldr             x16, [x16, #0xd48]
    // 0x13ea748: StoreField: r0->field_f = r16
    //     0x13ea748: stur            w16, [x0, #0xf]
    // 0x13ea74c: ldur            x1, [fp, #-0x10]
    // 0x13ea750: StoreField: r0->field_13 = r1
    //     0x13ea750: stur            w1, [x0, #0x13]
    // 0x13ea754: r16 = "\"."
    //     0x13ea754: ldr             x16, [PP, #0x39a8]  ; [pp+0x39a8] "\"."
    // 0x13ea758: ArrayStore: r0[0] = r16  ; List_4
    //     0x13ea758: stur            w16, [x0, #0x17]
    // 0x13ea75c: str             x0, [SP]
    // 0x13ea760: r0 = _interpolate()
    //     0x13ea760: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x13ea764: stur            x0, [fp, #-0x10]
    // 0x13ea768: r0 = PlatformException()
    //     0x13ea768: bl              #0x8bf90c  ; AllocatePlatformExceptionStub -> PlatformException (size=0x18)
    // 0x13ea76c: mov             x1, x0
    // 0x13ea770: r0 = "channel-error"
    //     0x13ea770: add             x0, PP, #8, lsl #12  ; [pp+0x8d50] "channel-error"
    //     0x13ea774: ldr             x0, [x0, #0xd50]
    // 0x13ea778: StoreField: r1->field_7 = r0
    //     0x13ea778: stur            w0, [x1, #7]
    // 0x13ea77c: ldur            x0, [fp, #-0x10]
    // 0x13ea780: StoreField: r1->field_b = r0
    //     0x13ea780: stur            w0, [x1, #0xb]
    // 0x13ea784: mov             x0, x1
    // 0x13ea788: r0 = Throw()
    //     0x13ea788: bl              #0x13ddb2c  ; ThrowStub
    // 0x13ea78c: brk             #0
    // 0x13ea790: ldur            x1, [fp, #-8]
    // 0x13ea794: r0 = LoadClassIdInstr(r1)
    //     0x13ea794: ldur            x0, [x1, #-1]
    //     0x13ea798: ubfx            x0, x0, #0xc, #0x14
    // 0x13ea79c: stp             xzr, x1, [SP]
    // 0x13ea7a0: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x13ea7a0: sub             lr, x0, #0xdfd
    //     0x13ea7a4: ldr             lr, [x21, lr, lsl #3]
    //     0x13ea7a8: blr             lr
    // 0x13ea7ac: mov             x3, x0
    // 0x13ea7b0: stur            x3, [fp, #-0x10]
    // 0x13ea7b4: cmp             w3, NULL
    // 0x13ea7b8: b.eq            #0x13ea8d8
    // 0x13ea7bc: mov             x0, x3
    // 0x13ea7c0: r2 = Null
    //     0x13ea7c0: mov             x2, NULL
    // 0x13ea7c4: r1 = Null
    //     0x13ea7c4: mov             x1, NULL
    // 0x13ea7c8: r4 = 60
    //     0x13ea7c8: mov             x4, #0x3c
    // 0x13ea7cc: branchIfSmi(r0, 0x13ea7d8)
    //     0x13ea7cc: tbz             w0, #0, #0x13ea7d8
    // 0x13ea7d0: r4 = LoadClassIdInstr(r0)
    //     0x13ea7d0: ldur            x4, [x0, #-1]
    //     0x13ea7d4: ubfx            x4, x4, #0xc, #0x14
    // 0x13ea7d8: sub             x4, x4, #0x5e
    // 0x13ea7dc: cmp             x4, #1
    // 0x13ea7e0: b.ls            #0x13ea7f4
    // 0x13ea7e4: r8 = String
    //     0x13ea7e4: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x13ea7e8: r3 = Null
    //     0x13ea7e8: add             x3, PP, #8, lsl #12  ; [pp+0x8d58] Null
    //     0x13ea7ec: ldr             x3, [x3, #0xd58]
    // 0x13ea7f0: r0 = String()
    //     0x13ea7f0: bl              #0x13ee320  ; IsType_String_Stub
    // 0x13ea7f4: ldur            x1, [fp, #-8]
    // 0x13ea7f8: r0 = LoadClassIdInstr(r1)
    //     0x13ea7f8: ldur            x0, [x1, #-1]
    //     0x13ea7fc: ubfx            x0, x0, #0xc, #0x14
    // 0x13ea800: r16 = 2
    //     0x13ea800: mov             x16, #2
    // 0x13ea804: stp             x16, x1, [SP]
    // 0x13ea808: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x13ea808: sub             lr, x0, #0xdfd
    //     0x13ea80c: ldr             lr, [x21, lr, lsl #3]
    //     0x13ea810: blr             lr
    // 0x13ea814: mov             x3, x0
    // 0x13ea818: r2 = Null
    //     0x13ea818: mov             x2, NULL
    // 0x13ea81c: r1 = Null
    //     0x13ea81c: mov             x1, NULL
    // 0x13ea820: stur            x3, [fp, #-0x18]
    // 0x13ea824: r4 = 60
    //     0x13ea824: mov             x4, #0x3c
    // 0x13ea828: branchIfSmi(r0, 0x13ea834)
    //     0x13ea828: tbz             w0, #0, #0x13ea834
    // 0x13ea82c: r4 = LoadClassIdInstr(r0)
    //     0x13ea82c: ldur            x4, [x0, #-1]
    //     0x13ea830: ubfx            x4, x4, #0xc, #0x14
    // 0x13ea834: sub             x4, x4, #0x5e
    // 0x13ea838: cmp             x4, #1
    // 0x13ea83c: b.ls            #0x13ea850
    // 0x13ea840: r8 = String?
    //     0x13ea840: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x13ea844: r3 = Null
    //     0x13ea844: add             x3, PP, #8, lsl #12  ; [pp+0x8d68] Null
    //     0x13ea848: ldr             x3, [x3, #0xd68]
    // 0x13ea84c: r0 = String?()
    //     0x13ea84c: bl              #0x7db310  ; IsType_String?_Stub
    // 0x13ea850: ldur            x0, [fp, #-8]
    // 0x13ea854: r1 = LoadClassIdInstr(r0)
    //     0x13ea854: ldur            x1, [x0, #-1]
    //     0x13ea858: ubfx            x1, x1, #0xc, #0x14
    // 0x13ea85c: r16 = 4
    //     0x13ea85c: mov             x16, #4
    // 0x13ea860: stp             x16, x0, [SP]
    // 0x13ea864: mov             x0, x1
    // 0x13ea868: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x13ea868: sub             lr, x0, #0xdfd
    //     0x13ea86c: ldr             lr, [x21, lr, lsl #3]
    //     0x13ea870: blr             lr
    // 0x13ea874: stur            x0, [fp, #-8]
    // 0x13ea878: r0 = PlatformException()
    //     0x13ea878: bl              #0x8bf90c  ; AllocatePlatformExceptionStub -> PlatformException (size=0x18)
    // 0x13ea87c: mov             x1, x0
    // 0x13ea880: ldur            x0, [fp, #-0x10]
    // 0x13ea884: StoreField: r1->field_7 = r0
    //     0x13ea884: stur            w0, [x1, #7]
    // 0x13ea888: ldur            x0, [fp, #-0x18]
    // 0x13ea88c: StoreField: r1->field_b = r0
    //     0x13ea88c: stur            w0, [x1, #0xb]
    // 0x13ea890: ldur            x0, [fp, #-8]
    // 0x13ea894: StoreField: r1->field_f = r0
    //     0x13ea894: stur            w0, [x1, #0xf]
    // 0x13ea898: mov             x0, x1
    // 0x13ea89c: r0 = Throw()
    //     0x13ea89c: bl              #0x13ddb2c  ; ThrowStub
    // 0x13ea8a0: brk             #0
    // 0x13ea8a4: r0 = PlatformException()
    //     0x13ea8a4: bl              #0x8bf90c  ; AllocatePlatformExceptionStub -> PlatformException (size=0x18)
    // 0x13ea8a8: mov             x1, x0
    // 0x13ea8ac: r0 = "null-error"
    //     0x13ea8ac: add             x0, PP, #8, lsl #12  ; [pp+0x8d78] "null-error"
    //     0x13ea8b0: ldr             x0, [x0, #0xd78]
    // 0x13ea8b4: StoreField: r1->field_7 = r0
    //     0x13ea8b4: stur            w0, [x1, #7]
    // 0x13ea8b8: r0 = "Host platform returned null value for non-null return value."
    //     0x13ea8b8: add             x0, PP, #8, lsl #12  ; [pp+0x8d80] "Host platform returned null value for non-null return value."
    //     0x13ea8bc: ldr             x0, [x0, #0xd80]
    // 0x13ea8c0: StoreField: r1->field_b = r0
    //     0x13ea8c0: stur            w0, [x1, #0xb]
    // 0x13ea8c4: mov             x0, x1
    // 0x13ea8c8: r0 = Throw()
    //     0x13ea8c8: bl              #0x13ddb2c  ; ThrowStub
    // 0x13ea8cc: brk             #0
    // 0x13ea8d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13ea8d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13ea8d4: b               #0x13ea690
    // 0x13ea8d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x13ea8d8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 3353, size: 0x10, field offset: 0x8
class FirebaseCoreHostApi extends Object {

  _ initializeApp(/* No info */) async {
    // ** addr: 0x13ea4e4, size: 0x188
    // 0x13ea4e4: EnterFrame
    //     0x13ea4e4: stp             fp, lr, [SP, #-0x10]!
    //     0x13ea4e8: mov             fp, SP
    // 0x13ea4ec: AllocStack(0x38)
    //     0x13ea4ec: sub             SP, SP, #0x38
    // 0x13ea4f0: SetupParameters(FirebaseCoreHostApi this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */)
    //     0x13ea4f0: stur            NULL, [fp, #-8]
    //     0x13ea4f4: stur            x1, [fp, #-0x10]
    //     0x13ea4f8: stur            x2, [fp, #-0x18]
    //     0x13ea4fc: stur            x3, [fp, #-0x20]
    // 0x13ea500: CheckStackOverflow
    //     0x13ea500: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13ea504: cmp             SP, x16
    //     0x13ea508: b.ls            #0x13ea660
    // 0x13ea50c: InitAsync() -> Future<CoreInitializeResponse>
    //     0x13ea50c: add             x0, PP, #8, lsl #12  ; [pp+0x8d08] TypeArguments: <CoreInitializeResponse>
    //     0x13ea510: ldr             x0, [x0, #0xd08]
    //     0x13ea514: bl              #0x7f5e44  ; InitAsyncStub
    // 0x13ea518: r1 = Null
    //     0x13ea518: mov             x1, NULL
    // 0x13ea51c: r2 = 4
    //     0x13ea51c: mov             x2, #4
    // 0x13ea520: r0 = AllocateArray()
    //     0x13ea520: bl              #0x13df928  ; AllocateArrayStub
    // 0x13ea524: r16 = "dev.flutter.pigeon.firebase_core_platform_interface.FirebaseCoreHostApi.initializeApp"
    //     0x13ea524: add             x16, PP, #8, lsl #12  ; [pp+0x8d10] "dev.flutter.pigeon.firebase_core_platform_interface.FirebaseCoreHostApi.initializeApp"
    //     0x13ea528: ldr             x16, [x16, #0xd10]
    // 0x13ea52c: StoreField: r0->field_f = r16
    //     0x13ea52c: stur            w16, [x0, #0xf]
    // 0x13ea530: ldur            x1, [fp, #-0x10]
    // 0x13ea534: LoadField: r2 = r1->field_b
    //     0x13ea534: ldur            w2, [x1, #0xb]
    // 0x13ea538: DecompressPointer r2
    //     0x13ea538: add             x2, x2, HEAP, lsl #32
    // 0x13ea53c: StoreField: r0->field_13 = r2
    //     0x13ea53c: stur            w2, [x0, #0x13]
    // 0x13ea540: str             x0, [SP]
    // 0x13ea544: r0 = _interpolate()
    //     0x13ea544: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x13ea548: r1 = <Object?>
    //     0x13ea548: ldr             x1, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0x13ea54c: stur            x0, [fp, #-0x10]
    // 0x13ea550: r0 = BasicMessageChannel()
    //     0x13ea550: bl              #0x8bfb04  ; AllocateBasicMessageChannelStub -> BasicMessageChannel<X0> (size=0x18)
    // 0x13ea554: mov             x3, x0
    // 0x13ea558: ldur            x0, [fp, #-0x10]
    // 0x13ea55c: stur            x3, [fp, #-0x28]
    // 0x13ea560: StoreField: r3->field_b = r0
    //     0x13ea560: stur            w0, [x3, #0xb]
    // 0x13ea564: r1 = Instance__PigeonCodec
    //     0x13ea564: add             x1, PP, #8, lsl #12  ; [pp+0x8d18] Obj!_PigeonCodec@129ff71
    //     0x13ea568: ldr             x1, [x1, #0xd18]
    // 0x13ea56c: StoreField: r3->field_f = r1
    //     0x13ea56c: stur            w1, [x3, #0xf]
    // 0x13ea570: r1 = Null
    //     0x13ea570: mov             x1, NULL
    // 0x13ea574: r2 = 4
    //     0x13ea574: mov             x2, #4
    // 0x13ea578: r0 = AllocateArray()
    //     0x13ea578: bl              #0x13df928  ; AllocateArrayStub
    // 0x13ea57c: mov             x2, x0
    // 0x13ea580: ldur            x0, [fp, #-0x18]
    // 0x13ea584: stur            x2, [fp, #-0x30]
    // 0x13ea588: StoreField: r2->field_f = r0
    //     0x13ea588: stur            w0, [x2, #0xf]
    // 0x13ea58c: ldur            x0, [fp, #-0x20]
    // 0x13ea590: StoreField: r2->field_13 = r0
    //     0x13ea590: stur            w0, [x2, #0x13]
    // 0x13ea594: r1 = <Object?>
    //     0x13ea594: ldr             x1, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0x13ea598: r0 = AllocateGrowableArray()
    //     0x13ea598: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x13ea59c: mov             x1, x0
    // 0x13ea5a0: ldur            x0, [fp, #-0x30]
    // 0x13ea5a4: StoreField: r1->field_f = r0
    //     0x13ea5a4: stur            w0, [x1, #0xf]
    // 0x13ea5a8: r0 = 4
    //     0x13ea5a8: mov             x0, #4
    // 0x13ea5ac: StoreField: r1->field_b = r0
    //     0x13ea5ac: stur            w0, [x1, #0xb]
    // 0x13ea5b0: mov             x2, x1
    // 0x13ea5b4: ldur            x1, [fp, #-0x28]
    // 0x13ea5b8: r0 = send()
    //     0x13ea5b8: bl              #0x8bf9c0  ; [package:flutter/src/services/platform_channel.dart] BasicMessageChannel::send
    // 0x13ea5bc: mov             x1, x0
    // 0x13ea5c0: stur            x1, [fp, #-0x18]
    // 0x13ea5c4: r0 = Await()
    //     0x13ea5c4: bl              #0x7f5c00  ; AwaitStub
    // 0x13ea5c8: mov             x3, x0
    // 0x13ea5cc: r2 = Null
    //     0x13ea5cc: mov             x2, NULL
    // 0x13ea5d0: r1 = Null
    //     0x13ea5d0: mov             x1, NULL
    // 0x13ea5d4: stur            x3, [fp, #-0x18]
    // 0x13ea5d8: r4 = 60
    //     0x13ea5d8: mov             x4, #0x3c
    // 0x13ea5dc: branchIfSmi(r0, 0x13ea5e8)
    //     0x13ea5dc: tbz             w0, #0, #0x13ea5e8
    // 0x13ea5e0: r4 = LoadClassIdInstr(r0)
    //     0x13ea5e0: ldur            x4, [x0, #-1]
    //     0x13ea5e4: ubfx            x4, x4, #0xc, #0x14
    // 0x13ea5e8: sub             x4, x4, #0x5a
    // 0x13ea5ec: cmp             x4, #2
    // 0x13ea5f0: b.ls            #0x13ea604
    // 0x13ea5f4: r8 = List<Object?>?
    //     0x13ea5f4: ldr             x8, [PP, #0x1988]  ; [pp+0x1988] Type: List<Object?>?
    // 0x13ea5f8: r3 = Null
    //     0x13ea5f8: add             x3, PP, #8, lsl #12  ; [pp+0x8d20] Null
    //     0x13ea5fc: ldr             x3, [x3, #0xd20]
    // 0x13ea600: r0 = List<Object?>?()
    //     0x13ea600: bl              #0x823c84  ; IsType_List<Object?>?_Stub
    // 0x13ea604: ldur            x1, [fp, #-0x18]
    // 0x13ea608: ldur            x2, [fp, #-0x10]
    // 0x13ea60c: r0 = _extractReplyValueOrThrow()
    //     0x13ea60c: bl              #0x13ea66c  ; [package:firebase_core_platform_interface/src/pigeon/messages.pigeon.dart] ::_extractReplyValueOrThrow
    // 0x13ea610: mov             x3, x0
    // 0x13ea614: stur            x3, [fp, #-0x10]
    // 0x13ea618: cmp             w3, NULL
    // 0x13ea61c: b.eq            #0x13ea668
    // 0x13ea620: mov             x0, x3
    // 0x13ea624: r2 = Null
    //     0x13ea624: mov             x2, NULL
    // 0x13ea628: r1 = Null
    //     0x13ea628: mov             x1, NULL
    // 0x13ea62c: r4 = 60
    //     0x13ea62c: mov             x4, #0x3c
    // 0x13ea630: branchIfSmi(r0, 0x13ea63c)
    //     0x13ea630: tbz             w0, #0, #0x13ea63c
    // 0x13ea634: r4 = LoadClassIdInstr(r0)
    //     0x13ea634: ldur            x4, [x0, #-1]
    //     0x13ea638: ubfx            x4, x4, #0xc, #0x14
    // 0x13ea63c: cmp             x4, #0xd26
    // 0x13ea640: b.eq            #0x13ea658
    // 0x13ea644: r8 = CoreInitializeResponse
    //     0x13ea644: add             x8, PP, #8, lsl #12  ; [pp+0x8d30] Type: CoreInitializeResponse
    //     0x13ea648: ldr             x8, [x8, #0xd30]
    // 0x13ea64c: r3 = Null
    //     0x13ea64c: add             x3, PP, #8, lsl #12  ; [pp+0x8d38] Null
    //     0x13ea650: ldr             x3, [x3, #0xd38]
    // 0x13ea654: r0 = DefaultTypeTest()
    //     0x13ea654: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x13ea658: ldur            x0, [fp, #-0x10]
    // 0x13ea65c: r0 = ReturnAsyncNotFuture()
    //     0x13ea65c: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x13ea660: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13ea660: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13ea664: b               #0x13ea50c
    // 0x13ea668: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x13ea668: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initializeCore(/* No info */) async {
    // ** addr: 0x13ea9c8, size: 0x168
    // 0x13ea9c8: EnterFrame
    //     0x13ea9c8: stp             fp, lr, [SP, #-0x10]!
    //     0x13ea9cc: mov             fp, SP
    // 0x13ea9d0: AllocStack(0x28)
    //     0x13ea9d0: sub             SP, SP, #0x28
    // 0x13ea9d4: SetupParameters(FirebaseCoreHostApi this /* r1 => r1, fp-0x10 */)
    //     0x13ea9d4: stur            NULL, [fp, #-8]
    //     0x13ea9d8: stur            x1, [fp, #-0x10]
    // 0x13ea9dc: CheckStackOverflow
    //     0x13ea9dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13ea9e0: cmp             SP, x16
    //     0x13ea9e4: b.ls            #0x13eab24
    // 0x13ea9e8: InitAsync() -> Future<List<CoreInitializeResponse>>
    //     0x13ea9e8: add             x0, PP, #8, lsl #12  ; [pp+0x8da0] TypeArguments: <List<CoreInitializeResponse>>
    //     0x13ea9ec: ldr             x0, [x0, #0xda0]
    //     0x13ea9f0: bl              #0x7f5e44  ; InitAsyncStub
    // 0x13ea9f4: r1 = Null
    //     0x13ea9f4: mov             x1, NULL
    // 0x13ea9f8: r2 = 4
    //     0x13ea9f8: mov             x2, #4
    // 0x13ea9fc: r0 = AllocateArray()
    //     0x13ea9fc: bl              #0x13df928  ; AllocateArrayStub
    // 0x13eaa00: r16 = "dev.flutter.pigeon.firebase_core_platform_interface.FirebaseCoreHostApi.initializeCore"
    //     0x13eaa00: add             x16, PP, #8, lsl #12  ; [pp+0x8da8] "dev.flutter.pigeon.firebase_core_platform_interface.FirebaseCoreHostApi.initializeCore"
    //     0x13eaa04: ldr             x16, [x16, #0xda8]
    // 0x13eaa08: StoreField: r0->field_f = r16
    //     0x13eaa08: stur            w16, [x0, #0xf]
    // 0x13eaa0c: ldur            x1, [fp, #-0x10]
    // 0x13eaa10: LoadField: r2 = r1->field_b
    //     0x13eaa10: ldur            w2, [x1, #0xb]
    // 0x13eaa14: DecompressPointer r2
    //     0x13eaa14: add             x2, x2, HEAP, lsl #32
    // 0x13eaa18: StoreField: r0->field_13 = r2
    //     0x13eaa18: stur            w2, [x0, #0x13]
    // 0x13eaa1c: str             x0, [SP]
    // 0x13eaa20: r0 = _interpolate()
    //     0x13eaa20: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x13eaa24: r1 = <Object?>
    //     0x13eaa24: ldr             x1, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0x13eaa28: stur            x0, [fp, #-0x10]
    // 0x13eaa2c: r0 = BasicMessageChannel()
    //     0x13eaa2c: bl              #0x8bfb04  ; AllocateBasicMessageChannelStub -> BasicMessageChannel<X0> (size=0x18)
    // 0x13eaa30: mov             x1, x0
    // 0x13eaa34: ldur            x0, [fp, #-0x10]
    // 0x13eaa38: StoreField: r1->field_b = r0
    //     0x13eaa38: stur            w0, [x1, #0xb]
    // 0x13eaa3c: r2 = Instance__PigeonCodec
    //     0x13eaa3c: add             x2, PP, #8, lsl #12  ; [pp+0x8d18] Obj!_PigeonCodec@129ff71
    //     0x13eaa40: ldr             x2, [x2, #0xd18]
    // 0x13eaa44: StoreField: r1->field_f = r2
    //     0x13eaa44: stur            w2, [x1, #0xf]
    // 0x13eaa48: r2 = Null
    //     0x13eaa48: mov             x2, NULL
    // 0x13eaa4c: r0 = send()
    //     0x13eaa4c: bl              #0x8bf9c0  ; [package:flutter/src/services/platform_channel.dart] BasicMessageChannel::send
    // 0x13eaa50: mov             x1, x0
    // 0x13eaa54: stur            x1, [fp, #-0x18]
    // 0x13eaa58: r0 = Await()
    //     0x13eaa58: bl              #0x7f5c00  ; AwaitStub
    // 0x13eaa5c: mov             x3, x0
    // 0x13eaa60: r2 = Null
    //     0x13eaa60: mov             x2, NULL
    // 0x13eaa64: r1 = Null
    //     0x13eaa64: mov             x1, NULL
    // 0x13eaa68: stur            x3, [fp, #-0x18]
    // 0x13eaa6c: r4 = 60
    //     0x13eaa6c: mov             x4, #0x3c
    // 0x13eaa70: branchIfSmi(r0, 0x13eaa7c)
    //     0x13eaa70: tbz             w0, #0, #0x13eaa7c
    // 0x13eaa74: r4 = LoadClassIdInstr(r0)
    //     0x13eaa74: ldur            x4, [x0, #-1]
    //     0x13eaa78: ubfx            x4, x4, #0xc, #0x14
    // 0x13eaa7c: sub             x4, x4, #0x5a
    // 0x13eaa80: cmp             x4, #2
    // 0x13eaa84: b.ls            #0x13eaa98
    // 0x13eaa88: r8 = List<Object?>?
    //     0x13eaa88: ldr             x8, [PP, #0x1988]  ; [pp+0x1988] Type: List<Object?>?
    // 0x13eaa8c: r3 = Null
    //     0x13eaa8c: add             x3, PP, #8, lsl #12  ; [pp+0x8db0] Null
    //     0x13eaa90: ldr             x3, [x3, #0xdb0]
    // 0x13eaa94: r0 = List<Object?>?()
    //     0x13eaa94: bl              #0x823c84  ; IsType_List<Object?>?_Stub
    // 0x13eaa98: ldur            x1, [fp, #-0x18]
    // 0x13eaa9c: ldur            x2, [fp, #-0x10]
    // 0x13eaaa0: r0 = _extractReplyValueOrThrow()
    //     0x13eaaa0: bl              #0x13ea66c  ; [package:firebase_core_platform_interface/src/pigeon/messages.pigeon.dart] ::_extractReplyValueOrThrow
    // 0x13eaaa4: mov             x3, x0
    // 0x13eaaa8: stur            x3, [fp, #-0x10]
    // 0x13eaaac: cmp             w3, NULL
    // 0x13eaab0: b.eq            #0x13eab2c
    // 0x13eaab4: mov             x0, x3
    // 0x13eaab8: r2 = Null
    //     0x13eaab8: mov             x2, NULL
    // 0x13eaabc: r1 = Null
    //     0x13eaabc: mov             x1, NULL
    // 0x13eaac0: r4 = 60
    //     0x13eaac0: mov             x4, #0x3c
    // 0x13eaac4: branchIfSmi(r0, 0x13eaad0)
    //     0x13eaac4: tbz             w0, #0, #0x13eaad0
    // 0x13eaac8: r4 = LoadClassIdInstr(r0)
    //     0x13eaac8: ldur            x4, [x0, #-1]
    //     0x13eaacc: ubfx            x4, x4, #0xc, #0x14
    // 0x13eaad0: sub             x4, x4, #0x5a
    // 0x13eaad4: cmp             x4, #2
    // 0x13eaad8: b.ls            #0x13eaaec
    // 0x13eaadc: r8 = List<Object?>
    //     0x13eaadc: ldr             x8, [PP, #0x3800]  ; [pp+0x3800] Type: List<Object?>
    // 0x13eaae0: r3 = Null
    //     0x13eaae0: add             x3, PP, #8, lsl #12  ; [pp+0x8dc0] Null
    //     0x13eaae4: ldr             x3, [x3, #0xdc0]
    // 0x13eaae8: r0 = List<Object?>()
    //     0x13eaae8: bl              #0x7fc684  ; IsType_List<Object?>_Stub
    // 0x13eaaec: ldur            x0, [fp, #-0x10]
    // 0x13eaaf0: r1 = LoadClassIdInstr(r0)
    //     0x13eaaf0: ldur            x1, [x0, #-1]
    //     0x13eaaf4: ubfx            x1, x1, #0xc, #0x14
    // 0x13eaaf8: r16 = <CoreInitializeResponse>
    //     0x13eaaf8: add             x16, PP, #8, lsl #12  ; [pp+0x8d08] TypeArguments: <CoreInitializeResponse>
    //     0x13eaafc: ldr             x16, [x16, #0xd08]
    // 0x13eab00: stp             x0, x16, [SP]
    // 0x13eab04: mov             x0, x1
    // 0x13eab08: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x13eab08: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x13eab0c: r0 = GDT[cid_x0 + 0x13106]()
    //     0x13eab0c: mov             x17, #0x3106
    //     0x13eab10: movk            x17, #1, lsl #16
    //     0x13eab14: add             lr, x0, x17
    //     0x13eab18: ldr             lr, [x21, lr, lsl #3]
    //     0x13eab1c: blr             lr
    // 0x13eab20: r0 = ReturnAsyncNotFuture()
    //     0x13eab20: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x13eab24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13eab24: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13eab28: b               #0x13ea9e8
    // 0x13eab2c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x13eab2c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 3365, size: 0x8, field offset: 0x8
//   const constructor, 
class _PigeonCodec extends StandardMessageCodec {

  _ readValueOfType(/* No info */) {
    // ** addr: 0x10f4900, size: 0xa4
    // 0x10f4900: EnterFrame
    //     0x10f4900: stp             fp, lr, [SP, #-0x10]!
    //     0x10f4904: mov             fp, SP
    // 0x10f4908: mov             x0, x2
    // 0x10f490c: mov             x2, x3
    // 0x10f4910: CheckStackOverflow
    //     0x10f4910: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f4914: cmp             SP, x16
    //     0x10f4918: b.ls            #0x10f4994
    // 0x10f491c: cmp             x0, #0x81
    // 0x10f4920: b.gt            #0x10f4950
    // 0x10f4924: lsl             x3, x0, #1
    // 0x10f4928: cmp             w3, #0x102
    // 0x10f492c: b.ne            #0x10f497c
    // 0x10f4930: r0 = readValue()
    //     0x10f4930: bl              #0xcced20  ; [package:flutter/src/services/message_codecs.dart] StandardMessageCodec::readValue
    // 0x10f4934: cmp             w0, NULL
    // 0x10f4938: b.eq            #0x10f499c
    // 0x10f493c: mov             x1, x0
    // 0x10f4940: r0 = decode()
    //     0x10f4940: bl              #0x10f4bec  ; [package:firebase_core_platform_interface/src/pigeon/messages.pigeon.dart] CoreFirebaseOptions::decode
    // 0x10f4944: LeaveFrame
    //     0x10f4944: mov             SP, fp
    //     0x10f4948: ldp             fp, lr, [SP], #0x10
    // 0x10f494c: ret
    //     0x10f494c: ret             
    // 0x10f4950: lsl             x3, x0, #1
    // 0x10f4954: cmp             w3, #0x104
    // 0x10f4958: b.ne            #0x10f497c
    // 0x10f495c: r0 = readValue()
    //     0x10f495c: bl              #0xcced20  ; [package:flutter/src/services/message_codecs.dart] StandardMessageCodec::readValue
    // 0x10f4960: cmp             w0, NULL
    // 0x10f4964: b.eq            #0x10f49a0
    // 0x10f4968: mov             x1, x0
    // 0x10f496c: r0 = decode()
    //     0x10f496c: bl              #0x10f49a4  ; [package:firebase_core_platform_interface/src/pigeon/messages.pigeon.dart] CoreInitializeResponse::decode
    // 0x10f4970: LeaveFrame
    //     0x10f4970: mov             SP, fp
    //     0x10f4974: ldp             fp, lr, [SP], #0x10
    // 0x10f4978: ret
    //     0x10f4978: ret             
    // 0x10f497c: mov             x3, x2
    // 0x10f4980: mov             x2, x0
    // 0x10f4984: r0 = readValueOfType()
    //     0x10f4984: bl              #0x10f7eb8  ; [package:flutter/src/services/message_codecs.dart] StandardMessageCodec::readValueOfType
    // 0x10f4988: LeaveFrame
    //     0x10f4988: mov             SP, fp
    //     0x10f498c: ldp             fp, lr, [SP], #0x10
    // 0x10f4990: ret
    //     0x10f4990: ret             
    // 0x10f4994: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10f4994: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10f4998: b               #0x10f491c
    // 0x10f499c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10f499c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x10f49a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10f49a0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ writeValue(/* No info */) {
    // ** addr: 0x12f2164, size: 0xfc
    // 0x12f2164: EnterFrame
    //     0x12f2164: stp             fp, lr, [SP, #-0x10]!
    //     0x12f2168: mov             fp, SP
    // 0x12f216c: AllocStack(0x18)
    //     0x12f216c: sub             SP, SP, #0x18
    // 0x12f2170: SetupParameters(_PigeonCodec this /* r1 => r4, fp-0x18 */, dynamic _ /* r2 => r3, fp-0x8 */, dynamic _ /* r3 => r0, fp-0x10 */)
    //     0x12f2170: mov             x4, x1
    //     0x12f2174: mov             x0, x3
    //     0x12f2178: stur            x3, [fp, #-0x10]
    //     0x12f217c: mov             x3, x2
    //     0x12f2180: stur            x2, [fp, #-8]
    //     0x12f2184: stur            x1, [fp, #-0x18]
    // 0x12f2188: CheckStackOverflow
    //     0x12f2188: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f218c: cmp             SP, x16
    //     0x12f2190: b.ls            #0x12f2258
    // 0x12f2194: r1 = 60
    //     0x12f2194: mov             x1, #0x3c
    // 0x12f2198: branchIfSmi(r0, 0x12f21a4)
    //     0x12f2198: tbz             w0, #0, #0x12f21a4
    // 0x12f219c: r1 = LoadClassIdInstr(r0)
    //     0x12f219c: ldur            x1, [x0, #-1]
    //     0x12f21a0: ubfx            x1, x1, #0xc, #0x14
    // 0x12f21a4: sub             x16, x1, #0x3c
    // 0x12f21a8: cmp             x16, #1
    // 0x12f21ac: b.hi            #0x12f21d8
    // 0x12f21b0: mov             x1, x3
    // 0x12f21b4: r2 = 4
    //     0x12f21b4: mov             x2, #4
    // 0x12f21b8: r0 = _add()
    //     0x12f21b8: bl              #0x12f289c  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_add
    // 0x12f21bc: ldur            x0, [fp, #-0x10]
    // 0x12f21c0: r2 = LoadInt32Instr(r0)
    //     0x12f21c0: sbfx            x2, x0, #1, #0x1f
    //     0x12f21c4: tbz             w0, #0, #0x12f21cc
    //     0x12f21c8: ldur            x2, [x0, #7]
    // 0x12f21cc: ldur            x1, [fp, #-8]
    // 0x12f21d0: r0 = putInt64()
    //     0x12f21d0: bl              #0x12f2260  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::putInt64
    // 0x12f21d4: b               #0x12f2248
    // 0x12f21d8: cmp             x1, #0xd27
    // 0x12f21dc: b.ne            #0x12f2208
    // 0x12f21e0: ldur            x1, [fp, #-8]
    // 0x12f21e4: r2 = 129
    //     0x12f21e4: mov             x2, #0x81
    // 0x12f21e8: r0 = _add()
    //     0x12f21e8: bl              #0x12f289c  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_add
    // 0x12f21ec: ldur            x1, [fp, #-0x10]
    // 0x12f21f0: r0 = _toList()
    //     0x12f21f0: bl              #0x114a754  ; [package:firebase_core_platform_interface/src/pigeon/messages.pigeon.dart] CoreFirebaseOptions::_toList
    // 0x12f21f4: ldur            x1, [fp, #-0x18]
    // 0x12f21f8: ldur            x2, [fp, #-8]
    // 0x12f21fc: mov             x3, x0
    // 0x12f2200: r0 = writeValue()
    //     0x12f2200: bl              #0x12f2164  ; [package:firebase_core_platform_interface/src/pigeon/messages.pigeon.dart] _PigeonCodec::writeValue
    // 0x12f2204: b               #0x12f2248
    // 0x12f2208: cmp             x1, #0xd26
    // 0x12f220c: b.ne            #0x12f2238
    // 0x12f2210: ldur            x1, [fp, #-8]
    // 0x12f2214: r2 = 130
    //     0x12f2214: mov             x2, #0x82
    // 0x12f2218: r0 = _add()
    //     0x12f2218: bl              #0x12f289c  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_add
    // 0x12f221c: ldur            x1, [fp, #-0x10]
    // 0x12f2220: r0 = _toList()
    //     0x12f2220: bl              #0x114a904  ; [package:firebase_core_platform_interface/src/pigeon/messages.pigeon.dart] CoreInitializeResponse::_toList
    // 0x12f2224: ldur            x1, [fp, #-0x18]
    // 0x12f2228: ldur            x2, [fp, #-8]
    // 0x12f222c: mov             x3, x0
    // 0x12f2230: r0 = writeValue()
    //     0x12f2230: bl              #0x12f2164  ; [package:firebase_core_platform_interface/src/pigeon/messages.pigeon.dart] _PigeonCodec::writeValue
    // 0x12f2234: b               #0x12f2248
    // 0x12f2238: ldur            x1, [fp, #-0x18]
    // 0x12f223c: ldur            x2, [fp, #-8]
    // 0x12f2240: ldur            x3, [fp, #-0x10]
    // 0x12f2244: r0 = writeValue()
    //     0x12f2244: bl              #0x12f3424  ; [package:flutter/src/services/message_codecs.dart] StandardMessageCodec::writeValue
    // 0x12f2248: r0 = Null
    //     0x12f2248: mov             x0, NULL
    // 0x12f224c: LeaveFrame
    //     0x12f224c: mov             SP, fp
    //     0x12f2250: ldp             fp, lr, [SP], #0x10
    // 0x12f2254: ret
    //     0x12f2254: ret             
    // 0x12f2258: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f2258: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f225c: b               #0x12f2194
  }
}

// class id: 3366, size: 0x18, field offset: 0x8
class CoreInitializeResponse extends Object {

  static _ decode(/* No info */) {
    // ** addr: 0x10f49a4, size: 0x23c
    // 0x10f49a4: EnterFrame
    //     0x10f49a4: stp             fp, lr, [SP, #-0x10]!
    //     0x10f49a8: mov             fp, SP
    // 0x10f49ac: AllocStack(0x30)
    //     0x10f49ac: sub             SP, SP, #0x30
    // 0x10f49b0: SetupParameters(dynamic _ /* r1 => r3, fp-0x8 */)
    //     0x10f49b0: mov             x3, x1
    //     0x10f49b4: stur            x1, [fp, #-8]
    // 0x10f49b8: CheckStackOverflow
    //     0x10f49b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f49bc: cmp             SP, x16
    //     0x10f49c0: b.ls            #0x10f4bcc
    // 0x10f49c4: mov             x0, x3
    // 0x10f49c8: r2 = Null
    //     0x10f49c8: mov             x2, NULL
    // 0x10f49cc: r1 = Null
    //     0x10f49cc: mov             x1, NULL
    // 0x10f49d0: r4 = 60
    //     0x10f49d0: mov             x4, #0x3c
    // 0x10f49d4: branchIfSmi(r0, 0x10f49e0)
    //     0x10f49d4: tbz             w0, #0, #0x10f49e0
    // 0x10f49d8: r4 = LoadClassIdInstr(r0)
    //     0x10f49d8: ldur            x4, [x0, #-1]
    //     0x10f49dc: ubfx            x4, x4, #0xc, #0x14
    // 0x10f49e0: sub             x4, x4, #0x5a
    // 0x10f49e4: cmp             x4, #2
    // 0x10f49e8: b.ls            #0x10f49fc
    // 0x10f49ec: r8 = List<Object?>
    //     0x10f49ec: ldr             x8, [PP, #0x3800]  ; [pp+0x3800] Type: List<Object?>
    // 0x10f49f0: r3 = Null
    //     0x10f49f0: add             x3, PP, #0xc, lsl #12  ; [pp+0xccd8] Null
    //     0x10f49f4: ldr             x3, [x3, #0xcd8]
    // 0x10f49f8: r0 = List<Object?>()
    //     0x10f49f8: bl              #0x7fc684  ; IsType_List<Object?>_Stub
    // 0x10f49fc: ldur            x1, [fp, #-8]
    // 0x10f4a00: r0 = LoadClassIdInstr(r1)
    //     0x10f4a00: ldur            x0, [x1, #-1]
    //     0x10f4a04: ubfx            x0, x0, #0xc, #0x14
    // 0x10f4a08: stp             xzr, x1, [SP]
    // 0x10f4a0c: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x10f4a0c: sub             lr, x0, #0xdfd
    //     0x10f4a10: ldr             lr, [x21, lr, lsl #3]
    //     0x10f4a14: blr             lr
    // 0x10f4a18: mov             x3, x0
    // 0x10f4a1c: stur            x3, [fp, #-0x10]
    // 0x10f4a20: cmp             w3, NULL
    // 0x10f4a24: b.eq            #0x10f4bd4
    // 0x10f4a28: mov             x0, x3
    // 0x10f4a2c: r2 = Null
    //     0x10f4a2c: mov             x2, NULL
    // 0x10f4a30: r1 = Null
    //     0x10f4a30: mov             x1, NULL
    // 0x10f4a34: r4 = 60
    //     0x10f4a34: mov             x4, #0x3c
    // 0x10f4a38: branchIfSmi(r0, 0x10f4a44)
    //     0x10f4a38: tbz             w0, #0, #0x10f4a44
    // 0x10f4a3c: r4 = LoadClassIdInstr(r0)
    //     0x10f4a3c: ldur            x4, [x0, #-1]
    //     0x10f4a40: ubfx            x4, x4, #0xc, #0x14
    // 0x10f4a44: sub             x4, x4, #0x5e
    // 0x10f4a48: cmp             x4, #1
    // 0x10f4a4c: b.ls            #0x10f4a60
    // 0x10f4a50: r8 = String
    //     0x10f4a50: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x10f4a54: r3 = Null
    //     0x10f4a54: add             x3, PP, #0xc, lsl #12  ; [pp+0xcce8] Null
    //     0x10f4a58: ldr             x3, [x3, #0xce8]
    // 0x10f4a5c: r0 = String()
    //     0x10f4a5c: bl              #0x13ee320  ; IsType_String_Stub
    // 0x10f4a60: ldur            x1, [fp, #-8]
    // 0x10f4a64: r0 = LoadClassIdInstr(r1)
    //     0x10f4a64: ldur            x0, [x1, #-1]
    //     0x10f4a68: ubfx            x0, x0, #0xc, #0x14
    // 0x10f4a6c: r16 = 2
    //     0x10f4a6c: mov             x16, #2
    // 0x10f4a70: stp             x16, x1, [SP]
    // 0x10f4a74: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x10f4a74: sub             lr, x0, #0xdfd
    //     0x10f4a78: ldr             lr, [x21, lr, lsl #3]
    //     0x10f4a7c: blr             lr
    // 0x10f4a80: mov             x3, x0
    // 0x10f4a84: stur            x3, [fp, #-0x18]
    // 0x10f4a88: cmp             w3, NULL
    // 0x10f4a8c: b.eq            #0x10f4bd8
    // 0x10f4a90: mov             x0, x3
    // 0x10f4a94: r2 = Null
    //     0x10f4a94: mov             x2, NULL
    // 0x10f4a98: r1 = Null
    //     0x10f4a98: mov             x1, NULL
    // 0x10f4a9c: r4 = 60
    //     0x10f4a9c: mov             x4, #0x3c
    // 0x10f4aa0: branchIfSmi(r0, 0x10f4aac)
    //     0x10f4aa0: tbz             w0, #0, #0x10f4aac
    // 0x10f4aa4: r4 = LoadClassIdInstr(r0)
    //     0x10f4aa4: ldur            x4, [x0, #-1]
    //     0x10f4aa8: ubfx            x4, x4, #0xc, #0x14
    // 0x10f4aac: cmp             x4, #0xd27
    // 0x10f4ab0: b.eq            #0x10f4ac8
    // 0x10f4ab4: r8 = CoreFirebaseOptions
    //     0x10f4ab4: add             x8, PP, #0xc, lsl #12  ; [pp+0xccf8] Type: CoreFirebaseOptions
    //     0x10f4ab8: ldr             x8, [x8, #0xcf8]
    // 0x10f4abc: r3 = Null
    //     0x10f4abc: add             x3, PP, #0xc, lsl #12  ; [pp+0xcd00] Null
    //     0x10f4ac0: ldr             x3, [x3, #0xd00]
    // 0x10f4ac4: r0 = DefaultTypeTest()
    //     0x10f4ac4: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x10f4ac8: ldur            x1, [fp, #-8]
    // 0x10f4acc: r0 = LoadClassIdInstr(r1)
    //     0x10f4acc: ldur            x0, [x1, #-1]
    //     0x10f4ad0: ubfx            x0, x0, #0xc, #0x14
    // 0x10f4ad4: r16 = 4
    //     0x10f4ad4: mov             x16, #4
    // 0x10f4ad8: stp             x16, x1, [SP]
    // 0x10f4adc: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x10f4adc: sub             lr, x0, #0xdfd
    //     0x10f4ae0: ldr             lr, [x21, lr, lsl #3]
    //     0x10f4ae4: blr             lr
    // 0x10f4ae8: mov             x3, x0
    // 0x10f4aec: r2 = Null
    //     0x10f4aec: mov             x2, NULL
    // 0x10f4af0: r1 = Null
    //     0x10f4af0: mov             x1, NULL
    // 0x10f4af4: stur            x3, [fp, #-0x20]
    // 0x10f4af8: r4 = 60
    //     0x10f4af8: mov             x4, #0x3c
    // 0x10f4afc: branchIfSmi(r0, 0x10f4b08)
    //     0x10f4afc: tbz             w0, #0, #0x10f4b08
    // 0x10f4b00: r4 = LoadClassIdInstr(r0)
    //     0x10f4b00: ldur            x4, [x0, #-1]
    //     0x10f4b04: ubfx            x4, x4, #0xc, #0x14
    // 0x10f4b08: cmp             x4, #0x3f
    // 0x10f4b0c: b.eq            #0x10f4b20
    // 0x10f4b10: r8 = bool?
    //     0x10f4b10: ldr             x8, [PP, #0x5fd0]  ; [pp+0x5fd0] Type: bool?
    // 0x10f4b14: r3 = Null
    //     0x10f4b14: add             x3, PP, #0xc, lsl #12  ; [pp+0xcd10] Null
    //     0x10f4b18: ldr             x3, [x3, #0xd10]
    // 0x10f4b1c: r0 = bool?()
    //     0x10f4b1c: bl              #0x7ecd2c  ; IsType_bool?_Stub
    // 0x10f4b20: ldur            x0, [fp, #-8]
    // 0x10f4b24: r1 = LoadClassIdInstr(r0)
    //     0x10f4b24: ldur            x1, [x0, #-1]
    //     0x10f4b28: ubfx            x1, x1, #0xc, #0x14
    // 0x10f4b2c: r16 = 6
    //     0x10f4b2c: mov             x16, #6
    // 0x10f4b30: stp             x16, x0, [SP]
    // 0x10f4b34: mov             x0, x1
    // 0x10f4b38: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x10f4b38: sub             lr, x0, #0xdfd
    //     0x10f4b3c: ldr             lr, [x21, lr, lsl #3]
    //     0x10f4b40: blr             lr
    // 0x10f4b44: mov             x3, x0
    // 0x10f4b48: stur            x3, [fp, #-8]
    // 0x10f4b4c: cmp             w3, NULL
    // 0x10f4b50: b.eq            #0x10f4bdc
    // 0x10f4b54: mov             x0, x3
    // 0x10f4b58: r2 = Null
    //     0x10f4b58: mov             x2, NULL
    // 0x10f4b5c: r1 = Null
    //     0x10f4b5c: mov             x1, NULL
    // 0x10f4b60: r8 = Map<Object?, Object?>
    //     0x10f4b60: ldr             x8, [PP, #0x3238]  ; [pp+0x3238] Type: Map<Object?, Object?>
    // 0x10f4b64: r3 = Null
    //     0x10f4b64: add             x3, PP, #0xc, lsl #12  ; [pp+0xcd20] Null
    //     0x10f4b68: ldr             x3, [x3, #0xd20]
    // 0x10f4b6c: r0 = Map<Object?, Object?>()
    //     0x10f4b6c: bl              #0x851560  ; IsType_Map<Object?, Object?>_Stub
    // 0x10f4b70: ldur            x0, [fp, #-8]
    // 0x10f4b74: r1 = LoadClassIdInstr(r0)
    //     0x10f4b74: ldur            x1, [x0, #-1]
    //     0x10f4b78: ubfx            x1, x1, #0xc, #0x14
    // 0x10f4b7c: r16 = <String?, Object?>
    //     0x10f4b7c: ldr             x16, [PP, #0x18d8]  ; [pp+0x18d8] TypeArguments: <String?, Object?>
    // 0x10f4b80: stp             x0, x16, [SP]
    // 0x10f4b84: mov             x0, x1
    // 0x10f4b88: r4 = const [0x2, 0x1, 0x1, 0x1, null]
    //     0x10f4b88: ldr             x4, [PP, #0x18e0]  ; [pp+0x18e0] List(5) [0x2, 0x1, 0x1, 0x1, Null]
    // 0x10f4b8c: r0 = GDT[cid_x0 + 0xfb3]()
    //     0x10f4b8c: add             lr, x0, #0xfb3
    //     0x10f4b90: ldr             lr, [x21, lr, lsl #3]
    //     0x10f4b94: blr             lr
    // 0x10f4b98: stur            x0, [fp, #-8]
    // 0x10f4b9c: r0 = CoreInitializeResponse()
    //     0x10f4b9c: bl              #0x10f4be0  ; AllocateCoreInitializeResponseStub -> CoreInitializeResponse (size=0x18)
    // 0x10f4ba0: ldur            x1, [fp, #-0x10]
    // 0x10f4ba4: StoreField: r0->field_7 = r1
    //     0x10f4ba4: stur            w1, [x0, #7]
    // 0x10f4ba8: ldur            x1, [fp, #-0x18]
    // 0x10f4bac: StoreField: r0->field_b = r1
    //     0x10f4bac: stur            w1, [x0, #0xb]
    // 0x10f4bb0: ldur            x1, [fp, #-0x20]
    // 0x10f4bb4: StoreField: r0->field_f = r1
    //     0x10f4bb4: stur            w1, [x0, #0xf]
    // 0x10f4bb8: ldur            x1, [fp, #-8]
    // 0x10f4bbc: StoreField: r0->field_13 = r1
    //     0x10f4bbc: stur            w1, [x0, #0x13]
    // 0x10f4bc0: LeaveFrame
    //     0x10f4bc0: mov             SP, fp
    //     0x10f4bc4: ldp             fp, lr, [SP], #0x10
    // 0x10f4bc8: ret
    //     0x10f4bc8: ret             
    // 0x10f4bcc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10f4bcc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10f4bd0: b               #0x10f49c4
    // 0x10f4bd4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10f4bd4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x10f4bd8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10f4bd8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x10f4bdc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10f4bdc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x114a864, size: 0xa0
    // 0x114a864: EnterFrame
    //     0x114a864: stp             fp, lr, [SP, #-0x10]!
    //     0x114a868: mov             fp, SP
    // 0x114a86c: AllocStack(0x10)
    //     0x114a86c: sub             SP, SP, #0x10
    // 0x114a870: r0 = 2
    //     0x114a870: mov             x0, #2
    // 0x114a874: CheckStackOverflow
    //     0x114a874: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x114a878: cmp             SP, x16
    //     0x114a87c: b.ls            #0x114a8fc
    // 0x114a880: mov             x2, x0
    // 0x114a884: r1 = Null
    //     0x114a884: mov             x1, NULL
    // 0x114a888: r0 = AllocateArray()
    //     0x114a888: bl              #0x13df928  ; AllocateArrayStub
    // 0x114a88c: stur            x0, [fp, #-8]
    // 0x114a890: r16 = CoreInitializeResponse
    //     0x114a890: add             x16, PP, #8, lsl #12  ; [pp+0x8d30] Type: CoreInitializeResponse
    //     0x114a894: ldr             x16, [x16, #0xd30]
    // 0x114a898: StoreField: r0->field_f = r16
    //     0x114a898: stur            w16, [x0, #0xf]
    // 0x114a89c: r1 = <Object?>
    //     0x114a89c: ldr             x1, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0x114a8a0: r0 = AllocateGrowableArray()
    //     0x114a8a0: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x114a8a4: mov             x2, x0
    // 0x114a8a8: ldur            x0, [fp, #-8]
    // 0x114a8ac: stur            x2, [fp, #-0x10]
    // 0x114a8b0: StoreField: r2->field_f = r0
    //     0x114a8b0: stur            w0, [x2, #0xf]
    // 0x114a8b4: r0 = 2
    //     0x114a8b4: mov             x0, #2
    // 0x114a8b8: StoreField: r2->field_b = r0
    //     0x114a8b8: stur            w0, [x2, #0xb]
    // 0x114a8bc: ldr             x1, [fp, #0x10]
    // 0x114a8c0: r0 = _toList()
    //     0x114a8c0: bl              #0x114a904  ; [package:firebase_core_platform_interface/src/pigeon/messages.pigeon.dart] CoreInitializeResponse::_toList
    // 0x114a8c4: ldur            x1, [fp, #-0x10]
    // 0x114a8c8: mov             x2, x0
    // 0x114a8cc: r0 = addAll()
    //     0x114a8cc: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0x114a8d0: ldur            x1, [fp, #-0x10]
    // 0x114a8d4: r0 = _deepHash()
    //     0x114a8d4: bl              #0x1149b58  ; [package:firebase_core_platform_interface/src/pigeon/messages.pigeon.dart] ::_deepHash
    // 0x114a8d8: mov             x2, x0
    // 0x114a8dc: r0 = BoxInt64Instr(r2)
    //     0x114a8dc: sbfiz           x0, x2, #1, #0x1f
    //     0x114a8e0: cmp             x2, x0, asr #1
    //     0x114a8e4: b.eq            #0x114a8f0
    //     0x114a8e8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x114a8ec: stur            x2, [x0, #7]
    // 0x114a8f0: LeaveFrame
    //     0x114a8f0: mov             SP, fp
    //     0x114a8f4: ldp             fp, lr, [SP], #0x10
    // 0x114a8f8: ret
    //     0x114a8f8: ret             
    // 0x114a8fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x114a8fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x114a900: b               #0x114a880
  }
  _ _toList(/* No info */) {
    // ** addr: 0x114a904, size: 0x98
    // 0x114a904: EnterFrame
    //     0x114a904: stp             fp, lr, [SP, #-0x10]!
    //     0x114a908: mov             fp, SP
    // 0x114a90c: AllocStack(0x28)
    //     0x114a90c: sub             SP, SP, #0x28
    // 0x114a910: r0 = 8
    //     0x114a910: mov             x0, #8
    // 0x114a914: LoadField: r3 = r1->field_7
    //     0x114a914: ldur            w3, [x1, #7]
    // 0x114a918: DecompressPointer r3
    //     0x114a918: add             x3, x3, HEAP, lsl #32
    // 0x114a91c: stur            x3, [fp, #-0x20]
    // 0x114a920: LoadField: r4 = r1->field_b
    //     0x114a920: ldur            w4, [x1, #0xb]
    // 0x114a924: DecompressPointer r4
    //     0x114a924: add             x4, x4, HEAP, lsl #32
    // 0x114a928: stur            x4, [fp, #-0x18]
    // 0x114a92c: LoadField: r5 = r1->field_f
    //     0x114a92c: ldur            w5, [x1, #0xf]
    // 0x114a930: DecompressPointer r5
    //     0x114a930: add             x5, x5, HEAP, lsl #32
    // 0x114a934: stur            x5, [fp, #-0x10]
    // 0x114a938: LoadField: r6 = r1->field_13
    //     0x114a938: ldur            w6, [x1, #0x13]
    // 0x114a93c: DecompressPointer r6
    //     0x114a93c: add             x6, x6, HEAP, lsl #32
    // 0x114a940: mov             x2, x0
    // 0x114a944: stur            x6, [fp, #-8]
    // 0x114a948: r1 = Null
    //     0x114a948: mov             x1, NULL
    // 0x114a94c: r0 = AllocateArray()
    //     0x114a94c: bl              #0x13df928  ; AllocateArrayStub
    // 0x114a950: mov             x2, x0
    // 0x114a954: ldur            x0, [fp, #-0x20]
    // 0x114a958: stur            x2, [fp, #-0x28]
    // 0x114a95c: StoreField: r2->field_f = r0
    //     0x114a95c: stur            w0, [x2, #0xf]
    // 0x114a960: ldur            x0, [fp, #-0x18]
    // 0x114a964: StoreField: r2->field_13 = r0
    //     0x114a964: stur            w0, [x2, #0x13]
    // 0x114a968: ldur            x0, [fp, #-0x10]
    // 0x114a96c: ArrayStore: r2[0] = r0  ; List_4
    //     0x114a96c: stur            w0, [x2, #0x17]
    // 0x114a970: ldur            x0, [fp, #-8]
    // 0x114a974: StoreField: r2->field_1b = r0
    //     0x114a974: stur            w0, [x2, #0x1b]
    // 0x114a978: r1 = <Object?>
    //     0x114a978: ldr             x1, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0x114a97c: r0 = AllocateGrowableArray()
    //     0x114a97c: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x114a980: ldur            x1, [fp, #-0x28]
    // 0x114a984: StoreField: r0->field_f = r1
    //     0x114a984: stur            w1, [x0, #0xf]
    // 0x114a988: r1 = 8
    //     0x114a988: mov             x1, #8
    // 0x114a98c: StoreField: r0->field_b = r1
    //     0x114a98c: stur            w1, [x0, #0xb]
    // 0x114a990: LeaveFrame
    //     0x114a990: mov             SP, fp
    //     0x114a994: ldp             fp, lr, [SP], #0x10
    // 0x114a998: ret
    //     0x114a998: ret             
  }
  _ ==(/* No info */) {
    // ** addr: 0x1294ba4, size: 0x134
    // 0x1294ba4: EnterFrame
    //     0x1294ba4: stp             fp, lr, [SP, #-0x10]!
    //     0x1294ba8: mov             fp, SP
    // 0x1294bac: AllocStack(0x10)
    //     0x1294bac: sub             SP, SP, #0x10
    // 0x1294bb0: CheckStackOverflow
    //     0x1294bb0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1294bb4: cmp             SP, x16
    //     0x1294bb8: b.ls            #0x1294cd0
    // 0x1294bbc: ldr             x0, [fp, #0x10]
    // 0x1294bc0: cmp             w0, NULL
    // 0x1294bc4: b.ne            #0x1294bd8
    // 0x1294bc8: r0 = false
    //     0x1294bc8: add             x0, NULL, #0x30  ; false
    // 0x1294bcc: LeaveFrame
    //     0x1294bcc: mov             SP, fp
    //     0x1294bd0: ldp             fp, lr, [SP], #0x10
    // 0x1294bd4: ret
    //     0x1294bd4: ret             
    // 0x1294bd8: r1 = 60
    //     0x1294bd8: mov             x1, #0x3c
    // 0x1294bdc: branchIfSmi(r0, 0x1294be8)
    //     0x1294bdc: tbz             w0, #0, #0x1294be8
    // 0x1294be0: r1 = LoadClassIdInstr(r0)
    //     0x1294be0: ldur            x1, [x0, #-1]
    //     0x1294be4: ubfx            x1, x1, #0xc, #0x14
    // 0x1294be8: cmp             x1, #0xd26
    // 0x1294bec: b.ne            #0x1294c0c
    // 0x1294bf0: r16 = CoreInitializeResponse
    //     0x1294bf0: add             x16, PP, #8, lsl #12  ; [pp+0x8d30] Type: CoreInitializeResponse
    //     0x1294bf4: ldr             x16, [x16, #0xd30]
    // 0x1294bf8: r30 = CoreInitializeResponse
    //     0x1294bf8: add             lr, PP, #8, lsl #12  ; [pp+0x8d30] Type: CoreInitializeResponse
    //     0x1294bfc: ldr             lr, [lr, #0xd30]
    // 0x1294c00: stp             lr, x16, [SP]
    // 0x1294c04: r0 = ==()
    //     0x1294c04: bl              #0x12b7fbc  ; [dart:core] _Type::==
    // 0x1294c08: tbz             w0, #4, #0x1294c1c
    // 0x1294c0c: r0 = false
    //     0x1294c0c: add             x0, NULL, #0x30  ; false
    // 0x1294c10: LeaveFrame
    //     0x1294c10: mov             SP, fp
    //     0x1294c14: ldp             fp, lr, [SP], #0x10
    // 0x1294c18: ret
    //     0x1294c18: ret             
    // 0x1294c1c: ldr             x3, [fp, #0x18]
    // 0x1294c20: ldr             x0, [fp, #0x10]
    // 0x1294c24: cmp             w3, w0
    // 0x1294c28: b.ne            #0x1294c3c
    // 0x1294c2c: r0 = true
    //     0x1294c2c: add             x0, NULL, #0x20  ; true
    // 0x1294c30: LeaveFrame
    //     0x1294c30: mov             SP, fp
    //     0x1294c34: ldp             fp, lr, [SP], #0x10
    // 0x1294c38: ret
    //     0x1294c38: ret             
    // 0x1294c3c: LoadField: r1 = r3->field_7
    //     0x1294c3c: ldur            w1, [x3, #7]
    // 0x1294c40: DecompressPointer r1
    //     0x1294c40: add             x1, x1, HEAP, lsl #32
    // 0x1294c44: LoadField: r2 = r0->field_7
    //     0x1294c44: ldur            w2, [x0, #7]
    // 0x1294c48: DecompressPointer r2
    //     0x1294c48: add             x2, x2, HEAP, lsl #32
    // 0x1294c4c: r0 = _deepEquals()
    //     0x1294c4c: bl              #0x12941bc  ; [package:firebase_core_platform_interface/src/pigeon/messages.pigeon.dart] ::_deepEquals
    // 0x1294c50: tbnz            w0, #4, #0x1294cc0
    // 0x1294c54: ldr             x3, [fp, #0x18]
    // 0x1294c58: ldr             x0, [fp, #0x10]
    // 0x1294c5c: LoadField: r1 = r3->field_b
    //     0x1294c5c: ldur            w1, [x3, #0xb]
    // 0x1294c60: DecompressPointer r1
    //     0x1294c60: add             x1, x1, HEAP, lsl #32
    // 0x1294c64: LoadField: r2 = r0->field_b
    //     0x1294c64: ldur            w2, [x0, #0xb]
    // 0x1294c68: DecompressPointer r2
    //     0x1294c68: add             x2, x2, HEAP, lsl #32
    // 0x1294c6c: r0 = _deepEquals()
    //     0x1294c6c: bl              #0x12941bc  ; [package:firebase_core_platform_interface/src/pigeon/messages.pigeon.dart] ::_deepEquals
    // 0x1294c70: tbnz            w0, #4, #0x1294cc0
    // 0x1294c74: ldr             x3, [fp, #0x18]
    // 0x1294c78: ldr             x0, [fp, #0x10]
    // 0x1294c7c: LoadField: r1 = r3->field_f
    //     0x1294c7c: ldur            w1, [x3, #0xf]
    // 0x1294c80: DecompressPointer r1
    //     0x1294c80: add             x1, x1, HEAP, lsl #32
    // 0x1294c84: LoadField: r2 = r0->field_f
    //     0x1294c84: ldur            w2, [x0, #0xf]
    // 0x1294c88: DecompressPointer r2
    //     0x1294c88: add             x2, x2, HEAP, lsl #32
    // 0x1294c8c: r0 = _deepEquals()
    //     0x1294c8c: bl              #0x12941bc  ; [package:firebase_core_platform_interface/src/pigeon/messages.pigeon.dart] ::_deepEquals
    // 0x1294c90: tbnz            w0, #4, #0x1294cc0
    // 0x1294c94: ldr             x1, [fp, #0x18]
    // 0x1294c98: ldr             x0, [fp, #0x10]
    // 0x1294c9c: LoadField: r2 = r1->field_13
    //     0x1294c9c: ldur            w2, [x1, #0x13]
    // 0x1294ca0: DecompressPointer r2
    //     0x1294ca0: add             x2, x2, HEAP, lsl #32
    // 0x1294ca4: LoadField: r1 = r0->field_13
    //     0x1294ca4: ldur            w1, [x0, #0x13]
    // 0x1294ca8: DecompressPointer r1
    //     0x1294ca8: add             x1, x1, HEAP, lsl #32
    // 0x1294cac: mov             x16, x1
    // 0x1294cb0: mov             x1, x2
    // 0x1294cb4: mov             x2, x16
    // 0x1294cb8: r0 = _deepEquals()
    //     0x1294cb8: bl              #0x12941bc  ; [package:firebase_core_platform_interface/src/pigeon/messages.pigeon.dart] ::_deepEquals
    // 0x1294cbc: b               #0x1294cc4
    // 0x1294cc0: r0 = false
    //     0x1294cc0: add             x0, NULL, #0x30  ; false
    // 0x1294cc4: LeaveFrame
    //     0x1294cc4: mov             SP, fp
    //     0x1294cc8: ldp             fp, lr, [SP], #0x10
    // 0x1294ccc: ret
    //     0x1294ccc: ret             
    // 0x1294cd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1294cd0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1294cd4: b               #0x1294bbc
  }
}

// class id: 3367, size: 0x44, field offset: 0x8
class CoreFirebaseOptions extends Object {

  static _ decode(/* No info */) {
    // ** addr: 0x10f4bec, size: 0x68c
    // 0x10f4bec: EnterFrame
    //     0x10f4bec: stp             fp, lr, [SP, #-0x10]!
    //     0x10f4bf0: mov             fp, SP
    // 0x10f4bf4: AllocStack(0x88)
    //     0x10f4bf4: sub             SP, SP, #0x88
    // 0x10f4bf8: SetupParameters(dynamic _ /* r1 => r3, fp-0x8 */)
    //     0x10f4bf8: mov             x3, x1
    //     0x10f4bfc: stur            x1, [fp, #-8]
    // 0x10f4c00: CheckStackOverflow
    //     0x10f4c00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f4c04: cmp             SP, x16
    //     0x10f4c08: b.ls            #0x10f5260
    // 0x10f4c0c: mov             x0, x3
    // 0x10f4c10: r2 = Null
    //     0x10f4c10: mov             x2, NULL
    // 0x10f4c14: r1 = Null
    //     0x10f4c14: mov             x1, NULL
    // 0x10f4c18: r4 = 60
    //     0x10f4c18: mov             x4, #0x3c
    // 0x10f4c1c: branchIfSmi(r0, 0x10f4c28)
    //     0x10f4c1c: tbz             w0, #0, #0x10f4c28
    // 0x10f4c20: r4 = LoadClassIdInstr(r0)
    //     0x10f4c20: ldur            x4, [x0, #-1]
    //     0x10f4c24: ubfx            x4, x4, #0xc, #0x14
    // 0x10f4c28: sub             x4, x4, #0x5a
    // 0x10f4c2c: cmp             x4, #2
    // 0x10f4c30: b.ls            #0x10f4c44
    // 0x10f4c34: r8 = List<Object?>
    //     0x10f4c34: ldr             x8, [PP, #0x3800]  ; [pp+0x3800] Type: List<Object?>
    // 0x10f4c38: r3 = Null
    //     0x10f4c38: add             x3, PP, #0xc, lsl #12  ; [pp+0xcd30] Null
    //     0x10f4c3c: ldr             x3, [x3, #0xd30]
    // 0x10f4c40: r0 = List<Object?>()
    //     0x10f4c40: bl              #0x7fc684  ; IsType_List<Object?>_Stub
    // 0x10f4c44: ldur            x1, [fp, #-8]
    // 0x10f4c48: r0 = LoadClassIdInstr(r1)
    //     0x10f4c48: ldur            x0, [x1, #-1]
    //     0x10f4c4c: ubfx            x0, x0, #0xc, #0x14
    // 0x10f4c50: stp             xzr, x1, [SP]
    // 0x10f4c54: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x10f4c54: sub             lr, x0, #0xdfd
    //     0x10f4c58: ldr             lr, [x21, lr, lsl #3]
    //     0x10f4c5c: blr             lr
    // 0x10f4c60: mov             x3, x0
    // 0x10f4c64: stur            x3, [fp, #-0x10]
    // 0x10f4c68: cmp             w3, NULL
    // 0x10f4c6c: b.eq            #0x10f5268
    // 0x10f4c70: mov             x0, x3
    // 0x10f4c74: r2 = Null
    //     0x10f4c74: mov             x2, NULL
    // 0x10f4c78: r1 = Null
    //     0x10f4c78: mov             x1, NULL
    // 0x10f4c7c: r4 = 60
    //     0x10f4c7c: mov             x4, #0x3c
    // 0x10f4c80: branchIfSmi(r0, 0x10f4c8c)
    //     0x10f4c80: tbz             w0, #0, #0x10f4c8c
    // 0x10f4c84: r4 = LoadClassIdInstr(r0)
    //     0x10f4c84: ldur            x4, [x0, #-1]
    //     0x10f4c88: ubfx            x4, x4, #0xc, #0x14
    // 0x10f4c8c: sub             x4, x4, #0x5e
    // 0x10f4c90: cmp             x4, #1
    // 0x10f4c94: b.ls            #0x10f4ca8
    // 0x10f4c98: r8 = String
    //     0x10f4c98: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x10f4c9c: r3 = Null
    //     0x10f4c9c: add             x3, PP, #0xc, lsl #12  ; [pp+0xcd40] Null
    //     0x10f4ca0: ldr             x3, [x3, #0xd40]
    // 0x10f4ca4: r0 = String()
    //     0x10f4ca4: bl              #0x13ee320  ; IsType_String_Stub
    // 0x10f4ca8: ldur            x1, [fp, #-8]
    // 0x10f4cac: r0 = LoadClassIdInstr(r1)
    //     0x10f4cac: ldur            x0, [x1, #-1]
    //     0x10f4cb0: ubfx            x0, x0, #0xc, #0x14
    // 0x10f4cb4: r16 = 2
    //     0x10f4cb4: mov             x16, #2
    // 0x10f4cb8: stp             x16, x1, [SP]
    // 0x10f4cbc: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x10f4cbc: sub             lr, x0, #0xdfd
    //     0x10f4cc0: ldr             lr, [x21, lr, lsl #3]
    //     0x10f4cc4: blr             lr
    // 0x10f4cc8: mov             x3, x0
    // 0x10f4ccc: stur            x3, [fp, #-0x18]
    // 0x10f4cd0: cmp             w3, NULL
    // 0x10f4cd4: b.eq            #0x10f526c
    // 0x10f4cd8: mov             x0, x3
    // 0x10f4cdc: r2 = Null
    //     0x10f4cdc: mov             x2, NULL
    // 0x10f4ce0: r1 = Null
    //     0x10f4ce0: mov             x1, NULL
    // 0x10f4ce4: r4 = 60
    //     0x10f4ce4: mov             x4, #0x3c
    // 0x10f4ce8: branchIfSmi(r0, 0x10f4cf4)
    //     0x10f4ce8: tbz             w0, #0, #0x10f4cf4
    // 0x10f4cec: r4 = LoadClassIdInstr(r0)
    //     0x10f4cec: ldur            x4, [x0, #-1]
    //     0x10f4cf0: ubfx            x4, x4, #0xc, #0x14
    // 0x10f4cf4: sub             x4, x4, #0x5e
    // 0x10f4cf8: cmp             x4, #1
    // 0x10f4cfc: b.ls            #0x10f4d10
    // 0x10f4d00: r8 = String
    //     0x10f4d00: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x10f4d04: r3 = Null
    //     0x10f4d04: add             x3, PP, #0xc, lsl #12  ; [pp+0xcd50] Null
    //     0x10f4d08: ldr             x3, [x3, #0xd50]
    // 0x10f4d0c: r0 = String()
    //     0x10f4d0c: bl              #0x13ee320  ; IsType_String_Stub
    // 0x10f4d10: ldur            x1, [fp, #-8]
    // 0x10f4d14: r0 = LoadClassIdInstr(r1)
    //     0x10f4d14: ldur            x0, [x1, #-1]
    //     0x10f4d18: ubfx            x0, x0, #0xc, #0x14
    // 0x10f4d1c: r16 = 4
    //     0x10f4d1c: mov             x16, #4
    // 0x10f4d20: stp             x16, x1, [SP]
    // 0x10f4d24: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x10f4d24: sub             lr, x0, #0xdfd
    //     0x10f4d28: ldr             lr, [x21, lr, lsl #3]
    //     0x10f4d2c: blr             lr
    // 0x10f4d30: mov             x3, x0
    // 0x10f4d34: stur            x3, [fp, #-0x20]
    // 0x10f4d38: cmp             w3, NULL
    // 0x10f4d3c: b.eq            #0x10f5270
    // 0x10f4d40: mov             x0, x3
    // 0x10f4d44: r2 = Null
    //     0x10f4d44: mov             x2, NULL
    // 0x10f4d48: r1 = Null
    //     0x10f4d48: mov             x1, NULL
    // 0x10f4d4c: r4 = 60
    //     0x10f4d4c: mov             x4, #0x3c
    // 0x10f4d50: branchIfSmi(r0, 0x10f4d5c)
    //     0x10f4d50: tbz             w0, #0, #0x10f4d5c
    // 0x10f4d54: r4 = LoadClassIdInstr(r0)
    //     0x10f4d54: ldur            x4, [x0, #-1]
    //     0x10f4d58: ubfx            x4, x4, #0xc, #0x14
    // 0x10f4d5c: sub             x4, x4, #0x5e
    // 0x10f4d60: cmp             x4, #1
    // 0x10f4d64: b.ls            #0x10f4d78
    // 0x10f4d68: r8 = String
    //     0x10f4d68: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x10f4d6c: r3 = Null
    //     0x10f4d6c: add             x3, PP, #0xc, lsl #12  ; [pp+0xcd60] Null
    //     0x10f4d70: ldr             x3, [x3, #0xd60]
    // 0x10f4d74: r0 = String()
    //     0x10f4d74: bl              #0x13ee320  ; IsType_String_Stub
    // 0x10f4d78: ldur            x1, [fp, #-8]
    // 0x10f4d7c: r0 = LoadClassIdInstr(r1)
    //     0x10f4d7c: ldur            x0, [x1, #-1]
    //     0x10f4d80: ubfx            x0, x0, #0xc, #0x14
    // 0x10f4d84: r16 = 6
    //     0x10f4d84: mov             x16, #6
    // 0x10f4d88: stp             x16, x1, [SP]
    // 0x10f4d8c: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x10f4d8c: sub             lr, x0, #0xdfd
    //     0x10f4d90: ldr             lr, [x21, lr, lsl #3]
    //     0x10f4d94: blr             lr
    // 0x10f4d98: mov             x3, x0
    // 0x10f4d9c: stur            x3, [fp, #-0x28]
    // 0x10f4da0: cmp             w3, NULL
    // 0x10f4da4: b.eq            #0x10f5274
    // 0x10f4da8: mov             x0, x3
    // 0x10f4dac: r2 = Null
    //     0x10f4dac: mov             x2, NULL
    // 0x10f4db0: r1 = Null
    //     0x10f4db0: mov             x1, NULL
    // 0x10f4db4: r4 = 60
    //     0x10f4db4: mov             x4, #0x3c
    // 0x10f4db8: branchIfSmi(r0, 0x10f4dc4)
    //     0x10f4db8: tbz             w0, #0, #0x10f4dc4
    // 0x10f4dbc: r4 = LoadClassIdInstr(r0)
    //     0x10f4dbc: ldur            x4, [x0, #-1]
    //     0x10f4dc0: ubfx            x4, x4, #0xc, #0x14
    // 0x10f4dc4: sub             x4, x4, #0x5e
    // 0x10f4dc8: cmp             x4, #1
    // 0x10f4dcc: b.ls            #0x10f4de0
    // 0x10f4dd0: r8 = String
    //     0x10f4dd0: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x10f4dd4: r3 = Null
    //     0x10f4dd4: add             x3, PP, #0xc, lsl #12  ; [pp+0xcd70] Null
    //     0x10f4dd8: ldr             x3, [x3, #0xd70]
    // 0x10f4ddc: r0 = String()
    //     0x10f4ddc: bl              #0x13ee320  ; IsType_String_Stub
    // 0x10f4de0: ldur            x1, [fp, #-8]
    // 0x10f4de4: r0 = LoadClassIdInstr(r1)
    //     0x10f4de4: ldur            x0, [x1, #-1]
    //     0x10f4de8: ubfx            x0, x0, #0xc, #0x14
    // 0x10f4dec: r16 = 8
    //     0x10f4dec: mov             x16, #8
    // 0x10f4df0: stp             x16, x1, [SP]
    // 0x10f4df4: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x10f4df4: sub             lr, x0, #0xdfd
    //     0x10f4df8: ldr             lr, [x21, lr, lsl #3]
    //     0x10f4dfc: blr             lr
    // 0x10f4e00: mov             x3, x0
    // 0x10f4e04: r2 = Null
    //     0x10f4e04: mov             x2, NULL
    // 0x10f4e08: r1 = Null
    //     0x10f4e08: mov             x1, NULL
    // 0x10f4e0c: stur            x3, [fp, #-0x30]
    // 0x10f4e10: r4 = 60
    //     0x10f4e10: mov             x4, #0x3c
    // 0x10f4e14: branchIfSmi(r0, 0x10f4e20)
    //     0x10f4e14: tbz             w0, #0, #0x10f4e20
    // 0x10f4e18: r4 = LoadClassIdInstr(r0)
    //     0x10f4e18: ldur            x4, [x0, #-1]
    //     0x10f4e1c: ubfx            x4, x4, #0xc, #0x14
    // 0x10f4e20: sub             x4, x4, #0x5e
    // 0x10f4e24: cmp             x4, #1
    // 0x10f4e28: b.ls            #0x10f4e3c
    // 0x10f4e2c: r8 = String?
    //     0x10f4e2c: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x10f4e30: r3 = Null
    //     0x10f4e30: add             x3, PP, #0xc, lsl #12  ; [pp+0xcd80] Null
    //     0x10f4e34: ldr             x3, [x3, #0xd80]
    // 0x10f4e38: r0 = String?()
    //     0x10f4e38: bl              #0x7db310  ; IsType_String?_Stub
    // 0x10f4e3c: ldur            x1, [fp, #-8]
    // 0x10f4e40: r0 = LoadClassIdInstr(r1)
    //     0x10f4e40: ldur            x0, [x1, #-1]
    //     0x10f4e44: ubfx            x0, x0, #0xc, #0x14
    // 0x10f4e48: r16 = 10
    //     0x10f4e48: mov             x16, #0xa
    // 0x10f4e4c: stp             x16, x1, [SP]
    // 0x10f4e50: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x10f4e50: sub             lr, x0, #0xdfd
    //     0x10f4e54: ldr             lr, [x21, lr, lsl #3]
    //     0x10f4e58: blr             lr
    // 0x10f4e5c: mov             x3, x0
    // 0x10f4e60: r2 = Null
    //     0x10f4e60: mov             x2, NULL
    // 0x10f4e64: r1 = Null
    //     0x10f4e64: mov             x1, NULL
    // 0x10f4e68: stur            x3, [fp, #-0x38]
    // 0x10f4e6c: r4 = 60
    //     0x10f4e6c: mov             x4, #0x3c
    // 0x10f4e70: branchIfSmi(r0, 0x10f4e7c)
    //     0x10f4e70: tbz             w0, #0, #0x10f4e7c
    // 0x10f4e74: r4 = LoadClassIdInstr(r0)
    //     0x10f4e74: ldur            x4, [x0, #-1]
    //     0x10f4e78: ubfx            x4, x4, #0xc, #0x14
    // 0x10f4e7c: sub             x4, x4, #0x5e
    // 0x10f4e80: cmp             x4, #1
    // 0x10f4e84: b.ls            #0x10f4e98
    // 0x10f4e88: r8 = String?
    //     0x10f4e88: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x10f4e8c: r3 = Null
    //     0x10f4e8c: add             x3, PP, #0xc, lsl #12  ; [pp+0xcd90] Null
    //     0x10f4e90: ldr             x3, [x3, #0xd90]
    // 0x10f4e94: r0 = String?()
    //     0x10f4e94: bl              #0x7db310  ; IsType_String?_Stub
    // 0x10f4e98: ldur            x1, [fp, #-8]
    // 0x10f4e9c: r0 = LoadClassIdInstr(r1)
    //     0x10f4e9c: ldur            x0, [x1, #-1]
    //     0x10f4ea0: ubfx            x0, x0, #0xc, #0x14
    // 0x10f4ea4: r16 = 12
    //     0x10f4ea4: mov             x16, #0xc
    // 0x10f4ea8: stp             x16, x1, [SP]
    // 0x10f4eac: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x10f4eac: sub             lr, x0, #0xdfd
    //     0x10f4eb0: ldr             lr, [x21, lr, lsl #3]
    //     0x10f4eb4: blr             lr
    // 0x10f4eb8: mov             x3, x0
    // 0x10f4ebc: r2 = Null
    //     0x10f4ebc: mov             x2, NULL
    // 0x10f4ec0: r1 = Null
    //     0x10f4ec0: mov             x1, NULL
    // 0x10f4ec4: stur            x3, [fp, #-0x40]
    // 0x10f4ec8: r4 = 60
    //     0x10f4ec8: mov             x4, #0x3c
    // 0x10f4ecc: branchIfSmi(r0, 0x10f4ed8)
    //     0x10f4ecc: tbz             w0, #0, #0x10f4ed8
    // 0x10f4ed0: r4 = LoadClassIdInstr(r0)
    //     0x10f4ed0: ldur            x4, [x0, #-1]
    //     0x10f4ed4: ubfx            x4, x4, #0xc, #0x14
    // 0x10f4ed8: sub             x4, x4, #0x5e
    // 0x10f4edc: cmp             x4, #1
    // 0x10f4ee0: b.ls            #0x10f4ef4
    // 0x10f4ee4: r8 = String?
    //     0x10f4ee4: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x10f4ee8: r3 = Null
    //     0x10f4ee8: add             x3, PP, #0xc, lsl #12  ; [pp+0xcda0] Null
    //     0x10f4eec: ldr             x3, [x3, #0xda0]
    // 0x10f4ef0: r0 = String?()
    //     0x10f4ef0: bl              #0x7db310  ; IsType_String?_Stub
    // 0x10f4ef4: ldur            x1, [fp, #-8]
    // 0x10f4ef8: r0 = LoadClassIdInstr(r1)
    //     0x10f4ef8: ldur            x0, [x1, #-1]
    //     0x10f4efc: ubfx            x0, x0, #0xc, #0x14
    // 0x10f4f00: r16 = 14
    //     0x10f4f00: mov             x16, #0xe
    // 0x10f4f04: stp             x16, x1, [SP]
    // 0x10f4f08: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x10f4f08: sub             lr, x0, #0xdfd
    //     0x10f4f0c: ldr             lr, [x21, lr, lsl #3]
    //     0x10f4f10: blr             lr
    // 0x10f4f14: mov             x3, x0
    // 0x10f4f18: r2 = Null
    //     0x10f4f18: mov             x2, NULL
    // 0x10f4f1c: r1 = Null
    //     0x10f4f1c: mov             x1, NULL
    // 0x10f4f20: stur            x3, [fp, #-0x48]
    // 0x10f4f24: r4 = 60
    //     0x10f4f24: mov             x4, #0x3c
    // 0x10f4f28: branchIfSmi(r0, 0x10f4f34)
    //     0x10f4f28: tbz             w0, #0, #0x10f4f34
    // 0x10f4f2c: r4 = LoadClassIdInstr(r0)
    //     0x10f4f2c: ldur            x4, [x0, #-1]
    //     0x10f4f30: ubfx            x4, x4, #0xc, #0x14
    // 0x10f4f34: sub             x4, x4, #0x5e
    // 0x10f4f38: cmp             x4, #1
    // 0x10f4f3c: b.ls            #0x10f4f50
    // 0x10f4f40: r8 = String?
    //     0x10f4f40: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x10f4f44: r3 = Null
    //     0x10f4f44: add             x3, PP, #0xc, lsl #12  ; [pp+0xcdb0] Null
    //     0x10f4f48: ldr             x3, [x3, #0xdb0]
    // 0x10f4f4c: r0 = String?()
    //     0x10f4f4c: bl              #0x7db310  ; IsType_String?_Stub
    // 0x10f4f50: ldur            x1, [fp, #-8]
    // 0x10f4f54: r0 = LoadClassIdInstr(r1)
    //     0x10f4f54: ldur            x0, [x1, #-1]
    //     0x10f4f58: ubfx            x0, x0, #0xc, #0x14
    // 0x10f4f5c: r16 = 16
    //     0x10f4f5c: mov             x16, #0x10
    // 0x10f4f60: stp             x16, x1, [SP]
    // 0x10f4f64: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x10f4f64: sub             lr, x0, #0xdfd
    //     0x10f4f68: ldr             lr, [x21, lr, lsl #3]
    //     0x10f4f6c: blr             lr
    // 0x10f4f70: mov             x3, x0
    // 0x10f4f74: r2 = Null
    //     0x10f4f74: mov             x2, NULL
    // 0x10f4f78: r1 = Null
    //     0x10f4f78: mov             x1, NULL
    // 0x10f4f7c: stur            x3, [fp, #-0x50]
    // 0x10f4f80: r4 = 60
    //     0x10f4f80: mov             x4, #0x3c
    // 0x10f4f84: branchIfSmi(r0, 0x10f4f90)
    //     0x10f4f84: tbz             w0, #0, #0x10f4f90
    // 0x10f4f88: r4 = LoadClassIdInstr(r0)
    //     0x10f4f88: ldur            x4, [x0, #-1]
    //     0x10f4f8c: ubfx            x4, x4, #0xc, #0x14
    // 0x10f4f90: sub             x4, x4, #0x5e
    // 0x10f4f94: cmp             x4, #1
    // 0x10f4f98: b.ls            #0x10f4fac
    // 0x10f4f9c: r8 = String?
    //     0x10f4f9c: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x10f4fa0: r3 = Null
    //     0x10f4fa0: add             x3, PP, #0xc, lsl #12  ; [pp+0xcdc0] Null
    //     0x10f4fa4: ldr             x3, [x3, #0xdc0]
    // 0x10f4fa8: r0 = String?()
    //     0x10f4fa8: bl              #0x7db310  ; IsType_String?_Stub
    // 0x10f4fac: ldur            x1, [fp, #-8]
    // 0x10f4fb0: r0 = LoadClassIdInstr(r1)
    //     0x10f4fb0: ldur            x0, [x1, #-1]
    //     0x10f4fb4: ubfx            x0, x0, #0xc, #0x14
    // 0x10f4fb8: r16 = 18
    //     0x10f4fb8: mov             x16, #0x12
    // 0x10f4fbc: stp             x16, x1, [SP]
    // 0x10f4fc0: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x10f4fc0: sub             lr, x0, #0xdfd
    //     0x10f4fc4: ldr             lr, [x21, lr, lsl #3]
    //     0x10f4fc8: blr             lr
    // 0x10f4fcc: mov             x3, x0
    // 0x10f4fd0: r2 = Null
    //     0x10f4fd0: mov             x2, NULL
    // 0x10f4fd4: r1 = Null
    //     0x10f4fd4: mov             x1, NULL
    // 0x10f4fd8: stur            x3, [fp, #-0x58]
    // 0x10f4fdc: r4 = 60
    //     0x10f4fdc: mov             x4, #0x3c
    // 0x10f4fe0: branchIfSmi(r0, 0x10f4fec)
    //     0x10f4fe0: tbz             w0, #0, #0x10f4fec
    // 0x10f4fe4: r4 = LoadClassIdInstr(r0)
    //     0x10f4fe4: ldur            x4, [x0, #-1]
    //     0x10f4fe8: ubfx            x4, x4, #0xc, #0x14
    // 0x10f4fec: sub             x4, x4, #0x5e
    // 0x10f4ff0: cmp             x4, #1
    // 0x10f4ff4: b.ls            #0x10f5008
    // 0x10f4ff8: r8 = String?
    //     0x10f4ff8: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x10f4ffc: r3 = Null
    //     0x10f4ffc: add             x3, PP, #0xc, lsl #12  ; [pp+0xcdd0] Null
    //     0x10f5000: ldr             x3, [x3, #0xdd0]
    // 0x10f5004: r0 = String?()
    //     0x10f5004: bl              #0x7db310  ; IsType_String?_Stub
    // 0x10f5008: ldur            x1, [fp, #-8]
    // 0x10f500c: r0 = LoadClassIdInstr(r1)
    //     0x10f500c: ldur            x0, [x1, #-1]
    //     0x10f5010: ubfx            x0, x0, #0xc, #0x14
    // 0x10f5014: r16 = 20
    //     0x10f5014: mov             x16, #0x14
    // 0x10f5018: stp             x16, x1, [SP]
    // 0x10f501c: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x10f501c: sub             lr, x0, #0xdfd
    //     0x10f5020: ldr             lr, [x21, lr, lsl #3]
    //     0x10f5024: blr             lr
    // 0x10f5028: mov             x3, x0
    // 0x10f502c: r2 = Null
    //     0x10f502c: mov             x2, NULL
    // 0x10f5030: r1 = Null
    //     0x10f5030: mov             x1, NULL
    // 0x10f5034: stur            x3, [fp, #-0x60]
    // 0x10f5038: r4 = 60
    //     0x10f5038: mov             x4, #0x3c
    // 0x10f503c: branchIfSmi(r0, 0x10f5048)
    //     0x10f503c: tbz             w0, #0, #0x10f5048
    // 0x10f5040: r4 = LoadClassIdInstr(r0)
    //     0x10f5040: ldur            x4, [x0, #-1]
    //     0x10f5044: ubfx            x4, x4, #0xc, #0x14
    // 0x10f5048: sub             x4, x4, #0x5e
    // 0x10f504c: cmp             x4, #1
    // 0x10f5050: b.ls            #0x10f5064
    // 0x10f5054: r8 = String?
    //     0x10f5054: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x10f5058: r3 = Null
    //     0x10f5058: add             x3, PP, #0xc, lsl #12  ; [pp+0xcde0] Null
    //     0x10f505c: ldr             x3, [x3, #0xde0]
    // 0x10f5060: r0 = String?()
    //     0x10f5060: bl              #0x7db310  ; IsType_String?_Stub
    // 0x10f5064: ldur            x1, [fp, #-8]
    // 0x10f5068: r0 = LoadClassIdInstr(r1)
    //     0x10f5068: ldur            x0, [x1, #-1]
    //     0x10f506c: ubfx            x0, x0, #0xc, #0x14
    // 0x10f5070: r16 = 22
    //     0x10f5070: mov             x16, #0x16
    // 0x10f5074: stp             x16, x1, [SP]
    // 0x10f5078: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x10f5078: sub             lr, x0, #0xdfd
    //     0x10f507c: ldr             lr, [x21, lr, lsl #3]
    //     0x10f5080: blr             lr
    // 0x10f5084: mov             x3, x0
    // 0x10f5088: r2 = Null
    //     0x10f5088: mov             x2, NULL
    // 0x10f508c: r1 = Null
    //     0x10f508c: mov             x1, NULL
    // 0x10f5090: stur            x3, [fp, #-0x68]
    // 0x10f5094: r4 = 60
    //     0x10f5094: mov             x4, #0x3c
    // 0x10f5098: branchIfSmi(r0, 0x10f50a4)
    //     0x10f5098: tbz             w0, #0, #0x10f50a4
    // 0x10f509c: r4 = LoadClassIdInstr(r0)
    //     0x10f509c: ldur            x4, [x0, #-1]
    //     0x10f50a0: ubfx            x4, x4, #0xc, #0x14
    // 0x10f50a4: sub             x4, x4, #0x5e
    // 0x10f50a8: cmp             x4, #1
    // 0x10f50ac: b.ls            #0x10f50c0
    // 0x10f50b0: r8 = String?
    //     0x10f50b0: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x10f50b4: r3 = Null
    //     0x10f50b4: add             x3, PP, #0xc, lsl #12  ; [pp+0xcdf0] Null
    //     0x10f50b8: ldr             x3, [x3, #0xdf0]
    // 0x10f50bc: r0 = String?()
    //     0x10f50bc: bl              #0x7db310  ; IsType_String?_Stub
    // 0x10f50c0: ldur            x1, [fp, #-8]
    // 0x10f50c4: r0 = LoadClassIdInstr(r1)
    //     0x10f50c4: ldur            x0, [x1, #-1]
    //     0x10f50c8: ubfx            x0, x0, #0xc, #0x14
    // 0x10f50cc: r16 = 24
    //     0x10f50cc: mov             x16, #0x18
    // 0x10f50d0: stp             x16, x1, [SP]
    // 0x10f50d4: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x10f50d4: sub             lr, x0, #0xdfd
    //     0x10f50d8: ldr             lr, [x21, lr, lsl #3]
    //     0x10f50dc: blr             lr
    // 0x10f50e0: mov             x3, x0
    // 0x10f50e4: r2 = Null
    //     0x10f50e4: mov             x2, NULL
    // 0x10f50e8: r1 = Null
    //     0x10f50e8: mov             x1, NULL
    // 0x10f50ec: stur            x3, [fp, #-0x70]
    // 0x10f50f0: r4 = 60
    //     0x10f50f0: mov             x4, #0x3c
    // 0x10f50f4: branchIfSmi(r0, 0x10f5100)
    //     0x10f50f4: tbz             w0, #0, #0x10f5100
    // 0x10f50f8: r4 = LoadClassIdInstr(r0)
    //     0x10f50f8: ldur            x4, [x0, #-1]
    //     0x10f50fc: ubfx            x4, x4, #0xc, #0x14
    // 0x10f5100: sub             x4, x4, #0x5e
    // 0x10f5104: cmp             x4, #1
    // 0x10f5108: b.ls            #0x10f511c
    // 0x10f510c: r8 = String?
    //     0x10f510c: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x10f5110: r3 = Null
    //     0x10f5110: add             x3, PP, #0xc, lsl #12  ; [pp+0xce00] Null
    //     0x10f5114: ldr             x3, [x3, #0xe00]
    // 0x10f5118: r0 = String?()
    //     0x10f5118: bl              #0x7db310  ; IsType_String?_Stub
    // 0x10f511c: ldur            x1, [fp, #-8]
    // 0x10f5120: r0 = LoadClassIdInstr(r1)
    //     0x10f5120: ldur            x0, [x1, #-1]
    //     0x10f5124: ubfx            x0, x0, #0xc, #0x14
    // 0x10f5128: r16 = 26
    //     0x10f5128: mov             x16, #0x1a
    // 0x10f512c: stp             x16, x1, [SP]
    // 0x10f5130: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x10f5130: sub             lr, x0, #0xdfd
    //     0x10f5134: ldr             lr, [x21, lr, lsl #3]
    //     0x10f5138: blr             lr
    // 0x10f513c: mov             x3, x0
    // 0x10f5140: r2 = Null
    //     0x10f5140: mov             x2, NULL
    // 0x10f5144: r1 = Null
    //     0x10f5144: mov             x1, NULL
    // 0x10f5148: stur            x3, [fp, #-0x78]
    // 0x10f514c: r4 = 60
    //     0x10f514c: mov             x4, #0x3c
    // 0x10f5150: branchIfSmi(r0, 0x10f515c)
    //     0x10f5150: tbz             w0, #0, #0x10f515c
    // 0x10f5154: r4 = LoadClassIdInstr(r0)
    //     0x10f5154: ldur            x4, [x0, #-1]
    //     0x10f5158: ubfx            x4, x4, #0xc, #0x14
    // 0x10f515c: sub             x4, x4, #0x5e
    // 0x10f5160: cmp             x4, #1
    // 0x10f5164: b.ls            #0x10f5178
    // 0x10f5168: r8 = String?
    //     0x10f5168: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x10f516c: r3 = Null
    //     0x10f516c: add             x3, PP, #0xc, lsl #12  ; [pp+0xce10] Null
    //     0x10f5170: ldr             x3, [x3, #0xe10]
    // 0x10f5174: r0 = String?()
    //     0x10f5174: bl              #0x7db310  ; IsType_String?_Stub
    // 0x10f5178: ldur            x0, [fp, #-8]
    // 0x10f517c: r1 = LoadClassIdInstr(r0)
    //     0x10f517c: ldur            x1, [x0, #-1]
    //     0x10f5180: ubfx            x1, x1, #0xc, #0x14
    // 0x10f5184: r16 = 28
    //     0x10f5184: mov             x16, #0x1c
    // 0x10f5188: stp             x16, x0, [SP]
    // 0x10f518c: mov             x0, x1
    // 0x10f5190: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x10f5190: sub             lr, x0, #0xdfd
    //     0x10f5194: ldr             lr, [x21, lr, lsl #3]
    //     0x10f5198: blr             lr
    // 0x10f519c: mov             x3, x0
    // 0x10f51a0: r2 = Null
    //     0x10f51a0: mov             x2, NULL
    // 0x10f51a4: r1 = Null
    //     0x10f51a4: mov             x1, NULL
    // 0x10f51a8: stur            x3, [fp, #-8]
    // 0x10f51ac: r4 = 60
    //     0x10f51ac: mov             x4, #0x3c
    // 0x10f51b0: branchIfSmi(r0, 0x10f51bc)
    //     0x10f51b0: tbz             w0, #0, #0x10f51bc
    // 0x10f51b4: r4 = LoadClassIdInstr(r0)
    //     0x10f51b4: ldur            x4, [x0, #-1]
    //     0x10f51b8: ubfx            x4, x4, #0xc, #0x14
    // 0x10f51bc: sub             x4, x4, #0x5e
    // 0x10f51c0: cmp             x4, #1
    // 0x10f51c4: b.ls            #0x10f51d8
    // 0x10f51c8: r8 = String?
    //     0x10f51c8: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x10f51cc: r3 = Null
    //     0x10f51cc: add             x3, PP, #0xc, lsl #12  ; [pp+0xce20] Null
    //     0x10f51d0: ldr             x3, [x3, #0xe20]
    // 0x10f51d4: r0 = String?()
    //     0x10f51d4: bl              #0x7db310  ; IsType_String?_Stub
    // 0x10f51d8: r0 = CoreFirebaseOptions()
    //     0x10f51d8: bl              #0x10f5278  ; AllocateCoreFirebaseOptionsStub -> CoreFirebaseOptions (size=0x44)
    // 0x10f51dc: ldur            x1, [fp, #-0x10]
    // 0x10f51e0: StoreField: r0->field_7 = r1
    //     0x10f51e0: stur            w1, [x0, #7]
    // 0x10f51e4: ldur            x1, [fp, #-0x18]
    // 0x10f51e8: StoreField: r0->field_b = r1
    //     0x10f51e8: stur            w1, [x0, #0xb]
    // 0x10f51ec: ldur            x1, [fp, #-0x20]
    // 0x10f51f0: StoreField: r0->field_f = r1
    //     0x10f51f0: stur            w1, [x0, #0xf]
    // 0x10f51f4: ldur            x1, [fp, #-0x28]
    // 0x10f51f8: StoreField: r0->field_13 = r1
    //     0x10f51f8: stur            w1, [x0, #0x13]
    // 0x10f51fc: ldur            x1, [fp, #-0x30]
    // 0x10f5200: ArrayStore: r0[0] = r1  ; List_4
    //     0x10f5200: stur            w1, [x0, #0x17]
    // 0x10f5204: ldur            x1, [fp, #-0x38]
    // 0x10f5208: StoreField: r0->field_1b = r1
    //     0x10f5208: stur            w1, [x0, #0x1b]
    // 0x10f520c: ldur            x1, [fp, #-0x40]
    // 0x10f5210: StoreField: r0->field_1f = r1
    //     0x10f5210: stur            w1, [x0, #0x1f]
    // 0x10f5214: ldur            x1, [fp, #-0x48]
    // 0x10f5218: StoreField: r0->field_23 = r1
    //     0x10f5218: stur            w1, [x0, #0x23]
    // 0x10f521c: ldur            x1, [fp, #-0x50]
    // 0x10f5220: StoreField: r0->field_27 = r1
    //     0x10f5220: stur            w1, [x0, #0x27]
    // 0x10f5224: ldur            x1, [fp, #-0x58]
    // 0x10f5228: StoreField: r0->field_2b = r1
    //     0x10f5228: stur            w1, [x0, #0x2b]
    // 0x10f522c: ldur            x1, [fp, #-0x60]
    // 0x10f5230: StoreField: r0->field_2f = r1
    //     0x10f5230: stur            w1, [x0, #0x2f]
    // 0x10f5234: ldur            x1, [fp, #-0x68]
    // 0x10f5238: StoreField: r0->field_33 = r1
    //     0x10f5238: stur            w1, [x0, #0x33]
    // 0x10f523c: ldur            x1, [fp, #-0x70]
    // 0x10f5240: StoreField: r0->field_37 = r1
    //     0x10f5240: stur            w1, [x0, #0x37]
    // 0x10f5244: ldur            x1, [fp, #-0x78]
    // 0x10f5248: StoreField: r0->field_3b = r1
    //     0x10f5248: stur            w1, [x0, #0x3b]
    // 0x10f524c: ldur            x1, [fp, #-8]
    // 0x10f5250: StoreField: r0->field_3f = r1
    //     0x10f5250: stur            w1, [x0, #0x3f]
    // 0x10f5254: LeaveFrame
    //     0x10f5254: mov             SP, fp
    //     0x10f5258: ldp             fp, lr, [SP], #0x10
    // 0x10f525c: ret
    //     0x10f525c: ret             
    // 0x10f5260: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10f5260: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10f5264: b               #0x10f4c0c
    // 0x10f5268: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10f5268: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x10f526c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10f526c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x10f5270: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10f5270: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x10f5274: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10f5274: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x1149ab8, size: 0xa0
    // 0x1149ab8: EnterFrame
    //     0x1149ab8: stp             fp, lr, [SP, #-0x10]!
    //     0x1149abc: mov             fp, SP
    // 0x1149ac0: AllocStack(0x10)
    //     0x1149ac0: sub             SP, SP, #0x10
    // 0x1149ac4: r0 = 2
    //     0x1149ac4: mov             x0, #2
    // 0x1149ac8: CheckStackOverflow
    //     0x1149ac8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1149acc: cmp             SP, x16
    //     0x1149ad0: b.ls            #0x1149b50
    // 0x1149ad4: mov             x2, x0
    // 0x1149ad8: r1 = Null
    //     0x1149ad8: mov             x1, NULL
    // 0x1149adc: r0 = AllocateArray()
    //     0x1149adc: bl              #0x13df928  ; AllocateArrayStub
    // 0x1149ae0: stur            x0, [fp, #-8]
    // 0x1149ae4: r16 = CoreFirebaseOptions
    //     0x1149ae4: add             x16, PP, #0xc, lsl #12  ; [pp+0xccf8] Type: CoreFirebaseOptions
    //     0x1149ae8: ldr             x16, [x16, #0xcf8]
    // 0x1149aec: StoreField: r0->field_f = r16
    //     0x1149aec: stur            w16, [x0, #0xf]
    // 0x1149af0: r1 = <Object?>
    //     0x1149af0: ldr             x1, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0x1149af4: r0 = AllocateGrowableArray()
    //     0x1149af4: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x1149af8: mov             x2, x0
    // 0x1149afc: ldur            x0, [fp, #-8]
    // 0x1149b00: stur            x2, [fp, #-0x10]
    // 0x1149b04: StoreField: r2->field_f = r0
    //     0x1149b04: stur            w0, [x2, #0xf]
    // 0x1149b08: r0 = 2
    //     0x1149b08: mov             x0, #2
    // 0x1149b0c: StoreField: r2->field_b = r0
    //     0x1149b0c: stur            w0, [x2, #0xb]
    // 0x1149b10: ldr             x1, [fp, #0x10]
    // 0x1149b14: r0 = _toList()
    //     0x1149b14: bl              #0x114a754  ; [package:firebase_core_platform_interface/src/pigeon/messages.pigeon.dart] CoreFirebaseOptions::_toList
    // 0x1149b18: ldur            x1, [fp, #-0x10]
    // 0x1149b1c: mov             x2, x0
    // 0x1149b20: r0 = addAll()
    //     0x1149b20: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0x1149b24: ldur            x1, [fp, #-0x10]
    // 0x1149b28: r0 = _deepHash()
    //     0x1149b28: bl              #0x1149b58  ; [package:firebase_core_platform_interface/src/pigeon/messages.pigeon.dart] ::_deepHash
    // 0x1149b2c: mov             x2, x0
    // 0x1149b30: r0 = BoxInt64Instr(r2)
    //     0x1149b30: sbfiz           x0, x2, #1, #0x1f
    //     0x1149b34: cmp             x2, x0, asr #1
    //     0x1149b38: b.eq            #0x1149b44
    //     0x1149b3c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1149b40: stur            x2, [x0, #7]
    // 0x1149b44: LeaveFrame
    //     0x1149b44: mov             SP, fp
    //     0x1149b48: ldp             fp, lr, [SP], #0x10
    // 0x1149b4c: ret
    //     0x1149b4c: ret             
    // 0x1149b50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1149b50: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1149b54: b               #0x1149ad4
  }
  _ _toList(/* No info */) {
    // ** addr: 0x114a754, size: 0x110
    // 0x114a754: EnterFrame
    //     0x114a754: stp             fp, lr, [SP, #-0x10]!
    //     0x114a758: mov             fp, SP
    // 0x114a75c: AllocStack(0x18)
    //     0x114a75c: sub             SP, SP, #0x18
    // 0x114a760: r0 = 30
    //     0x114a760: mov             x0, #0x1e
    // 0x114a764: mov             x3, x1
    // 0x114a768: stur            x1, [fp, #-0x10]
    // 0x114a76c: LoadField: r4 = r3->field_7
    //     0x114a76c: ldur            w4, [x3, #7]
    // 0x114a770: DecompressPointer r4
    //     0x114a770: add             x4, x4, HEAP, lsl #32
    // 0x114a774: mov             x2, x0
    // 0x114a778: stur            x4, [fp, #-8]
    // 0x114a77c: r1 = <Object?>
    //     0x114a77c: ldr             x1, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0x114a780: r0 = AllocateArray()
    //     0x114a780: bl              #0x13df928  ; AllocateArrayStub
    // 0x114a784: mov             x2, x0
    // 0x114a788: ldur            x0, [fp, #-8]
    // 0x114a78c: stur            x2, [fp, #-0x18]
    // 0x114a790: StoreField: r2->field_f = r0
    //     0x114a790: stur            w0, [x2, #0xf]
    // 0x114a794: ldur            x0, [fp, #-0x10]
    // 0x114a798: LoadField: r1 = r0->field_b
    //     0x114a798: ldur            w1, [x0, #0xb]
    // 0x114a79c: DecompressPointer r1
    //     0x114a79c: add             x1, x1, HEAP, lsl #32
    // 0x114a7a0: StoreField: r2->field_13 = r1
    //     0x114a7a0: stur            w1, [x2, #0x13]
    // 0x114a7a4: LoadField: r1 = r0->field_f
    //     0x114a7a4: ldur            w1, [x0, #0xf]
    // 0x114a7a8: DecompressPointer r1
    //     0x114a7a8: add             x1, x1, HEAP, lsl #32
    // 0x114a7ac: ArrayStore: r2[0] = r1  ; List_4
    //     0x114a7ac: stur            w1, [x2, #0x17]
    // 0x114a7b0: LoadField: r1 = r0->field_13
    //     0x114a7b0: ldur            w1, [x0, #0x13]
    // 0x114a7b4: DecompressPointer r1
    //     0x114a7b4: add             x1, x1, HEAP, lsl #32
    // 0x114a7b8: StoreField: r2->field_1b = r1
    //     0x114a7b8: stur            w1, [x2, #0x1b]
    // 0x114a7bc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x114a7bc: ldur            w1, [x0, #0x17]
    // 0x114a7c0: DecompressPointer r1
    //     0x114a7c0: add             x1, x1, HEAP, lsl #32
    // 0x114a7c4: StoreField: r2->field_1f = r1
    //     0x114a7c4: stur            w1, [x2, #0x1f]
    // 0x114a7c8: LoadField: r1 = r0->field_1b
    //     0x114a7c8: ldur            w1, [x0, #0x1b]
    // 0x114a7cc: DecompressPointer r1
    //     0x114a7cc: add             x1, x1, HEAP, lsl #32
    // 0x114a7d0: StoreField: r2->field_23 = r1
    //     0x114a7d0: stur            w1, [x2, #0x23]
    // 0x114a7d4: LoadField: r1 = r0->field_1f
    //     0x114a7d4: ldur            w1, [x0, #0x1f]
    // 0x114a7d8: DecompressPointer r1
    //     0x114a7d8: add             x1, x1, HEAP, lsl #32
    // 0x114a7dc: StoreField: r2->field_27 = r1
    //     0x114a7dc: stur            w1, [x2, #0x27]
    // 0x114a7e0: LoadField: r1 = r0->field_23
    //     0x114a7e0: ldur            w1, [x0, #0x23]
    // 0x114a7e4: DecompressPointer r1
    //     0x114a7e4: add             x1, x1, HEAP, lsl #32
    // 0x114a7e8: StoreField: r2->field_2b = r1
    //     0x114a7e8: stur            w1, [x2, #0x2b]
    // 0x114a7ec: LoadField: r1 = r0->field_27
    //     0x114a7ec: ldur            w1, [x0, #0x27]
    // 0x114a7f0: DecompressPointer r1
    //     0x114a7f0: add             x1, x1, HEAP, lsl #32
    // 0x114a7f4: StoreField: r2->field_2f = r1
    //     0x114a7f4: stur            w1, [x2, #0x2f]
    // 0x114a7f8: LoadField: r1 = r0->field_2b
    //     0x114a7f8: ldur            w1, [x0, #0x2b]
    // 0x114a7fc: DecompressPointer r1
    //     0x114a7fc: add             x1, x1, HEAP, lsl #32
    // 0x114a800: StoreField: r2->field_33 = r1
    //     0x114a800: stur            w1, [x2, #0x33]
    // 0x114a804: LoadField: r1 = r0->field_2f
    //     0x114a804: ldur            w1, [x0, #0x2f]
    // 0x114a808: DecompressPointer r1
    //     0x114a808: add             x1, x1, HEAP, lsl #32
    // 0x114a80c: StoreField: r2->field_37 = r1
    //     0x114a80c: stur            w1, [x2, #0x37]
    // 0x114a810: LoadField: r1 = r0->field_33
    //     0x114a810: ldur            w1, [x0, #0x33]
    // 0x114a814: DecompressPointer r1
    //     0x114a814: add             x1, x1, HEAP, lsl #32
    // 0x114a818: StoreField: r2->field_3b = r1
    //     0x114a818: stur            w1, [x2, #0x3b]
    // 0x114a81c: LoadField: r1 = r0->field_37
    //     0x114a81c: ldur            w1, [x0, #0x37]
    // 0x114a820: DecompressPointer r1
    //     0x114a820: add             x1, x1, HEAP, lsl #32
    // 0x114a824: StoreField: r2->field_3f = r1
    //     0x114a824: stur            w1, [x2, #0x3f]
    // 0x114a828: LoadField: r1 = r0->field_3b
    //     0x114a828: ldur            w1, [x0, #0x3b]
    // 0x114a82c: DecompressPointer r1
    //     0x114a82c: add             x1, x1, HEAP, lsl #32
    // 0x114a830: StoreField: r2->field_43 = r1
    //     0x114a830: stur            w1, [x2, #0x43]
    // 0x114a834: LoadField: r1 = r0->field_3f
    //     0x114a834: ldur            w1, [x0, #0x3f]
    // 0x114a838: DecompressPointer r1
    //     0x114a838: add             x1, x1, HEAP, lsl #32
    // 0x114a83c: StoreField: r2->field_47 = r1
    //     0x114a83c: stur            w1, [x2, #0x47]
    // 0x114a840: r1 = <Object?>
    //     0x114a840: ldr             x1, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0x114a844: r0 = AllocateGrowableArray()
    //     0x114a844: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x114a848: ldur            x1, [fp, #-0x18]
    // 0x114a84c: StoreField: r0->field_f = r1
    //     0x114a84c: stur            w1, [x0, #0xf]
    // 0x114a850: r1 = 30
    //     0x114a850: mov             x1, #0x1e
    // 0x114a854: StoreField: r0->field_b = r1
    //     0x114a854: stur            w1, [x0, #0xb]
    // 0x114a858: LeaveFrame
    //     0x114a858: mov             SP, fp
    //     0x114a85c: ldp             fp, lr, [SP], #0x10
    // 0x114a860: ret
    //     0x114a860: ret             
  }
  _ ==(/* No info */) {
    // ** addr: 0x1293f28, size: 0x294
    // 0x1293f28: EnterFrame
    //     0x1293f28: stp             fp, lr, [SP, #-0x10]!
    //     0x1293f2c: mov             fp, SP
    // 0x1293f30: AllocStack(0x10)
    //     0x1293f30: sub             SP, SP, #0x10
    // 0x1293f34: CheckStackOverflow
    //     0x1293f34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1293f38: cmp             SP, x16
    //     0x1293f3c: b.ls            #0x12941b4
    // 0x1293f40: ldr             x0, [fp, #0x10]
    // 0x1293f44: cmp             w0, NULL
    // 0x1293f48: b.ne            #0x1293f5c
    // 0x1293f4c: r0 = false
    //     0x1293f4c: add             x0, NULL, #0x30  ; false
    // 0x1293f50: LeaveFrame
    //     0x1293f50: mov             SP, fp
    //     0x1293f54: ldp             fp, lr, [SP], #0x10
    // 0x1293f58: ret
    //     0x1293f58: ret             
    // 0x1293f5c: r1 = 60
    //     0x1293f5c: mov             x1, #0x3c
    // 0x1293f60: branchIfSmi(r0, 0x1293f6c)
    //     0x1293f60: tbz             w0, #0, #0x1293f6c
    // 0x1293f64: r1 = LoadClassIdInstr(r0)
    //     0x1293f64: ldur            x1, [x0, #-1]
    //     0x1293f68: ubfx            x1, x1, #0xc, #0x14
    // 0x1293f6c: cmp             x1, #0xd27
    // 0x1293f70: b.ne            #0x1293f90
    // 0x1293f74: r16 = CoreFirebaseOptions
    //     0x1293f74: add             x16, PP, #0xc, lsl #12  ; [pp+0xccf8] Type: CoreFirebaseOptions
    //     0x1293f78: ldr             x16, [x16, #0xcf8]
    // 0x1293f7c: r30 = CoreFirebaseOptions
    //     0x1293f7c: add             lr, PP, #0xc, lsl #12  ; [pp+0xccf8] Type: CoreFirebaseOptions
    //     0x1293f80: ldr             lr, [lr, #0xcf8]
    // 0x1293f84: stp             lr, x16, [SP]
    // 0x1293f88: r0 = ==()
    //     0x1293f88: bl              #0x12b7fbc  ; [dart:core] _Type::==
    // 0x1293f8c: tbz             w0, #4, #0x1293fa0
    // 0x1293f90: r0 = false
    //     0x1293f90: add             x0, NULL, #0x30  ; false
    // 0x1293f94: LeaveFrame
    //     0x1293f94: mov             SP, fp
    //     0x1293f98: ldp             fp, lr, [SP], #0x10
    // 0x1293f9c: ret
    //     0x1293f9c: ret             
    // 0x1293fa0: ldr             x3, [fp, #0x18]
    // 0x1293fa4: ldr             x0, [fp, #0x10]
    // 0x1293fa8: cmp             w3, w0
    // 0x1293fac: b.ne            #0x1293fc0
    // 0x1293fb0: r0 = true
    //     0x1293fb0: add             x0, NULL, #0x20  ; true
    // 0x1293fb4: LeaveFrame
    //     0x1293fb4: mov             SP, fp
    //     0x1293fb8: ldp             fp, lr, [SP], #0x10
    // 0x1293fbc: ret
    //     0x1293fbc: ret             
    // 0x1293fc0: LoadField: r1 = r3->field_7
    //     0x1293fc0: ldur            w1, [x3, #7]
    // 0x1293fc4: DecompressPointer r1
    //     0x1293fc4: add             x1, x1, HEAP, lsl #32
    // 0x1293fc8: LoadField: r2 = r0->field_7
    //     0x1293fc8: ldur            w2, [x0, #7]
    // 0x1293fcc: DecompressPointer r2
    //     0x1293fcc: add             x2, x2, HEAP, lsl #32
    // 0x1293fd0: r0 = _deepEquals()
    //     0x1293fd0: bl              #0x12941bc  ; [package:firebase_core_platform_interface/src/pigeon/messages.pigeon.dart] ::_deepEquals
    // 0x1293fd4: tbnz            w0, #4, #0x12941a4
    // 0x1293fd8: ldr             x3, [fp, #0x18]
    // 0x1293fdc: ldr             x0, [fp, #0x10]
    // 0x1293fe0: LoadField: r1 = r3->field_b
    //     0x1293fe0: ldur            w1, [x3, #0xb]
    // 0x1293fe4: DecompressPointer r1
    //     0x1293fe4: add             x1, x1, HEAP, lsl #32
    // 0x1293fe8: LoadField: r2 = r0->field_b
    //     0x1293fe8: ldur            w2, [x0, #0xb]
    // 0x1293fec: DecompressPointer r2
    //     0x1293fec: add             x2, x2, HEAP, lsl #32
    // 0x1293ff0: r0 = _deepEquals()
    //     0x1293ff0: bl              #0x12941bc  ; [package:firebase_core_platform_interface/src/pigeon/messages.pigeon.dart] ::_deepEquals
    // 0x1293ff4: tbnz            w0, #4, #0x12941a4
    // 0x1293ff8: ldr             x3, [fp, #0x18]
    // 0x1293ffc: ldr             x0, [fp, #0x10]
    // 0x1294000: LoadField: r1 = r3->field_f
    //     0x1294000: ldur            w1, [x3, #0xf]
    // 0x1294004: DecompressPointer r1
    //     0x1294004: add             x1, x1, HEAP, lsl #32
    // 0x1294008: LoadField: r2 = r0->field_f
    //     0x1294008: ldur            w2, [x0, #0xf]
    // 0x129400c: DecompressPointer r2
    //     0x129400c: add             x2, x2, HEAP, lsl #32
    // 0x1294010: r0 = _deepEquals()
    //     0x1294010: bl              #0x12941bc  ; [package:firebase_core_platform_interface/src/pigeon/messages.pigeon.dart] ::_deepEquals
    // 0x1294014: tbnz            w0, #4, #0x12941a4
    // 0x1294018: ldr             x3, [fp, #0x18]
    // 0x129401c: ldr             x0, [fp, #0x10]
    // 0x1294020: LoadField: r1 = r3->field_13
    //     0x1294020: ldur            w1, [x3, #0x13]
    // 0x1294024: DecompressPointer r1
    //     0x1294024: add             x1, x1, HEAP, lsl #32
    // 0x1294028: LoadField: r2 = r0->field_13
    //     0x1294028: ldur            w2, [x0, #0x13]
    // 0x129402c: DecompressPointer r2
    //     0x129402c: add             x2, x2, HEAP, lsl #32
    // 0x1294030: r0 = _deepEquals()
    //     0x1294030: bl              #0x12941bc  ; [package:firebase_core_platform_interface/src/pigeon/messages.pigeon.dart] ::_deepEquals
    // 0x1294034: tbnz            w0, #4, #0x12941a4
    // 0x1294038: ldr             x3, [fp, #0x18]
    // 0x129403c: ldr             x0, [fp, #0x10]
    // 0x1294040: ArrayLoad: r1 = r3[0]  ; List_4
    //     0x1294040: ldur            w1, [x3, #0x17]
    // 0x1294044: DecompressPointer r1
    //     0x1294044: add             x1, x1, HEAP, lsl #32
    // 0x1294048: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x1294048: ldur            w2, [x0, #0x17]
    // 0x129404c: DecompressPointer r2
    //     0x129404c: add             x2, x2, HEAP, lsl #32
    // 0x1294050: r0 = _deepEquals()
    //     0x1294050: bl              #0x12941bc  ; [package:firebase_core_platform_interface/src/pigeon/messages.pigeon.dart] ::_deepEquals
    // 0x1294054: tbnz            w0, #4, #0x12941a4
    // 0x1294058: ldr             x3, [fp, #0x18]
    // 0x129405c: ldr             x0, [fp, #0x10]
    // 0x1294060: LoadField: r1 = r3->field_1b
    //     0x1294060: ldur            w1, [x3, #0x1b]
    // 0x1294064: DecompressPointer r1
    //     0x1294064: add             x1, x1, HEAP, lsl #32
    // 0x1294068: LoadField: r2 = r0->field_1b
    //     0x1294068: ldur            w2, [x0, #0x1b]
    // 0x129406c: DecompressPointer r2
    //     0x129406c: add             x2, x2, HEAP, lsl #32
    // 0x1294070: r0 = _deepEquals()
    //     0x1294070: bl              #0x12941bc  ; [package:firebase_core_platform_interface/src/pigeon/messages.pigeon.dart] ::_deepEquals
    // 0x1294074: tbnz            w0, #4, #0x12941a4
    // 0x1294078: ldr             x3, [fp, #0x18]
    // 0x129407c: ldr             x0, [fp, #0x10]
    // 0x1294080: LoadField: r1 = r3->field_1f
    //     0x1294080: ldur            w1, [x3, #0x1f]
    // 0x1294084: DecompressPointer r1
    //     0x1294084: add             x1, x1, HEAP, lsl #32
    // 0x1294088: LoadField: r2 = r0->field_1f
    //     0x1294088: ldur            w2, [x0, #0x1f]
    // 0x129408c: DecompressPointer r2
    //     0x129408c: add             x2, x2, HEAP, lsl #32
    // 0x1294090: r0 = _deepEquals()
    //     0x1294090: bl              #0x12941bc  ; [package:firebase_core_platform_interface/src/pigeon/messages.pigeon.dart] ::_deepEquals
    // 0x1294094: tbnz            w0, #4, #0x12941a4
    // 0x1294098: ldr             x3, [fp, #0x18]
    // 0x129409c: ldr             x0, [fp, #0x10]
    // 0x12940a0: LoadField: r1 = r3->field_23
    //     0x12940a0: ldur            w1, [x3, #0x23]
    // 0x12940a4: DecompressPointer r1
    //     0x12940a4: add             x1, x1, HEAP, lsl #32
    // 0x12940a8: LoadField: r2 = r0->field_23
    //     0x12940a8: ldur            w2, [x0, #0x23]
    // 0x12940ac: DecompressPointer r2
    //     0x12940ac: add             x2, x2, HEAP, lsl #32
    // 0x12940b0: r0 = _deepEquals()
    //     0x12940b0: bl              #0x12941bc  ; [package:firebase_core_platform_interface/src/pigeon/messages.pigeon.dart] ::_deepEquals
    // 0x12940b4: tbnz            w0, #4, #0x12941a4
    // 0x12940b8: ldr             x3, [fp, #0x18]
    // 0x12940bc: ldr             x0, [fp, #0x10]
    // 0x12940c0: LoadField: r1 = r3->field_27
    //     0x12940c0: ldur            w1, [x3, #0x27]
    // 0x12940c4: DecompressPointer r1
    //     0x12940c4: add             x1, x1, HEAP, lsl #32
    // 0x12940c8: LoadField: r2 = r0->field_27
    //     0x12940c8: ldur            w2, [x0, #0x27]
    // 0x12940cc: DecompressPointer r2
    //     0x12940cc: add             x2, x2, HEAP, lsl #32
    // 0x12940d0: r0 = _deepEquals()
    //     0x12940d0: bl              #0x12941bc  ; [package:firebase_core_platform_interface/src/pigeon/messages.pigeon.dart] ::_deepEquals
    // 0x12940d4: tbnz            w0, #4, #0x12941a4
    // 0x12940d8: ldr             x3, [fp, #0x18]
    // 0x12940dc: ldr             x0, [fp, #0x10]
    // 0x12940e0: LoadField: r1 = r3->field_2b
    //     0x12940e0: ldur            w1, [x3, #0x2b]
    // 0x12940e4: DecompressPointer r1
    //     0x12940e4: add             x1, x1, HEAP, lsl #32
    // 0x12940e8: LoadField: r2 = r0->field_2b
    //     0x12940e8: ldur            w2, [x0, #0x2b]
    // 0x12940ec: DecompressPointer r2
    //     0x12940ec: add             x2, x2, HEAP, lsl #32
    // 0x12940f0: r0 = _deepEquals()
    //     0x12940f0: bl              #0x12941bc  ; [package:firebase_core_platform_interface/src/pigeon/messages.pigeon.dart] ::_deepEquals
    // 0x12940f4: tbnz            w0, #4, #0x12941a4
    // 0x12940f8: ldr             x3, [fp, #0x18]
    // 0x12940fc: ldr             x0, [fp, #0x10]
    // 0x1294100: LoadField: r1 = r3->field_2f
    //     0x1294100: ldur            w1, [x3, #0x2f]
    // 0x1294104: DecompressPointer r1
    //     0x1294104: add             x1, x1, HEAP, lsl #32
    // 0x1294108: LoadField: r2 = r0->field_2f
    //     0x1294108: ldur            w2, [x0, #0x2f]
    // 0x129410c: DecompressPointer r2
    //     0x129410c: add             x2, x2, HEAP, lsl #32
    // 0x1294110: r0 = _deepEquals()
    //     0x1294110: bl              #0x12941bc  ; [package:firebase_core_platform_interface/src/pigeon/messages.pigeon.dart] ::_deepEquals
    // 0x1294114: tbnz            w0, #4, #0x12941a4
    // 0x1294118: ldr             x3, [fp, #0x18]
    // 0x129411c: ldr             x0, [fp, #0x10]
    // 0x1294120: LoadField: r1 = r3->field_33
    //     0x1294120: ldur            w1, [x3, #0x33]
    // 0x1294124: DecompressPointer r1
    //     0x1294124: add             x1, x1, HEAP, lsl #32
    // 0x1294128: LoadField: r2 = r0->field_33
    //     0x1294128: ldur            w2, [x0, #0x33]
    // 0x129412c: DecompressPointer r2
    //     0x129412c: add             x2, x2, HEAP, lsl #32
    // 0x1294130: r0 = _deepEquals()
    //     0x1294130: bl              #0x12941bc  ; [package:firebase_core_platform_interface/src/pigeon/messages.pigeon.dart] ::_deepEquals
    // 0x1294134: tbnz            w0, #4, #0x12941a4
    // 0x1294138: ldr             x3, [fp, #0x18]
    // 0x129413c: ldr             x0, [fp, #0x10]
    // 0x1294140: LoadField: r1 = r3->field_37
    //     0x1294140: ldur            w1, [x3, #0x37]
    // 0x1294144: DecompressPointer r1
    //     0x1294144: add             x1, x1, HEAP, lsl #32
    // 0x1294148: LoadField: r2 = r0->field_37
    //     0x1294148: ldur            w2, [x0, #0x37]
    // 0x129414c: DecompressPointer r2
    //     0x129414c: add             x2, x2, HEAP, lsl #32
    // 0x1294150: r0 = _deepEquals()
    //     0x1294150: bl              #0x12941bc  ; [package:firebase_core_platform_interface/src/pigeon/messages.pigeon.dart] ::_deepEquals
    // 0x1294154: tbnz            w0, #4, #0x12941a4
    // 0x1294158: ldr             x3, [fp, #0x18]
    // 0x129415c: ldr             x0, [fp, #0x10]
    // 0x1294160: LoadField: r1 = r3->field_3b
    //     0x1294160: ldur            w1, [x3, #0x3b]
    // 0x1294164: DecompressPointer r1
    //     0x1294164: add             x1, x1, HEAP, lsl #32
    // 0x1294168: LoadField: r2 = r0->field_3b
    //     0x1294168: ldur            w2, [x0, #0x3b]
    // 0x129416c: DecompressPointer r2
    //     0x129416c: add             x2, x2, HEAP, lsl #32
    // 0x1294170: r0 = _deepEquals()
    //     0x1294170: bl              #0x12941bc  ; [package:firebase_core_platform_interface/src/pigeon/messages.pigeon.dart] ::_deepEquals
    // 0x1294174: tbnz            w0, #4, #0x12941a4
    // 0x1294178: ldr             x1, [fp, #0x18]
    // 0x129417c: ldr             x0, [fp, #0x10]
    // 0x1294180: LoadField: r2 = r1->field_3f
    //     0x1294180: ldur            w2, [x1, #0x3f]
    // 0x1294184: DecompressPointer r2
    //     0x1294184: add             x2, x2, HEAP, lsl #32
    // 0x1294188: LoadField: r1 = r0->field_3f
    //     0x1294188: ldur            w1, [x0, #0x3f]
    // 0x129418c: DecompressPointer r1
    //     0x129418c: add             x1, x1, HEAP, lsl #32
    // 0x1294190: mov             x16, x1
    // 0x1294194: mov             x1, x2
    // 0x1294198: mov             x2, x16
    // 0x129419c: r0 = _deepEquals()
    //     0x129419c: bl              #0x12941bc  ; [package:firebase_core_platform_interface/src/pigeon/messages.pigeon.dart] ::_deepEquals
    // 0x12941a0: b               #0x12941a8
    // 0x12941a4: r0 = false
    //     0x12941a4: add             x0, NULL, #0x30  ; false
    // 0x12941a8: LeaveFrame
    //     0x12941a8: mov             SP, fp
    //     0x12941ac: ldp             fp, lr, [SP], #0x10
    // 0x12941b0: ret
    //     0x12941b0: ret             
    // 0x12941b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12941b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12941b8: b               #0x1293f40
  }
}
