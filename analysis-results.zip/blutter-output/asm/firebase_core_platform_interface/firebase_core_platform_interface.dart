// lib: , url: package:firebase_core_platform_interface/firebase_core_platform_interface.dart

// class id: 1048745, size: 0x8
class :: {

  static _ noAppExists(/* No info */) {
    // ** addr: 0x8c1150, size: 0x3c
    // 0x8c1150: EnterFrame
    //     0x8c1150: stp             fp, lr, [SP, #-0x10]!
    //     0x8c1154: mov             fp, SP
    // 0x8c1158: r0 = FirebaseException()
    //     0x8c1158: bl              #0x8c0a9c  ; AllocateFirebaseExceptionStub -> FirebaseException (size=0x18)
    // 0x8c115c: r1 = "core"
    //     0x8c115c: add             x1, PP, #8, lsl #12  ; [pp+0x8ca0] "core"
    //     0x8c1160: ldr             x1, [x1, #0xca0]
    // 0x8c1164: StoreField: r0->field_7 = r1
    //     0x8c1164: stur            w1, [x0, #7]
    // 0x8c1168: r1 = "No Firebase App \'[DEFAULT]\' has been created - call Firebase.initializeApp()"
    //     0x8c1168: add             x1, PP, #8, lsl #12  ; [pp+0x8ca8] "No Firebase App \'[DEFAULT]\' has been created - call Firebase.initializeApp()"
    //     0x8c116c: ldr             x1, [x1, #0xca8]
    // 0x8c1170: StoreField: r0->field_b = r1
    //     0x8c1170: stur            w1, [x0, #0xb]
    // 0x8c1174: r1 = "no-app"
    //     0x8c1174: add             x1, PP, #8, lsl #12  ; [pp+0x8cb0] "no-app"
    //     0x8c1178: ldr             x1, [x1, #0xcb0]
    // 0x8c117c: StoreField: r0->field_f = r1
    //     0x8c117c: stur            w1, [x0, #0xf]
    // 0x8c1180: LeaveFrame
    //     0x8c1180: mov             SP, fp
    //     0x8c1184: ldp             fp, lr, [SP], #0x10
    // 0x8c1188: ret
    //     0x8c1188: ret             
  }
  static _ duplicateApp(/* No info */) {
    // ** addr: 0x13e9f5c, size: 0x90
    // 0x13e9f5c: EnterFrame
    //     0x13e9f5c: stp             fp, lr, [SP, #-0x10]!
    //     0x13e9f60: mov             fp, SP
    // 0x13e9f64: AllocStack(0x10)
    //     0x13e9f64: sub             SP, SP, #0x10
    // 0x13e9f68: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */)
    //     0x13e9f68: mov             x0, x1
    //     0x13e9f6c: stur            x1, [fp, #-8]
    // 0x13e9f70: CheckStackOverflow
    //     0x13e9f70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13e9f74: cmp             SP, x16
    //     0x13e9f78: b.ls            #0x13e9fe4
    // 0x13e9f7c: r1 = Null
    //     0x13e9f7c: mov             x1, NULL
    // 0x13e9f80: r2 = 6
    //     0x13e9f80: mov             x2, #6
    // 0x13e9f84: r0 = AllocateArray()
    //     0x13e9f84: bl              #0x13df928  ; AllocateArrayStub
    // 0x13e9f88: r16 = "A Firebase App named \""
    //     0x13e9f88: add             x16, PP, #8, lsl #12  ; [pp+0x8cf0] "A Firebase App named \""
    //     0x13e9f8c: ldr             x16, [x16, #0xcf0]
    // 0x13e9f90: StoreField: r0->field_f = r16
    //     0x13e9f90: stur            w16, [x0, #0xf]
    // 0x13e9f94: ldur            x1, [fp, #-8]
    // 0x13e9f98: StoreField: r0->field_13 = r1
    //     0x13e9f98: stur            w1, [x0, #0x13]
    // 0x13e9f9c: r16 = "\" already exists"
    //     0x13e9f9c: add             x16, PP, #8, lsl #12  ; [pp+0x8cf8] "\" already exists"
    //     0x13e9fa0: ldr             x16, [x16, #0xcf8]
    // 0x13e9fa4: ArrayStore: r0[0] = r16  ; List_4
    //     0x13e9fa4: stur            w16, [x0, #0x17]
    // 0x13e9fa8: str             x0, [SP]
    // 0x13e9fac: r0 = _interpolate()
    //     0x13e9fac: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x13e9fb0: stur            x0, [fp, #-8]
    // 0x13e9fb4: r0 = FirebaseException()
    //     0x13e9fb4: bl              #0x8c0a9c  ; AllocateFirebaseExceptionStub -> FirebaseException (size=0x18)
    // 0x13e9fb8: r1 = "core"
    //     0x13e9fb8: add             x1, PP, #8, lsl #12  ; [pp+0x8ca0] "core"
    //     0x13e9fbc: ldr             x1, [x1, #0xca0]
    // 0x13e9fc0: StoreField: r0->field_7 = r1
    //     0x13e9fc0: stur            w1, [x0, #7]
    // 0x13e9fc4: ldur            x1, [fp, #-8]
    // 0x13e9fc8: StoreField: r0->field_b = r1
    //     0x13e9fc8: stur            w1, [x0, #0xb]
    // 0x13e9fcc: r1 = "duplicate-app"
    //     0x13e9fcc: add             x1, PP, #8, lsl #12  ; [pp+0x8d00] "duplicate-app"
    //     0x13e9fd0: ldr             x1, [x1, #0xd00]
    // 0x13e9fd4: StoreField: r0->field_f = r1
    //     0x13e9fd4: stur            w1, [x0, #0xf]
    // 0x13e9fd8: LeaveFrame
    //     0x13e9fd8: mov             SP, fp
    //     0x13e9fdc: ldp             fp, lr, [SP], #0x10
    // 0x13e9fe0: ret
    //     0x13e9fe0: ret             
    // 0x13e9fe4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13e9fe4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13e9fe8: b               #0x13e9f7c
  }
}

// class id: 3368, size: 0x10, field offset: 0x8
abstract class FirebasePlugin extends Object {

  static late Map<dynamic, dynamic> _constantsForPluginApps; // offset: 0x10b4

  get _ pluginConstants(/* No info */) {
    // ** addr: 0x8c12e8, size: 0x14c
    // 0x8c12e8: EnterFrame
    //     0x8c12e8: stp             fp, lr, [SP, #-0x10]!
    //     0x8c12ec: mov             fp, SP
    // 0x8c12f0: AllocStack(0x28)
    //     0x8c12f0: sub             SP, SP, #0x28
    // 0x8c12f4: SetupParameters(FirebasePlugin this /* r1 => r1, fp-0x8 */)
    //     0x8c12f4: stur            x1, [fp, #-8]
    // 0x8c12f8: CheckStackOverflow
    //     0x8c12f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c12fc: cmp             SP, x16
    //     0x8c1300: b.ls            #0x8c1428
    // 0x8c1304: r0 = LoadStaticField(0x10b4)
    //     0x8c1304: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8c1308: ldr             x0, [x0, #0x2168]
    // 0x8c130c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8c1310: cmp             w0, w16
    // 0x8c1314: b.ne            #0x8c1320
    // 0x8c1318: r2 = _constantsForPluginApps
    //     0x8c1318: ldr             x2, [PP, #0x7af0]  ; [pp+0x7af0] Field <FirebasePlugin._constantsForPluginApps@1279397154>: static late (offset: 0x10b4)
    // 0x8c131c: r0 = InitLateStaticField()
    //     0x8c131c: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0x8c1320: mov             x3, x0
    // 0x8c1324: ldur            x0, [fp, #-8]
    // 0x8c1328: stur            x3, [fp, #-0x10]
    // 0x8c132c: LoadField: r2 = r0->field_7
    //     0x8c132c: ldur            w2, [x0, #7]
    // 0x8c1330: DecompressPointer r2
    //     0x8c1330: add             x2, x2, HEAP, lsl #32
    // 0x8c1334: mov             x1, x3
    // 0x8c1338: r0 = _getValueOrData()
    //     0x8c1338: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x8c133c: mov             x1, x0
    // 0x8c1340: ldur            x0, [fp, #-0x10]
    // 0x8c1344: LoadField: r2 = r0->field_f
    //     0x8c1344: ldur            w2, [x0, #0xf]
    // 0x8c1348: DecompressPointer r2
    //     0x8c1348: add             x2, x2, HEAP, lsl #32
    // 0x8c134c: cmp             w2, w1
    // 0x8c1350: b.ne            #0x8c135c
    // 0x8c1354: r3 = Null
    //     0x8c1354: mov             x3, NULL
    // 0x8c1358: b               #0x8c1360
    // 0x8c135c: mov             x3, x1
    // 0x8c1360: mov             x0, x3
    // 0x8c1364: stur            x3, [fp, #-0x10]
    // 0x8c1368: r2 = Null
    //     0x8c1368: mov             x2, NULL
    // 0x8c136c: r1 = Null
    //     0x8c136c: mov             x1, NULL
    // 0x8c1370: r8 = Map<Object?, Object?>?
    //     0x8c1370: ldr             x8, [PP, #0x18c0]  ; [pp+0x18c0] Type: Map<Object?, Object?>?
    // 0x8c1374: r3 = Null
    //     0x8c1374: ldr             x3, [PP, #0x7af8]  ; [pp+0x7af8] Null
    // 0x8c1378: r0 = Map<Object?, Object?>?()
    //     0x8c1378: bl              #0x8514d0  ; IsType_Map<Object?, Object?>?_Stub
    // 0x8c137c: ldur            x3, [fp, #-0x10]
    // 0x8c1380: cmp             w3, NULL
    // 0x8c1384: b.eq            #0x8c1410
    // 0x8c1388: ldur            x0, [fp, #-8]
    // 0x8c138c: LoadField: r4 = r0->field_b
    //     0x8c138c: ldur            w4, [x0, #0xb]
    // 0x8c1390: DecompressPointer r4
    //     0x8c1390: add             x4, x4, HEAP, lsl #32
    // 0x8c1394: stur            x4, [fp, #-0x18]
    // 0x8c1398: r0 = LoadClassIdInstr(r3)
    //     0x8c1398: ldur            x0, [x3, #-1]
    //     0x8c139c: ubfx            x0, x0, #0xc, #0x14
    // 0x8c13a0: mov             x1, x3
    // 0x8c13a4: mov             x2, x4
    // 0x8c13a8: r0 = GDT[cid_x0 + -0xd48]()
    //     0x8c13a8: sub             lr, x0, #0xd48
    //     0x8c13ac: ldr             lr, [x21, lr, lsl #3]
    //     0x8c13b0: blr             lr
    // 0x8c13b4: cmp             w0, NULL
    // 0x8c13b8: b.eq            #0x8c1410
    // 0x8c13bc: ldur            x1, [fp, #-0x10]
    // 0x8c13c0: r0 = LoadClassIdInstr(r1)
    //     0x8c13c0: ldur            x0, [x1, #-1]
    //     0x8c13c4: ubfx            x0, x0, #0xc, #0x14
    // 0x8c13c8: ldur            x2, [fp, #-0x18]
    // 0x8c13cc: r0 = GDT[cid_x0 + -0xd48]()
    //     0x8c13cc: sub             lr, x0, #0xd48
    //     0x8c13d0: ldr             lr, [x21, lr, lsl #3]
    //     0x8c13d4: blr             lr
    // 0x8c13d8: mov             x3, x0
    // 0x8c13dc: stur            x3, [fp, #-8]
    // 0x8c13e0: cmp             w3, NULL
    // 0x8c13e4: b.eq            #0x8c1430
    // 0x8c13e8: mov             x0, x3
    // 0x8c13ec: r2 = Null
    //     0x8c13ec: mov             x2, NULL
    // 0x8c13f0: r1 = Null
    //     0x8c13f0: mov             x1, NULL
    // 0x8c13f4: r8 = Map
    //     0x8c13f4: ldr             x8, [PP, #0x1c8]  ; [pp+0x1c8] Type: Map
    // 0x8c13f8: r3 = Null
    //     0x8c13f8: ldr             x3, [PP, #0x7b08]  ; [pp+0x7b08] Null
    // 0x8c13fc: r0 = Map()
    //     0x8c13fc: bl              #0x13efa40  ; IsType_Map_Stub
    // 0x8c1400: ldur            x0, [fp, #-8]
    // 0x8c1404: LeaveFrame
    //     0x8c1404: mov             SP, fp
    //     0x8c1408: ldp             fp, lr, [SP], #0x10
    // 0x8c140c: ret
    //     0x8c140c: ret             
    // 0x8c1410: ldr             x16, [THR, #0xa8]  ; THR::empty_array
    // 0x8c1414: stp             x16, NULL, [SP]
    // 0x8c1418: r0 = Map._fromLiteral()
    //     0x8c1418: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x8c141c: LeaveFrame
    //     0x8c141c: mov             SP, fp
    //     0x8c1420: ldp             fp, lr, [SP], #0x10
    // 0x8c1424: ret
    //     0x8c1424: ret             
    // 0x8c1428: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c1428: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c142c: b               #0x8c1304
    // 0x8c1430: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8c1430: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static Map<dynamic, dynamic> _constantsForPluginApps() {
    // ** addr: 0x8c1434, size: 0x38
    // 0x8c1434: EnterFrame
    //     0x8c1434: stp             fp, lr, [SP, #-0x10]!
    //     0x8c1438: mov             fp, SP
    // 0x8c143c: AllocStack(0x10)
    //     0x8c143c: sub             SP, SP, #0x10
    // 0x8c1440: CheckStackOverflow
    //     0x8c1440: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c1444: cmp             SP, x16
    //     0x8c1448: b.ls            #0x8c1464
    // 0x8c144c: ldr             x16, [THR, #0xa8]  ; THR::empty_array
    // 0x8c1450: stp             x16, NULL, [SP]
    // 0x8c1454: r0 = Map._fromLiteral()
    //     0x8c1454: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x8c1458: LeaveFrame
    //     0x8c1458: mov             SP, fp
    //     0x8c145c: ldp             fp, lr, [SP], #0x10
    // 0x8c1460: ret
    //     0x8c1460: ret             
    // 0x8c1464: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c1464: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c1468: b               #0x8c144c
  }
}

// class id: 3371, size: 0x44, field offset: 0x8
//   const constructor, 
class FirebaseOptions extends Object {

  _ toString(/* No info */) {
    // ** addr: 0x1114ed4, size: 0x38
    // 0x1114ed4: EnterFrame
    //     0x1114ed4: stp             fp, lr, [SP, #-0x10]!
    //     0x1114ed8: mov             fp, SP
    // 0x1114edc: CheckStackOverflow
    //     0x1114edc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1114ee0: cmp             SP, x16
    //     0x1114ee4: b.ls            #0x1114f04
    // 0x1114ee8: ldr             x1, [fp, #0x10]
    // 0x1114eec: r0 = asMap()
    //     0x1114eec: bl              #0x1114f0c  ; [package:firebase_core_platform_interface/firebase_core_platform_interface.dart] FirebaseOptions::asMap
    // 0x1114ef0: mov             x1, x0
    // 0x1114ef4: r0 = mapToString()
    //     0x1114ef4: bl              #0x9211cc  ; [dart:collection] MapBase::mapToString
    // 0x1114ef8: LeaveFrame
    //     0x1114ef8: mov             SP, fp
    //     0x1114efc: ldp             fp, lr, [SP], #0x10
    // 0x1114f00: ret
    //     0x1114f00: ret             
    // 0x1114f04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1114f04: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1114f08: b               #0x1114ee8
  }
  get _ asMap(/* No info */) {
    // ** addr: 0x1114f0c, size: 0x1b8
    // 0x1114f0c: EnterFrame
    //     0x1114f0c: stp             fp, lr, [SP, #-0x10]!
    //     0x1114f10: mov             fp, SP
    // 0x1114f14: AllocStack(0x18)
    //     0x1114f14: sub             SP, SP, #0x18
    // 0x1114f18: SetupParameters(FirebaseOptions this /* r1 => r0, fp-0x8 */)
    //     0x1114f18: mov             x0, x1
    //     0x1114f1c: stur            x1, [fp, #-8]
    // 0x1114f20: CheckStackOverflow
    //     0x1114f20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1114f24: cmp             SP, x16
    //     0x1114f28: b.ls            #0x11150bc
    // 0x1114f2c: r1 = Null
    //     0x1114f2c: mov             x1, NULL
    // 0x1114f30: r2 = 60
    //     0x1114f30: mov             x2, #0x3c
    // 0x1114f34: r0 = AllocateArray()
    //     0x1114f34: bl              #0x13df928  ; AllocateArrayStub
    // 0x1114f38: r16 = "apiKey"
    //     0x1114f38: add             x16, PP, #0xc, lsl #12  ; [pp+0xcfa8] "apiKey"
    //     0x1114f3c: ldr             x16, [x16, #0xfa8]
    // 0x1114f40: StoreField: r0->field_f = r16
    //     0x1114f40: stur            w16, [x0, #0xf]
    // 0x1114f44: ldur            x1, [fp, #-8]
    // 0x1114f48: LoadField: r2 = r1->field_7
    //     0x1114f48: ldur            w2, [x1, #7]
    // 0x1114f4c: DecompressPointer r2
    //     0x1114f4c: add             x2, x2, HEAP, lsl #32
    // 0x1114f50: StoreField: r0->field_13 = r2
    //     0x1114f50: stur            w2, [x0, #0x13]
    // 0x1114f54: r16 = "appId"
    //     0x1114f54: add             x16, PP, #0xc, lsl #12  ; [pp+0xcfb0] "appId"
    //     0x1114f58: ldr             x16, [x16, #0xfb0]
    // 0x1114f5c: ArrayStore: r0[0] = r16  ; List_4
    //     0x1114f5c: stur            w16, [x0, #0x17]
    // 0x1114f60: LoadField: r2 = r1->field_b
    //     0x1114f60: ldur            w2, [x1, #0xb]
    // 0x1114f64: DecompressPointer r2
    //     0x1114f64: add             x2, x2, HEAP, lsl #32
    // 0x1114f68: StoreField: r0->field_1b = r2
    //     0x1114f68: stur            w2, [x0, #0x1b]
    // 0x1114f6c: r16 = "messagingSenderId"
    //     0x1114f6c: add             x16, PP, #0xc, lsl #12  ; [pp+0xcfb8] "messagingSenderId"
    //     0x1114f70: ldr             x16, [x16, #0xfb8]
    // 0x1114f74: StoreField: r0->field_1f = r16
    //     0x1114f74: stur            w16, [x0, #0x1f]
    // 0x1114f78: LoadField: r2 = r1->field_f
    //     0x1114f78: ldur            w2, [x1, #0xf]
    // 0x1114f7c: DecompressPointer r2
    //     0x1114f7c: add             x2, x2, HEAP, lsl #32
    // 0x1114f80: StoreField: r0->field_23 = r2
    //     0x1114f80: stur            w2, [x0, #0x23]
    // 0x1114f84: r16 = "projectId"
    //     0x1114f84: add             x16, PP, #0xc, lsl #12  ; [pp+0xcfc0] "projectId"
    //     0x1114f88: ldr             x16, [x16, #0xfc0]
    // 0x1114f8c: StoreField: r0->field_27 = r16
    //     0x1114f8c: stur            w16, [x0, #0x27]
    // 0x1114f90: LoadField: r2 = r1->field_13
    //     0x1114f90: ldur            w2, [x1, #0x13]
    // 0x1114f94: DecompressPointer r2
    //     0x1114f94: add             x2, x2, HEAP, lsl #32
    // 0x1114f98: StoreField: r0->field_2b = r2
    //     0x1114f98: stur            w2, [x0, #0x2b]
    // 0x1114f9c: r16 = "authDomain"
    //     0x1114f9c: add             x16, PP, #0xc, lsl #12  ; [pp+0xcfc8] "authDomain"
    //     0x1114fa0: ldr             x16, [x16, #0xfc8]
    // 0x1114fa4: StoreField: r0->field_2f = r16
    //     0x1114fa4: stur            w16, [x0, #0x2f]
    // 0x1114fa8: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x1114fa8: ldur            w2, [x1, #0x17]
    // 0x1114fac: DecompressPointer r2
    //     0x1114fac: add             x2, x2, HEAP, lsl #32
    // 0x1114fb0: StoreField: r0->field_33 = r2
    //     0x1114fb0: stur            w2, [x0, #0x33]
    // 0x1114fb4: r16 = "databaseURL"
    //     0x1114fb4: add             x16, PP, #0xc, lsl #12  ; [pp+0xcfd0] "databaseURL"
    //     0x1114fb8: ldr             x16, [x16, #0xfd0]
    // 0x1114fbc: StoreField: r0->field_37 = r16
    //     0x1114fbc: stur            w16, [x0, #0x37]
    // 0x1114fc0: LoadField: r2 = r1->field_1b
    //     0x1114fc0: ldur            w2, [x1, #0x1b]
    // 0x1114fc4: DecompressPointer r2
    //     0x1114fc4: add             x2, x2, HEAP, lsl #32
    // 0x1114fc8: StoreField: r0->field_3b = r2
    //     0x1114fc8: stur            w2, [x0, #0x3b]
    // 0x1114fcc: r16 = "storageBucket"
    //     0x1114fcc: add             x16, PP, #0xc, lsl #12  ; [pp+0xcfd8] "storageBucket"
    //     0x1114fd0: ldr             x16, [x16, #0xfd8]
    // 0x1114fd4: StoreField: r0->field_3f = r16
    //     0x1114fd4: stur            w16, [x0, #0x3f]
    // 0x1114fd8: LoadField: r2 = r1->field_1f
    //     0x1114fd8: ldur            w2, [x1, #0x1f]
    // 0x1114fdc: DecompressPointer r2
    //     0x1114fdc: add             x2, x2, HEAP, lsl #32
    // 0x1114fe0: StoreField: r0->field_43 = r2
    //     0x1114fe0: stur            w2, [x0, #0x43]
    // 0x1114fe4: r16 = "measurementId"
    //     0x1114fe4: add             x16, PP, #0xc, lsl #12  ; [pp+0xcfe0] "measurementId"
    //     0x1114fe8: ldr             x16, [x16, #0xfe0]
    // 0x1114fec: StoreField: r0->field_47 = r16
    //     0x1114fec: stur            w16, [x0, #0x47]
    // 0x1114ff0: LoadField: r2 = r1->field_23
    //     0x1114ff0: ldur            w2, [x1, #0x23]
    // 0x1114ff4: DecompressPointer r2
    //     0x1114ff4: add             x2, x2, HEAP, lsl #32
    // 0x1114ff8: StoreField: r0->field_4b = r2
    //     0x1114ff8: stur            w2, [x0, #0x4b]
    // 0x1114ffc: r16 = "trackingId"
    //     0x1114ffc: add             x16, PP, #0xc, lsl #12  ; [pp+0xcfe8] "trackingId"
    //     0x1115000: ldr             x16, [x16, #0xfe8]
    // 0x1115004: StoreField: r0->field_4f = r16
    //     0x1115004: stur            w16, [x0, #0x4f]
    // 0x1115008: LoadField: r2 = r1->field_27
    //     0x1115008: ldur            w2, [x1, #0x27]
    // 0x111500c: DecompressPointer r2
    //     0x111500c: add             x2, x2, HEAP, lsl #32
    // 0x1115010: StoreField: r0->field_53 = r2
    //     0x1115010: stur            w2, [x0, #0x53]
    // 0x1115014: r16 = "deepLinkURLScheme"
    //     0x1115014: add             x16, PP, #0xc, lsl #12  ; [pp+0xcff0] "deepLinkURLScheme"
    //     0x1115018: ldr             x16, [x16, #0xff0]
    // 0x111501c: StoreField: r0->field_57 = r16
    //     0x111501c: stur            w16, [x0, #0x57]
    // 0x1115020: LoadField: r2 = r1->field_2b
    //     0x1115020: ldur            w2, [x1, #0x2b]
    // 0x1115024: DecompressPointer r2
    //     0x1115024: add             x2, x2, HEAP, lsl #32
    // 0x1115028: StoreField: r0->field_5b = r2
    //     0x1115028: stur            w2, [x0, #0x5b]
    // 0x111502c: r16 = "androidClientId"
    //     0x111502c: add             x16, PP, #0xc, lsl #12  ; [pp+0xcff8] "androidClientId"
    //     0x1115030: ldr             x16, [x16, #0xff8]
    // 0x1115034: StoreField: r0->field_5f = r16
    //     0x1115034: stur            w16, [x0, #0x5f]
    // 0x1115038: LoadField: r2 = r1->field_2f
    //     0x1115038: ldur            w2, [x1, #0x2f]
    // 0x111503c: DecompressPointer r2
    //     0x111503c: add             x2, x2, HEAP, lsl #32
    // 0x1115040: StoreField: r0->field_63 = r2
    //     0x1115040: stur            w2, [x0, #0x63]
    // 0x1115044: r16 = "iosClientId"
    //     0x1115044: add             x16, PP, #0xd, lsl #12  ; [pp+0xd000] "iosClientId"
    //     0x1115048: ldr             x16, [x16]
    // 0x111504c: StoreField: r0->field_67 = r16
    //     0x111504c: stur            w16, [x0, #0x67]
    // 0x1115050: LoadField: r2 = r1->field_33
    //     0x1115050: ldur            w2, [x1, #0x33]
    // 0x1115054: DecompressPointer r2
    //     0x1115054: add             x2, x2, HEAP, lsl #32
    // 0x1115058: StoreField: r0->field_6b = r2
    //     0x1115058: stur            w2, [x0, #0x6b]
    // 0x111505c: r16 = "iosBundleId"
    //     0x111505c: add             x16, PP, #0xd, lsl #12  ; [pp+0xd008] "iosBundleId"
    //     0x1115060: ldr             x16, [x16, #8]
    // 0x1115064: StoreField: r0->field_6f = r16
    //     0x1115064: stur            w16, [x0, #0x6f]
    // 0x1115068: LoadField: r2 = r1->field_37
    //     0x1115068: ldur            w2, [x1, #0x37]
    // 0x111506c: DecompressPointer r2
    //     0x111506c: add             x2, x2, HEAP, lsl #32
    // 0x1115070: StoreField: r0->field_73 = r2
    //     0x1115070: stur            w2, [x0, #0x73]
    // 0x1115074: r16 = "appGroupId"
    //     0x1115074: add             x16, PP, #0xd, lsl #12  ; [pp+0xd010] "appGroupId"
    //     0x1115078: ldr             x16, [x16, #0x10]
    // 0x111507c: StoreField: r0->field_77 = r16
    //     0x111507c: stur            w16, [x0, #0x77]
    // 0x1115080: LoadField: r2 = r1->field_3b
    //     0x1115080: ldur            w2, [x1, #0x3b]
    // 0x1115084: DecompressPointer r2
    //     0x1115084: add             x2, x2, HEAP, lsl #32
    // 0x1115088: StoreField: r0->field_7b = r2
    //     0x1115088: stur            w2, [x0, #0x7b]
    // 0x111508c: r16 = "recaptchaSiteKey"
    //     0x111508c: add             x16, PP, #0xd, lsl #12  ; [pp+0xd018] "recaptchaSiteKey"
    //     0x1115090: ldr             x16, [x16, #0x18]
    // 0x1115094: StoreField: r0->field_7f = r16
    //     0x1115094: stur            w16, [x0, #0x7f]
    // 0x1115098: LoadField: r2 = r1->field_3f
    //     0x1115098: ldur            w2, [x1, #0x3f]
    // 0x111509c: DecompressPointer r2
    //     0x111509c: add             x2, x2, HEAP, lsl #32
    // 0x11150a0: StoreField: r0->field_83 = r2
    //     0x11150a0: stur            w2, [x0, #0x83]
    // 0x11150a4: r16 = <String, String?>
    //     0x11150a4: ldr             x16, [PP, #0x7cf0]  ; [pp+0x7cf0] TypeArguments: <String, String?>
    // 0x11150a8: stp             x0, x16, [SP]
    // 0x11150ac: r0 = Map._fromLiteral()
    //     0x11150ac: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x11150b0: LeaveFrame
    //     0x11150b0: mov             SP, fp
    //     0x11150b4: ldp             fp, lr, [SP], #0x10
    // 0x11150b8: ret
    //     0x11150b8: ret             
    // 0x11150bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11150bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11150c0: b               #0x1114f2c
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x1149a60, size: 0x58
    // 0x1149a60: EnterFrame
    //     0x1149a60: stp             fp, lr, [SP, #-0x10]!
    //     0x1149a64: mov             fp, SP
    // 0x1149a68: CheckStackOverflow
    //     0x1149a68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1149a6c: cmp             SP, x16
    //     0x1149a70: b.ls            #0x1149ab0
    // 0x1149a74: ldr             x1, [fp, #0x10]
    // 0x1149a78: r0 = asMap()
    //     0x1149a78: bl              #0x1114f0c  ; [package:firebase_core_platform_interface/firebase_core_platform_interface.dart] FirebaseOptions::asMap
    // 0x1149a7c: mov             x2, x0
    // 0x1149a80: r1 = Instance_MapEquality
    //     0x1149a80: add             x1, PP, #0xd, lsl #12  ; [pp+0xd020] Obj!MapEquality@12a0011
    //     0x1149a84: ldr             x1, [x1, #0x20]
    // 0x1149a88: r0 = hash()
    //     0x1149a88: bl              #0x12e8ebc  ; [package:collection/src/equality.dart] MapEquality::hash
    // 0x1149a8c: mov             x2, x0
    // 0x1149a90: r0 = BoxInt64Instr(r2)
    //     0x1149a90: sbfiz           x0, x2, #1, #0x1f
    //     0x1149a94: cmp             x2, x0, asr #1
    //     0x1149a98: b.eq            #0x1149aa4
    //     0x1149a9c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1149aa0: stur            x2, [x0, #7]
    // 0x1149aa4: LeaveFrame
    //     0x1149aa4: mov             SP, fp
    //     0x1149aa8: ldp             fp, lr, [SP], #0x10
    // 0x1149aac: ret
    //     0x1149aac: ret             
    // 0x1149ab0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1149ab0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1149ab4: b               #0x1149a74
  }
  _ ==(/* No info */) {
    // ** addr: 0x1293e78, size: 0xb0
    // 0x1293e78: EnterFrame
    //     0x1293e78: stp             fp, lr, [SP, #-0x10]!
    //     0x1293e7c: mov             fp, SP
    // 0x1293e80: AllocStack(0x8)
    //     0x1293e80: sub             SP, SP, #8
    // 0x1293e84: CheckStackOverflow
    //     0x1293e84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1293e88: cmp             SP, x16
    //     0x1293e8c: b.ls            #0x1293f20
    // 0x1293e90: ldr             x0, [fp, #0x10]
    // 0x1293e94: cmp             w0, NULL
    // 0x1293e98: b.ne            #0x1293eac
    // 0x1293e9c: r0 = false
    //     0x1293e9c: add             x0, NULL, #0x30  ; false
    // 0x1293ea0: LeaveFrame
    //     0x1293ea0: mov             SP, fp
    //     0x1293ea4: ldp             fp, lr, [SP], #0x10
    // 0x1293ea8: ret
    //     0x1293ea8: ret             
    // 0x1293eac: ldr             x1, [fp, #0x18]
    // 0x1293eb0: cmp             w1, w0
    // 0x1293eb4: b.ne            #0x1293ec8
    // 0x1293eb8: r0 = true
    //     0x1293eb8: add             x0, NULL, #0x20  ; true
    // 0x1293ebc: LeaveFrame
    //     0x1293ebc: mov             SP, fp
    //     0x1293ec0: ldp             fp, lr, [SP], #0x10
    // 0x1293ec4: ret
    //     0x1293ec4: ret             
    // 0x1293ec8: r2 = 60
    //     0x1293ec8: mov             x2, #0x3c
    // 0x1293ecc: branchIfSmi(r0, 0x1293ed8)
    //     0x1293ecc: tbz             w0, #0, #0x1293ed8
    // 0x1293ed0: r2 = LoadClassIdInstr(r0)
    //     0x1293ed0: ldur            x2, [x0, #-1]
    //     0x1293ed4: ubfx            x2, x2, #0xc, #0x14
    // 0x1293ed8: cmp             x2, #0xd2b
    // 0x1293edc: b.eq            #0x1293ef0
    // 0x1293ee0: r0 = false
    //     0x1293ee0: add             x0, NULL, #0x30  ; false
    // 0x1293ee4: LeaveFrame
    //     0x1293ee4: mov             SP, fp
    //     0x1293ee8: ldp             fp, lr, [SP], #0x10
    // 0x1293eec: ret
    //     0x1293eec: ret             
    // 0x1293ef0: r0 = asMap()
    //     0x1293ef0: bl              #0x1114f0c  ; [package:firebase_core_platform_interface/firebase_core_platform_interface.dart] FirebaseOptions::asMap
    // 0x1293ef4: ldr             x1, [fp, #0x10]
    // 0x1293ef8: stur            x0, [fp, #-8]
    // 0x1293efc: r0 = asMap()
    //     0x1293efc: bl              #0x1114f0c  ; [package:firebase_core_platform_interface/firebase_core_platform_interface.dart] FirebaseOptions::asMap
    // 0x1293f00: ldur            x2, [fp, #-8]
    // 0x1293f04: mov             x3, x0
    // 0x1293f08: r1 = Instance_MapEquality
    //     0x1293f08: add             x1, PP, #0xd, lsl #12  ; [pp+0xd020] Obj!MapEquality@12a0011
    //     0x1293f0c: ldr             x1, [x1, #0x20]
    // 0x1293f10: r0 = equals()
    //     0x1293f10: bl              #0x12e7c88  ; [package:collection/src/equality.dart] MapEquality::equals
    // 0x1293f14: LeaveFrame
    //     0x1293f14: mov             SP, fp
    //     0x1293f18: ldp             fp, lr, [SP], #0x10
    // 0x1293f1c: ret
    //     0x1293f1c: ret             
    // 0x1293f20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1293f20: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1293f24: b               #0x1293e90
  }
}

// class id: 3372, size: 0x18, field offset: 0x8
class FirebaseException extends Object
    implements Exception {

  _ toString(/* No info */) {
    // ** addr: 0x1114e50, size: 0x84
    // 0x1114e50: EnterFrame
    //     0x1114e50: stp             fp, lr, [SP, #-0x10]!
    //     0x1114e54: mov             fp, SP
    // 0x1114e58: AllocStack(0x8)
    //     0x1114e58: sub             SP, SP, #8
    // 0x1114e5c: CheckStackOverflow
    //     0x1114e5c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1114e60: cmp             SP, x16
    //     0x1114e64: b.ls            #0x1114ecc
    // 0x1114e68: r1 = Null
    //     0x1114e68: mov             x1, NULL
    // 0x1114e6c: r2 = 12
    //     0x1114e6c: mov             x2, #0xc
    // 0x1114e70: r0 = AllocateArray()
    //     0x1114e70: bl              #0x13df928  ; AllocateArrayStub
    // 0x1114e74: r16 = "["
    //     0x1114e74: ldr             x16, [PP, #0x1290]  ; [pp+0x1290] "["
    // 0x1114e78: StoreField: r0->field_f = r16
    //     0x1114e78: stur            w16, [x0, #0xf]
    // 0x1114e7c: ldr             x1, [fp, #0x10]
    // 0x1114e80: LoadField: r2 = r1->field_7
    //     0x1114e80: ldur            w2, [x1, #7]
    // 0x1114e84: DecompressPointer r2
    //     0x1114e84: add             x2, x2, HEAP, lsl #32
    // 0x1114e88: StoreField: r0->field_13 = r2
    //     0x1114e88: stur            w2, [x0, #0x13]
    // 0x1114e8c: r16 = "/"
    //     0x1114e8c: ldr             x16, [PP, #0xfe0]  ; [pp+0xfe0] "/"
    // 0x1114e90: ArrayStore: r0[0] = r16  ; List_4
    //     0x1114e90: stur            w16, [x0, #0x17]
    // 0x1114e94: LoadField: r2 = r1->field_f
    //     0x1114e94: ldur            w2, [x1, #0xf]
    // 0x1114e98: DecompressPointer r2
    //     0x1114e98: add             x2, x2, HEAP, lsl #32
    // 0x1114e9c: StoreField: r0->field_1b = r2
    //     0x1114e9c: stur            w2, [x0, #0x1b]
    // 0x1114ea0: r16 = "] "
    //     0x1114ea0: add             x16, PP, #0xd, lsl #12  ; [pp+0xd078] "] "
    //     0x1114ea4: ldr             x16, [x16, #0x78]
    // 0x1114ea8: StoreField: r0->field_1f = r16
    //     0x1114ea8: stur            w16, [x0, #0x1f]
    // 0x1114eac: LoadField: r2 = r1->field_b
    //     0x1114eac: ldur            w2, [x1, #0xb]
    // 0x1114eb0: DecompressPointer r2
    //     0x1114eb0: add             x2, x2, HEAP, lsl #32
    // 0x1114eb4: StoreField: r0->field_23 = r2
    //     0x1114eb4: stur            w2, [x0, #0x23]
    // 0x1114eb8: str             x0, [SP]
    // 0x1114ebc: r0 = _interpolate()
    //     0x1114ebc: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x1114ec0: LeaveFrame
    //     0x1114ec0: mov             SP, fp
    //     0x1114ec4: ldp             fp, lr, [SP], #0x10
    // 0x1114ec8: ret
    //     0x1114ec8: ret             
    // 0x1114ecc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1114ecc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1114ed0: b               #0x1114e68
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x11499f4, size: 0x6c
    // 0x11499f4: EnterFrame
    //     0x11499f4: stp             fp, lr, [SP, #-0x10]!
    //     0x11499f8: mov             fp, SP
    // 0x11499fc: AllocStack(0x8)
    //     0x11499fc: sub             SP, SP, #8
    // 0x1149a00: CheckStackOverflow
    //     0x1149a00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1149a04: cmp             SP, x16
    //     0x1149a08: b.ls            #0x1149a58
    // 0x1149a0c: ldr             x0, [fp, #0x10]
    // 0x1149a10: LoadField: r1 = r0->field_7
    //     0x1149a10: ldur            w1, [x0, #7]
    // 0x1149a14: DecompressPointer r1
    //     0x1149a14: add             x1, x1, HEAP, lsl #32
    // 0x1149a18: LoadField: r2 = r0->field_f
    //     0x1149a18: ldur            w2, [x0, #0xf]
    // 0x1149a1c: DecompressPointer r2
    //     0x1149a1c: add             x2, x2, HEAP, lsl #32
    // 0x1149a20: LoadField: r3 = r0->field_b
    //     0x1149a20: ldur            w3, [x0, #0xb]
    // 0x1149a24: DecompressPointer r3
    //     0x1149a24: add             x3, x3, HEAP, lsl #32
    // 0x1149a28: str             x3, [SP]
    // 0x1149a2c: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x1149a2c: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x1149a30: r0 = hash()
    //     0x1149a30: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x1149a34: mov             x2, x0
    // 0x1149a38: r0 = BoxInt64Instr(r2)
    //     0x1149a38: sbfiz           x0, x2, #1, #0x1f
    //     0x1149a3c: cmp             x2, x0, asr #1
    //     0x1149a40: b.eq            #0x1149a4c
    //     0x1149a44: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1149a48: stur            x2, [x0, #7]
    // 0x1149a4c: LeaveFrame
    //     0x1149a4c: mov             SP, fp
    //     0x1149a50: ldp             fp, lr, [SP], #0x10
    // 0x1149a54: ret
    //     0x1149a54: ret             
    // 0x1149a58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1149a58: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1149a5c: b               #0x1149a0c
  }
  _ ==(/* No info */) {
    // ** addr: 0x1293da8, size: 0xd0
    // 0x1293da8: EnterFrame
    //     0x1293da8: stp             fp, lr, [SP, #-0x10]!
    //     0x1293dac: mov             fp, SP
    // 0x1293db0: AllocStack(0x10)
    //     0x1293db0: sub             SP, SP, #0x10
    // 0x1293db4: CheckStackOverflow
    //     0x1293db4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1293db8: cmp             SP, x16
    //     0x1293dbc: b.ls            #0x1293e70
    // 0x1293dc0: ldr             x0, [fp, #0x10]
    // 0x1293dc4: cmp             w0, NULL
    // 0x1293dc8: b.ne            #0x1293ddc
    // 0x1293dcc: r0 = false
    //     0x1293dcc: add             x0, NULL, #0x30  ; false
    // 0x1293dd0: LeaveFrame
    //     0x1293dd0: mov             SP, fp
    //     0x1293dd4: ldp             fp, lr, [SP], #0x10
    // 0x1293dd8: ret
    //     0x1293dd8: ret             
    // 0x1293ddc: ldr             x1, [fp, #0x18]
    // 0x1293de0: cmp             w1, w0
    // 0x1293de4: b.ne            #0x1293df8
    // 0x1293de8: r0 = true
    //     0x1293de8: add             x0, NULL, #0x20  ; true
    // 0x1293dec: LeaveFrame
    //     0x1293dec: mov             SP, fp
    //     0x1293df0: ldp             fp, lr, [SP], #0x10
    // 0x1293df4: ret
    //     0x1293df4: ret             
    // 0x1293df8: r2 = 60
    //     0x1293df8: mov             x2, #0x3c
    // 0x1293dfc: branchIfSmi(r0, 0x1293e08)
    //     0x1293dfc: tbz             w0, #0, #0x1293e08
    // 0x1293e00: r2 = LoadClassIdInstr(r0)
    //     0x1293e00: ldur            x2, [x0, #-1]
    //     0x1293e04: ubfx            x2, x2, #0xc, #0x14
    // 0x1293e08: cmp             x2, #0xd2c
    // 0x1293e0c: b.eq            #0x1293e20
    // 0x1293e10: r0 = false
    //     0x1293e10: add             x0, NULL, #0x30  ; false
    // 0x1293e14: LeaveFrame
    //     0x1293e14: mov             SP, fp
    //     0x1293e18: ldp             fp, lr, [SP], #0x10
    // 0x1293e1c: ret
    //     0x1293e1c: ret             
    // 0x1293e20: str             x0, [SP]
    // 0x1293e24: r0 = hashCode()
    //     0x1293e24: bl              #0x11499f4  ; [package:firebase_core_platform_interface/firebase_core_platform_interface.dart] FirebaseException::hashCode
    // 0x1293e28: stur            x0, [fp, #-8]
    // 0x1293e2c: ldr             x16, [fp, #0x18]
    // 0x1293e30: str             x16, [SP]
    // 0x1293e34: r0 = hashCode()
    //     0x1293e34: bl              #0x11499f4  ; [package:firebase_core_platform_interface/firebase_core_platform_interface.dart] FirebaseException::hashCode
    // 0x1293e38: ldur            x1, [fp, #-8]
    // 0x1293e3c: r2 = LoadInt32Instr(r1)
    //     0x1293e3c: sbfx            x2, x1, #1, #0x1f
    //     0x1293e40: tbz             w1, #0, #0x1293e48
    //     0x1293e44: ldur            x2, [x1, #7]
    // 0x1293e48: r1 = LoadInt32Instr(r0)
    //     0x1293e48: sbfx            x1, x0, #1, #0x1f
    //     0x1293e4c: tbz             w0, #0, #0x1293e54
    //     0x1293e50: ldur            x1, [x0, #7]
    // 0x1293e54: cmp             x2, x1
    // 0x1293e58: r16 = true
    //     0x1293e58: add             x16, NULL, #0x20  ; true
    // 0x1293e5c: r17 = false
    //     0x1293e5c: add             x17, NULL, #0x30  ; false
    // 0x1293e60: csel            x0, x16, x17, eq
    // 0x1293e64: LeaveFrame
    //     0x1293e64: mov             SP, fp
    //     0x1293e68: ldp             fp, lr, [SP], #0x10
    // 0x1293e6c: ret
    //     0x1293e6c: ret             
    // 0x1293e70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1293e70: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1293e74: b               #0x1293dc0
  }
}

// class id: 3701, size: 0x10, field offset: 0x8
abstract class FirebaseAppPlatform extends PlatformInterface {

  static late final Object _token; // offset: 0x109c

  static _ verify(/* No info */) {
    // ** addr: 0x8c0cd8, size: 0x60
    // 0x8c0cd8: EnterFrame
    //     0x8c0cd8: stp             fp, lr, [SP, #-0x10]!
    //     0x8c0cdc: mov             fp, SP
    // 0x8c0ce0: AllocStack(0x8)
    //     0x8c0ce0: sub             SP, SP, #8
    // 0x8c0ce4: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0x8c0ce4: stur            x1, [fp, #-8]
    // 0x8c0ce8: CheckStackOverflow
    //     0x8c0ce8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c0cec: cmp             SP, x16
    //     0x8c0cf0: b.ls            #0x8c0d30
    // 0x8c0cf4: r0 = LoadStaticField(0x109c)
    //     0x8c0cf4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8c0cf8: ldr             x0, [x0, #0x2138]
    // 0x8c0cfc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8c0d00: cmp             w0, w16
    // 0x8c0d04: b.ne            #0x8c0d14
    // 0x8c0d08: r2 = _token
    //     0x8c0d08: add             x2, PP, #8, lsl #12  ; [pp+0x8c90] Field <FirebaseAppPlatform._token@1279397154>: static late final (offset: 0x109c)
    //     0x8c0d0c: ldr             x2, [x2, #0xc90]
    // 0x8c0d10: r0 = InitLateFinalStaticField()
    //     0x8c0d10: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8c0d14: ldur            x1, [fp, #-8]
    // 0x8c0d18: mov             x2, x0
    // 0x8c0d1c: r0 = verify()
    //     0x8c0d1c: bl              #0x8c0d38  ; [package:plugin_platform_interface/plugin_platform_interface.dart] PlatformInterface::verify
    // 0x8c0d20: r0 = Null
    //     0x8c0d20: mov             x0, NULL
    // 0x8c0d24: LeaveFrame
    //     0x8c0d24: mov             SP, fp
    //     0x8c0d28: ldp             fp, lr, [SP], #0x10
    // 0x8c0d2c: ret
    //     0x8c0d2c: ret             
    // 0x8c0d30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c0d30: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c0d34: b               #0x8c0cf4
  }
  _ toString(/* No info */) {
    // ** addr: 0x110a96c, size: 0x70
    // 0x110a96c: EnterFrame
    //     0x110a96c: stp             fp, lr, [SP, #-0x10]!
    //     0x110a970: mov             fp, SP
    // 0x110a974: AllocStack(0x8)
    //     0x110a974: sub             SP, SP, #8
    // 0x110a978: CheckStackOverflow
    //     0x110a978: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x110a97c: cmp             SP, x16
    //     0x110a980: b.ls            #0x110a9d4
    // 0x110a984: r1 = Null
    //     0x110a984: mov             x1, NULL
    // 0x110a988: r2 = 8
    //     0x110a988: mov             x2, #8
    // 0x110a98c: r0 = AllocateArray()
    //     0x110a98c: bl              #0x13df928  ; AllocateArrayStub
    // 0x110a990: r16 = FirebaseAppPlatform
    //     0x110a990: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf50] Type: FirebaseAppPlatform
    //     0x110a994: ldr             x16, [x16, #0xf50]
    // 0x110a998: StoreField: r0->field_f = r16
    //     0x110a998: stur            w16, [x0, #0xf]
    // 0x110a99c: r16 = "("
    //     0x110a99c: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc98] "("
    //     0x110a9a0: ldr             x16, [x16, #0xc98]
    // 0x110a9a4: StoreField: r0->field_13 = r16
    //     0x110a9a4: stur            w16, [x0, #0x13]
    // 0x110a9a8: ldr             x1, [fp, #0x10]
    // 0x110a9ac: LoadField: r2 = r1->field_7
    //     0x110a9ac: ldur            w2, [x1, #7]
    // 0x110a9b0: DecompressPointer r2
    //     0x110a9b0: add             x2, x2, HEAP, lsl #32
    // 0x110a9b4: ArrayStore: r0[0] = r2  ; List_4
    //     0x110a9b4: stur            w2, [x0, #0x17]
    // 0x110a9b8: r16 = ")"
    //     0x110a9b8: ldr             x16, [PP, #0xe60]  ; [pp+0xe60] ")"
    // 0x110a9bc: StoreField: r0->field_1b = r16
    //     0x110a9bc: stur            w16, [x0, #0x1b]
    // 0x110a9c0: str             x0, [SP]
    // 0x110a9c4: r0 = _interpolate()
    //     0x110a9c4: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x110a9c8: LeaveFrame
    //     0x110a9c8: mov             SP, fp
    //     0x110a9cc: ldp             fp, lr, [SP], #0x10
    // 0x110a9d0: ret
    //     0x110a9d0: ret             
    // 0x110a9d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x110a9d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x110a9d8: b               #0x110a984
  }
  _ ==(/* No info */) {
    // ** addr: 0x1290254, size: 0xe4
    // 0x1290254: EnterFrame
    //     0x1290254: stp             fp, lr, [SP, #-0x10]!
    //     0x1290258: mov             fp, SP
    // 0x129025c: AllocStack(0x10)
    //     0x129025c: sub             SP, SP, #0x10
    // 0x1290260: CheckStackOverflow
    //     0x1290260: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1290264: cmp             SP, x16
    //     0x1290268: b.ls            #0x1290330
    // 0x129026c: ldr             x1, [fp, #0x10]
    // 0x1290270: cmp             w1, NULL
    // 0x1290274: b.ne            #0x1290288
    // 0x1290278: r0 = false
    //     0x1290278: add             x0, NULL, #0x30  ; false
    // 0x129027c: LeaveFrame
    //     0x129027c: mov             SP, fp
    //     0x1290280: ldp             fp, lr, [SP], #0x10
    // 0x1290284: ret
    //     0x1290284: ret             
    // 0x1290288: ldr             x2, [fp, #0x18]
    // 0x129028c: cmp             w2, w1
    // 0x1290290: b.ne            #0x12902a4
    // 0x1290294: r0 = true
    //     0x1290294: add             x0, NULL, #0x20  ; true
    // 0x1290298: LeaveFrame
    //     0x1290298: mov             SP, fp
    //     0x129029c: ldp             fp, lr, [SP], #0x10
    // 0x12902a0: ret
    //     0x12902a0: ret             
    // 0x12902a4: r0 = 60
    //     0x12902a4: mov             x0, #0x3c
    // 0x12902a8: branchIfSmi(r1, 0x12902b4)
    //     0x12902a8: tbz             w1, #0, #0x12902b4
    // 0x12902ac: r0 = LoadClassIdInstr(r1)
    //     0x12902ac: ldur            x0, [x1, #-1]
    //     0x12902b0: ubfx            x0, x0, #0xc, #0x14
    // 0x12902b4: cmp             x0, #0xe76
    // 0x12902b8: b.eq            #0x12902cc
    // 0x12902bc: r0 = false
    //     0x12902bc: add             x0, NULL, #0x30  ; false
    // 0x12902c0: LeaveFrame
    //     0x12902c0: mov             SP, fp
    //     0x12902c4: ldp             fp, lr, [SP], #0x10
    // 0x12902c8: ret
    //     0x12902c8: ret             
    // 0x12902cc: LoadField: r0 = r1->field_7
    //     0x12902cc: ldur            w0, [x1, #7]
    // 0x12902d0: DecompressPointer r0
    //     0x12902d0: add             x0, x0, HEAP, lsl #32
    // 0x12902d4: LoadField: r3 = r2->field_7
    //     0x12902d4: ldur            w3, [x2, #7]
    // 0x12902d8: DecompressPointer r3
    //     0x12902d8: add             x3, x3, HEAP, lsl #32
    // 0x12902dc: r4 = LoadClassIdInstr(r0)
    //     0x12902dc: ldur            x4, [x0, #-1]
    //     0x12902e0: ubfx            x4, x4, #0xc, #0x14
    // 0x12902e4: stp             x3, x0, [SP]
    // 0x12902e8: mov             x0, x4
    // 0x12902ec: mov             lr, x0
    // 0x12902f0: ldr             lr, [x21, lr, lsl #3]
    // 0x12902f4: blr             lr
    // 0x12902f8: tbnz            w0, #4, #0x1290320
    // 0x12902fc: ldr             x1, [fp, #0x18]
    // 0x1290300: ldr             x0, [fp, #0x10]
    // 0x1290304: LoadField: r2 = r0->field_b
    //     0x1290304: ldur            w2, [x0, #0xb]
    // 0x1290308: DecompressPointer r2
    //     0x1290308: add             x2, x2, HEAP, lsl #32
    // 0x129030c: LoadField: r0 = r1->field_b
    //     0x129030c: ldur            w0, [x1, #0xb]
    // 0x1290310: DecompressPointer r0
    //     0x1290310: add             x0, x0, HEAP, lsl #32
    // 0x1290314: stp             x0, x2, [SP]
    // 0x1290318: r0 = ==()
    //     0x1290318: bl              #0x1293e78  ; [package:firebase_core_platform_interface/firebase_core_platform_interface.dart] FirebaseOptions::==
    // 0x129031c: b               #0x1290324
    // 0x1290320: r0 = false
    //     0x1290320: add             x0, NULL, #0x30  ; false
    // 0x1290324: LeaveFrame
    //     0x1290324: mov             SP, fp
    //     0x1290328: ldp             fp, lr, [SP], #0x10
    // 0x129032c: ret
    //     0x129032c: ret             
    // 0x1290330: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1290330: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1290334: b               #0x129026c
  }
  _ FirebaseAppPlatform(/* No info */) {
    // ** addr: 0x13ea230, size: 0xcc
    // 0x13ea230: EnterFrame
    //     0x13ea230: stp             fp, lr, [SP, #-0x10]!
    //     0x13ea234: mov             fp, SP
    // 0x13ea238: AllocStack(0x10)
    //     0x13ea238: sub             SP, SP, #0x10
    // 0x13ea23c: SetupParameters(FirebaseAppPlatform this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0 */, dynamic _ /* r3 => r1 */)
    //     0x13ea23c: mov             x0, x2
    //     0x13ea240: mov             x2, x1
    //     0x13ea244: stur            x1, [fp, #-8]
    //     0x13ea248: mov             x1, x3
    // 0x13ea24c: CheckStackOverflow
    //     0x13ea24c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13ea250: cmp             SP, x16
    //     0x13ea254: b.ls            #0x13ea2f4
    // 0x13ea258: StoreField: r2->field_7 = r0
    //     0x13ea258: stur            w0, [x2, #7]
    //     0x13ea25c: ldurb           w16, [x2, #-1]
    //     0x13ea260: ldurb           w17, [x0, #-1]
    //     0x13ea264: and             x16, x17, x16, lsr #2
    //     0x13ea268: tst             x16, HEAP, lsr #32
    //     0x13ea26c: b.eq            #0x13ea274
    //     0x13ea270: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x13ea274: mov             x0, x1
    // 0x13ea278: StoreField: r2->field_b = r0
    //     0x13ea278: stur            w0, [x2, #0xb]
    //     0x13ea27c: ldurb           w16, [x2, #-1]
    //     0x13ea280: ldurb           w17, [x0, #-1]
    //     0x13ea284: and             x16, x17, x16, lsr #2
    //     0x13ea288: tst             x16, HEAP, lsr #32
    //     0x13ea28c: b.eq            #0x13ea294
    //     0x13ea290: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x13ea294: r0 = LoadStaticField(0x109c)
    //     0x13ea294: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x13ea298: ldr             x0, [x0, #0x2138]
    // 0x13ea29c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x13ea2a0: cmp             w0, w16
    // 0x13ea2a4: b.ne            #0x13ea2b4
    // 0x13ea2a8: r2 = _token
    //     0x13ea2a8: add             x2, PP, #8, lsl #12  ; [pp+0x8c90] Field <FirebaseAppPlatform._token@1279397154>: static late final (offset: 0x109c)
    //     0x13ea2ac: ldr             x2, [x2, #0xc90]
    // 0x13ea2b0: r0 = InitLateFinalStaticField()
    //     0x13ea2b0: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x13ea2b4: stur            x0, [fp, #-0x10]
    // 0x13ea2b8: r0 = LoadStaticField(0xde8)
    //     0x13ea2b8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x13ea2bc: ldr             x0, [x0, #0x1bd0]
    // 0x13ea2c0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x13ea2c4: cmp             w0, w16
    // 0x13ea2c8: b.ne            #0x13ea2d4
    // 0x13ea2cc: r2 = _instanceTokens
    //     0x13ea2cc: ldr             x2, [PP, #0x68c0]  ; [pp+0x68c0] Field <PlatformInterface._instanceTokens@1171304592>: static late final (offset: 0xde8)
    // 0x13ea2d0: r0 = InitLateFinalStaticField()
    //     0x13ea2d0: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x13ea2d4: mov             x1, x0
    // 0x13ea2d8: ldur            x2, [fp, #-8]
    // 0x13ea2dc: ldur            x3, [fp, #-0x10]
    // 0x13ea2e0: r0 = []=()
    //     0x13ea2e0: bl              #0x7f6290  ; [dart:core] Expando::[]=
    // 0x13ea2e4: r0 = Null
    //     0x13ea2e4: mov             x0, NULL
    // 0x13ea2e8: LeaveFrame
    //     0x13ea2e8: mov             SP, fp
    //     0x13ea2ec: ldp             fp, lr, [SP], #0x10
    // 0x13ea2f0: ret
    //     0x13ea2f0: ret             
    // 0x13ea2f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13ea2f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13ea2f8: b               #0x13ea258
  }
}

// class id: 3702, size: 0x10, field offset: 0x10
class MethodChannelFirebaseApp extends FirebaseAppPlatform {
}

// class id: 3703, size: 0x8, field offset: 0x8
abstract class FirebasePlatform extends PlatformInterface {

  static late FirebasePlatform _instance; // offset: 0x10a4
  static late final Object _token; // offset: 0x10a0

  static FirebasePlatform _instance() {
    // ** addr: 0x8c1250, size: 0x8c
    // 0x8c1250: EnterFrame
    //     0x8c1250: stp             fp, lr, [SP, #-0x10]!
    //     0x8c1254: mov             fp, SP
    // 0x8c1258: AllocStack(0x10)
    //     0x8c1258: sub             SP, SP, #0x10
    // 0x8c125c: CheckStackOverflow
    //     0x8c125c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c1260: cmp             SP, x16
    //     0x8c1264: b.ls            #0x8c12d4
    // 0x8c1268: r0 = LoadStaticField(0x10a0)
    //     0x8c1268: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8c126c: ldr             x0, [x0, #0x2140]
    // 0x8c1270: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8c1274: cmp             w0, w16
    // 0x8c1278: b.ne            #0x8c1288
    // 0x8c127c: r2 = _token
    //     0x8c127c: add             x2, PP, #8, lsl #12  ; [pp+0x8cc8] Field <FirebasePlatform._token@1279397154>: static late final (offset: 0x10a0)
    //     0x8c1280: ldr             x2, [x2, #0xcc8]
    // 0x8c1284: r0 = InitLateFinalStaticField()
    //     0x8c1284: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8c1288: stur            x0, [fp, #-8]
    // 0x8c128c: r0 = LoadStaticField(0xde8)
    //     0x8c128c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8c1290: ldr             x0, [x0, #0x1bd0]
    // 0x8c1294: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8c1298: cmp             w0, w16
    // 0x8c129c: b.ne            #0x8c12a8
    // 0x8c12a0: r2 = _instanceTokens
    //     0x8c12a0: ldr             x2, [PP, #0x68c0]  ; [pp+0x68c0] Field <PlatformInterface._instanceTokens@1171304592>: static late final (offset: 0xde8)
    // 0x8c12a4: r0 = InitLateFinalStaticField()
    //     0x8c12a4: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8c12a8: stur            x0, [fp, #-0x10]
    // 0x8c12ac: r0 = MethodChannelFirebase()
    //     0x8c12ac: bl              #0x8c12dc  ; AllocateMethodChannelFirebaseStub -> MethodChannelFirebase (size=0x8)
    // 0x8c12b0: ldur            x1, [fp, #-0x10]
    // 0x8c12b4: mov             x2, x0
    // 0x8c12b8: ldur            x3, [fp, #-8]
    // 0x8c12bc: stur            x0, [fp, #-8]
    // 0x8c12c0: r0 = []=()
    //     0x8c12c0: bl              #0x7f6290  ; [dart:core] Expando::[]=
    // 0x8c12c4: ldur            x0, [fp, #-8]
    // 0x8c12c8: LeaveFrame
    //     0x8c12c8: mov             SP, fp
    //     0x8c12cc: ldp             fp, lr, [SP], #0x10
    // 0x8c12d0: ret
    //     0x8c12d0: ret             
    // 0x8c12d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c12d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c12d8: b               #0x8c1268
  }
}

// class id: 3704, size: 0x8, field offset: 0x8
class MethodChannelFirebase extends FirebasePlatform {

  static late Map<String, MethodChannelFirebaseApp> appInstances; // offset: 0x10a8
  static late FirebaseCoreHostApi api; // offset: 0x10b0

  _ app(/* No info */) {
    // ** addr: 0x8c1098, size: 0xb8
    // 0x8c1098: EnterFrame
    //     0x8c1098: stp             fp, lr, [SP, #-0x10]!
    //     0x8c109c: mov             fp, SP
    // 0x8c10a0: AllocStack(0x8)
    //     0x8c10a0: sub             SP, SP, #8
    // 0x8c10a4: CheckStackOverflow
    //     0x8c10a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c10a8: cmp             SP, x16
    //     0x8c10ac: b.ls            #0x8c1144
    // 0x8c10b0: r0 = LoadStaticField(0x10a8)
    //     0x8c10b0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8c10b4: ldr             x0, [x0, #0x2150]
    // 0x8c10b8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8c10bc: cmp             w0, w16
    // 0x8c10c0: b.ne            #0x8c10d0
    // 0x8c10c4: r2 = appInstances
    //     0x8c10c4: add             x2, PP, #8, lsl #12  ; [pp+0x8c98] Field <MethodChannelFirebase.appInstances>: static late (offset: 0x10a8)
    //     0x8c10c8: ldr             x2, [x2, #0xc98]
    // 0x8c10cc: r0 = InitLateStaticField()
    //     0x8c10cc: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0x8c10d0: mov             x1, x0
    // 0x8c10d4: r2 = "[DEFAULT]"
    //     0x8c10d4: add             x2, PP, #8, lsl #12  ; [pp+0x8c88] "[DEFAULT]"
    //     0x8c10d8: ldr             x2, [x2, #0xc88]
    // 0x8c10dc: r0 = containsKey()
    //     0x8c10dc: bl              #0x12d5a5c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x8c10e0: tbnz            w0, #4, #0x8c1138
    // 0x8c10e4: r0 = LoadStaticField(0x10a8)
    //     0x8c10e4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8c10e8: ldr             x0, [x0, #0x2150]
    // 0x8c10ec: mov             x1, x0
    // 0x8c10f0: stur            x0, [fp, #-8]
    // 0x8c10f4: r2 = "[DEFAULT]"
    //     0x8c10f4: add             x2, PP, #8, lsl #12  ; [pp+0x8c88] "[DEFAULT]"
    //     0x8c10f8: ldr             x2, [x2, #0xc88]
    // 0x8c10fc: r0 = _getValueOrData()
    //     0x8c10fc: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x8c1100: mov             x1, x0
    // 0x8c1104: ldur            x0, [fp, #-8]
    // 0x8c1108: LoadField: r2 = r0->field_f
    //     0x8c1108: ldur            w2, [x0, #0xf]
    // 0x8c110c: DecompressPointer r2
    //     0x8c110c: add             x2, x2, HEAP, lsl #32
    // 0x8c1110: cmp             w2, w1
    // 0x8c1114: b.ne            #0x8c1120
    // 0x8c1118: r0 = Null
    //     0x8c1118: mov             x0, NULL
    // 0x8c111c: b               #0x8c1124
    // 0x8c1120: mov             x0, x1
    // 0x8c1124: cmp             w0, NULL
    // 0x8c1128: b.eq            #0x8c114c
    // 0x8c112c: LeaveFrame
    //     0x8c112c: mov             SP, fp
    //     0x8c1130: ldp             fp, lr, [SP], #0x10
    // 0x8c1134: ret
    //     0x8c1134: ret             
    // 0x8c1138: r0 = noAppExists()
    //     0x8c1138: bl              #0x8c1150  ; [package:firebase_core_platform_interface/firebase_core_platform_interface.dart] ::noAppExists
    // 0x8c113c: r0 = Throw()
    //     0x8c113c: bl              #0x13ddb2c  ; ThrowStub
    // 0x8c1140: brk             #0
    // 0x8c1144: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c1144: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c1148: b               #0x8c10b0
    // 0x8c114c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8c114c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static Map<String, MethodChannelFirebaseApp> appInstances() {
    // ** addr: 0x8c118c, size: 0x40
    // 0x8c118c: EnterFrame
    //     0x8c118c: stp             fp, lr, [SP, #-0x10]!
    //     0x8c1190: mov             fp, SP
    // 0x8c1194: AllocStack(0x10)
    //     0x8c1194: sub             SP, SP, #0x10
    // 0x8c1198: CheckStackOverflow
    //     0x8c1198: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c119c: cmp             SP, x16
    //     0x8c11a0: b.ls            #0x8c11c4
    // 0x8c11a4: r16 = <String, MethodChannelFirebaseApp>
    //     0x8c11a4: add             x16, PP, #8, lsl #12  ; [pp+0x8cb8] TypeArguments: <String, MethodChannelFirebaseApp>
    //     0x8c11a8: ldr             x16, [x16, #0xcb8]
    // 0x8c11ac: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x8c11b0: stp             lr, x16, [SP]
    // 0x8c11b4: r0 = Map._fromLiteral()
    //     0x8c11b4: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x8c11b8: LeaveFrame
    //     0x8c11b8: mov             SP, fp
    //     0x8c11bc: ldp             fp, lr, [SP], #0x10
    // 0x8c11c0: ret
    //     0x8c11c0: ret             
    // 0x8c11c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c11c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c11c8: b               #0x8c11a4
  }
  _ initializeApp(/* No info */) async {
    // ** addr: 0x13e9bc0, size: 0x39c
    // 0x13e9bc0: EnterFrame
    //     0x13e9bc0: stp             fp, lr, [SP, #-0x10]!
    //     0x13e9bc4: mov             fp, SP
    // 0x13e9bc8: AllocStack(0xa8)
    //     0x13e9bc8: sub             SP, SP, #0xa8
    // 0x13e9bcc: SetupParameters(MethodChannelFirebase this /* r1 => r1, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x13e9bcc: stur            NULL, [fp, #-8]
    //     0x13e9bd0: stur            x1, [fp, #-0x10]
    //     0x13e9bd4: stur            x3, [fp, #-0x18]
    // 0x13e9bd8: CheckStackOverflow
    //     0x13e9bd8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13e9bdc: cmp             SP, x16
    //     0x13e9be0: b.ls            #0x13e9f4c
    // 0x13e9be4: InitAsync() -> Future<FirebaseAppPlatform>
    //     0x13e9be4: add             x0, PP, #8, lsl #12  ; [pp+0x8ce0] TypeArguments: <FirebaseAppPlatform>
    //     0x13e9be8: ldr             x0, [x0, #0xce0]
    //     0x13e9bec: bl              #0x7f5e44  ; InitAsyncStub
    // 0x13e9bf0: r0 = LoadStaticField(0x10ac)
    //     0x13e9bf0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x13e9bf4: ldr             x0, [x0, #0x2158]
    // 0x13e9bf8: tbz             w0, #4, #0x13e9c10
    // 0x13e9bfc: ldur            x1, [fp, #-0x10]
    // 0x13e9c00: r0 = _initializeCore()
    //     0x13e9c00: bl              #0x13ea8dc  ; [package:firebase_core_platform_interface/firebase_core_platform_interface.dart] MethodChannelFirebase::_initializeCore
    // 0x13e9c04: mov             x1, x0
    // 0x13e9c08: stur            x1, [fp, #-0x20]
    // 0x13e9c0c: r0 = Await()
    //     0x13e9c0c: bl              #0x7f5c00  ; AwaitStub
    // 0x13e9c10: r0 = LoadStaticField(0x10a8)
    //     0x13e9c10: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x13e9c14: ldr             x0, [x0, #0x2150]
    // 0x13e9c18: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x13e9c1c: cmp             w0, w16
    // 0x13e9c20: b.ne            #0x13e9c30
    // 0x13e9c24: r2 = appInstances
    //     0x13e9c24: add             x2, PP, #8, lsl #12  ; [pp+0x8c98] Field <MethodChannelFirebase.appInstances>: static late (offset: 0x10a8)
    //     0x13e9c28: ldr             x2, [x2, #0xc98]
    // 0x13e9c2c: r0 = InitLateStaticField()
    //     0x13e9c2c: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0x13e9c30: mov             x1, x0
    // 0x13e9c34: r2 = "simaster_vnext_ugm_student"
    //     0x13e9c34: add             x2, PP, #8, lsl #12  ; [pp+0x8cd8] "simaster_vnext_ugm_student"
    //     0x13e9c38: ldr             x2, [x2, #0xcd8]
    // 0x13e9c3c: r0 = containsKey()
    //     0x13e9c3c: bl              #0x12d5a5c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x13e9c40: tbnz            w0, #4, #0x13e9d50
    // 0x13e9c44: r0 = LoadStaticField(0x10a8)
    //     0x13e9c44: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x13e9c48: ldr             x0, [x0, #0x2150]
    // 0x13e9c4c: mov             x1, x0
    // 0x13e9c50: stur            x0, [fp, #-0x20]
    // 0x13e9c54: r2 = "simaster_vnext_ugm_student"
    //     0x13e9c54: add             x2, PP, #8, lsl #12  ; [pp+0x8cd8] "simaster_vnext_ugm_student"
    //     0x13e9c58: ldr             x2, [x2, #0xcd8]
    // 0x13e9c5c: r0 = _getValueOrData()
    //     0x13e9c5c: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x13e9c60: mov             x1, x0
    // 0x13e9c64: ldur            x0, [fp, #-0x20]
    // 0x13e9c68: LoadField: r2 = r0->field_f
    //     0x13e9c68: ldur            w2, [x0, #0xf]
    // 0x13e9c6c: DecompressPointer r2
    //     0x13e9c6c: add             x2, x2, HEAP, lsl #32
    // 0x13e9c70: cmp             w2, w1
    // 0x13e9c74: b.ne            #0x13e9c7c
    // 0x13e9c78: r1 = Null
    //     0x13e9c78: mov             x1, NULL
    // 0x13e9c7c: ldur            x3, [fp, #-0x18]
    // 0x13e9c80: stur            x1, [fp, #-0x28]
    // 0x13e9c84: cmp             w1, NULL
    // 0x13e9c88: b.eq            #0x13e9f54
    // 0x13e9c8c: LoadField: r0 = r3->field_7
    //     0x13e9c8c: ldur            w0, [x3, #7]
    // 0x13e9c90: DecompressPointer r0
    //     0x13e9c90: add             x0, x0, HEAP, lsl #32
    // 0x13e9c94: LoadField: r2 = r1->field_b
    //     0x13e9c94: ldur            w2, [x1, #0xb]
    // 0x13e9c98: DecompressPointer r2
    //     0x13e9c98: add             x2, x2, HEAP, lsl #32
    // 0x13e9c9c: stur            x2, [fp, #-0x20]
    // 0x13e9ca0: LoadField: r4 = r2->field_7
    //     0x13e9ca0: ldur            w4, [x2, #7]
    // 0x13e9ca4: DecompressPointer r4
    //     0x13e9ca4: add             x4, x4, HEAP, lsl #32
    // 0x13e9ca8: r5 = LoadClassIdInstr(r0)
    //     0x13e9ca8: ldur            x5, [x0, #-1]
    //     0x13e9cac: ubfx            x5, x5, #0xc, #0x14
    // 0x13e9cb0: stp             x4, x0, [SP]
    // 0x13e9cb4: mov             x0, x5
    // 0x13e9cb8: mov             lr, x0
    // 0x13e9cbc: ldr             lr, [x21, lr, lsl #3]
    // 0x13e9cc0: blr             lr
    // 0x13e9cc4: tbnz            w0, #4, #0x13e9f38
    // 0x13e9cc8: ldur            x3, [fp, #-0x18]
    // 0x13e9ccc: LoadField: r0 = r3->field_1b
    //     0x13e9ccc: ldur            w0, [x3, #0x1b]
    // 0x13e9cd0: DecompressPointer r0
    //     0x13e9cd0: add             x0, x0, HEAP, lsl #32
    // 0x13e9cd4: cmp             w0, NULL
    // 0x13e9cd8: b.eq            #0x13e9d08
    // 0x13e9cdc: ldur            x1, [fp, #-0x20]
    // 0x13e9ce0: LoadField: r2 = r1->field_1b
    //     0x13e9ce0: ldur            w2, [x1, #0x1b]
    // 0x13e9ce4: DecompressPointer r2
    //     0x13e9ce4: add             x2, x2, HEAP, lsl #32
    // 0x13e9ce8: r4 = LoadClassIdInstr(r0)
    //     0x13e9ce8: ldur            x4, [x0, #-1]
    //     0x13e9cec: ubfx            x4, x4, #0xc, #0x14
    // 0x13e9cf0: stp             x2, x0, [SP]
    // 0x13e9cf4: mov             x0, x4
    // 0x13e9cf8: mov             lr, x0
    // 0x13e9cfc: ldr             lr, [x21, lr, lsl #3]
    // 0x13e9d00: blr             lr
    // 0x13e9d04: tbnz            w0, #4, #0x13e9f38
    // 0x13e9d08: ldur            x3, [fp, #-0x18]
    // 0x13e9d0c: LoadField: r0 = r3->field_1f
    //     0x13e9d0c: ldur            w0, [x3, #0x1f]
    // 0x13e9d10: DecompressPointer r0
    //     0x13e9d10: add             x0, x0, HEAP, lsl #32
    // 0x13e9d14: cmp             w0, NULL
    // 0x13e9d18: b.eq            #0x13e9d48
    // 0x13e9d1c: ldur            x1, [fp, #-0x20]
    // 0x13e9d20: LoadField: r2 = r1->field_1f
    //     0x13e9d20: ldur            w2, [x1, #0x1f]
    // 0x13e9d24: DecompressPointer r2
    //     0x13e9d24: add             x2, x2, HEAP, lsl #32
    // 0x13e9d28: r1 = LoadClassIdInstr(r0)
    //     0x13e9d28: ldur            x1, [x0, #-1]
    //     0x13e9d2c: ubfx            x1, x1, #0xc, #0x14
    // 0x13e9d30: stp             x2, x0, [SP]
    // 0x13e9d34: mov             x0, x1
    // 0x13e9d38: mov             lr, x0
    // 0x13e9d3c: ldr             lr, [x21, lr, lsl #3]
    // 0x13e9d40: blr             lr
    // 0x13e9d44: tbnz            w0, #4, #0x13e9f38
    // 0x13e9d48: ldur            x0, [fp, #-0x28]
    // 0x13e9d4c: r0 = ReturnAsyncNotFuture()
    //     0x13e9d4c: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x13e9d50: ldur            x3, [fp, #-0x18]
    // 0x13e9d54: r0 = LoadStaticField(0x10b0)
    //     0x13e9d54: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x13e9d58: ldr             x0, [x0, #0x2160]
    // 0x13e9d5c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x13e9d60: cmp             w0, w16
    // 0x13e9d64: b.ne            #0x13e9d74
    // 0x13e9d68: r2 = api
    //     0x13e9d68: add             x2, PP, #8, lsl #12  ; [pp+0x8ce8] Field <MethodChannelFirebase.api>: static late (offset: 0x10b0)
    //     0x13e9d6c: ldr             x2, [x2, #0xce8]
    // 0x13e9d70: r0 = InitLateStaticField()
    //     0x13e9d70: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0x13e9d74: ldur            x3, [fp, #-0x18]
    // 0x13e9d78: stur            x0, [fp, #-0x98]
    // 0x13e9d7c: LoadField: r1 = r3->field_7
    //     0x13e9d7c: ldur            w1, [x3, #7]
    // 0x13e9d80: DecompressPointer r1
    //     0x13e9d80: add             x1, x1, HEAP, lsl #32
    // 0x13e9d84: stur            x1, [fp, #-0x90]
    // 0x13e9d88: LoadField: r2 = r3->field_b
    //     0x13e9d88: ldur            w2, [x3, #0xb]
    // 0x13e9d8c: DecompressPointer r2
    //     0x13e9d8c: add             x2, x2, HEAP, lsl #32
    // 0x13e9d90: stur            x2, [fp, #-0x88]
    // 0x13e9d94: LoadField: r4 = r3->field_f
    //     0x13e9d94: ldur            w4, [x3, #0xf]
    // 0x13e9d98: DecompressPointer r4
    //     0x13e9d98: add             x4, x4, HEAP, lsl #32
    // 0x13e9d9c: stur            x4, [fp, #-0x80]
    // 0x13e9da0: LoadField: r5 = r3->field_13
    //     0x13e9da0: ldur            w5, [x3, #0x13]
    // 0x13e9da4: DecompressPointer r5
    //     0x13e9da4: add             x5, x5, HEAP, lsl #32
    // 0x13e9da8: stur            x5, [fp, #-0x78]
    // 0x13e9dac: ArrayLoad: r6 = r3[0]  ; List_4
    //     0x13e9dac: ldur            w6, [x3, #0x17]
    // 0x13e9db0: DecompressPointer r6
    //     0x13e9db0: add             x6, x6, HEAP, lsl #32
    // 0x13e9db4: stur            x6, [fp, #-0x70]
    // 0x13e9db8: LoadField: r7 = r3->field_1b
    //     0x13e9db8: ldur            w7, [x3, #0x1b]
    // 0x13e9dbc: DecompressPointer r7
    //     0x13e9dbc: add             x7, x7, HEAP, lsl #32
    // 0x13e9dc0: stur            x7, [fp, #-0x68]
    // 0x13e9dc4: LoadField: r8 = r3->field_1f
    //     0x13e9dc4: ldur            w8, [x3, #0x1f]
    // 0x13e9dc8: DecompressPointer r8
    //     0x13e9dc8: add             x8, x8, HEAP, lsl #32
    // 0x13e9dcc: stur            x8, [fp, #-0x60]
    // 0x13e9dd0: LoadField: r9 = r3->field_23
    //     0x13e9dd0: ldur            w9, [x3, #0x23]
    // 0x13e9dd4: DecompressPointer r9
    //     0x13e9dd4: add             x9, x9, HEAP, lsl #32
    // 0x13e9dd8: stur            x9, [fp, #-0x58]
    // 0x13e9ddc: LoadField: r10 = r3->field_27
    //     0x13e9ddc: ldur            w10, [x3, #0x27]
    // 0x13e9de0: DecompressPointer r10
    //     0x13e9de0: add             x10, x10, HEAP, lsl #32
    // 0x13e9de4: stur            x10, [fp, #-0x50]
    // 0x13e9de8: LoadField: r11 = r3->field_2b
    //     0x13e9de8: ldur            w11, [x3, #0x2b]
    // 0x13e9dec: DecompressPointer r11
    //     0x13e9dec: add             x11, x11, HEAP, lsl #32
    // 0x13e9df0: stur            x11, [fp, #-0x48]
    // 0x13e9df4: LoadField: r12 = r3->field_2f
    //     0x13e9df4: ldur            w12, [x3, #0x2f]
    // 0x13e9df8: DecompressPointer r12
    //     0x13e9df8: add             x12, x12, HEAP, lsl #32
    // 0x13e9dfc: stur            x12, [fp, #-0x40]
    // 0x13e9e00: LoadField: r13 = r3->field_33
    //     0x13e9e00: ldur            w13, [x3, #0x33]
    // 0x13e9e04: DecompressPointer r13
    //     0x13e9e04: add             x13, x13, HEAP, lsl #32
    // 0x13e9e08: stur            x13, [fp, #-0x38]
    // 0x13e9e0c: LoadField: r14 = r3->field_37
    //     0x13e9e0c: ldur            w14, [x3, #0x37]
    // 0x13e9e10: DecompressPointer r14
    //     0x13e9e10: add             x14, x14, HEAP, lsl #32
    // 0x13e9e14: stur            x14, [fp, #-0x30]
    // 0x13e9e18: LoadField: r19 = r3->field_3b
    //     0x13e9e18: ldur            w19, [x3, #0x3b]
    // 0x13e9e1c: DecompressPointer r19
    //     0x13e9e1c: add             x19, x19, HEAP, lsl #32
    // 0x13e9e20: stur            x19, [fp, #-0x28]
    // 0x13e9e24: LoadField: r20 = r3->field_3f
    //     0x13e9e24: ldur            w20, [x3, #0x3f]
    // 0x13e9e28: DecompressPointer r20
    //     0x13e9e28: add             x20, x20, HEAP, lsl #32
    // 0x13e9e2c: stur            x20, [fp, #-0x20]
    // 0x13e9e30: r0 = CoreFirebaseOptions()
    //     0x13e9e30: bl              #0x10f5278  ; AllocateCoreFirebaseOptionsStub -> CoreFirebaseOptions (size=0x44)
    // 0x13e9e34: mov             x1, x0
    // 0x13e9e38: ldur            x0, [fp, #-0x90]
    // 0x13e9e3c: StoreField: r1->field_7 = r0
    //     0x13e9e3c: stur            w0, [x1, #7]
    // 0x13e9e40: ldur            x0, [fp, #-0x88]
    // 0x13e9e44: StoreField: r1->field_b = r0
    //     0x13e9e44: stur            w0, [x1, #0xb]
    // 0x13e9e48: ldur            x0, [fp, #-0x80]
    // 0x13e9e4c: StoreField: r1->field_f = r0
    //     0x13e9e4c: stur            w0, [x1, #0xf]
    // 0x13e9e50: ldur            x0, [fp, #-0x78]
    // 0x13e9e54: StoreField: r1->field_13 = r0
    //     0x13e9e54: stur            w0, [x1, #0x13]
    // 0x13e9e58: ldur            x0, [fp, #-0x70]
    // 0x13e9e5c: ArrayStore: r1[0] = r0  ; List_4
    //     0x13e9e5c: stur            w0, [x1, #0x17]
    // 0x13e9e60: ldur            x0, [fp, #-0x68]
    // 0x13e9e64: StoreField: r1->field_1b = r0
    //     0x13e9e64: stur            w0, [x1, #0x1b]
    // 0x13e9e68: ldur            x0, [fp, #-0x60]
    // 0x13e9e6c: StoreField: r1->field_1f = r0
    //     0x13e9e6c: stur            w0, [x1, #0x1f]
    // 0x13e9e70: ldur            x0, [fp, #-0x58]
    // 0x13e9e74: StoreField: r1->field_23 = r0
    //     0x13e9e74: stur            w0, [x1, #0x23]
    // 0x13e9e78: ldur            x0, [fp, #-0x50]
    // 0x13e9e7c: StoreField: r1->field_27 = r0
    //     0x13e9e7c: stur            w0, [x1, #0x27]
    // 0x13e9e80: ldur            x0, [fp, #-0x48]
    // 0x13e9e84: StoreField: r1->field_2b = r0
    //     0x13e9e84: stur            w0, [x1, #0x2b]
    // 0x13e9e88: ldur            x0, [fp, #-0x40]
    // 0x13e9e8c: StoreField: r1->field_2f = r0
    //     0x13e9e8c: stur            w0, [x1, #0x2f]
    // 0x13e9e90: ldur            x0, [fp, #-0x38]
    // 0x13e9e94: StoreField: r1->field_33 = r0
    //     0x13e9e94: stur            w0, [x1, #0x33]
    // 0x13e9e98: ldur            x0, [fp, #-0x30]
    // 0x13e9e9c: StoreField: r1->field_37 = r0
    //     0x13e9e9c: stur            w0, [x1, #0x37]
    // 0x13e9ea0: ldur            x0, [fp, #-0x28]
    // 0x13e9ea4: StoreField: r1->field_3b = r0
    //     0x13e9ea4: stur            w0, [x1, #0x3b]
    // 0x13e9ea8: ldur            x0, [fp, #-0x20]
    // 0x13e9eac: StoreField: r1->field_3f = r0
    //     0x13e9eac: stur            w0, [x1, #0x3f]
    // 0x13e9eb0: mov             x3, x1
    // 0x13e9eb4: ldur            x1, [fp, #-0x98]
    // 0x13e9eb8: r2 = "simaster_vnext_ugm_student"
    //     0x13e9eb8: add             x2, PP, #8, lsl #12  ; [pp+0x8cd8] "simaster_vnext_ugm_student"
    //     0x13e9ebc: ldr             x2, [x2, #0xcd8]
    // 0x13e9ec0: r0 = initializeApp()
    //     0x13e9ec0: bl              #0x13ea4e4  ; [package:firebase_core_platform_interface/src/pigeon/messages.pigeon.dart] FirebaseCoreHostApi::initializeApp
    // 0x13e9ec4: mov             x1, x0
    // 0x13e9ec8: stur            x1, [fp, #-0x20]
    // 0x13e9ecc: r0 = Await()
    //     0x13e9ecc: bl              #0x7f5c00  ; AwaitStub
    // 0x13e9ed0: ldur            x1, [fp, #-0x10]
    // 0x13e9ed4: mov             x2, x0
    // 0x13e9ed8: ldur            x3, [fp, #-0x18]
    // 0x13e9edc: r0 = _preserveRecaptchaSiteKey()
    //     0x13e9edc: bl              #0x13ea314  ; [package:firebase_core_platform_interface/firebase_core_platform_interface.dart] MethodChannelFirebase::_preserveRecaptchaSiteKey
    // 0x13e9ee0: ldur            x1, [fp, #-0x10]
    // 0x13e9ee4: mov             x2, x0
    // 0x13e9ee8: r0 = _initializeFirebaseAppFromMap()
    //     0x13e9ee8: bl              #0x13e9fec  ; [package:firebase_core_platform_interface/firebase_core_platform_interface.dart] MethodChannelFirebase::_initializeFirebaseAppFromMap
    // 0x13e9eec: r0 = LoadStaticField(0x10a8)
    //     0x13e9eec: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x13e9ef0: ldr             x0, [x0, #0x2150]
    // 0x13e9ef4: mov             x1, x0
    // 0x13e9ef8: stur            x0, [fp, #-0x10]
    // 0x13e9efc: r2 = "simaster_vnext_ugm_student"
    //     0x13e9efc: add             x2, PP, #8, lsl #12  ; [pp+0x8cd8] "simaster_vnext_ugm_student"
    //     0x13e9f00: ldr             x2, [x2, #0xcd8]
    // 0x13e9f04: r0 = _getValueOrData()
    //     0x13e9f04: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x13e9f08: mov             x1, x0
    // 0x13e9f0c: ldur            x0, [fp, #-0x10]
    // 0x13e9f10: LoadField: r2 = r0->field_f
    //     0x13e9f10: ldur            w2, [x0, #0xf]
    // 0x13e9f14: DecompressPointer r2
    //     0x13e9f14: add             x2, x2, HEAP, lsl #32
    // 0x13e9f18: cmp             w2, w1
    // 0x13e9f1c: b.ne            #0x13e9f28
    // 0x13e9f20: r0 = Null
    //     0x13e9f20: mov             x0, NULL
    // 0x13e9f24: b               #0x13e9f2c
    // 0x13e9f28: mov             x0, x1
    // 0x13e9f2c: cmp             w0, NULL
    // 0x13e9f30: b.eq            #0x13e9f58
    // 0x13e9f34: r0 = ReturnAsyncNotFuture()
    //     0x13e9f34: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x13e9f38: r1 = "simaster_vnext_ugm_student"
    //     0x13e9f38: add             x1, PP, #8, lsl #12  ; [pp+0x8cd8] "simaster_vnext_ugm_student"
    //     0x13e9f3c: ldr             x1, [x1, #0xcd8]
    // 0x13e9f40: r0 = duplicateApp()
    //     0x13e9f40: bl              #0x13e9f5c  ; [package:firebase_core_platform_interface/firebase_core_platform_interface.dart] ::duplicateApp
    // 0x13e9f44: r0 = Throw()
    //     0x13e9f44: bl              #0x13ddb2c  ; ThrowStub
    // 0x13e9f48: brk             #0
    // 0x13e9f4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13e9f4c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13e9f50: b               #0x13e9be4
    // 0x13e9f54: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x13e9f54: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x13e9f58: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x13e9f58: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _initializeFirebaseAppFromMap(/* No info */) {
    // ** addr: 0x13e9fec, size: 0x208
    // 0x13e9fec: EnterFrame
    //     0x13e9fec: stp             fp, lr, [SP, #-0x10]!
    //     0x13e9ff0: mov             fp, SP
    // 0x13e9ff4: AllocStack(0x28)
    //     0x13e9ff4: sub             SP, SP, #0x28
    // 0x13e9ff8: SetupParameters(dynamic _ /* r2 => r2, fp-0x20 */)
    //     0x13e9ff8: stur            x2, [fp, #-0x20]
    // 0x13e9ffc: CheckStackOverflow
    //     0x13e9ffc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13ea000: cmp             SP, x16
    //     0x13ea004: b.ls            #0x13ea1ec
    // 0x13ea008: LoadField: r0 = r2->field_7
    //     0x13ea008: ldur            w0, [x2, #7]
    // 0x13ea00c: DecompressPointer r0
    //     0x13ea00c: add             x0, x0, HEAP, lsl #32
    // 0x13ea010: stur            x0, [fp, #-0x18]
    // 0x13ea014: LoadField: r1 = r2->field_b
    //     0x13ea014: ldur            w1, [x2, #0xb]
    // 0x13ea018: DecompressPointer r1
    //     0x13ea018: add             x1, x1, HEAP, lsl #32
    // 0x13ea01c: stur            x1, [fp, #-0x10]
    // 0x13ea020: LoadField: r3 = r1->field_7
    //     0x13ea020: ldur            w3, [x1, #7]
    // 0x13ea024: DecompressPointer r3
    //     0x13ea024: add             x3, x3, HEAP, lsl #32
    // 0x13ea028: stur            x3, [fp, #-8]
    // 0x13ea02c: r0 = FirebaseOptions()
    //     0x13ea02c: bl              #0x13ea308  ; AllocateFirebaseOptionsStub -> FirebaseOptions (size=0x44)
    // 0x13ea030: mov             x1, x0
    // 0x13ea034: ldur            x0, [fp, #-8]
    // 0x13ea038: stur            x1, [fp, #-0x28]
    // 0x13ea03c: StoreField: r1->field_7 = r0
    //     0x13ea03c: stur            w0, [x1, #7]
    // 0x13ea040: ldur            x0, [fp, #-0x10]
    // 0x13ea044: LoadField: r2 = r0->field_b
    //     0x13ea044: ldur            w2, [x0, #0xb]
    // 0x13ea048: DecompressPointer r2
    //     0x13ea048: add             x2, x2, HEAP, lsl #32
    // 0x13ea04c: StoreField: r1->field_b = r2
    //     0x13ea04c: stur            w2, [x1, #0xb]
    // 0x13ea050: LoadField: r2 = r0->field_f
    //     0x13ea050: ldur            w2, [x0, #0xf]
    // 0x13ea054: DecompressPointer r2
    //     0x13ea054: add             x2, x2, HEAP, lsl #32
    // 0x13ea058: StoreField: r1->field_f = r2
    //     0x13ea058: stur            w2, [x1, #0xf]
    // 0x13ea05c: LoadField: r2 = r0->field_13
    //     0x13ea05c: ldur            w2, [x0, #0x13]
    // 0x13ea060: DecompressPointer r2
    //     0x13ea060: add             x2, x2, HEAP, lsl #32
    // 0x13ea064: StoreField: r1->field_13 = r2
    //     0x13ea064: stur            w2, [x1, #0x13]
    // 0x13ea068: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x13ea068: ldur            w2, [x0, #0x17]
    // 0x13ea06c: DecompressPointer r2
    //     0x13ea06c: add             x2, x2, HEAP, lsl #32
    // 0x13ea070: ArrayStore: r1[0] = r2  ; List_4
    //     0x13ea070: stur            w2, [x1, #0x17]
    // 0x13ea074: LoadField: r2 = r0->field_1b
    //     0x13ea074: ldur            w2, [x0, #0x1b]
    // 0x13ea078: DecompressPointer r2
    //     0x13ea078: add             x2, x2, HEAP, lsl #32
    // 0x13ea07c: StoreField: r1->field_1b = r2
    //     0x13ea07c: stur            w2, [x1, #0x1b]
    // 0x13ea080: LoadField: r2 = r0->field_1f
    //     0x13ea080: ldur            w2, [x0, #0x1f]
    // 0x13ea084: DecompressPointer r2
    //     0x13ea084: add             x2, x2, HEAP, lsl #32
    // 0x13ea088: StoreField: r1->field_1f = r2
    //     0x13ea088: stur            w2, [x1, #0x1f]
    // 0x13ea08c: LoadField: r2 = r0->field_23
    //     0x13ea08c: ldur            w2, [x0, #0x23]
    // 0x13ea090: DecompressPointer r2
    //     0x13ea090: add             x2, x2, HEAP, lsl #32
    // 0x13ea094: StoreField: r1->field_23 = r2
    //     0x13ea094: stur            w2, [x1, #0x23]
    // 0x13ea098: LoadField: r2 = r0->field_27
    //     0x13ea098: ldur            w2, [x0, #0x27]
    // 0x13ea09c: DecompressPointer r2
    //     0x13ea09c: add             x2, x2, HEAP, lsl #32
    // 0x13ea0a0: StoreField: r1->field_27 = r2
    //     0x13ea0a0: stur            w2, [x1, #0x27]
    // 0x13ea0a4: LoadField: r2 = r0->field_2b
    //     0x13ea0a4: ldur            w2, [x0, #0x2b]
    // 0x13ea0a8: DecompressPointer r2
    //     0x13ea0a8: add             x2, x2, HEAP, lsl #32
    // 0x13ea0ac: StoreField: r1->field_2b = r2
    //     0x13ea0ac: stur            w2, [x1, #0x2b]
    // 0x13ea0b0: LoadField: r2 = r0->field_2f
    //     0x13ea0b0: ldur            w2, [x0, #0x2f]
    // 0x13ea0b4: DecompressPointer r2
    //     0x13ea0b4: add             x2, x2, HEAP, lsl #32
    // 0x13ea0b8: StoreField: r1->field_2f = r2
    //     0x13ea0b8: stur            w2, [x1, #0x2f]
    // 0x13ea0bc: LoadField: r2 = r0->field_33
    //     0x13ea0bc: ldur            w2, [x0, #0x33]
    // 0x13ea0c0: DecompressPointer r2
    //     0x13ea0c0: add             x2, x2, HEAP, lsl #32
    // 0x13ea0c4: StoreField: r1->field_33 = r2
    //     0x13ea0c4: stur            w2, [x1, #0x33]
    // 0x13ea0c8: LoadField: r2 = r0->field_37
    //     0x13ea0c8: ldur            w2, [x0, #0x37]
    // 0x13ea0cc: DecompressPointer r2
    //     0x13ea0cc: add             x2, x2, HEAP, lsl #32
    // 0x13ea0d0: StoreField: r1->field_37 = r2
    //     0x13ea0d0: stur            w2, [x1, #0x37]
    // 0x13ea0d4: LoadField: r2 = r0->field_3b
    //     0x13ea0d4: ldur            w2, [x0, #0x3b]
    // 0x13ea0d8: DecompressPointer r2
    //     0x13ea0d8: add             x2, x2, HEAP, lsl #32
    // 0x13ea0dc: StoreField: r1->field_3b = r2
    //     0x13ea0dc: stur            w2, [x1, #0x3b]
    // 0x13ea0e0: LoadField: r2 = r0->field_3f
    //     0x13ea0e0: ldur            w2, [x0, #0x3f]
    // 0x13ea0e4: DecompressPointer r2
    //     0x13ea0e4: add             x2, x2, HEAP, lsl #32
    // 0x13ea0e8: StoreField: r1->field_3f = r2
    //     0x13ea0e8: stur            w2, [x1, #0x3f]
    // 0x13ea0ec: r0 = MethodChannelFirebaseApp()
    //     0x13ea0ec: bl              #0x13ea2fc  ; AllocateMethodChannelFirebaseAppStub -> MethodChannelFirebaseApp (size=0x10)
    // 0x13ea0f0: mov             x1, x0
    // 0x13ea0f4: ldur            x2, [fp, #-0x18]
    // 0x13ea0f8: ldur            x3, [fp, #-0x28]
    // 0x13ea0fc: stur            x0, [fp, #-8]
    // 0x13ea100: r0 = FirebaseAppPlatform()
    //     0x13ea100: bl              #0x13ea230  ; [package:firebase_core_platform_interface/firebase_core_platform_interface.dart] FirebaseAppPlatform::FirebaseAppPlatform
    // 0x13ea104: r0 = LoadStaticField(0x10a8)
    //     0x13ea104: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x13ea108: ldr             x0, [x0, #0x2150]
    // 0x13ea10c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x13ea110: cmp             w0, w16
    // 0x13ea114: b.ne            #0x13ea124
    // 0x13ea118: r2 = appInstances
    //     0x13ea118: add             x2, PP, #8, lsl #12  ; [pp+0x8c98] Field <MethodChannelFirebase.appInstances>: static late (offset: 0x10a8)
    //     0x13ea11c: ldr             x2, [x2, #0xc98]
    // 0x13ea120: r0 = InitLateStaticField()
    //     0x13ea120: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0x13ea124: ldur            x3, [fp, #-8]
    // 0x13ea128: stur            x0, [fp, #-0x18]
    // 0x13ea12c: LoadField: r4 = r3->field_7
    //     0x13ea12c: ldur            w4, [x3, #7]
    // 0x13ea130: DecompressPointer r4
    //     0x13ea130: add             x4, x4, HEAP, lsl #32
    // 0x13ea134: mov             x1, x0
    // 0x13ea138: mov             x2, x4
    // 0x13ea13c: stur            x4, [fp, #-0x10]
    // 0x13ea140: r0 = _hashCode()
    //     0x13ea140: bl              #0x13d8cbc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0x13ea144: mov             x2, x0
    // 0x13ea148: r0 = BoxInt64Instr(r2)
    //     0x13ea148: sbfiz           x0, x2, #1, #0x1f
    //     0x13ea14c: cmp             x2, x0, asr #1
    //     0x13ea150: b.eq            #0x13ea15c
    //     0x13ea154: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x13ea158: stur            x2, [x0, #7]
    // 0x13ea15c: ldur            x1, [fp, #-0x18]
    // 0x13ea160: ldur            x2, [fp, #-0x10]
    // 0x13ea164: ldur            x3, [fp, #-8]
    // 0x13ea168: mov             x5, x0
    // 0x13ea16c: r0 = _set()
    //     0x13ea16c: bl              #0x13d8170  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x13ea170: r0 = LoadStaticField(0x10b4)
    //     0x13ea170: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x13ea174: ldr             x0, [x0, #0x2168]
    // 0x13ea178: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x13ea17c: cmp             w0, w16
    // 0x13ea180: b.ne            #0x13ea18c
    // 0x13ea184: r2 = _constantsForPluginApps
    //     0x13ea184: ldr             x2, [PP, #0x7af0]  ; [pp+0x7af0] Field <FirebasePlugin._constantsForPluginApps@1279397154>: static late (offset: 0x10b4)
    // 0x13ea188: r0 = InitLateStaticField()
    //     0x13ea188: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0x13ea18c: mov             x3, x0
    // 0x13ea190: ldur            x0, [fp, #-0x20]
    // 0x13ea194: stur            x3, [fp, #-0x18]
    // 0x13ea198: LoadField: r4 = r0->field_13
    //     0x13ea198: ldur            w4, [x0, #0x13]
    // 0x13ea19c: DecompressPointer r4
    //     0x13ea19c: add             x4, x4, HEAP, lsl #32
    // 0x13ea1a0: mov             x1, x3
    // 0x13ea1a4: ldur            x2, [fp, #-0x10]
    // 0x13ea1a8: stur            x4, [fp, #-8]
    // 0x13ea1ac: r0 = _hashCode()
    //     0x13ea1ac: bl              #0x13d8cbc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0x13ea1b0: mov             x2, x0
    // 0x13ea1b4: r0 = BoxInt64Instr(r2)
    //     0x13ea1b4: sbfiz           x0, x2, #1, #0x1f
    //     0x13ea1b8: cmp             x2, x0, asr #1
    //     0x13ea1bc: b.eq            #0x13ea1c8
    //     0x13ea1c0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x13ea1c4: stur            x2, [x0, #7]
    // 0x13ea1c8: ldur            x1, [fp, #-0x18]
    // 0x13ea1cc: ldur            x2, [fp, #-0x10]
    // 0x13ea1d0: ldur            x3, [fp, #-8]
    // 0x13ea1d4: mov             x5, x0
    // 0x13ea1d8: r0 = _set()
    //     0x13ea1d8: bl              #0x13d8170  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x13ea1dc: r0 = Null
    //     0x13ea1dc: mov             x0, NULL
    // 0x13ea1e0: LeaveFrame
    //     0x13ea1e0: mov             SP, fp
    //     0x13ea1e4: ldp             fp, lr, [SP], #0x10
    // 0x13ea1e8: ret
    //     0x13ea1e8: ret             
    // 0x13ea1ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13ea1ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13ea1f0: b               #0x13ea008
  }
  [closure] void _initializeFirebaseAppFromMap(dynamic, CoreInitializeResponse) {
    // ** addr: 0x13ea1f4, size: 0x3c
    // 0x13ea1f4: EnterFrame
    //     0x13ea1f4: stp             fp, lr, [SP, #-0x10]!
    //     0x13ea1f8: mov             fp, SP
    // 0x13ea1fc: ldr             x0, [fp, #0x18]
    // 0x13ea200: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x13ea200: ldur            w1, [x0, #0x17]
    // 0x13ea204: DecompressPointer r1
    //     0x13ea204: add             x1, x1, HEAP, lsl #32
    // 0x13ea208: CheckStackOverflow
    //     0x13ea208: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13ea20c: cmp             SP, x16
    //     0x13ea210: b.ls            #0x13ea228
    // 0x13ea214: ldr             x2, [fp, #0x10]
    // 0x13ea218: r0 = _initializeFirebaseAppFromMap()
    //     0x13ea218: bl              #0x13e9fec  ; [package:firebase_core_platform_interface/firebase_core_platform_interface.dart] MethodChannelFirebase::_initializeFirebaseAppFromMap
    // 0x13ea21c: LeaveFrame
    //     0x13ea21c: mov             SP, fp
    //     0x13ea220: ldp             fp, lr, [SP], #0x10
    // 0x13ea224: ret
    //     0x13ea224: ret             
    // 0x13ea228: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13ea228: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13ea22c: b               #0x13ea214
  }
  _ _preserveRecaptchaSiteKey(/* No info */) {
    // ** addr: 0x13ea314, size: 0x1d0
    // 0x13ea314: EnterFrame
    //     0x13ea314: stp             fp, lr, [SP, #-0x10]!
    //     0x13ea318: mov             fp, SP
    // 0x13ea31c: AllocStack(0x90)
    //     0x13ea31c: sub             SP, SP, #0x90
    // 0x13ea320: SetupParameters(dynamic _ /* r2 => r0, fp-0x88 */)
    //     0x13ea320: mov             x0, x2
    //     0x13ea324: stur            x2, [fp, #-0x88]
    // 0x13ea328: LoadField: r1 = r0->field_b
    //     0x13ea328: ldur            w1, [x0, #0xb]
    // 0x13ea32c: DecompressPointer r1
    //     0x13ea32c: add             x1, x1, HEAP, lsl #32
    // 0x13ea330: LoadField: r2 = r1->field_3f
    //     0x13ea330: ldur            w2, [x1, #0x3f]
    // 0x13ea334: DecompressPointer r2
    //     0x13ea334: add             x2, x2, HEAP, lsl #32
    // 0x13ea338: cmp             w2, NULL
    // 0x13ea33c: b.ne            #0x13ea354
    // 0x13ea340: LoadField: r2 = r3->field_3f
    //     0x13ea340: ldur            w2, [x3, #0x3f]
    // 0x13ea344: DecompressPointer r2
    //     0x13ea344: add             x2, x2, HEAP, lsl #32
    // 0x13ea348: stur            x2, [fp, #-0x80]
    // 0x13ea34c: cmp             w2, NULL
    // 0x13ea350: b.ne            #0x13ea360
    // 0x13ea354: LeaveFrame
    //     0x13ea354: mov             SP, fp
    //     0x13ea358: ldp             fp, lr, [SP], #0x10
    // 0x13ea35c: ret
    //     0x13ea35c: ret             
    // 0x13ea360: LoadField: r3 = r0->field_7
    //     0x13ea360: ldur            w3, [x0, #7]
    // 0x13ea364: DecompressPointer r3
    //     0x13ea364: add             x3, x3, HEAP, lsl #32
    // 0x13ea368: stur            x3, [fp, #-0x78]
    // 0x13ea36c: LoadField: r4 = r1->field_7
    //     0x13ea36c: ldur            w4, [x1, #7]
    // 0x13ea370: DecompressPointer r4
    //     0x13ea370: add             x4, x4, HEAP, lsl #32
    // 0x13ea374: stur            x4, [fp, #-0x70]
    // 0x13ea378: LoadField: r5 = r1->field_b
    //     0x13ea378: ldur            w5, [x1, #0xb]
    // 0x13ea37c: DecompressPointer r5
    //     0x13ea37c: add             x5, x5, HEAP, lsl #32
    // 0x13ea380: stur            x5, [fp, #-0x68]
    // 0x13ea384: LoadField: r6 = r1->field_f
    //     0x13ea384: ldur            w6, [x1, #0xf]
    // 0x13ea388: DecompressPointer r6
    //     0x13ea388: add             x6, x6, HEAP, lsl #32
    // 0x13ea38c: stur            x6, [fp, #-0x60]
    // 0x13ea390: LoadField: r7 = r1->field_13
    //     0x13ea390: ldur            w7, [x1, #0x13]
    // 0x13ea394: DecompressPointer r7
    //     0x13ea394: add             x7, x7, HEAP, lsl #32
    // 0x13ea398: stur            x7, [fp, #-0x58]
    // 0x13ea39c: ArrayLoad: r8 = r1[0]  ; List_4
    //     0x13ea39c: ldur            w8, [x1, #0x17]
    // 0x13ea3a0: DecompressPointer r8
    //     0x13ea3a0: add             x8, x8, HEAP, lsl #32
    // 0x13ea3a4: stur            x8, [fp, #-0x50]
    // 0x13ea3a8: LoadField: r9 = r1->field_1b
    //     0x13ea3a8: ldur            w9, [x1, #0x1b]
    // 0x13ea3ac: DecompressPointer r9
    //     0x13ea3ac: add             x9, x9, HEAP, lsl #32
    // 0x13ea3b0: stur            x9, [fp, #-0x48]
    // 0x13ea3b4: LoadField: r10 = r1->field_1f
    //     0x13ea3b4: ldur            w10, [x1, #0x1f]
    // 0x13ea3b8: DecompressPointer r10
    //     0x13ea3b8: add             x10, x10, HEAP, lsl #32
    // 0x13ea3bc: stur            x10, [fp, #-0x40]
    // 0x13ea3c0: LoadField: r11 = r1->field_23
    //     0x13ea3c0: ldur            w11, [x1, #0x23]
    // 0x13ea3c4: DecompressPointer r11
    //     0x13ea3c4: add             x11, x11, HEAP, lsl #32
    // 0x13ea3c8: stur            x11, [fp, #-0x38]
    // 0x13ea3cc: LoadField: r12 = r1->field_27
    //     0x13ea3cc: ldur            w12, [x1, #0x27]
    // 0x13ea3d0: DecompressPointer r12
    //     0x13ea3d0: add             x12, x12, HEAP, lsl #32
    // 0x13ea3d4: stur            x12, [fp, #-0x30]
    // 0x13ea3d8: LoadField: r13 = r1->field_2b
    //     0x13ea3d8: ldur            w13, [x1, #0x2b]
    // 0x13ea3dc: DecompressPointer r13
    //     0x13ea3dc: add             x13, x13, HEAP, lsl #32
    // 0x13ea3e0: stur            x13, [fp, #-0x28]
    // 0x13ea3e4: LoadField: r14 = r1->field_2f
    //     0x13ea3e4: ldur            w14, [x1, #0x2f]
    // 0x13ea3e8: DecompressPointer r14
    //     0x13ea3e8: add             x14, x14, HEAP, lsl #32
    // 0x13ea3ec: stur            x14, [fp, #-0x20]
    // 0x13ea3f0: LoadField: r19 = r1->field_33
    //     0x13ea3f0: ldur            w19, [x1, #0x33]
    // 0x13ea3f4: DecompressPointer r19
    //     0x13ea3f4: add             x19, x19, HEAP, lsl #32
    // 0x13ea3f8: stur            x19, [fp, #-0x18]
    // 0x13ea3fc: LoadField: r20 = r1->field_37
    //     0x13ea3fc: ldur            w20, [x1, #0x37]
    // 0x13ea400: DecompressPointer r20
    //     0x13ea400: add             x20, x20, HEAP, lsl #32
    // 0x13ea404: stur            x20, [fp, #-0x10]
    // 0x13ea408: LoadField: r23 = r1->field_3b
    //     0x13ea408: ldur            w23, [x1, #0x3b]
    // 0x13ea40c: DecompressPointer r23
    //     0x13ea40c: add             x23, x23, HEAP, lsl #32
    // 0x13ea410: stur            x23, [fp, #-8]
    // 0x13ea414: r0 = CoreFirebaseOptions()
    //     0x13ea414: bl              #0x10f5278  ; AllocateCoreFirebaseOptionsStub -> CoreFirebaseOptions (size=0x44)
    // 0x13ea418: mov             x1, x0
    // 0x13ea41c: ldur            x0, [fp, #-0x70]
    // 0x13ea420: stur            x1, [fp, #-0x90]
    // 0x13ea424: StoreField: r1->field_7 = r0
    //     0x13ea424: stur            w0, [x1, #7]
    // 0x13ea428: ldur            x0, [fp, #-0x68]
    // 0x13ea42c: StoreField: r1->field_b = r0
    //     0x13ea42c: stur            w0, [x1, #0xb]
    // 0x13ea430: ldur            x0, [fp, #-0x60]
    // 0x13ea434: StoreField: r1->field_f = r0
    //     0x13ea434: stur            w0, [x1, #0xf]
    // 0x13ea438: ldur            x0, [fp, #-0x58]
    // 0x13ea43c: StoreField: r1->field_13 = r0
    //     0x13ea43c: stur            w0, [x1, #0x13]
    // 0x13ea440: ldur            x0, [fp, #-0x50]
    // 0x13ea444: ArrayStore: r1[0] = r0  ; List_4
    //     0x13ea444: stur            w0, [x1, #0x17]
    // 0x13ea448: ldur            x0, [fp, #-0x48]
    // 0x13ea44c: StoreField: r1->field_1b = r0
    //     0x13ea44c: stur            w0, [x1, #0x1b]
    // 0x13ea450: ldur            x0, [fp, #-0x40]
    // 0x13ea454: StoreField: r1->field_1f = r0
    //     0x13ea454: stur            w0, [x1, #0x1f]
    // 0x13ea458: ldur            x0, [fp, #-0x38]
    // 0x13ea45c: StoreField: r1->field_23 = r0
    //     0x13ea45c: stur            w0, [x1, #0x23]
    // 0x13ea460: ldur            x0, [fp, #-0x30]
    // 0x13ea464: StoreField: r1->field_27 = r0
    //     0x13ea464: stur            w0, [x1, #0x27]
    // 0x13ea468: ldur            x0, [fp, #-0x28]
    // 0x13ea46c: StoreField: r1->field_2b = r0
    //     0x13ea46c: stur            w0, [x1, #0x2b]
    // 0x13ea470: ldur            x0, [fp, #-0x20]
    // 0x13ea474: StoreField: r1->field_2f = r0
    //     0x13ea474: stur            w0, [x1, #0x2f]
    // 0x13ea478: ldur            x0, [fp, #-0x18]
    // 0x13ea47c: StoreField: r1->field_33 = r0
    //     0x13ea47c: stur            w0, [x1, #0x33]
    // 0x13ea480: ldur            x0, [fp, #-0x10]
    // 0x13ea484: StoreField: r1->field_37 = r0
    //     0x13ea484: stur            w0, [x1, #0x37]
    // 0x13ea488: ldur            x0, [fp, #-8]
    // 0x13ea48c: StoreField: r1->field_3b = r0
    //     0x13ea48c: stur            w0, [x1, #0x3b]
    // 0x13ea490: ldur            x0, [fp, #-0x80]
    // 0x13ea494: StoreField: r1->field_3f = r0
    //     0x13ea494: stur            w0, [x1, #0x3f]
    // 0x13ea498: ldur            x0, [fp, #-0x88]
    // 0x13ea49c: LoadField: r2 = r0->field_f
    //     0x13ea49c: ldur            w2, [x0, #0xf]
    // 0x13ea4a0: DecompressPointer r2
    //     0x13ea4a0: add             x2, x2, HEAP, lsl #32
    // 0x13ea4a4: stur            x2, [fp, #-0x10]
    // 0x13ea4a8: LoadField: r3 = r0->field_13
    //     0x13ea4a8: ldur            w3, [x0, #0x13]
    // 0x13ea4ac: DecompressPointer r3
    //     0x13ea4ac: add             x3, x3, HEAP, lsl #32
    // 0x13ea4b0: stur            x3, [fp, #-8]
    // 0x13ea4b4: r0 = CoreInitializeResponse()
    //     0x13ea4b4: bl              #0x10f4be0  ; AllocateCoreInitializeResponseStub -> CoreInitializeResponse (size=0x18)
    // 0x13ea4b8: ldur            x1, [fp, #-0x78]
    // 0x13ea4bc: StoreField: r0->field_7 = r1
    //     0x13ea4bc: stur            w1, [x0, #7]
    // 0x13ea4c0: ldur            x1, [fp, #-0x90]
    // 0x13ea4c4: StoreField: r0->field_b = r1
    //     0x13ea4c4: stur            w1, [x0, #0xb]
    // 0x13ea4c8: ldur            x1, [fp, #-0x10]
    // 0x13ea4cc: StoreField: r0->field_f = r1
    //     0x13ea4cc: stur            w1, [x0, #0xf]
    // 0x13ea4d0: ldur            x1, [fp, #-8]
    // 0x13ea4d4: StoreField: r0->field_13 = r1
    //     0x13ea4d4: stur            w1, [x0, #0x13]
    // 0x13ea4d8: LeaveFrame
    //     0x13ea4d8: mov             SP, fp
    //     0x13ea4dc: ldp             fp, lr, [SP], #0x10
    // 0x13ea4e0: ret
    //     0x13ea4e0: ret             
  }
  _ _initializeCore(/* No info */) async {
    // ** addr: 0x13ea8dc, size: 0xec
    // 0x13ea8dc: EnterFrame
    //     0x13ea8dc: stp             fp, lr, [SP, #-0x10]!
    //     0x13ea8e0: mov             fp, SP
    // 0x13ea8e4: AllocStack(0x28)
    //     0x13ea8e4: sub             SP, SP, #0x28
    // 0x13ea8e8: SetupParameters(MethodChannelFirebase this /* r1 => r2, fp-0x10 */)
    //     0x13ea8e8: stur            NULL, [fp, #-8]
    //     0x13ea8ec: mov             x2, x1
    //     0x13ea8f0: stur            x1, [fp, #-0x10]
    // 0x13ea8f4: CheckStackOverflow
    //     0x13ea8f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13ea8f8: cmp             SP, x16
    //     0x13ea8fc: b.ls            #0x13ea9c0
    // 0x13ea900: InitAsync() -> Future<void?>
    //     0x13ea900: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0x13ea904: bl              #0x7f5e44  ; InitAsyncStub
    // 0x13ea908: r0 = LoadStaticField(0x10b0)
    //     0x13ea908: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x13ea90c: ldr             x0, [x0, #0x2160]
    // 0x13ea910: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x13ea914: cmp             w0, w16
    // 0x13ea918: b.ne            #0x13ea928
    // 0x13ea91c: r2 = api
    //     0x13ea91c: add             x2, PP, #8, lsl #12  ; [pp+0x8ce8] Field <MethodChannelFirebase.api>: static late (offset: 0x10b0)
    //     0x13ea920: ldr             x2, [x2, #0xce8]
    // 0x13ea924: r0 = InitLateStaticField()
    //     0x13ea924: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0x13ea928: mov             x1, x0
    // 0x13ea92c: r0 = initializeCore()
    //     0x13ea92c: bl              #0x13ea9c8  ; [package:firebase_core_platform_interface/src/pigeon/messages.pigeon.dart] FirebaseCoreHostApi::initializeCore
    // 0x13ea930: mov             x1, x0
    // 0x13ea934: stur            x1, [fp, #-0x18]
    // 0x13ea938: r0 = Await()
    //     0x13ea938: bl              #0x7f5c00  ; AwaitStub
    // 0x13ea93c: r1 = LoadClassIdInstr(r0)
    //     0x13ea93c: ldur            x1, [x0, #-1]
    //     0x13ea940: ubfx            x1, x1, #0xc, #0x14
    // 0x13ea944: r16 = <CoreInitializeResponse>
    //     0x13ea944: add             x16, PP, #8, lsl #12  ; [pp+0x8d08] TypeArguments: <CoreInitializeResponse>
    //     0x13ea948: ldr             x16, [x16, #0xd08]
    // 0x13ea94c: stp             x0, x16, [SP]
    // 0x13ea950: mov             x0, x1
    // 0x13ea954: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x13ea954: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x13ea958: r0 = GDT[cid_x0 + 0x13106]()
    //     0x13ea958: mov             x17, #0x3106
    //     0x13ea95c: movk            x17, #1, lsl #16
    //     0x13ea960: add             lr, x0, x17
    //     0x13ea964: ldr             lr, [x21, lr, lsl #3]
    //     0x13ea968: blr             lr
    // 0x13ea96c: ldur            x2, [fp, #-0x10]
    // 0x13ea970: r1 = Function '_initializeFirebaseAppFromMap@1279397154':.
    //     0x13ea970: add             x1, PP, #8, lsl #12  ; [pp+0x8d98] AnonymousClosure: (0x13ea1f4), in [package:firebase_core_platform_interface/firebase_core_platform_interface.dart] MethodChannelFirebase::_initializeFirebaseAppFromMap (0x13e9fec)
    //     0x13ea974: ldr             x1, [x1, #0xd98]
    // 0x13ea978: stur            x0, [fp, #-0x10]
    // 0x13ea97c: r0 = AllocateClosure()
    //     0x13ea97c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x13ea980: ldur            x1, [fp, #-0x10]
    // 0x13ea984: r2 = LoadClassIdInstr(r1)
    //     0x13ea984: ldur            x2, [x1, #-1]
    //     0x13ea988: ubfx            x2, x2, #0xc, #0x14
    // 0x13ea98c: mov             x16, x0
    // 0x13ea990: mov             x0, x2
    // 0x13ea994: mov             x2, x16
    // 0x13ea998: r0 = GDT[cid_x0 + 0x12d45]()
    //     0x13ea998: mov             x17, #0x2d45
    //     0x13ea99c: movk            x17, #1, lsl #16
    //     0x13ea9a0: add             lr, x0, x17
    //     0x13ea9a4: ldr             lr, [x21, lr, lsl #3]
    //     0x13ea9a8: blr             lr
    // 0x13ea9ac: r2 = true
    //     0x13ea9ac: add             x2, NULL, #0x20  ; true
    // 0x13ea9b0: StoreStaticField(0x10ac, r2)
    //     0x13ea9b0: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x13ea9b4: str             x2, [x1, #0x2158]
    // 0x13ea9b8: r0 = Null
    //     0x13ea9b8: mov             x0, NULL
    // 0x13ea9bc: r0 = ReturnAsyncNotFuture()
    //     0x13ea9bc: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x13ea9c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13ea9c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13ea9c4: b               #0x13ea900
  }
  static FirebaseCoreHostApi api() {
    // ** addr: 0x13eab30, size: 0x20
    // 0x13eab30: EnterFrame
    //     0x13eab30: stp             fp, lr, [SP, #-0x10]!
    //     0x13eab34: mov             fp, SP
    // 0x13eab38: r0 = FirebaseCoreHostApi()
    //     0x13eab38: bl              #0x13eab50  ; AllocateFirebaseCoreHostApiStub -> FirebaseCoreHostApi (size=0x10)
    // 0x13eab3c: r1 = ""
    //     0x13eab3c: ldr             x1, [PP, #0x900]  ; [pp+0x900] ""
    // 0x13eab40: StoreField: r0->field_b = r1
    //     0x13eab40: stur            w1, [x0, #0xb]
    // 0x13eab44: LeaveFrame
    //     0x13eab44: mov             SP, fp
    //     0x13eab48: ldp             fp, lr, [SP], #0x10
    // 0x13eab4c: ret
    //     0x13eab4c: ret             
  }
}
