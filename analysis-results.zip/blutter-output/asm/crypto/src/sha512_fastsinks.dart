// lib: , url: package:crypto/src/sha512_fastsinks.dart

// class id: 1048679, size: 0x8
class :: {

  static late final Uint64List _noise64; // offset: 0xf70

  static Uint64List _noise64() {
    // ** addr: 0x12e5b8c, size: 0x490
    // 0x12e5b8c: EnterFrame
    //     0x12e5b8c: stp             fp, lr, [SP, #-0x10]!
    //     0x12e5b90: mov             fp, SP
    // 0x12e5b94: AllocStack(0x10)
    //     0x12e5b94: sub             SP, SP, #0x10
    // 0x12e5b98: r0 = 160
    //     0x12e5b98: mov             x0, #0xa0
    // 0x12e5b9c: CheckStackOverflow
    //     0x12e5b9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e5ba0: cmp             SP, x16
    //     0x12e5ba4: b.ls            #0x12e6014
    // 0x12e5ba8: mov             x2, x0
    // 0x12e5bac: r1 = <int>
    //     0x12e5bac: ldr             x1, [PP, #0x50]  ; [pp+0x50] TypeArguments: <int>
    // 0x12e5bb0: r0 = AllocateArray()
    //     0x12e5bb0: bl              #0x13df928  ; AllocateArrayStub
    // 0x12e5bb4: stur            x0, [fp, #-8]
    // 0x12e5bb8: r16 = 4794697086780616226
    //     0x12e5bb8: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf458] 0x428a2f98d728ae22
    //     0x12e5bbc: ldr             x16, [x16, #0x458]
    // 0x12e5bc0: StoreField: r0->field_f = r16
    //     0x12e5bc0: stur            w16, [x0, #0xf]
    // 0x12e5bc4: r16 = 8158064640168781261
    //     0x12e5bc4: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf460] 0x7137449123ef65cd
    //     0x12e5bc8: ldr             x16, [x16, #0x460]
    // 0x12e5bcc: StoreField: r0->field_13 = r16
    //     0x12e5bcc: stur            w16, [x0, #0x13]
    // 0x12e5bd0: r16 = -5349999486874862801
    //     0x12e5bd0: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf468] -0x4a3f043013b2c4d1
    //     0x12e5bd4: ldr             x16, [x16, #0x468]
    // 0x12e5bd8: ArrayStore: r0[0] = r16  ; List_4
    //     0x12e5bd8: stur            w16, [x0, #0x17]
    // 0x12e5bdc: r16 = -1606136188198331460
    //     0x12e5bdc: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf470] -0x164a245a7e762444
    //     0x12e5be0: ldr             x16, [x16, #0x470]
    // 0x12e5be4: StoreField: r0->field_1b = r16
    //     0x12e5be4: stur            w16, [x0, #0x1b]
    // 0x12e5be8: r16 = 4131703408338449720
    //     0x12e5be8: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf478] 0x3956c25bf348b538
    //     0x12e5bec: ldr             x16, [x16, #0x478]
    // 0x12e5bf0: StoreField: r0->field_1f = r16
    //     0x12e5bf0: stur            w16, [x0, #0x1f]
    // 0x12e5bf4: r16 = 6480981068601479193
    //     0x12e5bf4: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf480] 0x59f111f1b605d019
    //     0x12e5bf8: ldr             x16, [x16, #0x480]
    // 0x12e5bfc: StoreField: r0->field_23 = r16
    //     0x12e5bfc: stur            w16, [x0, #0x23]
    // 0x12e5c00: r16 = -7908458776815382629
    //     0x12e5c00: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf488] -0x6dc07d5b50e6b065
    //     0x12e5c04: ldr             x16, [x16, #0x488]
    // 0x12e5c08: StoreField: r0->field_27 = r16
    //     0x12e5c08: stur            w16, [x0, #0x27]
    // 0x12e5c0c: r16 = -6116909921290321640
    //     0x12e5c0c: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf490] -0x54e3a12a25927ee8
    //     0x12e5c10: ldr             x16, [x16, #0x490]
    // 0x12e5c14: StoreField: r0->field_2b = r16
    //     0x12e5c14: stur            w16, [x0, #0x2b]
    // 0x12e5c18: r16 = -2880145864133508542
    //     0x12e5c18: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf498] -0x27f855675cfcfdbe
    //     0x12e5c1c: ldr             x16, [x16, #0x498]
    // 0x12e5c20: StoreField: r0->field_2f = r16
    //     0x12e5c20: stur            w16, [x0, #0x2f]
    // 0x12e5c24: r16 = 1334009975649890238
    //     0x12e5c24: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf4a0] 0x12835b0145706fbe
    //     0x12e5c28: ldr             x16, [x16, #0x4a0]
    // 0x12e5c2c: StoreField: r0->field_33 = r16
    //     0x12e5c2c: stur            w16, [x0, #0x33]
    // 0x12e5c30: r16 = 2608012711638119052
    //     0x12e5c30: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf4a8] 0x243185be4ee4b28c
    //     0x12e5c34: ldr             x16, [x16, #0x4a8]
    // 0x12e5c38: StoreField: r0->field_37 = r16
    //     0x12e5c38: stur            w16, [x0, #0x37]
    // 0x12e5c3c: r16 = 6128411473006802146
    //     0x12e5c3c: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf4b0] 0x550c7dc3d5ffb4e2
    //     0x12e5c40: ldr             x16, [x16, #0x4b0]
    // 0x12e5c44: StoreField: r0->field_3b = r16
    //     0x12e5c44: stur            w16, [x0, #0x3b]
    // 0x12e5c48: r16 = 8268148722764581231
    //     0x12e5c48: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf4b8] 0x72be5d74f27b896f
    //     0x12e5c4c: ldr             x16, [x16, #0x4b8]
    // 0x12e5c50: StoreField: r0->field_3f = r16
    //     0x12e5c50: stur            w16, [x0, #0x3f]
    // 0x12e5c54: r16 = -9160688886553864527
    //     0x12e5c54: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf4c0] -0x7f214e01c4e9694f
    //     0x12e5c58: ldr             x16, [x16, #0x4c0]
    // 0x12e5c5c: StoreField: r0->field_43 = r16
    //     0x12e5c5c: stur            w16, [x0, #0x43]
    // 0x12e5c60: r16 = -7215885187991268811
    //     0x12e5c60: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf4c8] -0x6423f958da38edcb
    //     0x12e5c64: ldr             x16, [x16, #0x4c8]
    // 0x12e5c68: StoreField: r0->field_47 = r16
    //     0x12e5c68: stur            w16, [x0, #0x47]
    // 0x12e5c6c: r16 = -4495734319001033068
    //     0x12e5c6c: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf4d0] -0x3e640e8b3096d96c
    //     0x12e5c70: ldr             x16, [x16, #0x4d0]
    // 0x12e5c74: StoreField: r0->field_4b = r16
    //     0x12e5c74: stur            w16, [x0, #0x4b]
    // 0x12e5c78: r16 = -1973867731355612462
    //     0x12e5c78: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf4d8] -0x1b64963e610eb52e
    //     0x12e5c7c: ldr             x16, [x16, #0x4d8]
    // 0x12e5c80: StoreField: r0->field_4f = r16
    //     0x12e5c80: stur            w16, [x0, #0x4f]
    // 0x12e5c84: r16 = -1171420211273849373
    //     0x12e5c84: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf4e0] -0x1041b879c7b0da1d
    //     0x12e5c88: ldr             x16, [x16, #0x4e0]
    // 0x12e5c8c: StoreField: r0->field_53 = r16
    //     0x12e5c8c: stur            w16, [x0, #0x53]
    // 0x12e5c90: r16 = 1135362057144423861
    //     0x12e5c90: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf4e8] 0xfc19dc68b8cd5b5
    //     0x12e5c94: ldr             x16, [x16, #0x4e8]
    // 0x12e5c98: StoreField: r0->field_57 = r16
    //     0x12e5c98: stur            w16, [x0, #0x57]
    // 0x12e5c9c: r16 = 2597628984639134821
    //     0x12e5c9c: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf4f0] 0x240ca1cc77ac9c65
    //     0x12e5ca0: ldr             x16, [x16, #0x4f0]
    // 0x12e5ca4: StoreField: r0->field_5b = r16
    //     0x12e5ca4: stur            w16, [x0, #0x5b]
    // 0x12e5ca8: r16 = 3308224258029322869
    //     0x12e5ca8: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf4f8] 0x2de92c6f592b0275
    //     0x12e5cac: ldr             x16, [x16, #0x4f8]
    // 0x12e5cb0: StoreField: r0->field_5f = r16
    //     0x12e5cb0: stur            w16, [x0, #0x5f]
    // 0x12e5cb4: r16 = 5365058923640841347
    //     0x12e5cb4: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf500] 0x4a7484aa6ea6e483
    //     0x12e5cb8: ldr             x16, [x16, #0x500]
    // 0x12e5cbc: StoreField: r0->field_63 = r16
    //     0x12e5cbc: stur            w16, [x0, #0x63]
    // 0x12e5cc0: r16 = 6679025012923562964
    //     0x12e5cc0: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf508] 0x5cb0a9dcbd41fbd4
    //     0x12e5cc4: ldr             x16, [x16, #0x508]
    // 0x12e5cc8: StoreField: r0->field_67 = r16
    //     0x12e5cc8: stur            w16, [x0, #0x67]
    // 0x12e5ccc: r16 = 8573033837759648693
    //     0x12e5ccc: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf510] 0x76f988da831153b5
    //     0x12e5cd0: ldr             x16, [x16, #0x510]
    // 0x12e5cd4: StoreField: r0->field_6b = r16
    //     0x12e5cd4: stur            w16, [x0, #0x6b]
    // 0x12e5cd8: r16 = -7476448914759557205
    //     0x12e5cd8: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf518] -0x67c1aead11992055
    //     0x12e5cdc: ldr             x16, [x16, #0x518]
    // 0x12e5ce0: StoreField: r0->field_6f = r16
    //     0x12e5ce0: stur            w16, [x0, #0x6f]
    // 0x12e5ce4: r16 = -6327057829258317296
    //     0x12e5ce4: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf520] -0x57ce3992d24bcdf0
    //     0x12e5ce8: ldr             x16, [x16, #0x520]
    // 0x12e5cec: StoreField: r0->field_73 = r16
    //     0x12e5cec: stur            w16, [x0, #0x73]
    // 0x12e5cf0: r16 = -5763719355590565569
    //     0x12e5cf0: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf528] -0x4ffcd8376704dec1
    //     0x12e5cf4: ldr             x16, [x16, #0x528]
    // 0x12e5cf8: StoreField: r0->field_77 = r16
    //     0x12e5cf8: stur            w16, [x0, #0x77]
    // 0x12e5cfc: r16 = -4658551843659510044
    //     0x12e5cfc: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf530] -0x40a680384110f11c
    //     0x12e5d00: ldr             x16, [x16, #0x530]
    // 0x12e5d04: StoreField: r0->field_7b = r16
    //     0x12e5d04: stur            w16, [x0, #0x7b]
    // 0x12e5d08: r16 = -4116276920077217854
    //     0x12e5d08: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf538] -0x391ff40cc257703e
    //     0x12e5d0c: ldr             x16, [x16, #0x538]
    // 0x12e5d10: StoreField: r0->field_7f = r16
    //     0x12e5d10: stur            w16, [x0, #0x7f]
    // 0x12e5d14: r16 = -3051310485924567259
    //     0x12e5d14: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf540] -0x2a586eb86cf558db
    //     0x12e5d18: ldr             x16, [x16, #0x540]
    // 0x12e5d1c: StoreField: r0->field_83 = r16
    //     0x12e5d1c: stur            w16, [x0, #0x83]
    // 0x12e5d20: r16 = 489312712824947311
    //     0x12e5d20: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf548] 0x6ca6351e003826f
    //     0x12e5d24: ldr             x16, [x16, #0x548]
    // 0x12e5d28: StoreField: r0->field_87 = r16
    //     0x12e5d28: stur            w16, [x0, #0x87]
    // 0x12e5d2c: r16 = 1452737877330783856
    //     0x12e5d2c: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf550] 0x142929670a0e6e70
    //     0x12e5d30: ldr             x16, [x16, #0x550]
    // 0x12e5d34: StoreField: r0->field_8b = r16
    //     0x12e5d34: stur            w16, [x0, #0x8b]
    // 0x12e5d38: r16 = 2861767655752347644
    //     0x12e5d38: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf558] 0x27b70a8546d22ffc
    //     0x12e5d3c: ldr             x16, [x16, #0x558]
    // 0x12e5d40: StoreField: r0->field_8f = r16
    //     0x12e5d40: stur            w16, [x0, #0x8f]
    // 0x12e5d44: r16 = 3322285676063803686
    //     0x12e5d44: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf560] 0x2e1b21385c26c926
    //     0x12e5d48: ldr             x16, [x16, #0x560]
    // 0x12e5d4c: StoreField: r0->field_93 = r16
    //     0x12e5d4c: stur            w16, [x0, #0x93]
    // 0x12e5d50: r16 = 5560940570517711597
    //     0x12e5d50: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf568] 0x4d2c6dfc5ac42aed
    //     0x12e5d54: ldr             x16, [x16, #0x568]
    // 0x12e5d58: StoreField: r0->field_97 = r16
    //     0x12e5d58: stur            w16, [x0, #0x97]
    // 0x12e5d5c: r16 = 5996557281743188959
    //     0x12e5d5c: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf570] 0x53380d139d95b3df
    //     0x12e5d60: ldr             x16, [x16, #0x570]
    // 0x12e5d64: StoreField: r0->field_9b = r16
    //     0x12e5d64: stur            w16, [x0, #0x9b]
    // 0x12e5d68: r16 = 7280758554555802590
    //     0x12e5d68: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf578] 0x650a73548baf63de
    //     0x12e5d6c: ldr             x16, [x16, #0x578]
    // 0x12e5d70: StoreField: r0->field_9f = r16
    //     0x12e5d70: stur            w16, [x0, #0x9f]
    // 0x12e5d74: r16 = 8532644243296465576
    //     0x12e5d74: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf580] 0x766a0abb3c77b2a8
    //     0x12e5d78: ldr             x16, [x16, #0x580]
    // 0x12e5d7c: StoreField: r0->field_a3 = r16
    //     0x12e5d7c: stur            w16, [x0, #0xa3]
    // 0x12e5d80: r16 = -9096487096722542874
    //     0x12e5d80: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf588] -0x7e3d36d1b812511a
    //     0x12e5d84: ldr             x16, [x16, #0x588]
    // 0x12e5d88: StoreField: r0->field_a7 = r16
    //     0x12e5d88: stur            w16, [x0, #0xa7]
    // 0x12e5d8c: r16 = -7894198246740708037
    //     0x12e5d8c: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf590] -0x6d8dd37aeb7dcac5
    //     0x12e5d90: ldr             x16, [x16, #0x590]
    // 0x12e5d94: StoreField: r0->field_ab = r16
    //     0x12e5d94: stur            w16, [x0, #0xab]
    // 0x12e5d98: r16 = -6719396339535248540
    //     0x12e5d98: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf598] -0x5d40175eb30efc9c
    //     0x12e5d9c: ldr             x16, [x16, #0x598]
    // 0x12e5da0: StoreField: r0->field_af = r16
    //     0x12e5da0: stur            w16, [x0, #0xaf]
    // 0x12e5da4: r16 = -6333637450476146687
    //     0x12e5da4: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf5a0] -0x57e599b443bdcfff
    //     0x12e5da8: ldr             x16, [x16, #0x5a0]
    // 0x12e5dac: StoreField: r0->field_b3 = r16
    //     0x12e5dac: stur            w16, [x0, #0xb3]
    // 0x12e5db0: r16 = -4446306890439682159
    //     0x12e5db0: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf5a8] -0x3db4748f2f07686f
    //     0x12e5db4: ldr             x16, [x16, #0x5a8]
    // 0x12e5db8: StoreField: r0->field_b7 = r16
    //     0x12e5db8: stur            w16, [x0, #0xb7]
    // 0x12e5dbc: r16 = -4076793802049405392
    //     0x12e5dbc: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf5b0] -0x3893ae5cf9ab41d0
    //     0x12e5dc0: ldr             x16, [x16, #0x5b0]
    // 0x12e5dc4: StoreField: r0->field_bb = r16
    //     0x12e5dc4: stur            w16, [x0, #0xbb]
    // 0x12e5dc8: r16 = -3345356375505022440
    //     0x12e5dc8: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf5b8] -0x2e6d17e62910ade8
    //     0x12e5dcc: ldr             x16, [x16, #0x5b8]
    // 0x12e5dd0: StoreField: r0->field_bf = r16
    //     0x12e5dd0: stur            w16, [x0, #0xbf]
    // 0x12e5dd4: r16 = -2983346525034927856
    //     0x12e5dd4: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf5c0] -0x2966f9dbaa9a56f0
    //     0x12e5dd8: ldr             x16, [x16, #0x5c0]
    // 0x12e5ddc: StoreField: r0->field_c3 = r16
    //     0x12e5ddc: stur            w16, [x0, #0xc3]
    // 0x12e5de0: r16 = -860691631967231958
    //     0x12e5de0: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf5c8] -0xbf1ca7aa88edfd6
    //     0x12e5de4: ldr             x16, [x16, #0x5c8]
    // 0x12e5de8: StoreField: r0->field_c7 = r16
    //     0x12e5de8: stur            w16, [x0, #0xc7]
    // 0x12e5dec: r16 = 1182934255886127544
    //     0x12e5dec: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf5d0] 0x106aa07032bbd1b8
    //     0x12e5df0: ldr             x16, [x16, #0x5d0]
    // 0x12e5df4: StoreField: r0->field_cb = r16
    //     0x12e5df4: stur            w16, [x0, #0xcb]
    // 0x12e5df8: r16 = 1847814050463011016
    //     0x12e5df8: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf5d8] 0x19a4c116b8d2d0c8
    //     0x12e5dfc: ldr             x16, [x16, #0x5d8]
    // 0x12e5e00: StoreField: r0->field_cf = r16
    //     0x12e5e00: stur            w16, [x0, #0xcf]
    // 0x12e5e04: r16 = 2177327727835720531
    //     0x12e5e04: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf5e0] 0x1e376c085141ab53
    //     0x12e5e08: ldr             x16, [x16, #0x5e0]
    // 0x12e5e0c: StoreField: r0->field_d3 = r16
    //     0x12e5e0c: stur            w16, [x0, #0xd3]
    // 0x12e5e10: r16 = 2830643537854262169
    //     0x12e5e10: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf5e8] 0x2748774cdf8eeb99
    //     0x12e5e14: ldr             x16, [x16, #0x5e8]
    // 0x12e5e18: StoreField: r0->field_d7 = r16
    //     0x12e5e18: stur            w16, [x0, #0xd7]
    // 0x12e5e1c: r16 = 3796741975233480872
    //     0x12e5e1c: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf5f0] 0x34b0bcb5e19b48a8
    //     0x12e5e20: ldr             x16, [x16, #0x5f0]
    // 0x12e5e24: StoreField: r0->field_db = r16
    //     0x12e5e24: stur            w16, [x0, #0xdb]
    // 0x12e5e28: r16 = 4115178125766777443
    //     0x12e5e28: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf5f8] 0x391c0cb3c5c95a63
    //     0x12e5e2c: ldr             x16, [x16, #0x5f8]
    // 0x12e5e30: StoreField: r0->field_df = r16
    //     0x12e5e30: stur            w16, [x0, #0xdf]
    // 0x12e5e34: r16 = 5681478168544905931
    //     0x12e5e34: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf600] 0x4ed8aa4ae3418acb
    //     0x12e5e38: ldr             x16, [x16, #0x600]
    // 0x12e5e3c: StoreField: r0->field_e3 = r16
    //     0x12e5e3c: stur            w16, [x0, #0xe3]
    // 0x12e5e40: r16 = 6601373596472566643
    //     0x12e5e40: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf608] 0x5b9cca4f7763e373
    //     0x12e5e44: ldr             x16, [x16, #0x608]
    // 0x12e5e48: StoreField: r0->field_e7 = r16
    //     0x12e5e48: stur            w16, [x0, #0xe7]
    // 0x12e5e4c: r16 = 7507060721942968483
    //     0x12e5e4c: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf610] 0x682e6ff3d6b2b8a3
    //     0x12e5e50: ldr             x16, [x16, #0x610]
    // 0x12e5e54: StoreField: r0->field_eb = r16
    //     0x12e5e54: stur            w16, [x0, #0xeb]
    // 0x12e5e58: r16 = 8399075790359081724
    //     0x12e5e58: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf618] 0x748f82ee5defb2fc
    //     0x12e5e5c: ldr             x16, [x16, #0x618]
    // 0x12e5e60: StoreField: r0->field_ef = r16
    //     0x12e5e60: stur            w16, [x0, #0xef]
    // 0x12e5e64: r16 = 8693463985226723168
    //     0x12e5e64: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf620] 0x78a5636f43172f60
    //     0x12e5e68: ldr             x16, [x16, #0x620]
    // 0x12e5e6c: StoreField: r0->field_f3 = r16
    //     0x12e5e6c: stur            w16, [x0, #0xf3]
    // 0x12e5e70: r16 = -8878714635349349518
    //     0x12e5e70: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf628] -0x7b3787eb5e0f548e
    //     0x12e5e74: ldr             x16, [x16, #0x628]
    // 0x12e5e78: StoreField: r0->field_f7 = r16
    //     0x12e5e78: stur            w16, [x0, #0xf7]
    // 0x12e5e7c: r16 = -8302665154208450068
    //     0x12e5e7c: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf630] -0x7338fdf7e59bc614
    //     0x12e5e80: ldr             x16, [x16, #0x630]
    // 0x12e5e84: StoreField: r0->field_fb = r16
    //     0x12e5e84: stur            w16, [x0, #0xfb]
    // 0x12e5e88: r16 = -8016688836872298968
    //     0x12e5e88: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf638] -0x6f410005dc9ce1d8
    //     0x12e5e8c: ldr             x16, [x16, #0x638]
    // 0x12e5e90: StoreField: r0->field_ff = r16
    //     0x12e5e90: stur            w16, [x0, #0xff]
    // 0x12e5e94: r16 = -6606660893046293015
    //     0x12e5e94: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf640] -0x5baf9314217d4217
    //     0x12e5e98: ldr             x16, [x16, #0x640]
    // 0x12e5e9c: r17 = 259
    //     0x12e5e9c: mov             x17, #0x103
    // 0x12e5ea0: str             w16, [x0, x17]
    // 0x12e5ea4: r16 = -4685533653050689259
    //     0x12e5ea4: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf648] -0x41065c084d3986eb
    //     0x12e5ea8: ldr             x16, [x16, #0x648]
    // 0x12e5eac: r17 = 263
    //     0x12e5eac: mov             x17, #0x107
    // 0x12e5eb0: str             w16, [x0, x17]
    // 0x12e5eb4: r16 = -4147400797238176981
    //     0x12e5eb4: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf650] -0x398e870d1c8dacd5
    //     0x12e5eb8: ldr             x16, [x16, #0x650]
    // 0x12e5ebc: r17 = 267
    //     0x12e5ebc: mov             x17, #0x10b
    // 0x12e5ec0: str             w16, [x0, x17]
    // 0x12e5ec4: r16 = -3880063495543823972
    //     0x12e5ec4: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf658] -0x35d8c13115d99e64
    //     0x12e5ec8: ldr             x16, [x16, #0x658]
    // 0x12e5ecc: r17 = 271
    //     0x12e5ecc: mov             x17, #0x10f
    // 0x12e5ed0: str             w16, [x0, x17]
    // 0x12e5ed4: r16 = -3348786107499101689
    //     0x12e5ed4: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf660] -0x2e794738de3f3df9
    //     0x12e5ed8: ldr             x16, [x16, #0x660]
    // 0x12e5edc: r17 = 275
    //     0x12e5edc: mov             x17, #0x113
    // 0x12e5ee0: str             w16, [x0, x17]
    // 0x12e5ee4: r16 = -1523767162380948706
    //     0x12e5ee4: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf668] -0x15258229321f14e2
    //     0x12e5ee8: ldr             x16, [x16, #0x668]
    // 0x12e5eec: r17 = 279
    //     0x12e5eec: mov             x17, #0x117
    // 0x12e5ef0: str             w16, [x0, x17]
    // 0x12e5ef4: r16 = -757361751448694408
    //     0x12e5ef4: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf670] -0xa82b08011912e88
    //     0x12e5ef8: ldr             x16, [x16, #0x670]
    // 0x12e5efc: r17 = 283
    //     0x12e5efc: mov             x17, #0x11b
    // 0x12e5f00: str             w16, [x0, x17]
    // 0x12e5f04: r16 = 500013540394364858
    //     0x12e5f04: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf678] 0x6f067aa72176fba
    //     0x12e5f08: ldr             x16, [x16, #0x678]
    // 0x12e5f0c: r17 = 287
    //     0x12e5f0c: mov             x17, #0x11f
    // 0x12e5f10: str             w16, [x0, x17]
    // 0x12e5f14: r16 = 748580250866718886
    //     0x12e5f14: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf680] 0xa637dc5a2c898a6
    //     0x12e5f18: ldr             x16, [x16, #0x680]
    // 0x12e5f1c: r17 = 291
    //     0x12e5f1c: mov             x17, #0x123
    // 0x12e5f20: str             w16, [x0, x17]
    // 0x12e5f24: r16 = 1242879168328830382
    //     0x12e5f24: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf688] 0x113f9804bef90dae
    //     0x12e5f28: ldr             x16, [x16, #0x688]
    // 0x12e5f2c: r17 = 295
    //     0x12e5f2c: mov             x17, #0x127
    // 0x12e5f30: str             w16, [x0, x17]
    // 0x12e5f34: r16 = 1977374033974150939
    //     0x12e5f34: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf690] 0x1b710b35131c471b
    //     0x12e5f38: ldr             x16, [x16, #0x690]
    // 0x12e5f3c: r17 = 299
    //     0x12e5f3c: mov             x17, #0x12b
    // 0x12e5f40: str             w16, [x0, x17]
    // 0x12e5f44: r16 = 2944078676154940804
    //     0x12e5f44: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf698] 0x28db77f523047d84
    //     0x12e5f48: ldr             x16, [x16, #0x698]
    // 0x12e5f4c: r17 = 303
    //     0x12e5f4c: mov             x17, #0x12f
    // 0x12e5f50: str             w16, [x0, x17]
    // 0x12e5f54: r16 = 3659926193048069267
    //     0x12e5f54: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf6a0] 0x32caab7b40c72493
    //     0x12e5f58: ldr             x16, [x16, #0x6a0]
    // 0x12e5f5c: r17 = 307
    //     0x12e5f5c: mov             x17, #0x133
    // 0x12e5f60: str             w16, [x0, x17]
    // 0x12e5f64: r16 = 4368137639120453308
    //     0x12e5f64: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf6a8] 0x3c9ebe0a15c9bebc
    //     0x12e5f68: ldr             x16, [x16, #0x6a8]
    // 0x12e5f6c: r17 = 311
    //     0x12e5f6c: mov             x17, #0x137
    // 0x12e5f70: str             w16, [x0, x17]
    // 0x12e5f74: r16 = 4836135668995329356
    //     0x12e5f74: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf6b0] 0x431d67c49c100d4c
    //     0x12e5f78: ldr             x16, [x16, #0x6b0]
    // 0x12e5f7c: r17 = 315
    //     0x12e5f7c: mov             x17, #0x13b
    // 0x12e5f80: str             w16, [x0, x17]
    // 0x12e5f84: r16 = 5532061633213252278
    //     0x12e5f84: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf6b8] 0x4cc5d4becb3e42b6
    //     0x12e5f88: ldr             x16, [x16, #0x6b8]
    // 0x12e5f8c: r17 = 319
    //     0x12e5f8c: mov             x17, #0x13f
    // 0x12e5f90: str             w16, [x0, x17]
    // 0x12e5f94: r16 = 6448918945643986474
    //     0x12e5f94: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf6c0] 0x597f299cfc657e2a
    //     0x12e5f98: ldr             x16, [x16, #0x6c0]
    // 0x12e5f9c: r17 = 323
    //     0x12e5f9c: mov             x17, #0x143
    // 0x12e5fa0: str             w16, [x0, x17]
    // 0x12e5fa4: r16 = 6902733635092675308
    //     0x12e5fa4: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf6c8] 0x5fcb6fab3ad6faec
    //     0x12e5fa8: ldr             x16, [x16, #0x6c8]
    // 0x12e5fac: r17 = 327
    //     0x12e5fac: mov             x17, #0x147
    // 0x12e5fb0: str             w16, [x0, x17]
    // 0x12e5fb4: r16 = 7801388544844847127
    //     0x12e5fb4: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf6d0] 0x6c44198c4a475817
    //     0x12e5fb8: ldr             x16, [x16, #0x6d0]
    // 0x12e5fbc: r17 = 331
    //     0x12e5fbc: mov             x17, #0x14b
    // 0x12e5fc0: str             w16, [x0, x17]
    // 0x12e5fc4: r1 = <int>
    //     0x12e5fc4: ldr             x1, [PP, #0x50]  ; [pp+0x50] TypeArguments: <int>
    // 0x12e5fc8: r0 = AllocateGrowableArray()
    //     0x12e5fc8: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x12e5fcc: mov             x1, x0
    // 0x12e5fd0: ldur            x0, [fp, #-8]
    // 0x12e5fd4: stur            x1, [fp, #-0x10]
    // 0x12e5fd8: StoreField: r1->field_f = r0
    //     0x12e5fd8: stur            w0, [x1, #0xf]
    // 0x12e5fdc: r4 = 160
    //     0x12e5fdc: mov             x4, #0xa0
    // 0x12e5fe0: StoreField: r1->field_b = r4
    //     0x12e5fe0: stur            w4, [x1, #0xb]
    // 0x12e5fe4: r0 = AllocateUint64Array()
    //     0x12e5fe4: bl              #0x13df0a8  ; AllocateUint64ArrayStub
    // 0x12e5fe8: mov             x1, x0
    // 0x12e5fec: ldur            x5, [fp, #-0x10]
    // 0x12e5ff0: r2 = 0
    //     0x12e5ff0: mov             x2, #0
    // 0x12e5ff4: r3 = 80
    //     0x12e5ff4: mov             x3, #0x50
    // 0x12e5ff8: r6 = 0
    //     0x12e5ff8: mov             x6, #0
    // 0x12e5ffc: stur            x0, [fp, #-8]
    // 0x12e6000: r0 = _slowSetRange()
    //     0x12e6000: bl              #0x117828c  ; [dart:typed_data] __Uint64List&_TypedList&_IntListMixin&_TypedIntListMixin::_slowSetRange
    // 0x12e6004: ldur            x0, [fp, #-8]
    // 0x12e6008: LeaveFrame
    //     0x12e6008: mov             SP, fp
    //     0x12e600c: ldp             fp, lr, [SP], #0x10
    // 0x12e6010: ret
    //     0x12e6010: ret             
    // 0x12e6014: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e6014: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e6018: b               #0x12e5ba8
  }
}

// class id: 3548, size: 0x40, field offset: 0x38
abstract class _Sha64BitSink extends HashSink {

  _ _Sha64BitSink(/* No info */) {
    // ** addr: 0x121db6c, size: 0x114
    // 0x121db6c: EnterFrame
    //     0x121db6c: stp             fp, lr, [SP, #-0x10]!
    //     0x121db70: mov             fp, SP
    // 0x121db74: AllocStack(0x18)
    //     0x121db74: sub             SP, SP, #0x18
    // 0x121db78: SetupParameters(_Sha64BitSink this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r16 */)
    //     0x121db78: stur            x1, [fp, #-8]
    //     0x121db7c: mov             x16, x2
    //     0x121db80: mov             x2, x1
    // 0x121db84: mov             x1, x16
    // 0x121db88: mov             x0, x3
    // 0x121db8c: stur            x1, [fp, #-0x10]
    // 0x121db90: stur            x3, [fp, #-0x18]
    // 0x121db94: r4 = 160
    //     0x121db94: mov             x4, #0xa0
    // 0x121db98: r0 = AllocateUint64Array()
    //     0x121db98: bl              #0x13df0a8  ; AllocateUint64ArrayStub
    // 0x121db9c: ldur            x1, [fp, #-8]
    // 0x121dba0: StoreField: r1->field_3b = r0
    //     0x121dba0: stur            w0, [x1, #0x3b]
    //     0x121dba4: ldurb           w16, [x1, #-1]
    //     0x121dba8: ldurb           w17, [x0, #-1]
    //     0x121dbac: and             x16, x17, x16, lsr #2
    //     0x121dbb0: tst             x16, HEAP, lsr #32
    //     0x121dbb4: b.eq            #0x121dbbc
    //     0x121dbb8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x121dbbc: ldur            x0, [fp, #-0x18]
    // 0x121dbc0: StoreField: r1->field_37 = r0
    //     0x121dbc0: stur            w0, [x1, #0x37]
    //     0x121dbc4: ldurb           w16, [x1, #-1]
    //     0x121dbc8: ldurb           w17, [x0, #-1]
    //     0x121dbcc: and             x16, x17, x16, lsr #2
    //     0x121dbd0: tst             x16, HEAP, lsr #32
    //     0x121dbd4: b.eq            #0x121dbdc
    //     0x121dbd8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x121dbdc: StoreField: r1->field_23 = rZR
    //     0x121dbdc: stur            xzr, [x1, #0x23]
    // 0x121dbe0: r0 = false
    //     0x121dbe0: add             x0, NULL, #0x30  ; false
    // 0x121dbe4: StoreField: r1->field_2b = r0
    //     0x121dbe4: stur            w0, [x1, #0x2b]
    // 0x121dbe8: ldur            x0, [fp, #-0x10]
    // 0x121dbec: StoreField: r1->field_7 = r0
    //     0x121dbec: stur            w0, [x1, #7]
    //     0x121dbf0: ldurb           w16, [x1, #-1]
    //     0x121dbf4: ldurb           w17, [x0, #-1]
    //     0x121dbf8: and             x16, x17, x16, lsr #2
    //     0x121dbfc: tst             x16, HEAP, lsr #32
    //     0x121dc00: b.eq            #0x121dc08
    //     0x121dc04: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x121dc08: r0 = Instance_Endian
    //     0x121dc08: add             x0, PP, #0x1f, lsl #12  ; [pp+0x1f788] Obj!Endian@12b7a01
    //     0x121dc0c: ldr             x0, [x0, #0x788]
    // 0x121dc10: StoreField: r1->field_b = r0
    //     0x121dc10: stur            w0, [x1, #0xb]
    // 0x121dc14: r0 = 16
    //     0x121dc14: mov             x0, #0x10
    // 0x121dc18: StoreField: r1->field_2f = r0
    //     0x121dc18: stur            x0, [x1, #0x2f]
    // 0x121dc1c: r4 = 256
    //     0x121dc1c: mov             x4, #0x100
    // 0x121dc20: r0 = AllocateUint8Array()
    //     0x121dc20: bl              #0x13df5f0  ; AllocateUint8ArrayStub
    // 0x121dc24: ldur            x1, [fp, #-8]
    // 0x121dc28: StoreField: r1->field_13 = r0
    //     0x121dc28: stur            w0, [x1, #0x13]
    //     0x121dc2c: ldurb           w16, [x1, #-1]
    //     0x121dc30: ldurb           w17, [x0, #-1]
    //     0x121dc34: and             x16, x17, x16, lsr #2
    //     0x121dc38: tst             x16, HEAP, lsr #32
    //     0x121dc3c: b.eq            #0x121dc44
    //     0x121dc40: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x121dc44: ArrayStore: r1[0] = rZR  ; List_8
    //     0x121dc44: stur            xzr, [x1, #0x17]
    // 0x121dc48: r4 = 64
    //     0x121dc48: mov             x4, #0x40
    // 0x121dc4c: r0 = AllocateUint32Array()
    //     0x121dc4c: bl              #0x13df228  ; AllocateUint32ArrayStub
    // 0x121dc50: ldur            x1, [fp, #-8]
    // 0x121dc54: StoreField: r1->field_1f = r0
    //     0x121dc54: stur            w0, [x1, #0x1f]
    //     0x121dc58: ldurb           w16, [x1, #-1]
    //     0x121dc5c: ldurb           w17, [x0, #-1]
    //     0x121dc60: and             x16, x17, x16, lsr #2
    //     0x121dc64: tst             x16, HEAP, lsr #32
    //     0x121dc68: b.eq            #0x121dc70
    //     0x121dc6c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x121dc70: r0 = Null
    //     0x121dc70: mov             x0, NULL
    // 0x121dc74: LeaveFrame
    //     0x121dc74: mov             SP, fp
    //     0x121dc78: ldp             fp, lr, [SP], #0x10
    // 0x121dc7c: ret
    //     0x121dc7c: ret             
  }
  _ updateHash(/* No info */) {
    // ** addr: 0x12e5540, size: 0x578
    // 0x12e5540: EnterFrame
    //     0x12e5540: stp             fp, lr, [SP, #-0x10]!
    //     0x12e5544: mov             fp, SP
    // 0x12e5548: AllocStack(0x80)
    //     0x12e5548: sub             SP, SP, #0x80
    // 0x12e554c: SetupParameters(_Sha64BitSink this /* r1 => r3, fp-0x28 */)
    //     0x12e554c: mov             x3, x1
    //     0x12e5550: stur            x1, [fp, #-0x28]
    // 0x12e5554: CheckStackOverflow
    //     0x12e5554: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e5558: cmp             SP, x16
    //     0x12e555c: b.ls            #0x12e5a60
    // 0x12e5560: LoadField: r4 = r3->field_3b
    //     0x12e5560: ldur            w4, [x3, #0x3b]
    // 0x12e5564: DecompressPointer r4
    //     0x12e5564: add             x4, x4, HEAP, lsl #32
    // 0x12e5568: stur            x4, [fp, #-0x20]
    // 0x12e556c: LoadField: r0 = r2->field_13
    //     0x12e556c: ldur            w0, [x2, #0x13]
    // 0x12e5570: r5 = LoadInt32Instr(r0)
    //     0x12e5570: sbfx            x5, x0, #1, #0x1f
    // 0x12e5574: LoadField: r0 = r4->field_13
    //     0x12e5574: ldur            w0, [x4, #0x13]
    // 0x12e5578: r6 = LoadInt32Instr(r0)
    //     0x12e5578: sbfx            x6, x0, #1, #0x1f
    // 0x12e557c: r8 = 0
    //     0x12e557c: mov             x8, #0
    // 0x12e5580: r7 = 0
    //     0x12e5580: mov             x7, #0
    // 0x12e5584: CheckStackOverflow
    //     0x12e5584: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e5588: cmp             SP, x16
    //     0x12e558c: b.ls            #0x12e5a68
    // 0x12e5590: cmp             x8, #0x20
    // 0x12e5594: b.ge            #0x12e5608
    // 0x12e5598: mov             x0, x5
    // 0x12e559c: mov             x1, x8
    // 0x12e55a0: cmp             x1, x0
    // 0x12e55a4: b.hs            #0x12e5a70
    // 0x12e55a8: ArrayLoad: r0 = r2[r8]  ; List_4
    //     0x12e55a8: add             x16, x2, x8, lsl #2
    //     0x12e55ac: ldur            w0, [x16, #0x17]
    // 0x12e55b0: ubfx            x0, x0, #0, #0x20
    // 0x12e55b4: lsl             x9, x0, #0x20
    // 0x12e55b8: add             x10, x8, #1
    // 0x12e55bc: mov             x0, x5
    // 0x12e55c0: mov             x1, x10
    // 0x12e55c4: cmp             x1, x0
    // 0x12e55c8: b.hs            #0x12e5a74
    // 0x12e55cc: ArrayLoad: r0 = r2[r10]  ; List_4
    //     0x12e55cc: add             x16, x2, x10, lsl #2
    //     0x12e55d0: ldur            w0, [x16, #0x17]
    // 0x12e55d4: ubfx            x0, x0, #0, #0x20
    // 0x12e55d8: orr             x10, x9, x0
    // 0x12e55dc: mov             x0, x6
    // 0x12e55e0: mov             x1, x7
    // 0x12e55e4: cmp             x1, x0
    // 0x12e55e8: b.hs            #0x12e5a78
    // 0x12e55ec: ArrayStore: r4[r7] = r10  ; List_8
    //     0x12e55ec: add             x0, x4, x7, lsl #3
    //     0x12e55f0: stur            x10, [x0, #0x17]
    // 0x12e55f4: add             x0, x8, #2
    // 0x12e55f8: add             x1, x7, #1
    // 0x12e55fc: mov             x8, x0
    // 0x12e5600: mov             x7, x1
    // 0x12e5604: b               #0x12e5584
    // 0x12e5608: LoadField: r0 = r4->field_13
    //     0x12e5608: ldur            w0, [x4, #0x13]
    // 0x12e560c: r5 = LoadInt32Instr(r0)
    //     0x12e560c: sbfx            x5, x0, #1, #0x1f
    // 0x12e5610: stur            x5, [fp, #-0x18]
    // 0x12e5614: r0 = 16
    //     0x12e5614: mov             x0, #0x10
    // 0x12e5618: stur            x0, [fp, #-0x10]
    // 0x12e561c: CheckStackOverflow
    //     0x12e561c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e5620: cmp             SP, x16
    //     0x12e5624: b.ls            #0x12e5a7c
    // 0x12e5628: cmp             x0, #0x50
    // 0x12e562c: b.ge            #0x12e5724
    // 0x12e5630: sub             x1, x0, #2
    // 0x12e5634: ArrayLoad: r6 = r4[r1]  ; List_8
    //     0x12e5634: add             x16, x4, x1, lsl #3
    //     0x12e5638: ldur            x6, [x16, #0x17]
    // 0x12e563c: mov             x2, x6
    // 0x12e5640: stur            x6, [fp, #-8]
    // 0x12e5644: r1 = 19
    //     0x12e5644: mov             x1, #0x13
    // 0x12e5648: r0 = _rotr64()
    //     0x12e5648: bl              #0x12e5ab8  ; [package:crypto/src/sha512_fastsinks.dart] _Sha64BitSink::_rotr64
    // 0x12e564c: ldur            x2, [fp, #-8]
    // 0x12e5650: r1 = 61
    //     0x12e5650: mov             x1, #0x3d
    // 0x12e5654: stur            x0, [fp, #-0x30]
    // 0x12e5658: r0 = _rotr64()
    //     0x12e5658: bl              #0x12e5ab8  ; [package:crypto/src/sha512_fastsinks.dart] _Sha64BitSink::_rotr64
    // 0x12e565c: mov             x1, x0
    // 0x12e5660: ldur            x0, [fp, #-0x30]
    // 0x12e5664: eor             x2, x0, x1
    // 0x12e5668: ldur            x0, [fp, #-8]
    // 0x12e566c: asr             x1, x0, #6
    // 0x12e5670: and             x0, x1, #0x3ffffffffffffff
    // 0x12e5674: eor             x1, x2, x0
    // 0x12e5678: ldur            x0, [fp, #-0x10]
    // 0x12e567c: sub             x2, x0, #7
    // 0x12e5680: ldur            x3, [fp, #-0x20]
    // 0x12e5684: ArrayLoad: r4 = r3[r2]  ; List_8
    //     0x12e5684: add             x16, x3, x2, lsl #3
    //     0x12e5688: ldur            x4, [x16, #0x17]
    // 0x12e568c: add             x5, x1, x4
    // 0x12e5690: stur            x5, [fp, #-0x30]
    // 0x12e5694: sub             x1, x0, #0xf
    // 0x12e5698: ArrayLoad: r4 = r3[r1]  ; List_8
    //     0x12e5698: add             x16, x3, x1, lsl #3
    //     0x12e569c: ldur            x4, [x16, #0x17]
    // 0x12e56a0: mov             x2, x4
    // 0x12e56a4: stur            x4, [fp, #-8]
    // 0x12e56a8: r1 = 1
    //     0x12e56a8: mov             x1, #1
    // 0x12e56ac: r0 = _rotr64()
    //     0x12e56ac: bl              #0x12e5ab8  ; [package:crypto/src/sha512_fastsinks.dart] _Sha64BitSink::_rotr64
    // 0x12e56b0: ldur            x2, [fp, #-8]
    // 0x12e56b4: r1 = 8
    //     0x12e56b4: mov             x1, #8
    // 0x12e56b8: stur            x0, [fp, #-0x38]
    // 0x12e56bc: r0 = _rotr64()
    //     0x12e56bc: bl              #0x12e5ab8  ; [package:crypto/src/sha512_fastsinks.dart] _Sha64BitSink::_rotr64
    // 0x12e56c0: mov             x1, x0
    // 0x12e56c4: ldur            x0, [fp, #-0x38]
    // 0x12e56c8: eor             x2, x0, x1
    // 0x12e56cc: ldur            x0, [fp, #-8]
    // 0x12e56d0: asr             x1, x0, #7
    // 0x12e56d4: and             x0, x1, #0x1ffffffffffffff
    // 0x12e56d8: eor             x1, x2, x0
    // 0x12e56dc: ldur            x0, [fp, #-0x30]
    // 0x12e56e0: add             x2, x0, x1
    // 0x12e56e4: ldur            x3, [fp, #-0x10]
    // 0x12e56e8: sub             x0, x3, #0x10
    // 0x12e56ec: ldur            x4, [fp, #-0x20]
    // 0x12e56f0: ArrayLoad: r1 = r4[r0]  ; List_8
    //     0x12e56f0: add             x16, x4, x0, lsl #3
    //     0x12e56f4: ldur            x1, [x16, #0x17]
    // 0x12e56f8: add             x5, x2, x1
    // 0x12e56fc: ldur            x0, [fp, #-0x18]
    // 0x12e5700: mov             x1, x3
    // 0x12e5704: cmp             x1, x0
    // 0x12e5708: b.hs            #0x12e5a84
    // 0x12e570c: ArrayStore: r4[r3] = r5  ; List_8
    //     0x12e570c: add             x0, x4, x3, lsl #3
    //     0x12e5710: stur            x5, [x0, #0x17]
    // 0x12e5714: add             x0, x3, #1
    // 0x12e5718: ldur            x3, [fp, #-0x28]
    // 0x12e571c: ldur            x5, [fp, #-0x18]
    // 0x12e5720: b               #0x12e5618
    // 0x12e5724: mov             x0, x3
    // 0x12e5728: LoadField: r3 = r0->field_37
    //     0x12e5728: ldur            w3, [x0, #0x37]
    // 0x12e572c: DecompressPointer r3
    //     0x12e572c: add             x3, x3, HEAP, lsl #32
    // 0x12e5730: stur            x3, [fp, #-0x68]
    // 0x12e5734: LoadField: r0 = r3->field_13
    //     0x12e5734: ldur            w0, [x3, #0x13]
    // 0x12e5738: r2 = LoadInt32Instr(r0)
    //     0x12e5738: sbfx            x2, x0, #1, #0x1f
    // 0x12e573c: mov             x0, x2
    // 0x12e5740: r1 = 0
    //     0x12e5740: mov             x1, #0
    // 0x12e5744: cmp             x1, x0
    // 0x12e5748: b.hs            #0x12e5a88
    // 0x12e574c: ArrayLoad: r5 = r3[0]  ; List_8
    //     0x12e574c: ldur            x5, [x3, #0x17]
    // 0x12e5750: mov             x0, x2
    // 0x12e5754: r1 = 1
    //     0x12e5754: mov             x1, #1
    // 0x12e5758: cmp             x1, x0
    // 0x12e575c: b.hs            #0x12e5a8c
    // 0x12e5760: LoadField: r6 = r3->field_1f
    //     0x12e5760: ldur            x6, [x3, #0x1f]
    // 0x12e5764: mov             x0, x2
    // 0x12e5768: r1 = 2
    //     0x12e5768: mov             x1, #2
    // 0x12e576c: cmp             x1, x0
    // 0x12e5770: b.hs            #0x12e5a90
    // 0x12e5774: LoadField: r7 = r3->field_27
    //     0x12e5774: ldur            x7, [x3, #0x27]
    // 0x12e5778: mov             x0, x2
    // 0x12e577c: r1 = 3
    //     0x12e577c: mov             x1, #3
    // 0x12e5780: cmp             x1, x0
    // 0x12e5784: b.hs            #0x12e5a94
    // 0x12e5788: LoadField: r8 = r3->field_2f
    //     0x12e5788: ldur            x8, [x3, #0x2f]
    // 0x12e578c: mov             x0, x2
    // 0x12e5790: r1 = 4
    //     0x12e5790: mov             x1, #4
    // 0x12e5794: cmp             x1, x0
    // 0x12e5798: b.hs            #0x12e5a98
    // 0x12e579c: LoadField: r9 = r3->field_37
    //     0x12e579c: ldur            x9, [x3, #0x37]
    // 0x12e57a0: mov             x0, x2
    // 0x12e57a4: r1 = 5
    //     0x12e57a4: mov             x1, #5
    // 0x12e57a8: cmp             x1, x0
    // 0x12e57ac: b.hs            #0x12e5a9c
    // 0x12e57b0: LoadField: r10 = r3->field_3f
    //     0x12e57b0: ldur            x10, [x3, #0x3f]
    // 0x12e57b4: mov             x0, x2
    // 0x12e57b8: r1 = 6
    //     0x12e57b8: mov             x1, #6
    // 0x12e57bc: cmp             x1, x0
    // 0x12e57c0: b.hs            #0x12e5aa0
    // 0x12e57c4: LoadField: r11 = r3->field_47
    //     0x12e57c4: ldur            x11, [x3, #0x47]
    // 0x12e57c8: mov             x0, x2
    // 0x12e57cc: r1 = 7
    //     0x12e57cc: mov             x1, #7
    // 0x12e57d0: cmp             x1, x0
    // 0x12e57d4: b.hs            #0x12e5aa4
    // 0x12e57d8: LoadField: r0 = r3->field_4f
    //     0x12e57d8: ldur            x0, [x3, #0x4f]
    // 0x12e57dc: LoadField: r1 = r4->field_13
    //     0x12e57dc: ldur            w1, [x4, #0x13]
    // 0x12e57e0: r12 = LoadInt32Instr(r1)
    //     0x12e57e0: sbfx            x12, x1, #1, #0x1f
    // 0x12e57e4: stur            x12, [fp, #-0x60]
    // 0x12e57e8: mov             x13, x5
    // 0x12e57ec: mov             x16, x11
    // 0x12e57f0: mov             x11, x6
    // 0x12e57f4: mov             x6, x16
    // 0x12e57f8: mov             x16, x10
    // 0x12e57fc: mov             x10, x7
    // 0x12e5800: mov             x7, x16
    // 0x12e5804: mov             x16, x9
    // 0x12e5808: mov             x9, x8
    // 0x12e580c: mov             x8, x16
    // 0x12e5810: mov             x5, x0
    // 0x12e5814: r0 = 0
    //     0x12e5814: mov             x0, #0
    // 0x12e5818: stur            x13, [fp, #-8]
    // 0x12e581c: stur            x11, [fp, #-0x10]
    // 0x12e5820: stur            x10, [fp, #-0x18]
    // 0x12e5824: stur            x9, [fp, #-0x30]
    // 0x12e5828: stur            x8, [fp, #-0x38]
    // 0x12e582c: stur            x7, [fp, #-0x40]
    // 0x12e5830: stur            x6, [fp, #-0x48]
    // 0x12e5834: stur            x5, [fp, #-0x50]
    // 0x12e5838: stur            x0, [fp, #-0x58]
    // 0x12e583c: CheckStackOverflow
    //     0x12e583c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e5840: cmp             SP, x16
    //     0x12e5844: b.ls            #0x12e5aa8
    // 0x12e5848: cmp             x0, #0x50
    // 0x12e584c: b.ge            #0x12e59cc
    // 0x12e5850: mov             x2, x8
    // 0x12e5854: r1 = 14
    //     0x12e5854: mov             x1, #0xe
    // 0x12e5858: r0 = _rotr64()
    //     0x12e5858: bl              #0x12e5ab8  ; [package:crypto/src/sha512_fastsinks.dart] _Sha64BitSink::_rotr64
    // 0x12e585c: ldur            x2, [fp, #-0x38]
    // 0x12e5860: r1 = 18
    //     0x12e5860: mov             x1, #0x12
    // 0x12e5864: stur            x0, [fp, #-0x70]
    // 0x12e5868: r0 = _rotr64()
    //     0x12e5868: bl              #0x12e5ab8  ; [package:crypto/src/sha512_fastsinks.dart] _Sha64BitSink::_rotr64
    // 0x12e586c: mov             x1, x0
    // 0x12e5870: ldur            x0, [fp, #-0x70]
    // 0x12e5874: eor             x3, x0, x1
    // 0x12e5878: ldur            x2, [fp, #-0x38]
    // 0x12e587c: stur            x3, [fp, #-0x78]
    // 0x12e5880: r1 = 41
    //     0x12e5880: mov             x1, #0x29
    // 0x12e5884: r0 = _rotr64()
    //     0x12e5884: bl              #0x12e5ab8  ; [package:crypto/src/sha512_fastsinks.dart] _Sha64BitSink::_rotr64
    // 0x12e5888: mov             x1, x0
    // 0x12e588c: ldur            x0, [fp, #-0x78]
    // 0x12e5890: eor             x2, x0, x1
    // 0x12e5894: ldur            x0, [fp, #-0x50]
    // 0x12e5898: add             x1, x0, x2
    // 0x12e589c: ldur            x7, [fp, #-0x38]
    // 0x12e58a0: ldur            x6, [fp, #-0x40]
    // 0x12e58a4: and             x0, x7, x6
    // 0x12e58a8: mvn             x2, x7
    // 0x12e58ac: ldur            x5, [fp, #-0x48]
    // 0x12e58b0: and             x3, x2, x5
    // 0x12e58b4: eor             x2, x0, x3
    // 0x12e58b8: add             x0, x1, x2
    // 0x12e58bc: stur            x0, [fp, #-0x70]
    // 0x12e58c0: r0 = LoadStaticField(0xf70)
    //     0x12e58c0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x12e58c4: ldr             x0, [x0, #0x1ee0]
    // 0x12e58c8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12e58cc: cmp             w0, w16
    // 0x12e58d0: b.ne            #0x12e58e0
    // 0x12e58d4: r2 = _noise64
    //     0x12e58d4: add             x2, PP, #0xcf, lsl #12  ; [pp+0xcf450] Field <::._noise64@1250379572>: static late final (offset: 0xf70)
    //     0x12e58d8: ldr             x2, [x2, #0x450]
    // 0x12e58dc: r0 = InitLateFinalStaticField()
    //     0x12e58dc: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x12e58e0: mov             x2, x0
    // 0x12e58e4: LoadField: r0 = r2->field_13
    //     0x12e58e4: ldur            w0, [x2, #0x13]
    // 0x12e58e8: r1 = LoadInt32Instr(r0)
    //     0x12e58e8: sbfx            x1, x0, #1, #0x1f
    // 0x12e58ec: mov             x0, x1
    // 0x12e58f0: ldur            x1, [fp, #-0x58]
    // 0x12e58f4: cmp             x1, x0
    // 0x12e58f8: b.hs            #0x12e5ab0
    // 0x12e58fc: ldur            x3, [fp, #-0x58]
    // 0x12e5900: ArrayLoad: r0 = r2[r3]  ; List_8
    //     0x12e5900: add             x16, x2, x3, lsl #3
    //     0x12e5904: ldur            x0, [x16, #0x17]
    // 0x12e5908: ldur            x1, [fp, #-0x70]
    // 0x12e590c: add             x2, x1, x0
    // 0x12e5910: ldur            x0, [fp, #-0x60]
    // 0x12e5914: mov             x1, x3
    // 0x12e5918: cmp             x1, x0
    // 0x12e591c: b.hs            #0x12e5ab4
    // 0x12e5920: ldur            x0, [fp, #-0x20]
    // 0x12e5924: ArrayLoad: r1 = r0[r3]  ; List_8
    //     0x12e5924: add             x16, x0, x3, lsl #3
    //     0x12e5928: ldur            x1, [x16, #0x17]
    // 0x12e592c: add             x4, x2, x1
    // 0x12e5930: ldur            x2, [fp, #-8]
    // 0x12e5934: stur            x4, [fp, #-0x70]
    // 0x12e5938: r1 = 28
    //     0x12e5938: mov             x1, #0x1c
    // 0x12e593c: r0 = _rotr64()
    //     0x12e593c: bl              #0x12e5ab8  ; [package:crypto/src/sha512_fastsinks.dart] _Sha64BitSink::_rotr64
    // 0x12e5940: ldur            x2, [fp, #-8]
    // 0x12e5944: r1 = 34
    //     0x12e5944: mov             x1, #0x22
    // 0x12e5948: stur            x0, [fp, #-0x78]
    // 0x12e594c: r0 = _rotr64()
    //     0x12e594c: bl              #0x12e5ab8  ; [package:crypto/src/sha512_fastsinks.dart] _Sha64BitSink::_rotr64
    // 0x12e5950: mov             x1, x0
    // 0x12e5954: ldur            x0, [fp, #-0x78]
    // 0x12e5958: eor             x3, x0, x1
    // 0x12e595c: ldur            x2, [fp, #-8]
    // 0x12e5960: stur            x3, [fp, #-0x80]
    // 0x12e5964: r1 = 39
    //     0x12e5964: mov             x1, #0x27
    // 0x12e5968: r0 = _rotr64()
    //     0x12e5968: bl              #0x12e5ab8  ; [package:crypto/src/sha512_fastsinks.dart] _Sha64BitSink::_rotr64
    // 0x12e596c: ldur            x1, [fp, #-0x80]
    // 0x12e5970: eor             x2, x1, x0
    // 0x12e5974: ldur            x11, [fp, #-8]
    // 0x12e5978: ldur            x10, [fp, #-0x10]
    // 0x12e597c: and             x1, x11, x10
    // 0x12e5980: ldur            x9, [fp, #-0x18]
    // 0x12e5984: and             x3, x11, x9
    // 0x12e5988: eor             x4, x1, x3
    // 0x12e598c: and             x1, x10, x9
    // 0x12e5990: eor             x3, x4, x1
    // 0x12e5994: add             x1, x2, x3
    // 0x12e5998: ldur            x3, [fp, #-0x30]
    // 0x12e599c: ldur            x2, [fp, #-0x70]
    // 0x12e59a0: add             x8, x3, x2
    // 0x12e59a4: add             x13, x2, x1
    // 0x12e59a8: ldur            x1, [fp, #-0x58]
    // 0x12e59ac: add             x0, x1, #1
    // 0x12e59b0: ldur            x7, [fp, #-0x38]
    // 0x12e59b4: ldur            x6, [fp, #-0x40]
    // 0x12e59b8: ldur            x5, [fp, #-0x48]
    // 0x12e59bc: ldur            x3, [fp, #-0x68]
    // 0x12e59c0: ldur            x4, [fp, #-0x20]
    // 0x12e59c4: ldur            x12, [fp, #-0x60]
    // 0x12e59c8: b               #0x12e5818
    // 0x12e59cc: mov             x0, x5
    // 0x12e59d0: mov             x5, x3
    // 0x12e59d4: mov             x3, x9
    // 0x12e59d8: mov             x9, x10
    // 0x12e59dc: mov             x10, x11
    // 0x12e59e0: mov             x11, x13
    // 0x12e59e4: mov             x2, x8
    // 0x12e59e8: mov             x1, x7
    // 0x12e59ec: mov             x4, x6
    // 0x12e59f0: ArrayLoad: r6 = r5[0]  ; List_8
    //     0x12e59f0: ldur            x6, [x5, #0x17]
    // 0x12e59f4: add             x7, x6, x11
    // 0x12e59f8: ArrayStore: r5[0] = r7  ; List_8
    //     0x12e59f8: stur            x7, [x5, #0x17]
    // 0x12e59fc: LoadField: r6 = r5->field_1f
    //     0x12e59fc: ldur            x6, [x5, #0x1f]
    // 0x12e5a00: add             x7, x6, x10
    // 0x12e5a04: StoreField: r5->field_1f = r7
    //     0x12e5a04: stur            x7, [x5, #0x1f]
    // 0x12e5a08: LoadField: r6 = r5->field_27
    //     0x12e5a08: ldur            x6, [x5, #0x27]
    // 0x12e5a0c: add             x7, x6, x9
    // 0x12e5a10: StoreField: r5->field_27 = r7
    //     0x12e5a10: stur            x7, [x5, #0x27]
    // 0x12e5a14: LoadField: r6 = r5->field_2f
    //     0x12e5a14: ldur            x6, [x5, #0x2f]
    // 0x12e5a18: add             x7, x6, x3
    // 0x12e5a1c: StoreField: r5->field_2f = r7
    //     0x12e5a1c: stur            x7, [x5, #0x2f]
    // 0x12e5a20: LoadField: r3 = r5->field_37
    //     0x12e5a20: ldur            x3, [x5, #0x37]
    // 0x12e5a24: add             x6, x3, x2
    // 0x12e5a28: StoreField: r5->field_37 = r6
    //     0x12e5a28: stur            x6, [x5, #0x37]
    // 0x12e5a2c: LoadField: r2 = r5->field_3f
    //     0x12e5a2c: ldur            x2, [x5, #0x3f]
    // 0x12e5a30: add             x3, x2, x1
    // 0x12e5a34: StoreField: r5->field_3f = r3
    //     0x12e5a34: stur            x3, [x5, #0x3f]
    // 0x12e5a38: LoadField: r1 = r5->field_47
    //     0x12e5a38: ldur            x1, [x5, #0x47]
    // 0x12e5a3c: add             x2, x1, x4
    // 0x12e5a40: StoreField: r5->field_47 = r2
    //     0x12e5a40: stur            x2, [x5, #0x47]
    // 0x12e5a44: LoadField: r1 = r5->field_4f
    //     0x12e5a44: ldur            x1, [x5, #0x4f]
    // 0x12e5a48: add             x2, x1, x0
    // 0x12e5a4c: StoreField: r5->field_4f = r2
    //     0x12e5a4c: stur            x2, [x5, #0x4f]
    // 0x12e5a50: r0 = Null
    //     0x12e5a50: mov             x0, NULL
    // 0x12e5a54: LeaveFrame
    //     0x12e5a54: mov             SP, fp
    //     0x12e5a58: ldp             fp, lr, [SP], #0x10
    // 0x12e5a5c: ret
    //     0x12e5a5c: ret             
    // 0x12e5a60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e5a60: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e5a64: b               #0x12e5560
    // 0x12e5a68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e5a68: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e5a6c: b               #0x12e5590
    // 0x12e5a70: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12e5a70: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12e5a74: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12e5a74: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12e5a78: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12e5a78: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12e5a7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e5a7c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e5a80: b               #0x12e5628
    // 0x12e5a84: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12e5a84: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12e5a88: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12e5a88: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12e5a8c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12e5a8c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12e5a90: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12e5a90: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12e5a94: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12e5a94: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12e5a98: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12e5a98: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12e5a9c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12e5a9c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12e5aa0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12e5aa0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12e5aa4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12e5aa4: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12e5aa8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e5aa8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e5aac: b               #0x12e5848
    // 0x12e5ab0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12e5ab0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12e5ab4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12e5ab4: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  static _ _rotr64(/* No info */) {
    // ** addr: 0x12e5ab8, size: 0xd4
    // 0x12e5ab8: EnterFrame
    //     0x12e5ab8: stp             fp, lr, [SP, #-0x10]!
    //     0x12e5abc: mov             fp, SP
    // 0x12e5ac0: r4 = -1
    //     0x12e5ac0: mov             x4, #-1
    // 0x12e5ac4: r3 = 64
    //     0x12e5ac4: mov             x3, #0x40
    // 0x12e5ac8: cmp             x1, #0x3f
    // 0x12e5acc: b.hi            #0x12e5b08
    // 0x12e5ad0: asr             x5, x2, x1
    // 0x12e5ad4: sub             x6, x3, x1
    // 0x12e5ad8: cmp             x6, #0x3f
    // 0x12e5adc: b.hi            #0x12e5b34
    // 0x12e5ae0: lsl             x1, x4, x6
    // 0x12e5ae4: mvn             x3, x1
    // 0x12e5ae8: and             x1, x5, x3
    // 0x12e5aec: cmp             x6, #0x3f
    // 0x12e5af0: b.hi            #0x12e5b60
    // 0x12e5af4: lsl             x3, x2, x6
    // 0x12e5af8: orr             x0, x1, x3
    // 0x12e5afc: LeaveFrame
    //     0x12e5afc: mov             SP, fp
    //     0x12e5b00: ldp             fp, lr, [SP], #0x10
    // 0x12e5b04: ret
    //     0x12e5b04: ret             
    // 0x12e5b08: tbnz            x1, #0x3f, #0x12e5b14
    // 0x12e5b0c: asr             x5, x2, #0x3f
    // 0x12e5b10: b               #0x12e5ad4
    // 0x12e5b14: str             x1, [THR, #0x8a0]  ; THR::
    // 0x12e5b18: stp             x3, x4, [SP, #-0x10]!
    // 0x12e5b1c: stp             x1, x2, [SP, #-0x10]!
    // 0x12e5b20: ldr             x5, [THR, #0x470]  ; THR::ArgumentErrorUnboxedInt64
    // 0x12e5b24: r4 = 0
    //     0x12e5b24: mov             x4, #0
    // 0x12e5b28: ldr             lr, [THR, #0x210]  ; THR::call_to_runtime_entry_point
    // 0x12e5b2c: blr             lr
    // 0x12e5b30: brk             #0
    // 0x12e5b34: tbnz            x6, #0x3f, #0x12e5b40
    // 0x12e5b38: mov             x1, xzr
    // 0x12e5b3c: b               #0x12e5ae4
    // 0x12e5b40: str             x6, [THR, #0x8a0]  ; THR::
    // 0x12e5b44: stp             x5, x6, [SP, #-0x10]!
    // 0x12e5b48: stp             x2, x4, [SP, #-0x10]!
    // 0x12e5b4c: ldr             x5, [THR, #0x470]  ; THR::ArgumentErrorUnboxedInt64
    // 0x12e5b50: r4 = 0
    //     0x12e5b50: mov             x4, #0
    // 0x12e5b54: ldr             lr, [THR, #0x210]  ; THR::call_to_runtime_entry_point
    // 0x12e5b58: blr             lr
    // 0x12e5b5c: brk             #0
    // 0x12e5b60: tbnz            x6, #0x3f, #0x12e5b6c
    // 0x12e5b64: mov             x3, xzr
    // 0x12e5b68: b               #0x12e5af8
    // 0x12e5b6c: str             x6, [THR, #0x8a0]  ; THR::
    // 0x12e5b70: stp             x2, x6, [SP, #-0x10]!
    // 0x12e5b74: SaveReg r1
    //     0x12e5b74: str             x1, [SP, #-8]!
    // 0x12e5b78: ldr             x5, [THR, #0x470]  ; THR::ArgumentErrorUnboxedInt64
    // 0x12e5b7c: r4 = 0
    //     0x12e5b7c: mov             x4, #0
    // 0x12e5b80: ldr             lr, [THR, #0x210]  ; THR::call_to_runtime_entry_point
    // 0x12e5b84: blr             lr
    // 0x12e5b88: brk             #0
  }
  get _ digest(/* No info */) {
    // ** addr: 0x12e9a48, size: 0x154
    // 0x12e9a48: EnterFrame
    //     0x12e9a48: stp             fp, lr, [SP, #-0x10]!
    //     0x12e9a4c: mov             fp, SP
    // 0x12e9a50: AllocStack(0x20)
    //     0x12e9a50: sub             SP, SP, #0x20
    // 0x12e9a54: SetupParameters(_Sha64BitSink this /* r1 => r1, fp-0x10 */)
    //     0x12e9a54: stur            x1, [fp, #-0x10]
    // 0x12e9a58: CheckStackOverflow
    //     0x12e9a58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e9a5c: cmp             SP, x16
    //     0x12e9a60: b.ls            #0x12e9b84
    // 0x12e9a64: LoadField: r0 = r1->field_37
    //     0x12e9a64: ldur            w0, [x1, #0x37]
    // 0x12e9a68: DecompressPointer r0
    //     0x12e9a68: add             x0, x0, HEAP, lsl #32
    // 0x12e9a6c: stur            x0, [fp, #-8]
    // 0x12e9a70: r0 = _ByteBuffer()
    //     0x12e9a70: bl              #0x7e9024  ; Allocate_ByteBufferStub -> _ByteBuffer (size=0xc)
    // 0x12e9a74: mov             x1, x0
    // 0x12e9a78: ldur            x0, [fp, #-8]
    // 0x12e9a7c: StoreField: r1->field_7 = r0
    //     0x12e9a7c: stur            w0, [x1, #7]
    // 0x12e9a80: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x12e9a80: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x12e9a84: r0 = asUint32List()
    //     0x12e9a84: bl              #0x139f100  ; [dart:typed_data] _ByteBuffer::asUint32List
    // 0x12e9a88: mov             x3, x0
    // 0x12e9a8c: ldur            x2, [fp, #-0x10]
    // 0x12e9a90: stur            x3, [fp, #-8]
    // 0x12e9a94: r5 = LoadClassIdInstr(r2)
    //     0x12e9a94: ldur            x5, [x2, #-1]
    //     0x12e9a98: ubfx            x5, x5, #0xc, #0x14
    // 0x12e9a9c: stur            x5, [fp, #-0x20]
    // 0x12e9aa0: cmp             x5, #0xddd
    // 0x12e9aa4: b.ne            #0x12e9ab4
    // 0x12e9aa8: LoadField: r0 = r2->field_3f
    //     0x12e9aa8: ldur            x0, [x2, #0x3f]
    // 0x12e9aac: mov             x6, x0
    // 0x12e9ab0: b               #0x12e9abc
    // 0x12e9ab4: LoadField: r0 = r2->field_3f
    //     0x12e9ab4: ldur            x0, [x2, #0x3f]
    // 0x12e9ab8: mov             x6, x0
    // 0x12e9abc: stur            x6, [fp, #-0x18]
    // 0x12e9ac0: r0 = BoxInt64Instr(r6)
    //     0x12e9ac0: sbfiz           x0, x6, #1, #0x1f
    //     0x12e9ac4: cmp             x6, x0, asr #1
    //     0x12e9ac8: b.eq            #0x12e9ad4
    //     0x12e9acc: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12e9ad0: stur            x6, [x0, #7]
    // 0x12e9ad4: mov             x4, x0
    // 0x12e9ad8: r0 = AllocateUint32Array()
    //     0x12e9ad8: bl              #0x13df228  ; AllocateUint32ArrayStub
    // 0x12e9adc: mov             x3, x0
    // 0x12e9ae0: ldur            x2, [fp, #-8]
    // 0x12e9ae4: LoadField: r4 = r2->field_13
    //     0x12e9ae4: ldur            w4, [x2, #0x13]
    // 0x12e9ae8: r5 = LoadInt32Instr(r4)
    //     0x12e9ae8: sbfx            x5, x4, #1, #0x1f
    // 0x12e9aec: ldur            x4, [fp, #-0x10]
    // 0x12e9af0: ldur            x6, [fp, #-0x20]
    // 0x12e9af4: r7 = 0
    //     0x12e9af4: mov             x7, #0
    // 0x12e9af8: CheckStackOverflow
    //     0x12e9af8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e9afc: cmp             SP, x16
    //     0x12e9b00: b.ls            #0x12e9b8c
    // 0x12e9b04: cmp             x6, #0xddd
    // 0x12e9b08: b.ne            #0x12e9b14
    // 0x12e9b0c: LoadField: r8 = r4->field_3f
    //     0x12e9b0c: ldur            x8, [x4, #0x3f]
    // 0x12e9b10: b               #0x12e9b18
    // 0x12e9b14: LoadField: r8 = r4->field_3f
    //     0x12e9b14: ldur            x8, [x4, #0x3f]
    // 0x12e9b18: cmp             x7, x8
    // 0x12e9b1c: b.ge            #0x12e9b74
    // 0x12e9b20: tbnz            w7, #0, #0x12e9b2c
    // 0x12e9b24: r8 = 1
    //     0x12e9b24: mov             x8, #1
    // 0x12e9b28: b               #0x12e9b30
    // 0x12e9b2c: r8 = -1
    //     0x12e9b2c: mov             x8, #-1
    // 0x12e9b30: add             x9, x7, x8
    // 0x12e9b34: mov             x0, x5
    // 0x12e9b38: mov             x1, x9
    // 0x12e9b3c: cmp             x1, x0
    // 0x12e9b40: b.hs            #0x12e9b94
    // 0x12e9b44: LoadField: r8 = r2->field_7
    //     0x12e9b44: ldur            x8, [x2, #7]
    // 0x12e9b48: add             x16, x8, x9, lsl #2
    // 0x12e9b4c: ldr             w10, [x16]
    // 0x12e9b50: ldur            x0, [fp, #-0x18]
    // 0x12e9b54: mov             x1, x7
    // 0x12e9b58: cmp             x1, x0
    // 0x12e9b5c: b.hs            #0x12e9b98
    // 0x12e9b60: ArrayStore: r3[r7] = r10  ; List_4
    //     0x12e9b60: add             x1, x3, x7, lsl #2
    //     0x12e9b64: stur            w10, [x1, #0x17]
    // 0x12e9b68: add             x0, x7, #1
    // 0x12e9b6c: mov             x7, x0
    // 0x12e9b70: b               #0x12e9af8
    // 0x12e9b74: mov             x0, x3
    // 0x12e9b78: LeaveFrame
    //     0x12e9b78: mov             SP, fp
    //     0x12e9b7c: ldp             fp, lr, [SP], #0x10
    // 0x12e9b80: ret
    //     0x12e9b80: ret             
    // 0x12e9b84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e9b84: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e9b88: b               #0x12e9a64
    // 0x12e9b8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e9b8c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e9b90: b               #0x12e9b04
    // 0x12e9b94: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12e9b94: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12e9b98: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12e9b98: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
}

// class id: 3549, size: 0x48, field offset: 0x40
class Sha512Sink extends _Sha64BitSink {

  _ Sha512Sink(/* No info */) {
    // ** addr: 0x121dcdc, size: 0x10c
    // 0x121dcdc: EnterFrame
    //     0x121dcdc: stp             fp, lr, [SP, #-0x10]!
    //     0x121dce0: mov             fp, SP
    // 0x121dce4: AllocStack(0x20)
    //     0x121dce4: sub             SP, SP, #0x20
    // 0x121dce8: r3 = 16
    //     0x121dce8: mov             x3, #0x10
    // 0x121dcec: r0 = 16
    //     0x121dcec: mov             x0, #0x10
    // 0x121dcf0: mov             x5, x1
    // 0x121dcf4: mov             x4, x2
    // 0x121dcf8: stur            x1, [fp, #-8]
    // 0x121dcfc: stur            x2, [fp, #-0x10]
    // 0x121dd00: CheckStackOverflow
    //     0x121dd00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x121dd04: cmp             SP, x16
    //     0x121dd08: b.ls            #0x121dde0
    // 0x121dd0c: StoreField: r5->field_3f = r0
    //     0x121dd0c: stur            x0, [x5, #0x3f]
    // 0x121dd10: mov             x2, x3
    // 0x121dd14: r1 = Null
    //     0x121dd14: mov             x1, NULL
    // 0x121dd18: r0 = AllocateArray()
    //     0x121dd18: bl              #0x13df928  ; AllocateArrayStub
    // 0x121dd1c: stur            x0, [fp, #-0x18]
    // 0x121dd20: r16 = 7640891576956012808
    //     0x121dd20: add             x16, PP, #0xb3, lsl #12  ; [pp+0xb3fd0] 0x6a09e667f3bcc908
    //     0x121dd24: ldr             x16, [x16, #0xfd0]
    // 0x121dd28: StoreField: r0->field_f = r16
    //     0x121dd28: stur            w16, [x0, #0xf]
    // 0x121dd2c: r16 = -4942790177534073029
    //     0x121dd2c: add             x16, PP, #0xb3, lsl #12  ; [pp+0xb3fd8] -0x4498517a7b3558c5
    //     0x121dd30: ldr             x16, [x16, #0xfd8]
    // 0x121dd34: StoreField: r0->field_13 = r16
    //     0x121dd34: stur            w16, [x0, #0x13]
    // 0x121dd38: r16 = 4354685564936845355
    //     0x121dd38: add             x16, PP, #0xb3, lsl #12  ; [pp+0xb3fe0] 0x3c6ef372fe94f82b
    //     0x121dd3c: ldr             x16, [x16, #0xfe0]
    // 0x121dd40: ArrayStore: r0[0] = r16  ; List_4
    //     0x121dd40: stur            w16, [x0, #0x17]
    // 0x121dd44: r16 = -6534734903238641935
    //     0x121dd44: add             x16, PP, #0xb3, lsl #12  ; [pp+0xb3fe8] -0x5ab00ac5a0e2c90f
    //     0x121dd48: ldr             x16, [x16, #0xfe8]
    // 0x121dd4c: StoreField: r0->field_1b = r16
    //     0x121dd4c: stur            w16, [x0, #0x1b]
    // 0x121dd50: r16 = 5840696475078001361
    //     0x121dd50: add             x16, PP, #0xb3, lsl #12  ; [pp+0xb3ff0] 0x510e527fade682d1
    //     0x121dd54: ldr             x16, [x16, #0xff0]
    // 0x121dd58: StoreField: r0->field_1f = r16
    //     0x121dd58: stur            w16, [x0, #0x1f]
    // 0x121dd5c: r16 = -7276294671716946913
    //     0x121dd5c: add             x16, PP, #0xb3, lsl #12  ; [pp+0xb3ff8] -0x64fa9773d4c193e1
    //     0x121dd60: ldr             x16, [x16, #0xff8]
    // 0x121dd64: StoreField: r0->field_23 = r16
    //     0x121dd64: stur            w16, [x0, #0x23]
    // 0x121dd68: r16 = 2270897969802886507
    //     0x121dd68: add             x16, PP, #0xb4, lsl #12  ; [pp+0xb4000] 0x1f83d9abfb41bd6b
    //     0x121dd6c: ldr             x16, [x16]
    // 0x121dd70: StoreField: r0->field_27 = r16
    //     0x121dd70: stur            w16, [x0, #0x27]
    // 0x121dd74: r16 = 6620516959819538809
    //     0x121dd74: add             x16, PP, #0xb4, lsl #12  ; [pp+0xb4008] 0x5be0cd19137e2179
    //     0x121dd78: ldr             x16, [x16, #8]
    // 0x121dd7c: StoreField: r0->field_2b = r16
    //     0x121dd7c: stur            w16, [x0, #0x2b]
    // 0x121dd80: r1 = <int>
    //     0x121dd80: ldr             x1, [PP, #0x50]  ; [pp+0x50] TypeArguments: <int>
    // 0x121dd84: r0 = AllocateGrowableArray()
    //     0x121dd84: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x121dd88: mov             x1, x0
    // 0x121dd8c: ldur            x0, [fp, #-0x18]
    // 0x121dd90: stur            x1, [fp, #-0x20]
    // 0x121dd94: StoreField: r1->field_f = r0
    //     0x121dd94: stur            w0, [x1, #0xf]
    // 0x121dd98: r4 = 16
    //     0x121dd98: mov             x4, #0x10
    // 0x121dd9c: StoreField: r1->field_b = r4
    //     0x121dd9c: stur            w4, [x1, #0xb]
    // 0x121dda0: r0 = AllocateUint64Array()
    //     0x121dda0: bl              #0x13df0a8  ; AllocateUint64ArrayStub
    // 0x121dda4: mov             x1, x0
    // 0x121dda8: ldur            x5, [fp, #-0x20]
    // 0x121ddac: r2 = 0
    //     0x121ddac: mov             x2, #0
    // 0x121ddb0: r3 = 8
    //     0x121ddb0: mov             x3, #8
    // 0x121ddb4: r6 = 0
    //     0x121ddb4: mov             x6, #0
    // 0x121ddb8: stur            x0, [fp, #-0x18]
    // 0x121ddbc: r0 = _slowSetRange()
    //     0x121ddbc: bl              #0x117828c  ; [dart:typed_data] __Uint64List&_TypedList&_IntListMixin&_TypedIntListMixin::_slowSetRange
    // 0x121ddc0: ldur            x1, [fp, #-8]
    // 0x121ddc4: ldur            x2, [fp, #-0x10]
    // 0x121ddc8: ldur            x3, [fp, #-0x18]
    // 0x121ddcc: r0 = _Sha64BitSink()
    //     0x121ddcc: bl              #0x121db6c  ; [package:crypto/src/sha512_fastsinks.dart] _Sha64BitSink::_Sha64BitSink
    // 0x121ddd0: r0 = Null
    //     0x121ddd0: mov             x0, NULL
    // 0x121ddd4: LeaveFrame
    //     0x121ddd4: mov             SP, fp
    //     0x121ddd8: ldp             fp, lr, [SP], #0x10
    // 0x121dddc: ret
    //     0x121dddc: ret             
    // 0x121dde0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x121dde0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x121dde4: b               #0x121dd0c
  }
}

// class id: 3550, size: 0x48, field offset: 0x40
class Sha384Sink extends _Sha64BitSink {

  _ Sha384Sink(/* No info */) {
    // ** addr: 0x121da60, size: 0x10c
    // 0x121da60: EnterFrame
    //     0x121da60: stp             fp, lr, [SP, #-0x10]!
    //     0x121da64: mov             fp, SP
    // 0x121da68: AllocStack(0x20)
    //     0x121da68: sub             SP, SP, #0x20
    // 0x121da6c: r3 = 16
    //     0x121da6c: mov             x3, #0x10
    // 0x121da70: r0 = 12
    //     0x121da70: mov             x0, #0xc
    // 0x121da74: mov             x5, x1
    // 0x121da78: mov             x4, x2
    // 0x121da7c: stur            x1, [fp, #-8]
    // 0x121da80: stur            x2, [fp, #-0x10]
    // 0x121da84: CheckStackOverflow
    //     0x121da84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x121da88: cmp             SP, x16
    //     0x121da8c: b.ls            #0x121db64
    // 0x121da90: StoreField: r5->field_3f = r0
    //     0x121da90: stur            x0, [x5, #0x3f]
    // 0x121da94: mov             x2, x3
    // 0x121da98: r1 = Null
    //     0x121da98: mov             x1, NULL
    // 0x121da9c: r0 = AllocateArray()
    //     0x121da9c: bl              #0x13df928  ; AllocateArrayStub
    // 0x121daa0: stur            x0, [fp, #-0x18]
    // 0x121daa4: r16 = -3766243637369397544
    //     0x121daa4: add             x16, PP, #0xb4, lsl #12  ; [pp+0xb4010] -0x344462a23efa6128
    //     0x121daa8: ldr             x16, [x16, #0x10]
    // 0x121daac: StoreField: r0->field_f = r16
    //     0x121daac: stur            w16, [x0, #0xf]
    // 0x121dab0: r16 = 7105036623409894663
    //     0x121dab0: add             x16, PP, #0xb4, lsl #12  ; [pp+0xb4018] 0x629a292a367cd507
    //     0x121dab4: ldr             x16, [x16, #0x18]
    // 0x121dab8: StoreField: r0->field_13 = r16
    //     0x121dab8: stur            w16, [x0, #0x13]
    // 0x121dabc: r16 = -7973340178411365097
    //     0x121dabc: add             x16, PP, #0xb4, lsl #12  ; [pp+0xb4020] -0x6ea6fea5cf8f22e9
    //     0x121dac0: ldr             x16, [x16, #0x20]
    // 0x121dac4: ArrayStore: r0[0] = r16  ; List_4
    //     0x121dac4: stur            w16, [x0, #0x17]
    // 0x121dac8: r16 = 1526699215303891257
    //     0x121dac8: add             x16, PP, #0xb4, lsl #12  ; [pp+0xb4028] 0x152fecd8f70e5939
    //     0x121dacc: ldr             x16, [x16, #0x28]
    // 0x121dad0: StoreField: r0->field_1b = r16
    //     0x121dad0: stur            w16, [x0, #0x1b]
    // 0x121dad4: r16 = 7436329637833083697
    //     0x121dad4: add             x16, PP, #0xb4, lsl #12  ; [pp+0xb4030] 0x67332667ffc00b31
    //     0x121dad8: ldr             x16, [x16, #0x30]
    // 0x121dadc: StoreField: r0->field_1f = r16
    //     0x121dadc: stur            w16, [x0, #0x1f]
    // 0x121dae0: r16 = -8163818279084223215
    //     0x121dae0: add             x16, PP, #0xb4, lsl #12  ; [pp+0xb4038] -0x714bb57897a7eaef
    //     0x121dae4: ldr             x16, [x16, #0x38]
    // 0x121dae8: StoreField: r0->field_23 = r16
    //     0x121dae8: stur            w16, [x0, #0x23]
    // 0x121daec: r16 = -2662702644619276377
    //     0x121daec: add             x16, PP, #0xb4, lsl #12  ; [pp+0xb4040] -0x24f3d1f29b067059
    //     0x121daf0: ldr             x16, [x16, #0x40]
    // 0x121daf4: StoreField: r0->field_27 = r16
    //     0x121daf4: stur            w16, [x0, #0x27]
    // 0x121daf8: r16 = 5167115440072839076
    //     0x121daf8: add             x16, PP, #0xb4, lsl #12  ; [pp+0xb4048] 0x47b5481dbefa4fa4
    //     0x121dafc: ldr             x16, [x16, #0x48]
    // 0x121db00: StoreField: r0->field_2b = r16
    //     0x121db00: stur            w16, [x0, #0x2b]
    // 0x121db04: r1 = <int>
    //     0x121db04: ldr             x1, [PP, #0x50]  ; [pp+0x50] TypeArguments: <int>
    // 0x121db08: r0 = AllocateGrowableArray()
    //     0x121db08: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x121db0c: mov             x1, x0
    // 0x121db10: ldur            x0, [fp, #-0x18]
    // 0x121db14: stur            x1, [fp, #-0x20]
    // 0x121db18: StoreField: r1->field_f = r0
    //     0x121db18: stur            w0, [x1, #0xf]
    // 0x121db1c: r4 = 16
    //     0x121db1c: mov             x4, #0x10
    // 0x121db20: StoreField: r1->field_b = r4
    //     0x121db20: stur            w4, [x1, #0xb]
    // 0x121db24: r0 = AllocateUint64Array()
    //     0x121db24: bl              #0x13df0a8  ; AllocateUint64ArrayStub
    // 0x121db28: mov             x1, x0
    // 0x121db2c: ldur            x5, [fp, #-0x20]
    // 0x121db30: r2 = 0
    //     0x121db30: mov             x2, #0
    // 0x121db34: r3 = 8
    //     0x121db34: mov             x3, #8
    // 0x121db38: r6 = 0
    //     0x121db38: mov             x6, #0
    // 0x121db3c: stur            x0, [fp, #-0x18]
    // 0x121db40: r0 = _slowSetRange()
    //     0x121db40: bl              #0x117828c  ; [dart:typed_data] __Uint64List&_TypedList&_IntListMixin&_TypedIntListMixin::_slowSetRange
    // 0x121db44: ldur            x1, [fp, #-8]
    // 0x121db48: ldur            x2, [fp, #-0x10]
    // 0x121db4c: ldur            x3, [fp, #-0x18]
    // 0x121db50: r0 = _Sha64BitSink()
    //     0x121db50: bl              #0x121db6c  ; [package:crypto/src/sha512_fastsinks.dart] _Sha64BitSink::_Sha64BitSink
    // 0x121db54: r0 = Null
    //     0x121db54: mov             x0, NULL
    // 0x121db58: LeaveFrame
    //     0x121db58: mov             SP, fp
    //     0x121db5c: ldp             fp, lr, [SP], #0x10
    // 0x121db60: ret
    //     0x121db60: ret             
    // 0x121db64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x121db64: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x121db68: b               #0x121da90
  }
}
