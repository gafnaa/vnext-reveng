// lib: , url: package:crypto/src/hash.dart

// class id: 1048673, size: 0x8
class :: {
}

// class id: 7323, size: 0xc, field offset: 0xc
//   const constructor, 
abstract class Hash extends Converter<dynamic, dynamic> {

  _ convert(/* No info */) {
    // ** addr: 0x12241fc, size: 0xb0
    // 0x12241fc: EnterFrame
    //     0x12241fc: stp             fp, lr, [SP, #-0x10]!
    //     0x1224200: mov             fp, SP
    // 0x1224204: AllocStack(0x18)
    //     0x1224204: sub             SP, SP, #0x18
    // 0x1224208: SetupParameters(Hash this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x1224208: mov             x4, x1
    //     0x122420c: mov             x3, x2
    //     0x1224210: stur            x1, [fp, #-8]
    //     0x1224214: stur            x2, [fp, #-0x10]
    // 0x1224218: CheckStackOverflow
    //     0x1224218: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x122421c: cmp             SP, x16
    //     0x1224220: b.ls            #0x12242a0
    // 0x1224224: mov             x0, x3
    // 0x1224228: r2 = Null
    //     0x1224228: mov             x2, NULL
    // 0x122422c: r1 = Null
    //     0x122422c: mov             x1, NULL
    // 0x1224230: r8 = List<int>
    //     0x1224230: ldr             x8, [PP, #0x13e8]  ; [pp+0x13e8] Type: List<int>
    // 0x1224234: r3 = Null
    //     0x1224234: add             x3, PP, #0x14, lsl #12  ; [pp+0x14010] Null
    //     0x1224238: ldr             x3, [x3, #0x10]
    // 0x122423c: r0 = List<int>()
    //     0x122423c: bl              #0x7fd2a4  ; IsType_List<int>_Stub
    // 0x1224240: r0 = DigestSink()
    //     0x1224240: bl              #0xa26f50  ; AllocateDigestSinkStub -> DigestSink (size=0xc)
    // 0x1224244: mov             x3, x0
    // 0x1224248: ldur            x1, [fp, #-8]
    // 0x122424c: stur            x3, [fp, #-0x18]
    // 0x1224250: r0 = LoadClassIdInstr(r1)
    //     0x1224250: ldur            x0, [x1, #-1]
    //     0x1224254: ubfx            x0, x0, #0xc, #0x14
    // 0x1224258: mov             x2, x3
    // 0x122425c: r0 = GDT[cid_x0 + 0xb37]()
    //     0x122425c: add             lr, x0, #0xb37
    //     0x1224260: ldr             lr, [x21, lr, lsl #3]
    //     0x1224264: blr             lr
    // 0x1224268: mov             x1, x0
    // 0x122426c: ldur            x2, [fp, #-0x10]
    // 0x1224270: stur            x0, [fp, #-8]
    // 0x1224274: r0 = add()
    //     0x1224274: bl              #0x809264  ; [dart:convert] _ByteAdapterSink::add
    // 0x1224278: ldur            x1, [fp, #-8]
    // 0x122427c: r0 = close()
    //     0x122427c: bl              #0x8149b0  ; [dart:_http] _Uint8ListConversionSink::close
    // 0x1224280: ldur            x1, [fp, #-0x18]
    // 0x1224284: LoadField: r0 = r1->field_7
    //     0x1224284: ldur            w0, [x1, #7]
    // 0x1224288: DecompressPointer r0
    //     0x1224288: add             x0, x0, HEAP, lsl #32
    // 0x122428c: cmp             w0, NULL
    // 0x1224290: b.eq            #0x12242a8
    // 0x1224294: LeaveFrame
    //     0x1224294: mov             SP, fp
    //     0x1224298: ldp             fp, lr, [SP], #0x10
    // 0x122429c: ret
    //     0x122429c: ret             
    // 0x12242a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12242a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12242a4: b               #0x1224224
    // 0x12242a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12242a8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}
