// lib: , url: package:crypto/src/sha256.dart

// class id: 1048677, size: 0x8
class :: {
}

// class id: 3551, size: 0x40, field offset: 0x38
abstract class _Sha32BitSink extends HashSink {

  _ _Sha32BitSink(/* No info */) {
    // ** addr: 0x121d8f0, size: 0x114
    // 0x121d8f0: EnterFrame
    //     0x121d8f0: stp             fp, lr, [SP, #-0x10]!
    //     0x121d8f4: mov             fp, SP
    // 0x121d8f8: AllocStack(0x18)
    //     0x121d8f8: sub             SP, SP, #0x18
    // 0x121d8fc: SetupParameters(_Sha32BitSink this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r16 */)
    //     0x121d8fc: stur            x1, [fp, #-8]
    //     0x121d900: mov             x16, x2
    //     0x121d904: mov             x2, x1
    // 0x121d908: mov             x1, x16
    // 0x121d90c: mov             x0, x3
    // 0x121d910: stur            x1, [fp, #-0x10]
    // 0x121d914: stur            x3, [fp, #-0x18]
    // 0x121d918: r4 = 128
    //     0x121d918: mov             x4, #0x80
    // 0x121d91c: r0 = AllocateUint32Array()
    //     0x121d91c: bl              #0x13df228  ; AllocateUint32ArrayStub
    // 0x121d920: ldur            x1, [fp, #-8]
    // 0x121d924: StoreField: r1->field_3b = r0
    //     0x121d924: stur            w0, [x1, #0x3b]
    //     0x121d928: ldurb           w16, [x1, #-1]
    //     0x121d92c: ldurb           w17, [x0, #-1]
    //     0x121d930: and             x16, x17, x16, lsr #2
    //     0x121d934: tst             x16, HEAP, lsr #32
    //     0x121d938: b.eq            #0x121d940
    //     0x121d93c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x121d940: ldur            x0, [fp, #-0x18]
    // 0x121d944: StoreField: r1->field_37 = r0
    //     0x121d944: stur            w0, [x1, #0x37]
    //     0x121d948: ldurb           w16, [x1, #-1]
    //     0x121d94c: ldurb           w17, [x0, #-1]
    //     0x121d950: and             x16, x17, x16, lsr #2
    //     0x121d954: tst             x16, HEAP, lsr #32
    //     0x121d958: b.eq            #0x121d960
    //     0x121d95c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x121d960: StoreField: r1->field_23 = rZR
    //     0x121d960: stur            xzr, [x1, #0x23]
    // 0x121d964: r0 = false
    //     0x121d964: add             x0, NULL, #0x30  ; false
    // 0x121d968: StoreField: r1->field_2b = r0
    //     0x121d968: stur            w0, [x1, #0x2b]
    // 0x121d96c: ldur            x0, [fp, #-0x10]
    // 0x121d970: StoreField: r1->field_7 = r0
    //     0x121d970: stur            w0, [x1, #7]
    //     0x121d974: ldurb           w16, [x1, #-1]
    //     0x121d978: ldurb           w17, [x0, #-1]
    //     0x121d97c: and             x16, x17, x16, lsr #2
    //     0x121d980: tst             x16, HEAP, lsr #32
    //     0x121d984: b.eq            #0x121d98c
    //     0x121d988: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x121d98c: r0 = Instance_Endian
    //     0x121d98c: add             x0, PP, #0x1f, lsl #12  ; [pp+0x1f788] Obj!Endian@12b7a01
    //     0x121d990: ldr             x0, [x0, #0x788]
    // 0x121d994: StoreField: r1->field_b = r0
    //     0x121d994: stur            w0, [x1, #0xb]
    // 0x121d998: r0 = 8
    //     0x121d998: mov             x0, #8
    // 0x121d99c: StoreField: r1->field_2f = r0
    //     0x121d99c: stur            x0, [x1, #0x2f]
    // 0x121d9a0: r4 = 128
    //     0x121d9a0: mov             x4, #0x80
    // 0x121d9a4: r0 = AllocateUint8Array()
    //     0x121d9a4: bl              #0x13df5f0  ; AllocateUint8ArrayStub
    // 0x121d9a8: ldur            x1, [fp, #-8]
    // 0x121d9ac: StoreField: r1->field_13 = r0
    //     0x121d9ac: stur            w0, [x1, #0x13]
    //     0x121d9b0: ldurb           w16, [x1, #-1]
    //     0x121d9b4: ldurb           w17, [x0, #-1]
    //     0x121d9b8: and             x16, x17, x16, lsr #2
    //     0x121d9bc: tst             x16, HEAP, lsr #32
    //     0x121d9c0: b.eq            #0x121d9c8
    //     0x121d9c4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x121d9c8: ArrayStore: r1[0] = rZR  ; List_8
    //     0x121d9c8: stur            xzr, [x1, #0x17]
    // 0x121d9cc: r4 = 32
    //     0x121d9cc: mov             x4, #0x20
    // 0x121d9d0: r0 = AllocateUint32Array()
    //     0x121d9d0: bl              #0x13df228  ; AllocateUint32ArrayStub
    // 0x121d9d4: ldur            x1, [fp, #-8]
    // 0x121d9d8: StoreField: r1->field_1f = r0
    //     0x121d9d8: stur            w0, [x1, #0x1f]
    //     0x121d9dc: ldurb           w16, [x1, #-1]
    //     0x121d9e0: ldurb           w17, [x0, #-1]
    //     0x121d9e4: and             x16, x17, x16, lsr #2
    //     0x121d9e8: tst             x16, HEAP, lsr #32
    //     0x121d9ec: b.eq            #0x121d9f4
    //     0x121d9f0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x121d9f4: r0 = Null
    //     0x121d9f4: mov             x0, NULL
    // 0x121d9f8: LeaveFrame
    //     0x121d9f8: mov             SP, fp
    //     0x121d9fc: ldp             fp, lr, [SP], #0x10
    // 0x121da00: ret
    //     0x121da00: ret             
  }
  _ updateHash(/* No info */) {
    // ** addr: 0x12e4fbc, size: 0x584
    // 0x12e4fbc: EnterFrame
    //     0x12e4fbc: stp             fp, lr, [SP, #-0x10]!
    //     0x12e4fc0: mov             fp, SP
    // 0x12e4fc4: AllocStack(0x38)
    //     0x12e4fc4: sub             SP, SP, #0x38
    // 0x12e4fc8: SetupParameters(_Sha32BitSink this /* r1 => r3 */)
    //     0x12e4fc8: mov             x3, x1
    // 0x12e4fcc: LoadField: r4 = r3->field_3b
    //     0x12e4fcc: ldur            w4, [x3, #0x3b]
    // 0x12e4fd0: DecompressPointer r4
    //     0x12e4fd0: add             x4, x4, HEAP, lsl #32
    // 0x12e4fd4: LoadField: r5 = r2->field_13
    //     0x12e4fd4: ldur            w5, [x2, #0x13]
    // 0x12e4fd8: r6 = LoadInt32Instr(r5)
    //     0x12e4fd8: sbfx            x6, x5, #1, #0x1f
    // 0x12e4fdc: LoadField: r5 = r4->field_13
    //     0x12e4fdc: ldur            w5, [x4, #0x13]
    // 0x12e4fe0: r7 = LoadInt32Instr(r5)
    //     0x12e4fe0: sbfx            x7, x5, #1, #0x1f
    // 0x12e4fe4: r5 = 0
    //     0x12e4fe4: mov             x5, #0
    // 0x12e4fe8: CheckStackOverflow
    //     0x12e4fe8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e4fec: cmp             SP, x16
    //     0x12e4ff0: b.ls            #0x12e54f8
    // 0x12e4ff4: cmp             x5, #0x10
    // 0x12e4ff8: b.ge            #0x12e5038
    // 0x12e4ffc: mov             x0, x6
    // 0x12e5000: mov             x1, x5
    // 0x12e5004: cmp             x1, x0
    // 0x12e5008: b.hs            #0x12e5500
    // 0x12e500c: ArrayLoad: r8 = r2[r5]  ; List_4
    //     0x12e500c: add             x16, x2, x5, lsl #2
    //     0x12e5010: ldur            w8, [x16, #0x17]
    // 0x12e5014: mov             x0, x7
    // 0x12e5018: mov             x1, x5
    // 0x12e501c: cmp             x1, x0
    // 0x12e5020: b.hs            #0x12e5504
    // 0x12e5024: ArrayStore: r4[r5] = r8  ; List_4
    //     0x12e5024: add             x9, x4, x5, lsl #2
    //     0x12e5028: stur            w8, [x9, #0x17]
    // 0x12e502c: add             x0, x5, #1
    // 0x12e5030: mov             x5, x0
    // 0x12e5034: b               #0x12e4fe8
    // 0x12e5038: LoadField: r2 = r4->field_13
    //     0x12e5038: ldur            w2, [x4, #0x13]
    // 0x12e503c: r5 = LoadInt32Instr(r2)
    //     0x12e503c: sbfx            x5, x2, #1, #0x1f
    // 0x12e5040: r2 = 16
    //     0x12e5040: mov             x2, #0x10
    // 0x12e5044: CheckStackOverflow
    //     0x12e5044: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e5048: cmp             SP, x16
    //     0x12e504c: b.ls            #0x12e5508
    // 0x12e5050: cmp             x2, #0x40
    // 0x12e5054: b.ge            #0x12e5128
    // 0x12e5058: sub             x6, x2, #2
    // 0x12e505c: ArrayLoad: r7 = r4[r6]  ; List_4
    //     0x12e505c: add             x16, x4, x6, lsl #2
    //     0x12e5060: ldur            w7, [x16, #0x17]
    // 0x12e5064: mov             x6, x7
    // 0x12e5068: ubfx            x6, x6, #0, #0x20
    // 0x12e506c: asr             x8, x6, #0x11
    // 0x12e5070: lsl             w9, w7, #0xf
    // 0x12e5074: ubfx            x9, x9, #0, #0x20
    // 0x12e5078: orr             x10, x8, x9
    // 0x12e507c: asr             x8, x6, #0x13
    // 0x12e5080: lsl             w9, w7, #0xd
    // 0x12e5084: ubfx            x9, x9, #0, #0x20
    // 0x12e5088: orr             x7, x8, x9
    // 0x12e508c: eor             x8, x10, x7
    // 0x12e5090: asr             x7, x6, #0xa
    // 0x12e5094: eor             x6, x8, x7
    // 0x12e5098: sub             x7, x2, #7
    // 0x12e509c: ArrayLoad: r8 = r4[r7]  ; List_4
    //     0x12e509c: add             x16, x4, x7, lsl #2
    //     0x12e50a0: ldur            w8, [x16, #0x17]
    // 0x12e50a4: ubfx            x6, x6, #0, #0x20
    // 0x12e50a8: add             w7, w6, w8
    // 0x12e50ac: sub             x6, x2, #0xf
    // 0x12e50b0: ArrayLoad: r8 = r4[r6]  ; List_4
    //     0x12e50b0: add             x16, x4, x6, lsl #2
    //     0x12e50b4: ldur            w8, [x16, #0x17]
    // 0x12e50b8: mov             x6, x8
    // 0x12e50bc: ubfx            x6, x6, #0, #0x20
    // 0x12e50c0: asr             x9, x6, #7
    // 0x12e50c4: lsl             w10, w8, #0x19
    // 0x12e50c8: ubfx            x10, x10, #0, #0x20
    // 0x12e50cc: orr             x11, x9, x10
    // 0x12e50d0: asr             x9, x6, #0x12
    // 0x12e50d4: lsl             w10, w8, #0xe
    // 0x12e50d8: ubfx            x10, x10, #0, #0x20
    // 0x12e50dc: orr             x8, x9, x10
    // 0x12e50e0: eor             x9, x11, x8
    // 0x12e50e4: asr             x8, x6, #3
    // 0x12e50e8: eor             x6, x9, x8
    // 0x12e50ec: sub             x8, x2, #0x10
    // 0x12e50f0: ArrayLoad: r9 = r4[r8]  ; List_4
    //     0x12e50f0: add             x16, x4, x8, lsl #2
    //     0x12e50f4: ldur            w9, [x16, #0x17]
    // 0x12e50f8: ubfx            x6, x6, #0, #0x20
    // 0x12e50fc: add             w8, w6, w9
    // 0x12e5100: add             w6, w7, w8
    // 0x12e5104: mov             x0, x5
    // 0x12e5108: mov             x1, x2
    // 0x12e510c: cmp             x1, x0
    // 0x12e5110: b.hs            #0x12e5510
    // 0x12e5114: ArrayStore: r4[r2] = r6  ; List_4
    //     0x12e5114: add             x7, x4, x2, lsl #2
    //     0x12e5118: stur            w6, [x7, #0x17]
    // 0x12e511c: add             x0, x2, #1
    // 0x12e5120: mov             x2, x0
    // 0x12e5124: b               #0x12e5044
    // 0x12e5128: LoadField: r2 = r3->field_37
    //     0x12e5128: ldur            w2, [x3, #0x37]
    // 0x12e512c: DecompressPointer r2
    //     0x12e512c: add             x2, x2, HEAP, lsl #32
    // 0x12e5130: LoadField: r3 = r2->field_13
    //     0x12e5130: ldur            w3, [x2, #0x13]
    // 0x12e5134: r5 = LoadInt32Instr(r3)
    //     0x12e5134: sbfx            x5, x3, #1, #0x1f
    // 0x12e5138: mov             x0, x5
    // 0x12e513c: r1 = 0
    //     0x12e513c: mov             x1, #0
    // 0x12e5140: cmp             x1, x0
    // 0x12e5144: b.hs            #0x12e5514
    // 0x12e5148: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x12e5148: ldur            w3, [x2, #0x17]
    // 0x12e514c: mov             x0, x5
    // 0x12e5150: r1 = 1
    //     0x12e5150: mov             x1, #1
    // 0x12e5154: cmp             x1, x0
    // 0x12e5158: b.hs            #0x12e5518
    // 0x12e515c: LoadField: r6 = r2->field_1b
    //     0x12e515c: ldur            w6, [x2, #0x1b]
    // 0x12e5160: mov             x0, x5
    // 0x12e5164: r1 = 2
    //     0x12e5164: mov             x1, #2
    // 0x12e5168: cmp             x1, x0
    // 0x12e516c: b.hs            #0x12e551c
    // 0x12e5170: LoadField: r7 = r2->field_1f
    //     0x12e5170: ldur            w7, [x2, #0x1f]
    // 0x12e5174: mov             x0, x5
    // 0x12e5178: r1 = 3
    //     0x12e5178: mov             x1, #3
    // 0x12e517c: cmp             x1, x0
    // 0x12e5180: b.hs            #0x12e5520
    // 0x12e5184: LoadField: r8 = r2->field_23
    //     0x12e5184: ldur            w8, [x2, #0x23]
    // 0x12e5188: mov             x0, x5
    // 0x12e518c: r1 = 4
    //     0x12e518c: mov             x1, #4
    // 0x12e5190: cmp             x1, x0
    // 0x12e5194: b.hs            #0x12e5524
    // 0x12e5198: LoadField: r9 = r2->field_27
    //     0x12e5198: ldur            w9, [x2, #0x27]
    // 0x12e519c: mov             x0, x5
    // 0x12e51a0: stur            x9, [fp, #-0x38]
    // 0x12e51a4: r1 = 5
    //     0x12e51a4: mov             x1, #5
    // 0x12e51a8: cmp             x1, x0
    // 0x12e51ac: b.hs            #0x12e5528
    // 0x12e51b0: LoadField: r10 = r2->field_2b
    //     0x12e51b0: ldur            w10, [x2, #0x2b]
    // 0x12e51b4: mov             x0, x5
    // 0x12e51b8: stur            x10, [fp, #-0x28]
    // 0x12e51bc: r1 = 6
    //     0x12e51bc: mov             x1, #6
    // 0x12e51c0: cmp             x1, x0
    // 0x12e51c4: b.hs            #0x12e552c
    // 0x12e51c8: LoadField: r11 = r2->field_2f
    //     0x12e51c8: ldur            w11, [x2, #0x2f]
    // 0x12e51cc: mov             x0, x5
    // 0x12e51d0: stur            x11, [fp, #-0x18]
    // 0x12e51d4: r1 = 7
    //     0x12e51d4: mov             x1, #7
    // 0x12e51d8: cmp             x1, x0
    // 0x12e51dc: b.hs            #0x12e5530
    // 0x12e51e0: LoadField: r5 = r2->field_33
    //     0x12e51e0: ldur            w5, [x2, #0x33]
    // 0x12e51e4: stur            x5, [fp, #-8]
    // 0x12e51e8: mov             x12, x3
    // 0x12e51ec: ubfx            x12, x12, #0, #0x20
    // 0x12e51f0: mov             x13, x6
    // 0x12e51f4: ubfx            x13, x13, #0, #0x20
    // 0x12e51f8: mov             x14, x7
    // 0x12e51fc: ubfx            x14, x14, #0, #0x20
    // 0x12e5200: mov             x19, x8
    // 0x12e5204: ubfx            x19, x19, #0, #0x20
    // 0x12e5208: mov             x20, x9
    // 0x12e520c: ubfx            x20, x20, #0, #0x20
    // 0x12e5210: mov             x23, x10
    // 0x12e5214: ubfx            x23, x23, #0, #0x20
    // 0x12e5218: mov             x24, x11
    // 0x12e521c: ubfx            x24, x24, #0, #0x20
    // 0x12e5220: mov             x25, x5
    // 0x12e5224: ubfx            x25, x25, #0, #0x20
    // 0x12e5228: LoadField: r0 = r4->field_13
    //     0x12e5228: ldur            w0, [x4, #0x13]
    // 0x12e522c: r1 = LoadInt32Instr(r0)
    //     0x12e522c: sbfx            x1, x0, #1, #0x1f
    // 0x12e5230: mov             x5, x12
    // 0x12e5234: mov             x0, x13
    // 0x12e5238: mov             x16, x25
    // 0x12e523c: mov             x25, x14
    // 0x12e5240: mov             x14, x16
    // 0x12e5244: mov             x16, x24
    // 0x12e5248: mov             x24, x19
    // 0x12e524c: mov             x19, x16
    // 0x12e5250: mov             x16, x23
    // 0x12e5254: mov             x23, x20
    // 0x12e5258: mov             x20, x16
    // 0x12e525c: r13 = 0
    //     0x12e525c: mov             x13, #0
    // 0x12e5260: r12 = const [1116352408, 1899447441, 3049323471, 3921009573, 0x3956c25b, 1508970993, 2453635748, 2870763221, 3624381080, 0x12835b01, 0x243185be, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774, 0xfc19dc6, 0x240ca1cc, 0x2de92c6f, 1249150122, 1555081692, 1996064986, 2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711, 0x6ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 1294757372, 1396182291, 1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411, 3259730800, 3345764771, 3516065817, 3600352804, 4094571909, 0x106aa070, 0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424, 2428436474, 2756734187, 3204031479, 3329325298]
    //     0x12e5260: add             x12, PP, #0x8a, lsl #12  ; [pp+0x8afe0] List<int>(64)
    //     0x12e5264: ldr             x12, [x12, #0xfe0]
    // 0x12e5268: stur            x14, [fp, #-0x10]
    // 0x12e526c: stur            x19, [fp, #-0x20]
    // 0x12e5270: stur            x20, [fp, #-0x30]
    // 0x12e5274: CheckStackOverflow
    //     0x12e5274: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e5278: cmp             SP, x16
    //     0x12e527c: b.ls            #0x12e5534
    // 0x12e5280: cmp             x13, #0x40
    // 0x12e5284: b.ge            #0x12e5468
    // 0x12e5288: mov             x14, x23
    // 0x12e528c: ubfx            x14, x14, #0, #0x20
    // 0x12e5290: lsr             w11, w14, #6
    // 0x12e5294: mov             x14, x23
    // 0x12e5298: ubfx            x14, x14, #0, #0x20
    // 0x12e529c: lsl             w19, w14, #0x1a
    // 0x12e52a0: orr             x14, x11, x19
    // 0x12e52a4: mov             x11, x23
    // 0x12e52a8: ubfx            x11, x11, #0, #0x20
    // 0x12e52ac: lsr             w19, w11, #0xb
    // 0x12e52b0: mov             x11, x23
    // 0x12e52b4: ubfx            x11, x11, #0, #0x20
    // 0x12e52b8: lsl             w10, w11, #0x15
    // 0x12e52bc: orr             x11, x19, x10
    // 0x12e52c0: eor             x10, x14, x11
    // 0x12e52c4: mov             x11, x23
    // 0x12e52c8: ubfx            x11, x11, #0, #0x20
    // 0x12e52cc: lsr             w14, w11, #0x19
    // 0x12e52d0: mov             x11, x23
    // 0x12e52d4: ubfx            x11, x11, #0, #0x20
    // 0x12e52d8: lsl             w19, w11, #7
    // 0x12e52dc: orr             x11, x14, x19
    // 0x12e52e0: eor             x14, x10, x11
    // 0x12e52e4: ldur            x10, [fp, #-0x10]
    // 0x12e52e8: ubfx            x10, x10, #0, #0x20
    // 0x12e52ec: add             w11, w10, w14
    // 0x12e52f0: mov             x10, x23
    // 0x12e52f4: ubfx            x10, x10, #0, #0x20
    // 0x12e52f8: mov             x14, x20
    // 0x12e52fc: ubfx            x14, x14, #0, #0x20
    // 0x12e5300: and             x19, x10, x14
    // 0x12e5304: mov             x10, x23
    // 0x12e5308: ubfx            x10, x10, #0, #0x20
    // 0x12e530c: mvn             w14, w10
    // 0x12e5310: ldur            x10, [fp, #-0x20]
    // 0x12e5314: ubfx            x10, x10, #0, #0x20
    // 0x12e5318: and             x20, x14, x10
    // 0x12e531c: ubfx            x19, x19, #0, #0x20
    // 0x12e5320: ubfx            x20, x20, #0, #0x20
    // 0x12e5324: eor             x10, x19, x20
    // 0x12e5328: ArrayLoad: r14 = r12[r13]  ; Unknown_4
    //     0x12e5328: add             x16, x12, x13, lsl #2
    //     0x12e532c: ldur            w14, [x16, #0xf]
    // 0x12e5330: DecompressPointer r14
    //     0x12e5330: add             x14, x14, HEAP, lsl #32
    // 0x12e5334: mov             x19, x0
    // 0x12e5338: mov             x0, x1
    // 0x12e533c: mov             x20, x1
    // 0x12e5340: mov             x1, x13
    // 0x12e5344: cmp             x1, x0
    // 0x12e5348: b.hs            #0x12e553c
    // 0x12e534c: ArrayLoad: r1 = r4[r13]  ; List_4
    //     0x12e534c: add             x16, x4, x13, lsl #2
    //     0x12e5350: ldur            w1, [x16, #0x17]
    // 0x12e5354: r0 = LoadInt32Instr(r14)
    //     0x12e5354: sbfx            x0, x14, #1, #0x1f
    //     0x12e5358: tbz             w14, #0, #0x12e5360
    //     0x12e535c: ldur            x0, [x14, #7]
    // 0x12e5360: add             w14, w0, w1
    // 0x12e5364: ubfx            x10, x10, #0, #0x20
    // 0x12e5368: add             w1, w10, w14
    // 0x12e536c: add             w10, w11, w1
    // 0x12e5370: mov             x1, x5
    // 0x12e5374: ubfx            x1, x1, #0, #0x20
    // 0x12e5378: lsr             w11, w1, #2
    // 0x12e537c: mov             x1, x5
    // 0x12e5380: ubfx            x1, x1, #0, #0x20
    // 0x12e5384: lsl             w14, w1, #0x1e
    // 0x12e5388: orr             x1, x11, x14
    // 0x12e538c: mov             x11, x5
    // 0x12e5390: ubfx            x11, x11, #0, #0x20
    // 0x12e5394: lsr             w14, w11, #0xd
    // 0x12e5398: mov             x11, x5
    // 0x12e539c: ubfx            x11, x11, #0, #0x20
    // 0x12e53a0: lsl             w0, w11, #0x13
    // 0x12e53a4: orr             x11, x14, x0
    // 0x12e53a8: eor             x14, x1, x11
    // 0x12e53ac: mov             x1, x5
    // 0x12e53b0: ubfx            x1, x1, #0, #0x20
    // 0x12e53b4: lsr             w11, w1, #0x16
    // 0x12e53b8: mov             x1, x5
    // 0x12e53bc: ubfx            x1, x1, #0, #0x20
    // 0x12e53c0: lsl             w0, w1, #0xa
    // 0x12e53c4: orr             x1, x11, x0
    // 0x12e53c8: eor             x11, x14, x1
    // 0x12e53cc: mov             x1, x5
    // 0x12e53d0: ubfx            x1, x1, #0, #0x20
    // 0x12e53d4: mov             x14, x19
    // 0x12e53d8: ubfx            x14, x14, #0, #0x20
    // 0x12e53dc: and             x0, x1, x14
    // 0x12e53e0: mov             x1, x5
    // 0x12e53e4: ubfx            x1, x1, #0, #0x20
    // 0x12e53e8: mov             x14, x25
    // 0x12e53ec: ubfx            x14, x14, #0, #0x20
    // 0x12e53f0: and             x9, x1, x14
    // 0x12e53f4: eor             x1, x0, x9
    // 0x12e53f8: mov             x9, x19
    // 0x12e53fc: ubfx            x9, x9, #0, #0x20
    // 0x12e5400: mov             x14, x25
    // 0x12e5404: ubfx            x14, x14, #0, #0x20
    // 0x12e5408: and             x0, x9, x14
    // 0x12e540c: eor             x9, x1, x0
    // 0x12e5410: add             w1, w11, w9
    // 0x12e5414: mov             x9, x24
    // 0x12e5418: ubfx            x9, x9, #0, #0x20
    // 0x12e541c: add             w11, w9, w10
    // 0x12e5420: add             w9, w10, w1
    // 0x12e5424: add             x1, x13, #1
    // 0x12e5428: ubfx            x11, x11, #0, #0x20
    // 0x12e542c: ubfx            x9, x9, #0, #0x20
    // 0x12e5430: mov             x0, x5
    // 0x12e5434: mov             x5, x9
    // 0x12e5438: mov             x24, x25
    // 0x12e543c: mov             x25, x19
    // 0x12e5440: mov             x13, x1
    // 0x12e5444: mov             x1, x20
    // 0x12e5448: mov             x20, x23
    // 0x12e544c: mov             x23, x11
    // 0x12e5450: ldur            x19, [fp, #-0x30]
    // 0x12e5454: ldur            x14, [fp, #-0x20]
    // 0x12e5458: ldur            x9, [fp, #-0x38]
    // 0x12e545c: ldur            x10, [fp, #-0x28]
    // 0x12e5460: ldur            x11, [fp, #-0x18]
    // 0x12e5464: b               #0x12e5268
    // 0x12e5468: mov             x19, x0
    // 0x12e546c: mov             x1, x9
    // 0x12e5470: mov             x4, x10
    // 0x12e5474: mov             x9, x11
    // 0x12e5478: ldur            x10, [fp, #-8]
    // 0x12e547c: ubfx            x5, x5, #0, #0x20
    // 0x12e5480: add             w11, w5, w3
    // 0x12e5484: ArrayStore: r2[0] = r11  ; List_4
    //     0x12e5484: stur            w11, [x2, #0x17]
    // 0x12e5488: ubfx            x19, x19, #0, #0x20
    // 0x12e548c: add             w3, w19, w6
    // 0x12e5490: StoreField: r2->field_1b = r3
    //     0x12e5490: stur            w3, [x2, #0x1b]
    // 0x12e5494: ubfx            x25, x25, #0, #0x20
    // 0x12e5498: add             w3, w25, w7
    // 0x12e549c: StoreField: r2->field_1f = r3
    //     0x12e549c: stur            w3, [x2, #0x1f]
    // 0x12e54a0: ubfx            x24, x24, #0, #0x20
    // 0x12e54a4: add             w3, w24, w8
    // 0x12e54a8: StoreField: r2->field_23 = r3
    //     0x12e54a8: stur            w3, [x2, #0x23]
    // 0x12e54ac: ubfx            x23, x23, #0, #0x20
    // 0x12e54b0: add             w3, w23, w1
    // 0x12e54b4: StoreField: r2->field_27 = r3
    //     0x12e54b4: stur            w3, [x2, #0x27]
    // 0x12e54b8: ldur            x1, [fp, #-0x30]
    // 0x12e54bc: ubfx            x1, x1, #0, #0x20
    // 0x12e54c0: add             w3, w1, w4
    // 0x12e54c4: StoreField: r2->field_2b = r3
    //     0x12e54c4: stur            w3, [x2, #0x2b]
    // 0x12e54c8: ldur            x1, [fp, #-0x20]
    // 0x12e54cc: ubfx            x1, x1, #0, #0x20
    // 0x12e54d0: add             w3, w1, w9
    // 0x12e54d4: StoreField: r2->field_2f = r3
    //     0x12e54d4: stur            w3, [x2, #0x2f]
    // 0x12e54d8: ldur            x1, [fp, #-0x10]
    // 0x12e54dc: ubfx            x1, x1, #0, #0x20
    // 0x12e54e0: add             w3, w1, w10
    // 0x12e54e4: StoreField: r2->field_33 = r3
    //     0x12e54e4: stur            w3, [x2, #0x33]
    // 0x12e54e8: r0 = Null
    //     0x12e54e8: mov             x0, NULL
    // 0x12e54ec: LeaveFrame
    //     0x12e54ec: mov             SP, fp
    //     0x12e54f0: ldp             fp, lr, [SP], #0x10
    // 0x12e54f4: ret
    //     0x12e54f4: ret             
    // 0x12e54f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e54f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e54fc: b               #0x12e4ff4
    // 0x12e5500: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12e5500: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12e5504: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12e5504: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12e5508: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e5508: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e550c: b               #0x12e5050
    // 0x12e5510: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12e5510: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12e5514: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12e5514: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12e5518: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12e5518: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12e551c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12e551c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12e5520: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12e5520: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12e5524: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12e5524: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12e5528: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12e5528: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12e552c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12e552c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12e5530: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12e5530: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12e5534: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e5534: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e5538: b               #0x12e5280
    // 0x12e553c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12e553c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
}

// class id: 3552, size: 0x40, field offset: 0x40
class _Sha256Sink extends _Sha32BitSink {

  _ _Sha256Sink(/* No info */) {
    // ** addr: 0x121d7ec, size: 0x104
    // 0x121d7ec: EnterFrame
    //     0x121d7ec: stp             fp, lr, [SP, #-0x10]!
    //     0x121d7f0: mov             fp, SP
    // 0x121d7f4: AllocStack(0x20)
    //     0x121d7f4: sub             SP, SP, #0x20
    // 0x121d7f8: r0 = 16
    //     0x121d7f8: mov             x0, #0x10
    // 0x121d7fc: mov             x4, x1
    // 0x121d800: mov             x3, x2
    // 0x121d804: stur            x1, [fp, #-8]
    // 0x121d808: stur            x2, [fp, #-0x10]
    // 0x121d80c: CheckStackOverflow
    //     0x121d80c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x121d810: cmp             SP, x16
    //     0x121d814: b.ls            #0x121d8e8
    // 0x121d818: mov             x2, x0
    // 0x121d81c: r1 = Null
    //     0x121d81c: mov             x1, NULL
    // 0x121d820: r0 = AllocateArray()
    //     0x121d820: bl              #0x13df928  ; AllocateArrayStub
    // 0x121d824: stur            x0, [fp, #-0x18]
    // 0x121d828: r16 = 1779033703
    //     0x121d828: add             x16, PP, #0x25, lsl #12  ; [pp+0x25fd0] 0x6a09e667
    //     0x121d82c: ldr             x16, [x16, #0xfd0]
    // 0x121d830: StoreField: r0->field_f = r16
    //     0x121d830: stur            w16, [x0, #0xf]
    // 0x121d834: r16 = 3144134277
    //     0x121d834: add             x16, PP, #0x25, lsl #12  ; [pp+0x25fd8] 0xbb67ae85
    //     0x121d838: ldr             x16, [x16, #0xfd8]
    // 0x121d83c: StoreField: r0->field_13 = r16
    //     0x121d83c: stur            w16, [x0, #0x13]
    // 0x121d840: r16 = 2027808484
    //     0x121d840: mov             x16, #0xe6e4
    //     0x121d844: movk            x16, #0x78dd, lsl #16
    // 0x121d848: ArrayStore: r0[0] = r16  ; List_4
    //     0x121d848: stur            w16, [x0, #0x17]
    // 0x121d84c: r16 = 2773480762
    //     0x121d84c: add             x16, PP, #0x25, lsl #12  ; [pp+0x25fe0] 0xa54ff53a
    //     0x121d850: ldr             x16, [x16, #0xfe0]
    // 0x121d854: StoreField: r0->field_1b = r16
    //     0x121d854: stur            w16, [x0, #0x1b]
    // 0x121d858: r16 = 1359893119
    //     0x121d858: add             x16, PP, #0x25, lsl #12  ; [pp+0x25fe8] 0x510e527f
    //     0x121d85c: ldr             x16, [x16, #0xfe8]
    // 0x121d860: StoreField: r0->field_1f = r16
    //     0x121d860: stur            w16, [x0, #0x1f]
    // 0x121d864: r16 = 2600822924
    //     0x121d864: add             x16, PP, #0x25, lsl #12  ; [pp+0x25ff0] 0x9b05688c
    //     0x121d868: ldr             x16, [x16, #0xff0]
    // 0x121d86c: StoreField: r0->field_23 = r16
    //     0x121d86c: stur            w16, [x0, #0x23]
    // 0x121d870: r16 = 1057469270
    //     0x121d870: mov             x16, #0xb356
    //     0x121d874: movk            x16, #0x3f07, lsl #16
    // 0x121d878: StoreField: r0->field_27 = r16
    //     0x121d878: stur            w16, [x0, #0x27]
    // 0x121d87c: r16 = 1541459225
    //     0x121d87c: add             x16, PP, #0x25, lsl #12  ; [pp+0x25ff8] 0x5be0cd19
    //     0x121d880: ldr             x16, [x16, #0xff8]
    // 0x121d884: StoreField: r0->field_2b = r16
    //     0x121d884: stur            w16, [x0, #0x2b]
    // 0x121d888: r1 = <int>
    //     0x121d888: ldr             x1, [PP, #0x50]  ; [pp+0x50] TypeArguments: <int>
    // 0x121d88c: r0 = AllocateGrowableArray()
    //     0x121d88c: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x121d890: mov             x1, x0
    // 0x121d894: ldur            x0, [fp, #-0x18]
    // 0x121d898: stur            x1, [fp, #-0x20]
    // 0x121d89c: StoreField: r1->field_f = r0
    //     0x121d89c: stur            w0, [x1, #0xf]
    // 0x121d8a0: r4 = 16
    //     0x121d8a0: mov             x4, #0x10
    // 0x121d8a4: StoreField: r1->field_b = r4
    //     0x121d8a4: stur            w4, [x1, #0xb]
    // 0x121d8a8: r0 = AllocateUint32Array()
    //     0x121d8a8: bl              #0x13df228  ; AllocateUint32ArrayStub
    // 0x121d8ac: mov             x1, x0
    // 0x121d8b0: ldur            x5, [fp, #-0x20]
    // 0x121d8b4: r2 = 0
    //     0x121d8b4: mov             x2, #0
    // 0x121d8b8: r3 = 8
    //     0x121d8b8: mov             x3, #8
    // 0x121d8bc: r6 = 0
    //     0x121d8bc: mov             x6, #0
    // 0x121d8c0: stur            x0, [fp, #-0x18]
    // 0x121d8c4: r0 = _slowSetRange()
    //     0x121d8c4: bl              #0x117a094  ; [dart:typed_data] __Uint32List&_TypedList&_IntListMixin&_TypedIntListMixin::_slowSetRange
    // 0x121d8c8: ldur            x1, [fp, #-8]
    // 0x121d8cc: ldur            x2, [fp, #-0x10]
    // 0x121d8d0: ldur            x3, [fp, #-0x18]
    // 0x121d8d4: r0 = _Sha32BitSink()
    //     0x121d8d4: bl              #0x121d8f0  ; [package:crypto/src/sha256.dart] _Sha32BitSink::_Sha32BitSink
    // 0x121d8d8: r0 = Null
    //     0x121d8d8: mov             x0, NULL
    // 0x121d8dc: LeaveFrame
    //     0x121d8dc: mov             SP, fp
    //     0x121d8e0: ldp             fp, lr, [SP], #0x10
    // 0x121d8e4: ret
    //     0x121d8e4: ret             
    // 0x121d8e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x121d8e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x121d8ec: b               #0x121d818
  }
}

// class id: 7326, size: 0xc, field offset: 0xc
//   const constructor, 
class _Sha256 extends Hash {

  _ startChunkedConversion(/* No info */) {
    // ** addr: 0x121d79c, size: 0x50
    // 0x121d79c: EnterFrame
    //     0x121d79c: stp             fp, lr, [SP, #-0x10]!
    //     0x121d7a0: mov             fp, SP
    // 0x121d7a4: AllocStack(0x8)
    //     0x121d7a4: sub             SP, SP, #8
    // 0x121d7a8: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x121d7a8: stur            x2, [fp, #-8]
    // 0x121d7ac: CheckStackOverflow
    //     0x121d7ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x121d7b0: cmp             SP, x16
    //     0x121d7b4: b.ls            #0x121d7e4
    // 0x121d7b8: r0 = _Sha256Sink()
    //     0x121d7b8: bl              #0x121da04  ; Allocate_Sha256SinkStub -> _Sha256Sink (size=0x40)
    // 0x121d7bc: mov             x1, x0
    // 0x121d7c0: ldur            x2, [fp, #-8]
    // 0x121d7c4: stur            x0, [fp, #-8]
    // 0x121d7c8: r0 = _Sha256Sink()
    //     0x121d7c8: bl              #0x121d7ec  ; [package:crypto/src/sha256.dart] _Sha256Sink::_Sha256Sink
    // 0x121d7cc: r0 = _ByteAdapterSink()
    //     0x121d7cc: bl              #0x121d614  ; Allocate_ByteAdapterSinkStub -> _ByteAdapterSink (size=0xc)
    // 0x121d7d0: ldur            x1, [fp, #-8]
    // 0x121d7d4: StoreField: r0->field_7 = r1
    //     0x121d7d4: stur            w1, [x0, #7]
    // 0x121d7d8: LeaveFrame
    //     0x121d7d8: mov             SP, fp
    //     0x121d7dc: ldp             fp, lr, [SP], #0x10
    // 0x121d7e0: ret
    //     0x121d7e0: ret             
    // 0x121d7e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x121d7e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x121d7e8: b               #0x121d7b8
  }
}
