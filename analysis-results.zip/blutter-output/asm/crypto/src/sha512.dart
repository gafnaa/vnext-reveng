// lib: , url: package:crypto/src/sha512.dart

// class id: 1048678, size: 0x8
class :: {
}

// class id: 7324, size: 0xc, field offset: 0xc
//   const constructor, 
class _Sha512 extends Hash {

  _ startChunkedConversion(/* No info */) {
    // ** addr: 0x121dc8c, size: 0x50
    // 0x121dc8c: EnterFrame
    //     0x121dc8c: stp             fp, lr, [SP, #-0x10]!
    //     0x121dc90: mov             fp, SP
    // 0x121dc94: AllocStack(0x8)
    //     0x121dc94: sub             SP, SP, #8
    // 0x121dc98: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x121dc98: stur            x2, [fp, #-8]
    // 0x121dc9c: CheckStackOverflow
    //     0x121dc9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x121dca0: cmp             SP, x16
    //     0x121dca4: b.ls            #0x121dcd4
    // 0x121dca8: r0 = Sha512Sink()
    //     0x121dca8: bl              #0x121dde8  ; AllocateSha512SinkStub -> Sha512Sink (size=0x48)
    // 0x121dcac: mov             x1, x0
    // 0x121dcb0: ldur            x2, [fp, #-8]
    // 0x121dcb4: stur            x0, [fp, #-8]
    // 0x121dcb8: r0 = Sha512Sink()
    //     0x121dcb8: bl              #0x121dcdc  ; [package:crypto/src/sha512_fastsinks.dart] Sha512Sink::Sha512Sink
    // 0x121dcbc: r0 = _ByteAdapterSink()
    //     0x121dcbc: bl              #0x121d614  ; Allocate_ByteAdapterSinkStub -> _ByteAdapterSink (size=0xc)
    // 0x121dcc0: ldur            x1, [fp, #-8]
    // 0x121dcc4: StoreField: r0->field_7 = r1
    //     0x121dcc4: stur            w1, [x0, #7]
    // 0x121dcc8: LeaveFrame
    //     0x121dcc8: mov             SP, fp
    //     0x121dccc: ldp             fp, lr, [SP], #0x10
    // 0x121dcd0: ret
    //     0x121dcd0: ret             
    // 0x121dcd4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x121dcd4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x121dcd8: b               #0x121dca8
  }
}

// class id: 7325, size: 0xc, field offset: 0xc
//   const constructor, 
class _Sha384 extends Hash {

  _ startChunkedConversion(/* No info */) {
    // ** addr: 0x121da10, size: 0x50
    // 0x121da10: EnterFrame
    //     0x121da10: stp             fp, lr, [SP, #-0x10]!
    //     0x121da14: mov             fp, SP
    // 0x121da18: AllocStack(0x8)
    //     0x121da18: sub             SP, SP, #8
    // 0x121da1c: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x121da1c: stur            x2, [fp, #-8]
    // 0x121da20: CheckStackOverflow
    //     0x121da20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x121da24: cmp             SP, x16
    //     0x121da28: b.ls            #0x121da58
    // 0x121da2c: r0 = Sha384Sink()
    //     0x121da2c: bl              #0x121dc80  ; AllocateSha384SinkStub -> Sha384Sink (size=0x48)
    // 0x121da30: mov             x1, x0
    // 0x121da34: ldur            x2, [fp, #-8]
    // 0x121da38: stur            x0, [fp, #-8]
    // 0x121da3c: r0 = Sha384Sink()
    //     0x121da3c: bl              #0x121da60  ; [package:crypto/src/sha512_fastsinks.dart] Sha384Sink::Sha384Sink
    // 0x121da40: r0 = _ByteAdapterSink()
    //     0x121da40: bl              #0x121d614  ; Allocate_ByteAdapterSinkStub -> _ByteAdapterSink (size=0xc)
    // 0x121da44: ldur            x1, [fp, #-8]
    // 0x121da48: StoreField: r0->field_7 = r1
    //     0x121da48: stur            w1, [x0, #7]
    // 0x121da4c: LeaveFrame
    //     0x121da4c: mov             SP, fp
    //     0x121da50: ldp             fp, lr, [SP], #0x10
    // 0x121da54: ret
    //     0x121da54: ret             
    // 0x121da58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x121da58: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x121da5c: b               #0x121da2c
  }
}
