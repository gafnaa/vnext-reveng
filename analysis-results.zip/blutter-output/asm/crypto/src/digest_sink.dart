// lib: , url: package:crypto/src/digest_sink.dart

// class id: 1048672, size: 0x8
class :: {
}

// class id: 3555, size: 0xc, field offset: 0x8
class DigestSink extends Object
    implements Sink<X0> {

  _ add(/* No info */) {
    // ** addr: 0x8d9e00, size: 0x68
    // 0x8d9e00: EnterFrame
    //     0x8d9e00: stp             fp, lr, [SP, #-0x10]!
    //     0x8d9e04: mov             fp, SP
    // 0x8d9e08: mov             x0, x2
    // 0x8d9e0c: LoadField: r2 = r1->field_7
    //     0x8d9e0c: ldur            w2, [x1, #7]
    // 0x8d9e10: DecompressPointer r2
    //     0x8d9e10: add             x2, x2, HEAP, lsl #32
    // 0x8d9e14: cmp             w2, NULL
    // 0x8d9e18: b.ne            #0x8d9e48
    // 0x8d9e1c: StoreField: r1->field_7 = r0
    //     0x8d9e1c: stur            w0, [x1, #7]
    //     0x8d9e20: ldurb           w16, [x1, #-1]
    //     0x8d9e24: ldurb           w17, [x0, #-1]
    //     0x8d9e28: and             x16, x17, x16, lsr #2
    //     0x8d9e2c: tst             x16, HEAP, lsr #32
    //     0x8d9e30: b.eq            #0x8d9e38
    //     0x8d9e34: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8d9e38: r0 = Null
    //     0x8d9e38: mov             x0, NULL
    // 0x8d9e3c: LeaveFrame
    //     0x8d9e3c: mov             SP, fp
    //     0x8d9e40: ldp             fp, lr, [SP], #0x10
    // 0x8d9e44: ret
    //     0x8d9e44: ret             
    // 0x8d9e48: r0 = StateError()
    //     0x8d9e48: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x8d9e4c: mov             x1, x0
    // 0x8d9e50: r0 = "add may only be called once."
    //     0x8d9e50: add             x0, PP, #0x26, lsl #12  ; [pp+0x26010] "add may only be called once."
    //     0x8d9e54: ldr             x0, [x0, #0x10]
    // 0x8d9e58: StoreField: r1->field_b = r0
    //     0x8d9e58: stur            w0, [x1, #0xb]
    // 0x8d9e5c: mov             x0, x1
    // 0x8d9e60: r0 = Throw()
    //     0x8d9e60: bl              #0x13ddb2c  ; ThrowStub
    // 0x8d9e64: brk             #0
  }
  [closure] void add(dynamic, Object?) {
    // ** addr: 0x8d9e68, size: 0x3c
    // 0x8d9e68: EnterFrame
    //     0x8d9e68: stp             fp, lr, [SP, #-0x10]!
    //     0x8d9e6c: mov             fp, SP
    // 0x8d9e70: ldr             x0, [fp, #0x18]
    // 0x8d9e74: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8d9e74: ldur            w1, [x0, #0x17]
    // 0x8d9e78: DecompressPointer r1
    //     0x8d9e78: add             x1, x1, HEAP, lsl #32
    // 0x8d9e7c: CheckStackOverflow
    //     0x8d9e7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d9e80: cmp             SP, x16
    //     0x8d9e84: b.ls            #0x8d9e9c
    // 0x8d9e88: ldr             x2, [fp, #0x10]
    // 0x8d9e8c: r0 = add()
    //     0x8d9e8c: bl              #0x8d9e00  ; [package:crypto/src/digest_sink.dart] DigestSink::add
    // 0x8d9e90: LeaveFrame
    //     0x8d9e90: mov             SP, fp
    //     0x8d9e94: ldp             fp, lr, [SP], #0x10
    // 0x8d9e98: ret
    //     0x8d9e98: ret             
    // 0x8d9e9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d9e9c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d9ea0: b               #0x8d9e88
  }
  Digest dyn:get:value(DigestSink) {
    // ** addr: 0x8d9ebc, size: 0x3c
    // 0x8d9ebc: ldr             x1, [SP]
    // 0x8d9ec0: LoadField: r0 = r1->field_7
    //     0x8d9ec0: ldur            w0, [x1, #7]
    // 0x8d9ec4: DecompressPointer r0
    //     0x8d9ec4: add             x0, x0, HEAP, lsl #32
    // 0x8d9ec8: cmp             w0, NULL
    // 0x8d9ecc: b.eq            #0x8d9ed4
    // 0x8d9ed0: ret
    //     0x8d9ed0: ret             
    // 0x8d9ed4: EnterFrame
    //     0x8d9ed4: stp             fp, lr, [SP, #-0x10]!
    //     0x8d9ed8: mov             fp, SP
    // 0x8d9edc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8d9edc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  dynamic add(dynamic) {
    // ** addr: 0x8db2b0, size: 0x24
    // 0x8db2b0: EnterFrame
    //     0x8db2b0: stp             fp, lr, [SP, #-0x10]!
    //     0x8db2b4: mov             fp, SP
    // 0x8db2b8: ldr             x2, [fp, #0x10]
    // 0x8db2bc: r1 = Function 'add':.
    //     0x8db2bc: add             x1, PP, #0x26, lsl #12  ; [pp+0x26000] AnonymousClosure: (0x8d9e68), in [package:crypto/src/digest_sink.dart] DigestSink::add (0x8d9e00)
    //     0x8db2c0: ldr             x1, [x1]
    // 0x8db2c4: r0 = AllocateClosure()
    //     0x8db2c4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8db2c8: LeaveFrame
    //     0x8db2c8: mov             SP, fp
    //     0x8db2cc: ldp             fp, lr, [SP], #0x10
    // 0x8db2d0: ret
    //     0x8db2d0: ret             
  }
  _ close(/* No info */) {
    // ** addr: 0x8de7d8, size: 0x48
    // 0x8de7d8: EnterFrame
    //     0x8de7d8: stp             fp, lr, [SP, #-0x10]!
    //     0x8de7dc: mov             fp, SP
    // 0x8de7e0: LoadField: r0 = r1->field_7
    //     0x8de7e0: ldur            w0, [x1, #7]
    // 0x8de7e4: DecompressPointer r0
    //     0x8de7e4: add             x0, x0, HEAP, lsl #32
    // 0x8de7e8: cmp             w0, NULL
    // 0x8de7ec: b.eq            #0x8de800
    // 0x8de7f0: r0 = Null
    //     0x8de7f0: mov             x0, NULL
    // 0x8de7f4: LeaveFrame
    //     0x8de7f4: mov             SP, fp
    //     0x8de7f8: ldp             fp, lr, [SP], #0x10
    // 0x8de7fc: ret
    //     0x8de7fc: ret             
    // 0x8de800: r0 = StateError()
    //     0x8de800: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x8de804: mov             x1, x0
    // 0x8de808: r0 = "add must be called once."
    //     0x8de808: add             x0, PP, #0x26, lsl #12  ; [pp+0x26008] "add must be called once."
    //     0x8de80c: ldr             x0, [x0, #8]
    // 0x8de810: StoreField: r1->field_b = r0
    //     0x8de810: stur            w0, [x1, #0xb]
    // 0x8de814: mov             x0, x1
    // 0x8de818: r0 = Throw()
    //     0x8de818: bl              #0x13ddb2c  ; ThrowStub
    // 0x8de81c: brk             #0
  }
}
