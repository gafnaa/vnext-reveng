// lib: , url: package:crypto/src/hash_sink.dart

// class id: 1048674, size: 0x8
class :: {
}

// class id: 3547, size: 0x38, field offset: 0x8
abstract class HashSink extends Object
    implements Sink<X0> {

  _ add(/* No info */) {
    // ** addr: 0x8d9ee0, size: 0xd8
    // 0x8d9ee0: EnterFrame
    //     0x8d9ee0: stp             fp, lr, [SP, #-0x10]!
    //     0x8d9ee4: mov             fp, SP
    // 0x8d9ee8: AllocStack(0x20)
    //     0x8d9ee8: sub             SP, SP, #0x20
    // 0x8d9eec: SetupParameters(HashSink this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x8d9eec: mov             x4, x1
    //     0x8d9ef0: mov             x3, x2
    //     0x8d9ef4: stur            x1, [fp, #-8]
    //     0x8d9ef8: stur            x2, [fp, #-0x10]
    // 0x8d9efc: CheckStackOverflow
    //     0x8d9efc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d9f00: cmp             SP, x16
    //     0x8d9f04: b.ls            #0x8d9fb0
    // 0x8d9f08: mov             x0, x3
    // 0x8d9f0c: r2 = Null
    //     0x8d9f0c: mov             x2, NULL
    // 0x8d9f10: r1 = Null
    //     0x8d9f10: mov             x1, NULL
    // 0x8d9f14: r8 = List<int>
    //     0x8d9f14: ldr             x8, [PP, #0x13e8]  ; [pp+0x13e8] Type: List<int>
    // 0x8d9f18: r3 = Null
    //     0x8d9f18: add             x3, PP, #0x7e, lsl #12  ; [pp+0x7eda8] Null
    //     0x8d9f1c: ldr             x3, [x3, #0xda8]
    // 0x8d9f20: r0 = List<int>()
    //     0x8d9f20: bl              #0x7fd2a4  ; IsType_List<int>_Stub
    // 0x8d9f24: ldur            x1, [fp, #-8]
    // 0x8d9f28: LoadField: r0 = r1->field_2b
    //     0x8d9f28: ldur            w0, [x1, #0x2b]
    // 0x8d9f2c: DecompressPointer r0
    //     0x8d9f2c: add             x0, x0, HEAP, lsl #32
    // 0x8d9f30: tbz             w0, #4, #0x8d9f90
    // 0x8d9f34: ldur            x2, [fp, #-0x10]
    // 0x8d9f38: LoadField: r3 = r1->field_23
    //     0x8d9f38: ldur            x3, [x1, #0x23]
    // 0x8d9f3c: stur            x3, [fp, #-0x18]
    // 0x8d9f40: r0 = LoadClassIdInstr(r2)
    //     0x8d9f40: ldur            x0, [x2, #-1]
    //     0x8d9f44: ubfx            x0, x0, #0xc, #0x14
    // 0x8d9f48: str             x2, [SP]
    // 0x8d9f4c: r0 = GDT[cid_x0 + 0xf078]()
    //     0x8d9f4c: mov             x17, #0xf078
    //     0x8d9f50: add             lr, x0, x17
    //     0x8d9f54: ldr             lr, [x21, lr, lsl #3]
    //     0x8d9f58: blr             lr
    // 0x8d9f5c: r1 = LoadInt32Instr(r0)
    //     0x8d9f5c: sbfx            x1, x0, #1, #0x1f
    //     0x8d9f60: tbz             w0, #0, #0x8d9f68
    //     0x8d9f64: ldur            x1, [x0, #7]
    // 0x8d9f68: ldur            x0, [fp, #-0x18]
    // 0x8d9f6c: add             x2, x0, x1
    // 0x8d9f70: ldur            x1, [fp, #-8]
    // 0x8d9f74: StoreField: r1->field_23 = r2
    //     0x8d9f74: stur            x2, [x1, #0x23]
    // 0x8d9f78: ldur            x2, [fp, #-0x10]
    // 0x8d9f7c: r0 = _addData()
    //     0x8d9f7c: bl              #0x8d9ff4  ; [package:crypto/src/hash_sink.dart] HashSink::_addData
    // 0x8d9f80: r0 = Null
    //     0x8d9f80: mov             x0, NULL
    // 0x8d9f84: LeaveFrame
    //     0x8d9f84: mov             SP, fp
    //     0x8d9f88: ldp             fp, lr, [SP], #0x10
    // 0x8d9f8c: ret
    //     0x8d9f8c: ret             
    // 0x8d9f90: r0 = StateError()
    //     0x8d9f90: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x8d9f94: mov             x1, x0
    // 0x8d9f98: r0 = "Hash.add() called after close()."
    //     0x8d9f98: add             x0, PP, #0x7e, lsl #12  ; [pp+0x7edb8] "Hash.add() called after close()."
    //     0x8d9f9c: ldr             x0, [x0, #0xdb8]
    // 0x8d9fa0: StoreField: r1->field_b = r0
    //     0x8d9fa0: stur            w0, [x1, #0xb]
    // 0x8d9fa4: mov             x0, x1
    // 0x8d9fa8: r0 = Throw()
    //     0x8d9fa8: bl              #0x13ddb2c  ; ThrowStub
    // 0x8d9fac: brk             #0
    // 0x8d9fb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d9fb0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d9fb4: b               #0x8d9f08
  }
  [closure] void add(dynamic, Object?) {
    // ** addr: 0x8d9fb8, size: 0x3c
    // 0x8d9fb8: EnterFrame
    //     0x8d9fb8: stp             fp, lr, [SP, #-0x10]!
    //     0x8d9fbc: mov             fp, SP
    // 0x8d9fc0: ldr             x0, [fp, #0x18]
    // 0x8d9fc4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8d9fc4: ldur            w1, [x0, #0x17]
    // 0x8d9fc8: DecompressPointer r1
    //     0x8d9fc8: add             x1, x1, HEAP, lsl #32
    // 0x8d9fcc: CheckStackOverflow
    //     0x8d9fcc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d9fd0: cmp             SP, x16
    //     0x8d9fd4: b.ls            #0x8d9fec
    // 0x8d9fd8: ldr             x2, [fp, #0x10]
    // 0x8d9fdc: r0 = add()
    //     0x8d9fdc: bl              #0x8d9ee0  ; [package:crypto/src/hash_sink.dart] HashSink::add
    // 0x8d9fe0: LeaveFrame
    //     0x8d9fe0: mov             SP, fp
    //     0x8d9fe4: ldp             fp, lr, [SP], #0x10
    // 0x8d9fe8: ret
    //     0x8d9fe8: ret             
    // 0x8d9fec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d9fec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d9ff0: b               #0x8d9fd8
  }
  _ _addData(/* No info */) {
    // ** addr: 0x8d9ff4, size: 0x8c0
    // 0x8d9ff4: EnterFrame
    //     0x8d9ff4: stp             fp, lr, [SP, #-0x10]!
    //     0x8d9ff8: mov             fp, SP
    // 0x8d9ffc: AllocStack(0x70)
    //     0x8d9ffc: sub             SP, SP, #0x70
    // 0x8da000: SetupParameters(HashSink this /* r1 => r0, fp-0x20 */, dynamic _ /* r2 => r1, fp-0x28 */)
    //     0x8da000: mov             x0, x1
    //     0x8da004: stur            x1, [fp, #-0x20]
    //     0x8da008: mov             x1, x2
    //     0x8da00c: stur            x2, [fp, #-0x28]
    // 0x8da010: CheckStackOverflow
    //     0x8da010: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8da014: cmp             SP, x16
    //     0x8da018: b.ls            #0x8da890
    // 0x8da01c: ArrayLoad: r2 = r0[0]  ; List_8
    //     0x8da01c: ldur            x2, [x0, #0x17]
    // 0x8da020: stur            x2, [fp, #-0x18]
    // 0x8da024: LoadField: r3 = r0->field_13
    //     0x8da024: ldur            w3, [x0, #0x13]
    // 0x8da028: DecompressPointer r3
    //     0x8da028: add             x3, x3, HEAP, lsl #32
    // 0x8da02c: stur            x3, [fp, #-0x10]
    // 0x8da030: LoadField: r4 = r3->field_13
    //     0x8da030: ldur            w4, [x3, #0x13]
    // 0x8da034: stur            x4, [fp, #-8]
    // 0x8da038: LoadField: r5 = r0->field_f
    //     0x8da038: ldur            w5, [x0, #0xf]
    // 0x8da03c: DecompressPointer r5
    //     0x8da03c: add             x5, x5, HEAP, lsl #32
    // 0x8da040: cmp             w5, NULL
    // 0x8da044: b.ne            #0x8da084
    // 0x8da048: r0 = _ByteBuffer()
    //     0x8da048: bl              #0x7e9024  ; Allocate_ByteBufferStub -> _ByteBuffer (size=0xc)
    // 0x8da04c: mov             x1, x0
    // 0x8da050: ldur            x0, [fp, #-0x10]
    // 0x8da054: StoreField: r1->field_7 = r0
    //     0x8da054: stur            w0, [x1, #7]
    // 0x8da058: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8da058: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8da05c: r0 = asByteData()
    //     0x8da05c: bl              #0x13d99cc  ; [dart:typed_data] _ByteBuffer::asByteData
    // 0x8da060: ldur            x1, [fp, #-0x20]
    // 0x8da064: StoreField: r1->field_f = r0
    //     0x8da064: stur            w0, [x1, #0xf]
    //     0x8da068: ldurb           w16, [x1, #-1]
    //     0x8da06c: ldurb           w17, [x0, #-1]
    //     0x8da070: and             x16, x17, x16, lsr #2
    //     0x8da074: tst             x16, HEAP, lsr #32
    //     0x8da078: b.eq            #0x8da080
    //     0x8da07c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8da080: b               #0x8da088
    // 0x8da084: mov             x1, x0
    // 0x8da088: ldur            x2, [fp, #-8]
    // 0x8da08c: r3 = LoadInt32Instr(r2)
    //     0x8da08c: sbfx            x3, x2, #1, #0x1f
    // 0x8da090: stur            x3, [fp, #-0x58]
    // 0x8da094: LoadField: r4 = r1->field_1f
    //     0x8da094: ldur            w4, [x1, #0x1f]
    // 0x8da098: DecompressPointer r4
    //     0x8da098: add             x4, x4, HEAP, lsl #32
    // 0x8da09c: stur            x4, [fp, #-0x50]
    // 0x8da0a0: LoadField: r5 = r1->field_b
    //     0x8da0a0: ldur            w5, [x1, #0xb]
    // 0x8da0a4: DecompressPointer r5
    //     0x8da0a4: add             x5, x5, HEAP, lsl #32
    // 0x8da0a8: stur            x5, [fp, #-0x48]
    // 0x8da0ac: LoadField: r0 = r4->field_13
    //     0x8da0ac: ldur            w0, [x4, #0x13]
    // 0x8da0b0: r6 = LoadInt32Instr(r0)
    //     0x8da0b0: sbfx            x6, x0, #1, #0x1f
    // 0x8da0b4: stur            x6, [fp, #-0x40]
    // 0x8da0b8: mov             x7, THR
    // 0x8da0bc: stur            x7, [fp, #-0x38]
    // 0x8da0c0: ldur            x10, [fp, #-0x18]
    // 0x8da0c4: r11 = 0
    //     0x8da0c4: mov             x11, #0
    // 0x8da0c8: ldur            x9, [fp, #-0x28]
    // 0x8da0cc: ldur            x8, [fp, #-0x10]
    // 0x8da0d0: stur            x11, [fp, #-0x18]
    // 0x8da0d4: stur            x10, [fp, #-0x30]
    // 0x8da0d8: CheckStackOverflow
    //     0x8da0d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8da0dc: cmp             SP, x16
    //     0x8da0e0: b.ls            #0x8da898
    // 0x8da0e4: r0 = LoadClassIdInstr(r9)
    //     0x8da0e4: ldur            x0, [x9, #-1]
    //     0x8da0e8: ubfx            x0, x0, #0xc, #0x14
    // 0x8da0ec: str             x9, [SP]
    // 0x8da0f0: r0 = GDT[cid_x0 + 0xf078]()
    //     0x8da0f0: mov             x17, #0xf078
    //     0x8da0f4: add             lr, x0, x17
    //     0x8da0f8: ldr             lr, [x21, lr, lsl #3]
    //     0x8da0fc: blr             lr
    // 0x8da100: r1 = LoadInt32Instr(r0)
    //     0x8da100: sbfx            x1, x0, #1, #0x1f
    //     0x8da104: tbz             w0, #0, #0x8da10c
    //     0x8da108: ldur            x1, [x0, #7]
    // 0x8da10c: ldur            x0, [fp, #-0x30]
    // 0x8da110: add             x2, x0, x1
    // 0x8da114: ldur            x6, [fp, #-0x18]
    // 0x8da118: sub             x4, x2, x6
    // 0x8da11c: ldur            x5, [fp, #-0x58]
    // 0x8da120: stur            x4, [fp, #-0x68]
    // 0x8da124: cmp             x4, x5
    // 0x8da128: b.lt            #0x8da520
    // 0x8da12c: tbnz            x0, #0x3f, #0x8da138
    // 0x8da130: cmp             x0, x5
    // 0x8da134: b.le            #0x8da14c
    // 0x8da138: mov             x1, x0
    // 0x8da13c: ldur            x2, [fp, #-8]
    // 0x8da140: mov             x3, x5
    // 0x8da144: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x8da144: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x8da148: r0 = checkValidRange()
    //     0x8da148: bl              #0x7db068  ; [dart:core] RangeError::checkValidRange
    // 0x8da14c: ldur            x6, [fp, #-0x18]
    // 0x8da150: tbnz            x6, #0x3f, #0x8da7dc
    // 0x8da154: ldur            x2, [fp, #-0x28]
    // 0x8da158: r0 = LoadClassIdInstr(r2)
    //     0x8da158: ldur            x0, [x2, #-1]
    //     0x8da15c: ubfx            x0, x0, #0xc, #0x14
    // 0x8da160: sub             x16, x0, #0x70
    // 0x8da164: cmp             x16, #0x37
    // 0x8da168: b.hi            #0x8da3a0
    // 0x8da16c: r0 = LoadClassIdInstr(r2)
    //     0x8da16c: ldur            x0, [x2, #-1]
    //     0x8da170: ubfx            x0, x0, #0xc, #0x14
    // 0x8da174: mov             x1, x2
    // 0x8da178: r0 = GDT[cid_x0 + -0x7f5]()
    //     0x8da178: sub             lr, x0, #0x7f5
    //     0x8da17c: ldr             lr, [x21, lr, lsl #3]
    //     0x8da180: blr             lr
    // 0x8da184: cmp             x0, #1
    // 0x8da188: b.ne            #0x8da38c
    // 0x8da18c: ldur            x5, [fp, #-0x28]
    // 0x8da190: ldur            x6, [fp, #-0x18]
    // 0x8da194: ldur            x2, [fp, #-0x30]
    // 0x8da198: ldur            x3, [fp, #-0x58]
    // 0x8da19c: sub             x1, x3, x2
    // 0x8da1a0: stur            x1, [fp, #-0x60]
    // 0x8da1a4: r0 = LoadClassIdInstr(r5)
    //     0x8da1a4: ldur            x0, [x5, #-1]
    //     0x8da1a8: ubfx            x0, x0, #0xc, #0x14
    // 0x8da1ac: str             x5, [SP]
    // 0x8da1b0: r0 = GDT[cid_x0 + 0xf078]()
    //     0x8da1b0: mov             x17, #0xf078
    //     0x8da1b4: add             lr, x0, x17
    //     0x8da1b8: ldr             lr, [x21, lr, lsl #3]
    //     0x8da1bc: blr             lr
    // 0x8da1c0: r1 = LoadInt32Instr(r0)
    //     0x8da1c0: sbfx            x1, x0, #1, #0x1f
    //     0x8da1c4: tbz             w0, #0, #0x8da1cc
    //     0x8da1c8: ldur            x1, [x0, #7]
    // 0x8da1cc: ldur            x20, [fp, #-0x18]
    // 0x8da1d0: sub             x0, x1, x20
    // 0x8da1d4: ldur            x2, [fp, #-0x60]
    // 0x8da1d8: cmp             x0, x2
    // 0x8da1dc: b.lt            #0x8da7d0
    // 0x8da1e0: cbnz            x2, #0x8da1f0
    // 0x8da1e4: mov             x6, x20
    // 0x8da1e8: ldur            x5, [fp, #-0x30]
    // 0x8da1ec: b               #0x8da3d0
    // 0x8da1f0: r0 = BoxInt64Instr(r2)
    //     0x8da1f0: sbfiz           x0, x2, #1, #0x1f
    //     0x8da1f4: cmp             x2, x0, asr #1
    //     0x8da1f8: b.eq            #0x8da204
    //     0x8da1fc: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8da200: stur            x2, [x0, #7]
    // 0x8da204: mov             x3, x0
    // 0x8da208: cmp             w3, #0x800
    // 0x8da20c: b.ge            #0x8da320
    // 0x8da210: ldur            x23, [fp, #-0x28]
    // 0x8da214: ldur            x25, [fp, #-0x10]
    // 0x8da218: ldur            x24, [fp, #-0x30]
    // 0x8da21c: r0 = BoxInt64Instr(r20)
    //     0x8da21c: sbfiz           x0, x20, #1, #0x1f
    //     0x8da220: cmp             x20, x0, asr #1
    //     0x8da224: b.eq            #0x8da230
    //     0x8da228: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8da22c: stur            x20, [x0, #7]
    // 0x8da230: mov             x2, x0
    // 0x8da234: r0 = BoxInt64Instr(r24)
    //     0x8da234: sbfiz           x0, x24, #1, #0x1f
    //     0x8da238: cmp             x24, x0, asr #1
    //     0x8da23c: b.eq            #0x8da248
    //     0x8da240: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8da244: stur            x24, [x0, #7]
    // 0x8da248: LoadField: r1 = r23->field_7
    //     0x8da248: ldur            x1, [x23, #7]
    // 0x8da24c: mov             x5, x3
    // 0x8da250: sxtw            x2, w2
    // 0x8da254: add             x4, x1, x2, asr #1
    // 0x8da258: sxtw            x0, w0
    // 0x8da25c: add             x3, x25, x0, asr #1
    // 0x8da260: add             x3, x3, #0x17
    // 0x8da264: cbz             x5, #0x8da31c
    // 0x8da268: cmp             x3, x4
    // 0x8da26c: b.ls            #0x8da2d4
    // 0x8da270: sxtw            x5, w5
    // 0x8da274: add             x16, x4, x5, asr #1
    // 0x8da278: cmp             x3, x16
    // 0x8da27c: b.hs            #0x8da2d4
    // 0x8da280: mov             x4, x16
    // 0x8da284: add             x3, x3, x5, asr #1
    // 0x8da288: tbz             w5, #4, #0x8da294
    // 0x8da28c: ldr             x16, [x4, #-8]!
    // 0x8da290: str             x16, [x3, #-8]!
    // 0x8da294: tbz             w5, #3, #0x8da2a0
    // 0x8da298: ldr             w16, [x4, #-4]!
    // 0x8da29c: str             w16, [x3, #-4]!
    // 0x8da2a0: tbz             w5, #2, #0x8da2ac
    // 0x8da2a4: ldrh            w16, [x4, #-2]!
    // 0x8da2a8: strh            w16, [x3, #-2]!
    // 0x8da2ac: tbz             w5, #1, #0x8da2b8
    // 0x8da2b0: ldrb            w16, [x4, #-1]!
    // 0x8da2b4: strb            w16, [x3, #-1]!
    // 0x8da2b8: ands            w5, w5, #0xffffffe1
    // 0x8da2bc: b.eq            #0x8da31c
    // 0x8da2c0: ldp             x16, x17, [x4, #-0x10]!
    // 0x8da2c4: stp             x16, x17, [x3, #-0x10]!
    // 0x8da2c8: subs            w5, w5, #0x20
    // 0x8da2cc: b.ne            #0x8da2c0
    // 0x8da2d0: b               #0x8da31c
    // 0x8da2d4: tbz             w5, #4, #0x8da2e0
    // 0x8da2d8: ldr             x16, [x4], #8
    // 0x8da2dc: str             x16, [x3], #8
    // 0x8da2e0: tbz             w5, #3, #0x8da2ec
    // 0x8da2e4: ldr             w16, [x4], #4
    // 0x8da2e8: str             w16, [x3], #4
    // 0x8da2ec: tbz             w5, #2, #0x8da2f8
    // 0x8da2f0: ldrh            w16, [x4], #2
    // 0x8da2f4: strh            w16, [x3], #2
    // 0x8da2f8: tbz             w5, #1, #0x8da304
    // 0x8da2fc: ldrb            w16, [x4], #1
    // 0x8da300: strb            w16, [x3], #1
    // 0x8da304: ands            w5, w5, #0xffffffe1
    // 0x8da308: b.eq            #0x8da31c
    // 0x8da30c: ldp             x16, x17, [x4], #0x10
    // 0x8da310: stp             x16, x17, [x3], #0x10
    // 0x8da314: subs            w5, w5, #0x20
    // 0x8da318: b.ne            #0x8da30c
    // 0x8da31c: b               #0x8da380
    // 0x8da320: ldur            x23, [fp, #-0x28]
    // 0x8da324: ldur            x25, [fp, #-0x10]
    // 0x8da328: ldur            x24, [fp, #-0x30]
    // 0x8da32c: ldur            x3, [fp, #-0x38]
    // 0x8da330: LoadField: r0 = r25->field_7
    //     0x8da330: ldur            x0, [x25, #7]
    // 0x8da334: add             x1, x0, x24
    // 0x8da338: LoadField: r0 = r23->field_7
    //     0x8da338: ldur            x0, [x23, #7]
    // 0x8da33c: add             x4, x0, x20
    // 0x8da340: CallRuntime_MemoryMove(void*, const void*, size_t) -> void*
    //     0x8da340: ldr             x9, [x3, #0x888]
    //     0x8da344: mov             x0, x1
    //     0x8da348: mov             x1, x4
    //     0x8da34c: mov             x17, fp
    //     0x8da350: str             fp, [SP, #-8]!
    //     0x8da354: mov             fp, SP
    //     0x8da358: and             SP, SP, #0xfffffffffffffff0
    //     0x8da35c: mov             x19, sp
    //     0x8da360: mov             sp, SP
    //     0x8da364: str             x9, [THR, #0x6c8]  ; THR::vm_tag
    //     0x8da368: blr             x9
    //     0x8da36c: mov             x16, #8
    //     0x8da370: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x8da374: mov             sp, x19
    //     0x8da378: mov             SP, fp
    //     0x8da37c: ldr             fp, [SP], #8
    // 0x8da380: mov             x6, x20
    // 0x8da384: mov             x5, x24
    // 0x8da388: b               #0x8da3d0
    // 0x8da38c: ldur            x23, [fp, #-0x28]
    // 0x8da390: ldur            x25, [fp, #-0x10]
    // 0x8da394: ldur            x20, [fp, #-0x18]
    // 0x8da398: ldur            x24, [fp, #-0x30]
    // 0x8da39c: b               #0x8da3b0
    // 0x8da3a0: mov             x23, x2
    // 0x8da3a4: ldur            x25, [fp, #-0x10]
    // 0x8da3a8: mov             x20, x6
    // 0x8da3ac: ldur            x24, [fp, #-0x30]
    // 0x8da3b0: mov             x1, x25
    // 0x8da3b4: mov             x2, x24
    // 0x8da3b8: ldur            x3, [fp, #-0x58]
    // 0x8da3bc: mov             x5, x23
    // 0x8da3c0: mov             x6, x20
    // 0x8da3c4: r0 = _slowSetRange()
    //     0x8da3c4: bl              #0x117e940  ; [dart:typed_data] __Uint8List&_TypedList&_IntListMixin&_TypedIntListMixin::_slowSetRange
    // 0x8da3c8: ldur            x6, [fp, #-0x18]
    // 0x8da3cc: ldur            x5, [fp, #-0x30]
    // 0x8da3d0: ldur            x4, [fp, #-0x20]
    // 0x8da3d4: ldur            x3, [fp, #-0x58]
    // 0x8da3d8: sub             x0, x3, x5
    // 0x8da3dc: add             x11, x6, x0
    // 0x8da3e0: stur            x11, [fp, #-0x60]
    // 0x8da3e4: LoadField: r0 = r4->field_f
    //     0x8da3e4: ldur            w0, [x4, #0xf]
    // 0x8da3e8: DecompressPointer r0
    //     0x8da3e8: add             x0, x0, HEAP, lsl #32
    // 0x8da3ec: cmp             w0, NULL
    // 0x8da3f0: b.eq            #0x8da8a0
    // 0x8da3f4: LoadField: r1 = r0->field_13
    //     0x8da3f4: ldur            w1, [x0, #0x13]
    // 0x8da3f8: r2 = LoadInt32Instr(r1)
    //     0x8da3f8: sbfx            x2, x1, #1, #0x1f
    // 0x8da3fc: ArrayLoad: r5 = r0[0]  ; List_4
    //     0x8da3fc: ldur            w5, [x0, #0x17]
    // 0x8da400: DecompressPointer r5
    //     0x8da400: add             x5, x5, HEAP, lsl #32
    // 0x8da404: LoadField: r1 = r0->field_1b
    //     0x8da404: ldur            w1, [x0, #0x1b]
    // 0x8da408: r6 = LoadInt32Instr(r1)
    //     0x8da408: sbfx            x6, x1, #1, #0x1f
    // 0x8da40c: ldur            x7, [fp, #-0x50]
    // 0x8da410: ldur            x8, [fp, #-0x48]
    // 0x8da414: ldur            x9, [fp, #-0x40]
    // 0x8da418: r10 = 0
    //     0x8da418: mov             x10, #0
    // 0x8da41c: CheckStackOverflow
    //     0x8da41c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8da420: cmp             SP, x16
    //     0x8da424: b.ls            #0x8da8a4
    // 0x8da428: lsl             x12, x10, #2
    // 0x8da42c: add             x1, x12, #3
    // 0x8da430: mov             x0, x2
    // 0x8da434: cmp             x1, x0
    // 0x8da438: b.hs            #0x8da8ac
    // 0x8da43c: mov             x0, x2
    // 0x8da440: mov             x1, x12
    // 0x8da444: cmp             x1, x0
    // 0x8da448: b.hs            #0x8da8b0
    // 0x8da44c: add             x0, x6, x12
    // 0x8da450: LoadField: r1 = r5->field_7
    //     0x8da450: ldur            x1, [x5, #7]
    // 0x8da454: ldr             w12, [x1, x0]
    // 0x8da458: r16 = Instance_Endian
    //     0x8da458: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f780] Obj!Endian@12b79f1
    //     0x8da45c: ldr             x16, [x16, #0x780]
    // 0x8da460: cmp             w8, w16
    // 0x8da464: b.ne            #0x8da474
    // 0x8da468: mov             x0, x12
    // 0x8da46c: ubfx            x0, x0, #0, #0x20
    // 0x8da470: b               #0x8da4bc
    // 0x8da474: and             w0, w12, #0xff00ff00
    // 0x8da478: ubfx            x0, x0, #0, #0x20
    // 0x8da47c: asr             x1, x0, #8
    // 0x8da480: and             w0, w12, #0xff00ff
    // 0x8da484: ubfx            x0, x0, #0, #0x20
    // 0x8da488: lsl             x12, x0, #8
    // 0x8da48c: orr             x0, x1, x12
    // 0x8da490: mov             x1, x0
    // 0x8da494: ubfx            x1, x1, #0, #0x20
    // 0x8da498: and             w12, w1, #0xffff0000
    // 0x8da49c: ubfx            x12, x12, #0, #0x20
    // 0x8da4a0: asr             x1, x12, #0x10
    // 0x8da4a4: ubfx            x0, x0, #0, #0x20
    // 0x8da4a8: and             w12, w0, #0xffff
    // 0x8da4ac: ubfx            x12, x12, #0, #0x20
    // 0x8da4b0: lsl             x0, x12, #0x10
    // 0x8da4b4: orr             x12, x1, x0
    // 0x8da4b8: mov             x0, x12
    // 0x8da4bc: ubfx            x0, x0, #0, #0x20
    // 0x8da4c0: ArrayStore: r7[r10] = r0  ; List_4
    //     0x8da4c0: add             x1, x7, x10, lsl #2
    //     0x8da4c4: stur            w0, [x1, #0x17]
    // 0x8da4c8: add             x0, x10, #1
    // 0x8da4cc: cmp             x0, x9
    // 0x8da4d0: b.ge            #0x8da4dc
    // 0x8da4d4: mov             x10, x0
    // 0x8da4d8: b               #0x8da41c
    // 0x8da4dc: r0 = LoadClassIdInstr(r4)
    //     0x8da4dc: ldur            x0, [x4, #-1]
    //     0x8da4e0: ubfx            x0, x0, #0xc, #0x14
    // 0x8da4e4: mov             x1, x4
    // 0x8da4e8: mov             x2, x7
    // 0x8da4ec: r0 = GDT[cid_x0 + -0xfb9]()
    //     0x8da4ec: sub             lr, x0, #0xfb9
    //     0x8da4f0: ldr             lr, [x21, lr, lsl #3]
    //     0x8da4f4: blr             lr
    // 0x8da4f8: ldur            x11, [fp, #-0x60]
    // 0x8da4fc: ldur            x1, [fp, #-0x20]
    // 0x8da500: ldur            x4, [fp, #-0x50]
    // 0x8da504: ldur            x5, [fp, #-0x48]
    // 0x8da508: ldur            x2, [fp, #-8]
    // 0x8da50c: ldur            x7, [fp, #-0x38]
    // 0x8da510: ldur            x3, [fp, #-0x58]
    // 0x8da514: ldur            x6, [fp, #-0x40]
    // 0x8da518: r10 = 0
    //     0x8da518: mov             x10, #0
    // 0x8da51c: b               #0x8da0c8
    // 0x8da520: mov             x5, x0
    // 0x8da524: tbnz            x5, #0x3f, #0x8da530
    // 0x8da528: cmp             x5, x4
    // 0x8da52c: b.le            #0x8da558
    // 0x8da530: r0 = BoxInt64Instr(r4)
    //     0x8da530: sbfiz           x0, x4, #1, #0x1f
    //     0x8da534: cmp             x4, x0, asr #1
    //     0x8da538: b.eq            #0x8da544
    //     0x8da53c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8da540: stur            x4, [x0, #7]
    // 0x8da544: mov             x1, x5
    // 0x8da548: mov             x2, x0
    // 0x8da54c: ldur            x3, [fp, #-0x58]
    // 0x8da550: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x8da550: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x8da554: r0 = checkValidRange()
    //     0x8da554: bl              #0x7db068  ; [dart:core] RangeError::checkValidRange
    // 0x8da558: ldur            x6, [fp, #-0x18]
    // 0x8da55c: tbnz            x6, #0x3f, #0x8da828
    // 0x8da560: ldur            x2, [fp, #-0x28]
    // 0x8da564: r0 = LoadClassIdInstr(r2)
    //     0x8da564: ldur            x0, [x2, #-1]
    //     0x8da568: ubfx            x0, x0, #0xc, #0x14
    // 0x8da56c: sub             x16, x0, #0x70
    // 0x8da570: cmp             x16, #0x37
    // 0x8da574: b.hi            #0x8da798
    // 0x8da578: r0 = LoadClassIdInstr(r2)
    //     0x8da578: ldur            x0, [x2, #-1]
    //     0x8da57c: ubfx            x0, x0, #0xc, #0x14
    // 0x8da580: mov             x1, x2
    // 0x8da584: r0 = GDT[cid_x0 + -0x7f5]()
    //     0x8da584: sub             lr, x0, #0x7f5
    //     0x8da588: ldr             lr, [x21, lr, lsl #3]
    //     0x8da58c: blr             lr
    // 0x8da590: cmp             x0, #1
    // 0x8da594: b.ne            #0x8da784
    // 0x8da598: ldur            x5, [fp, #-0x28]
    // 0x8da59c: ldur            x6, [fp, #-0x18]
    // 0x8da5a0: ldur            x2, [fp, #-0x30]
    // 0x8da5a4: ldur            x3, [fp, #-0x68]
    // 0x8da5a8: sub             x1, x3, x2
    // 0x8da5ac: stur            x1, [fp, #-0x38]
    // 0x8da5b0: r0 = LoadClassIdInstr(r5)
    //     0x8da5b0: ldur            x0, [x5, #-1]
    //     0x8da5b4: ubfx            x0, x0, #0xc, #0x14
    // 0x8da5b8: str             x5, [SP]
    // 0x8da5bc: r0 = GDT[cid_x0 + 0xf078]()
    //     0x8da5bc: mov             x17, #0xf078
    //     0x8da5c0: add             lr, x0, x17
    //     0x8da5c4: ldr             lr, [x21, lr, lsl #3]
    //     0x8da5c8: blr             lr
    // 0x8da5cc: r1 = LoadInt32Instr(r0)
    //     0x8da5cc: sbfx            x1, x0, #1, #0x1f
    //     0x8da5d0: tbz             w0, #0, #0x8da5d8
    //     0x8da5d4: ldur            x1, [x0, #7]
    // 0x8da5d8: ldur            x6, [fp, #-0x18]
    // 0x8da5dc: sub             x0, x1, x6
    // 0x8da5e0: ldur            x2, [fp, #-0x38]
    // 0x8da5e4: cmp             x0, x2
    // 0x8da5e8: b.lt            #0x8da884
    // 0x8da5ec: cbz             x2, #0x8da7b4
    // 0x8da5f0: r0 = BoxInt64Instr(r2)
    //     0x8da5f0: sbfiz           x0, x2, #1, #0x1f
    //     0x8da5f4: cmp             x2, x0, asr #1
    //     0x8da5f8: b.eq            #0x8da604
    //     0x8da5fc: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8da600: stur            x2, [x0, #7]
    // 0x8da604: mov             x3, x0
    // 0x8da608: cmp             w3, #0x800
    // 0x8da60c: b.ge            #0x8da720
    // 0x8da610: ldur            x5, [fp, #-0x28]
    // 0x8da614: ldur            x7, [fp, #-0x10]
    // 0x8da618: ldur            x4, [fp, #-0x30]
    // 0x8da61c: r0 = BoxInt64Instr(r6)
    //     0x8da61c: sbfiz           x0, x6, #1, #0x1f
    //     0x8da620: cmp             x6, x0, asr #1
    //     0x8da624: b.eq            #0x8da630
    //     0x8da628: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8da62c: stur            x6, [x0, #7]
    // 0x8da630: mov             x2, x0
    // 0x8da634: r0 = BoxInt64Instr(r4)
    //     0x8da634: sbfiz           x0, x4, #1, #0x1f
    //     0x8da638: cmp             x4, x0, asr #1
    //     0x8da63c: b.eq            #0x8da648
    //     0x8da640: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8da644: stur            x4, [x0, #7]
    // 0x8da648: LoadField: r1 = r5->field_7
    //     0x8da648: ldur            x1, [x5, #7]
    // 0x8da64c: mov             x5, x3
    // 0x8da650: sxtw            x2, w2
    // 0x8da654: add             x4, x1, x2, asr #1
    // 0x8da658: sxtw            x0, w0
    // 0x8da65c: add             x3, x7, x0, asr #1
    // 0x8da660: add             x3, x3, #0x17
    // 0x8da664: cbz             x5, #0x8da71c
    // 0x8da668: cmp             x3, x4
    // 0x8da66c: b.ls            #0x8da6d4
    // 0x8da670: sxtw            x5, w5
    // 0x8da674: add             x16, x4, x5, asr #1
    // 0x8da678: cmp             x3, x16
    // 0x8da67c: b.hs            #0x8da6d4
    // 0x8da680: mov             x4, x16
    // 0x8da684: add             x3, x3, x5, asr #1
    // 0x8da688: tbz             w5, #4, #0x8da694
    // 0x8da68c: ldr             x16, [x4, #-8]!
    // 0x8da690: str             x16, [x3, #-8]!
    // 0x8da694: tbz             w5, #3, #0x8da6a0
    // 0x8da698: ldr             w16, [x4, #-4]!
    // 0x8da69c: str             w16, [x3, #-4]!
    // 0x8da6a0: tbz             w5, #2, #0x8da6ac
    // 0x8da6a4: ldrh            w16, [x4, #-2]!
    // 0x8da6a8: strh            w16, [x3, #-2]!
    // 0x8da6ac: tbz             w5, #1, #0x8da6b8
    // 0x8da6b0: ldrb            w16, [x4, #-1]!
    // 0x8da6b4: strb            w16, [x3, #-1]!
    // 0x8da6b8: ands            w5, w5, #0xffffffe1
    // 0x8da6bc: b.eq            #0x8da71c
    // 0x8da6c0: ldp             x16, x17, [x4, #-0x10]!
    // 0x8da6c4: stp             x16, x17, [x3, #-0x10]!
    // 0x8da6c8: subs            w5, w5, #0x20
    // 0x8da6cc: b.ne            #0x8da6c0
    // 0x8da6d0: b               #0x8da71c
    // 0x8da6d4: tbz             w5, #4, #0x8da6e0
    // 0x8da6d8: ldr             x16, [x4], #8
    // 0x8da6dc: str             x16, [x3], #8
    // 0x8da6e0: tbz             w5, #3, #0x8da6ec
    // 0x8da6e4: ldr             w16, [x4], #4
    // 0x8da6e8: str             w16, [x3], #4
    // 0x8da6ec: tbz             w5, #2, #0x8da6f8
    // 0x8da6f0: ldrh            w16, [x4], #2
    // 0x8da6f4: strh            w16, [x3], #2
    // 0x8da6f8: tbz             w5, #1, #0x8da704
    // 0x8da6fc: ldrb            w16, [x4], #1
    // 0x8da700: strb            w16, [x3], #1
    // 0x8da704: ands            w5, w5, #0xffffffe1
    // 0x8da708: b.eq            #0x8da71c
    // 0x8da70c: ldp             x16, x17, [x4], #0x10
    // 0x8da710: stp             x16, x17, [x3], #0x10
    // 0x8da714: subs            w5, w5, #0x20
    // 0x8da718: b.ne            #0x8da70c
    // 0x8da71c: b               #0x8da7b4
    // 0x8da720: ldur            x5, [fp, #-0x28]
    // 0x8da724: ldur            x7, [fp, #-0x10]
    // 0x8da728: ldur            x4, [fp, #-0x30]
    // 0x8da72c: LoadField: r0 = r7->field_7
    //     0x8da72c: ldur            x0, [x7, #7]
    // 0x8da730: add             x1, x0, x4
    // 0x8da734: LoadField: r0 = r5->field_7
    //     0x8da734: ldur            x0, [x5, #7]
    // 0x8da738: add             x3, x0, x6
    // 0x8da73c: CallRuntime_MemoryMove(void*, const void*, size_t) -> void*
    //     0x8da73c: mov             x0, THR
    //     0x8da740: ldr             x9, [x0, #0x888]
    //     0x8da744: mov             x0, x1
    //     0x8da748: mov             x1, x3
    //     0x8da74c: mov             x17, fp
    //     0x8da750: str             fp, [SP, #-8]!
    //     0x8da754: mov             fp, SP
    //     0x8da758: and             SP, SP, #0xfffffffffffffff0
    //     0x8da75c: mov             x19, sp
    //     0x8da760: mov             sp, SP
    //     0x8da764: str             x9, [THR, #0x6c8]  ; THR::vm_tag
    //     0x8da768: blr             x9
    //     0x8da76c: mov             x16, #8
    //     0x8da770: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x8da774: mov             sp, x19
    //     0x8da778: mov             SP, fp
    //     0x8da77c: ldr             fp, [SP], #8
    // 0x8da780: b               #0x8da7b4
    // 0x8da784: ldur            x5, [fp, #-0x28]
    // 0x8da788: ldur            x7, [fp, #-0x10]
    // 0x8da78c: ldur            x6, [fp, #-0x18]
    // 0x8da790: ldur            x4, [fp, #-0x30]
    // 0x8da794: b               #0x8da7a4
    // 0x8da798: mov             x5, x2
    // 0x8da79c: ldur            x7, [fp, #-0x10]
    // 0x8da7a0: ldur            x4, [fp, #-0x30]
    // 0x8da7a4: mov             x1, x7
    // 0x8da7a8: mov             x2, x4
    // 0x8da7ac: ldur            x3, [fp, #-0x68]
    // 0x8da7b0: r0 = _slowSetRange()
    //     0x8da7b0: bl              #0x117e940  ; [dart:typed_data] __Uint8List&_TypedList&_IntListMixin&_TypedIntListMixin::_slowSetRange
    // 0x8da7b4: ldur            x1, [fp, #-0x20]
    // 0x8da7b8: ldur            x0, [fp, #-0x68]
    // 0x8da7bc: ArrayStore: r1[0] = r0  ; List_8
    //     0x8da7bc: stur            x0, [x1, #0x17]
    // 0x8da7c0: r0 = Null
    //     0x8da7c0: mov             x0, NULL
    // 0x8da7c4: LeaveFrame
    //     0x8da7c4: mov             SP, fp
    //     0x8da7c8: ldp             fp, lr, [SP], #0x10
    // 0x8da7cc: ret
    //     0x8da7cc: ret             
    // 0x8da7d0: r0 = tooFew()
    //     0x8da7d0: bl              #0x7e9534  ; [dart:_internal] IterableElementError::tooFew
    // 0x8da7d4: r0 = Throw()
    //     0x8da7d4: bl              #0x13ddb2c  ; ThrowStub
    // 0x8da7d8: brk             #0
    // 0x8da7dc: r0 = RangeError()
    //     0x8da7dc: bl              #0x7db570  ; AllocateRangeErrorStub -> RangeError (size=0x24)
    // 0x8da7e0: mov             x2, x0
    // 0x8da7e4: StoreField: r2->field_1b = rZR
    //     0x8da7e4: stur            wzr, [x2, #0x1b]
    // 0x8da7e8: r0 = "skipCount"
    //     0x8da7e8: ldr             x0, [PP, #0x1240]  ; [pp+0x1240] "skipCount"
    // 0x8da7ec: StoreField: r2->field_13 = r0
    //     0x8da7ec: stur            w0, [x2, #0x13]
    // 0x8da7f0: r1 = "Invalid value"
    //     0x8da7f0: ldr             x1, [PP, #0x950]  ; [pp+0x950] "Invalid value"
    // 0x8da7f4: ArrayStore: r2[0] = r1  ; List_4
    //     0x8da7f4: stur            w1, [x2, #0x17]
    // 0x8da7f8: ldur            x3, [fp, #-0x18]
    // 0x8da7fc: r0 = BoxInt64Instr(r3)
    //     0x8da7fc: sbfiz           x0, x3, #1, #0x1f
    //     0x8da800: cmp             x3, x0, asr #1
    //     0x8da804: b.eq            #0x8da810
    //     0x8da808: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8da80c: stur            x3, [x0, #7]
    // 0x8da810: StoreField: r2->field_f = r0
    //     0x8da810: stur            w0, [x2, #0xf]
    // 0x8da814: r4 = true
    //     0x8da814: add             x4, NULL, #0x20  ; true
    // 0x8da818: StoreField: r2->field_b = r4
    //     0x8da818: stur            w4, [x2, #0xb]
    // 0x8da81c: mov             x0, x2
    // 0x8da820: r0 = Throw()
    //     0x8da820: bl              #0x13ddb2c  ; ThrowStub
    // 0x8da824: brk             #0
    // 0x8da828: mov             x3, x6
    // 0x8da82c: r4 = true
    //     0x8da82c: add             x4, NULL, #0x20  ; true
    // 0x8da830: r0 = "skipCount"
    //     0x8da830: ldr             x0, [PP, #0x1240]  ; [pp+0x1240] "skipCount"
    // 0x8da834: r1 = "Invalid value"
    //     0x8da834: ldr             x1, [PP, #0x950]  ; [pp+0x950] "Invalid value"
    // 0x8da838: r0 = RangeError()
    //     0x8da838: bl              #0x7db570  ; AllocateRangeErrorStub -> RangeError (size=0x24)
    // 0x8da83c: mov             x2, x0
    // 0x8da840: StoreField: r2->field_1b = rZR
    //     0x8da840: stur            wzr, [x2, #0x1b]
    // 0x8da844: r0 = "skipCount"
    //     0x8da844: ldr             x0, [PP, #0x1240]  ; [pp+0x1240] "skipCount"
    // 0x8da848: StoreField: r2->field_13 = r0
    //     0x8da848: stur            w0, [x2, #0x13]
    // 0x8da84c: r0 = "Invalid value"
    //     0x8da84c: ldr             x0, [PP, #0x950]  ; [pp+0x950] "Invalid value"
    // 0x8da850: ArrayStore: r2[0] = r0  ; List_4
    //     0x8da850: stur            w0, [x2, #0x17]
    // 0x8da854: ldur            x3, [fp, #-0x18]
    // 0x8da858: r0 = BoxInt64Instr(r3)
    //     0x8da858: sbfiz           x0, x3, #1, #0x1f
    //     0x8da85c: cmp             x3, x0, asr #1
    //     0x8da860: b.eq            #0x8da86c
    //     0x8da864: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8da868: stur            x3, [x0, #7]
    // 0x8da86c: StoreField: r2->field_f = r0
    //     0x8da86c: stur            w0, [x2, #0xf]
    // 0x8da870: r0 = true
    //     0x8da870: add             x0, NULL, #0x20  ; true
    // 0x8da874: StoreField: r2->field_b = r0
    //     0x8da874: stur            w0, [x2, #0xb]
    // 0x8da878: mov             x0, x2
    // 0x8da87c: r0 = Throw()
    //     0x8da87c: bl              #0x13ddb2c  ; ThrowStub
    // 0x8da880: brk             #0
    // 0x8da884: r0 = tooFew()
    //     0x8da884: bl              #0x7e9534  ; [dart:_internal] IterableElementError::tooFew
    // 0x8da888: r0 = Throw()
    //     0x8da888: bl              #0x13ddb2c  ; ThrowStub
    // 0x8da88c: brk             #0
    // 0x8da890: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8da890: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8da894: b               #0x8da01c
    // 0x8da898: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8da898: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8da89c: b               #0x8da0e4
    // 0x8da8a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8da8a0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8da8a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8da8a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8da8a8: b               #0x8da428
    // 0x8da8ac: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8da8ac: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8da8b0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8da8b0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  dynamic add(dynamic) {
    // ** addr: 0x8db2d4, size: 0x24
    // 0x8db2d4: EnterFrame
    //     0x8db2d4: stp             fp, lr, [SP, #-0x10]!
    //     0x8db2d8: mov             fp, SP
    // 0x8db2dc: ldr             x2, [fp, #0x10]
    // 0x8db2e0: r1 = Function 'add':.
    //     0x8db2e0: add             x1, PP, #0x7e, lsl #12  ; [pp+0x7ed98] AnonymousClosure: (0x8d9fb8), in [package:crypto/src/hash_sink.dart] HashSink::add (0x8d9ee0)
    //     0x8db2e4: ldr             x1, [x1, #0xd98]
    // 0x8db2e8: r0 = AllocateClosure()
    //     0x8db2e8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8db2ec: LeaveFrame
    //     0x8db2ec: mov             SP, fp
    //     0x8db2f0: ldp             fp, lr, [SP], #0x10
    // 0x8db2f4: ret
    //     0x8db2f4: ret             
  }
  _ close(/* No info */) {
    // ** addr: 0x8de820, size: 0xa0
    // 0x8de820: EnterFrame
    //     0x8de820: stp             fp, lr, [SP, #-0x10]!
    //     0x8de824: mov             fp, SP
    // 0x8de828: AllocStack(0x10)
    //     0x8de828: sub             SP, SP, #0x10
    // 0x8de82c: SetupParameters(HashSink this /* r1 => r0, fp-0x8 */)
    //     0x8de82c: mov             x0, x1
    //     0x8de830: stur            x1, [fp, #-8]
    // 0x8de834: CheckStackOverflow
    //     0x8de834: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8de838: cmp             SP, x16
    //     0x8de83c: b.ls            #0x8de8b8
    // 0x8de840: LoadField: r1 = r0->field_2b
    //     0x8de840: ldur            w1, [x0, #0x2b]
    // 0x8de844: DecompressPointer r1
    //     0x8de844: add             x1, x1, HEAP, lsl #32
    // 0x8de848: tbnz            w1, #4, #0x8de85c
    // 0x8de84c: r0 = Null
    //     0x8de84c: mov             x0, NULL
    // 0x8de850: LeaveFrame
    //     0x8de850: mov             SP, fp
    //     0x8de854: ldp             fp, lr, [SP], #0x10
    // 0x8de858: ret
    //     0x8de858: ret             
    // 0x8de85c: r1 = true
    //     0x8de85c: add             x1, NULL, #0x20  ; true
    // 0x8de860: StoreField: r0->field_2b = r1
    //     0x8de860: stur            w1, [x0, #0x2b]
    // 0x8de864: mov             x1, x0
    // 0x8de868: r0 = _finalizeAndProcessData()
    //     0x8de868: bl              #0x8dea88  ; [package:crypto/src/hash_sink.dart] HashSink::_finalizeAndProcessData
    // 0x8de86c: ldur            x1, [fp, #-8]
    // 0x8de870: LoadField: r0 = r1->field_7
    //     0x8de870: ldur            w0, [x1, #7]
    // 0x8de874: DecompressPointer r0
    //     0x8de874: add             x0, x0, HEAP, lsl #32
    // 0x8de878: stur            x0, [fp, #-0x10]
    // 0x8de87c: r0 = _byteDigest()
    //     0x8de87c: bl              #0x8de8cc  ; [package:crypto/src/hash_sink.dart] HashSink::_byteDigest
    // 0x8de880: stur            x0, [fp, #-8]
    // 0x8de884: r0 = Digest()
    //     0x8de884: bl              #0x8de8c0  ; AllocateDigestStub -> Digest (size=0xc)
    // 0x8de888: mov             x1, x0
    // 0x8de88c: ldur            x0, [fp, #-8]
    // 0x8de890: StoreField: r1->field_7 = r0
    //     0x8de890: stur            w0, [x1, #7]
    // 0x8de894: mov             x2, x1
    // 0x8de898: ldur            x1, [fp, #-0x10]
    // 0x8de89c: r0 = add()
    //     0x8de89c: bl              #0x8d9e00  ; [package:crypto/src/digest_sink.dart] DigestSink::add
    // 0x8de8a0: ldur            x1, [fp, #-0x10]
    // 0x8de8a4: r0 = close()
    //     0x8de8a4: bl              #0x8de7d8  ; [package:crypto/src/digest_sink.dart] DigestSink::close
    // 0x8de8a8: r0 = Null
    //     0x8de8a8: mov             x0, NULL
    // 0x8de8ac: LeaveFrame
    //     0x8de8ac: mov             SP, fp
    //     0x8de8b0: ldp             fp, lr, [SP], #0x10
    // 0x8de8b4: ret
    //     0x8de8b4: ret             
    // 0x8de8b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8de8b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8de8bc: b               #0x8de840
  }
  _ _byteDigest(/* No info */) {
    // ** addr: 0x8de8cc, size: 0x1bc
    // 0x8de8cc: EnterFrame
    //     0x8de8cc: stp             fp, lr, [SP, #-0x10]!
    //     0x8de8d0: mov             fp, SP
    // 0x8de8d4: AllocStack(0x18)
    //     0x8de8d4: sub             SP, SP, #0x18
    // 0x8de8d8: CheckStackOverflow
    //     0x8de8d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8de8dc: cmp             SP, x16
    //     0x8de8e0: b.ls            #0x8dea70
    // 0x8de8e4: LoadField: r0 = r1->field_b
    //     0x8de8e4: ldur            w0, [x1, #0xb]
    // 0x8de8e8: DecompressPointer r0
    //     0x8de8e8: add             x0, x0, HEAP, lsl #32
    // 0x8de8ec: r16 = Instance_Endian
    //     0x8de8ec: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f780] Obj!Endian@12b79f1
    //     0x8de8f0: ldr             x16, [x16, #0x780]
    // 0x8de8f4: cmp             w0, w16
    // 0x8de8f8: b.ne            #0x8de938
    // 0x8de8fc: r0 = LoadClassIdInstr(r1)
    //     0x8de8fc: ldur            x0, [x1, #-1]
    //     0x8de900: ubfx            x0, x0, #0xc, #0x14
    // 0x8de904: r0 = GDT[cid_x0 + -0xffe]()
    //     0x8de904: sub             lr, x0, #0xffe
    //     0x8de908: ldr             lr, [x21, lr, lsl #3]
    //     0x8de90c: blr             lr
    // 0x8de910: stur            x0, [fp, #-8]
    // 0x8de914: r0 = _ByteBuffer()
    //     0x8de914: bl              #0x7e9024  ; Allocate_ByteBufferStub -> _ByteBuffer (size=0xc)
    // 0x8de918: mov             x1, x0
    // 0x8de91c: ldur            x0, [fp, #-8]
    // 0x8de920: StoreField: r1->field_7 = r0
    //     0x8de920: stur            w0, [x1, #7]
    // 0x8de924: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8de924: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8de928: r0 = asUint8List()
    //     0x8de928: bl              #0x13d9b38  ; [dart:typed_data] _ByteBuffer::asUint8List
    // 0x8de92c: LeaveFrame
    //     0x8de92c: mov             SP, fp
    //     0x8de930: ldp             fp, lr, [SP], #0x10
    // 0x8de934: ret
    //     0x8de934: ret             
    // 0x8de938: r0 = LoadClassIdInstr(r1)
    //     0x8de938: ldur            x0, [x1, #-1]
    //     0x8de93c: ubfx            x0, x0, #0xc, #0x14
    // 0x8de940: r0 = GDT[cid_x0 + -0xffe]()
    //     0x8de940: sub             lr, x0, #0xffe
    //     0x8de944: ldr             lr, [x21, lr, lsl #3]
    //     0x8de948: blr             lr
    // 0x8de94c: mov             x2, x0
    // 0x8de950: stur            x2, [fp, #-8]
    // 0x8de954: LoadField: r0 = r2->field_13
    //     0x8de954: ldur            w0, [x2, #0x13]
    // 0x8de958: r3 = LoadInt32Instr(r0)
    //     0x8de958: sbfx            x3, x0, #1, #0x1f
    // 0x8de95c: stur            x3, [fp, #-0x10]
    // 0x8de960: lsl             x4, x3, #2
    // 0x8de964: r0 = BoxInt64Instr(r4)
    //     0x8de964: sbfiz           x0, x4, #1, #0x1f
    //     0x8de968: cmp             x4, x0, asr #1
    //     0x8de96c: b.eq            #0x8de978
    //     0x8de970: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8de974: stur            x4, [x0, #7]
    // 0x8de978: mov             x4, x0
    // 0x8de97c: r0 = AllocateUint8Array()
    //     0x8de97c: bl              #0x13df5f0  ; AllocateUint8ArrayStub
    // 0x8de980: stur            x0, [fp, #-0x18]
    // 0x8de984: r0 = _ByteBuffer()
    //     0x8de984: bl              #0x7e9024  ; Allocate_ByteBufferStub -> _ByteBuffer (size=0xc)
    // 0x8de988: mov             x1, x0
    // 0x8de98c: ldur            x0, [fp, #-0x18]
    // 0x8de990: StoreField: r1->field_7 = r0
    //     0x8de990: stur            w0, [x1, #7]
    // 0x8de994: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8de994: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8de998: r0 = asByteData()
    //     0x8de998: bl              #0x13d99cc  ; [dart:typed_data] _ByteBuffer::asByteData
    // 0x8de99c: LoadField: r2 = r0->field_13
    //     0x8de99c: ldur            w2, [x0, #0x13]
    // 0x8de9a0: r3 = LoadInt32Instr(r2)
    //     0x8de9a0: sbfx            x3, x2, #1, #0x1f
    // 0x8de9a4: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x8de9a4: ldur            w2, [x0, #0x17]
    // 0x8de9a8: DecompressPointer r2
    //     0x8de9a8: add             x2, x2, HEAP, lsl #32
    // 0x8de9ac: LoadField: r4 = r0->field_1b
    //     0x8de9ac: ldur            w4, [x0, #0x1b]
    // 0x8de9b0: r5 = LoadInt32Instr(r4)
    //     0x8de9b0: sbfx            x5, x4, #1, #0x1f
    // 0x8de9b4: ldur            x4, [fp, #-8]
    // 0x8de9b8: ldur            x6, [fp, #-0x10]
    // 0x8de9bc: r7 = 0
    //     0x8de9bc: mov             x7, #0
    // 0x8de9c0: CheckStackOverflow
    //     0x8de9c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8de9c4: cmp             SP, x16
    //     0x8de9c8: b.ls            #0x8dea78
    // 0x8de9cc: cmp             x7, x6
    // 0x8de9d0: b.ge            #0x8dea60
    // 0x8de9d4: lsl             x8, x7, #2
    // 0x8de9d8: ArrayLoad: r9 = r4[r7]  ; List_4
    //     0x8de9d8: add             x16, x4, x7, lsl #2
    //     0x8de9dc: ldur            w9, [x16, #0x17]
    // 0x8de9e0: add             x1, x8, #3
    // 0x8de9e4: mov             x0, x3
    // 0x8de9e8: cmp             x1, x0
    // 0x8de9ec: b.hs            #0x8dea80
    // 0x8de9f0: mov             x0, x3
    // 0x8de9f4: mov             x1, x8
    // 0x8de9f8: cmp             x1, x0
    // 0x8de9fc: b.hs            #0x8dea84
    // 0x8dea00: add             x1, x5, x8
    // 0x8dea04: and             w8, w9, #0xff00ff00
    // 0x8dea08: ubfx            x8, x8, #0, #0x20
    // 0x8dea0c: asr             x10, x8, #8
    // 0x8dea10: and             w8, w9, #0xff00ff
    // 0x8dea14: ubfx            x8, x8, #0, #0x20
    // 0x8dea18: lsl             x9, x8, #8
    // 0x8dea1c: orr             x8, x10, x9
    // 0x8dea20: mov             x9, x8
    // 0x8dea24: ubfx            x9, x9, #0, #0x20
    // 0x8dea28: and             w10, w9, #0xffff0000
    // 0x8dea2c: ubfx            x10, x10, #0, #0x20
    // 0x8dea30: asr             x9, x10, #0x10
    // 0x8dea34: ubfx            x8, x8, #0, #0x20
    // 0x8dea38: and             w10, w8, #0xffff
    // 0x8dea3c: ubfx            x10, x10, #0, #0x20
    // 0x8dea40: lsl             x8, x10, #0x10
    // 0x8dea44: orr             x10, x9, x8
    // 0x8dea48: ubfx            x10, x10, #0, #0x20
    // 0x8dea4c: LoadField: r8 = r2->field_7
    //     0x8dea4c: ldur            x8, [x2, #7]
    // 0x8dea50: str             w10, [x8, x1]
    // 0x8dea54: add             x0, x7, #1
    // 0x8dea58: mov             x7, x0
    // 0x8dea5c: b               #0x8de9c0
    // 0x8dea60: ldur            x0, [fp, #-0x18]
    // 0x8dea64: LeaveFrame
    //     0x8dea64: mov             SP, fp
    //     0x8dea68: ldp             fp, lr, [SP], #0x10
    // 0x8dea6c: ret
    //     0x8dea6c: ret             
    // 0x8dea70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8dea70: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8dea74: b               #0x8de8e4
    // 0x8dea78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8dea78: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8dea7c: b               #0x8de9cc
    // 0x8dea80: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8dea80: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8dea84: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8dea84: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _finalizeAndProcessData(/* No info */) {
    // ** addr: 0x8dea88, size: 0x3d8
    // 0x8dea88: EnterFrame
    //     0x8dea88: stp             fp, lr, [SP, #-0x10]!
    //     0x8dea8c: mov             fp, SP
    // 0x8dea90: AllocStack(0x28)
    //     0x8dea90: sub             SP, SP, #0x28
    // 0x8dea94: SetupParameters(HashSink this /* r1 => r2, fp-0x18 */)
    //     0x8dea94: mov             x2, x1
    //     0x8dea98: stur            x1, [fp, #-0x18]
    // 0x8dea9c: CheckStackOverflow
    //     0x8dea9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8deaa0: cmp             SP, x16
    //     0x8deaa4: b.ls            #0x8dee34
    // 0x8deaa8: LoadField: r3 = r2->field_23
    //     0x8deaa8: ldur            x3, [x2, #0x23]
    // 0x8deaac: stur            x3, [fp, #-0x10]
    // 0x8deab0: r17 = 1125899906842623
    //     0x8deab0: mov             x17, #0x3ffffffffffff
    // 0x8deab4: cmp             x3, x17
    // 0x8deab8: b.gt            #0x8dee14
    // 0x8deabc: add             x0, x3, #1
    // 0x8deac0: LoadField: r1 = r2->field_2f
    //     0x8deac0: ldur            x1, [x2, #0x2f]
    // 0x8deac4: add             x4, x0, x1
    // 0x8deac8: LoadField: r0 = r2->field_13
    //     0x8deac8: ldur            w0, [x2, #0x13]
    // 0x8deacc: DecompressPointer r0
    //     0x8deacc: add             x0, x0, HEAP, lsl #32
    // 0x8dead0: LoadField: r1 = r0->field_13
    //     0x8dead0: ldur            w1, [x0, #0x13]
    // 0x8dead4: r0 = LoadInt32Instr(r1)
    //     0x8dead4: sbfx            x0, x1, #1, #0x1f
    // 0x8dead8: add             x1, x4, x0
    // 0x8deadc: sub             x4, x1, #1
    // 0x8deae0: neg             x1, x0
    // 0x8deae4: and             x0, x4, x1
    // 0x8deae8: sub             x5, x0, x3
    // 0x8deaec: stur            x5, [fp, #-8]
    // 0x8deaf0: r0 = BoxInt64Instr(r5)
    //     0x8deaf0: sbfiz           x0, x5, #1, #0x1f
    //     0x8deaf4: cmp             x5, x0, asr #1
    //     0x8deaf8: b.eq            #0x8deb04
    //     0x8deafc: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8deb00: stur            x5, [x0, #7]
    // 0x8deb04: mov             x4, x0
    // 0x8deb08: mov             x0, x5
    // 0x8deb0c: r1 = 0
    //     0x8deb0c: mov             x1, #0
    // 0x8deb10: cmp             x1, x0
    // 0x8deb14: b.hs            #0x8dee3c
    // 0x8deb18: r0 = AllocateUint8Array()
    //     0x8deb18: bl              #0x13df5f0  ; AllocateUint8ArrayStub
    // 0x8deb1c: mov             x1, x0
    // 0x8deb20: r0 = 128
    //     0x8deb20: mov             x0, #0x80
    // 0x8deb24: stur            x1, [fp, #-0x28]
    // 0x8deb28: ArrayStore: r1[0] = r0  ; TypeUnknown_1
    //     0x8deb28: strb            w0, [x1, #0x17]
    // 0x8deb2c: ldur            x0, [fp, #-0x10]
    // 0x8deb30: lsl             x2, x0, #3
    // 0x8deb34: ldur            x0, [fp, #-8]
    // 0x8deb38: stur            x2, [fp, #-0x20]
    // 0x8deb3c: sub             x3, x0, #8
    // 0x8deb40: stur            x3, [fp, #-0x10]
    // 0x8deb44: r0 = _ByteBuffer()
    //     0x8deb44: bl              #0x7e9024  ; Allocate_ByteBufferStub -> _ByteBuffer (size=0xc)
    // 0x8deb48: ldur            x2, [fp, #-0x28]
    // 0x8deb4c: StoreField: r0->field_7 = r2
    //     0x8deb4c: stur            w2, [x0, #7]
    // 0x8deb50: mov             x1, x0
    // 0x8deb54: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8deb54: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8deb58: r0 = asByteData()
    //     0x8deb58: bl              #0x13d99cc  ; [dart:typed_data] _ByteBuffer::asByteData
    // 0x8deb5c: mov             x2, x0
    // 0x8deb60: ldur            x0, [fp, #-0x20]
    // 0x8deb64: r1 = 4294967296
    //     0x8deb64: mov             x1, #0x100000000
    // 0x8deb68: sdiv            x3, x0, x1
    // 0x8deb6c: mov             x4, x0
    // 0x8deb70: ubfx            x4, x4, #0, #0x20
    // 0x8deb74: ldur            x5, [fp, #-0x18]
    // 0x8deb78: LoadField: r6 = r5->field_b
    //     0x8deb78: ldur            w6, [x5, #0xb]
    // 0x8deb7c: DecompressPointer r6
    //     0x8deb7c: add             x6, x6, HEAP, lsl #32
    // 0x8deb80: r16 = Instance_Endian
    //     0x8deb80: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f788] Obj!Endian@12b7a01
    //     0x8deb84: ldr             x16, [x16, #0x788]
    // 0x8deb88: cmp             w6, w16
    // 0x8deb8c: b.ne            #0x8deca8
    // 0x8deb90: ldur            x7, [fp, #-0x10]
    // 0x8deb94: add             x1, x7, #3
    // 0x8deb98: LoadField: r0 = r2->field_13
    //     0x8deb98: ldur            w0, [x2, #0x13]
    // 0x8deb9c: r6 = LoadInt32Instr(r0)
    //     0x8deb9c: sbfx            x6, x0, #1, #0x1f
    // 0x8deba0: mov             x0, x6
    // 0x8deba4: cmp             x1, x0
    // 0x8deba8: b.hs            #0x8dee40
    // 0x8debac: mov             x0, x6
    // 0x8debb0: mov             x1, x7
    // 0x8debb4: cmp             x1, x0
    // 0x8debb8: b.hs            #0x8dee44
    // 0x8debbc: ArrayLoad: r8 = r2[0]  ; List_4
    //     0x8debbc: ldur            w8, [x2, #0x17]
    // 0x8debc0: DecompressPointer r8
    //     0x8debc0: add             x8, x8, HEAP, lsl #32
    // 0x8debc4: LoadField: r0 = r2->field_1b
    //     0x8debc4: ldur            w0, [x2, #0x1b]
    // 0x8debc8: r2 = LoadInt32Instr(r0)
    //     0x8debc8: sbfx            x2, x0, #1, #0x1f
    // 0x8debcc: add             x0, x2, x7
    // 0x8debd0: mov             x1, x3
    // 0x8debd4: ubfx            x1, x1, #0, #0x20
    // 0x8debd8: and             w9, w1, #0xff00ff00
    // 0x8debdc: ubfx            x9, x9, #0, #0x20
    // 0x8debe0: asr             x1, x9, #8
    // 0x8debe4: ubfx            x3, x3, #0, #0x20
    // 0x8debe8: and             w9, w3, #0xff00ff
    // 0x8debec: ubfx            x9, x9, #0, #0x20
    // 0x8debf0: lsl             x3, x9, #8
    // 0x8debf4: orr             x9, x1, x3
    // 0x8debf8: mov             x1, x9
    // 0x8debfc: ubfx            x1, x1, #0, #0x20
    // 0x8dec00: and             w3, w1, #0xffff0000
    // 0x8dec04: ubfx            x3, x3, #0, #0x20
    // 0x8dec08: asr             x1, x3, #0x10
    // 0x8dec0c: ubfx            x9, x9, #0, #0x20
    // 0x8dec10: and             w3, w9, #0xffff
    // 0x8dec14: ubfx            x3, x3, #0, #0x20
    // 0x8dec18: lsl             x9, x3, #0x10
    // 0x8dec1c: orr             x3, x1, x9
    // 0x8dec20: ubfx            x3, x3, #0, #0x20
    // 0x8dec24: LoadField: r1 = r8->field_7
    //     0x8dec24: ldur            x1, [x8, #7]
    // 0x8dec28: str             w3, [x1, x0]
    // 0x8dec2c: add             x3, x7, #4
    // 0x8dec30: add             x1, x3, #3
    // 0x8dec34: mov             x0, x6
    // 0x8dec38: cmp             x1, x0
    // 0x8dec3c: b.hs            #0x8dee48
    // 0x8dec40: mov             x0, x6
    // 0x8dec44: mov             x1, x3
    // 0x8dec48: cmp             x1, x0
    // 0x8dec4c: b.hs            #0x8dee4c
    // 0x8dec50: add             x0, x2, x3
    // 0x8dec54: and             w1, w4, #0xff00ff00
    // 0x8dec58: ubfx            x1, x1, #0, #0x20
    // 0x8dec5c: asr             x2, x1, #8
    // 0x8dec60: and             w1, w4, #0xff00ff
    // 0x8dec64: ubfx            x1, x1, #0, #0x20
    // 0x8dec68: lsl             x3, x1, #8
    // 0x8dec6c: orr             x1, x2, x3
    // 0x8dec70: mov             x2, x1
    // 0x8dec74: ubfx            x2, x2, #0, #0x20
    // 0x8dec78: and             w3, w2, #0xffff0000
    // 0x8dec7c: ubfx            x3, x3, #0, #0x20
    // 0x8dec80: asr             x2, x3, #0x10
    // 0x8dec84: ubfx            x1, x1, #0, #0x20
    // 0x8dec88: and             w3, w1, #0xffff
    // 0x8dec8c: ubfx            x3, x3, #0, #0x20
    // 0x8dec90: lsl             x1, x3, #0x10
    // 0x8dec94: orr             x3, x2, x1
    // 0x8dec98: ubfx            x3, x3, #0, #0x20
    // 0x8dec9c: LoadField: r1 = r8->field_7
    //     0x8dec9c: ldur            x1, [x8, #7]
    // 0x8deca0: str             w3, [x1, x0]
    // 0x8deca4: b               #0x8dedf8
    // 0x8deca8: ldur            x7, [fp, #-0x10]
    // 0x8decac: add             x1, x7, #3
    // 0x8decb0: LoadField: r0 = r2->field_13
    //     0x8decb0: ldur            w0, [x2, #0x13]
    // 0x8decb4: r8 = LoadInt32Instr(r0)
    //     0x8decb4: sbfx            x8, x0, #1, #0x1f
    // 0x8decb8: mov             x0, x8
    // 0x8decbc: cmp             x1, x0
    // 0x8decc0: b.hs            #0x8dee50
    // 0x8decc4: mov             x0, x8
    // 0x8decc8: mov             x1, x7
    // 0x8deccc: cmp             x1, x0
    // 0x8decd0: b.hs            #0x8dee54
    // 0x8decd4: ArrayLoad: r9 = r2[0]  ; List_4
    //     0x8decd4: ldur            w9, [x2, #0x17]
    // 0x8decd8: DecompressPointer r9
    //     0x8decd8: add             x9, x9, HEAP, lsl #32
    // 0x8decdc: LoadField: r0 = r2->field_1b
    //     0x8decdc: ldur            w0, [x2, #0x1b]
    // 0x8dece0: r2 = LoadInt32Instr(r0)
    //     0x8dece0: sbfx            x2, x0, #1, #0x1f
    // 0x8dece4: add             x0, x2, x7
    // 0x8dece8: r16 = Instance_Endian
    //     0x8dece8: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f780] Obj!Endian@12b79f1
    //     0x8decec: ldr             x16, [x16, #0x780]
    // 0x8decf0: cmp             w6, w16
    // 0x8decf4: b.ne            #0x8ded04
    // 0x8decf8: mov             x1, x4
    // 0x8decfc: ubfx            x1, x1, #0, #0x20
    // 0x8ded00: b               #0x8ded4c
    // 0x8ded04: and             w1, w4, #0xff00ff00
    // 0x8ded08: ubfx            x1, x1, #0, #0x20
    // 0x8ded0c: asr             x10, x1, #8
    // 0x8ded10: and             w1, w4, #0xff00ff
    // 0x8ded14: ubfx            x1, x1, #0, #0x20
    // 0x8ded18: lsl             x4, x1, #8
    // 0x8ded1c: orr             x1, x10, x4
    // 0x8ded20: mov             x4, x1
    // 0x8ded24: ubfx            x4, x4, #0, #0x20
    // 0x8ded28: and             w10, w4, #0xffff0000
    // 0x8ded2c: ubfx            x10, x10, #0, #0x20
    // 0x8ded30: asr             x4, x10, #0x10
    // 0x8ded34: ubfx            x1, x1, #0, #0x20
    // 0x8ded38: and             w10, w1, #0xffff
    // 0x8ded3c: ubfx            x10, x10, #0, #0x20
    // 0x8ded40: lsl             x1, x10, #0x10
    // 0x8ded44: orr             x10, x4, x1
    // 0x8ded48: mov             x1, x10
    // 0x8ded4c: ubfx            x1, x1, #0, #0x20
    // 0x8ded50: LoadField: r4 = r9->field_7
    //     0x8ded50: ldur            x4, [x9, #7]
    // 0x8ded54: str             w1, [x4, x0]
    // 0x8ded58: add             x4, x7, #4
    // 0x8ded5c: add             x1, x4, #3
    // 0x8ded60: mov             x0, x8
    // 0x8ded64: cmp             x1, x0
    // 0x8ded68: b.hs            #0x8dee58
    // 0x8ded6c: mov             x0, x8
    // 0x8ded70: mov             x1, x4
    // 0x8ded74: cmp             x1, x0
    // 0x8ded78: b.hs            #0x8dee5c
    // 0x8ded7c: add             x0, x2, x4
    // 0x8ded80: r16 = Instance_Endian
    //     0x8ded80: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f780] Obj!Endian@12b79f1
    //     0x8ded84: ldr             x16, [x16, #0x780]
    // 0x8ded88: cmp             w6, w16
    // 0x8ded8c: b.ne            #0x8ded98
    // 0x8ded90: mov             x1, x3
    // 0x8ded94: b               #0x8dedec
    // 0x8ded98: mov             x1, x3
    // 0x8ded9c: ubfx            x1, x1, #0, #0x20
    // 0x8deda0: and             w2, w1, #0xff00ff00
    // 0x8deda4: ubfx            x2, x2, #0, #0x20
    // 0x8deda8: asr             x1, x2, #8
    // 0x8dedac: ubfx            x3, x3, #0, #0x20
    // 0x8dedb0: and             w2, w3, #0xff00ff
    // 0x8dedb4: ubfx            x2, x2, #0, #0x20
    // 0x8dedb8: lsl             x3, x2, #8
    // 0x8dedbc: orr             x2, x1, x3
    // 0x8dedc0: mov             x1, x2
    // 0x8dedc4: ubfx            x1, x1, #0, #0x20
    // 0x8dedc8: and             w3, w1, #0xffff0000
    // 0x8dedcc: ubfx            x3, x3, #0, #0x20
    // 0x8dedd0: asr             x1, x3, #0x10
    // 0x8dedd4: ubfx            x2, x2, #0, #0x20
    // 0x8dedd8: and             w3, w2, #0xffff
    // 0x8deddc: ubfx            x3, x3, #0, #0x20
    // 0x8dede0: lsl             x2, x3, #0x10
    // 0x8dede4: orr             x3, x1, x2
    // 0x8dede8: mov             x1, x3
    // 0x8dedec: ubfx            x1, x1, #0, #0x20
    // 0x8dedf0: LoadField: r2 = r9->field_7
    //     0x8dedf0: ldur            x2, [x9, #7]
    // 0x8dedf4: str             w1, [x2, x0]
    // 0x8dedf8: mov             x1, x5
    // 0x8dedfc: ldur            x2, [fp, #-0x28]
    // 0x8dee00: r0 = _addData()
    //     0x8dee00: bl              #0x8d9ff4  ; [package:crypto/src/hash_sink.dart] HashSink::_addData
    // 0x8dee04: r0 = Null
    //     0x8dee04: mov             x0, NULL
    // 0x8dee08: LeaveFrame
    //     0x8dee08: mov             SP, fp
    //     0x8dee0c: ldp             fp, lr, [SP], #0x10
    // 0x8dee10: ret
    //     0x8dee10: ret             
    // 0x8dee14: r0 = UnsupportedError()
    //     0x8dee14: bl              #0x7d923c  ; AllocateUnsupportedErrorStub -> UnsupportedError (size=0x10)
    // 0x8dee18: mov             x1, x0
    // 0x8dee1c: r0 = "Hashing is unsupported for messages with more than 2^53 bits."
    //     0x8dee1c: add             x0, PP, #0x7e, lsl #12  ; [pp+0x7eda0] "Hashing is unsupported for messages with more than 2^53 bits."
    //     0x8dee20: ldr             x0, [x0, #0xda0]
    // 0x8dee24: StoreField: r1->field_b = r0
    //     0x8dee24: stur            w0, [x1, #0xb]
    // 0x8dee28: mov             x0, x1
    // 0x8dee2c: r0 = Throw()
    //     0x8dee2c: bl              #0x13ddb2c  ; ThrowStub
    // 0x8dee30: brk             #0
    // 0x8dee34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8dee34: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8dee38: b               #0x8deaa8
    // 0x8dee3c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8dee3c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8dee40: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8dee40: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8dee44: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8dee44: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8dee48: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8dee48: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8dee4c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8dee4c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8dee50: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8dee50: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8dee54: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8dee54: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8dee58: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8dee58: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8dee5c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8dee5c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
}
