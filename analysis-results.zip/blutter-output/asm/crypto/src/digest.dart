// lib: , url: package:crypto/src/digest.dart

// class id: 1048671, size: 0x8
class :: {

  static _ _hexEncode(/* No info */) {
    // ** addr: 0x110b0a8, size: 0x168
    // 0x110b0a8: EnterFrame
    //     0x110b0a8: stp             fp, lr, [SP, #-0x10]!
    //     0x110b0ac: mov             fp, SP
    // 0x110b0b0: AllocStack(0x40)
    //     0x110b0b0: sub             SP, SP, #0x40
    // 0x110b0b4: SetupParameters(dynamic _ /* r1 => r2, fp-0x18 */)
    //     0x110b0b4: mov             x2, x1
    //     0x110b0b8: stur            x1, [fp, #-0x18]
    // 0x110b0bc: CheckStackOverflow
    //     0x110b0bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x110b0c0: cmp             SP, x16
    //     0x110b0c4: b.ls            #0x110b1f8
    // 0x110b0c8: LoadField: r0 = r2->field_13
    //     0x110b0c8: ldur            w0, [x2, #0x13]
    // 0x110b0cc: r3 = LoadInt32Instr(r0)
    //     0x110b0cc: sbfx            x3, x0, #1, #0x1f
    // 0x110b0d0: stur            x3, [fp, #-0x10]
    // 0x110b0d4: lsl             x5, x3, #1
    // 0x110b0d8: stur            x5, [fp, #-8]
    // 0x110b0dc: r0 = BoxInt64Instr(r5)
    //     0x110b0dc: sbfiz           x0, x5, #1, #0x1f
    //     0x110b0e0: cmp             x5, x0, asr #1
    //     0x110b0e4: b.eq            #0x110b0f0
    //     0x110b0e8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x110b0ec: stur            x5, [x0, #7]
    // 0x110b0f0: mov             x4, x0
    // 0x110b0f4: r0 = AllocateUint8Array()
    //     0x110b0f4: bl              #0x13df5f0  ; AllocateUint8ArrayStub
    // 0x110b0f8: mov             x1, x0
    // 0x110b0fc: stur            x1, [fp, #-0x30]
    // 0x110b100: r5 = 0
    //     0x110b100: mov             x5, #0
    // 0x110b104: r4 = 0
    //     0x110b104: mov             x4, #0
    // 0x110b108: ldur            x2, [fp, #-0x18]
    // 0x110b10c: ldur            x3, [fp, #-0x10]
    // 0x110b110: stur            x5, [fp, #-0x20]
    // 0x110b114: stur            x4, [fp, #-0x28]
    // 0x110b118: CheckStackOverflow
    //     0x110b118: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x110b11c: cmp             SP, x16
    //     0x110b120: b.ls            #0x110b200
    // 0x110b124: cmp             x5, x3
    // 0x110b128: b.ge            #0x110b1d8
    // 0x110b12c: lsl             x0, x5, #1
    // 0x110b130: r6 = LoadClassIdInstr(r2)
    //     0x110b130: ldur            x6, [x2, #-1]
    //     0x110b134: ubfx            x6, x6, #0xc, #0x14
    // 0x110b138: stp             x0, x2, [SP]
    // 0x110b13c: mov             x0, x6
    // 0x110b140: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x110b140: sub             lr, x0, #0xdfd
    //     0x110b144: ldr             lr, [x21, lr, lsl #3]
    //     0x110b148: blr             lr
    // 0x110b14c: ldur            x2, [fp, #-0x28]
    // 0x110b150: add             x3, x2, #1
    // 0x110b154: r4 = LoadInt32Instr(r0)
    //     0x110b154: sbfx            x4, x0, #1, #0x1f
    // 0x110b158: asr             x0, x4, #4
    // 0x110b15c: ubfx            x0, x0, #0, #0x20
    // 0x110b160: and             w1, w0, #0xf
    // 0x110b164: ubfx            x1, x1, #0, #0x20
    // 0x110b168: r6 = "0123456789abcdef"
    //     0x110b168: add             x6, PP, #0x14, lsl #12  ; [pp+0x14008] "0123456789abcdef"
    //     0x110b16c: ldr             x6, [x6, #8]
    // 0x110b170: ArrayLoad: r5 = r6[r1]  ; TypedUnsigned_1
    //     0x110b170: add             x16, x6, x1
    //     0x110b174: ldrb            w5, [x16, #0xf]
    // 0x110b178: ldur            x0, [fp, #-8]
    // 0x110b17c: mov             x1, x2
    // 0x110b180: cmp             x1, x0
    // 0x110b184: b.hs            #0x110b208
    // 0x110b188: ldur            x7, [fp, #-0x30]
    // 0x110b18c: ArrayStore: r7[r2] = r5  ; TypeUnknown_1
    //     0x110b18c: add             x0, x7, x2
    //     0x110b190: strb            w5, [x0, #0x17]
    // 0x110b194: add             x2, x3, #1
    // 0x110b198: ubfx            x4, x4, #0, #0x20
    // 0x110b19c: and             w0, w4, #0xf
    // 0x110b1a0: ubfx            x0, x0, #0, #0x20
    // 0x110b1a4: ArrayLoad: r4 = r6[r0]  ; TypedUnsigned_1
    //     0x110b1a4: add             x16, x6, x0
    //     0x110b1a8: ldrb            w4, [x16, #0xf]
    // 0x110b1ac: ldur            x0, [fp, #-8]
    // 0x110b1b0: mov             x1, x3
    // 0x110b1b4: cmp             x1, x0
    // 0x110b1b8: b.hs            #0x110b20c
    // 0x110b1bc: ArrayStore: r7[r3] = r4  ; TypeUnknown_1
    //     0x110b1bc: add             x0, x7, x3
    //     0x110b1c0: strb            w4, [x0, #0x17]
    // 0x110b1c4: ldur            x0, [fp, #-0x20]
    // 0x110b1c8: add             x5, x0, #1
    // 0x110b1cc: mov             x4, x2
    // 0x110b1d0: mov             x1, x7
    // 0x110b1d4: b               #0x110b108
    // 0x110b1d8: mov             x7, x1
    // 0x110b1dc: mov             x1, x7
    // 0x110b1e0: r2 = 0
    //     0x110b1e0: mov             x2, #0
    // 0x110b1e4: r3 = Null
    //     0x110b1e4: mov             x3, NULL
    // 0x110b1e8: r0 = createFromCharCodes()
    //     0x110b1e8: bl              #0x7e5490  ; [dart:core] _StringBase::createFromCharCodes
    // 0x110b1ec: LeaveFrame
    //     0x110b1ec: mov             SP, fp
    //     0x110b1f0: ldp             fp, lr, [SP], #0x10
    // 0x110b1f4: ret
    //     0x110b1f4: ret             
    // 0x110b1f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x110b1f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x110b1fc: b               #0x110b0c8
    // 0x110b200: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x110b200: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x110b204: b               #0x110b124
    // 0x110b208: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x110b208: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x110b20c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x110b20c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
}

// class id: 3556, size: 0xc, field offset: 0x8
class Digest extends Object {

  _ toString(/* No info */) {
    // ** addr: 0x110b070, size: 0x38
    // 0x110b070: EnterFrame
    //     0x110b070: stp             fp, lr, [SP, #-0x10]!
    //     0x110b074: mov             fp, SP
    // 0x110b078: CheckStackOverflow
    //     0x110b078: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x110b07c: cmp             SP, x16
    //     0x110b080: b.ls            #0x110b0a0
    // 0x110b084: ldr             x0, [fp, #0x10]
    // 0x110b088: LoadField: r1 = r0->field_7
    //     0x110b088: ldur            w1, [x0, #7]
    // 0x110b08c: DecompressPointer r1
    //     0x110b08c: add             x1, x1, HEAP, lsl #32
    // 0x110b090: r0 = _hexEncode()
    //     0x110b090: bl              #0x110b0a8  ; [package:crypto/src/digest.dart] ::_hexEncode
    // 0x110b094: LeaveFrame
    //     0x110b094: mov             SP, fp
    //     0x110b098: ldp             fp, lr, [SP], #0x10
    // 0x110b09c: ret
    //     0x110b09c: ret             
    // 0x110b0a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x110b0a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x110b0a4: b               #0x110b084
  }
  _ ==(/* No info */) {
    // ** addr: 0x1292ab0, size: 0x170
    // 0x1292ab0: EnterFrame
    //     0x1292ab0: stp             fp, lr, [SP, #-0x10]!
    //     0x1292ab4: mov             fp, SP
    // 0x1292ab8: AllocStack(0x48)
    //     0x1292ab8: sub             SP, SP, #0x48
    // 0x1292abc: CheckStackOverflow
    //     0x1292abc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1292ac0: cmp             SP, x16
    //     0x1292ac4: b.ls            #0x1292c10
    // 0x1292ac8: ldr             x0, [fp, #0x10]
    // 0x1292acc: cmp             w0, NULL
    // 0x1292ad0: b.ne            #0x1292ae4
    // 0x1292ad4: r0 = false
    //     0x1292ad4: add             x0, NULL, #0x30  ; false
    // 0x1292ad8: LeaveFrame
    //     0x1292ad8: mov             SP, fp
    //     0x1292adc: ldp             fp, lr, [SP], #0x10
    // 0x1292ae0: ret
    //     0x1292ae0: ret             
    // 0x1292ae4: r1 = 60
    //     0x1292ae4: mov             x1, #0x3c
    // 0x1292ae8: branchIfSmi(r0, 0x1292af4)
    //     0x1292ae8: tbz             w0, #0, #0x1292af4
    // 0x1292aec: r1 = LoadClassIdInstr(r0)
    //     0x1292aec: ldur            x1, [x0, #-1]
    //     0x1292af0: ubfx            x1, x1, #0xc, #0x14
    // 0x1292af4: cmp             x1, #0xde4
    // 0x1292af8: b.ne            #0x1292c00
    // 0x1292afc: ldr             x1, [fp, #0x18]
    // 0x1292b00: LoadField: r2 = r1->field_7
    //     0x1292b00: ldur            w2, [x1, #7]
    // 0x1292b04: DecompressPointer r2
    //     0x1292b04: add             x2, x2, HEAP, lsl #32
    // 0x1292b08: stur            x2, [fp, #-0x30]
    // 0x1292b0c: LoadField: r1 = r0->field_7
    //     0x1292b0c: ldur            w1, [x0, #7]
    // 0x1292b10: DecompressPointer r1
    //     0x1292b10: add             x1, x1, HEAP, lsl #32
    // 0x1292b14: stur            x1, [fp, #-0x28]
    // 0x1292b18: LoadField: r0 = r2->field_13
    //     0x1292b18: ldur            w0, [x2, #0x13]
    // 0x1292b1c: LoadField: r3 = r1->field_13
    //     0x1292b1c: ldur            w3, [x1, #0x13]
    // 0x1292b20: r4 = LoadInt32Instr(r0)
    //     0x1292b20: sbfx            x4, x0, #1, #0x1f
    // 0x1292b24: stur            x4, [fp, #-0x20]
    // 0x1292b28: r0 = LoadInt32Instr(r3)
    //     0x1292b28: sbfx            x0, x3, #1, #0x1f
    // 0x1292b2c: cmp             x4, x0
    // 0x1292b30: b.eq            #0x1292b44
    // 0x1292b34: r0 = false
    //     0x1292b34: add             x0, NULL, #0x30  ; false
    // 0x1292b38: LeaveFrame
    //     0x1292b38: mov             SP, fp
    //     0x1292b3c: ldp             fp, lr, [SP], #0x10
    // 0x1292b40: ret
    //     0x1292b40: ret             
    // 0x1292b44: r5 = 0
    //     0x1292b44: mov             x5, #0
    // 0x1292b48: r3 = 0
    //     0x1292b48: mov             x3, #0
    // 0x1292b4c: stur            x5, [fp, #-0x10]
    // 0x1292b50: stur            x3, [fp, #-0x18]
    // 0x1292b54: CheckStackOverflow
    //     0x1292b54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1292b58: cmp             SP, x16
    //     0x1292b5c: b.ls            #0x1292c18
    // 0x1292b60: cmp             x3, x4
    // 0x1292b64: b.ge            #0x1292be0
    // 0x1292b68: lsl             x6, x3, #1
    // 0x1292b6c: stur            x6, [fp, #-8]
    // 0x1292b70: r0 = LoadClassIdInstr(r2)
    //     0x1292b70: ldur            x0, [x2, #-1]
    //     0x1292b74: ubfx            x0, x0, #0xc, #0x14
    // 0x1292b78: stp             x6, x2, [SP]
    // 0x1292b7c: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x1292b7c: sub             lr, x0, #0xdfd
    //     0x1292b80: ldr             lr, [x21, lr, lsl #3]
    //     0x1292b84: blr             lr
    // 0x1292b88: mov             x2, x0
    // 0x1292b8c: ldur            x1, [fp, #-0x28]
    // 0x1292b90: stur            x2, [fp, #-0x38]
    // 0x1292b94: r0 = LoadClassIdInstr(r1)
    //     0x1292b94: ldur            x0, [x1, #-1]
    //     0x1292b98: ubfx            x0, x0, #0xc, #0x14
    // 0x1292b9c: ldur            x16, [fp, #-8]
    // 0x1292ba0: stp             x16, x1, [SP]
    // 0x1292ba4: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x1292ba4: sub             lr, x0, #0xdfd
    //     0x1292ba8: ldr             lr, [x21, lr, lsl #3]
    //     0x1292bac: blr             lr
    // 0x1292bb0: ldur            x1, [fp, #-0x38]
    // 0x1292bb4: r2 = LoadInt32Instr(r1)
    //     0x1292bb4: sbfx            x2, x1, #1, #0x1f
    // 0x1292bb8: r1 = LoadInt32Instr(r0)
    //     0x1292bb8: sbfx            x1, x0, #1, #0x1f
    // 0x1292bbc: eor             x3, x2, x1
    // 0x1292bc0: ldur            x1, [fp, #-0x10]
    // 0x1292bc4: orr             x5, x1, x3
    // 0x1292bc8: ldur            x2, [fp, #-0x18]
    // 0x1292bcc: add             x3, x2, #1
    // 0x1292bd0: ldur            x2, [fp, #-0x30]
    // 0x1292bd4: ldur            x1, [fp, #-0x28]
    // 0x1292bd8: ldur            x4, [fp, #-0x20]
    // 0x1292bdc: b               #0x1292b4c
    // 0x1292be0: mov             x1, x5
    // 0x1292be4: cbz             x1, #0x1292bf0
    // 0x1292be8: r0 = false
    //     0x1292be8: add             x0, NULL, #0x30  ; false
    // 0x1292bec: b               #0x1292bf4
    // 0x1292bf0: r0 = true
    //     0x1292bf0: add             x0, NULL, #0x20  ; true
    // 0x1292bf4: LeaveFrame
    //     0x1292bf4: mov             SP, fp
    //     0x1292bf8: ldp             fp, lr, [SP], #0x10
    // 0x1292bfc: ret
    //     0x1292bfc: ret             
    // 0x1292c00: r0 = false
    //     0x1292c00: add             x0, NULL, #0x30  ; false
    // 0x1292c04: LeaveFrame
    //     0x1292c04: mov             SP, fp
    //     0x1292c08: ldp             fp, lr, [SP], #0x10
    // 0x1292c0c: ret
    //     0x1292c0c: ret             
    // 0x1292c10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1292c10: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1292c14: b               #0x1292ac8
    // 0x1292c18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1292c18: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1292c1c: b               #0x1292b60
  }
}
