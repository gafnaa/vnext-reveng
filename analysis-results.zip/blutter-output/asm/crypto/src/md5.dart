// lib: , url: package:crypto/src/md5.dart

// class id: 1048675, size: 0x8
class :: {
}

// class id: 3554, size: 0x3c, field offset: 0x38
class _MD5Sink extends HashSink {

  _ _MD5Sink(/* No info */) {
    // ** addr: 0x121d670, size: 0x120
    // 0x121d670: EnterFrame
    //     0x121d670: stp             fp, lr, [SP, #-0x10]!
    //     0x121d674: mov             fp, SP
    // 0x121d678: AllocStack(0x18)
    //     0x121d678: sub             SP, SP, #0x18
    // 0x121d67c: SetupParameters(_MD5Sink this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x121d67c: mov             x0, x2
    //     0x121d680: stur            x1, [fp, #-8]
    //     0x121d684: stur            x2, [fp, #-0x10]
    // 0x121d688: r4 = 8
    //     0x121d688: mov             x4, #8
    // 0x121d68c: r0 = AllocateUint32Array()
    //     0x121d68c: bl              #0x13df228  ; AllocateUint32ArrayStub
    // 0x121d690: mov             x2, x0
    // 0x121d694: ldur            x1, [fp, #-8]
    // 0x121d698: stur            x2, [fp, #-0x18]
    // 0x121d69c: StoreField: r1->field_37 = r0
    //     0x121d69c: stur            w0, [x1, #0x37]
    //     0x121d6a0: ldurb           w16, [x1, #-1]
    //     0x121d6a4: ldurb           w17, [x0, #-1]
    //     0x121d6a8: and             x16, x17, x16, lsr #2
    //     0x121d6ac: tst             x16, HEAP, lsr #32
    //     0x121d6b0: b.eq            #0x121d6b8
    //     0x121d6b4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x121d6b8: StoreField: r1->field_23 = rZR
    //     0x121d6b8: stur            xzr, [x1, #0x23]
    // 0x121d6bc: r0 = false
    //     0x121d6bc: add             x0, NULL, #0x30  ; false
    // 0x121d6c0: StoreField: r1->field_2b = r0
    //     0x121d6c0: stur            w0, [x1, #0x2b]
    // 0x121d6c4: ldur            x0, [fp, #-0x10]
    // 0x121d6c8: StoreField: r1->field_7 = r0
    //     0x121d6c8: stur            w0, [x1, #7]
    //     0x121d6cc: ldurb           w16, [x1, #-1]
    //     0x121d6d0: ldurb           w17, [x0, #-1]
    //     0x121d6d4: and             x16, x17, x16, lsr #2
    //     0x121d6d8: tst             x16, HEAP, lsr #32
    //     0x121d6dc: b.eq            #0x121d6e4
    //     0x121d6e0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x121d6e4: r0 = Instance_Endian
    //     0x121d6e4: add             x0, PP, #0x1f, lsl #12  ; [pp+0x1f780] Obj!Endian@12b79f1
    //     0x121d6e8: ldr             x0, [x0, #0x780]
    // 0x121d6ec: StoreField: r1->field_b = r0
    //     0x121d6ec: stur            w0, [x1, #0xb]
    // 0x121d6f0: r0 = 8
    //     0x121d6f0: mov             x0, #8
    // 0x121d6f4: StoreField: r1->field_2f = r0
    //     0x121d6f4: stur            x0, [x1, #0x2f]
    // 0x121d6f8: r4 = 128
    //     0x121d6f8: mov             x4, #0x80
    // 0x121d6fc: r0 = AllocateUint8Array()
    //     0x121d6fc: bl              #0x13df5f0  ; AllocateUint8ArrayStub
    // 0x121d700: ldur            x1, [fp, #-8]
    // 0x121d704: StoreField: r1->field_13 = r0
    //     0x121d704: stur            w0, [x1, #0x13]
    //     0x121d708: ldurb           w16, [x1, #-1]
    //     0x121d70c: ldurb           w17, [x0, #-1]
    //     0x121d710: and             x16, x17, x16, lsr #2
    //     0x121d714: tst             x16, HEAP, lsr #32
    //     0x121d718: b.eq            #0x121d720
    //     0x121d71c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x121d720: ArrayStore: r1[0] = rZR  ; List_8
    //     0x121d720: stur            xzr, [x1, #0x17]
    // 0x121d724: r4 = 32
    //     0x121d724: mov             x4, #0x20
    // 0x121d728: r0 = AllocateUint32Array()
    //     0x121d728: bl              #0x13df228  ; AllocateUint32ArrayStub
    // 0x121d72c: ldur            x1, [fp, #-8]
    // 0x121d730: StoreField: r1->field_1f = r0
    //     0x121d730: stur            w0, [x1, #0x1f]
    //     0x121d734: ldurb           w16, [x1, #-1]
    //     0x121d738: ldurb           w17, [x0, #-1]
    //     0x121d73c: and             x16, x17, x16, lsr #2
    //     0x121d740: tst             x16, HEAP, lsr #32
    //     0x121d744: b.eq            #0x121d74c
    //     0x121d748: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x121d74c: ldur            x1, [fp, #-0x18]
    // 0x121d750: r2 = 1732584193
    //     0x121d750: mov             x2, #0x2301
    //     0x121d754: movk            x2, #0x6745, lsl #16
    // 0x121d758: ArrayStore: r1[0] = r2  ; List_4
    //     0x121d758: stur            w2, [x1, #0x17]
    // 0x121d75c: r2 = 4023233417
    //     0x121d75c: mov             x2, #0xab89
    //     0x121d760: movk            x2, #0xefcd, lsl #16
    // 0x121d764: StoreField: r1->field_1b = r2
    //     0x121d764: stur            w2, [x1, #0x1b]
    // 0x121d768: r2 = 2562383102
    //     0x121d768: mov             x2, #0xdcfe
    //     0x121d76c: movk            x2, #0x98ba, lsl #16
    // 0x121d770: StoreField: r1->field_1f = r2
    //     0x121d770: stur            w2, [x1, #0x1f]
    // 0x121d774: r2 = 271733878
    //     0x121d774: mov             x2, #0x5476
    //     0x121d778: movk            x2, #0x1032, lsl #16
    // 0x121d77c: StoreField: r1->field_23 = r2
    //     0x121d77c: stur            w2, [x1, #0x23]
    // 0x121d780: r0 = Null
    //     0x121d780: mov             x0, NULL
    // 0x121d784: LeaveFrame
    //     0x121d784: mov             SP, fp
    //     0x121d788: ldp             fp, lr, [SP], #0x10
    // 0x121d78c: ret
    //     0x121d78c: ret             
  }
  _ updateHash(/* No info */) {
    // ** addr: 0x12e4b00, size: 0x4bc
    // 0x12e4b00: EnterFrame
    //     0x12e4b00: stp             fp, lr, [SP, #-0x10]!
    //     0x12e4b04: mov             fp, SP
    // 0x12e4b08: mov             x3, x1
    // 0x12e4b0c: LoadField: r4 = r2->field_13
    //     0x12e4b0c: ldur            w4, [x2, #0x13]
    // 0x12e4b10: r5 = LoadInt32Instr(r4)
    //     0x12e4b10: sbfx            x5, x4, #1, #0x1f
    // 0x12e4b14: mov             x0, x5
    // 0x12e4b18: r1 = 15
    //     0x12e4b18: mov             x1, #0xf
    // 0x12e4b1c: cmp             x1, x0
    // 0x12e4b20: b.hs            #0x12e4f90
    // 0x12e4b24: LoadField: r4 = r3->field_37
    //     0x12e4b24: ldur            w4, [x3, #0x37]
    // 0x12e4b28: DecompressPointer r4
    //     0x12e4b28: add             x4, x4, HEAP, lsl #32
    // 0x12e4b2c: LoadField: r3 = r4->field_13
    //     0x12e4b2c: ldur            w3, [x4, #0x13]
    // 0x12e4b30: r0 = LoadInt32Instr(r3)
    //     0x12e4b30: sbfx            x0, x3, #1, #0x1f
    // 0x12e4b34: r1 = 3
    //     0x12e4b34: mov             x1, #3
    // 0x12e4b38: cmp             x1, x0
    // 0x12e4b3c: b.hs            #0x12e4f94
    // 0x12e4b40: LoadField: r3 = r4->field_23
    //     0x12e4b40: ldur            w3, [x4, #0x23]
    // 0x12e4b44: LoadField: r6 = r4->field_1f
    //     0x12e4b44: ldur            w6, [x4, #0x1f]
    // 0x12e4b48: LoadField: r7 = r4->field_1b
    //     0x12e4b48: ldur            w7, [x4, #0x1b]
    // 0x12e4b4c: ArrayLoad: r8 = r4[0]  ; List_4
    //     0x12e4b4c: ldur            w8, [x4, #0x17]
    // 0x12e4b50: mov             x9, x3
    // 0x12e4b54: ubfx            x9, x9, #0, #0x20
    // 0x12e4b58: mov             x10, x6
    // 0x12e4b5c: ubfx            x10, x10, #0, #0x20
    // 0x12e4b60: mov             x11, x7
    // 0x12e4b64: ubfx            x11, x11, #0, #0x20
    // 0x12e4b68: mov             x12, x8
    // 0x12e4b6c: ubfx            x12, x12, #0, #0x20
    // 0x12e4b70: mov             x19, x9
    // 0x12e4b74: mov             x14, x10
    // 0x12e4b78: mov             x13, x11
    // 0x12e4b7c: r20 = 0
    //     0x12e4b7c: mov             x20, #0
    // 0x12e4b80: r11 = const [3614090360, 3905402710, 0x242070db, 3250441966, 4118548399, 1200080426, 2821735955, 4249261313, 1770035416, 2336552879, 4294925233, 2304563134, 1804603682, 4254626195, 2792965006, 1236535329, 4129170786, 3225465664, 0x265e5a51, 3921069994, 3593408605, 0x2441453, 3634488961, 3889429448, 0x21e1cde6, 3275163606, 4107603335, 1163531501, 2850285829, 4243563512, 1735328473, 2368359562, 4294588738, 2272392833, 1839030562, 4259657740, 2763975236, 1272893353, 4139469664, 3200236656, 0x289b7ec6, 3936430074, 3572445317, 0x4881d05, 3654602809, 3873151461, 0x1fa27cf8, 3299628645, 4096336452, 1126891415, 2878612391, 4237533241, 1700485571, 2399980690, 4293915773, 2240044497, 1873313359, 4264355552, 2734768916, 1309151649, 4149444226, 3174756917, 0x2ad7d2bb, 3951481745]
    //     0x12e4b80: add             x11, PP, #0xcf, lsl #12  ; [pp+0xcf6d8] List<int>(64)
    //     0x12e4b84: ldr             x11, [x11, #0x6d8]
    // 0x12e4b88: r10 = const [0x7, 0xc, 0x11, 0x16, 0x7, 0xc, 0x11, 0x16, 0x7, 0xc, 0x11, 0x16, 0x7, 0xc, 0x11, 0x16, 0x5, 0x9, 0xe, 0x14, 0x5, 0x9, 0xe, 0x14, 0x5, 0x9, 0xe, 0x14, 0x5, 0x9, 0xe, 0x14, 0x4, 0xb, 0x10, 0x17, 0x4, 0xb, 0x10, 0x17, 0x4, 0xb, 0x10, 0x17, 0x4, 0xb, 0x10, 0x17, 0x6, 0xa, 0xf, 0x15, 0x6, 0xa, 0xf, 0x15, 0x6, 0xa, 0xf, 0x15, 0x6, 0xa, 0xf, 0x15]
    //     0x12e4b88: add             x10, PP, #0xcf, lsl #12  ; [pp+0xcf6e0] List<int>(64)
    //     0x12e4b8c: ldr             x10, [x10, #0x6e0]
    // 0x12e4b90: r9 = 32
    //     0x12e4b90: mov             x9, #0x20
    // 0x12e4b94: CheckStackOverflow
    //     0x12e4b94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e4b98: cmp             SP, x16
    //     0x12e4b9c: b.ls            #0x12e4f98
    // 0x12e4ba0: cmp             x20, #0x10
    // 0x12e4ba4: b.ge            #0x12e4c80
    // 0x12e4ba8: mov             x23, x13
    // 0x12e4bac: ubfx            x23, x23, #0, #0x20
    // 0x12e4bb0: mov             x24, x14
    // 0x12e4bb4: ubfx            x24, x24, #0, #0x20
    // 0x12e4bb8: and             x25, x23, x24
    // 0x12e4bbc: mvn             w24, w23
    // 0x12e4bc0: mov             x0, x19
    // 0x12e4bc4: ubfx            x0, x0, #0, #0x20
    // 0x12e4bc8: and             x1, x24, x0
    // 0x12e4bcc: ubfx            x25, x25, #0, #0x20
    // 0x12e4bd0: ubfx            x1, x1, #0, #0x20
    // 0x12e4bd4: orr             x24, x25, x1
    // 0x12e4bd8: mov             x25, x12
    // 0x12e4bdc: ubfx            x25, x25, #0, #0x20
    // 0x12e4be0: ubfx            x24, x24, #0, #0x20
    // 0x12e4be4: add             w12, w25, w24
    // 0x12e4be8: ArrayLoad: r24 = r11[r20]  ; Unknown_4
    //     0x12e4be8: add             x16, x11, x20, lsl #2
    //     0x12e4bec: ldur            w24, [x16, #0xf]
    // 0x12e4bf0: DecompressPointer r24
    //     0x12e4bf0: add             x24, x24, HEAP, lsl #32
    // 0x12e4bf4: mov             x0, x5
    // 0x12e4bf8: mov             x1, x20
    // 0x12e4bfc: cmp             x1, x0
    // 0x12e4c00: b.hs            #0x12e4fa0
    // 0x12e4c04: ArrayLoad: r1 = r2[r20]  ; List_4
    //     0x12e4c04: add             x16, x2, x20, lsl #2
    //     0x12e4c08: ldur            w1, [x16, #0x17]
    // 0x12e4c0c: r25 = LoadInt32Instr(r24)
    //     0x12e4c0c: sbfx            x25, x24, #1, #0x1f
    //     0x12e4c10: tbz             w24, #0, #0x12e4c18
    //     0x12e4c14: ldur            x25, [x24, #7]
    // 0x12e4c18: add             w24, w25, w1
    // 0x12e4c1c: add             w1, w12, w24
    // 0x12e4c20: ArrayLoad: r24 = r10[r20]  ; Unknown_4
    //     0x12e4c20: add             x16, x10, x20, lsl #2
    //     0x12e4c24: ldur            w24, [x16, #0xf]
    // 0x12e4c28: DecompressPointer r24
    //     0x12e4c28: add             x24, x24, HEAP, lsl #32
    // 0x12e4c2c: r25 = LoadInt32Instr(r24)
    //     0x12e4c2c: sbfx            x25, x24, #1, #0x1f
    // 0x12e4c30: and             w24, w25, #0x1f
    // 0x12e4c34: lsl             w25, w1, w24
    // 0x12e4c38: cmp             w24, #0x1f
    // 0x12e4c3c: csel            x25, x25, xzr, ls
    // 0x12e4c40: ubfx            x24, x24, #0, #0x20
    // 0x12e4c44: sub             x0, x9, x24
    // 0x12e4c48: ubfx            x0, x0, #0, #0x20
    // 0x12e4c4c: lsr             w24, w1, w0
    // 0x12e4c50: cmp             w0, #0x1f
    // 0x12e4c54: csel            x24, x24, xzr, ls
    // 0x12e4c58: orr             x1, x25, x24
    // 0x12e4c5c: add             w24, w23, w1
    // 0x12e4c60: add             x0, x20, #1
    // 0x12e4c64: ubfx            x24, x24, #0, #0x20
    // 0x12e4c68: mov             x20, x0
    // 0x12e4c6c: mov             x12, x19
    // 0x12e4c70: mov             x19, x14
    // 0x12e4c74: mov             x14, x13
    // 0x12e4c78: mov             x13, x24
    // 0x12e4c7c: b               #0x12e4b94
    // 0x12e4c80: mov             x0, x19
    // 0x12e4c84: mov             x1, x12
    // 0x12e4c88: mov             x12, x14
    // 0x12e4c8c: mov             x5, x13
    // 0x12e4c90: r13 = 16
    //     0x12e4c90: mov             x13, #0x10
    // 0x12e4c94: CheckStackOverflow
    //     0x12e4c94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e4c98: cmp             SP, x16
    //     0x12e4c9c: b.ls            #0x12e4fa4
    // 0x12e4ca0: cmp             x13, #0x20
    // 0x12e4ca4: b.ge            #0x12e4d8c
    // 0x12e4ca8: mov             x14, x0
    // 0x12e4cac: ubfx            x14, x14, #0, #0x20
    // 0x12e4cb0: mov             x19, x5
    // 0x12e4cb4: ubfx            x19, x19, #0, #0x20
    // 0x12e4cb8: and             x20, x14, x19
    // 0x12e4cbc: mvn             w23, w14
    // 0x12e4cc0: mov             x14, x12
    // 0x12e4cc4: ubfx            x14, x14, #0, #0x20
    // 0x12e4cc8: and             x24, x23, x14
    // 0x12e4ccc: ubfx            x20, x20, #0, #0x20
    // 0x12e4cd0: ubfx            x24, x24, #0, #0x20
    // 0x12e4cd4: orr             x14, x20, x24
    // 0x12e4cd8: mov             x20, x13
    // 0x12e4cdc: ubfx            x20, x20, #0, #0x20
    // 0x12e4ce0: r16 = 5
    //     0x12e4ce0: mov             x16, #5
    // 0x12e4ce4: mul             x23, x20, x16
    // 0x12e4ce8: add             w20, w23, #1
    // 0x12e4cec: and             w23, w20, #0xf
    // 0x12e4cf0: mov             x20, x1
    // 0x12e4cf4: ubfx            x20, x20, #0, #0x20
    // 0x12e4cf8: ubfx            x14, x14, #0, #0x20
    // 0x12e4cfc: add             w24, w20, w14
    // 0x12e4d00: ArrayLoad: r14 = r11[r13]  ; Unknown_4
    //     0x12e4d00: add             x16, x11, x13, lsl #2
    //     0x12e4d04: ldur            w14, [x16, #0xf]
    // 0x12e4d08: DecompressPointer r14
    //     0x12e4d08: add             x14, x14, HEAP, lsl #32
    // 0x12e4d0c: ubfx            x23, x23, #0, #0x20
    // 0x12e4d10: ArrayLoad: r20 = r2[r23]  ; List_4
    //     0x12e4d10: add             x16, x2, x23, lsl #2
    //     0x12e4d14: ldur            w20, [x16, #0x17]
    // 0x12e4d18: r23 = LoadInt32Instr(r14)
    //     0x12e4d18: sbfx            x23, x14, #1, #0x1f
    //     0x12e4d1c: tbz             w14, #0, #0x12e4d24
    //     0x12e4d20: ldur            x23, [x14, #7]
    // 0x12e4d24: add             w14, w23, w20
    // 0x12e4d28: add             w20, w24, w14
    // 0x12e4d2c: ArrayLoad: r14 = r10[r13]  ; Unknown_4
    //     0x12e4d2c: add             x16, x10, x13, lsl #2
    //     0x12e4d30: ldur            w14, [x16, #0xf]
    // 0x12e4d34: DecompressPointer r14
    //     0x12e4d34: add             x14, x14, HEAP, lsl #32
    // 0x12e4d38: r23 = LoadInt32Instr(r14)
    //     0x12e4d38: sbfx            x23, x14, #1, #0x1f
    // 0x12e4d3c: and             w14, w23, #0x1f
    // 0x12e4d40: lsl             w23, w20, w14
    // 0x12e4d44: cmp             w14, #0x1f
    // 0x12e4d48: csel            x23, x23, xzr, ls
    // 0x12e4d4c: ubfx            x14, x14, #0, #0x20
    // 0x12e4d50: sub             x24, x9, x14
    // 0x12e4d54: ubfx            x24, x24, #0, #0x20
    // 0x12e4d58: lsr             w14, w20, w24
    // 0x12e4d5c: cmp             w24, #0x1f
    // 0x12e4d60: csel            x14, x14, xzr, ls
    // 0x12e4d64: orr             x20, x23, x14
    // 0x12e4d68: add             w14, w19, w20
    // 0x12e4d6c: add             x19, x13, #1
    // 0x12e4d70: ubfx            x14, x14, #0, #0x20
    // 0x12e4d74: mov             x13, x19
    // 0x12e4d78: mov             x1, x0
    // 0x12e4d7c: mov             x0, x12
    // 0x12e4d80: mov             x12, x5
    // 0x12e4d84: mov             x5, x14
    // 0x12e4d88: b               #0x12e4c94
    // 0x12e4d8c: r13 = 32
    //     0x12e4d8c: mov             x13, #0x20
    // 0x12e4d90: CheckStackOverflow
    //     0x12e4d90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e4d94: cmp             SP, x16
    //     0x12e4d98: b.ls            #0x12e4fac
    // 0x12e4d9c: cmp             x13, #0x30
    // 0x12e4da0: b.ge            #0x12e4e68
    // 0x12e4da4: eor             x14, x5, x12
    // 0x12e4da8: eor             x19, x14, x0
    // 0x12e4dac: mov             x14, x13
    // 0x12e4db0: ubfx            x14, x14, #0, #0x20
    // 0x12e4db4: r16 = 3
    //     0x12e4db4: mov             x16, #3
    // 0x12e4db8: mul             x20, x14, x16
    // 0x12e4dbc: add             w14, w20, #5
    // 0x12e4dc0: and             w20, w14, #0xf
    // 0x12e4dc4: mov             x14, x1
    // 0x12e4dc8: ubfx            x14, x14, #0, #0x20
    // 0x12e4dcc: ubfx            x19, x19, #0, #0x20
    // 0x12e4dd0: add             w23, w14, w19
    // 0x12e4dd4: ArrayLoad: r14 = r11[r13]  ; Unknown_4
    //     0x12e4dd4: add             x16, x11, x13, lsl #2
    //     0x12e4dd8: ldur            w14, [x16, #0xf]
    // 0x12e4ddc: DecompressPointer r14
    //     0x12e4ddc: add             x14, x14, HEAP, lsl #32
    // 0x12e4de0: ubfx            x20, x20, #0, #0x20
    // 0x12e4de4: ArrayLoad: r19 = r2[r20]  ; List_4
    //     0x12e4de4: add             x16, x2, x20, lsl #2
    //     0x12e4de8: ldur            w19, [x16, #0x17]
    // 0x12e4dec: r20 = LoadInt32Instr(r14)
    //     0x12e4dec: sbfx            x20, x14, #1, #0x1f
    //     0x12e4df0: tbz             w14, #0, #0x12e4df8
    //     0x12e4df4: ldur            x20, [x14, #7]
    // 0x12e4df8: add             w14, w20, w19
    // 0x12e4dfc: add             w19, w23, w14
    // 0x12e4e00: ArrayLoad: r14 = r10[r13]  ; Unknown_4
    //     0x12e4e00: add             x16, x10, x13, lsl #2
    //     0x12e4e04: ldur            w14, [x16, #0xf]
    // 0x12e4e08: DecompressPointer r14
    //     0x12e4e08: add             x14, x14, HEAP, lsl #32
    // 0x12e4e0c: r20 = LoadInt32Instr(r14)
    //     0x12e4e0c: sbfx            x20, x14, #1, #0x1f
    // 0x12e4e10: and             w14, w20, #0x1f
    // 0x12e4e14: lsl             w20, w19, w14
    // 0x12e4e18: cmp             w14, #0x1f
    // 0x12e4e1c: csel            x20, x20, xzr, ls
    // 0x12e4e20: ubfx            x14, x14, #0, #0x20
    // 0x12e4e24: sub             x23, x9, x14
    // 0x12e4e28: ubfx            x23, x23, #0, #0x20
    // 0x12e4e2c: lsr             w14, w19, w23
    // 0x12e4e30: cmp             w23, #0x1f
    // 0x12e4e34: csel            x14, x14, xzr, ls
    // 0x12e4e38: orr             x19, x20, x14
    // 0x12e4e3c: mov             x14, x5
    // 0x12e4e40: ubfx            x14, x14, #0, #0x20
    // 0x12e4e44: add             w20, w14, w19
    // 0x12e4e48: add             x14, x13, #1
    // 0x12e4e4c: ubfx            x20, x20, #0, #0x20
    // 0x12e4e50: mov             x13, x14
    // 0x12e4e54: mov             x1, x0
    // 0x12e4e58: mov             x0, x12
    // 0x12e4e5c: mov             x12, x5
    // 0x12e4e60: mov             x5, x20
    // 0x12e4e64: b               #0x12e4d90
    // 0x12e4e68: r13 = 48
    //     0x12e4e68: mov             x13, #0x30
    // 0x12e4e6c: CheckStackOverflow
    //     0x12e4e6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e4e70: cmp             SP, x16
    //     0x12e4e74: b.ls            #0x12e4fb4
    // 0x12e4e78: cmp             x13, #0x40
    // 0x12e4e7c: b.ge            #0x12e4f50
    // 0x12e4e80: mov             x14, x0
    // 0x12e4e84: ubfx            x14, x14, #0, #0x20
    // 0x12e4e88: mvn             w19, w14
    // 0x12e4e8c: ubfx            x19, x19, #0, #0x20
    // 0x12e4e90: orr             x14, x5, x19
    // 0x12e4e94: eor             x19, x12, x14
    // 0x12e4e98: mov             x14, x13
    // 0x12e4e9c: ubfx            x14, x14, #0, #0x20
    // 0x12e4ea0: r16 = 7
    //     0x12e4ea0: mov             x16, #7
    // 0x12e4ea4: mul             x20, x14, x16
    // 0x12e4ea8: and             w14, w20, #0xf
    // 0x12e4eac: mov             x20, x1
    // 0x12e4eb0: ubfx            x20, x20, #0, #0x20
    // 0x12e4eb4: ubfx            x19, x19, #0, #0x20
    // 0x12e4eb8: add             w23, w20, w19
    // 0x12e4ebc: ArrayLoad: r19 = r11[r13]  ; Unknown_4
    //     0x12e4ebc: add             x16, x11, x13, lsl #2
    //     0x12e4ec0: ldur            w19, [x16, #0xf]
    // 0x12e4ec4: DecompressPointer r19
    //     0x12e4ec4: add             x19, x19, HEAP, lsl #32
    // 0x12e4ec8: ubfx            x14, x14, #0, #0x20
    // 0x12e4ecc: ArrayLoad: r20 = r2[r14]  ; List_4
    //     0x12e4ecc: add             x16, x2, x14, lsl #2
    //     0x12e4ed0: ldur            w20, [x16, #0x17]
    // 0x12e4ed4: r14 = LoadInt32Instr(r19)
    //     0x12e4ed4: sbfx            x14, x19, #1, #0x1f
    //     0x12e4ed8: tbz             w19, #0, #0x12e4ee0
    //     0x12e4edc: ldur            x14, [x19, #7]
    // 0x12e4ee0: add             w19, w14, w20
    // 0x12e4ee4: add             w14, w23, w19
    // 0x12e4ee8: ArrayLoad: r19 = r10[r13]  ; Unknown_4
    //     0x12e4ee8: add             x16, x10, x13, lsl #2
    //     0x12e4eec: ldur            w19, [x16, #0xf]
    // 0x12e4ef0: DecompressPointer r19
    //     0x12e4ef0: add             x19, x19, HEAP, lsl #32
    // 0x12e4ef4: r20 = LoadInt32Instr(r19)
    //     0x12e4ef4: sbfx            x20, x19, #1, #0x1f
    // 0x12e4ef8: and             w19, w20, #0x1f
    // 0x12e4efc: lsl             w20, w14, w19
    // 0x12e4f00: cmp             w19, #0x1f
    // 0x12e4f04: csel            x20, x20, xzr, ls
    // 0x12e4f08: ubfx            x19, x19, #0, #0x20
    // 0x12e4f0c: sub             x23, x9, x19
    // 0x12e4f10: ubfx            x23, x23, #0, #0x20
    // 0x12e4f14: lsr             w19, w14, w23
    // 0x12e4f18: cmp             w23, #0x1f
    // 0x12e4f1c: csel            x19, x19, xzr, ls
    // 0x12e4f20: orr             x14, x20, x19
    // 0x12e4f24: mov             x19, x5
    // 0x12e4f28: ubfx            x19, x19, #0, #0x20
    // 0x12e4f2c: add             w20, w19, w14
    // 0x12e4f30: add             x14, x13, #1
    // 0x12e4f34: ubfx            x20, x20, #0, #0x20
    // 0x12e4f38: mov             x13, x14
    // 0x12e4f3c: mov             x1, x0
    // 0x12e4f40: mov             x0, x12
    // 0x12e4f44: mov             x12, x5
    // 0x12e4f48: mov             x5, x20
    // 0x12e4f4c: b               #0x12e4e6c
    // 0x12e4f50: ubfx            x1, x1, #0, #0x20
    // 0x12e4f54: add             w2, w1, w8
    // 0x12e4f58: ArrayStore: r4[0] = r2  ; List_4
    //     0x12e4f58: stur            w2, [x4, #0x17]
    // 0x12e4f5c: ubfx            x5, x5, #0, #0x20
    // 0x12e4f60: add             w1, w5, w7
    // 0x12e4f64: StoreField: r4->field_1b = r1
    //     0x12e4f64: stur            w1, [x4, #0x1b]
    // 0x12e4f68: ubfx            x12, x12, #0, #0x20
    // 0x12e4f6c: add             w1, w12, w6
    // 0x12e4f70: StoreField: r4->field_1f = r1
    //     0x12e4f70: stur            w1, [x4, #0x1f]
    // 0x12e4f74: ubfx            x0, x0, #0, #0x20
    // 0x12e4f78: add             w1, w0, w3
    // 0x12e4f7c: StoreField: r4->field_23 = r1
    //     0x12e4f7c: stur            w1, [x4, #0x23]
    // 0x12e4f80: r0 = Null
    //     0x12e4f80: mov             x0, NULL
    // 0x12e4f84: LeaveFrame
    //     0x12e4f84: mov             SP, fp
    //     0x12e4f88: ldp             fp, lr, [SP], #0x10
    // 0x12e4f8c: ret
    //     0x12e4f8c: ret             
    // 0x12e4f90: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12e4f90: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12e4f94: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12e4f94: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12e4f98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e4f98: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e4f9c: b               #0x12e4ba0
    // 0x12e4fa0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12e4fa0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12e4fa4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e4fa4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e4fa8: b               #0x12e4ca0
    // 0x12e4fac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e4fac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e4fb0: b               #0x12e4d9c
    // 0x12e4fb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e4fb4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e4fb8: b               #0x12e4e78
  }
}

// class id: 7328, size: 0xc, field offset: 0xc
//   const constructor, 
class _MD5 extends Hash {

  _ startChunkedConversion(/* No info */) {
    // ** addr: 0x121d620, size: 0x50
    // 0x121d620: EnterFrame
    //     0x121d620: stp             fp, lr, [SP, #-0x10]!
    //     0x121d624: mov             fp, SP
    // 0x121d628: AllocStack(0x8)
    //     0x121d628: sub             SP, SP, #8
    // 0x121d62c: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x121d62c: stur            x2, [fp, #-8]
    // 0x121d630: CheckStackOverflow
    //     0x121d630: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x121d634: cmp             SP, x16
    //     0x121d638: b.ls            #0x121d668
    // 0x121d63c: r0 = _MD5Sink()
    //     0x121d63c: bl              #0x121d790  ; Allocate_MD5SinkStub -> _MD5Sink (size=0x3c)
    // 0x121d640: mov             x1, x0
    // 0x121d644: ldur            x2, [fp, #-8]
    // 0x121d648: stur            x0, [fp, #-8]
    // 0x121d64c: r0 = _MD5Sink()
    //     0x121d64c: bl              #0x121d670  ; [package:crypto/src/md5.dart] _MD5Sink::_MD5Sink
    // 0x121d650: r0 = _ByteAdapterSink()
    //     0x121d650: bl              #0x121d614  ; Allocate_ByteAdapterSinkStub -> _ByteAdapterSink (size=0xc)
    // 0x121d654: ldur            x1, [fp, #-8]
    // 0x121d658: StoreField: r0->field_7 = r1
    //     0x121d658: stur            w1, [x0, #7]
    // 0x121d65c: LeaveFrame
    //     0x121d65c: mov             SP, fp
    //     0x121d660: ldp             fp, lr, [SP], #0x10
    // 0x121d664: ret
    //     0x121d664: ret             
    // 0x121d668: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x121d668: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x121d66c: b               #0x121d63c
  }
}
