// lib: , url: package:clock/clock.dart

// class id: 1048647, size: 0x8
class :: {

  [closure] static DateTime systemTime(dynamic) {
    // ** addr: 0xaf2fd8, size: 0x2c
    // 0xaf2fd8: EnterFrame
    //     0xaf2fd8: stp             fp, lr, [SP, #-0x10]!
    //     0xaf2fdc: mov             fp, SP
    // 0xaf2fe0: CheckStackOverflow
    //     0xaf2fe0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xaf2fe4: cmp             SP, x16
    //     0xaf2fe8: b.ls            #0xaf2ffc
    // 0xaf2fec: r0 = now()
    //     0xaf2fec: bl              #0xaf3004  ; [package:flutter/src/material/date.dart] GregorianCalendarDelegate::now
    // 0xaf2ff0: LeaveFrame
    //     0xaf2ff0: mov             SP, fp
    //     0xaf2ff4: ldp             fp, lr, [SP], #0x10
    // 0xaf2ff8: ret
    //     0xaf2ff8: ret             
    // 0xaf2ffc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaf2ffc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaf3000: b               #0xaf2fec
  }
}
