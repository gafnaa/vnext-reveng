// lib: , url: package:clock/src/default.dart

// class id: 1048649, size: 0x8
class :: {

  static late final Object _clockKey; // offset: 0xf60

  get _ clock(/* No info */) {
    // ** addr: 0xaf305c, size: 0xe8
    // 0xaf305c: EnterFrame
    //     0xaf305c: stp             fp, lr, [SP, #-0x10]!
    //     0xaf3060: mov             fp, SP
    // 0xaf3064: AllocStack(0x8)
    //     0xaf3064: sub             SP, SP, #8
    // 0xaf3068: CheckStackOverflow
    //     0xaf3068: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xaf306c: cmp             SP, x16
    //     0xaf3070: b.ls            #0xaf313c
    // 0xaf3074: r0 = LoadStaticField(0x364)
    //     0xaf3074: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xaf3078: ldr             x0, [x0, #0x6c8]
    // 0xaf307c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xaf3080: cmp             w0, w16
    // 0xaf3084: b.ne            #0xaf3090
    // 0xaf3088: r2 = _current
    //     0xaf3088: ldr             x2, [PP, #0x2c0]  ; [pp+0x2c0] Field <Zone._current@5048458>: static late (offset: 0x364)
    // 0xaf308c: r0 = InitLateStaticField()
    //     0xaf308c: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0xaf3090: stur            x0, [fp, #-8]
    // 0xaf3094: r0 = LoadStaticField(0xf60)
    //     0xaf3094: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xaf3098: ldr             x0, [x0, #0x1ec0]
    // 0xaf309c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xaf30a0: cmp             w0, w16
    // 0xaf30a4: b.ne            #0xaf30b4
    // 0xaf30a8: r2 = _clockKey
    //     0xaf30a8: add             x2, PP, #0x20, lsl #12  ; [pp+0x20f80] Field <::._clockKey@1230264408>: static late final (offset: 0xf60)
    //     0xaf30ac: ldr             x2, [x2, #0xf80]
    // 0xaf30b0: r0 = InitLateFinalStaticField()
    //     0xaf30b0: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xaf30b4: ldur            x1, [fp, #-8]
    // 0xaf30b8: r2 = LoadClassIdInstr(r1)
    //     0xaf30b8: ldur            x2, [x1, #-1]
    //     0xaf30bc: ubfx            x2, x2, #0xc, #0x14
    // 0xaf30c0: mov             x16, x0
    // 0xaf30c4: mov             x0, x2
    // 0xaf30c8: mov             x2, x16
    // 0xaf30cc: r0 = GDT[cid_x0 + -0xff3]()
    //     0xaf30cc: sub             lr, x0, #0xff3
    //     0xaf30d0: ldr             lr, [x21, lr, lsl #3]
    //     0xaf30d4: blr             lr
    // 0xaf30d8: mov             x3, x0
    // 0xaf30dc: r2 = Null
    //     0xaf30dc: mov             x2, NULL
    // 0xaf30e0: r1 = Null
    //     0xaf30e0: mov             x1, NULL
    // 0xaf30e4: stur            x3, [fp, #-8]
    // 0xaf30e8: r4 = 60
    //     0xaf30e8: mov             x4, #0x3c
    // 0xaf30ec: branchIfSmi(r0, 0xaf30f8)
    //     0xaf30ec: tbz             w0, #0, #0xaf30f8
    // 0xaf30f0: r4 = LoadClassIdInstr(r0)
    //     0xaf30f0: ldur            x4, [x0, #-1]
    //     0xaf30f4: ubfx            x4, x4, #0xc, #0x14
    // 0xaf30f8: cmp             x4, #0xdfd
    // 0xaf30fc: b.eq            #0xaf3114
    // 0xaf3100: r8 = Clock?
    //     0xaf3100: add             x8, PP, #0x20, lsl #12  ; [pp+0x20f88] Type: Clock?
    //     0xaf3104: ldr             x8, [x8, #0xf88]
    // 0xaf3108: r3 = Null
    //     0xaf3108: add             x3, PP, #0x20, lsl #12  ; [pp+0x20f90] Null
    //     0xaf310c: ldr             x3, [x3, #0xf90]
    // 0xaf3110: r0 = DefaultNullableTypeTest()
    //     0xaf3110: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0xaf3114: ldur            x1, [fp, #-8]
    // 0xaf3118: cmp             w1, NULL
    // 0xaf311c: b.ne            #0xaf312c
    // 0xaf3120: r0 = Instance_Clock
    //     0xaf3120: add             x0, PP, #0x20, lsl #12  ; [pp+0x20fa0] Obj!Clock@12a0061
    //     0xaf3124: ldr             x0, [x0, #0xfa0]
    // 0xaf3128: b               #0xaf3130
    // 0xaf312c: mov             x0, x1
    // 0xaf3130: LeaveFrame
    //     0xaf3130: mov             SP, fp
    //     0xaf3134: ldp             fp, lr, [SP], #0x10
    // 0xaf3138: ret
    //     0xaf3138: ret             
    // 0xaf313c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaf313c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaf3140: b               #0xaf3074
  }
}
