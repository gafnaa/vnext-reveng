// lib: , url: package:archive/src/codecs/zlib_decoder.dart

// class id: 1048604, size: 0x8
class :: {
}

// class id: 3627, size: 0x8, field offset: 0x8
//   const constructor, 
class ZLibDecoder extends Object {

  _ decodeBytes(/* No info */) {
    // ** addr: 0x13405a0, size: 0x34
    // 0x13405a0: EnterFrame
    //     0x13405a0: stp             fp, lr, [SP, #-0x10]!
    //     0x13405a4: mov             fp, SP
    // 0x13405a8: CheckStackOverflow
    //     0x13405a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13405ac: cmp             SP, x16
    //     0x13405b0: b.ls            #0x13405cc
    // 0x13405b4: r1 = Instance__ZLibDecoder
    //     0x13405b4: add             x1, PP, #0x88, lsl #12  ; [pp+0x88b18] Obj!_ZLibDecoder@12a0421
    //     0x13405b8: ldr             x1, [x1, #0xb18]
    // 0x13405bc: r0 = decodeBytes()
    //     0x13405bc: bl              #0x1342a00  ; [package:archive/src/codecs/zlib/_zlib_decoder_io.dart] _ZLibDecoder::decodeBytes
    // 0x13405c0: LeaveFrame
    //     0x13405c0: mov             SP, fp
    //     0x13405c4: ldp             fp, lr, [SP], #0x10
    // 0x13405c8: ret
    //     0x13405c8: ret             
    // 0x13405cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13405cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13405d0: b               #0x13405b4
  }
}
