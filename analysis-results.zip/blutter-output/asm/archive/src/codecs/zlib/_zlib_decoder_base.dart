// lib: , url: package:archive/src/codecs/zlib/_zlib_decoder_base.dart

// class id: 1048602, size: 0x8
class :: {
}

// class id: 3628, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class ZLibDecoderBase extends Object {
}
