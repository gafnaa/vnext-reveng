// lib: , url: package:archive/src/codecs/zlib/_zlib_decoder_io.dart

// class id: 1048603, size: 0x8
class :: {
}

// class id: 3629, size: 0x8, field offset: 0x8
//   const constructor, 
class _ZLibDecoder extends ZLibDecoderBase {

  _ decodeBytes(/* No info */) {
    // ** addr: 0x1342a00, size: 0x74
    // 0x1342a00: EnterFrame
    //     0x1342a00: stp             fp, lr, [SP, #-0x10]!
    //     0x1342a04: mov             fp, SP
    // 0x1342a08: AllocStack(0x10)
    //     0x1342a08: sub             SP, SP, #0x10
    // 0x1342a0c: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x1342a0c: stur            x2, [fp, #-8]
    // 0x1342a10: CheckStackOverflow
    //     0x1342a10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1342a14: cmp             SP, x16
    //     0x1342a18: b.ls            #0x1342a6c
    // 0x1342a1c: r1 = <List<int>, List<int>>
    //     0x1342a1c: ldr             x1, [PP, #0x35a0]  ; [pp+0x35a0] TypeArguments: <List<int>, List<int>>
    // 0x1342a20: r0 = ZLibCodec()
    //     0x1342a20: bl              #0x1342a74  ; AllocateZLibCodecStub -> ZLibCodec (size=0x34)
    // 0x1342a24: mov             x1, x0
    // 0x1342a28: r0 = 6
    //     0x1342a28: mov             x0, #6
    // 0x1342a2c: stur            x1, [fp, #-0x10]
    // 0x1342a30: StoreField: r1->field_b = r0
    //     0x1342a30: stur            x0, [x1, #0xb]
    // 0x1342a34: r0 = 15
    //     0x1342a34: mov             x0, #0xf
    // 0x1342a38: StoreField: r1->field_23 = r0
    //     0x1342a38: stur            x0, [x1, #0x23]
    // 0x1342a3c: r0 = 8
    //     0x1342a3c: mov             x0, #8
    // 0x1342a40: StoreField: r1->field_13 = r0
    //     0x1342a40: stur            x0, [x1, #0x13]
    // 0x1342a44: StoreField: r1->field_1b = rZR
    //     0x1342a44: stur            xzr, [x1, #0x1b]
    // 0x1342a48: r0 = false
    //     0x1342a48: add             x0, NULL, #0x30  ; false
    // 0x1342a4c: StoreField: r1->field_2b = r0
    //     0x1342a4c: stur            w0, [x1, #0x2b]
    // 0x1342a50: r0 = _validateZLibStrategy()
    //     0x1342a50: bl              #0x121a868  ; [dart:io] ::_validateZLibStrategy
    // 0x1342a54: ldur            x1, [fp, #-0x10]
    // 0x1342a58: ldur            x2, [fp, #-8]
    // 0x1342a5c: r0 = decode()
    //     0x1342a5c: bl              #0x121a328  ; [dart:convert] Codec::decode
    // 0x1342a60: LeaveFrame
    //     0x1342a60: mov             SP, fp
    //     0x1342a64: ldp             fp, lr, [SP], #0x10
    // 0x1342a68: ret
    //     0x1342a68: ret             
    // 0x1342a6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1342a6c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1342a70: b               #0x1342a1c
  }
}
