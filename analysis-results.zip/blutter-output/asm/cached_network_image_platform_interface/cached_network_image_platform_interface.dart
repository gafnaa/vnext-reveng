// lib: cached_network_image_platform_interface, url: package:cached_network_image_platform_interface/cached_network_image_platform_interface.dart

// class id: 1048620, size: 0x8
class :: {
}

// class id: 3605, size: 0x8, field offset: 0x8
abstract class ImageLoader extends Object {
}

// class id: 8341, size: 0x14, field offset: 0x14
enum ImageRenderMethodForWeb extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11a902c, size: 0x64
    // 0x11a902c: EnterFrame
    //     0x11a902c: stp             fp, lr, [SP, #-0x10]!
    //     0x11a9030: mov             fp, SP
    // 0x11a9034: AllocStack(0x10)
    //     0x11a9034: sub             SP, SP, #0x10
    // 0x11a9038: SetupParameters(ImageRenderMethodForWeb this /* r1 => r0, fp-0x8 */)
    //     0x11a9038: mov             x0, x1
    //     0x11a903c: stur            x1, [fp, #-8]
    // 0x11a9040: CheckStackOverflow
    //     0x11a9040: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a9044: cmp             SP, x16
    //     0x11a9048: b.ls            #0x11a9088
    // 0x11a904c: r1 = Null
    //     0x11a904c: mov             x1, NULL
    // 0x11a9050: r2 = 4
    //     0x11a9050: mov             x2, #4
    // 0x11a9054: r0 = AllocateArray()
    //     0x11a9054: bl              #0x13df928  ; AllocateArrayStub
    // 0x11a9058: r16 = "ImageRenderMethodForWeb."
    //     0x11a9058: add             x16, PP, #0x7e, lsl #12  ; [pp+0x7ee38] "ImageRenderMethodForWeb."
    //     0x11a905c: ldr             x16, [x16, #0xe38]
    // 0x11a9060: StoreField: r0->field_f = r16
    //     0x11a9060: stur            w16, [x0, #0xf]
    // 0x11a9064: ldur            x1, [fp, #-8]
    // 0x11a9068: LoadField: r2 = r1->field_f
    //     0x11a9068: ldur            w2, [x1, #0xf]
    // 0x11a906c: DecompressPointer r2
    //     0x11a906c: add             x2, x2, HEAP, lsl #32
    // 0x11a9070: StoreField: r0->field_13 = r2
    //     0x11a9070: stur            w2, [x0, #0x13]
    // 0x11a9074: str             x0, [SP]
    // 0x11a9078: r0 = _interpolate()
    //     0x11a9078: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11a907c: LeaveFrame
    //     0x11a907c: mov             SP, fp
    //     0x11a9080: ldp             fp, lr, [SP], #0x10
    // 0x11a9084: ret
    //     0x11a9084: ret             
    // 0x11a9088: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a9088: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a908c: b               #0x11a904c
  }
}
