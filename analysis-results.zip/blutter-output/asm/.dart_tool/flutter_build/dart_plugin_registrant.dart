// lib: , url: file:///D:/Flutter%20Project/simaster-mahasiswa/.dart_tool/flutter_build/dart_plugin_registrant.dart

// class id: 1048597, size: 0x8
class :: {
}

// class id: 3714, size: 0x8, field offset: 0x8
class _PluginRegistrant extends Object {

  static void register() {
    // ** addr: 0x13e3f34, size: 0x434
    // 0x13e3f34: EnterFrame
    //     0x13e3f34: stp             fp, lr, [SP, #-0x10]!
    //     0x13e3f38: mov             fp, SP
    // 0x13e3f3c: AllocStack(0x48)
    //     0x13e3f3c: sub             SP, SP, #0x48
    // 0x13e3f40: CheckStackOverflow
    //     0x13e3f40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13e3f44: cmp             SP, x16
    //     0x13e3f48: b.ls            #0x13e4360
    // 0x13e3f4c: r0 = registerWith()
    //     0x13e3f4c: bl              #0x13e51a0  ; [package:flutter_background_service_android/flutter_background_service_android.dart] FlutterBackgroundServiceAndroid::registerWith
    // 0x13e3f50: r0 = Null
    //     0x13e3f50: mov             x0, NULL
    // 0x13e3f54: b               #0x13e3f98
    // 0x13e3f58: sub             SP, fp, #0x48
    // 0x13e3f5c: stur            x0, [fp, #-0x40]
    // 0x13e3f60: r1 = Null
    //     0x13e3f60: mov             x1, NULL
    // 0x13e3f64: r2 = 6
    //     0x13e3f64: mov             x2, #6
    // 0x13e3f68: r0 = AllocateArray()
    //     0x13e3f68: bl              #0x13df928  ; AllocateArrayStub
    // 0x13e3f6c: r16 = "`flutter_background_service_android` threw an error: "
    //     0x13e3f6c: ldr             x16, [PP, #0x6848]  ; [pp+0x6848] "`flutter_background_service_android` threw an error: "
    // 0x13e3f70: StoreField: r0->field_f = r16
    //     0x13e3f70: stur            w16, [x0, #0xf]
    // 0x13e3f74: ldur            x1, [fp, #-0x40]
    // 0x13e3f78: StoreField: r0->field_13 = r1
    //     0x13e3f78: stur            w1, [x0, #0x13]
    // 0x13e3f7c: r16 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0x13e3f7c: ldr             x16, [PP, #0x6850]  ; [pp+0x6850] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0x13e3f80: ArrayStore: r0[0] = r16  ; List_4
    //     0x13e3f80: stur            w16, [x0, #0x17]
    // 0x13e3f84: str             x0, [SP]
    // 0x13e3f88: r0 = _interpolate()
    //     0x13e3f88: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x13e3f8c: mov             x1, x0
    // 0x13e3f90: r0 = print()
    //     0x13e3f90: bl              #0x82a3d4  ; [dart:core] ::print
    // 0x13e3f94: ldur            x0, [fp, #-0x40]
    // 0x13e3f98: stur            x0, [fp, #-0x40]
    // 0x13e3f9c: r0 = registerWith()
    //     0x13e3f9c: bl              #0x13e5074  ; [package:flutter_custom_tabs_android/src/custom_tabs_plugin_android.dart] CustomTabsPluginAndroid::registerWith
    // 0x13e3fa0: ldur            x0, [fp, #-0x40]
    // 0x13e3fa4: b               #0x13e3fe8
    // 0x13e3fa8: sub             SP, fp, #0x48
    // 0x13e3fac: stur            x0, [fp, #-0x40]
    // 0x13e3fb0: r1 = Null
    //     0x13e3fb0: mov             x1, NULL
    // 0x13e3fb4: r2 = 6
    //     0x13e3fb4: mov             x2, #6
    // 0x13e3fb8: r0 = AllocateArray()
    //     0x13e3fb8: bl              #0x13df928  ; AllocateArrayStub
    // 0x13e3fbc: r16 = "`flutter_custom_tabs_android` threw an error: "
    //     0x13e3fbc: ldr             x16, [PP, #0x6858]  ; [pp+0x6858] "`flutter_custom_tabs_android` threw an error: "
    // 0x13e3fc0: StoreField: r0->field_f = r16
    //     0x13e3fc0: stur            w16, [x0, #0xf]
    // 0x13e3fc4: ldur            x1, [fp, #-0x40]
    // 0x13e3fc8: StoreField: r0->field_13 = r1
    //     0x13e3fc8: stur            w1, [x0, #0x13]
    // 0x13e3fcc: r16 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0x13e3fcc: ldr             x16, [PP, #0x6850]  ; [pp+0x6850] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0x13e3fd0: ArrayStore: r0[0] = r16  ; List_4
    //     0x13e3fd0: stur            w16, [x0, #0x17]
    // 0x13e3fd4: str             x0, [SP]
    // 0x13e3fd8: r0 = _interpolate()
    //     0x13e3fd8: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x13e3fdc: mov             x1, x0
    // 0x13e3fe0: r0 = print()
    //     0x13e3fe0: bl              #0x82a3d4  ; [dart:core] ::print
    // 0x13e3fe4: ldur            x0, [fp, #-0x40]
    // 0x13e3fe8: stur            x0, [fp, #-0x40]
    // 0x13e3fec: r0 = registerWith()
    //     0x13e3fec: bl              #0x13e5004  ; [package:flutter_image_compress_common/flutter_image_compress_common.dart] FlutterImageCompressCommon::registerWith
    // 0x13e3ff0: ldur            x0, [fp, #-0x40]
    // 0x13e3ff4: b               #0x13e4038
    // 0x13e3ff8: sub             SP, fp, #0x48
    // 0x13e3ffc: stur            x0, [fp, #-0x40]
    // 0x13e4000: r1 = Null
    //     0x13e4000: mov             x1, NULL
    // 0x13e4004: r2 = 6
    //     0x13e4004: mov             x2, #6
    // 0x13e4008: r0 = AllocateArray()
    //     0x13e4008: bl              #0x13df928  ; AllocateArrayStub
    // 0x13e400c: r16 = "`flutter_image_compress_common` threw an error: "
    //     0x13e400c: ldr             x16, [PP, #0x6860]  ; [pp+0x6860] "`flutter_image_compress_common` threw an error: "
    // 0x13e4010: StoreField: r0->field_f = r16
    //     0x13e4010: stur            w16, [x0, #0xf]
    // 0x13e4014: ldur            x1, [fp, #-0x40]
    // 0x13e4018: StoreField: r0->field_13 = r1
    //     0x13e4018: stur            w1, [x0, #0x13]
    // 0x13e401c: r16 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0x13e401c: ldr             x16, [PP, #0x6850]  ; [pp+0x6850] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0x13e4020: ArrayStore: r0[0] = r16  ; List_4
    //     0x13e4020: stur            w16, [x0, #0x17]
    // 0x13e4024: str             x0, [SP]
    // 0x13e4028: r0 = _interpolate()
    //     0x13e4028: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x13e402c: mov             x1, x0
    // 0x13e4030: r0 = print()
    //     0x13e4030: bl              #0x82a3d4  ; [dart:core] ::print
    // 0x13e4034: ldur            x0, [fp, #-0x40]
    // 0x13e4038: stur            x0, [fp, #-0x40]
    // 0x13e403c: r0 = registerWith()
    //     0x13e403c: bl              #0x13e4ecc  ; [package:flutter_local_notifications/src/platform_flutter_local_notifications.dart] AndroidFlutterLocalNotificationsPlugin::registerWith
    // 0x13e4040: ldur            x0, [fp, #-0x40]
    // 0x13e4044: b               #0x13e4088
    // 0x13e4048: sub             SP, fp, #0x48
    // 0x13e404c: stur            x0, [fp, #-0x40]
    // 0x13e4050: r1 = Null
    //     0x13e4050: mov             x1, NULL
    // 0x13e4054: r2 = 6
    //     0x13e4054: mov             x2, #6
    // 0x13e4058: r0 = AllocateArray()
    //     0x13e4058: bl              #0x13df928  ; AllocateArrayStub
    // 0x13e405c: r16 = "`flutter_local_notifications` threw an error: "
    //     0x13e405c: ldr             x16, [PP, #0x6868]  ; [pp+0x6868] "`flutter_local_notifications` threw an error: "
    // 0x13e4060: StoreField: r0->field_f = r16
    //     0x13e4060: stur            w16, [x0, #0xf]
    // 0x13e4064: ldur            x1, [fp, #-0x40]
    // 0x13e4068: StoreField: r0->field_13 = r1
    //     0x13e4068: stur            w1, [x0, #0x13]
    // 0x13e406c: r16 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0x13e406c: ldr             x16, [PP, #0x6850]  ; [pp+0x6850] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0x13e4070: ArrayStore: r0[0] = r16  ; List_4
    //     0x13e4070: stur            w16, [x0, #0x17]
    // 0x13e4074: str             x0, [SP]
    // 0x13e4078: r0 = _interpolate()
    //     0x13e4078: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x13e407c: mov             x1, x0
    // 0x13e4080: r0 = print()
    //     0x13e4080: bl              #0x82a3d4  ; [dart:core] ::print
    // 0x13e4084: ldur            x0, [fp, #-0x40]
    // 0x13e4088: stur            x0, [fp, #-0x40]
    // 0x13e408c: r0 = registerWith()
    //     0x13e408c: bl              #0x13e4dc0  ; [package:geolocator_android/src/geolocator_android.dart] GeolocatorAndroid::registerWith
    // 0x13e4090: ldur            x0, [fp, #-0x40]
    // 0x13e4094: b               #0x13e40d8
    // 0x13e4098: sub             SP, fp, #0x48
    // 0x13e409c: stur            x0, [fp, #-0x40]
    // 0x13e40a0: r1 = Null
    //     0x13e40a0: mov             x1, NULL
    // 0x13e40a4: r2 = 6
    //     0x13e40a4: mov             x2, #6
    // 0x13e40a8: r0 = AllocateArray()
    //     0x13e40a8: bl              #0x13df928  ; AllocateArrayStub
    // 0x13e40ac: r16 = "`geolocator_android` threw an error: "
    //     0x13e40ac: ldr             x16, [PP, #0x6870]  ; [pp+0x6870] "`geolocator_android` threw an error: "
    // 0x13e40b0: StoreField: r0->field_f = r16
    //     0x13e40b0: stur            w16, [x0, #0xf]
    // 0x13e40b4: ldur            x1, [fp, #-0x40]
    // 0x13e40b8: StoreField: r0->field_13 = r1
    //     0x13e40b8: stur            w1, [x0, #0x13]
    // 0x13e40bc: r16 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0x13e40bc: ldr             x16, [PP, #0x6850]  ; [pp+0x6850] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0x13e40c0: ArrayStore: r0[0] = r16  ; List_4
    //     0x13e40c0: stur            w16, [x0, #0x17]
    // 0x13e40c4: str             x0, [SP]
    // 0x13e40c8: r0 = _interpolate()
    //     0x13e40c8: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x13e40cc: mov             x1, x0
    // 0x13e40d0: r0 = print()
    //     0x13e40d0: bl              #0x82a3d4  ; [dart:core] ::print
    // 0x13e40d4: ldur            x0, [fp, #-0x40]
    // 0x13e40d8: stur            x0, [fp, #-0x40]
    // 0x13e40dc: r0 = registerWith()
    //     0x13e40dc: bl              #0x13e4cc8  ; [package:image_picker_android/image_picker_android.dart] ImagePickerAndroid::registerWith
    // 0x13e40e0: ldur            x0, [fp, #-0x40]
    // 0x13e40e4: b               #0x13e4128
    // 0x13e40e8: sub             SP, fp, #0x48
    // 0x13e40ec: stur            x0, [fp, #-0x40]
    // 0x13e40f0: r1 = Null
    //     0x13e40f0: mov             x1, NULL
    // 0x13e40f4: r2 = 6
    //     0x13e40f4: mov             x2, #6
    // 0x13e40f8: r0 = AllocateArray()
    //     0x13e40f8: bl              #0x13df928  ; AllocateArrayStub
    // 0x13e40fc: r16 = "`image_picker_android` threw an error: "
    //     0x13e40fc: ldr             x16, [PP, #0x6878]  ; [pp+0x6878] "`image_picker_android` threw an error: "
    // 0x13e4100: StoreField: r0->field_f = r16
    //     0x13e4100: stur            w16, [x0, #0xf]
    // 0x13e4104: ldur            x1, [fp, #-0x40]
    // 0x13e4108: StoreField: r0->field_13 = r1
    //     0x13e4108: stur            w1, [x0, #0x13]
    // 0x13e410c: r16 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0x13e410c: ldr             x16, [PP, #0x6850]  ; [pp+0x6850] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0x13e4110: ArrayStore: r0[0] = r16  ; List_4
    //     0x13e4110: stur            w16, [x0, #0x17]
    // 0x13e4114: str             x0, [SP]
    // 0x13e4118: r0 = _interpolate()
    //     0x13e4118: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x13e411c: mov             x1, x0
    // 0x13e4120: r0 = print()
    //     0x13e4120: bl              #0x82a3d4  ; [dart:core] ::print
    // 0x13e4124: ldur            x0, [fp, #-0x40]
    // 0x13e4128: stur            x0, [fp, #-0x40]
    // 0x13e412c: r0 = registerWith()
    //     0x13e412c: bl              #0x13e4bbc  ; [package:path_provider_android/src/path_provider_android_real.dart] PathProviderAndroid::registerWith
    // 0x13e4130: ldur            x0, [fp, #-0x40]
    // 0x13e4134: b               #0x13e4178
    // 0x13e4138: sub             SP, fp, #0x48
    // 0x13e413c: stur            x0, [fp, #-0x40]
    // 0x13e4140: r1 = Null
    //     0x13e4140: mov             x1, NULL
    // 0x13e4144: r2 = 6
    //     0x13e4144: mov             x2, #6
    // 0x13e4148: r0 = AllocateArray()
    //     0x13e4148: bl              #0x13df928  ; AllocateArrayStub
    // 0x13e414c: r16 = "`path_provider_android` threw an error: "
    //     0x13e414c: ldr             x16, [PP, #0x6880]  ; [pp+0x6880] "`path_provider_android` threw an error: "
    // 0x13e4150: StoreField: r0->field_f = r16
    //     0x13e4150: stur            w16, [x0, #0xf]
    // 0x13e4154: ldur            x1, [fp, #-0x40]
    // 0x13e4158: StoreField: r0->field_13 = r1
    //     0x13e4158: stur            w1, [x0, #0x13]
    // 0x13e415c: r16 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0x13e415c: ldr             x16, [PP, #0x6850]  ; [pp+0x6850] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0x13e4160: ArrayStore: r0[0] = r16  ; List_4
    //     0x13e4160: stur            w16, [x0, #0x17]
    // 0x13e4164: str             x0, [SP]
    // 0x13e4168: r0 = _interpolate()
    //     0x13e4168: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x13e416c: mov             x1, x0
    // 0x13e4170: r0 = print()
    //     0x13e4170: bl              #0x82a3d4  ; [dart:core] ::print
    // 0x13e4174: ldur            x0, [fp, #-0x40]
    // 0x13e4178: stur            x0, [fp, #-0x40]
    // 0x13e417c: r0 = registerWith()
    //     0x13e417c: bl              #0x13e4a90  ; [package:quick_actions_android/quick_actions_android.dart] QuickActionsAndroid::registerWith
    // 0x13e4180: ldur            x0, [fp, #-0x40]
    // 0x13e4184: b               #0x13e41c8
    // 0x13e4188: sub             SP, fp, #0x48
    // 0x13e418c: stur            x0, [fp, #-0x40]
    // 0x13e4190: r1 = Null
    //     0x13e4190: mov             x1, NULL
    // 0x13e4194: r2 = 6
    //     0x13e4194: mov             x2, #6
    // 0x13e4198: r0 = AllocateArray()
    //     0x13e4198: bl              #0x13df928  ; AllocateArrayStub
    // 0x13e419c: r16 = "`quick_actions_android` threw an error: "
    //     0x13e419c: ldr             x16, [PP, #0x6888]  ; [pp+0x6888] "`quick_actions_android` threw an error: "
    // 0x13e41a0: StoreField: r0->field_f = r16
    //     0x13e41a0: stur            w16, [x0, #0xf]
    // 0x13e41a4: ldur            x1, [fp, #-0x40]
    // 0x13e41a8: StoreField: r0->field_13 = r1
    //     0x13e41a8: stur            w1, [x0, #0x13]
    // 0x13e41ac: r16 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0x13e41ac: ldr             x16, [PP, #0x6850]  ; [pp+0x6850] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0x13e41b0: ArrayStore: r0[0] = r16  ; List_4
    //     0x13e41b0: stur            w16, [x0, #0x17]
    // 0x13e41b4: str             x0, [SP]
    // 0x13e41b8: r0 = _interpolate()
    //     0x13e41b8: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x13e41bc: mov             x1, x0
    // 0x13e41c0: r0 = print()
    //     0x13e41c0: bl              #0x82a3d4  ; [dart:core] ::print
    // 0x13e41c4: ldur            x0, [fp, #-0x40]
    // 0x13e41c8: stur            x0, [fp, #-0x40]
    // 0x13e41cc: r0 = registerWith()
    //     0x13e41cc: bl              #0x13e4860  ; [package:shared_preferences_android/src/shared_preferences_android.dart] SharedPreferencesAndroid::registerWith
    // 0x13e41d0: ldur            x0, [fp, #-0x40]
    // 0x13e41d4: b               #0x13e4218
    // 0x13e41d8: sub             SP, fp, #0x48
    // 0x13e41dc: stur            x0, [fp, #-0x40]
    // 0x13e41e0: r1 = Null
    //     0x13e41e0: mov             x1, NULL
    // 0x13e41e4: r2 = 6
    //     0x13e41e4: mov             x2, #6
    // 0x13e41e8: r0 = AllocateArray()
    //     0x13e41e8: bl              #0x13df928  ; AllocateArrayStub
    // 0x13e41ec: r16 = "`shared_preferences_android` threw an error: "
    //     0x13e41ec: ldr             x16, [PP, #0x6890]  ; [pp+0x6890] "`shared_preferences_android` threw an error: "
    // 0x13e41f0: StoreField: r0->field_f = r16
    //     0x13e41f0: stur            w16, [x0, #0xf]
    // 0x13e41f4: ldur            x1, [fp, #-0x40]
    // 0x13e41f8: StoreField: r0->field_13 = r1
    //     0x13e41f8: stur            w1, [x0, #0x13]
    // 0x13e41fc: r16 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0x13e41fc: ldr             x16, [PP, #0x6850]  ; [pp+0x6850] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0x13e4200: ArrayStore: r0[0] = r16  ; List_4
    //     0x13e4200: stur            w16, [x0, #0x17]
    // 0x13e4204: str             x0, [SP]
    // 0x13e4208: r0 = _interpolate()
    //     0x13e4208: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x13e420c: mov             x1, x0
    // 0x13e4210: r0 = print()
    //     0x13e4210: bl              #0x82a3d4  ; [dart:core] ::print
    // 0x13e4214: ldur            x0, [fp, #-0x40]
    // 0x13e4218: stur            x0, [fp, #-0x40]
    // 0x13e421c: r0 = initWithDatabaseFactoryMethodChannel()
    //     0x13e421c: bl              #0x13e4758  ; [package:sqflite_platform_interface/sqflite_platform_interface.dart] SqflitePlatform::initWithDatabaseFactoryMethodChannel
    // 0x13e4220: ldur            x0, [fp, #-0x40]
    // 0x13e4224: b               #0x13e4268
    // 0x13e4228: sub             SP, fp, #0x48
    // 0x13e422c: stur            x0, [fp, #-0x40]
    // 0x13e4230: r1 = Null
    //     0x13e4230: mov             x1, NULL
    // 0x13e4234: r2 = 6
    //     0x13e4234: mov             x2, #6
    // 0x13e4238: r0 = AllocateArray()
    //     0x13e4238: bl              #0x13df928  ; AllocateArrayStub
    // 0x13e423c: r16 = "`sqflite_android` threw an error: "
    //     0x13e423c: ldr             x16, [PP, #0x6898]  ; [pp+0x6898] "`sqflite_android` threw an error: "
    // 0x13e4240: StoreField: r0->field_f = r16
    //     0x13e4240: stur            w16, [x0, #0xf]
    // 0x13e4244: ldur            x1, [fp, #-0x40]
    // 0x13e4248: StoreField: r0->field_13 = r1
    //     0x13e4248: stur            w1, [x0, #0x13]
    // 0x13e424c: r16 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0x13e424c: ldr             x16, [PP, #0x6850]  ; [pp+0x6850] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0x13e4250: ArrayStore: r0[0] = r16  ; List_4
    //     0x13e4250: stur            w16, [x0, #0x17]
    // 0x13e4254: str             x0, [SP]
    // 0x13e4258: r0 = _interpolate()
    //     0x13e4258: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x13e425c: mov             x1, x0
    // 0x13e4260: r0 = print()
    //     0x13e4260: bl              #0x82a3d4  ; [dart:core] ::print
    // 0x13e4264: ldur            x0, [fp, #-0x40]
    // 0x13e4268: stur            x0, [fp, #-0x40]
    // 0x13e426c: r0 = registerWith()
    //     0x13e426c: bl              #0x13e462c  ; [package:url_launcher_android/url_launcher_android.dart] UrlLauncherAndroid::registerWith
    // 0x13e4270: ldur            x0, [fp, #-0x40]
    // 0x13e4274: b               #0x13e42b8
    // 0x13e4278: sub             SP, fp, #0x48
    // 0x13e427c: stur            x0, [fp, #-0x40]
    // 0x13e4280: r1 = Null
    //     0x13e4280: mov             x1, NULL
    // 0x13e4284: r2 = 6
    //     0x13e4284: mov             x2, #6
    // 0x13e4288: r0 = AllocateArray()
    //     0x13e4288: bl              #0x13df928  ; AllocateArrayStub
    // 0x13e428c: r16 = "`url_launcher_android` threw an error: "
    //     0x13e428c: ldr             x16, [PP, #0x68a0]  ; [pp+0x68a0] "`url_launcher_android` threw an error: "
    // 0x13e4290: StoreField: r0->field_f = r16
    //     0x13e4290: stur            w16, [x0, #0xf]
    // 0x13e4294: ldur            x1, [fp, #-0x40]
    // 0x13e4298: StoreField: r0->field_13 = r1
    //     0x13e4298: stur            w1, [x0, #0x13]
    // 0x13e429c: r16 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0x13e429c: ldr             x16, [PP, #0x6850]  ; [pp+0x6850] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0x13e42a0: ArrayStore: r0[0] = r16  ; List_4
    //     0x13e42a0: stur            w16, [x0, #0x17]
    // 0x13e42a4: str             x0, [SP]
    // 0x13e42a8: r0 = _interpolate()
    //     0x13e42a8: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x13e42ac: mov             x1, x0
    // 0x13e42b0: r0 = print()
    //     0x13e42b0: bl              #0x82a3d4  ; [dart:core] ::print
    // 0x13e42b4: ldur            x0, [fp, #-0x40]
    // 0x13e42b8: stur            x0, [fp, #-0x40]
    // 0x13e42bc: r0 = registerWith()
    //     0x13e42bc: bl              #0x13e446c  ; [package:video_player_android/src/android_video_player.dart] AndroidVideoPlayer::registerWith
    // 0x13e42c0: ldur            x0, [fp, #-0x40]
    // 0x13e42c4: b               #0x13e4308
    // 0x13e42c8: sub             SP, fp, #0x48
    // 0x13e42cc: stur            x0, [fp, #-0x40]
    // 0x13e42d0: r1 = Null
    //     0x13e42d0: mov             x1, NULL
    // 0x13e42d4: r2 = 6
    //     0x13e42d4: mov             x2, #6
    // 0x13e42d8: r0 = AllocateArray()
    //     0x13e42d8: bl              #0x13df928  ; AllocateArrayStub
    // 0x13e42dc: r16 = "`video_player_android` threw an error: "
    //     0x13e42dc: ldr             x16, [PP, #0x68a8]  ; [pp+0x68a8] "`video_player_android` threw an error: "
    // 0x13e42e0: StoreField: r0->field_f = r16
    //     0x13e42e0: stur            w16, [x0, #0xf]
    // 0x13e42e4: ldur            x1, [fp, #-0x40]
    // 0x13e42e8: StoreField: r0->field_13 = r1
    //     0x13e42e8: stur            w1, [x0, #0x13]
    // 0x13e42ec: r16 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0x13e42ec: ldr             x16, [PP, #0x6850]  ; [pp+0x6850] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0x13e42f0: ArrayStore: r0[0] = r16  ; List_4
    //     0x13e42f0: stur            w16, [x0, #0x17]
    // 0x13e42f4: str             x0, [SP]
    // 0x13e42f8: r0 = _interpolate()
    //     0x13e42f8: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x13e42fc: mov             x1, x0
    // 0x13e4300: r0 = print()
    //     0x13e4300: bl              #0x82a3d4  ; [dart:core] ::print
    // 0x13e4304: ldur            x0, [fp, #-0x40]
    // 0x13e4308: stur            x0, [fp, #-0x40]
    // 0x13e430c: r0 = registerWith()
    //     0x13e430c: bl              #0x13e4368  ; [package:webview_flutter_android/src/android_webview_platform.dart] AndroidWebViewPlatform::registerWith
    // 0x13e4310: b               #0x13e4350
    // 0x13e4314: sub             SP, fp, #0x48
    // 0x13e4318: stur            x0, [fp, #-0x40]
    // 0x13e431c: r1 = Null
    //     0x13e431c: mov             x1, NULL
    // 0x13e4320: r2 = 6
    //     0x13e4320: mov             x2, #6
    // 0x13e4324: r0 = AllocateArray()
    //     0x13e4324: bl              #0x13df928  ; AllocateArrayStub
    // 0x13e4328: r16 = "`webview_flutter_android` threw an error: "
    //     0x13e4328: ldr             x16, [PP, #0x68b0]  ; [pp+0x68b0] "`webview_flutter_android` threw an error: "
    // 0x13e432c: StoreField: r0->field_f = r16
    //     0x13e432c: stur            w16, [x0, #0xf]
    // 0x13e4330: ldur            x1, [fp, #-0x40]
    // 0x13e4334: StoreField: r0->field_13 = r1
    //     0x13e4334: stur            w1, [x0, #0x13]
    // 0x13e4338: r16 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0x13e4338: ldr             x16, [PP, #0x6850]  ; [pp+0x6850] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0x13e433c: ArrayStore: r0[0] = r16  ; List_4
    //     0x13e433c: stur            w16, [x0, #0x17]
    // 0x13e4340: str             x0, [SP]
    // 0x13e4344: r0 = _interpolate()
    //     0x13e4344: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x13e4348: mov             x1, x0
    // 0x13e434c: r0 = print()
    //     0x13e434c: bl              #0x82a3d4  ; [dart:core] ::print
    // 0x13e4350: r0 = Null
    //     0x13e4350: mov             x0, NULL
    // 0x13e4354: LeaveFrame
    //     0x13e4354: mov             SP, fp
    //     0x13e4358: ldp             fp, lr, [SP], #0x10
    // 0x13e435c: ret
    //     0x13e435c: ret             
    // 0x13e4360: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13e4360: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13e4364: b               #0x13e3f4c
  }
  [closure] static void register(dynamic) {
    // ** addr: 0x13e5338, size: 0x2c
    // 0x13e5338: EnterFrame
    //     0x13e5338: stp             fp, lr, [SP, #-0x10]!
    //     0x13e533c: mov             fp, SP
    // 0x13e5340: CheckStackOverflow
    //     0x13e5340: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13e5344: cmp             SP, x16
    //     0x13e5348: b.ls            #0x13e535c
    // 0x13e534c: r0 = register()
    //     0x13e534c: bl              #0x13e3f34  ; [file:///D:/Flutter%20Project/simaster-mahasiswa/.dart_tool/flutter_build/dart_plugin_registrant.dart] _PluginRegistrant::register
    // 0x13e5350: LeaveFrame
    //     0x13e5350: mov             SP, fp
    //     0x13e5354: ldp             fp, lr, [SP], #0x10
    // 0x13e5358: ret
    //     0x13e5358: ret             
    // 0x13e535c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13e535c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13e5360: b               #0x13e534c
  }
}
