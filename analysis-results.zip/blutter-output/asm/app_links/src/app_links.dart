// lib: , url: package:app_links/src/app_links.dart

// class id: 1048599, size: 0x8
class :: {
}

// class id: 3713, size: 0xc, field offset: 0x8
class AppLinks extends Object {

  static late final AppLinks _instance; // offset: 0xf24

  get _ uriLinkStream(/* No info */) {
    // ** addr: 0xf7d1b0, size: 0xfc
    // 0xf7d1b0: EnterFrame
    //     0xf7d1b0: stp             fp, lr, [SP, #-0x10]!
    //     0xf7d1b4: mov             fp, SP
    // 0xf7d1b8: AllocStack(0x30)
    //     0xf7d1b8: sub             SP, SP, #0x30
    // 0xf7d1bc: SetupParameters(AppLinks this /* r1 => r1, fp-0x8 */)
    //     0xf7d1bc: stur            x1, [fp, #-8]
    // 0xf7d1c0: CheckStackOverflow
    //     0xf7d1c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf7d1c4: cmp             SP, x16
    //     0xf7d1c8: b.ls            #0xf7d2a4
    // 0xf7d1cc: r1 = 1
    //     0xf7d1cc: mov             x1, #1
    // 0xf7d1d0: r0 = AllocateContext()
    //     0xf7d1d0: bl              #0x13de838  ; AllocateContextStub
    // 0xf7d1d4: mov             x1, x0
    // 0xf7d1d8: ldur            x0, [fp, #-8]
    // 0xf7d1dc: stur            x1, [fp, #-0x10]
    // 0xf7d1e0: StoreField: r1->field_f = r0
    //     0xf7d1e0: stur            w0, [x1, #0xf]
    // 0xf7d1e4: LoadField: r2 = r0->field_7
    //     0xf7d1e4: ldur            w2, [x0, #7]
    // 0xf7d1e8: DecompressPointer r2
    //     0xf7d1e8: add             x2, x2, HEAP, lsl #32
    // 0xf7d1ec: cmp             w2, NULL
    // 0xf7d1f0: b.ne            #0xf7d27c
    // 0xf7d1f4: r0 = LoadStaticField(0xf08)
    //     0xf7d1f4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf7d1f8: ldr             x0, [x0, #0x1e10]
    // 0xf7d1fc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf7d200: cmp             w0, w16
    // 0xf7d204: b.ne            #0xf7d214
    // 0xf7d208: r2 = _instance
    //     0xf7d208: add             x2, PP, #0x83, lsl #12  ; [pp+0x83690] Field <AppLinksPlatform._instance@1165069159>: static late (offset: 0xf08)
    //     0xf7d20c: ldr             x2, [x2, #0x690]
    // 0xf7d210: r0 = InitLateStaticField()
    //     0xf7d210: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0xf7d214: mov             x1, x0
    // 0xf7d218: r0 = uriLinkStream()
    //     0xf7d218: bl              #0xf7d64c  ; [package:app_links_platform_interface/app_links_method_channel.dart] AppLinksMethodChannel::uriLinkStream
    // 0xf7d21c: ldur            x2, [fp, #-0x10]
    // 0xf7d220: r1 = Function '<anonymous closure>':.
    //     0xf7d220: add             x1, PP, #0x83, lsl #12  ; [pp+0x83698] AnonymousClosure: (0xf7d894), in [package:app_links/src/app_links.dart] AppLinks::uriLinkStream (0xf7d1b0)
    //     0xf7d224: ldr             x1, [x1, #0x698]
    // 0xf7d228: stur            x0, [fp, #-0x10]
    // 0xf7d22c: r0 = AllocateClosure()
    //     0xf7d22c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf7d230: r16 = <Uri>
    //     0xf7d230: add             x16, PP, #0x83, lsl #12  ; [pp+0x836a0] TypeArguments: <Uri>
    //     0xf7d234: ldr             x16, [x16, #0x6a0]
    // 0xf7d238: ldur            lr, [fp, #-8]
    // 0xf7d23c: stp             lr, x16, [SP, #0x10]
    // 0xf7d240: ldur            x16, [fp, #-0x10]
    // 0xf7d244: stp             x0, x16, [SP]
    // 0xf7d248: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xf7d248: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xf7d24c: r0 = _createController()
    //     0xf7d24c: bl              #0xf7d2ac  ; [package:app_links/src/app_links.dart] AppLinks::_createController
    // 0xf7d250: mov             x2, x0
    // 0xf7d254: ldur            x1, [fp, #-8]
    // 0xf7d258: StoreField: r1->field_7 = r0
    //     0xf7d258: stur            w0, [x1, #7]
    //     0xf7d25c: ldurb           w16, [x1, #-1]
    //     0xf7d260: ldurb           w17, [x0, #-1]
    //     0xf7d264: and             x16, x17, x16, lsr #2
    //     0xf7d268: tst             x16, HEAP, lsr #32
    //     0xf7d26c: b.eq            #0xf7d274
    //     0xf7d270: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf7d274: mov             x0, x2
    // 0xf7d278: b               #0xf7d280
    // 0xf7d27c: mov             x0, x2
    // 0xf7d280: stur            x0, [fp, #-8]
    // 0xf7d284: LoadField: r1 = r0->field_7
    //     0xf7d284: ldur            w1, [x0, #7]
    // 0xf7d288: DecompressPointer r1
    //     0xf7d288: add             x1, x1, HEAP, lsl #32
    // 0xf7d28c: r0 = _BroadcastStream()
    //     0xf7d28c: bl              #0xea2bf4  ; Allocate_BroadcastStreamStub -> _BroadcastStream<X0> (size=0x10)
    // 0xf7d290: ldur            x1, [fp, #-8]
    // 0xf7d294: StoreField: r0->field_b = r1
    //     0xf7d294: stur            w1, [x0, #0xb]
    // 0xf7d298: LeaveFrame
    //     0xf7d298: mov             SP, fp
    //     0xf7d29c: ldp             fp, lr, [SP], #0x10
    // 0xf7d2a0: ret
    //     0xf7d2a0: ret             
    // 0xf7d2a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf7d2a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf7d2a8: b               #0xf7d1cc
  }
  StreamController<Y0> _createController<Y0>(AppLinks, Stream<Y0>, (dynamic) => void) {
    // ** addr: 0xf7d2ac, size: 0x118
    // 0xf7d2ac: EnterFrame
    //     0xf7d2ac: stp             fp, lr, [SP, #-0x10]!
    //     0xf7d2b0: mov             fp, SP
    // 0xf7d2b4: AllocStack(0x28)
    //     0xf7d2b4: sub             SP, SP, #0x28
    // 0xf7d2b8: SetupParameters([dynamic _ /* r0 */, dynamic _ /* r1 */])
    //     0xf7d2b8: ldur            w0, [x4, #0xf]
    //     0xf7d2bc: cbnz            w0, #0xf7d2c8
    //     0xf7d2c0: mov             x2, NULL
    //     0xf7d2c4: b               #0xf7d2d8
    //     0xf7d2c8: ldur            w0, [x4, #0x17]
    //     0xf7d2cc: add             x1, fp, w0, sxtw #2
    //     0xf7d2d0: ldr             x1, [x1, #0x10]
    //     0xf7d2d4: mov             x2, x1
    //     0xf7d2d8: ldr             x1, [fp, #0x18]
    //     0xf7d2dc: ldr             x0, [fp, #0x10]
    //     0xf7d2e0: stur            x2, [fp, #-8]
    // 0xf7d2e4: CheckStackOverflow
    //     0xf7d2e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf7d2e8: cmp             SP, x16
    //     0xf7d2ec: b.ls            #0xf7d3bc
    // 0xf7d2f0: r1 = 4
    //     0xf7d2f0: mov             x1, #4
    // 0xf7d2f4: r0 = AllocateContext()
    //     0xf7d2f4: bl              #0x13de838  ; AllocateContextStub
    // 0xf7d2f8: mov             x3, x0
    // 0xf7d2fc: ldr             x0, [fp, #0x18]
    // 0xf7d300: stur            x3, [fp, #-0x10]
    // 0xf7d304: StoreField: r3->field_f = r0
    //     0xf7d304: stur            w0, [x3, #0xf]
    // 0xf7d308: ldr             x0, [fp, #0x10]
    // 0xf7d30c: StoreField: r3->field_13 = r0
    //     0xf7d30c: stur            w0, [x3, #0x13]
    // 0xf7d310: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xf7d314: StoreField: r3->field_1b = r0
    //     0xf7d314: stur            w0, [x3, #0x1b]
    // 0xf7d318: mov             x2, x3
    // 0xf7d31c: r1 = Function '<anonymous closure>':.
    //     0xf7d31c: add             x1, PP, #0x83, lsl #12  ; [pp+0x836a8] AnonymousClosure: (0xf7d450), in [package:app_links/src/app_links.dart] AppLinks::_createController (0xf7d2ac)
    //     0xf7d320: ldr             x1, [x1, #0x6a8]
    // 0xf7d324: r0 = AllocateClosure()
    //     0xf7d324: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf7d328: mov             x3, x0
    // 0xf7d32c: ldur            x0, [fp, #-8]
    // 0xf7d330: stur            x3, [fp, #-0x18]
    // 0xf7d334: StoreField: r3->field_b = r0
    //     0xf7d334: stur            w0, [x3, #0xb]
    // 0xf7d338: ldur            x2, [fp, #-0x10]
    // 0xf7d33c: r1 = Function '<anonymous closure>':.
    //     0xf7d33c: add             x1, PP, #0x83, lsl #12  ; [pp+0x836b0] AnonymousClosure: (0xf7d3c4), in [package:app_links/src/app_links.dart] AppLinks::_createController (0xf7d2ac)
    //     0xf7d340: ldr             x1, [x1, #0x6b0]
    // 0xf7d344: r0 = AllocateClosure()
    //     0xf7d344: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf7d348: ldur            x1, [fp, #-8]
    // 0xf7d34c: StoreField: r0->field_b = r1
    //     0xf7d34c: stur            w1, [x0, #0xb]
    // 0xf7d350: ldur            x16, [fp, #-0x18]
    // 0xf7d354: stp             x0, x16, [SP]
    // 0xf7d358: r4 = const [0, 0x3, 0x2, 0x1, onCancel, 0x2, onListen, 0x1, null]
    //     0xf7d358: ldr             x4, [PP, #0x840]  ; [pp+0x840] List(9) [0, 0x3, 0x2, 0x1, "onCancel", 0x2, "onListen", 0x1, Null]
    // 0xf7d35c: r0 = StreamController.broadcast()
    //     0xf7d35c: bl              #0x8c36b8  ; [dart:async] StreamController::StreamController.broadcast
    // 0xf7d360: mov             x2, x0
    // 0xf7d364: ldur            x1, [fp, #-0x10]
    // 0xf7d368: LoadField: r0 = r1->field_1b
    //     0xf7d368: ldur            w0, [x1, #0x1b]
    // 0xf7d36c: DecompressPointer r0
    //     0xf7d36c: add             x0, x0, HEAP, lsl #32
    // 0xf7d370: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf7d374: cmp             w0, w16
    // 0xf7d378: b.ne            #0xf7d3ac
    // 0xf7d37c: mov             x0, x2
    // 0xf7d380: StoreField: r1->field_1b = r0
    //     0xf7d380: stur            w0, [x1, #0x1b]
    //     0xf7d384: ldurb           w16, [x1, #-1]
    //     0xf7d388: ldurb           w17, [x0, #-1]
    //     0xf7d38c: and             x16, x17, x16, lsr #2
    //     0xf7d390: tst             x16, HEAP, lsr #32
    //     0xf7d394: b.eq            #0xf7d39c
    //     0xf7d398: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf7d39c: mov             x0, x2
    // 0xf7d3a0: LeaveFrame
    //     0xf7d3a0: mov             SP, fp
    //     0xf7d3a4: ldp             fp, lr, [SP], #0x10
    // 0xf7d3a8: ret
    //     0xf7d3a8: ret             
    // 0xf7d3ac: r16 = "controller"
    //     0xf7d3ac: ldr             x16, [PP, #0x15b0]  ; [pp+0x15b0] "controller"
    // 0xf7d3b0: str             x16, [SP]
    // 0xf7d3b4: r0 = _throwLocalAlreadyInitialized()
    //     0xf7d3b4: bl              #0x82b684  ; [dart:_internal] LateError::_throwLocalAlreadyInitialized
    // 0xf7d3b8: brk             #0
    // 0xf7d3bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf7d3bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf7d3c0: b               #0xf7d2f0
  }
  [closure] Future<void> <anonymous closure>(dynamic) async {
    // ** addr: 0xf7d3c4, size: 0x8c
    // 0xf7d3c4: EnterFrame
    //     0xf7d3c4: stp             fp, lr, [SP, #-0x10]!
    //     0xf7d3c8: mov             fp, SP
    // 0xf7d3cc: AllocStack(0x18)
    //     0xf7d3cc: sub             SP, SP, #0x18
    // 0xf7d3d0: SetupParameters(AppLinks this /* r1 */)
    //     0xf7d3d0: stur            NULL, [fp, #-8]
    //     0xf7d3d4: mov             x0, #0
    //     0xf7d3d8: add             x1, fp, w0, sxtw #2
    //     0xf7d3dc: ldr             x1, [x1, #0x10]
    //     0xf7d3e0: ldur            w2, [x1, #0x17]
    //     0xf7d3e4: add             x2, x2, HEAP, lsl #32
    //     0xf7d3e8: stur            x2, [fp, #-0x10]
    // 0xf7d3ec: CheckStackOverflow
    //     0xf7d3ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf7d3f0: cmp             SP, x16
    //     0xf7d3f4: b.ls            #0xf7d448
    // 0xf7d3f8: InitAsync() -> Future<void?>
    //     0xf7d3f8: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0xf7d3fc: bl              #0x7f5e44  ; InitAsyncStub
    // 0xf7d400: ldur            x0, [fp, #-0x10]
    // 0xf7d404: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf7d404: ldur            w1, [x0, #0x17]
    // 0xf7d408: DecompressPointer r1
    //     0xf7d408: add             x1, x1, HEAP, lsl #32
    // 0xf7d40c: cmp             w1, NULL
    // 0xf7d410: b.ne            #0xf7d420
    // 0xf7d414: mov             x1, x0
    // 0xf7d418: r2 = Null
    //     0xf7d418: mov             x2, NULL
    // 0xf7d41c: b               #0xf7d42c
    // 0xf7d420: r0 = cancel()
    //     0xf7d420: bl              #0x124a844  ; [dart:async] _BufferingStreamSubscription::cancel
    // 0xf7d424: mov             x2, x0
    // 0xf7d428: ldur            x1, [fp, #-0x10]
    // 0xf7d42c: mov             x0, x2
    // 0xf7d430: stur            x2, [fp, #-0x18]
    // 0xf7d434: r0 = Await()
    //     0xf7d434: bl              #0x7f5c00  ; AwaitStub
    // 0xf7d438: ldur            x1, [fp, #-0x10]
    // 0xf7d43c: ArrayStore: r1[0] = rNULL  ; List_4
    //     0xf7d43c: stur            NULL, [x1, #0x17]
    // 0xf7d440: r0 = Null
    //     0xf7d440: mov             x0, NULL
    // 0xf7d444: r0 = ReturnAsyncNotFuture()
    //     0xf7d444: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xf7d448: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf7d448: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf7d44c: b               #0xf7d3f8
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xf7d450, size: 0x170
    // 0xf7d450: EnterFrame
    //     0xf7d450: stp             fp, lr, [SP, #-0x10]!
    //     0xf7d454: mov             fp, SP
    // 0xf7d458: AllocStack(0x38)
    //     0xf7d458: sub             SP, SP, #0x38
    // 0xf7d45c: SetupParameters([dynamic _ /* r0 */])
    //     0xf7d45c: ldr             x0, [fp, #0x10]
    //     0xf7d460: ldur            w2, [x0, #0x17]
    //     0xf7d464: add             x2, x2, HEAP, lsl #32
    //     0xf7d468: stur            x2, [fp, #-0x18]
    // 0xf7d46c: CheckStackOverflow
    //     0xf7d46c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf7d470: cmp             SP, x16
    //     0xf7d474: b.ls            #0xf7d5b8
    // 0xf7d478: LoadField: r1 = r0->field_b
    //     0xf7d478: ldur            w1, [x0, #0xb]
    // 0xf7d47c: DecompressPointer r1
    //     0xf7d47c: add             x1, x1, HEAP, lsl #32
    // 0xf7d480: stur            x1, [fp, #-0x10]
    // 0xf7d484: LoadField: r3 = r2->field_f
    //     0xf7d484: ldur            w3, [x2, #0xf]
    // 0xf7d488: DecompressPointer r3
    //     0xf7d488: add             x3, x3, HEAP, lsl #32
    // 0xf7d48c: stur            x3, [fp, #-8]
    // 0xf7d490: LoadField: r0 = r2->field_1b
    //     0xf7d490: ldur            w0, [x2, #0x1b]
    // 0xf7d494: DecompressPointer r0
    //     0xf7d494: add             x0, x0, HEAP, lsl #32
    // 0xf7d498: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf7d49c: cmp             w0, w16
    // 0xf7d4a0: b.eq            #0xf7d598
    // 0xf7d4a4: r4 = LoadClassIdInstr(r0)
    //     0xf7d4a4: ldur            x4, [x0, #-1]
    //     0xf7d4a8: ubfx            x4, x4, #0xc, #0x14
    // 0xf7d4ac: str             x0, [SP]
    // 0xf7d4b0: mov             x0, x4
    // 0xf7d4b4: r0 = GDT[cid_x0 + 0x1845b]()
    //     0xf7d4b4: mov             x17, #0x845b
    //     0xf7d4b8: movk            x17, #1, lsl #16
    //     0xf7d4bc: add             lr, x0, x17
    //     0xf7d4c0: ldr             lr, [x21, lr, lsl #3]
    //     0xf7d4c4: blr             lr
    // 0xf7d4c8: ldur            x1, [fp, #-0x10]
    // 0xf7d4cc: mov             x3, x0
    // 0xf7d4d0: r2 = Null
    //     0xf7d4d0: mov             x2, NULL
    // 0xf7d4d4: stur            x3, [fp, #-0x20]
    // 0xf7d4d8: r8 = (dynamic this, Y0) => void?
    //     0xf7d4d8: add             x8, PP, #0x83, lsl #12  ; [pp+0x836b8] FunctionType: (dynamic this, Y0) => void?
    //     0xf7d4dc: ldr             x8, [x8, #0x6b8]
    // 0xf7d4e0: LoadField: r9 = r8->field_7
    //     0xf7d4e0: ldur            x9, [x8, #7]
    // 0xf7d4e4: r3 = Null
    //     0xf7d4e4: add             x3, PP, #0x83, lsl #12  ; [pp+0x836c0] Null
    //     0xf7d4e8: ldr             x3, [x3, #0x6c0]
    // 0xf7d4ec: blr             x9
    // 0xf7d4f0: ldur            x2, [fp, #-0x18]
    // 0xf7d4f4: LoadField: r0 = r2->field_1b
    //     0xf7d4f4: ldur            w0, [x2, #0x1b]
    // 0xf7d4f8: DecompressPointer r0
    //     0xf7d4f8: add             x0, x0, HEAP, lsl #32
    // 0xf7d4fc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf7d500: cmp             w0, w16
    // 0xf7d504: b.eq            #0xf7d5a8
    // 0xf7d508: ldur            x1, [fp, #-0x10]
    // 0xf7d50c: r3 = LoadClassIdInstr(r0)
    //     0xf7d50c: ldur            x3, [x0, #-1]
    //     0xf7d510: ubfx            x3, x3, #0xc, #0x14
    // 0xf7d514: str             x0, [SP]
    // 0xf7d518: mov             x0, x3
    // 0xf7d51c: r0 = GDT[cid_x0 + 0x1764c]()
    //     0xf7d51c: mov             x17, #0x764c
    //     0xf7d520: movk            x17, #1, lsl #16
    //     0xf7d524: add             lr, x0, x17
    //     0xf7d528: ldr             lr, [x21, lr, lsl #3]
    //     0xf7d52c: blr             lr
    // 0xf7d530: ldur            x2, [fp, #-0x18]
    // 0xf7d534: r1 = Function '<anonymous closure>':.
    //     0xf7d534: add             x1, PP, #0x83, lsl #12  ; [pp+0x836d0] AnonymousClosure: (0xf7d5c0), in [package:app_links/src/app_links.dart] AppLinks::_createController (0xf7d2ac)
    //     0xf7d538: ldr             x1, [x1, #0x6d0]
    // 0xf7d53c: stur            x0, [fp, #-0x28]
    // 0xf7d540: r0 = AllocateClosure()
    //     0xf7d540: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf7d544: mov             x1, x0
    // 0xf7d548: ldur            x0, [fp, #-0x10]
    // 0xf7d54c: StoreField: r1->field_b = r0
    //     0xf7d54c: stur            w0, [x1, #0xb]
    // 0xf7d550: ldur            x16, [fp, #-0x28]
    // 0xf7d554: stp             x1, x16, [SP]
    // 0xf7d558: ldur            x1, [fp, #-8]
    // 0xf7d55c: ldur            x2, [fp, #-0x20]
    // 0xf7d560: r4 = const [0, 0x4, 0x2, 0x2, onDone, 0x3, onError, 0x2, null]
    //     0xf7d560: ldr             x4, [PP, #0x220]  ; [pp+0x220] List(9) [0, 0x4, 0x2, 0x2, "onDone", 0x3, "onError", 0x2, Null]
    // 0xf7d564: r0 = listen()
    //     0xf7d564: bl              #0x123aff0  ; [dart:async] _BoundSinkStream::listen
    // 0xf7d568: ldur            x1, [fp, #-0x18]
    // 0xf7d56c: ArrayStore: r1[0] = r0  ; List_4
    //     0xf7d56c: stur            w0, [x1, #0x17]
    //     0xf7d570: ldurb           w16, [x1, #-1]
    //     0xf7d574: ldurb           w17, [x0, #-1]
    //     0xf7d578: and             x16, x17, x16, lsr #2
    //     0xf7d57c: tst             x16, HEAP, lsr #32
    //     0xf7d580: b.eq            #0xf7d588
    //     0xf7d584: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf7d588: r0 = Null
    //     0xf7d588: mov             x0, NULL
    // 0xf7d58c: LeaveFrame
    //     0xf7d58c: mov             SP, fp
    //     0xf7d590: ldp             fp, lr, [SP], #0x10
    // 0xf7d594: ret
    //     0xf7d594: ret             
    // 0xf7d598: r16 = "controller"
    //     0xf7d598: ldr             x16, [PP, #0x15b0]  ; [pp+0x15b0] "controller"
    // 0xf7d59c: str             x16, [SP]
    // 0xf7d5a0: r0 = _throwLocalNotInitialized()
    //     0xf7d5a0: bl              #0x82b57c  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0xf7d5a4: brk             #0
    // 0xf7d5a8: r16 = "controller"
    //     0xf7d5a8: ldr             x16, [PP, #0x15b0]  ; [pp+0x15b0] "controller"
    // 0xf7d5ac: str             x16, [SP]
    // 0xf7d5b0: r0 = _throwLocalNotInitialized()
    //     0xf7d5b0: bl              #0x82b57c  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0xf7d5b4: brk             #0
    // 0xf7d5b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf7d5b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf7d5bc: b               #0xf7d478
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xf7d5c0, size: 0x8c
    // 0xf7d5c0: EnterFrame
    //     0xf7d5c0: stp             fp, lr, [SP, #-0x10]!
    //     0xf7d5c4: mov             fp, SP
    // 0xf7d5c8: AllocStack(0x10)
    //     0xf7d5c8: sub             SP, SP, #0x10
    // 0xf7d5cc: SetupParameters([dynamic _ /* r0 */])
    //     0xf7d5cc: ldr             x0, [fp, #0x10]
    //     0xf7d5d0: ldur            w2, [x0, #0x17]
    //     0xf7d5d4: add             x2, x2, HEAP, lsl #32
    //     0xf7d5d8: stur            x2, [fp, #-8]
    // 0xf7d5dc: CheckStackOverflow
    //     0xf7d5dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf7d5e0: cmp             SP, x16
    //     0xf7d5e4: b.ls            #0xf7d644
    // 0xf7d5e8: ArrayStore: r2[0] = rNULL  ; List_4
    //     0xf7d5e8: stur            NULL, [x2, #0x17]
    // 0xf7d5ec: LoadField: r1 = r2->field_1b
    //     0xf7d5ec: ldur            w1, [x2, #0x1b]
    // 0xf7d5f0: DecompressPointer r1
    //     0xf7d5f0: add             x1, x1, HEAP, lsl #32
    // 0xf7d5f4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf7d5f8: cmp             w1, w16
    // 0xf7d5fc: b.eq            #0xf7d634
    // 0xf7d600: r0 = close()
    //     0xf7d600: bl              #0x80f99c  ; [dart:async] _BroadcastStreamController::close
    // 0xf7d604: ldur            x0, [fp, #-8]
    // 0xf7d608: LoadField: r1 = r0->field_13
    //     0xf7d608: ldur            w1, [x0, #0x13]
    // 0xf7d60c: DecompressPointer r1
    //     0xf7d60c: add             x1, x1, HEAP, lsl #32
    // 0xf7d610: str             x1, [SP]
    // 0xf7d614: mov             x0, x1
    // 0xf7d618: ClosureCall
    //     0xf7d618: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xf7d61c: ldur            x2, [x0, #0x1f]
    //     0xf7d620: blr             x2
    // 0xf7d624: r0 = Null
    //     0xf7d624: mov             x0, NULL
    // 0xf7d628: LeaveFrame
    //     0xf7d628: mov             SP, fp
    //     0xf7d62c: ldp             fp, lr, [SP], #0x10
    // 0xf7d630: ret
    //     0xf7d630: ret             
    // 0xf7d634: r16 = "controller"
    //     0xf7d634: ldr             x16, [PP, #0x15b0]  ; [pp+0x15b0] "controller"
    // 0xf7d638: str             x16, [SP]
    // 0xf7d63c: r0 = _throwLocalNotInitialized()
    //     0xf7d63c: bl              #0x82b57c  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0xf7d640: brk             #0
    // 0xf7d644: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf7d644: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf7d648: b               #0xf7d5e8
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xf7d894, size: 0x20
    // 0xf7d894: ldr             x1, [SP]
    // 0xf7d898: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xf7d898: ldur            w2, [x1, #0x17]
    // 0xf7d89c: DecompressPointer r2
    //     0xf7d89c: add             x2, x2, HEAP, lsl #32
    // 0xf7d8a0: LoadField: r1 = r2->field_f
    //     0xf7d8a0: ldur            w1, [x2, #0xf]
    // 0xf7d8a4: DecompressPointer r1
    //     0xf7d8a4: add             x1, x1, HEAP, lsl #32
    // 0xf7d8a8: StoreField: r1->field_7 = rNULL
    //     0xf7d8a8: stur            NULL, [x1, #7]
    // 0xf7d8ac: r0 = Null
    //     0xf7d8ac: mov             x0, NULL
    // 0xf7d8b0: ret
    //     0xf7d8b0: ret             
  }
  static AppLinks _instance() {
    // ** addr: 0xfa6f08, size: 0x18
    // 0xfa6f08: EnterFrame
    //     0xfa6f08: stp             fp, lr, [SP, #-0x10]!
    //     0xfa6f0c: mov             fp, SP
    // 0xfa6f10: r0 = AppLinks()
    //     0xfa6f10: bl              #0xfa6f20  ; AllocateAppLinksStub -> AppLinks (size=0xc)
    // 0xfa6f14: LeaveFrame
    //     0xfa6f14: mov             SP, fp
    //     0xfa6f18: ldp             fp, lr, [SP], #0x10
    // 0xfa6f1c: ret
    //     0xfa6f1c: ret             
  }
}
