// lib: , url: package:characters/src/extensions.dart

// class id: 1048623, size: 0x8
class :: {

  static _ StringCharacters.characters(/* No info */) {
    // ** addr: 0x8613d0, size: 0x34
    // 0x8613d0: EnterFrame
    //     0x8613d0: stp             fp, lr, [SP, #-0x10]!
    //     0x8613d4: mov             fp, SP
    // 0x8613d8: mov             x2, x1
    // 0x8613dc: CheckStackOverflow
    //     0x8613dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8613e0: cmp             SP, x16
    //     0x8613e4: b.ls            #0x8613fc
    // 0x8613e8: r1 = Null
    //     0x8613e8: mov             x1, NULL
    // 0x8613ec: r0 = Characters()
    //     0x8613ec: bl              #0x861404  ; [package:characters/src/characters.dart] Characters::Characters
    // 0x8613f0: LeaveFrame
    //     0x8613f0: mov             SP, fp
    //     0x8613f4: ldp             fp, lr, [SP], #0x10
    // 0x8613f8: ret
    //     0x8613f8: ret             
    // 0x8613fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8613fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x861400: b               #0x8613e8
  }
}
