// lib: , url: package:characters/src/characters.dart

// class id: 1048621, size: 0x8
class :: {
}

// class id: 3589, size: 0x8, field offset: 0x8
abstract class CharacterRange extends Object
    implements Iterator<X0> {
}

// class id: 3590, size: 0x8, field offset: 0x8
abstract class Characters extends Object
    implements Iterable<X0> {

  factory _ Characters(/* No info */) {
    // ** addr: 0x861404, size: 0x3c
    // 0x861404: EnterFrame
    //     0x861404: stp             fp, lr, [SP, #-0x10]!
    //     0x861408: mov             fp, SP
    // 0x86140c: AllocStack(0x8)
    //     0x86140c: sub             SP, SP, #8
    // 0x861410: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x861410: stur            x2, [fp, #-8]
    // 0x861414: LoadField: r0 = r2->field_7
    //     0x861414: ldur            w0, [x2, #7]
    // 0x861418: cbnz            w0, #0x861424
    // 0x86141c: r0 = Instance_StringCharacters
    //     0x86141c: ldr             x0, [PP, #0x4dd8]  ; [pp+0x4dd8] Obj!StringCharacters@12b8241
    // 0x861420: b               #0x861434
    // 0x861424: r1 = <String>
    //     0x861424: ldr             x1, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    // 0x861428: r0 = StringCharacters()
    //     0x861428: bl              #0x861440  ; AllocateStringCharactersStub -> StringCharacters (size=0x10)
    // 0x86142c: ldur            x1, [fp, #-8]
    // 0x861430: StoreField: r0->field_b = r1
    //     0x861430: stur            w1, [x0, #0xb]
    // 0x861434: LeaveFrame
    //     0x861434: mov             SP, fp
    //     0x861438: ldp             fp, lr, [SP], #0x10
    // 0x86143c: ret
    //     0x86143c: ret             
  }
}
