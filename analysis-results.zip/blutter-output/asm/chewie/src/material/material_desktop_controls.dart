// lib: , url: package:chewie/src/material/material_desktop_controls.dart

// class id: 1048637, size: 0x8
class :: {
}

// class id: 5560, size: 0x5c, field offset: 0x1c
class _MaterialDesktopControlsState extends _MixinApplication739&State&SingleTickerProviderStateMixin {

  late VideoPlayerController controller; // offset: 0x50
  late PlayerNotifier notifier; // offset: 0x1c
  late final FocusNode _focusNode; // offset: 0x58
  late VideoPlayerValue _latestValue; // offset: 0x20

  [closure] Null <anonymous closure>(dynamic) {
    // ** addr: 0xdcfa28, size: 0x54
    // 0xdcfa28: EnterFrame
    //     0xdcfa28: stp             fp, lr, [SP, #-0x10]!
    //     0xdcfa2c: mov             fp, SP
    // 0xdcfa30: ldr             x0, [fp, #0x10]
    // 0xdcfa34: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdcfa34: ldur            w1, [x0, #0x17]
    // 0xdcfa38: DecompressPointer r1
    //     0xdcfa38: add             x1, x1, HEAP, lsl #32
    // 0xdcfa3c: CheckStackOverflow
    //     0xdcfa3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdcfa40: cmp             SP, x16
    //     0xdcfa44: b.ls            #0xdcfa74
    // 0xdcfa48: LoadField: r0 = r1->field_f
    //     0xdcfa48: ldur            w0, [x1, #0xf]
    // 0xdcfa4c: DecompressPointer r0
    //     0xdcfa4c: add             x0, x0, HEAP, lsl #32
    // 0xdcfa50: LoadField: r1 = r0->field_27
    //     0xdcfa50: ldur            w1, [x0, #0x27]
    // 0xdcfa54: DecompressPointer r1
    //     0xdcfa54: add             x1, x1, HEAP, lsl #32
    // 0xdcfa58: cmp             w1, NULL
    // 0xdcfa5c: b.eq            #0xdcfa64
    // 0xdcfa60: r0 = cancel()
    //     0xdcfa60: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0xdcfa64: r0 = Null
    //     0xdcfa64: mov             x0, NULL
    // 0xdcfa68: LeaveFrame
    //     0xdcfa68: mov             SP, fp
    //     0xdcfa6c: ldp             fp, lr, [SP], #0x10
    // 0xdcfa70: ret
    //     0xdcfa70: ret             
    // 0xdcfa74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdcfa74: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdcfa78: b               #0xdcfa48
  }
  _ _buildProgressBar(/* No info */) {
    // ** addr: 0xdcfa7c, size: 0x264
    // 0xdcfa7c: EnterFrame
    //     0xdcfa7c: stp             fp, lr, [SP, #-0x10]!
    //     0xdcfa80: mov             fp, SP
    // 0xdcfa84: AllocStack(0x40)
    //     0xdcfa84: sub             SP, SP, #0x40
    // 0xdcfa88: SetupParameters(_MaterialDesktopControlsState this /* r1 => r1, fp-0x8 */)
    //     0xdcfa88: stur            x1, [fp, #-8]
    // 0xdcfa8c: CheckStackOverflow
    //     0xdcfa8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdcfa90: cmp             SP, x16
    //     0xdcfa94: b.ls            #0xdcfcb4
    // 0xdcfa98: r1 = 1
    //     0xdcfa98: mov             x1, #1
    // 0xdcfa9c: r0 = AllocateContext()
    //     0xdcfa9c: bl              #0x13de838  ; AllocateContextStub
    // 0xdcfaa0: mov             x2, x0
    // 0xdcfaa4: ldur            x0, [fp, #-8]
    // 0xdcfaa8: stur            x2, [fp, #-0x18]
    // 0xdcfaac: StoreField: r2->field_f = r0
    //     0xdcfaac: stur            w0, [x2, #0xf]
    // 0xdcfab0: LoadField: r3 = r0->field_4f
    //     0xdcfab0: ldur            w3, [x0, #0x4f]
    // 0xdcfab4: DecompressPointer r3
    //     0xdcfab4: add             x3, x3, HEAP, lsl #32
    // 0xdcfab8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdcfabc: cmp             w3, w16
    // 0xdcfac0: b.eq            #0xdcfcbc
    // 0xdcfac4: stur            x3, [fp, #-0x10]
    // 0xdcfac8: LoadField: r1 = r0->field_53
    //     0xdcfac8: ldur            w1, [x0, #0x53]
    // 0xdcfacc: DecompressPointer r1
    //     0xdcfacc: add             x1, x1, HEAP, lsl #32
    // 0xdcfad0: cmp             w1, NULL
    // 0xdcfad4: b.eq            #0xdcfcc8
    // 0xdcfad8: LoadField: r1 = r0->field_f
    //     0xdcfad8: ldur            w1, [x0, #0xf]
    // 0xdcfadc: DecompressPointer r1
    //     0xdcfadc: add             x1, x1, HEAP, lsl #32
    // 0xdcfae0: cmp             w1, NULL
    // 0xdcfae4: b.eq            #0xdcfccc
    // 0xdcfae8: r0 = of()
    //     0xdcfae8: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xdcfaec: LoadField: r1 = r0->field_3f
    //     0xdcfaec: ldur            w1, [x0, #0x3f]
    // 0xdcfaf0: DecompressPointer r1
    //     0xdcfaf0: add             x1, x1, HEAP, lsl #32
    // 0xdcfaf4: LoadField: r6 = r1->field_2b
    //     0xdcfaf4: ldur            w6, [x1, #0x2b]
    // 0xdcfaf8: DecompressPointer r6
    //     0xdcfaf8: add             x6, x6, HEAP, lsl #32
    // 0xdcfafc: ldur            x0, [fp, #-8]
    // 0xdcfb00: stur            x6, [fp, #-0x20]
    // 0xdcfb04: LoadField: r1 = r0->field_f
    //     0xdcfb04: ldur            w1, [x0, #0xf]
    // 0xdcfb08: DecompressPointer r1
    //     0xdcfb08: add             x1, x1, HEAP, lsl #32
    // 0xdcfb0c: cmp             w1, NULL
    // 0xdcfb10: b.eq            #0xdcfcd0
    // 0xdcfb14: r0 = of()
    //     0xdcfb14: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xdcfb18: LoadField: r1 = r0->field_3f
    //     0xdcfb18: ldur            w1, [x0, #0x3f]
    // 0xdcfb1c: DecompressPointer r1
    //     0xdcfb1c: add             x1, x1, HEAP, lsl #32
    // 0xdcfb20: LoadField: r5 = r1->field_2b
    //     0xdcfb20: ldur            w5, [x1, #0x2b]
    // 0xdcfb24: DecompressPointer r5
    //     0xdcfb24: add             x5, x5, HEAP, lsl #32
    // 0xdcfb28: ldur            x0, [fp, #-8]
    // 0xdcfb2c: stur            x5, [fp, #-0x28]
    // 0xdcfb30: LoadField: r1 = r0->field_f
    //     0xdcfb30: ldur            w1, [x0, #0xf]
    // 0xdcfb34: DecompressPointer r1
    //     0xdcfb34: add             x1, x1, HEAP, lsl #32
    // 0xdcfb38: cmp             w1, NULL
    // 0xdcfb3c: b.eq            #0xdcfcd4
    // 0xdcfb40: r0 = of()
    //     0xdcfb40: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xdcfb44: LoadField: r1 = r0->field_3f
    //     0xdcfb44: ldur            w1, [x0, #0x3f]
    // 0xdcfb48: DecompressPointer r1
    //     0xdcfb48: add             x1, x1, HEAP, lsl #32
    // 0xdcfb4c: LoadField: r0 = r1->field_7b
    //     0xdcfb4c: ldur            w0, [x1, #0x7b]
    // 0xdcfb50: DecompressPointer r0
    //     0xdcfb50: add             x0, x0, HEAP, lsl #32
    // 0xdcfb54: r1 = LoadClassIdInstr(r0)
    //     0xdcfb54: ldur            x1, [x0, #-1]
    //     0xdcfb58: ubfx            x1, x1, #0xc, #0x14
    // 0xdcfb5c: r16 = 0.500000
    //     0xdcfb5c: ldr             x16, [PP, #0x4c70]  ; [pp+0x4c70] 0.5
    // 0xdcfb60: str             x16, [SP]
    // 0xdcfb64: mov             x16, x0
    // 0xdcfb68: mov             x0, x1
    // 0xdcfb6c: mov             x1, x16
    // 0xdcfb70: r4 = const [0, 0x2, 0x1, 0x1, alpha, 0x1, null]
    //     0xdcfb70: add             x4, PP, #0x28, lsl #12  ; [pp+0x28640] List(7) [0, 0x2, 0x1, 0x1, "alpha", 0x1, Null]
    //     0xdcfb74: ldr             x4, [x4, #0x640]
    // 0xdcfb78: r0 = GDT[cid_x0 + -0xffa]()
    //     0xdcfb78: sub             lr, x0, #0xffa
    //     0xdcfb7c: ldr             lr, [x21, lr, lsl #3]
    //     0xdcfb80: blr             lr
    // 0xdcfb84: mov             x2, x0
    // 0xdcfb88: ldur            x0, [fp, #-8]
    // 0xdcfb8c: stur            x2, [fp, #-0x30]
    // 0xdcfb90: LoadField: r1 = r0->field_f
    //     0xdcfb90: ldur            w1, [x0, #0xf]
    // 0xdcfb94: DecompressPointer r1
    //     0xdcfb94: add             x1, x1, HEAP, lsl #32
    // 0xdcfb98: cmp             w1, NULL
    // 0xdcfb9c: b.eq            #0xdcfcd8
    // 0xdcfba0: r0 = of()
    //     0xdcfba0: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xdcfba4: LoadField: r1 = r0->field_43
    //     0xdcfba4: ldur            w1, [x0, #0x43]
    // 0xdcfba8: DecompressPointer r1
    //     0xdcfba8: add             x1, x1, HEAP, lsl #32
    // 0xdcfbac: r16 = 0.500000
    //     0xdcfbac: ldr             x16, [PP, #0x4c70]  ; [pp+0x4c70] 0.5
    // 0xdcfbb0: str             x16, [SP]
    // 0xdcfbb4: r4 = const [0, 0x2, 0x1, 0x1, alpha, 0x1, null]
    //     0xdcfbb4: add             x4, PP, #0x28, lsl #12  ; [pp+0x28640] List(7) [0, 0x2, 0x1, 0x1, "alpha", 0x1, Null]
    //     0xdcfbb8: ldr             x4, [x4, #0x640]
    // 0xdcfbbc: r0 = withValues()
    //     0xdcfbbc: bl              #0x12d8818  ; [dart:ui] Color::withValues
    // 0xdcfbc0: stur            x0, [fp, #-0x38]
    // 0xdcfbc4: r0 = ChewieProgressColors()
    //     0xdcfbc4: bl              #0xdcfa1c  ; AllocateChewieProgressColorsStub -> ChewieProgressColors (size=0x18)
    // 0xdcfbc8: mov             x1, x0
    // 0xdcfbcc: ldur            x2, [fp, #-0x38]
    // 0xdcfbd0: ldur            x3, [fp, #-0x30]
    // 0xdcfbd4: ldur            x5, [fp, #-0x28]
    // 0xdcfbd8: ldur            x6, [fp, #-0x20]
    // 0xdcfbdc: stur            x0, [fp, #-0x20]
    // 0xdcfbe0: r0 = ChewieProgressColors()
    //     0xdcfbe0: bl              #0xdcf874  ; [package:chewie/src/chewie_progress_colors.dart] ChewieProgressColors::ChewieProgressColors
    // 0xdcfbe4: ldur            x0, [fp, #-8]
    // 0xdcfbe8: LoadField: r1 = r0->field_53
    //     0xdcfbe8: ldur            w1, [x0, #0x53]
    // 0xdcfbec: DecompressPointer r1
    //     0xdcfbec: add             x1, x1, HEAP, lsl #32
    // 0xdcfbf0: cmp             w1, NULL
    // 0xdcfbf4: b.eq            #0xdcfcdc
    // 0xdcfbf8: r0 = MaterialVideoProgressBar()
    //     0xdcfbf8: bl              #0xdcfce0  ; AllocateMaterialVideoProgressBarStub -> MaterialVideoProgressBar (size=0x34)
    // 0xdcfbfc: mov             x3, x0
    // 0xdcfc00: ldur            x0, [fp, #-0x10]
    // 0xdcfc04: stur            x3, [fp, #-8]
    // 0xdcfc08: StoreField: r3->field_1b = r0
    //     0xdcfc08: stur            w0, [x3, #0x1b]
    // 0xdcfc0c: d0 = 10.000000
    //     0xdcfc0c: fmov            d0, #10.00000000
    // 0xdcfc10: StoreField: r3->field_b = d0
    //     0xdcfc10: stur            d0, [x3, #0xb]
    // 0xdcfc14: d0 = 6.000000
    //     0xdcfc14: fmov            d0, #6.00000000
    // 0xdcfc18: StoreField: r3->field_13 = d0
    //     0xdcfc18: stur            d0, [x3, #0x13]
    // 0xdcfc1c: ldur            x2, [fp, #-0x18]
    // 0xdcfc20: r1 = Function '<anonymous closure>':.
    //     0xdcfc20: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3d60] AnonymousClosure: (0xdcfd9c), in [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_buildProgressBar (0xdcfa7c)
    //     0xdcfc24: ldr             x1, [x1, #0xd60]
    // 0xdcfc28: r0 = AllocateClosure()
    //     0xdcfc28: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdcfc2c: mov             x1, x0
    // 0xdcfc30: ldur            x0, [fp, #-8]
    // 0xdcfc34: StoreField: r0->field_27 = r1
    //     0xdcfc34: stur            w1, [x0, #0x27]
    // 0xdcfc38: ldur            x2, [fp, #-0x18]
    // 0xdcfc3c: r1 = Function '<anonymous closure>':.
    //     0xdcfc3c: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3d68] AnonymousClosure: (0xdcfcec), in [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_buildProgressBar (0xdcfa7c)
    //     0xdcfc40: ldr             x1, [x1, #0xd68]
    // 0xdcfc44: r0 = AllocateClosure()
    //     0xdcfc44: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdcfc48: mov             x1, x0
    // 0xdcfc4c: ldur            x0, [fp, #-8]
    // 0xdcfc50: StoreField: r0->field_23 = r1
    //     0xdcfc50: stur            w1, [x0, #0x23]
    // 0xdcfc54: ldur            x2, [fp, #-0x18]
    // 0xdcfc58: r1 = Function '<anonymous closure>':.
    //     0xdcfc58: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3d70] AnonymousClosure: (0xdcfa28), in [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_buildProgressBar (0xdcfa7c)
    //     0xdcfc5c: ldr             x1, [x1, #0xd70]
    // 0xdcfc60: r0 = AllocateClosure()
    //     0xdcfc60: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdcfc64: mov             x1, x0
    // 0xdcfc68: ldur            x0, [fp, #-8]
    // 0xdcfc6c: StoreField: r0->field_2b = r1
    //     0xdcfc6c: stur            w1, [x0, #0x2b]
    // 0xdcfc70: r1 = true
    //     0xdcfc70: add             x1, NULL, #0x20  ; true
    // 0xdcfc74: StoreField: r0->field_2f = r1
    //     0xdcfc74: stur            w1, [x0, #0x2f]
    // 0xdcfc78: ldur            x1, [fp, #-0x20]
    // 0xdcfc7c: StoreField: r0->field_1f = r1
    //     0xdcfc7c: stur            w1, [x0, #0x1f]
    // 0xdcfc80: r1 = <FlexParentData>
    //     0xdcfc80: add             x1, PP, #0x15, lsl #12  ; [pp+0x15878] TypeArguments: <FlexParentData>
    //     0xdcfc84: ldr             x1, [x1, #0x878]
    // 0xdcfc88: r0 = Expanded()
    //     0xdcfc88: bl              #0x8a5b10  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0xdcfc8c: r1 = 1
    //     0xdcfc8c: mov             x1, #1
    // 0xdcfc90: StoreField: r0->field_13 = r1
    //     0xdcfc90: stur            x1, [x0, #0x13]
    // 0xdcfc94: r1 = Instance_FlexFit
    //     0xdcfc94: add             x1, PP, #0x15, lsl #12  ; [pp+0x15880] Obj!FlexFit@12c4641
    //     0xdcfc98: ldr             x1, [x1, #0x880]
    // 0xdcfc9c: StoreField: r0->field_1b = r1
    //     0xdcfc9c: stur            w1, [x0, #0x1b]
    // 0xdcfca0: ldur            x1, [fp, #-8]
    // 0xdcfca4: StoreField: r0->field_b = r1
    //     0xdcfca4: stur            w1, [x0, #0xb]
    // 0xdcfca8: LeaveFrame
    //     0xdcfca8: mov             SP, fp
    //     0xdcfcac: ldp             fp, lr, [SP], #0x10
    // 0xdcfcb0: ret
    //     0xdcfcb0: ret             
    // 0xdcfcb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdcfcb4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdcfcb8: b               #0xdcfa98
    // 0xdcfcbc: r9 = controller
    //     0xdcfcbc: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3cb8] Field <_MaterialDesktopControlsState@452377751.controller>: late (offset: 0x50)
    //     0xdcfcc0: ldr             x9, [x9, #0xcb8]
    // 0xdcfcc4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdcfcc4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdcfcc8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdcfcc8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdcfccc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdcfccc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdcfcd0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdcfcd0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdcfcd4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdcfcd4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdcfcd8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdcfcd8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdcfcdc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdcfcdc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Null <anonymous closure>(dynamic) {
    // ** addr: 0xdcfcec, size: 0x8c
    // 0xdcfcec: EnterFrame
    //     0xdcfcec: stp             fp, lr, [SP, #-0x10]!
    //     0xdcfcf0: mov             fp, SP
    // 0xdcfcf4: AllocStack(0x10)
    //     0xdcfcf4: sub             SP, SP, #0x10
    // 0xdcfcf8: SetupParameters([dynamic _ /* r0 */])
    //     0xdcfcf8: ldr             x0, [fp, #0x10]
    //     0xdcfcfc: ldur            w3, [x0, #0x17]
    //     0xdcfd00: add             x3, x3, HEAP, lsl #32
    //     0xdcfd04: stur            x3, [fp, #-0x10]
    // 0xdcfd08: CheckStackOverflow
    //     0xdcfd08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdcfd0c: cmp             SP, x16
    //     0xdcfd10: b.ls            #0xdcfd70
    // 0xdcfd14: LoadField: r0 = r3->field_f
    //     0xdcfd14: ldur            w0, [x3, #0xf]
    // 0xdcfd18: DecompressPointer r0
    //     0xdcfd18: add             x0, x0, HEAP, lsl #32
    // 0xdcfd1c: mov             x2, x3
    // 0xdcfd20: stur            x0, [fp, #-8]
    // 0xdcfd24: r1 = Function '<anonymous closure>':.
    //     0xdcfd24: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3d78] AnonymousClosure: (0xdcfd78), in [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_buildProgressBar (0xdcfa7c)
    //     0xdcfd28: ldr             x1, [x1, #0xd78]
    // 0xdcfd2c: r0 = AllocateClosure()
    //     0xdcfd2c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdcfd30: ldur            x1, [fp, #-8]
    // 0xdcfd34: mov             x2, x0
    // 0xdcfd38: r0 = setState()
    //     0xdcfd38: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xdcfd3c: ldur            x0, [fp, #-0x10]
    // 0xdcfd40: LoadField: r1 = r0->field_f
    //     0xdcfd40: ldur            w1, [x0, #0xf]
    // 0xdcfd44: DecompressPointer r1
    //     0xdcfd44: add             x1, x1, HEAP, lsl #32
    // 0xdcfd48: LoadField: r0 = r1->field_27
    //     0xdcfd48: ldur            w0, [x1, #0x27]
    // 0xdcfd4c: DecompressPointer r0
    //     0xdcfd4c: add             x0, x0, HEAP, lsl #32
    // 0xdcfd50: cmp             w0, NULL
    // 0xdcfd54: b.eq            #0xdcfd60
    // 0xdcfd58: mov             x1, x0
    // 0xdcfd5c: r0 = cancel()
    //     0xdcfd5c: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0xdcfd60: r0 = Null
    //     0xdcfd60: mov             x0, NULL
    // 0xdcfd64: LeaveFrame
    //     0xdcfd64: mov             SP, fp
    //     0xdcfd68: ldp             fp, lr, [SP], #0x10
    // 0xdcfd6c: ret
    //     0xdcfd6c: ret             
    // 0xdcfd70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdcfd70: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdcfd74: b               #0xdcfd14
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xdcfd78, size: 0x24
    // 0xdcfd78: r1 = true
    //     0xdcfd78: add             x1, NULL, #0x20  ; true
    // 0xdcfd7c: ldr             x2, [SP]
    // 0xdcfd80: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xdcfd80: ldur            w3, [x2, #0x17]
    // 0xdcfd84: DecompressPointer r3
    //     0xdcfd84: add             x3, x3, HEAP, lsl #32
    // 0xdcfd88: LoadField: r2 = r3->field_f
    //     0xdcfd88: ldur            w2, [x3, #0xf]
    // 0xdcfd8c: DecompressPointer r2
    //     0xdcfd8c: add             x2, x2, HEAP, lsl #32
    // 0xdcfd90: StoreField: r2->field_37 = r1
    //     0xdcfd90: stur            w1, [x2, #0x37]
    // 0xdcfd94: r0 = Null
    //     0xdcfd94: mov             x0, NULL
    // 0xdcfd98: ret
    //     0xdcfd98: ret             
  }
  [closure] Null <anonymous closure>(dynamic) {
    // ** addr: 0xdcfd9c, size: 0x78
    // 0xdcfd9c: EnterFrame
    //     0xdcfd9c: stp             fp, lr, [SP, #-0x10]!
    //     0xdcfda0: mov             fp, SP
    // 0xdcfda4: AllocStack(0x10)
    //     0xdcfda4: sub             SP, SP, #0x10
    // 0xdcfda8: SetupParameters([dynamic _ /* r0 */])
    //     0xdcfda8: ldr             x0, [fp, #0x10]
    //     0xdcfdac: ldur            w3, [x0, #0x17]
    //     0xdcfdb0: add             x3, x3, HEAP, lsl #32
    //     0xdcfdb4: stur            x3, [fp, #-0x10]
    // 0xdcfdb8: CheckStackOverflow
    //     0xdcfdb8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdcfdbc: cmp             SP, x16
    //     0xdcfdc0: b.ls            #0xdcfe0c
    // 0xdcfdc4: LoadField: r0 = r3->field_f
    //     0xdcfdc4: ldur            w0, [x3, #0xf]
    // 0xdcfdc8: DecompressPointer r0
    //     0xdcfdc8: add             x0, x0, HEAP, lsl #32
    // 0xdcfdcc: mov             x2, x3
    // 0xdcfdd0: stur            x0, [fp, #-8]
    // 0xdcfdd4: r1 = Function '<anonymous closure>':.
    //     0xdcfdd4: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3d80] AnonymousClosure: (0xdcff84), in [package:youtube_player_iframe/src/widgets/youtube_player.dart] _YoutubePlayerState::_onValueChanged (0xdcffa8)
    //     0xdcfdd8: ldr             x1, [x1, #0xd80]
    // 0xdcfddc: r0 = AllocateClosure()
    //     0xdcfddc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdcfde0: ldur            x1, [fp, #-8]
    // 0xdcfde4: mov             x2, x0
    // 0xdcfde8: r0 = setState()
    //     0xdcfde8: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xdcfdec: ldur            x0, [fp, #-0x10]
    // 0xdcfdf0: LoadField: r1 = r0->field_f
    //     0xdcfdf0: ldur            w1, [x0, #0xf]
    // 0xdcfdf4: DecompressPointer r1
    //     0xdcfdf4: add             x1, x1, HEAP, lsl #32
    // 0xdcfdf8: r0 = _startHideTimer()
    //     0xdcfdf8: bl              #0xdcfe14  ; [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_startHideTimer
    // 0xdcfdfc: r0 = Null
    //     0xdcfdfc: mov             x0, NULL
    // 0xdcfe00: LeaveFrame
    //     0xdcfe00: mov             SP, fp
    //     0xdcfe04: ldp             fp, lr, [SP], #0x10
    // 0xdcfe08: ret
    //     0xdcfe08: ret             
    // 0xdcfe0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdcfe0c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdcfe10: b               #0xdcfdc4
  }
  _ _startHideTimer(/* No info */) {
    // ** addr: 0xdcfe14, size: 0xa0
    // 0xdcfe14: EnterFrame
    //     0xdcfe14: stp             fp, lr, [SP, #-0x10]!
    //     0xdcfe18: mov             fp, SP
    // 0xdcfe1c: AllocStack(0x8)
    //     0xdcfe1c: sub             SP, SP, #8
    // 0xdcfe20: SetupParameters(_MaterialDesktopControlsState this /* r1 => r1, fp-0x8 */)
    //     0xdcfe20: stur            x1, [fp, #-8]
    // 0xdcfe24: CheckStackOverflow
    //     0xdcfe24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdcfe28: cmp             SP, x16
    //     0xdcfe2c: b.ls            #0xdcfea8
    // 0xdcfe30: r1 = 1
    //     0xdcfe30: mov             x1, #1
    // 0xdcfe34: r0 = AllocateContext()
    //     0xdcfe34: bl              #0x13de838  ; AllocateContextStub
    // 0xdcfe38: mov             x1, x0
    // 0xdcfe3c: ldur            x0, [fp, #-8]
    // 0xdcfe40: StoreField: r1->field_f = r0
    //     0xdcfe40: stur            w0, [x1, #0xf]
    // 0xdcfe44: LoadField: r2 = r0->field_53
    //     0xdcfe44: ldur            w2, [x0, #0x53]
    // 0xdcfe48: DecompressPointer r2
    //     0xdcfe48: add             x2, x2, HEAP, lsl #32
    // 0xdcfe4c: cmp             w2, NULL
    // 0xdcfe50: b.eq            #0xdcfeb0
    // 0xdcfe54: mov             x2, x1
    // 0xdcfe58: r1 = Function '<anonymous closure>':.
    //     0xdcfe58: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3cd0] AnonymousClosure: (0xdcfeb4), in [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_startHideTimer (0xdcfe14)
    //     0xdcfe5c: ldr             x1, [x1, #0xcd0]
    // 0xdcfe60: r0 = AllocateClosure()
    //     0xdcfe60: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdcfe64: mov             x3, x0
    // 0xdcfe68: r1 = Null
    //     0xdcfe68: mov             x1, NULL
    // 0xdcfe6c: r2 = Instance_Duration
    //     0xdcfe6c: add             x2, PP, #0x16, lsl #12  ; [pp+0x16670] Obj!Duration@12c8961
    //     0xdcfe70: ldr             x2, [x2, #0x670]
    // 0xdcfe74: r0 = Timer()
    //     0xdcfe74: bl              #0x7eed74  ; [dart:async] Timer::Timer
    // 0xdcfe78: ldur            x1, [fp, #-8]
    // 0xdcfe7c: StoreField: r1->field_27 = r0
    //     0xdcfe7c: stur            w0, [x1, #0x27]
    //     0xdcfe80: ldurb           w16, [x1, #-1]
    //     0xdcfe84: ldurb           w17, [x0, #-1]
    //     0xdcfe88: and             x16, x17, x16, lsr #2
    //     0xdcfe8c: tst             x16, HEAP, lsr #32
    //     0xdcfe90: b.eq            #0xdcfe98
    //     0xdcfe94: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdcfe98: r0 = Null
    //     0xdcfe98: mov             x0, NULL
    // 0xdcfe9c: LeaveFrame
    //     0xdcfe9c: mov             SP, fp
    //     0xdcfea0: ldp             fp, lr, [SP], #0x10
    // 0xdcfea4: ret
    //     0xdcfea4: ret             
    // 0xdcfea8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdcfea8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdcfeac: b               #0xdcfe30
    // 0xdcfeb0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdcfeb0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xdcfeb4, size: 0x60
    // 0xdcfeb4: EnterFrame
    //     0xdcfeb4: stp             fp, lr, [SP, #-0x10]!
    //     0xdcfeb8: mov             fp, SP
    // 0xdcfebc: AllocStack(0x8)
    //     0xdcfebc: sub             SP, SP, #8
    // 0xdcfec0: SetupParameters([dynamic _ /* r0 */])
    //     0xdcfec0: ldr             x0, [fp, #0x10]
    //     0xdcfec4: ldur            w2, [x0, #0x17]
    //     0xdcfec8: add             x2, x2, HEAP, lsl #32
    // 0xdcfecc: CheckStackOverflow
    //     0xdcfecc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdcfed0: cmp             SP, x16
    //     0xdcfed4: b.ls            #0xdcff0c
    // 0xdcfed8: LoadField: r0 = r2->field_f
    //     0xdcfed8: ldur            w0, [x2, #0xf]
    // 0xdcfedc: DecompressPointer r0
    //     0xdcfedc: add             x0, x0, HEAP, lsl #32
    // 0xdcfee0: stur            x0, [fp, #-8]
    // 0xdcfee4: r1 = Function '<anonymous closure>':.
    //     0xdcfee4: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3cd8] AnonymousClosure: (0xdcff14), in [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_startHideTimer (0xdcfe14)
    //     0xdcfee8: ldr             x1, [x1, #0xcd8]
    // 0xdcfeec: r0 = AllocateClosure()
    //     0xdcfeec: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdcfef0: ldur            x1, [fp, #-8]
    // 0xdcfef4: mov             x2, x0
    // 0xdcfef8: r0 = setState()
    //     0xdcfef8: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xdcfefc: r0 = Null
    //     0xdcfefc: mov             x0, NULL
    // 0xdcff00: LeaveFrame
    //     0xdcff00: mov             SP, fp
    //     0xdcff04: ldp             fp, lr, [SP], #0x10
    // 0xdcff08: ret
    //     0xdcff08: ret             
    // 0xdcff0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdcff0c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdcff10: b               #0xdcfed8
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xdcff14, size: 0x70
    // 0xdcff14: EnterFrame
    //     0xdcff14: stp             fp, lr, [SP, #-0x10]!
    //     0xdcff18: mov             fp, SP
    // 0xdcff1c: r0 = true
    //     0xdcff1c: add             x0, NULL, #0x20  ; true
    // 0xdcff20: ldr             x1, [fp, #0x10]
    // 0xdcff24: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xdcff24: ldur            w2, [x1, #0x17]
    // 0xdcff28: DecompressPointer r2
    //     0xdcff28: add             x2, x2, HEAP, lsl #32
    // 0xdcff2c: CheckStackOverflow
    //     0xdcff2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdcff30: cmp             SP, x16
    //     0xdcff34: b.ls            #0xdcff70
    // 0xdcff38: LoadField: r1 = r2->field_f
    //     0xdcff38: ldur            w1, [x2, #0xf]
    // 0xdcff3c: DecompressPointer r1
    //     0xdcff3c: add             x1, x1, HEAP, lsl #32
    // 0xdcff40: LoadField: r2 = r1->field_1b
    //     0xdcff40: ldur            w2, [x1, #0x1b]
    // 0xdcff44: DecompressPointer r2
    //     0xdcff44: add             x2, x2, HEAP, lsl #32
    // 0xdcff48: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdcff4c: cmp             w2, w16
    // 0xdcff50: b.eq            #0xdcff78
    // 0xdcff54: StoreField: r2->field_23 = r0
    //     0xdcff54: stur            w0, [x2, #0x23]
    // 0xdcff58: mov             x1, x2
    // 0xdcff5c: r0 = notifyListeners()
    //     0xdcff5c: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xdcff60: r0 = Null
    //     0xdcff60: mov             x0, NULL
    // 0xdcff64: LeaveFrame
    //     0xdcff64: mov             SP, fp
    //     0xdcff68: ldp             fp, lr, [SP], #0x10
    // 0xdcff6c: ret
    //     0xdcff6c: ret             
    // 0xdcff70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdcff70: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdcff74: b               #0xdcff38
    // 0xdcff78: r9 = notifier
    //     0xdcff78: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3cc8] Field <_MaterialDesktopControlsState@452377751.notifier>: late (offset: 0x1c)
    //     0xdcff7c: ldr             x9, [x9, #0xcc8]
    // 0xdcff80: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdcff80: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ build(/* No info */) {
    // ** addr: 0xdd7520, size: 0x48c
    // 0xdd7520: EnterFrame
    //     0xdd7520: stp             fp, lr, [SP, #-0x10]!
    //     0xdd7524: mov             fp, SP
    // 0xdd7528: AllocStack(0x50)
    //     0xdd7528: sub             SP, SP, #0x50
    // 0xdd752c: SetupParameters(_MaterialDesktopControlsState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xdd752c: stur            x1, [fp, #-8]
    //     0xdd7530: stur            x2, [fp, #-0x10]
    // 0xdd7534: CheckStackOverflow
    //     0xdd7534: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd7538: cmp             SP, x16
    //     0xdd753c: b.ls            #0xdd797c
    // 0xdd7540: r1 = 1
    //     0xdd7540: mov             x1, #1
    // 0xdd7544: r0 = AllocateContext()
    //     0xdd7544: bl              #0x13de838  ; AllocateContextStub
    // 0xdd7548: mov             x3, x0
    // 0xdd754c: ldur            x0, [fp, #-8]
    // 0xdd7550: stur            x3, [fp, #-0x28]
    // 0xdd7554: StoreField: r3->field_f = r0
    //     0xdd7554: stur            w0, [x3, #0xf]
    // 0xdd7558: LoadField: r1 = r0->field_1f
    //     0xdd7558: ldur            w1, [x0, #0x1f]
    // 0xdd755c: DecompressPointer r1
    //     0xdd755c: add             x1, x1, HEAP, lsl #32
    // 0xdd7560: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd7564: cmp             w1, w16
    // 0xdd7568: b.eq            #0xdd7984
    // 0xdd756c: LoadField: r2 = r1->field_37
    //     0xdd756c: ldur            w2, [x1, #0x37]
    // 0xdd7570: DecompressPointer r2
    //     0xdd7570: add             x2, x2, HEAP, lsl #32
    // 0xdd7574: cmp             w2, NULL
    // 0xdd7578: b.eq            #0xdd75a0
    // 0xdd757c: LoadField: r1 = r0->field_53
    //     0xdd757c: ldur            w1, [x0, #0x53]
    // 0xdd7580: DecompressPointer r1
    //     0xdd7580: add             x1, x1, HEAP, lsl #32
    // 0xdd7584: cmp             w1, NULL
    // 0xdd7588: b.eq            #0xdd7990
    // 0xdd758c: r0 = Instance_Center
    //     0xdd758c: add             x0, PP, #0xd3, lsl #12  ; [pp+0xd3cf0] Obj!Center@12b75e1
    //     0xdd7590: ldr             x0, [x0, #0xcf0]
    // 0xdd7594: LeaveFrame
    //     0xdd7594: mov             SP, fp
    //     0xdd7598: ldp             fp, lr, [SP], #0x10
    // 0xdd759c: ret
    //     0xdd759c: ret             
    // 0xdd75a0: LoadField: r4 = r0->field_57
    //     0xdd75a0: ldur            w4, [x0, #0x57]
    // 0xdd75a4: DecompressPointer r4
    //     0xdd75a4: add             x4, x4, HEAP, lsl #32
    // 0xdd75a8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd75ac: cmp             w4, w16
    // 0xdd75b0: b.eq            #0xdd7994
    // 0xdd75b4: stur            x4, [fp, #-0x20]
    // 0xdd75b8: LoadField: r1 = r0->field_1b
    //     0xdd75b8: ldur            w1, [x0, #0x1b]
    // 0xdd75bc: DecompressPointer r1
    //     0xdd75bc: add             x1, x1, HEAP, lsl #32
    // 0xdd75c0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd75c4: cmp             w1, w16
    // 0xdd75c8: b.eq            #0xdd79a0
    // 0xdd75cc: LoadField: r5 = r1->field_23
    //     0xdd75cc: ldur            w5, [x1, #0x23]
    // 0xdd75d0: DecompressPointer r5
    //     0xdd75d0: add             x5, x5, HEAP, lsl #32
    // 0xdd75d4: stur            x5, [fp, #-0x18]
    // 0xdd75d8: r1 = <Widget>
    //     0xdd75d8: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xdd75dc: r2 = 0
    //     0xdd75dc: mov             x2, #0
    // 0xdd75e0: r0 = _GrowableList()
    //     0xdd75e0: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xdd75e4: mov             x2, x0
    // 0xdd75e8: ldur            x0, [fp, #-8]
    // 0xdd75ec: stur            x2, [fp, #-0x38]
    // 0xdd75f0: LoadField: r1 = r0->field_43
    //     0xdd75f0: ldur            w1, [x0, #0x43]
    // 0xdd75f4: DecompressPointer r1
    //     0xdd75f4: add             x1, x1, HEAP, lsl #32
    // 0xdd75f8: tbnz            w1, #4, #0xdd765c
    // 0xdd75fc: LoadField: r1 = r2->field_b
    //     0xdd75fc: ldur            w1, [x2, #0xb]
    // 0xdd7600: LoadField: r3 = r2->field_f
    //     0xdd7600: ldur            w3, [x2, #0xf]
    // 0xdd7604: DecompressPointer r3
    //     0xdd7604: add             x3, x3, HEAP, lsl #32
    // 0xdd7608: LoadField: r4 = r3->field_b
    //     0xdd7608: ldur            w4, [x3, #0xb]
    // 0xdd760c: r3 = LoadInt32Instr(r1)
    //     0xdd760c: sbfx            x3, x1, #1, #0x1f
    // 0xdd7610: stur            x3, [fp, #-0x30]
    // 0xdd7614: r1 = LoadInt32Instr(r4)
    //     0xdd7614: sbfx            x1, x4, #1, #0x1f
    // 0xdd7618: cmp             x3, x1
    // 0xdd761c: b.ne            #0xdd7628
    // 0xdd7620: mov             x1, x2
    // 0xdd7624: r0 = _growToNextCapacity()
    //     0xdd7624: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xdd7628: ldur            x0, [fp, #-0x38]
    // 0xdd762c: ldur            x1, [fp, #-0x30]
    // 0xdd7630: add             x2, x1, #1
    // 0xdd7634: lsl             x3, x2, #1
    // 0xdd7638: StoreField: r0->field_b = r3
    //     0xdd7638: stur            w3, [x0, #0xb]
    // 0xdd763c: LoadField: r2 = r0->field_f
    //     0xdd763c: ldur            w2, [x0, #0xf]
    // 0xdd7640: DecompressPointer r2
    //     0xdd7640: add             x2, x2, HEAP, lsl #32
    // 0xdd7644: add             x3, x2, x1, lsl #2
    // 0xdd7648: r16 = Instance_Center
    //     0xdd7648: add             x16, PP, #0x15, lsl #12  ; [pp+0x157b8] Obj!Center@12b75a1
    //     0xdd764c: ldr             x16, [x16, #0x7b8]
    // 0xdd7650: StoreField: r3->field_f = r16
    //     0xdd7650: stur            w16, [x3, #0xf]
    // 0xdd7654: mov             x3, x0
    // 0xdd7658: b               #0xdd76e8
    // 0xdd765c: mov             x0, x2
    // 0xdd7660: ldur            x1, [fp, #-8]
    // 0xdd7664: r0 = _buildHitArea()
    //     0xdd7664: bl              #0xdd9464  ; [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_buildHitArea
    // 0xdd7668: mov             x2, x0
    // 0xdd766c: ldur            x0, [fp, #-0x38]
    // 0xdd7670: stur            x2, [fp, #-0x40]
    // 0xdd7674: LoadField: r1 = r0->field_b
    //     0xdd7674: ldur            w1, [x0, #0xb]
    // 0xdd7678: LoadField: r3 = r0->field_f
    //     0xdd7678: ldur            w3, [x0, #0xf]
    // 0xdd767c: DecompressPointer r3
    //     0xdd767c: add             x3, x3, HEAP, lsl #32
    // 0xdd7680: LoadField: r4 = r3->field_b
    //     0xdd7680: ldur            w4, [x3, #0xb]
    // 0xdd7684: r3 = LoadInt32Instr(r1)
    //     0xdd7684: sbfx            x3, x1, #1, #0x1f
    // 0xdd7688: stur            x3, [fp, #-0x30]
    // 0xdd768c: r1 = LoadInt32Instr(r4)
    //     0xdd768c: sbfx            x1, x4, #1, #0x1f
    // 0xdd7690: cmp             x3, x1
    // 0xdd7694: b.ne            #0xdd76a0
    // 0xdd7698: mov             x1, x0
    // 0xdd769c: r0 = _growToNextCapacity()
    //     0xdd769c: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xdd76a0: ldur            x3, [fp, #-0x38]
    // 0xdd76a4: ldur            x2, [fp, #-0x30]
    // 0xdd76a8: add             x0, x2, #1
    // 0xdd76ac: lsl             x1, x0, #1
    // 0xdd76b0: StoreField: r3->field_b = r1
    //     0xdd76b0: stur            w1, [x3, #0xb]
    // 0xdd76b4: LoadField: r1 = r3->field_f
    //     0xdd76b4: ldur            w1, [x3, #0xf]
    // 0xdd76b8: DecompressPointer r1
    //     0xdd76b8: add             x1, x1, HEAP, lsl #32
    // 0xdd76bc: ldur            x0, [fp, #-0x40]
    // 0xdd76c0: ArrayStore: r1[r2] = r0  ; List_4
    //     0xdd76c0: add             x25, x1, x2, lsl #2
    //     0xdd76c4: add             x25, x25, #0xf
    //     0xdd76c8: str             w0, [x25]
    //     0xdd76cc: tbz             w0, #0, #0xdd76e8
    //     0xdd76d0: ldurb           w16, [x1, #-1]
    //     0xdd76d4: ldurb           w17, [x0, #-1]
    //     0xdd76d8: and             x16, x17, x16, lsr #2
    //     0xdd76dc: tst             x16, HEAP, lsr #32
    //     0xdd76e0: b.eq            #0xdd76e8
    //     0xdd76e4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdd76e8: r1 = <Widget>
    //     0xdd76e8: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xdd76ec: r2 = 0
    //     0xdd76ec: mov             x2, #0
    // 0xdd76f0: r0 = _GrowableList()
    //     0xdd76f0: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xdd76f4: ldur            x1, [fp, #-8]
    // 0xdd76f8: ldur            x2, [fp, #-0x10]
    // 0xdd76fc: stur            x0, [fp, #-0x10]
    // 0xdd7700: r0 = _buildBottomBar()
    //     0xdd7700: bl              #0xdd79b8  ; [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_buildBottomBar
    // 0xdd7704: mov             x2, x0
    // 0xdd7708: ldur            x0, [fp, #-0x10]
    // 0xdd770c: stur            x2, [fp, #-0x40]
    // 0xdd7710: LoadField: r1 = r0->field_b
    //     0xdd7710: ldur            w1, [x0, #0xb]
    // 0xdd7714: LoadField: r3 = r0->field_f
    //     0xdd7714: ldur            w3, [x0, #0xf]
    // 0xdd7718: DecompressPointer r3
    //     0xdd7718: add             x3, x3, HEAP, lsl #32
    // 0xdd771c: LoadField: r4 = r3->field_b
    //     0xdd771c: ldur            w4, [x3, #0xb]
    // 0xdd7720: r3 = LoadInt32Instr(r1)
    //     0xdd7720: sbfx            x3, x1, #1, #0x1f
    // 0xdd7724: stur            x3, [fp, #-0x30]
    // 0xdd7728: r1 = LoadInt32Instr(r4)
    //     0xdd7728: sbfx            x1, x4, #1, #0x1f
    // 0xdd772c: cmp             x3, x1
    // 0xdd7730: b.ne            #0xdd773c
    // 0xdd7734: mov             x1, x0
    // 0xdd7738: r0 = _growToNextCapacity()
    //     0xdd7738: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xdd773c: ldur            x4, [fp, #-0x38]
    // 0xdd7740: ldur            x2, [fp, #-0x10]
    // 0xdd7744: ldur            x3, [fp, #-0x30]
    // 0xdd7748: add             x0, x3, #1
    // 0xdd774c: lsl             x1, x0, #1
    // 0xdd7750: StoreField: r2->field_b = r1
    //     0xdd7750: stur            w1, [x2, #0xb]
    // 0xdd7754: LoadField: r1 = r2->field_f
    //     0xdd7754: ldur            w1, [x2, #0xf]
    // 0xdd7758: DecompressPointer r1
    //     0xdd7758: add             x1, x1, HEAP, lsl #32
    // 0xdd775c: ldur            x0, [fp, #-0x40]
    // 0xdd7760: ArrayStore: r1[r3] = r0  ; List_4
    //     0xdd7760: add             x25, x1, x3, lsl #2
    //     0xdd7764: add             x25, x25, #0xf
    //     0xdd7768: str             w0, [x25]
    //     0xdd776c: tbz             w0, #0, #0xdd7788
    //     0xdd7770: ldurb           w16, [x1, #-1]
    //     0xdd7774: ldurb           w17, [x0, #-1]
    //     0xdd7778: and             x16, x17, x16, lsr #2
    //     0xdd777c: tst             x16, HEAP, lsr #32
    //     0xdd7780: b.eq            #0xdd7788
    //     0xdd7784: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdd7788: r0 = Column()
    //     0xdd7788: bl              #0x8a5b1c  ; AllocateColumnStub -> Column (size=0x38)
    // 0xdd778c: mov             x2, x0
    // 0xdd7790: r0 = Instance_Axis
    //     0xdd7790: ldr             x0, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xdd7794: stur            x2, [fp, #-0x40]
    // 0xdd7798: StoreField: r2->field_f = r0
    //     0xdd7798: stur            w0, [x2, #0xf]
    // 0xdd779c: r0 = Instance_MainAxisAlignment
    //     0xdd779c: add             x0, PP, #0x18, lsl #12  ; [pp+0x182b8] Obj!MainAxisAlignment@12c45e1
    //     0xdd77a0: ldr             x0, [x0, #0x2b8]
    // 0xdd77a4: StoreField: r2->field_13 = r0
    //     0xdd77a4: stur            w0, [x2, #0x13]
    // 0xdd77a8: r0 = Instance_MainAxisSize
    //     0xdd77a8: add             x0, PP, #0x15, lsl #12  ; [pp+0x15828] Obj!MainAxisSize@12c4621
    //     0xdd77ac: ldr             x0, [x0, #0x828]
    // 0xdd77b0: ArrayStore: r2[0] = r0  ; List_4
    //     0xdd77b0: stur            w0, [x2, #0x17]
    // 0xdd77b4: r0 = Instance_CrossAxisAlignment
    //     0xdd77b4: add             x0, PP, #0x15, lsl #12  ; [pp+0x15888] Obj!CrossAxisAlignment@12c44a1
    //     0xdd77b8: ldr             x0, [x0, #0x888]
    // 0xdd77bc: StoreField: r2->field_1b = r0
    //     0xdd77bc: stur            w0, [x2, #0x1b]
    // 0xdd77c0: r0 = Instance_VerticalDirection
    //     0xdd77c0: add             x0, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xdd77c4: ldr             x0, [x0, #0x838]
    // 0xdd77c8: StoreField: r2->field_23 = r0
    //     0xdd77c8: stur            w0, [x2, #0x23]
    // 0xdd77cc: r0 = Instance_Clip
    //     0xdd77cc: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xdd77d0: ldr             x0, [x0, #0x840]
    // 0xdd77d4: StoreField: r2->field_2b = r0
    //     0xdd77d4: stur            w0, [x2, #0x2b]
    // 0xdd77d8: StoreField: r2->field_2f = rZR
    //     0xdd77d8: stur            xzr, [x2, #0x2f]
    // 0xdd77dc: ldur            x0, [fp, #-0x10]
    // 0xdd77e0: StoreField: r2->field_b = r0
    //     0xdd77e0: stur            w0, [x2, #0xb]
    // 0xdd77e4: ldur            x0, [fp, #-0x38]
    // 0xdd77e8: LoadField: r1 = r0->field_b
    //     0xdd77e8: ldur            w1, [x0, #0xb]
    // 0xdd77ec: LoadField: r3 = r0->field_f
    //     0xdd77ec: ldur            w3, [x0, #0xf]
    // 0xdd77f0: DecompressPointer r3
    //     0xdd77f0: add             x3, x3, HEAP, lsl #32
    // 0xdd77f4: LoadField: r4 = r3->field_b
    //     0xdd77f4: ldur            w4, [x3, #0xb]
    // 0xdd77f8: r3 = LoadInt32Instr(r1)
    //     0xdd77f8: sbfx            x3, x1, #1, #0x1f
    // 0xdd77fc: stur            x3, [fp, #-0x30]
    // 0xdd7800: r1 = LoadInt32Instr(r4)
    //     0xdd7800: sbfx            x1, x4, #1, #0x1f
    // 0xdd7804: cmp             x3, x1
    // 0xdd7808: b.ne            #0xdd7814
    // 0xdd780c: mov             x1, x0
    // 0xdd7810: r0 = _growToNextCapacity()
    //     0xdd7810: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xdd7814: ldur            x2, [fp, #-0x38]
    // 0xdd7818: ldur            x4, [fp, #-0x20]
    // 0xdd781c: ldur            x5, [fp, #-0x18]
    // 0xdd7820: ldur            x3, [fp, #-0x30]
    // 0xdd7824: add             x0, x3, #1
    // 0xdd7828: lsl             x1, x0, #1
    // 0xdd782c: StoreField: r2->field_b = r1
    //     0xdd782c: stur            w1, [x2, #0xb]
    // 0xdd7830: LoadField: r1 = r2->field_f
    //     0xdd7830: ldur            w1, [x2, #0xf]
    // 0xdd7834: DecompressPointer r1
    //     0xdd7834: add             x1, x1, HEAP, lsl #32
    // 0xdd7838: ldur            x0, [fp, #-0x40]
    // 0xdd783c: ArrayStore: r1[r3] = r0  ; List_4
    //     0xdd783c: add             x25, x1, x3, lsl #2
    //     0xdd7840: add             x25, x25, #0xf
    //     0xdd7844: str             w0, [x25]
    //     0xdd7848: tbz             w0, #0, #0xdd7864
    //     0xdd784c: ldurb           w16, [x1, #-1]
    //     0xdd7850: ldurb           w17, [x0, #-1]
    //     0xdd7854: and             x16, x17, x16, lsr #2
    //     0xdd7858: tst             x16, HEAP, lsr #32
    //     0xdd785c: b.eq            #0xdd7864
    //     0xdd7860: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdd7864: r0 = Stack()
    //     0xdd7864: bl              #0xd1a854  ; AllocateStackStub -> Stack (size=0x20)
    // 0xdd7868: mov             x1, x0
    // 0xdd786c: r0 = Instance_AlignmentDirectional
    //     0xdd786c: add             x0, PP, #0x15, lsl #12  ; [pp+0x158d8] Obj!AlignmentDirectional@129e611
    //     0xdd7870: ldr             x0, [x0, #0x8d8]
    // 0xdd7874: stur            x1, [fp, #-0x10]
    // 0xdd7878: StoreField: r1->field_f = r0
    //     0xdd7878: stur            w0, [x1, #0xf]
    // 0xdd787c: r0 = Instance_StackFit
    //     0xdd787c: add             x0, PP, #0x15, lsl #12  ; [pp+0x158e0] Obj!StackFit@12c4221
    //     0xdd7880: ldr             x0, [x0, #0x8e0]
    // 0xdd7884: ArrayStore: r1[0] = r0  ; List_4
    //     0xdd7884: stur            w0, [x1, #0x17]
    // 0xdd7888: r0 = Instance_Clip
    //     0xdd7888: add             x0, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xdd788c: ldr             x0, [x0, #0x850]
    // 0xdd7890: StoreField: r1->field_1b = r0
    //     0xdd7890: stur            w0, [x1, #0x1b]
    // 0xdd7894: ldur            x0, [fp, #-0x38]
    // 0xdd7898: StoreField: r1->field_b = r0
    //     0xdd7898: stur            w0, [x1, #0xb]
    // 0xdd789c: r0 = AbsorbPointer()
    //     0xdd789c: bl              #0xd6cda8  ; AllocateAbsorbPointerStub -> AbsorbPointer (size=0x18)
    // 0xdd78a0: mov             x1, x0
    // 0xdd78a4: ldur            x0, [fp, #-0x18]
    // 0xdd78a8: stur            x1, [fp, #-0x38]
    // 0xdd78ac: StoreField: r1->field_f = r0
    //     0xdd78ac: stur            w0, [x1, #0xf]
    // 0xdd78b0: ldur            x0, [fp, #-0x10]
    // 0xdd78b4: StoreField: r1->field_b = r0
    //     0xdd78b4: stur            w0, [x1, #0xb]
    // 0xdd78b8: r0 = GestureDetector()
    //     0xdd78b8: bl              #0x918e18  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0xdd78bc: ldur            x2, [fp, #-0x28]
    // 0xdd78c0: r1 = Function '<anonymous closure>':.
    //     0xdd78c0: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3cf8] AnonymousClosure: (0xdd9bc4), in [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::build (0xdd7520)
    //     0xdd78c4: ldr             x1, [x1, #0xcf8]
    // 0xdd78c8: stur            x0, [fp, #-0x10]
    // 0xdd78cc: r0 = AllocateClosure()
    //     0xdd78cc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd78d0: ldur            x16, [fp, #-0x38]
    // 0xdd78d4: stp             x16, x0, [SP]
    // 0xdd78d8: ldur            x1, [fp, #-0x10]
    // 0xdd78dc: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0xdd78dc: add             x4, PP, #0x16, lsl #12  ; [pp+0x16e90] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0xdd78e0: ldr             x4, [x4, #0xe90]
    // 0xdd78e4: r0 = GestureDetector()
    //     0xdd78e4: bl              #0x9182dc  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0xdd78e8: ldur            x2, [fp, #-0x28]
    // 0xdd78ec: r1 = Function '<anonymous closure>':.
    //     0xdd78ec: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3d00] AnonymousClosure: (0xdd9b44), in [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::build (0xdd7520)
    //     0xdd78f0: ldr             x1, [x1, #0xd00]
    // 0xdd78f4: r0 = AllocateClosure()
    //     0xdd78f4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd78f8: stur            x0, [fp, #-0x18]
    // 0xdd78fc: r0 = MouseRegion()
    //     0xdd78fc: bl              #0xd1c8fc  ; AllocateMouseRegionStub -> MouseRegion (size=0x28)
    // 0xdd7900: mov             x1, x0
    // 0xdd7904: ldur            x0, [fp, #-0x18]
    // 0xdd7908: stur            x1, [fp, #-0x28]
    // 0xdd790c: StoreField: r1->field_13 = r0
    //     0xdd790c: stur            w0, [x1, #0x13]
    // 0xdd7910: r0 = Instance__DeferringMouseCursor
    //     0xdd7910: ldr             x0, [PP, #0x2208]  ; [pp+0x2208] Obj!_DeferringMouseCursor@12b3241
    // 0xdd7914: StoreField: r1->field_1b = r0
    //     0xdd7914: stur            w0, [x1, #0x1b]
    // 0xdd7918: r0 = true
    //     0xdd7918: add             x0, NULL, #0x20  ; true
    // 0xdd791c: StoreField: r1->field_1f = r0
    //     0xdd791c: stur            w0, [x1, #0x1f]
    // 0xdd7920: ldur            x2, [fp, #-0x10]
    // 0xdd7924: StoreField: r1->field_b = r2
    //     0xdd7924: stur            w2, [x1, #0xb]
    // 0xdd7928: r0 = KeyboardListener()
    //     0xdd7928: bl              #0xdd79ac  ; AllocateKeyboardListenerStub -> KeyboardListener (size=0x20)
    // 0xdd792c: mov             x3, x0
    // 0xdd7930: ldur            x0, [fp, #-0x20]
    // 0xdd7934: stur            x3, [fp, #-0x10]
    // 0xdd7938: StoreField: r3->field_b = r0
    //     0xdd7938: stur            w0, [x3, #0xb]
    // 0xdd793c: r0 = false
    //     0xdd793c: add             x0, NULL, #0x30  ; false
    // 0xdd7940: StoreField: r3->field_f = r0
    //     0xdd7940: stur            w0, [x3, #0xf]
    // 0xdd7944: r0 = true
    //     0xdd7944: add             x0, NULL, #0x20  ; true
    // 0xdd7948: StoreField: r3->field_13 = r0
    //     0xdd7948: stur            w0, [x3, #0x13]
    // 0xdd794c: ldur            x2, [fp, #-8]
    // 0xdd7950: r1 = Function '_handleKeyPress@452377751':.
    //     0xdd7950: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3d08] AnonymousClosure: (0xdd973c), in [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_handleKeyPress (0xdd9778)
    //     0xdd7954: ldr             x1, [x1, #0xd08]
    // 0xdd7958: r0 = AllocateClosure()
    //     0xdd7958: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd795c: mov             x1, x0
    // 0xdd7960: ldur            x0, [fp, #-0x10]
    // 0xdd7964: ArrayStore: r0[0] = r1  ; List_4
    //     0xdd7964: stur            w1, [x0, #0x17]
    // 0xdd7968: ldur            x1, [fp, #-0x28]
    // 0xdd796c: StoreField: r0->field_1b = r1
    //     0xdd796c: stur            w1, [x0, #0x1b]
    // 0xdd7970: LeaveFrame
    //     0xdd7970: mov             SP, fp
    //     0xdd7974: ldp             fp, lr, [SP], #0x10
    // 0xdd7978: ret
    //     0xdd7978: ret             
    // 0xdd797c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd797c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd7980: b               #0xdd7540
    // 0xdd7984: r9 = _latestValue
    //     0xdd7984: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3d10] Field <_MaterialDesktopControlsState@452377751._latestValue@452377751>: late (offset: 0x20)
    //     0xdd7988: ldr             x9, [x9, #0xd10]
    // 0xdd798c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd798c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdd7990: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd7990: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdd7994: r9 = _focusNode
    //     0xdd7994: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3ce8] Field <_MaterialDesktopControlsState@452377751._focusNode@452377751>: late final (offset: 0x58)
    //     0xdd7998: ldr             x9, [x9, #0xce8]
    // 0xdd799c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd799c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdd79a0: r9 = notifier
    //     0xdd79a0: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3cc8] Field <_MaterialDesktopControlsState@452377751.notifier>: late (offset: 0x1c)
    //     0xdd79a4: ldr             x9, [x9, #0xcc8]
    // 0xdd79a8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd79a8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _buildBottomBar(/* No info */) {
    // ** addr: 0xdd79b8, size: 0x820
    // 0xdd79b8: EnterFrame
    //     0xdd79b8: stp             fp, lr, [SP, #-0x10]!
    //     0xdd79bc: mov             fp, SP
    // 0xdd79c0: AllocStack(0x70)
    //     0xdd79c0: sub             SP, SP, #0x70
    // 0xdd79c4: SetupParameters(_MaterialDesktopControlsState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1 */)
    //     0xdd79c4: mov             x0, x1
    //     0xdd79c8: stur            x1, [fp, #-8]
    //     0xdd79cc: mov             x1, x2
    // 0xdd79d0: CheckStackOverflow
    //     0xdd79d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd79d4: cmp             SP, x16
    //     0xdd79d8: b.ls            #0xdd8180
    // 0xdd79dc: r0 = of()
    //     0xdd79dc: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xdd79e0: ldur            x1, [fp, #-8]
    // 0xdd79e4: LoadField: r0 = r1->field_1b
    //     0xdd79e4: ldur            w0, [x1, #0x1b]
    // 0xdd79e8: DecompressPointer r0
    //     0xdd79e8: add             x0, x0, HEAP, lsl #32
    // 0xdd79ec: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd79f0: cmp             w0, w16
    // 0xdd79f4: b.eq            #0xdd8188
    // 0xdd79f8: LoadField: r2 = r0->field_23
    //     0xdd79f8: ldur            w2, [x0, #0x23]
    // 0xdd79fc: DecompressPointer r2
    //     0xdd79fc: add             x2, x2, HEAP, lsl #32
    // 0xdd7a00: tbnz            w2, #4, #0xdd7a0c
    // 0xdd7a04: d0 = 0.000000
    //     0xdd7a04: eor             v0.16b, v0.16b, v0.16b
    // 0xdd7a08: b               #0xdd7a10
    // 0xdd7a0c: d0 = 1.000000
    //     0xdd7a0c: fmov            d0, #1.00000000
    // 0xdd7a10: stur            d0, [fp, #-0x50]
    // 0xdd7a14: LoadField: d1 = r1->field_47
    //     0xdd7a14: ldur            d1, [x1, #0x47]
    // 0xdd7a18: LoadField: r0 = r1->field_53
    //     0xdd7a18: ldur            w0, [x1, #0x53]
    // 0xdd7a1c: DecompressPointer r0
    //     0xdd7a1c: add             x0, x0, HEAP, lsl #32
    // 0xdd7a20: cmp             w0, NULL
    // 0xdd7a24: b.eq            #0xdd8194
    // 0xdd7a28: LoadField: r2 = r0->field_cf
    //     0xdd7a28: ldur            w2, [x0, #0xcf]
    // 0xdd7a2c: DecompressPointer r2
    //     0xdd7a2c: add             x2, x2, HEAP, lsl #32
    // 0xdd7a30: tbnz            w2, #4, #0xdd7a40
    // 0xdd7a34: r0 = 20.000000
    //     0xdd7a34: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1ae98] 20
    //     0xdd7a38: ldr             x0, [x0, #0xe98]
    // 0xdd7a3c: b               #0xdd7a44
    // 0xdd7a40: r0 = 0
    //     0xdd7a40: mov             x0, #0
    // 0xdd7a44: r2 = inline_Allocate_Double()
    //     0xdd7a44: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xdd7a48: add             x2, x2, #0x10
    //     0xdd7a4c: cmp             x3, x2
    //     0xdd7a50: b.ls            #0xdd8198
    //     0xdd7a54: str             x2, [THR, #0x60]  ; THR::top
    //     0xdd7a58: sub             x2, x2, #0xf
    //     0xdd7a5c: mov             x3, #0xe19c
    //     0xdd7a60: movk            x3, #3, lsl #16
    //     0xdd7a64: stur            x3, [x2, #-1]
    // 0xdd7a68: dmb             ishst
    // 0xdd7a6c: StoreField: r2->field_7 = d1
    //     0xdd7a6c: stur            d1, [x2, #7]
    // 0xdd7a70: stp             x0, x2, [SP]
    // 0xdd7a74: r0 = +()
    //     0xdd7a74: bl              #0x13dce50  ; [dart:core] _Double::+
    // 0xdd7a78: ldur            x1, [fp, #-8]
    // 0xdd7a7c: stur            x0, [fp, #-0x18]
    // 0xdd7a80: LoadField: r2 = r1->field_53
    //     0xdd7a80: ldur            w2, [x1, #0x53]
    // 0xdd7a84: DecompressPointer r2
    //     0xdd7a84: add             x2, x2, HEAP, lsl #32
    // 0xdd7a88: cmp             w2, NULL
    // 0xdd7a8c: b.eq            #0xdd81b4
    // 0xdd7a90: LoadField: r3 = r2->field_cf
    //     0xdd7a90: ldur            w3, [x2, #0xcf]
    // 0xdd7a94: DecompressPointer r3
    //     0xdd7a94: add             x3, x3, HEAP, lsl #32
    // 0xdd7a98: stur            x3, [fp, #-0x10]
    // 0xdd7a9c: tbnz            w3, #4, #0xdd7aa8
    // 0xdd7aa0: d0 = 10.000000
    //     0xdd7aa0: fmov            d0, #10.00000000
    // 0xdd7aa4: b               #0xdd7aac
    // 0xdd7aa8: d0 = 15.000000
    //     0xdd7aa8: fmov            d0, #15.00000000
    // 0xdd7aac: stur            d0, [fp, #-0x58]
    // 0xdd7ab0: r0 = EdgeInsets()
    //     0xdd7ab0: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xdd7ab4: stur            x0, [fp, #-0x20]
    // 0xdd7ab8: StoreField: r0->field_7 = rZR
    //     0xdd7ab8: stur            xzr, [x0, #7]
    // 0xdd7abc: StoreField: r0->field_f = rZR
    //     0xdd7abc: stur            xzr, [x0, #0xf]
    // 0xdd7ac0: ArrayStore: r0[0] = rZR  ; List_8
    //     0xdd7ac0: stur            xzr, [x0, #0x17]
    // 0xdd7ac4: ldur            d0, [fp, #-0x58]
    // 0xdd7ac8: StoreField: r0->field_1f = d0
    //     0xdd7ac8: stur            d0, [x0, #0x1f]
    // 0xdd7acc: ldur            x3, [fp, #-8]
    // 0xdd7ad0: LoadField: r2 = r3->field_4f
    //     0xdd7ad0: ldur            w2, [x3, #0x4f]
    // 0xdd7ad4: DecompressPointer r2
    //     0xdd7ad4: add             x2, x2, HEAP, lsl #32
    // 0xdd7ad8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd7adc: cmp             w2, w16
    // 0xdd7ae0: b.eq            #0xdd81b8
    // 0xdd7ae4: mov             x1, x3
    // 0xdd7ae8: r0 = _buildPlayPause()
    //     0xdd7ae8: bl              #0xdd9100  ; [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_buildPlayPause
    // 0xdd7aec: r1 = Null
    //     0xdd7aec: mov             x1, NULL
    // 0xdd7af0: r2 = 2
    //     0xdd7af0: mov             x2, #2
    // 0xdd7af4: stur            x0, [fp, #-0x28]
    // 0xdd7af8: r0 = AllocateArray()
    //     0xdd7af8: bl              #0x13df928  ; AllocateArrayStub
    // 0xdd7afc: mov             x2, x0
    // 0xdd7b00: ldur            x0, [fp, #-0x28]
    // 0xdd7b04: stur            x2, [fp, #-0x30]
    // 0xdd7b08: StoreField: r2->field_f = r0
    //     0xdd7b08: stur            w0, [x2, #0xf]
    // 0xdd7b0c: r1 = <Widget>
    //     0xdd7b0c: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xdd7b10: r0 = AllocateGrowableArray()
    //     0xdd7b10: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xdd7b14: mov             x3, x0
    // 0xdd7b18: ldur            x0, [fp, #-0x30]
    // 0xdd7b1c: stur            x3, [fp, #-0x28]
    // 0xdd7b20: StoreField: r3->field_f = r0
    //     0xdd7b20: stur            w0, [x3, #0xf]
    // 0xdd7b24: r0 = 2
    //     0xdd7b24: mov             x0, #2
    // 0xdd7b28: StoreField: r3->field_b = r0
    //     0xdd7b28: stur            w0, [x3, #0xb]
    // 0xdd7b2c: ldur            x4, [fp, #-8]
    // 0xdd7b30: LoadField: r1 = r4->field_53
    //     0xdd7b30: ldur            w1, [x4, #0x53]
    // 0xdd7b34: DecompressPointer r1
    //     0xdd7b34: add             x1, x1, HEAP, lsl #32
    // 0xdd7b38: cmp             w1, NULL
    // 0xdd7b3c: b.eq            #0xdd81c4
    // 0xdd7b40: LoadField: r2 = r4->field_4f
    //     0xdd7b40: ldur            w2, [x4, #0x4f]
    // 0xdd7b44: DecompressPointer r2
    //     0xdd7b44: add             x2, x2, HEAP, lsl #32
    // 0xdd7b48: mov             x1, x4
    // 0xdd7b4c: r0 = _buildMuteButton()
    //     0xdd7b4c: bl              #0xdd8dc4  ; [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_buildMuteButton
    // 0xdd7b50: mov             x2, x0
    // 0xdd7b54: ldur            x0, [fp, #-0x28]
    // 0xdd7b58: stur            x2, [fp, #-0x30]
    // 0xdd7b5c: LoadField: r1 = r0->field_b
    //     0xdd7b5c: ldur            w1, [x0, #0xb]
    // 0xdd7b60: LoadField: r3 = r0->field_f
    //     0xdd7b60: ldur            w3, [x0, #0xf]
    // 0xdd7b64: DecompressPointer r3
    //     0xdd7b64: add             x3, x3, HEAP, lsl #32
    // 0xdd7b68: LoadField: r4 = r3->field_b
    //     0xdd7b68: ldur            w4, [x3, #0xb]
    // 0xdd7b6c: r3 = LoadInt32Instr(r1)
    //     0xdd7b6c: sbfx            x3, x1, #1, #0x1f
    // 0xdd7b70: stur            x3, [fp, #-0x38]
    // 0xdd7b74: r1 = LoadInt32Instr(r4)
    //     0xdd7b74: sbfx            x1, x4, #1, #0x1f
    // 0xdd7b78: cmp             x3, x1
    // 0xdd7b7c: b.ne            #0xdd7b88
    // 0xdd7b80: mov             x1, x0
    // 0xdd7b84: r0 = _growToNextCapacity()
    //     0xdd7b84: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xdd7b88: ldur            x4, [fp, #-8]
    // 0xdd7b8c: ldur            x2, [fp, #-0x28]
    // 0xdd7b90: ldur            x3, [fp, #-0x38]
    // 0xdd7b94: add             x0, x3, #1
    // 0xdd7b98: lsl             x1, x0, #1
    // 0xdd7b9c: StoreField: r2->field_b = r1
    //     0xdd7b9c: stur            w1, [x2, #0xb]
    // 0xdd7ba0: LoadField: r1 = r2->field_f
    //     0xdd7ba0: ldur            w1, [x2, #0xf]
    // 0xdd7ba4: DecompressPointer r1
    //     0xdd7ba4: add             x1, x1, HEAP, lsl #32
    // 0xdd7ba8: ldur            x0, [fp, #-0x30]
    // 0xdd7bac: ArrayStore: r1[r3] = r0  ; List_4
    //     0xdd7bac: add             x25, x1, x3, lsl #2
    //     0xdd7bb0: add             x25, x25, #0xf
    //     0xdd7bb4: str             w0, [x25]
    //     0xdd7bb8: tbz             w0, #0, #0xdd7bd4
    //     0xdd7bbc: ldurb           w16, [x1, #-1]
    //     0xdd7bc0: ldurb           w17, [x0, #-1]
    //     0xdd7bc4: and             x16, x17, x16, lsr #2
    //     0xdd7bc8: tst             x16, HEAP, lsr #32
    //     0xdd7bcc: b.eq            #0xdd7bd4
    //     0xdd7bd0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdd7bd4: LoadField: r0 = r4->field_53
    //     0xdd7bd4: ldur            w0, [x4, #0x53]
    // 0xdd7bd8: DecompressPointer r0
    //     0xdd7bd8: add             x0, x0, HEAP, lsl #32
    // 0xdd7bdc: cmp             w0, NULL
    // 0xdd7be0: b.eq            #0xdd81c8
    // 0xdd7be4: mov             x1, x4
    // 0xdd7be8: r0 = _buildPosition()
    //     0xdd7be8: bl              #0xdd8cdc  ; [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_buildPosition
    // 0xdd7bec: mov             x2, x0
    // 0xdd7bf0: ldur            x0, [fp, #-0x28]
    // 0xdd7bf4: stur            x2, [fp, #-0x30]
    // 0xdd7bf8: LoadField: r1 = r0->field_b
    //     0xdd7bf8: ldur            w1, [x0, #0xb]
    // 0xdd7bfc: LoadField: r3 = r0->field_f
    //     0xdd7bfc: ldur            w3, [x0, #0xf]
    // 0xdd7c00: DecompressPointer r3
    //     0xdd7c00: add             x3, x3, HEAP, lsl #32
    // 0xdd7c04: LoadField: r4 = r3->field_b
    //     0xdd7c04: ldur            w4, [x3, #0xb]
    // 0xdd7c08: r3 = LoadInt32Instr(r1)
    //     0xdd7c08: sbfx            x3, x1, #1, #0x1f
    // 0xdd7c0c: stur            x3, [fp, #-0x38]
    // 0xdd7c10: r1 = LoadInt32Instr(r4)
    //     0xdd7c10: sbfx            x1, x4, #1, #0x1f
    // 0xdd7c14: cmp             x3, x1
    // 0xdd7c18: b.ne            #0xdd7c24
    // 0xdd7c1c: mov             x1, x0
    // 0xdd7c20: r0 = _growToNextCapacity()
    //     0xdd7c20: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xdd7c24: ldur            x2, [fp, #-0x28]
    // 0xdd7c28: ldur            x3, [fp, #-0x38]
    // 0xdd7c2c: add             x4, x3, #1
    // 0xdd7c30: stur            x4, [fp, #-0x40]
    // 0xdd7c34: lsl             x0, x4, #1
    // 0xdd7c38: StoreField: r2->field_b = r0
    //     0xdd7c38: stur            w0, [x2, #0xb]
    // 0xdd7c3c: LoadField: r5 = r2->field_f
    //     0xdd7c3c: ldur            w5, [x2, #0xf]
    // 0xdd7c40: DecompressPointer r5
    //     0xdd7c40: add             x5, x5, HEAP, lsl #32
    // 0xdd7c44: mov             x1, x5
    // 0xdd7c48: ldur            x0, [fp, #-0x30]
    // 0xdd7c4c: ArrayStore: r1[r3] = r0  ; List_4
    //     0xdd7c4c: add             x25, x1, x3, lsl #2
    //     0xdd7c50: add             x25, x25, #0xf
    //     0xdd7c54: str             w0, [x25]
    //     0xdd7c58: tbz             w0, #0, #0xdd7c74
    //     0xdd7c5c: ldurb           w16, [x1, #-1]
    //     0xdd7c60: ldurb           w17, [x0, #-1]
    //     0xdd7c64: and             x16, x17, x16, lsr #2
    //     0xdd7c68: tst             x16, HEAP, lsr #32
    //     0xdd7c6c: b.eq            #0xdd7c74
    //     0xdd7c70: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdd7c74: LoadField: r0 = r5->field_b
    //     0xdd7c74: ldur            w0, [x5, #0xb]
    // 0xdd7c78: r1 = LoadInt32Instr(r0)
    //     0xdd7c78: sbfx            x1, x0, #1, #0x1f
    // 0xdd7c7c: cmp             x4, x1
    // 0xdd7c80: b.ne            #0xdd7c8c
    // 0xdd7c84: mov             x1, x2
    // 0xdd7c88: r0 = _growToNextCapacity()
    //     0xdd7c88: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xdd7c8c: ldur            x2, [fp, #-8]
    // 0xdd7c90: ldur            x1, [fp, #-0x40]
    // 0xdd7c94: ldur            x0, [fp, #-0x28]
    // 0xdd7c98: add             x3, x1, #1
    // 0xdd7c9c: lsl             x4, x3, #1
    // 0xdd7ca0: StoreField: r0->field_b = r4
    //     0xdd7ca0: stur            w4, [x0, #0xb]
    // 0xdd7ca4: LoadField: r3 = r0->field_f
    //     0xdd7ca4: ldur            w3, [x0, #0xf]
    // 0xdd7ca8: DecompressPointer r3
    //     0xdd7ca8: add             x3, x3, HEAP, lsl #32
    // 0xdd7cac: add             x4, x3, x1, lsl #2
    // 0xdd7cb0: r16 = Instance_Spacer
    //     0xdd7cb0: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1ee78] Obj!Spacer@12b5c01
    //     0xdd7cb4: ldr             x16, [x16, #0xe78]
    // 0xdd7cb8: StoreField: r4->field_f = r16
    //     0xdd7cb8: stur            w16, [x4, #0xf]
    // 0xdd7cbc: LoadField: r1 = r2->field_53
    //     0xdd7cbc: ldur            w1, [x2, #0x53]
    // 0xdd7cc0: DecompressPointer r1
    //     0xdd7cc0: add             x1, x1, HEAP, lsl #32
    // 0xdd7cc4: cmp             w1, NULL
    // 0xdd7cc8: b.eq            #0xdd81cc
    // 0xdd7ccc: mov             x1, x2
    // 0xdd7cd0: r0 = _buildOptionsButton()
    //     0xdd7cd0: bl              #0xdd86a4  ; [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_buildOptionsButton
    // 0xdd7cd4: mov             x2, x0
    // 0xdd7cd8: ldur            x0, [fp, #-0x28]
    // 0xdd7cdc: stur            x2, [fp, #-0x30]
    // 0xdd7ce0: LoadField: r1 = r0->field_b
    //     0xdd7ce0: ldur            w1, [x0, #0xb]
    // 0xdd7ce4: LoadField: r3 = r0->field_f
    //     0xdd7ce4: ldur            w3, [x0, #0xf]
    // 0xdd7ce8: DecompressPointer r3
    //     0xdd7ce8: add             x3, x3, HEAP, lsl #32
    // 0xdd7cec: LoadField: r4 = r3->field_b
    //     0xdd7cec: ldur            w4, [x3, #0xb]
    // 0xdd7cf0: r3 = LoadInt32Instr(r1)
    //     0xdd7cf0: sbfx            x3, x1, #1, #0x1f
    // 0xdd7cf4: stur            x3, [fp, #-0x38]
    // 0xdd7cf8: r1 = LoadInt32Instr(r4)
    //     0xdd7cf8: sbfx            x1, x4, #1, #0x1f
    // 0xdd7cfc: cmp             x3, x1
    // 0xdd7d00: b.ne            #0xdd7d0c
    // 0xdd7d04: mov             x1, x0
    // 0xdd7d08: r0 = _growToNextCapacity()
    //     0xdd7d08: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xdd7d0c: ldur            x4, [fp, #-8]
    // 0xdd7d10: ldur            x2, [fp, #-0x28]
    // 0xdd7d14: ldur            x3, [fp, #-0x38]
    // 0xdd7d18: add             x0, x3, #1
    // 0xdd7d1c: lsl             x1, x0, #1
    // 0xdd7d20: StoreField: r2->field_b = r1
    //     0xdd7d20: stur            w1, [x2, #0xb]
    // 0xdd7d24: LoadField: r1 = r2->field_f
    //     0xdd7d24: ldur            w1, [x2, #0xf]
    // 0xdd7d28: DecompressPointer r1
    //     0xdd7d28: add             x1, x1, HEAP, lsl #32
    // 0xdd7d2c: ldur            x0, [fp, #-0x30]
    // 0xdd7d30: ArrayStore: r1[r3] = r0  ; List_4
    //     0xdd7d30: add             x25, x1, x3, lsl #2
    //     0xdd7d34: add             x25, x25, #0xf
    //     0xdd7d38: str             w0, [x25]
    //     0xdd7d3c: tbz             w0, #0, #0xdd7d58
    //     0xdd7d40: ldurb           w16, [x1, #-1]
    //     0xdd7d44: ldurb           w17, [x0, #-1]
    //     0xdd7d48: and             x16, x17, x16, lsr #2
    //     0xdd7d4c: tst             x16, HEAP, lsr #32
    //     0xdd7d50: b.eq            #0xdd7d58
    //     0xdd7d54: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdd7d58: LoadField: r0 = r4->field_53
    //     0xdd7d58: ldur            w0, [x4, #0x53]
    // 0xdd7d5c: DecompressPointer r0
    //     0xdd7d5c: add             x0, x0, HEAP, lsl #32
    // 0xdd7d60: cmp             w0, NULL
    // 0xdd7d64: b.eq            #0xdd81d0
    // 0xdd7d68: mov             x1, x4
    // 0xdd7d6c: r0 = _buildExpandButton()
    //     0xdd7d6c: bl              #0xdd81d8  ; [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_buildExpandButton
    // 0xdd7d70: mov             x2, x0
    // 0xdd7d74: ldur            x0, [fp, #-0x28]
    // 0xdd7d78: stur            x2, [fp, #-0x30]
    // 0xdd7d7c: LoadField: r1 = r0->field_b
    //     0xdd7d7c: ldur            w1, [x0, #0xb]
    // 0xdd7d80: LoadField: r3 = r0->field_f
    //     0xdd7d80: ldur            w3, [x0, #0xf]
    // 0xdd7d84: DecompressPointer r3
    //     0xdd7d84: add             x3, x3, HEAP, lsl #32
    // 0xdd7d88: LoadField: r4 = r3->field_b
    //     0xdd7d88: ldur            w4, [x3, #0xb]
    // 0xdd7d8c: r3 = LoadInt32Instr(r1)
    //     0xdd7d8c: sbfx            x3, x1, #1, #0x1f
    // 0xdd7d90: stur            x3, [fp, #-0x38]
    // 0xdd7d94: r1 = LoadInt32Instr(r4)
    //     0xdd7d94: sbfx            x1, x4, #1, #0x1f
    // 0xdd7d98: cmp             x3, x1
    // 0xdd7d9c: b.ne            #0xdd7da8
    // 0xdd7da0: mov             x1, x0
    // 0xdd7da4: r0 = _growToNextCapacity()
    //     0xdd7da4: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xdd7da8: ldur            x4, [fp, #-8]
    // 0xdd7dac: ldur            x2, [fp, #-0x28]
    // 0xdd7db0: ldur            x3, [fp, #-0x38]
    // 0xdd7db4: add             x0, x3, #1
    // 0xdd7db8: lsl             x1, x0, #1
    // 0xdd7dbc: StoreField: r2->field_b = r1
    //     0xdd7dbc: stur            w1, [x2, #0xb]
    // 0xdd7dc0: LoadField: r1 = r2->field_f
    //     0xdd7dc0: ldur            w1, [x2, #0xf]
    // 0xdd7dc4: DecompressPointer r1
    //     0xdd7dc4: add             x1, x1, HEAP, lsl #32
    // 0xdd7dc8: ldur            x0, [fp, #-0x30]
    // 0xdd7dcc: ArrayStore: r1[r3] = r0  ; List_4
    //     0xdd7dcc: add             x25, x1, x3, lsl #2
    //     0xdd7dd0: add             x25, x25, #0xf
    //     0xdd7dd4: str             w0, [x25]
    //     0xdd7dd8: tbz             w0, #0, #0xdd7df4
    //     0xdd7ddc: ldurb           w16, [x1, #-1]
    //     0xdd7de0: ldurb           w17, [x0, #-1]
    //     0xdd7de4: and             x16, x17, x16, lsr #2
    //     0xdd7de8: tst             x16, HEAP, lsr #32
    //     0xdd7dec: b.eq            #0xdd7df4
    //     0xdd7df0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdd7df4: r0 = Row()
    //     0xdd7df4: bl              #0x8a5b04  ; AllocateRowStub -> Row (size=0x38)
    // 0xdd7df8: mov             x2, x0
    // 0xdd7dfc: r0 = Instance_Axis
    //     0xdd7dfc: ldr             x0, [PP, #0x49c8]  ; [pp+0x49c8] Obj!Axis@12c4a61
    // 0xdd7e00: stur            x2, [fp, #-0x30]
    // 0xdd7e04: StoreField: r2->field_f = r0
    //     0xdd7e04: stur            w0, [x2, #0xf]
    // 0xdd7e08: r3 = Instance_MainAxisAlignment
    //     0xdd7e08: add             x3, PP, #0x15, lsl #12  ; [pp+0x15820] Obj!MainAxisAlignment@12c4541
    //     0xdd7e0c: ldr             x3, [x3, #0x820]
    // 0xdd7e10: StoreField: r2->field_13 = r3
    //     0xdd7e10: stur            w3, [x2, #0x13]
    // 0xdd7e14: r4 = Instance_MainAxisSize
    //     0xdd7e14: add             x4, PP, #0x15, lsl #12  ; [pp+0x15828] Obj!MainAxisSize@12c4621
    //     0xdd7e18: ldr             x4, [x4, #0x828]
    // 0xdd7e1c: ArrayStore: r2[0] = r4  ; List_4
    //     0xdd7e1c: stur            w4, [x2, #0x17]
    // 0xdd7e20: r5 = Instance_CrossAxisAlignment
    //     0xdd7e20: add             x5, PP, #0x15, lsl #12  ; [pp+0x15888] Obj!CrossAxisAlignment@12c44a1
    //     0xdd7e24: ldr             x5, [x5, #0x888]
    // 0xdd7e28: StoreField: r2->field_1b = r5
    //     0xdd7e28: stur            w5, [x2, #0x1b]
    // 0xdd7e2c: r6 = Instance_VerticalDirection
    //     0xdd7e2c: add             x6, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xdd7e30: ldr             x6, [x6, #0x838]
    // 0xdd7e34: StoreField: r2->field_23 = r6
    //     0xdd7e34: stur            w6, [x2, #0x23]
    // 0xdd7e38: r7 = Instance_Clip
    //     0xdd7e38: add             x7, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xdd7e3c: ldr             x7, [x7, #0x840]
    // 0xdd7e40: StoreField: r2->field_2b = r7
    //     0xdd7e40: stur            w7, [x2, #0x2b]
    // 0xdd7e44: StoreField: r2->field_2f = rZR
    //     0xdd7e44: stur            xzr, [x2, #0x2f]
    // 0xdd7e48: ldur            x1, [fp, #-0x28]
    // 0xdd7e4c: StoreField: r2->field_b = r1
    //     0xdd7e4c: stur            w1, [x2, #0xb]
    // 0xdd7e50: r1 = <FlexParentData>
    //     0xdd7e50: add             x1, PP, #0x15, lsl #12  ; [pp+0x15878] TypeArguments: <FlexParentData>
    //     0xdd7e54: ldr             x1, [x1, #0x878]
    // 0xdd7e58: r0 = Flexible()
    //     0xdd7e58: bl              #0xd0fd68  ; AllocateFlexibleStub -> Flexible (size=0x20)
    // 0xdd7e5c: mov             x3, x0
    // 0xdd7e60: r0 = 1
    //     0xdd7e60: mov             x0, #1
    // 0xdd7e64: stur            x3, [fp, #-0x28]
    // 0xdd7e68: StoreField: r3->field_13 = r0
    //     0xdd7e68: stur            x0, [x3, #0x13]
    // 0xdd7e6c: r1 = Instance_FlexFit
    //     0xdd7e6c: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1ac30] Obj!FlexFit@12c4661
    //     0xdd7e70: ldr             x1, [x1, #0xc30]
    // 0xdd7e74: StoreField: r3->field_1b = r1
    //     0xdd7e74: stur            w1, [x3, #0x1b]
    // 0xdd7e78: ldur            x1, [fp, #-0x30]
    // 0xdd7e7c: StoreField: r3->field_b = r1
    //     0xdd7e7c: stur            w1, [x3, #0xb]
    // 0xdd7e80: r1 = Null
    //     0xdd7e80: mov             x1, NULL
    // 0xdd7e84: r2 = 2
    //     0xdd7e84: mov             x2, #2
    // 0xdd7e88: r0 = AllocateArray()
    //     0xdd7e88: bl              #0x13df928  ; AllocateArrayStub
    // 0xdd7e8c: mov             x2, x0
    // 0xdd7e90: ldur            x0, [fp, #-0x28]
    // 0xdd7e94: stur            x2, [fp, #-0x30]
    // 0xdd7e98: StoreField: r2->field_f = r0
    //     0xdd7e98: stur            w0, [x2, #0xf]
    // 0xdd7e9c: r1 = <Widget>
    //     0xdd7e9c: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xdd7ea0: r0 = AllocateGrowableArray()
    //     0xdd7ea0: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xdd7ea4: mov             x1, x0
    // 0xdd7ea8: ldur            x0, [fp, #-0x30]
    // 0xdd7eac: stur            x1, [fp, #-0x28]
    // 0xdd7eb0: StoreField: r1->field_f = r0
    //     0xdd7eb0: stur            w0, [x1, #0xf]
    // 0xdd7eb4: r2 = 2
    //     0xdd7eb4: mov             x2, #2
    // 0xdd7eb8: StoreField: r1->field_b = r2
    //     0xdd7eb8: stur            w2, [x1, #0xb]
    // 0xdd7ebc: ldur            x0, [fp, #-8]
    // 0xdd7ec0: LoadField: r3 = r0->field_53
    //     0xdd7ec0: ldur            w3, [x0, #0x53]
    // 0xdd7ec4: DecompressPointer r3
    //     0xdd7ec4: add             x3, x3, HEAP, lsl #32
    // 0xdd7ec8: cmp             w3, NULL
    // 0xdd7ecc: b.eq            #0xdd81d4
    // 0xdd7ed0: LoadField: r4 = r3->field_cf
    //     0xdd7ed0: ldur            w4, [x3, #0xcf]
    // 0xdd7ed4: DecompressPointer r4
    //     0xdd7ed4: add             x4, x4, HEAP, lsl #32
    // 0xdd7ed8: tbnz            w4, #4, #0xdd7ee4
    // 0xdd7edc: d0 = 5.000000
    //     0xdd7edc: fmov            d0, #5.00000000
    // 0xdd7ee0: b               #0xdd7ee8
    // 0xdd7ee4: d0 = 0.000000
    //     0xdd7ee4: eor             v0.16b, v0.16b, v0.16b
    // 0xdd7ee8: stur            d0, [fp, #-0x58]
    // 0xdd7eec: r0 = EdgeInsets()
    //     0xdd7eec: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xdd7ef0: d0 = 20.000000
    //     0xdd7ef0: fmov            d0, #20.00000000
    // 0xdd7ef4: stur            x0, [fp, #-0x30]
    // 0xdd7ef8: StoreField: r0->field_7 = d0
    //     0xdd7ef8: stur            d0, [x0, #7]
    // 0xdd7efc: StoreField: r0->field_f = rZR
    //     0xdd7efc: stur            xzr, [x0, #0xf]
    // 0xdd7f00: ArrayStore: r0[0] = d0  ; List_8
    //     0xdd7f00: stur            d0, [x0, #0x17]
    // 0xdd7f04: ldur            d0, [fp, #-0x58]
    // 0xdd7f08: StoreField: r0->field_1f = d0
    //     0xdd7f08: stur            d0, [x0, #0x1f]
    // 0xdd7f0c: ldur            x1, [fp, #-8]
    // 0xdd7f10: r0 = _buildProgressBar()
    //     0xdd7f10: bl              #0xdcfa7c  ; [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_buildProgressBar
    // 0xdd7f14: r1 = Null
    //     0xdd7f14: mov             x1, NULL
    // 0xdd7f18: r2 = 2
    //     0xdd7f18: mov             x2, #2
    // 0xdd7f1c: stur            x0, [fp, #-8]
    // 0xdd7f20: r0 = AllocateArray()
    //     0xdd7f20: bl              #0x13df928  ; AllocateArrayStub
    // 0xdd7f24: mov             x2, x0
    // 0xdd7f28: ldur            x0, [fp, #-8]
    // 0xdd7f2c: stur            x2, [fp, #-0x48]
    // 0xdd7f30: StoreField: r2->field_f = r0
    //     0xdd7f30: stur            w0, [x2, #0xf]
    // 0xdd7f34: r1 = <Widget>
    //     0xdd7f34: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xdd7f38: r0 = AllocateGrowableArray()
    //     0xdd7f38: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xdd7f3c: mov             x1, x0
    // 0xdd7f40: ldur            x0, [fp, #-0x48]
    // 0xdd7f44: stur            x1, [fp, #-8]
    // 0xdd7f48: StoreField: r1->field_f = r0
    //     0xdd7f48: stur            w0, [x1, #0xf]
    // 0xdd7f4c: r0 = 2
    //     0xdd7f4c: mov             x0, #2
    // 0xdd7f50: StoreField: r1->field_b = r0
    //     0xdd7f50: stur            w0, [x1, #0xb]
    // 0xdd7f54: r0 = Row()
    //     0xdd7f54: bl              #0x8a5b04  ; AllocateRowStub -> Row (size=0x38)
    // 0xdd7f58: mov             x1, x0
    // 0xdd7f5c: r0 = Instance_Axis
    //     0xdd7f5c: ldr             x0, [PP, #0x49c8]  ; [pp+0x49c8] Obj!Axis@12c4a61
    // 0xdd7f60: stur            x1, [fp, #-0x48]
    // 0xdd7f64: StoreField: r1->field_f = r0
    //     0xdd7f64: stur            w0, [x1, #0xf]
    // 0xdd7f68: r0 = Instance_MainAxisAlignment
    //     0xdd7f68: add             x0, PP, #0x15, lsl #12  ; [pp+0x15820] Obj!MainAxisAlignment@12c4541
    //     0xdd7f6c: ldr             x0, [x0, #0x820]
    // 0xdd7f70: StoreField: r1->field_13 = r0
    //     0xdd7f70: stur            w0, [x1, #0x13]
    // 0xdd7f74: r0 = Instance_MainAxisSize
    //     0xdd7f74: add             x0, PP, #0x15, lsl #12  ; [pp+0x15828] Obj!MainAxisSize@12c4621
    //     0xdd7f78: ldr             x0, [x0, #0x828]
    // 0xdd7f7c: ArrayStore: r1[0] = r0  ; List_4
    //     0xdd7f7c: stur            w0, [x1, #0x17]
    // 0xdd7f80: r0 = Instance_CrossAxisAlignment
    //     0xdd7f80: add             x0, PP, #0x15, lsl #12  ; [pp+0x15888] Obj!CrossAxisAlignment@12c44a1
    //     0xdd7f84: ldr             x0, [x0, #0x888]
    // 0xdd7f88: StoreField: r1->field_1b = r0
    //     0xdd7f88: stur            w0, [x1, #0x1b]
    // 0xdd7f8c: r2 = Instance_VerticalDirection
    //     0xdd7f8c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xdd7f90: ldr             x2, [x2, #0x838]
    // 0xdd7f94: StoreField: r1->field_23 = r2
    //     0xdd7f94: stur            w2, [x1, #0x23]
    // 0xdd7f98: r2 = Instance_Clip
    //     0xdd7f98: add             x2, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xdd7f9c: ldr             x2, [x2, #0x840]
    // 0xdd7fa0: StoreField: r1->field_2b = r2
    //     0xdd7fa0: stur            w2, [x1, #0x2b]
    // 0xdd7fa4: StoreField: r1->field_2f = rZR
    //     0xdd7fa4: stur            xzr, [x1, #0x2f]
    // 0xdd7fa8: ldur            x3, [fp, #-8]
    // 0xdd7fac: StoreField: r1->field_b = r3
    //     0xdd7fac: stur            w3, [x1, #0xb]
    // 0xdd7fb0: r0 = Container()
    //     0xdd7fb0: bl              #0x8a5af8  ; AllocateContainerStub -> Container (size=0x38)
    // 0xdd7fb4: stur            x0, [fp, #-8]
    // 0xdd7fb8: ldur            x16, [fp, #-0x30]
    // 0xdd7fbc: ldur            lr, [fp, #-0x48]
    // 0xdd7fc0: stp             lr, x16, [SP]
    // 0xdd7fc4: mov             x1, x0
    // 0xdd7fc8: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, padding, 0x1, null]
    //     0xdd7fc8: add             x4, PP, #0x1b, lsl #12  ; [pp+0x1bdb0] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "padding", 0x1, Null]
    //     0xdd7fcc: ldr             x4, [x4, #0xdb0]
    // 0xdd7fd0: r0 = Container()
    //     0xdd7fd0: bl              #0x8a54e0  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0xdd7fd4: r1 = <FlexParentData>
    //     0xdd7fd4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15878] TypeArguments: <FlexParentData>
    //     0xdd7fd8: ldr             x1, [x1, #0x878]
    // 0xdd7fdc: r0 = Expanded()
    //     0xdd7fdc: bl              #0x8a5b10  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0xdd7fe0: mov             x2, x0
    // 0xdd7fe4: r0 = 1
    //     0xdd7fe4: mov             x0, #1
    // 0xdd7fe8: stur            x2, [fp, #-0x30]
    // 0xdd7fec: StoreField: r2->field_13 = r0
    //     0xdd7fec: stur            x0, [x2, #0x13]
    // 0xdd7ff0: r0 = Instance_FlexFit
    //     0xdd7ff0: add             x0, PP, #0x15, lsl #12  ; [pp+0x15880] Obj!FlexFit@12c4641
    //     0xdd7ff4: ldr             x0, [x0, #0x880]
    // 0xdd7ff8: StoreField: r2->field_1b = r0
    //     0xdd7ff8: stur            w0, [x2, #0x1b]
    // 0xdd7ffc: ldur            x0, [fp, #-8]
    // 0xdd8000: StoreField: r2->field_b = r0
    //     0xdd8000: stur            w0, [x2, #0xb]
    // 0xdd8004: ldur            x0, [fp, #-0x28]
    // 0xdd8008: LoadField: r1 = r0->field_b
    //     0xdd8008: ldur            w1, [x0, #0xb]
    // 0xdd800c: LoadField: r3 = r0->field_f
    //     0xdd800c: ldur            w3, [x0, #0xf]
    // 0xdd8010: DecompressPointer r3
    //     0xdd8010: add             x3, x3, HEAP, lsl #32
    // 0xdd8014: LoadField: r4 = r3->field_b
    //     0xdd8014: ldur            w4, [x3, #0xb]
    // 0xdd8018: r3 = LoadInt32Instr(r1)
    //     0xdd8018: sbfx            x3, x1, #1, #0x1f
    // 0xdd801c: stur            x3, [fp, #-0x38]
    // 0xdd8020: r1 = LoadInt32Instr(r4)
    //     0xdd8020: sbfx            x1, x4, #1, #0x1f
    // 0xdd8024: cmp             x3, x1
    // 0xdd8028: b.ne            #0xdd8034
    // 0xdd802c: mov             x1, x0
    // 0xdd8030: r0 = _growToNextCapacity()
    //     0xdd8030: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xdd8034: ldur            d0, [fp, #-0x50]
    // 0xdd8038: ldur            x4, [fp, #-0x10]
    // 0xdd803c: ldur            x2, [fp, #-0x28]
    // 0xdd8040: ldur            x3, [fp, #-0x38]
    // 0xdd8044: add             x0, x3, #1
    // 0xdd8048: lsl             x1, x0, #1
    // 0xdd804c: StoreField: r2->field_b = r1
    //     0xdd804c: stur            w1, [x2, #0xb]
    // 0xdd8050: LoadField: r1 = r2->field_f
    //     0xdd8050: ldur            w1, [x2, #0xf]
    // 0xdd8054: DecompressPointer r1
    //     0xdd8054: add             x1, x1, HEAP, lsl #32
    // 0xdd8058: ldur            x0, [fp, #-0x30]
    // 0xdd805c: ArrayStore: r1[r3] = r0  ; List_4
    //     0xdd805c: add             x25, x1, x3, lsl #2
    //     0xdd8060: add             x25, x25, #0xf
    //     0xdd8064: str             w0, [x25]
    //     0xdd8068: tbz             w0, #0, #0xdd8084
    //     0xdd806c: ldurb           w16, [x1, #-1]
    //     0xdd8070: ldurb           w17, [x0, #-1]
    //     0xdd8074: and             x16, x17, x16, lsr #2
    //     0xdd8078: tst             x16, HEAP, lsr #32
    //     0xdd807c: b.eq            #0xdd8084
    //     0xdd8080: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdd8084: r0 = Column()
    //     0xdd8084: bl              #0x8a5b1c  ; AllocateColumnStub -> Column (size=0x38)
    // 0xdd8088: mov             x1, x0
    // 0xdd808c: r0 = Instance_Axis
    //     0xdd808c: ldr             x0, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xdd8090: stur            x1, [fp, #-8]
    // 0xdd8094: StoreField: r1->field_f = r0
    //     0xdd8094: stur            w0, [x1, #0xf]
    // 0xdd8098: r0 = Instance_MainAxisAlignment
    //     0xdd8098: add             x0, PP, #0x18, lsl #12  ; [pp+0x180f0] Obj!MainAxisAlignment@12c4581
    //     0xdd809c: ldr             x0, [x0, #0xf0]
    // 0xdd80a0: StoreField: r1->field_13 = r0
    //     0xdd80a0: stur            w0, [x1, #0x13]
    // 0xdd80a4: r0 = Instance_MainAxisSize
    //     0xdd80a4: add             x0, PP, #0x17, lsl #12  ; [pp+0x17200] Obj!MainAxisSize@12c4601
    //     0xdd80a8: ldr             x0, [x0, #0x200]
    // 0xdd80ac: ArrayStore: r1[0] = r0  ; List_4
    //     0xdd80ac: stur            w0, [x1, #0x17]
    // 0xdd80b0: r0 = Instance_CrossAxisAlignment
    //     0xdd80b0: add             x0, PP, #0x15, lsl #12  ; [pp+0x15888] Obj!CrossAxisAlignment@12c44a1
    //     0xdd80b4: ldr             x0, [x0, #0x888]
    // 0xdd80b8: StoreField: r1->field_1b = r0
    //     0xdd80b8: stur            w0, [x1, #0x1b]
    // 0xdd80bc: r0 = Instance_VerticalDirection
    //     0xdd80bc: add             x0, PP, #0xd3, lsl #12  ; [pp+0xd3d58] Obj!VerticalDirection@12c4a41
    //     0xdd80c0: ldr             x0, [x0, #0xd58]
    // 0xdd80c4: StoreField: r1->field_23 = r0
    //     0xdd80c4: stur            w0, [x1, #0x23]
    // 0xdd80c8: r0 = Instance_Clip
    //     0xdd80c8: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xdd80cc: ldr             x0, [x0, #0x840]
    // 0xdd80d0: StoreField: r1->field_2b = r0
    //     0xdd80d0: stur            w0, [x1, #0x2b]
    // 0xdd80d4: StoreField: r1->field_2f = rZR
    //     0xdd80d4: stur            xzr, [x1, #0x2f]
    // 0xdd80d8: ldur            x0, [fp, #-0x28]
    // 0xdd80dc: StoreField: r1->field_b = r0
    //     0xdd80dc: stur            w0, [x1, #0xb]
    // 0xdd80e0: r0 = SafeArea()
    //     0xdd80e0: bl              #0xd73100  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0xdd80e4: mov             x1, x0
    // 0xdd80e8: r0 = true
    //     0xdd80e8: add             x0, NULL, #0x20  ; true
    // 0xdd80ec: stur            x1, [fp, #-0x28]
    // 0xdd80f0: StoreField: r1->field_b = r0
    //     0xdd80f0: stur            w0, [x1, #0xb]
    // 0xdd80f4: StoreField: r1->field_f = r0
    //     0xdd80f4: stur            w0, [x1, #0xf]
    // 0xdd80f8: StoreField: r1->field_13 = r0
    //     0xdd80f8: stur            w0, [x1, #0x13]
    // 0xdd80fc: ldur            x0, [fp, #-0x10]
    // 0xdd8100: ArrayStore: r1[0] = r0  ; List_4
    //     0xdd8100: stur            w0, [x1, #0x17]
    // 0xdd8104: r0 = Instance_EdgeInsets
    //     0xdd8104: ldr             x0, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0xdd8108: StoreField: r1->field_1b = r0
    //     0xdd8108: stur            w0, [x1, #0x1b]
    // 0xdd810c: r0 = false
    //     0xdd810c: add             x0, NULL, #0x30  ; false
    // 0xdd8110: StoreField: r1->field_1f = r0
    //     0xdd8110: stur            w0, [x1, #0x1f]
    // 0xdd8114: ldur            x2, [fp, #-8]
    // 0xdd8118: StoreField: r1->field_23 = r2
    //     0xdd8118: stur            w2, [x1, #0x23]
    // 0xdd811c: r0 = Container()
    //     0xdd811c: bl              #0x8a5af8  ; AllocateContainerStub -> Container (size=0x38)
    // 0xdd8120: stur            x0, [fp, #-8]
    // 0xdd8124: ldur            x16, [fp, #-0x18]
    // 0xdd8128: ldur            lr, [fp, #-0x20]
    // 0xdd812c: stp             lr, x16, [SP, #8]
    // 0xdd8130: ldur            x16, [fp, #-0x28]
    // 0xdd8134: str             x16, [SP]
    // 0xdd8138: mov             x1, x0
    // 0xdd813c: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, height, 0x1, padding, 0x2, null]
    //     0xdd813c: add             x4, PP, #0x91, lsl #12  ; [pp+0x91970] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "height", 0x1, "padding", 0x2, Null]
    //     0xdd8140: ldr             x4, [x4, #0x970]
    // 0xdd8144: r0 = Container()
    //     0xdd8144: bl              #0x8a54e0  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0xdd8148: r0 = AnimatedOpacity()
    //     0xdd8148: bl              #0xd2cf50  ; AllocateAnimatedOpacityStub -> AnimatedOpacity (size=0x28)
    // 0xdd814c: ldur            x1, [fp, #-8]
    // 0xdd8150: ArrayStore: r0[0] = r1  ; List_4
    //     0xdd8150: stur            w1, [x0, #0x17]
    // 0xdd8154: ldur            d0, [fp, #-0x50]
    // 0xdd8158: StoreField: r0->field_1b = d0
    //     0xdd8158: stur            d0, [x0, #0x1b]
    // 0xdd815c: r1 = false
    //     0xdd815c: add             x1, NULL, #0x30  ; false
    // 0xdd8160: StoreField: r0->field_23 = r1
    //     0xdd8160: stur            w1, [x0, #0x23]
    // 0xdd8164: r1 = Instance__Linear
    //     0xdd8164: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] Obj!_Linear@129fef1
    // 0xdd8168: StoreField: r0->field_b = r1
    //     0xdd8168: stur            w1, [x0, #0xb]
    // 0xdd816c: r1 = Instance_Duration
    //     0xdd816c: ldr             x1, [PP, #0x7cd8]  ; [pp+0x7cd8] Obj!Duration@12c8971
    // 0xdd8170: StoreField: r0->field_f = r1
    //     0xdd8170: stur            w1, [x0, #0xf]
    // 0xdd8174: LeaveFrame
    //     0xdd8174: mov             SP, fp
    //     0xdd8178: ldp             fp, lr, [SP], #0x10
    // 0xdd817c: ret
    //     0xdd817c: ret             
    // 0xdd8180: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd8180: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd8184: b               #0xdd79dc
    // 0xdd8188: r9 = notifier
    //     0xdd8188: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3cc8] Field <_MaterialDesktopControlsState@452377751.notifier>: late (offset: 0x1c)
    //     0xdd818c: ldr             x9, [x9, #0xcc8]
    // 0xdd8190: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd8190: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdd8194: r0 = NullCastErrorSharedWithFPURegs()
    //     0xdd8194: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xdd8198: stp             q0, q1, [SP, #-0x20]!
    // 0xdd819c: stp             x0, x1, [SP, #-0x10]!
    // 0xdd81a0: r0 = AllocateDouble()
    //     0xdd81a0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xdd81a4: mov             x2, x0
    // 0xdd81a8: ldp             x0, x1, [SP], #0x10
    // 0xdd81ac: ldp             q0, q1, [SP], #0x20
    // 0xdd81b0: b               #0xdd7a6c
    // 0xdd81b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd81b4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdd81b8: r9 = controller
    //     0xdd81b8: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3cb8] Field <_MaterialDesktopControlsState@452377751.controller>: late (offset: 0x50)
    //     0xdd81bc: ldr             x9, [x9, #0xcb8]
    // 0xdd81c0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd81c0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdd81c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd81c4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdd81c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd81c8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdd81cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd81cc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdd81d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd81d0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdd81d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd81d4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _buildExpandButton(/* No info */) {
    // ** addr: 0xdd81d8, size: 0x218
    // 0xdd81d8: EnterFrame
    //     0xdd81d8: stp             fp, lr, [SP, #-0x10]!
    //     0xdd81dc: mov             fp, SP
    // 0xdd81e0: AllocStack(0x48)
    //     0xdd81e0: sub             SP, SP, #0x48
    // 0xdd81e4: SetupParameters(_MaterialDesktopControlsState this /* r1 => r2, fp-0x8 */)
    //     0xdd81e4: mov             x2, x1
    //     0xdd81e8: stur            x1, [fp, #-8]
    // 0xdd81ec: CheckStackOverflow
    //     0xdd81ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd81f0: cmp             SP, x16
    //     0xdd81f4: b.ls            #0xdd83b8
    // 0xdd81f8: LoadField: r0 = r2->field_1b
    //     0xdd81f8: ldur            w0, [x2, #0x1b]
    // 0xdd81fc: DecompressPointer r0
    //     0xdd81fc: add             x0, x0, HEAP, lsl #32
    // 0xdd8200: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd8204: cmp             w0, w16
    // 0xdd8208: b.eq            #0xdd83c0
    // 0xdd820c: LoadField: r1 = r0->field_23
    //     0xdd820c: ldur            w1, [x0, #0x23]
    // 0xdd8210: DecompressPointer r1
    //     0xdd8210: add             x1, x1, HEAP, lsl #32
    // 0xdd8214: tbnz            w1, #4, #0xdd8220
    // 0xdd8218: d0 = 0.000000
    //     0xdd8218: eor             v0.16b, v0.16b, v0.16b
    // 0xdd821c: b               #0xdd8224
    // 0xdd8220: d0 = 1.000000
    //     0xdd8220: fmov            d0, #1.00000000
    // 0xdd8224: stur            d0, [fp, #-0x28]
    // 0xdd8228: LoadField: d1 = r2->field_47
    //     0xdd8228: ldur            d1, [x2, #0x47]
    // 0xdd822c: LoadField: r0 = r2->field_53
    //     0xdd822c: ldur            w0, [x2, #0x53]
    // 0xdd8230: DecompressPointer r0
    //     0xdd8230: add             x0, x0, HEAP, lsl #32
    // 0xdd8234: cmp             w0, NULL
    // 0xdd8238: b.eq            #0xdd83cc
    // 0xdd823c: LoadField: r1 = r0->field_cf
    //     0xdd823c: ldur            w1, [x0, #0xcf]
    // 0xdd8240: DecompressPointer r1
    //     0xdd8240: add             x1, x1, HEAP, lsl #32
    // 0xdd8244: tbnz            w1, #4, #0xdd8254
    // 0xdd8248: r0 = 15.000000
    //     0xdd8248: add             x0, PP, #0x27, lsl #12  ; [pp+0x274b0] 15
    //     0xdd824c: ldr             x0, [x0, #0x4b0]
    // 0xdd8250: b               #0xdd8258
    // 0xdd8254: r0 = 0
    //     0xdd8254: mov             x0, #0
    // 0xdd8258: r1 = inline_Allocate_Double()
    //     0xdd8258: ldp             x1, x3, [THR, #0x60]  ; THR::top
    //     0xdd825c: add             x1, x1, #0x10
    //     0xdd8260: cmp             x3, x1
    //     0xdd8264: b.ls            #0xdd83d0
    //     0xdd8268: str             x1, [THR, #0x60]  ; THR::top
    //     0xdd826c: sub             x1, x1, #0xf
    //     0xdd8270: mov             x3, #0xe19c
    //     0xdd8274: movk            x3, #3, lsl #16
    //     0xdd8278: stur            x3, [x1, #-1]
    // 0xdd827c: dmb             ishst
    // 0xdd8280: StoreField: r1->field_7 = d1
    //     0xdd8280: stur            d1, [x1, #7]
    // 0xdd8284: stp             x0, x1, [SP]
    // 0xdd8288: r0 = +()
    //     0xdd8288: bl              #0x13dce50  ; [dart:core] _Double::+
    // 0xdd828c: ldur            x2, [fp, #-8]
    // 0xdd8290: stur            x0, [fp, #-0x18]
    // 0xdd8294: LoadField: r1 = r2->field_53
    //     0xdd8294: ldur            w1, [x2, #0x53]
    // 0xdd8298: DecompressPointer r1
    //     0xdd8298: add             x1, x1, HEAP, lsl #32
    // 0xdd829c: cmp             w1, NULL
    // 0xdd82a0: b.eq            #0xdd83ec
    // 0xdd82a4: LoadField: r3 = r1->field_cf
    //     0xdd82a4: ldur            w3, [x1, #0xcf]
    // 0xdd82a8: DecompressPointer r3
    //     0xdd82a8: add             x3, x3, HEAP, lsl #32
    // 0xdd82ac: tbnz            w3, #4, #0xdd82bc
    // 0xdd82b0: r1 = Instance_IconData
    //     0xdd82b0: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3d88] Obj!IconData@128a751
    //     0xdd82b4: ldr             x1, [x1, #0xd88]
    // 0xdd82b8: b               #0xdd82c4
    // 0xdd82bc: r1 = Instance_IconData
    //     0xdd82bc: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3d90] Obj!IconData@128a731
    //     0xdd82c0: ldr             x1, [x1, #0xd90]
    // 0xdd82c4: ldur            d0, [fp, #-0x28]
    // 0xdd82c8: stur            x1, [fp, #-0x10]
    // 0xdd82cc: r0 = Icon()
    //     0xdd82cc: bl              #0xd0fd5c  ; AllocateIconStub -> Icon (size=0x40)
    // 0xdd82d0: mov             x1, x0
    // 0xdd82d4: ldur            x0, [fp, #-0x10]
    // 0xdd82d8: stur            x1, [fp, #-0x20]
    // 0xdd82dc: StoreField: r1->field_b = r0
    //     0xdd82dc: stur            w0, [x1, #0xb]
    // 0xdd82e0: r0 = Instance_Color
    //     0xdd82e0: add             x0, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0xdd82e4: ldr             x0, [x0, #0xc38]
    // 0xdd82e8: StoreField: r1->field_23 = r0
    //     0xdd82e8: stur            w0, [x1, #0x23]
    // 0xdd82ec: r0 = Center()
    //     0xdd82ec: bl              #0xd0c898  ; AllocateCenterStub -> Center (size=0x1c)
    // 0xdd82f0: mov             x1, x0
    // 0xdd82f4: r0 = Instance_Alignment
    //     0xdd82f4: add             x0, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xdd82f8: ldr             x0, [x0, #0xb80]
    // 0xdd82fc: stur            x1, [fp, #-0x10]
    // 0xdd8300: StoreField: r1->field_f = r0
    //     0xdd8300: stur            w0, [x1, #0xf]
    // 0xdd8304: ldur            x0, [fp, #-0x20]
    // 0xdd8308: StoreField: r1->field_b = r0
    //     0xdd8308: stur            w0, [x1, #0xb]
    // 0xdd830c: r0 = Container()
    //     0xdd830c: bl              #0x8a5af8  ; AllocateContainerStub -> Container (size=0x38)
    // 0xdd8310: stur            x0, [fp, #-0x20]
    // 0xdd8314: ldur            x16, [fp, #-0x18]
    // 0xdd8318: r30 = Instance_EdgeInsets
    //     0xdd8318: add             lr, PP, #0xd3, lsl #12  ; [pp+0xd3d98] Obj!EdgeInsets@129d351
    //     0xdd831c: ldr             lr, [lr, #0xd98]
    // 0xdd8320: stp             lr, x16, [SP, #0x10]
    // 0xdd8324: r16 = Instance_EdgeInsets
    //     0xdd8324: add             x16, PP, #0x7a, lsl #12  ; [pp+0x7abf0] Obj!EdgeInsets@129cd21
    //     0xdd8328: ldr             x16, [x16, #0xbf0]
    // 0xdd832c: ldur            lr, [fp, #-0x10]
    // 0xdd8330: stp             lr, x16, [SP]
    // 0xdd8334: mov             x1, x0
    // 0xdd8338: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, height, 0x1, margin, 0x2, padding, 0x3, null]
    //     0xdd8338: add             x4, PP, #0xd3, lsl #12  ; [pp+0xd3da0] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "height", 0x1, "margin", 0x2, "padding", 0x3, Null]
    //     0xdd833c: ldr             x4, [x4, #0xda0]
    // 0xdd8340: r0 = Container()
    //     0xdd8340: bl              #0x8a54e0  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0xdd8344: r0 = AnimatedOpacity()
    //     0xdd8344: bl              #0xd2cf50  ; AllocateAnimatedOpacityStub -> AnimatedOpacity (size=0x28)
    // 0xdd8348: mov             x1, x0
    // 0xdd834c: ldur            x0, [fp, #-0x20]
    // 0xdd8350: stur            x1, [fp, #-0x10]
    // 0xdd8354: ArrayStore: r1[0] = r0  ; List_4
    //     0xdd8354: stur            w0, [x1, #0x17]
    // 0xdd8358: ldur            d0, [fp, #-0x28]
    // 0xdd835c: StoreField: r1->field_1b = d0
    //     0xdd835c: stur            d0, [x1, #0x1b]
    // 0xdd8360: r0 = false
    //     0xdd8360: add             x0, NULL, #0x30  ; false
    // 0xdd8364: StoreField: r1->field_23 = r0
    //     0xdd8364: stur            w0, [x1, #0x23]
    // 0xdd8368: r0 = Instance__Linear
    //     0xdd8368: ldr             x0, [PP, #0x5168]  ; [pp+0x5168] Obj!_Linear@129fef1
    // 0xdd836c: StoreField: r1->field_b = r0
    //     0xdd836c: stur            w0, [x1, #0xb]
    // 0xdd8370: r0 = Instance_Duration
    //     0xdd8370: ldr             x0, [PP, #0x7cd8]  ; [pp+0x7cd8] Obj!Duration@12c8971
    // 0xdd8374: StoreField: r1->field_f = r0
    //     0xdd8374: stur            w0, [x1, #0xf]
    // 0xdd8378: r0 = GestureDetector()
    //     0xdd8378: bl              #0x918e18  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0xdd837c: ldur            x2, [fp, #-8]
    // 0xdd8380: r1 = Function '_onExpandCollapse@452377751':.
    //     0xdd8380: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3da8] AnonymousClosure: (0xdd83f0), in [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_onExpandCollapse (0xdd8428)
    //     0xdd8384: ldr             x1, [x1, #0xda8]
    // 0xdd8388: stur            x0, [fp, #-8]
    // 0xdd838c: r0 = AllocateClosure()
    //     0xdd838c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd8390: ldur            x16, [fp, #-0x10]
    // 0xdd8394: stp             x16, x0, [SP]
    // 0xdd8398: ldur            x1, [fp, #-8]
    // 0xdd839c: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0xdd839c: add             x4, PP, #0x16, lsl #12  ; [pp+0x16e90] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0xdd83a0: ldr             x4, [x4, #0xe90]
    // 0xdd83a4: r0 = GestureDetector()
    //     0xdd83a4: bl              #0x9182dc  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0xdd83a8: ldur            x0, [fp, #-8]
    // 0xdd83ac: LeaveFrame
    //     0xdd83ac: mov             SP, fp
    //     0xdd83b0: ldp             fp, lr, [SP], #0x10
    // 0xdd83b4: ret
    //     0xdd83b4: ret             
    // 0xdd83b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd83b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd83bc: b               #0xdd81f8
    // 0xdd83c0: r9 = notifier
    //     0xdd83c0: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3cc8] Field <_MaterialDesktopControlsState@452377751.notifier>: late (offset: 0x1c)
    //     0xdd83c4: ldr             x9, [x9, #0xcc8]
    // 0xdd83c8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd83c8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdd83cc: r0 = NullCastErrorSharedWithFPURegs()
    //     0xdd83cc: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xdd83d0: stp             q0, q1, [SP, #-0x20]!
    // 0xdd83d4: stp             x0, x2, [SP, #-0x10]!
    // 0xdd83d8: r0 = AllocateDouble()
    //     0xdd83d8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xdd83dc: mov             x1, x0
    // 0xdd83e0: ldp             x0, x2, [SP], #0x10
    // 0xdd83e4: ldp             q0, q1, [SP], #0x20
    // 0xdd83e8: b               #0xdd8280
    // 0xdd83ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd83ec: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _onExpandCollapse(dynamic) {
    // ** addr: 0xdd83f0, size: 0x38
    // 0xdd83f0: EnterFrame
    //     0xdd83f0: stp             fp, lr, [SP, #-0x10]!
    //     0xdd83f4: mov             fp, SP
    // 0xdd83f8: ldr             x0, [fp, #0x10]
    // 0xdd83fc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdd83fc: ldur            w1, [x0, #0x17]
    // 0xdd8400: DecompressPointer r1
    //     0xdd8400: add             x1, x1, HEAP, lsl #32
    // 0xdd8404: CheckStackOverflow
    //     0xdd8404: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd8408: cmp             SP, x16
    //     0xdd840c: b.ls            #0xdd8420
    // 0xdd8410: r0 = _onExpandCollapse()
    //     0xdd8410: bl              #0xdd8428  ; [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_onExpandCollapse
    // 0xdd8414: LeaveFrame
    //     0xdd8414: mov             SP, fp
    //     0xdd8418: ldp             fp, lr, [SP], #0x10
    // 0xdd841c: ret
    //     0xdd841c: ret             
    // 0xdd8420: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd8420: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd8424: b               #0xdd8410
  }
  _ _onExpandCollapse(/* No info */) {
    // ** addr: 0xdd8428, size: 0xc4
    // 0xdd8428: EnterFrame
    //     0xdd8428: stp             fp, lr, [SP, #-0x10]!
    //     0xdd842c: mov             fp, SP
    // 0xdd8430: AllocStack(0x10)
    //     0xdd8430: sub             SP, SP, #0x10
    // 0xdd8434: SetupParameters(_MaterialDesktopControlsState this /* r1 => r1, fp-0x8 */)
    //     0xdd8434: stur            x1, [fp, #-8]
    // 0xdd8438: CheckStackOverflow
    //     0xdd8438: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd843c: cmp             SP, x16
    //     0xdd8440: b.ls            #0xdd84e0
    // 0xdd8444: r1 = 1
    //     0xdd8444: mov             x1, #1
    // 0xdd8448: r0 = AllocateContext()
    //     0xdd8448: bl              #0x13de838  ; AllocateContextStub
    // 0xdd844c: mov             x3, x0
    // 0xdd8450: ldur            x0, [fp, #-8]
    // 0xdd8454: stur            x3, [fp, #-0x10]
    // 0xdd8458: StoreField: r3->field_f = r0
    //     0xdd8458: stur            w0, [x3, #0xf]
    // 0xdd845c: mov             x2, x3
    // 0xdd8460: r1 = Function '<anonymous closure>':.
    //     0xdd8460: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3d20] AnonymousClosure: (0xdcff14), in [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_startHideTimer (0xdcfe14)
    //     0xdd8464: ldr             x1, [x1, #0xd20]
    // 0xdd8468: r0 = AllocateClosure()
    //     0xdd8468: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd846c: ldur            x1, [fp, #-8]
    // 0xdd8470: mov             x2, x0
    // 0xdd8474: r0 = setState()
    //     0xdd8474: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xdd8478: ldur            x0, [fp, #-8]
    // 0xdd847c: LoadField: r1 = r0->field_53
    //     0xdd847c: ldur            w1, [x0, #0x53]
    // 0xdd8480: DecompressPointer r1
    //     0xdd8480: add             x1, x1, HEAP, lsl #32
    // 0xdd8484: cmp             w1, NULL
    // 0xdd8488: b.eq            #0xdd84e8
    // 0xdd848c: r0 = toggleFullScreen()
    //     0xdd848c: bl              #0xdd30a8  ; [package:chewie/src/chewie_player.dart] ChewieController::toggleFullScreen
    // 0xdd8490: ldur            x2, [fp, #-0x10]
    // 0xdd8494: r1 = Function '<anonymous closure>':.
    //     0xdd8494: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3d28] AnonymousClosure: (0xdd84ec), in [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_onExpandCollapse (0xdd8428)
    //     0xdd8498: ldr             x1, [x1, #0xd28]
    // 0xdd849c: r0 = AllocateClosure()
    //     0xdd849c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd84a0: mov             x3, x0
    // 0xdd84a4: r1 = Null
    //     0xdd84a4: mov             x1, NULL
    // 0xdd84a8: r2 = Instance_Duration
    //     0xdd84a8: ldr             x2, [PP, #0x7cd8]  ; [pp+0x7cd8] Obj!Duration@12c8971
    // 0xdd84ac: r0 = Timer()
    //     0xdd84ac: bl              #0x7eed74  ; [dart:async] Timer::Timer
    // 0xdd84b0: ldur            x1, [fp, #-8]
    // 0xdd84b4: StoreField: r1->field_33 = r0
    //     0xdd84b4: stur            w0, [x1, #0x33]
    //     0xdd84b8: ldurb           w16, [x1, #-1]
    //     0xdd84bc: ldurb           w17, [x0, #-1]
    //     0xdd84c0: and             x16, x17, x16, lsr #2
    //     0xdd84c4: tst             x16, HEAP, lsr #32
    //     0xdd84c8: b.eq            #0xdd84d0
    //     0xdd84cc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdd84d0: r0 = Null
    //     0xdd84d0: mov             x0, NULL
    // 0xdd84d4: LeaveFrame
    //     0xdd84d4: mov             SP, fp
    //     0xdd84d8: ldp             fp, lr, [SP], #0x10
    // 0xdd84dc: ret
    //     0xdd84dc: ret             
    // 0xdd84e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd84e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd84e4: b               #0xdd8444
    // 0xdd84e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd84e8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xdd84ec, size: 0x60
    // 0xdd84ec: EnterFrame
    //     0xdd84ec: stp             fp, lr, [SP, #-0x10]!
    //     0xdd84f0: mov             fp, SP
    // 0xdd84f4: AllocStack(0x8)
    //     0xdd84f4: sub             SP, SP, #8
    // 0xdd84f8: SetupParameters([dynamic _ /* r0 */])
    //     0xdd84f8: ldr             x0, [fp, #0x10]
    //     0xdd84fc: ldur            w2, [x0, #0x17]
    //     0xdd8500: add             x2, x2, HEAP, lsl #32
    // 0xdd8504: CheckStackOverflow
    //     0xdd8504: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd8508: cmp             SP, x16
    //     0xdd850c: b.ls            #0xdd8544
    // 0xdd8510: LoadField: r0 = r2->field_f
    //     0xdd8510: ldur            w0, [x2, #0xf]
    // 0xdd8514: DecompressPointer r0
    //     0xdd8514: add             x0, x0, HEAP, lsl #32
    // 0xdd8518: stur            x0, [fp, #-8]
    // 0xdd851c: r1 = Function '<anonymous closure>':.
    //     0xdd851c: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3d30] AnonymousClosure: (0xdd854c), in [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_onExpandCollapse (0xdd8428)
    //     0xdd8520: ldr             x1, [x1, #0xd30]
    // 0xdd8524: r0 = AllocateClosure()
    //     0xdd8524: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd8528: ldur            x1, [fp, #-8]
    // 0xdd852c: mov             x2, x0
    // 0xdd8530: r0 = setState()
    //     0xdd8530: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xdd8534: r0 = Null
    //     0xdd8534: mov             x0, NULL
    // 0xdd8538: LeaveFrame
    //     0xdd8538: mov             SP, fp
    //     0xdd853c: ldp             fp, lr, [SP], #0x10
    // 0xdd8540: ret
    //     0xdd8540: ret             
    // 0xdd8544: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd8544: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd8548: b               #0xdd8510
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xdd854c, size: 0x48
    // 0xdd854c: EnterFrame
    //     0xdd854c: stp             fp, lr, [SP, #-0x10]!
    //     0xdd8550: mov             fp, SP
    // 0xdd8554: ldr             x0, [fp, #0x10]
    // 0xdd8558: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdd8558: ldur            w1, [x0, #0x17]
    // 0xdd855c: DecompressPointer r1
    //     0xdd855c: add             x1, x1, HEAP, lsl #32
    // 0xdd8560: CheckStackOverflow
    //     0xdd8560: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd8564: cmp             SP, x16
    //     0xdd8568: b.ls            #0xdd858c
    // 0xdd856c: LoadField: r0 = r1->field_f
    //     0xdd856c: ldur            w0, [x1, #0xf]
    // 0xdd8570: DecompressPointer r0
    //     0xdd8570: add             x0, x0, HEAP, lsl #32
    // 0xdd8574: mov             x1, x0
    // 0xdd8578: r0 = _cancelAndRestartTimer()
    //     0xdd8578: bl              #0xdd8594  ; [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_cancelAndRestartTimer
    // 0xdd857c: r0 = Null
    //     0xdd857c: mov             x0, NULL
    // 0xdd8580: LeaveFrame
    //     0xdd8580: mov             SP, fp
    //     0xdd8584: ldp             fp, lr, [SP], #0x10
    // 0xdd8588: ret
    //     0xdd8588: ret             
    // 0xdd858c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd858c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd8590: b               #0xdd856c
  }
  _ _cancelAndRestartTimer(/* No info */) {
    // ** addr: 0xdd8594, size: 0x84
    // 0xdd8594: EnterFrame
    //     0xdd8594: stp             fp, lr, [SP, #-0x10]!
    //     0xdd8598: mov             fp, SP
    // 0xdd859c: AllocStack(0x10)
    //     0xdd859c: sub             SP, SP, #0x10
    // 0xdd85a0: SetupParameters(_MaterialDesktopControlsState this /* r1 => r1, fp-0x8 */)
    //     0xdd85a0: stur            x1, [fp, #-8]
    // 0xdd85a4: CheckStackOverflow
    //     0xdd85a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd85a8: cmp             SP, x16
    //     0xdd85ac: b.ls            #0xdd8610
    // 0xdd85b0: r1 = 1
    //     0xdd85b0: mov             x1, #1
    // 0xdd85b4: r0 = AllocateContext()
    //     0xdd85b4: bl              #0x13de838  ; AllocateContextStub
    // 0xdd85b8: mov             x2, x0
    // 0xdd85bc: ldur            x0, [fp, #-8]
    // 0xdd85c0: stur            x2, [fp, #-0x10]
    // 0xdd85c4: StoreField: r2->field_f = r0
    //     0xdd85c4: stur            w0, [x2, #0xf]
    // 0xdd85c8: LoadField: r1 = r0->field_27
    //     0xdd85c8: ldur            w1, [x0, #0x27]
    // 0xdd85cc: DecompressPointer r1
    //     0xdd85cc: add             x1, x1, HEAP, lsl #32
    // 0xdd85d0: cmp             w1, NULL
    // 0xdd85d4: b.eq            #0xdd85dc
    // 0xdd85d8: r0 = cancel()
    //     0xdd85d8: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0xdd85dc: ldur            x1, [fp, #-8]
    // 0xdd85e0: r0 = _startHideTimer()
    //     0xdd85e0: bl              #0xdcfe14  ; [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_startHideTimer
    // 0xdd85e4: ldur            x2, [fp, #-0x10]
    // 0xdd85e8: r1 = Function '<anonymous closure>':.
    //     0xdd85e8: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3d38] AnonymousClosure: (0xdd8618), in [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_cancelAndRestartTimer (0xdd8594)
    //     0xdd85ec: ldr             x1, [x1, #0xd38]
    // 0xdd85f0: r0 = AllocateClosure()
    //     0xdd85f0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd85f4: ldur            x1, [fp, #-8]
    // 0xdd85f8: mov             x2, x0
    // 0xdd85fc: r0 = setState()
    //     0xdd85fc: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xdd8600: r0 = Null
    //     0xdd8600: mov             x0, NULL
    // 0xdd8604: LeaveFrame
    //     0xdd8604: mov             SP, fp
    //     0xdd8608: ldp             fp, lr, [SP], #0x10
    // 0xdd860c: ret
    //     0xdd860c: ret             
    // 0xdd8610: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd8610: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd8614: b               #0xdd85b0
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xdd8618, size: 0x8c
    // 0xdd8618: EnterFrame
    //     0xdd8618: stp             fp, lr, [SP, #-0x10]!
    //     0xdd861c: mov             fp, SP
    // 0xdd8620: AllocStack(0x8)
    //     0xdd8620: sub             SP, SP, #8
    // 0xdd8624: SetupParameters([dynamic _ /* r1 */])
    //     0xdd8624: add             x0, NULL, #0x30  ; false
    //     0xdd8628: ldr             x1, [fp, #0x10]
    //     0xdd862c: ldur            w2, [x1, #0x17]
    //     0xdd8630: add             x2, x2, HEAP, lsl #32
    //     0xdd8634: stur            x2, [fp, #-8]
    // 0xdd8624: r0 = false
    // 0xdd8638: CheckStackOverflow
    //     0xdd8638: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd863c: cmp             SP, x16
    //     0xdd8640: b.ls            #0xdd8690
    // 0xdd8644: LoadField: r1 = r2->field_f
    //     0xdd8644: ldur            w1, [x2, #0xf]
    // 0xdd8648: DecompressPointer r1
    //     0xdd8648: add             x1, x1, HEAP, lsl #32
    // 0xdd864c: LoadField: r3 = r1->field_1b
    //     0xdd864c: ldur            w3, [x1, #0x1b]
    // 0xdd8650: DecompressPointer r3
    //     0xdd8650: add             x3, x3, HEAP, lsl #32
    // 0xdd8654: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd8658: cmp             w3, w16
    // 0xdd865c: b.eq            #0xdd8698
    // 0xdd8660: StoreField: r3->field_23 = r0
    //     0xdd8660: stur            w0, [x3, #0x23]
    // 0xdd8664: mov             x1, x3
    // 0xdd8668: r0 = notifyListeners()
    //     0xdd8668: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xdd866c: ldur            x1, [fp, #-8]
    // 0xdd8670: LoadField: r2 = r1->field_f
    //     0xdd8670: ldur            w2, [x1, #0xf]
    // 0xdd8674: DecompressPointer r2
    //     0xdd8674: add             x2, x2, HEAP, lsl #32
    // 0xdd8678: r1 = true
    //     0xdd8678: add             x1, NULL, #0x20  ; true
    // 0xdd867c: StoreField: r2->field_3b = r1
    //     0xdd867c: stur            w1, [x2, #0x3b]
    // 0xdd8680: r0 = Null
    //     0xdd8680: mov             x0, NULL
    // 0xdd8684: LeaveFrame
    //     0xdd8684: mov             SP, fp
    //     0xdd8688: ldp             fp, lr, [SP], #0x10
    // 0xdd868c: ret
    //     0xdd868c: ret             
    // 0xdd8690: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd8690: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd8694: b               #0xdd8644
    // 0xdd8698: r9 = notifier
    //     0xdd8698: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3cc8] Field <_MaterialDesktopControlsState@452377751.notifier>: late (offset: 0x1c)
    //     0xdd869c: ldr             x9, [x9, #0xcc8]
    // 0xdd86a0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd86a0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _buildOptionsButton(/* No info */) {
    // ** addr: 0xdd86a4, size: 0x270
    // 0xdd86a4: EnterFrame
    //     0xdd86a4: stp             fp, lr, [SP, #-0x10]!
    //     0xdd86a8: mov             fp, SP
    // 0xdd86ac: AllocStack(0x40)
    //     0xdd86ac: sub             SP, SP, #0x40
    // 0xdd86b0: SetupParameters(_MaterialDesktopControlsState this /* r1 => r1, fp-0x8 */)
    //     0xdd86b0: stur            x1, [fp, #-8]
    // 0xdd86b4: CheckStackOverflow
    //     0xdd86b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd86b8: cmp             SP, x16
    //     0xdd86bc: b.ls            #0xdd88ec
    // 0xdd86c0: r1 = 2
    //     0xdd86c0: mov             x1, #2
    // 0xdd86c4: r0 = AllocateContext()
    //     0xdd86c4: bl              #0x13de838  ; AllocateContextStub
    // 0xdd86c8: mov             x3, x0
    // 0xdd86cc: ldur            x0, [fp, #-8]
    // 0xdd86d0: stur            x3, [fp, #-0x18]
    // 0xdd86d4: StoreField: r3->field_f = r0
    //     0xdd86d4: stur            w0, [x3, #0xf]
    // 0xdd86d8: LoadField: r4 = r0->field_53
    //     0xdd86d8: ldur            w4, [x0, #0x53]
    // 0xdd86dc: DecompressPointer r4
    //     0xdd86dc: add             x4, x4, HEAP, lsl #32
    // 0xdd86e0: stur            x4, [fp, #-0x10]
    // 0xdd86e4: cmp             w4, NULL
    // 0xdd86e8: b.eq            #0xdd88f4
    // 0xdd86ec: mov             x2, x3
    // 0xdd86f0: r1 = Function '<anonymous closure>':.
    //     0xdd86f0: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3db0] AnonymousClosure: (0xdd8a9c), in [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_buildOptionsButton (0xdd86a4)
    //     0xdd86f4: ldr             x1, [x1, #0xdb0]
    // 0xdd86f8: r0 = AllocateClosure()
    //     0xdd86f8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd86fc: stur            x0, [fp, #-0x20]
    // 0xdd8700: r0 = OptionItem()
    //     0xdd8700: bl              #0xdd66cc  ; AllocateOptionItemStub -> OptionItem (size=0x18)
    // 0xdd8704: mov             x3, x0
    // 0xdd8708: ldur            x0, [fp, #-0x20]
    // 0xdd870c: stur            x3, [fp, #-0x28]
    // 0xdd8710: StoreField: r3->field_7 = r0
    //     0xdd8710: stur            w0, [x3, #7]
    // 0xdd8714: r0 = Instance_IconData
    //     0xdd8714: add             x0, PP, #0xd3, lsl #12  ; [pp+0xd3db8] Obj!IconData@128a631
    //     0xdd8718: ldr             x0, [x0, #0xdb8]
    // 0xdd871c: StoreField: r3->field_b = r0
    //     0xdd871c: stur            w0, [x3, #0xb]
    // 0xdd8720: r0 = "Playback speed"
    //     0xdd8720: add             x0, PP, #0xd3, lsl #12  ; [pp+0xd3dc0] "Playback speed"
    //     0xdd8724: ldr             x0, [x0, #0xdc0]
    // 0xdd8728: StoreField: r3->field_f = r0
    //     0xdd8728: stur            w0, [x3, #0xf]
    // 0xdd872c: r1 = Null
    //     0xdd872c: mov             x1, NULL
    // 0xdd8730: r2 = 2
    //     0xdd8730: mov             x2, #2
    // 0xdd8734: r0 = AllocateArray()
    //     0xdd8734: bl              #0x13df928  ; AllocateArrayStub
    // 0xdd8738: mov             x2, x0
    // 0xdd873c: ldur            x0, [fp, #-0x28]
    // 0xdd8740: stur            x2, [fp, #-0x20]
    // 0xdd8744: StoreField: r2->field_f = r0
    //     0xdd8744: stur            w0, [x2, #0xf]
    // 0xdd8748: r1 = <OptionItem>
    //     0xdd8748: add             x1, PP, #0xcf, lsl #12  ; [pp+0xcf380] TypeArguments: <OptionItem>
    //     0xdd874c: ldr             x1, [x1, #0x380]
    // 0xdd8750: r0 = AllocateGrowableArray()
    //     0xdd8750: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xdd8754: mov             x1, x0
    // 0xdd8758: ldur            x0, [fp, #-0x20]
    // 0xdd875c: stur            x1, [fp, #-0x28]
    // 0xdd8760: StoreField: r1->field_f = r0
    //     0xdd8760: stur            w0, [x1, #0xf]
    // 0xdd8764: r0 = 2
    //     0xdd8764: mov             x0, #2
    // 0xdd8768: StoreField: r1->field_b = r0
    //     0xdd8768: stur            w0, [x1, #0xb]
    // 0xdd876c: ldur            x2, [fp, #-0x18]
    // 0xdd8770: StoreField: r2->field_13 = r1
    //     0xdd8770: stur            w1, [x2, #0x13]
    // 0xdd8774: ldur            x0, [fp, #-0x10]
    // 0xdd8778: LoadField: r3 = r0->field_2f
    //     0xdd8778: ldur            w3, [x0, #0x2f]
    // 0xdd877c: DecompressPointer r3
    //     0xdd877c: add             x3, x3, HEAP, lsl #32
    // 0xdd8780: cmp             w3, NULL
    // 0xdd8784: b.eq            #0xdd880c
    // 0xdd8788: ldur            x4, [fp, #-8]
    // 0xdd878c: LoadField: r0 = r4->field_f
    //     0xdd878c: ldur            w0, [x4, #0xf]
    // 0xdd8790: DecompressPointer r0
    //     0xdd8790: add             x0, x0, HEAP, lsl #32
    // 0xdd8794: cmp             w0, NULL
    // 0xdd8798: b.eq            #0xdd88f8
    // 0xdd879c: stp             x0, x3, [SP]
    // 0xdd87a0: mov             x0, x3
    // 0xdd87a4: ClosureCall
    //     0xdd87a4: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xdd87a8: ldur            x2, [x0, #0x1f]
    //     0xdd87ac: blr             x2
    // 0xdd87b0: LoadField: r1 = r0->field_b
    //     0xdd87b0: ldur            w1, [x0, #0xb]
    // 0xdd87b4: cbz             w1, #0xdd880c
    // 0xdd87b8: ldur            x1, [fp, #-8]
    // 0xdd87bc: LoadField: r0 = r1->field_53
    //     0xdd87bc: ldur            w0, [x1, #0x53]
    // 0xdd87c0: DecompressPointer r0
    //     0xdd87c0: add             x0, x0, HEAP, lsl #32
    // 0xdd87c4: cmp             w0, NULL
    // 0xdd87c8: b.eq            #0xdd88fc
    // 0xdd87cc: LoadField: r2 = r0->field_2f
    //     0xdd87cc: ldur            w2, [x0, #0x2f]
    // 0xdd87d0: DecompressPointer r2
    //     0xdd87d0: add             x2, x2, HEAP, lsl #32
    // 0xdd87d4: cmp             w2, NULL
    // 0xdd87d8: b.eq            #0xdd8900
    // 0xdd87dc: LoadField: r0 = r1->field_f
    //     0xdd87dc: ldur            w0, [x1, #0xf]
    // 0xdd87e0: DecompressPointer r0
    //     0xdd87e0: add             x0, x0, HEAP, lsl #32
    // 0xdd87e4: cmp             w0, NULL
    // 0xdd87e8: b.eq            #0xdd8904
    // 0xdd87ec: stp             x0, x2, [SP]
    // 0xdd87f0: mov             x0, x2
    // 0xdd87f4: ClosureCall
    //     0xdd87f4: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xdd87f8: ldur            x2, [x0, #0x1f]
    //     0xdd87fc: blr             x2
    // 0xdd8800: ldur            x1, [fp, #-0x28]
    // 0xdd8804: mov             x2, x0
    // 0xdd8808: r0 = addAll()
    //     0xdd8808: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0xdd880c: ldur            x0, [fp, #-8]
    // 0xdd8810: LoadField: r1 = r0->field_1b
    //     0xdd8810: ldur            w1, [x0, #0x1b]
    // 0xdd8814: DecompressPointer r1
    //     0xdd8814: add             x1, x1, HEAP, lsl #32
    // 0xdd8818: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd881c: cmp             w1, w16
    // 0xdd8820: b.eq            #0xdd8908
    // 0xdd8824: LoadField: r0 = r1->field_23
    //     0xdd8824: ldur            w0, [x1, #0x23]
    // 0xdd8828: DecompressPointer r0
    //     0xdd8828: add             x0, x0, HEAP, lsl #32
    // 0xdd882c: tbnz            w0, #4, #0xdd8838
    // 0xdd8830: d0 = 0.000000
    //     0xdd8830: eor             v0.16b, v0.16b, v0.16b
    // 0xdd8834: b               #0xdd883c
    // 0xdd8838: d0 = 1.000000
    //     0xdd8838: fmov            d0, #1.00000000
    // 0xdd883c: stur            d0, [fp, #-0x30]
    // 0xdd8840: r0 = Icon()
    //     0xdd8840: bl              #0xd0fd5c  ; AllocateIconStub -> Icon (size=0x40)
    // 0xdd8844: mov             x1, x0
    // 0xdd8848: r0 = Instance_IconData
    //     0xdd8848: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1ae00] Obj!IconData@128a7b1
    //     0xdd884c: ldr             x0, [x0, #0xe00]
    // 0xdd8850: stur            x1, [fp, #-8]
    // 0xdd8854: StoreField: r1->field_b = r0
    //     0xdd8854: stur            w0, [x1, #0xb]
    // 0xdd8858: r0 = Instance_Color
    //     0xdd8858: add             x0, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0xdd885c: ldr             x0, [x0, #0xc38]
    // 0xdd8860: StoreField: r1->field_23 = r0
    //     0xdd8860: stur            w0, [x1, #0x23]
    // 0xdd8864: r0 = IconButton()
    //     0xdd8864: bl              #0xd16288  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0xdd8868: mov             x3, x0
    // 0xdd886c: r0 = Instance_EdgeInsets
    //     0xdd886c: ldr             x0, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0xdd8870: stur            x3, [fp, #-0x10]
    // 0xdd8874: StoreField: r3->field_13 = r0
    //     0xdd8874: stur            w0, [x3, #0x13]
    // 0xdd8878: ldur            x2, [fp, #-0x18]
    // 0xdd887c: r1 = Function '<anonymous closure>':.
    //     0xdd887c: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3dc8] AnonymousClosure: (0xdd8914), in [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_buildOptionsButton (0xdd86a4)
    //     0xdd8880: ldr             x1, [x1, #0xdc8]
    // 0xdd8884: r0 = AllocateClosure()
    //     0xdd8884: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd8888: mov             x1, x0
    // 0xdd888c: ldur            x0, [fp, #-0x10]
    // 0xdd8890: StoreField: r0->field_3b = r1
    //     0xdd8890: stur            w1, [x0, #0x3b]
    // 0xdd8894: r1 = false
    //     0xdd8894: add             x1, NULL, #0x30  ; false
    // 0xdd8898: StoreField: r0->field_4f = r1
    //     0xdd8898: stur            w1, [x0, #0x4f]
    // 0xdd889c: ldur            x2, [fp, #-8]
    // 0xdd88a0: StoreField: r0->field_1f = r2
    //     0xdd88a0: stur            w2, [x0, #0x1f]
    // 0xdd88a4: r2 = Instance__IconButtonVariant
    //     0xdd88a4: add             x2, PP, #0x17, lsl #12  ; [pp+0x177a8] Obj!_IconButtonVariant@12c57a1
    //     0xdd88a8: ldr             x2, [x2, #0x7a8]
    // 0xdd88ac: StoreField: r0->field_6f = r2
    //     0xdd88ac: stur            w2, [x0, #0x6f]
    // 0xdd88b0: r0 = AnimatedOpacity()
    //     0xdd88b0: bl              #0xd2cf50  ; AllocateAnimatedOpacityStub -> AnimatedOpacity (size=0x28)
    // 0xdd88b4: ldur            x1, [fp, #-0x10]
    // 0xdd88b8: ArrayStore: r0[0] = r1  ; List_4
    //     0xdd88b8: stur            w1, [x0, #0x17]
    // 0xdd88bc: ldur            d0, [fp, #-0x30]
    // 0xdd88c0: StoreField: r0->field_1b = d0
    //     0xdd88c0: stur            d0, [x0, #0x1b]
    // 0xdd88c4: r1 = false
    //     0xdd88c4: add             x1, NULL, #0x30  ; false
    // 0xdd88c8: StoreField: r0->field_23 = r1
    //     0xdd88c8: stur            w1, [x0, #0x23]
    // 0xdd88cc: r1 = Instance__Linear
    //     0xdd88cc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] Obj!_Linear@129fef1
    // 0xdd88d0: StoreField: r0->field_b = r1
    //     0xdd88d0: stur            w1, [x0, #0xb]
    // 0xdd88d4: r1 = Instance_Duration
    //     0xdd88d4: add             x1, PP, #0xc, lsl #12  ; [pp+0xc920] Obj!Duration@12c89c1
    //     0xdd88d8: ldr             x1, [x1, #0x920]
    // 0xdd88dc: StoreField: r0->field_f = r1
    //     0xdd88dc: stur            w1, [x0, #0xf]
    // 0xdd88e0: LeaveFrame
    //     0xdd88e0: mov             SP, fp
    //     0xdd88e4: ldp             fp, lr, [SP], #0x10
    // 0xdd88e8: ret
    //     0xdd88e8: ret             
    // 0xdd88ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd88ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd88f0: b               #0xdd86c0
    // 0xdd88f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd88f4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdd88f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd88f8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdd88fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd88fc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdd8900: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd8900: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdd8904: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd8904: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdd8908: r9 = notifier
    //     0xdd8908: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3cc8] Field <_MaterialDesktopControlsState@452377751.notifier>: late (offset: 0x1c)
    //     0xdd890c: ldr             x9, [x9, #0xcc8]
    // 0xdd8910: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd8910: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> <anonymous closure>(dynamic) async {
    // ** addr: 0xdd8914, size: 0x130
    // 0xdd8914: EnterFrame
    //     0xdd8914: stp             fp, lr, [SP, #-0x10]!
    //     0xdd8918: mov             fp, SP
    // 0xdd891c: AllocStack(0x40)
    //     0xdd891c: sub             SP, SP, #0x40
    // 0xdd8920: SetupParameters(_MaterialDesktopControlsState this /* r1 */)
    //     0xdd8920: stur            NULL, [fp, #-8]
    //     0xdd8924: mov             x0, #0
    //     0xdd8928: add             x1, fp, w0, sxtw #2
    //     0xdd892c: ldr             x1, [x1, #0x10]
    //     0xdd8930: ldur            w2, [x1, #0x17]
    //     0xdd8934: add             x2, x2, HEAP, lsl #32
    //     0xdd8938: stur            x2, [fp, #-0x10]
    // 0xdd893c: CheckStackOverflow
    //     0xdd893c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd8940: cmp             SP, x16
    //     0xdd8944: b.ls            #0xdd8a28
    // 0xdd8948: InitAsync() -> Future<void?>
    //     0xdd8948: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0xdd894c: bl              #0x7f5e44  ; InitAsyncStub
    // 0xdd8950: ldur            x2, [fp, #-0x10]
    // 0xdd8954: LoadField: r0 = r2->field_f
    //     0xdd8954: ldur            w0, [x2, #0xf]
    // 0xdd8958: DecompressPointer r0
    //     0xdd8958: add             x0, x0, HEAP, lsl #32
    // 0xdd895c: LoadField: r1 = r0->field_27
    //     0xdd895c: ldur            w1, [x0, #0x27]
    // 0xdd8960: DecompressPointer r1
    //     0xdd8960: add             x1, x1, HEAP, lsl #32
    // 0xdd8964: cmp             w1, NULL
    // 0xdd8968: b.ne            #0xdd8974
    // 0xdd896c: mov             x0, x2
    // 0xdd8970: b               #0xdd897c
    // 0xdd8974: r0 = cancel()
    //     0xdd8974: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0xdd8978: ldur            x0, [fp, #-0x10]
    // 0xdd897c: LoadField: r1 = r0->field_f
    //     0xdd897c: ldur            w1, [x0, #0xf]
    // 0xdd8980: DecompressPointer r1
    //     0xdd8980: add             x1, x1, HEAP, lsl #32
    // 0xdd8984: LoadField: r2 = r1->field_53
    //     0xdd8984: ldur            w2, [x1, #0x53]
    // 0xdd8988: DecompressPointer r2
    //     0xdd8988: add             x2, x2, HEAP, lsl #32
    // 0xdd898c: cmp             w2, NULL
    // 0xdd8990: b.eq            #0xdd8a30
    // 0xdd8994: LoadField: r3 = r1->field_f
    //     0xdd8994: ldur            w3, [x1, #0xf]
    // 0xdd8998: DecompressPointer r3
    //     0xdd8998: add             x3, x3, HEAP, lsl #32
    // 0xdd899c: stur            x3, [fp, #-0x18]
    // 0xdd89a0: cmp             w3, NULL
    // 0xdd89a4: b.eq            #0xdd8a34
    // 0xdd89a8: mov             x2, x0
    // 0xdd89ac: r1 = Function '<anonymous closure>':.
    //     0xdd89ac: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3dd0] AnonymousClosure: (0xdd8a44), in [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_buildOptionsButton (0xdd86a4)
    //     0xdd89b0: ldr             x1, [x1, #0xdd0]
    // 0xdd89b4: r0 = AllocateClosure()
    //     0xdd89b4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd89b8: r16 = <OptionItem>
    //     0xdd89b8: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf380] TypeArguments: <OptionItem>
    //     0xdd89bc: ldr             x16, [x16, #0x380]
    // 0xdd89c0: stp             x0, x16, [SP, #0x18]
    // 0xdd89c4: ldur            x16, [fp, #-0x18]
    // 0xdd89c8: r30 = true
    //     0xdd89c8: add             lr, NULL, #0x20  ; true
    // 0xdd89cc: stp             lr, x16, [SP, #8]
    // 0xdd89d0: r16 = true
    //     0xdd89d0: add             x16, NULL, #0x20  ; true
    // 0xdd89d4: str             x16, [SP]
    // 0xdd89d8: r4 = const [0x1, 0x4, 0x4, 0x2, isScrollControlled, 0x2, useRootNavigator, 0x3, null]
    //     0xdd89d8: add             x4, PP, #0xd3, lsl #12  ; [pp+0xd3dd8] List(9) [0x1, 0x4, 0x4, 0x2, "isScrollControlled", 0x2, "useRootNavigator", 0x3, Null]
    //     0xdd89dc: ldr             x4, [x4, #0xdd8]
    // 0xdd89e0: r0 = showModalBottomSheet()
    //     0xdd89e0: bl              #0xdd5dfc  ; [package:flutter/src/material/bottom_sheet.dart] ::showModalBottomSheet
    // 0xdd89e4: mov             x1, x0
    // 0xdd89e8: stur            x1, [fp, #-0x18]
    // 0xdd89ec: r0 = Await()
    //     0xdd89ec: bl              #0x7f5c00  ; AwaitStub
    // 0xdd89f0: ldur            x0, [fp, #-0x10]
    // 0xdd89f4: LoadField: r1 = r0->field_f
    //     0xdd89f4: ldur            w1, [x0, #0xf]
    // 0xdd89f8: DecompressPointer r1
    //     0xdd89f8: add             x1, x1, HEAP, lsl #32
    // 0xdd89fc: LoadField: r0 = r1->field_1f
    //     0xdd89fc: ldur            w0, [x1, #0x1f]
    // 0xdd8a00: DecompressPointer r0
    //     0xdd8a00: add             x0, x0, HEAP, lsl #32
    // 0xdd8a04: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd8a08: cmp             w0, w16
    // 0xdd8a0c: b.eq            #0xdd8a38
    // 0xdd8a10: LoadField: r2 = r0->field_1b
    //     0xdd8a10: ldur            w2, [x0, #0x1b]
    // 0xdd8a14: DecompressPointer r2
    //     0xdd8a14: add             x2, x2, HEAP, lsl #32
    // 0xdd8a18: tbnz            w2, #4, #0xdd8a20
    // 0xdd8a1c: r0 = _startHideTimer()
    //     0xdd8a1c: bl              #0xdcfe14  ; [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_startHideTimer
    // 0xdd8a20: r0 = Null
    //     0xdd8a20: mov             x0, NULL
    // 0xdd8a24: r0 = ReturnAsyncNotFuture()
    //     0xdd8a24: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xdd8a28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd8a28: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd8a2c: b               #0xdd8948
    // 0xdd8a30: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd8a30: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdd8a34: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd8a34: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdd8a38: r9 = _latestValue
    //     0xdd8a38: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3d10] Field <_MaterialDesktopControlsState@452377751._latestValue@452377751>: late (offset: 0x20)
    //     0xdd8a3c: ldr             x9, [x9, #0xd10]
    // 0xdd8a40: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd8a40: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] OptionsDialog <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0xdd8a44, size: 0x58
    // 0xdd8a44: EnterFrame
    //     0xdd8a44: stp             fp, lr, [SP, #-0x10]!
    //     0xdd8a48: mov             fp, SP
    // 0xdd8a4c: AllocStack(0x8)
    //     0xdd8a4c: sub             SP, SP, #8
    // 0xdd8a50: SetupParameters([dynamic _ /* r0 */])
    //     0xdd8a50: ldr             x0, [fp, #0x18]
    //     0xdd8a54: ldur            w1, [x0, #0x17]
    //     0xdd8a58: add             x1, x1, HEAP, lsl #32
    // 0xdd8a5c: LoadField: r0 = r1->field_f
    //     0xdd8a5c: ldur            w0, [x1, #0xf]
    // 0xdd8a60: DecompressPointer r0
    //     0xdd8a60: add             x0, x0, HEAP, lsl #32
    // 0xdd8a64: LoadField: r2 = r0->field_53
    //     0xdd8a64: ldur            w2, [x0, #0x53]
    // 0xdd8a68: DecompressPointer r2
    //     0xdd8a68: add             x2, x2, HEAP, lsl #32
    // 0xdd8a6c: cmp             w2, NULL
    // 0xdd8a70: b.eq            #0xdd8a98
    // 0xdd8a74: LoadField: r0 = r1->field_13
    //     0xdd8a74: ldur            w0, [x1, #0x13]
    // 0xdd8a78: DecompressPointer r0
    //     0xdd8a78: add             x0, x0, HEAP, lsl #32
    // 0xdd8a7c: stur            x0, [fp, #-8]
    // 0xdd8a80: r0 = OptionsDialog()
    //     0xdd8a80: bl              #0xdd6538  ; AllocateOptionsDialogStub -> OptionsDialog (size=0x14)
    // 0xdd8a84: ldur            x1, [fp, #-8]
    // 0xdd8a88: StoreField: r0->field_b = r1
    //     0xdd8a88: stur            w1, [x0, #0xb]
    // 0xdd8a8c: LeaveFrame
    //     0xdd8a8c: mov             SP, fp
    //     0xdd8a90: ldp             fp, lr, [SP], #0x10
    // 0xdd8a94: ret
    //     0xdd8a94: ret             
    // 0xdd8a98: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd8a98: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> <anonymous closure>(dynamic, BuildContext) async {
    // ** addr: 0xdd8a9c, size: 0x7c
    // 0xdd8a9c: EnterFrame
    //     0xdd8a9c: stp             fp, lr, [SP, #-0x10]!
    //     0xdd8aa0: mov             fp, SP
    // 0xdd8aa4: AllocStack(0x28)
    //     0xdd8aa4: sub             SP, SP, #0x28
    // 0xdd8aa8: SetupParameters(_MaterialDesktopControlsState this /* r1 */, dynamic _ /* r2, fp-0x18 */)
    //     0xdd8aa8: stur            NULL, [fp, #-8]
    //     0xdd8aac: mov             x0, #0
    //     0xdd8ab0: add             x1, fp, w0, sxtw #2
    //     0xdd8ab4: ldr             x1, [x1, #0x18]
    //     0xdd8ab8: add             x2, fp, w0, sxtw #2
    //     0xdd8abc: ldr             x2, [x2, #0x10]
    //     0xdd8ac0: stur            x2, [fp, #-0x18]
    //     0xdd8ac4: ldur            w3, [x1, #0x17]
    //     0xdd8ac8: add             x3, x3, HEAP, lsl #32
    //     0xdd8acc: stur            x3, [fp, #-0x10]
    // 0xdd8ad0: CheckStackOverflow
    //     0xdd8ad0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd8ad4: cmp             SP, x16
    //     0xdd8ad8: b.ls            #0xdd8b10
    // 0xdd8adc: InitAsync() -> Future<void?>
    //     0xdd8adc: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0xdd8ae0: bl              #0x7f5e44  ; InitAsyncStub
    // 0xdd8ae4: r16 = <Object?>
    //     0xdd8ae4: ldr             x16, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0xdd8ae8: ldur            lr, [fp, #-0x18]
    // 0xdd8aec: stp             lr, x16, [SP]
    // 0xdd8af0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdd8af0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdd8af4: r0 = pop()
    //     0xdd8af4: bl              #0xd190ec  ; [package:flutter/src/widgets/navigator.dart] Navigator::pop
    // 0xdd8af8: ldur            x0, [fp, #-0x10]
    // 0xdd8afc: LoadField: r1 = r0->field_f
    //     0xdd8afc: ldur            w1, [x0, #0xf]
    // 0xdd8b00: DecompressPointer r1
    //     0xdd8b00: add             x1, x1, HEAP, lsl #32
    // 0xdd8b04: r0 = _onSpeedButtonTap()
    //     0xdd8b04: bl              #0xdd8b18  ; [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_onSpeedButtonTap
    // 0xdd8b08: r0 = Null
    //     0xdd8b08: mov             x0, NULL
    // 0xdd8b0c: r0 = ReturnAsyncNotFuture()
    //     0xdd8b0c: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xdd8b10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd8b10: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd8b14: b               #0xdd8adc
  }
  _ _onSpeedButtonTap(/* No info */) async {
    // ** addr: 0xdd8b18, size: 0x144
    // 0xdd8b18: EnterFrame
    //     0xdd8b18: stp             fp, lr, [SP, #-0x10]!
    //     0xdd8b1c: mov             fp, SP
    // 0xdd8b20: AllocStack(0x48)
    //     0xdd8b20: sub             SP, SP, #0x48
    // 0xdd8b24: SetupParameters(_MaterialDesktopControlsState this /* r1 => r1, fp-0x10 */)
    //     0xdd8b24: stur            NULL, [fp, #-8]
    //     0xdd8b28: stur            x1, [fp, #-0x10]
    // 0xdd8b2c: CheckStackOverflow
    //     0xdd8b2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd8b30: cmp             SP, x16
    //     0xdd8b34: b.ls            #0xdd8c34
    // 0xdd8b38: r1 = 1
    //     0xdd8b38: mov             x1, #1
    // 0xdd8b3c: r0 = AllocateContext()
    //     0xdd8b3c: bl              #0x13de838  ; AllocateContextStub
    // 0xdd8b40: mov             x2, x0
    // 0xdd8b44: ldur            x1, [fp, #-0x10]
    // 0xdd8b48: stur            x2, [fp, #-0x18]
    // 0xdd8b4c: StoreField: r2->field_f = r1
    //     0xdd8b4c: stur            w1, [x2, #0xf]
    // 0xdd8b50: InitAsync() -> Future<void?>
    //     0xdd8b50: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0xdd8b54: bl              #0x7f5e44  ; InitAsyncStub
    // 0xdd8b58: ldur            x0, [fp, #-0x10]
    // 0xdd8b5c: LoadField: r1 = r0->field_27
    //     0xdd8b5c: ldur            w1, [x0, #0x27]
    // 0xdd8b60: DecompressPointer r1
    //     0xdd8b60: add             x1, x1, HEAP, lsl #32
    // 0xdd8b64: cmp             w1, NULL
    // 0xdd8b68: b.eq            #0xdd8b74
    // 0xdd8b6c: r0 = cancel()
    //     0xdd8b6c: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0xdd8b70: ldur            x0, [fp, #-0x10]
    // 0xdd8b74: LoadField: r3 = r0->field_f
    //     0xdd8b74: ldur            w3, [x0, #0xf]
    // 0xdd8b78: DecompressPointer r3
    //     0xdd8b78: add             x3, x3, HEAP, lsl #32
    // 0xdd8b7c: stur            x3, [fp, #-0x20]
    // 0xdd8b80: cmp             w3, NULL
    // 0xdd8b84: b.eq            #0xdd8c3c
    // 0xdd8b88: LoadField: r1 = r0->field_53
    //     0xdd8b88: ldur            w1, [x0, #0x53]
    // 0xdd8b8c: DecompressPointer r1
    //     0xdd8b8c: add             x1, x1, HEAP, lsl #32
    // 0xdd8b90: cmp             w1, NULL
    // 0xdd8b94: b.eq            #0xdd8c40
    // 0xdd8b98: ldur            x2, [fp, #-0x18]
    // 0xdd8b9c: r1 = Function '<anonymous closure>':.
    //     0xdd8b9c: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3de0] AnonymousClosure: (0xdd8c5c), in [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_onSpeedButtonTap (0xdd8b18)
    //     0xdd8ba0: ldr             x1, [x1, #0xde0]
    // 0xdd8ba4: r0 = AllocateClosure()
    //     0xdd8ba4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd8ba8: r16 = <double>
    //     0xdd8ba8: ldr             x16, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xdd8bac: stp             x0, x16, [SP, #0x18]
    // 0xdd8bb0: ldur            x16, [fp, #-0x20]
    // 0xdd8bb4: r30 = true
    //     0xdd8bb4: add             lr, NULL, #0x20  ; true
    // 0xdd8bb8: stp             lr, x16, [SP, #8]
    // 0xdd8bbc: r16 = true
    //     0xdd8bbc: add             x16, NULL, #0x20  ; true
    // 0xdd8bc0: str             x16, [SP]
    // 0xdd8bc4: r4 = const [0x1, 0x4, 0x4, 0x2, isScrollControlled, 0x2, useRootNavigator, 0x3, null]
    //     0xdd8bc4: add             x4, PP, #0xd3, lsl #12  ; [pp+0xd3dd8] List(9) [0x1, 0x4, 0x4, 0x2, "isScrollControlled", 0x2, "useRootNavigator", 0x3, Null]
    //     0xdd8bc8: ldr             x4, [x4, #0xdd8]
    // 0xdd8bcc: r0 = showModalBottomSheet()
    //     0xdd8bcc: bl              #0xdd5dfc  ; [package:flutter/src/material/bottom_sheet.dart] ::showModalBottomSheet
    // 0xdd8bd0: mov             x1, x0
    // 0xdd8bd4: stur            x1, [fp, #-0x20]
    // 0xdd8bd8: r0 = Await()
    //     0xdd8bd8: bl              #0x7f5c00  ; AwaitStub
    // 0xdd8bdc: cmp             w0, NULL
    // 0xdd8be0: b.eq            #0xdd8c04
    // 0xdd8be4: ldur            x2, [fp, #-0x10]
    // 0xdd8be8: LoadField: r1 = r2->field_4f
    //     0xdd8be8: ldur            w1, [x2, #0x4f]
    // 0xdd8bec: DecompressPointer r1
    //     0xdd8bec: add             x1, x1, HEAP, lsl #32
    // 0xdd8bf0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd8bf4: cmp             w1, w16
    // 0xdd8bf8: b.eq            #0xdd8c44
    // 0xdd8bfc: LoadField: d0 = r0->field_7
    //     0xdd8bfc: ldur            d0, [x0, #7]
    // 0xdd8c00: r0 = setPlaybackSpeed()
    //     0xdd8c00: bl              #0xdcf0e8  ; [package:video_player/video_player.dart] VideoPlayerController::setPlaybackSpeed
    // 0xdd8c04: ldur            x1, [fp, #-0x10]
    // 0xdd8c08: LoadField: r0 = r1->field_1f
    //     0xdd8c08: ldur            w0, [x1, #0x1f]
    // 0xdd8c0c: DecompressPointer r0
    //     0xdd8c0c: add             x0, x0, HEAP, lsl #32
    // 0xdd8c10: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd8c14: cmp             w0, w16
    // 0xdd8c18: b.eq            #0xdd8c50
    // 0xdd8c1c: LoadField: r2 = r0->field_1b
    //     0xdd8c1c: ldur            w2, [x0, #0x1b]
    // 0xdd8c20: DecompressPointer r2
    //     0xdd8c20: add             x2, x2, HEAP, lsl #32
    // 0xdd8c24: tbnz            w2, #4, #0xdd8c2c
    // 0xdd8c28: r0 = _startHideTimer()
    //     0xdd8c28: bl              #0xdcfe14  ; [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_startHideTimer
    // 0xdd8c2c: r0 = Null
    //     0xdd8c2c: mov             x0, NULL
    // 0xdd8c30: r0 = ReturnAsyncNotFuture()
    //     0xdd8c30: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xdd8c34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd8c34: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd8c38: b               #0xdd8b38
    // 0xdd8c3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd8c3c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdd8c40: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd8c40: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdd8c44: r9 = controller
    //     0xdd8c44: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3cb8] Field <_MaterialDesktopControlsState@452377751.controller>: late (offset: 0x50)
    //     0xdd8c48: ldr             x9, [x9, #0xcb8]
    // 0xdd8c4c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd8c4c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdd8c50: r9 = _latestValue
    //     0xdd8c50: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3d10] Field <_MaterialDesktopControlsState@452377751._latestValue@452377751>: late (offset: 0x20)
    //     0xdd8c54: ldr             x9, [x9, #0xd10]
    // 0xdd8c58: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd8c58: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] PlaybackSpeedDialog <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0xdd8c5c, size: 0x80
    // 0xdd8c5c: EnterFrame
    //     0xdd8c5c: stp             fp, lr, [SP, #-0x10]!
    //     0xdd8c60: mov             fp, SP
    // 0xdd8c64: AllocStack(0x8)
    //     0xdd8c64: sub             SP, SP, #8
    // 0xdd8c68: SetupParameters([dynamic _ /* r0 */])
    //     0xdd8c68: ldr             x0, [fp, #0x18]
    //     0xdd8c6c: ldur            w1, [x0, #0x17]
    //     0xdd8c70: add             x1, x1, HEAP, lsl #32
    // 0xdd8c74: LoadField: r0 = r1->field_f
    //     0xdd8c74: ldur            w0, [x1, #0xf]
    // 0xdd8c78: DecompressPointer r0
    //     0xdd8c78: add             x0, x0, HEAP, lsl #32
    // 0xdd8c7c: LoadField: r1 = r0->field_53
    //     0xdd8c7c: ldur            w1, [x0, #0x53]
    // 0xdd8c80: DecompressPointer r1
    //     0xdd8c80: add             x1, x1, HEAP, lsl #32
    // 0xdd8c84: cmp             w1, NULL
    // 0xdd8c88: b.eq            #0xdd8ccc
    // 0xdd8c8c: LoadField: r1 = r0->field_1f
    //     0xdd8c8c: ldur            w1, [x0, #0x1f]
    // 0xdd8c90: DecompressPointer r1
    //     0xdd8c90: add             x1, x1, HEAP, lsl #32
    // 0xdd8c94: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd8c98: cmp             w1, w16
    // 0xdd8c9c: b.eq            #0xdd8cd0
    // 0xdd8ca0: LoadField: d0 = r1->field_2f
    //     0xdd8ca0: ldur            d0, [x1, #0x2f]
    // 0xdd8ca4: stur            d0, [fp, #-8]
    // 0xdd8ca8: r0 = PlaybackSpeedDialog()
    //     0xdd8ca8: bl              #0xdd6918  ; AllocatePlaybackSpeedDialogStub -> PlaybackSpeedDialog (size=0x18)
    // 0xdd8cac: r1 = const [0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0]
    //     0xdd8cac: add             x1, PP, #0xa5, lsl #12  ; [pp+0xa5f68] List<double>(8)
    //     0xdd8cb0: ldr             x1, [x1, #0xf68]
    // 0xdd8cb4: StoreField: r0->field_b = r1
    //     0xdd8cb4: stur            w1, [x0, #0xb]
    // 0xdd8cb8: ldur            d0, [fp, #-8]
    // 0xdd8cbc: StoreField: r0->field_f = d0
    //     0xdd8cbc: stur            d0, [x0, #0xf]
    // 0xdd8cc0: LeaveFrame
    //     0xdd8cc0: mov             SP, fp
    //     0xdd8cc4: ldp             fp, lr, [SP], #0x10
    // 0xdd8cc8: ret
    //     0xdd8cc8: ret             
    // 0xdd8ccc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd8ccc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdd8cd0: r9 = _latestValue
    //     0xdd8cd0: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3d10] Field <_MaterialDesktopControlsState@452377751._latestValue@452377751>: late (offset: 0x20)
    //     0xdd8cd4: ldr             x9, [x9, #0xd10]
    // 0xdd8cd8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd8cd8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _buildPosition(/* No info */) {
    // ** addr: 0xdd8cdc, size: 0xe8
    // 0xdd8cdc: EnterFrame
    //     0xdd8cdc: stp             fp, lr, [SP, #-0x10]!
    //     0xdd8ce0: mov             fp, SP
    // 0xdd8ce4: AllocStack(0x20)
    //     0xdd8ce4: sub             SP, SP, #0x20
    // 0xdd8ce8: CheckStackOverflow
    //     0xdd8ce8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd8cec: cmp             SP, x16
    //     0xdd8cf0: b.ls            #0xdd8db0
    // 0xdd8cf4: LoadField: r0 = r1->field_1f
    //     0xdd8cf4: ldur            w0, [x1, #0x1f]
    // 0xdd8cf8: DecompressPointer r0
    //     0xdd8cf8: add             x0, x0, HEAP, lsl #32
    // 0xdd8cfc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd8d00: cmp             w0, w16
    // 0xdd8d04: b.eq            #0xdd8db8
    // 0xdd8d08: LoadField: r1 = r0->field_b
    //     0xdd8d08: ldur            w1, [x0, #0xb]
    // 0xdd8d0c: DecompressPointer r1
    //     0xdd8d0c: add             x1, x1, HEAP, lsl #32
    // 0xdd8d10: LoadField: r2 = r0->field_7
    //     0xdd8d10: ldur            w2, [x0, #7]
    // 0xdd8d14: DecompressPointer r2
    //     0xdd8d14: add             x2, x2, HEAP, lsl #32
    // 0xdd8d18: stur            x2, [fp, #-8]
    // 0xdd8d1c: r0 = formatDuration()
    //     0xdd8d1c: bl              #0xdcf474  ; [package:chewie/src/helpers/utils.dart] ::formatDuration
    // 0xdd8d20: r1 = Null
    //     0xdd8d20: mov             x1, NULL
    // 0xdd8d24: r2 = 6
    //     0xdd8d24: mov             x2, #6
    // 0xdd8d28: stur            x0, [fp, #-0x10]
    // 0xdd8d2c: r0 = AllocateArray()
    //     0xdd8d2c: bl              #0x13df928  ; AllocateArrayStub
    // 0xdd8d30: mov             x2, x0
    // 0xdd8d34: ldur            x0, [fp, #-0x10]
    // 0xdd8d38: stur            x2, [fp, #-0x18]
    // 0xdd8d3c: StoreField: r2->field_f = r0
    //     0xdd8d3c: stur            w0, [x2, #0xf]
    // 0xdd8d40: r16 = " / "
    //     0xdd8d40: add             x16, PP, #0x28, lsl #12  ; [pp+0x288d0] " / "
    //     0xdd8d44: ldr             x16, [x16, #0x8d0]
    // 0xdd8d48: StoreField: r2->field_13 = r16
    //     0xdd8d48: stur            w16, [x2, #0x13]
    // 0xdd8d4c: ldur            x1, [fp, #-8]
    // 0xdd8d50: r0 = formatDuration()
    //     0xdd8d50: bl              #0xdcf474  ; [package:chewie/src/helpers/utils.dart] ::formatDuration
    // 0xdd8d54: ldur            x1, [fp, #-0x18]
    // 0xdd8d58: ArrayStore: r1[2] = r0  ; List_4
    //     0xdd8d58: add             x25, x1, #0x17
    //     0xdd8d5c: str             w0, [x25]
    //     0xdd8d60: tbz             w0, #0, #0xdd8d7c
    //     0xdd8d64: ldurb           w16, [x1, #-1]
    //     0xdd8d68: ldurb           w17, [x0, #-1]
    //     0xdd8d6c: and             x16, x17, x16, lsr #2
    //     0xdd8d70: tst             x16, HEAP, lsr #32
    //     0xdd8d74: b.eq            #0xdd8d7c
    //     0xdd8d78: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdd8d7c: ldur            x16, [fp, #-0x18]
    // 0xdd8d80: str             x16, [SP]
    // 0xdd8d84: r0 = _interpolate()
    //     0xdd8d84: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xdd8d88: stur            x0, [fp, #-8]
    // 0xdd8d8c: r0 = Text()
    //     0xdd8d8c: bl              #0x8a70a4  ; AllocateTextStub -> Text (size=0x50)
    // 0xdd8d90: ldur            x1, [fp, #-8]
    // 0xdd8d94: StoreField: r0->field_b = r1
    //     0xdd8d94: stur            w1, [x0, #0xb]
    // 0xdd8d98: r1 = Instance_TextStyle
    //     0xdd8d98: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f5d0] Obj!TextStyle@12b0bd1
    //     0xdd8d9c: ldr             x1, [x1, #0x5d0]
    // 0xdd8da0: StoreField: r0->field_13 = r1
    //     0xdd8da0: stur            w1, [x0, #0x13]
    // 0xdd8da4: LeaveFrame
    //     0xdd8da4: mov             SP, fp
    //     0xdd8da8: ldp             fp, lr, [SP], #0x10
    // 0xdd8dac: ret
    //     0xdd8dac: ret             
    // 0xdd8db0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd8db0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd8db4: b               #0xdd8cf4
    // 0xdd8db8: r9 = _latestValue
    //     0xdd8db8: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3d10] Field <_MaterialDesktopControlsState@452377751._latestValue@452377751>: late (offset: 0x20)
    //     0xdd8dbc: ldr             x9, [x9, #0xd10]
    // 0xdd8dc0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd8dc0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _buildMuteButton(/* No info */) {
    // ** addr: 0xdd8dc4, size: 0x204
    // 0xdd8dc4: EnterFrame
    //     0xdd8dc4: stp             fp, lr, [SP, #-0x10]!
    //     0xdd8dc8: mov             fp, SP
    // 0xdd8dcc: AllocStack(0x48)
    //     0xdd8dcc: sub             SP, SP, #0x48
    // 0xdd8dd0: SetupParameters(_MaterialDesktopControlsState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xdd8dd0: stur            x1, [fp, #-8]
    //     0xdd8dd4: stur            x2, [fp, #-0x10]
    // 0xdd8dd8: CheckStackOverflow
    //     0xdd8dd8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd8ddc: cmp             SP, x16
    //     0xdd8de0: b.ls            #0xdd8f90
    // 0xdd8de4: r1 = 2
    //     0xdd8de4: mov             x1, #2
    // 0xdd8de8: r0 = AllocateContext()
    //     0xdd8de8: bl              #0x13de838  ; AllocateContextStub
    // 0xdd8dec: mov             x1, x0
    // 0xdd8df0: ldur            x0, [fp, #-8]
    // 0xdd8df4: stur            x1, [fp, #-0x18]
    // 0xdd8df8: StoreField: r1->field_f = r0
    //     0xdd8df8: stur            w0, [x1, #0xf]
    // 0xdd8dfc: ldur            x2, [fp, #-0x10]
    // 0xdd8e00: StoreField: r1->field_13 = r2
    //     0xdd8e00: stur            w2, [x1, #0x13]
    // 0xdd8e04: LoadField: r2 = r0->field_1b
    //     0xdd8e04: ldur            w2, [x0, #0x1b]
    // 0xdd8e08: DecompressPointer r2
    //     0xdd8e08: add             x2, x2, HEAP, lsl #32
    // 0xdd8e0c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd8e10: cmp             w2, w16
    // 0xdd8e14: b.eq            #0xdd8f98
    // 0xdd8e18: LoadField: r3 = r2->field_23
    //     0xdd8e18: ldur            w3, [x2, #0x23]
    // 0xdd8e1c: DecompressPointer r3
    //     0xdd8e1c: add             x3, x3, HEAP, lsl #32
    // 0xdd8e20: tbnz            w3, #4, #0xdd8e2c
    // 0xdd8e24: d1 = 0.000000
    //     0xdd8e24: eor             v1.16b, v1.16b, v1.16b
    // 0xdd8e28: b               #0xdd8e30
    // 0xdd8e2c: d1 = 1.000000
    //     0xdd8e2c: fmov            d1, #1.00000000
    // 0xdd8e30: d0 = 0.000000
    //     0xdd8e30: eor             v0.16b, v0.16b, v0.16b
    // 0xdd8e34: stur            d1, [fp, #-0x30]
    // 0xdd8e38: LoadField: d2 = r0->field_47
    //     0xdd8e38: ldur            d2, [x0, #0x47]
    // 0xdd8e3c: stur            d2, [fp, #-0x28]
    // 0xdd8e40: LoadField: r2 = r0->field_1f
    //     0xdd8e40: ldur            w2, [x0, #0x1f]
    // 0xdd8e44: DecompressPointer r2
    //     0xdd8e44: add             x2, x2, HEAP, lsl #32
    // 0xdd8e48: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd8e4c: cmp             w2, w16
    // 0xdd8e50: b.eq            #0xdd8fa4
    // 0xdd8e54: LoadField: d3 = r2->field_27
    //     0xdd8e54: ldur            d3, [x2, #0x27]
    // 0xdd8e58: fcmp            d3, d0
    // 0xdd8e5c: b.le            #0xdd8e6c
    // 0xdd8e60: r0 = Instance_IconData
    //     0xdd8e60: add             x0, PP, #0xd3, lsl #12  ; [pp+0xd3e00] Obj!IconData@128a6b1
    //     0xdd8e64: ldr             x0, [x0, #0xe00]
    // 0xdd8e68: b               #0xdd8e74
    // 0xdd8e6c: r0 = Instance_IconData
    //     0xdd8e6c: add             x0, PP, #0xd3, lsl #12  ; [pp+0xd3e08] Obj!IconData@128a691
    //     0xdd8e70: ldr             x0, [x0, #0xe08]
    // 0xdd8e74: stur            x0, [fp, #-8]
    // 0xdd8e78: r0 = Icon()
    //     0xdd8e78: bl              #0xd0fd5c  ; AllocateIconStub -> Icon (size=0x40)
    // 0xdd8e7c: mov             x1, x0
    // 0xdd8e80: ldur            x0, [fp, #-8]
    // 0xdd8e84: stur            x1, [fp, #-0x10]
    // 0xdd8e88: StoreField: r1->field_b = r0
    //     0xdd8e88: stur            w0, [x1, #0xb]
    // 0xdd8e8c: r0 = Instance_Color
    //     0xdd8e8c: add             x0, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0xdd8e90: ldr             x0, [x0, #0xc38]
    // 0xdd8e94: StoreField: r1->field_23 = r0
    //     0xdd8e94: stur            w0, [x1, #0x23]
    // 0xdd8e98: ldur            d0, [fp, #-0x28]
    // 0xdd8e9c: r0 = inline_Allocate_Double()
    //     0xdd8e9c: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xdd8ea0: add             x0, x0, #0x10
    //     0xdd8ea4: cmp             x2, x0
    //     0xdd8ea8: b.ls            #0xdd8fb0
    //     0xdd8eac: str             x0, [THR, #0x60]  ; THR::top
    //     0xdd8eb0: sub             x0, x0, #0xf
    //     0xdd8eb4: mov             x2, #0xe19c
    //     0xdd8eb8: movk            x2, #3, lsl #16
    //     0xdd8ebc: stur            x2, [x0, #-1]
    // 0xdd8ec0: dmb             ishst
    // 0xdd8ec4: StoreField: r0->field_7 = d0
    //     0xdd8ec4: stur            d0, [x0, #7]
    // 0xdd8ec8: stur            x0, [fp, #-8]
    // 0xdd8ecc: r0 = Container()
    //     0xdd8ecc: bl              #0x8a5af8  ; AllocateContainerStub -> Container (size=0x38)
    // 0xdd8ed0: stur            x0, [fp, #-0x20]
    // 0xdd8ed4: ldur            x16, [fp, #-8]
    // 0xdd8ed8: r30 = Instance_EdgeInsets
    //     0xdd8ed8: add             lr, PP, #0xd3, lsl #12  ; [pp+0xd3e10] Obj!EdgeInsets@129d441
    //     0xdd8edc: ldr             lr, [lr, #0xe10]
    // 0xdd8ee0: stp             lr, x16, [SP, #8]
    // 0xdd8ee4: ldur            x16, [fp, #-0x10]
    // 0xdd8ee8: str             x16, [SP]
    // 0xdd8eec: mov             x1, x0
    // 0xdd8ef0: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, height, 0x1, padding, 0x2, null]
    //     0xdd8ef0: add             x4, PP, #0x91, lsl #12  ; [pp+0x91970] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "height", 0x1, "padding", 0x2, Null]
    //     0xdd8ef4: ldr             x4, [x4, #0x970]
    // 0xdd8ef8: r0 = Container()
    //     0xdd8ef8: bl              #0x8a54e0  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0xdd8efc: r0 = ClipRect()
    //     0xdd8efc: bl              #0xd5c118  ; AllocateClipRectStub -> ClipRect (size=0x18)
    // 0xdd8f00: mov             x1, x0
    // 0xdd8f04: r0 = Instance_Clip
    //     0xdd8f04: add             x0, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xdd8f08: ldr             x0, [x0, #0x850]
    // 0xdd8f0c: stur            x1, [fp, #-8]
    // 0xdd8f10: StoreField: r1->field_13 = r0
    //     0xdd8f10: stur            w0, [x1, #0x13]
    // 0xdd8f14: ldur            x0, [fp, #-0x20]
    // 0xdd8f18: StoreField: r1->field_b = r0
    //     0xdd8f18: stur            w0, [x1, #0xb]
    // 0xdd8f1c: r0 = AnimatedOpacity()
    //     0xdd8f1c: bl              #0xd2cf50  ; AllocateAnimatedOpacityStub -> AnimatedOpacity (size=0x28)
    // 0xdd8f20: mov             x1, x0
    // 0xdd8f24: ldur            x0, [fp, #-8]
    // 0xdd8f28: stur            x1, [fp, #-0x10]
    // 0xdd8f2c: ArrayStore: r1[0] = r0  ; List_4
    //     0xdd8f2c: stur            w0, [x1, #0x17]
    // 0xdd8f30: ldur            d0, [fp, #-0x30]
    // 0xdd8f34: StoreField: r1->field_1b = d0
    //     0xdd8f34: stur            d0, [x1, #0x1b]
    // 0xdd8f38: r0 = false
    //     0xdd8f38: add             x0, NULL, #0x30  ; false
    // 0xdd8f3c: StoreField: r1->field_23 = r0
    //     0xdd8f3c: stur            w0, [x1, #0x23]
    // 0xdd8f40: r0 = Instance__Linear
    //     0xdd8f40: ldr             x0, [PP, #0x5168]  ; [pp+0x5168] Obj!_Linear@129fef1
    // 0xdd8f44: StoreField: r1->field_b = r0
    //     0xdd8f44: stur            w0, [x1, #0xb]
    // 0xdd8f48: r0 = Instance_Duration
    //     0xdd8f48: ldr             x0, [PP, #0x7cd8]  ; [pp+0x7cd8] Obj!Duration@12c8971
    // 0xdd8f4c: StoreField: r1->field_f = r0
    //     0xdd8f4c: stur            w0, [x1, #0xf]
    // 0xdd8f50: r0 = GestureDetector()
    //     0xdd8f50: bl              #0x918e18  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0xdd8f54: ldur            x2, [fp, #-0x18]
    // 0xdd8f58: r1 = Function '<anonymous closure>':.
    //     0xdd8f58: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3e18] AnonymousClosure: (0xdd8fc8), in [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_buildMuteButton (0xdd8dc4)
    //     0xdd8f5c: ldr             x1, [x1, #0xe18]
    // 0xdd8f60: stur            x0, [fp, #-8]
    // 0xdd8f64: r0 = AllocateClosure()
    //     0xdd8f64: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd8f68: ldur            x16, [fp, #-0x10]
    // 0xdd8f6c: stp             x16, x0, [SP]
    // 0xdd8f70: ldur            x1, [fp, #-8]
    // 0xdd8f74: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0xdd8f74: add             x4, PP, #0x16, lsl #12  ; [pp+0x16e90] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0xdd8f78: ldr             x4, [x4, #0xe90]
    // 0xdd8f7c: r0 = GestureDetector()
    //     0xdd8f7c: bl              #0x9182dc  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0xdd8f80: ldur            x0, [fp, #-8]
    // 0xdd8f84: LeaveFrame
    //     0xdd8f84: mov             SP, fp
    //     0xdd8f88: ldp             fp, lr, [SP], #0x10
    // 0xdd8f8c: ret
    //     0xdd8f8c: ret             
    // 0xdd8f90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd8f90: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd8f94: b               #0xdd8de4
    // 0xdd8f98: r9 = notifier
    //     0xdd8f98: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3cc8] Field <_MaterialDesktopControlsState@452377751.notifier>: late (offset: 0x1c)
    //     0xdd8f9c: ldr             x9, [x9, #0xcc8]
    // 0xdd8fa0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd8fa0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdd8fa4: r9 = _latestValue
    //     0xdd8fa4: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3d10] Field <_MaterialDesktopControlsState@452377751._latestValue@452377751>: late (offset: 0x20)
    //     0xdd8fa8: ldr             x9, [x9, #0xd10]
    // 0xdd8fac: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xdd8fac: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xdd8fb0: SaveReg d0
    //     0xdd8fb0: str             q0, [SP, #-0x10]!
    // 0xdd8fb4: SaveReg r1
    //     0xdd8fb4: str             x1, [SP, #-8]!
    // 0xdd8fb8: r0 = AllocateDouble()
    //     0xdd8fb8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xdd8fbc: RestoreReg r1
    //     0xdd8fbc: ldr             x1, [SP], #8
    // 0xdd8fc0: RestoreReg d0
    //     0xdd8fc0: ldr             q0, [SP], #0x10
    // 0xdd8fc4: b               #0xdd8ec4
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xdd8fc8, size: 0x138
    // 0xdd8fc8: EnterFrame
    //     0xdd8fc8: stp             fp, lr, [SP, #-0x10]!
    //     0xdd8fcc: mov             fp, SP
    // 0xdd8fd0: AllocStack(0x8)
    //     0xdd8fd0: sub             SP, SP, #8
    // 0xdd8fd4: SetupParameters([dynamic _ /* r0 */])
    //     0xdd8fd4: ldr             x0, [fp, #0x10]
    //     0xdd8fd8: ldur            w2, [x0, #0x17]
    //     0xdd8fdc: add             x2, x2, HEAP, lsl #32
    //     0xdd8fe0: stur            x2, [fp, #-8]
    // 0xdd8fe4: CheckStackOverflow
    //     0xdd8fe4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd8fe8: cmp             SP, x16
    //     0xdd8fec: b.ls            #0xdd90d4
    // 0xdd8ff0: LoadField: r1 = r2->field_f
    //     0xdd8ff0: ldur            w1, [x2, #0xf]
    // 0xdd8ff4: DecompressPointer r1
    //     0xdd8ff4: add             x1, x1, HEAP, lsl #32
    // 0xdd8ff8: r0 = _cancelAndRestartTimer()
    //     0xdd8ff8: bl              #0xdd8594  ; [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_cancelAndRestartTimer
    // 0xdd8ffc: ldur            x0, [fp, #-8]
    // 0xdd9000: LoadField: r1 = r0->field_f
    //     0xdd9000: ldur            w1, [x0, #0xf]
    // 0xdd9004: DecompressPointer r1
    //     0xdd9004: add             x1, x1, HEAP, lsl #32
    // 0xdd9008: LoadField: r2 = r1->field_1f
    //     0xdd9008: ldur            w2, [x1, #0x1f]
    // 0xdd900c: DecompressPointer r2
    //     0xdd900c: add             x2, x2, HEAP, lsl #32
    // 0xdd9010: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd9014: cmp             w2, w16
    // 0xdd9018: b.eq            #0xdd90dc
    // 0xdd901c: LoadField: d0 = r2->field_27
    //     0xdd901c: ldur            d0, [x2, #0x27]
    // 0xdd9020: d1 = 0.000000
    //     0xdd9020: eor             v1.16b, v1.16b, v1.16b
    // 0xdd9024: fcmp            d0, d1
    // 0xdd9028: b.ne            #0xdd905c
    // 0xdd902c: LoadField: r2 = r0->field_13
    //     0xdd902c: ldur            w2, [x0, #0x13]
    // 0xdd9030: DecompressPointer r2
    //     0xdd9030: add             x2, x2, HEAP, lsl #32
    // 0xdd9034: LoadField: r0 = r1->field_23
    //     0xdd9034: ldur            w0, [x1, #0x23]
    // 0xdd9038: DecompressPointer r0
    //     0xdd9038: add             x0, x0, HEAP, lsl #32
    // 0xdd903c: cmp             w0, NULL
    // 0xdd9040: b.ne            #0xdd904c
    // 0xdd9044: d0 = 0.500000
    //     0xdd9044: fmov            d0, #0.50000000
    // 0xdd9048: b               #0xdd9050
    // 0xdd904c: LoadField: d0 = r0->field_7
    //     0xdd904c: ldur            d0, [x0, #7]
    // 0xdd9050: mov             x1, x2
    // 0xdd9054: r0 = setVolume()
    //     0xdd9054: bl              #0xdd2b84  ; [package:video_player/video_player.dart] VideoPlayerController::setVolume
    // 0xdd9058: b               #0xdd90c4
    // 0xdd905c: LoadField: r2 = r0->field_13
    //     0xdd905c: ldur            w2, [x0, #0x13]
    // 0xdd9060: DecompressPointer r2
    //     0xdd9060: add             x2, x2, HEAP, lsl #32
    // 0xdd9064: LoadField: r0 = r2->field_27
    //     0xdd9064: ldur            w0, [x2, #0x27]
    // 0xdd9068: DecompressPointer r0
    //     0xdd9068: add             x0, x0, HEAP, lsl #32
    // 0xdd906c: LoadField: d0 = r0->field_27
    //     0xdd906c: ldur            d0, [x0, #0x27]
    // 0xdd9070: r0 = inline_Allocate_Double()
    //     0xdd9070: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0xdd9074: add             x0, x0, #0x10
    //     0xdd9078: cmp             x3, x0
    //     0xdd907c: b.ls            #0xdd90e8
    //     0xdd9080: str             x0, [THR, #0x60]  ; THR::top
    //     0xdd9084: sub             x0, x0, #0xf
    //     0xdd9088: mov             x3, #0xe19c
    //     0xdd908c: movk            x3, #3, lsl #16
    //     0xdd9090: stur            x3, [x0, #-1]
    // 0xdd9094: dmb             ishst
    // 0xdd9098: StoreField: r0->field_7 = d0
    //     0xdd9098: stur            d0, [x0, #7]
    // 0xdd909c: StoreField: r1->field_23 = r0
    //     0xdd909c: stur            w0, [x1, #0x23]
    //     0xdd90a0: ldurb           w16, [x1, #-1]
    //     0xdd90a4: ldurb           w17, [x0, #-1]
    //     0xdd90a8: and             x16, x17, x16, lsr #2
    //     0xdd90ac: tst             x16, HEAP, lsr #32
    //     0xdd90b0: b.eq            #0xdd90b8
    //     0xdd90b4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdd90b8: mov             x1, x2
    // 0xdd90bc: mov             v0.16b, v1.16b
    // 0xdd90c0: r0 = setVolume()
    //     0xdd90c0: bl              #0xdd2b84  ; [package:video_player/video_player.dart] VideoPlayerController::setVolume
    // 0xdd90c4: r0 = Null
    //     0xdd90c4: mov             x0, NULL
    // 0xdd90c8: LeaveFrame
    //     0xdd90c8: mov             SP, fp
    //     0xdd90cc: ldp             fp, lr, [SP], #0x10
    // 0xdd90d0: ret
    //     0xdd90d0: ret             
    // 0xdd90d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd90d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd90d8: b               #0xdd8ff0
    // 0xdd90dc: r9 = _latestValue
    //     0xdd90dc: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3d10] Field <_MaterialDesktopControlsState@452377751._latestValue@452377751>: late (offset: 0x20)
    //     0xdd90e0: ldr             x9, [x9, #0xd10]
    // 0xdd90e4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd90e4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdd90e8: stp             q0, q1, [SP, #-0x20]!
    // 0xdd90ec: stp             x1, x2, [SP, #-0x10]!
    // 0xdd90f0: r0 = AllocateDouble()
    //     0xdd90f0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xdd90f4: ldp             x1, x2, [SP], #0x10
    // 0xdd90f8: ldp             q0, q1, [SP], #0x20
    // 0xdd90fc: b               #0xdd9098
  }
  _ _buildPlayPause(/* No info */) {
    // ** addr: 0xdd9100, size: 0x134
    // 0xdd9100: EnterFrame
    //     0xdd9100: stp             fp, lr, [SP, #-0x10]!
    //     0xdd9104: mov             fp, SP
    // 0xdd9108: AllocStack(0x50)
    //     0xdd9108: sub             SP, SP, #0x50
    // 0xdd910c: SetupParameters(_MaterialDesktopControlsState this /* r1 => r0, fp-0x10 */)
    //     0xdd910c: mov             x0, x1
    //     0xdd9110: stur            x1, [fp, #-0x10]
    // 0xdd9114: CheckStackOverflow
    //     0xdd9114: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd9118: cmp             SP, x16
    //     0xdd911c: b.ls            #0xdd9214
    // 0xdd9120: LoadField: d0 = r0->field_47
    //     0xdd9120: ldur            d0, [x0, #0x47]
    // 0xdd9124: stur            d0, [fp, #-0x28]
    // 0xdd9128: LoadField: r1 = r2->field_27
    //     0xdd9128: ldur            w1, [x2, #0x27]
    // 0xdd912c: DecompressPointer r1
    //     0xdd912c: add             x1, x1, HEAP, lsl #32
    // 0xdd9130: LoadField: r2 = r1->field_1b
    //     0xdd9130: ldur            w2, [x1, #0x1b]
    // 0xdd9134: DecompressPointer r2
    //     0xdd9134: add             x2, x2, HEAP, lsl #32
    // 0xdd9138: stur            x2, [fp, #-8]
    // 0xdd913c: r0 = AnimatedPlayPause()
    //     0xdd913c: bl              #0xdd1040  ; AllocateAnimatedPlayPauseStub -> AnimatedPlayPause (size=0x18)
    // 0xdd9140: mov             x1, x0
    // 0xdd9144: ldur            x0, [fp, #-8]
    // 0xdd9148: stur            x1, [fp, #-0x18]
    // 0xdd914c: StoreField: r1->field_f = r0
    //     0xdd914c: stur            w0, [x1, #0xf]
    // 0xdd9150: r0 = Instance_Color
    //     0xdd9150: add             x0, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0xdd9154: ldr             x0, [x0, #0xc38]
    // 0xdd9158: StoreField: r1->field_13 = r0
    //     0xdd9158: stur            w0, [x1, #0x13]
    // 0xdd915c: ldur            d0, [fp, #-0x28]
    // 0xdd9160: r0 = inline_Allocate_Double()
    //     0xdd9160: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xdd9164: add             x0, x0, #0x10
    //     0xdd9168: cmp             x2, x0
    //     0xdd916c: b.ls            #0xdd921c
    //     0xdd9170: str             x0, [THR, #0x60]  ; THR::top
    //     0xdd9174: sub             x0, x0, #0xf
    //     0xdd9178: mov             x2, #0xe19c
    //     0xdd917c: movk            x2, #3, lsl #16
    //     0xdd9180: stur            x2, [x0, #-1]
    // 0xdd9184: dmb             ishst
    // 0xdd9188: StoreField: r0->field_7 = d0
    //     0xdd9188: stur            d0, [x0, #7]
    // 0xdd918c: stur            x0, [fp, #-8]
    // 0xdd9190: r0 = Container()
    //     0xdd9190: bl              #0x8a5af8  ; AllocateContainerStub -> Container (size=0x38)
    // 0xdd9194: stur            x0, [fp, #-0x20]
    // 0xdd9198: ldur            x16, [fp, #-8]
    // 0xdd919c: r30 = Instance_Color
    //     0xdd919c: add             lr, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xdd91a0: ldr             lr, [lr, #0x810]
    // 0xdd91a4: stp             lr, x16, [SP, #0x18]
    // 0xdd91a8: r16 = Instance_EdgeInsets
    //     0xdd91a8: add             x16, PP, #0xd3, lsl #12  ; [pp+0xd3e28] Obj!EdgeInsets@129d471
    //     0xdd91ac: ldr             x16, [x16, #0xe28]
    // 0xdd91b0: r30 = Instance_EdgeInsets
    //     0xdd91b0: add             lr, PP, #0xd2, lsl #12  ; [pp+0xd2cc8] Obj!EdgeInsets@129d321
    //     0xdd91b4: ldr             lr, [lr, #0xcc8]
    // 0xdd91b8: stp             lr, x16, [SP, #8]
    // 0xdd91bc: ldur            x16, [fp, #-0x18]
    // 0xdd91c0: str             x16, [SP]
    // 0xdd91c4: mov             x1, x0
    // 0xdd91c8: r4 = const [0, 0x6, 0x5, 0x1, child, 0x5, color, 0x2, height, 0x1, margin, 0x3, padding, 0x4, null]
    //     0xdd91c8: add             x4, PP, #0xd3, lsl #12  ; [pp+0xd3e30] List(15) [0, 0x6, 0x5, 0x1, "child", 0x5, "color", 0x2, "height", 0x1, "margin", 0x3, "padding", 0x4, Null]
    //     0xdd91cc: ldr             x4, [x4, #0xe30]
    // 0xdd91d0: r0 = Container()
    //     0xdd91d0: bl              #0x8a54e0  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0xdd91d4: r0 = GestureDetector()
    //     0xdd91d4: bl              #0x918e18  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0xdd91d8: ldur            x2, [fp, #-0x10]
    // 0xdd91dc: r1 = Function '_playPause@452377751':.
    //     0xdd91dc: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3e38] AnonymousClosure: (0xdd9234), in [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_playPause (0xdd926c)
    //     0xdd91e0: ldr             x1, [x1, #0xe38]
    // 0xdd91e4: stur            x0, [fp, #-8]
    // 0xdd91e8: r0 = AllocateClosure()
    //     0xdd91e8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd91ec: ldur            x16, [fp, #-0x20]
    // 0xdd91f0: stp             x16, x0, [SP]
    // 0xdd91f4: ldur            x1, [fp, #-8]
    // 0xdd91f8: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0xdd91f8: add             x4, PP, #0x16, lsl #12  ; [pp+0x16e90] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0xdd91fc: ldr             x4, [x4, #0xe90]
    // 0xdd9200: r0 = GestureDetector()
    //     0xdd9200: bl              #0x9182dc  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0xdd9204: ldur            x0, [fp, #-8]
    // 0xdd9208: LeaveFrame
    //     0xdd9208: mov             SP, fp
    //     0xdd920c: ldp             fp, lr, [SP], #0x10
    // 0xdd9210: ret
    //     0xdd9210: ret             
    // 0xdd9214: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd9214: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd9218: b               #0xdd9120
    // 0xdd921c: SaveReg d0
    //     0xdd921c: str             q0, [SP, #-0x10]!
    // 0xdd9220: SaveReg r1
    //     0xdd9220: str             x1, [SP, #-8]!
    // 0xdd9224: r0 = AllocateDouble()
    //     0xdd9224: bl              #0x13df878  ; AllocateDoubleStub
    // 0xdd9228: RestoreReg r1
    //     0xdd9228: ldr             x1, [SP], #8
    // 0xdd922c: RestoreReg d0
    //     0xdd922c: ldr             q0, [SP], #0x10
    // 0xdd9230: b               #0xdd9188
  }
  [closure] void _playPause(dynamic) {
    // ** addr: 0xdd9234, size: 0x38
    // 0xdd9234: EnterFrame
    //     0xdd9234: stp             fp, lr, [SP, #-0x10]!
    //     0xdd9238: mov             fp, SP
    // 0xdd923c: ldr             x0, [fp, #0x10]
    // 0xdd9240: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdd9240: ldur            w1, [x0, #0x17]
    // 0xdd9244: DecompressPointer r1
    //     0xdd9244: add             x1, x1, HEAP, lsl #32
    // 0xdd9248: CheckStackOverflow
    //     0xdd9248: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd924c: cmp             SP, x16
    //     0xdd9250: b.ls            #0xdd9264
    // 0xdd9254: r0 = _playPause()
    //     0xdd9254: bl              #0xdd926c  ; [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_playPause
    // 0xdd9258: LeaveFrame
    //     0xdd9258: mov             SP, fp
    //     0xdd925c: ldp             fp, lr, [SP], #0x10
    // 0xdd9260: ret
    //     0xdd9260: ret             
    // 0xdd9264: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd9264: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd9268: b               #0xdd9254
  }
  _ _playPause(/* No info */) {
    // ** addr: 0xdd926c, size: 0x124
    // 0xdd926c: EnterFrame
    //     0xdd926c: stp             fp, lr, [SP, #-0x10]!
    //     0xdd9270: mov             fp, SP
    // 0xdd9274: AllocStack(0x28)
    //     0xdd9274: sub             SP, SP, #0x28
    // 0xdd9278: SetupParameters(_MaterialDesktopControlsState this /* r1 => r1, fp-0x8 */)
    //     0xdd9278: stur            x1, [fp, #-8]
    // 0xdd927c: CheckStackOverflow
    //     0xdd927c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd9280: cmp             SP, x16
    //     0xdd9284: b.ls            #0xdd937c
    // 0xdd9288: r1 = 1
    //     0xdd9288: mov             x1, #1
    // 0xdd928c: r0 = AllocateContext()
    //     0xdd928c: bl              #0x13de838  ; AllocateContextStub
    // 0xdd9290: mov             x2, x0
    // 0xdd9294: ldur            x0, [fp, #-8]
    // 0xdd9298: stur            x2, [fp, #-0x10]
    // 0xdd929c: StoreField: r2->field_f = r0
    //     0xdd929c: stur            w0, [x2, #0xf]
    // 0xdd92a0: LoadField: r1 = r0->field_4f
    //     0xdd92a0: ldur            w1, [x0, #0x4f]
    // 0xdd92a4: DecompressPointer r1
    //     0xdd92a4: add             x1, x1, HEAP, lsl #32
    // 0xdd92a8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd92ac: cmp             w1, w16
    // 0xdd92b0: b.eq            #0xdd9384
    // 0xdd92b4: LoadField: r3 = r1->field_27
    //     0xdd92b4: ldur            w3, [x1, #0x27]
    // 0xdd92b8: DecompressPointer r3
    //     0xdd92b8: add             x3, x3, HEAP, lsl #32
    // 0xdd92bc: LoadField: r1 = r3->field_1b
    //     0xdd92bc: ldur            w1, [x3, #0x1b]
    // 0xdd92c0: DecompressPointer r1
    //     0xdd92c0: add             x1, x1, HEAP, lsl #32
    // 0xdd92c4: tbnz            w1, #4, #0xdd930c
    // 0xdd92c8: r1 = Function '<anonymous closure>':.
    //     0xdd92c8: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3d48] AnonymousClosure: (0xdd93f4), in [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_playPause (0xdd926c)
    //     0xdd92cc: ldr             x1, [x1, #0xd48]
    // 0xdd92d0: r0 = AllocateClosure()
    //     0xdd92d0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd92d4: ldur            x1, [fp, #-8]
    // 0xdd92d8: mov             x2, x0
    // 0xdd92dc: r0 = setState()
    //     0xdd92dc: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xdd92e0: ldur            x0, [fp, #-8]
    // 0xdd92e4: LoadField: r1 = r0->field_27
    //     0xdd92e4: ldur            w1, [x0, #0x27]
    // 0xdd92e8: DecompressPointer r1
    //     0xdd92e8: add             x1, x1, HEAP, lsl #32
    // 0xdd92ec: cmp             w1, NULL
    // 0xdd92f0: b.eq            #0xdd92fc
    // 0xdd92f4: r0 = cancel()
    //     0xdd92f4: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0xdd92f8: ldur            x0, [fp, #-8]
    // 0xdd92fc: LoadField: r1 = r0->field_4f
    //     0xdd92fc: ldur            w1, [x0, #0x4f]
    // 0xdd9300: DecompressPointer r1
    //     0xdd9300: add             x1, x1, HEAP, lsl #32
    // 0xdd9304: r0 = pause()
    //     0xdd9304: bl              #0x8d70ec  ; [package:video_player/video_player.dart] VideoPlayerController::pause
    // 0xdd9308: b               #0xdd936c
    // 0xdd930c: mov             x1, x0
    // 0xdd9310: r0 = _cancelAndRestartTimer()
    //     0xdd9310: bl              #0xdd8594  ; [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_cancelAndRestartTimer
    // 0xdd9314: ldur            x0, [fp, #-8]
    // 0xdd9318: LoadField: r1 = r0->field_4f
    //     0xdd9318: ldur            w1, [x0, #0x4f]
    // 0xdd931c: DecompressPointer r1
    //     0xdd931c: add             x1, x1, HEAP, lsl #32
    // 0xdd9320: LoadField: r0 = r1->field_27
    //     0xdd9320: ldur            w0, [x1, #0x27]
    // 0xdd9324: DecompressPointer r0
    //     0xdd9324: add             x0, x0, HEAP, lsl #32
    // 0xdd9328: LoadField: r2 = r0->field_4f
    //     0xdd9328: ldur            w2, [x0, #0x4f]
    // 0xdd932c: DecompressPointer r2
    //     0xdd932c: add             x2, x2, HEAP, lsl #32
    // 0xdd9330: tbz             w2, #4, #0xdd9368
    // 0xdd9334: r0 = initialize()
    //     0xdd9334: bl              #0xdd1314  ; [package:video_player/video_player.dart] VideoPlayerController::initialize
    // 0xdd9338: ldur            x2, [fp, #-0x10]
    // 0xdd933c: r1 = Function '<anonymous closure>':.
    //     0xdd933c: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3d50] AnonymousClosure: (0xdd9390), in [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_playPause (0xdd926c)
    //     0xdd9340: ldr             x1, [x1, #0xd50]
    // 0xdd9344: stur            x0, [fp, #-8]
    // 0xdd9348: r0 = AllocateClosure()
    //     0xdd9348: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd934c: r16 = <Null?>
    //     0xdd934c: ldr             x16, [PP, #0x70]  ; [pp+0x70] TypeArguments: <Null?>
    // 0xdd9350: ldur            lr, [fp, #-8]
    // 0xdd9354: stp             lr, x16, [SP, #8]
    // 0xdd9358: str             x0, [SP]
    // 0xdd935c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xdd935c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xdd9360: r0 = then()
    //     0xdd9360: bl              #0x1293070  ; [dart:async] _Future::then
    // 0xdd9364: b               #0xdd936c
    // 0xdd9368: r0 = play()
    //     0xdd9368: bl              #0x8d57ac  ; [package:video_player/video_player.dart] VideoPlayerController::play
    // 0xdd936c: r0 = Null
    //     0xdd936c: mov             x0, NULL
    // 0xdd9370: LeaveFrame
    //     0xdd9370: mov             SP, fp
    //     0xdd9374: ldp             fp, lr, [SP], #0x10
    // 0xdd9378: ret
    //     0xdd9378: ret             
    // 0xdd937c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd937c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd9380: b               #0xdd9288
    // 0xdd9384: r9 = controller
    //     0xdd9384: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3cb8] Field <_MaterialDesktopControlsState@452377751.controller>: late (offset: 0x50)
    //     0xdd9388: ldr             x9, [x9, #0xcb8]
    // 0xdd938c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd938c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Null <anonymous closure>(dynamic, void) {
    // ** addr: 0xdd9390, size: 0x64
    // 0xdd9390: EnterFrame
    //     0xdd9390: stp             fp, lr, [SP, #-0x10]!
    //     0xdd9394: mov             fp, SP
    // 0xdd9398: ldr             x0, [fp, #0x18]
    // 0xdd939c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdd939c: ldur            w1, [x0, #0x17]
    // 0xdd93a0: DecompressPointer r1
    //     0xdd93a0: add             x1, x1, HEAP, lsl #32
    // 0xdd93a4: CheckStackOverflow
    //     0xdd93a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd93a8: cmp             SP, x16
    //     0xdd93ac: b.ls            #0xdd93e0
    // 0xdd93b0: LoadField: r0 = r1->field_f
    //     0xdd93b0: ldur            w0, [x1, #0xf]
    // 0xdd93b4: DecompressPointer r0
    //     0xdd93b4: add             x0, x0, HEAP, lsl #32
    // 0xdd93b8: LoadField: r1 = r0->field_4f
    //     0xdd93b8: ldur            w1, [x0, #0x4f]
    // 0xdd93bc: DecompressPointer r1
    //     0xdd93bc: add             x1, x1, HEAP, lsl #32
    // 0xdd93c0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd93c4: cmp             w1, w16
    // 0xdd93c8: b.eq            #0xdd93e8
    // 0xdd93cc: r0 = play()
    //     0xdd93cc: bl              #0x8d57ac  ; [package:video_player/video_player.dart] VideoPlayerController::play
    // 0xdd93d0: r0 = Null
    //     0xdd93d0: mov             x0, NULL
    // 0xdd93d4: LeaveFrame
    //     0xdd93d4: mov             SP, fp
    //     0xdd93d8: ldp             fp, lr, [SP], #0x10
    // 0xdd93dc: ret
    //     0xdd93dc: ret             
    // 0xdd93e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd93e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd93e4: b               #0xdd93b0
    // 0xdd93e8: r9 = controller
    //     0xdd93e8: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3cb8] Field <_MaterialDesktopControlsState@452377751.controller>: late (offset: 0x50)
    //     0xdd93ec: ldr             x9, [x9, #0xcb8]
    // 0xdd93f0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd93f0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xdd93f4, size: 0x70
    // 0xdd93f4: EnterFrame
    //     0xdd93f4: stp             fp, lr, [SP, #-0x10]!
    //     0xdd93f8: mov             fp, SP
    // 0xdd93fc: r0 = false
    //     0xdd93fc: add             x0, NULL, #0x30  ; false
    // 0xdd9400: ldr             x1, [fp, #0x10]
    // 0xdd9404: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xdd9404: ldur            w2, [x1, #0x17]
    // 0xdd9408: DecompressPointer r2
    //     0xdd9408: add             x2, x2, HEAP, lsl #32
    // 0xdd940c: CheckStackOverflow
    //     0xdd940c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd9410: cmp             SP, x16
    //     0xdd9414: b.ls            #0xdd9450
    // 0xdd9418: LoadField: r1 = r2->field_f
    //     0xdd9418: ldur            w1, [x2, #0xf]
    // 0xdd941c: DecompressPointer r1
    //     0xdd941c: add             x1, x1, HEAP, lsl #32
    // 0xdd9420: LoadField: r2 = r1->field_1b
    //     0xdd9420: ldur            w2, [x1, #0x1b]
    // 0xdd9424: DecompressPointer r2
    //     0xdd9424: add             x2, x2, HEAP, lsl #32
    // 0xdd9428: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd942c: cmp             w2, w16
    // 0xdd9430: b.eq            #0xdd9458
    // 0xdd9434: StoreField: r2->field_23 = r0
    //     0xdd9434: stur            w0, [x2, #0x23]
    // 0xdd9438: mov             x1, x2
    // 0xdd943c: r0 = notifyListeners()
    //     0xdd943c: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xdd9440: r0 = Null
    //     0xdd9440: mov             x0, NULL
    // 0xdd9444: LeaveFrame
    //     0xdd9444: mov             SP, fp
    //     0xdd9448: ldp             fp, lr, [SP], #0x10
    // 0xdd944c: ret
    //     0xdd944c: ret             
    // 0xdd9450: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd9450: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd9454: b               #0xdd9418
    // 0xdd9458: r9 = notifier
    //     0xdd9458: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3cc8] Field <_MaterialDesktopControlsState@452377751.notifier>: late (offset: 0x1c)
    //     0xdd945c: ldr             x9, [x9, #0xcc8]
    // 0xdd9460: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd9460: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _buildHitArea(/* No info */) {
    // ** addr: 0xdd9464, size: 0x1c8
    // 0xdd9464: EnterFrame
    //     0xdd9464: stp             fp, lr, [SP, #-0x10]!
    //     0xdd9468: mov             fp, SP
    // 0xdd946c: AllocStack(0x40)
    //     0xdd946c: sub             SP, SP, #0x40
    // 0xdd9470: SetupParameters(_MaterialDesktopControlsState this /* r1 => r2, fp-0x8 */)
    //     0xdd9470: mov             x2, x1
    //     0xdd9474: stur            x1, [fp, #-8]
    // 0xdd9478: CheckStackOverflow
    //     0xdd9478: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd947c: cmp             SP, x16
    //     0xdd9480: b.ls            #0xdd95fc
    // 0xdd9484: r1 = 1
    //     0xdd9484: mov             x1, #1
    // 0xdd9488: r0 = AllocateContext()
    //     0xdd9488: bl              #0x13de838  ; AllocateContextStub
    // 0xdd948c: ldur            x2, [fp, #-8]
    // 0xdd9490: stur            x0, [fp, #-0x28]
    // 0xdd9494: StoreField: r0->field_f = r2
    //     0xdd9494: stur            w2, [x0, #0xf]
    // 0xdd9498: LoadField: r1 = r2->field_1f
    //     0xdd9498: ldur            w1, [x2, #0x1f]
    // 0xdd949c: DecompressPointer r1
    //     0xdd949c: add             x1, x1, HEAP, lsl #32
    // 0xdd94a0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd94a4: cmp             w1, w16
    // 0xdd94a8: b.eq            #0xdd9604
    // 0xdd94ac: LoadField: r3 = r1->field_b
    //     0xdd94ac: ldur            w3, [x1, #0xb]
    // 0xdd94b0: DecompressPointer r3
    //     0xdd94b0: add             x3, x3, HEAP, lsl #32
    // 0xdd94b4: LoadField: r4 = r1->field_7
    //     0xdd94b4: ldur            w4, [x1, #7]
    // 0xdd94b8: DecompressPointer r4
    //     0xdd94b8: add             x4, x4, HEAP, lsl #32
    // 0xdd94bc: LoadField: r1 = r3->field_7
    //     0xdd94bc: ldur            x1, [x3, #7]
    // 0xdd94c0: LoadField: r3 = r4->field_7
    //     0xdd94c0: ldur            x3, [x4, #7]
    // 0xdd94c4: cmp             x1, x3
    // 0xdd94c8: b.lt            #0xdd94ec
    // 0xdd94cc: r1 = 1000000
    //     0xdd94cc: mov             x1, #0x4240
    //     0xdd94d0: movk            x1, #0xf, lsl #16
    // 0xdd94d4: sdiv            x4, x3, x1
    // 0xdd94d8: cmp             x4, #0
    // 0xdd94dc: r16 = true
    //     0xdd94dc: add             x16, NULL, #0x20  ; true
    // 0xdd94e0: r17 = false
    //     0xdd94e0: add             x17, NULL, #0x30  ; false
    // 0xdd94e4: csel            x1, x16, x17, gt
    // 0xdd94e8: b               #0xdd94f0
    // 0xdd94ec: r1 = false
    //     0xdd94ec: add             x1, NULL, #0x30  ; false
    // 0xdd94f0: stur            x1, [fp, #-0x20]
    // 0xdd94f4: LoadField: r3 = r2->field_b
    //     0xdd94f4: ldur            w3, [x2, #0xb]
    // 0xdd94f8: DecompressPointer r3
    //     0xdd94f8: add             x3, x3, HEAP, lsl #32
    // 0xdd94fc: cmp             w3, NULL
    // 0xdd9500: b.eq            #0xdd9610
    // 0xdd9504: LoadField: r3 = r2->field_37
    //     0xdd9504: ldur            w3, [x2, #0x37]
    // 0xdd9508: DecompressPointer r3
    //     0xdd9508: add             x3, x3, HEAP, lsl #32
    // 0xdd950c: tbz             w3, #4, #0xdd9534
    // 0xdd9510: LoadField: r3 = r2->field_1b
    //     0xdd9510: ldur            w3, [x2, #0x1b]
    // 0xdd9514: DecompressPointer r3
    //     0xdd9514: add             x3, x3, HEAP, lsl #32
    // 0xdd9518: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd951c: cmp             w3, w16
    // 0xdd9520: b.eq            #0xdd9614
    // 0xdd9524: LoadField: r4 = r3->field_23
    //     0xdd9524: ldur            w4, [x3, #0x23]
    // 0xdd9528: DecompressPointer r4
    //     0xdd9528: add             x4, x4, HEAP, lsl #32
    // 0xdd952c: eor             x3, x4, #0x10
    // 0xdd9530: b               #0xdd9538
    // 0xdd9534: r3 = false
    //     0xdd9534: add             x3, NULL, #0x30  ; false
    // 0xdd9538: stur            x3, [fp, #-0x18]
    // 0xdd953c: LoadField: r4 = r2->field_4f
    //     0xdd953c: ldur            w4, [x2, #0x4f]
    // 0xdd9540: DecompressPointer r4
    //     0xdd9540: add             x4, x4, HEAP, lsl #32
    // 0xdd9544: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd9548: cmp             w4, w16
    // 0xdd954c: b.eq            #0xdd9620
    // 0xdd9550: LoadField: r5 = r4->field_27
    //     0xdd9550: ldur            w5, [x4, #0x27]
    // 0xdd9554: DecompressPointer r5
    //     0xdd9554: add             x5, x5, HEAP, lsl #32
    // 0xdd9558: LoadField: r4 = r5->field_1b
    //     0xdd9558: ldur            w4, [x5, #0x1b]
    // 0xdd955c: DecompressPointer r4
    //     0xdd955c: add             x4, x4, HEAP, lsl #32
    // 0xdd9560: stur            x4, [fp, #-0x10]
    // 0xdd9564: r0 = CenterPlayButton()
    //     0xdd9564: bl              #0xdd33a8  ; AllocateCenterPlayButtonStub -> CenterPlayButton (size=0x24)
    // 0xdd9568: mov             x3, x0
    // 0xdd956c: r0 = Instance_Color
    //     0xdd956c: add             x0, PP, #0x12, lsl #12  ; [pp+0x12c78] Obj!Color@12a1741
    //     0xdd9570: ldr             x0, [x0, #0xc78]
    // 0xdd9574: stur            x3, [fp, #-0x30]
    // 0xdd9578: StoreField: r3->field_b = r0
    //     0xdd9578: stur            w0, [x3, #0xb]
    // 0xdd957c: r0 = Instance_Color
    //     0xdd957c: add             x0, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0xdd9580: ldr             x0, [x0, #0xc38]
    // 0xdd9584: StoreField: r3->field_f = r0
    //     0xdd9584: stur            w0, [x3, #0xf]
    // 0xdd9588: ldur            x0, [fp, #-0x18]
    // 0xdd958c: StoreField: r3->field_13 = r0
    //     0xdd958c: stur            w0, [x3, #0x13]
    // 0xdd9590: ldur            x0, [fp, #-0x10]
    // 0xdd9594: ArrayStore: r3[0] = r0  ; List_4
    //     0xdd9594: stur            w0, [x3, #0x17]
    // 0xdd9598: ldur            x0, [fp, #-0x20]
    // 0xdd959c: StoreField: r3->field_1b = r0
    //     0xdd959c: stur            w0, [x3, #0x1b]
    // 0xdd95a0: ldur            x2, [fp, #-8]
    // 0xdd95a4: r1 = Function '_playPause@452377751':.
    //     0xdd95a4: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3e38] AnonymousClosure: (0xdd9234), in [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_playPause (0xdd926c)
    //     0xdd95a8: ldr             x1, [x1, #0xe38]
    // 0xdd95ac: r0 = AllocateClosure()
    //     0xdd95ac: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd95b0: mov             x1, x0
    // 0xdd95b4: ldur            x0, [fp, #-0x30]
    // 0xdd95b8: StoreField: r0->field_1f = r1
    //     0xdd95b8: stur            w1, [x0, #0x1f]
    // 0xdd95bc: r0 = GestureDetector()
    //     0xdd95bc: bl              #0x918e18  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0xdd95c0: ldur            x2, [fp, #-0x28]
    // 0xdd95c4: r1 = Function '<anonymous closure>':.
    //     0xdd95c4: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3e40] AnonymousClosure: (0xdd962c), in [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_buildHitArea (0xdd9464)
    //     0xdd95c8: ldr             x1, [x1, #0xe40]
    // 0xdd95cc: stur            x0, [fp, #-8]
    // 0xdd95d0: r0 = AllocateClosure()
    //     0xdd95d0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd95d4: ldur            x16, [fp, #-0x30]
    // 0xdd95d8: stp             x16, x0, [SP]
    // 0xdd95dc: ldur            x1, [fp, #-8]
    // 0xdd95e0: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0xdd95e0: add             x4, PP, #0x16, lsl #12  ; [pp+0x16e90] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0xdd95e4: ldr             x4, [x4, #0xe90]
    // 0xdd95e8: r0 = GestureDetector()
    //     0xdd95e8: bl              #0x9182dc  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0xdd95ec: ldur            x0, [fp, #-8]
    // 0xdd95f0: LeaveFrame
    //     0xdd95f0: mov             SP, fp
    //     0xdd95f4: ldp             fp, lr, [SP], #0x10
    // 0xdd95f8: ret
    //     0xdd95f8: ret             
    // 0xdd95fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd95fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd9600: b               #0xdd9484
    // 0xdd9604: r9 = _latestValue
    //     0xdd9604: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3d10] Field <_MaterialDesktopControlsState@452377751._latestValue@452377751>: late (offset: 0x20)
    //     0xdd9608: ldr             x9, [x9, #0xd10]
    // 0xdd960c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd960c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdd9610: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd9610: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdd9614: r9 = notifier
    //     0xdd9614: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3cc8] Field <_MaterialDesktopControlsState@452377751.notifier>: late (offset: 0x1c)
    //     0xdd9618: ldr             x9, [x9, #0xcc8]
    // 0xdd961c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd961c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdd9620: r9 = controller
    //     0xdd9620: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3cb8] Field <_MaterialDesktopControlsState@452377751.controller>: late (offset: 0x50)
    //     0xdd9624: ldr             x9, [x9, #0xcb8]
    // 0xdd9628: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd9628: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xdd962c, size: 0x110
    // 0xdd962c: EnterFrame
    //     0xdd962c: stp             fp, lr, [SP, #-0x10]!
    //     0xdd9630: mov             fp, SP
    // 0xdd9634: AllocStack(0x10)
    //     0xdd9634: sub             SP, SP, #0x10
    // 0xdd9638: SetupParameters([dynamic _ /* r0 */])
    //     0xdd9638: ldr             x0, [fp, #0x10]
    //     0xdd963c: ldur            w2, [x0, #0x17]
    //     0xdd9640: add             x2, x2, HEAP, lsl #32
    //     0xdd9644: stur            x2, [fp, #-0x10]
    // 0xdd9648: CheckStackOverflow
    //     0xdd9648: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd964c: cmp             SP, x16
    //     0xdd9650: b.ls            #0xdd9728
    // 0xdd9654: LoadField: r0 = r2->field_f
    //     0xdd9654: ldur            w0, [x2, #0xf]
    // 0xdd9658: DecompressPointer r0
    //     0xdd9658: add             x0, x0, HEAP, lsl #32
    // 0xdd965c: stur            x0, [fp, #-8]
    // 0xdd9660: LoadField: r1 = r0->field_1f
    //     0xdd9660: ldur            w1, [x0, #0x1f]
    // 0xdd9664: DecompressPointer r1
    //     0xdd9664: add             x1, x1, HEAP, lsl #32
    // 0xdd9668: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd966c: cmp             w1, w16
    // 0xdd9670: b.eq            #0xdd9730
    // 0xdd9674: LoadField: r3 = r1->field_1b
    //     0xdd9674: ldur            w3, [x1, #0x1b]
    // 0xdd9678: DecompressPointer r3
    //     0xdd9678: add             x3, x3, HEAP, lsl #32
    // 0xdd967c: tbnz            w3, #4, #0xdd96dc
    // 0xdd9680: LoadField: r1 = r0->field_53
    //     0xdd9680: ldur            w1, [x0, #0x53]
    // 0xdd9684: DecompressPointer r1
    //     0xdd9684: add             x1, x1, HEAP, lsl #32
    // 0xdd9688: cmp             w1, NULL
    // 0xdd968c: b.ne            #0xdd9698
    // 0xdd9690: r1 = Null
    //     0xdd9690: mov             x1, NULL
    // 0xdd9694: b               #0xdd969c
    // 0xdd9698: r1 = false
    //     0xdd9698: add             x1, NULL, #0x30  ; false
    // 0xdd969c: cmp             w1, NULL
    // 0xdd96a0: b.eq            #0xdd96a8
    // 0xdd96a4: tbz             w1, #4, #0xdd971c
    // 0xdd96a8: LoadField: r1 = r0->field_3b
    //     0xdd96a8: ldur            w1, [x0, #0x3b]
    // 0xdd96ac: DecompressPointer r1
    //     0xdd96ac: add             x1, x1, HEAP, lsl #32
    // 0xdd96b0: tbnz            w1, #4, #0xdd96d0
    // 0xdd96b4: r1 = Function '<anonymous closure>':.
    //     0xdd96b4: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3e48] AnonymousClosure: (0xdcff14), in [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_startHideTimer (0xdcfe14)
    //     0xdd96b8: ldr             x1, [x1, #0xe48]
    // 0xdd96bc: r0 = AllocateClosure()
    //     0xdd96bc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd96c0: ldur            x1, [fp, #-8]
    // 0xdd96c4: mov             x2, x0
    // 0xdd96c8: r0 = setState()
    //     0xdd96c8: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xdd96cc: b               #0xdd970c
    // 0xdd96d0: ldur            x1, [fp, #-8]
    // 0xdd96d4: r0 = _cancelAndRestartTimer()
    //     0xdd96d4: bl              #0xdd8594  ; [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_cancelAndRestartTimer
    // 0xdd96d8: b               #0xdd970c
    // 0xdd96dc: ldur            x1, [fp, #-8]
    // 0xdd96e0: r0 = _playPause()
    //     0xdd96e0: bl              #0xdd926c  ; [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_playPause
    // 0xdd96e4: ldur            x2, [fp, #-0x10]
    // 0xdd96e8: LoadField: r0 = r2->field_f
    //     0xdd96e8: ldur            w0, [x2, #0xf]
    // 0xdd96ec: DecompressPointer r0
    //     0xdd96ec: add             x0, x0, HEAP, lsl #32
    // 0xdd96f0: stur            x0, [fp, #-8]
    // 0xdd96f4: r1 = Function '<anonymous closure>':.
    //     0xdd96f4: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3e50] AnonymousClosure: (0xdcff14), in [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_startHideTimer (0xdcfe14)
    //     0xdd96f8: ldr             x1, [x1, #0xe50]
    // 0xdd96fc: r0 = AllocateClosure()
    //     0xdd96fc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd9700: ldur            x1, [fp, #-8]
    // 0xdd9704: mov             x2, x0
    // 0xdd9708: r0 = setState()
    //     0xdd9708: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xdd970c: r0 = Null
    //     0xdd970c: mov             x0, NULL
    // 0xdd9710: LeaveFrame
    //     0xdd9710: mov             SP, fp
    //     0xdd9714: ldp             fp, lr, [SP], #0x10
    // 0xdd9718: ret
    //     0xdd9718: ret             
    // 0xdd971c: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xdd971c: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xdd9720: r0 = Throw()
    //     0xdd9720: bl              #0x13ddb2c  ; ThrowStub
    // 0xdd9724: brk             #0
    // 0xdd9728: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd9728: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd972c: b               #0xdd9654
    // 0xdd9730: r9 = _latestValue
    //     0xdd9730: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3d10] Field <_MaterialDesktopControlsState@452377751._latestValue@452377751>: late (offset: 0x20)
    //     0xdd9734: ldr             x9, [x9, #0xd10]
    // 0xdd9738: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd9738: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleKeyPress(dynamic, KeyEvent) {
    // ** addr: 0xdd973c, size: 0x3c
    // 0xdd973c: EnterFrame
    //     0xdd973c: stp             fp, lr, [SP, #-0x10]!
    //     0xdd9740: mov             fp, SP
    // 0xdd9744: ldr             x0, [fp, #0x18]
    // 0xdd9748: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdd9748: ldur            w1, [x0, #0x17]
    // 0xdd974c: DecompressPointer r1
    //     0xdd974c: add             x1, x1, HEAP, lsl #32
    // 0xdd9750: CheckStackOverflow
    //     0xdd9750: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd9754: cmp             SP, x16
    //     0xdd9758: b.ls            #0xdd9770
    // 0xdd975c: ldr             x2, [fp, #0x10]
    // 0xdd9760: r0 = _handleKeyPress()
    //     0xdd9760: bl              #0xdd9778  ; [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_handleKeyPress
    // 0xdd9764: LeaveFrame
    //     0xdd9764: mov             SP, fp
    //     0xdd9768: ldp             fp, lr, [SP], #0x10
    // 0xdd976c: ret
    //     0xdd976c: ret             
    // 0xdd9770: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd9770: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd9774: b               #0xdd975c
  }
  _ _handleKeyPress(/* No info */) {
    // ** addr: 0xdd9778, size: 0x21c
    // 0xdd9778: EnterFrame
    //     0xdd9778: stp             fp, lr, [SP, #-0x10]!
    //     0xdd977c: mov             fp, SP
    // 0xdd9780: AllocStack(0x30)
    //     0xdd9780: sub             SP, SP, #0x30
    // 0xdd9784: SetupParameters(_MaterialDesktopControlsState this /* r1 => r1, fp-0x18 */, dynamic _ /* r2 => r2, fp-0x20 */)
    //     0xdd9784: stur            x1, [fp, #-0x18]
    //     0xdd9788: stur            x2, [fp, #-0x20]
    // 0xdd978c: CheckStackOverflow
    //     0xdd978c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd9790: cmp             SP, x16
    //     0xdd9794: b.ls            #0xdd9988
    // 0xdd9798: r0 = LoadClassIdInstr(r2)
    //     0xdd9798: ldur            x0, [x2, #-1]
    //     0xdd979c: ubfx            x0, x0, #0xc, #0x14
    // 0xdd97a0: stur            x0, [fp, #-0x10]
    // 0xdd97a4: r17 = 5032
    //     0xdd97a4: mov             x17, #0x13a8
    // 0xdd97a8: cmp             x0, x17
    // 0xdd97ac: b.ne            #0xdd9804
    // 0xdd97b0: LoadField: r3 = r2->field_b
    //     0xdd97b0: ldur            w3, [x2, #0xb]
    // 0xdd97b4: DecompressPointer r3
    //     0xdd97b4: add             x3, x3, HEAP, lsl #32
    // 0xdd97b8: stur            x3, [fp, #-8]
    // 0xdd97bc: r16 = Instance_LogicalKeyboardKey
    //     0xdd97bc: add             x16, PP, #0xd3, lsl #12  ; [pp+0xd3d18] Obj!LogicalKeyboardKey@12ad301
    //     0xdd97c0: ldr             x16, [x16, #0xd18]
    // 0xdd97c4: cmp             w3, w16
    // 0xdd97c8: b.eq            #0xdd97f8
    // 0xdd97cc: r16 = LogicalKeyboardKey
    //     0xdd97cc: add             x16, PP, #0xd, lsl #12  ; [pp+0xdd00] Type: LogicalKeyboardKey
    //     0xdd97d0: ldr             x16, [x16, #0xd00]
    // 0xdd97d4: r30 = LogicalKeyboardKey
    //     0xdd97d4: add             lr, PP, #0xd, lsl #12  ; [pp+0xdd00] Type: LogicalKeyboardKey
    //     0xdd97d8: ldr             lr, [lr, #0xd00]
    // 0xdd97dc: stp             lr, x16, [SP]
    // 0xdd97e0: r0 = ==()
    //     0xdd97e0: bl              #0x12b7fbc  ; [dart:core] _Type::==
    // 0xdd97e4: tbnz            w0, #4, #0xdd9804
    // 0xdd97e8: ldur            x0, [fp, #-8]
    // 0xdd97ec: LoadField: r1 = r0->field_7
    //     0xdd97ec: ldur            x1, [x0, #7]
    // 0xdd97f0: cmp             x1, #0x20
    // 0xdd97f4: b.ne            #0xdd9804
    // 0xdd97f8: ldur            x1, [fp, #-0x18]
    // 0xdd97fc: r0 = _playPause()
    //     0xdd97fc: bl              #0xdd926c  ; [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_playPause
    // 0xdd9800: b               #0xdd9978
    // 0xdd9804: ldur            x0, [fp, #-0x10]
    // 0xdd9808: r17 = 5032
    //     0xdd9808: mov             x17, #0x13a8
    // 0xdd980c: cmp             x0, x17
    // 0xdd9810: b.ne            #0xdd9878
    // 0xdd9814: ldur            x1, [fp, #-0x20]
    // 0xdd9818: LoadField: r2 = r1->field_b
    //     0xdd9818: ldur            w2, [x1, #0xb]
    // 0xdd981c: DecompressPointer r2
    //     0xdd981c: add             x2, x2, HEAP, lsl #32
    // 0xdd9820: stur            x2, [fp, #-8]
    // 0xdd9824: r16 = Instance_LogicalKeyboardKey
    //     0xdd9824: add             x16, PP, #0xd, lsl #12  ; [pp+0xdde0] Obj!LogicalKeyboardKey@12acda1
    //     0xdd9828: ldr             x16, [x16, #0xde0]
    // 0xdd982c: cmp             w2, w16
    // 0xdd9830: b.eq            #0xdd986c
    // 0xdd9834: r16 = LogicalKeyboardKey
    //     0xdd9834: add             x16, PP, #0xd, lsl #12  ; [pp+0xdd00] Type: LogicalKeyboardKey
    //     0xdd9838: ldr             x16, [x16, #0xd00]
    // 0xdd983c: r30 = LogicalKeyboardKey
    //     0xdd983c: add             lr, PP, #0xd, lsl #12  ; [pp+0xdd00] Type: LogicalKeyboardKey
    //     0xdd9840: ldr             lr, [lr, #0xd00]
    // 0xdd9844: stp             lr, x16, [SP]
    // 0xdd9848: r0 = ==()
    //     0xdd9848: bl              #0x12b7fbc  ; [dart:core] _Type::==
    // 0xdd984c: tbnz            w0, #4, #0xdd9878
    // 0xdd9850: ldur            x0, [fp, #-8]
    // 0xdd9854: r1 = Instance_LogicalKeyboardKey
    //     0xdd9854: add             x1, PP, #0xd, lsl #12  ; [pp+0xdde0] Obj!LogicalKeyboardKey@12acda1
    //     0xdd9858: ldr             x1, [x1, #0xde0]
    // 0xdd985c: LoadField: r2 = r1->field_7
    //     0xdd985c: ldur            x2, [x1, #7]
    // 0xdd9860: LoadField: r1 = r0->field_7
    //     0xdd9860: ldur            x1, [x0, #7]
    // 0xdd9864: cmp             x2, x1
    // 0xdd9868: b.ne            #0xdd9878
    // 0xdd986c: ldur            x1, [fp, #-0x18]
    // 0xdd9870: r0 = _seekForward()
    //     0xdd9870: bl              #0xdd9b0c  ; [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_seekForward
    // 0xdd9874: b               #0xdd9978
    // 0xdd9878: ldur            x0, [fp, #-0x10]
    // 0xdd987c: r17 = 5032
    //     0xdd987c: mov             x17, #0x13a8
    // 0xdd9880: cmp             x0, x17
    // 0xdd9884: b.ne            #0xdd98ec
    // 0xdd9888: ldur            x1, [fp, #-0x20]
    // 0xdd988c: LoadField: r2 = r1->field_b
    //     0xdd988c: ldur            w2, [x1, #0xb]
    // 0xdd9890: DecompressPointer r2
    //     0xdd9890: add             x2, x2, HEAP, lsl #32
    // 0xdd9894: stur            x2, [fp, #-8]
    // 0xdd9898: r16 = Instance_LogicalKeyboardKey
    //     0xdd9898: add             x16, PP, #0xd, lsl #12  ; [pp+0xddd0] Obj!LogicalKeyboardKey@12acdb1
    //     0xdd989c: ldr             x16, [x16, #0xdd0]
    // 0xdd98a0: cmp             w2, w16
    // 0xdd98a4: b.eq            #0xdd98e0
    // 0xdd98a8: r16 = LogicalKeyboardKey
    //     0xdd98a8: add             x16, PP, #0xd, lsl #12  ; [pp+0xdd00] Type: LogicalKeyboardKey
    //     0xdd98ac: ldr             x16, [x16, #0xd00]
    // 0xdd98b0: r30 = LogicalKeyboardKey
    //     0xdd98b0: add             lr, PP, #0xd, lsl #12  ; [pp+0xdd00] Type: LogicalKeyboardKey
    //     0xdd98b4: ldr             lr, [lr, #0xd00]
    // 0xdd98b8: stp             lr, x16, [SP]
    // 0xdd98bc: r0 = ==()
    //     0xdd98bc: bl              #0x12b7fbc  ; [dart:core] _Type::==
    // 0xdd98c0: tbnz            w0, #4, #0xdd98ec
    // 0xdd98c4: ldur            x0, [fp, #-8]
    // 0xdd98c8: r1 = Instance_LogicalKeyboardKey
    //     0xdd98c8: add             x1, PP, #0xd, lsl #12  ; [pp+0xddd0] Obj!LogicalKeyboardKey@12acdb1
    //     0xdd98cc: ldr             x1, [x1, #0xdd0]
    // 0xdd98d0: LoadField: r2 = r1->field_7
    //     0xdd98d0: ldur            x2, [x1, #7]
    // 0xdd98d4: LoadField: r1 = r0->field_7
    //     0xdd98d4: ldur            x1, [x0, #7]
    // 0xdd98d8: cmp             x2, x1
    // 0xdd98dc: b.ne            #0xdd98ec
    // 0xdd98e0: ldur            x1, [fp, #-0x18]
    // 0xdd98e4: r0 = _seekBackward()
    //     0xdd98e4: bl              #0xdd9994  ; [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_seekBackward
    // 0xdd98e8: b               #0xdd9978
    // 0xdd98ec: ldur            x0, [fp, #-0x10]
    // 0xdd98f0: r17 = 5032
    //     0xdd98f0: mov             x17, #0x13a8
    // 0xdd98f4: cmp             x0, x17
    // 0xdd98f8: b.ne            #0xdd9978
    // 0xdd98fc: ldur            x0, [fp, #-0x20]
    // 0xdd9900: LoadField: r1 = r0->field_b
    //     0xdd9900: ldur            w1, [x0, #0xb]
    // 0xdd9904: DecompressPointer r1
    //     0xdd9904: add             x1, x1, HEAP, lsl #32
    // 0xdd9908: stur            x1, [fp, #-8]
    // 0xdd990c: r16 = Instance_LogicalKeyboardKey
    //     0xdd990c: add             x16, PP, #0xa3, lsl #12  ; [pp+0xa33d0] Obj!LogicalKeyboardKey@12ace71
    //     0xdd9910: ldr             x16, [x16, #0x3d0]
    // 0xdd9914: cmp             w1, w16
    // 0xdd9918: b.eq            #0xdd9954
    // 0xdd991c: r16 = LogicalKeyboardKey
    //     0xdd991c: add             x16, PP, #0xd, lsl #12  ; [pp+0xdd00] Type: LogicalKeyboardKey
    //     0xdd9920: ldr             x16, [x16, #0xd00]
    // 0xdd9924: r30 = LogicalKeyboardKey
    //     0xdd9924: add             lr, PP, #0xd, lsl #12  ; [pp+0xdd00] Type: LogicalKeyboardKey
    //     0xdd9928: ldr             lr, [lr, #0xd00]
    // 0xdd992c: stp             lr, x16, [SP]
    // 0xdd9930: r0 = ==()
    //     0xdd9930: bl              #0x12b7fbc  ; [dart:core] _Type::==
    // 0xdd9934: tbnz            w0, #4, #0xdd9978
    // 0xdd9938: ldur            x0, [fp, #-8]
    // 0xdd993c: r1 = Instance_LogicalKeyboardKey
    //     0xdd993c: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa33d0] Obj!LogicalKeyboardKey@12ace71
    //     0xdd9940: ldr             x1, [x1, #0x3d0]
    // 0xdd9944: LoadField: r2 = r1->field_7
    //     0xdd9944: ldur            x2, [x1, #7]
    // 0xdd9948: LoadField: r1 = r0->field_7
    //     0xdd9948: ldur            x1, [x0, #7]
    // 0xdd994c: cmp             x2, x1
    // 0xdd9950: b.ne            #0xdd9978
    // 0xdd9954: ldur            x1, [fp, #-0x18]
    // 0xdd9958: LoadField: r0 = r1->field_53
    //     0xdd9958: ldur            w0, [x1, #0x53]
    // 0xdd995c: DecompressPointer r0
    //     0xdd995c: add             x0, x0, HEAP, lsl #32
    // 0xdd9960: cmp             w0, NULL
    // 0xdd9964: b.eq            #0xdd9990
    // 0xdd9968: LoadField: r2 = r0->field_cf
    //     0xdd9968: ldur            w2, [x0, #0xcf]
    // 0xdd996c: DecompressPointer r2
    //     0xdd996c: add             x2, x2, HEAP, lsl #32
    // 0xdd9970: tbnz            w2, #4, #0xdd9978
    // 0xdd9974: r0 = _onExpandCollapse()
    //     0xdd9974: bl              #0xdd8428  ; [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_onExpandCollapse
    // 0xdd9978: r0 = Null
    //     0xdd9978: mov             x0, NULL
    // 0xdd997c: LeaveFrame
    //     0xdd997c: mov             SP, fp
    //     0xdd9980: ldp             fp, lr, [SP], #0x10
    // 0xdd9984: ret
    //     0xdd9984: ret             
    // 0xdd9988: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd9988: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd998c: b               #0xdd9798
    // 0xdd9990: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd9990: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _seekBackward(/* No info */) {
    // ** addr: 0xdd9994, size: 0x38
    // 0xdd9994: EnterFrame
    //     0xdd9994: stp             fp, lr, [SP, #-0x10]!
    //     0xdd9998: mov             fp, SP
    // 0xdd999c: CheckStackOverflow
    //     0xdd999c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd99a0: cmp             SP, x16
    //     0xdd99a4: b.ls            #0xdd99c4
    // 0xdd99a8: r2 = Instance_Duration
    //     0xdd99a8: add             x2, PP, #0xd3, lsl #12  ; [pp+0xd3d40] Obj!Duration@12c8b31
    //     0xdd99ac: ldr             x2, [x2, #0xd40]
    // 0xdd99b0: r0 = _seekRelative()
    //     0xdd99b0: bl              #0xdd99cc  ; [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_seekRelative
    // 0xdd99b4: r0 = Null
    //     0xdd99b4: mov             x0, NULL
    // 0xdd99b8: LeaveFrame
    //     0xdd99b8: mov             SP, fp
    //     0xdd99bc: ldp             fp, lr, [SP], #0x10
    // 0xdd99c0: ret
    //     0xdd99c0: ret             
    // 0xdd99c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd99c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd99c8: b               #0xdd99a8
  }
  _ _seekRelative(/* No info */) {
    // ** addr: 0xdd99cc, size: 0x140
    // 0xdd99cc: EnterFrame
    //     0xdd99cc: stp             fp, lr, [SP, #-0x10]!
    //     0xdd99d0: mov             fp, SP
    // 0xdd99d4: AllocStack(0x20)
    //     0xdd99d4: sub             SP, SP, #0x20
    // 0xdd99d8: SetupParameters(_MaterialDesktopControlsState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xdd99d8: mov             x0, x1
    //     0xdd99dc: stur            x1, [fp, #-8]
    //     0xdd99e0: stur            x2, [fp, #-0x10]
    // 0xdd99e4: CheckStackOverflow
    //     0xdd99e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd99e8: cmp             SP, x16
    //     0xdd99ec: b.ls            #0xdd9ad4
    // 0xdd99f0: mov             x1, x0
    // 0xdd99f4: r0 = _cancelAndRestartTimer()
    //     0xdd99f4: bl              #0xdd8594  ; [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_cancelAndRestartTimer
    // 0xdd99f8: ldur            x0, [fp, #-8]
    // 0xdd99fc: LoadField: r1 = r0->field_1f
    //     0xdd99fc: ldur            w1, [x0, #0x1f]
    // 0xdd9a00: DecompressPointer r1
    //     0xdd9a00: add             x1, x1, HEAP, lsl #32
    // 0xdd9a04: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd9a08: cmp             w1, w16
    // 0xdd9a0c: b.eq            #0xdd9adc
    // 0xdd9a10: stur            x1, [fp, #-0x20]
    // 0xdd9a14: LoadField: r2 = r1->field_b
    //     0xdd9a14: ldur            w2, [x1, #0xb]
    // 0xdd9a18: DecompressPointer r2
    //     0xdd9a18: add             x2, x2, HEAP, lsl #32
    // 0xdd9a1c: LoadField: r3 = r2->field_7
    //     0xdd9a1c: ldur            x3, [x2, #7]
    // 0xdd9a20: ldur            x2, [fp, #-0x10]
    // 0xdd9a24: LoadField: r4 = r2->field_7
    //     0xdd9a24: ldur            x4, [x2, #7]
    // 0xdd9a28: add             x2, x3, x4
    // 0xdd9a2c: stur            x2, [fp, #-0x18]
    // 0xdd9a30: r0 = Duration()
    //     0xdd9a30: bl              #0x7dd0d0  ; AllocateDurationStub -> Duration (size=0x10)
    // 0xdd9a34: mov             x1, x0
    // 0xdd9a38: ldur            x0, [fp, #-0x18]
    // 0xdd9a3c: StoreField: r1->field_7 = r0
    //     0xdd9a3c: stur            x0, [x1, #7]
    // 0xdd9a40: ldur            x2, [fp, #-0x20]
    // 0xdd9a44: LoadField: r3 = r2->field_7
    //     0xdd9a44: ldur            w3, [x2, #7]
    // 0xdd9a48: DecompressPointer r3
    //     0xdd9a48: add             x3, x3, HEAP, lsl #32
    // 0xdd9a4c: tbz             x0, #0x3f, #0xdd9a74
    // 0xdd9a50: ldur            x2, [fp, #-8]
    // 0xdd9a54: LoadField: r1 = r2->field_4f
    //     0xdd9a54: ldur            w1, [x2, #0x4f]
    // 0xdd9a58: DecompressPointer r1
    //     0xdd9a58: add             x1, x1, HEAP, lsl #32
    // 0xdd9a5c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd9a60: cmp             w1, w16
    // 0xdd9a64: b.eq            #0xdd9ae8
    // 0xdd9a68: r2 = Instance_Duration
    //     0xdd9a68: ldr             x2, [PP, #0x1808]  ; [pp+0x1808] Obj!Duration@12c8901
    // 0xdd9a6c: r0 = seekTo()
    //     0xdd9a6c: bl              #0x8d6e4c  ; [package:video_player/video_player.dart] VideoPlayerController::seekTo
    // 0xdd9a70: b               #0xdd9ac4
    // 0xdd9a74: ldur            x2, [fp, #-8]
    // 0xdd9a78: LoadField: r4 = r3->field_7
    //     0xdd9a78: ldur            x4, [x3, #7]
    // 0xdd9a7c: cmp             x0, x4
    // 0xdd9a80: b.le            #0xdd9aa4
    // 0xdd9a84: LoadField: r1 = r2->field_4f
    //     0xdd9a84: ldur            w1, [x2, #0x4f]
    // 0xdd9a88: DecompressPointer r1
    //     0xdd9a88: add             x1, x1, HEAP, lsl #32
    // 0xdd9a8c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd9a90: cmp             w1, w16
    // 0xdd9a94: b.eq            #0xdd9af4
    // 0xdd9a98: mov             x2, x3
    // 0xdd9a9c: r0 = seekTo()
    //     0xdd9a9c: bl              #0x8d6e4c  ; [package:video_player/video_player.dart] VideoPlayerController::seekTo
    // 0xdd9aa0: b               #0xdd9ac4
    // 0xdd9aa4: LoadField: r0 = r2->field_4f
    //     0xdd9aa4: ldur            w0, [x2, #0x4f]
    // 0xdd9aa8: DecompressPointer r0
    //     0xdd9aa8: add             x0, x0, HEAP, lsl #32
    // 0xdd9aac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd9ab0: cmp             w0, w16
    // 0xdd9ab4: b.eq            #0xdd9b00
    // 0xdd9ab8: mov             x2, x1
    // 0xdd9abc: mov             x1, x0
    // 0xdd9ac0: r0 = seekTo()
    //     0xdd9ac0: bl              #0x8d6e4c  ; [package:video_player/video_player.dart] VideoPlayerController::seekTo
    // 0xdd9ac4: r0 = Null
    //     0xdd9ac4: mov             x0, NULL
    // 0xdd9ac8: LeaveFrame
    //     0xdd9ac8: mov             SP, fp
    //     0xdd9acc: ldp             fp, lr, [SP], #0x10
    // 0xdd9ad0: ret
    //     0xdd9ad0: ret             
    // 0xdd9ad4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd9ad4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd9ad8: b               #0xdd99f0
    // 0xdd9adc: r9 = _latestValue
    //     0xdd9adc: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3d10] Field <_MaterialDesktopControlsState@452377751._latestValue@452377751>: late (offset: 0x20)
    //     0xdd9ae0: ldr             x9, [x9, #0xd10]
    // 0xdd9ae4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd9ae4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdd9ae8: r9 = controller
    //     0xdd9ae8: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3cb8] Field <_MaterialDesktopControlsState@452377751.controller>: late (offset: 0x50)
    //     0xdd9aec: ldr             x9, [x9, #0xcb8]
    // 0xdd9af0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd9af0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdd9af4: r9 = controller
    //     0xdd9af4: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3cb8] Field <_MaterialDesktopControlsState@452377751.controller>: late (offset: 0x50)
    //     0xdd9af8: ldr             x9, [x9, #0xcb8]
    // 0xdd9afc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd9afc: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdd9b00: r9 = controller
    //     0xdd9b00: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3cb8] Field <_MaterialDesktopControlsState@452377751.controller>: late (offset: 0x50)
    //     0xdd9b04: ldr             x9, [x9, #0xcb8]
    // 0xdd9b08: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd9b08: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _seekForward(/* No info */) {
    // ** addr: 0xdd9b0c, size: 0x38
    // 0xdd9b0c: EnterFrame
    //     0xdd9b0c: stp             fp, lr, [SP, #-0x10]!
    //     0xdd9b10: mov             fp, SP
    // 0xdd9b14: CheckStackOverflow
    //     0xdd9b14: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd9b18: cmp             SP, x16
    //     0xdd9b1c: b.ls            #0xdd9b3c
    // 0xdd9b20: r2 = Instance_Duration
    //     0xdd9b20: add             x2, PP, #0x94, lsl #12  ; [pp+0x94f70] Obj!Duration@12c8b21
    //     0xdd9b24: ldr             x2, [x2, #0xf70]
    // 0xdd9b28: r0 = _seekRelative()
    //     0xdd9b28: bl              #0xdd99cc  ; [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_seekRelative
    // 0xdd9b2c: r0 = Null
    //     0xdd9b2c: mov             x0, NULL
    // 0xdd9b30: LeaveFrame
    //     0xdd9b30: mov             SP, fp
    //     0xdd9b34: ldp             fp, lr, [SP], #0x10
    // 0xdd9b38: ret
    //     0xdd9b38: ret             
    // 0xdd9b3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd9b3c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd9b40: b               #0xdd9b20
  }
  [closure] void <anonymous closure>(dynamic, PointerHoverEvent) {
    // ** addr: 0xdd9b44, size: 0x80
    // 0xdd9b44: EnterFrame
    //     0xdd9b44: stp             fp, lr, [SP, #-0x10]!
    //     0xdd9b48: mov             fp, SP
    // 0xdd9b4c: AllocStack(0x8)
    //     0xdd9b4c: sub             SP, SP, #8
    // 0xdd9b50: SetupParameters([dynamic _ /* r0 */])
    //     0xdd9b50: ldr             x0, [fp, #0x18]
    //     0xdd9b54: ldur            w2, [x0, #0x17]
    //     0xdd9b58: add             x2, x2, HEAP, lsl #32
    //     0xdd9b5c: stur            x2, [fp, #-8]
    // 0xdd9b60: CheckStackOverflow
    //     0xdd9b60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd9b64: cmp             SP, x16
    //     0xdd9b68: b.ls            #0xdd9bb0
    // 0xdd9b6c: LoadField: r0 = r2->field_f
    //     0xdd9b6c: ldur            w0, [x2, #0xf]
    // 0xdd9b70: DecompressPointer r0
    //     0xdd9b70: add             x0, x0, HEAP, lsl #32
    // 0xdd9b74: LoadField: r1 = r0->field_57
    //     0xdd9b74: ldur            w1, [x0, #0x57]
    // 0xdd9b78: DecompressPointer r1
    //     0xdd9b78: add             x1, x1, HEAP, lsl #32
    // 0xdd9b7c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd9b80: cmp             w1, w16
    // 0xdd9b84: b.eq            #0xdd9bb8
    // 0xdd9b88: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xdd9b88: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xdd9b8c: r0 = requestFocus()
    //     0xdd9b8c: bl              #0x83e7b8  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::requestFocus
    // 0xdd9b90: ldur            x0, [fp, #-8]
    // 0xdd9b94: LoadField: r1 = r0->field_f
    //     0xdd9b94: ldur            w1, [x0, #0xf]
    // 0xdd9b98: DecompressPointer r1
    //     0xdd9b98: add             x1, x1, HEAP, lsl #32
    // 0xdd9b9c: r0 = _cancelAndRestartTimer()
    //     0xdd9b9c: bl              #0xdd8594  ; [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_cancelAndRestartTimer
    // 0xdd9ba0: r0 = Null
    //     0xdd9ba0: mov             x0, NULL
    // 0xdd9ba4: LeaveFrame
    //     0xdd9ba4: mov             SP, fp
    //     0xdd9ba8: ldp             fp, lr, [SP], #0x10
    // 0xdd9bac: ret
    //     0xdd9bac: ret             
    // 0xdd9bb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd9bb0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd9bb4: b               #0xdd9b6c
    // 0xdd9bb8: r9 = _focusNode
    //     0xdd9bb8: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3ce8] Field <_MaterialDesktopControlsState@452377751._focusNode@452377751>: late final (offset: 0x58)
    //     0xdd9bbc: ldr             x9, [x9, #0xce8]
    // 0xdd9bc0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd9bc0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xdd9bc4, size: 0x5c
    // 0xdd9bc4: EnterFrame
    //     0xdd9bc4: stp             fp, lr, [SP, #-0x10]!
    //     0xdd9bc8: mov             fp, SP
    // 0xdd9bcc: AllocStack(0x8)
    //     0xdd9bcc: sub             SP, SP, #8
    // 0xdd9bd0: SetupParameters([dynamic _ /* r0 */])
    //     0xdd9bd0: ldr             x0, [fp, #0x10]
    //     0xdd9bd4: ldur            w2, [x0, #0x17]
    //     0xdd9bd8: add             x2, x2, HEAP, lsl #32
    //     0xdd9bdc: stur            x2, [fp, #-8]
    // 0xdd9be0: CheckStackOverflow
    //     0xdd9be0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd9be4: cmp             SP, x16
    //     0xdd9be8: b.ls            #0xdd9c18
    // 0xdd9bec: LoadField: r1 = r2->field_f
    //     0xdd9bec: ldur            w1, [x2, #0xf]
    // 0xdd9bf0: DecompressPointer r1
    //     0xdd9bf0: add             x1, x1, HEAP, lsl #32
    // 0xdd9bf4: r0 = _playPause()
    //     0xdd9bf4: bl              #0xdd926c  ; [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_playPause
    // 0xdd9bf8: ldur            x0, [fp, #-8]
    // 0xdd9bfc: LoadField: r1 = r0->field_f
    //     0xdd9bfc: ldur            w1, [x0, #0xf]
    // 0xdd9c00: DecompressPointer r1
    //     0xdd9c00: add             x1, x1, HEAP, lsl #32
    // 0xdd9c04: r0 = _cancelAndRestartTimer()
    //     0xdd9c04: bl              #0xdd8594  ; [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_cancelAndRestartTimer
    // 0xdd9c08: r0 = Null
    //     0xdd9c08: mov             x0, NULL
    // 0xdd9c0c: LeaveFrame
    //     0xdd9c0c: mov             SP, fp
    //     0xdd9c10: ldp             fp, lr, [SP], #0x10
    // 0xdd9c14: ret
    //     0xdd9c14: ret             
    // 0xdd9c18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd9c18: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd9c1c: b               #0xdd9bec
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0xef3624, size: 0xc0
    // 0xef3624: EnterFrame
    //     0xef3624: stp             fp, lr, [SP, #-0x10]!
    //     0xef3628: mov             fp, SP
    // 0xef362c: AllocStack(0x10)
    //     0xef362c: sub             SP, SP, #0x10
    // 0xef3630: SetupParameters(_MaterialDesktopControlsState this /* r1 => r0, fp-0x10 */)
    //     0xef3630: mov             x0, x1
    //     0xef3634: stur            x1, [fp, #-0x10]
    // 0xef3638: CheckStackOverflow
    //     0xef3638: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef363c: cmp             SP, x16
    //     0xef3640: b.ls            #0xef36d8
    // 0xef3644: LoadField: r2 = r0->field_53
    //     0xef3644: ldur            w2, [x0, #0x53]
    // 0xef3648: DecompressPointer r2
    //     0xef3648: add             x2, x2, HEAP, lsl #32
    // 0xef364c: stur            x2, [fp, #-8]
    // 0xef3650: LoadField: r1 = r0->field_f
    //     0xef3650: ldur            w1, [x0, #0xf]
    // 0xef3654: DecompressPointer r1
    //     0xef3654: add             x1, x1, HEAP, lsl #32
    // 0xef3658: cmp             w1, NULL
    // 0xef365c: b.eq            #0xef36e0
    // 0xef3660: r0 = of()
    //     0xef3660: bl              #0xef309c  ; [package:chewie/src/chewie_player.dart] ChewieController::of
    // 0xef3664: mov             x1, x0
    // 0xef3668: ldur            x2, [fp, #-0x10]
    // 0xef366c: StoreField: r2->field_53 = r0
    //     0xef366c: stur            w0, [x2, #0x53]
    //     0xef3670: ldurb           w16, [x2, #-1]
    //     0xef3674: ldurb           w17, [x0, #-1]
    //     0xef3678: and             x16, x17, x16, lsr #2
    //     0xef367c: tst             x16, HEAP, lsr #32
    //     0xef3680: b.eq            #0xef3688
    //     0xef3684: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xef3688: LoadField: r0 = r1->field_3b
    //     0xef3688: ldur            w0, [x1, #0x3b]
    // 0xef368c: DecompressPointer r0
    //     0xef368c: add             x0, x0, HEAP, lsl #32
    // 0xef3690: StoreField: r2->field_4f = r0
    //     0xef3690: stur            w0, [x2, #0x4f]
    //     0xef3694: ldurb           w16, [x2, #-1]
    //     0xef3698: ldurb           w17, [x0, #-1]
    //     0xef369c: and             x16, x17, x16, lsr #2
    //     0xef36a0: tst             x16, HEAP, lsr #32
    //     0xef36a4: b.eq            #0xef36ac
    //     0xef36a8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xef36ac: ldur            x0, [fp, #-8]
    // 0xef36b0: cmp             w0, w1
    // 0xef36b4: b.eq            #0xef36c8
    // 0xef36b8: mov             x1, x2
    // 0xef36bc: r0 = _dispose()
    //     0xef36bc: bl              #0xef3a8c  ; [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_dispose
    // 0xef36c0: ldur            x1, [fp, #-0x10]
    // 0xef36c4: r0 = _initialize()
    //     0xef36c4: bl              #0xef36e4  ; [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_initialize
    // 0xef36c8: r0 = Null
    //     0xef36c8: mov             x0, NULL
    // 0xef36cc: LeaveFrame
    //     0xef36cc: mov             SP, fp
    //     0xef36d0: ldp             fp, lr, [SP], #0x10
    // 0xef36d4: ret
    //     0xef36d4: ret             
    // 0xef36d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef36d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef36dc: b               #0xef3644
    // 0xef36e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef36e0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _initialize(/* No info */) async {
    // ** addr: 0xef36e4, size: 0x16c
    // 0xef36e4: EnterFrame
    //     0xef36e4: stp             fp, lr, [SP, #-0x10]!
    //     0xef36e8: mov             fp, SP
    // 0xef36ec: AllocStack(0x20)
    //     0xef36ec: sub             SP, SP, #0x20
    // 0xef36f0: SetupParameters(_MaterialDesktopControlsState this /* r1 => r2, fp-0x10 */)
    //     0xef36f0: stur            NULL, [fp, #-8]
    //     0xef36f4: mov             x2, x1
    //     0xef36f8: stur            x1, [fp, #-0x10]
    // 0xef36fc: CheckStackOverflow
    //     0xef36fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef3700: cmp             SP, x16
    //     0xef3704: b.ls            #0xef3830
    // 0xef3708: r1 = 1
    //     0xef3708: mov             x1, #1
    // 0xef370c: r0 = AllocateContext()
    //     0xef370c: bl              #0x13de838  ; AllocateContextStub
    // 0xef3710: mov             x1, x0
    // 0xef3714: ldur            x2, [fp, #-0x10]
    // 0xef3718: stur            x1, [fp, #-0x18]
    // 0xef371c: StoreField: r1->field_f = r2
    //     0xef371c: stur            w2, [x1, #0xf]
    // 0xef3720: InitAsync() -> Future<void?>
    //     0xef3720: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0xef3724: bl              #0x7f5e44  ; InitAsyncStub
    // 0xef3728: ldur            x0, [fp, #-0x10]
    // 0xef372c: LoadField: r1 = r0->field_53
    //     0xef372c: ldur            w1, [x0, #0x53]
    // 0xef3730: DecompressPointer r1
    //     0xef3730: add             x1, x1, HEAP, lsl #32
    // 0xef3734: cmp             w1, NULL
    // 0xef3738: b.eq            #0xef3838
    // 0xef373c: r1 = false
    //     0xef373c: add             x1, NULL, #0x30  ; false
    // 0xef3740: StoreField: r0->field_2f = r1
    //     0xef3740: stur            w1, [x0, #0x2f]
    // 0xef3744: LoadField: r3 = r0->field_4f
    //     0xef3744: ldur            w3, [x0, #0x4f]
    // 0xef3748: DecompressPointer r3
    //     0xef3748: add             x3, x3, HEAP, lsl #32
    // 0xef374c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xef3750: cmp             w3, w16
    // 0xef3754: b.eq            #0xef383c
    // 0xef3758: mov             x2, x0
    // 0xef375c: stur            x3, [fp, #-0x20]
    // 0xef3760: r1 = Function '_updateState@452377751':.
    //     0xef3760: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3ca8] AnonymousClosure: (0xef3a54), in [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_updateState (0xef3850)
    //     0xef3764: ldr             x1, [x1, #0xca8]
    // 0xef3768: r0 = AllocateClosure()
    //     0xef3768: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xef376c: ldur            x1, [fp, #-0x20]
    // 0xef3770: mov             x2, x0
    // 0xef3774: r0 = addListener()
    //     0xef3774: bl              #0xd038e0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0xef3778: ldur            x1, [fp, #-0x10]
    // 0xef377c: r0 = _updateState()
    //     0xef377c: bl              #0xef3850  ; [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_updateState
    // 0xef3780: ldur            x0, [fp, #-0x10]
    // 0xef3784: LoadField: r1 = r0->field_4f
    //     0xef3784: ldur            w1, [x0, #0x4f]
    // 0xef3788: DecompressPointer r1
    //     0xef3788: add             x1, x1, HEAP, lsl #32
    // 0xef378c: LoadField: r2 = r1->field_27
    //     0xef378c: ldur            w2, [x1, #0x27]
    // 0xef3790: DecompressPointer r2
    //     0xef3790: add             x2, x2, HEAP, lsl #32
    // 0xef3794: LoadField: r1 = r2->field_1b
    //     0xef3794: ldur            w1, [x2, #0x1b]
    // 0xef3798: DecompressPointer r1
    //     0xef3798: add             x1, x1, HEAP, lsl #32
    // 0xef379c: tbz             w1, #4, #0xef37bc
    // 0xef37a0: LoadField: r1 = r0->field_53
    //     0xef37a0: ldur            w1, [x0, #0x53]
    // 0xef37a4: DecompressPointer r1
    //     0xef37a4: add             x1, x1, HEAP, lsl #32
    // 0xef37a8: cmp             w1, NULL
    // 0xef37ac: b.eq            #0xef3848
    // 0xef37b0: LoadField: r2 = r1->field_43
    //     0xef37b0: ldur            w2, [x1, #0x43]
    // 0xef37b4: DecompressPointer r2
    //     0xef37b4: add             x2, x2, HEAP, lsl #32
    // 0xef37b8: tbnz            w2, #4, #0xef37c4
    // 0xef37bc: mov             x1, x0
    // 0xef37c0: r0 = _startHideTimer()
    //     0xef37c0: bl              #0xdcfe14  ; [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_startHideTimer
    // 0xef37c4: ldur            x0, [fp, #-0x10]
    // 0xef37c8: LoadField: r1 = r0->field_53
    //     0xef37c8: ldur            w1, [x0, #0x53]
    // 0xef37cc: DecompressPointer r1
    //     0xef37cc: add             x1, x1, HEAP, lsl #32
    // 0xef37d0: cmp             w1, NULL
    // 0xef37d4: b.eq            #0xef384c
    // 0xef37d8: LoadField: r2 = r1->field_53
    //     0xef37d8: ldur            w2, [x1, #0x53]
    // 0xef37dc: DecompressPointer r2
    //     0xef37dc: add             x2, x2, HEAP, lsl #32
    // 0xef37e0: tbnz            w2, #4, #0xef3828
    // 0xef37e4: ldur            x2, [fp, #-0x18]
    // 0xef37e8: r1 = Function '<anonymous closure>':.
    //     0xef37e8: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3cb0] AnonymousClosure: (0xef398c), in [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_initialize (0xef36e4)
    //     0xef37ec: ldr             x1, [x1, #0xcb0]
    // 0xef37f0: r0 = AllocateClosure()
    //     0xef37f0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xef37f4: mov             x3, x0
    // 0xef37f8: r1 = Null
    //     0xef37f8: mov             x1, NULL
    // 0xef37fc: r2 = Instance_Duration
    //     0xef37fc: add             x2, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xef3800: ldr             x2, [x2, #0x318]
    // 0xef3804: r0 = Timer()
    //     0xef3804: bl              #0x7eed74  ; [dart:async] Timer::Timer
    // 0xef3808: ldur            x1, [fp, #-0x10]
    // 0xef380c: StoreField: r1->field_2b = r0
    //     0xef380c: stur            w0, [x1, #0x2b]
    //     0xef3810: ldurb           w16, [x1, #-1]
    //     0xef3814: ldurb           w17, [x0, #-1]
    //     0xef3818: and             x16, x17, x16, lsr #2
    //     0xef381c: tst             x16, HEAP, lsr #32
    //     0xef3820: b.eq            #0xef3828
    //     0xef3824: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xef3828: r0 = Null
    //     0xef3828: mov             x0, NULL
    // 0xef382c: r0 = ReturnAsyncNotFuture()
    //     0xef382c: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xef3830: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef3830: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef3834: b               #0xef3708
    // 0xef3838: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef3838: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef383c: r9 = controller
    //     0xef383c: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3cb8] Field <_MaterialDesktopControlsState@452377751.controller>: late (offset: 0x50)
    //     0xef3840: ldr             x9, [x9, #0xcb8]
    // 0xef3844: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xef3844: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xef3848: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef3848: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef384c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef384c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateState(/* No info */) {
    // ** addr: 0xef3850, size: 0xcc
    // 0xef3850: EnterFrame
    //     0xef3850: stp             fp, lr, [SP, #-0x10]!
    //     0xef3854: mov             fp, SP
    // 0xef3858: AllocStack(0x10)
    //     0xef3858: sub             SP, SP, #0x10
    // 0xef385c: SetupParameters(_MaterialDesktopControlsState this /* r1 => r1, fp-0x8 */)
    //     0xef385c: stur            x1, [fp, #-8]
    // 0xef3860: CheckStackOverflow
    //     0xef3860: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef3864: cmp             SP, x16
    //     0xef3868: b.ls            #0xef3904
    // 0xef386c: r1 = 1
    //     0xef386c: mov             x1, #1
    // 0xef3870: r0 = AllocateContext()
    //     0xef3870: bl              #0x13de838  ; AllocateContextStub
    // 0xef3874: mov             x2, x0
    // 0xef3878: ldur            x0, [fp, #-8]
    // 0xef387c: stur            x2, [fp, #-0x10]
    // 0xef3880: StoreField: r2->field_f = r0
    //     0xef3880: stur            w0, [x2, #0xf]
    // 0xef3884: LoadField: r1 = r0->field_f
    //     0xef3884: ldur            w1, [x0, #0xf]
    // 0xef3888: DecompressPointer r1
    //     0xef3888: add             x1, x1, HEAP, lsl #32
    // 0xef388c: cmp             w1, NULL
    // 0xef3890: b.ne            #0xef38a4
    // 0xef3894: r0 = Null
    //     0xef3894: mov             x0, NULL
    // 0xef3898: LeaveFrame
    //     0xef3898: mov             SP, fp
    //     0xef389c: ldp             fp, lr, [SP], #0x10
    // 0xef38a0: ret
    //     0xef38a0: ret             
    // 0xef38a4: LoadField: r1 = r0->field_4f
    //     0xef38a4: ldur            w1, [x0, #0x4f]
    // 0xef38a8: DecompressPointer r1
    //     0xef38a8: add             x1, x1, HEAP, lsl #32
    // 0xef38ac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xef38b0: cmp             w1, w16
    // 0xef38b4: b.eq            #0xef390c
    // 0xef38b8: r0 = getIsBuffering()
    //     0xef38b8: bl              #0xdd3740  ; [package:chewie/src/helpers/utils.dart] ::getIsBuffering
    // 0xef38bc: mov             x1, x0
    // 0xef38c0: ldur            x0, [fp, #-8]
    // 0xef38c4: LoadField: r2 = r0->field_53
    //     0xef38c4: ldur            w2, [x0, #0x53]
    // 0xef38c8: DecompressPointer r2
    //     0xef38c8: add             x2, x2, HEAP, lsl #32
    // 0xef38cc: cmp             w2, NULL
    // 0xef38d0: b.eq            #0xef3918
    // 0xef38d4: StoreField: r0->field_43 = r1
    //     0xef38d4: stur            w1, [x0, #0x43]
    // 0xef38d8: ldur            x2, [fp, #-0x10]
    // 0xef38dc: r1 = Function '<anonymous closure>':.
    //     0xef38dc: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3ce0] AnonymousClosure: (0xef391c), in [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_updateState (0xef3850)
    //     0xef38e0: ldr             x1, [x1, #0xce0]
    // 0xef38e4: r0 = AllocateClosure()
    //     0xef38e4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xef38e8: ldur            x1, [fp, #-8]
    // 0xef38ec: mov             x2, x0
    // 0xef38f0: r0 = setState()
    //     0xef38f0: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xef38f4: r0 = Null
    //     0xef38f4: mov             x0, NULL
    // 0xef38f8: LeaveFrame
    //     0xef38f8: mov             SP, fp
    //     0xef38fc: ldp             fp, lr, [SP], #0x10
    // 0xef3900: ret
    //     0xef3900: ret             
    // 0xef3904: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef3904: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef3908: b               #0xef386c
    // 0xef390c: r9 = controller
    //     0xef390c: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3cb8] Field <_MaterialDesktopControlsState@452377751.controller>: late (offset: 0x50)
    //     0xef3910: ldr             x9, [x9, #0xcb8]
    // 0xef3914: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xef3914: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xef3918: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef3918: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xef391c, size: 0x70
    // 0xef391c: ldr             x1, [SP]
    // 0xef3920: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xef3920: ldur            w2, [x1, #0x17]
    // 0xef3924: DecompressPointer r2
    //     0xef3924: add             x2, x2, HEAP, lsl #32
    // 0xef3928: LoadField: r1 = r2->field_f
    //     0xef3928: ldur            w1, [x2, #0xf]
    // 0xef392c: DecompressPointer r1
    //     0xef392c: add             x1, x1, HEAP, lsl #32
    // 0xef3930: LoadField: r2 = r1->field_4f
    //     0xef3930: ldur            w2, [x1, #0x4f]
    // 0xef3934: DecompressPointer r2
    //     0xef3934: add             x2, x2, HEAP, lsl #32
    // 0xef3938: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xef393c: cmp             w2, w16
    // 0xef3940: b.eq            #0xef3978
    // 0xef3944: LoadField: r0 = r2->field_27
    //     0xef3944: ldur            w0, [x2, #0x27]
    // 0xef3948: DecompressPointer r0
    //     0xef3948: add             x0, x0, HEAP, lsl #32
    // 0xef394c: StoreField: r1->field_1f = r0
    //     0xef394c: stur            w0, [x1, #0x1f]
    //     0xef3950: ldurb           w16, [x1, #-1]
    //     0xef3954: ldurb           w17, [x0, #-1]
    //     0xef3958: and             x16, x17, x16, lsr #2
    //     0xef395c: tst             x16, HEAP, lsr #32
    //     0xef3960: b.eq            #0xef3970
    //     0xef3964: str             lr, [SP, #-8]!
    //     0xef3968: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    //     0xef396c: ldr             lr, [SP], #8
    // 0xef3970: r0 = Null
    //     0xef3970: mov             x0, NULL
    // 0xef3974: ret
    //     0xef3974: ret             
    // 0xef3978: EnterFrame
    //     0xef3978: stp             fp, lr, [SP, #-0x10]!
    //     0xef397c: mov             fp, SP
    // 0xef3980: r9 = controller
    //     0xef3980: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3cb8] Field <_MaterialDesktopControlsState@452377751.controller>: late (offset: 0x50)
    //     0xef3984: ldr             x9, [x9, #0xcb8]
    // 0xef3988: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xef3988: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xef398c, size: 0x60
    // 0xef398c: EnterFrame
    //     0xef398c: stp             fp, lr, [SP, #-0x10]!
    //     0xef3990: mov             fp, SP
    // 0xef3994: AllocStack(0x8)
    //     0xef3994: sub             SP, SP, #8
    // 0xef3998: SetupParameters([dynamic _ /* r0 */])
    //     0xef3998: ldr             x0, [fp, #0x10]
    //     0xef399c: ldur            w2, [x0, #0x17]
    //     0xef39a0: add             x2, x2, HEAP, lsl #32
    // 0xef39a4: CheckStackOverflow
    //     0xef39a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef39a8: cmp             SP, x16
    //     0xef39ac: b.ls            #0xef39e4
    // 0xef39b0: LoadField: r0 = r2->field_f
    //     0xef39b0: ldur            w0, [x2, #0xf]
    // 0xef39b4: DecompressPointer r0
    //     0xef39b4: add             x0, x0, HEAP, lsl #32
    // 0xef39b8: stur            x0, [fp, #-8]
    // 0xef39bc: r1 = Function '<anonymous closure>':.
    //     0xef39bc: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3cc0] AnonymousClosure: (0xef39ec), in [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_initialize (0xef36e4)
    //     0xef39c0: ldr             x1, [x1, #0xcc0]
    // 0xef39c4: r0 = AllocateClosure()
    //     0xef39c4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xef39c8: ldur            x1, [fp, #-8]
    // 0xef39cc: mov             x2, x0
    // 0xef39d0: r0 = setState()
    //     0xef39d0: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xef39d4: r0 = Null
    //     0xef39d4: mov             x0, NULL
    // 0xef39d8: LeaveFrame
    //     0xef39d8: mov             SP, fp
    //     0xef39dc: ldp             fp, lr, [SP], #0x10
    // 0xef39e0: ret
    //     0xef39e0: ret             
    // 0xef39e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef39e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef39e8: b               #0xef39b0
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xef39ec, size: 0x68
    // 0xef39ec: EnterFrame
    //     0xef39ec: stp             fp, lr, [SP, #-0x10]!
    //     0xef39f0: mov             fp, SP
    // 0xef39f4: ldr             x0, [fp, #0x10]
    // 0xef39f8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xef39f8: ldur            w1, [x0, #0x17]
    // 0xef39fc: DecompressPointer r1
    //     0xef39fc: add             x1, x1, HEAP, lsl #32
    // 0xef3a00: CheckStackOverflow
    //     0xef3a00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef3a04: cmp             SP, x16
    //     0xef3a08: b.ls            #0xef3a40
    // 0xef3a0c: LoadField: r0 = r1->field_f
    //     0xef3a0c: ldur            w0, [x1, #0xf]
    // 0xef3a10: DecompressPointer r0
    //     0xef3a10: add             x0, x0, HEAP, lsl #32
    // 0xef3a14: LoadField: r1 = r0->field_1b
    //     0xef3a14: ldur            w1, [x0, #0x1b]
    // 0xef3a18: DecompressPointer r1
    //     0xef3a18: add             x1, x1, HEAP, lsl #32
    // 0xef3a1c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xef3a20: cmp             w1, w16
    // 0xef3a24: b.eq            #0xef3a48
    // 0xef3a28: r2 = false
    //     0xef3a28: add             x2, NULL, #0x30  ; false
    // 0xef3a2c: r0 = AnnotationExtension.setIsLocked()
    //     0xef3a2c: bl              #0xdabdf4  ; [package:syncfusion_flutter_pdfviewer/src/annotation/annotation.dart] ::AnnotationExtension.setIsLocked
    // 0xef3a30: r0 = Null
    //     0xef3a30: mov             x0, NULL
    // 0xef3a34: LeaveFrame
    //     0xef3a34: mov             SP, fp
    //     0xef3a38: ldp             fp, lr, [SP], #0x10
    // 0xef3a3c: ret
    //     0xef3a3c: ret             
    // 0xef3a40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef3a40: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef3a44: b               #0xef3a0c
    // 0xef3a48: r9 = notifier
    //     0xef3a48: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3cc8] Field <_MaterialDesktopControlsState@452377751.notifier>: late (offset: 0x1c)
    //     0xef3a4c: ldr             x9, [x9, #0xcc8]
    // 0xef3a50: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xef3a50: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void _updateState(dynamic) {
    // ** addr: 0xef3a54, size: 0x38
    // 0xef3a54: EnterFrame
    //     0xef3a54: stp             fp, lr, [SP, #-0x10]!
    //     0xef3a58: mov             fp, SP
    // 0xef3a5c: ldr             x0, [fp, #0x10]
    // 0xef3a60: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xef3a60: ldur            w1, [x0, #0x17]
    // 0xef3a64: DecompressPointer r1
    //     0xef3a64: add             x1, x1, HEAP, lsl #32
    // 0xef3a68: CheckStackOverflow
    //     0xef3a68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef3a6c: cmp             SP, x16
    //     0xef3a70: b.ls            #0xef3a84
    // 0xef3a74: r0 = _updateState()
    //     0xef3a74: bl              #0xef3850  ; [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_updateState
    // 0xef3a78: LeaveFrame
    //     0xef3a78: mov             SP, fp
    //     0xef3a7c: ldp             fp, lr, [SP], #0x10
    // 0xef3a80: ret
    //     0xef3a80: ret             
    // 0xef3a84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef3a84: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef3a88: b               #0xef3a74
  }
  _ _dispose(/* No info */) {
    // ** addr: 0xef3a8c, size: 0xc0
    // 0xef3a8c: EnterFrame
    //     0xef3a8c: stp             fp, lr, [SP, #-0x10]!
    //     0xef3a90: mov             fp, SP
    // 0xef3a94: AllocStack(0x10)
    //     0xef3a94: sub             SP, SP, #0x10
    // 0xef3a98: SetupParameters(_MaterialDesktopControlsState this /* r1 => r0, fp-0x10 */)
    //     0xef3a98: mov             x0, x1
    //     0xef3a9c: stur            x1, [fp, #-0x10]
    // 0xef3aa0: CheckStackOverflow
    //     0xef3aa0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef3aa4: cmp             SP, x16
    //     0xef3aa8: b.ls            #0xef3b38
    // 0xef3aac: LoadField: r3 = r0->field_4f
    //     0xef3aac: ldur            w3, [x0, #0x4f]
    // 0xef3ab0: DecompressPointer r3
    //     0xef3ab0: add             x3, x3, HEAP, lsl #32
    // 0xef3ab4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xef3ab8: cmp             w3, w16
    // 0xef3abc: b.eq            #0xef3b40
    // 0xef3ac0: mov             x2, x0
    // 0xef3ac4: stur            x3, [fp, #-8]
    // 0xef3ac8: r1 = Function '_updateState@452377751':.
    //     0xef3ac8: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3ca8] AnonymousClosure: (0xef3a54), in [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_updateState (0xef3850)
    //     0xef3acc: ldr             x1, [x1, #0xca8]
    // 0xef3ad0: r0 = AllocateClosure()
    //     0xef3ad0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xef3ad4: ldur            x1, [fp, #-8]
    // 0xef3ad8: mov             x2, x0
    // 0xef3adc: r0 = removeListener()
    //     0xef3adc: bl              #0xcff784  ; [package:video_player/video_player.dart] VideoPlayerController::removeListener
    // 0xef3ae0: ldur            x0, [fp, #-0x10]
    // 0xef3ae4: LoadField: r1 = r0->field_27
    //     0xef3ae4: ldur            w1, [x0, #0x27]
    // 0xef3ae8: DecompressPointer r1
    //     0xef3ae8: add             x1, x1, HEAP, lsl #32
    // 0xef3aec: cmp             w1, NULL
    // 0xef3af0: b.eq            #0xef3afc
    // 0xef3af4: r0 = cancel()
    //     0xef3af4: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0xef3af8: ldur            x0, [fp, #-0x10]
    // 0xef3afc: LoadField: r1 = r0->field_2b
    //     0xef3afc: ldur            w1, [x0, #0x2b]
    // 0xef3b00: DecompressPointer r1
    //     0xef3b00: add             x1, x1, HEAP, lsl #32
    // 0xef3b04: cmp             w1, NULL
    // 0xef3b08: b.eq            #0xef3b14
    // 0xef3b0c: r0 = cancel()
    //     0xef3b0c: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0xef3b10: ldur            x0, [fp, #-0x10]
    // 0xef3b14: LoadField: r1 = r0->field_33
    //     0xef3b14: ldur            w1, [x0, #0x33]
    // 0xef3b18: DecompressPointer r1
    //     0xef3b18: add             x1, x1, HEAP, lsl #32
    // 0xef3b1c: cmp             w1, NULL
    // 0xef3b20: b.eq            #0xef3b28
    // 0xef3b24: r0 = cancel()
    //     0xef3b24: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0xef3b28: r0 = Null
    //     0xef3b28: mov             x0, NULL
    // 0xef3b2c: LeaveFrame
    //     0xef3b2c: mov             SP, fp
    //     0xef3b30: ldp             fp, lr, [SP], #0x10
    // 0xef3b34: ret
    //     0xef3b34: ret             
    // 0xef3b38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef3b38: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef3b3c: b               #0xef3aac
    // 0xef3b40: r9 = controller
    //     0xef3b40: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3cb8] Field <_MaterialDesktopControlsState@452377751.controller>: late (offset: 0x50)
    //     0xef3b44: ldr             x9, [x9, #0xcb8]
    // 0xef3b48: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xef3b48: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0xf8aee8, size: 0xf8
    // 0xf8aee8: EnterFrame
    //     0xf8aee8: stp             fp, lr, [SP, #-0x10]!
    //     0xf8aeec: mov             fp, SP
    // 0xf8aef0: AllocStack(0x28)
    //     0xf8aef0: sub             SP, SP, #0x28
    // 0xf8aef4: SetupParameters(_MaterialDesktopControlsState this /* r1 => r1, fp-0x8 */)
    //     0xf8aef4: stur            x1, [fp, #-8]
    // 0xf8aef8: CheckStackOverflow
    //     0xf8aef8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf8aefc: cmp             SP, x16
    //     0xf8af00: b.ls            #0xf8afd4
    // 0xf8af04: r0 = FocusNode()
    //     0xf8af04: bl              #0xd4952c  ; AllocateFocusNodeStub -> FocusNode (size=0x68)
    // 0xf8af08: mov             x1, x0
    // 0xf8af0c: stur            x0, [fp, #-0x10]
    // 0xf8af10: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xf8af10: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xf8af14: r0 = FocusNode()
    //     0xf8af14: bl              #0x83cf84  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::FocusNode
    // 0xf8af18: ldur            x2, [fp, #-8]
    // 0xf8af1c: LoadField: r0 = r2->field_57
    //     0xf8af1c: ldur            w0, [x2, #0x57]
    // 0xf8af20: DecompressPointer r0
    //     0xf8af20: add             x0, x0, HEAP, lsl #32
    // 0xf8af24: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf8af28: cmp             w0, w16
    // 0xf8af2c: b.ne            #0xf8afc0
    // 0xf8af30: ldur            x0, [fp, #-0x10]
    // 0xf8af34: StoreField: r2->field_57 = r0
    //     0xf8af34: stur            w0, [x2, #0x57]
    //     0xf8af38: ldurb           w16, [x2, #-1]
    //     0xf8af3c: ldurb           w17, [x0, #-1]
    //     0xf8af40: and             x16, x17, x16, lsr #2
    //     0xf8af44: tst             x16, HEAP, lsr #32
    //     0xf8af48: b.eq            #0xf8af50
    //     0xf8af4c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf8af50: ldur            x1, [fp, #-0x10]
    // 0xf8af54: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xf8af54: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xf8af58: r0 = requestFocus()
    //     0xf8af58: bl              #0x83e7b8  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::requestFocus
    // 0xf8af5c: ldur            x0, [fp, #-8]
    // 0xf8af60: LoadField: r1 = r0->field_f
    //     0xf8af60: ldur            w1, [x0, #0xf]
    // 0xf8af64: DecompressPointer r1
    //     0xf8af64: add             x1, x1, HEAP, lsl #32
    // 0xf8af68: cmp             w1, NULL
    // 0xf8af6c: b.eq            #0xf8afdc
    // 0xf8af70: r16 = <PlayerNotifier>
    //     0xf8af70: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf6f0] TypeArguments: <PlayerNotifier>
    //     0xf8af74: ldr             x16, [x16, #0x6f0]
    // 0xf8af78: stp             x1, x16, [SP, #8]
    // 0xf8af7c: r16 = false
    //     0xf8af7c: add             x16, NULL, #0x30  ; false
    // 0xf8af80: str             x16, [SP]
    // 0xf8af84: r4 = const [0x1, 0x2, 0x2, 0x1, listen, 0x1, null]
    //     0xf8af84: add             x4, PP, #0xd1, lsl #12  ; [pp+0xd17f8] List(7) [0x1, 0x2, 0x2, 0x1, "listen", 0x1, Null]
    //     0xf8af88: ldr             x4, [x4, #0x7f8]
    // 0xf8af8c: r0 = of()
    //     0xf8af8c: bl              #0xf8a8d4  ; [package:provider/src/provider.dart] Provider::of
    // 0xf8af90: ldur            x1, [fp, #-8]
    // 0xf8af94: StoreField: r1->field_1b = r0
    //     0xf8af94: stur            w0, [x1, #0x1b]
    //     0xf8af98: ldurb           w16, [x1, #-1]
    //     0xf8af9c: ldurb           w17, [x0, #-1]
    //     0xf8afa0: and             x16, x17, x16, lsr #2
    //     0xf8afa4: tst             x16, HEAP, lsr #32
    //     0xf8afa8: b.eq            #0xf8afb0
    //     0xf8afac: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf8afb0: r0 = Null
    //     0xf8afb0: mov             x0, NULL
    // 0xf8afb4: LeaveFrame
    //     0xf8afb4: mov             SP, fp
    //     0xf8afb8: ldp             fp, lr, [SP], #0x10
    // 0xf8afbc: ret
    //     0xf8afbc: ret             
    // 0xf8afc0: r16 = "_focusNode@452377751"
    //     0xf8afc0: add             x16, PP, #0xd3, lsl #12  ; [pp+0xd3e58] "_focusNode@452377751"
    //     0xf8afc4: ldr             x16, [x16, #0xe58]
    // 0xf8afc8: str             x16, [SP]
    // 0xf8afcc: r0 = _throwFieldAlreadyInitialized()
    //     0xf8afcc: bl              #0x82b720  ; [dart:_internal] LateError::_throwFieldAlreadyInitialized
    // 0xf8afd0: brk             #0
    // 0xf8afd4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf8afd4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf8afd8: b               #0xf8af04
    // 0xf8afdc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf8afdc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _MaterialDesktopControlsState(/* No info */) {
    // ** addr: 0xfa0058, size: 0x3c
    // 0xfa0058: ldr             x3, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa005c: r2 = false
    //     0xfa005c: add             x2, NULL, #0x30  ; false
    // 0xfa0060: d0 = 72.000000
    //     0xfa0060: add             x17, PP, #0x89, lsl #12  ; [pp+0x89030] IMM: double(72) from 0x4052000000000000
    //     0xfa0064: ldr             d0, [x17, #0x30]
    // 0xfa0068: StoreField: r1->field_1b = r3
    //     0xfa0068: stur            w3, [x1, #0x1b]
    // 0xfa006c: StoreField: r1->field_1f = r3
    //     0xfa006c: stur            w3, [x1, #0x1f]
    // 0xfa0070: StoreField: r1->field_2f = r2
    //     0xfa0070: stur            w2, [x1, #0x2f]
    // 0xfa0074: StoreField: r1->field_37 = r2
    //     0xfa0074: stur            w2, [x1, #0x37]
    // 0xfa0078: StoreField: r1->field_3b = r2
    //     0xfa0078: stur            w2, [x1, #0x3b]
    // 0xfa007c: StoreField: r1->field_43 = r2
    //     0xfa007c: stur            w2, [x1, #0x43]
    // 0xfa0080: StoreField: r1->field_4f = r3
    //     0xfa0080: stur            w3, [x1, #0x4f]
    // 0xfa0084: StoreField: r1->field_57 = r3
    //     0xfa0084: stur            w3, [x1, #0x57]
    // 0xfa0088: StoreField: r1->field_47 = d0
    //     0xfa0088: stur            d0, [x1, #0x47]
    // 0xfa008c: r0 = Null
    //     0xfa008c: mov             x0, NULL
    // 0xfa0090: ret
    //     0xfa0090: ret             
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10e28fc, size: 0x70
    // 0x10e28fc: EnterFrame
    //     0x10e28fc: stp             fp, lr, [SP, #-0x10]!
    //     0x10e2900: mov             fp, SP
    // 0x10e2904: AllocStack(0x8)
    //     0x10e2904: sub             SP, SP, #8
    // 0x10e2908: SetupParameters(_MaterialDesktopControlsState this /* r1 => r0, fp-0x8 */)
    //     0x10e2908: mov             x0, x1
    //     0x10e290c: stur            x1, [fp, #-8]
    // 0x10e2910: CheckStackOverflow
    //     0x10e2910: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e2914: cmp             SP, x16
    //     0x10e2918: b.ls            #0x10e2958
    // 0x10e291c: mov             x1, x0
    // 0x10e2920: r0 = _dispose()
    //     0x10e2920: bl              #0xef3a8c  ; [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_dispose
    // 0x10e2924: ldur            x0, [fp, #-8]
    // 0x10e2928: LoadField: r1 = r0->field_57
    //     0x10e2928: ldur            w1, [x0, #0x57]
    // 0x10e292c: DecompressPointer r1
    //     0x10e292c: add             x1, x1, HEAP, lsl #32
    // 0x10e2930: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10e2934: cmp             w1, w16
    // 0x10e2938: b.eq            #0x10e2960
    // 0x10e293c: r0 = dispose()
    //     0x10e293c: bl              #0x10ec024  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::dispose
    // 0x10e2940: ldur            x1, [fp, #-8]
    // 0x10e2944: r0 = dispose()
    //     0x10e2944: bl              #0x10e296c  ; [dart:mixin_deduplication] _MixinApplication739&State&SingleTickerProviderStateMixin::dispose
    // 0x10e2948: r0 = Null
    //     0x10e2948: mov             x0, NULL
    // 0x10e294c: LeaveFrame
    //     0x10e294c: mov             SP, fp
    //     0x10e2950: ldp             fp, lr, [SP], #0x10
    // 0x10e2954: ret
    //     0x10e2954: ret             
    // 0x10e2958: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e2958: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e295c: b               #0x10e291c
    // 0x10e2960: r9 = _focusNode
    //     0x10e2960: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3ce8] Field <_MaterialDesktopControlsState@452377751._focusNode@452377751>: late final (offset: 0x58)
    //     0x10e2964: ldr             x9, [x9, #0xce8]
    // 0x10e2968: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x10e2968: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 6534, size: 0x10, field offset: 0xc
//   const constructor, 
class MaterialDesktopControls extends StatefulWidget {

  bool field_c;

  _ createState(/* No info */) {
    // ** addr: 0xfa0010, size: 0x48
    // 0xfa0010: EnterFrame
    //     0xfa0010: stp             fp, lr, [SP, #-0x10]!
    //     0xfa0014: mov             fp, SP
    // 0xfa0018: AllocStack(0x8)
    //     0xfa0018: sub             SP, SP, #8
    // 0xfa001c: CheckStackOverflow
    //     0xfa001c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa0020: cmp             SP, x16
    //     0xfa0024: b.ls            #0xfa0050
    // 0xfa0028: r1 = <MaterialDesktopControls>
    //     0xfa0028: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd32f8] TypeArguments: <MaterialDesktopControls>
    //     0xfa002c: ldr             x1, [x1, #0x2f8]
    // 0xfa0030: r0 = _MaterialDesktopControlsState()
    //     0xfa0030: bl              #0xfa0094  ; Allocate_MaterialDesktopControlsStateStub -> _MaterialDesktopControlsState (size=0x5c)
    // 0xfa0034: mov             x1, x0
    // 0xfa0038: stur            x0, [fp, #-8]
    // 0xfa003c: r0 = _MaterialDesktopControlsState()
    //     0xfa003c: bl              #0xfa0058  ; [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_MaterialDesktopControlsState
    // 0xfa0040: ldur            x0, [fp, #-8]
    // 0xfa0044: LeaveFrame
    //     0xfa0044: mov             SP, fp
    //     0xfa0048: ldp             fp, lr, [SP], #0x10
    // 0xfa004c: ret
    //     0xfa004c: ret             
    // 0xfa0050: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa0050: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa0054: b               #0xfa0028
  }
}
