// lib: , url: package:chewie/src/material/material_progress_bar.dart

// class id: 1048638, size: 0x8
class :: {
}

// class id: 6213, size: 0x34, field offset: 0xc
class MaterialVideoProgressBar extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfaaa64, size: 0x94
    // 0xfaaa64: EnterFrame
    //     0xfaaa64: stp             fp, lr, [SP, #-0x10]!
    //     0xfaaa68: mov             fp, SP
    // 0xfaaa6c: AllocStack(0x28)
    //     0xfaaa6c: sub             SP, SP, #0x28
    // 0xfaaa70: CheckStackOverflow
    //     0xfaaa70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfaaa74: cmp             SP, x16
    //     0xfaaa78: b.ls            #0xfaaaf0
    // 0xfaaa7c: LoadField: r2 = r1->field_1b
    //     0xfaaa7c: ldur            w2, [x1, #0x1b]
    // 0xfaaa80: DecompressPointer r2
    //     0xfaaa80: add             x2, x2, HEAP, lsl #32
    // 0xfaaa84: stur            x2, [fp, #-0x28]
    // 0xfaaa88: LoadField: r3 = r1->field_1f
    //     0xfaaa88: ldur            w3, [x1, #0x1f]
    // 0xfaaa8c: DecompressPointer r3
    //     0xfaaa8c: add             x3, x3, HEAP, lsl #32
    // 0xfaaa90: stur            x3, [fp, #-0x20]
    // 0xfaaa94: LoadField: r5 = r1->field_27
    //     0xfaaa94: ldur            w5, [x1, #0x27]
    // 0xfaaa98: DecompressPointer r5
    //     0xfaaa98: add             x5, x5, HEAP, lsl #32
    // 0xfaaa9c: stur            x5, [fp, #-0x18]
    // 0xfaaaa0: LoadField: r6 = r1->field_23
    //     0xfaaaa0: ldur            w6, [x1, #0x23]
    // 0xfaaaa4: DecompressPointer r6
    //     0xfaaaa4: add             x6, x6, HEAP, lsl #32
    // 0xfaaaa8: stur            x6, [fp, #-0x10]
    // 0xfaaaac: LoadField: r7 = r1->field_2b
    //     0xfaaaac: ldur            w7, [x1, #0x2b]
    // 0xfaaab0: DecompressPointer r7
    //     0xfaaab0: add             x7, x7, HEAP, lsl #32
    // 0xfaaab4: stur            x7, [fp, #-8]
    // 0xfaaab8: r0 = VideoProgressBar()
    //     0xfaaab8: bl              #0xfaa9d8  ; AllocateVideoProgressBarStub -> VideoProgressBar (size=0x38)
    // 0xfaaabc: mov             x1, x0
    // 0xfaaac0: ldur            x2, [fp, #-0x28]
    // 0xfaaac4: ldur            x3, [fp, #-0x20]
    // 0xfaaac8: ldur            x5, [fp, #-0x18]
    // 0xfaaacc: ldur            x6, [fp, #-0x10]
    // 0xfaaad0: ldur            x7, [fp, #-8]
    // 0xfaaad4: d0 = 10.000000
    //     0xfaaad4: fmov            d0, #10.00000000
    // 0xfaaad8: stur            x0, [fp, #-8]
    // 0xfaaadc: r0 = VideoProgressBar()
    //     0xfaaadc: bl              #0xfaa8e4  ; [package:chewie/src/progress_bar.dart] VideoProgressBar::VideoProgressBar
    // 0xfaaae0: ldur            x0, [fp, #-8]
    // 0xfaaae4: LeaveFrame
    //     0xfaaae4: mov             SP, fp
    //     0xfaaae8: ldp             fp, lr, [SP], #0x10
    // 0xfaaaec: ret
    //     0xfaaaec: ret             
    // 0xfaaaf0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfaaaf0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfaaaf4: b               #0xfaaa7c
  }
}
