// lib: , url: package:chewie/src/material/widgets/options_dialog.dart

// class id: 1048639, size: 0x8
class :: {
}

// class id: 5498, size: 0x14, field offset: 0x14
class _OptionsDialogState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0xde2234, size: 0x218
    // 0xde2234: EnterFrame
    //     0xde2234: stp             fp, lr, [SP, #-0x10]!
    //     0xde2238: mov             fp, SP
    // 0xde223c: AllocStack(0x38)
    //     0xde223c: sub             SP, SP, #0x38
    // 0xde2240: SetupParameters(_OptionsDialogState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xde2240: stur            x1, [fp, #-8]
    //     0xde2244: stur            x2, [fp, #-0x10]
    // 0xde2248: CheckStackOverflow
    //     0xde2248: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde224c: cmp             SP, x16
    //     0xde2250: b.ls            #0xde243c
    // 0xde2254: r1 = 2
    //     0xde2254: mov             x1, #2
    // 0xde2258: r0 = AllocateContext()
    //     0xde2258: bl              #0x13de838  ; AllocateContextStub
    // 0xde225c: mov             x3, x0
    // 0xde2260: ldur            x0, [fp, #-8]
    // 0xde2264: stur            x3, [fp, #-0x18]
    // 0xde2268: StoreField: r3->field_f = r0
    //     0xde2268: stur            w0, [x3, #0xf]
    // 0xde226c: ldur            x1, [fp, #-0x10]
    // 0xde2270: StoreField: r3->field_13 = r1
    //     0xde2270: stur            w1, [x3, #0x13]
    // 0xde2274: LoadField: r1 = r0->field_b
    //     0xde2274: ldur            w1, [x0, #0xb]
    // 0xde2278: DecompressPointer r1
    //     0xde2278: add             x1, x1, HEAP, lsl #32
    // 0xde227c: cmp             w1, NULL
    // 0xde2280: b.eq            #0xde2444
    // 0xde2284: LoadField: r2 = r1->field_b
    //     0xde2284: ldur            w2, [x1, #0xb]
    // 0xde2288: DecompressPointer r2
    //     0xde2288: add             x2, x2, HEAP, lsl #32
    // 0xde228c: LoadField: r4 = r2->field_b
    //     0xde228c: ldur            w4, [x2, #0xb]
    // 0xde2290: mov             x2, x3
    // 0xde2294: stur            x4, [fp, #-0x10]
    // 0xde2298: r1 = Function '<anonymous closure>':.
    //     0xde2298: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4998] AnonymousClosure: (0xde24a0), in [package:chewie/src/material/widgets/options_dialog.dart] _OptionsDialogState::build (0xde2234)
    //     0xde229c: ldr             x1, [x1, #0x998]
    // 0xde22a0: r0 = AllocateClosure()
    //     0xde22a0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xde22a4: stur            x0, [fp, #-0x20]
    // 0xde22a8: r0 = ListView()
    //     0xde22a8: bl              #0xd8c860  ; AllocateListViewStub -> ListView (size=0x6c)
    // 0xde22ac: stur            x0, [fp, #-0x28]
    // 0xde22b0: r16 = true
    //     0xde22b0: add             x16, NULL, #0x20  ; true
    // 0xde22b4: ldur            lr, [fp, #-0x10]
    // 0xde22b8: stp             lr, x16, [SP]
    // 0xde22bc: mov             x1, x0
    // 0xde22c0: ldur            x2, [fp, #-0x20]
    // 0xde22c4: r4 = const [0, 0x4, 0x2, 0x2, itemCount, 0x3, shrinkWrap, 0x2, null]
    //     0xde22c4: add             x4, PP, #0x1a, lsl #12  ; [pp+0x1a128] List(9) [0, 0x4, 0x2, 0x2, "itemCount", 0x3, "shrinkWrap", 0x2, Null]
    //     0xde22c8: ldr             x4, [x4, #0x128]
    // 0xde22cc: r0 = ListView.builder()
    //     0xde22cc: bl              #0xd8c3c8  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView.builder
    // 0xde22d0: ldur            x0, [fp, #-8]
    // 0xde22d4: LoadField: r1 = r0->field_b
    //     0xde22d4: ldur            w1, [x0, #0xb]
    // 0xde22d8: DecompressPointer r1
    //     0xde22d8: add             x1, x1, HEAP, lsl #32
    // 0xde22dc: cmp             w1, NULL
    // 0xde22e0: b.eq            #0xde2448
    // 0xde22e4: r0 = Text()
    //     0xde22e4: bl              #0x8a70a4  ; AllocateTextStub -> Text (size=0x50)
    // 0xde22e8: mov             x1, x0
    // 0xde22ec: r0 = "Cancel"
    //     0xde22ec: add             x0, PP, #0x24, lsl #12  ; [pp+0x24ce0] "Cancel"
    //     0xde22f0: ldr             x0, [x0, #0xce0]
    // 0xde22f4: stur            x1, [fp, #-8]
    // 0xde22f8: StoreField: r1->field_b = r0
    //     0xde22f8: stur            w0, [x1, #0xb]
    // 0xde22fc: r0 = ListTile()
    //     0xde22fc: bl              #0xd32f8c  ; AllocateListTileStub -> ListTile (size=0xa0)
    // 0xde2300: mov             x3, x0
    // 0xde2304: r0 = Instance_Icon
    //     0xde2304: add             x0, PP, #0xc6, lsl #12  ; [pp+0xc6648] Obj!Icon@12b5e21
    //     0xde2308: ldr             x0, [x0, #0x648]
    // 0xde230c: stur            x3, [fp, #-0x10]
    // 0xde2310: StoreField: r3->field_b = r0
    //     0xde2310: stur            w0, [x3, #0xb]
    // 0xde2314: ldur            x0, [fp, #-8]
    // 0xde2318: StoreField: r3->field_f = r0
    //     0xde2318: stur            w0, [x3, #0xf]
    // 0xde231c: r0 = true
    //     0xde231c: add             x0, NULL, #0x20  ; true
    // 0xde2320: StoreField: r3->field_4b = r0
    //     0xde2320: stur            w0, [x3, #0x4b]
    // 0xde2324: ldur            x2, [fp, #-0x18]
    // 0xde2328: r1 = Function '<anonymous closure>':.
    //     0xde2328: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd49a0] AnonymousClosure: (0xde244c), in [package:chewie/src/material/widgets/options_dialog.dart] _OptionsDialogState::build (0xde2234)
    //     0xde232c: ldr             x1, [x1, #0x9a0]
    // 0xde2330: r0 = AllocateClosure()
    //     0xde2330: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xde2334: mov             x1, x0
    // 0xde2338: ldur            x0, [fp, #-0x10]
    // 0xde233c: StoreField: r0->field_4f = r1
    //     0xde233c: stur            w1, [x0, #0x4f]
    // 0xde2340: r3 = false
    //     0xde2340: add             x3, NULL, #0x30  ; false
    // 0xde2344: StoreField: r0->field_5f = r3
    //     0xde2344: stur            w3, [x0, #0x5f]
    // 0xde2348: StoreField: r0->field_73 = r3
    //     0xde2348: stur            w3, [x0, #0x73]
    // 0xde234c: r4 = true
    //     0xde234c: add             x4, NULL, #0x20  ; true
    // 0xde2350: StoreField: r0->field_97 = r4
    //     0xde2350: stur            w4, [x0, #0x97]
    // 0xde2354: r1 = Null
    //     0xde2354: mov             x1, NULL
    // 0xde2358: r2 = 6
    //     0xde2358: mov             x2, #6
    // 0xde235c: r0 = AllocateArray()
    //     0xde235c: bl              #0x13df928  ; AllocateArrayStub
    // 0xde2360: mov             x2, x0
    // 0xde2364: ldur            x0, [fp, #-0x28]
    // 0xde2368: stur            x2, [fp, #-8]
    // 0xde236c: StoreField: r2->field_f = r0
    //     0xde236c: stur            w0, [x2, #0xf]
    // 0xde2370: r16 = Instance_Padding
    //     0xde2370: add             x16, PP, #0xd4, lsl #12  ; [pp+0xd49a8] Obj!Padding@12b7721
    //     0xde2374: ldr             x16, [x16, #0x9a8]
    // 0xde2378: StoreField: r2->field_13 = r16
    //     0xde2378: stur            w16, [x2, #0x13]
    // 0xde237c: ldur            x0, [fp, #-0x10]
    // 0xde2380: ArrayStore: r2[0] = r0  ; List_4
    //     0xde2380: stur            w0, [x2, #0x17]
    // 0xde2384: r1 = <Widget>
    //     0xde2384: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xde2388: r0 = AllocateGrowableArray()
    //     0xde2388: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xde238c: mov             x1, x0
    // 0xde2390: ldur            x0, [fp, #-8]
    // 0xde2394: stur            x1, [fp, #-0x10]
    // 0xde2398: StoreField: r1->field_f = r0
    //     0xde2398: stur            w0, [x1, #0xf]
    // 0xde239c: r0 = 6
    //     0xde239c: mov             x0, #6
    // 0xde23a0: StoreField: r1->field_b = r0
    //     0xde23a0: stur            w0, [x1, #0xb]
    // 0xde23a4: r0 = Column()
    //     0xde23a4: bl              #0x8a5b1c  ; AllocateColumnStub -> Column (size=0x38)
    // 0xde23a8: mov             x1, x0
    // 0xde23ac: r0 = Instance_Axis
    //     0xde23ac: ldr             x0, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xde23b0: stur            x1, [fp, #-8]
    // 0xde23b4: StoreField: r1->field_f = r0
    //     0xde23b4: stur            w0, [x1, #0xf]
    // 0xde23b8: r0 = Instance_MainAxisAlignment
    //     0xde23b8: add             x0, PP, #0x15, lsl #12  ; [pp+0x15820] Obj!MainAxisAlignment@12c4541
    //     0xde23bc: ldr             x0, [x0, #0x820]
    // 0xde23c0: StoreField: r1->field_13 = r0
    //     0xde23c0: stur            w0, [x1, #0x13]
    // 0xde23c4: r0 = Instance_MainAxisSize
    //     0xde23c4: add             x0, PP, #0x17, lsl #12  ; [pp+0x17200] Obj!MainAxisSize@12c4601
    //     0xde23c8: ldr             x0, [x0, #0x200]
    // 0xde23cc: ArrayStore: r1[0] = r0  ; List_4
    //     0xde23cc: stur            w0, [x1, #0x17]
    // 0xde23d0: r0 = Instance_CrossAxisAlignment
    //     0xde23d0: add             x0, PP, #0x15, lsl #12  ; [pp+0x15888] Obj!CrossAxisAlignment@12c44a1
    //     0xde23d4: ldr             x0, [x0, #0x888]
    // 0xde23d8: StoreField: r1->field_1b = r0
    //     0xde23d8: stur            w0, [x1, #0x1b]
    // 0xde23dc: r0 = Instance_VerticalDirection
    //     0xde23dc: add             x0, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xde23e0: ldr             x0, [x0, #0x838]
    // 0xde23e4: StoreField: r1->field_23 = r0
    //     0xde23e4: stur            w0, [x1, #0x23]
    // 0xde23e8: r0 = Instance_Clip
    //     0xde23e8: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xde23ec: ldr             x0, [x0, #0x840]
    // 0xde23f0: StoreField: r1->field_2b = r0
    //     0xde23f0: stur            w0, [x1, #0x2b]
    // 0xde23f4: StoreField: r1->field_2f = rZR
    //     0xde23f4: stur            xzr, [x1, #0x2f]
    // 0xde23f8: ldur            x0, [fp, #-0x10]
    // 0xde23fc: StoreField: r1->field_b = r0
    //     0xde23fc: stur            w0, [x1, #0xb]
    // 0xde2400: r0 = SafeArea()
    //     0xde2400: bl              #0xd73100  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0xde2404: r1 = true
    //     0xde2404: add             x1, NULL, #0x20  ; true
    // 0xde2408: StoreField: r0->field_b = r1
    //     0xde2408: stur            w1, [x0, #0xb]
    // 0xde240c: StoreField: r0->field_f = r1
    //     0xde240c: stur            w1, [x0, #0xf]
    // 0xde2410: StoreField: r0->field_13 = r1
    //     0xde2410: stur            w1, [x0, #0x13]
    // 0xde2414: ArrayStore: r0[0] = r1  ; List_4
    //     0xde2414: stur            w1, [x0, #0x17]
    // 0xde2418: r1 = Instance_EdgeInsets
    //     0xde2418: ldr             x1, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0xde241c: StoreField: r0->field_1b = r1
    //     0xde241c: stur            w1, [x0, #0x1b]
    // 0xde2420: r1 = false
    //     0xde2420: add             x1, NULL, #0x30  ; false
    // 0xde2424: StoreField: r0->field_1f = r1
    //     0xde2424: stur            w1, [x0, #0x1f]
    // 0xde2428: ldur            x1, [fp, #-8]
    // 0xde242c: StoreField: r0->field_23 = r1
    //     0xde242c: stur            w1, [x0, #0x23]
    // 0xde2430: LeaveFrame
    //     0xde2430: mov             SP, fp
    //     0xde2434: ldp             fp, lr, [SP], #0x10
    // 0xde2438: ret
    //     0xde2438: ret             
    // 0xde243c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde243c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde2440: b               #0xde2254
    // 0xde2444: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde2444: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde2448: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde2448: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xde244c, size: 0x54
    // 0xde244c: EnterFrame
    //     0xde244c: stp             fp, lr, [SP, #-0x10]!
    //     0xde2450: mov             fp, SP
    // 0xde2454: AllocStack(0x10)
    //     0xde2454: sub             SP, SP, #0x10
    // 0xde2458: SetupParameters([dynamic _ /* r0 */])
    //     0xde2458: ldr             x0, [fp, #0x10]
    //     0xde245c: ldur            w1, [x0, #0x17]
    //     0xde2460: add             x1, x1, HEAP, lsl #32
    // 0xde2464: CheckStackOverflow
    //     0xde2464: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde2468: cmp             SP, x16
    //     0xde246c: b.ls            #0xde2498
    // 0xde2470: LoadField: r0 = r1->field_13
    //     0xde2470: ldur            w0, [x1, #0x13]
    // 0xde2474: DecompressPointer r0
    //     0xde2474: add             x0, x0, HEAP, lsl #32
    // 0xde2478: r16 = <Object?>
    //     0xde2478: ldr             x16, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0xde247c: stp             x0, x16, [SP]
    // 0xde2480: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xde2480: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xde2484: r0 = pop()
    //     0xde2484: bl              #0xd190ec  ; [package:flutter/src/widgets/navigator.dart] Navigator::pop
    // 0xde2488: r0 = Null
    //     0xde2488: mov             x0, NULL
    // 0xde248c: LeaveFrame
    //     0xde248c: mov             SP, fp
    //     0xde2490: ldp             fp, lr, [SP], #0x10
    // 0xde2494: ret
    //     0xde2494: ret             
    // 0xde2498: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde2498: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde249c: b               #0xde2470
  }
  [closure] ListTile <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0xde24a0, size: 0x14c
    // 0xde24a0: EnterFrame
    //     0xde24a0: stp             fp, lr, [SP, #-0x10]!
    //     0xde24a4: mov             fp, SP
    // 0xde24a8: AllocStack(0x20)
    //     0xde24a8: sub             SP, SP, #0x20
    // 0xde24ac: SetupParameters([dynamic _ /* r0 */])
    //     0xde24ac: ldr             x0, [fp, #0x20]
    //     0xde24b0: ldur            w1, [x0, #0x17]
    //     0xde24b4: add             x1, x1, HEAP, lsl #32
    //     0xde24b8: stur            x1, [fp, #-8]
    // 0xde24bc: r1 = 2
    //     0xde24bc: mov             x1, #2
    // 0xde24c0: r0 = AllocateContext()
    //     0xde24c0: bl              #0x13de838  ; AllocateContextStub
    // 0xde24c4: mov             x2, x0
    // 0xde24c8: ldur            x0, [fp, #-8]
    // 0xde24cc: stur            x2, [fp, #-0x18]
    // 0xde24d0: StoreField: r2->field_b = r0
    //     0xde24d0: stur            w0, [x2, #0xb]
    // 0xde24d4: ldr             x1, [fp, #0x18]
    // 0xde24d8: StoreField: r2->field_f = r1
    //     0xde24d8: stur            w1, [x2, #0xf]
    // 0xde24dc: ldr             x1, [fp, #0x10]
    // 0xde24e0: StoreField: r2->field_13 = r1
    //     0xde24e0: stur            w1, [x2, #0x13]
    // 0xde24e4: LoadField: r3 = r0->field_f
    //     0xde24e4: ldur            w3, [x0, #0xf]
    // 0xde24e8: DecompressPointer r3
    //     0xde24e8: add             x3, x3, HEAP, lsl #32
    // 0xde24ec: LoadField: r0 = r3->field_b
    //     0xde24ec: ldur            w0, [x3, #0xb]
    // 0xde24f0: DecompressPointer r0
    //     0xde24f0: add             x0, x0, HEAP, lsl #32
    // 0xde24f4: cmp             w0, NULL
    // 0xde24f8: b.eq            #0xde25e4
    // 0xde24fc: LoadField: r3 = r0->field_b
    //     0xde24fc: ldur            w3, [x0, #0xb]
    // 0xde2500: DecompressPointer r3
    //     0xde2500: add             x3, x3, HEAP, lsl #32
    // 0xde2504: LoadField: r0 = r3->field_b
    //     0xde2504: ldur            w0, [x3, #0xb]
    // 0xde2508: r4 = LoadInt32Instr(r1)
    //     0xde2508: sbfx            x4, x1, #1, #0x1f
    //     0xde250c: tbz             w1, #0, #0xde2514
    //     0xde2510: ldur            x4, [x1, #7]
    // 0xde2514: r1 = LoadInt32Instr(r0)
    //     0xde2514: sbfx            x1, x0, #1, #0x1f
    // 0xde2518: mov             x0, x1
    // 0xde251c: mov             x1, x4
    // 0xde2520: cmp             x1, x0
    // 0xde2524: b.hs            #0xde25e8
    // 0xde2528: LoadField: r0 = r3->field_f
    //     0xde2528: ldur            w0, [x3, #0xf]
    // 0xde252c: DecompressPointer r0
    //     0xde252c: add             x0, x0, HEAP, lsl #32
    // 0xde2530: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0xde2530: add             x16, x0, x4, lsl #2
    //     0xde2534: ldur            w1, [x16, #0xf]
    // 0xde2538: DecompressPointer r1
    //     0xde2538: add             x1, x1, HEAP, lsl #32
    // 0xde253c: stur            x1, [fp, #-0x10]
    // 0xde2540: LoadField: r0 = r1->field_b
    //     0xde2540: ldur            w0, [x1, #0xb]
    // 0xde2544: DecompressPointer r0
    //     0xde2544: add             x0, x0, HEAP, lsl #32
    // 0xde2548: stur            x0, [fp, #-8]
    // 0xde254c: r0 = Icon()
    //     0xde254c: bl              #0xd0fd5c  ; AllocateIconStub -> Icon (size=0x40)
    // 0xde2550: mov             x1, x0
    // 0xde2554: ldur            x0, [fp, #-8]
    // 0xde2558: stur            x1, [fp, #-0x20]
    // 0xde255c: StoreField: r1->field_b = r0
    //     0xde255c: stur            w0, [x1, #0xb]
    // 0xde2560: ldur            x0, [fp, #-0x10]
    // 0xde2564: LoadField: r2 = r0->field_f
    //     0xde2564: ldur            w2, [x0, #0xf]
    // 0xde2568: DecompressPointer r2
    //     0xde2568: add             x2, x2, HEAP, lsl #32
    // 0xde256c: stur            x2, [fp, #-8]
    // 0xde2570: r0 = Text()
    //     0xde2570: bl              #0x8a70a4  ; AllocateTextStub -> Text (size=0x50)
    // 0xde2574: mov             x1, x0
    // 0xde2578: ldur            x0, [fp, #-8]
    // 0xde257c: stur            x1, [fp, #-0x10]
    // 0xde2580: StoreField: r1->field_b = r0
    //     0xde2580: stur            w0, [x1, #0xb]
    // 0xde2584: r0 = ListTile()
    //     0xde2584: bl              #0xd32f8c  ; AllocateListTileStub -> ListTile (size=0xa0)
    // 0xde2588: mov             x3, x0
    // 0xde258c: ldur            x0, [fp, #-0x20]
    // 0xde2590: stur            x3, [fp, #-8]
    // 0xde2594: StoreField: r3->field_b = r0
    //     0xde2594: stur            w0, [x3, #0xb]
    // 0xde2598: ldur            x0, [fp, #-0x10]
    // 0xde259c: StoreField: r3->field_f = r0
    //     0xde259c: stur            w0, [x3, #0xf]
    // 0xde25a0: r0 = true
    //     0xde25a0: add             x0, NULL, #0x20  ; true
    // 0xde25a4: StoreField: r3->field_4b = r0
    //     0xde25a4: stur            w0, [x3, #0x4b]
    // 0xde25a8: ldur            x2, [fp, #-0x18]
    // 0xde25ac: r1 = Function '<anonymous closure>':.
    //     0xde25ac: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd49b0] AnonymousClosure: (0xde25ec), in [package:chewie/src/material/widgets/options_dialog.dart] _OptionsDialogState::build (0xde2234)
    //     0xde25b0: ldr             x1, [x1, #0x9b0]
    // 0xde25b4: r0 = AllocateClosure()
    //     0xde25b4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xde25b8: mov             x1, x0
    // 0xde25bc: ldur            x0, [fp, #-8]
    // 0xde25c0: StoreField: r0->field_4f = r1
    //     0xde25c0: stur            w1, [x0, #0x4f]
    // 0xde25c4: r1 = false
    //     0xde25c4: add             x1, NULL, #0x30  ; false
    // 0xde25c8: StoreField: r0->field_5f = r1
    //     0xde25c8: stur            w1, [x0, #0x5f]
    // 0xde25cc: StoreField: r0->field_73 = r1
    //     0xde25cc: stur            w1, [x0, #0x73]
    // 0xde25d0: r1 = true
    //     0xde25d0: add             x1, NULL, #0x20  ; true
    // 0xde25d4: StoreField: r0->field_97 = r1
    //     0xde25d4: stur            w1, [x0, #0x97]
    // 0xde25d8: LeaveFrame
    //     0xde25d8: mov             SP, fp
    //     0xde25dc: ldp             fp, lr, [SP], #0x10
    // 0xde25e0: ret
    //     0xde25e0: ret             
    // 0xde25e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde25e4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde25e8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xde25e8: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xde25ec, size: 0xc8
    // 0xde25ec: EnterFrame
    //     0xde25ec: stp             fp, lr, [SP, #-0x10]!
    //     0xde25f0: mov             fp, SP
    // 0xde25f4: AllocStack(0x10)
    //     0xde25f4: sub             SP, SP, #0x10
    // 0xde25f8: SetupParameters([dynamic _ /* r0 */])
    //     0xde25f8: ldr             x0, [fp, #0x10]
    //     0xde25fc: ldur            w2, [x0, #0x17]
    //     0xde2600: add             x2, x2, HEAP, lsl #32
    // 0xde2604: CheckStackOverflow
    //     0xde2604: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde2608: cmp             SP, x16
    //     0xde260c: b.ls            #0xde26a4
    // 0xde2610: LoadField: r0 = r2->field_b
    //     0xde2610: ldur            w0, [x2, #0xb]
    // 0xde2614: DecompressPointer r0
    //     0xde2614: add             x0, x0, HEAP, lsl #32
    // 0xde2618: LoadField: r1 = r0->field_f
    //     0xde2618: ldur            w1, [x0, #0xf]
    // 0xde261c: DecompressPointer r1
    //     0xde261c: add             x1, x1, HEAP, lsl #32
    // 0xde2620: LoadField: r0 = r1->field_b
    //     0xde2620: ldur            w0, [x1, #0xb]
    // 0xde2624: DecompressPointer r0
    //     0xde2624: add             x0, x0, HEAP, lsl #32
    // 0xde2628: cmp             w0, NULL
    // 0xde262c: b.eq            #0xde26ac
    // 0xde2630: LoadField: r3 = r0->field_b
    //     0xde2630: ldur            w3, [x0, #0xb]
    // 0xde2634: DecompressPointer r3
    //     0xde2634: add             x3, x3, HEAP, lsl #32
    // 0xde2638: LoadField: r0 = r2->field_13
    //     0xde2638: ldur            w0, [x2, #0x13]
    // 0xde263c: DecompressPointer r0
    //     0xde263c: add             x0, x0, HEAP, lsl #32
    // 0xde2640: LoadField: r1 = r3->field_b
    //     0xde2640: ldur            w1, [x3, #0xb]
    // 0xde2644: r4 = LoadInt32Instr(r0)
    //     0xde2644: sbfx            x4, x0, #1, #0x1f
    //     0xde2648: tbz             w0, #0, #0xde2650
    //     0xde264c: ldur            x4, [x0, #7]
    // 0xde2650: r0 = LoadInt32Instr(r1)
    //     0xde2650: sbfx            x0, x1, #1, #0x1f
    // 0xde2654: mov             x1, x4
    // 0xde2658: cmp             x1, x0
    // 0xde265c: b.hs            #0xde26b0
    // 0xde2660: LoadField: r0 = r3->field_f
    //     0xde2660: ldur            w0, [x3, #0xf]
    // 0xde2664: DecompressPointer r0
    //     0xde2664: add             x0, x0, HEAP, lsl #32
    // 0xde2668: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0xde2668: add             x16, x0, x4, lsl #2
    //     0xde266c: ldur            w1, [x16, #0xf]
    // 0xde2670: DecompressPointer r1
    //     0xde2670: add             x1, x1, HEAP, lsl #32
    // 0xde2674: LoadField: r0 = r2->field_f
    //     0xde2674: ldur            w0, [x2, #0xf]
    // 0xde2678: DecompressPointer r0
    //     0xde2678: add             x0, x0, HEAP, lsl #32
    // 0xde267c: LoadField: r2 = r1->field_7
    //     0xde267c: ldur            w2, [x1, #7]
    // 0xde2680: DecompressPointer r2
    //     0xde2680: add             x2, x2, HEAP, lsl #32
    // 0xde2684: stp             x0, x2, [SP]
    // 0xde2688: mov             x0, x2
    // 0xde268c: ClosureCall
    //     0xde268c: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xde2690: ldur            x2, [x0, #0x1f]
    //     0xde2694: blr             x2
    // 0xde2698: LeaveFrame
    //     0xde2698: mov             SP, fp
    //     0xde269c: ldp             fp, lr, [SP], #0x10
    // 0xde26a0: ret
    //     0xde26a0: ret             
    // 0xde26a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde26a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde26a8: b               #0xde2610
    // 0xde26ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde26ac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde26b0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xde26b0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
}

// class id: 6533, size: 0x14, field offset: 0xc
//   const constructor, 
class OptionsDialog extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa00a0, size: 0x24
    // 0xfa00a0: EnterFrame
    //     0xfa00a0: stp             fp, lr, [SP, #-0x10]!
    //     0xfa00a4: mov             fp, SP
    // 0xfa00a8: mov             x0, x1
    // 0xfa00ac: r1 = <OptionsDialog>
    //     0xfa00ac: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4680] TypeArguments: <OptionsDialog>
    //     0xfa00b0: ldr             x1, [x1, #0x680]
    // 0xfa00b4: r0 = _OptionsDialogState()
    //     0xfa00b4: bl              #0xfa00c4  ; Allocate_OptionsDialogStateStub -> _OptionsDialogState (size=0x14)
    // 0xfa00b8: LeaveFrame
    //     0xfa00b8: mov             SP, fp
    //     0xfa00bc: ldp             fp, lr, [SP], #0x10
    // 0xfa00c0: ret
    //     0xfa00c0: ret             
  }
}
