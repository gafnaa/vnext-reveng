// lib: , url: package:chewie/src/material/widgets/playback_speed_dialog.dart

// class id: 1048640, size: 0x8
class :: {
}

// class id: 6212, size: 0x18, field offset: 0xc
//   const constructor, 
class PlaybackSpeedDialog extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfaaaf8, size: 0xd0
    // 0xfaaaf8: EnterFrame
    //     0xfaaaf8: stp             fp, lr, [SP, #-0x10]!
    //     0xfaaafc: mov             fp, SP
    // 0xfaab00: AllocStack(0x30)
    //     0xfaab00: sub             SP, SP, #0x30
    // 0xfaab04: SetupParameters(PlaybackSpeedDialog this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xfaab04: mov             x0, x1
    //     0xfaab08: stur            x1, [fp, #-8]
    //     0xfaab0c: mov             x1, x2
    //     0xfaab10: stur            x2, [fp, #-0x10]
    // 0xfaab14: CheckStackOverflow
    //     0xfaab14: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfaab18: cmp             SP, x16
    //     0xfaab1c: b.ls            #0xfaabc0
    // 0xfaab20: r1 = 2
    //     0xfaab20: mov             x1, #2
    // 0xfaab24: r0 = AllocateContext()
    //     0xfaab24: bl              #0x13de838  ; AllocateContextStub
    // 0xfaab28: mov             x2, x0
    // 0xfaab2c: ldur            x0, [fp, #-8]
    // 0xfaab30: stur            x2, [fp, #-0x18]
    // 0xfaab34: StoreField: r2->field_f = r0
    //     0xfaab34: stur            w0, [x2, #0xf]
    // 0xfaab38: ldur            x1, [fp, #-0x10]
    // 0xfaab3c: r0 = of()
    //     0xfaab3c: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfaab40: LoadField: r1 = r0->field_5b
    //     0xfaab40: ldur            w1, [x0, #0x5b]
    // 0xfaab44: DecompressPointer r1
    //     0xfaab44: add             x1, x1, HEAP, lsl #32
    // 0xfaab48: mov             x0, x1
    // 0xfaab4c: ldur            x2, [fp, #-0x18]
    // 0xfaab50: StoreField: r2->field_13 = r0
    //     0xfaab50: stur            w0, [x2, #0x13]
    //     0xfaab54: ldurb           w16, [x2, #-1]
    //     0xfaab58: ldurb           w17, [x0, #-1]
    //     0xfaab5c: and             x16, x17, x16, lsr #2
    //     0xfaab60: tst             x16, HEAP, lsr #32
    //     0xfaab64: b.eq            #0xfaab6c
    //     0xfaab68: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xfaab6c: r1 = Function '<anonymous closure>':.
    //     0xfaab6c: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4668] AnonymousClosure: (0xfaabc8), in [package:chewie/src/material/widgets/playback_speed_dialog.dart] PlaybackSpeedDialog::build (0xfaaaf8)
    //     0xfaab70: ldr             x1, [x1, #0x668]
    // 0xfaab74: r0 = AllocateClosure()
    //     0xfaab74: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfaab78: stur            x0, [fp, #-8]
    // 0xfaab7c: r0 = ListView()
    //     0xfaab7c: bl              #0xd8c860  ; AllocateListViewStub -> ListView (size=0x6c)
    // 0xfaab80: stur            x0, [fp, #-0x10]
    // 0xfaab84: r16 = true
    //     0xfaab84: add             x16, NULL, #0x20  ; true
    // 0xfaab88: r30 = Instance_ScrollPhysics
    //     0xfaab88: add             lr, PP, #0xd4, lsl #12  ; [pp+0xd4670] Obj!ScrollPhysics@129b551
    //     0xfaab8c: ldr             lr, [lr, #0x670]
    // 0xfaab90: stp             lr, x16, [SP, #8]
    // 0xfaab94: r16 = 16
    //     0xfaab94: mov             x16, #0x10
    // 0xfaab98: str             x16, [SP]
    // 0xfaab9c: mov             x1, x0
    // 0xfaaba0: ldur            x2, [fp, #-8]
    // 0xfaaba4: r4 = const [0, 0x5, 0x3, 0x2, itemCount, 0x4, physics, 0x3, shrinkWrap, 0x2, null]
    //     0xfaaba4: add             x4, PP, #0x1e, lsl #12  ; [pp+0x1eaf8] List(11) [0, 0x5, 0x3, 0x2, "itemCount", 0x4, "physics", 0x3, "shrinkWrap", 0x2, Null]
    //     0xfaaba8: ldr             x4, [x4, #0xaf8]
    // 0xfaabac: r0 = ListView.builder()
    //     0xfaabac: bl              #0xd8c3c8  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView.builder
    // 0xfaabb0: ldur            x0, [fp, #-0x10]
    // 0xfaabb4: LeaveFrame
    //     0xfaabb4: mov             SP, fp
    //     0xfaabb8: ldp             fp, lr, [SP], #0x10
    // 0xfaabbc: ret
    //     0xfaabbc: ret             
    // 0xfaabc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfaabc0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfaabc4: b               #0xfaab20
  }
  [closure] ListTile <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0xfaabc8, size: 0x414
    // 0xfaabc8: EnterFrame
    //     0xfaabc8: stp             fp, lr, [SP, #-0x10]!
    //     0xfaabcc: mov             fp, SP
    // 0xfaabd0: AllocStack(0x48)
    //     0xfaabd0: sub             SP, SP, #0x48
    // 0xfaabd4: SetupParameters([dynamic _ /* r0 */])
    //     0xfaabd4: ldr             x0, [fp, #0x20]
    //     0xfaabd8: ldur            w1, [x0, #0x17]
    //     0xfaabdc: add             x1, x1, HEAP, lsl #32
    //     0xfaabe0: stur            x1, [fp, #-8]
    // 0xfaabe4: CheckStackOverflow
    //     0xfaabe4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfaabe8: cmp             SP, x16
    //     0xfaabec: b.ls            #0xfaafcc
    // 0xfaabf0: r1 = 2
    //     0xfaabf0: mov             x1, #2
    // 0xfaabf4: r0 = AllocateContext()
    //     0xfaabf4: bl              #0x13de838  ; AllocateContextStub
    // 0xfaabf8: mov             x4, x0
    // 0xfaabfc: ldur            x3, [fp, #-8]
    // 0xfaac00: stur            x4, [fp, #-0x18]
    // 0xfaac04: StoreField: r4->field_b = r3
    //     0xfaac04: stur            w3, [x4, #0xb]
    // 0xfaac08: ldr             x0, [fp, #0x18]
    // 0xfaac0c: StoreField: r4->field_f = r0
    //     0xfaac0c: stur            w0, [x4, #0xf]
    // 0xfaac10: ldr             x0, [fp, #0x10]
    // 0xfaac14: r2 = LoadInt32Instr(r0)
    //     0xfaac14: sbfx            x2, x0, #1, #0x1f
    //     0xfaac18: tbz             w0, #0, #0xfaac20
    //     0xfaac1c: ldur            x2, [x0, #7]
    // 0xfaac20: mov             x1, x2
    // 0xfaac24: r0 = 8
    //     0xfaac24: mov             x0, #8
    // 0xfaac28: cmp             x1, x0
    // 0xfaac2c: b.hs            #0xfaafd4
    // 0xfaac30: r0 = const [0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0]
    //     0xfaac30: add             x0, PP, #0xa5, lsl #12  ; [pp+0xa5f68] List<double>(8)
    //     0xfaac34: ldr             x0, [x0, #0xf68]
    // 0xfaac38: ArrayLoad: r5 = r0[r2]  ; Unknown_4
    //     0xfaac38: add             x16, x0, x2, lsl #2
    //     0xfaac3c: ldur            w5, [x16, #0xf]
    // 0xfaac40: DecompressPointer r5
    //     0xfaac40: add             x5, x5, HEAP, lsl #32
    // 0xfaac44: stur            x5, [fp, #-0x10]
    // 0xfaac48: StoreField: r4->field_13 = r5
    //     0xfaac48: stur            w5, [x4, #0x13]
    // 0xfaac4c: r1 = <Widget>
    //     0xfaac4c: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xfaac50: r2 = 0
    //     0xfaac50: mov             x2, #0
    // 0xfaac54: r0 = _GrowableList()
    //     0xfaac54: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xfaac58: mov             x1, x0
    // 0xfaac5c: ldur            x0, [fp, #-8]
    // 0xfaac60: stur            x1, [fp, #-0x28]
    // 0xfaac64: LoadField: r2 = r0->field_f
    //     0xfaac64: ldur            w2, [x0, #0xf]
    // 0xfaac68: DecompressPointer r2
    //     0xfaac68: add             x2, x2, HEAP, lsl #32
    // 0xfaac6c: LoadField: d0 = r2->field_f
    //     0xfaac6c: ldur            d0, [x2, #0xf]
    // 0xfaac70: ldur            x2, [fp, #-0x10]
    // 0xfaac74: LoadField: d1 = r2->field_7
    //     0xfaac74: ldur            d1, [x2, #7]
    // 0xfaac78: stur            d1, [fp, #-0x40]
    // 0xfaac7c: fcmp            d1, d0
    // 0xfaac80: b.ne            #0xfaad44
    // 0xfaac84: LoadField: r3 = r0->field_13
    //     0xfaac84: ldur            w3, [x0, #0x13]
    // 0xfaac88: DecompressPointer r3
    //     0xfaac88: add             x3, x3, HEAP, lsl #32
    // 0xfaac8c: stur            x3, [fp, #-0x20]
    // 0xfaac90: r0 = Icon()
    //     0xfaac90: bl              #0xd0fd5c  ; AllocateIconStub -> Icon (size=0x40)
    // 0xfaac94: mov             x2, x0
    // 0xfaac98: r0 = Instance_IconData
    //     0xfaac98: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1ad80] Obj!IconData@128a9b1
    //     0xfaac9c: ldr             x0, [x0, #0xd80]
    // 0xfaaca0: stur            x2, [fp, #-0x38]
    // 0xfaaca4: StoreField: r2->field_b = r0
    //     0xfaaca4: stur            w0, [x2, #0xb]
    // 0xfaaca8: r0 = 20.000000
    //     0xfaaca8: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1ae98] 20
    //     0xfaacac: ldr             x0, [x0, #0xe98]
    // 0xfaacb0: StoreField: r2->field_f = r0
    //     0xfaacb0: stur            w0, [x2, #0xf]
    // 0xfaacb4: ldur            x0, [fp, #-0x20]
    // 0xfaacb8: StoreField: r2->field_23 = r0
    //     0xfaacb8: stur            w0, [x2, #0x23]
    // 0xfaacbc: ldur            x0, [fp, #-0x28]
    // 0xfaacc0: LoadField: r1 = r0->field_b
    //     0xfaacc0: ldur            w1, [x0, #0xb]
    // 0xfaacc4: LoadField: r3 = r0->field_f
    //     0xfaacc4: ldur            w3, [x0, #0xf]
    // 0xfaacc8: DecompressPointer r3
    //     0xfaacc8: add             x3, x3, HEAP, lsl #32
    // 0xfaaccc: LoadField: r4 = r3->field_b
    //     0xfaaccc: ldur            w4, [x3, #0xb]
    // 0xfaacd0: r3 = LoadInt32Instr(r1)
    //     0xfaacd0: sbfx            x3, x1, #1, #0x1f
    // 0xfaacd4: stur            x3, [fp, #-0x30]
    // 0xfaacd8: r1 = LoadInt32Instr(r4)
    //     0xfaacd8: sbfx            x1, x4, #1, #0x1f
    // 0xfaacdc: cmp             x3, x1
    // 0xfaace0: b.ne            #0xfaacec
    // 0xfaace4: mov             x1, x0
    // 0xfaace8: r0 = _growToNextCapacity()
    //     0xfaace8: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xfaacec: ldur            x2, [fp, #-0x28]
    // 0xfaacf0: ldur            x3, [fp, #-0x30]
    // 0xfaacf4: add             x4, x3, #1
    // 0xfaacf8: lsl             x0, x4, #1
    // 0xfaacfc: StoreField: r2->field_b = r0
    //     0xfaacfc: stur            w0, [x2, #0xb]
    // 0xfaad00: LoadField: r5 = r2->field_f
    //     0xfaad00: ldur            w5, [x2, #0xf]
    // 0xfaad04: DecompressPointer r5
    //     0xfaad04: add             x5, x5, HEAP, lsl #32
    // 0xfaad08: mov             x1, x5
    // 0xfaad0c: ldur            x0, [fp, #-0x38]
    // 0xfaad10: ArrayStore: r1[r3] = r0  ; List_4
    //     0xfaad10: add             x25, x1, x3, lsl #2
    //     0xfaad14: add             x25, x25, #0xf
    //     0xfaad18: str             w0, [x25]
    //     0xfaad1c: tbz             w0, #0, #0xfaad38
    //     0xfaad20: ldurb           w16, [x1, #-1]
    //     0xfaad24: ldurb           w17, [x0, #-1]
    //     0xfaad28: and             x16, x17, x16, lsr #2
    //     0xfaad2c: tst             x16, HEAP, lsr #32
    //     0xfaad30: b.eq            #0xfaad38
    //     0xfaad34: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xfaad38: mov             x3, x4
    // 0xfaad3c: mov             x0, x5
    // 0xfaad40: b               #0xfaadf0
    // 0xfaad44: mov             x2, x1
    // 0xfaad48: r0 = Container()
    //     0xfaad48: bl              #0x8a5af8  ; AllocateContainerStub -> Container (size=0x38)
    // 0xfaad4c: stur            x0, [fp, #-0x20]
    // 0xfaad50: r16 = 20.000000
    //     0xfaad50: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1ae98] 20
    //     0xfaad54: ldr             x16, [x16, #0xe98]
    // 0xfaad58: str             x16, [SP]
    // 0xfaad5c: mov             x1, x0
    // 0xfaad60: r4 = const [0, 0x2, 0x1, 0x1, width, 0x1, null]
    //     0xfaad60: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1f198] List(7) [0, 0x2, 0x1, 0x1, "width", 0x1, Null]
    //     0xfaad64: ldr             x4, [x4, #0x198]
    // 0xfaad68: r0 = Container()
    //     0xfaad68: bl              #0x8a54e0  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0xfaad6c: ldur            x0, [fp, #-0x28]
    // 0xfaad70: LoadField: r1 = r0->field_b
    //     0xfaad70: ldur            w1, [x0, #0xb]
    // 0xfaad74: LoadField: r2 = r0->field_f
    //     0xfaad74: ldur            w2, [x0, #0xf]
    // 0xfaad78: DecompressPointer r2
    //     0xfaad78: add             x2, x2, HEAP, lsl #32
    // 0xfaad7c: LoadField: r3 = r2->field_b
    //     0xfaad7c: ldur            w3, [x2, #0xb]
    // 0xfaad80: r2 = LoadInt32Instr(r1)
    //     0xfaad80: sbfx            x2, x1, #1, #0x1f
    // 0xfaad84: stur            x2, [fp, #-0x30]
    // 0xfaad88: r1 = LoadInt32Instr(r3)
    //     0xfaad88: sbfx            x1, x3, #1, #0x1f
    // 0xfaad8c: cmp             x2, x1
    // 0xfaad90: b.ne            #0xfaad9c
    // 0xfaad94: mov             x1, x0
    // 0xfaad98: r0 = _growToNextCapacity()
    //     0xfaad98: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xfaad9c: ldur            x2, [fp, #-0x28]
    // 0xfaada0: ldur            x3, [fp, #-0x30]
    // 0xfaada4: add             x4, x3, #1
    // 0xfaada8: lsl             x0, x4, #1
    // 0xfaadac: StoreField: r2->field_b = r0
    //     0xfaadac: stur            w0, [x2, #0xb]
    // 0xfaadb0: LoadField: r5 = r2->field_f
    //     0xfaadb0: ldur            w5, [x2, #0xf]
    // 0xfaadb4: DecompressPointer r5
    //     0xfaadb4: add             x5, x5, HEAP, lsl #32
    // 0xfaadb8: mov             x1, x5
    // 0xfaadbc: ldur            x0, [fp, #-0x20]
    // 0xfaadc0: ArrayStore: r1[r3] = r0  ; List_4
    //     0xfaadc0: add             x25, x1, x3, lsl #2
    //     0xfaadc4: add             x25, x25, #0xf
    //     0xfaadc8: str             w0, [x25]
    //     0xfaadcc: tbz             w0, #0, #0xfaade8
    //     0xfaadd0: ldurb           w16, [x1, #-1]
    //     0xfaadd4: ldurb           w17, [x0, #-1]
    //     0xfaadd8: and             x16, x17, x16, lsr #2
    //     0xfaaddc: tst             x16, HEAP, lsr #32
    //     0xfaade0: b.eq            #0xfaade8
    //     0xfaade4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xfaade8: mov             x3, x4
    // 0xfaadec: mov             x0, x5
    // 0xfaadf0: stur            x3, [fp, #-0x30]
    // 0xfaadf4: LoadField: r1 = r0->field_b
    //     0xfaadf4: ldur            w1, [x0, #0xb]
    // 0xfaadf8: r0 = LoadInt32Instr(r1)
    //     0xfaadf8: sbfx            x0, x1, #1, #0x1f
    // 0xfaadfc: cmp             x3, x0
    // 0xfaae00: b.ne            #0xfaae0c
    // 0xfaae04: mov             x1, x2
    // 0xfaae08: r0 = _growToNextCapacity()
    //     0xfaae08: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xfaae0c: ldur            x2, [fp, #-0x28]
    // 0xfaae10: ldur            x3, [fp, #-0x30]
    // 0xfaae14: add             x0, x3, #1
    // 0xfaae18: lsl             x1, x0, #1
    // 0xfaae1c: StoreField: r2->field_b = r1
    //     0xfaae1c: stur            w1, [x2, #0xb]
    // 0xfaae20: mov             x1, x3
    // 0xfaae24: cmp             x1, x0
    // 0xfaae28: b.hs            #0xfaafd8
    // 0xfaae2c: LoadField: r0 = r2->field_f
    //     0xfaae2c: ldur            w0, [x2, #0xf]
    // 0xfaae30: DecompressPointer r0
    //     0xfaae30: add             x0, x0, HEAP, lsl #32
    // 0xfaae34: add             x1, x0, x3, lsl #2
    // 0xfaae38: r16 = Instance_SizedBox
    //     0xfaae38: add             x16, PP, #0x9d, lsl #12  ; [pp+0x9d0b0] Obj!SizedBox@12b7341
    //     0xfaae3c: ldr             x16, [x16, #0xb0]
    // 0xfaae40: StoreField: r1->field_f = r16
    //     0xfaae40: stur            w16, [x1, #0xf]
    // 0xfaae44: ldur            x16, [fp, #-0x10]
    // 0xfaae48: str             x16, [SP]
    // 0xfaae4c: r0 = toString()
    //     0xfaae4c: bl              #0x112a5f0  ; [dart:core] _Double::toString
    // 0xfaae50: stur            x0, [fp, #-0x10]
    // 0xfaae54: r0 = Text()
    //     0xfaae54: bl              #0x8a70a4  ; AllocateTextStub -> Text (size=0x50)
    // 0xfaae58: mov             x2, x0
    // 0xfaae5c: ldur            x0, [fp, #-0x10]
    // 0xfaae60: stur            x2, [fp, #-0x20]
    // 0xfaae64: StoreField: r2->field_b = r0
    //     0xfaae64: stur            w0, [x2, #0xb]
    // 0xfaae68: ldur            x0, [fp, #-0x28]
    // 0xfaae6c: LoadField: r1 = r0->field_b
    //     0xfaae6c: ldur            w1, [x0, #0xb]
    // 0xfaae70: LoadField: r3 = r0->field_f
    //     0xfaae70: ldur            w3, [x0, #0xf]
    // 0xfaae74: DecompressPointer r3
    //     0xfaae74: add             x3, x3, HEAP, lsl #32
    // 0xfaae78: LoadField: r4 = r3->field_b
    //     0xfaae78: ldur            w4, [x3, #0xb]
    // 0xfaae7c: r3 = LoadInt32Instr(r1)
    //     0xfaae7c: sbfx            x3, x1, #1, #0x1f
    // 0xfaae80: stur            x3, [fp, #-0x30]
    // 0xfaae84: r1 = LoadInt32Instr(r4)
    //     0xfaae84: sbfx            x1, x4, #1, #0x1f
    // 0xfaae88: cmp             x3, x1
    // 0xfaae8c: b.ne            #0xfaae98
    // 0xfaae90: mov             x1, x0
    // 0xfaae94: r0 = _growToNextCapacity()
    //     0xfaae94: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xfaae98: ldur            x4, [fp, #-8]
    // 0xfaae9c: ldur            x2, [fp, #-0x28]
    // 0xfaaea0: ldur            d0, [fp, #-0x40]
    // 0xfaaea4: ldur            x3, [fp, #-0x30]
    // 0xfaaea8: add             x0, x3, #1
    // 0xfaaeac: lsl             x1, x0, #1
    // 0xfaaeb0: StoreField: r2->field_b = r1
    //     0xfaaeb0: stur            w1, [x2, #0xb]
    // 0xfaaeb4: LoadField: r1 = r2->field_f
    //     0xfaaeb4: ldur            w1, [x2, #0xf]
    // 0xfaaeb8: DecompressPointer r1
    //     0xfaaeb8: add             x1, x1, HEAP, lsl #32
    // 0xfaaebc: ldur            x0, [fp, #-0x20]
    // 0xfaaec0: ArrayStore: r1[r3] = r0  ; List_4
    //     0xfaaec0: add             x25, x1, x3, lsl #2
    //     0xfaaec4: add             x25, x25, #0xf
    //     0xfaaec8: str             w0, [x25]
    //     0xfaaecc: tbz             w0, #0, #0xfaaee8
    //     0xfaaed0: ldurb           w16, [x1, #-1]
    //     0xfaaed4: ldurb           w17, [x0, #-1]
    //     0xfaaed8: and             x16, x17, x16, lsr #2
    //     0xfaaedc: tst             x16, HEAP, lsr #32
    //     0xfaaee0: b.eq            #0xfaaee8
    //     0xfaaee4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xfaaee8: r0 = Row()
    //     0xfaaee8: bl              #0x8a5b04  ; AllocateRowStub -> Row (size=0x38)
    // 0xfaaeec: mov             x1, x0
    // 0xfaaef0: r0 = Instance_Axis
    //     0xfaaef0: ldr             x0, [PP, #0x49c8]  ; [pp+0x49c8] Obj!Axis@12c4a61
    // 0xfaaef4: stur            x1, [fp, #-0x10]
    // 0xfaaef8: StoreField: r1->field_f = r0
    //     0xfaaef8: stur            w0, [x1, #0xf]
    // 0xfaaefc: r0 = Instance_MainAxisAlignment
    //     0xfaaefc: add             x0, PP, #0x15, lsl #12  ; [pp+0x15820] Obj!MainAxisAlignment@12c4541
    //     0xfaaf00: ldr             x0, [x0, #0x820]
    // 0xfaaf04: StoreField: r1->field_13 = r0
    //     0xfaaf04: stur            w0, [x1, #0x13]
    // 0xfaaf08: r0 = Instance_MainAxisSize
    //     0xfaaf08: add             x0, PP, #0x15, lsl #12  ; [pp+0x15828] Obj!MainAxisSize@12c4621
    //     0xfaaf0c: ldr             x0, [x0, #0x828]
    // 0xfaaf10: ArrayStore: r1[0] = r0  ; List_4
    //     0xfaaf10: stur            w0, [x1, #0x17]
    // 0xfaaf14: r0 = Instance_CrossAxisAlignment
    //     0xfaaf14: add             x0, PP, #0x15, lsl #12  ; [pp+0x15888] Obj!CrossAxisAlignment@12c44a1
    //     0xfaaf18: ldr             x0, [x0, #0x888]
    // 0xfaaf1c: StoreField: r1->field_1b = r0
    //     0xfaaf1c: stur            w0, [x1, #0x1b]
    // 0xfaaf20: r0 = Instance_VerticalDirection
    //     0xfaaf20: add             x0, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xfaaf24: ldr             x0, [x0, #0x838]
    // 0xfaaf28: StoreField: r1->field_23 = r0
    //     0xfaaf28: stur            w0, [x1, #0x23]
    // 0xfaaf2c: r0 = Instance_Clip
    //     0xfaaf2c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xfaaf30: ldr             x0, [x0, #0x840]
    // 0xfaaf34: StoreField: r1->field_2b = r0
    //     0xfaaf34: stur            w0, [x1, #0x2b]
    // 0xfaaf38: StoreField: r1->field_2f = rZR
    //     0xfaaf38: stur            xzr, [x1, #0x2f]
    // 0xfaaf3c: ldur            x0, [fp, #-0x28]
    // 0xfaaf40: StoreField: r1->field_b = r0
    //     0xfaaf40: stur            w0, [x1, #0xb]
    // 0xfaaf44: ldur            x0, [fp, #-8]
    // 0xfaaf48: LoadField: r2 = r0->field_f
    //     0xfaaf48: ldur            w2, [x0, #0xf]
    // 0xfaaf4c: DecompressPointer r2
    //     0xfaaf4c: add             x2, x2, HEAP, lsl #32
    // 0xfaaf50: LoadField: d0 = r2->field_f
    //     0xfaaf50: ldur            d0, [x2, #0xf]
    // 0xfaaf54: ldur            d1, [fp, #-0x40]
    // 0xfaaf58: fcmp            d1, d0
    // 0xfaaf5c: r16 = true
    //     0xfaaf5c: add             x16, NULL, #0x20  ; true
    // 0xfaaf60: r17 = false
    //     0xfaaf60: add             x17, NULL, #0x30  ; false
    // 0xfaaf64: csel            x0, x16, x17, eq
    // 0xfaaf68: stur            x0, [fp, #-8]
    // 0xfaaf6c: r0 = ListTile()
    //     0xfaaf6c: bl              #0xd32f8c  ; AllocateListTileStub -> ListTile (size=0xa0)
    // 0xfaaf70: mov             x3, x0
    // 0xfaaf74: ldur            x0, [fp, #-0x10]
    // 0xfaaf78: stur            x3, [fp, #-0x20]
    // 0xfaaf7c: StoreField: r3->field_f = r0
    //     0xfaaf7c: stur            w0, [x3, #0xf]
    // 0xfaaf80: r0 = true
    //     0xfaaf80: add             x0, NULL, #0x20  ; true
    // 0xfaaf84: StoreField: r3->field_1f = r0
    //     0xfaaf84: stur            w0, [x3, #0x1f]
    // 0xfaaf88: StoreField: r3->field_4b = r0
    //     0xfaaf88: stur            w0, [x3, #0x4b]
    // 0xfaaf8c: ldur            x2, [fp, #-0x18]
    // 0xfaaf90: r1 = Function '<anonymous closure>':.
    //     0xfaaf90: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4678] AnonymousClosure: (0xfaafdc), in [package:chewie/src/material/widgets/playback_speed_dialog.dart] PlaybackSpeedDialog::build (0xfaaaf8)
    //     0xfaaf94: ldr             x1, [x1, #0x678]
    // 0xfaaf98: r0 = AllocateClosure()
    //     0xfaaf98: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfaaf9c: mov             x1, x0
    // 0xfaafa0: ldur            x0, [fp, #-0x20]
    // 0xfaafa4: StoreField: r0->field_4f = r1
    //     0xfaafa4: stur            w1, [x0, #0x4f]
    // 0xfaafa8: ldur            x1, [fp, #-8]
    // 0xfaafac: StoreField: r0->field_5f = r1
    //     0xfaafac: stur            w1, [x0, #0x5f]
    // 0xfaafb0: r1 = false
    //     0xfaafb0: add             x1, NULL, #0x30  ; false
    // 0xfaafb4: StoreField: r0->field_73 = r1
    //     0xfaafb4: stur            w1, [x0, #0x73]
    // 0xfaafb8: r1 = true
    //     0xfaafb8: add             x1, NULL, #0x20  ; true
    // 0xfaafbc: StoreField: r0->field_97 = r1
    //     0xfaafbc: stur            w1, [x0, #0x97]
    // 0xfaafc0: LeaveFrame
    //     0xfaafc0: mov             SP, fp
    //     0xfaafc4: ldp             fp, lr, [SP], #0x10
    // 0xfaafc8: ret
    //     0xfaafc8: ret             
    // 0xfaafcc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfaafcc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfaafd0: b               #0xfaabf0
    // 0xfaafd4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xfaafd4: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xfaafd8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xfaafd8: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xfaafdc, size: 0x74
    // 0xfaafdc: EnterFrame
    //     0xfaafdc: stp             fp, lr, [SP, #-0x10]!
    //     0xfaafe0: mov             fp, SP
    // 0xfaafe4: AllocStack(0x20)
    //     0xfaafe4: sub             SP, SP, #0x20
    // 0xfaafe8: SetupParameters([dynamic _ /* r0 */])
    //     0xfaafe8: ldr             x0, [fp, #0x10]
    //     0xfaafec: ldur            w2, [x0, #0x17]
    //     0xfaaff0: add             x2, x2, HEAP, lsl #32
    //     0xfaaff4: stur            x2, [fp, #-8]
    // 0xfaaff8: CheckStackOverflow
    //     0xfaaff8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfaaffc: cmp             SP, x16
    //     0xfab000: b.ls            #0xfab048
    // 0xfab004: LoadField: r1 = r2->field_f
    //     0xfab004: ldur            w1, [x2, #0xf]
    // 0xfab008: DecompressPointer r1
    //     0xfab008: add             x1, x1, HEAP, lsl #32
    // 0xfab00c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xfab00c: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xfab010: r0 = of()
    //     0xfab010: bl              #0xb35e68  ; [package:flutter/src/widgets/navigator.dart] Navigator::of
    // 0xfab014: mov             x1, x0
    // 0xfab018: ldur            x0, [fp, #-8]
    // 0xfab01c: LoadField: r2 = r0->field_13
    //     0xfab01c: ldur            w2, [x0, #0x13]
    // 0xfab020: DecompressPointer r2
    //     0xfab020: add             x2, x2, HEAP, lsl #32
    // 0xfab024: r16 = <double>
    //     0xfab024: ldr             x16, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xfab028: stp             x1, x16, [SP, #8]
    // 0xfab02c: str             x2, [SP]
    // 0xfab030: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xfab030: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xfab034: r0 = pop()
    //     0xfab034: bl              #0x8c87a0  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::pop
    // 0xfab038: r0 = Null
    //     0xfab038: mov             x0, NULL
    // 0xfab03c: LeaveFrame
    //     0xfab03c: mov             SP, fp
    //     0xfab040: ldp             fp, lr, [SP], #0x10
    // 0xfab044: ret
    //     0xfab044: ret             
    // 0xfab048: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfab048: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfab04c: b               #0xfab004
  }
}
