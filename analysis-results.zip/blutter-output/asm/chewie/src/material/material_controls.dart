// lib: , url: package:chewie/src/material/material_controls.dart

// class id: 1048636, size: 0x8
class :: {
}

// class id: 5562, size: 0x60, field offset: 0x1c
class _MaterialControlsState extends _MixinApplication738&State&SingleTickerProviderStateMixin {

  late VideoPlayerController controller; // offset: 0x58
  late PlayerNotifier notifier; // offset: 0x1c
  late VideoPlayerValue _latestValue; // offset: 0x20

  _ build(/* No info */) {
    // ** addr: 0xdd39bc, size: 0x49c
    // 0xdd39bc: EnterFrame
    //     0xdd39bc: stp             fp, lr, [SP, #-0x10]!
    //     0xdd39c0: mov             fp, SP
    // 0xdd39c4: AllocStack(0x48)
    //     0xdd39c4: sub             SP, SP, #0x48
    // 0xdd39c8: SetupParameters(_MaterialControlsState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xdd39c8: stur            x1, [fp, #-8]
    //     0xdd39cc: stur            x2, [fp, #-0x10]
    // 0xdd39d0: CheckStackOverflow
    //     0xdd39d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd39d4: cmp             SP, x16
    //     0xdd39d8: b.ls            #0xdd3e34
    // 0xdd39dc: r1 = 1
    //     0xdd39dc: mov             x1, #1
    // 0xdd39e0: r0 = AllocateContext()
    //     0xdd39e0: bl              #0x13de838  ; AllocateContextStub
    // 0xdd39e4: mov             x3, x0
    // 0xdd39e8: ldur            x0, [fp, #-8]
    // 0xdd39ec: stur            x3, [fp, #-0x20]
    // 0xdd39f0: StoreField: r3->field_f = r0
    //     0xdd39f0: stur            w0, [x3, #0xf]
    // 0xdd39f4: LoadField: r1 = r0->field_1f
    //     0xdd39f4: ldur            w1, [x0, #0x1f]
    // 0xdd39f8: DecompressPointer r1
    //     0xdd39f8: add             x1, x1, HEAP, lsl #32
    // 0xdd39fc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd3a00: cmp             w1, w16
    // 0xdd3a04: b.eq            #0xdd3e3c
    // 0xdd3a08: LoadField: r2 = r1->field_37
    //     0xdd3a08: ldur            w2, [x1, #0x37]
    // 0xdd3a0c: DecompressPointer r2
    //     0xdd3a0c: add             x2, x2, HEAP, lsl #32
    // 0xdd3a10: cmp             w2, NULL
    // 0xdd3a14: b.eq            #0xdd3a3c
    // 0xdd3a18: LoadField: r1 = r0->field_5b
    //     0xdd3a18: ldur            w1, [x0, #0x5b]
    // 0xdd3a1c: DecompressPointer r1
    //     0xdd3a1c: add             x1, x1, HEAP, lsl #32
    // 0xdd3a20: cmp             w1, NULL
    // 0xdd3a24: b.eq            #0xdd3e48
    // 0xdd3a28: r0 = Instance_Center
    //     0xdd3a28: add             x0, PP, #0xd3, lsl #12  ; [pp+0xd3cf0] Obj!Center@12b75e1
    //     0xdd3a2c: ldr             x0, [x0, #0xcf0]
    // 0xdd3a30: LeaveFrame
    //     0xdd3a30: mov             SP, fp
    //     0xdd3a34: ldp             fp, lr, [SP], #0x10
    // 0xdd3a38: ret
    //     0xdd3a38: ret             
    // 0xdd3a3c: LoadField: r1 = r0->field_1b
    //     0xdd3a3c: ldur            w1, [x0, #0x1b]
    // 0xdd3a40: DecompressPointer r1
    //     0xdd3a40: add             x1, x1, HEAP, lsl #32
    // 0xdd3a44: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd3a48: cmp             w1, w16
    // 0xdd3a4c: b.eq            #0xdd3e4c
    // 0xdd3a50: LoadField: r4 = r1->field_23
    //     0xdd3a50: ldur            w4, [x1, #0x23]
    // 0xdd3a54: DecompressPointer r4
    //     0xdd3a54: add             x4, x4, HEAP, lsl #32
    // 0xdd3a58: stur            x4, [fp, #-0x18]
    // 0xdd3a5c: r1 = <Widget>
    //     0xdd3a5c: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xdd3a60: r2 = 0
    //     0xdd3a60: mov             x2, #0
    // 0xdd3a64: r0 = _GrowableList()
    //     0xdd3a64: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xdd3a68: mov             x2, x0
    // 0xdd3a6c: ldur            x0, [fp, #-8]
    // 0xdd3a70: stur            x2, [fp, #-0x30]
    // 0xdd3a74: LoadField: r1 = r0->field_43
    //     0xdd3a74: ldur            w1, [x0, #0x43]
    // 0xdd3a78: DecompressPointer r1
    //     0xdd3a78: add             x1, x1, HEAP, lsl #32
    // 0xdd3a7c: tbnz            w1, #4, #0xdd3ae0
    // 0xdd3a80: LoadField: r1 = r2->field_b
    //     0xdd3a80: ldur            w1, [x2, #0xb]
    // 0xdd3a84: LoadField: r3 = r2->field_f
    //     0xdd3a84: ldur            w3, [x2, #0xf]
    // 0xdd3a88: DecompressPointer r3
    //     0xdd3a88: add             x3, x3, HEAP, lsl #32
    // 0xdd3a8c: LoadField: r4 = r3->field_b
    //     0xdd3a8c: ldur            w4, [x3, #0xb]
    // 0xdd3a90: r3 = LoadInt32Instr(r1)
    //     0xdd3a90: sbfx            x3, x1, #1, #0x1f
    // 0xdd3a94: stur            x3, [fp, #-0x28]
    // 0xdd3a98: r1 = LoadInt32Instr(r4)
    //     0xdd3a98: sbfx            x1, x4, #1, #0x1f
    // 0xdd3a9c: cmp             x3, x1
    // 0xdd3aa0: b.ne            #0xdd3aac
    // 0xdd3aa4: mov             x1, x2
    // 0xdd3aa8: r0 = _growToNextCapacity()
    //     0xdd3aa8: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xdd3aac: ldur            x0, [fp, #-0x30]
    // 0xdd3ab0: ldur            x1, [fp, #-0x28]
    // 0xdd3ab4: add             x2, x1, #1
    // 0xdd3ab8: lsl             x3, x2, #1
    // 0xdd3abc: StoreField: r0->field_b = r3
    //     0xdd3abc: stur            w3, [x0, #0xb]
    // 0xdd3ac0: LoadField: r2 = r0->field_f
    //     0xdd3ac0: ldur            w2, [x0, #0xf]
    // 0xdd3ac4: DecompressPointer r2
    //     0xdd3ac4: add             x2, x2, HEAP, lsl #32
    // 0xdd3ac8: add             x3, x2, x1, lsl #2
    // 0xdd3acc: r16 = Instance_Center
    //     0xdd3acc: add             x16, PP, #0x15, lsl #12  ; [pp+0x157b8] Obj!Center@12b75a1
    //     0xdd3ad0: ldr             x16, [x16, #0x7b8]
    // 0xdd3ad4: StoreField: r3->field_f = r16
    //     0xdd3ad4: stur            w16, [x3, #0xf]
    // 0xdd3ad8: mov             x2, x0
    // 0xdd3adc: b               #0xdd3b6c
    // 0xdd3ae0: mov             x0, x2
    // 0xdd3ae4: ldur            x1, [fp, #-8]
    // 0xdd3ae8: r0 = _buildHitArea()
    //     0xdd3ae8: bl              #0xdd6924  ; [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_buildHitArea
    // 0xdd3aec: mov             x2, x0
    // 0xdd3af0: ldur            x0, [fp, #-0x30]
    // 0xdd3af4: stur            x2, [fp, #-0x38]
    // 0xdd3af8: LoadField: r1 = r0->field_b
    //     0xdd3af8: ldur            w1, [x0, #0xb]
    // 0xdd3afc: LoadField: r3 = r0->field_f
    //     0xdd3afc: ldur            w3, [x0, #0xf]
    // 0xdd3b00: DecompressPointer r3
    //     0xdd3b00: add             x3, x3, HEAP, lsl #32
    // 0xdd3b04: LoadField: r4 = r3->field_b
    //     0xdd3b04: ldur            w4, [x3, #0xb]
    // 0xdd3b08: r3 = LoadInt32Instr(r1)
    //     0xdd3b08: sbfx            x3, x1, #1, #0x1f
    // 0xdd3b0c: stur            x3, [fp, #-0x28]
    // 0xdd3b10: r1 = LoadInt32Instr(r4)
    //     0xdd3b10: sbfx            x1, x4, #1, #0x1f
    // 0xdd3b14: cmp             x3, x1
    // 0xdd3b18: b.ne            #0xdd3b24
    // 0xdd3b1c: mov             x1, x0
    // 0xdd3b20: r0 = _growToNextCapacity()
    //     0xdd3b20: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xdd3b24: ldur            x2, [fp, #-0x30]
    // 0xdd3b28: ldur            x3, [fp, #-0x28]
    // 0xdd3b2c: add             x0, x3, #1
    // 0xdd3b30: lsl             x1, x0, #1
    // 0xdd3b34: StoreField: r2->field_b = r1
    //     0xdd3b34: stur            w1, [x2, #0xb]
    // 0xdd3b38: LoadField: r1 = r2->field_f
    //     0xdd3b38: ldur            w1, [x2, #0xf]
    // 0xdd3b3c: DecompressPointer r1
    //     0xdd3b3c: add             x1, x1, HEAP, lsl #32
    // 0xdd3b40: ldur            x0, [fp, #-0x38]
    // 0xdd3b44: ArrayStore: r1[r3] = r0  ; List_4
    //     0xdd3b44: add             x25, x1, x3, lsl #2
    //     0xdd3b48: add             x25, x25, #0xf
    //     0xdd3b4c: str             w0, [x25]
    //     0xdd3b50: tbz             w0, #0, #0xdd3b6c
    //     0xdd3b54: ldurb           w16, [x1, #-1]
    //     0xdd3b58: ldurb           w17, [x0, #-1]
    //     0xdd3b5c: and             x16, x17, x16, lsr #2
    //     0xdd3b60: tst             x16, HEAP, lsr #32
    //     0xdd3b64: b.eq            #0xdd3b6c
    //     0xdd3b68: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdd3b6c: ldur            x1, [fp, #-8]
    // 0xdd3b70: r0 = _buildActionBar()
    //     0xdd3b70: bl              #0xdd59ac  ; [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_buildActionBar
    // 0xdd3b74: mov             x2, x0
    // 0xdd3b78: ldur            x0, [fp, #-0x30]
    // 0xdd3b7c: stur            x2, [fp, #-0x38]
    // 0xdd3b80: LoadField: r1 = r0->field_b
    //     0xdd3b80: ldur            w1, [x0, #0xb]
    // 0xdd3b84: LoadField: r3 = r0->field_f
    //     0xdd3b84: ldur            w3, [x0, #0xf]
    // 0xdd3b88: DecompressPointer r3
    //     0xdd3b88: add             x3, x3, HEAP, lsl #32
    // 0xdd3b8c: LoadField: r4 = r3->field_b
    //     0xdd3b8c: ldur            w4, [x3, #0xb]
    // 0xdd3b90: r3 = LoadInt32Instr(r1)
    //     0xdd3b90: sbfx            x3, x1, #1, #0x1f
    // 0xdd3b94: stur            x3, [fp, #-0x28]
    // 0xdd3b98: r1 = LoadInt32Instr(r4)
    //     0xdd3b98: sbfx            x1, x4, #1, #0x1f
    // 0xdd3b9c: cmp             x3, x1
    // 0xdd3ba0: b.ne            #0xdd3bac
    // 0xdd3ba4: mov             x1, x0
    // 0xdd3ba8: r0 = _growToNextCapacity()
    //     0xdd3ba8: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xdd3bac: ldur            x3, [fp, #-0x30]
    // 0xdd3bb0: ldur            x2, [fp, #-0x28]
    // 0xdd3bb4: add             x0, x2, #1
    // 0xdd3bb8: lsl             x1, x0, #1
    // 0xdd3bbc: StoreField: r3->field_b = r1
    //     0xdd3bbc: stur            w1, [x3, #0xb]
    // 0xdd3bc0: LoadField: r1 = r3->field_f
    //     0xdd3bc0: ldur            w1, [x3, #0xf]
    // 0xdd3bc4: DecompressPointer r1
    //     0xdd3bc4: add             x1, x1, HEAP, lsl #32
    // 0xdd3bc8: ldur            x0, [fp, #-0x38]
    // 0xdd3bcc: ArrayStore: r1[r2] = r0  ; List_4
    //     0xdd3bcc: add             x25, x1, x2, lsl #2
    //     0xdd3bd0: add             x25, x25, #0xf
    //     0xdd3bd4: str             w0, [x25]
    //     0xdd3bd8: tbz             w0, #0, #0xdd3bf4
    //     0xdd3bdc: ldurb           w16, [x1, #-1]
    //     0xdd3be0: ldurb           w17, [x0, #-1]
    //     0xdd3be4: and             x16, x17, x16, lsr #2
    //     0xdd3be8: tst             x16, HEAP, lsr #32
    //     0xdd3bec: b.eq            #0xdd3bf4
    //     0xdd3bf0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdd3bf4: r1 = <Widget>
    //     0xdd3bf4: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xdd3bf8: r2 = 0
    //     0xdd3bf8: mov             x2, #0
    // 0xdd3bfc: r0 = _GrowableList()
    //     0xdd3bfc: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xdd3c00: ldur            x1, [fp, #-8]
    // 0xdd3c04: ldur            x2, [fp, #-0x10]
    // 0xdd3c08: stur            x0, [fp, #-8]
    // 0xdd3c0c: r0 = _buildBottomBar()
    //     0xdd3c0c: bl              #0xdd3e58  ; [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_buildBottomBar
    // 0xdd3c10: mov             x2, x0
    // 0xdd3c14: ldur            x0, [fp, #-8]
    // 0xdd3c18: stur            x2, [fp, #-0x10]
    // 0xdd3c1c: LoadField: r1 = r0->field_b
    //     0xdd3c1c: ldur            w1, [x0, #0xb]
    // 0xdd3c20: LoadField: r3 = r0->field_f
    //     0xdd3c20: ldur            w3, [x0, #0xf]
    // 0xdd3c24: DecompressPointer r3
    //     0xdd3c24: add             x3, x3, HEAP, lsl #32
    // 0xdd3c28: LoadField: r4 = r3->field_b
    //     0xdd3c28: ldur            w4, [x3, #0xb]
    // 0xdd3c2c: r3 = LoadInt32Instr(r1)
    //     0xdd3c2c: sbfx            x3, x1, #1, #0x1f
    // 0xdd3c30: stur            x3, [fp, #-0x28]
    // 0xdd3c34: r1 = LoadInt32Instr(r4)
    //     0xdd3c34: sbfx            x1, x4, #1, #0x1f
    // 0xdd3c38: cmp             x3, x1
    // 0xdd3c3c: b.ne            #0xdd3c48
    // 0xdd3c40: mov             x1, x0
    // 0xdd3c44: r0 = _growToNextCapacity()
    //     0xdd3c44: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xdd3c48: ldur            x4, [fp, #-0x30]
    // 0xdd3c4c: ldur            x2, [fp, #-8]
    // 0xdd3c50: ldur            x3, [fp, #-0x28]
    // 0xdd3c54: add             x0, x3, #1
    // 0xdd3c58: lsl             x1, x0, #1
    // 0xdd3c5c: StoreField: r2->field_b = r1
    //     0xdd3c5c: stur            w1, [x2, #0xb]
    // 0xdd3c60: LoadField: r1 = r2->field_f
    //     0xdd3c60: ldur            w1, [x2, #0xf]
    // 0xdd3c64: DecompressPointer r1
    //     0xdd3c64: add             x1, x1, HEAP, lsl #32
    // 0xdd3c68: ldur            x0, [fp, #-0x10]
    // 0xdd3c6c: ArrayStore: r1[r3] = r0  ; List_4
    //     0xdd3c6c: add             x25, x1, x3, lsl #2
    //     0xdd3c70: add             x25, x25, #0xf
    //     0xdd3c74: str             w0, [x25]
    //     0xdd3c78: tbz             w0, #0, #0xdd3c94
    //     0xdd3c7c: ldurb           w16, [x1, #-1]
    //     0xdd3c80: ldurb           w17, [x0, #-1]
    //     0xdd3c84: and             x16, x17, x16, lsr #2
    //     0xdd3c88: tst             x16, HEAP, lsr #32
    //     0xdd3c8c: b.eq            #0xdd3c94
    //     0xdd3c90: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdd3c94: r0 = Column()
    //     0xdd3c94: bl              #0x8a5b1c  ; AllocateColumnStub -> Column (size=0x38)
    // 0xdd3c98: mov             x2, x0
    // 0xdd3c9c: r0 = Instance_Axis
    //     0xdd3c9c: ldr             x0, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xdd3ca0: stur            x2, [fp, #-0x10]
    // 0xdd3ca4: StoreField: r2->field_f = r0
    //     0xdd3ca4: stur            w0, [x2, #0xf]
    // 0xdd3ca8: r0 = Instance_MainAxisAlignment
    //     0xdd3ca8: add             x0, PP, #0x18, lsl #12  ; [pp+0x182b8] Obj!MainAxisAlignment@12c45e1
    //     0xdd3cac: ldr             x0, [x0, #0x2b8]
    // 0xdd3cb0: StoreField: r2->field_13 = r0
    //     0xdd3cb0: stur            w0, [x2, #0x13]
    // 0xdd3cb4: r0 = Instance_MainAxisSize
    //     0xdd3cb4: add             x0, PP, #0x15, lsl #12  ; [pp+0x15828] Obj!MainAxisSize@12c4621
    //     0xdd3cb8: ldr             x0, [x0, #0x828]
    // 0xdd3cbc: ArrayStore: r2[0] = r0  ; List_4
    //     0xdd3cbc: stur            w0, [x2, #0x17]
    // 0xdd3cc0: r0 = Instance_CrossAxisAlignment
    //     0xdd3cc0: add             x0, PP, #0x15, lsl #12  ; [pp+0x15888] Obj!CrossAxisAlignment@12c44a1
    //     0xdd3cc4: ldr             x0, [x0, #0x888]
    // 0xdd3cc8: StoreField: r2->field_1b = r0
    //     0xdd3cc8: stur            w0, [x2, #0x1b]
    // 0xdd3ccc: r0 = Instance_VerticalDirection
    //     0xdd3ccc: add             x0, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xdd3cd0: ldr             x0, [x0, #0x838]
    // 0xdd3cd4: StoreField: r2->field_23 = r0
    //     0xdd3cd4: stur            w0, [x2, #0x23]
    // 0xdd3cd8: r0 = Instance_Clip
    //     0xdd3cd8: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xdd3cdc: ldr             x0, [x0, #0x840]
    // 0xdd3ce0: StoreField: r2->field_2b = r0
    //     0xdd3ce0: stur            w0, [x2, #0x2b]
    // 0xdd3ce4: StoreField: r2->field_2f = rZR
    //     0xdd3ce4: stur            xzr, [x2, #0x2f]
    // 0xdd3ce8: ldur            x0, [fp, #-8]
    // 0xdd3cec: StoreField: r2->field_b = r0
    //     0xdd3cec: stur            w0, [x2, #0xb]
    // 0xdd3cf0: ldur            x0, [fp, #-0x30]
    // 0xdd3cf4: LoadField: r1 = r0->field_b
    //     0xdd3cf4: ldur            w1, [x0, #0xb]
    // 0xdd3cf8: LoadField: r3 = r0->field_f
    //     0xdd3cf8: ldur            w3, [x0, #0xf]
    // 0xdd3cfc: DecompressPointer r3
    //     0xdd3cfc: add             x3, x3, HEAP, lsl #32
    // 0xdd3d00: LoadField: r4 = r3->field_b
    //     0xdd3d00: ldur            w4, [x3, #0xb]
    // 0xdd3d04: r3 = LoadInt32Instr(r1)
    //     0xdd3d04: sbfx            x3, x1, #1, #0x1f
    // 0xdd3d08: stur            x3, [fp, #-0x28]
    // 0xdd3d0c: r1 = LoadInt32Instr(r4)
    //     0xdd3d0c: sbfx            x1, x4, #1, #0x1f
    // 0xdd3d10: cmp             x3, x1
    // 0xdd3d14: b.ne            #0xdd3d20
    // 0xdd3d18: mov             x1, x0
    // 0xdd3d1c: r0 = _growToNextCapacity()
    //     0xdd3d1c: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xdd3d20: ldur            x2, [fp, #-0x30]
    // 0xdd3d24: ldur            x4, [fp, #-0x18]
    // 0xdd3d28: ldur            x3, [fp, #-0x28]
    // 0xdd3d2c: add             x0, x3, #1
    // 0xdd3d30: lsl             x1, x0, #1
    // 0xdd3d34: StoreField: r2->field_b = r1
    //     0xdd3d34: stur            w1, [x2, #0xb]
    // 0xdd3d38: LoadField: r1 = r2->field_f
    //     0xdd3d38: ldur            w1, [x2, #0xf]
    // 0xdd3d3c: DecompressPointer r1
    //     0xdd3d3c: add             x1, x1, HEAP, lsl #32
    // 0xdd3d40: ldur            x0, [fp, #-0x10]
    // 0xdd3d44: ArrayStore: r1[r3] = r0  ; List_4
    //     0xdd3d44: add             x25, x1, x3, lsl #2
    //     0xdd3d48: add             x25, x25, #0xf
    //     0xdd3d4c: str             w0, [x25]
    //     0xdd3d50: tbz             w0, #0, #0xdd3d6c
    //     0xdd3d54: ldurb           w16, [x1, #-1]
    //     0xdd3d58: ldurb           w17, [x0, #-1]
    //     0xdd3d5c: and             x16, x17, x16, lsr #2
    //     0xdd3d60: tst             x16, HEAP, lsr #32
    //     0xdd3d64: b.eq            #0xdd3d6c
    //     0xdd3d68: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdd3d6c: r0 = Stack()
    //     0xdd3d6c: bl              #0xd1a854  ; AllocateStackStub -> Stack (size=0x20)
    // 0xdd3d70: mov             x1, x0
    // 0xdd3d74: r0 = Instance_AlignmentDirectional
    //     0xdd3d74: add             x0, PP, #0x15, lsl #12  ; [pp+0x158d8] Obj!AlignmentDirectional@129e611
    //     0xdd3d78: ldr             x0, [x0, #0x8d8]
    // 0xdd3d7c: stur            x1, [fp, #-8]
    // 0xdd3d80: StoreField: r1->field_f = r0
    //     0xdd3d80: stur            w0, [x1, #0xf]
    // 0xdd3d84: r0 = Instance_StackFit
    //     0xdd3d84: add             x0, PP, #0x15, lsl #12  ; [pp+0x158e0] Obj!StackFit@12c4221
    //     0xdd3d88: ldr             x0, [x0, #0x8e0]
    // 0xdd3d8c: ArrayStore: r1[0] = r0  ; List_4
    //     0xdd3d8c: stur            w0, [x1, #0x17]
    // 0xdd3d90: r0 = Instance_Clip
    //     0xdd3d90: add             x0, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xdd3d94: ldr             x0, [x0, #0x850]
    // 0xdd3d98: StoreField: r1->field_1b = r0
    //     0xdd3d98: stur            w0, [x1, #0x1b]
    // 0xdd3d9c: ldur            x0, [fp, #-0x30]
    // 0xdd3da0: StoreField: r1->field_b = r0
    //     0xdd3da0: stur            w0, [x1, #0xb]
    // 0xdd3da4: r0 = AbsorbPointer()
    //     0xdd3da4: bl              #0xd6cda8  ; AllocateAbsorbPointerStub -> AbsorbPointer (size=0x18)
    // 0xdd3da8: mov             x1, x0
    // 0xdd3dac: ldur            x0, [fp, #-0x18]
    // 0xdd3db0: stur            x1, [fp, #-0x10]
    // 0xdd3db4: StoreField: r1->field_f = r0
    //     0xdd3db4: stur            w0, [x1, #0xf]
    // 0xdd3db8: ldur            x0, [fp, #-8]
    // 0xdd3dbc: StoreField: r1->field_b = r0
    //     0xdd3dbc: stur            w0, [x1, #0xb]
    // 0xdd3dc0: r0 = GestureDetector()
    //     0xdd3dc0: bl              #0x918e18  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0xdd3dc4: ldur            x2, [fp, #-0x20]
    // 0xdd3dc8: r1 = Function '<anonymous closure>':.
    //     0xdd3dc8: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3ea0] AnonymousClosure: (0xdd4ee0), in [package:chewie/src/material/material_controls.dart] _MaterialControlsState::build (0xdd39bc)
    //     0xdd3dcc: ldr             x1, [x1, #0xea0]
    // 0xdd3dd0: stur            x0, [fp, #-8]
    // 0xdd3dd4: r0 = AllocateClosure()
    //     0xdd3dd4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd3dd8: ldur            x16, [fp, #-0x10]
    // 0xdd3ddc: stp             x16, x0, [SP]
    // 0xdd3de0: ldur            x1, [fp, #-8]
    // 0xdd3de4: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0xdd3de4: add             x4, PP, #0x16, lsl #12  ; [pp+0x16e90] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0xdd3de8: ldr             x4, [x4, #0xe90]
    // 0xdd3dec: r0 = GestureDetector()
    //     0xdd3dec: bl              #0x9182dc  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0xdd3df0: ldur            x2, [fp, #-0x20]
    // 0xdd3df4: r1 = Function '<anonymous closure>':.
    //     0xdd3df4: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3ea8] AnonymousClosure: (0xdd74d8), in [package:chewie/src/material/material_controls.dart] _MaterialControlsState::build (0xdd39bc)
    //     0xdd3df8: ldr             x1, [x1, #0xea8]
    // 0xdd3dfc: r0 = AllocateClosure()
    //     0xdd3dfc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd3e00: stur            x0, [fp, #-0x10]
    // 0xdd3e04: r0 = MouseRegion()
    //     0xdd3e04: bl              #0xd1c8fc  ; AllocateMouseRegionStub -> MouseRegion (size=0x28)
    // 0xdd3e08: ldur            x1, [fp, #-0x10]
    // 0xdd3e0c: StoreField: r0->field_13 = r1
    //     0xdd3e0c: stur            w1, [x0, #0x13]
    // 0xdd3e10: r1 = Instance__DeferringMouseCursor
    //     0xdd3e10: ldr             x1, [PP, #0x2208]  ; [pp+0x2208] Obj!_DeferringMouseCursor@12b3241
    // 0xdd3e14: StoreField: r0->field_1b = r1
    //     0xdd3e14: stur            w1, [x0, #0x1b]
    // 0xdd3e18: r1 = true
    //     0xdd3e18: add             x1, NULL, #0x20  ; true
    // 0xdd3e1c: StoreField: r0->field_1f = r1
    //     0xdd3e1c: stur            w1, [x0, #0x1f]
    // 0xdd3e20: ldur            x1, [fp, #-8]
    // 0xdd3e24: StoreField: r0->field_b = r1
    //     0xdd3e24: stur            w1, [x0, #0xb]
    // 0xdd3e28: LeaveFrame
    //     0xdd3e28: mov             SP, fp
    //     0xdd3e2c: ldp             fp, lr, [SP], #0x10
    // 0xdd3e30: ret
    //     0xdd3e30: ret             
    // 0xdd3e34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd3e34: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd3e38: b               #0xdd39dc
    // 0xdd3e3c: r9 = _latestValue
    //     0xdd3e3c: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3eb0] Field <_MaterialControlsState@451269912._latestValue@451269912>: late (offset: 0x20)
    //     0xdd3e40: ldr             x9, [x9, #0xeb0]
    // 0xdd3e44: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd3e44: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdd3e48: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd3e48: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdd3e4c: r9 = notifier
    //     0xdd3e4c: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3e80] Field <_MaterialControlsState@451269912.notifier>: late (offset: 0x1c)
    //     0xdd3e50: ldr             x9, [x9, #0xe80]
    // 0xdd3e54: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd3e54: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _buildBottomBar(/* No info */) {
    // ** addr: 0xdd3e58, size: 0x794
    // 0xdd3e58: EnterFrame
    //     0xdd3e58: stp             fp, lr, [SP, #-0x10]!
    //     0xdd3e5c: mov             fp, SP
    // 0xdd3e60: AllocStack(0x70)
    //     0xdd3e60: sub             SP, SP, #0x70
    // 0xdd3e64: SetupParameters(_MaterialControlsState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1 */)
    //     0xdd3e64: mov             x0, x1
    //     0xdd3e68: stur            x1, [fp, #-8]
    //     0xdd3e6c: mov             x1, x2
    // 0xdd3e70: CheckStackOverflow
    //     0xdd3e70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd3e74: cmp             SP, x16
    //     0xdd3e78: b.ls            #0xdd4574
    // 0xdd3e7c: r0 = of()
    //     0xdd3e7c: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xdd3e80: ldur            x1, [fp, #-8]
    // 0xdd3e84: LoadField: r0 = r1->field_1b
    //     0xdd3e84: ldur            w0, [x1, #0x1b]
    // 0xdd3e88: DecompressPointer r0
    //     0xdd3e88: add             x0, x0, HEAP, lsl #32
    // 0xdd3e8c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd3e90: cmp             w0, w16
    // 0xdd3e94: b.eq            #0xdd457c
    // 0xdd3e98: LoadField: r2 = r0->field_23
    //     0xdd3e98: ldur            w2, [x0, #0x23]
    // 0xdd3e9c: DecompressPointer r2
    //     0xdd3e9c: add             x2, x2, HEAP, lsl #32
    // 0xdd3ea0: tbnz            w2, #4, #0xdd3eac
    // 0xdd3ea4: d0 = 0.000000
    //     0xdd3ea4: eor             v0.16b, v0.16b, v0.16b
    // 0xdd3ea8: b               #0xdd3eb0
    // 0xdd3eac: d0 = 1.000000
    //     0xdd3eac: fmov            d0, #1.00000000
    // 0xdd3eb0: stur            d0, [fp, #-0x50]
    // 0xdd3eb4: LoadField: d1 = r1->field_47
    //     0xdd3eb4: ldur            d1, [x1, #0x47]
    // 0xdd3eb8: LoadField: r0 = r1->field_5b
    //     0xdd3eb8: ldur            w0, [x1, #0x5b]
    // 0xdd3ebc: DecompressPointer r0
    //     0xdd3ebc: add             x0, x0, HEAP, lsl #32
    // 0xdd3ec0: cmp             w0, NULL
    // 0xdd3ec4: b.eq            #0xdd4588
    // 0xdd3ec8: LoadField: r2 = r0->field_cf
    //     0xdd3ec8: ldur            w2, [x0, #0xcf]
    // 0xdd3ecc: DecompressPointer r2
    //     0xdd3ecc: add             x2, x2, HEAP, lsl #32
    // 0xdd3ed0: tbnz            w2, #4, #0xdd3ee0
    // 0xdd3ed4: r0 = 10.000000
    //     0xdd3ed4: add             x0, PP, #0x13, lsl #12  ; [pp+0x13850] 10
    //     0xdd3ed8: ldr             x0, [x0, #0x850]
    // 0xdd3edc: b               #0xdd3ee4
    // 0xdd3ee0: r0 = 0
    //     0xdd3ee0: mov             x0, #0
    // 0xdd3ee4: r2 = inline_Allocate_Double()
    //     0xdd3ee4: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xdd3ee8: add             x2, x2, #0x10
    //     0xdd3eec: cmp             x3, x2
    //     0xdd3ef0: b.ls            #0xdd458c
    //     0xdd3ef4: str             x2, [THR, #0x60]  ; THR::top
    //     0xdd3ef8: sub             x2, x2, #0xf
    //     0xdd3efc: mov             x3, #0xe19c
    //     0xdd3f00: movk            x3, #3, lsl #16
    //     0xdd3f04: stur            x3, [x2, #-1]
    // 0xdd3f08: dmb             ishst
    // 0xdd3f0c: StoreField: r2->field_7 = d1
    //     0xdd3f0c: stur            d1, [x2, #7]
    // 0xdd3f10: stp             x0, x2, [SP]
    // 0xdd3f14: r0 = +()
    //     0xdd3f14: bl              #0x13dce50  ; [dart:core] _Double::+
    // 0xdd3f18: ldur            x1, [fp, #-8]
    // 0xdd3f1c: stur            x0, [fp, #-0x18]
    // 0xdd3f20: LoadField: r2 = r1->field_5b
    //     0xdd3f20: ldur            w2, [x1, #0x5b]
    // 0xdd3f24: DecompressPointer r2
    //     0xdd3f24: add             x2, x2, HEAP, lsl #32
    // 0xdd3f28: cmp             w2, NULL
    // 0xdd3f2c: b.eq            #0xdd45a8
    // 0xdd3f30: LoadField: r3 = r2->field_cf
    //     0xdd3f30: ldur            w3, [x2, #0xcf]
    // 0xdd3f34: DecompressPointer r3
    //     0xdd3f34: add             x3, x3, HEAP, lsl #32
    // 0xdd3f38: stur            x3, [fp, #-0x10]
    // 0xdd3f3c: tbz             w3, #4, #0xdd3f48
    // 0xdd3f40: d0 = 10.000000
    //     0xdd3f40: fmov            d0, #10.00000000
    // 0xdd3f44: b               #0xdd3f4c
    // 0xdd3f48: d0 = 0.000000
    //     0xdd3f48: eor             v0.16b, v0.16b, v0.16b
    // 0xdd3f4c: stur            d0, [fp, #-0x58]
    // 0xdd3f50: r0 = EdgeInsets()
    //     0xdd3f50: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xdd3f54: d0 = 20.000000
    //     0xdd3f54: fmov            d0, #20.00000000
    // 0xdd3f58: stur            x0, [fp, #-0x20]
    // 0xdd3f5c: StoreField: r0->field_7 = d0
    //     0xdd3f5c: stur            d0, [x0, #7]
    // 0xdd3f60: StoreField: r0->field_f = rZR
    //     0xdd3f60: stur            xzr, [x0, #0xf]
    // 0xdd3f64: ArrayStore: r0[0] = d0  ; List_8
    //     0xdd3f64: stur            d0, [x0, #0x17]
    // 0xdd3f68: ldur            d0, [fp, #-0x58]
    // 0xdd3f6c: StoreField: r0->field_1f = d0
    //     0xdd3f6c: stur            d0, [x0, #0x1f]
    // 0xdd3f70: r1 = <Widget>
    //     0xdd3f70: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xdd3f74: r2 = 0
    //     0xdd3f74: mov             x2, #0
    // 0xdd3f78: r0 = _GrowableList()
    //     0xdd3f78: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xdd3f7c: mov             x2, x0
    // 0xdd3f80: ldur            x0, [fp, #-8]
    // 0xdd3f84: stur            x2, [fp, #-0x28]
    // 0xdd3f88: LoadField: r1 = r0->field_5b
    //     0xdd3f88: ldur            w1, [x0, #0x5b]
    // 0xdd3f8c: DecompressPointer r1
    //     0xdd3f8c: add             x1, x1, HEAP, lsl #32
    // 0xdd3f90: cmp             w1, NULL
    // 0xdd3f94: b.eq            #0xdd45ac
    // 0xdd3f98: mov             x1, x0
    // 0xdd3f9c: r0 = _buildPosition()
    //     0xdd3f9c: bl              #0xdd5374  ; [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_buildPosition
    // 0xdd3fa0: mov             x2, x0
    // 0xdd3fa4: ldur            x0, [fp, #-0x28]
    // 0xdd3fa8: stur            x2, [fp, #-0x38]
    // 0xdd3fac: LoadField: r1 = r0->field_b
    //     0xdd3fac: ldur            w1, [x0, #0xb]
    // 0xdd3fb0: LoadField: r3 = r0->field_f
    //     0xdd3fb0: ldur            w3, [x0, #0xf]
    // 0xdd3fb4: DecompressPointer r3
    //     0xdd3fb4: add             x3, x3, HEAP, lsl #32
    // 0xdd3fb8: LoadField: r4 = r3->field_b
    //     0xdd3fb8: ldur            w4, [x3, #0xb]
    // 0xdd3fbc: r3 = LoadInt32Instr(r1)
    //     0xdd3fbc: sbfx            x3, x1, #1, #0x1f
    // 0xdd3fc0: stur            x3, [fp, #-0x30]
    // 0xdd3fc4: r1 = LoadInt32Instr(r4)
    //     0xdd3fc4: sbfx            x1, x4, #1, #0x1f
    // 0xdd3fc8: cmp             x3, x1
    // 0xdd3fcc: b.ne            #0xdd3fd8
    // 0xdd3fd0: mov             x1, x0
    // 0xdd3fd4: r0 = _growToNextCapacity()
    //     0xdd3fd4: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xdd3fd8: ldur            x4, [fp, #-8]
    // 0xdd3fdc: ldur            x3, [fp, #-0x28]
    // 0xdd3fe0: ldur            x2, [fp, #-0x30]
    // 0xdd3fe4: add             x0, x2, #1
    // 0xdd3fe8: lsl             x1, x0, #1
    // 0xdd3fec: StoreField: r3->field_b = r1
    //     0xdd3fec: stur            w1, [x3, #0xb]
    // 0xdd3ff0: LoadField: r1 = r3->field_f
    //     0xdd3ff0: ldur            w1, [x3, #0xf]
    // 0xdd3ff4: DecompressPointer r1
    //     0xdd3ff4: add             x1, x1, HEAP, lsl #32
    // 0xdd3ff8: ldur            x0, [fp, #-0x38]
    // 0xdd3ffc: ArrayStore: r1[r2] = r0  ; List_4
    //     0xdd3ffc: add             x25, x1, x2, lsl #2
    //     0xdd4000: add             x25, x25, #0xf
    //     0xdd4004: str             w0, [x25]
    //     0xdd4008: tbz             w0, #0, #0xdd4024
    //     0xdd400c: ldurb           w16, [x1, #-1]
    //     0xdd4010: ldurb           w17, [x0, #-1]
    //     0xdd4014: and             x16, x17, x16, lsr #2
    //     0xdd4018: tst             x16, HEAP, lsr #32
    //     0xdd401c: b.eq            #0xdd4024
    //     0xdd4020: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdd4024: LoadField: r0 = r4->field_5b
    //     0xdd4024: ldur            w0, [x4, #0x5b]
    // 0xdd4028: DecompressPointer r0
    //     0xdd4028: add             x0, x0, HEAP, lsl #32
    // 0xdd402c: cmp             w0, NULL
    // 0xdd4030: b.eq            #0xdd45b0
    // 0xdd4034: LoadField: r2 = r4->field_57
    //     0xdd4034: ldur            w2, [x4, #0x57]
    // 0xdd4038: DecompressPointer r2
    //     0xdd4038: add             x2, x2, HEAP, lsl #32
    // 0xdd403c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd4040: cmp             w2, w16
    // 0xdd4044: b.eq            #0xdd45b4
    // 0xdd4048: mov             x1, x4
    // 0xdd404c: r0 = _buildMuteButton()
    //     0xdd404c: bl              #0xdd5038  ; [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_buildMuteButton
    // 0xdd4050: mov             x2, x0
    // 0xdd4054: ldur            x0, [fp, #-0x28]
    // 0xdd4058: stur            x2, [fp, #-0x38]
    // 0xdd405c: LoadField: r1 = r0->field_b
    //     0xdd405c: ldur            w1, [x0, #0xb]
    // 0xdd4060: LoadField: r3 = r0->field_f
    //     0xdd4060: ldur            w3, [x0, #0xf]
    // 0xdd4064: DecompressPointer r3
    //     0xdd4064: add             x3, x3, HEAP, lsl #32
    // 0xdd4068: LoadField: r4 = r3->field_b
    //     0xdd4068: ldur            w4, [x3, #0xb]
    // 0xdd406c: r3 = LoadInt32Instr(r1)
    //     0xdd406c: sbfx            x3, x1, #1, #0x1f
    // 0xdd4070: stur            x3, [fp, #-0x30]
    // 0xdd4074: r1 = LoadInt32Instr(r4)
    //     0xdd4074: sbfx            x1, x4, #1, #0x1f
    // 0xdd4078: cmp             x3, x1
    // 0xdd407c: b.ne            #0xdd4088
    // 0xdd4080: mov             x1, x0
    // 0xdd4084: r0 = _growToNextCapacity()
    //     0xdd4084: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xdd4088: ldur            x2, [fp, #-0x28]
    // 0xdd408c: ldur            x3, [fp, #-0x30]
    // 0xdd4090: add             x4, x3, #1
    // 0xdd4094: stur            x4, [fp, #-0x40]
    // 0xdd4098: lsl             x0, x4, #1
    // 0xdd409c: StoreField: r2->field_b = r0
    //     0xdd409c: stur            w0, [x2, #0xb]
    // 0xdd40a0: LoadField: r5 = r2->field_f
    //     0xdd40a0: ldur            w5, [x2, #0xf]
    // 0xdd40a4: DecompressPointer r5
    //     0xdd40a4: add             x5, x5, HEAP, lsl #32
    // 0xdd40a8: mov             x1, x5
    // 0xdd40ac: ldur            x0, [fp, #-0x38]
    // 0xdd40b0: ArrayStore: r1[r3] = r0  ; List_4
    //     0xdd40b0: add             x25, x1, x3, lsl #2
    //     0xdd40b4: add             x25, x25, #0xf
    //     0xdd40b8: str             w0, [x25]
    //     0xdd40bc: tbz             w0, #0, #0xdd40d8
    //     0xdd40c0: ldurb           w16, [x1, #-1]
    //     0xdd40c4: ldurb           w17, [x0, #-1]
    //     0xdd40c8: and             x16, x17, x16, lsr #2
    //     0xdd40cc: tst             x16, HEAP, lsr #32
    //     0xdd40d0: b.eq            #0xdd40d8
    //     0xdd40d4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdd40d8: LoadField: r0 = r5->field_b
    //     0xdd40d8: ldur            w0, [x5, #0xb]
    // 0xdd40dc: r1 = LoadInt32Instr(r0)
    //     0xdd40dc: sbfx            x1, x0, #1, #0x1f
    // 0xdd40e0: cmp             x4, x1
    // 0xdd40e4: b.ne            #0xdd40f0
    // 0xdd40e8: mov             x1, x2
    // 0xdd40ec: r0 = _growToNextCapacity()
    //     0xdd40ec: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xdd40f0: ldur            x2, [fp, #-8]
    // 0xdd40f4: ldur            x0, [fp, #-0x28]
    // 0xdd40f8: ldur            x1, [fp, #-0x40]
    // 0xdd40fc: add             x3, x1, #1
    // 0xdd4100: lsl             x4, x3, #1
    // 0xdd4104: StoreField: r0->field_b = r4
    //     0xdd4104: stur            w4, [x0, #0xb]
    // 0xdd4108: LoadField: r3 = r0->field_f
    //     0xdd4108: ldur            w3, [x0, #0xf]
    // 0xdd410c: DecompressPointer r3
    //     0xdd410c: add             x3, x3, HEAP, lsl #32
    // 0xdd4110: add             x4, x3, x1, lsl #2
    // 0xdd4114: r16 = Instance_Spacer
    //     0xdd4114: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1ee78] Obj!Spacer@12b5c01
    //     0xdd4118: ldr             x16, [x16, #0xe78]
    // 0xdd411c: StoreField: r4->field_f = r16
    //     0xdd411c: stur            w16, [x4, #0xf]
    // 0xdd4120: LoadField: r1 = r2->field_5b
    //     0xdd4120: ldur            w1, [x2, #0x5b]
    // 0xdd4124: DecompressPointer r1
    //     0xdd4124: add             x1, x1, HEAP, lsl #32
    // 0xdd4128: cmp             w1, NULL
    // 0xdd412c: b.eq            #0xdd45c0
    // 0xdd4130: mov             x1, x2
    // 0xdd4134: r0 = _buildExpandButton()
    //     0xdd4134: bl              #0xdd4ae4  ; [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_buildExpandButton
    // 0xdd4138: mov             x2, x0
    // 0xdd413c: ldur            x0, [fp, #-0x28]
    // 0xdd4140: stur            x2, [fp, #-0x38]
    // 0xdd4144: LoadField: r1 = r0->field_b
    //     0xdd4144: ldur            w1, [x0, #0xb]
    // 0xdd4148: LoadField: r3 = r0->field_f
    //     0xdd4148: ldur            w3, [x0, #0xf]
    // 0xdd414c: DecompressPointer r3
    //     0xdd414c: add             x3, x3, HEAP, lsl #32
    // 0xdd4150: LoadField: r4 = r3->field_b
    //     0xdd4150: ldur            w4, [x3, #0xb]
    // 0xdd4154: r3 = LoadInt32Instr(r1)
    //     0xdd4154: sbfx            x3, x1, #1, #0x1f
    // 0xdd4158: stur            x3, [fp, #-0x30]
    // 0xdd415c: r1 = LoadInt32Instr(r4)
    //     0xdd415c: sbfx            x1, x4, #1, #0x1f
    // 0xdd4160: cmp             x3, x1
    // 0xdd4164: b.ne            #0xdd4170
    // 0xdd4168: mov             x1, x0
    // 0xdd416c: r0 = _growToNextCapacity()
    //     0xdd416c: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xdd4170: ldur            x4, [fp, #-8]
    // 0xdd4174: ldur            x2, [fp, #-0x28]
    // 0xdd4178: ldur            x3, [fp, #-0x30]
    // 0xdd417c: add             x0, x3, #1
    // 0xdd4180: lsl             x1, x0, #1
    // 0xdd4184: StoreField: r2->field_b = r1
    //     0xdd4184: stur            w1, [x2, #0xb]
    // 0xdd4188: LoadField: r1 = r2->field_f
    //     0xdd4188: ldur            w1, [x2, #0xf]
    // 0xdd418c: DecompressPointer r1
    //     0xdd418c: add             x1, x1, HEAP, lsl #32
    // 0xdd4190: ldur            x0, [fp, #-0x38]
    // 0xdd4194: ArrayStore: r1[r3] = r0  ; List_4
    //     0xdd4194: add             x25, x1, x3, lsl #2
    //     0xdd4198: add             x25, x25, #0xf
    //     0xdd419c: str             w0, [x25]
    //     0xdd41a0: tbz             w0, #0, #0xdd41bc
    //     0xdd41a4: ldurb           w16, [x1, #-1]
    //     0xdd41a8: ldurb           w17, [x0, #-1]
    //     0xdd41ac: and             x16, x17, x16, lsr #2
    //     0xdd41b0: tst             x16, HEAP, lsr #32
    //     0xdd41b4: b.eq            #0xdd41bc
    //     0xdd41b8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdd41bc: r0 = Row()
    //     0xdd41bc: bl              #0x8a5b04  ; AllocateRowStub -> Row (size=0x38)
    // 0xdd41c0: mov             x2, x0
    // 0xdd41c4: r0 = Instance_Axis
    //     0xdd41c4: ldr             x0, [PP, #0x49c8]  ; [pp+0x49c8] Obj!Axis@12c4a61
    // 0xdd41c8: stur            x2, [fp, #-0x38]
    // 0xdd41cc: StoreField: r2->field_f = r0
    //     0xdd41cc: stur            w0, [x2, #0xf]
    // 0xdd41d0: r1 = Instance_MainAxisAlignment
    //     0xdd41d0: add             x1, PP, #0x17, lsl #12  ; [pp+0x177b0] Obj!MainAxisAlignment@12c45c1
    //     0xdd41d4: ldr             x1, [x1, #0x7b0]
    // 0xdd41d8: StoreField: r2->field_13 = r1
    //     0xdd41d8: stur            w1, [x2, #0x13]
    // 0xdd41dc: r3 = Instance_MainAxisSize
    //     0xdd41dc: add             x3, PP, #0x15, lsl #12  ; [pp+0x15828] Obj!MainAxisSize@12c4621
    //     0xdd41e0: ldr             x3, [x3, #0x828]
    // 0xdd41e4: ArrayStore: r2[0] = r3  ; List_4
    //     0xdd41e4: stur            w3, [x2, #0x17]
    // 0xdd41e8: r4 = Instance_CrossAxisAlignment
    //     0xdd41e8: add             x4, PP, #0x15, lsl #12  ; [pp+0x15888] Obj!CrossAxisAlignment@12c44a1
    //     0xdd41ec: ldr             x4, [x4, #0x888]
    // 0xdd41f0: StoreField: r2->field_1b = r4
    //     0xdd41f0: stur            w4, [x2, #0x1b]
    // 0xdd41f4: r5 = Instance_VerticalDirection
    //     0xdd41f4: add             x5, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xdd41f8: ldr             x5, [x5, #0x838]
    // 0xdd41fc: StoreField: r2->field_23 = r5
    //     0xdd41fc: stur            w5, [x2, #0x23]
    // 0xdd4200: r6 = Instance_Clip
    //     0xdd4200: add             x6, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xdd4204: ldr             x6, [x6, #0x840]
    // 0xdd4208: StoreField: r2->field_2b = r6
    //     0xdd4208: stur            w6, [x2, #0x2b]
    // 0xdd420c: StoreField: r2->field_2f = rZR
    //     0xdd420c: stur            xzr, [x2, #0x2f]
    // 0xdd4210: ldur            x1, [fp, #-0x28]
    // 0xdd4214: StoreField: r2->field_b = r1
    //     0xdd4214: stur            w1, [x2, #0xb]
    // 0xdd4218: r1 = <FlexParentData>
    //     0xdd4218: add             x1, PP, #0x15, lsl #12  ; [pp+0x15878] TypeArguments: <FlexParentData>
    //     0xdd421c: ldr             x1, [x1, #0x878]
    // 0xdd4220: r0 = Flexible()
    //     0xdd4220: bl              #0xd0fd68  ; AllocateFlexibleStub -> Flexible (size=0x20)
    // 0xdd4224: mov             x1, x0
    // 0xdd4228: r0 = 1
    //     0xdd4228: mov             x0, #1
    // 0xdd422c: stur            x1, [fp, #-0x48]
    // 0xdd4230: StoreField: r1->field_13 = r0
    //     0xdd4230: stur            x0, [x1, #0x13]
    // 0xdd4234: r2 = Instance_FlexFit
    //     0xdd4234: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1ac30] Obj!FlexFit@12c4661
    //     0xdd4238: ldr             x2, [x2, #0xc30]
    // 0xdd423c: StoreField: r1->field_1b = r2
    //     0xdd423c: stur            w2, [x1, #0x1b]
    // 0xdd4240: ldur            x2, [fp, #-0x38]
    // 0xdd4244: StoreField: r1->field_b = r2
    //     0xdd4244: stur            w2, [x1, #0xb]
    // 0xdd4248: ldur            x2, [fp, #-8]
    // 0xdd424c: LoadField: r3 = r2->field_5b
    //     0xdd424c: ldur            w3, [x2, #0x5b]
    // 0xdd4250: DecompressPointer r3
    //     0xdd4250: add             x3, x3, HEAP, lsl #32
    // 0xdd4254: cmp             w3, NULL
    // 0xdd4258: b.eq            #0xdd45c4
    // 0xdd425c: LoadField: r4 = r3->field_cf
    //     0xdd425c: ldur            w4, [x3, #0xcf]
    // 0xdd4260: DecompressPointer r4
    //     0xdd4260: add             x4, x4, HEAP, lsl #32
    // 0xdd4264: tbnz            w4, #4, #0xdd4270
    // 0xdd4268: d0 = 15.000000
    //     0xdd4268: fmov            d0, #15.00000000
    // 0xdd426c: b               #0xdd4274
    // 0xdd4270: d0 = 0.000000
    //     0xdd4270: eor             v0.16b, v0.16b, v0.16b
    // 0xdd4274: r3 = inline_Allocate_Double()
    //     0xdd4274: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0xdd4278: add             x3, x3, #0x10
    //     0xdd427c: cmp             x4, x3
    //     0xdd4280: b.ls            #0xdd45c8
    //     0xdd4284: str             x3, [THR, #0x60]  ; THR::top
    //     0xdd4288: sub             x3, x3, #0xf
    //     0xdd428c: mov             x4, #0xe19c
    //     0xdd4290: movk            x4, #3, lsl #16
    //     0xdd4294: stur            x4, [x3, #-1]
    // 0xdd4298: dmb             ishst
    // 0xdd429c: StoreField: r3->field_7 = d0
    //     0xdd429c: stur            d0, [x3, #7]
    // 0xdd42a0: stur            x3, [fp, #-0x28]
    // 0xdd42a4: r0 = SizedBox()
    //     0xdd42a4: bl              #0x8a7210  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0xdd42a8: mov             x3, x0
    // 0xdd42ac: ldur            x0, [fp, #-0x28]
    // 0xdd42b0: stur            x3, [fp, #-0x38]
    // 0xdd42b4: StoreField: r3->field_13 = r0
    //     0xdd42b4: stur            w0, [x3, #0x13]
    // 0xdd42b8: r1 = Null
    //     0xdd42b8: mov             x1, NULL
    // 0xdd42bc: r2 = 4
    //     0xdd42bc: mov             x2, #4
    // 0xdd42c0: r0 = AllocateArray()
    //     0xdd42c0: bl              #0x13df928  ; AllocateArrayStub
    // 0xdd42c4: mov             x2, x0
    // 0xdd42c8: ldur            x0, [fp, #-0x48]
    // 0xdd42cc: stur            x2, [fp, #-0x28]
    // 0xdd42d0: StoreField: r2->field_f = r0
    //     0xdd42d0: stur            w0, [x2, #0xf]
    // 0xdd42d4: ldur            x0, [fp, #-0x38]
    // 0xdd42d8: StoreField: r2->field_13 = r0
    //     0xdd42d8: stur            w0, [x2, #0x13]
    // 0xdd42dc: r1 = <Widget>
    //     0xdd42dc: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xdd42e0: r0 = AllocateGrowableArray()
    //     0xdd42e0: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xdd42e4: mov             x2, x0
    // 0xdd42e8: ldur            x0, [fp, #-0x28]
    // 0xdd42ec: stur            x2, [fp, #-0x38]
    // 0xdd42f0: StoreField: r2->field_f = r0
    //     0xdd42f0: stur            w0, [x2, #0xf]
    // 0xdd42f4: r0 = 4
    //     0xdd42f4: mov             x0, #4
    // 0xdd42f8: StoreField: r2->field_b = r0
    //     0xdd42f8: stur            w0, [x2, #0xb]
    // 0xdd42fc: ldur            x1, [fp, #-8]
    // 0xdd4300: r0 = _buildProgressBar()
    //     0xdd4300: bl              #0xdd45ec  ; [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_buildProgressBar
    // 0xdd4304: r1 = Null
    //     0xdd4304: mov             x1, NULL
    // 0xdd4308: r2 = 2
    //     0xdd4308: mov             x2, #2
    // 0xdd430c: stur            x0, [fp, #-8]
    // 0xdd4310: r0 = AllocateArray()
    //     0xdd4310: bl              #0x13df928  ; AllocateArrayStub
    // 0xdd4314: mov             x2, x0
    // 0xdd4318: ldur            x0, [fp, #-8]
    // 0xdd431c: stur            x2, [fp, #-0x28]
    // 0xdd4320: StoreField: r2->field_f = r0
    //     0xdd4320: stur            w0, [x2, #0xf]
    // 0xdd4324: r1 = <Widget>
    //     0xdd4324: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xdd4328: r0 = AllocateGrowableArray()
    //     0xdd4328: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xdd432c: mov             x1, x0
    // 0xdd4330: ldur            x0, [fp, #-0x28]
    // 0xdd4334: stur            x1, [fp, #-8]
    // 0xdd4338: StoreField: r1->field_f = r0
    //     0xdd4338: stur            w0, [x1, #0xf]
    // 0xdd433c: r0 = 2
    //     0xdd433c: mov             x0, #2
    // 0xdd4340: StoreField: r1->field_b = r0
    //     0xdd4340: stur            w0, [x1, #0xb]
    // 0xdd4344: r0 = Row()
    //     0xdd4344: bl              #0x8a5b04  ; AllocateRowStub -> Row (size=0x38)
    // 0xdd4348: mov             x1, x0
    // 0xdd434c: r0 = Instance_Axis
    //     0xdd434c: ldr             x0, [PP, #0x49c8]  ; [pp+0x49c8] Obj!Axis@12c4a61
    // 0xdd4350: stur            x1, [fp, #-0x28]
    // 0xdd4354: StoreField: r1->field_f = r0
    //     0xdd4354: stur            w0, [x1, #0xf]
    // 0xdd4358: r0 = Instance_MainAxisAlignment
    //     0xdd4358: add             x0, PP, #0x15, lsl #12  ; [pp+0x15820] Obj!MainAxisAlignment@12c4541
    //     0xdd435c: ldr             x0, [x0, #0x820]
    // 0xdd4360: StoreField: r1->field_13 = r0
    //     0xdd4360: stur            w0, [x1, #0x13]
    // 0xdd4364: r0 = Instance_MainAxisSize
    //     0xdd4364: add             x0, PP, #0x15, lsl #12  ; [pp+0x15828] Obj!MainAxisSize@12c4621
    //     0xdd4368: ldr             x0, [x0, #0x828]
    // 0xdd436c: ArrayStore: r1[0] = r0  ; List_4
    //     0xdd436c: stur            w0, [x1, #0x17]
    // 0xdd4370: r0 = Instance_CrossAxisAlignment
    //     0xdd4370: add             x0, PP, #0x15, lsl #12  ; [pp+0x15888] Obj!CrossAxisAlignment@12c44a1
    //     0xdd4374: ldr             x0, [x0, #0x888]
    // 0xdd4378: StoreField: r1->field_1b = r0
    //     0xdd4378: stur            w0, [x1, #0x1b]
    // 0xdd437c: r2 = Instance_VerticalDirection
    //     0xdd437c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xdd4380: ldr             x2, [x2, #0x838]
    // 0xdd4384: StoreField: r1->field_23 = r2
    //     0xdd4384: stur            w2, [x1, #0x23]
    // 0xdd4388: r3 = Instance_Clip
    //     0xdd4388: add             x3, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xdd438c: ldr             x3, [x3, #0x840]
    // 0xdd4390: StoreField: r1->field_2b = r3
    //     0xdd4390: stur            w3, [x1, #0x2b]
    // 0xdd4394: StoreField: r1->field_2f = rZR
    //     0xdd4394: stur            xzr, [x1, #0x2f]
    // 0xdd4398: ldur            x4, [fp, #-8]
    // 0xdd439c: StoreField: r1->field_b = r4
    //     0xdd439c: stur            w4, [x1, #0xb]
    // 0xdd43a0: r0 = Container()
    //     0xdd43a0: bl              #0x8a5af8  ; AllocateContainerStub -> Container (size=0x38)
    // 0xdd43a4: stur            x0, [fp, #-8]
    // 0xdd43a8: r16 = Instance_EdgeInsets
    //     0xdd43a8: add             x16, PP, #0xd3, lsl #12  ; [pp+0xd3ec0] Obj!EdgeInsets@129d411
    //     0xdd43ac: ldr             x16, [x16, #0xec0]
    // 0xdd43b0: ldur            lr, [fp, #-0x28]
    // 0xdd43b4: stp             lr, x16, [SP]
    // 0xdd43b8: mov             x1, x0
    // 0xdd43bc: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, padding, 0x1, null]
    //     0xdd43bc: add             x4, PP, #0x1b, lsl #12  ; [pp+0x1bdb0] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "padding", 0x1, Null]
    //     0xdd43c0: ldr             x4, [x4, #0xdb0]
    // 0xdd43c4: r0 = Container()
    //     0xdd43c4: bl              #0x8a54e0  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0xdd43c8: r1 = <FlexParentData>
    //     0xdd43c8: add             x1, PP, #0x15, lsl #12  ; [pp+0x15878] TypeArguments: <FlexParentData>
    //     0xdd43cc: ldr             x1, [x1, #0x878]
    // 0xdd43d0: r0 = Expanded()
    //     0xdd43d0: bl              #0x8a5b10  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0xdd43d4: mov             x2, x0
    // 0xdd43d8: r0 = 1
    //     0xdd43d8: mov             x0, #1
    // 0xdd43dc: stur            x2, [fp, #-0x28]
    // 0xdd43e0: StoreField: r2->field_13 = r0
    //     0xdd43e0: stur            x0, [x2, #0x13]
    // 0xdd43e4: r0 = Instance_FlexFit
    //     0xdd43e4: add             x0, PP, #0x15, lsl #12  ; [pp+0x15880] Obj!FlexFit@12c4641
    //     0xdd43e8: ldr             x0, [x0, #0x880]
    // 0xdd43ec: StoreField: r2->field_1b = r0
    //     0xdd43ec: stur            w0, [x2, #0x1b]
    // 0xdd43f0: ldur            x0, [fp, #-8]
    // 0xdd43f4: StoreField: r2->field_b = r0
    //     0xdd43f4: stur            w0, [x2, #0xb]
    // 0xdd43f8: ldur            x0, [fp, #-0x38]
    // 0xdd43fc: LoadField: r1 = r0->field_b
    //     0xdd43fc: ldur            w1, [x0, #0xb]
    // 0xdd4400: LoadField: r3 = r0->field_f
    //     0xdd4400: ldur            w3, [x0, #0xf]
    // 0xdd4404: DecompressPointer r3
    //     0xdd4404: add             x3, x3, HEAP, lsl #32
    // 0xdd4408: LoadField: r4 = r3->field_b
    //     0xdd4408: ldur            w4, [x3, #0xb]
    // 0xdd440c: r3 = LoadInt32Instr(r1)
    //     0xdd440c: sbfx            x3, x1, #1, #0x1f
    // 0xdd4410: stur            x3, [fp, #-0x30]
    // 0xdd4414: r1 = LoadInt32Instr(r4)
    //     0xdd4414: sbfx            x1, x4, #1, #0x1f
    // 0xdd4418: cmp             x3, x1
    // 0xdd441c: b.ne            #0xdd4428
    // 0xdd4420: mov             x1, x0
    // 0xdd4424: r0 = _growToNextCapacity()
    //     0xdd4424: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xdd4428: ldur            d0, [fp, #-0x50]
    // 0xdd442c: ldur            x4, [fp, #-0x10]
    // 0xdd4430: ldur            x2, [fp, #-0x38]
    // 0xdd4434: ldur            x3, [fp, #-0x30]
    // 0xdd4438: add             x0, x3, #1
    // 0xdd443c: lsl             x1, x0, #1
    // 0xdd4440: StoreField: r2->field_b = r1
    //     0xdd4440: stur            w1, [x2, #0xb]
    // 0xdd4444: LoadField: r1 = r2->field_f
    //     0xdd4444: ldur            w1, [x2, #0xf]
    // 0xdd4448: DecompressPointer r1
    //     0xdd4448: add             x1, x1, HEAP, lsl #32
    // 0xdd444c: ldur            x0, [fp, #-0x28]
    // 0xdd4450: ArrayStore: r1[r3] = r0  ; List_4
    //     0xdd4450: add             x25, x1, x3, lsl #2
    //     0xdd4454: add             x25, x25, #0xf
    //     0xdd4458: str             w0, [x25]
    //     0xdd445c: tbz             w0, #0, #0xdd4478
    //     0xdd4460: ldurb           w16, [x1, #-1]
    //     0xdd4464: ldurb           w17, [x0, #-1]
    //     0xdd4468: and             x16, x17, x16, lsr #2
    //     0xdd446c: tst             x16, HEAP, lsr #32
    //     0xdd4470: b.eq            #0xdd4478
    //     0xdd4474: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdd4478: r0 = Column()
    //     0xdd4478: bl              #0x8a5b1c  ; AllocateColumnStub -> Column (size=0x38)
    // 0xdd447c: mov             x1, x0
    // 0xdd4480: r0 = Instance_Axis
    //     0xdd4480: ldr             x0, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xdd4484: stur            x1, [fp, #-8]
    // 0xdd4488: StoreField: r1->field_f = r0
    //     0xdd4488: stur            w0, [x1, #0xf]
    // 0xdd448c: r0 = Instance_MainAxisAlignment
    //     0xdd448c: add             x0, PP, #0x18, lsl #12  ; [pp+0x180f0] Obj!MainAxisAlignment@12c4581
    //     0xdd4490: ldr             x0, [x0, #0xf0]
    // 0xdd4494: StoreField: r1->field_13 = r0
    //     0xdd4494: stur            w0, [x1, #0x13]
    // 0xdd4498: r0 = Instance_MainAxisSize
    //     0xdd4498: add             x0, PP, #0x17, lsl #12  ; [pp+0x17200] Obj!MainAxisSize@12c4601
    //     0xdd449c: ldr             x0, [x0, #0x200]
    // 0xdd44a0: ArrayStore: r1[0] = r0  ; List_4
    //     0xdd44a0: stur            w0, [x1, #0x17]
    // 0xdd44a4: r0 = Instance_CrossAxisAlignment
    //     0xdd44a4: add             x0, PP, #0x15, lsl #12  ; [pp+0x15888] Obj!CrossAxisAlignment@12c44a1
    //     0xdd44a8: ldr             x0, [x0, #0x888]
    // 0xdd44ac: StoreField: r1->field_1b = r0
    //     0xdd44ac: stur            w0, [x1, #0x1b]
    // 0xdd44b0: r0 = Instance_VerticalDirection
    //     0xdd44b0: add             x0, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xdd44b4: ldr             x0, [x0, #0x838]
    // 0xdd44b8: StoreField: r1->field_23 = r0
    //     0xdd44b8: stur            w0, [x1, #0x23]
    // 0xdd44bc: r0 = Instance_Clip
    //     0xdd44bc: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xdd44c0: ldr             x0, [x0, #0x840]
    // 0xdd44c4: StoreField: r1->field_2b = r0
    //     0xdd44c4: stur            w0, [x1, #0x2b]
    // 0xdd44c8: StoreField: r1->field_2f = rZR
    //     0xdd44c8: stur            xzr, [x1, #0x2f]
    // 0xdd44cc: ldur            x0, [fp, #-0x38]
    // 0xdd44d0: StoreField: r1->field_b = r0
    //     0xdd44d0: stur            w0, [x1, #0xb]
    // 0xdd44d4: r0 = SafeArea()
    //     0xdd44d4: bl              #0xd73100  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0xdd44d8: mov             x1, x0
    // 0xdd44dc: r0 = true
    //     0xdd44dc: add             x0, NULL, #0x20  ; true
    // 0xdd44e0: stur            x1, [fp, #-0x28]
    // 0xdd44e4: StoreField: r1->field_b = r0
    //     0xdd44e4: stur            w0, [x1, #0xb]
    // 0xdd44e8: r2 = false
    //     0xdd44e8: add             x2, NULL, #0x30  ; false
    // 0xdd44ec: StoreField: r1->field_f = r2
    //     0xdd44ec: stur            w2, [x1, #0xf]
    // 0xdd44f0: StoreField: r1->field_13 = r0
    //     0xdd44f0: stur            w0, [x1, #0x13]
    // 0xdd44f4: ldur            x0, [fp, #-0x10]
    // 0xdd44f8: ArrayStore: r1[0] = r0  ; List_4
    //     0xdd44f8: stur            w0, [x1, #0x17]
    // 0xdd44fc: r0 = Instance_EdgeInsets
    //     0xdd44fc: ldr             x0, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0xdd4500: StoreField: r1->field_1b = r0
    //     0xdd4500: stur            w0, [x1, #0x1b]
    // 0xdd4504: StoreField: r1->field_1f = r2
    //     0xdd4504: stur            w2, [x1, #0x1f]
    // 0xdd4508: ldur            x0, [fp, #-8]
    // 0xdd450c: StoreField: r1->field_23 = r0
    //     0xdd450c: stur            w0, [x1, #0x23]
    // 0xdd4510: r0 = Container()
    //     0xdd4510: bl              #0x8a5af8  ; AllocateContainerStub -> Container (size=0x38)
    // 0xdd4514: stur            x0, [fp, #-8]
    // 0xdd4518: ldur            x16, [fp, #-0x18]
    // 0xdd451c: ldur            lr, [fp, #-0x20]
    // 0xdd4520: stp             lr, x16, [SP, #8]
    // 0xdd4524: ldur            x16, [fp, #-0x28]
    // 0xdd4528: str             x16, [SP]
    // 0xdd452c: mov             x1, x0
    // 0xdd4530: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, height, 0x1, padding, 0x2, null]
    //     0xdd4530: add             x4, PP, #0x91, lsl #12  ; [pp+0x91970] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "height", 0x1, "padding", 0x2, Null]
    //     0xdd4534: ldr             x4, [x4, #0x970]
    // 0xdd4538: r0 = Container()
    //     0xdd4538: bl              #0x8a54e0  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0xdd453c: r0 = AnimatedOpacity()
    //     0xdd453c: bl              #0xd2cf50  ; AllocateAnimatedOpacityStub -> AnimatedOpacity (size=0x28)
    // 0xdd4540: ldur            x1, [fp, #-8]
    // 0xdd4544: ArrayStore: r0[0] = r1  ; List_4
    //     0xdd4544: stur            w1, [x0, #0x17]
    // 0xdd4548: ldur            d0, [fp, #-0x50]
    // 0xdd454c: StoreField: r0->field_1b = d0
    //     0xdd454c: stur            d0, [x0, #0x1b]
    // 0xdd4550: r1 = false
    //     0xdd4550: add             x1, NULL, #0x30  ; false
    // 0xdd4554: StoreField: r0->field_23 = r1
    //     0xdd4554: stur            w1, [x0, #0x23]
    // 0xdd4558: r1 = Instance__Linear
    //     0xdd4558: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] Obj!_Linear@129fef1
    // 0xdd455c: StoreField: r0->field_b = r1
    //     0xdd455c: stur            w1, [x0, #0xb]
    // 0xdd4560: r1 = Instance_Duration
    //     0xdd4560: ldr             x1, [PP, #0x7cd8]  ; [pp+0x7cd8] Obj!Duration@12c8971
    // 0xdd4564: StoreField: r0->field_f = r1
    //     0xdd4564: stur            w1, [x0, #0xf]
    // 0xdd4568: LeaveFrame
    //     0xdd4568: mov             SP, fp
    //     0xdd456c: ldp             fp, lr, [SP], #0x10
    // 0xdd4570: ret
    //     0xdd4570: ret             
    // 0xdd4574: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd4574: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd4578: b               #0xdd3e7c
    // 0xdd457c: r9 = notifier
    //     0xdd457c: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3e80] Field <_MaterialControlsState@451269912.notifier>: late (offset: 0x1c)
    //     0xdd4580: ldr             x9, [x9, #0xe80]
    // 0xdd4584: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd4584: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdd4588: r0 = NullCastErrorSharedWithFPURegs()
    //     0xdd4588: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xdd458c: stp             q0, q1, [SP, #-0x20]!
    // 0xdd4590: stp             x0, x1, [SP, #-0x10]!
    // 0xdd4594: r0 = AllocateDouble()
    //     0xdd4594: bl              #0x13df878  ; AllocateDoubleStub
    // 0xdd4598: mov             x2, x0
    // 0xdd459c: ldp             x0, x1, [SP], #0x10
    // 0xdd45a0: ldp             q0, q1, [SP], #0x20
    // 0xdd45a4: b               #0xdd3f0c
    // 0xdd45a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd45a8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdd45ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd45ac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdd45b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd45b0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdd45b4: r9 = controller
    //     0xdd45b4: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3e70] Field <_MaterialControlsState@451269912.controller>: late (offset: 0x58)
    //     0xdd45b8: ldr             x9, [x9, #0xe70]
    // 0xdd45bc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd45bc: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdd45c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd45c0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdd45c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd45c4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdd45c8: SaveReg d0
    //     0xdd45c8: str             q0, [SP, #-0x10]!
    // 0xdd45cc: stp             x1, x2, [SP, #-0x10]!
    // 0xdd45d0: SaveReg r0
    //     0xdd45d0: str             x0, [SP, #-8]!
    // 0xdd45d4: r0 = AllocateDouble()
    //     0xdd45d4: bl              #0x13df878  ; AllocateDoubleStub
    // 0xdd45d8: mov             x3, x0
    // 0xdd45dc: RestoreReg r0
    //     0xdd45dc: ldr             x0, [SP], #8
    // 0xdd45e0: ldp             x1, x2, [SP], #0x10
    // 0xdd45e4: RestoreReg d0
    //     0xdd45e4: ldr             q0, [SP], #0x10
    // 0xdd45e8: b               #0xdd429c
  }
  _ _buildProgressBar(/* No info */) {
    // ** addr: 0xdd45ec, size: 0x264
    // 0xdd45ec: EnterFrame
    //     0xdd45ec: stp             fp, lr, [SP, #-0x10]!
    //     0xdd45f0: mov             fp, SP
    // 0xdd45f4: AllocStack(0x40)
    //     0xdd45f4: sub             SP, SP, #0x40
    // 0xdd45f8: SetupParameters(_MaterialControlsState this /* r1 => r1, fp-0x8 */)
    //     0xdd45f8: stur            x1, [fp, #-8]
    // 0xdd45fc: CheckStackOverflow
    //     0xdd45fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd4600: cmp             SP, x16
    //     0xdd4604: b.ls            #0xdd4824
    // 0xdd4608: r1 = 1
    //     0xdd4608: mov             x1, #1
    // 0xdd460c: r0 = AllocateContext()
    //     0xdd460c: bl              #0x13de838  ; AllocateContextStub
    // 0xdd4610: mov             x2, x0
    // 0xdd4614: ldur            x0, [fp, #-8]
    // 0xdd4618: stur            x2, [fp, #-0x18]
    // 0xdd461c: StoreField: r2->field_f = r0
    //     0xdd461c: stur            w0, [x2, #0xf]
    // 0xdd4620: LoadField: r3 = r0->field_57
    //     0xdd4620: ldur            w3, [x0, #0x57]
    // 0xdd4624: DecompressPointer r3
    //     0xdd4624: add             x3, x3, HEAP, lsl #32
    // 0xdd4628: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd462c: cmp             w3, w16
    // 0xdd4630: b.eq            #0xdd482c
    // 0xdd4634: stur            x3, [fp, #-0x10]
    // 0xdd4638: LoadField: r1 = r0->field_5b
    //     0xdd4638: ldur            w1, [x0, #0x5b]
    // 0xdd463c: DecompressPointer r1
    //     0xdd463c: add             x1, x1, HEAP, lsl #32
    // 0xdd4640: cmp             w1, NULL
    // 0xdd4644: b.eq            #0xdd4838
    // 0xdd4648: LoadField: r1 = r0->field_f
    //     0xdd4648: ldur            w1, [x0, #0xf]
    // 0xdd464c: DecompressPointer r1
    //     0xdd464c: add             x1, x1, HEAP, lsl #32
    // 0xdd4650: cmp             w1, NULL
    // 0xdd4654: b.eq            #0xdd483c
    // 0xdd4658: r0 = of()
    //     0xdd4658: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xdd465c: LoadField: r1 = r0->field_3f
    //     0xdd465c: ldur            w1, [x0, #0x3f]
    // 0xdd4660: DecompressPointer r1
    //     0xdd4660: add             x1, x1, HEAP, lsl #32
    // 0xdd4664: LoadField: r6 = r1->field_2b
    //     0xdd4664: ldur            w6, [x1, #0x2b]
    // 0xdd4668: DecompressPointer r6
    //     0xdd4668: add             x6, x6, HEAP, lsl #32
    // 0xdd466c: ldur            x0, [fp, #-8]
    // 0xdd4670: stur            x6, [fp, #-0x20]
    // 0xdd4674: LoadField: r1 = r0->field_f
    //     0xdd4674: ldur            w1, [x0, #0xf]
    // 0xdd4678: DecompressPointer r1
    //     0xdd4678: add             x1, x1, HEAP, lsl #32
    // 0xdd467c: cmp             w1, NULL
    // 0xdd4680: b.eq            #0xdd4840
    // 0xdd4684: r0 = of()
    //     0xdd4684: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xdd4688: LoadField: r1 = r0->field_3f
    //     0xdd4688: ldur            w1, [x0, #0x3f]
    // 0xdd468c: DecompressPointer r1
    //     0xdd468c: add             x1, x1, HEAP, lsl #32
    // 0xdd4690: LoadField: r5 = r1->field_2b
    //     0xdd4690: ldur            w5, [x1, #0x2b]
    // 0xdd4694: DecompressPointer r5
    //     0xdd4694: add             x5, x5, HEAP, lsl #32
    // 0xdd4698: ldur            x0, [fp, #-8]
    // 0xdd469c: stur            x5, [fp, #-0x28]
    // 0xdd46a0: LoadField: r1 = r0->field_f
    //     0xdd46a0: ldur            w1, [x0, #0xf]
    // 0xdd46a4: DecompressPointer r1
    //     0xdd46a4: add             x1, x1, HEAP, lsl #32
    // 0xdd46a8: cmp             w1, NULL
    // 0xdd46ac: b.eq            #0xdd4844
    // 0xdd46b0: r0 = of()
    //     0xdd46b0: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xdd46b4: LoadField: r1 = r0->field_3f
    //     0xdd46b4: ldur            w1, [x0, #0x3f]
    // 0xdd46b8: DecompressPointer r1
    //     0xdd46b8: add             x1, x1, HEAP, lsl #32
    // 0xdd46bc: LoadField: r0 = r1->field_7b
    //     0xdd46bc: ldur            w0, [x1, #0x7b]
    // 0xdd46c0: DecompressPointer r0
    //     0xdd46c0: add             x0, x0, HEAP, lsl #32
    // 0xdd46c4: r1 = LoadClassIdInstr(r0)
    //     0xdd46c4: ldur            x1, [x0, #-1]
    //     0xdd46c8: ubfx            x1, x1, #0xc, #0x14
    // 0xdd46cc: r16 = 0.500000
    //     0xdd46cc: ldr             x16, [PP, #0x4c70]  ; [pp+0x4c70] 0.5
    // 0xdd46d0: str             x16, [SP]
    // 0xdd46d4: mov             x16, x0
    // 0xdd46d8: mov             x0, x1
    // 0xdd46dc: mov             x1, x16
    // 0xdd46e0: r4 = const [0, 0x2, 0x1, 0x1, alpha, 0x1, null]
    //     0xdd46e0: add             x4, PP, #0x28, lsl #12  ; [pp+0x28640] List(7) [0, 0x2, 0x1, 0x1, "alpha", 0x1, Null]
    //     0xdd46e4: ldr             x4, [x4, #0x640]
    // 0xdd46e8: r0 = GDT[cid_x0 + -0xffa]()
    //     0xdd46e8: sub             lr, x0, #0xffa
    //     0xdd46ec: ldr             lr, [x21, lr, lsl #3]
    //     0xdd46f0: blr             lr
    // 0xdd46f4: mov             x2, x0
    // 0xdd46f8: ldur            x0, [fp, #-8]
    // 0xdd46fc: stur            x2, [fp, #-0x30]
    // 0xdd4700: LoadField: r1 = r0->field_f
    //     0xdd4700: ldur            w1, [x0, #0xf]
    // 0xdd4704: DecompressPointer r1
    //     0xdd4704: add             x1, x1, HEAP, lsl #32
    // 0xdd4708: cmp             w1, NULL
    // 0xdd470c: b.eq            #0xdd4848
    // 0xdd4710: r0 = of()
    //     0xdd4710: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xdd4714: LoadField: r1 = r0->field_43
    //     0xdd4714: ldur            w1, [x0, #0x43]
    // 0xdd4718: DecompressPointer r1
    //     0xdd4718: add             x1, x1, HEAP, lsl #32
    // 0xdd471c: r16 = 0.500000
    //     0xdd471c: ldr             x16, [PP, #0x4c70]  ; [pp+0x4c70] 0.5
    // 0xdd4720: str             x16, [SP]
    // 0xdd4724: r4 = const [0, 0x2, 0x1, 0x1, alpha, 0x1, null]
    //     0xdd4724: add             x4, PP, #0x28, lsl #12  ; [pp+0x28640] List(7) [0, 0x2, 0x1, 0x1, "alpha", 0x1, Null]
    //     0xdd4728: ldr             x4, [x4, #0x640]
    // 0xdd472c: r0 = withValues()
    //     0xdd472c: bl              #0x12d8818  ; [dart:ui] Color::withValues
    // 0xdd4730: stur            x0, [fp, #-0x38]
    // 0xdd4734: r0 = ChewieProgressColors()
    //     0xdd4734: bl              #0xdcfa1c  ; AllocateChewieProgressColorsStub -> ChewieProgressColors (size=0x18)
    // 0xdd4738: mov             x1, x0
    // 0xdd473c: ldur            x2, [fp, #-0x38]
    // 0xdd4740: ldur            x3, [fp, #-0x30]
    // 0xdd4744: ldur            x5, [fp, #-0x28]
    // 0xdd4748: ldur            x6, [fp, #-0x20]
    // 0xdd474c: stur            x0, [fp, #-0x20]
    // 0xdd4750: r0 = ChewieProgressColors()
    //     0xdd4750: bl              #0xdcf874  ; [package:chewie/src/chewie_progress_colors.dart] ChewieProgressColors::ChewieProgressColors
    // 0xdd4754: ldur            x0, [fp, #-8]
    // 0xdd4758: LoadField: r1 = r0->field_5b
    //     0xdd4758: ldur            w1, [x0, #0x5b]
    // 0xdd475c: DecompressPointer r1
    //     0xdd475c: add             x1, x1, HEAP, lsl #32
    // 0xdd4760: cmp             w1, NULL
    // 0xdd4764: b.eq            #0xdd484c
    // 0xdd4768: r0 = MaterialVideoProgressBar()
    //     0xdd4768: bl              #0xdcfce0  ; AllocateMaterialVideoProgressBarStub -> MaterialVideoProgressBar (size=0x34)
    // 0xdd476c: mov             x3, x0
    // 0xdd4770: ldur            x0, [fp, #-0x10]
    // 0xdd4774: stur            x3, [fp, #-8]
    // 0xdd4778: StoreField: r3->field_1b = r0
    //     0xdd4778: stur            w0, [x3, #0x1b]
    // 0xdd477c: d0 = 10.000000
    //     0xdd477c: fmov            d0, #10.00000000
    // 0xdd4780: StoreField: r3->field_b = d0
    //     0xdd4780: stur            d0, [x3, #0xb]
    // 0xdd4784: d0 = 6.000000
    //     0xdd4784: fmov            d0, #6.00000000
    // 0xdd4788: StoreField: r3->field_13 = d0
    //     0xdd4788: stur            d0, [x3, #0x13]
    // 0xdd478c: ldur            x2, [fp, #-0x18]
    // 0xdd4790: r1 = Function '<anonymous closure>':.
    //     0xdd4790: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3ec8] AnonymousClosure: (0xdd48dc), in [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_buildProgressBar (0xdd45ec)
    //     0xdd4794: ldr             x1, [x1, #0xec8]
    // 0xdd4798: r0 = AllocateClosure()
    //     0xdd4798: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd479c: mov             x1, x0
    // 0xdd47a0: ldur            x0, [fp, #-8]
    // 0xdd47a4: StoreField: r0->field_27 = r1
    //     0xdd47a4: stur            w1, [x0, #0x27]
    // 0xdd47a8: ldur            x2, [fp, #-0x18]
    // 0xdd47ac: r1 = Function '<anonymous closure>':.
    //     0xdd47ac: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3ed0] AnonymousClosure: (0xdd4850), in [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_buildProgressBar (0xdd45ec)
    //     0xdd47b0: ldr             x1, [x1, #0xed0]
    // 0xdd47b4: r0 = AllocateClosure()
    //     0xdd47b4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd47b8: mov             x1, x0
    // 0xdd47bc: ldur            x0, [fp, #-8]
    // 0xdd47c0: StoreField: r0->field_23 = r1
    //     0xdd47c0: stur            w1, [x0, #0x23]
    // 0xdd47c4: ldur            x2, [fp, #-0x18]
    // 0xdd47c8: r1 = Function '<anonymous closure>':.
    //     0xdd47c8: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3ed8] AnonymousClosure: (0xdcfa28), in [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_buildProgressBar (0xdcfa7c)
    //     0xdd47cc: ldr             x1, [x1, #0xed8]
    // 0xdd47d0: r0 = AllocateClosure()
    //     0xdd47d0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd47d4: mov             x1, x0
    // 0xdd47d8: ldur            x0, [fp, #-8]
    // 0xdd47dc: StoreField: r0->field_2b = r1
    //     0xdd47dc: stur            w1, [x0, #0x2b]
    // 0xdd47e0: r1 = true
    //     0xdd47e0: add             x1, NULL, #0x20  ; true
    // 0xdd47e4: StoreField: r0->field_2f = r1
    //     0xdd47e4: stur            w1, [x0, #0x2f]
    // 0xdd47e8: ldur            x1, [fp, #-0x20]
    // 0xdd47ec: StoreField: r0->field_1f = r1
    //     0xdd47ec: stur            w1, [x0, #0x1f]
    // 0xdd47f0: r1 = <FlexParentData>
    //     0xdd47f0: add             x1, PP, #0x15, lsl #12  ; [pp+0x15878] TypeArguments: <FlexParentData>
    //     0xdd47f4: ldr             x1, [x1, #0x878]
    // 0xdd47f8: r0 = Expanded()
    //     0xdd47f8: bl              #0x8a5b10  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0xdd47fc: r1 = 1
    //     0xdd47fc: mov             x1, #1
    // 0xdd4800: StoreField: r0->field_13 = r1
    //     0xdd4800: stur            x1, [x0, #0x13]
    // 0xdd4804: r1 = Instance_FlexFit
    //     0xdd4804: add             x1, PP, #0x15, lsl #12  ; [pp+0x15880] Obj!FlexFit@12c4641
    //     0xdd4808: ldr             x1, [x1, #0x880]
    // 0xdd480c: StoreField: r0->field_1b = r1
    //     0xdd480c: stur            w1, [x0, #0x1b]
    // 0xdd4810: ldur            x1, [fp, #-8]
    // 0xdd4814: StoreField: r0->field_b = r1
    //     0xdd4814: stur            w1, [x0, #0xb]
    // 0xdd4818: LeaveFrame
    //     0xdd4818: mov             SP, fp
    //     0xdd481c: ldp             fp, lr, [SP], #0x10
    // 0xdd4820: ret
    //     0xdd4820: ret             
    // 0xdd4824: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd4824: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd4828: b               #0xdd4608
    // 0xdd482c: r9 = controller
    //     0xdd482c: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3e70] Field <_MaterialControlsState@451269912.controller>: late (offset: 0x58)
    //     0xdd4830: ldr             x9, [x9, #0xe70]
    // 0xdd4834: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd4834: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdd4838: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd4838: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdd483c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd483c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdd4840: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd4840: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdd4844: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd4844: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdd4848: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd4848: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdd484c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd484c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Null <anonymous closure>(dynamic) {
    // ** addr: 0xdd4850, size: 0x8c
    // 0xdd4850: EnterFrame
    //     0xdd4850: stp             fp, lr, [SP, #-0x10]!
    //     0xdd4854: mov             fp, SP
    // 0xdd4858: AllocStack(0x10)
    //     0xdd4858: sub             SP, SP, #0x10
    // 0xdd485c: SetupParameters([dynamic _ /* r0 */])
    //     0xdd485c: ldr             x0, [fp, #0x10]
    //     0xdd4860: ldur            w3, [x0, #0x17]
    //     0xdd4864: add             x3, x3, HEAP, lsl #32
    //     0xdd4868: stur            x3, [fp, #-0x10]
    // 0xdd486c: CheckStackOverflow
    //     0xdd486c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd4870: cmp             SP, x16
    //     0xdd4874: b.ls            #0xdd48d4
    // 0xdd4878: LoadField: r0 = r3->field_f
    //     0xdd4878: ldur            w0, [x3, #0xf]
    // 0xdd487c: DecompressPointer r0
    //     0xdd487c: add             x0, x0, HEAP, lsl #32
    // 0xdd4880: mov             x2, x3
    // 0xdd4884: stur            x0, [fp, #-8]
    // 0xdd4888: r1 = Function '<anonymous closure>':.
    //     0xdd4888: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3ee0] AnonymousClosure: (0xdcfd78), in [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_buildProgressBar (0xdcfa7c)
    //     0xdd488c: ldr             x1, [x1, #0xee0]
    // 0xdd4890: r0 = AllocateClosure()
    //     0xdd4890: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd4894: ldur            x1, [fp, #-8]
    // 0xdd4898: mov             x2, x0
    // 0xdd489c: r0 = setState()
    //     0xdd489c: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xdd48a0: ldur            x0, [fp, #-0x10]
    // 0xdd48a4: LoadField: r1 = r0->field_f
    //     0xdd48a4: ldur            w1, [x0, #0xf]
    // 0xdd48a8: DecompressPointer r1
    //     0xdd48a8: add             x1, x1, HEAP, lsl #32
    // 0xdd48ac: LoadField: r0 = r1->field_27
    //     0xdd48ac: ldur            w0, [x1, #0x27]
    // 0xdd48b0: DecompressPointer r0
    //     0xdd48b0: add             x0, x0, HEAP, lsl #32
    // 0xdd48b4: cmp             w0, NULL
    // 0xdd48b8: b.eq            #0xdd48c4
    // 0xdd48bc: mov             x1, x0
    // 0xdd48c0: r0 = cancel()
    //     0xdd48c0: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0xdd48c4: r0 = Null
    //     0xdd48c4: mov             x0, NULL
    // 0xdd48c8: LeaveFrame
    //     0xdd48c8: mov             SP, fp
    //     0xdd48cc: ldp             fp, lr, [SP], #0x10
    // 0xdd48d0: ret
    //     0xdd48d0: ret             
    // 0xdd48d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd48d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd48d8: b               #0xdd4878
  }
  [closure] Null <anonymous closure>(dynamic) {
    // ** addr: 0xdd48dc, size: 0x78
    // 0xdd48dc: EnterFrame
    //     0xdd48dc: stp             fp, lr, [SP, #-0x10]!
    //     0xdd48e0: mov             fp, SP
    // 0xdd48e4: AllocStack(0x10)
    //     0xdd48e4: sub             SP, SP, #0x10
    // 0xdd48e8: SetupParameters([dynamic _ /* r0 */])
    //     0xdd48e8: ldr             x0, [fp, #0x10]
    //     0xdd48ec: ldur            w3, [x0, #0x17]
    //     0xdd48f0: add             x3, x3, HEAP, lsl #32
    //     0xdd48f4: stur            x3, [fp, #-0x10]
    // 0xdd48f8: CheckStackOverflow
    //     0xdd48f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd48fc: cmp             SP, x16
    //     0xdd4900: b.ls            #0xdd494c
    // 0xdd4904: LoadField: r0 = r3->field_f
    //     0xdd4904: ldur            w0, [x3, #0xf]
    // 0xdd4908: DecompressPointer r0
    //     0xdd4908: add             x0, x0, HEAP, lsl #32
    // 0xdd490c: mov             x2, x3
    // 0xdd4910: stur            x0, [fp, #-8]
    // 0xdd4914: r1 = Function '<anonymous closure>':.
    //     0xdd4914: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3ee8] AnonymousClosure: (0xdcff84), in [package:youtube_player_iframe/src/widgets/youtube_player.dart] _YoutubePlayerState::_onValueChanged (0xdcffa8)
    //     0xdd4918: ldr             x1, [x1, #0xee8]
    // 0xdd491c: r0 = AllocateClosure()
    //     0xdd491c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd4920: ldur            x1, [fp, #-8]
    // 0xdd4924: mov             x2, x0
    // 0xdd4928: r0 = setState()
    //     0xdd4928: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xdd492c: ldur            x0, [fp, #-0x10]
    // 0xdd4930: LoadField: r1 = r0->field_f
    //     0xdd4930: ldur            w1, [x0, #0xf]
    // 0xdd4934: DecompressPointer r1
    //     0xdd4934: add             x1, x1, HEAP, lsl #32
    // 0xdd4938: r0 = _startHideTimer()
    //     0xdd4938: bl              #0xdd4954  ; [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_startHideTimer
    // 0xdd493c: r0 = Null
    //     0xdd493c: mov             x0, NULL
    // 0xdd4940: LeaveFrame
    //     0xdd4940: mov             SP, fp
    //     0xdd4944: ldp             fp, lr, [SP], #0x10
    // 0xdd4948: ret
    //     0xdd4948: ret             
    // 0xdd494c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd494c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd4950: b               #0xdd4904
  }
  _ _startHideTimer(/* No info */) {
    // ** addr: 0xdd4954, size: 0xa0
    // 0xdd4954: EnterFrame
    //     0xdd4954: stp             fp, lr, [SP, #-0x10]!
    //     0xdd4958: mov             fp, SP
    // 0xdd495c: AllocStack(0x8)
    //     0xdd495c: sub             SP, SP, #8
    // 0xdd4960: SetupParameters(_MaterialControlsState this /* r1 => r1, fp-0x8 */)
    //     0xdd4960: stur            x1, [fp, #-8]
    // 0xdd4964: CheckStackOverflow
    //     0xdd4964: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd4968: cmp             SP, x16
    //     0xdd496c: b.ls            #0xdd49e8
    // 0xdd4970: r1 = 1
    //     0xdd4970: mov             x1, #1
    // 0xdd4974: r0 = AllocateContext()
    //     0xdd4974: bl              #0x13de838  ; AllocateContextStub
    // 0xdd4978: mov             x1, x0
    // 0xdd497c: ldur            x0, [fp, #-8]
    // 0xdd4980: StoreField: r1->field_f = r0
    //     0xdd4980: stur            w0, [x1, #0xf]
    // 0xdd4984: LoadField: r2 = r0->field_5b
    //     0xdd4984: ldur            w2, [x0, #0x5b]
    // 0xdd4988: DecompressPointer r2
    //     0xdd4988: add             x2, x2, HEAP, lsl #32
    // 0xdd498c: cmp             w2, NULL
    // 0xdd4990: b.eq            #0xdd49f0
    // 0xdd4994: mov             x2, x1
    // 0xdd4998: r1 = Function '<anonymous closure>':.
    //     0xdd4998: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3e88] AnonymousClosure: (0xdd49f4), in [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_startHideTimer (0xdd4954)
    //     0xdd499c: ldr             x1, [x1, #0xe88]
    // 0xdd49a0: r0 = AllocateClosure()
    //     0xdd49a0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd49a4: mov             x3, x0
    // 0xdd49a8: r1 = Null
    //     0xdd49a8: mov             x1, NULL
    // 0xdd49ac: r2 = Instance_Duration
    //     0xdd49ac: add             x2, PP, #0x16, lsl #12  ; [pp+0x16670] Obj!Duration@12c8961
    //     0xdd49b0: ldr             x2, [x2, #0x670]
    // 0xdd49b4: r0 = Timer()
    //     0xdd49b4: bl              #0x7eed74  ; [dart:async] Timer::Timer
    // 0xdd49b8: ldur            x1, [fp, #-8]
    // 0xdd49bc: StoreField: r1->field_27 = r0
    //     0xdd49bc: stur            w0, [x1, #0x27]
    //     0xdd49c0: ldurb           w16, [x1, #-1]
    //     0xdd49c4: ldurb           w17, [x0, #-1]
    //     0xdd49c8: and             x16, x17, x16, lsr #2
    //     0xdd49cc: tst             x16, HEAP, lsr #32
    //     0xdd49d0: b.eq            #0xdd49d8
    //     0xdd49d4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdd49d8: r0 = Null
    //     0xdd49d8: mov             x0, NULL
    // 0xdd49dc: LeaveFrame
    //     0xdd49dc: mov             SP, fp
    //     0xdd49e0: ldp             fp, lr, [SP], #0x10
    // 0xdd49e4: ret
    //     0xdd49e4: ret             
    // 0xdd49e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd49e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd49ec: b               #0xdd4970
    // 0xdd49f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd49f0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xdd49f4, size: 0x80
    // 0xdd49f4: EnterFrame
    //     0xdd49f4: stp             fp, lr, [SP, #-0x10]!
    //     0xdd49f8: mov             fp, SP
    // 0xdd49fc: AllocStack(0x8)
    //     0xdd49fc: sub             SP, SP, #8
    // 0xdd4a00: SetupParameters([dynamic _ /* r0 */])
    //     0xdd4a00: ldr             x0, [fp, #0x10]
    //     0xdd4a04: ldur            w2, [x0, #0x17]
    //     0xdd4a08: add             x2, x2, HEAP, lsl #32
    // 0xdd4a0c: CheckStackOverflow
    //     0xdd4a0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd4a10: cmp             SP, x16
    //     0xdd4a14: b.ls            #0xdd4a6c
    // 0xdd4a18: LoadField: r0 = r2->field_f
    //     0xdd4a18: ldur            w0, [x2, #0xf]
    // 0xdd4a1c: DecompressPointer r0
    //     0xdd4a1c: add             x0, x0, HEAP, lsl #32
    // 0xdd4a20: stur            x0, [fp, #-8]
    // 0xdd4a24: LoadField: r1 = r0->field_f
    //     0xdd4a24: ldur            w1, [x0, #0xf]
    // 0xdd4a28: DecompressPointer r1
    //     0xdd4a28: add             x1, x1, HEAP, lsl #32
    // 0xdd4a2c: cmp             w1, NULL
    // 0xdd4a30: b.ne            #0xdd4a44
    // 0xdd4a34: r0 = Null
    //     0xdd4a34: mov             x0, NULL
    // 0xdd4a38: LeaveFrame
    //     0xdd4a38: mov             SP, fp
    //     0xdd4a3c: ldp             fp, lr, [SP], #0x10
    // 0xdd4a40: ret
    //     0xdd4a40: ret             
    // 0xdd4a44: r1 = Function '<anonymous closure>':.
    //     0xdd4a44: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3e90] AnonymousClosure: (0xdd4a74), in [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_startHideTimer (0xdd4954)
    //     0xdd4a48: ldr             x1, [x1, #0xe90]
    // 0xdd4a4c: r0 = AllocateClosure()
    //     0xdd4a4c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd4a50: ldur            x1, [fp, #-8]
    // 0xdd4a54: mov             x2, x0
    // 0xdd4a58: r0 = setState()
    //     0xdd4a58: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xdd4a5c: r0 = Null
    //     0xdd4a5c: mov             x0, NULL
    // 0xdd4a60: LeaveFrame
    //     0xdd4a60: mov             SP, fp
    //     0xdd4a64: ldp             fp, lr, [SP], #0x10
    // 0xdd4a68: ret
    //     0xdd4a68: ret             
    // 0xdd4a6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd4a6c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd4a70: b               #0xdd4a18
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xdd4a74, size: 0x70
    // 0xdd4a74: EnterFrame
    //     0xdd4a74: stp             fp, lr, [SP, #-0x10]!
    //     0xdd4a78: mov             fp, SP
    // 0xdd4a7c: r0 = true
    //     0xdd4a7c: add             x0, NULL, #0x20  ; true
    // 0xdd4a80: ldr             x1, [fp, #0x10]
    // 0xdd4a84: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xdd4a84: ldur            w2, [x1, #0x17]
    // 0xdd4a88: DecompressPointer r2
    //     0xdd4a88: add             x2, x2, HEAP, lsl #32
    // 0xdd4a8c: CheckStackOverflow
    //     0xdd4a8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd4a90: cmp             SP, x16
    //     0xdd4a94: b.ls            #0xdd4ad0
    // 0xdd4a98: LoadField: r1 = r2->field_f
    //     0xdd4a98: ldur            w1, [x2, #0xf]
    // 0xdd4a9c: DecompressPointer r1
    //     0xdd4a9c: add             x1, x1, HEAP, lsl #32
    // 0xdd4aa0: LoadField: r2 = r1->field_1b
    //     0xdd4aa0: ldur            w2, [x1, #0x1b]
    // 0xdd4aa4: DecompressPointer r2
    //     0xdd4aa4: add             x2, x2, HEAP, lsl #32
    // 0xdd4aa8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd4aac: cmp             w2, w16
    // 0xdd4ab0: b.eq            #0xdd4ad8
    // 0xdd4ab4: StoreField: r2->field_23 = r0
    //     0xdd4ab4: stur            w0, [x2, #0x23]
    // 0xdd4ab8: mov             x1, x2
    // 0xdd4abc: r0 = notifyListeners()
    //     0xdd4abc: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xdd4ac0: r0 = Null
    //     0xdd4ac0: mov             x0, NULL
    // 0xdd4ac4: LeaveFrame
    //     0xdd4ac4: mov             SP, fp
    //     0xdd4ac8: ldp             fp, lr, [SP], #0x10
    // 0xdd4acc: ret
    //     0xdd4acc: ret             
    // 0xdd4ad0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd4ad0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd4ad4: b               #0xdd4a98
    // 0xdd4ad8: r9 = notifier
    //     0xdd4ad8: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3e80] Field <_MaterialControlsState@451269912.notifier>: late (offset: 0x1c)
    //     0xdd4adc: ldr             x9, [x9, #0xe80]
    // 0xdd4ae0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd4ae0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _buildExpandButton(/* No info */) {
    // ** addr: 0xdd4ae4, size: 0x218
    // 0xdd4ae4: EnterFrame
    //     0xdd4ae4: stp             fp, lr, [SP, #-0x10]!
    //     0xdd4ae8: mov             fp, SP
    // 0xdd4aec: AllocStack(0x48)
    //     0xdd4aec: sub             SP, SP, #0x48
    // 0xdd4af0: SetupParameters(_MaterialControlsState this /* r1 => r2, fp-0x8 */)
    //     0xdd4af0: mov             x2, x1
    //     0xdd4af4: stur            x1, [fp, #-8]
    // 0xdd4af8: CheckStackOverflow
    //     0xdd4af8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd4afc: cmp             SP, x16
    //     0xdd4b00: b.ls            #0xdd4cc4
    // 0xdd4b04: LoadField: r0 = r2->field_1b
    //     0xdd4b04: ldur            w0, [x2, #0x1b]
    // 0xdd4b08: DecompressPointer r0
    //     0xdd4b08: add             x0, x0, HEAP, lsl #32
    // 0xdd4b0c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd4b10: cmp             w0, w16
    // 0xdd4b14: b.eq            #0xdd4ccc
    // 0xdd4b18: LoadField: r1 = r0->field_23
    //     0xdd4b18: ldur            w1, [x0, #0x23]
    // 0xdd4b1c: DecompressPointer r1
    //     0xdd4b1c: add             x1, x1, HEAP, lsl #32
    // 0xdd4b20: tbnz            w1, #4, #0xdd4b2c
    // 0xdd4b24: d0 = 0.000000
    //     0xdd4b24: eor             v0.16b, v0.16b, v0.16b
    // 0xdd4b28: b               #0xdd4b30
    // 0xdd4b2c: d0 = 1.000000
    //     0xdd4b2c: fmov            d0, #1.00000000
    // 0xdd4b30: stur            d0, [fp, #-0x28]
    // 0xdd4b34: LoadField: d1 = r2->field_47
    //     0xdd4b34: ldur            d1, [x2, #0x47]
    // 0xdd4b38: LoadField: r0 = r2->field_5b
    //     0xdd4b38: ldur            w0, [x2, #0x5b]
    // 0xdd4b3c: DecompressPointer r0
    //     0xdd4b3c: add             x0, x0, HEAP, lsl #32
    // 0xdd4b40: cmp             w0, NULL
    // 0xdd4b44: b.eq            #0xdd4cd8
    // 0xdd4b48: LoadField: r1 = r0->field_cf
    //     0xdd4b48: ldur            w1, [x0, #0xcf]
    // 0xdd4b4c: DecompressPointer r1
    //     0xdd4b4c: add             x1, x1, HEAP, lsl #32
    // 0xdd4b50: tbnz            w1, #4, #0xdd4b60
    // 0xdd4b54: r0 = 15.000000
    //     0xdd4b54: add             x0, PP, #0x27, lsl #12  ; [pp+0x274b0] 15
    //     0xdd4b58: ldr             x0, [x0, #0x4b0]
    // 0xdd4b5c: b               #0xdd4b64
    // 0xdd4b60: r0 = 0
    //     0xdd4b60: mov             x0, #0
    // 0xdd4b64: r1 = inline_Allocate_Double()
    //     0xdd4b64: ldp             x1, x3, [THR, #0x60]  ; THR::top
    //     0xdd4b68: add             x1, x1, #0x10
    //     0xdd4b6c: cmp             x3, x1
    //     0xdd4b70: b.ls            #0xdd4cdc
    //     0xdd4b74: str             x1, [THR, #0x60]  ; THR::top
    //     0xdd4b78: sub             x1, x1, #0xf
    //     0xdd4b7c: mov             x3, #0xe19c
    //     0xdd4b80: movk            x3, #3, lsl #16
    //     0xdd4b84: stur            x3, [x1, #-1]
    // 0xdd4b88: dmb             ishst
    // 0xdd4b8c: StoreField: r1->field_7 = d1
    //     0xdd4b8c: stur            d1, [x1, #7]
    // 0xdd4b90: stp             x0, x1, [SP]
    // 0xdd4b94: r0 = +()
    //     0xdd4b94: bl              #0x13dce50  ; [dart:core] _Double::+
    // 0xdd4b98: ldur            x2, [fp, #-8]
    // 0xdd4b9c: stur            x0, [fp, #-0x18]
    // 0xdd4ba0: LoadField: r1 = r2->field_5b
    //     0xdd4ba0: ldur            w1, [x2, #0x5b]
    // 0xdd4ba4: DecompressPointer r1
    //     0xdd4ba4: add             x1, x1, HEAP, lsl #32
    // 0xdd4ba8: cmp             w1, NULL
    // 0xdd4bac: b.eq            #0xdd4cf8
    // 0xdd4bb0: LoadField: r3 = r1->field_cf
    //     0xdd4bb0: ldur            w3, [x1, #0xcf]
    // 0xdd4bb4: DecompressPointer r3
    //     0xdd4bb4: add             x3, x3, HEAP, lsl #32
    // 0xdd4bb8: tbnz            w3, #4, #0xdd4bc8
    // 0xdd4bbc: r1 = Instance_IconData
    //     0xdd4bbc: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3d88] Obj!IconData@128a751
    //     0xdd4bc0: ldr             x1, [x1, #0xd88]
    // 0xdd4bc4: b               #0xdd4bd0
    // 0xdd4bc8: r1 = Instance_IconData
    //     0xdd4bc8: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3d90] Obj!IconData@128a731
    //     0xdd4bcc: ldr             x1, [x1, #0xd90]
    // 0xdd4bd0: ldur            d0, [fp, #-0x28]
    // 0xdd4bd4: stur            x1, [fp, #-0x10]
    // 0xdd4bd8: r0 = Icon()
    //     0xdd4bd8: bl              #0xd0fd5c  ; AllocateIconStub -> Icon (size=0x40)
    // 0xdd4bdc: mov             x1, x0
    // 0xdd4be0: ldur            x0, [fp, #-0x10]
    // 0xdd4be4: stur            x1, [fp, #-0x20]
    // 0xdd4be8: StoreField: r1->field_b = r0
    //     0xdd4be8: stur            w0, [x1, #0xb]
    // 0xdd4bec: r0 = Instance_Color
    //     0xdd4bec: add             x0, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0xdd4bf0: ldr             x0, [x0, #0xc38]
    // 0xdd4bf4: StoreField: r1->field_23 = r0
    //     0xdd4bf4: stur            w0, [x1, #0x23]
    // 0xdd4bf8: r0 = Center()
    //     0xdd4bf8: bl              #0xd0c898  ; AllocateCenterStub -> Center (size=0x1c)
    // 0xdd4bfc: mov             x1, x0
    // 0xdd4c00: r0 = Instance_Alignment
    //     0xdd4c00: add             x0, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xdd4c04: ldr             x0, [x0, #0xb80]
    // 0xdd4c08: stur            x1, [fp, #-0x10]
    // 0xdd4c0c: StoreField: r1->field_f = r0
    //     0xdd4c0c: stur            w0, [x1, #0xf]
    // 0xdd4c10: ldur            x0, [fp, #-0x20]
    // 0xdd4c14: StoreField: r1->field_b = r0
    //     0xdd4c14: stur            w0, [x1, #0xb]
    // 0xdd4c18: r0 = Container()
    //     0xdd4c18: bl              #0x8a5af8  ; AllocateContainerStub -> Container (size=0x38)
    // 0xdd4c1c: stur            x0, [fp, #-0x20]
    // 0xdd4c20: ldur            x16, [fp, #-0x18]
    // 0xdd4c24: r30 = Instance_EdgeInsets
    //     0xdd4c24: add             lr, PP, #0xd3, lsl #12  ; [pp+0xd3d98] Obj!EdgeInsets@129d351
    //     0xdd4c28: ldr             lr, [lr, #0xd98]
    // 0xdd4c2c: stp             lr, x16, [SP, #0x10]
    // 0xdd4c30: r16 = Instance_EdgeInsets
    //     0xdd4c30: add             x16, PP, #0x7a, lsl #12  ; [pp+0x7abf0] Obj!EdgeInsets@129cd21
    //     0xdd4c34: ldr             x16, [x16, #0xbf0]
    // 0xdd4c38: ldur            lr, [fp, #-0x10]
    // 0xdd4c3c: stp             lr, x16, [SP]
    // 0xdd4c40: mov             x1, x0
    // 0xdd4c44: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, height, 0x1, margin, 0x2, padding, 0x3, null]
    //     0xdd4c44: add             x4, PP, #0xd3, lsl #12  ; [pp+0xd3da0] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "height", 0x1, "margin", 0x2, "padding", 0x3, Null]
    //     0xdd4c48: ldr             x4, [x4, #0xda0]
    // 0xdd4c4c: r0 = Container()
    //     0xdd4c4c: bl              #0x8a54e0  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0xdd4c50: r0 = AnimatedOpacity()
    //     0xdd4c50: bl              #0xd2cf50  ; AllocateAnimatedOpacityStub -> AnimatedOpacity (size=0x28)
    // 0xdd4c54: mov             x1, x0
    // 0xdd4c58: ldur            x0, [fp, #-0x20]
    // 0xdd4c5c: stur            x1, [fp, #-0x10]
    // 0xdd4c60: ArrayStore: r1[0] = r0  ; List_4
    //     0xdd4c60: stur            w0, [x1, #0x17]
    // 0xdd4c64: ldur            d0, [fp, #-0x28]
    // 0xdd4c68: StoreField: r1->field_1b = d0
    //     0xdd4c68: stur            d0, [x1, #0x1b]
    // 0xdd4c6c: r0 = false
    //     0xdd4c6c: add             x0, NULL, #0x30  ; false
    // 0xdd4c70: StoreField: r1->field_23 = r0
    //     0xdd4c70: stur            w0, [x1, #0x23]
    // 0xdd4c74: r0 = Instance__Linear
    //     0xdd4c74: ldr             x0, [PP, #0x5168]  ; [pp+0x5168] Obj!_Linear@129fef1
    // 0xdd4c78: StoreField: r1->field_b = r0
    //     0xdd4c78: stur            w0, [x1, #0xb]
    // 0xdd4c7c: r0 = Instance_Duration
    //     0xdd4c7c: ldr             x0, [PP, #0x7cd8]  ; [pp+0x7cd8] Obj!Duration@12c8971
    // 0xdd4c80: StoreField: r1->field_f = r0
    //     0xdd4c80: stur            w0, [x1, #0xf]
    // 0xdd4c84: r0 = GestureDetector()
    //     0xdd4c84: bl              #0x918e18  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0xdd4c88: ldur            x2, [fp, #-8]
    // 0xdd4c8c: r1 = Function '_onExpandCollapse@451269912':.
    //     0xdd4c8c: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3ef0] AnonymousClosure: (0xdd4cfc), in [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_onExpandCollapse (0xdd4d34)
    //     0xdd4c90: ldr             x1, [x1, #0xef0]
    // 0xdd4c94: stur            x0, [fp, #-8]
    // 0xdd4c98: r0 = AllocateClosure()
    //     0xdd4c98: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd4c9c: ldur            x16, [fp, #-0x10]
    // 0xdd4ca0: stp             x16, x0, [SP]
    // 0xdd4ca4: ldur            x1, [fp, #-8]
    // 0xdd4ca8: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0xdd4ca8: add             x4, PP, #0x16, lsl #12  ; [pp+0x16e90] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0xdd4cac: ldr             x4, [x4, #0xe90]
    // 0xdd4cb0: r0 = GestureDetector()
    //     0xdd4cb0: bl              #0x9182dc  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0xdd4cb4: ldur            x0, [fp, #-8]
    // 0xdd4cb8: LeaveFrame
    //     0xdd4cb8: mov             SP, fp
    //     0xdd4cbc: ldp             fp, lr, [SP], #0x10
    // 0xdd4cc0: ret
    //     0xdd4cc0: ret             
    // 0xdd4cc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd4cc4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd4cc8: b               #0xdd4b04
    // 0xdd4ccc: r9 = notifier
    //     0xdd4ccc: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3e80] Field <_MaterialControlsState@451269912.notifier>: late (offset: 0x1c)
    //     0xdd4cd0: ldr             x9, [x9, #0xe80]
    // 0xdd4cd4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd4cd4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdd4cd8: r0 = NullCastErrorSharedWithFPURegs()
    //     0xdd4cd8: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xdd4cdc: stp             q0, q1, [SP, #-0x20]!
    // 0xdd4ce0: stp             x0, x2, [SP, #-0x10]!
    // 0xdd4ce4: r0 = AllocateDouble()
    //     0xdd4ce4: bl              #0x13df878  ; AllocateDoubleStub
    // 0xdd4ce8: mov             x1, x0
    // 0xdd4cec: ldp             x0, x2, [SP], #0x10
    // 0xdd4cf0: ldp             q0, q1, [SP], #0x20
    // 0xdd4cf4: b               #0xdd4b8c
    // 0xdd4cf8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd4cf8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _onExpandCollapse(dynamic) {
    // ** addr: 0xdd4cfc, size: 0x38
    // 0xdd4cfc: EnterFrame
    //     0xdd4cfc: stp             fp, lr, [SP, #-0x10]!
    //     0xdd4d00: mov             fp, SP
    // 0xdd4d04: ldr             x0, [fp, #0x10]
    // 0xdd4d08: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdd4d08: ldur            w1, [x0, #0x17]
    // 0xdd4d0c: DecompressPointer r1
    //     0xdd4d0c: add             x1, x1, HEAP, lsl #32
    // 0xdd4d10: CheckStackOverflow
    //     0xdd4d10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd4d14: cmp             SP, x16
    //     0xdd4d18: b.ls            #0xdd4d2c
    // 0xdd4d1c: r0 = _onExpandCollapse()
    //     0xdd4d1c: bl              #0xdd4d34  ; [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_onExpandCollapse
    // 0xdd4d20: LeaveFrame
    //     0xdd4d20: mov             SP, fp
    //     0xdd4d24: ldp             fp, lr, [SP], #0x10
    // 0xdd4d28: ret
    //     0xdd4d28: ret             
    // 0xdd4d2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd4d2c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd4d30: b               #0xdd4d1c
  }
  _ _onExpandCollapse(/* No info */) {
    // ** addr: 0xdd4d34, size: 0x64
    // 0xdd4d34: EnterFrame
    //     0xdd4d34: stp             fp, lr, [SP, #-0x10]!
    //     0xdd4d38: mov             fp, SP
    // 0xdd4d3c: AllocStack(0x8)
    //     0xdd4d3c: sub             SP, SP, #8
    // 0xdd4d40: SetupParameters(_MaterialControlsState this /* r1 => r1, fp-0x8 */)
    //     0xdd4d40: stur            x1, [fp, #-8]
    // 0xdd4d44: CheckStackOverflow
    //     0xdd4d44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd4d48: cmp             SP, x16
    //     0xdd4d4c: b.ls            #0xdd4d90
    // 0xdd4d50: r1 = 1
    //     0xdd4d50: mov             x1, #1
    // 0xdd4d54: r0 = AllocateContext()
    //     0xdd4d54: bl              #0x13de838  ; AllocateContextStub
    // 0xdd4d58: mov             x1, x0
    // 0xdd4d5c: ldur            x0, [fp, #-8]
    // 0xdd4d60: StoreField: r1->field_f = r0
    //     0xdd4d60: stur            w0, [x1, #0xf]
    // 0xdd4d64: mov             x2, x1
    // 0xdd4d68: r1 = Function '<anonymous closure>':.
    //     0xdd4d68: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3ef8] AnonymousClosure: (0xdd4d98), in [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_onExpandCollapse (0xdd4d34)
    //     0xdd4d6c: ldr             x1, [x1, #0xef8]
    // 0xdd4d70: r0 = AllocateClosure()
    //     0xdd4d70: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd4d74: ldur            x1, [fp, #-8]
    // 0xdd4d78: mov             x2, x0
    // 0xdd4d7c: r0 = setState()
    //     0xdd4d7c: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xdd4d80: r0 = Null
    //     0xdd4d80: mov             x0, NULL
    // 0xdd4d84: LeaveFrame
    //     0xdd4d84: mov             SP, fp
    //     0xdd4d88: ldp             fp, lr, [SP], #0x10
    // 0xdd4d8c: ret
    //     0xdd4d8c: ret             
    // 0xdd4d90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd4d90: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd4d94: b               #0xdd4d50
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xdd4d98, size: 0xe8
    // 0xdd4d98: EnterFrame
    //     0xdd4d98: stp             fp, lr, [SP, #-0x10]!
    //     0xdd4d9c: mov             fp, SP
    // 0xdd4da0: AllocStack(0x10)
    //     0xdd4da0: sub             SP, SP, #0x10
    // 0xdd4da4: SetupParameters([dynamic _ /* r1 */])
    //     0xdd4da4: add             x0, NULL, #0x20  ; true
    //     0xdd4da8: ldr             x1, [fp, #0x10]
    //     0xdd4dac: ldur            w2, [x1, #0x17]
    //     0xdd4db0: add             x2, x2, HEAP, lsl #32
    //     0xdd4db4: stur            x2, [fp, #-8]
    // 0xdd4da4: r0 = true
    // 0xdd4db8: CheckStackOverflow
    //     0xdd4db8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd4dbc: cmp             SP, x16
    //     0xdd4dc0: b.ls            #0xdd4e68
    // 0xdd4dc4: LoadField: r1 = r2->field_f
    //     0xdd4dc4: ldur            w1, [x2, #0xf]
    // 0xdd4dc8: DecompressPointer r1
    //     0xdd4dc8: add             x1, x1, HEAP, lsl #32
    // 0xdd4dcc: LoadField: r3 = r1->field_1b
    //     0xdd4dcc: ldur            w3, [x1, #0x1b]
    // 0xdd4dd0: DecompressPointer r3
    //     0xdd4dd0: add             x3, x3, HEAP, lsl #32
    // 0xdd4dd4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd4dd8: cmp             w3, w16
    // 0xdd4ddc: b.eq            #0xdd4e70
    // 0xdd4de0: StoreField: r3->field_23 = r0
    //     0xdd4de0: stur            w0, [x3, #0x23]
    // 0xdd4de4: mov             x1, x3
    // 0xdd4de8: r0 = notifyListeners()
    //     0xdd4de8: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xdd4dec: ldur            x2, [fp, #-8]
    // 0xdd4df0: LoadField: r0 = r2->field_f
    //     0xdd4df0: ldur            w0, [x2, #0xf]
    // 0xdd4df4: DecompressPointer r0
    //     0xdd4df4: add             x0, x0, HEAP, lsl #32
    // 0xdd4df8: LoadField: r1 = r0->field_5b
    //     0xdd4df8: ldur            w1, [x0, #0x5b]
    // 0xdd4dfc: DecompressPointer r1
    //     0xdd4dfc: add             x1, x1, HEAP, lsl #32
    // 0xdd4e00: cmp             w1, NULL
    // 0xdd4e04: b.eq            #0xdd4e7c
    // 0xdd4e08: r0 = toggleFullScreen()
    //     0xdd4e08: bl              #0xdd30a8  ; [package:chewie/src/chewie_player.dart] ChewieController::toggleFullScreen
    // 0xdd4e0c: ldur            x2, [fp, #-8]
    // 0xdd4e10: LoadField: r0 = r2->field_f
    //     0xdd4e10: ldur            w0, [x2, #0xf]
    // 0xdd4e14: DecompressPointer r0
    //     0xdd4e14: add             x0, x0, HEAP, lsl #32
    // 0xdd4e18: stur            x0, [fp, #-0x10]
    // 0xdd4e1c: r1 = Function '<anonymous closure>':.
    //     0xdd4e1c: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3f00] AnonymousClosure: (0xdd4e80), in [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_onExpandCollapse (0xdd4d34)
    //     0xdd4e20: ldr             x1, [x1, #0xf00]
    // 0xdd4e24: r0 = AllocateClosure()
    //     0xdd4e24: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd4e28: mov             x3, x0
    // 0xdd4e2c: r1 = Null
    //     0xdd4e2c: mov             x1, NULL
    // 0xdd4e30: r2 = Instance_Duration
    //     0xdd4e30: ldr             x2, [PP, #0x7cd8]  ; [pp+0x7cd8] Obj!Duration@12c8971
    // 0xdd4e34: r0 = Timer()
    //     0xdd4e34: bl              #0x7eed74  ; [dart:async] Timer::Timer
    // 0xdd4e38: ldur            x1, [fp, #-0x10]
    // 0xdd4e3c: StoreField: r1->field_33 = r0
    //     0xdd4e3c: stur            w0, [x1, #0x33]
    //     0xdd4e40: ldurb           w16, [x1, #-1]
    //     0xdd4e44: ldurb           w17, [x0, #-1]
    //     0xdd4e48: and             x16, x17, x16, lsr #2
    //     0xdd4e4c: tst             x16, HEAP, lsr #32
    //     0xdd4e50: b.eq            #0xdd4e58
    //     0xdd4e54: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdd4e58: r0 = Null
    //     0xdd4e58: mov             x0, NULL
    // 0xdd4e5c: LeaveFrame
    //     0xdd4e5c: mov             SP, fp
    //     0xdd4e60: ldp             fp, lr, [SP], #0x10
    // 0xdd4e64: ret
    //     0xdd4e64: ret             
    // 0xdd4e68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd4e68: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd4e6c: b               #0xdd4dc4
    // 0xdd4e70: r9 = notifier
    //     0xdd4e70: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3e80] Field <_MaterialControlsState@451269912.notifier>: late (offset: 0x1c)
    //     0xdd4e74: ldr             x9, [x9, #0xe80]
    // 0xdd4e78: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd4e78: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdd4e7c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd4e7c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xdd4e80, size: 0x60
    // 0xdd4e80: EnterFrame
    //     0xdd4e80: stp             fp, lr, [SP, #-0x10]!
    //     0xdd4e84: mov             fp, SP
    // 0xdd4e88: AllocStack(0x8)
    //     0xdd4e88: sub             SP, SP, #8
    // 0xdd4e8c: SetupParameters([dynamic _ /* r0 */])
    //     0xdd4e8c: ldr             x0, [fp, #0x10]
    //     0xdd4e90: ldur            w2, [x0, #0x17]
    //     0xdd4e94: add             x2, x2, HEAP, lsl #32
    // 0xdd4e98: CheckStackOverflow
    //     0xdd4e98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd4e9c: cmp             SP, x16
    //     0xdd4ea0: b.ls            #0xdd4ed8
    // 0xdd4ea4: LoadField: r0 = r2->field_f
    //     0xdd4ea4: ldur            w0, [x2, #0xf]
    // 0xdd4ea8: DecompressPointer r0
    //     0xdd4ea8: add             x0, x0, HEAP, lsl #32
    // 0xdd4eac: stur            x0, [fp, #-8]
    // 0xdd4eb0: r1 = Function '<anonymous closure>':.
    //     0xdd4eb0: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3f08] AnonymousClosure: (0xdd4ee0), in [package:chewie/src/material/material_controls.dart] _MaterialControlsState::build (0xdd39bc)
    //     0xdd4eb4: ldr             x1, [x1, #0xf08]
    // 0xdd4eb8: r0 = AllocateClosure()
    //     0xdd4eb8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd4ebc: ldur            x1, [fp, #-8]
    // 0xdd4ec0: mov             x2, x0
    // 0xdd4ec4: r0 = setState()
    //     0xdd4ec4: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xdd4ec8: r0 = Null
    //     0xdd4ec8: mov             x0, NULL
    // 0xdd4ecc: LeaveFrame
    //     0xdd4ecc: mov             SP, fp
    //     0xdd4ed0: ldp             fp, lr, [SP], #0x10
    // 0xdd4ed4: ret
    //     0xdd4ed4: ret             
    // 0xdd4ed8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd4ed8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd4edc: b               #0xdd4ea4
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xdd4ee0, size: 0x48
    // 0xdd4ee0: EnterFrame
    //     0xdd4ee0: stp             fp, lr, [SP, #-0x10]!
    //     0xdd4ee4: mov             fp, SP
    // 0xdd4ee8: ldr             x0, [fp, #0x10]
    // 0xdd4eec: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdd4eec: ldur            w1, [x0, #0x17]
    // 0xdd4ef0: DecompressPointer r1
    //     0xdd4ef0: add             x1, x1, HEAP, lsl #32
    // 0xdd4ef4: CheckStackOverflow
    //     0xdd4ef4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd4ef8: cmp             SP, x16
    //     0xdd4efc: b.ls            #0xdd4f20
    // 0xdd4f00: LoadField: r0 = r1->field_f
    //     0xdd4f00: ldur            w0, [x1, #0xf]
    // 0xdd4f04: DecompressPointer r0
    //     0xdd4f04: add             x0, x0, HEAP, lsl #32
    // 0xdd4f08: mov             x1, x0
    // 0xdd4f0c: r0 = _cancelAndRestartTimer()
    //     0xdd4f0c: bl              #0xdd4f28  ; [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_cancelAndRestartTimer
    // 0xdd4f10: r0 = Null
    //     0xdd4f10: mov             x0, NULL
    // 0xdd4f14: LeaveFrame
    //     0xdd4f14: mov             SP, fp
    //     0xdd4f18: ldp             fp, lr, [SP], #0x10
    // 0xdd4f1c: ret
    //     0xdd4f1c: ret             
    // 0xdd4f20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd4f20: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd4f24: b               #0xdd4f00
  }
  _ _cancelAndRestartTimer(/* No info */) {
    // ** addr: 0xdd4f28, size: 0x84
    // 0xdd4f28: EnterFrame
    //     0xdd4f28: stp             fp, lr, [SP, #-0x10]!
    //     0xdd4f2c: mov             fp, SP
    // 0xdd4f30: AllocStack(0x10)
    //     0xdd4f30: sub             SP, SP, #0x10
    // 0xdd4f34: SetupParameters(_MaterialControlsState this /* r1 => r1, fp-0x8 */)
    //     0xdd4f34: stur            x1, [fp, #-8]
    // 0xdd4f38: CheckStackOverflow
    //     0xdd4f38: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd4f3c: cmp             SP, x16
    //     0xdd4f40: b.ls            #0xdd4fa4
    // 0xdd4f44: r1 = 1
    //     0xdd4f44: mov             x1, #1
    // 0xdd4f48: r0 = AllocateContext()
    //     0xdd4f48: bl              #0x13de838  ; AllocateContextStub
    // 0xdd4f4c: mov             x2, x0
    // 0xdd4f50: ldur            x0, [fp, #-8]
    // 0xdd4f54: stur            x2, [fp, #-0x10]
    // 0xdd4f58: StoreField: r2->field_f = r0
    //     0xdd4f58: stur            w0, [x2, #0xf]
    // 0xdd4f5c: LoadField: r1 = r0->field_27
    //     0xdd4f5c: ldur            w1, [x0, #0x27]
    // 0xdd4f60: DecompressPointer r1
    //     0xdd4f60: add             x1, x1, HEAP, lsl #32
    // 0xdd4f64: cmp             w1, NULL
    // 0xdd4f68: b.eq            #0xdd4f70
    // 0xdd4f6c: r0 = cancel()
    //     0xdd4f6c: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0xdd4f70: ldur            x1, [fp, #-8]
    // 0xdd4f74: r0 = _startHideTimer()
    //     0xdd4f74: bl              #0xdd4954  ; [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_startHideTimer
    // 0xdd4f78: ldur            x2, [fp, #-0x10]
    // 0xdd4f7c: r1 = Function '<anonymous closure>':.
    //     0xdd4f7c: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3eb8] AnonymousClosure: (0xdd4fac), in [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_cancelAndRestartTimer (0xdd4f28)
    //     0xdd4f80: ldr             x1, [x1, #0xeb8]
    // 0xdd4f84: r0 = AllocateClosure()
    //     0xdd4f84: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd4f88: ldur            x1, [fp, #-8]
    // 0xdd4f8c: mov             x2, x0
    // 0xdd4f90: r0 = setState()
    //     0xdd4f90: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xdd4f94: r0 = Null
    //     0xdd4f94: mov             x0, NULL
    // 0xdd4f98: LeaveFrame
    //     0xdd4f98: mov             SP, fp
    //     0xdd4f9c: ldp             fp, lr, [SP], #0x10
    // 0xdd4fa0: ret
    //     0xdd4fa0: ret             
    // 0xdd4fa4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd4fa4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd4fa8: b               #0xdd4f44
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xdd4fac, size: 0x8c
    // 0xdd4fac: EnterFrame
    //     0xdd4fac: stp             fp, lr, [SP, #-0x10]!
    //     0xdd4fb0: mov             fp, SP
    // 0xdd4fb4: AllocStack(0x8)
    //     0xdd4fb4: sub             SP, SP, #8
    // 0xdd4fb8: SetupParameters([dynamic _ /* r1 */])
    //     0xdd4fb8: add             x0, NULL, #0x30  ; false
    //     0xdd4fbc: ldr             x1, [fp, #0x10]
    //     0xdd4fc0: ldur            w2, [x1, #0x17]
    //     0xdd4fc4: add             x2, x2, HEAP, lsl #32
    //     0xdd4fc8: stur            x2, [fp, #-8]
    // 0xdd4fb8: r0 = false
    // 0xdd4fcc: CheckStackOverflow
    //     0xdd4fcc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd4fd0: cmp             SP, x16
    //     0xdd4fd4: b.ls            #0xdd5024
    // 0xdd4fd8: LoadField: r1 = r2->field_f
    //     0xdd4fd8: ldur            w1, [x2, #0xf]
    // 0xdd4fdc: DecompressPointer r1
    //     0xdd4fdc: add             x1, x1, HEAP, lsl #32
    // 0xdd4fe0: LoadField: r3 = r1->field_1b
    //     0xdd4fe0: ldur            w3, [x1, #0x1b]
    // 0xdd4fe4: DecompressPointer r3
    //     0xdd4fe4: add             x3, x3, HEAP, lsl #32
    // 0xdd4fe8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd4fec: cmp             w3, w16
    // 0xdd4ff0: b.eq            #0xdd502c
    // 0xdd4ff4: StoreField: r3->field_23 = r0
    //     0xdd4ff4: stur            w0, [x3, #0x23]
    // 0xdd4ff8: mov             x1, x3
    // 0xdd4ffc: r0 = notifyListeners()
    //     0xdd4ffc: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xdd5000: ldur            x1, [fp, #-8]
    // 0xdd5004: LoadField: r2 = r1->field_f
    //     0xdd5004: ldur            w2, [x1, #0xf]
    // 0xdd5008: DecompressPointer r2
    //     0xdd5008: add             x2, x2, HEAP, lsl #32
    // 0xdd500c: r1 = true
    //     0xdd500c: add             x1, NULL, #0x20  ; true
    // 0xdd5010: StoreField: r2->field_3b = r1
    //     0xdd5010: stur            w1, [x2, #0x3b]
    // 0xdd5014: r0 = Null
    //     0xdd5014: mov             x0, NULL
    // 0xdd5018: LeaveFrame
    //     0xdd5018: mov             SP, fp
    //     0xdd501c: ldp             fp, lr, [SP], #0x10
    // 0xdd5020: ret
    //     0xdd5020: ret             
    // 0xdd5024: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd5024: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd5028: b               #0xdd4fd8
    // 0xdd502c: r9 = notifier
    //     0xdd502c: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3e80] Field <_MaterialControlsState@451269912.notifier>: late (offset: 0x1c)
    //     0xdd5030: ldr             x9, [x9, #0xe80]
    // 0xdd5034: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd5034: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _buildMuteButton(/* No info */) {
    // ** addr: 0xdd5038, size: 0x204
    // 0xdd5038: EnterFrame
    //     0xdd5038: stp             fp, lr, [SP, #-0x10]!
    //     0xdd503c: mov             fp, SP
    // 0xdd5040: AllocStack(0x48)
    //     0xdd5040: sub             SP, SP, #0x48
    // 0xdd5044: SetupParameters(_MaterialControlsState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xdd5044: stur            x1, [fp, #-8]
    //     0xdd5048: stur            x2, [fp, #-0x10]
    // 0xdd504c: CheckStackOverflow
    //     0xdd504c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd5050: cmp             SP, x16
    //     0xdd5054: b.ls            #0xdd5204
    // 0xdd5058: r1 = 2
    //     0xdd5058: mov             x1, #2
    // 0xdd505c: r0 = AllocateContext()
    //     0xdd505c: bl              #0x13de838  ; AllocateContextStub
    // 0xdd5060: mov             x1, x0
    // 0xdd5064: ldur            x0, [fp, #-8]
    // 0xdd5068: stur            x1, [fp, #-0x18]
    // 0xdd506c: StoreField: r1->field_f = r0
    //     0xdd506c: stur            w0, [x1, #0xf]
    // 0xdd5070: ldur            x2, [fp, #-0x10]
    // 0xdd5074: StoreField: r1->field_13 = r2
    //     0xdd5074: stur            w2, [x1, #0x13]
    // 0xdd5078: LoadField: r2 = r0->field_1b
    //     0xdd5078: ldur            w2, [x0, #0x1b]
    // 0xdd507c: DecompressPointer r2
    //     0xdd507c: add             x2, x2, HEAP, lsl #32
    // 0xdd5080: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd5084: cmp             w2, w16
    // 0xdd5088: b.eq            #0xdd520c
    // 0xdd508c: LoadField: r3 = r2->field_23
    //     0xdd508c: ldur            w3, [x2, #0x23]
    // 0xdd5090: DecompressPointer r3
    //     0xdd5090: add             x3, x3, HEAP, lsl #32
    // 0xdd5094: tbnz            w3, #4, #0xdd50a0
    // 0xdd5098: d1 = 0.000000
    //     0xdd5098: eor             v1.16b, v1.16b, v1.16b
    // 0xdd509c: b               #0xdd50a4
    // 0xdd50a0: d1 = 1.000000
    //     0xdd50a0: fmov            d1, #1.00000000
    // 0xdd50a4: d0 = 0.000000
    //     0xdd50a4: eor             v0.16b, v0.16b, v0.16b
    // 0xdd50a8: stur            d1, [fp, #-0x30]
    // 0xdd50ac: LoadField: d2 = r0->field_47
    //     0xdd50ac: ldur            d2, [x0, #0x47]
    // 0xdd50b0: stur            d2, [fp, #-0x28]
    // 0xdd50b4: LoadField: r2 = r0->field_1f
    //     0xdd50b4: ldur            w2, [x0, #0x1f]
    // 0xdd50b8: DecompressPointer r2
    //     0xdd50b8: add             x2, x2, HEAP, lsl #32
    // 0xdd50bc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd50c0: cmp             w2, w16
    // 0xdd50c4: b.eq            #0xdd5218
    // 0xdd50c8: LoadField: d3 = r2->field_27
    //     0xdd50c8: ldur            d3, [x2, #0x27]
    // 0xdd50cc: fcmp            d3, d0
    // 0xdd50d0: b.le            #0xdd50e0
    // 0xdd50d4: r0 = Instance_IconData
    //     0xdd50d4: add             x0, PP, #0xd3, lsl #12  ; [pp+0xd3e00] Obj!IconData@128a6b1
    //     0xdd50d8: ldr             x0, [x0, #0xe00]
    // 0xdd50dc: b               #0xdd50e8
    // 0xdd50e0: r0 = Instance_IconData
    //     0xdd50e0: add             x0, PP, #0xd3, lsl #12  ; [pp+0xd3e08] Obj!IconData@128a691
    //     0xdd50e4: ldr             x0, [x0, #0xe08]
    // 0xdd50e8: stur            x0, [fp, #-8]
    // 0xdd50ec: r0 = Icon()
    //     0xdd50ec: bl              #0xd0fd5c  ; AllocateIconStub -> Icon (size=0x40)
    // 0xdd50f0: mov             x1, x0
    // 0xdd50f4: ldur            x0, [fp, #-8]
    // 0xdd50f8: stur            x1, [fp, #-0x10]
    // 0xdd50fc: StoreField: r1->field_b = r0
    //     0xdd50fc: stur            w0, [x1, #0xb]
    // 0xdd5100: r0 = Instance_Color
    //     0xdd5100: add             x0, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0xdd5104: ldr             x0, [x0, #0xc38]
    // 0xdd5108: StoreField: r1->field_23 = r0
    //     0xdd5108: stur            w0, [x1, #0x23]
    // 0xdd510c: ldur            d0, [fp, #-0x28]
    // 0xdd5110: r0 = inline_Allocate_Double()
    //     0xdd5110: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xdd5114: add             x0, x0, #0x10
    //     0xdd5118: cmp             x2, x0
    //     0xdd511c: b.ls            #0xdd5224
    //     0xdd5120: str             x0, [THR, #0x60]  ; THR::top
    //     0xdd5124: sub             x0, x0, #0xf
    //     0xdd5128: mov             x2, #0xe19c
    //     0xdd512c: movk            x2, #3, lsl #16
    //     0xdd5130: stur            x2, [x0, #-1]
    // 0xdd5134: dmb             ishst
    // 0xdd5138: StoreField: r0->field_7 = d0
    //     0xdd5138: stur            d0, [x0, #7]
    // 0xdd513c: stur            x0, [fp, #-8]
    // 0xdd5140: r0 = Container()
    //     0xdd5140: bl              #0x8a5af8  ; AllocateContainerStub -> Container (size=0x38)
    // 0xdd5144: stur            x0, [fp, #-0x20]
    // 0xdd5148: ldur            x16, [fp, #-8]
    // 0xdd514c: r30 = Instance_EdgeInsets
    //     0xdd514c: add             lr, PP, #0xd3, lsl #12  ; [pp+0xd3f10] Obj!EdgeInsets@129d3e1
    //     0xdd5150: ldr             lr, [lr, #0xf10]
    // 0xdd5154: stp             lr, x16, [SP, #8]
    // 0xdd5158: ldur            x16, [fp, #-0x10]
    // 0xdd515c: str             x16, [SP]
    // 0xdd5160: mov             x1, x0
    // 0xdd5164: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, height, 0x1, padding, 0x2, null]
    //     0xdd5164: add             x4, PP, #0x91, lsl #12  ; [pp+0x91970] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "height", 0x1, "padding", 0x2, Null]
    //     0xdd5168: ldr             x4, [x4, #0x970]
    // 0xdd516c: r0 = Container()
    //     0xdd516c: bl              #0x8a54e0  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0xdd5170: r0 = ClipRect()
    //     0xdd5170: bl              #0xd5c118  ; AllocateClipRectStub -> ClipRect (size=0x18)
    // 0xdd5174: mov             x1, x0
    // 0xdd5178: r0 = Instance_Clip
    //     0xdd5178: add             x0, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xdd517c: ldr             x0, [x0, #0x850]
    // 0xdd5180: stur            x1, [fp, #-8]
    // 0xdd5184: StoreField: r1->field_13 = r0
    //     0xdd5184: stur            w0, [x1, #0x13]
    // 0xdd5188: ldur            x0, [fp, #-0x20]
    // 0xdd518c: StoreField: r1->field_b = r0
    //     0xdd518c: stur            w0, [x1, #0xb]
    // 0xdd5190: r0 = AnimatedOpacity()
    //     0xdd5190: bl              #0xd2cf50  ; AllocateAnimatedOpacityStub -> AnimatedOpacity (size=0x28)
    // 0xdd5194: mov             x1, x0
    // 0xdd5198: ldur            x0, [fp, #-8]
    // 0xdd519c: stur            x1, [fp, #-0x10]
    // 0xdd51a0: ArrayStore: r1[0] = r0  ; List_4
    //     0xdd51a0: stur            w0, [x1, #0x17]
    // 0xdd51a4: ldur            d0, [fp, #-0x30]
    // 0xdd51a8: StoreField: r1->field_1b = d0
    //     0xdd51a8: stur            d0, [x1, #0x1b]
    // 0xdd51ac: r0 = false
    //     0xdd51ac: add             x0, NULL, #0x30  ; false
    // 0xdd51b0: StoreField: r1->field_23 = r0
    //     0xdd51b0: stur            w0, [x1, #0x23]
    // 0xdd51b4: r0 = Instance__Linear
    //     0xdd51b4: ldr             x0, [PP, #0x5168]  ; [pp+0x5168] Obj!_Linear@129fef1
    // 0xdd51b8: StoreField: r1->field_b = r0
    //     0xdd51b8: stur            w0, [x1, #0xb]
    // 0xdd51bc: r0 = Instance_Duration
    //     0xdd51bc: ldr             x0, [PP, #0x7cd8]  ; [pp+0x7cd8] Obj!Duration@12c8971
    // 0xdd51c0: StoreField: r1->field_f = r0
    //     0xdd51c0: stur            w0, [x1, #0xf]
    // 0xdd51c4: r0 = GestureDetector()
    //     0xdd51c4: bl              #0x918e18  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0xdd51c8: ldur            x2, [fp, #-0x18]
    // 0xdd51cc: r1 = Function '<anonymous closure>':.
    //     0xdd51cc: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3f18] AnonymousClosure: (0xdd523c), in [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_buildMuteButton (0xdd5038)
    //     0xdd51d0: ldr             x1, [x1, #0xf18]
    // 0xdd51d4: stur            x0, [fp, #-8]
    // 0xdd51d8: r0 = AllocateClosure()
    //     0xdd51d8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd51dc: ldur            x16, [fp, #-0x10]
    // 0xdd51e0: stp             x16, x0, [SP]
    // 0xdd51e4: ldur            x1, [fp, #-8]
    // 0xdd51e8: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0xdd51e8: add             x4, PP, #0x16, lsl #12  ; [pp+0x16e90] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0xdd51ec: ldr             x4, [x4, #0xe90]
    // 0xdd51f0: r0 = GestureDetector()
    //     0xdd51f0: bl              #0x9182dc  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0xdd51f4: ldur            x0, [fp, #-8]
    // 0xdd51f8: LeaveFrame
    //     0xdd51f8: mov             SP, fp
    //     0xdd51fc: ldp             fp, lr, [SP], #0x10
    // 0xdd5200: ret
    //     0xdd5200: ret             
    // 0xdd5204: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd5204: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd5208: b               #0xdd5058
    // 0xdd520c: r9 = notifier
    //     0xdd520c: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3e80] Field <_MaterialControlsState@451269912.notifier>: late (offset: 0x1c)
    //     0xdd5210: ldr             x9, [x9, #0xe80]
    // 0xdd5214: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd5214: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdd5218: r9 = _latestValue
    //     0xdd5218: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3eb0] Field <_MaterialControlsState@451269912._latestValue@451269912>: late (offset: 0x20)
    //     0xdd521c: ldr             x9, [x9, #0xeb0]
    // 0xdd5220: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xdd5220: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xdd5224: SaveReg d0
    //     0xdd5224: str             q0, [SP, #-0x10]!
    // 0xdd5228: SaveReg r1
    //     0xdd5228: str             x1, [SP, #-8]!
    // 0xdd522c: r0 = AllocateDouble()
    //     0xdd522c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xdd5230: RestoreReg r1
    //     0xdd5230: ldr             x1, [SP], #8
    // 0xdd5234: RestoreReg d0
    //     0xdd5234: ldr             q0, [SP], #0x10
    // 0xdd5238: b               #0xdd5138
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xdd523c, size: 0x138
    // 0xdd523c: EnterFrame
    //     0xdd523c: stp             fp, lr, [SP, #-0x10]!
    //     0xdd5240: mov             fp, SP
    // 0xdd5244: AllocStack(0x8)
    //     0xdd5244: sub             SP, SP, #8
    // 0xdd5248: SetupParameters([dynamic _ /* r0 */])
    //     0xdd5248: ldr             x0, [fp, #0x10]
    //     0xdd524c: ldur            w2, [x0, #0x17]
    //     0xdd5250: add             x2, x2, HEAP, lsl #32
    //     0xdd5254: stur            x2, [fp, #-8]
    // 0xdd5258: CheckStackOverflow
    //     0xdd5258: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd525c: cmp             SP, x16
    //     0xdd5260: b.ls            #0xdd5348
    // 0xdd5264: LoadField: r1 = r2->field_f
    //     0xdd5264: ldur            w1, [x2, #0xf]
    // 0xdd5268: DecompressPointer r1
    //     0xdd5268: add             x1, x1, HEAP, lsl #32
    // 0xdd526c: r0 = _cancelAndRestartTimer()
    //     0xdd526c: bl              #0xdd4f28  ; [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_cancelAndRestartTimer
    // 0xdd5270: ldur            x0, [fp, #-8]
    // 0xdd5274: LoadField: r1 = r0->field_f
    //     0xdd5274: ldur            w1, [x0, #0xf]
    // 0xdd5278: DecompressPointer r1
    //     0xdd5278: add             x1, x1, HEAP, lsl #32
    // 0xdd527c: LoadField: r2 = r1->field_1f
    //     0xdd527c: ldur            w2, [x1, #0x1f]
    // 0xdd5280: DecompressPointer r2
    //     0xdd5280: add             x2, x2, HEAP, lsl #32
    // 0xdd5284: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd5288: cmp             w2, w16
    // 0xdd528c: b.eq            #0xdd5350
    // 0xdd5290: LoadField: d0 = r2->field_27
    //     0xdd5290: ldur            d0, [x2, #0x27]
    // 0xdd5294: d1 = 0.000000
    //     0xdd5294: eor             v1.16b, v1.16b, v1.16b
    // 0xdd5298: fcmp            d0, d1
    // 0xdd529c: b.ne            #0xdd52d0
    // 0xdd52a0: LoadField: r2 = r0->field_13
    //     0xdd52a0: ldur            w2, [x0, #0x13]
    // 0xdd52a4: DecompressPointer r2
    //     0xdd52a4: add             x2, x2, HEAP, lsl #32
    // 0xdd52a8: LoadField: r0 = r1->field_23
    //     0xdd52a8: ldur            w0, [x1, #0x23]
    // 0xdd52ac: DecompressPointer r0
    //     0xdd52ac: add             x0, x0, HEAP, lsl #32
    // 0xdd52b0: cmp             w0, NULL
    // 0xdd52b4: b.ne            #0xdd52c0
    // 0xdd52b8: d0 = 0.500000
    //     0xdd52b8: fmov            d0, #0.50000000
    // 0xdd52bc: b               #0xdd52c4
    // 0xdd52c0: LoadField: d0 = r0->field_7
    //     0xdd52c0: ldur            d0, [x0, #7]
    // 0xdd52c4: mov             x1, x2
    // 0xdd52c8: r0 = setVolume()
    //     0xdd52c8: bl              #0xdd2b84  ; [package:video_player/video_player.dart] VideoPlayerController::setVolume
    // 0xdd52cc: b               #0xdd5338
    // 0xdd52d0: LoadField: r2 = r0->field_13
    //     0xdd52d0: ldur            w2, [x0, #0x13]
    // 0xdd52d4: DecompressPointer r2
    //     0xdd52d4: add             x2, x2, HEAP, lsl #32
    // 0xdd52d8: LoadField: r0 = r2->field_27
    //     0xdd52d8: ldur            w0, [x2, #0x27]
    // 0xdd52dc: DecompressPointer r0
    //     0xdd52dc: add             x0, x0, HEAP, lsl #32
    // 0xdd52e0: LoadField: d0 = r0->field_27
    //     0xdd52e0: ldur            d0, [x0, #0x27]
    // 0xdd52e4: r0 = inline_Allocate_Double()
    //     0xdd52e4: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0xdd52e8: add             x0, x0, #0x10
    //     0xdd52ec: cmp             x3, x0
    //     0xdd52f0: b.ls            #0xdd535c
    //     0xdd52f4: str             x0, [THR, #0x60]  ; THR::top
    //     0xdd52f8: sub             x0, x0, #0xf
    //     0xdd52fc: mov             x3, #0xe19c
    //     0xdd5300: movk            x3, #3, lsl #16
    //     0xdd5304: stur            x3, [x0, #-1]
    // 0xdd5308: dmb             ishst
    // 0xdd530c: StoreField: r0->field_7 = d0
    //     0xdd530c: stur            d0, [x0, #7]
    // 0xdd5310: StoreField: r1->field_23 = r0
    //     0xdd5310: stur            w0, [x1, #0x23]
    //     0xdd5314: ldurb           w16, [x1, #-1]
    //     0xdd5318: ldurb           w17, [x0, #-1]
    //     0xdd531c: and             x16, x17, x16, lsr #2
    //     0xdd5320: tst             x16, HEAP, lsr #32
    //     0xdd5324: b.eq            #0xdd532c
    //     0xdd5328: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdd532c: mov             x1, x2
    // 0xdd5330: mov             v0.16b, v1.16b
    // 0xdd5334: r0 = setVolume()
    //     0xdd5334: bl              #0xdd2b84  ; [package:video_player/video_player.dart] VideoPlayerController::setVolume
    // 0xdd5338: r0 = Null
    //     0xdd5338: mov             x0, NULL
    // 0xdd533c: LeaveFrame
    //     0xdd533c: mov             SP, fp
    //     0xdd5340: ldp             fp, lr, [SP], #0x10
    // 0xdd5344: ret
    //     0xdd5344: ret             
    // 0xdd5348: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd5348: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd534c: b               #0xdd5264
    // 0xdd5350: r9 = _latestValue
    //     0xdd5350: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3eb0] Field <_MaterialControlsState@451269912._latestValue@451269912>: late (offset: 0x20)
    //     0xdd5354: ldr             x9, [x9, #0xeb0]
    // 0xdd5358: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd5358: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdd535c: stp             q0, q1, [SP, #-0x20]!
    // 0xdd5360: stp             x1, x2, [SP, #-0x10]!
    // 0xdd5364: r0 = AllocateDouble()
    //     0xdd5364: bl              #0x13df878  ; AllocateDoubleStub
    // 0xdd5368: ldp             x1, x2, [SP], #0x10
    // 0xdd536c: ldp             q0, q1, [SP], #0x20
    // 0xdd5370: b               #0xdd530c
  }
  _ _buildPosition(/* No info */) {
    // ** addr: 0xdd5374, size: 0x1f8
    // 0xdd5374: EnterFrame
    //     0xdd5374: stp             fp, lr, [SP, #-0x10]!
    //     0xdd5378: mov             fp, SP
    // 0xdd537c: AllocStack(0x28)
    //     0xdd537c: sub             SP, SP, #0x28
    // 0xdd5380: CheckStackOverflow
    //     0xdd5380: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd5384: cmp             SP, x16
    //     0xdd5388: b.ls            #0xdd5558
    // 0xdd538c: LoadField: r0 = r1->field_1f
    //     0xdd538c: ldur            w0, [x1, #0x1f]
    // 0xdd5390: DecompressPointer r0
    //     0xdd5390: add             x0, x0, HEAP, lsl #32
    // 0xdd5394: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd5398: cmp             w0, w16
    // 0xdd539c: b.eq            #0xdd5560
    // 0xdd53a0: LoadField: r1 = r0->field_b
    //     0xdd53a0: ldur            w1, [x0, #0xb]
    // 0xdd53a4: DecompressPointer r1
    //     0xdd53a4: add             x1, x1, HEAP, lsl #32
    // 0xdd53a8: LoadField: r2 = r0->field_7
    //     0xdd53a8: ldur            w2, [x0, #7]
    // 0xdd53ac: DecompressPointer r2
    //     0xdd53ac: add             x2, x2, HEAP, lsl #32
    // 0xdd53b0: stur            x2, [fp, #-8]
    // 0xdd53b4: r0 = formatDuration()
    //     0xdd53b4: bl              #0xdcf474  ; [package:chewie/src/helpers/utils.dart] ::formatDuration
    // 0xdd53b8: r1 = Null
    //     0xdd53b8: mov             x1, NULL
    // 0xdd53bc: r2 = 4
    //     0xdd53bc: mov             x2, #4
    // 0xdd53c0: stur            x0, [fp, #-0x10]
    // 0xdd53c4: r0 = AllocateArray()
    //     0xdd53c4: bl              #0x13df928  ; AllocateArrayStub
    // 0xdd53c8: mov             x1, x0
    // 0xdd53cc: ldur            x0, [fp, #-0x10]
    // 0xdd53d0: StoreField: r1->field_f = r0
    //     0xdd53d0: stur            w0, [x1, #0xf]
    // 0xdd53d4: r16 = " "
    //     0xdd53d4: ldr             x16, [PP, #0x8f8]  ; [pp+0x8f8] " "
    // 0xdd53d8: StoreField: r1->field_13 = r16
    //     0xdd53d8: stur            w16, [x1, #0x13]
    // 0xdd53dc: str             x1, [SP]
    // 0xdd53e0: r0 = _interpolate()
    //     0xdd53e0: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xdd53e4: r1 = Null
    //     0xdd53e4: mov             x1, NULL
    // 0xdd53e8: r2 = 4
    //     0xdd53e8: mov             x2, #4
    // 0xdd53ec: stur            x0, [fp, #-0x10]
    // 0xdd53f0: r0 = AllocateArray()
    //     0xdd53f0: bl              #0x13df928  ; AllocateArrayStub
    // 0xdd53f4: stur            x0, [fp, #-0x18]
    // 0xdd53f8: r16 = "/ "
    //     0xdd53f8: add             x16, PP, #0x9f, lsl #12  ; [pp+0x9f830] "/ "
    //     0xdd53fc: ldr             x16, [x16, #0x830]
    // 0xdd5400: StoreField: r0->field_f = r16
    //     0xdd5400: stur            w16, [x0, #0xf]
    // 0xdd5404: ldur            x1, [fp, #-8]
    // 0xdd5408: r0 = formatDuration()
    //     0xdd5408: bl              #0xdcf474  ; [package:chewie/src/helpers/utils.dart] ::formatDuration
    // 0xdd540c: ldur            x1, [fp, #-0x18]
    // 0xdd5410: ArrayStore: r1[1] = r0  ; List_4
    //     0xdd5410: add             x25, x1, #0x13
    //     0xdd5414: str             w0, [x25]
    //     0xdd5418: tbz             w0, #0, #0xdd5434
    //     0xdd541c: ldurb           w16, [x1, #-1]
    //     0xdd5420: ldurb           w17, [x0, #-1]
    //     0xdd5424: and             x16, x17, x16, lsr #2
    //     0xdd5428: tst             x16, HEAP, lsr #32
    //     0xdd542c: b.eq            #0xdd5434
    //     0xdd5430: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdd5434: ldur            x16, [fp, #-0x18]
    // 0xdd5438: str             x16, [SP]
    // 0xdd543c: r0 = _interpolate()
    //     0xdd543c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xdd5440: stur            x0, [fp, #-8]
    // 0xdd5444: r16 = 0.750000
    //     0xdd5444: add             x16, PP, #0x8e, lsl #12  ; [pp+0x8e168] 0.75
    //     0xdd5448: ldr             x16, [x16, #0x168]
    // 0xdd544c: str             x16, [SP]
    // 0xdd5450: r1 = Instance_Color
    //     0xdd5450: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0xdd5454: ldr             x1, [x1, #0xc38]
    // 0xdd5458: r4 = const [0, 0x2, 0x1, 0x1, alpha, 0x1, null]
    //     0xdd5458: add             x4, PP, #0x28, lsl #12  ; [pp+0x28640] List(7) [0, 0x2, 0x1, 0x1, "alpha", 0x1, Null]
    //     0xdd545c: ldr             x4, [x4, #0x640]
    // 0xdd5460: r0 = withValues()
    //     0xdd5460: bl              #0x12d8818  ; [dart:ui] Color::withValues
    // 0xdd5464: stur            x0, [fp, #-0x18]
    // 0xdd5468: r0 = TextStyle()
    //     0xdd5468: bl              #0x8a68f4  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0xdd546c: mov             x1, x0
    // 0xdd5470: r0 = true
    //     0xdd5470: add             x0, NULL, #0x20  ; true
    // 0xdd5474: stur            x1, [fp, #-0x20]
    // 0xdd5478: StoreField: r1->field_7 = r0
    //     0xdd5478: stur            w0, [x1, #7]
    // 0xdd547c: ldur            x0, [fp, #-0x18]
    // 0xdd5480: StoreField: r1->field_b = r0
    //     0xdd5480: stur            w0, [x1, #0xb]
    // 0xdd5484: r0 = 14.000000
    //     0xdd5484: add             x0, PP, #0x16, lsl #12  ; [pp+0x16d30] 14
    //     0xdd5488: ldr             x0, [x0, #0xd30]
    // 0xdd548c: StoreField: r1->field_1f = r0
    //     0xdd548c: stur            w0, [x1, #0x1f]
    // 0xdd5490: r0 = Instance_FontWeight
    //     0xdd5490: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f40] Obj!FontWeight@12a0571
    //     0xdd5494: ldr             x0, [x0, #0xf40]
    // 0xdd5498: StoreField: r1->field_23 = r0
    //     0xdd5498: stur            w0, [x1, #0x23]
    // 0xdd549c: r0 = TextSpan()
    //     0xdd549c: bl              #0xb57880  ; AllocateTextSpanStub -> TextSpan (size=0x34)
    // 0xdd54a0: mov             x3, x0
    // 0xdd54a4: ldur            x0, [fp, #-8]
    // 0xdd54a8: stur            x3, [fp, #-0x18]
    // 0xdd54ac: StoreField: r3->field_b = r0
    //     0xdd54ac: stur            w0, [x3, #0xb]
    // 0xdd54b0: r0 = Instance__DeferringMouseCursor
    //     0xdd54b0: ldr             x0, [PP, #0x2208]  ; [pp+0x2208] Obj!_DeferringMouseCursor@12b3241
    // 0xdd54b4: ArrayStore: r3[0] = r0  ; List_4
    //     0xdd54b4: stur            w0, [x3, #0x17]
    // 0xdd54b8: ldur            x1, [fp, #-0x20]
    // 0xdd54bc: StoreField: r3->field_7 = r1
    //     0xdd54bc: stur            w1, [x3, #7]
    // 0xdd54c0: r1 = Null
    //     0xdd54c0: mov             x1, NULL
    // 0xdd54c4: r2 = 2
    //     0xdd54c4: mov             x2, #2
    // 0xdd54c8: r0 = AllocateArray()
    //     0xdd54c8: bl              #0x13df928  ; AllocateArrayStub
    // 0xdd54cc: mov             x2, x0
    // 0xdd54d0: ldur            x0, [fp, #-0x18]
    // 0xdd54d4: stur            x2, [fp, #-8]
    // 0xdd54d8: StoreField: r2->field_f = r0
    //     0xdd54d8: stur            w0, [x2, #0xf]
    // 0xdd54dc: r1 = <InlineSpan>
    //     0xdd54dc: add             x1, PP, #0x7a, lsl #12  ; [pp+0x7aa80] TypeArguments: <InlineSpan>
    //     0xdd54e0: ldr             x1, [x1, #0xa80]
    // 0xdd54e4: r0 = AllocateGrowableArray()
    //     0xdd54e4: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xdd54e8: mov             x1, x0
    // 0xdd54ec: ldur            x0, [fp, #-8]
    // 0xdd54f0: stur            x1, [fp, #-0x18]
    // 0xdd54f4: StoreField: r1->field_f = r0
    //     0xdd54f4: stur            w0, [x1, #0xf]
    // 0xdd54f8: r0 = 2
    //     0xdd54f8: mov             x0, #2
    // 0xdd54fc: StoreField: r1->field_b = r0
    //     0xdd54fc: stur            w0, [x1, #0xb]
    // 0xdd5500: r0 = TextSpan()
    //     0xdd5500: bl              #0xb57880  ; AllocateTextSpanStub -> TextSpan (size=0x34)
    // 0xdd5504: mov             x1, x0
    // 0xdd5508: ldur            x0, [fp, #-0x10]
    // 0xdd550c: stur            x1, [fp, #-8]
    // 0xdd5510: StoreField: r1->field_b = r0
    //     0xdd5510: stur            w0, [x1, #0xb]
    // 0xdd5514: ldur            x0, [fp, #-0x18]
    // 0xdd5518: StoreField: r1->field_f = r0
    //     0xdd5518: stur            w0, [x1, #0xf]
    // 0xdd551c: r0 = Instance__DeferringMouseCursor
    //     0xdd551c: ldr             x0, [PP, #0x2208]  ; [pp+0x2208] Obj!_DeferringMouseCursor@12b3241
    // 0xdd5520: ArrayStore: r1[0] = r0  ; List_4
    //     0xdd5520: stur            w0, [x1, #0x17]
    // 0xdd5524: r0 = Instance_TextStyle
    //     0xdd5524: add             x0, PP, #0x87, lsl #12  ; [pp+0x87ae0] Obj!TextStyle@12b0b61
    //     0xdd5528: ldr             x0, [x0, #0xae0]
    // 0xdd552c: StoreField: r1->field_7 = r0
    //     0xdd552c: stur            w0, [x1, #7]
    // 0xdd5530: r0 = RichText()
    //     0xdd5530: bl              #0xdd59a0  ; AllocateRichTextStub -> RichText (size=0x44)
    // 0xdd5534: mov             x1, x0
    // 0xdd5538: ldur            x2, [fp, #-8]
    // 0xdd553c: stur            x0, [fp, #-8]
    // 0xdd5540: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xdd5540: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xdd5544: r0 = RichText()
    //     0xdd5544: bl              #0xdd556c  ; [package:flutter/src/widgets/basic.dart] RichText::RichText
    // 0xdd5548: ldur            x0, [fp, #-8]
    // 0xdd554c: LeaveFrame
    //     0xdd554c: mov             SP, fp
    //     0xdd5550: ldp             fp, lr, [SP], #0x10
    // 0xdd5554: ret
    //     0xdd5554: ret             
    // 0xdd5558: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd5558: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd555c: b               #0xdd538c
    // 0xdd5560: r9 = _latestValue
    //     0xdd5560: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3eb0] Field <_MaterialControlsState@451269912._latestValue@451269912>: late (offset: 0x20)
    //     0xdd5564: ldr             x9, [x9, #0xeb0]
    // 0xdd5568: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd5568: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _buildActionBar(/* No info */) {
    // ** addr: 0xdd59ac, size: 0x23c
    // 0xdd59ac: EnterFrame
    //     0xdd59ac: stp             fp, lr, [SP, #-0x10]!
    //     0xdd59b0: mov             fp, SP
    // 0xdd59b4: AllocStack(0x28)
    //     0xdd59b4: sub             SP, SP, #0x28
    // 0xdd59b8: SetupParameters(_MaterialControlsState this /* r1 => r0, fp-0x8 */)
    //     0xdd59b8: mov             x0, x1
    //     0xdd59bc: stur            x1, [fp, #-8]
    // 0xdd59c0: CheckStackOverflow
    //     0xdd59c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd59c4: cmp             SP, x16
    //     0xdd59c8: b.ls            #0xdd5bd0
    // 0xdd59cc: LoadField: r1 = r0->field_1b
    //     0xdd59cc: ldur            w1, [x0, #0x1b]
    // 0xdd59d0: DecompressPointer r1
    //     0xdd59d0: add             x1, x1, HEAP, lsl #32
    // 0xdd59d4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd59d8: cmp             w1, w16
    // 0xdd59dc: b.eq            #0xdd5bd8
    // 0xdd59e0: LoadField: r2 = r1->field_23
    //     0xdd59e0: ldur            w2, [x1, #0x23]
    // 0xdd59e4: DecompressPointer r2
    //     0xdd59e4: add             x2, x2, HEAP, lsl #32
    // 0xdd59e8: tbnz            w2, #4, #0xdd59f4
    // 0xdd59ec: d0 = 0.000000
    //     0xdd59ec: eor             v0.16b, v0.16b, v0.16b
    // 0xdd59f0: b               #0xdd59f8
    // 0xdd59f4: d0 = 1.000000
    //     0xdd59f4: fmov            d0, #1.00000000
    // 0xdd59f8: r3 = 2
    //     0xdd59f8: mov             x3, #2
    // 0xdd59fc: stur            d0, [fp, #-0x28]
    // 0xdd5a00: LoadField: r1 = r0->field_5b
    //     0xdd5a00: ldur            w1, [x0, #0x5b]
    // 0xdd5a04: DecompressPointer r1
    //     0xdd5a04: add             x1, x1, HEAP, lsl #32
    // 0xdd5a08: cmp             w1, NULL
    // 0xdd5a0c: b.eq            #0xdd5be4
    // 0xdd5a10: mov             x2, x3
    // 0xdd5a14: r1 = Null
    //     0xdd5a14: mov             x1, NULL
    // 0xdd5a18: r0 = AllocateArray()
    //     0xdd5a18: bl              #0x13df928  ; AllocateArrayStub
    // 0xdd5a1c: stur            x0, [fp, #-0x10]
    // 0xdd5a20: r16 = Instance_SizedBox
    //     0xdd5a20: add             x16, PP, #0x13, lsl #12  ; [pp+0x13db8] Obj!SizedBox@12b7241
    //     0xdd5a24: ldr             x16, [x16, #0xdb8]
    // 0xdd5a28: StoreField: r0->field_f = r16
    //     0xdd5a28: stur            w16, [x0, #0xf]
    // 0xdd5a2c: r1 = <Widget>
    //     0xdd5a2c: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xdd5a30: r0 = AllocateGrowableArray()
    //     0xdd5a30: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xdd5a34: mov             x2, x0
    // 0xdd5a38: ldur            x0, [fp, #-0x10]
    // 0xdd5a3c: stur            x2, [fp, #-0x18]
    // 0xdd5a40: StoreField: r2->field_f = r0
    //     0xdd5a40: stur            w0, [x2, #0xf]
    // 0xdd5a44: r0 = 2
    //     0xdd5a44: mov             x0, #2
    // 0xdd5a48: StoreField: r2->field_b = r0
    //     0xdd5a48: stur            w0, [x2, #0xb]
    // 0xdd5a4c: ldur            x1, [fp, #-8]
    // 0xdd5a50: r0 = _buildOptionsButton()
    //     0xdd5a50: bl              #0xdd5be8  ; [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_buildOptionsButton
    // 0xdd5a54: mov             x2, x0
    // 0xdd5a58: ldur            x0, [fp, #-0x18]
    // 0xdd5a5c: stur            x2, [fp, #-8]
    // 0xdd5a60: LoadField: r1 = r0->field_b
    //     0xdd5a60: ldur            w1, [x0, #0xb]
    // 0xdd5a64: LoadField: r3 = r0->field_f
    //     0xdd5a64: ldur            w3, [x0, #0xf]
    // 0xdd5a68: DecompressPointer r3
    //     0xdd5a68: add             x3, x3, HEAP, lsl #32
    // 0xdd5a6c: LoadField: r4 = r3->field_b
    //     0xdd5a6c: ldur            w4, [x3, #0xb]
    // 0xdd5a70: r3 = LoadInt32Instr(r1)
    //     0xdd5a70: sbfx            x3, x1, #1, #0x1f
    // 0xdd5a74: stur            x3, [fp, #-0x20]
    // 0xdd5a78: r1 = LoadInt32Instr(r4)
    //     0xdd5a78: sbfx            x1, x4, #1, #0x1f
    // 0xdd5a7c: cmp             x3, x1
    // 0xdd5a80: b.ne            #0xdd5a8c
    // 0xdd5a84: mov             x1, x0
    // 0xdd5a88: r0 = _growToNextCapacity()
    //     0xdd5a88: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xdd5a8c: ldur            d0, [fp, #-0x28]
    // 0xdd5a90: ldur            x2, [fp, #-0x18]
    // 0xdd5a94: ldur            x3, [fp, #-0x20]
    // 0xdd5a98: add             x0, x3, #1
    // 0xdd5a9c: lsl             x1, x0, #1
    // 0xdd5aa0: StoreField: r2->field_b = r1
    //     0xdd5aa0: stur            w1, [x2, #0xb]
    // 0xdd5aa4: LoadField: r1 = r2->field_f
    //     0xdd5aa4: ldur            w1, [x2, #0xf]
    // 0xdd5aa8: DecompressPointer r1
    //     0xdd5aa8: add             x1, x1, HEAP, lsl #32
    // 0xdd5aac: ldur            x0, [fp, #-8]
    // 0xdd5ab0: ArrayStore: r1[r3] = r0  ; List_4
    //     0xdd5ab0: add             x25, x1, x3, lsl #2
    //     0xdd5ab4: add             x25, x25, #0xf
    //     0xdd5ab8: str             w0, [x25]
    //     0xdd5abc: tbz             w0, #0, #0xdd5ad8
    //     0xdd5ac0: ldurb           w16, [x1, #-1]
    //     0xdd5ac4: ldurb           w17, [x0, #-1]
    //     0xdd5ac8: and             x16, x17, x16, lsr #2
    //     0xdd5acc: tst             x16, HEAP, lsr #32
    //     0xdd5ad0: b.eq            #0xdd5ad8
    //     0xdd5ad4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdd5ad8: r0 = Row()
    //     0xdd5ad8: bl              #0x8a5b04  ; AllocateRowStub -> Row (size=0x38)
    // 0xdd5adc: mov             x1, x0
    // 0xdd5ae0: r0 = Instance_Axis
    //     0xdd5ae0: ldr             x0, [PP, #0x49c8]  ; [pp+0x49c8] Obj!Axis@12c4a61
    // 0xdd5ae4: stur            x1, [fp, #-8]
    // 0xdd5ae8: StoreField: r1->field_f = r0
    //     0xdd5ae8: stur            w0, [x1, #0xf]
    // 0xdd5aec: r0 = Instance_MainAxisAlignment
    //     0xdd5aec: add             x0, PP, #0x15, lsl #12  ; [pp+0x15820] Obj!MainAxisAlignment@12c4541
    //     0xdd5af0: ldr             x0, [x0, #0x820]
    // 0xdd5af4: StoreField: r1->field_13 = r0
    //     0xdd5af4: stur            w0, [x1, #0x13]
    // 0xdd5af8: r0 = Instance_MainAxisSize
    //     0xdd5af8: add             x0, PP, #0x15, lsl #12  ; [pp+0x15828] Obj!MainAxisSize@12c4621
    //     0xdd5afc: ldr             x0, [x0, #0x828]
    // 0xdd5b00: ArrayStore: r1[0] = r0  ; List_4
    //     0xdd5b00: stur            w0, [x1, #0x17]
    // 0xdd5b04: r0 = Instance_CrossAxisAlignment
    //     0xdd5b04: add             x0, PP, #0x15, lsl #12  ; [pp+0x15888] Obj!CrossAxisAlignment@12c44a1
    //     0xdd5b08: ldr             x0, [x0, #0x888]
    // 0xdd5b0c: StoreField: r1->field_1b = r0
    //     0xdd5b0c: stur            w0, [x1, #0x1b]
    // 0xdd5b10: r0 = Instance_VerticalDirection
    //     0xdd5b10: add             x0, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xdd5b14: ldr             x0, [x0, #0x838]
    // 0xdd5b18: StoreField: r1->field_23 = r0
    //     0xdd5b18: stur            w0, [x1, #0x23]
    // 0xdd5b1c: r0 = Instance_Clip
    //     0xdd5b1c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xdd5b20: ldr             x0, [x0, #0x840]
    // 0xdd5b24: StoreField: r1->field_2b = r0
    //     0xdd5b24: stur            w0, [x1, #0x2b]
    // 0xdd5b28: StoreField: r1->field_2f = rZR
    //     0xdd5b28: stur            xzr, [x1, #0x2f]
    // 0xdd5b2c: ldur            x0, [fp, #-0x18]
    // 0xdd5b30: StoreField: r1->field_b = r0
    //     0xdd5b30: stur            w0, [x1, #0xb]
    // 0xdd5b34: r0 = AnimatedOpacity()
    //     0xdd5b34: bl              #0xd2cf50  ; AllocateAnimatedOpacityStub -> AnimatedOpacity (size=0x28)
    // 0xdd5b38: mov             x1, x0
    // 0xdd5b3c: ldur            x0, [fp, #-8]
    // 0xdd5b40: stur            x1, [fp, #-0x10]
    // 0xdd5b44: ArrayStore: r1[0] = r0  ; List_4
    //     0xdd5b44: stur            w0, [x1, #0x17]
    // 0xdd5b48: ldur            d0, [fp, #-0x28]
    // 0xdd5b4c: StoreField: r1->field_1b = d0
    //     0xdd5b4c: stur            d0, [x1, #0x1b]
    // 0xdd5b50: r0 = false
    //     0xdd5b50: add             x0, NULL, #0x30  ; false
    // 0xdd5b54: StoreField: r1->field_23 = r0
    //     0xdd5b54: stur            w0, [x1, #0x23]
    // 0xdd5b58: r2 = Instance__Linear
    //     0xdd5b58: ldr             x2, [PP, #0x5168]  ; [pp+0x5168] Obj!_Linear@129fef1
    // 0xdd5b5c: StoreField: r1->field_b = r2
    //     0xdd5b5c: stur            w2, [x1, #0xb]
    // 0xdd5b60: r2 = Instance_Duration
    //     0xdd5b60: add             x2, PP, #0xc, lsl #12  ; [pp+0xc920] Obj!Duration@12c89c1
    //     0xdd5b64: ldr             x2, [x2, #0x920]
    // 0xdd5b68: StoreField: r1->field_f = r2
    //     0xdd5b68: stur            w2, [x1, #0xf]
    // 0xdd5b6c: r0 = SafeArea()
    //     0xdd5b6c: bl              #0xd73100  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0xdd5b70: mov             x2, x0
    // 0xdd5b74: r0 = true
    //     0xdd5b74: add             x0, NULL, #0x20  ; true
    // 0xdd5b78: stur            x2, [fp, #-8]
    // 0xdd5b7c: StoreField: r2->field_b = r0
    //     0xdd5b7c: stur            w0, [x2, #0xb]
    // 0xdd5b80: StoreField: r2->field_f = r0
    //     0xdd5b80: stur            w0, [x2, #0xf]
    // 0xdd5b84: StoreField: r2->field_13 = r0
    //     0xdd5b84: stur            w0, [x2, #0x13]
    // 0xdd5b88: ArrayStore: r2[0] = r0  ; List_4
    //     0xdd5b88: stur            w0, [x2, #0x17]
    // 0xdd5b8c: r0 = Instance_EdgeInsets
    //     0xdd5b8c: ldr             x0, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0xdd5b90: StoreField: r2->field_1b = r0
    //     0xdd5b90: stur            w0, [x2, #0x1b]
    // 0xdd5b94: r0 = false
    //     0xdd5b94: add             x0, NULL, #0x30  ; false
    // 0xdd5b98: StoreField: r2->field_1f = r0
    //     0xdd5b98: stur            w0, [x2, #0x1f]
    // 0xdd5b9c: ldur            x0, [fp, #-0x10]
    // 0xdd5ba0: StoreField: r2->field_23 = r0
    //     0xdd5ba0: stur            w0, [x2, #0x23]
    // 0xdd5ba4: r1 = <StackParentData>
    //     0xdd5ba4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15858] TypeArguments: <StackParentData>
    //     0xdd5ba8: ldr             x1, [x1, #0x858]
    // 0xdd5bac: r0 = Positioned()
    //     0xdd5bac: bl              #0x8a54a4  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0xdd5bb0: r1 = 0.000000
    //     0xdd5bb0: ldr             x1, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xdd5bb4: ArrayStore: r0[0] = r1  ; List_4
    //     0xdd5bb4: stur            w1, [x0, #0x17]
    // 0xdd5bb8: StoreField: r0->field_1b = r1
    //     0xdd5bb8: stur            w1, [x0, #0x1b]
    // 0xdd5bbc: ldur            x1, [fp, #-8]
    // 0xdd5bc0: StoreField: r0->field_b = r1
    //     0xdd5bc0: stur            w1, [x0, #0xb]
    // 0xdd5bc4: LeaveFrame
    //     0xdd5bc4: mov             SP, fp
    //     0xdd5bc8: ldp             fp, lr, [SP], #0x10
    // 0xdd5bcc: ret
    //     0xdd5bcc: ret             
    // 0xdd5bd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd5bd0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd5bd4: b               #0xdd59cc
    // 0xdd5bd8: r9 = notifier
    //     0xdd5bd8: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3e80] Field <_MaterialControlsState@451269912.notifier>: late (offset: 0x1c)
    //     0xdd5bdc: ldr             x9, [x9, #0xe80]
    // 0xdd5be0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd5be0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdd5be4: r0 = NullCastErrorSharedWithFPURegs()
    //     0xdd5be4: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  _ _buildOptionsButton(/* No info */) {
    // ** addr: 0xdd5be8, size: 0xe4
    // 0xdd5be8: EnterFrame
    //     0xdd5be8: stp             fp, lr, [SP, #-0x10]!
    //     0xdd5bec: mov             fp, SP
    // 0xdd5bf0: AllocStack(0x18)
    //     0xdd5bf0: sub             SP, SP, #0x18
    // 0xdd5bf4: SetupParameters(_MaterialControlsState this /* r1 => r1, fp-0x8 */)
    //     0xdd5bf4: stur            x1, [fp, #-8]
    // 0xdd5bf8: r1 = 1
    //     0xdd5bf8: mov             x1, #1
    // 0xdd5bfc: r0 = AllocateContext()
    //     0xdd5bfc: bl              #0x13de838  ; AllocateContextStub
    // 0xdd5c00: mov             x1, x0
    // 0xdd5c04: ldur            x0, [fp, #-8]
    // 0xdd5c08: StoreField: r1->field_f = r0
    //     0xdd5c08: stur            w0, [x1, #0xf]
    // 0xdd5c0c: LoadField: r2 = r0->field_1b
    //     0xdd5c0c: ldur            w2, [x0, #0x1b]
    // 0xdd5c10: DecompressPointer r2
    //     0xdd5c10: add             x2, x2, HEAP, lsl #32
    // 0xdd5c14: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd5c18: cmp             w2, w16
    // 0xdd5c1c: b.eq            #0xdd5cc0
    // 0xdd5c20: LoadField: r0 = r2->field_23
    //     0xdd5c20: ldur            w0, [x2, #0x23]
    // 0xdd5c24: DecompressPointer r0
    //     0xdd5c24: add             x0, x0, HEAP, lsl #32
    // 0xdd5c28: tbnz            w0, #4, #0xdd5c34
    // 0xdd5c2c: d0 = 0.000000
    //     0xdd5c2c: eor             v0.16b, v0.16b, v0.16b
    // 0xdd5c30: b               #0xdd5c38
    // 0xdd5c34: d0 = 1.000000
    //     0xdd5c34: fmov            d0, #1.00000000
    // 0xdd5c38: mov             x2, x1
    // 0xdd5c3c: stur            d0, [fp, #-0x18]
    // 0xdd5c40: r1 = Function '<anonymous closure>':.
    //     0xdd5c40: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3f20] AnonymousClosure: (0xdd5ccc), in [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_buildOptionsButton (0xdd5be8)
    //     0xdd5c44: ldr             x1, [x1, #0xf20]
    // 0xdd5c48: r0 = AllocateClosure()
    //     0xdd5c48: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd5c4c: stur            x0, [fp, #-8]
    // 0xdd5c50: r0 = IconButton()
    //     0xdd5c50: bl              #0xd16288  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0xdd5c54: mov             x1, x0
    // 0xdd5c58: ldur            x0, [fp, #-8]
    // 0xdd5c5c: stur            x1, [fp, #-0x10]
    // 0xdd5c60: StoreField: r1->field_3b = r0
    //     0xdd5c60: stur            w0, [x1, #0x3b]
    // 0xdd5c64: r0 = false
    //     0xdd5c64: add             x0, NULL, #0x30  ; false
    // 0xdd5c68: StoreField: r1->field_4f = r0
    //     0xdd5c68: stur            w0, [x1, #0x4f]
    // 0xdd5c6c: r2 = Instance_Icon
    //     0xdd5c6c: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8f530] Obj!Icon@12b5ea1
    //     0xdd5c70: ldr             x2, [x2, #0x530]
    // 0xdd5c74: StoreField: r1->field_1f = r2
    //     0xdd5c74: stur            w2, [x1, #0x1f]
    // 0xdd5c78: r2 = Instance__IconButtonVariant
    //     0xdd5c78: add             x2, PP, #0x17, lsl #12  ; [pp+0x177a8] Obj!_IconButtonVariant@12c57a1
    //     0xdd5c7c: ldr             x2, [x2, #0x7a8]
    // 0xdd5c80: StoreField: r1->field_6f = r2
    //     0xdd5c80: stur            w2, [x1, #0x6f]
    // 0xdd5c84: r0 = AnimatedOpacity()
    //     0xdd5c84: bl              #0xd2cf50  ; AllocateAnimatedOpacityStub -> AnimatedOpacity (size=0x28)
    // 0xdd5c88: ldur            x1, [fp, #-0x10]
    // 0xdd5c8c: ArrayStore: r0[0] = r1  ; List_4
    //     0xdd5c8c: stur            w1, [x0, #0x17]
    // 0xdd5c90: ldur            d0, [fp, #-0x18]
    // 0xdd5c94: StoreField: r0->field_1b = d0
    //     0xdd5c94: stur            d0, [x0, #0x1b]
    // 0xdd5c98: r1 = false
    //     0xdd5c98: add             x1, NULL, #0x30  ; false
    // 0xdd5c9c: StoreField: r0->field_23 = r1
    //     0xdd5c9c: stur            w1, [x0, #0x23]
    // 0xdd5ca0: r1 = Instance__Linear
    //     0xdd5ca0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] Obj!_Linear@129fef1
    // 0xdd5ca4: StoreField: r0->field_b = r1
    //     0xdd5ca4: stur            w1, [x0, #0xb]
    // 0xdd5ca8: r1 = Instance_Duration
    //     0xdd5ca8: add             x1, PP, #0xc, lsl #12  ; [pp+0xc920] Obj!Duration@12c89c1
    //     0xdd5cac: ldr             x1, [x1, #0x920]
    // 0xdd5cb0: StoreField: r0->field_f = r1
    //     0xdd5cb0: stur            w1, [x0, #0xf]
    // 0xdd5cb4: LeaveFrame
    //     0xdd5cb4: mov             SP, fp
    //     0xdd5cb8: ldp             fp, lr, [SP], #0x10
    // 0xdd5cbc: ret
    //     0xdd5cbc: ret             
    // 0xdd5cc0: r9 = notifier
    //     0xdd5cc0: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3e80] Field <_MaterialControlsState@451269912.notifier>: late (offset: 0x1c)
    //     0xdd5cc4: ldr             x9, [x9, #0xe80]
    // 0xdd5cc8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd5cc8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> <anonymous closure>(dynamic) async {
    // ** addr: 0xdd5ccc, size: 0x130
    // 0xdd5ccc: EnterFrame
    //     0xdd5ccc: stp             fp, lr, [SP, #-0x10]!
    //     0xdd5cd0: mov             fp, SP
    // 0xdd5cd4: AllocStack(0x40)
    //     0xdd5cd4: sub             SP, SP, #0x40
    // 0xdd5cd8: SetupParameters(_MaterialControlsState this /* r1 */)
    //     0xdd5cd8: stur            NULL, [fp, #-8]
    //     0xdd5cdc: mov             x0, #0
    //     0xdd5ce0: add             x1, fp, w0, sxtw #2
    //     0xdd5ce4: ldr             x1, [x1, #0x10]
    //     0xdd5ce8: ldur            w2, [x1, #0x17]
    //     0xdd5cec: add             x2, x2, HEAP, lsl #32
    //     0xdd5cf0: stur            x2, [fp, #-0x10]
    // 0xdd5cf4: CheckStackOverflow
    //     0xdd5cf4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd5cf8: cmp             SP, x16
    //     0xdd5cfc: b.ls            #0xdd5de0
    // 0xdd5d00: InitAsync() -> Future<void?>
    //     0xdd5d00: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0xdd5d04: bl              #0x7f5e44  ; InitAsyncStub
    // 0xdd5d08: ldur            x2, [fp, #-0x10]
    // 0xdd5d0c: LoadField: r0 = r2->field_f
    //     0xdd5d0c: ldur            w0, [x2, #0xf]
    // 0xdd5d10: DecompressPointer r0
    //     0xdd5d10: add             x0, x0, HEAP, lsl #32
    // 0xdd5d14: LoadField: r1 = r0->field_27
    //     0xdd5d14: ldur            w1, [x0, #0x27]
    // 0xdd5d18: DecompressPointer r1
    //     0xdd5d18: add             x1, x1, HEAP, lsl #32
    // 0xdd5d1c: cmp             w1, NULL
    // 0xdd5d20: b.ne            #0xdd5d2c
    // 0xdd5d24: mov             x0, x2
    // 0xdd5d28: b               #0xdd5d34
    // 0xdd5d2c: r0 = cancel()
    //     0xdd5d2c: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0xdd5d30: ldur            x0, [fp, #-0x10]
    // 0xdd5d34: LoadField: r1 = r0->field_f
    //     0xdd5d34: ldur            w1, [x0, #0xf]
    // 0xdd5d38: DecompressPointer r1
    //     0xdd5d38: add             x1, x1, HEAP, lsl #32
    // 0xdd5d3c: LoadField: r2 = r1->field_5b
    //     0xdd5d3c: ldur            w2, [x1, #0x5b]
    // 0xdd5d40: DecompressPointer r2
    //     0xdd5d40: add             x2, x2, HEAP, lsl #32
    // 0xdd5d44: cmp             w2, NULL
    // 0xdd5d48: b.eq            #0xdd5de8
    // 0xdd5d4c: LoadField: r3 = r1->field_f
    //     0xdd5d4c: ldur            w3, [x1, #0xf]
    // 0xdd5d50: DecompressPointer r3
    //     0xdd5d50: add             x3, x3, HEAP, lsl #32
    // 0xdd5d54: stur            x3, [fp, #-0x18]
    // 0xdd5d58: cmp             w3, NULL
    // 0xdd5d5c: b.eq            #0xdd5dec
    // 0xdd5d60: mov             x2, x0
    // 0xdd5d64: r1 = Function '<anonymous closure>':.
    //     0xdd5d64: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3f28] AnonymousClosure: (0xdd64b8), in [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_buildOptionsButton (0xdd5be8)
    //     0xdd5d68: ldr             x1, [x1, #0xf28]
    // 0xdd5d6c: r0 = AllocateClosure()
    //     0xdd5d6c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd5d70: r16 = <OptionItem>
    //     0xdd5d70: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf380] TypeArguments: <OptionItem>
    //     0xdd5d74: ldr             x16, [x16, #0x380]
    // 0xdd5d78: stp             x0, x16, [SP, #0x18]
    // 0xdd5d7c: ldur            x16, [fp, #-0x18]
    // 0xdd5d80: r30 = true
    //     0xdd5d80: add             lr, NULL, #0x20  ; true
    // 0xdd5d84: stp             lr, x16, [SP, #8]
    // 0xdd5d88: r16 = true
    //     0xdd5d88: add             x16, NULL, #0x20  ; true
    // 0xdd5d8c: str             x16, [SP]
    // 0xdd5d90: r4 = const [0x1, 0x4, 0x4, 0x2, isScrollControlled, 0x2, useRootNavigator, 0x3, null]
    //     0xdd5d90: add             x4, PP, #0xd3, lsl #12  ; [pp+0xd3dd8] List(9) [0x1, 0x4, 0x4, 0x2, "isScrollControlled", 0x2, "useRootNavigator", 0x3, Null]
    //     0xdd5d94: ldr             x4, [x4, #0xdd8]
    // 0xdd5d98: r0 = showModalBottomSheet()
    //     0xdd5d98: bl              #0xdd5dfc  ; [package:flutter/src/material/bottom_sheet.dart] ::showModalBottomSheet
    // 0xdd5d9c: mov             x1, x0
    // 0xdd5da0: stur            x1, [fp, #-0x18]
    // 0xdd5da4: r0 = Await()
    //     0xdd5da4: bl              #0x7f5c00  ; AwaitStub
    // 0xdd5da8: ldur            x0, [fp, #-0x10]
    // 0xdd5dac: LoadField: r1 = r0->field_f
    //     0xdd5dac: ldur            w1, [x0, #0xf]
    // 0xdd5db0: DecompressPointer r1
    //     0xdd5db0: add             x1, x1, HEAP, lsl #32
    // 0xdd5db4: LoadField: r0 = r1->field_1f
    //     0xdd5db4: ldur            w0, [x1, #0x1f]
    // 0xdd5db8: DecompressPointer r0
    //     0xdd5db8: add             x0, x0, HEAP, lsl #32
    // 0xdd5dbc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd5dc0: cmp             w0, w16
    // 0xdd5dc4: b.eq            #0xdd5df0
    // 0xdd5dc8: LoadField: r2 = r0->field_1b
    //     0xdd5dc8: ldur            w2, [x0, #0x1b]
    // 0xdd5dcc: DecompressPointer r2
    //     0xdd5dcc: add             x2, x2, HEAP, lsl #32
    // 0xdd5dd0: tbnz            w2, #4, #0xdd5dd8
    // 0xdd5dd4: r0 = _startHideTimer()
    //     0xdd5dd4: bl              #0xdd4954  ; [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_startHideTimer
    // 0xdd5dd8: r0 = Null
    //     0xdd5dd8: mov             x0, NULL
    // 0xdd5ddc: r0 = ReturnAsyncNotFuture()
    //     0xdd5ddc: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xdd5de0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd5de0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd5de4: b               #0xdd5d00
    // 0xdd5de8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd5de8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdd5dec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd5dec: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdd5df0: r9 = _latestValue
    //     0xdd5df0: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3eb0] Field <_MaterialControlsState@451269912._latestValue@451269912>: late (offset: 0x20)
    //     0xdd5df4: ldr             x9, [x9, #0xeb0]
    // 0xdd5df8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd5df8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] OptionsDialog <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0xdd64b8, size: 0x80
    // 0xdd64b8: EnterFrame
    //     0xdd64b8: stp             fp, lr, [SP, #-0x10]!
    //     0xdd64bc: mov             fp, SP
    // 0xdd64c0: AllocStack(0x10)
    //     0xdd64c0: sub             SP, SP, #0x10
    // 0xdd64c4: SetupParameters([dynamic _ /* r0 */])
    //     0xdd64c4: ldr             x0, [fp, #0x18]
    //     0xdd64c8: ldur            w3, [x0, #0x17]
    //     0xdd64cc: add             x3, x3, HEAP, lsl #32
    //     0xdd64d0: stur            x3, [fp, #-8]
    // 0xdd64d4: CheckStackOverflow
    //     0xdd64d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd64d8: cmp             SP, x16
    //     0xdd64dc: b.ls            #0xdd652c
    // 0xdd64e0: LoadField: r1 = r3->field_f
    //     0xdd64e0: ldur            w1, [x3, #0xf]
    // 0xdd64e4: DecompressPointer r1
    //     0xdd64e4: add             x1, x1, HEAP, lsl #32
    // 0xdd64e8: ldr             x2, [fp, #0x10]
    // 0xdd64ec: r0 = _buildOptions()
    //     0xdd64ec: bl              #0xdd6568  ; [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_buildOptions
    // 0xdd64f0: mov             x1, x0
    // 0xdd64f4: ldur            x0, [fp, #-8]
    // 0xdd64f8: stur            x1, [fp, #-0x10]
    // 0xdd64fc: LoadField: r2 = r0->field_f
    //     0xdd64fc: ldur            w2, [x0, #0xf]
    // 0xdd6500: DecompressPointer r2
    //     0xdd6500: add             x2, x2, HEAP, lsl #32
    // 0xdd6504: LoadField: r0 = r2->field_5b
    //     0xdd6504: ldur            w0, [x2, #0x5b]
    // 0xdd6508: DecompressPointer r0
    //     0xdd6508: add             x0, x0, HEAP, lsl #32
    // 0xdd650c: cmp             w0, NULL
    // 0xdd6510: b.eq            #0xdd6534
    // 0xdd6514: r0 = OptionsDialog()
    //     0xdd6514: bl              #0xdd6538  ; AllocateOptionsDialogStub -> OptionsDialog (size=0x14)
    // 0xdd6518: ldur            x1, [fp, #-0x10]
    // 0xdd651c: StoreField: r0->field_b = r1
    //     0xdd651c: stur            w1, [x0, #0xb]
    // 0xdd6520: LeaveFrame
    //     0xdd6520: mov             SP, fp
    //     0xdd6524: ldp             fp, lr, [SP], #0x10
    // 0xdd6528: ret
    //     0xdd6528: ret             
    // 0xdd652c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd652c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd6530: b               #0xdd64e0
    // 0xdd6534: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd6534: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _buildOptions(/* No info */) {
    // ** addr: 0xdd6568, size: 0x164
    // 0xdd6568: EnterFrame
    //     0xdd6568: stp             fp, lr, [SP, #-0x10]!
    //     0xdd656c: mov             fp, SP
    // 0xdd6570: AllocStack(0x38)
    //     0xdd6570: sub             SP, SP, #0x38
    // 0xdd6574: SetupParameters(_MaterialControlsState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xdd6574: stur            x1, [fp, #-8]
    //     0xdd6578: stur            x2, [fp, #-0x10]
    // 0xdd657c: CheckStackOverflow
    //     0xdd657c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd6580: cmp             SP, x16
    //     0xdd6584: b.ls            #0xdd66b8
    // 0xdd6588: r1 = 1
    //     0xdd6588: mov             x1, #1
    // 0xdd658c: r0 = AllocateContext()
    //     0xdd658c: bl              #0x13de838  ; AllocateContextStub
    // 0xdd6590: mov             x1, x0
    // 0xdd6594: ldur            x0, [fp, #-8]
    // 0xdd6598: StoreField: r1->field_f = r0
    //     0xdd6598: stur            w0, [x1, #0xf]
    // 0xdd659c: LoadField: r3 = r0->field_5b
    //     0xdd659c: ldur            w3, [x0, #0x5b]
    // 0xdd65a0: DecompressPointer r3
    //     0xdd65a0: add             x3, x3, HEAP, lsl #32
    // 0xdd65a4: stur            x3, [fp, #-0x18]
    // 0xdd65a8: cmp             w3, NULL
    // 0xdd65ac: b.eq            #0xdd66c0
    // 0xdd65b0: mov             x2, x1
    // 0xdd65b4: r1 = Function '<anonymous closure>':.
    //     0xdd65b4: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3f30] AnonymousClosure: (0xdd66d8), in [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_buildOptions (0xdd6568)
    //     0xdd65b8: ldr             x1, [x1, #0xf30]
    // 0xdd65bc: r0 = AllocateClosure()
    //     0xdd65bc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd65c0: stur            x0, [fp, #-0x20]
    // 0xdd65c4: r0 = OptionItem()
    //     0xdd65c4: bl              #0xdd66cc  ; AllocateOptionItemStub -> OptionItem (size=0x18)
    // 0xdd65c8: mov             x3, x0
    // 0xdd65cc: ldur            x0, [fp, #-0x20]
    // 0xdd65d0: stur            x3, [fp, #-0x28]
    // 0xdd65d4: StoreField: r3->field_7 = r0
    //     0xdd65d4: stur            w0, [x3, #7]
    // 0xdd65d8: r0 = Instance_IconData
    //     0xdd65d8: add             x0, PP, #0xd3, lsl #12  ; [pp+0xd3db8] Obj!IconData@128a631
    //     0xdd65dc: ldr             x0, [x0, #0xdb8]
    // 0xdd65e0: StoreField: r3->field_b = r0
    //     0xdd65e0: stur            w0, [x3, #0xb]
    // 0xdd65e4: r0 = "Playback speed"
    //     0xdd65e4: add             x0, PP, #0xd3, lsl #12  ; [pp+0xd3dc0] "Playback speed"
    //     0xdd65e8: ldr             x0, [x0, #0xdc0]
    // 0xdd65ec: StoreField: r3->field_f = r0
    //     0xdd65ec: stur            w0, [x3, #0xf]
    // 0xdd65f0: r1 = Null
    //     0xdd65f0: mov             x1, NULL
    // 0xdd65f4: r2 = 2
    //     0xdd65f4: mov             x2, #2
    // 0xdd65f8: r0 = AllocateArray()
    //     0xdd65f8: bl              #0x13df928  ; AllocateArrayStub
    // 0xdd65fc: mov             x2, x0
    // 0xdd6600: ldur            x0, [fp, #-0x28]
    // 0xdd6604: stur            x2, [fp, #-0x20]
    // 0xdd6608: StoreField: r2->field_f = r0
    //     0xdd6608: stur            w0, [x2, #0xf]
    // 0xdd660c: r1 = <OptionItem>
    //     0xdd660c: add             x1, PP, #0xcf, lsl #12  ; [pp+0xcf380] TypeArguments: <OptionItem>
    //     0xdd6610: ldr             x1, [x1, #0x380]
    // 0xdd6614: r0 = AllocateGrowableArray()
    //     0xdd6614: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xdd6618: mov             x1, x0
    // 0xdd661c: ldur            x0, [fp, #-0x20]
    // 0xdd6620: stur            x1, [fp, #-0x28]
    // 0xdd6624: StoreField: r1->field_f = r0
    //     0xdd6624: stur            w0, [x1, #0xf]
    // 0xdd6628: r0 = 2
    //     0xdd6628: mov             x0, #2
    // 0xdd662c: StoreField: r1->field_b = r0
    //     0xdd662c: stur            w0, [x1, #0xb]
    // 0xdd6630: ldur            x0, [fp, #-0x18]
    // 0xdd6634: LoadField: r2 = r0->field_2f
    //     0xdd6634: ldur            w2, [x0, #0x2f]
    // 0xdd6638: DecompressPointer r2
    //     0xdd6638: add             x2, x2, HEAP, lsl #32
    // 0xdd663c: cmp             w2, NULL
    // 0xdd6640: b.eq            #0xdd66a8
    // 0xdd6644: ldur            x16, [fp, #-0x10]
    // 0xdd6648: stp             x16, x2, [SP]
    // 0xdd664c: mov             x0, x2
    // 0xdd6650: ClosureCall
    //     0xdd6650: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xdd6654: ldur            x2, [x0, #0x1f]
    //     0xdd6658: blr             x2
    // 0xdd665c: LoadField: r1 = r0->field_b
    //     0xdd665c: ldur            w1, [x0, #0xb]
    // 0xdd6660: cbz             w1, #0xdd66a8
    // 0xdd6664: ldur            x0, [fp, #-8]
    // 0xdd6668: LoadField: r1 = r0->field_5b
    //     0xdd6668: ldur            w1, [x0, #0x5b]
    // 0xdd666c: DecompressPointer r1
    //     0xdd666c: add             x1, x1, HEAP, lsl #32
    // 0xdd6670: cmp             w1, NULL
    // 0xdd6674: b.eq            #0xdd66c4
    // 0xdd6678: LoadField: r0 = r1->field_2f
    //     0xdd6678: ldur            w0, [x1, #0x2f]
    // 0xdd667c: DecompressPointer r0
    //     0xdd667c: add             x0, x0, HEAP, lsl #32
    // 0xdd6680: cmp             w0, NULL
    // 0xdd6684: b.eq            #0xdd66c8
    // 0xdd6688: ldur            x16, [fp, #-0x10]
    // 0xdd668c: stp             x16, x0, [SP]
    // 0xdd6690: ClosureCall
    //     0xdd6690: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xdd6694: ldur            x2, [x0, #0x1f]
    //     0xdd6698: blr             x2
    // 0xdd669c: ldur            x1, [fp, #-0x28]
    // 0xdd66a0: mov             x2, x0
    // 0xdd66a4: r0 = addAll()
    //     0xdd66a4: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0xdd66a8: ldur            x0, [fp, #-0x28]
    // 0xdd66ac: LeaveFrame
    //     0xdd66ac: mov             SP, fp
    //     0xdd66b0: ldp             fp, lr, [SP], #0x10
    // 0xdd66b4: ret
    //     0xdd66b4: ret             
    // 0xdd66b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd66b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd66bc: b               #0xdd6588
    // 0xdd66c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd66c0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdd66c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd66c4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdd66c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd66c8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> <anonymous closure>(dynamic, BuildContext) async {
    // ** addr: 0xdd66d8, size: 0x7c
    // 0xdd66d8: EnterFrame
    //     0xdd66d8: stp             fp, lr, [SP, #-0x10]!
    //     0xdd66dc: mov             fp, SP
    // 0xdd66e0: AllocStack(0x28)
    //     0xdd66e0: sub             SP, SP, #0x28
    // 0xdd66e4: SetupParameters(_MaterialControlsState this /* r1 */, dynamic _ /* r2, fp-0x18 */)
    //     0xdd66e4: stur            NULL, [fp, #-8]
    //     0xdd66e8: mov             x0, #0
    //     0xdd66ec: add             x1, fp, w0, sxtw #2
    //     0xdd66f0: ldr             x1, [x1, #0x18]
    //     0xdd66f4: add             x2, fp, w0, sxtw #2
    //     0xdd66f8: ldr             x2, [x2, #0x10]
    //     0xdd66fc: stur            x2, [fp, #-0x18]
    //     0xdd6700: ldur            w3, [x1, #0x17]
    //     0xdd6704: add             x3, x3, HEAP, lsl #32
    //     0xdd6708: stur            x3, [fp, #-0x10]
    // 0xdd670c: CheckStackOverflow
    //     0xdd670c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd6710: cmp             SP, x16
    //     0xdd6714: b.ls            #0xdd674c
    // 0xdd6718: InitAsync() -> Future<void?>
    //     0xdd6718: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0xdd671c: bl              #0x7f5e44  ; InitAsyncStub
    // 0xdd6720: r16 = <Object?>
    //     0xdd6720: ldr             x16, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0xdd6724: ldur            lr, [fp, #-0x18]
    // 0xdd6728: stp             lr, x16, [SP]
    // 0xdd672c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdd672c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdd6730: r0 = pop()
    //     0xdd6730: bl              #0xd190ec  ; [package:flutter/src/widgets/navigator.dart] Navigator::pop
    // 0xdd6734: ldur            x0, [fp, #-0x10]
    // 0xdd6738: LoadField: r1 = r0->field_f
    //     0xdd6738: ldur            w1, [x0, #0xf]
    // 0xdd673c: DecompressPointer r1
    //     0xdd673c: add             x1, x1, HEAP, lsl #32
    // 0xdd6740: r0 = _onSpeedButtonTap()
    //     0xdd6740: bl              #0xdd6754  ; [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_onSpeedButtonTap
    // 0xdd6744: r0 = Null
    //     0xdd6744: mov             x0, NULL
    // 0xdd6748: r0 = ReturnAsyncNotFuture()
    //     0xdd6748: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xdd674c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd674c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd6750: b               #0xdd6718
  }
  _ _onSpeedButtonTap(/* No info */) async {
    // ** addr: 0xdd6754, size: 0x144
    // 0xdd6754: EnterFrame
    //     0xdd6754: stp             fp, lr, [SP, #-0x10]!
    //     0xdd6758: mov             fp, SP
    // 0xdd675c: AllocStack(0x48)
    //     0xdd675c: sub             SP, SP, #0x48
    // 0xdd6760: SetupParameters(_MaterialControlsState this /* r1 => r1, fp-0x10 */)
    //     0xdd6760: stur            NULL, [fp, #-8]
    //     0xdd6764: stur            x1, [fp, #-0x10]
    // 0xdd6768: CheckStackOverflow
    //     0xdd6768: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd676c: cmp             SP, x16
    //     0xdd6770: b.ls            #0xdd6870
    // 0xdd6774: r1 = 1
    //     0xdd6774: mov             x1, #1
    // 0xdd6778: r0 = AllocateContext()
    //     0xdd6778: bl              #0x13de838  ; AllocateContextStub
    // 0xdd677c: mov             x2, x0
    // 0xdd6780: ldur            x1, [fp, #-0x10]
    // 0xdd6784: stur            x2, [fp, #-0x18]
    // 0xdd6788: StoreField: r2->field_f = r1
    //     0xdd6788: stur            w1, [x2, #0xf]
    // 0xdd678c: InitAsync() -> Future<void?>
    //     0xdd678c: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0xdd6790: bl              #0x7f5e44  ; InitAsyncStub
    // 0xdd6794: ldur            x0, [fp, #-0x10]
    // 0xdd6798: LoadField: r1 = r0->field_27
    //     0xdd6798: ldur            w1, [x0, #0x27]
    // 0xdd679c: DecompressPointer r1
    //     0xdd679c: add             x1, x1, HEAP, lsl #32
    // 0xdd67a0: cmp             w1, NULL
    // 0xdd67a4: b.eq            #0xdd67b0
    // 0xdd67a8: r0 = cancel()
    //     0xdd67a8: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0xdd67ac: ldur            x0, [fp, #-0x10]
    // 0xdd67b0: LoadField: r3 = r0->field_f
    //     0xdd67b0: ldur            w3, [x0, #0xf]
    // 0xdd67b4: DecompressPointer r3
    //     0xdd67b4: add             x3, x3, HEAP, lsl #32
    // 0xdd67b8: stur            x3, [fp, #-0x20]
    // 0xdd67bc: cmp             w3, NULL
    // 0xdd67c0: b.eq            #0xdd6878
    // 0xdd67c4: LoadField: r1 = r0->field_5b
    //     0xdd67c4: ldur            w1, [x0, #0x5b]
    // 0xdd67c8: DecompressPointer r1
    //     0xdd67c8: add             x1, x1, HEAP, lsl #32
    // 0xdd67cc: cmp             w1, NULL
    // 0xdd67d0: b.eq            #0xdd687c
    // 0xdd67d4: ldur            x2, [fp, #-0x18]
    // 0xdd67d8: r1 = Function '<anonymous closure>':.
    //     0xdd67d8: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3f38] AnonymousClosure: (0xdd6898), in [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_onSpeedButtonTap (0xdd6754)
    //     0xdd67dc: ldr             x1, [x1, #0xf38]
    // 0xdd67e0: r0 = AllocateClosure()
    //     0xdd67e0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd67e4: r16 = <double>
    //     0xdd67e4: ldr             x16, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xdd67e8: stp             x0, x16, [SP, #0x18]
    // 0xdd67ec: ldur            x16, [fp, #-0x20]
    // 0xdd67f0: r30 = true
    //     0xdd67f0: add             lr, NULL, #0x20  ; true
    // 0xdd67f4: stp             lr, x16, [SP, #8]
    // 0xdd67f8: r16 = true
    //     0xdd67f8: add             x16, NULL, #0x20  ; true
    // 0xdd67fc: str             x16, [SP]
    // 0xdd6800: r4 = const [0x1, 0x4, 0x4, 0x2, isScrollControlled, 0x2, useRootNavigator, 0x3, null]
    //     0xdd6800: add             x4, PP, #0xd3, lsl #12  ; [pp+0xd3dd8] List(9) [0x1, 0x4, 0x4, 0x2, "isScrollControlled", 0x2, "useRootNavigator", 0x3, Null]
    //     0xdd6804: ldr             x4, [x4, #0xdd8]
    // 0xdd6808: r0 = showModalBottomSheet()
    //     0xdd6808: bl              #0xdd5dfc  ; [package:flutter/src/material/bottom_sheet.dart] ::showModalBottomSheet
    // 0xdd680c: mov             x1, x0
    // 0xdd6810: stur            x1, [fp, #-0x20]
    // 0xdd6814: r0 = Await()
    //     0xdd6814: bl              #0x7f5c00  ; AwaitStub
    // 0xdd6818: cmp             w0, NULL
    // 0xdd681c: b.eq            #0xdd6840
    // 0xdd6820: ldur            x2, [fp, #-0x10]
    // 0xdd6824: LoadField: r1 = r2->field_57
    //     0xdd6824: ldur            w1, [x2, #0x57]
    // 0xdd6828: DecompressPointer r1
    //     0xdd6828: add             x1, x1, HEAP, lsl #32
    // 0xdd682c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd6830: cmp             w1, w16
    // 0xdd6834: b.eq            #0xdd6880
    // 0xdd6838: LoadField: d0 = r0->field_7
    //     0xdd6838: ldur            d0, [x0, #7]
    // 0xdd683c: r0 = setPlaybackSpeed()
    //     0xdd683c: bl              #0xdcf0e8  ; [package:video_player/video_player.dart] VideoPlayerController::setPlaybackSpeed
    // 0xdd6840: ldur            x1, [fp, #-0x10]
    // 0xdd6844: LoadField: r0 = r1->field_1f
    //     0xdd6844: ldur            w0, [x1, #0x1f]
    // 0xdd6848: DecompressPointer r0
    //     0xdd6848: add             x0, x0, HEAP, lsl #32
    // 0xdd684c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd6850: cmp             w0, w16
    // 0xdd6854: b.eq            #0xdd688c
    // 0xdd6858: LoadField: r2 = r0->field_1b
    //     0xdd6858: ldur            w2, [x0, #0x1b]
    // 0xdd685c: DecompressPointer r2
    //     0xdd685c: add             x2, x2, HEAP, lsl #32
    // 0xdd6860: tbnz            w2, #4, #0xdd6868
    // 0xdd6864: r0 = _startHideTimer()
    //     0xdd6864: bl              #0xdd4954  ; [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_startHideTimer
    // 0xdd6868: r0 = Null
    //     0xdd6868: mov             x0, NULL
    // 0xdd686c: r0 = ReturnAsyncNotFuture()
    //     0xdd686c: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xdd6870: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd6870: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd6874: b               #0xdd6774
    // 0xdd6878: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd6878: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdd687c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd687c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdd6880: r9 = controller
    //     0xdd6880: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3e70] Field <_MaterialControlsState@451269912.controller>: late (offset: 0x58)
    //     0xdd6884: ldr             x9, [x9, #0xe70]
    // 0xdd6888: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd6888: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdd688c: r9 = _latestValue
    //     0xdd688c: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3eb0] Field <_MaterialControlsState@451269912._latestValue@451269912>: late (offset: 0x20)
    //     0xdd6890: ldr             x9, [x9, #0xeb0]
    // 0xdd6894: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd6894: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] PlaybackSpeedDialog <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0xdd6898, size: 0x80
    // 0xdd6898: EnterFrame
    //     0xdd6898: stp             fp, lr, [SP, #-0x10]!
    //     0xdd689c: mov             fp, SP
    // 0xdd68a0: AllocStack(0x8)
    //     0xdd68a0: sub             SP, SP, #8
    // 0xdd68a4: SetupParameters([dynamic _ /* r0 */])
    //     0xdd68a4: ldr             x0, [fp, #0x18]
    //     0xdd68a8: ldur            w1, [x0, #0x17]
    //     0xdd68ac: add             x1, x1, HEAP, lsl #32
    // 0xdd68b0: LoadField: r0 = r1->field_f
    //     0xdd68b0: ldur            w0, [x1, #0xf]
    // 0xdd68b4: DecompressPointer r0
    //     0xdd68b4: add             x0, x0, HEAP, lsl #32
    // 0xdd68b8: LoadField: r1 = r0->field_5b
    //     0xdd68b8: ldur            w1, [x0, #0x5b]
    // 0xdd68bc: DecompressPointer r1
    //     0xdd68bc: add             x1, x1, HEAP, lsl #32
    // 0xdd68c0: cmp             w1, NULL
    // 0xdd68c4: b.eq            #0xdd6908
    // 0xdd68c8: LoadField: r1 = r0->field_1f
    //     0xdd68c8: ldur            w1, [x0, #0x1f]
    // 0xdd68cc: DecompressPointer r1
    //     0xdd68cc: add             x1, x1, HEAP, lsl #32
    // 0xdd68d0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd68d4: cmp             w1, w16
    // 0xdd68d8: b.eq            #0xdd690c
    // 0xdd68dc: LoadField: d0 = r1->field_2f
    //     0xdd68dc: ldur            d0, [x1, #0x2f]
    // 0xdd68e0: stur            d0, [fp, #-8]
    // 0xdd68e4: r0 = PlaybackSpeedDialog()
    //     0xdd68e4: bl              #0xdd6918  ; AllocatePlaybackSpeedDialogStub -> PlaybackSpeedDialog (size=0x18)
    // 0xdd68e8: r1 = const [0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0]
    //     0xdd68e8: add             x1, PP, #0xa5, lsl #12  ; [pp+0xa5f68] List<double>(8)
    //     0xdd68ec: ldr             x1, [x1, #0xf68]
    // 0xdd68f0: StoreField: r0->field_b = r1
    //     0xdd68f0: stur            w1, [x0, #0xb]
    // 0xdd68f4: ldur            d0, [fp, #-8]
    // 0xdd68f8: StoreField: r0->field_f = d0
    //     0xdd68f8: stur            d0, [x0, #0xf]
    // 0xdd68fc: LeaveFrame
    //     0xdd68fc: mov             SP, fp
    //     0xdd6900: ldp             fp, lr, [SP], #0x10
    // 0xdd6904: ret
    //     0xdd6904: ret             
    // 0xdd6908: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd6908: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdd690c: r9 = _latestValue
    //     0xdd690c: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3eb0] Field <_MaterialControlsState@451269912._latestValue@451269912>: late (offset: 0x20)
    //     0xdd6910: ldr             x9, [x9, #0xeb0]
    // 0xdd6914: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd6914: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _buildHitArea(/* No info */) {
    // ** addr: 0xdd6924, size: 0x54c
    // 0xdd6924: EnterFrame
    //     0xdd6924: stp             fp, lr, [SP, #-0x10]!
    //     0xdd6928: mov             fp, SP
    // 0xdd692c: AllocStack(0x68)
    //     0xdd692c: sub             SP, SP, #0x68
    // 0xdd6930: SetupParameters(_MaterialControlsState this /* r1 => r2, fp-0x8 */)
    //     0xdd6930: mov             x2, x1
    //     0xdd6934: stur            x1, [fp, #-8]
    // 0xdd6938: CheckStackOverflow
    //     0xdd6938: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd693c: cmp             SP, x16
    //     0xdd6940: b.ls            #0xdd6e38
    // 0xdd6944: r1 = 1
    //     0xdd6944: mov             x1, #1
    // 0xdd6948: r0 = AllocateContext()
    //     0xdd6948: bl              #0x13de838  ; AllocateContextStub
    // 0xdd694c: mov             x3, x0
    // 0xdd6950: ldur            x0, [fp, #-8]
    // 0xdd6954: stur            x3, [fp, #-0x20]
    // 0xdd6958: StoreField: r3->field_f = r0
    //     0xdd6958: stur            w0, [x3, #0xf]
    // 0xdd695c: LoadField: r1 = r0->field_1f
    //     0xdd695c: ldur            w1, [x0, #0x1f]
    // 0xdd6960: DecompressPointer r1
    //     0xdd6960: add             x1, x1, HEAP, lsl #32
    // 0xdd6964: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd6968: cmp             w1, w16
    // 0xdd696c: b.eq            #0xdd6e40
    // 0xdd6970: LoadField: r2 = r1->field_b
    //     0xdd6970: ldur            w2, [x1, #0xb]
    // 0xdd6974: DecompressPointer r2
    //     0xdd6974: add             x2, x2, HEAP, lsl #32
    // 0xdd6978: LoadField: r4 = r1->field_7
    //     0xdd6978: ldur            w4, [x1, #7]
    // 0xdd697c: DecompressPointer r4
    //     0xdd697c: add             x4, x4, HEAP, lsl #32
    // 0xdd6980: LoadField: r1 = r2->field_7
    //     0xdd6980: ldur            x1, [x2, #7]
    // 0xdd6984: LoadField: r2 = r4->field_7
    //     0xdd6984: ldur            x2, [x4, #7]
    // 0xdd6988: cmp             x1, x2
    // 0xdd698c: b.lt            #0xdd69b4
    // 0xdd6990: r1 = 1000000
    //     0xdd6990: mov             x1, #0x4240
    //     0xdd6994: movk            x1, #0xf, lsl #16
    // 0xdd6998: sdiv            x4, x2, x1
    // 0xdd699c: cmp             x4, #0
    // 0xdd69a0: r16 = true
    //     0xdd69a0: add             x16, NULL, #0x20  ; true
    // 0xdd69a4: r17 = false
    //     0xdd69a4: add             x17, NULL, #0x30  ; false
    // 0xdd69a8: csel            x1, x16, x17, gt
    // 0xdd69ac: mov             x4, x1
    // 0xdd69b0: b               #0xdd69b8
    // 0xdd69b4: r4 = false
    //     0xdd69b4: add             x4, NULL, #0x30  ; false
    // 0xdd69b8: stur            x4, [fp, #-0x18]
    // 0xdd69bc: LoadField: r1 = r0->field_b
    //     0xdd69bc: ldur            w1, [x0, #0xb]
    // 0xdd69c0: DecompressPointer r1
    //     0xdd69c0: add             x1, x1, HEAP, lsl #32
    // 0xdd69c4: cmp             w1, NULL
    // 0xdd69c8: b.eq            #0xdd6e4c
    // 0xdd69cc: LoadField: r1 = r0->field_37
    //     0xdd69cc: ldur            w1, [x0, #0x37]
    // 0xdd69d0: DecompressPointer r1
    //     0xdd69d0: add             x1, x1, HEAP, lsl #32
    // 0xdd69d4: tbz             w1, #4, #0xdd6a00
    // 0xdd69d8: LoadField: r1 = r0->field_1b
    //     0xdd69d8: ldur            w1, [x0, #0x1b]
    // 0xdd69dc: DecompressPointer r1
    //     0xdd69dc: add             x1, x1, HEAP, lsl #32
    // 0xdd69e0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd69e4: cmp             w1, w16
    // 0xdd69e8: b.eq            #0xdd6e50
    // 0xdd69ec: LoadField: r2 = r1->field_23
    //     0xdd69ec: ldur            w2, [x1, #0x23]
    // 0xdd69f0: DecompressPointer r2
    //     0xdd69f0: add             x2, x2, HEAP, lsl #32
    // 0xdd69f4: eor             x1, x2, #0x10
    // 0xdd69f8: mov             x5, x1
    // 0xdd69fc: b               #0xdd6a04
    // 0xdd6a00: r5 = false
    //     0xdd6a00: add             x5, NULL, #0x30  ; false
    // 0xdd6a04: stur            x5, [fp, #-0x10]
    // 0xdd6a08: r1 = <Widget>
    //     0xdd6a08: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xdd6a0c: r2 = 0
    //     0xdd6a0c: mov             x2, #0
    // 0xdd6a10: r0 = _GrowableList()
    //     0xdd6a10: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xdd6a14: mov             x1, x0
    // 0xdd6a18: ldur            x0, [fp, #-0x18]
    // 0xdd6a1c: stur            x1, [fp, #-0x28]
    // 0xdd6a20: tbz             w0, #4, #0xdd6b1c
    // 0xdd6a24: ldur            x2, [fp, #-8]
    // 0xdd6a28: ldur            x3, [fp, #-0x10]
    // 0xdd6a2c: LoadField: r4 = r2->field_5b
    //     0xdd6a2c: ldur            w4, [x2, #0x5b]
    // 0xdd6a30: DecompressPointer r4
    //     0xdd6a30: add             x4, x4, HEAP, lsl #32
    // 0xdd6a34: cmp             w4, NULL
    // 0xdd6a38: b.eq            #0xdd6e5c
    // 0xdd6a3c: r0 = CenterSeekButton()
    //     0xdd6a3c: bl              #0xdd6e70  ; AllocateCenterSeekButtonStub -> CenterSeekButton (size=0x2c)
    // 0xdd6a40: mov             x3, x0
    // 0xdd6a44: r0 = Instance_IconData
    //     0xdd6a44: add             x0, PP, #0xd3, lsl #12  ; [pp+0xd3f40] Obj!IconData@128a791
    //     0xdd6a48: ldr             x0, [x0, #0xf40]
    // 0xdd6a4c: stur            x3, [fp, #-0x30]
    // 0xdd6a50: StoreField: r3->field_b = r0
    //     0xdd6a50: stur            w0, [x3, #0xb]
    // 0xdd6a54: r0 = Instance_Color
    //     0xdd6a54: add             x0, PP, #0x12, lsl #12  ; [pp+0x12c78] Obj!Color@12a1741
    //     0xdd6a58: ldr             x0, [x0, #0xc78]
    // 0xdd6a5c: StoreField: r3->field_f = r0
    //     0xdd6a5c: stur            w0, [x3, #0xf]
    // 0xdd6a60: r4 = Instance_Color
    //     0xdd6a60: add             x4, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0xdd6a64: ldr             x4, [x4, #0xc38]
    // 0xdd6a68: StoreField: r3->field_13 = r4
    //     0xdd6a68: stur            w4, [x3, #0x13]
    // 0xdd6a6c: ldur            x5, [fp, #-0x10]
    // 0xdd6a70: ArrayStore: r3[0] = r5  ; List_4
    //     0xdd6a70: stur            w5, [x3, #0x17]
    // 0xdd6a74: r6 = Instance_Duration
    //     0xdd6a74: ldr             x6, [PP, #0x7cd8]  ; [pp+0x7cd8] Obj!Duration@12c8971
    // 0xdd6a78: StoreField: r3->field_1f = r6
    //     0xdd6a78: stur            w6, [x3, #0x1f]
    // 0xdd6a7c: d0 = 26.000000
    //     0xdd6a7c: fmov            d0, #26.00000000
    // 0xdd6a80: StoreField: r3->field_23 = d0
    //     0xdd6a80: stur            d0, [x3, #0x23]
    // 0xdd6a84: ldur            x2, [fp, #-8]
    // 0xdd6a88: r1 = Function '_seekBackward@451269912':.
    //     0xdd6a88: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3f48] AnonymousClosure: (0xdd7468), in [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_seekBackward (0xdd74a0)
    //     0xdd6a8c: ldr             x1, [x1, #0xf48]
    // 0xdd6a90: r0 = AllocateClosure()
    //     0xdd6a90: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd6a94: mov             x1, x0
    // 0xdd6a98: ldur            x0, [fp, #-0x30]
    // 0xdd6a9c: StoreField: r0->field_1b = r1
    //     0xdd6a9c: stur            w1, [x0, #0x1b]
    // 0xdd6aa0: ldur            x2, [fp, #-0x28]
    // 0xdd6aa4: LoadField: r1 = r2->field_b
    //     0xdd6aa4: ldur            w1, [x2, #0xb]
    // 0xdd6aa8: LoadField: r3 = r2->field_f
    //     0xdd6aa8: ldur            w3, [x2, #0xf]
    // 0xdd6aac: DecompressPointer r3
    //     0xdd6aac: add             x3, x3, HEAP, lsl #32
    // 0xdd6ab0: LoadField: r4 = r3->field_b
    //     0xdd6ab0: ldur            w4, [x3, #0xb]
    // 0xdd6ab4: r3 = LoadInt32Instr(r1)
    //     0xdd6ab4: sbfx            x3, x1, #1, #0x1f
    // 0xdd6ab8: stur            x3, [fp, #-0x38]
    // 0xdd6abc: r1 = LoadInt32Instr(r4)
    //     0xdd6abc: sbfx            x1, x4, #1, #0x1f
    // 0xdd6ac0: cmp             x3, x1
    // 0xdd6ac4: b.ne            #0xdd6ad0
    // 0xdd6ac8: mov             x1, x2
    // 0xdd6acc: r0 = _growToNextCapacity()
    //     0xdd6acc: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xdd6ad0: ldur            x2, [fp, #-0x28]
    // 0xdd6ad4: ldur            x3, [fp, #-0x38]
    // 0xdd6ad8: add             x0, x3, #1
    // 0xdd6adc: lsl             x1, x0, #1
    // 0xdd6ae0: StoreField: r2->field_b = r1
    //     0xdd6ae0: stur            w1, [x2, #0xb]
    // 0xdd6ae4: LoadField: r1 = r2->field_f
    //     0xdd6ae4: ldur            w1, [x2, #0xf]
    // 0xdd6ae8: DecompressPointer r1
    //     0xdd6ae8: add             x1, x1, HEAP, lsl #32
    // 0xdd6aec: ldur            x0, [fp, #-0x30]
    // 0xdd6af0: ArrayStore: r1[r3] = r0  ; List_4
    //     0xdd6af0: add             x25, x1, x3, lsl #2
    //     0xdd6af4: add             x25, x25, #0xf
    //     0xdd6af8: str             w0, [x25]
    //     0xdd6afc: tbz             w0, #0, #0xdd6b18
    //     0xdd6b00: ldurb           w16, [x1, #-1]
    //     0xdd6b04: ldurb           w17, [x0, #-1]
    //     0xdd6b08: and             x16, x17, x16, lsr #2
    //     0xdd6b0c: tst             x16, HEAP, lsr #32
    //     0xdd6b10: b.eq            #0xdd6b18
    //     0xdd6b14: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdd6b18: b               #0xdd6b20
    // 0xdd6b1c: mov             x2, x1
    // 0xdd6b20: ldur            x3, [fp, #-8]
    // 0xdd6b24: ldur            x1, [fp, #-0x18]
    // 0xdd6b28: ldur            x0, [fp, #-0x10]
    // 0xdd6b2c: r0 = EdgeInsets()
    //     0xdd6b2c: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xdd6b30: d0 = 5.000000
    //     0xdd6b30: fmov            d0, #5.00000000
    // 0xdd6b34: stur            x0, [fp, #-0x40]
    // 0xdd6b38: StoreField: r0->field_7 = d0
    //     0xdd6b38: stur            d0, [x0, #7]
    // 0xdd6b3c: StoreField: r0->field_f = rZR
    //     0xdd6b3c: stur            xzr, [x0, #0xf]
    // 0xdd6b40: ArrayStore: r0[0] = d0  ; List_8
    //     0xdd6b40: stur            d0, [x0, #0x17]
    // 0xdd6b44: StoreField: r0->field_1f = rZR
    //     0xdd6b44: stur            xzr, [x0, #0x1f]
    // 0xdd6b48: ldur            x2, [fp, #-8]
    // 0xdd6b4c: LoadField: r1 = r2->field_57
    //     0xdd6b4c: ldur            w1, [x2, #0x57]
    // 0xdd6b50: DecompressPointer r1
    //     0xdd6b50: add             x1, x1, HEAP, lsl #32
    // 0xdd6b54: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd6b58: cmp             w1, w16
    // 0xdd6b5c: b.eq            #0xdd6e60
    // 0xdd6b60: LoadField: r3 = r1->field_27
    //     0xdd6b60: ldur            w3, [x1, #0x27]
    // 0xdd6b64: DecompressPointer r3
    //     0xdd6b64: add             x3, x3, HEAP, lsl #32
    // 0xdd6b68: LoadField: r1 = r3->field_1b
    //     0xdd6b68: ldur            w1, [x3, #0x1b]
    // 0xdd6b6c: DecompressPointer r1
    //     0xdd6b6c: add             x1, x1, HEAP, lsl #32
    // 0xdd6b70: stur            x1, [fp, #-0x30]
    // 0xdd6b74: r0 = CenterPlayButton()
    //     0xdd6b74: bl              #0xdd33a8  ; AllocateCenterPlayButtonStub -> CenterPlayButton (size=0x24)
    // 0xdd6b78: mov             x3, x0
    // 0xdd6b7c: r0 = Instance_Color
    //     0xdd6b7c: add             x0, PP, #0x12, lsl #12  ; [pp+0x12c78] Obj!Color@12a1741
    //     0xdd6b80: ldr             x0, [x0, #0xc78]
    // 0xdd6b84: stur            x3, [fp, #-0x48]
    // 0xdd6b88: StoreField: r3->field_b = r0
    //     0xdd6b88: stur            w0, [x3, #0xb]
    // 0xdd6b8c: r4 = Instance_Color
    //     0xdd6b8c: add             x4, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0xdd6b90: ldr             x4, [x4, #0xc38]
    // 0xdd6b94: StoreField: r3->field_f = r4
    //     0xdd6b94: stur            w4, [x3, #0xf]
    // 0xdd6b98: ldur            x5, [fp, #-0x10]
    // 0xdd6b9c: StoreField: r3->field_13 = r5
    //     0xdd6b9c: stur            w5, [x3, #0x13]
    // 0xdd6ba0: ldur            x1, [fp, #-0x30]
    // 0xdd6ba4: ArrayStore: r3[0] = r1  ; List_4
    //     0xdd6ba4: stur            w1, [x3, #0x17]
    // 0xdd6ba8: ldur            x6, [fp, #-0x18]
    // 0xdd6bac: StoreField: r3->field_1b = r6
    //     0xdd6bac: stur            w6, [x3, #0x1b]
    // 0xdd6bb0: ldur            x2, [fp, #-8]
    // 0xdd6bb4: r1 = Function '_playPause@451269912':.
    //     0xdd6bb4: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3f50] AnonymousClosure: (0xdd7430), in [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_playPause (0xdd6f8c)
    //     0xdd6bb8: ldr             x1, [x1, #0xf50]
    // 0xdd6bbc: r0 = AllocateClosure()
    //     0xdd6bbc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd6bc0: mov             x1, x0
    // 0xdd6bc4: ldur            x0, [fp, #-0x48]
    // 0xdd6bc8: StoreField: r0->field_1f = r1
    //     0xdd6bc8: stur            w1, [x0, #0x1f]
    // 0xdd6bcc: r0 = Container()
    //     0xdd6bcc: bl              #0x8a5af8  ; AllocateContainerStub -> Container (size=0x38)
    // 0xdd6bd0: stur            x0, [fp, #-0x30]
    // 0xdd6bd4: ldur            x16, [fp, #-0x40]
    // 0xdd6bd8: ldur            lr, [fp, #-0x48]
    // 0xdd6bdc: stp             lr, x16, [SP]
    // 0xdd6be0: mov             x1, x0
    // 0xdd6be4: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, margin, 0x1, null]
    //     0xdd6be4: add             x4, PP, #0x16, lsl #12  ; [pp+0x16e78] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "margin", 0x1, Null]
    //     0xdd6be8: ldr             x4, [x4, #0xe78]
    // 0xdd6bec: r0 = Container()
    //     0xdd6bec: bl              #0x8a54e0  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0xdd6bf0: ldur            x0, [fp, #-0x28]
    // 0xdd6bf4: LoadField: r1 = r0->field_b
    //     0xdd6bf4: ldur            w1, [x0, #0xb]
    // 0xdd6bf8: LoadField: r2 = r0->field_f
    //     0xdd6bf8: ldur            w2, [x0, #0xf]
    // 0xdd6bfc: DecompressPointer r2
    //     0xdd6bfc: add             x2, x2, HEAP, lsl #32
    // 0xdd6c00: LoadField: r3 = r2->field_b
    //     0xdd6c00: ldur            w3, [x2, #0xb]
    // 0xdd6c04: r2 = LoadInt32Instr(r1)
    //     0xdd6c04: sbfx            x2, x1, #1, #0x1f
    // 0xdd6c08: stur            x2, [fp, #-0x38]
    // 0xdd6c0c: r1 = LoadInt32Instr(r3)
    //     0xdd6c0c: sbfx            x1, x3, #1, #0x1f
    // 0xdd6c10: cmp             x2, x1
    // 0xdd6c14: b.ne            #0xdd6c20
    // 0xdd6c18: mov             x1, x0
    // 0xdd6c1c: r0 = _growToNextCapacity()
    //     0xdd6c1c: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xdd6c20: ldur            x4, [fp, #-0x18]
    // 0xdd6c24: ldur            x2, [fp, #-0x28]
    // 0xdd6c28: ldur            x3, [fp, #-0x38]
    // 0xdd6c2c: add             x5, x3, #1
    // 0xdd6c30: stur            x5, [fp, #-0x50]
    // 0xdd6c34: lsl             x0, x5, #1
    // 0xdd6c38: StoreField: r2->field_b = r0
    //     0xdd6c38: stur            w0, [x2, #0xb]
    // 0xdd6c3c: LoadField: r6 = r2->field_f
    //     0xdd6c3c: ldur            w6, [x2, #0xf]
    // 0xdd6c40: DecompressPointer r6
    //     0xdd6c40: add             x6, x6, HEAP, lsl #32
    // 0xdd6c44: mov             x1, x6
    // 0xdd6c48: ldur            x0, [fp, #-0x30]
    // 0xdd6c4c: stur            x6, [fp, #-0x40]
    // 0xdd6c50: ArrayStore: r1[r3] = r0  ; List_4
    //     0xdd6c50: add             x25, x1, x3, lsl #2
    //     0xdd6c54: add             x25, x25, #0xf
    //     0xdd6c58: str             w0, [x25]
    //     0xdd6c5c: tbz             w0, #0, #0xdd6c78
    //     0xdd6c60: ldurb           w16, [x1, #-1]
    //     0xdd6c64: ldurb           w17, [x0, #-1]
    //     0xdd6c68: and             x16, x17, x16, lsr #2
    //     0xdd6c6c: tst             x16, HEAP, lsr #32
    //     0xdd6c70: b.eq            #0xdd6c78
    //     0xdd6c74: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdd6c78: tbz             w4, #4, #0xdd6d64
    // 0xdd6c7c: ldur            x1, [fp, #-8]
    // 0xdd6c80: ldur            x0, [fp, #-0x10]
    // 0xdd6c84: LoadField: r3 = r1->field_5b
    //     0xdd6c84: ldur            w3, [x1, #0x5b]
    // 0xdd6c88: DecompressPointer r3
    //     0xdd6c88: add             x3, x3, HEAP, lsl #32
    // 0xdd6c8c: cmp             w3, NULL
    // 0xdd6c90: b.eq            #0xdd6e6c
    // 0xdd6c94: r0 = CenterSeekButton()
    //     0xdd6c94: bl              #0xdd6e70  ; AllocateCenterSeekButtonStub -> CenterSeekButton (size=0x2c)
    // 0xdd6c98: mov             x3, x0
    // 0xdd6c9c: r0 = Instance_IconData
    //     0xdd6c9c: add             x0, PP, #0xd3, lsl #12  ; [pp+0xd3f58] Obj!IconData@128a771
    //     0xdd6ca0: ldr             x0, [x0, #0xf58]
    // 0xdd6ca4: stur            x3, [fp, #-0x18]
    // 0xdd6ca8: StoreField: r3->field_b = r0
    //     0xdd6ca8: stur            w0, [x3, #0xb]
    // 0xdd6cac: r0 = Instance_Color
    //     0xdd6cac: add             x0, PP, #0x12, lsl #12  ; [pp+0x12c78] Obj!Color@12a1741
    //     0xdd6cb0: ldr             x0, [x0, #0xc78]
    // 0xdd6cb4: StoreField: r3->field_f = r0
    //     0xdd6cb4: stur            w0, [x3, #0xf]
    // 0xdd6cb8: r0 = Instance_Color
    //     0xdd6cb8: add             x0, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0xdd6cbc: ldr             x0, [x0, #0xc38]
    // 0xdd6cc0: StoreField: r3->field_13 = r0
    //     0xdd6cc0: stur            w0, [x3, #0x13]
    // 0xdd6cc4: ldur            x0, [fp, #-0x10]
    // 0xdd6cc8: ArrayStore: r3[0] = r0  ; List_4
    //     0xdd6cc8: stur            w0, [x3, #0x17]
    // 0xdd6ccc: r0 = Instance_Duration
    //     0xdd6ccc: ldr             x0, [PP, #0x7cd8]  ; [pp+0x7cd8] Obj!Duration@12c8971
    // 0xdd6cd0: StoreField: r3->field_1f = r0
    //     0xdd6cd0: stur            w0, [x3, #0x1f]
    // 0xdd6cd4: d0 = 26.000000
    //     0xdd6cd4: fmov            d0, #26.00000000
    // 0xdd6cd8: StoreField: r3->field_23 = d0
    //     0xdd6cd8: stur            d0, [x3, #0x23]
    // 0xdd6cdc: ldur            x2, [fp, #-8]
    // 0xdd6ce0: r1 = Function '_seekForward@451269912':.
    //     0xdd6ce0: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3f60] AnonymousClosure: (0xdd7280), in [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_seekForward (0xdd72b8)
    //     0xdd6ce4: ldr             x1, [x1, #0xf60]
    // 0xdd6ce8: r0 = AllocateClosure()
    //     0xdd6ce8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd6cec: mov             x1, x0
    // 0xdd6cf0: ldur            x0, [fp, #-0x18]
    // 0xdd6cf4: StoreField: r0->field_1b = r1
    //     0xdd6cf4: stur            w1, [x0, #0x1b]
    // 0xdd6cf8: ldur            x1, [fp, #-0x40]
    // 0xdd6cfc: LoadField: r2 = r1->field_b
    //     0xdd6cfc: ldur            w2, [x1, #0xb]
    // 0xdd6d00: r1 = LoadInt32Instr(r2)
    //     0xdd6d00: sbfx            x1, x2, #1, #0x1f
    // 0xdd6d04: ldur            x2, [fp, #-0x50]
    // 0xdd6d08: cmp             x2, x1
    // 0xdd6d0c: b.ne            #0xdd6d18
    // 0xdd6d10: ldur            x1, [fp, #-0x28]
    // 0xdd6d14: r0 = _growToNextCapacity()
    //     0xdd6d14: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xdd6d18: ldur            x3, [fp, #-0x28]
    // 0xdd6d1c: ldur            x2, [fp, #-0x50]
    // 0xdd6d20: add             x0, x2, #1
    // 0xdd6d24: lsl             x1, x0, #1
    // 0xdd6d28: StoreField: r3->field_b = r1
    //     0xdd6d28: stur            w1, [x3, #0xb]
    // 0xdd6d2c: LoadField: r1 = r3->field_f
    //     0xdd6d2c: ldur            w1, [x3, #0xf]
    // 0xdd6d30: DecompressPointer r1
    //     0xdd6d30: add             x1, x1, HEAP, lsl #32
    // 0xdd6d34: ldur            x0, [fp, #-0x18]
    // 0xdd6d38: ArrayStore: r1[r2] = r0  ; List_4
    //     0xdd6d38: add             x25, x1, x2, lsl #2
    //     0xdd6d3c: add             x25, x25, #0xf
    //     0xdd6d40: str             w0, [x25]
    //     0xdd6d44: tbz             w0, #0, #0xdd6d60
    //     0xdd6d48: ldurb           w16, [x1, #-1]
    //     0xdd6d4c: ldurb           w17, [x0, #-1]
    //     0xdd6d50: and             x16, x17, x16, lsr #2
    //     0xdd6d54: tst             x16, HEAP, lsr #32
    //     0xdd6d58: b.eq            #0xdd6d60
    //     0xdd6d5c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdd6d60: b               #0xdd6d68
    // 0xdd6d64: mov             x3, x2
    // 0xdd6d68: r0 = Row()
    //     0xdd6d68: bl              #0x8a5b04  ; AllocateRowStub -> Row (size=0x38)
    // 0xdd6d6c: mov             x1, x0
    // 0xdd6d70: r0 = Instance_Axis
    //     0xdd6d70: ldr             x0, [PP, #0x49c8]  ; [pp+0x49c8] Obj!Axis@12c4a61
    // 0xdd6d74: stur            x1, [fp, #-8]
    // 0xdd6d78: StoreField: r1->field_f = r0
    //     0xdd6d78: stur            w0, [x1, #0xf]
    // 0xdd6d7c: r0 = Instance_MainAxisAlignment
    //     0xdd6d7c: add             x0, PP, #0x18, lsl #12  ; [pp+0x180f0] Obj!MainAxisAlignment@12c4581
    //     0xdd6d80: ldr             x0, [x0, #0xf0]
    // 0xdd6d84: StoreField: r1->field_13 = r0
    //     0xdd6d84: stur            w0, [x1, #0x13]
    // 0xdd6d88: r0 = Instance_MainAxisSize
    //     0xdd6d88: add             x0, PP, #0x15, lsl #12  ; [pp+0x15828] Obj!MainAxisSize@12c4621
    //     0xdd6d8c: ldr             x0, [x0, #0x828]
    // 0xdd6d90: ArrayStore: r1[0] = r0  ; List_4
    //     0xdd6d90: stur            w0, [x1, #0x17]
    // 0xdd6d94: r0 = Instance_CrossAxisAlignment
    //     0xdd6d94: add             x0, PP, #0x15, lsl #12  ; [pp+0x15888] Obj!CrossAxisAlignment@12c44a1
    //     0xdd6d98: ldr             x0, [x0, #0x888]
    // 0xdd6d9c: StoreField: r1->field_1b = r0
    //     0xdd6d9c: stur            w0, [x1, #0x1b]
    // 0xdd6da0: r0 = Instance_VerticalDirection
    //     0xdd6da0: add             x0, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xdd6da4: ldr             x0, [x0, #0x838]
    // 0xdd6da8: StoreField: r1->field_23 = r0
    //     0xdd6da8: stur            w0, [x1, #0x23]
    // 0xdd6dac: r0 = Instance_Clip
    //     0xdd6dac: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xdd6db0: ldr             x0, [x0, #0x840]
    // 0xdd6db4: StoreField: r1->field_2b = r0
    //     0xdd6db4: stur            w0, [x1, #0x2b]
    // 0xdd6db8: StoreField: r1->field_2f = rZR
    //     0xdd6db8: stur            xzr, [x1, #0x2f]
    // 0xdd6dbc: ldur            x0, [fp, #-0x28]
    // 0xdd6dc0: StoreField: r1->field_b = r0
    //     0xdd6dc0: stur            w0, [x1, #0xb]
    // 0xdd6dc4: r0 = Container()
    //     0xdd6dc4: bl              #0x8a5af8  ; AllocateContainerStub -> Container (size=0x38)
    // 0xdd6dc8: stur            x0, [fp, #-0x10]
    // 0xdd6dcc: r16 = Instance_Alignment
    //     0xdd6dcc: add             x16, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xdd6dd0: ldr             x16, [x16, #0xb80]
    // 0xdd6dd4: r30 = Instance_Color
    //     0xdd6dd4: add             lr, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xdd6dd8: ldr             lr, [lr, #0x810]
    // 0xdd6ddc: stp             lr, x16, [SP, #8]
    // 0xdd6de0: ldur            x16, [fp, #-8]
    // 0xdd6de4: str             x16, [SP]
    // 0xdd6de8: mov             x1, x0
    // 0xdd6dec: r4 = const [0, 0x4, 0x3, 0x1, alignment, 0x1, child, 0x3, color, 0x2, null]
    //     0xdd6dec: add             x4, PP, #0xcf, lsl #12  ; [pp+0xcf770] List(11) [0, 0x4, 0x3, 0x1, "alignment", 0x1, "child", 0x3, "color", 0x2, Null]
    //     0xdd6df0: ldr             x4, [x4, #0x770]
    // 0xdd6df4: r0 = Container()
    //     0xdd6df4: bl              #0x8a54e0  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0xdd6df8: r0 = GestureDetector()
    //     0xdd6df8: bl              #0x918e18  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0xdd6dfc: ldur            x2, [fp, #-0x20]
    // 0xdd6e00: r1 = Function '<anonymous closure>':.
    //     0xdd6e00: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3f68] AnonymousClosure: (0xdd6e7c), in [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_buildHitArea (0xdd6924)
    //     0xdd6e04: ldr             x1, [x1, #0xf68]
    // 0xdd6e08: stur            x0, [fp, #-8]
    // 0xdd6e0c: r0 = AllocateClosure()
    //     0xdd6e0c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd6e10: ldur            x16, [fp, #-0x10]
    // 0xdd6e14: stp             x16, x0, [SP]
    // 0xdd6e18: ldur            x1, [fp, #-8]
    // 0xdd6e1c: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0xdd6e1c: add             x4, PP, #0x16, lsl #12  ; [pp+0x16e90] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0xdd6e20: ldr             x4, [x4, #0xe90]
    // 0xdd6e24: r0 = GestureDetector()
    //     0xdd6e24: bl              #0x9182dc  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0xdd6e28: ldur            x0, [fp, #-8]
    // 0xdd6e2c: LeaveFrame
    //     0xdd6e2c: mov             SP, fp
    //     0xdd6e30: ldp             fp, lr, [SP], #0x10
    // 0xdd6e34: ret
    //     0xdd6e34: ret             
    // 0xdd6e38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd6e38: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd6e3c: b               #0xdd6944
    // 0xdd6e40: r9 = _latestValue
    //     0xdd6e40: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3eb0] Field <_MaterialControlsState@451269912._latestValue@451269912>: late (offset: 0x20)
    //     0xdd6e44: ldr             x9, [x9, #0xeb0]
    // 0xdd6e48: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd6e48: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdd6e4c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd6e4c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdd6e50: r9 = notifier
    //     0xdd6e50: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3e80] Field <_MaterialControlsState@451269912.notifier>: late (offset: 0x1c)
    //     0xdd6e54: ldr             x9, [x9, #0xe80]
    // 0xdd6e58: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd6e58: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdd6e5c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd6e5c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdd6e60: r9 = controller
    //     0xdd6e60: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3e70] Field <_MaterialControlsState@451269912.controller>: late (offset: 0x58)
    //     0xdd6e64: ldr             x9, [x9, #0xe70]
    // 0xdd6e68: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd6e68: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdd6e6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd6e6c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xdd6e7c, size: 0x110
    // 0xdd6e7c: EnterFrame
    //     0xdd6e7c: stp             fp, lr, [SP, #-0x10]!
    //     0xdd6e80: mov             fp, SP
    // 0xdd6e84: AllocStack(0x10)
    //     0xdd6e84: sub             SP, SP, #0x10
    // 0xdd6e88: SetupParameters([dynamic _ /* r0 */])
    //     0xdd6e88: ldr             x0, [fp, #0x10]
    //     0xdd6e8c: ldur            w2, [x0, #0x17]
    //     0xdd6e90: add             x2, x2, HEAP, lsl #32
    //     0xdd6e94: stur            x2, [fp, #-0x10]
    // 0xdd6e98: CheckStackOverflow
    //     0xdd6e98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd6e9c: cmp             SP, x16
    //     0xdd6ea0: b.ls            #0xdd6f78
    // 0xdd6ea4: LoadField: r0 = r2->field_f
    //     0xdd6ea4: ldur            w0, [x2, #0xf]
    // 0xdd6ea8: DecompressPointer r0
    //     0xdd6ea8: add             x0, x0, HEAP, lsl #32
    // 0xdd6eac: stur            x0, [fp, #-8]
    // 0xdd6eb0: LoadField: r1 = r0->field_1f
    //     0xdd6eb0: ldur            w1, [x0, #0x1f]
    // 0xdd6eb4: DecompressPointer r1
    //     0xdd6eb4: add             x1, x1, HEAP, lsl #32
    // 0xdd6eb8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd6ebc: cmp             w1, w16
    // 0xdd6ec0: b.eq            #0xdd6f80
    // 0xdd6ec4: LoadField: r3 = r1->field_1b
    //     0xdd6ec4: ldur            w3, [x1, #0x1b]
    // 0xdd6ec8: DecompressPointer r3
    //     0xdd6ec8: add             x3, x3, HEAP, lsl #32
    // 0xdd6ecc: tbnz            w3, #4, #0xdd6f2c
    // 0xdd6ed0: LoadField: r1 = r0->field_5b
    //     0xdd6ed0: ldur            w1, [x0, #0x5b]
    // 0xdd6ed4: DecompressPointer r1
    //     0xdd6ed4: add             x1, x1, HEAP, lsl #32
    // 0xdd6ed8: cmp             w1, NULL
    // 0xdd6edc: b.ne            #0xdd6ee8
    // 0xdd6ee0: r1 = Null
    //     0xdd6ee0: mov             x1, NULL
    // 0xdd6ee4: b               #0xdd6eec
    // 0xdd6ee8: r1 = false
    //     0xdd6ee8: add             x1, NULL, #0x30  ; false
    // 0xdd6eec: cmp             w1, NULL
    // 0xdd6ef0: b.eq            #0xdd6ef8
    // 0xdd6ef4: tbz             w1, #4, #0xdd6f6c
    // 0xdd6ef8: LoadField: r1 = r0->field_3b
    //     0xdd6ef8: ldur            w1, [x0, #0x3b]
    // 0xdd6efc: DecompressPointer r1
    //     0xdd6efc: add             x1, x1, HEAP, lsl #32
    // 0xdd6f00: tbnz            w1, #4, #0xdd6f20
    // 0xdd6f04: r1 = Function '<anonymous closure>':.
    //     0xdd6f04: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3f70] AnonymousClosure: (0xdd4a74), in [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_startHideTimer (0xdd4954)
    //     0xdd6f08: ldr             x1, [x1, #0xf70]
    // 0xdd6f0c: r0 = AllocateClosure()
    //     0xdd6f0c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd6f10: ldur            x1, [fp, #-8]
    // 0xdd6f14: mov             x2, x0
    // 0xdd6f18: r0 = setState()
    //     0xdd6f18: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xdd6f1c: b               #0xdd6f5c
    // 0xdd6f20: ldur            x1, [fp, #-8]
    // 0xdd6f24: r0 = _cancelAndRestartTimer()
    //     0xdd6f24: bl              #0xdd4f28  ; [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_cancelAndRestartTimer
    // 0xdd6f28: b               #0xdd6f5c
    // 0xdd6f2c: ldur            x1, [fp, #-8]
    // 0xdd6f30: r0 = _playPause()
    //     0xdd6f30: bl              #0xdd6f8c  ; [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_playPause
    // 0xdd6f34: ldur            x2, [fp, #-0x10]
    // 0xdd6f38: LoadField: r0 = r2->field_f
    //     0xdd6f38: ldur            w0, [x2, #0xf]
    // 0xdd6f3c: DecompressPointer r0
    //     0xdd6f3c: add             x0, x0, HEAP, lsl #32
    // 0xdd6f40: stur            x0, [fp, #-8]
    // 0xdd6f44: r1 = Function '<anonymous closure>':.
    //     0xdd6f44: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3f78] AnonymousClosure: (0xdd4a74), in [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_startHideTimer (0xdd4954)
    //     0xdd6f48: ldr             x1, [x1, #0xf78]
    // 0xdd6f4c: r0 = AllocateClosure()
    //     0xdd6f4c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd6f50: ldur            x1, [fp, #-8]
    // 0xdd6f54: mov             x2, x0
    // 0xdd6f58: r0 = setState()
    //     0xdd6f58: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xdd6f5c: r0 = Null
    //     0xdd6f5c: mov             x0, NULL
    // 0xdd6f60: LeaveFrame
    //     0xdd6f60: mov             SP, fp
    //     0xdd6f64: ldp             fp, lr, [SP], #0x10
    // 0xdd6f68: ret
    //     0xdd6f68: ret             
    // 0xdd6f6c: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xdd6f6c: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xdd6f70: r0 = Throw()
    //     0xdd6f70: bl              #0x13ddb2c  ; ThrowStub
    // 0xdd6f74: brk             #0
    // 0xdd6f78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd6f78: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd6f7c: b               #0xdd6ea4
    // 0xdd6f80: r9 = _latestValue
    //     0xdd6f80: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3eb0] Field <_MaterialControlsState@451269912._latestValue@451269912>: late (offset: 0x20)
    //     0xdd6f84: ldr             x9, [x9, #0xeb0]
    // 0xdd6f88: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd6f88: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _playPause(/* No info */) {
    // ** addr: 0xdd6f8c, size: 0xcc
    // 0xdd6f8c: EnterFrame
    //     0xdd6f8c: stp             fp, lr, [SP, #-0x10]!
    //     0xdd6f90: mov             fp, SP
    // 0xdd6f94: AllocStack(0x8)
    //     0xdd6f94: sub             SP, SP, #8
    // 0xdd6f98: SetupParameters(_MaterialControlsState this /* r1 => r1, fp-0x8 */)
    //     0xdd6f98: stur            x1, [fp, #-8]
    // 0xdd6f9c: CheckStackOverflow
    //     0xdd6f9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd6fa0: cmp             SP, x16
    //     0xdd6fa4: b.ls            #0xdd7044
    // 0xdd6fa8: r1 = 2
    //     0xdd6fa8: mov             x1, #2
    // 0xdd6fac: r0 = AllocateContext()
    //     0xdd6fac: bl              #0x13de838  ; AllocateContextStub
    // 0xdd6fb0: mov             x1, x0
    // 0xdd6fb4: ldur            x0, [fp, #-8]
    // 0xdd6fb8: StoreField: r1->field_f = r0
    //     0xdd6fb8: stur            w0, [x1, #0xf]
    // 0xdd6fbc: LoadField: r2 = r0->field_1f
    //     0xdd6fbc: ldur            w2, [x0, #0x1f]
    // 0xdd6fc0: DecompressPointer r2
    //     0xdd6fc0: add             x2, x2, HEAP, lsl #32
    // 0xdd6fc4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd6fc8: cmp             w2, w16
    // 0xdd6fcc: b.eq            #0xdd704c
    // 0xdd6fd0: LoadField: r3 = r2->field_b
    //     0xdd6fd0: ldur            w3, [x2, #0xb]
    // 0xdd6fd4: DecompressPointer r3
    //     0xdd6fd4: add             x3, x3, HEAP, lsl #32
    // 0xdd6fd8: LoadField: r4 = r2->field_7
    //     0xdd6fd8: ldur            w4, [x2, #7]
    // 0xdd6fdc: DecompressPointer r4
    //     0xdd6fdc: add             x4, x4, HEAP, lsl #32
    // 0xdd6fe0: LoadField: r2 = r3->field_7
    //     0xdd6fe0: ldur            x2, [x3, #7]
    // 0xdd6fe4: LoadField: r3 = r4->field_7
    //     0xdd6fe4: ldur            x3, [x4, #7]
    // 0xdd6fe8: cmp             x2, x3
    // 0xdd6fec: b.lt            #0xdd7010
    // 0xdd6ff0: r2 = 1000000
    //     0xdd6ff0: mov             x2, #0x4240
    //     0xdd6ff4: movk            x2, #0xf, lsl #16
    // 0xdd6ff8: sdiv            x4, x3, x2
    // 0xdd6ffc: cmp             x4, #0
    // 0xdd7000: r16 = true
    //     0xdd7000: add             x16, NULL, #0x20  ; true
    // 0xdd7004: r17 = false
    //     0xdd7004: add             x17, NULL, #0x30  ; false
    // 0xdd7008: csel            x2, x16, x17, gt
    // 0xdd700c: b               #0xdd7014
    // 0xdd7010: r2 = false
    //     0xdd7010: add             x2, NULL, #0x30  ; false
    // 0xdd7014: StoreField: r1->field_13 = r2
    //     0xdd7014: stur            w2, [x1, #0x13]
    // 0xdd7018: mov             x2, x1
    // 0xdd701c: r1 = Function '<anonymous closure>':.
    //     0xdd701c: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3f80] AnonymousClosure: (0xdd7058), in [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_playPause (0xdd6f8c)
    //     0xdd7020: ldr             x1, [x1, #0xf80]
    // 0xdd7024: r0 = AllocateClosure()
    //     0xdd7024: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd7028: ldur            x1, [fp, #-8]
    // 0xdd702c: mov             x2, x0
    // 0xdd7030: r0 = setState()
    //     0xdd7030: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xdd7034: r0 = Null
    //     0xdd7034: mov             x0, NULL
    // 0xdd7038: LeaveFrame
    //     0xdd7038: mov             SP, fp
    //     0xdd703c: ldp             fp, lr, [SP], #0x10
    // 0xdd7040: ret
    //     0xdd7040: ret             
    // 0xdd7044: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd7044: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd7048: b               #0xdd6fa8
    // 0xdd704c: r9 = _latestValue
    //     0xdd704c: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3eb0] Field <_MaterialControlsState@451269912._latestValue@451269912>: late (offset: 0x20)
    //     0xdd7050: ldr             x9, [x9, #0xeb0]
    // 0xdd7054: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd7054: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xdd7058, size: 0x1c4
    // 0xdd7058: EnterFrame
    //     0xdd7058: stp             fp, lr, [SP, #-0x10]!
    //     0xdd705c: mov             fp, SP
    // 0xdd7060: AllocStack(0x28)
    //     0xdd7060: sub             SP, SP, #0x28
    // 0xdd7064: SetupParameters([dynamic _ /* r0 */])
    //     0xdd7064: ldr             x0, [fp, #0x10]
    //     0xdd7068: ldur            w2, [x0, #0x17]
    //     0xdd706c: add             x2, x2, HEAP, lsl #32
    //     0xdd7070: stur            x2, [fp, #-8]
    // 0xdd7074: CheckStackOverflow
    //     0xdd7074: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd7078: cmp             SP, x16
    //     0xdd707c: b.ls            #0xdd71d8
    // 0xdd7080: LoadField: r1 = r2->field_f
    //     0xdd7080: ldur            w1, [x2, #0xf]
    // 0xdd7084: DecompressPointer r1
    //     0xdd7084: add             x1, x1, HEAP, lsl #32
    // 0xdd7088: LoadField: r0 = r1->field_57
    //     0xdd7088: ldur            w0, [x1, #0x57]
    // 0xdd708c: DecompressPointer r0
    //     0xdd708c: add             x0, x0, HEAP, lsl #32
    // 0xdd7090: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd7094: cmp             w0, w16
    // 0xdd7098: b.eq            #0xdd71e0
    // 0xdd709c: LoadField: r3 = r0->field_27
    //     0xdd709c: ldur            w3, [x0, #0x27]
    // 0xdd70a0: DecompressPointer r3
    //     0xdd70a0: add             x3, x3, HEAP, lsl #32
    // 0xdd70a4: LoadField: r0 = r3->field_1b
    //     0xdd70a4: ldur            w0, [x3, #0x1b]
    // 0xdd70a8: DecompressPointer r0
    //     0xdd70a8: add             x0, x0, HEAP, lsl #32
    // 0xdd70ac: tbnz            w0, #4, #0xdd711c
    // 0xdd70b0: r0 = false
    //     0xdd70b0: add             x0, NULL, #0x30  ; false
    // 0xdd70b4: LoadField: r3 = r1->field_1b
    //     0xdd70b4: ldur            w3, [x1, #0x1b]
    // 0xdd70b8: DecompressPointer r3
    //     0xdd70b8: add             x3, x3, HEAP, lsl #32
    // 0xdd70bc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd70c0: cmp             w3, w16
    // 0xdd70c4: b.eq            #0xdd71ec
    // 0xdd70c8: StoreField: r3->field_23 = r0
    //     0xdd70c8: stur            w0, [x3, #0x23]
    // 0xdd70cc: mov             x1, x3
    // 0xdd70d0: r0 = notifyListeners()
    //     0xdd70d0: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xdd70d4: ldur            x2, [fp, #-8]
    // 0xdd70d8: LoadField: r0 = r2->field_f
    //     0xdd70d8: ldur            w0, [x2, #0xf]
    // 0xdd70dc: DecompressPointer r0
    //     0xdd70dc: add             x0, x0, HEAP, lsl #32
    // 0xdd70e0: LoadField: r1 = r0->field_27
    //     0xdd70e0: ldur            w1, [x0, #0x27]
    // 0xdd70e4: DecompressPointer r1
    //     0xdd70e4: add             x1, x1, HEAP, lsl #32
    // 0xdd70e8: cmp             w1, NULL
    // 0xdd70ec: b.eq            #0xdd70f8
    // 0xdd70f0: r0 = cancel()
    //     0xdd70f0: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0xdd70f4: ldur            x2, [fp, #-8]
    // 0xdd70f8: LoadField: r0 = r2->field_f
    //     0xdd70f8: ldur            w0, [x2, #0xf]
    // 0xdd70fc: DecompressPointer r0
    //     0xdd70fc: add             x0, x0, HEAP, lsl #32
    // 0xdd7100: LoadField: r1 = r0->field_57
    //     0xdd7100: ldur            w1, [x0, #0x57]
    // 0xdd7104: DecompressPointer r1
    //     0xdd7104: add             x1, x1, HEAP, lsl #32
    // 0xdd7108: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd710c: cmp             w1, w16
    // 0xdd7110: b.eq            #0xdd71f8
    // 0xdd7114: r0 = pause()
    //     0xdd7114: bl              #0x8d70ec  ; [package:video_player/video_player.dart] VideoPlayerController::pause
    // 0xdd7118: b               #0xdd71c8
    // 0xdd711c: r0 = _cancelAndRestartTimer()
    //     0xdd711c: bl              #0xdd4f28  ; [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_cancelAndRestartTimer
    // 0xdd7120: ldur            x2, [fp, #-8]
    // 0xdd7124: LoadField: r0 = r2->field_f
    //     0xdd7124: ldur            w0, [x2, #0xf]
    // 0xdd7128: DecompressPointer r0
    //     0xdd7128: add             x0, x0, HEAP, lsl #32
    // 0xdd712c: LoadField: r1 = r0->field_57
    //     0xdd712c: ldur            w1, [x0, #0x57]
    // 0xdd7130: DecompressPointer r1
    //     0xdd7130: add             x1, x1, HEAP, lsl #32
    // 0xdd7134: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd7138: cmp             w1, w16
    // 0xdd713c: b.eq            #0xdd7204
    // 0xdd7140: LoadField: r0 = r1->field_27
    //     0xdd7140: ldur            w0, [x1, #0x27]
    // 0xdd7144: DecompressPointer r0
    //     0xdd7144: add             x0, x0, HEAP, lsl #32
    // 0xdd7148: LoadField: r3 = r0->field_4f
    //     0xdd7148: ldur            w3, [x0, #0x4f]
    // 0xdd714c: DecompressPointer r3
    //     0xdd714c: add             x3, x3, HEAP, lsl #32
    // 0xdd7150: tbz             w3, #4, #0xdd7188
    // 0xdd7154: r0 = initialize()
    //     0xdd7154: bl              #0xdd1314  ; [package:video_player/video_player.dart] VideoPlayerController::initialize
    // 0xdd7158: ldur            x2, [fp, #-8]
    // 0xdd715c: r1 = Function '<anonymous closure>':.
    //     0xdd715c: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3f88] AnonymousClosure: (0xdd721c), in [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_playPause (0xdd6f8c)
    //     0xdd7160: ldr             x1, [x1, #0xf88]
    // 0xdd7164: stur            x0, [fp, #-0x10]
    // 0xdd7168: r0 = AllocateClosure()
    //     0xdd7168: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd716c: r16 = <Null?>
    //     0xdd716c: ldr             x16, [PP, #0x70]  ; [pp+0x70] TypeArguments: <Null?>
    // 0xdd7170: ldur            lr, [fp, #-0x10]
    // 0xdd7174: stp             lr, x16, [SP, #8]
    // 0xdd7178: str             x0, [SP]
    // 0xdd717c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xdd717c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xdd7180: r0 = then()
    //     0xdd7180: bl              #0x1293070  ; [dart:async] _Future::then
    // 0xdd7184: b               #0xdd71c8
    // 0xdd7188: mov             x0, x2
    // 0xdd718c: LoadField: r2 = r0->field_13
    //     0xdd718c: ldur            w2, [x0, #0x13]
    // 0xdd7190: DecompressPointer r2
    //     0xdd7190: add             x2, x2, HEAP, lsl #32
    // 0xdd7194: tbnz            w2, #4, #0xdd71a0
    // 0xdd7198: r2 = Instance_Duration
    //     0xdd7198: ldr             x2, [PP, #0x1808]  ; [pp+0x1808] Obj!Duration@12c8901
    // 0xdd719c: r0 = seekTo()
    //     0xdd719c: bl              #0x8d6e4c  ; [package:video_player/video_player.dart] VideoPlayerController::seekTo
    // 0xdd71a0: ldur            x0, [fp, #-8]
    // 0xdd71a4: LoadField: r1 = r0->field_f
    //     0xdd71a4: ldur            w1, [x0, #0xf]
    // 0xdd71a8: DecompressPointer r1
    //     0xdd71a8: add             x1, x1, HEAP, lsl #32
    // 0xdd71ac: LoadField: r0 = r1->field_57
    //     0xdd71ac: ldur            w0, [x1, #0x57]
    // 0xdd71b0: DecompressPointer r0
    //     0xdd71b0: add             x0, x0, HEAP, lsl #32
    // 0xdd71b4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd71b8: cmp             w0, w16
    // 0xdd71bc: b.eq            #0xdd7210
    // 0xdd71c0: mov             x1, x0
    // 0xdd71c4: r0 = play()
    //     0xdd71c4: bl              #0x8d57ac  ; [package:video_player/video_player.dart] VideoPlayerController::play
    // 0xdd71c8: r0 = Null
    //     0xdd71c8: mov             x0, NULL
    // 0xdd71cc: LeaveFrame
    //     0xdd71cc: mov             SP, fp
    //     0xdd71d0: ldp             fp, lr, [SP], #0x10
    // 0xdd71d4: ret
    //     0xdd71d4: ret             
    // 0xdd71d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd71d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd71dc: b               #0xdd7080
    // 0xdd71e0: r9 = controller
    //     0xdd71e0: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3e70] Field <_MaterialControlsState@451269912.controller>: late (offset: 0x58)
    //     0xdd71e4: ldr             x9, [x9, #0xe70]
    // 0xdd71e8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd71e8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdd71ec: r9 = notifier
    //     0xdd71ec: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3e80] Field <_MaterialControlsState@451269912.notifier>: late (offset: 0x1c)
    //     0xdd71f0: ldr             x9, [x9, #0xe80]
    // 0xdd71f4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd71f4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdd71f8: r9 = controller
    //     0xdd71f8: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3e70] Field <_MaterialControlsState@451269912.controller>: late (offset: 0x58)
    //     0xdd71fc: ldr             x9, [x9, #0xe70]
    // 0xdd7200: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd7200: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdd7204: r9 = controller
    //     0xdd7204: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3e70] Field <_MaterialControlsState@451269912.controller>: late (offset: 0x58)
    //     0xdd7208: ldr             x9, [x9, #0xe70]
    // 0xdd720c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd720c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdd7210: r9 = controller
    //     0xdd7210: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3e70] Field <_MaterialControlsState@451269912.controller>: late (offset: 0x58)
    //     0xdd7214: ldr             x9, [x9, #0xe70]
    // 0xdd7218: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd7218: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Null <anonymous closure>(dynamic, void) {
    // ** addr: 0xdd721c, size: 0x64
    // 0xdd721c: EnterFrame
    //     0xdd721c: stp             fp, lr, [SP, #-0x10]!
    //     0xdd7220: mov             fp, SP
    // 0xdd7224: ldr             x0, [fp, #0x18]
    // 0xdd7228: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdd7228: ldur            w1, [x0, #0x17]
    // 0xdd722c: DecompressPointer r1
    //     0xdd722c: add             x1, x1, HEAP, lsl #32
    // 0xdd7230: CheckStackOverflow
    //     0xdd7230: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd7234: cmp             SP, x16
    //     0xdd7238: b.ls            #0xdd726c
    // 0xdd723c: LoadField: r0 = r1->field_f
    //     0xdd723c: ldur            w0, [x1, #0xf]
    // 0xdd7240: DecompressPointer r0
    //     0xdd7240: add             x0, x0, HEAP, lsl #32
    // 0xdd7244: LoadField: r1 = r0->field_57
    //     0xdd7244: ldur            w1, [x0, #0x57]
    // 0xdd7248: DecompressPointer r1
    //     0xdd7248: add             x1, x1, HEAP, lsl #32
    // 0xdd724c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd7250: cmp             w1, w16
    // 0xdd7254: b.eq            #0xdd7274
    // 0xdd7258: r0 = play()
    //     0xdd7258: bl              #0x8d57ac  ; [package:video_player/video_player.dart] VideoPlayerController::play
    // 0xdd725c: r0 = Null
    //     0xdd725c: mov             x0, NULL
    // 0xdd7260: LeaveFrame
    //     0xdd7260: mov             SP, fp
    //     0xdd7264: ldp             fp, lr, [SP], #0x10
    // 0xdd7268: ret
    //     0xdd7268: ret             
    // 0xdd726c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd726c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd7270: b               #0xdd723c
    // 0xdd7274: r9 = controller
    //     0xdd7274: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3e70] Field <_MaterialControlsState@451269912.controller>: late (offset: 0x58)
    //     0xdd7278: ldr             x9, [x9, #0xe70]
    // 0xdd727c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd727c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void _seekForward(dynamic) {
    // ** addr: 0xdd7280, size: 0x38
    // 0xdd7280: EnterFrame
    //     0xdd7280: stp             fp, lr, [SP, #-0x10]!
    //     0xdd7284: mov             fp, SP
    // 0xdd7288: ldr             x0, [fp, #0x10]
    // 0xdd728c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdd728c: ldur            w1, [x0, #0x17]
    // 0xdd7290: DecompressPointer r1
    //     0xdd7290: add             x1, x1, HEAP, lsl #32
    // 0xdd7294: CheckStackOverflow
    //     0xdd7294: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd7298: cmp             SP, x16
    //     0xdd729c: b.ls            #0xdd72b0
    // 0xdd72a0: r0 = _seekForward()
    //     0xdd72a0: bl              #0xdd72b8  ; [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_seekForward
    // 0xdd72a4: LeaveFrame
    //     0xdd72a4: mov             SP, fp
    //     0xdd72a8: ldp             fp, lr, [SP], #0x10
    // 0xdd72ac: ret
    //     0xdd72ac: ret             
    // 0xdd72b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd72b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd72b4: b               #0xdd72a0
  }
  _ _seekForward(/* No info */) {
    // ** addr: 0xdd72b8, size: 0x38
    // 0xdd72b8: EnterFrame
    //     0xdd72b8: stp             fp, lr, [SP, #-0x10]!
    //     0xdd72bc: mov             fp, SP
    // 0xdd72c0: CheckStackOverflow
    //     0xdd72c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd72c4: cmp             SP, x16
    //     0xdd72c8: b.ls            #0xdd72e8
    // 0xdd72cc: r2 = Instance_Duration
    //     0xdd72cc: add             x2, PP, #0x94, lsl #12  ; [pp+0x94f70] Obj!Duration@12c8b21
    //     0xdd72d0: ldr             x2, [x2, #0xf70]
    // 0xdd72d4: r0 = _seekRelative()
    //     0xdd72d4: bl              #0xdd72f0  ; [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_seekRelative
    // 0xdd72d8: r0 = Null
    //     0xdd72d8: mov             x0, NULL
    // 0xdd72dc: LeaveFrame
    //     0xdd72dc: mov             SP, fp
    //     0xdd72e0: ldp             fp, lr, [SP], #0x10
    // 0xdd72e4: ret
    //     0xdd72e4: ret             
    // 0xdd72e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd72e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd72ec: b               #0xdd72cc
  }
  _ _seekRelative(/* No info */) {
    // ** addr: 0xdd72f0, size: 0x140
    // 0xdd72f0: EnterFrame
    //     0xdd72f0: stp             fp, lr, [SP, #-0x10]!
    //     0xdd72f4: mov             fp, SP
    // 0xdd72f8: AllocStack(0x20)
    //     0xdd72f8: sub             SP, SP, #0x20
    // 0xdd72fc: SetupParameters(_MaterialControlsState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xdd72fc: mov             x0, x1
    //     0xdd7300: stur            x1, [fp, #-8]
    //     0xdd7304: stur            x2, [fp, #-0x10]
    // 0xdd7308: CheckStackOverflow
    //     0xdd7308: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd730c: cmp             SP, x16
    //     0xdd7310: b.ls            #0xdd73f8
    // 0xdd7314: mov             x1, x0
    // 0xdd7318: r0 = _cancelAndRestartTimer()
    //     0xdd7318: bl              #0xdd4f28  ; [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_cancelAndRestartTimer
    // 0xdd731c: ldur            x0, [fp, #-8]
    // 0xdd7320: LoadField: r1 = r0->field_1f
    //     0xdd7320: ldur            w1, [x0, #0x1f]
    // 0xdd7324: DecompressPointer r1
    //     0xdd7324: add             x1, x1, HEAP, lsl #32
    // 0xdd7328: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd732c: cmp             w1, w16
    // 0xdd7330: b.eq            #0xdd7400
    // 0xdd7334: stur            x1, [fp, #-0x20]
    // 0xdd7338: LoadField: r2 = r1->field_b
    //     0xdd7338: ldur            w2, [x1, #0xb]
    // 0xdd733c: DecompressPointer r2
    //     0xdd733c: add             x2, x2, HEAP, lsl #32
    // 0xdd7340: LoadField: r3 = r2->field_7
    //     0xdd7340: ldur            x3, [x2, #7]
    // 0xdd7344: ldur            x2, [fp, #-0x10]
    // 0xdd7348: LoadField: r4 = r2->field_7
    //     0xdd7348: ldur            x4, [x2, #7]
    // 0xdd734c: add             x2, x3, x4
    // 0xdd7350: stur            x2, [fp, #-0x18]
    // 0xdd7354: r0 = Duration()
    //     0xdd7354: bl              #0x7dd0d0  ; AllocateDurationStub -> Duration (size=0x10)
    // 0xdd7358: mov             x1, x0
    // 0xdd735c: ldur            x0, [fp, #-0x18]
    // 0xdd7360: StoreField: r1->field_7 = r0
    //     0xdd7360: stur            x0, [x1, #7]
    // 0xdd7364: ldur            x2, [fp, #-0x20]
    // 0xdd7368: LoadField: r3 = r2->field_7
    //     0xdd7368: ldur            w3, [x2, #7]
    // 0xdd736c: DecompressPointer r3
    //     0xdd736c: add             x3, x3, HEAP, lsl #32
    // 0xdd7370: tbz             x0, #0x3f, #0xdd7398
    // 0xdd7374: ldur            x2, [fp, #-8]
    // 0xdd7378: LoadField: r1 = r2->field_57
    //     0xdd7378: ldur            w1, [x2, #0x57]
    // 0xdd737c: DecompressPointer r1
    //     0xdd737c: add             x1, x1, HEAP, lsl #32
    // 0xdd7380: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd7384: cmp             w1, w16
    // 0xdd7388: b.eq            #0xdd740c
    // 0xdd738c: r2 = Instance_Duration
    //     0xdd738c: ldr             x2, [PP, #0x1808]  ; [pp+0x1808] Obj!Duration@12c8901
    // 0xdd7390: r0 = seekTo()
    //     0xdd7390: bl              #0x8d6e4c  ; [package:video_player/video_player.dart] VideoPlayerController::seekTo
    // 0xdd7394: b               #0xdd73e8
    // 0xdd7398: ldur            x2, [fp, #-8]
    // 0xdd739c: LoadField: r4 = r3->field_7
    //     0xdd739c: ldur            x4, [x3, #7]
    // 0xdd73a0: cmp             x0, x4
    // 0xdd73a4: b.le            #0xdd73c8
    // 0xdd73a8: LoadField: r1 = r2->field_57
    //     0xdd73a8: ldur            w1, [x2, #0x57]
    // 0xdd73ac: DecompressPointer r1
    //     0xdd73ac: add             x1, x1, HEAP, lsl #32
    // 0xdd73b0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd73b4: cmp             w1, w16
    // 0xdd73b8: b.eq            #0xdd7418
    // 0xdd73bc: mov             x2, x3
    // 0xdd73c0: r0 = seekTo()
    //     0xdd73c0: bl              #0x8d6e4c  ; [package:video_player/video_player.dart] VideoPlayerController::seekTo
    // 0xdd73c4: b               #0xdd73e8
    // 0xdd73c8: LoadField: r0 = r2->field_57
    //     0xdd73c8: ldur            w0, [x2, #0x57]
    // 0xdd73cc: DecompressPointer r0
    //     0xdd73cc: add             x0, x0, HEAP, lsl #32
    // 0xdd73d0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd73d4: cmp             w0, w16
    // 0xdd73d8: b.eq            #0xdd7424
    // 0xdd73dc: mov             x2, x1
    // 0xdd73e0: mov             x1, x0
    // 0xdd73e4: r0 = seekTo()
    //     0xdd73e4: bl              #0x8d6e4c  ; [package:video_player/video_player.dart] VideoPlayerController::seekTo
    // 0xdd73e8: r0 = Null
    //     0xdd73e8: mov             x0, NULL
    // 0xdd73ec: LeaveFrame
    //     0xdd73ec: mov             SP, fp
    //     0xdd73f0: ldp             fp, lr, [SP], #0x10
    // 0xdd73f4: ret
    //     0xdd73f4: ret             
    // 0xdd73f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd73f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd73fc: b               #0xdd7314
    // 0xdd7400: r9 = _latestValue
    //     0xdd7400: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3eb0] Field <_MaterialControlsState@451269912._latestValue@451269912>: late (offset: 0x20)
    //     0xdd7404: ldr             x9, [x9, #0xeb0]
    // 0xdd7408: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd7408: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdd740c: r9 = controller
    //     0xdd740c: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3e70] Field <_MaterialControlsState@451269912.controller>: late (offset: 0x58)
    //     0xdd7410: ldr             x9, [x9, #0xe70]
    // 0xdd7414: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd7414: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdd7418: r9 = controller
    //     0xdd7418: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3e70] Field <_MaterialControlsState@451269912.controller>: late (offset: 0x58)
    //     0xdd741c: ldr             x9, [x9, #0xe70]
    // 0xdd7420: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd7420: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdd7424: r9 = controller
    //     0xdd7424: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3e70] Field <_MaterialControlsState@451269912.controller>: late (offset: 0x58)
    //     0xdd7428: ldr             x9, [x9, #0xe70]
    // 0xdd742c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd742c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void _playPause(dynamic) {
    // ** addr: 0xdd7430, size: 0x38
    // 0xdd7430: EnterFrame
    //     0xdd7430: stp             fp, lr, [SP, #-0x10]!
    //     0xdd7434: mov             fp, SP
    // 0xdd7438: ldr             x0, [fp, #0x10]
    // 0xdd743c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdd743c: ldur            w1, [x0, #0x17]
    // 0xdd7440: DecompressPointer r1
    //     0xdd7440: add             x1, x1, HEAP, lsl #32
    // 0xdd7444: CheckStackOverflow
    //     0xdd7444: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd7448: cmp             SP, x16
    //     0xdd744c: b.ls            #0xdd7460
    // 0xdd7450: r0 = _playPause()
    //     0xdd7450: bl              #0xdd6f8c  ; [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_playPause
    // 0xdd7454: LeaveFrame
    //     0xdd7454: mov             SP, fp
    //     0xdd7458: ldp             fp, lr, [SP], #0x10
    // 0xdd745c: ret
    //     0xdd745c: ret             
    // 0xdd7460: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd7460: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd7464: b               #0xdd7450
  }
  [closure] void _seekBackward(dynamic) {
    // ** addr: 0xdd7468, size: 0x38
    // 0xdd7468: EnterFrame
    //     0xdd7468: stp             fp, lr, [SP, #-0x10]!
    //     0xdd746c: mov             fp, SP
    // 0xdd7470: ldr             x0, [fp, #0x10]
    // 0xdd7474: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdd7474: ldur            w1, [x0, #0x17]
    // 0xdd7478: DecompressPointer r1
    //     0xdd7478: add             x1, x1, HEAP, lsl #32
    // 0xdd747c: CheckStackOverflow
    //     0xdd747c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd7480: cmp             SP, x16
    //     0xdd7484: b.ls            #0xdd7498
    // 0xdd7488: r0 = _seekBackward()
    //     0xdd7488: bl              #0xdd74a0  ; [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_seekBackward
    // 0xdd748c: LeaveFrame
    //     0xdd748c: mov             SP, fp
    //     0xdd7490: ldp             fp, lr, [SP], #0x10
    // 0xdd7494: ret
    //     0xdd7494: ret             
    // 0xdd7498: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd7498: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd749c: b               #0xdd7488
  }
  _ _seekBackward(/* No info */) {
    // ** addr: 0xdd74a0, size: 0x38
    // 0xdd74a0: EnterFrame
    //     0xdd74a0: stp             fp, lr, [SP, #-0x10]!
    //     0xdd74a4: mov             fp, SP
    // 0xdd74a8: CheckStackOverflow
    //     0xdd74a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd74ac: cmp             SP, x16
    //     0xdd74b0: b.ls            #0xdd74d0
    // 0xdd74b4: r2 = Instance_Duration
    //     0xdd74b4: add             x2, PP, #0xd3, lsl #12  ; [pp+0xd3d40] Obj!Duration@12c8b31
    //     0xdd74b8: ldr             x2, [x2, #0xd40]
    // 0xdd74bc: r0 = _seekRelative()
    //     0xdd74bc: bl              #0xdd72f0  ; [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_seekRelative
    // 0xdd74c0: r0 = Null
    //     0xdd74c0: mov             x0, NULL
    // 0xdd74c4: LeaveFrame
    //     0xdd74c4: mov             SP, fp
    //     0xdd74c8: ldp             fp, lr, [SP], #0x10
    // 0xdd74cc: ret
    //     0xdd74cc: ret             
    // 0xdd74d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd74d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd74d4: b               #0xdd74b4
  }
  [closure] void <anonymous closure>(dynamic, PointerHoverEvent) {
    // ** addr: 0xdd74d8, size: 0x48
    // 0xdd74d8: EnterFrame
    //     0xdd74d8: stp             fp, lr, [SP, #-0x10]!
    //     0xdd74dc: mov             fp, SP
    // 0xdd74e0: ldr             x0, [fp, #0x18]
    // 0xdd74e4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdd74e4: ldur            w1, [x0, #0x17]
    // 0xdd74e8: DecompressPointer r1
    //     0xdd74e8: add             x1, x1, HEAP, lsl #32
    // 0xdd74ec: CheckStackOverflow
    //     0xdd74ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd74f0: cmp             SP, x16
    //     0xdd74f4: b.ls            #0xdd7518
    // 0xdd74f8: LoadField: r0 = r1->field_f
    //     0xdd74f8: ldur            w0, [x1, #0xf]
    // 0xdd74fc: DecompressPointer r0
    //     0xdd74fc: add             x0, x0, HEAP, lsl #32
    // 0xdd7500: mov             x1, x0
    // 0xdd7504: r0 = _cancelAndRestartTimer()
    //     0xdd7504: bl              #0xdd4f28  ; [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_cancelAndRestartTimer
    // 0xdd7508: r0 = Null
    //     0xdd7508: mov             x0, NULL
    // 0xdd750c: LeaveFrame
    //     0xdd750c: mov             SP, fp
    //     0xdd7510: ldp             fp, lr, [SP], #0x10
    // 0xdd7514: ret
    //     0xdd7514: ret             
    // 0xdd7518: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd7518: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd751c: b               #0xdd74f8
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0xef30f4, size: 0xc0
    // 0xef30f4: EnterFrame
    //     0xef30f4: stp             fp, lr, [SP, #-0x10]!
    //     0xef30f8: mov             fp, SP
    // 0xef30fc: AllocStack(0x10)
    //     0xef30fc: sub             SP, SP, #0x10
    // 0xef3100: SetupParameters(_MaterialControlsState this /* r1 => r0, fp-0x10 */)
    //     0xef3100: mov             x0, x1
    //     0xef3104: stur            x1, [fp, #-0x10]
    // 0xef3108: CheckStackOverflow
    //     0xef3108: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef310c: cmp             SP, x16
    //     0xef3110: b.ls            #0xef31a8
    // 0xef3114: LoadField: r2 = r0->field_5b
    //     0xef3114: ldur            w2, [x0, #0x5b]
    // 0xef3118: DecompressPointer r2
    //     0xef3118: add             x2, x2, HEAP, lsl #32
    // 0xef311c: stur            x2, [fp, #-8]
    // 0xef3120: LoadField: r1 = r0->field_f
    //     0xef3120: ldur            w1, [x0, #0xf]
    // 0xef3124: DecompressPointer r1
    //     0xef3124: add             x1, x1, HEAP, lsl #32
    // 0xef3128: cmp             w1, NULL
    // 0xef312c: b.eq            #0xef31b0
    // 0xef3130: r0 = of()
    //     0xef3130: bl              #0xef309c  ; [package:chewie/src/chewie_player.dart] ChewieController::of
    // 0xef3134: mov             x1, x0
    // 0xef3138: ldur            x2, [fp, #-0x10]
    // 0xef313c: StoreField: r2->field_5b = r0
    //     0xef313c: stur            w0, [x2, #0x5b]
    //     0xef3140: ldurb           w16, [x2, #-1]
    //     0xef3144: ldurb           w17, [x0, #-1]
    //     0xef3148: and             x16, x17, x16, lsr #2
    //     0xef314c: tst             x16, HEAP, lsr #32
    //     0xef3150: b.eq            #0xef3158
    //     0xef3154: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xef3158: LoadField: r0 = r1->field_3b
    //     0xef3158: ldur            w0, [x1, #0x3b]
    // 0xef315c: DecompressPointer r0
    //     0xef315c: add             x0, x0, HEAP, lsl #32
    // 0xef3160: StoreField: r2->field_57 = r0
    //     0xef3160: stur            w0, [x2, #0x57]
    //     0xef3164: ldurb           w16, [x2, #-1]
    //     0xef3168: ldurb           w17, [x0, #-1]
    //     0xef316c: and             x16, x17, x16, lsr #2
    //     0xef3170: tst             x16, HEAP, lsr #32
    //     0xef3174: b.eq            #0xef317c
    //     0xef3178: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xef317c: ldur            x0, [fp, #-8]
    // 0xef3180: cmp             w0, w1
    // 0xef3184: b.eq            #0xef3198
    // 0xef3188: mov             x1, x2
    // 0xef318c: r0 = _dispose()
    //     0xef318c: bl              #0xef3564  ; [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_dispose
    // 0xef3190: ldur            x1, [fp, #-0x10]
    // 0xef3194: r0 = _initialize()
    //     0xef3194: bl              #0xef31b4  ; [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_initialize
    // 0xef3198: r0 = Null
    //     0xef3198: mov             x0, NULL
    // 0xef319c: LeaveFrame
    //     0xef319c: mov             SP, fp
    //     0xef31a0: ldp             fp, lr, [SP], #0x10
    // 0xef31a4: ret
    //     0xef31a4: ret             
    // 0xef31a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef31a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef31ac: b               #0xef3114
    // 0xef31b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef31b0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _initialize(/* No info */) async {
    // ** addr: 0xef31b4, size: 0x16c
    // 0xef31b4: EnterFrame
    //     0xef31b4: stp             fp, lr, [SP, #-0x10]!
    //     0xef31b8: mov             fp, SP
    // 0xef31bc: AllocStack(0x20)
    //     0xef31bc: sub             SP, SP, #0x20
    // 0xef31c0: SetupParameters(_MaterialControlsState this /* r1 => r2, fp-0x10 */)
    //     0xef31c0: stur            NULL, [fp, #-8]
    //     0xef31c4: mov             x2, x1
    //     0xef31c8: stur            x1, [fp, #-0x10]
    // 0xef31cc: CheckStackOverflow
    //     0xef31cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef31d0: cmp             SP, x16
    //     0xef31d4: b.ls            #0xef3300
    // 0xef31d8: r1 = 1
    //     0xef31d8: mov             x1, #1
    // 0xef31dc: r0 = AllocateContext()
    //     0xef31dc: bl              #0x13de838  ; AllocateContextStub
    // 0xef31e0: mov             x1, x0
    // 0xef31e4: ldur            x2, [fp, #-0x10]
    // 0xef31e8: stur            x1, [fp, #-0x18]
    // 0xef31ec: StoreField: r1->field_f = r2
    //     0xef31ec: stur            w2, [x1, #0xf]
    // 0xef31f0: InitAsync() -> Future<void?>
    //     0xef31f0: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0xef31f4: bl              #0x7f5e44  ; InitAsyncStub
    // 0xef31f8: ldur            x0, [fp, #-0x10]
    // 0xef31fc: LoadField: r1 = r0->field_5b
    //     0xef31fc: ldur            w1, [x0, #0x5b]
    // 0xef3200: DecompressPointer r1
    //     0xef3200: add             x1, x1, HEAP, lsl #32
    // 0xef3204: cmp             w1, NULL
    // 0xef3208: b.eq            #0xef3308
    // 0xef320c: r1 = false
    //     0xef320c: add             x1, NULL, #0x30  ; false
    // 0xef3210: StoreField: r0->field_2f = r1
    //     0xef3210: stur            w1, [x0, #0x2f]
    // 0xef3214: LoadField: r3 = r0->field_57
    //     0xef3214: ldur            w3, [x0, #0x57]
    // 0xef3218: DecompressPointer r3
    //     0xef3218: add             x3, x3, HEAP, lsl #32
    // 0xef321c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xef3220: cmp             w3, w16
    // 0xef3224: b.eq            #0xef330c
    // 0xef3228: mov             x2, x0
    // 0xef322c: stur            x3, [fp, #-0x20]
    // 0xef3230: r1 = Function '_updateState@451269912':.
    //     0xef3230: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3e60] AnonymousClosure: (0xef352c), in [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_updateState (0xef3320)
    //     0xef3234: ldr             x1, [x1, #0xe60]
    // 0xef3238: r0 = AllocateClosure()
    //     0xef3238: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xef323c: ldur            x1, [fp, #-0x20]
    // 0xef3240: mov             x2, x0
    // 0xef3244: r0 = addListener()
    //     0xef3244: bl              #0xd038e0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0xef3248: ldur            x1, [fp, #-0x10]
    // 0xef324c: r0 = _updateState()
    //     0xef324c: bl              #0xef3320  ; [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_updateState
    // 0xef3250: ldur            x0, [fp, #-0x10]
    // 0xef3254: LoadField: r1 = r0->field_57
    //     0xef3254: ldur            w1, [x0, #0x57]
    // 0xef3258: DecompressPointer r1
    //     0xef3258: add             x1, x1, HEAP, lsl #32
    // 0xef325c: LoadField: r2 = r1->field_27
    //     0xef325c: ldur            w2, [x1, #0x27]
    // 0xef3260: DecompressPointer r2
    //     0xef3260: add             x2, x2, HEAP, lsl #32
    // 0xef3264: LoadField: r1 = r2->field_1b
    //     0xef3264: ldur            w1, [x2, #0x1b]
    // 0xef3268: DecompressPointer r1
    //     0xef3268: add             x1, x1, HEAP, lsl #32
    // 0xef326c: tbz             w1, #4, #0xef328c
    // 0xef3270: LoadField: r1 = r0->field_5b
    //     0xef3270: ldur            w1, [x0, #0x5b]
    // 0xef3274: DecompressPointer r1
    //     0xef3274: add             x1, x1, HEAP, lsl #32
    // 0xef3278: cmp             w1, NULL
    // 0xef327c: b.eq            #0xef3318
    // 0xef3280: LoadField: r2 = r1->field_43
    //     0xef3280: ldur            w2, [x1, #0x43]
    // 0xef3284: DecompressPointer r2
    //     0xef3284: add             x2, x2, HEAP, lsl #32
    // 0xef3288: tbnz            w2, #4, #0xef3294
    // 0xef328c: mov             x1, x0
    // 0xef3290: r0 = _startHideTimer()
    //     0xef3290: bl              #0xdd4954  ; [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_startHideTimer
    // 0xef3294: ldur            x0, [fp, #-0x10]
    // 0xef3298: LoadField: r1 = r0->field_5b
    //     0xef3298: ldur            w1, [x0, #0x5b]
    // 0xef329c: DecompressPointer r1
    //     0xef329c: add             x1, x1, HEAP, lsl #32
    // 0xef32a0: cmp             w1, NULL
    // 0xef32a4: b.eq            #0xef331c
    // 0xef32a8: LoadField: r2 = r1->field_53
    //     0xef32a8: ldur            w2, [x1, #0x53]
    // 0xef32ac: DecompressPointer r2
    //     0xef32ac: add             x2, x2, HEAP, lsl #32
    // 0xef32b0: tbnz            w2, #4, #0xef32f8
    // 0xef32b4: ldur            x2, [fp, #-0x18]
    // 0xef32b8: r1 = Function '<anonymous closure>':.
    //     0xef32b8: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3e68] AnonymousClosure: (0xef345c), in [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_initialize (0xef31b4)
    //     0xef32bc: ldr             x1, [x1, #0xe68]
    // 0xef32c0: r0 = AllocateClosure()
    //     0xef32c0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xef32c4: mov             x3, x0
    // 0xef32c8: r1 = Null
    //     0xef32c8: mov             x1, NULL
    // 0xef32cc: r2 = Instance_Duration
    //     0xef32cc: add             x2, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xef32d0: ldr             x2, [x2, #0x318]
    // 0xef32d4: r0 = Timer()
    //     0xef32d4: bl              #0x7eed74  ; [dart:async] Timer::Timer
    // 0xef32d8: ldur            x1, [fp, #-0x10]
    // 0xef32dc: StoreField: r1->field_2b = r0
    //     0xef32dc: stur            w0, [x1, #0x2b]
    //     0xef32e0: ldurb           w16, [x1, #-1]
    //     0xef32e4: ldurb           w17, [x0, #-1]
    //     0xef32e8: and             x16, x17, x16, lsr #2
    //     0xef32ec: tst             x16, HEAP, lsr #32
    //     0xef32f0: b.eq            #0xef32f8
    //     0xef32f4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xef32f8: r0 = Null
    //     0xef32f8: mov             x0, NULL
    // 0xef32fc: r0 = ReturnAsyncNotFuture()
    //     0xef32fc: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xef3300: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef3300: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef3304: b               #0xef31d8
    // 0xef3308: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef3308: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef330c: r9 = controller
    //     0xef330c: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3e70] Field <_MaterialControlsState@451269912.controller>: late (offset: 0x58)
    //     0xef3310: ldr             x9, [x9, #0xe70]
    // 0xef3314: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xef3314: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xef3318: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef3318: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef331c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef331c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateState(/* No info */) {
    // ** addr: 0xef3320, size: 0xcc
    // 0xef3320: EnterFrame
    //     0xef3320: stp             fp, lr, [SP, #-0x10]!
    //     0xef3324: mov             fp, SP
    // 0xef3328: AllocStack(0x10)
    //     0xef3328: sub             SP, SP, #0x10
    // 0xef332c: SetupParameters(_MaterialControlsState this /* r1 => r1, fp-0x8 */)
    //     0xef332c: stur            x1, [fp, #-8]
    // 0xef3330: CheckStackOverflow
    //     0xef3330: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef3334: cmp             SP, x16
    //     0xef3338: b.ls            #0xef33d4
    // 0xef333c: r1 = 1
    //     0xef333c: mov             x1, #1
    // 0xef3340: r0 = AllocateContext()
    //     0xef3340: bl              #0x13de838  ; AllocateContextStub
    // 0xef3344: mov             x2, x0
    // 0xef3348: ldur            x0, [fp, #-8]
    // 0xef334c: stur            x2, [fp, #-0x10]
    // 0xef3350: StoreField: r2->field_f = r0
    //     0xef3350: stur            w0, [x2, #0xf]
    // 0xef3354: LoadField: r1 = r0->field_f
    //     0xef3354: ldur            w1, [x0, #0xf]
    // 0xef3358: DecompressPointer r1
    //     0xef3358: add             x1, x1, HEAP, lsl #32
    // 0xef335c: cmp             w1, NULL
    // 0xef3360: b.ne            #0xef3374
    // 0xef3364: r0 = Null
    //     0xef3364: mov             x0, NULL
    // 0xef3368: LeaveFrame
    //     0xef3368: mov             SP, fp
    //     0xef336c: ldp             fp, lr, [SP], #0x10
    // 0xef3370: ret
    //     0xef3370: ret             
    // 0xef3374: LoadField: r1 = r0->field_57
    //     0xef3374: ldur            w1, [x0, #0x57]
    // 0xef3378: DecompressPointer r1
    //     0xef3378: add             x1, x1, HEAP, lsl #32
    // 0xef337c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xef3380: cmp             w1, w16
    // 0xef3384: b.eq            #0xef33dc
    // 0xef3388: r0 = getIsBuffering()
    //     0xef3388: bl              #0xdd3740  ; [package:chewie/src/helpers/utils.dart] ::getIsBuffering
    // 0xef338c: mov             x1, x0
    // 0xef3390: ldur            x0, [fp, #-8]
    // 0xef3394: LoadField: r2 = r0->field_5b
    //     0xef3394: ldur            w2, [x0, #0x5b]
    // 0xef3398: DecompressPointer r2
    //     0xef3398: add             x2, x2, HEAP, lsl #32
    // 0xef339c: cmp             w2, NULL
    // 0xef33a0: b.eq            #0xef33e8
    // 0xef33a4: StoreField: r0->field_43 = r1
    //     0xef33a4: stur            w1, [x0, #0x43]
    // 0xef33a8: ldur            x2, [fp, #-0x10]
    // 0xef33ac: r1 = Function '<anonymous closure>':.
    //     0xef33ac: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3e98] AnonymousClosure: (0xef33ec), in [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_updateState (0xef3320)
    //     0xef33b0: ldr             x1, [x1, #0xe98]
    // 0xef33b4: r0 = AllocateClosure()
    //     0xef33b4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xef33b8: ldur            x1, [fp, #-8]
    // 0xef33bc: mov             x2, x0
    // 0xef33c0: r0 = setState()
    //     0xef33c0: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xef33c4: r0 = Null
    //     0xef33c4: mov             x0, NULL
    // 0xef33c8: LeaveFrame
    //     0xef33c8: mov             SP, fp
    //     0xef33cc: ldp             fp, lr, [SP], #0x10
    // 0xef33d0: ret
    //     0xef33d0: ret             
    // 0xef33d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef33d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef33d8: b               #0xef333c
    // 0xef33dc: r9 = controller
    //     0xef33dc: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3e70] Field <_MaterialControlsState@451269912.controller>: late (offset: 0x58)
    //     0xef33e0: ldr             x9, [x9, #0xe70]
    // 0xef33e4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xef33e4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xef33e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef33e8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xef33ec, size: 0x70
    // 0xef33ec: ldr             x1, [SP]
    // 0xef33f0: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xef33f0: ldur            w2, [x1, #0x17]
    // 0xef33f4: DecompressPointer r2
    //     0xef33f4: add             x2, x2, HEAP, lsl #32
    // 0xef33f8: LoadField: r1 = r2->field_f
    //     0xef33f8: ldur            w1, [x2, #0xf]
    // 0xef33fc: DecompressPointer r1
    //     0xef33fc: add             x1, x1, HEAP, lsl #32
    // 0xef3400: LoadField: r2 = r1->field_57
    //     0xef3400: ldur            w2, [x1, #0x57]
    // 0xef3404: DecompressPointer r2
    //     0xef3404: add             x2, x2, HEAP, lsl #32
    // 0xef3408: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xef340c: cmp             w2, w16
    // 0xef3410: b.eq            #0xef3448
    // 0xef3414: LoadField: r0 = r2->field_27
    //     0xef3414: ldur            w0, [x2, #0x27]
    // 0xef3418: DecompressPointer r0
    //     0xef3418: add             x0, x0, HEAP, lsl #32
    // 0xef341c: StoreField: r1->field_1f = r0
    //     0xef341c: stur            w0, [x1, #0x1f]
    //     0xef3420: ldurb           w16, [x1, #-1]
    //     0xef3424: ldurb           w17, [x0, #-1]
    //     0xef3428: and             x16, x17, x16, lsr #2
    //     0xef342c: tst             x16, HEAP, lsr #32
    //     0xef3430: b.eq            #0xef3440
    //     0xef3434: str             lr, [SP, #-8]!
    //     0xef3438: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    //     0xef343c: ldr             lr, [SP], #8
    // 0xef3440: r0 = Null
    //     0xef3440: mov             x0, NULL
    // 0xef3444: ret
    //     0xef3444: ret             
    // 0xef3448: EnterFrame
    //     0xef3448: stp             fp, lr, [SP, #-0x10]!
    //     0xef344c: mov             fp, SP
    // 0xef3450: r9 = controller
    //     0xef3450: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3e70] Field <_MaterialControlsState@451269912.controller>: late (offset: 0x58)
    //     0xef3454: ldr             x9, [x9, #0xe70]
    // 0xef3458: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xef3458: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xef345c, size: 0x60
    // 0xef345c: EnterFrame
    //     0xef345c: stp             fp, lr, [SP, #-0x10]!
    //     0xef3460: mov             fp, SP
    // 0xef3464: AllocStack(0x8)
    //     0xef3464: sub             SP, SP, #8
    // 0xef3468: SetupParameters([dynamic _ /* r0 */])
    //     0xef3468: ldr             x0, [fp, #0x10]
    //     0xef346c: ldur            w2, [x0, #0x17]
    //     0xef3470: add             x2, x2, HEAP, lsl #32
    // 0xef3474: CheckStackOverflow
    //     0xef3474: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef3478: cmp             SP, x16
    //     0xef347c: b.ls            #0xef34b4
    // 0xef3480: LoadField: r0 = r2->field_f
    //     0xef3480: ldur            w0, [x2, #0xf]
    // 0xef3484: DecompressPointer r0
    //     0xef3484: add             x0, x0, HEAP, lsl #32
    // 0xef3488: stur            x0, [fp, #-8]
    // 0xef348c: r1 = Function '<anonymous closure>':.
    //     0xef348c: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3e78] AnonymousClosure: (0xef34bc), in [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_initialize (0xef31b4)
    //     0xef3490: ldr             x1, [x1, #0xe78]
    // 0xef3494: r0 = AllocateClosure()
    //     0xef3494: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xef3498: ldur            x1, [fp, #-8]
    // 0xef349c: mov             x2, x0
    // 0xef34a0: r0 = setState()
    //     0xef34a0: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xef34a4: r0 = Null
    //     0xef34a4: mov             x0, NULL
    // 0xef34a8: LeaveFrame
    //     0xef34a8: mov             SP, fp
    //     0xef34ac: ldp             fp, lr, [SP], #0x10
    // 0xef34b0: ret
    //     0xef34b0: ret             
    // 0xef34b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef34b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef34b8: b               #0xef3480
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xef34bc, size: 0x70
    // 0xef34bc: EnterFrame
    //     0xef34bc: stp             fp, lr, [SP, #-0x10]!
    //     0xef34c0: mov             fp, SP
    // 0xef34c4: r0 = false
    //     0xef34c4: add             x0, NULL, #0x30  ; false
    // 0xef34c8: ldr             x1, [fp, #0x10]
    // 0xef34cc: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xef34cc: ldur            w2, [x1, #0x17]
    // 0xef34d0: DecompressPointer r2
    //     0xef34d0: add             x2, x2, HEAP, lsl #32
    // 0xef34d4: CheckStackOverflow
    //     0xef34d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef34d8: cmp             SP, x16
    //     0xef34dc: b.ls            #0xef3518
    // 0xef34e0: LoadField: r1 = r2->field_f
    //     0xef34e0: ldur            w1, [x2, #0xf]
    // 0xef34e4: DecompressPointer r1
    //     0xef34e4: add             x1, x1, HEAP, lsl #32
    // 0xef34e8: LoadField: r2 = r1->field_1b
    //     0xef34e8: ldur            w2, [x1, #0x1b]
    // 0xef34ec: DecompressPointer r2
    //     0xef34ec: add             x2, x2, HEAP, lsl #32
    // 0xef34f0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xef34f4: cmp             w2, w16
    // 0xef34f8: b.eq            #0xef3520
    // 0xef34fc: StoreField: r2->field_23 = r0
    //     0xef34fc: stur            w0, [x2, #0x23]
    // 0xef3500: mov             x1, x2
    // 0xef3504: r0 = notifyListeners()
    //     0xef3504: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xef3508: r0 = Null
    //     0xef3508: mov             x0, NULL
    // 0xef350c: LeaveFrame
    //     0xef350c: mov             SP, fp
    //     0xef3510: ldp             fp, lr, [SP], #0x10
    // 0xef3514: ret
    //     0xef3514: ret             
    // 0xef3518: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef3518: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef351c: b               #0xef34e0
    // 0xef3520: r9 = notifier
    //     0xef3520: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3e80] Field <_MaterialControlsState@451269912.notifier>: late (offset: 0x1c)
    //     0xef3524: ldr             x9, [x9, #0xe80]
    // 0xef3528: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xef3528: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void _updateState(dynamic) {
    // ** addr: 0xef352c, size: 0x38
    // 0xef352c: EnterFrame
    //     0xef352c: stp             fp, lr, [SP, #-0x10]!
    //     0xef3530: mov             fp, SP
    // 0xef3534: ldr             x0, [fp, #0x10]
    // 0xef3538: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xef3538: ldur            w1, [x0, #0x17]
    // 0xef353c: DecompressPointer r1
    //     0xef353c: add             x1, x1, HEAP, lsl #32
    // 0xef3540: CheckStackOverflow
    //     0xef3540: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef3544: cmp             SP, x16
    //     0xef3548: b.ls            #0xef355c
    // 0xef354c: r0 = _updateState()
    //     0xef354c: bl              #0xef3320  ; [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_updateState
    // 0xef3550: LeaveFrame
    //     0xef3550: mov             SP, fp
    //     0xef3554: ldp             fp, lr, [SP], #0x10
    // 0xef3558: ret
    //     0xef3558: ret             
    // 0xef355c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef355c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef3560: b               #0xef354c
  }
  _ _dispose(/* No info */) {
    // ** addr: 0xef3564, size: 0xc0
    // 0xef3564: EnterFrame
    //     0xef3564: stp             fp, lr, [SP, #-0x10]!
    //     0xef3568: mov             fp, SP
    // 0xef356c: AllocStack(0x10)
    //     0xef356c: sub             SP, SP, #0x10
    // 0xef3570: SetupParameters(_MaterialControlsState this /* r1 => r0, fp-0x10 */)
    //     0xef3570: mov             x0, x1
    //     0xef3574: stur            x1, [fp, #-0x10]
    // 0xef3578: CheckStackOverflow
    //     0xef3578: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef357c: cmp             SP, x16
    //     0xef3580: b.ls            #0xef3610
    // 0xef3584: LoadField: r3 = r0->field_57
    //     0xef3584: ldur            w3, [x0, #0x57]
    // 0xef3588: DecompressPointer r3
    //     0xef3588: add             x3, x3, HEAP, lsl #32
    // 0xef358c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xef3590: cmp             w3, w16
    // 0xef3594: b.eq            #0xef3618
    // 0xef3598: mov             x2, x0
    // 0xef359c: stur            x3, [fp, #-8]
    // 0xef35a0: r1 = Function '_updateState@451269912':.
    //     0xef35a0: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3e60] AnonymousClosure: (0xef352c), in [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_updateState (0xef3320)
    //     0xef35a4: ldr             x1, [x1, #0xe60]
    // 0xef35a8: r0 = AllocateClosure()
    //     0xef35a8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xef35ac: ldur            x1, [fp, #-8]
    // 0xef35b0: mov             x2, x0
    // 0xef35b4: r0 = removeListener()
    //     0xef35b4: bl              #0xcff784  ; [package:video_player/video_player.dart] VideoPlayerController::removeListener
    // 0xef35b8: ldur            x0, [fp, #-0x10]
    // 0xef35bc: LoadField: r1 = r0->field_27
    //     0xef35bc: ldur            w1, [x0, #0x27]
    // 0xef35c0: DecompressPointer r1
    //     0xef35c0: add             x1, x1, HEAP, lsl #32
    // 0xef35c4: cmp             w1, NULL
    // 0xef35c8: b.eq            #0xef35d4
    // 0xef35cc: r0 = cancel()
    //     0xef35cc: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0xef35d0: ldur            x0, [fp, #-0x10]
    // 0xef35d4: LoadField: r1 = r0->field_2b
    //     0xef35d4: ldur            w1, [x0, #0x2b]
    // 0xef35d8: DecompressPointer r1
    //     0xef35d8: add             x1, x1, HEAP, lsl #32
    // 0xef35dc: cmp             w1, NULL
    // 0xef35e0: b.eq            #0xef35ec
    // 0xef35e4: r0 = cancel()
    //     0xef35e4: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0xef35e8: ldur            x0, [fp, #-0x10]
    // 0xef35ec: LoadField: r1 = r0->field_33
    //     0xef35ec: ldur            w1, [x0, #0x33]
    // 0xef35f0: DecompressPointer r1
    //     0xef35f0: add             x1, x1, HEAP, lsl #32
    // 0xef35f4: cmp             w1, NULL
    // 0xef35f8: b.eq            #0xef3600
    // 0xef35fc: r0 = cancel()
    //     0xef35fc: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0xef3600: r0 = Null
    //     0xef3600: mov             x0, NULL
    // 0xef3604: LeaveFrame
    //     0xef3604: mov             SP, fp
    //     0xef3608: ldp             fp, lr, [SP], #0x10
    // 0xef360c: ret
    //     0xef360c: ret             
    // 0xef3610: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef3610: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef3614: b               #0xef3584
    // 0xef3618: r9 = controller
    //     0xef3618: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3e70] Field <_MaterialControlsState@451269912.controller>: late (offset: 0x58)
    //     0xef361c: ldr             x9, [x9, #0xe70]
    // 0xef3620: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xef3620: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0xf8a84c, size: 0x88
    // 0xf8a84c: EnterFrame
    //     0xf8a84c: stp             fp, lr, [SP, #-0x10]!
    //     0xf8a850: mov             fp, SP
    // 0xf8a854: AllocStack(0x20)
    //     0xf8a854: sub             SP, SP, #0x20
    // 0xf8a858: SetupParameters(_MaterialControlsState this /* r1 => r1, fp-0x8 */)
    //     0xf8a858: stur            x1, [fp, #-8]
    // 0xf8a85c: CheckStackOverflow
    //     0xf8a85c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf8a860: cmp             SP, x16
    //     0xf8a864: b.ls            #0xf8a8c8
    // 0xf8a868: LoadField: r0 = r1->field_f
    //     0xf8a868: ldur            w0, [x1, #0xf]
    // 0xf8a86c: DecompressPointer r0
    //     0xf8a86c: add             x0, x0, HEAP, lsl #32
    // 0xf8a870: cmp             w0, NULL
    // 0xf8a874: b.eq            #0xf8a8d0
    // 0xf8a878: r16 = <PlayerNotifier>
    //     0xf8a878: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf6f0] TypeArguments: <PlayerNotifier>
    //     0xf8a87c: ldr             x16, [x16, #0x6f0]
    // 0xf8a880: stp             x0, x16, [SP, #8]
    // 0xf8a884: r16 = false
    //     0xf8a884: add             x16, NULL, #0x30  ; false
    // 0xf8a888: str             x16, [SP]
    // 0xf8a88c: r4 = const [0x1, 0x2, 0x2, 0x1, listen, 0x1, null]
    //     0xf8a88c: add             x4, PP, #0xd1, lsl #12  ; [pp+0xd17f8] List(7) [0x1, 0x2, 0x2, 0x1, "listen", 0x1, Null]
    //     0xf8a890: ldr             x4, [x4, #0x7f8]
    // 0xf8a894: r0 = of()
    //     0xf8a894: bl              #0xf8a8d4  ; [package:provider/src/provider.dart] Provider::of
    // 0xf8a898: ldur            x1, [fp, #-8]
    // 0xf8a89c: StoreField: r1->field_1b = r0
    //     0xf8a89c: stur            w0, [x1, #0x1b]
    //     0xf8a8a0: ldurb           w16, [x1, #-1]
    //     0xf8a8a4: ldurb           w17, [x0, #-1]
    //     0xf8a8a8: and             x16, x17, x16, lsr #2
    //     0xf8a8ac: tst             x16, HEAP, lsr #32
    //     0xf8a8b0: b.eq            #0xf8a8b8
    //     0xf8a8b4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf8a8b8: r0 = Null
    //     0xf8a8b8: mov             x0, NULL
    // 0xf8a8bc: LeaveFrame
    //     0xf8a8bc: mov             SP, fp
    //     0xf8a8c0: ldp             fp, lr, [SP], #0x10
    // 0xf8a8c4: ret
    //     0xf8a8c4: ret             
    // 0xf8a8c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf8a8c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf8a8cc: b               #0xf8a868
    // 0xf8a8d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf8a8d0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _MaterialControlsState(/* No info */) {
    // ** addr: 0xf9ffc4, size: 0x40
    // 0xf9ffc4: ldr             x3, [THR, #0x90]  ; THR::object_sentinel
    // 0xf9ffc8: r2 = false
    //     0xf9ffc8: add             x2, NULL, #0x30  ; false
    // 0xf9ffcc: d1 = 72.000000
    //     0xf9ffcc: add             x17, PP, #0x89, lsl #12  ; [pp+0x89030] IMM: double(72) from 0x4052000000000000
    //     0xf9ffd0: ldr             d1, [x17, #0x30]
    // 0xf9ffd4: d0 = 5.000000
    //     0xf9ffd4: fmov            d0, #5.00000000
    // 0xf9ffd8: StoreField: r1->field_1b = r3
    //     0xf9ffd8: stur            w3, [x1, #0x1b]
    // 0xf9ffdc: StoreField: r1->field_1f = r3
    //     0xf9ffdc: stur            w3, [x1, #0x1f]
    // 0xf9ffe0: StoreField: r1->field_2f = r2
    //     0xf9ffe0: stur            w2, [x1, #0x2f]
    // 0xf9ffe4: StoreField: r1->field_37 = r2
    //     0xf9ffe4: stur            w2, [x1, #0x37]
    // 0xf9ffe8: StoreField: r1->field_3b = r2
    //     0xf9ffe8: stur            w2, [x1, #0x3b]
    // 0xf9ffec: StoreField: r1->field_43 = r2
    //     0xf9ffec: stur            w2, [x1, #0x43]
    // 0xf9fff0: StoreField: r1->field_4f = d0
    //     0xf9fff0: stur            d0, [x1, #0x4f]
    // 0xf9fff4: StoreField: r1->field_57 = r3
    //     0xf9fff4: stur            w3, [x1, #0x57]
    // 0xf9fff8: StoreField: r1->field_47 = d1
    //     0xf9fff8: stur            d1, [x1, #0x47]
    // 0xf9fffc: r0 = Null
    //     0xf9fffc: mov             x0, NULL
    // 0xfa0000: ret
    //     0xfa0000: ret             
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10e2820, size: 0x48
    // 0x10e2820: EnterFrame
    //     0x10e2820: stp             fp, lr, [SP, #-0x10]!
    //     0x10e2824: mov             fp, SP
    // 0x10e2828: AllocStack(0x8)
    //     0x10e2828: sub             SP, SP, #8
    // 0x10e282c: SetupParameters(_MaterialControlsState this /* r1 => r0, fp-0x8 */)
    //     0x10e282c: mov             x0, x1
    //     0x10e2830: stur            x1, [fp, #-8]
    // 0x10e2834: CheckStackOverflow
    //     0x10e2834: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e2838: cmp             SP, x16
    //     0x10e283c: b.ls            #0x10e2860
    // 0x10e2840: mov             x1, x0
    // 0x10e2844: r0 = _dispose()
    //     0x10e2844: bl              #0xef3564  ; [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_dispose
    // 0x10e2848: ldur            x1, [fp, #-8]
    // 0x10e284c: r0 = dispose()
    //     0x10e284c: bl              #0x10e2868  ; [dart:mixin_deduplication] _MixinApplication738&State&SingleTickerProviderStateMixin::dispose
    // 0x10e2850: r0 = Null
    //     0x10e2850: mov             x0, NULL
    // 0x10e2854: LeaveFrame
    //     0x10e2854: mov             SP, fp
    //     0x10e2858: ldp             fp, lr, [SP], #0x10
    // 0x10e285c: ret
    //     0x10e285c: ret             
    // 0x10e2860: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e2860: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e2864: b               #0x10e2840
  }
}

// class id: 6535, size: 0x10, field offset: 0xc
//   const constructor, 
class MaterialControls extends StatefulWidget {

  bool field_c;

  _ createState(/* No info */) {
    // ** addr: 0xf9ff7c, size: 0x48
    // 0xf9ff7c: EnterFrame
    //     0xf9ff7c: stp             fp, lr, [SP, #-0x10]!
    //     0xf9ff80: mov             fp, SP
    // 0xf9ff84: AllocStack(0x8)
    //     0xf9ff84: sub             SP, SP, #8
    // 0xf9ff88: CheckStackOverflow
    //     0xf9ff88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf9ff8c: cmp             SP, x16
    //     0xf9ff90: b.ls            #0xf9ffbc
    // 0xf9ff94: r1 = <MaterialControls>
    //     0xf9ff94: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3300] TypeArguments: <MaterialControls>
    //     0xf9ff98: ldr             x1, [x1, #0x300]
    // 0xf9ff9c: r0 = _MaterialControlsState()
    //     0xf9ff9c: bl              #0xfa0004  ; Allocate_MaterialControlsStateStub -> _MaterialControlsState (size=0x60)
    // 0xf9ffa0: mov             x1, x0
    // 0xf9ffa4: stur            x0, [fp, #-8]
    // 0xf9ffa8: r0 = _MaterialControlsState()
    //     0xf9ffa8: bl              #0xf9ffc4  ; [package:chewie/src/material/material_controls.dart] _MaterialControlsState::_MaterialControlsState
    // 0xf9ffac: ldur            x0, [fp, #-8]
    // 0xf9ffb0: LeaveFrame
    //     0xf9ffb0: mov             SP, fp
    //     0xf9ffb4: ldp             fp, lr, [SP], #0x10
    // 0xf9ffb8: ret
    //     0xf9ffb8: ret             
    // 0xf9ffbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf9ffbc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf9ffc0: b               #0xf9ff94
  }
}
