// lib: , url: package:chewie/src/chewie_player.dart

// class id: 1048629, size: 0x8
class :: {
}

// class id: 4518, size: 0xd4, field offset: 0x24
class ChewieController extends ChangeNotifier {

  _ toggleFullScreen(/* No info */) {
    // ** addr: 0xdd30a8, size: 0x40
    // 0xdd30a8: EnterFrame
    //     0xdd30a8: stp             fp, lr, [SP, #-0x10]!
    //     0xdd30ac: mov             fp, SP
    // 0xdd30b0: CheckStackOverflow
    //     0xdd30b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd30b4: cmp             SP, x16
    //     0xdd30b8: b.ls            #0xdd30e0
    // 0xdd30bc: LoadField: r0 = r1->field_cf
    //     0xdd30bc: ldur            w0, [x1, #0xcf]
    // 0xdd30c0: DecompressPointer r0
    //     0xdd30c0: add             x0, x0, HEAP, lsl #32
    // 0xdd30c4: eor             x2, x0, #0x10
    // 0xdd30c8: StoreField: r1->field_cf = r2
    //     0xdd30c8: stur            w2, [x1, #0xcf]
    // 0xdd30cc: r0 = notifyListeners()
    //     0xdd30cc: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xdd30d0: r0 = Null
    //     0xdd30d0: mov             x0, NULL
    // 0xdd30d4: LeaveFrame
    //     0xdd30d4: mov             SP, fp
    //     0xdd30d8: ldp             fp, lr, [SP], #0x10
    // 0xdd30dc: ret
    //     0xdd30dc: ret             
    // 0xdd30e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd30e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd30e4: b               #0xdd30bc
  }
  static _ of(/* No info */) {
    // ** addr: 0xef309c, size: 0x58
    // 0xef309c: EnterFrame
    //     0xef309c: stp             fp, lr, [SP, #-0x10]!
    //     0xef30a0: mov             fp, SP
    // 0xef30a4: AllocStack(0x10)
    //     0xef30a4: sub             SP, SP, #0x10
    // 0xef30a8: CheckStackOverflow
    //     0xef30a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef30ac: cmp             SP, x16
    //     0xef30b0: b.ls            #0xef30e8
    // 0xef30b4: r16 = <ChewieControllerProvider>
    //     0xef30b4: add             x16, PP, #0xd1, lsl #12  ; [pp+0xd1930] TypeArguments: <ChewieControllerProvider>
    //     0xef30b8: ldr             x16, [x16, #0x930]
    // 0xef30bc: stp             x1, x16, [SP]
    // 0xef30c0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xef30c0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xef30c4: r0 = dependOnInheritedWidgetOfExactType()
    //     0xef30c4: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xef30c8: cmp             w0, NULL
    // 0xef30cc: b.eq            #0xef30f0
    // 0xef30d0: LoadField: r1 = r0->field_f
    //     0xef30d0: ldur            w1, [x0, #0xf]
    // 0xef30d4: DecompressPointer r1
    //     0xef30d4: add             x1, x1, HEAP, lsl #32
    // 0xef30d8: mov             x0, x1
    // 0xef30dc: LeaveFrame
    //     0xef30dc: mov             SP, fp
    //     0xef30e0: ldp             fp, lr, [SP], #0x10
    // 0xef30e4: ret
    //     0xef30e4: ret             
    // 0xef30e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef30e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef30ec: b               #0xef30b4
    // 0xef30f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef30f0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ exitFullScreen(/* No info */) {
    // ** addr: 0xf6c220, size: 0x38
    // 0xf6c220: EnterFrame
    //     0xf6c220: stp             fp, lr, [SP, #-0x10]!
    //     0xf6c224: mov             fp, SP
    // 0xf6c228: r0 = false
    //     0xf6c228: add             x0, NULL, #0x30  ; false
    // 0xf6c22c: CheckStackOverflow
    //     0xf6c22c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6c230: cmp             SP, x16
    //     0xf6c234: b.ls            #0xf6c250
    // 0xf6c238: StoreField: r1->field_cf = r0
    //     0xf6c238: stur            w0, [x1, #0xcf]
    // 0xf6c23c: r0 = notifyListeners()
    //     0xf6c23c: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xf6c240: r0 = Null
    //     0xf6c240: mov             x0, NULL
    // 0xf6c244: LeaveFrame
    //     0xf6c244: mov             SP, fp
    //     0xf6c248: ldp             fp, lr, [SP], #0x10
    // 0xf6c24c: ret
    //     0xf6c24c: ret             
    // 0xf6c250: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6c250: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6c254: b               #0xf6c238
  }
  _ ChewieController(/* No info */) {
    // ** addr: 0xf97070, size: 0x268
    // 0xf97070: EnterFrame
    //     0xf97070: stp             fp, lr, [SP, #-0x10]!
    //     0xf97074: mov             fp, SP
    // 0xf97078: AllocStack(0x8)
    //     0xf97078: sub             SP, SP, #8
    // 0xf9707c: SetupParameters(ChewieController this /* r1 => r1, fp-0x8 */, dynamic _ /* r3 => r0 */, {dynamic additionalOptions = Null /* r6 */, dynamic aspectRatio = Null /* r7 */, dynamic showControlsOnInitialize = true /* r13 */})
    //     0xf9707c: mov             x0, x3
    //     0xf97080: stur            x1, [fp, #-8]
    //     0xf97084: ldur            w3, [x4, #0x13]
    //     0xf97088: ldur            w5, [x4, #0x1f]
    //     0xf9708c: add             x5, x5, HEAP, lsl #32
    //     0xf97090: add             x16, PP, #0xa5, lsl #12  ; [pp+0xa5f50] "additionalOptions"
    //     0xf97094: ldr             x16, [x16, #0xf50]
    //     0xf97098: cmp             w5, w16
    //     0xf9709c: b.ne            #0xf970c0
    //     0xf970a0: ldur            w5, [x4, #0x23]
    //     0xf970a4: add             x5, x5, HEAP, lsl #32
    //     0xf970a8: sub             w6, w3, w5
    //     0xf970ac: add             x5, fp, w6, sxtw #2
    //     0xf970b0: ldr             x5, [x5, #8]
    //     0xf970b4: mov             x6, x5
    //     0xf970b8: mov             x5, #1
    //     0xf970bc: b               #0xf970c8
    //     0xf970c0: mov             x6, NULL
    //     0xf970c4: mov             x5, #0
    //     0xf970c8: lsl             x7, x5, #1
    //     0xf970cc: lsl             w8, w7, #1
    //     0xf970d0: add             w9, w8, #8
    //     0xf970d4: add             x16, x4, w9, sxtw #1
    //     0xf970d8: ldur            w10, [x16, #0xf]
    //     0xf970dc: add             x10, x10, HEAP, lsl #32
    //     0xf970e0: add             x16, PP, #0xa5, lsl #12  ; [pp+0xa5f58] "aspectRatio"
    //     0xf970e4: ldr             x16, [x16, #0xf58]
    //     0xf970e8: cmp             w10, w16
    //     0xf970ec: b.ne            #0xf97120
    //     0xf970f0: add             w5, w8, #0xa
    //     0xf970f4: add             x16, x4, w5, sxtw #1
    //     0xf970f8: ldur            w8, [x16, #0xf]
    //     0xf970fc: add             x8, x8, HEAP, lsl #32
    //     0xf97100: sub             w5, w3, w8
    //     0xf97104: add             x8, fp, w5, sxtw #2
    //     0xf97108: ldr             x8, [x8, #8]
    //     0xf9710c: add             w5, w7, #2
    //     0xf97110: sbfx            x7, x5, #1, #0x1f
    //     0xf97114: mov             x5, x7
    //     0xf97118: mov             x7, x8
    //     0xf9711c: b               #0xf97124
    //     0xf97120: mov             x7, NULL
    //     0xf97124: lsl             x8, x5, #1
    //     0xf97128: lsl             w5, w8, #1
    //     0xf9712c: add             w8, w5, #8
    //     0xf97130: add             x16, x4, w8, sxtw #1
    //     0xf97134: ldur            w9, [x16, #0xf]
    //     0xf97138: add             x9, x9, HEAP, lsl #32
    //     0xf9713c: add             x16, PP, #0xa5, lsl #12  ; [pp+0xa5f60] "showControlsOnInitialize"
    //     0xf97140: ldr             x16, [x16, #0xf60]
    //     0xf97144: cmp             w9, w16
    //     0xf97148: b.ne            #0xf97170
    //     0xf9714c: add             w8, w5, #0xa
    //     0xf97150: add             x16, x4, w8, sxtw #1
    //     0xf97154: ldur            w5, [x16, #0xf]
    //     0xf97158: add             x5, x5, HEAP, lsl #32
    //     0xf9715c: sub             w4, w3, w5
    //     0xf97160: add             x3, fp, w4, sxtw #2
    //     0xf97164: ldr             x3, [x3, #8]
    //     0xf97168: mov             x13, x3
    //     0xf9716c: b               #0xf97174
    //     0xf97170: add             x13, NULL, #0x20  ; true
    //     0xf97174: add             x12, NULL, #0x20  ; true
    //     0xf97178: add             x11, NULL, #0x30  ; false
    //     0xf9717c: ldr             x10, [PP, #0x7cd8]  ; [pp+0x7cd8] Obj!Duration@12c8971
    //     0xf97180: add             x9, PP, #0xa5, lsl #12  ; [pp+0xa5f68] List<double>(8)
    //     0xf97184: ldr             x9, [x9, #0xf68]
    //     0xf97188: add             x8, PP, #0xa5, lsl #12  ; [pp+0xa5f70] List<SystemUiOverlay>(2)
    //     0xf9718c: ldr             x8, [x8, #0xf70]
    //     0xf97190: add             x5, PP, #0xa5, lsl #12  ; [pp+0xa5f78] List<DeviceOrientation>(4)
    //     0xf97194: ldr             x5, [x5, #0xf78]
    //     0xf97198: add             x4, PP, #0x16, lsl #12  ; [pp+0x16670] Obj!Duration@12c8961
    //     0xf9719c: ldr             x4, [x4, #0x670]
    //     0xf971a0: ldr             x3, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    //     0xf971a4: fmov            d0, #26.00000000
    // 0xf97174: r12 = true
    // 0xf97178: r11 = false
    // 0xf9717c: r10 = Instance_Duration
    // 0xf97180: r9 = const [0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0]
    // 0xf97188: r8 = const [Instance of 'SystemUiOverlay', Instance of 'SystemUiOverlay']
    // 0xf97190: r5 = const [Instance of 'DeviceOrientation', Instance of 'DeviceOrientation', Instance of 'DeviceOrientation', Instance of 'DeviceOrientation']
    // 0xf97198: r4 = Instance_Duration
    // 0xf971a0: r3 = Instance_EdgeInsets
    // 0xf971a4: d0 = 26.000000
    // 0xf971a8: CheckStackOverflow
    //     0xf971a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf971ac: cmp             SP, x16
    //     0xf971b0: b.ls            #0xf972d0
    // 0xf971b4: StoreField: r1->field_cf = r11
    //     0xf971b4: stur            w11, [x1, #0xcf]
    // 0xf971b8: StoreField: r1->field_3b = r0
    //     0xf971b8: stur            w0, [x1, #0x3b]
    //     0xf971bc: ldurb           w16, [x1, #-1]
    //     0xf971c0: ldurb           w17, [x0, #-1]
    //     0xf971c4: and             x16, x17, x16, lsr #2
    //     0xf971c8: tst             x16, HEAP, lsr #32
    //     0xf971cc: b.eq            #0xf971d4
    //     0xf971d0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf971d4: mov             x0, x7
    // 0xf971d8: StoreField: r1->field_6f = r0
    //     0xf971d8: stur            w0, [x1, #0x6f]
    //     0xf971dc: ldurb           w16, [x1, #-1]
    //     0xf971e0: ldurb           w17, [x0, #-1]
    //     0xf971e4: and             x16, x17, x16, lsr #2
    //     0xf971e8: tst             x16, HEAP, lsr #32
    //     0xf971ec: b.eq            #0xf971f4
    //     0xf971f0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf971f4: StoreField: r1->field_3f = r11
    //     0xf971f4: stur            w11, [x1, #0x3f]
    // 0xf971f8: StoreField: r1->field_43 = r2
    //     0xf971f8: stur            w2, [x1, #0x43]
    // 0xf971fc: StoreField: r1->field_47 = r12
    //     0xf971fc: stur            w12, [x1, #0x47]
    // 0xf97200: StoreField: r1->field_4f = r12
    //     0xf97200: stur            w12, [x1, #0x4f]
    // 0xf97204: StoreField: r1->field_8f = r11
    //     0xf97204: stur            w11, [x1, #0x8f]
    // 0xf97208: StoreField: r1->field_7b = r10
    //     0xf97208: stur            w10, [x1, #0x7b]
    // 0xf9720c: StoreField: r1->field_7f = d0
    //     0xf9720c: stur            d0, [x1, #0x7f]
    // 0xf97210: StoreField: r1->field_53 = r13
    //     0xf97210: stur            w13, [x1, #0x53]
    // 0xf97214: StoreField: r1->field_23 = r12
    //     0xf97214: stur            w12, [x1, #0x23]
    // 0xf97218: mov             x0, x6
    // 0xf9721c: StoreField: r1->field_2f = r0
    //     0xf9721c: stur            w0, [x1, #0x2f]
    //     0xf97220: ldurb           w16, [x1, #-1]
    //     0xf97224: ldurb           w17, [x0, #-1]
    //     0xf97228: and             x16, x17, x16, lsr #2
    //     0xf9722c: tst             x16, HEAP, lsr #32
    //     0xf97230: b.eq            #0xf97238
    //     0xf97234: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf97238: StoreField: r1->field_57 = r12
    //     0xf97238: stur            w12, [x1, #0x57]
    // 0xf9723c: StoreField: r1->field_5f = r11
    //     0xf9723c: stur            w11, [x1, #0x5f]
    // 0xf97240: StoreField: r1->field_37 = r11
    //     0xf97240: stur            w11, [x1, #0x37]
    // 0xf97244: StoreField: r1->field_93 = r12
    //     0xf97244: stur            w12, [x1, #0x93]
    // 0xf97248: StoreField: r1->field_97 = r11
    //     0xf97248: stur            w11, [x1, #0x97]
    // 0xf9724c: StoreField: r1->field_9b = r12
    //     0xf9724c: stur            w12, [x1, #0x9b]
    // 0xf97250: StoreField: r1->field_9f = r12
    //     0xf97250: stur            w12, [x1, #0x9f]
    // 0xf97254: StoreField: r1->field_a3 = r12
    //     0xf97254: stur            w12, [x1, #0xa3]
    // 0xf97258: StoreField: r1->field_a7 = r12
    //     0xf97258: stur            w12, [x1, #0xa7]
    // 0xf9725c: StoreField: r1->field_af = r9
    //     0xf9725c: stur            w9, [x1, #0xaf]
    // 0xf97260: StoreField: r1->field_b7 = r8
    //     0xf97260: stur            w8, [x1, #0xb7]
    // 0xf97264: StoreField: r1->field_bb = r5
    //     0xf97264: stur            w5, [x1, #0xbb]
    // 0xf97268: StoreField: r1->field_ab = r4
    //     0xf97268: stur            w4, [x1, #0xab]
    // 0xf9726c: StoreField: r1->field_c7 = r3
    //     0xf9726c: stur            w3, [x1, #0xc7]
    // 0xf97270: StoreField: r1->field_cb = r11
    //     0xf97270: stur            w11, [x1, #0xcb]
    // 0xf97274: StoreField: r1->field_7 = rZR
    //     0xf97274: stur            xzr, [x1, #7]
    // 0xf97278: StoreField: r1->field_13 = rZR
    //     0xf97278: stur            xzr, [x1, #0x13]
    // 0xf9727c: StoreField: r1->field_1b = rZR
    //     0xf9727c: stur            xzr, [x1, #0x1b]
    // 0xf97280: r0 = LoadStaticField(0x45c)
    //     0xf97280: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf97284: ldr             x0, [x0, #0x8b8]
    // 0xf97288: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf9728c: cmp             w0, w16
    // 0xf97290: b.ne            #0xf9729c
    // 0xf97294: r2 = _emptyListeners
    //     0xf97294: ldr             x2, [PP, #0x17f0]  ; [pp+0x17f0] Field <ChangeNotifier._emptyListeners@28329750>: static late final (offset: 0x45c)
    // 0xf97298: r0 = InitLateFinalStaticField()
    //     0xf97298: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xf9729c: ldur            x1, [fp, #-8]
    // 0xf972a0: StoreField: r1->field_f = r0
    //     0xf972a0: stur            w0, [x1, #0xf]
    //     0xf972a4: ldurb           w16, [x1, #-1]
    //     0xf972a8: ldurb           w17, [x0, #-1]
    //     0xf972ac: and             x16, x17, x16, lsr #2
    //     0xf972b0: tst             x16, HEAP, lsr #32
    //     0xf972b4: b.eq            #0xf972bc
    //     0xf972b8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf972bc: r0 = _initialize()
    //     0xf972bc: bl              #0xf972d8  ; [package:chewie/src/chewie_player.dart] ChewieController::_initialize
    // 0xf972c0: r0 = Null
    //     0xf972c0: mov             x0, NULL
    // 0xf972c4: LeaveFrame
    //     0xf972c4: mov             SP, fp
    //     0xf972c8: ldp             fp, lr, [SP], #0x10
    // 0xf972cc: ret
    //     0xf972cc: ret             
    // 0xf972d0: r0 = StackOverflowSharedWithFPURegs()
    //     0xf972d0: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xf972d4: b               #0xf971b4
  }
  _ _initialize(/* No info */) async {
    // ** addr: 0xf972d8, size: 0xb8
    // 0xf972d8: EnterFrame
    //     0xf972d8: stp             fp, lr, [SP, #-0x10]!
    //     0xf972dc: mov             fp, SP
    // 0xf972e0: AllocStack(0x28)
    //     0xf972e0: sub             SP, SP, #0x28
    // 0xf972e4: SetupParameters(ChewieController this /* r1 => r1, fp-0x10 */)
    //     0xf972e4: stur            NULL, [fp, #-8]
    //     0xf972e8: stur            x1, [fp, #-0x10]
    // 0xf972ec: CheckStackOverflow
    //     0xf972ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf972f0: cmp             SP, x16
    //     0xf972f4: b.ls            #0xf97388
    // 0xf972f8: InitAsync() -> Future
    //     0xf972f8: mov             x0, NULL
    //     0xf972fc: bl              #0x7f5e44  ; InitAsyncStub
    // 0xf97300: ldur            x0, [fp, #-0x10]
    // 0xf97304: LoadField: r2 = r0->field_3b
    //     0xf97304: ldur            w2, [x0, #0x3b]
    // 0xf97308: DecompressPointer r2
    //     0xf97308: add             x2, x2, HEAP, lsl #32
    // 0xf9730c: mov             x1, x2
    // 0xf97310: stur            x2, [fp, #-0x18]
    // 0xf97314: r0 = setLooping()
    //     0xf97314: bl              #0xf97390  ; [package:video_player/video_player.dart] VideoPlayerController::setLooping
    // 0xf97318: mov             x1, x0
    // 0xf9731c: stur            x1, [fp, #-0x20]
    // 0xf97320: r0 = Await()
    //     0xf97320: bl              #0x7f5c00  ; AwaitStub
    // 0xf97324: ldur            x0, [fp, #-0x10]
    // 0xf97328: LoadField: r2 = r0->field_43
    //     0xf97328: ldur            w2, [x0, #0x43]
    // 0xf9732c: DecompressPointer r2
    //     0xf9732c: add             x2, x2, HEAP, lsl #32
    // 0xf97330: stur            x2, [fp, #-0x20]
    // 0xf97334: tbnz            w2, #4, #0xf97364
    // 0xf97338: ldur            x3, [fp, #-0x18]
    // 0xf9733c: LoadField: r1 = r3->field_27
    //     0xf9733c: ldur            w1, [x3, #0x27]
    // 0xf97340: DecompressPointer r1
    //     0xf97340: add             x1, x1, HEAP, lsl #32
    // 0xf97344: LoadField: r4 = r1->field_4f
    //     0xf97344: ldur            w4, [x1, #0x4f]
    // 0xf97348: DecompressPointer r4
    //     0xf97348: add             x4, x4, HEAP, lsl #32
    // 0xf9734c: tbz             w4, #4, #0xf97364
    // 0xf97350: mov             x1, x3
    // 0xf97354: r0 = initialize()
    //     0xf97354: bl              #0xdd1314  ; [package:video_player/video_player.dart] VideoPlayerController::initialize
    // 0xf97358: mov             x1, x0
    // 0xf9735c: stur            x1, [fp, #-0x28]
    // 0xf97360: r0 = Await()
    //     0xf97360: bl              #0x7f5c00  ; AwaitStub
    // 0xf97364: ldur            x0, [fp, #-0x20]
    // 0xf97368: tbnz            w0, #4, #0xf97380
    // 0xf9736c: ldur            x1, [fp, #-0x18]
    // 0xf97370: r0 = play()
    //     0xf97370: bl              #0x8d57ac  ; [package:video_player/video_player.dart] VideoPlayerController::play
    // 0xf97374: mov             x1, x0
    // 0xf97378: stur            x1, [fp, #-0x18]
    // 0xf9737c: r0 = Await()
    //     0xf9737c: bl              #0x7f5c00  ; AwaitStub
    // 0xf97380: r0 = Null
    //     0xf97380: mov             x0, NULL
    // 0xf97384: r0 = ReturnAsyncNotFuture()
    //     0xf97384: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xf97388: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf97388: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf9738c: b               #0xf972f8
  }
}

// class id: 5500, size: 0x1c, field offset: 0x14
class ChewieState extends State<dynamic> {

  late PlayerNotifier notifier; // offset: 0x18

  _ build(/* No info */) {
    // ** addr: 0xde1cec, size: 0xb8
    // 0xde1cec: EnterFrame
    //     0xde1cec: stp             fp, lr, [SP, #-0x10]!
    //     0xde1cf0: mov             fp, SP
    // 0xde1cf4: AllocStack(0x18)
    //     0xde1cf4: sub             SP, SP, #0x18
    // 0xde1cf8: CheckStackOverflow
    //     0xde1cf8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde1cfc: cmp             SP, x16
    //     0xde1d00: b.ls            #0xde1d8c
    // 0xde1d04: LoadField: r0 = r1->field_b
    //     0xde1d04: ldur            w0, [x1, #0xb]
    // 0xde1d08: DecompressPointer r0
    //     0xde1d08: add             x0, x0, HEAP, lsl #32
    // 0xde1d0c: cmp             w0, NULL
    // 0xde1d10: b.eq            #0xde1d94
    // 0xde1d14: LoadField: r3 = r0->field_b
    //     0xde1d14: ldur            w3, [x0, #0xb]
    // 0xde1d18: DecompressPointer r3
    //     0xde1d18: add             x3, x3, HEAP, lsl #32
    // 0xde1d1c: stur            x3, [fp, #-0x10]
    // 0xde1d20: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xde1d20: ldur            w0, [x1, #0x17]
    // 0xde1d24: DecompressPointer r0
    //     0xde1d24: add             x0, x0, HEAP, lsl #32
    // 0xde1d28: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xde1d2c: cmp             w0, w16
    // 0xde1d30: b.eq            #0xde1d98
    // 0xde1d34: stur            x0, [fp, #-8]
    // 0xde1d38: r1 = Function '<anonymous closure>':.
    //     0xde1d38: add             x1, PP, #0xcf, lsl #12  ; [pp+0xcf6e8] AnonymousClosure: (0xde1e74), in [package:chewie/src/chewie_player.dart] ChewieState::build (0xde1cec)
    //     0xde1d3c: ldr             x1, [x1, #0x6e8]
    // 0xde1d40: r2 = Null
    //     0xde1d40: mov             x2, NULL
    // 0xde1d44: r0 = AllocateClosure()
    //     0xde1d44: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xde1d48: r1 = <PlayerNotifier>
    //     0xde1d48: add             x1, PP, #0xcf, lsl #12  ; [pp+0xcf6f0] TypeArguments: <PlayerNotifier>
    //     0xde1d4c: ldr             x1, [x1, #0x6f0]
    // 0xde1d50: stur            x0, [fp, #-0x18]
    // 0xde1d54: r0 = ChangeNotifierProvider()
    //     0xde1d54: bl              #0xde1e68  ; AllocateChangeNotifierProviderStub -> ChangeNotifierProvider<X0 bound ChangeNotifier?> (size=0x20)
    // 0xde1d58: mov             x1, x0
    // 0xde1d5c: ldur            x2, [fp, #-0x18]
    // 0xde1d60: ldur            x3, [fp, #-8]
    // 0xde1d64: stur            x0, [fp, #-8]
    // 0xde1d68: r0 = InheritedProvider.value()
    //     0xde1d68: bl              #0xde1dd4  ; [package:provider/src/provider.dart] InheritedProvider::InheritedProvider.value
    // 0xde1d6c: r0 = ChewieControllerProvider()
    //     0xde1d6c: bl              #0xde1dc8  ; AllocateChewieControllerProviderStub -> ChewieControllerProvider (size=0x14)
    // 0xde1d70: ldur            x1, [fp, #-0x10]
    // 0xde1d74: StoreField: r0->field_f = r1
    //     0xde1d74: stur            w1, [x0, #0xf]
    // 0xde1d78: ldur            x1, [fp, #-8]
    // 0xde1d7c: StoreField: r0->field_b = r1
    //     0xde1d7c: stur            w1, [x0, #0xb]
    // 0xde1d80: LeaveFrame
    //     0xde1d80: mov             SP, fp
    //     0xde1d84: ldp             fp, lr, [SP], #0x10
    // 0xde1d88: ret
    //     0xde1d88: ret             
    // 0xde1d8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde1d8c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde1d90: b               #0xde1d04
    // 0xde1d94: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde1d94: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde1d98: r9 = notifier
    //     0xde1d98: add             x9, PP, #0xcf, lsl #12  ; [pp+0xcf6f8] Field <ChewieState.notifier>: late (offset: 0x18)
    //     0xde1d9c: ldr             x9, [x9, #0x6f8]
    // 0xde1da0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xde1da0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] PlayerWithControls <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0xde1e74, size: 0xc
    // 0xde1e74: r0 = Instance_PlayerWithControls
    //     0xde1e74: add             x0, PP, #0xcf, lsl #12  ; [pp+0xcf700] Obj!PlayerWithControls@12b6af1
    //     0xde1e78: ldr             x0, [x0, #0x700]
    // 0xde1e7c: ret
    //     0xde1e7c: ret             
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf6bd0c, size: 0x15c
    // 0xf6bd0c: EnterFrame
    //     0xf6bd0c: stp             fp, lr, [SP, #-0x10]!
    //     0xf6bd10: mov             fp, SP
    // 0xf6bd14: AllocStack(0x18)
    //     0xf6bd14: sub             SP, SP, #0x18
    // 0xf6bd18: SetupParameters(ChewieState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xf6bd18: mov             x4, x1
    //     0xf6bd1c: mov             x3, x2
    //     0xf6bd20: stur            x1, [fp, #-8]
    //     0xf6bd24: stur            x2, [fp, #-0x10]
    // 0xf6bd28: CheckStackOverflow
    //     0xf6bd28: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6bd2c: cmp             SP, x16
    //     0xf6bd30: b.ls            #0xf6be58
    // 0xf6bd34: mov             x0, x3
    // 0xf6bd38: r2 = Null
    //     0xf6bd38: mov             x2, NULL
    // 0xf6bd3c: r1 = Null
    //     0xf6bd3c: mov             x1, NULL
    // 0xf6bd40: r4 = 60
    //     0xf6bd40: mov             x4, #0x3c
    // 0xf6bd44: branchIfSmi(r0, 0xf6bd50)
    //     0xf6bd44: tbz             w0, #0, #0xf6bd50
    // 0xf6bd48: r4 = LoadClassIdInstr(r0)
    //     0xf6bd48: ldur            x4, [x0, #-1]
    //     0xf6bd4c: ubfx            x4, x4, #0xc, #0x14
    // 0xf6bd50: r17 = 6538
    //     0xf6bd50: mov             x17, #0x198a
    // 0xf6bd54: cmp             x4, x17
    // 0xf6bd58: b.eq            #0xf6bd70
    // 0xf6bd5c: r8 = Chewie
    //     0xf6bd5c: add             x8, PP, #0xcf, lsl #12  ; [pp+0xcf720] Type: Chewie
    //     0xf6bd60: ldr             x8, [x8, #0x720]
    // 0xf6bd64: r3 = Null
    //     0xf6bd64: add             x3, PP, #0xcf, lsl #12  ; [pp+0xcf728] Null
    //     0xf6bd68: ldr             x3, [x3, #0x728]
    // 0xf6bd6c: r0 = Chewie()
    //     0xf6bd6c: bl              #0xde1da4  ; IsType_Chewie_Stub
    // 0xf6bd70: ldur            x0, [fp, #-0x10]
    // 0xf6bd74: LoadField: r1 = r0->field_b
    //     0xf6bd74: ldur            w1, [x0, #0xb]
    // 0xf6bd78: DecompressPointer r1
    //     0xf6bd78: add             x1, x1, HEAP, lsl #32
    // 0xf6bd7c: ldur            x3, [fp, #-8]
    // 0xf6bd80: LoadField: r2 = r3->field_b
    //     0xf6bd80: ldur            w2, [x3, #0xb]
    // 0xf6bd84: DecompressPointer r2
    //     0xf6bd84: add             x2, x2, HEAP, lsl #32
    // 0xf6bd88: cmp             w2, NULL
    // 0xf6bd8c: b.eq            #0xf6be60
    // 0xf6bd90: LoadField: r4 = r2->field_b
    //     0xf6bd90: ldur            w4, [x2, #0xb]
    // 0xf6bd94: DecompressPointer r4
    //     0xf6bd94: add             x4, x4, HEAP, lsl #32
    // 0xf6bd98: stur            x4, [fp, #-0x18]
    // 0xf6bd9c: cmp             w1, w4
    // 0xf6bda0: b.eq            #0xf6bdc0
    // 0xf6bda4: mov             x2, x3
    // 0xf6bda8: r1 = Function 'listener':.
    //     0xf6bda8: add             x1, PP, #0xcf, lsl #12  ; [pp+0xcf738] AnonymousClosure: (0xf6be98), in [package:chewie/src/chewie_player.dart] ChewieState::listener (0xf6bed0)
    //     0xf6bdac: ldr             x1, [x1, #0x738]
    // 0xf6bdb0: r0 = AllocateClosure()
    //     0xf6bdb0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf6bdb4: ldur            x1, [fp, #-0x18]
    // 0xf6bdb8: mov             x2, x0
    // 0xf6bdbc: r0 = addListener()
    //     0xf6bdbc: bl              #0xd038e0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0xf6bdc0: ldur            x3, [fp, #-8]
    // 0xf6bdc4: LoadField: r2 = r3->field_7
    //     0xf6bdc4: ldur            w2, [x3, #7]
    // 0xf6bdc8: DecompressPointer r2
    //     0xf6bdc8: add             x2, x2, HEAP, lsl #32
    // 0xf6bdcc: ldur            x0, [fp, #-0x10]
    // 0xf6bdd0: r1 = Null
    //     0xf6bdd0: mov             x1, NULL
    // 0xf6bdd4: cmp             w2, NULL
    // 0xf6bdd8: b.eq            #0xf6bdfc
    // 0xf6bddc: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf6bddc: ldur            w4, [x2, #0x17]
    // 0xf6bde0: DecompressPointer r4
    //     0xf6bde0: add             x4, x4, HEAP, lsl #32
    // 0xf6bde4: r8 = X0 bound StatefulWidget
    //     0xf6bde4: add             x8, PP, #0x12, lsl #12  ; [pp+0x12498] TypeParameter: X0 bound StatefulWidget
    //     0xf6bde8: ldr             x8, [x8, #0x498]
    // 0xf6bdec: LoadField: r9 = r4->field_7
    //     0xf6bdec: ldur            x9, [x4, #7]
    // 0xf6bdf0: r3 = Null
    //     0xf6bdf0: add             x3, PP, #0xcf, lsl #12  ; [pp+0xcf740] Null
    //     0xf6bdf4: ldr             x3, [x3, #0x740]
    // 0xf6bdf8: blr             x9
    // 0xf6bdfc: ldur            x0, [fp, #-8]
    // 0xf6be00: LoadField: r2 = r0->field_13
    //     0xf6be00: ldur            w2, [x0, #0x13]
    // 0xf6be04: DecompressPointer r2
    //     0xf6be04: add             x2, x2, HEAP, lsl #32
    // 0xf6be08: mov             x1, x0
    // 0xf6be0c: stur            x2, [fp, #-0x10]
    // 0xf6be10: r0 = isControllerFullScreen()
    //     0xf6be10: bl              #0xf6be68  ; [package:chewie/src/chewie_player.dart] ChewieState::isControllerFullScreen
    // 0xf6be14: ldur            x1, [fp, #-0x10]
    // 0xf6be18: cmp             w1, w0
    // 0xf6be1c: b.eq            #0xf6be48
    // 0xf6be20: ldur            x1, [fp, #-8]
    // 0xf6be24: LoadField: r2 = r1->field_b
    //     0xf6be24: ldur            w2, [x1, #0xb]
    // 0xf6be28: DecompressPointer r2
    //     0xf6be28: add             x2, x2, HEAP, lsl #32
    // 0xf6be2c: cmp             w2, NULL
    // 0xf6be30: b.eq            #0xf6be64
    // 0xf6be34: LoadField: r3 = r2->field_b
    //     0xf6be34: ldur            w3, [x2, #0xb]
    // 0xf6be38: DecompressPointer r3
    //     0xf6be38: add             x3, x3, HEAP, lsl #32
    // 0xf6be3c: LoadField: r2 = r1->field_13
    //     0xf6be3c: ldur            w2, [x1, #0x13]
    // 0xf6be40: DecompressPointer r2
    //     0xf6be40: add             x2, x2, HEAP, lsl #32
    // 0xf6be44: StoreField: r3->field_cf = r2
    //     0xf6be44: stur            w2, [x3, #0xcf]
    // 0xf6be48: r0 = Null
    //     0xf6be48: mov             x0, NULL
    // 0xf6be4c: LeaveFrame
    //     0xf6be4c: mov             SP, fp
    //     0xf6be50: ldp             fp, lr, [SP], #0x10
    // 0xf6be54: ret
    //     0xf6be54: ret             
    // 0xf6be58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6be58: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6be5c: b               #0xf6bd34
    // 0xf6be60: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6be60: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6be64: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6be64: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ isControllerFullScreen(/* No info */) {
    // ** addr: 0xf6be68, size: 0x30
    // 0xf6be68: LoadField: r2 = r1->field_b
    //     0xf6be68: ldur            w2, [x1, #0xb]
    // 0xf6be6c: DecompressPointer r2
    //     0xf6be6c: add             x2, x2, HEAP, lsl #32
    // 0xf6be70: cmp             w2, NULL
    // 0xf6be74: b.eq            #0xf6be8c
    // 0xf6be78: LoadField: r1 = r2->field_b
    //     0xf6be78: ldur            w1, [x2, #0xb]
    // 0xf6be7c: DecompressPointer r1
    //     0xf6be7c: add             x1, x1, HEAP, lsl #32
    // 0xf6be80: LoadField: r0 = r1->field_cf
    //     0xf6be80: ldur            w0, [x1, #0xcf]
    // 0xf6be84: DecompressPointer r0
    //     0xf6be84: add             x0, x0, HEAP, lsl #32
    // 0xf6be88: ret
    //     0xf6be88: ret             
    // 0xf6be8c: EnterFrame
    //     0xf6be8c: stp             fp, lr, [SP, #-0x10]!
    //     0xf6be90: mov             fp, SP
    // 0xf6be94: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6be94: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> listener(dynamic) {
    // ** addr: 0xf6be98, size: 0x38
    // 0xf6be98: EnterFrame
    //     0xf6be98: stp             fp, lr, [SP, #-0x10]!
    //     0xf6be9c: mov             fp, SP
    // 0xf6bea0: ldr             x0, [fp, #0x10]
    // 0xf6bea4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf6bea4: ldur            w1, [x0, #0x17]
    // 0xf6bea8: DecompressPointer r1
    //     0xf6bea8: add             x1, x1, HEAP, lsl #32
    // 0xf6beac: CheckStackOverflow
    //     0xf6beac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6beb0: cmp             SP, x16
    //     0xf6beb4: b.ls            #0xf6bec8
    // 0xf6beb8: r0 = listener()
    //     0xf6beb8: bl              #0xf6bed0  ; [package:chewie/src/chewie_player.dart] ChewieState::listener
    // 0xf6bebc: LeaveFrame
    //     0xf6bebc: mov             SP, fp
    //     0xf6bec0: ldp             fp, lr, [SP], #0x10
    // 0xf6bec4: ret
    //     0xf6bec4: ret             
    // 0xf6bec8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6bec8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6becc: b               #0xf6beb8
  }
  _ listener(/* No info */) async {
    // ** addr: 0xf6bed0, size: 0xf0
    // 0xf6bed0: EnterFrame
    //     0xf6bed0: stp             fp, lr, [SP, #-0x10]!
    //     0xf6bed4: mov             fp, SP
    // 0xf6bed8: AllocStack(0x28)
    //     0xf6bed8: sub             SP, SP, #0x28
    // 0xf6bedc: SetupParameters(ChewieState this /* r1 => r1, fp-0x10 */)
    //     0xf6bedc: stur            NULL, [fp, #-8]
    //     0xf6bee0: stur            x1, [fp, #-0x10]
    // 0xf6bee4: CheckStackOverflow
    //     0xf6bee4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6bee8: cmp             SP, x16
    //     0xf6beec: b.ls            #0xf6bfac
    // 0xf6bef0: InitAsync() -> Future<void?>
    //     0xf6bef0: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0xf6bef4: bl              #0x7f5e44  ; InitAsyncStub
    // 0xf6bef8: ldur            x0, [fp, #-0x10]
    // 0xf6befc: LoadField: r1 = r0->field_b
    //     0xf6befc: ldur            w1, [x0, #0xb]
    // 0xf6bf00: DecompressPointer r1
    //     0xf6bf00: add             x1, x1, HEAP, lsl #32
    // 0xf6bf04: cmp             w1, NULL
    // 0xf6bf08: b.eq            #0xf6bfb4
    // 0xf6bf0c: LoadField: r2 = r1->field_b
    //     0xf6bf0c: ldur            w2, [x1, #0xb]
    // 0xf6bf10: DecompressPointer r2
    //     0xf6bf10: add             x2, x2, HEAP, lsl #32
    // 0xf6bf14: LoadField: r1 = r2->field_cf
    //     0xf6bf14: ldur            w1, [x2, #0xcf]
    // 0xf6bf18: DecompressPointer r1
    //     0xf6bf18: add             x1, x1, HEAP, lsl #32
    // 0xf6bf1c: tbnz            w1, #4, #0xf6bf58
    // 0xf6bf20: LoadField: r2 = r0->field_13
    //     0xf6bf20: ldur            w2, [x0, #0x13]
    // 0xf6bf24: DecompressPointer r2
    //     0xf6bf24: add             x2, x2, HEAP, lsl #32
    // 0xf6bf28: tbz             w2, #4, #0xf6bf58
    // 0xf6bf2c: StoreField: r0->field_13 = r1
    //     0xf6bf2c: stur            w1, [x0, #0x13]
    // 0xf6bf30: LoadField: r2 = r0->field_f
    //     0xf6bf30: ldur            w2, [x0, #0xf]
    // 0xf6bf34: DecompressPointer r2
    //     0xf6bf34: add             x2, x2, HEAP, lsl #32
    // 0xf6bf38: cmp             w2, NULL
    // 0xf6bf3c: b.eq            #0xf6bfb8
    // 0xf6bf40: mov             x1, x0
    // 0xf6bf44: r0 = _pushFullScreenWidget()
    //     0xf6bf44: bl              #0xf6bfc0  ; [package:chewie/src/chewie_player.dart] ChewieState::_pushFullScreenWidget
    // 0xf6bf48: mov             x1, x0
    // 0xf6bf4c: stur            x1, [fp, #-0x18]
    // 0xf6bf50: r0 = Await()
    //     0xf6bf50: bl              #0x7f5c00  ; AwaitStub
    // 0xf6bf54: b               #0xf6bfa4
    // 0xf6bf58: LoadField: r1 = r0->field_13
    //     0xf6bf58: ldur            w1, [x0, #0x13]
    // 0xf6bf5c: DecompressPointer r1
    //     0xf6bf5c: add             x1, x1, HEAP, lsl #32
    // 0xf6bf60: tbnz            w1, #4, #0xf6bfa4
    // 0xf6bf64: LoadField: r1 = r0->field_f
    //     0xf6bf64: ldur            w1, [x0, #0xf]
    // 0xf6bf68: DecompressPointer r1
    //     0xf6bf68: add             x1, x1, HEAP, lsl #32
    // 0xf6bf6c: cmp             w1, NULL
    // 0xf6bf70: b.eq            #0xf6bfbc
    // 0xf6bf74: r16 = true
    //     0xf6bf74: add             x16, NULL, #0x20  ; true
    // 0xf6bf78: str             x16, [SP]
    // 0xf6bf7c: r4 = const [0, 0x2, 0x1, 0x1, rootNavigator, 0x1, null]
    //     0xf6bf7c: add             x4, PP, #0x15, lsl #12  ; [pp+0x150a0] List(7) [0, 0x2, 0x1, 0x1, "rootNavigator", 0x1, Null]
    //     0xf6bf80: ldr             x4, [x4, #0xa0]
    // 0xf6bf84: r0 = of()
    //     0xf6bf84: bl              #0xb35e68  ; [package:flutter/src/widgets/navigator.dart] Navigator::of
    // 0xf6bf88: r16 = <Object?>
    //     0xf6bf88: ldr             x16, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0xf6bf8c: stp             x0, x16, [SP]
    // 0xf6bf90: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xf6bf90: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xf6bf94: r0 = pop()
    //     0xf6bf94: bl              #0x8c87a0  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::pop
    // 0xf6bf98: ldur            x1, [fp, #-0x10]
    // 0xf6bf9c: r2 = false
    //     0xf6bf9c: add             x2, NULL, #0x30  ; false
    // 0xf6bfa0: StoreField: r1->field_13 = r2
    //     0xf6bfa0: stur            w2, [x1, #0x13]
    // 0xf6bfa4: r0 = Null
    //     0xf6bfa4: mov             x0, NULL
    // 0xf6bfa8: r0 = ReturnAsyncNotFuture()
    //     0xf6bfa8: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xf6bfac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6bfac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6bfb0: b               #0xf6bef0
    // 0xf6bfb4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6bfb4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6bfb8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6bfb8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6bfbc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6bfbc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _pushFullScreenWidget(/* No info */) async {
    // ** addr: 0xf6bfc0, size: 0x160
    // 0xf6bfc0: EnterFrame
    //     0xf6bfc0: stp             fp, lr, [SP, #-0x10]!
    //     0xf6bfc4: mov             fp, SP
    // 0xf6bfc8: AllocStack(0x38)
    //     0xf6bfc8: sub             SP, SP, #0x38
    // 0xf6bfcc: SetupParameters(ChewieState this /* r1 => r2, fp-0x10 */, dynamic _ /* r2 => r1, fp-0x18 */)
    //     0xf6bfcc: stur            NULL, [fp, #-8]
    //     0xf6bfd0: stur            x1, [fp, #-0x10]
    //     0xf6bfd4: mov             x16, x2
    //     0xf6bfd8: mov             x2, x1
    //     0xf6bfdc: mov             x1, x16
    //     0xf6bfe0: stur            x1, [fp, #-0x18]
    // 0xf6bfe4: CheckStackOverflow
    //     0xf6bfe4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6bfe8: cmp             SP, x16
    //     0xf6bfec: b.ls            #0xf6c108
    // 0xf6bff0: InitAsync() -> Future
    //     0xf6bff0: mov             x0, NULL
    //     0xf6bff4: bl              #0x7f5e44  ; InitAsyncStub
    // 0xf6bff8: ldur            x2, [fp, #-0x10]
    // 0xf6bffc: r1 = Function '_fullScreenRoutePageBuilder@1209330589':.
    //     0xf6bffc: add             x1, PP, #0xcf, lsl #12  ; [pp+0xcf750] AnonymousClosure: (0xf6c5b8), in [package:chewie/src/chewie_player.dart] ChewieState::_fullScreenRoutePageBuilder (0xf6c5fc)
    //     0xf6c000: ldr             x1, [x1, #0x750]
    // 0xf6c004: r0 = AllocateClosure()
    //     0xf6c004: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf6c008: r1 = <void?>
    //     0xf6c008: ldr             x1, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xf6c00c: stur            x0, [fp, #-0x20]
    // 0xf6c010: r0 = PageRouteBuilder()
    //     0xf6c010: bl              #0xf6c5ac  ; AllocatePageRouteBuilderStub -> PageRouteBuilder<X0> (size=0xc8)
    // 0xf6c014: mov             x1, x0
    // 0xf6c018: ldur            x2, [fp, #-0x20]
    // 0xf6c01c: stur            x0, [fp, #-0x20]
    // 0xf6c020: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xf6c020: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xf6c024: r0 = PageRouteBuilder()
    //     0xf6c024: bl              #0xf6c3f8  ; [package:flutter/src/widgets/pages.dart] PageRouteBuilder::PageRouteBuilder
    // 0xf6c028: ldur            x1, [fp, #-0x10]
    // 0xf6c02c: r0 = onEnterFullScreen()
    //     0xf6c02c: bl              #0xf6c258  ; [package:chewie/src/chewie_player.dart] ChewieState::onEnterFullScreen
    // 0xf6c030: ldur            x0, [fp, #-0x10]
    // 0xf6c034: LoadField: r1 = r0->field_b
    //     0xf6c034: ldur            w1, [x0, #0xb]
    // 0xf6c038: DecompressPointer r1
    //     0xf6c038: add             x1, x1, HEAP, lsl #32
    // 0xf6c03c: cmp             w1, NULL
    // 0xf6c040: b.eq            #0xf6c110
    // 0xf6c044: r16 = true
    //     0xf6c044: add             x16, NULL, #0x20  ; true
    // 0xf6c048: str             x16, [SP]
    // 0xf6c04c: ldur            x1, [fp, #-0x18]
    // 0xf6c050: r4 = const [0, 0x2, 0x1, 0x1, rootNavigator, 0x1, null]
    //     0xf6c050: add             x4, PP, #0x15, lsl #12  ; [pp+0x150a0] List(7) [0, 0x2, 0x1, 0x1, "rootNavigator", 0x1, Null]
    //     0xf6c054: ldr             x4, [x4, #0xa0]
    // 0xf6c058: r0 = of()
    //     0xf6c058: bl              #0xb35e68  ; [package:flutter/src/widgets/navigator.dart] Navigator::of
    // 0xf6c05c: r16 = <void?>
    //     0xf6c05c: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xf6c060: stp             x0, x16, [SP, #8]
    // 0xf6c064: ldur            x16, [fp, #-0x20]
    // 0xf6c068: str             x16, [SP]
    // 0xf6c06c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xf6c06c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xf6c070: r0 = push()
    //     0xf6c070: bl              #0x9ec7a0  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::push
    // 0xf6c074: mov             x1, x0
    // 0xf6c078: stur            x1, [fp, #-0x18]
    // 0xf6c07c: r0 = Await()
    //     0xf6c07c: bl              #0x7f5c00  ; AwaitStub
    // 0xf6c080: ldur            x0, [fp, #-0x10]
    // 0xf6c084: LoadField: r1 = r0->field_b
    //     0xf6c084: ldur            w1, [x0, #0xb]
    // 0xf6c088: DecompressPointer r1
    //     0xf6c088: add             x1, x1, HEAP, lsl #32
    // 0xf6c08c: cmp             w1, NULL
    // 0xf6c090: b.eq            #0xf6c114
    // 0xf6c094: r2 = false
    //     0xf6c094: add             x2, NULL, #0x30  ; false
    // 0xf6c098: StoreField: r0->field_13 = r2
    //     0xf6c098: stur            w2, [x0, #0x13]
    // 0xf6c09c: LoadField: r2 = r1->field_b
    //     0xf6c09c: ldur            w2, [x1, #0xb]
    // 0xf6c0a0: DecompressPointer r2
    //     0xf6c0a0: add             x2, x2, HEAP, lsl #32
    // 0xf6c0a4: mov             x1, x2
    // 0xf6c0a8: r0 = exitFullScreen()
    //     0xf6c0a8: bl              #0xf6c220  ; [package:chewie/src/chewie_player.dart] ChewieController::exitFullScreen
    // 0xf6c0ac: ldur            x0, [fp, #-0x10]
    // 0xf6c0b0: LoadField: r1 = r0->field_b
    //     0xf6c0b0: ldur            w1, [x0, #0xb]
    // 0xf6c0b4: DecompressPointer r1
    //     0xf6c0b4: add             x1, x1, HEAP, lsl #32
    // 0xf6c0b8: cmp             w1, NULL
    // 0xf6c0bc: b.eq            #0xf6c118
    // 0xf6c0c0: r16 = const [Instance of 'SystemUiOverlay', Instance of 'SystemUiOverlay']
    //     0xf6c0c0: add             x16, PP, #0xa5, lsl #12  ; [pp+0xa5f70] List<SystemUiOverlay>(2)
    //     0xf6c0c4: ldr             x16, [x16, #0xf70]
    // 0xf6c0c8: str             x16, [SP]
    // 0xf6c0cc: r1 = Instance_SystemUiMode
    //     0xf6c0cc: add             x1, PP, #8, lsl #12  ; [pp+0x8028] Obj!SystemUiMode@12c3a81
    //     0xf6c0d0: ldr             x1, [x1, #0x28]
    // 0xf6c0d4: r4 = const [0, 0x2, 0x1, 0x1, overlays, 0x1, null]
    //     0xf6c0d4: add             x4, PP, #0xcf, lsl #12  ; [pp+0xcf758] List(7) [0, 0x2, 0x1, 0x1, "overlays", 0x1, Null]
    //     0xf6c0d8: ldr             x4, [x4, #0x758]
    // 0xf6c0dc: r0 = setEnabledSystemUIMode()
    //     0xf6c0dc: bl              #0xf6c120  ; [package:flutter/src/services/system_chrome.dart] SystemChrome::setEnabledSystemUIMode
    // 0xf6c0e0: ldur            x0, [fp, #-0x10]
    // 0xf6c0e4: LoadField: r1 = r0->field_b
    //     0xf6c0e4: ldur            w1, [x0, #0xb]
    // 0xf6c0e8: DecompressPointer r1
    //     0xf6c0e8: add             x1, x1, HEAP, lsl #32
    // 0xf6c0ec: cmp             w1, NULL
    // 0xf6c0f0: b.eq            #0xf6c11c
    // 0xf6c0f4: r1 = const [Instance of 'DeviceOrientation', Instance of 'DeviceOrientation', Instance of 'DeviceOrientation', Instance of 'DeviceOrientation']
    //     0xf6c0f4: add             x1, PP, #0xa5, lsl #12  ; [pp+0xa5f78] List<DeviceOrientation>(4)
    //     0xf6c0f8: ldr             x1, [x1, #0xf78]
    // 0xf6c0fc: r0 = setPreferredOrientations()
    //     0xf6c0fc: bl              #0xeb70e8  ; [package:flutter/src/services/system_chrome.dart] SystemChrome::setPreferredOrientations
    // 0xf6c100: r0 = Null
    //     0xf6c100: mov             x0, NULL
    // 0xf6c104: r0 = ReturnAsyncNotFuture()
    //     0xf6c104: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xf6c108: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6c108: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6c10c: b               #0xf6bff0
    // 0xf6c110: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6c110: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6c114: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6c114: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6c118: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6c118: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6c11c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6c11c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ onEnterFullScreen(/* No info */) {
    // ** addr: 0xf6c258, size: 0x17c
    // 0xf6c258: EnterFrame
    //     0xf6c258: stp             fp, lr, [SP, #-0x10]!
    //     0xf6c25c: mov             fp, SP
    // 0xf6c260: AllocStack(0x20)
    //     0xf6c260: sub             SP, SP, #0x20
    // 0xf6c264: SetupParameters(ChewieState this /* r1 => r0, fp-0x8 */)
    //     0xf6c264: mov             x0, x1
    //     0xf6c268: stur            x1, [fp, #-8]
    // 0xf6c26c: CheckStackOverflow
    //     0xf6c26c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6c270: cmp             SP, x16
    //     0xf6c274: b.ls            #0xf6c3c4
    // 0xf6c278: LoadField: r1 = r0->field_b
    //     0xf6c278: ldur            w1, [x0, #0xb]
    // 0xf6c27c: DecompressPointer r1
    //     0xf6c27c: add             x1, x1, HEAP, lsl #32
    // 0xf6c280: cmp             w1, NULL
    // 0xf6c284: b.eq            #0xf6c3cc
    // 0xf6c288: LoadField: r2 = r1->field_b
    //     0xf6c288: ldur            w2, [x1, #0xb]
    // 0xf6c28c: DecompressPointer r2
    //     0xf6c28c: add             x2, x2, HEAP, lsl #32
    // 0xf6c290: LoadField: r1 = r2->field_3b
    //     0xf6c290: ldur            w1, [x2, #0x3b]
    // 0xf6c294: DecompressPointer r1
    //     0xf6c294: add             x1, x1, HEAP, lsl #32
    // 0xf6c298: LoadField: r2 = r1->field_27
    //     0xf6c298: ldur            w2, [x1, #0x27]
    // 0xf6c29c: DecompressPointer r2
    //     0xf6c29c: add             x2, x2, HEAP, lsl #32
    // 0xf6c2a0: LoadField: r1 = r2->field_43
    //     0xf6c2a0: ldur            w1, [x2, #0x43]
    // 0xf6c2a4: DecompressPointer r1
    //     0xf6c2a4: add             x1, x1, HEAP, lsl #32
    // 0xf6c2a8: LoadField: d0 = r1->field_7
    //     0xf6c2a8: ldur            d0, [x1, #7]
    // 0xf6c2ac: stur            d0, [fp, #-0x18]
    // 0xf6c2b0: LoadField: d1 = r1->field_f
    //     0xf6c2b0: ldur            d1, [x1, #0xf]
    // 0xf6c2b4: stur            d1, [fp, #-0x10]
    // 0xf6c2b8: r1 = <SystemUiOverlay>
    //     0xf6c2b8: add             x1, PP, #0xcf, lsl #12  ; [pp+0xcf778] TypeArguments: <SystemUiOverlay>
    //     0xf6c2bc: ldr             x1, [x1, #0x778]
    // 0xf6c2c0: r2 = 0
    //     0xf6c2c0: mov             x2, #0
    // 0xf6c2c4: r0 = _GrowableList()
    //     0xf6c2c4: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xf6c2c8: str             x0, [SP]
    // 0xf6c2cc: r1 = Instance_SystemUiMode
    //     0xf6c2cc: add             x1, PP, #8, lsl #12  ; [pp+0x8028] Obj!SystemUiMode@12c3a81
    //     0xf6c2d0: ldr             x1, [x1, #0x28]
    // 0xf6c2d4: r4 = const [0, 0x2, 0x1, 0x1, overlays, 0x1, null]
    //     0xf6c2d4: add             x4, PP, #0xcf, lsl #12  ; [pp+0xcf758] List(7) [0, 0x2, 0x1, 0x1, "overlays", 0x1, Null]
    //     0xf6c2d8: ldr             x4, [x4, #0x758]
    // 0xf6c2dc: r0 = setEnabledSystemUIMode()
    //     0xf6c2dc: bl              #0xf6c120  ; [package:flutter/src/services/system_chrome.dart] SystemChrome::setEnabledSystemUIMode
    // 0xf6c2e0: ldur            x0, [fp, #-8]
    // 0xf6c2e4: LoadField: r1 = r0->field_b
    //     0xf6c2e4: ldur            w1, [x0, #0xb]
    // 0xf6c2e8: DecompressPointer r1
    //     0xf6c2e8: add             x1, x1, HEAP, lsl #32
    // 0xf6c2ec: cmp             w1, NULL
    // 0xf6c2f0: b.eq            #0xf6c3d0
    // 0xf6c2f4: ldur            d0, [fp, #-0x18]
    // 0xf6c2f8: ldur            d1, [fp, #-0x10]
    // 0xf6c2fc: fcmp            d0, d1
    // 0xf6c300: b.le            #0xf6c354
    // 0xf6c304: r0 = 4
    //     0xf6c304: mov             x0, #4
    // 0xf6c308: mov             x2, x0
    // 0xf6c30c: r1 = Null
    //     0xf6c30c: mov             x1, NULL
    // 0xf6c310: r0 = AllocateArray()
    //     0xf6c310: bl              #0x13df928  ; AllocateArrayStub
    // 0xf6c314: stur            x0, [fp, #-8]
    // 0xf6c318: r16 = Instance_DeviceOrientation
    //     0xf6c318: add             x16, PP, #0x7c, lsl #12  ; [pp+0x7cbb0] Obj!DeviceOrientation@12c3b21
    //     0xf6c31c: ldr             x16, [x16, #0xbb0]
    // 0xf6c320: StoreField: r0->field_f = r16
    //     0xf6c320: stur            w16, [x0, #0xf]
    // 0xf6c324: r16 = Instance_DeviceOrientation
    //     0xf6c324: add             x16, PP, #0x7c, lsl #12  ; [pp+0x7cba8] Obj!DeviceOrientation@12c3b01
    //     0xf6c328: ldr             x16, [x16, #0xba8]
    // 0xf6c32c: StoreField: r0->field_13 = r16
    //     0xf6c32c: stur            w16, [x0, #0x13]
    // 0xf6c330: r1 = <DeviceOrientation>
    //     0xf6c330: ldr             x1, [PP, #0x7900]  ; [pp+0x7900] TypeArguments: <DeviceOrientation>
    // 0xf6c334: r0 = AllocateGrowableArray()
    //     0xf6c334: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xf6c338: mov             x1, x0
    // 0xf6c33c: ldur            x0, [fp, #-8]
    // 0xf6c340: StoreField: r1->field_f = r0
    //     0xf6c340: stur            w0, [x1, #0xf]
    // 0xf6c344: r0 = 4
    //     0xf6c344: mov             x0, #4
    // 0xf6c348: StoreField: r1->field_b = r0
    //     0xf6c348: stur            w0, [x1, #0xb]
    // 0xf6c34c: r0 = setPreferredOrientations()
    //     0xf6c34c: bl              #0xeb70e8  ; [package:flutter/src/services/system_chrome.dart] SystemChrome::setPreferredOrientations
    // 0xf6c350: b               #0xf6c3b4
    // 0xf6c354: r0 = 4
    //     0xf6c354: mov             x0, #4
    // 0xf6c358: fcmp            d1, d0
    // 0xf6c35c: b.le            #0xf6c3a8
    // 0xf6c360: mov             x2, x0
    // 0xf6c364: r1 = Null
    //     0xf6c364: mov             x1, NULL
    // 0xf6c368: r0 = AllocateArray()
    //     0xf6c368: bl              #0x13df928  ; AllocateArrayStub
    // 0xf6c36c: stur            x0, [fp, #-8]
    // 0xf6c370: r16 = Instance_DeviceOrientation
    //     0xf6c370: ldr             x16, [PP, #0x78f8]  ; [pp+0x78f8] Obj!DeviceOrientation@12c3b61
    // 0xf6c374: StoreField: r0->field_f = r16
    //     0xf6c374: stur            w16, [x0, #0xf]
    // 0xf6c378: r16 = Instance_DeviceOrientation
    //     0xf6c378: add             x16, PP, #0x7c, lsl #12  ; [pp+0x7cbc8] Obj!DeviceOrientation@12c3b41
    //     0xf6c37c: ldr             x16, [x16, #0xbc8]
    // 0xf6c380: StoreField: r0->field_13 = r16
    //     0xf6c380: stur            w16, [x0, #0x13]
    // 0xf6c384: r1 = <DeviceOrientation>
    //     0xf6c384: ldr             x1, [PP, #0x7900]  ; [pp+0x7900] TypeArguments: <DeviceOrientation>
    // 0xf6c388: r0 = AllocateGrowableArray()
    //     0xf6c388: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xf6c38c: mov             x1, x0
    // 0xf6c390: ldur            x0, [fp, #-8]
    // 0xf6c394: StoreField: r1->field_f = r0
    //     0xf6c394: stur            w0, [x1, #0xf]
    // 0xf6c398: r0 = 4
    //     0xf6c398: mov             x0, #4
    // 0xf6c39c: StoreField: r1->field_b = r0
    //     0xf6c39c: stur            w0, [x1, #0xb]
    // 0xf6c3a0: r0 = setPreferredOrientations()
    //     0xf6c3a0: bl              #0xeb70e8  ; [package:flutter/src/services/system_chrome.dart] SystemChrome::setPreferredOrientations
    // 0xf6c3a4: b               #0xf6c3b4
    // 0xf6c3a8: r1 = const [Instance of 'DeviceOrientation', Instance of 'DeviceOrientation', Instance of 'DeviceOrientation', Instance of 'DeviceOrientation']
    //     0xf6c3a8: add             x1, PP, #0xa5, lsl #12  ; [pp+0xa5f78] List<DeviceOrientation>(4)
    //     0xf6c3ac: ldr             x1, [x1, #0xf78]
    // 0xf6c3b0: r0 = setPreferredOrientations()
    //     0xf6c3b0: bl              #0xeb70e8  ; [package:flutter/src/services/system_chrome.dart] SystemChrome::setPreferredOrientations
    // 0xf6c3b4: r0 = Null
    //     0xf6c3b4: mov             x0, NULL
    // 0xf6c3b8: LeaveFrame
    //     0xf6c3b8: mov             SP, fp
    //     0xf6c3bc: ldp             fp, lr, [SP], #0x10
    // 0xf6c3c0: ret
    //     0xf6c3c0: ret             
    // 0xf6c3c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6c3c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6c3c8: b               #0xf6c278
    // 0xf6c3cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6c3cc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6c3d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6c3d0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Widget _fullScreenRoutePageBuilder(dynamic, BuildContext, Animation<double>, Animation<double>) {
    // ** addr: 0xf6c5b8, size: 0x44
    // 0xf6c5b8: EnterFrame
    //     0xf6c5b8: stp             fp, lr, [SP, #-0x10]!
    //     0xf6c5bc: mov             fp, SP
    // 0xf6c5c0: ldr             x0, [fp, #0x28]
    // 0xf6c5c4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf6c5c4: ldur            w1, [x0, #0x17]
    // 0xf6c5c8: DecompressPointer r1
    //     0xf6c5c8: add             x1, x1, HEAP, lsl #32
    // 0xf6c5cc: CheckStackOverflow
    //     0xf6c5cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6c5d0: cmp             SP, x16
    //     0xf6c5d4: b.ls            #0xf6c5f4
    // 0xf6c5d8: ldr             x2, [fp, #0x20]
    // 0xf6c5dc: ldr             x3, [fp, #0x18]
    // 0xf6c5e0: ldr             x5, [fp, #0x10]
    // 0xf6c5e4: r0 = _fullScreenRoutePageBuilder()
    //     0xf6c5e4: bl              #0xf6c5fc  ; [package:chewie/src/chewie_player.dart] ChewieState::_fullScreenRoutePageBuilder
    // 0xf6c5e8: LeaveFrame
    //     0xf6c5e8: mov             SP, fp
    //     0xf6c5ec: ldp             fp, lr, [SP], #0x10
    // 0xf6c5f0: ret
    //     0xf6c5f0: ret             
    // 0xf6c5f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6c5f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6c5f8: b               #0xf6c5d8
  }
  _ _fullScreenRoutePageBuilder(/* No info */) {
    // ** addr: 0xf6c5fc, size: 0x124
    // 0xf6c5fc: EnterFrame
    //     0xf6c5fc: stp             fp, lr, [SP, #-0x10]!
    //     0xf6c600: mov             fp, SP
    // 0xf6c604: AllocStack(0x30)
    //     0xf6c604: sub             SP, SP, #0x30
    // 0xf6c608: SetupParameters(ChewieState this /* r1 => r3, fp-0x18 */, dynamic _ /* r3 => r0, fp-0x20 */)
    //     0xf6c608: mov             x0, x3
    //     0xf6c60c: stur            x3, [fp, #-0x20]
    //     0xf6c610: mov             x3, x1
    //     0xf6c614: stur            x1, [fp, #-0x18]
    // 0xf6c618: CheckStackOverflow
    //     0xf6c618: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6c61c: cmp             SP, x16
    //     0xf6c620: b.ls            #0xf6c704
    // 0xf6c624: LoadField: r1 = r3->field_b
    //     0xf6c624: ldur            w1, [x3, #0xb]
    // 0xf6c628: DecompressPointer r1
    //     0xf6c628: add             x1, x1, HEAP, lsl #32
    // 0xf6c62c: cmp             w1, NULL
    // 0xf6c630: b.eq            #0xf6c70c
    // 0xf6c634: LoadField: r4 = r1->field_b
    //     0xf6c634: ldur            w4, [x1, #0xb]
    // 0xf6c638: DecompressPointer r4
    //     0xf6c638: add             x4, x4, HEAP, lsl #32
    // 0xf6c63c: stur            x4, [fp, #-0x10]
    // 0xf6c640: ArrayLoad: r5 = r3[0]  ; List_4
    //     0xf6c640: ldur            w5, [x3, #0x17]
    // 0xf6c644: DecompressPointer r5
    //     0xf6c644: add             x5, x5, HEAP, lsl #32
    // 0xf6c648: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf6c64c: cmp             w5, w16
    // 0xf6c650: b.eq            #0xf6c710
    // 0xf6c654: stur            x5, [fp, #-8]
    // 0xf6c658: r1 = Function '<anonymous closure>':.
    //     0xf6c658: add             x1, PP, #0xcf, lsl #12  ; [pp+0xcf760] AnonymousClosure: (0xde1e74), in [package:chewie/src/chewie_player.dart] ChewieState::build (0xde1cec)
    //     0xf6c65c: ldr             x1, [x1, #0x760]
    // 0xf6c660: r2 = Null
    //     0xf6c660: mov             x2, NULL
    // 0xf6c664: r0 = AllocateClosure()
    //     0xf6c664: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf6c668: r1 = <PlayerNotifier>
    //     0xf6c668: add             x1, PP, #0xcf, lsl #12  ; [pp+0xcf6f0] TypeArguments: <PlayerNotifier>
    //     0xf6c66c: ldr             x1, [x1, #0x6f0]
    // 0xf6c670: stur            x0, [fp, #-0x28]
    // 0xf6c674: r0 = ChangeNotifierProvider()
    //     0xf6c674: bl              #0xde1e68  ; AllocateChangeNotifierProviderStub -> ChangeNotifierProvider<X0 bound ChangeNotifier?> (size=0x20)
    // 0xf6c678: mov             x2, x0
    // 0xf6c67c: ldur            x0, [fp, #-0x28]
    // 0xf6c680: stur            x2, [fp, #-0x30]
    // 0xf6c684: StoreField: r2->field_1b = r0
    //     0xf6c684: stur            w0, [x2, #0x1b]
    // 0xf6c688: r1 = <PlayerNotifier>
    //     0xf6c688: add             x1, PP, #0xcf, lsl #12  ; [pp+0xcf6f0] TypeArguments: <PlayerNotifier>
    //     0xf6c68c: ldr             x1, [x1, #0x6f0]
    // 0xf6c690: r0 = _ValueInheritedProvider()
    //     0xf6c690: bl              #0xde1e5c  ; Allocate_ValueInheritedProviderStub -> _ValueInheritedProvider<X0> (size=0x18)
    // 0xf6c694: mov             x1, x0
    // 0xf6c698: ldur            x0, [fp, #-8]
    // 0xf6c69c: StoreField: r1->field_b = r0
    //     0xf6c69c: stur            w0, [x1, #0xb]
    // 0xf6c6a0: r0 = Closure: (InheritedContext<Listenable?>, Listenable?) => () => void from Function '_startListening@1219289466': static.
    //     0xf6c6a0: add             x0, PP, #0xcf, lsl #12  ; [pp+0xcf708] Closure: (InheritedContext<Listenable?>, Listenable?) => () => void from Function '_startListening@1219289466': static. (0x7f2ada728260)
    //     0xf6c6a4: ldr             x0, [x0, #0x708]
    // 0xf6c6a8: StoreField: r1->field_13 = r0
    //     0xf6c6a8: stur            w0, [x1, #0x13]
    // 0xf6c6ac: ldur            x0, [fp, #-0x30]
    // 0xf6c6b0: StoreField: r0->field_13 = r1
    //     0xf6c6b0: stur            w1, [x0, #0x13]
    // 0xf6c6b4: mov             x1, x0
    // 0xf6c6b8: r0 = Shader._()
    //     0xf6c6b8: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xf6c6bc: r0 = ChewieControllerProvider()
    //     0xf6c6bc: bl              #0xde1dc8  ; AllocateChewieControllerProviderStub -> ChewieControllerProvider (size=0x14)
    // 0xf6c6c0: mov             x1, x0
    // 0xf6c6c4: ldur            x0, [fp, #-0x10]
    // 0xf6c6c8: StoreField: r1->field_f = r0
    //     0xf6c6c8: stur            w0, [x1, #0xf]
    // 0xf6c6cc: ldur            x0, [fp, #-0x30]
    // 0xf6c6d0: StoreField: r1->field_b = r0
    //     0xf6c6d0: stur            w0, [x1, #0xb]
    // 0xf6c6d4: ldur            x0, [fp, #-0x18]
    // 0xf6c6d8: LoadField: r2 = r0->field_b
    //     0xf6c6d8: ldur            w2, [x0, #0xb]
    // 0xf6c6dc: DecompressPointer r2
    //     0xf6c6dc: add             x2, x2, HEAP, lsl #32
    // 0xf6c6e0: cmp             w2, NULL
    // 0xf6c6e4: b.eq            #0xf6c71c
    // 0xf6c6e8: mov             x3, x1
    // 0xf6c6ec: mov             x1, x0
    // 0xf6c6f0: ldur            x2, [fp, #-0x20]
    // 0xf6c6f4: r0 = _defaultRoutePageBuilder()
    //     0xf6c6f4: bl              #0xf6c720  ; [package:chewie/src/chewie_player.dart] ChewieState::_defaultRoutePageBuilder
    // 0xf6c6f8: LeaveFrame
    //     0xf6c6f8: mov             SP, fp
    //     0xf6c6fc: ldp             fp, lr, [SP], #0x10
    // 0xf6c700: ret
    //     0xf6c700: ret             
    // 0xf6c704: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6c704: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6c708: b               #0xf6c624
    // 0xf6c70c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6c70c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6c710: r9 = notifier
    //     0xf6c710: add             x9, PP, #0xcf, lsl #12  ; [pp+0xcf6f8] Field <ChewieState.notifier>: late (offset: 0x18)
    //     0xf6c714: ldr             x9, [x9, #0x6f8]
    // 0xf6c718: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf6c718: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xf6c71c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6c71c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _defaultRoutePageBuilder(/* No info */) {
    // ** addr: 0xf6c720, size: 0x68
    // 0xf6c720: EnterFrame
    //     0xf6c720: stp             fp, lr, [SP, #-0x10]!
    //     0xf6c724: mov             fp, SP
    // 0xf6c728: AllocStack(0x18)
    //     0xf6c728: sub             SP, SP, #0x18
    // 0xf6c72c: SetupParameters(ChewieState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xf6c72c: stur            x1, [fp, #-8]
    //     0xf6c730: stur            x2, [fp, #-0x10]
    //     0xf6c734: stur            x3, [fp, #-0x18]
    // 0xf6c738: r1 = 2
    //     0xf6c738: mov             x1, #2
    // 0xf6c73c: r0 = AllocateContext()
    //     0xf6c73c: bl              #0x13de838  ; AllocateContextStub
    // 0xf6c740: mov             x1, x0
    // 0xf6c744: ldur            x0, [fp, #-8]
    // 0xf6c748: StoreField: r1->field_f = r0
    //     0xf6c748: stur            w0, [x1, #0xf]
    // 0xf6c74c: ldur            x0, [fp, #-0x18]
    // 0xf6c750: StoreField: r1->field_13 = r0
    //     0xf6c750: stur            w0, [x1, #0x13]
    // 0xf6c754: mov             x2, x1
    // 0xf6c758: r1 = Function '<anonymous closure>':.
    //     0xf6c758: add             x1, PP, #0xcf, lsl #12  ; [pp+0xcf768] AnonymousClosure: (0xf6c788), in [package:chewie/src/chewie_player.dart] ChewieState::_defaultRoutePageBuilder (0xf6c720)
    //     0xf6c75c: ldr             x1, [x1, #0x768]
    // 0xf6c760: r0 = AllocateClosure()
    //     0xf6c760: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf6c764: stur            x0, [fp, #-8]
    // 0xf6c768: r0 = AnimatedBuilder()
    //     0xf6c768: bl              #0x918e2c  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0xf6c76c: ldur            x1, [fp, #-8]
    // 0xf6c770: StoreField: r0->field_f = r1
    //     0xf6c770: stur            w1, [x0, #0xf]
    // 0xf6c774: ldur            x1, [fp, #-0x10]
    // 0xf6c778: StoreField: r0->field_b = r1
    //     0xf6c778: stur            w1, [x0, #0xb]
    // 0xf6c77c: LeaveFrame
    //     0xf6c77c: mov             SP, fp
    //     0xf6c780: ldp             fp, lr, [SP], #0x10
    // 0xf6c784: ret
    //     0xf6c784: ret             
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0xf6c788, size: 0x4c
    // 0xf6c788: EnterFrame
    //     0xf6c788: stp             fp, lr, [SP, #-0x10]!
    //     0xf6c78c: mov             fp, SP
    // 0xf6c790: ldr             x0, [fp, #0x20]
    // 0xf6c794: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf6c794: ldur            w1, [x0, #0x17]
    // 0xf6c798: DecompressPointer r1
    //     0xf6c798: add             x1, x1, HEAP, lsl #32
    // 0xf6c79c: CheckStackOverflow
    //     0xf6c79c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6c7a0: cmp             SP, x16
    //     0xf6c7a4: b.ls            #0xf6c7cc
    // 0xf6c7a8: LoadField: r0 = r1->field_f
    //     0xf6c7a8: ldur            w0, [x1, #0xf]
    // 0xf6c7ac: DecompressPointer r0
    //     0xf6c7ac: add             x0, x0, HEAP, lsl #32
    // 0xf6c7b0: LoadField: r2 = r1->field_13
    //     0xf6c7b0: ldur            w2, [x1, #0x13]
    // 0xf6c7b4: DecompressPointer r2
    //     0xf6c7b4: add             x2, x2, HEAP, lsl #32
    // 0xf6c7b8: mov             x1, x0
    // 0xf6c7bc: r0 = _buildFullScreenVideo()
    //     0xf6c7bc: bl              #0xf6c7d4  ; [package:chewie/src/chewie_player.dart] ChewieState::_buildFullScreenVideo
    // 0xf6c7c0: LeaveFrame
    //     0xf6c7c0: mov             SP, fp
    //     0xf6c7c4: ldp             fp, lr, [SP], #0x10
    // 0xf6c7c8: ret
    //     0xf6c7c8: ret             
    // 0xf6c7cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6c7cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6c7d0: b               #0xf6c7a8
  }
  _ _buildFullScreenVideo(/* No info */) {
    // ** addr: 0xf6c7d4, size: 0xa4
    // 0xf6c7d4: EnterFrame
    //     0xf6c7d4: stp             fp, lr, [SP, #-0x10]!
    //     0xf6c7d8: mov             fp, SP
    // 0xf6c7dc: AllocStack(0x28)
    //     0xf6c7dc: sub             SP, SP, #0x28
    // 0xf6c7e0: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0xf6c7e0: stur            x2, [fp, #-8]
    // 0xf6c7e4: CheckStackOverflow
    //     0xf6c7e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6c7e8: cmp             SP, x16
    //     0xf6c7ec: b.ls            #0xf6c870
    // 0xf6c7f0: r0 = Container()
    //     0xf6c7f0: bl              #0x8a5af8  ; AllocateContainerStub -> Container (size=0x38)
    // 0xf6c7f4: stur            x0, [fp, #-0x10]
    // 0xf6c7f8: r16 = Instance_Alignment
    //     0xf6c7f8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xf6c7fc: ldr             x16, [x16, #0xb80]
    // 0xf6c800: r30 = Instance_Color
    //     0xf6c800: add             lr, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0xf6c804: ldr             lr, [lr, #0x948]
    // 0xf6c808: stp             lr, x16, [SP, #8]
    // 0xf6c80c: ldur            x16, [fp, #-8]
    // 0xf6c810: str             x16, [SP]
    // 0xf6c814: mov             x1, x0
    // 0xf6c818: r4 = const [0, 0x4, 0x3, 0x1, alignment, 0x1, child, 0x3, color, 0x2, null]
    //     0xf6c818: add             x4, PP, #0xcf, lsl #12  ; [pp+0xcf770] List(11) [0, 0x4, 0x3, 0x1, "alignment", 0x1, "child", 0x3, "color", 0x2, Null]
    //     0xf6c81c: ldr             x4, [x4, #0x770]
    // 0xf6c820: r0 = Container()
    //     0xf6c820: bl              #0x8a54e0  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0xf6c824: r0 = Scaffold()
    //     0xf6c824: bl              #0xd4bcf0  ; AllocateScaffoldStub -> Scaffold (size=0x70)
    // 0xf6c828: ldur            x1, [fp, #-0x10]
    // 0xf6c82c: StoreField: r0->field_1b = r1
    //     0xf6c82c: stur            w1, [x0, #0x1b]
    // 0xf6c830: r1 = false
    //     0xf6c830: add             x1, NULL, #0x30  ; false
    // 0xf6c834: StoreField: r0->field_57 = r1
    //     0xf6c834: stur            w1, [x0, #0x57]
    // 0xf6c838: r2 = true
    //     0xf6c838: add             x2, NULL, #0x20  ; true
    // 0xf6c83c: StoreField: r0->field_5b = r2
    //     0xf6c83c: stur            w2, [x0, #0x5b]
    // 0xf6c840: r3 = Instance_DragStartBehavior
    //     0xf6c840: ldr             x3, [PP, #0x5360]  ; [pp+0x5360] Obj!DragStartBehavior@12c5c61
    // 0xf6c844: StoreField: r0->field_5f = r3
    //     0xf6c844: stur            w3, [x0, #0x5f]
    // 0xf6c848: StoreField: r0->field_b = r1
    //     0xf6c848: stur            w1, [x0, #0xb]
    // 0xf6c84c: StoreField: r0->field_f = r2
    //     0xf6c84c: stur            w2, [x0, #0xf]
    // 0xf6c850: StoreField: r0->field_13 = r1
    //     0xf6c850: stur            w1, [x0, #0x13]
    // 0xf6c854: r1 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0xf6c854: add             x1, PP, #0x15, lsl #12  ; [pp+0x157b0] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x7f2adac1d228)
    //     0xf6c858: ldr             x1, [x1, #0x7b0]
    // 0xf6c85c: StoreField: r0->field_47 = r1
    //     0xf6c85c: stur            w1, [x0, #0x47]
    // 0xf6c860: StoreField: r0->field_67 = r2
    //     0xf6c860: stur            w2, [x0, #0x67]
    // 0xf6c864: LeaveFrame
    //     0xf6c864: mov             SP, fp
    //     0xf6c868: ldp             fp, lr, [SP], #0x10
    // 0xf6c86c: ret
    //     0xf6c86c: ret             
    // 0xf6c870: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6c870: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6c874: b               #0xf6c7f0
  }
  _ initState(/* No info */) {
    // ** addr: 0xf8e818, size: 0x98
    // 0xf8e818: EnterFrame
    //     0xf8e818: stp             fp, lr, [SP, #-0x10]!
    //     0xf8e81c: mov             fp, SP
    // 0xf8e820: AllocStack(0x10)
    //     0xf8e820: sub             SP, SP, #0x10
    // 0xf8e824: SetupParameters(ChewieState this /* r1 => r0, fp-0x10 */)
    //     0xf8e824: mov             x0, x1
    //     0xf8e828: stur            x1, [fp, #-0x10]
    // 0xf8e82c: CheckStackOverflow
    //     0xf8e82c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf8e830: cmp             SP, x16
    //     0xf8e834: b.ls            #0xf8e8a4
    // 0xf8e838: LoadField: r1 = r0->field_b
    //     0xf8e838: ldur            w1, [x0, #0xb]
    // 0xf8e83c: DecompressPointer r1
    //     0xf8e83c: add             x1, x1, HEAP, lsl #32
    // 0xf8e840: cmp             w1, NULL
    // 0xf8e844: b.eq            #0xf8e8ac
    // 0xf8e848: LoadField: r3 = r1->field_b
    //     0xf8e848: ldur            w3, [x1, #0xb]
    // 0xf8e84c: DecompressPointer r3
    //     0xf8e84c: add             x3, x3, HEAP, lsl #32
    // 0xf8e850: mov             x2, x0
    // 0xf8e854: stur            x3, [fp, #-8]
    // 0xf8e858: r1 = Function 'listener':.
    //     0xf8e858: add             x1, PP, #0xcf, lsl #12  ; [pp+0xcf738] AnonymousClosure: (0xf6be98), in [package:chewie/src/chewie_player.dart] ChewieState::listener (0xf6bed0)
    //     0xf8e85c: ldr             x1, [x1, #0x738]
    // 0xf8e860: r0 = AllocateClosure()
    //     0xf8e860: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf8e864: ldur            x1, [fp, #-8]
    // 0xf8e868: mov             x2, x0
    // 0xf8e86c: r0 = addListener()
    //     0xf8e86c: bl              #0xd038e0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0xf8e870: r0 = init()
    //     0xf8e870: bl              #0xf8e8b0  ; [package:chewie/src/notifiers/player_notifier.dart] PlayerNotifier::init
    // 0xf8e874: ldur            x1, [fp, #-0x10]
    // 0xf8e878: ArrayStore: r1[0] = r0  ; List_4
    //     0xf8e878: stur            w0, [x1, #0x17]
    //     0xf8e87c: ldurb           w16, [x1, #-1]
    //     0xf8e880: ldurb           w17, [x0, #-1]
    //     0xf8e884: and             x16, x17, x16, lsr #2
    //     0xf8e888: tst             x16, HEAP, lsr #32
    //     0xf8e88c: b.eq            #0xf8e894
    //     0xf8e890: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf8e894: r0 = Null
    //     0xf8e894: mov             x0, NULL
    // 0xf8e898: LeaveFrame
    //     0xf8e898: mov             SP, fp
    //     0xf8e89c: ldp             fp, lr, [SP], #0x10
    // 0xf8e8a0: ret
    //     0xf8e8a0: ret             
    // 0xf8e8a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf8e8a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf8e8a8: b               #0xf8e838
    // 0xf8e8ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf8e8ac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10e47b4, size: 0x9c
    // 0x10e47b4: EnterFrame
    //     0x10e47b4: stp             fp, lr, [SP, #-0x10]!
    //     0x10e47b8: mov             fp, SP
    // 0x10e47bc: AllocStack(0x10)
    //     0x10e47bc: sub             SP, SP, #0x10
    // 0x10e47c0: SetupParameters(ChewieState this /* r1 => r0, fp-0x10 */)
    //     0x10e47c0: mov             x0, x1
    //     0x10e47c4: stur            x1, [fp, #-0x10]
    // 0x10e47c8: CheckStackOverflow
    //     0x10e47c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e47cc: cmp             SP, x16
    //     0x10e47d0: b.ls            #0x10e4838
    // 0x10e47d4: LoadField: r1 = r0->field_b
    //     0x10e47d4: ldur            w1, [x0, #0xb]
    // 0x10e47d8: DecompressPointer r1
    //     0x10e47d8: add             x1, x1, HEAP, lsl #32
    // 0x10e47dc: cmp             w1, NULL
    // 0x10e47e0: b.eq            #0x10e4840
    // 0x10e47e4: LoadField: r3 = r1->field_b
    //     0x10e47e4: ldur            w3, [x1, #0xb]
    // 0x10e47e8: DecompressPointer r3
    //     0x10e47e8: add             x3, x3, HEAP, lsl #32
    // 0x10e47ec: mov             x2, x0
    // 0x10e47f0: stur            x3, [fp, #-8]
    // 0x10e47f4: r1 = Function 'listener':.
    //     0x10e47f4: add             x1, PP, #0xcf, lsl #12  ; [pp+0xcf738] AnonymousClosure: (0xf6be98), in [package:chewie/src/chewie_player.dart] ChewieState::listener (0xf6bed0)
    //     0x10e47f8: ldr             x1, [x1, #0x738]
    // 0x10e47fc: r0 = AllocateClosure()
    //     0x10e47fc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10e4800: ldur            x1, [fp, #-8]
    // 0x10e4804: mov             x2, x0
    // 0x10e4808: r0 = removeListener()
    //     0x10e4808: bl              #0xcff968  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x10e480c: ldur            x0, [fp, #-0x10]
    // 0x10e4810: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x10e4810: ldur            w1, [x0, #0x17]
    // 0x10e4814: DecompressPointer r1
    //     0x10e4814: add             x1, x1, HEAP, lsl #32
    // 0x10e4818: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10e481c: cmp             w1, w16
    // 0x10e4820: b.eq            #0x10e4844
    // 0x10e4824: r0 = dispose()
    //     0x10e4824: bl              #0x10ef878  ; [dart:mixin_deduplication] _MixinApplication276&Object&ChangeNotifier::dispose
    // 0x10e4828: r0 = Null
    //     0x10e4828: mov             x0, NULL
    // 0x10e482c: LeaveFrame
    //     0x10e482c: mov             SP, fp
    //     0x10e4830: ldp             fp, lr, [SP], #0x10
    // 0x10e4834: ret
    //     0x10e4834: ret             
    // 0x10e4838: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e4838: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e483c: b               #0x10e47d4
    // 0x10e4840: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10e4840: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x10e4844: r9 = notifier
    //     0x10e4844: add             x9, PP, #0xcf, lsl #12  ; [pp+0xcf6f8] Field <ChewieState.notifier>: late (offset: 0x18)
    //     0x10e4848: ldr             x9, [x9, #0x6f8]
    // 0x10e484c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x10e484c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 6538, size: 0x10, field offset: 0xc
//   const constructor, 
class Chewie extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xf9feac, size: 0x34
    // 0xf9feac: EnterFrame
    //     0xf9feac: stp             fp, lr, [SP, #-0x10]!
    //     0xf9feb0: mov             fp, SP
    // 0xf9feb4: mov             x0, x1
    // 0xf9feb8: r1 = <Chewie>
    //     0xf9feb8: add             x1, PP, #0xb0, lsl #12  ; [pp+0xb0710] TypeArguments: <Chewie>
    //     0xf9febc: ldr             x1, [x1, #0x710]
    // 0xf9fec0: r0 = ChewieState()
    //     0xf9fec0: bl              #0xf9fee0  ; AllocateChewieStateStub -> ChewieState (size=0x1c)
    // 0xf9fec4: r1 = false
    //     0xf9fec4: add             x1, NULL, #0x30  ; false
    // 0xf9fec8: StoreField: r0->field_13 = r1
    //     0xf9fec8: stur            w1, [x0, #0x13]
    // 0xf9fecc: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xf9fed0: ArrayStore: r0[0] = r1  ; List_4
    //     0xf9fed0: stur            w1, [x0, #0x17]
    // 0xf9fed4: LeaveFrame
    //     0xf9fed4: mov             SP, fp
    //     0xf9fed8: ldp             fp, lr, [SP], #0x10
    // 0xf9fedc: ret
    //     0xf9fedc: ret             
  }
}

// class id: 6821, size: 0x14, field offset: 0x10
//   const constructor, 
class ChewieControllerProvider extends InheritedWidget {

  _ updateShouldNotify(/* No info */) {
    // ** addr: 0xc00968, size: 0x8c
    // 0xc00968: EnterFrame
    //     0xc00968: stp             fp, lr, [SP, #-0x10]!
    //     0xc0096c: mov             fp, SP
    // 0xc00970: AllocStack(0x10)
    //     0xc00970: sub             SP, SP, #0x10
    // 0xc00974: SetupParameters(ChewieControllerProvider this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xc00974: mov             x0, x2
    //     0xc00978: mov             x4, x1
    //     0xc0097c: mov             x3, x2
    //     0xc00980: stur            x1, [fp, #-8]
    //     0xc00984: stur            x2, [fp, #-0x10]
    // 0xc00988: r2 = Null
    //     0xc00988: mov             x2, NULL
    // 0xc0098c: r1 = Null
    //     0xc0098c: mov             x1, NULL
    // 0xc00990: r4 = 60
    //     0xc00990: mov             x4, #0x3c
    // 0xc00994: branchIfSmi(r0, 0xc009a0)
    //     0xc00994: tbz             w0, #0, #0xc009a0
    // 0xc00998: r4 = LoadClassIdInstr(r0)
    //     0xc00998: ldur            x4, [x0, #-1]
    //     0xc0099c: ubfx            x4, x4, #0xc, #0x14
    // 0xc009a0: r17 = 6821
    //     0xc009a0: mov             x17, #0x1aa5
    // 0xc009a4: cmp             x4, x17
    // 0xc009a8: b.eq            #0xc009c0
    // 0xc009ac: r8 = ChewieControllerProvider
    //     0xc009ac: add             x8, PP, #0xd1, lsl #12  ; [pp+0xd1950] Type: ChewieControllerProvider
    //     0xc009b0: ldr             x8, [x8, #0x950]
    // 0xc009b4: r3 = Null
    //     0xc009b4: add             x3, PP, #0xd1, lsl #12  ; [pp+0xd1958] Null
    //     0xc009b8: ldr             x3, [x3, #0x958]
    // 0xc009bc: r0 = DefaultTypeTest()
    //     0xc009bc: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xc009c0: ldur            x1, [fp, #-8]
    // 0xc009c4: LoadField: r2 = r1->field_f
    //     0xc009c4: ldur            w2, [x1, #0xf]
    // 0xc009c8: DecompressPointer r2
    //     0xc009c8: add             x2, x2, HEAP, lsl #32
    // 0xc009cc: ldur            x1, [fp, #-0x10]
    // 0xc009d0: LoadField: r3 = r1->field_f
    //     0xc009d0: ldur            w3, [x1, #0xf]
    // 0xc009d4: DecompressPointer r3
    //     0xc009d4: add             x3, x3, HEAP, lsl #32
    // 0xc009d8: cmp             w2, w3
    // 0xc009dc: r16 = true
    //     0xc009dc: add             x16, NULL, #0x20  ; true
    // 0xc009e0: r17 = false
    //     0xc009e0: add             x17, NULL, #0x30  ; false
    // 0xc009e4: csel            x0, x16, x17, ne
    // 0xc009e8: LeaveFrame
    //     0xc009e8: mov             SP, fp
    //     0xc009ec: ldp             fp, lr, [SP], #0x10
    // 0xc009f0: ret
    //     0xc009f0: ret             
  }
}
