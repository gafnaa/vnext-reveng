// lib: , url: package:chewie/src/chewie_progress_colors.dart

// class id: 1048630, size: 0x8
class :: {
}

// class id: 3585, size: 0x18, field offset: 0x8
class ChewieProgressColors extends Object {

  _ ChewieProgressColors(/* No info */) {
    // ** addr: 0xdcf874, size: 0x1a8
    // 0xdcf874: EnterFrame
    //     0xdcf874: stp             fp, lr, [SP, #-0x10]!
    //     0xdcf878: mov             fp, SP
    // 0xdcf87c: AllocStack(0x48)
    //     0xdcf87c: sub             SP, SP, #0x48
    // 0xdcf880: SetupParameters(ChewieProgressColors this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */, dynamic _ /* r3 => r1, fp-0x18 */, dynamic _ /* r5 => r0, fp-0x20 */, dynamic _ /* r6 => r2, fp-0x28 */)
    //     0xdcf880: mov             x4, x1
    //     0xdcf884: stur            x1, [fp, #-8]
    //     0xdcf888: mov             x1, x3
    //     0xdcf88c: stur            x3, [fp, #-0x18]
    //     0xdcf890: mov             x3, x2
    //     0xdcf894: mov             x0, x5
    //     0xdcf898: stur            x2, [fp, #-0x10]
    //     0xdcf89c: mov             x2, x6
    //     0xdcf8a0: stur            x5, [fp, #-0x20]
    //     0xdcf8a4: stur            x6, [fp, #-0x28]
    // 0xdcf8a8: CheckStackOverflow
    //     0xdcf8a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdcf8ac: cmp             SP, x16
    //     0xdcf8b0: b.ls            #0xdcfa14
    // 0xdcf8b4: r16 = 136
    //     0xdcf8b4: mov             x16, #0x88
    // 0xdcf8b8: stp             x16, NULL, [SP]
    // 0xdcf8bc: r0 = ByteData()
    //     0xdcf8bc: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xdcf8c0: stur            x0, [fp, #-0x30]
    // 0xdcf8c4: r0 = Paint()
    //     0xdcf8c4: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xdcf8c8: mov             x3, x0
    // 0xdcf8cc: ldur            x0, [fp, #-0x30]
    // 0xdcf8d0: stur            x3, [fp, #-0x38]
    // 0xdcf8d4: StoreField: r3->field_7 = r0
    //     0xdcf8d4: stur            w0, [x3, #7]
    // 0xdcf8d8: mov             x1, x3
    // 0xdcf8dc: ldur            x2, [fp, #-0x28]
    // 0xdcf8e0: r0 = color=()
    //     0xdcf8e0: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xdcf8e4: ldur            x0, [fp, #-0x38]
    // 0xdcf8e8: ldur            x1, [fp, #-8]
    // 0xdcf8ec: StoreField: r1->field_7 = r0
    //     0xdcf8ec: stur            w0, [x1, #7]
    //     0xdcf8f0: ldurb           w16, [x1, #-1]
    //     0xdcf8f4: ldurb           w17, [x0, #-1]
    //     0xdcf8f8: and             x16, x17, x16, lsr #2
    //     0xdcf8fc: tst             x16, HEAP, lsr #32
    //     0xdcf900: b.eq            #0xdcf908
    //     0xdcf904: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdcf908: r16 = 136
    //     0xdcf908: mov             x16, #0x88
    // 0xdcf90c: stp             x16, NULL, [SP]
    // 0xdcf910: r0 = ByteData()
    //     0xdcf910: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xdcf914: stur            x0, [fp, #-0x28]
    // 0xdcf918: r0 = Paint()
    //     0xdcf918: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xdcf91c: mov             x3, x0
    // 0xdcf920: ldur            x0, [fp, #-0x28]
    // 0xdcf924: stur            x3, [fp, #-0x30]
    // 0xdcf928: StoreField: r3->field_7 = r0
    //     0xdcf928: stur            w0, [x3, #7]
    // 0xdcf92c: mov             x1, x3
    // 0xdcf930: ldur            x2, [fp, #-0x18]
    // 0xdcf934: r0 = color=()
    //     0xdcf934: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xdcf938: ldur            x0, [fp, #-0x30]
    // 0xdcf93c: ldur            x1, [fp, #-8]
    // 0xdcf940: StoreField: r1->field_b = r0
    //     0xdcf940: stur            w0, [x1, #0xb]
    //     0xdcf944: ldurb           w16, [x1, #-1]
    //     0xdcf948: ldurb           w17, [x0, #-1]
    //     0xdcf94c: and             x16, x17, x16, lsr #2
    //     0xdcf950: tst             x16, HEAP, lsr #32
    //     0xdcf954: b.eq            #0xdcf95c
    //     0xdcf958: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdcf95c: r16 = 136
    //     0xdcf95c: mov             x16, #0x88
    // 0xdcf960: stp             x16, NULL, [SP]
    // 0xdcf964: r0 = ByteData()
    //     0xdcf964: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xdcf968: stur            x0, [fp, #-0x18]
    // 0xdcf96c: r0 = Paint()
    //     0xdcf96c: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xdcf970: mov             x3, x0
    // 0xdcf974: ldur            x0, [fp, #-0x18]
    // 0xdcf978: stur            x3, [fp, #-0x28]
    // 0xdcf97c: StoreField: r3->field_7 = r0
    //     0xdcf97c: stur            w0, [x3, #7]
    // 0xdcf980: mov             x1, x3
    // 0xdcf984: ldur            x2, [fp, #-0x20]
    // 0xdcf988: r0 = color=()
    //     0xdcf988: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xdcf98c: ldur            x0, [fp, #-0x28]
    // 0xdcf990: ldur            x1, [fp, #-8]
    // 0xdcf994: StoreField: r1->field_f = r0
    //     0xdcf994: stur            w0, [x1, #0xf]
    //     0xdcf998: ldurb           w16, [x1, #-1]
    //     0xdcf99c: ldurb           w17, [x0, #-1]
    //     0xdcf9a0: and             x16, x17, x16, lsr #2
    //     0xdcf9a4: tst             x16, HEAP, lsr #32
    //     0xdcf9a8: b.eq            #0xdcf9b0
    //     0xdcf9ac: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdcf9b0: r16 = 136
    //     0xdcf9b0: mov             x16, #0x88
    // 0xdcf9b4: stp             x16, NULL, [SP]
    // 0xdcf9b8: r0 = ByteData()
    //     0xdcf9b8: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xdcf9bc: stur            x0, [fp, #-0x18]
    // 0xdcf9c0: r0 = Paint()
    //     0xdcf9c0: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xdcf9c4: mov             x3, x0
    // 0xdcf9c8: ldur            x0, [fp, #-0x18]
    // 0xdcf9cc: stur            x3, [fp, #-0x20]
    // 0xdcf9d0: StoreField: r3->field_7 = r0
    //     0xdcf9d0: stur            w0, [x3, #7]
    // 0xdcf9d4: mov             x1, x3
    // 0xdcf9d8: ldur            x2, [fp, #-0x10]
    // 0xdcf9dc: r0 = color=()
    //     0xdcf9dc: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xdcf9e0: ldur            x0, [fp, #-0x20]
    // 0xdcf9e4: ldur            x1, [fp, #-8]
    // 0xdcf9e8: StoreField: r1->field_13 = r0
    //     0xdcf9e8: stur            w0, [x1, #0x13]
    //     0xdcf9ec: ldurb           w16, [x1, #-1]
    //     0xdcf9f0: ldurb           w17, [x0, #-1]
    //     0xdcf9f4: and             x16, x17, x16, lsr #2
    //     0xdcf9f8: tst             x16, HEAP, lsr #32
    //     0xdcf9fc: b.eq            #0xdcfa04
    //     0xdcfa00: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdcfa04: r0 = Null
    //     0xdcfa04: mov             x0, NULL
    // 0xdcfa08: LeaveFrame
    //     0xdcfa08: mov             SP, fp
    //     0xdcfa0c: ldp             fp, lr, [SP], #0x10
    // 0xdcfa10: ret
    //     0xdcfa10: ret             
    // 0xdcfa14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdcfa14: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdcfa18: b               #0xdcf8b4
  }
}
