// lib: , url: package:chewie/src/cupertino/widgets/cupertino_options_dialog.dart

// class id: 1048633, size: 0x8
class :: {
}

// class id: 5499, size: 0x14, field offset: 0x14
class _CupertinoOptionsDialogState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0xde1e80, size: 0x24c
    // 0xde1e80: EnterFrame
    //     0xde1e80: stp             fp, lr, [SP, #-0x10]!
    //     0xde1e84: mov             fp, SP
    // 0xde1e88: AllocStack(0x38)
    //     0xde1e88: sub             SP, SP, #0x38
    // 0xde1e8c: SetupParameters(_CupertinoOptionsDialogState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xde1e8c: stur            x1, [fp, #-8]
    //     0xde1e90: stur            x2, [fp, #-0x10]
    // 0xde1e94: CheckStackOverflow
    //     0xde1e94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde1e98: cmp             SP, x16
    //     0xde1e9c: b.ls            #0xde20bc
    // 0xde1ea0: r1 = 1
    //     0xde1ea0: mov             x1, #1
    // 0xde1ea4: r0 = AllocateContext()
    //     0xde1ea4: bl              #0x13de838  ; AllocateContextStub
    // 0xde1ea8: mov             x3, x0
    // 0xde1eac: ldur            x0, [fp, #-0x10]
    // 0xde1eb0: stur            x3, [fp, #-0x18]
    // 0xde1eb4: StoreField: r3->field_f = r0
    //     0xde1eb4: stur            w0, [x3, #0xf]
    // 0xde1eb8: ldur            x0, [fp, #-8]
    // 0xde1ebc: LoadField: r1 = r0->field_b
    //     0xde1ebc: ldur            w1, [x0, #0xb]
    // 0xde1ec0: DecompressPointer r1
    //     0xde1ec0: add             x1, x1, HEAP, lsl #32
    // 0xde1ec4: cmp             w1, NULL
    // 0xde1ec8: b.eq            #0xde20c4
    // 0xde1ecc: LoadField: r4 = r1->field_b
    //     0xde1ecc: ldur            w4, [x1, #0xb]
    // 0xde1ed0: DecompressPointer r4
    //     0xde1ed0: add             x4, x4, HEAP, lsl #32
    // 0xde1ed4: mov             x2, x3
    // 0xde1ed8: stur            x4, [fp, #-0x10]
    // 0xde1edc: r1 = Function '<anonymous closure>':.
    //     0xde1edc: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd49c0] AnonymousClosure: (0xde212c), in [package:chewie/src/cupertino/widgets/cupertino_options_dialog.dart] _CupertinoOptionsDialogState::build (0xde1e80)
    //     0xde1ee0: ldr             x1, [x1, #0x9c0]
    // 0xde1ee4: r0 = AllocateClosure()
    //     0xde1ee4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xde1ee8: r16 = <CupertinoActionSheetAction>
    //     0xde1ee8: add             x16, PP, #0xd4, lsl #12  ; [pp+0xd4730] TypeArguments: <CupertinoActionSheetAction>
    //     0xde1eec: ldr             x16, [x16, #0x730]
    // 0xde1ef0: ldur            lr, [fp, #-0x10]
    // 0xde1ef4: stp             lr, x16, [SP, #8]
    // 0xde1ef8: str             x0, [SP]
    // 0xde1efc: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xde1efc: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xde1f00: r0 = map()
    //     0xde1f00: bl              #0xba574c  ; [dart:collection] ListBase::map
    // 0xde1f04: mov             x3, x0
    // 0xde1f08: stur            x3, [fp, #-0x20]
    // 0xde1f0c: LoadField: r4 = r3->field_7
    //     0xde1f0c: ldur            w4, [x3, #7]
    // 0xde1f10: DecompressPointer r4
    //     0xde1f10: add             x4, x4, HEAP, lsl #32
    // 0xde1f14: mov             x0, x3
    // 0xde1f18: stur            x4, [fp, #-0x10]
    // 0xde1f1c: r2 = Null
    //     0xde1f1c: mov             x2, NULL
    // 0xde1f20: r1 = Null
    //     0xde1f20: mov             x1, NULL
    // 0xde1f24: cmp             w0, NULL
    // 0xde1f28: b.eq            #0xde1fc0
    // 0xde1f2c: branchIfSmi(r0, 0xde1fc0)
    //     0xde1f2c: tbz             w0, #0, #0xde1fc0
    // 0xde1f30: r3 = LoadClassIdInstr(r0)
    //     0xde1f30: ldur            x3, [x0, #-1]
    //     0xde1f34: ubfx            x3, x3, #0xc, #0x14
    // 0xde1f38: r17 = 7724
    //     0xde1f38: mov             x17, #0x1e2c
    // 0xde1f3c: cmp             x3, x17
    // 0xde1f40: b.eq            #0xde1fc8
    // 0xde1f44: r4 = LoadClassIdInstr(r0)
    //     0xde1f44: ldur            x4, [x0, #-1]
    //     0xde1f48: ubfx            x4, x4, #0xc, #0x14
    // 0xde1f4c: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0xde1f50: ldr             x3, [x3, #0x18]
    // 0xde1f54: ldr             x3, [x3, x4, lsl #3]
    // 0xde1f58: LoadField: r3 = r3->field_2b
    //     0xde1f58: ldur            w3, [x3, #0x2b]
    // 0xde1f5c: DecompressPointer r3
    //     0xde1f5c: add             x3, x3, HEAP, lsl #32
    // 0xde1f60: cmp             w3, NULL
    // 0xde1f64: b.eq            #0xde1fc0
    // 0xde1f68: LoadField: r3 = r3->field_f
    //     0xde1f68: ldur            w3, [x3, #0xf]
    // 0xde1f6c: lsr             x3, x3, #3
    // 0xde1f70: r17 = 7724
    //     0xde1f70: mov             x17, #0x1e2c
    // 0xde1f74: cmp             x3, x17
    // 0xde1f78: b.eq            #0xde1fc8
    // 0xde1f7c: r3 = SubtypeTestCache
    //     0xde1f7c: add             x3, PP, #0xd4, lsl #12  ; [pp+0xd49c8] SubtypeTestCache
    //     0xde1f80: ldr             x3, [x3, #0x9c8]
    // 0xde1f84: r30 = Subtype1TestCacheStub
    //     0xde1f84: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0xde1f88: LoadField: r30 = r30->field_7
    //     0xde1f88: ldur            lr, [lr, #7]
    // 0xde1f8c: blr             lr
    // 0xde1f90: cmp             w7, NULL
    // 0xde1f94: b.eq            #0xde1fa0
    // 0xde1f98: tbnz            w7, #4, #0xde1fc0
    // 0xde1f9c: b               #0xde1fc8
    // 0xde1fa0: r8 = EfficientLengthIterable
    //     0xde1fa0: add             x8, PP, #0xd4, lsl #12  ; [pp+0xd49d0] Type: EfficientLengthIterable
    //     0xde1fa4: ldr             x8, [x8, #0x9d0]
    // 0xde1fa8: r3 = SubtypeTestCache
    //     0xde1fa8: add             x3, PP, #0xd4, lsl #12  ; [pp+0xd49d8] SubtypeTestCache
    //     0xde1fac: ldr             x3, [x3, #0x9d8]
    // 0xde1fb0: r30 = InstanceOfStub
    //     0xde1fb0: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0xde1fb4: LoadField: r30 = r30->field_7
    //     0xde1fb4: ldur            lr, [lr, #7]
    // 0xde1fb8: blr             lr
    // 0xde1fbc: b               #0xde1fcc
    // 0xde1fc0: r0 = false
    //     0xde1fc0: add             x0, NULL, #0x30  ; false
    // 0xde1fc4: b               #0xde1fcc
    // 0xde1fc8: r0 = true
    //     0xde1fc8: add             x0, NULL, #0x20  ; true
    // 0xde1fcc: tbnz            w0, #4, #0xde1fe4
    // 0xde1fd0: ldur            x1, [fp, #-0x10]
    // 0xde1fd4: ldur            x2, [fp, #-0x20]
    // 0xde1fd8: r0 = _GrowableList._ofEfficientLengthIterable()
    //     0xde1fd8: bl              #0x7d732c  ; [dart:core] _GrowableList::_GrowableList._ofEfficientLengthIterable
    // 0xde1fdc: mov             x1, x0
    // 0xde1fe0: b               #0xde1ff4
    // 0xde1fe4: ldur            x1, [fp, #-0x10]
    // 0xde1fe8: ldur            x2, [fp, #-0x20]
    // 0xde1fec: r0 = _GrowableList._ofOther()
    //     0xde1fec: bl              #0x7d94b4  ; [dart:core] _GrowableList::_GrowableList._ofOther
    // 0xde1ff0: mov             x1, x0
    // 0xde1ff4: ldur            x0, [fp, #-8]
    // 0xde1ff8: stur            x1, [fp, #-0x10]
    // 0xde1ffc: LoadField: r2 = r0->field_b
    //     0xde1ffc: ldur            w2, [x0, #0xb]
    // 0xde2000: DecompressPointer r2
    //     0xde2000: add             x2, x2, HEAP, lsl #32
    // 0xde2004: cmp             w2, NULL
    // 0xde2008: b.eq            #0xde20c8
    // 0xde200c: r0 = Text()
    //     0xde200c: bl              #0x8a70a4  ; AllocateTextStub -> Text (size=0x50)
    // 0xde2010: mov             x3, x0
    // 0xde2014: r0 = "Cancel"
    //     0xde2014: add             x0, PP, #0x24, lsl #12  ; [pp+0x24ce0] "Cancel"
    //     0xde2018: ldr             x0, [x0, #0xce0]
    // 0xde201c: stur            x3, [fp, #-8]
    // 0xde2020: StoreField: r3->field_b = r0
    //     0xde2020: stur            w0, [x3, #0xb]
    // 0xde2024: ldur            x2, [fp, #-0x18]
    // 0xde2028: r1 = Function '<anonymous closure>':.
    //     0xde2028: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd49e0] AnonymousClosure: (0xdc825c), in [package:syncfusion_flutter_pdfviewer/src/pdfviewer.dart] SfPdfViewerState::_showStickyNoteDialogMobile (0xdc6c50)
    //     0xde202c: ldr             x1, [x1, #0x9e0]
    // 0xde2030: r0 = AllocateClosure()
    //     0xde2030: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xde2034: stur            x0, [fp, #-0x18]
    // 0xde2038: r0 = CupertinoActionSheetAction()
    //     0xde2038: bl              #0xde20fc  ; AllocateCupertinoActionSheetActionStub -> CupertinoActionSheetAction (size=0x28)
    // 0xde203c: mov             x1, x0
    // 0xde2040: ldur            x0, [fp, #-0x18]
    // 0xde2044: stur            x1, [fp, #-0x20]
    // 0xde2048: StoreField: r1->field_b = r0
    //     0xde2048: stur            w0, [x1, #0xb]
    // 0xde204c: r0 = false
    //     0xde204c: add             x0, NULL, #0x30  ; false
    // 0xde2050: StoreField: r1->field_f = r0
    //     0xde2050: stur            w0, [x1, #0xf]
    // 0xde2054: r2 = true
    //     0xde2054: add             x2, NULL, #0x20  ; true
    // 0xde2058: StoreField: r1->field_13 = r2
    //     0xde2058: stur            w2, [x1, #0x13]
    // 0xde205c: ldur            x3, [fp, #-8]
    // 0xde2060: StoreField: r1->field_23 = r3
    //     0xde2060: stur            w3, [x1, #0x23]
    // 0xde2064: r0 = CupertinoActionSheet()
    //     0xde2064: bl              #0xde20cc  ; AllocateCupertinoActionSheetStub -> CupertinoActionSheet (size=0x20)
    // 0xde2068: mov             x1, x0
    // 0xde206c: ldur            x0, [fp, #-0x10]
    // 0xde2070: stur            x1, [fp, #-8]
    // 0xde2074: StoreField: r1->field_13 = r0
    //     0xde2074: stur            w0, [x1, #0x13]
    // 0xde2078: ldur            x0, [fp, #-0x20]
    // 0xde207c: StoreField: r1->field_1b = r0
    //     0xde207c: stur            w0, [x1, #0x1b]
    // 0xde2080: r0 = SafeArea()
    //     0xde2080: bl              #0xd73100  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0xde2084: r1 = true
    //     0xde2084: add             x1, NULL, #0x20  ; true
    // 0xde2088: StoreField: r0->field_b = r1
    //     0xde2088: stur            w1, [x0, #0xb]
    // 0xde208c: StoreField: r0->field_f = r1
    //     0xde208c: stur            w1, [x0, #0xf]
    // 0xde2090: StoreField: r0->field_13 = r1
    //     0xde2090: stur            w1, [x0, #0x13]
    // 0xde2094: ArrayStore: r0[0] = r1  ; List_4
    //     0xde2094: stur            w1, [x0, #0x17]
    // 0xde2098: r1 = Instance_EdgeInsets
    //     0xde2098: ldr             x1, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0xde209c: StoreField: r0->field_1b = r1
    //     0xde209c: stur            w1, [x0, #0x1b]
    // 0xde20a0: r1 = false
    //     0xde20a0: add             x1, NULL, #0x30  ; false
    // 0xde20a4: StoreField: r0->field_1f = r1
    //     0xde20a4: stur            w1, [x0, #0x1f]
    // 0xde20a8: ldur            x1, [fp, #-8]
    // 0xde20ac: StoreField: r0->field_23 = r1
    //     0xde20ac: stur            w1, [x0, #0x23]
    // 0xde20b0: LeaveFrame
    //     0xde20b0: mov             SP, fp
    //     0xde20b4: ldp             fp, lr, [SP], #0x10
    // 0xde20b8: ret
    //     0xde20b8: ret             
    // 0xde20bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde20bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde20c0: b               #0xde1ea0
    // 0xde20c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde20c4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde20c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde20c8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] CupertinoActionSheetAction <anonymous closure>(dynamic, OptionItem) {
    // ** addr: 0xde212c, size: 0x9c
    // 0xde212c: EnterFrame
    //     0xde212c: stp             fp, lr, [SP, #-0x10]!
    //     0xde2130: mov             fp, SP
    // 0xde2134: AllocStack(0x18)
    //     0xde2134: sub             SP, SP, #0x18
    // 0xde2138: SetupParameters([dynamic _ /* r0 */])
    //     0xde2138: ldr             x0, [fp, #0x18]
    //     0xde213c: ldur            w1, [x0, #0x17]
    //     0xde2140: add             x1, x1, HEAP, lsl #32
    //     0xde2144: stur            x1, [fp, #-8]
    // 0xde2148: r1 = 1
    //     0xde2148: mov             x1, #1
    // 0xde214c: r0 = AllocateContext()
    //     0xde214c: bl              #0x13de838  ; AllocateContextStub
    // 0xde2150: mov             x1, x0
    // 0xde2154: ldur            x0, [fp, #-8]
    // 0xde2158: stur            x1, [fp, #-0x10]
    // 0xde215c: StoreField: r1->field_b = r0
    //     0xde215c: stur            w0, [x1, #0xb]
    // 0xde2160: ldr             x0, [fp, #0x10]
    // 0xde2164: StoreField: r1->field_f = r0
    //     0xde2164: stur            w0, [x1, #0xf]
    // 0xde2168: LoadField: r2 = r0->field_f
    //     0xde2168: ldur            w2, [x0, #0xf]
    // 0xde216c: DecompressPointer r2
    //     0xde216c: add             x2, x2, HEAP, lsl #32
    // 0xde2170: stur            x2, [fp, #-8]
    // 0xde2174: r0 = Text()
    //     0xde2174: bl              #0x8a70a4  ; AllocateTextStub -> Text (size=0x50)
    // 0xde2178: mov             x3, x0
    // 0xde217c: ldur            x0, [fp, #-8]
    // 0xde2180: stur            x3, [fp, #-0x18]
    // 0xde2184: StoreField: r3->field_b = r0
    //     0xde2184: stur            w0, [x3, #0xb]
    // 0xde2188: ldur            x2, [fp, #-0x10]
    // 0xde218c: r1 = Function '<anonymous closure>':.
    //     0xde218c: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd49e8] AnonymousClosure: (0xde21c8), in [package:chewie/src/cupertino/widgets/cupertino_options_dialog.dart] _CupertinoOptionsDialogState::build (0xde1e80)
    //     0xde2190: ldr             x1, [x1, #0x9e8]
    // 0xde2194: r0 = AllocateClosure()
    //     0xde2194: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xde2198: stur            x0, [fp, #-8]
    // 0xde219c: r0 = CupertinoActionSheetAction()
    //     0xde219c: bl              #0xde20fc  ; AllocateCupertinoActionSheetActionStub -> CupertinoActionSheetAction (size=0x28)
    // 0xde21a0: ldur            x1, [fp, #-8]
    // 0xde21a4: StoreField: r0->field_b = r1
    //     0xde21a4: stur            w1, [x0, #0xb]
    // 0xde21a8: r1 = false
    //     0xde21a8: add             x1, NULL, #0x30  ; false
    // 0xde21ac: StoreField: r0->field_f = r1
    //     0xde21ac: stur            w1, [x0, #0xf]
    // 0xde21b0: StoreField: r0->field_13 = r1
    //     0xde21b0: stur            w1, [x0, #0x13]
    // 0xde21b4: ldur            x1, [fp, #-0x18]
    // 0xde21b8: StoreField: r0->field_23 = r1
    //     0xde21b8: stur            w1, [x0, #0x23]
    // 0xde21bc: LeaveFrame
    //     0xde21bc: mov             SP, fp
    //     0xde21c0: ldp             fp, lr, [SP], #0x10
    // 0xde21c4: ret
    //     0xde21c4: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xde21c8, size: 0x6c
    // 0xde21c8: EnterFrame
    //     0xde21c8: stp             fp, lr, [SP, #-0x10]!
    //     0xde21cc: mov             fp, SP
    // 0xde21d0: AllocStack(0x10)
    //     0xde21d0: sub             SP, SP, #0x10
    // 0xde21d4: SetupParameters([dynamic _ /* r0 */])
    //     0xde21d4: ldr             x0, [fp, #0x10]
    //     0xde21d8: ldur            w1, [x0, #0x17]
    //     0xde21dc: add             x1, x1, HEAP, lsl #32
    // 0xde21e0: CheckStackOverflow
    //     0xde21e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde21e4: cmp             SP, x16
    //     0xde21e8: b.ls            #0xde222c
    // 0xde21ec: LoadField: r0 = r1->field_f
    //     0xde21ec: ldur            w0, [x1, #0xf]
    // 0xde21f0: DecompressPointer r0
    //     0xde21f0: add             x0, x0, HEAP, lsl #32
    // 0xde21f4: LoadField: r2 = r1->field_b
    //     0xde21f4: ldur            w2, [x1, #0xb]
    // 0xde21f8: DecompressPointer r2
    //     0xde21f8: add             x2, x2, HEAP, lsl #32
    // 0xde21fc: LoadField: r1 = r2->field_f
    //     0xde21fc: ldur            w1, [x2, #0xf]
    // 0xde2200: DecompressPointer r1
    //     0xde2200: add             x1, x1, HEAP, lsl #32
    // 0xde2204: LoadField: r2 = r0->field_7
    //     0xde2204: ldur            w2, [x0, #7]
    // 0xde2208: DecompressPointer r2
    //     0xde2208: add             x2, x2, HEAP, lsl #32
    // 0xde220c: stp             x1, x2, [SP]
    // 0xde2210: mov             x0, x2
    // 0xde2214: ClosureCall
    //     0xde2214: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xde2218: ldur            x2, [x0, #0x1f]
    //     0xde221c: blr             x2
    // 0xde2220: LeaveFrame
    //     0xde2220: mov             SP, fp
    //     0xde2224: ldp             fp, lr, [SP], #0x10
    // 0xde2228: ret
    //     0xde2228: ret             
    // 0xde222c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde222c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde2230: b               #0xde21ec
  }
}

// class id: 6536, size: 0x14, field offset: 0xc
//   const constructor, 
class CupertinoOptionsDialog extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xf9ff4c, size: 0x24
    // 0xf9ff4c: EnterFrame
    //     0xf9ff4c: stp             fp, lr, [SP, #-0x10]!
    //     0xf9ff50: mov             fp, SP
    // 0xf9ff54: mov             x0, x1
    // 0xf9ff58: r1 = <CupertinoOptionsDialog>
    //     0xf9ff58: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4688] TypeArguments: <CupertinoOptionsDialog>
    //     0xf9ff5c: ldr             x1, [x1, #0x688]
    // 0xf9ff60: r0 = _CupertinoOptionsDialogState()
    //     0xf9ff60: bl              #0xf9ff70  ; Allocate_CupertinoOptionsDialogStateStub -> _CupertinoOptionsDialogState (size=0x14)
    // 0xf9ff64: LeaveFrame
    //     0xf9ff64: mov             SP, fp
    //     0xf9ff68: ldp             fp, lr, [SP], #0x10
    // 0xf9ff6c: ret
    //     0xf9ff6c: ret             
  }
}
