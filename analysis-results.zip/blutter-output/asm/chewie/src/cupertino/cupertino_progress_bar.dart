// lib: , url: package:chewie/src/cupertino/cupertino_progress_bar.dart

// class id: 1048632, size: 0x8
class :: {
}

// class id: 6215, size: 0x24, field offset: 0xc
class CupertinoVideoProgressBar extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfaa850, size: 0x94
    // 0xfaa850: EnterFrame
    //     0xfaa850: stp             fp, lr, [SP, #-0x10]!
    //     0xfaa854: mov             fp, SP
    // 0xfaa858: AllocStack(0x28)
    //     0xfaa858: sub             SP, SP, #0x28
    // 0xfaa85c: CheckStackOverflow
    //     0xfaa85c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfaa860: cmp             SP, x16
    //     0xfaa864: b.ls            #0xfaa8dc
    // 0xfaa868: LoadField: r2 = r1->field_b
    //     0xfaa868: ldur            w2, [x1, #0xb]
    // 0xfaa86c: DecompressPointer r2
    //     0xfaa86c: add             x2, x2, HEAP, lsl #32
    // 0xfaa870: stur            x2, [fp, #-0x28]
    // 0xfaa874: LoadField: r3 = r1->field_f
    //     0xfaa874: ldur            w3, [x1, #0xf]
    // 0xfaa878: DecompressPointer r3
    //     0xfaa878: add             x3, x3, HEAP, lsl #32
    // 0xfaa87c: stur            x3, [fp, #-0x20]
    // 0xfaa880: ArrayLoad: r5 = r1[0]  ; List_4
    //     0xfaa880: ldur            w5, [x1, #0x17]
    // 0xfaa884: DecompressPointer r5
    //     0xfaa884: add             x5, x5, HEAP, lsl #32
    // 0xfaa888: stur            x5, [fp, #-0x18]
    // 0xfaa88c: LoadField: r6 = r1->field_13
    //     0xfaa88c: ldur            w6, [x1, #0x13]
    // 0xfaa890: DecompressPointer r6
    //     0xfaa890: add             x6, x6, HEAP, lsl #32
    // 0xfaa894: stur            x6, [fp, #-0x10]
    // 0xfaa898: LoadField: r7 = r1->field_1b
    //     0xfaa898: ldur            w7, [x1, #0x1b]
    // 0xfaa89c: DecompressPointer r7
    //     0xfaa89c: add             x7, x7, HEAP, lsl #32
    // 0xfaa8a0: stur            x7, [fp, #-8]
    // 0xfaa8a4: r0 = VideoProgressBar()
    //     0xfaa8a4: bl              #0xfaa9d8  ; AllocateVideoProgressBarStub -> VideoProgressBar (size=0x38)
    // 0xfaa8a8: mov             x1, x0
    // 0xfaa8ac: ldur            x2, [fp, #-0x28]
    // 0xfaa8b0: ldur            x3, [fp, #-0x20]
    // 0xfaa8b4: ldur            x5, [fp, #-0x18]
    // 0xfaa8b8: ldur            x6, [fp, #-0x10]
    // 0xfaa8bc: ldur            x7, [fp, #-8]
    // 0xfaa8c0: d0 = 5.000000
    //     0xfaa8c0: fmov            d0, #5.00000000
    // 0xfaa8c4: stur            x0, [fp, #-8]
    // 0xfaa8c8: r0 = VideoProgressBar()
    //     0xfaa8c8: bl              #0xfaa8e4  ; [package:chewie/src/progress_bar.dart] VideoProgressBar::VideoProgressBar
    // 0xfaa8cc: ldur            x0, [fp, #-8]
    // 0xfaa8d0: LeaveFrame
    //     0xfaa8d0: mov             SP, fp
    //     0xfaa8d4: ldp             fp, lr, [SP], #0x10
    // 0xfaa8d8: ret
    //     0xfaa8d8: ret             
    // 0xfaa8dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfaa8dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfaa8e0: b               #0xfaa868
  }
}
