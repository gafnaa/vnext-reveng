// lib: , url: package:chewie/src/cupertino/cupertino_controls.dart

// class id: 1048631, size: 0x8
class :: {
}

// class id: 5564, size: 0x5c, field offset: 0x1c
class _CupertinoControlsState extends _MixinApplication737&State&SingleTickerProviderStateMixin {

  late VideoPlayerController controller; // offset: 0x54
  late PlayerNotifier notifier; // offset: 0x1c
  late VideoPlayerValue _latestValue; // offset: 0x20

  _ build(/* No info */) {
    // ** addr: 0xdcd9bc, size: 0x4fc
    // 0xdcd9bc: EnterFrame
    //     0xdcd9bc: stp             fp, lr, [SP, #-0x10]!
    //     0xdcd9c0: mov             fp, SP
    // 0xdcd9c4: AllocStack(0x58)
    //     0xdcd9c4: sub             SP, SP, #0x58
    // 0xdcd9c8: SetupParameters(_CupertinoControlsState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xdcd9c8: mov             x0, x1
    //     0xdcd9cc: stur            x1, [fp, #-8]
    //     0xdcd9d0: mov             x1, x2
    //     0xdcd9d4: stur            x2, [fp, #-0x10]
    // 0xdcd9d8: CheckStackOverflow
    //     0xdcd9d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdcd9dc: cmp             SP, x16
    //     0xdcd9e0: b.ls            #0xdcde90
    // 0xdcd9e4: r1 = 1
    //     0xdcd9e4: mov             x1, #1
    // 0xdcd9e8: r0 = AllocateContext()
    //     0xdcd9e8: bl              #0x13de838  ; AllocateContextStub
    // 0xdcd9ec: mov             x2, x0
    // 0xdcd9f0: ldur            x0, [fp, #-8]
    // 0xdcd9f4: stur            x2, [fp, #-0x18]
    // 0xdcd9f8: StoreField: r2->field_f = r0
    //     0xdcd9f8: stur            w0, [x2, #0xf]
    // 0xdcd9fc: LoadField: r1 = r0->field_1f
    //     0xdcd9fc: ldur            w1, [x0, #0x1f]
    // 0xdcda00: DecompressPointer r1
    //     0xdcda00: add             x1, x1, HEAP, lsl #32
    // 0xdcda04: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdcda08: cmp             w1, w16
    // 0xdcda0c: b.eq            #0xdcde98
    // 0xdcda10: LoadField: r3 = r1->field_37
    //     0xdcda10: ldur            w3, [x1, #0x37]
    // 0xdcda14: DecompressPointer r3
    //     0xdcda14: add             x3, x3, HEAP, lsl #32
    // 0xdcda18: cmp             w3, NULL
    // 0xdcda1c: b.eq            #0xdcda44
    // 0xdcda20: LoadField: r1 = r0->field_57
    //     0xdcda20: ldur            w1, [x0, #0x57]
    // 0xdcda24: DecompressPointer r1
    //     0xdcda24: add             x1, x1, HEAP, lsl #32
    // 0xdcda28: cmp             w1, NULL
    // 0xdcda2c: b.eq            #0xdcdea4
    // 0xdcda30: r0 = Instance_Center
    //     0xdcda30: add             x0, PP, #0xd3, lsl #12  ; [pp+0xd3fd0] Obj!Center@12b75c1
    //     0xdcda34: ldr             x0, [x0, #0xfd0]
    // 0xdcda38: LeaveFrame
    //     0xdcda38: mov             SP, fp
    //     0xdcda3c: ldp             fp, lr, [SP], #0x10
    // 0xdcda40: ret
    //     0xdcda40: ret             
    // 0xdcda44: LoadField: r1 = r0->field_b
    //     0xdcda44: ldur            w1, [x0, #0xb]
    // 0xdcda48: DecompressPointer r1
    //     0xdcda48: add             x1, x1, HEAP, lsl #32
    // 0xdcda4c: cmp             w1, NULL
    // 0xdcda50: b.eq            #0xdcdea8
    // 0xdcda54: ldur            x1, [fp, #-0x10]
    // 0xdcda58: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xdcda58: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xdcda5c: r0 = _of()
    //     0xdcda5c: bl              #0x8651cc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::_of
    // 0xdcda60: LoadField: r1 = r0->field_7
    //     0xdcda60: ldur            w1, [x0, #7]
    // 0xdcda64: DecompressPointer r1
    //     0xdcda64: add             x1, x1, HEAP, lsl #32
    // 0xdcda68: LoadField: d0 = r1->field_7
    //     0xdcda68: ldur            d0, [x1, #7]
    // 0xdcda6c: LoadField: d1 = r1->field_f
    //     0xdcda6c: ldur            d1, [x1, #0xf]
    // 0xdcda70: fcmp            d0, d1
    // 0xdcda74: b.le            #0xdcda84
    // 0xdcda78: r0 = Instance_Orientation
    //     0xdcda78: add             x0, PP, #0x14, lsl #12  ; [pp+0x143c0] Obj!Orientation@12c2ee1
    //     0xdcda7c: ldr             x0, [x0, #0x3c0]
    // 0xdcda80: b               #0xdcda8c
    // 0xdcda84: r0 = Instance_Orientation
    //     0xdcda84: add             x0, PP, #0x14, lsl #12  ; [pp+0x143c8] Obj!Orientation@12c2ec1
    //     0xdcda88: ldr             x0, [x0, #0x3c8]
    // 0xdcda8c: r16 = Instance_Orientation
    //     0xdcda8c: add             x16, PP, #0x14, lsl #12  ; [pp+0x143c8] Obj!Orientation@12c2ec1
    //     0xdcda90: ldr             x16, [x16, #0x3c8]
    // 0xdcda94: cmp             w0, w16
    // 0xdcda98: b.ne            #0xdcdaa4
    // 0xdcda9c: d0 = 30.000000
    //     0xdcda9c: fmov            d0, #30.00000000
    // 0xdcdaa0: b               #0xdcdaac
    // 0xdcdaa4: d0 = 47.000000
    //     0xdcdaa4: add             x17, PP, #0xd3, lsl #12  ; [pp+0xd3fd8] IMM: double(47) from 0x4047800000000000
    //     0xdcdaa8: ldr             d0, [x17, #0xfd8]
    // 0xdcdaac: stur            d0, [fp, #-0x48]
    // 0xdcdab0: r16 = Instance_Orientation
    //     0xdcdab0: add             x16, PP, #0x14, lsl #12  ; [pp+0x143c8] Obj!Orientation@12c2ec1
    //     0xdcdab4: ldr             x16, [x16, #0x3c8]
    // 0xdcdab8: cmp             w0, w16
    // 0xdcdabc: b.ne            #0xdcdac8
    // 0xdcdac0: d1 = 16.000000
    //     0xdcdac0: fmov            d1, #16.00000000
    // 0xdcdac4: b               #0xdcdacc
    // 0xdcdac8: d1 = 24.000000
    //     0xdcdac8: fmov            d1, #24.00000000
    // 0xdcdacc: ldur            x0, [fp, #-8]
    // 0xdcdad0: stur            d1, [fp, #-0x40]
    // 0xdcdad4: LoadField: r1 = r0->field_1b
    //     0xdcdad4: ldur            w1, [x0, #0x1b]
    // 0xdcdad8: DecompressPointer r1
    //     0xdcdad8: add             x1, x1, HEAP, lsl #32
    // 0xdcdadc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdcdae0: cmp             w1, w16
    // 0xdcdae4: b.eq            #0xdcdeac
    // 0xdcdae8: LoadField: r3 = r1->field_23
    //     0xdcdae8: ldur            w3, [x1, #0x23]
    // 0xdcdaec: DecompressPointer r3
    //     0xdcdaec: add             x3, x3, HEAP, lsl #32
    // 0xdcdaf0: stur            x3, [fp, #-0x10]
    // 0xdcdaf4: r1 = <Widget>
    //     0xdcdaf4: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xdcdaf8: r2 = 0
    //     0xdcdaf8: mov             x2, #0
    // 0xdcdafc: r0 = _GrowableList()
    //     0xdcdafc: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xdcdb00: mov             x2, x0
    // 0xdcdb04: ldur            x0, [fp, #-8]
    // 0xdcdb08: stur            x2, [fp, #-0x28]
    // 0xdcdb0c: LoadField: r1 = r0->field_47
    //     0xdcdb0c: ldur            w1, [x0, #0x47]
    // 0xdcdb10: DecompressPointer r1
    //     0xdcdb10: add             x1, x1, HEAP, lsl #32
    // 0xdcdb14: tbnz            w1, #4, #0xdcdb78
    // 0xdcdb18: LoadField: r1 = r2->field_b
    //     0xdcdb18: ldur            w1, [x2, #0xb]
    // 0xdcdb1c: LoadField: r3 = r2->field_f
    //     0xdcdb1c: ldur            w3, [x2, #0xf]
    // 0xdcdb20: DecompressPointer r3
    //     0xdcdb20: add             x3, x3, HEAP, lsl #32
    // 0xdcdb24: LoadField: r4 = r3->field_b
    //     0xdcdb24: ldur            w4, [x3, #0xb]
    // 0xdcdb28: r3 = LoadInt32Instr(r1)
    //     0xdcdb28: sbfx            x3, x1, #1, #0x1f
    // 0xdcdb2c: stur            x3, [fp, #-0x20]
    // 0xdcdb30: r1 = LoadInt32Instr(r4)
    //     0xdcdb30: sbfx            x1, x4, #1, #0x1f
    // 0xdcdb34: cmp             x3, x1
    // 0xdcdb38: b.ne            #0xdcdb44
    // 0xdcdb3c: mov             x1, x2
    // 0xdcdb40: r0 = _growToNextCapacity()
    //     0xdcdb40: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xdcdb44: ldur            x0, [fp, #-0x28]
    // 0xdcdb48: ldur            x1, [fp, #-0x20]
    // 0xdcdb4c: add             x2, x1, #1
    // 0xdcdb50: lsl             x3, x2, #1
    // 0xdcdb54: StoreField: r0->field_b = r3
    //     0xdcdb54: stur            w3, [x0, #0xb]
    // 0xdcdb58: LoadField: r2 = r0->field_f
    //     0xdcdb58: ldur            w2, [x0, #0xf]
    // 0xdcdb5c: DecompressPointer r2
    //     0xdcdb5c: add             x2, x2, HEAP, lsl #32
    // 0xdcdb60: add             x3, x2, x1, lsl #2
    // 0xdcdb64: r16 = Instance_Center
    //     0xdcdb64: add             x16, PP, #0x15, lsl #12  ; [pp+0x157b8] Obj!Center@12b75a1
    //     0xdcdb68: ldr             x16, [x16, #0x7b8]
    // 0xdcdb6c: StoreField: r3->field_f = r16
    //     0xdcdb6c: stur            w16, [x3, #0xf]
    // 0xdcdb70: mov             x2, x0
    // 0xdcdb74: b               #0xdcdc04
    // 0xdcdb78: mov             x0, x2
    // 0xdcdb7c: ldur            x1, [fp, #-8]
    // 0xdcdb80: r0 = _buildHitArea()
    //     0xdcdb80: bl              #0xdd3190  ; [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_buildHitArea
    // 0xdcdb84: mov             x2, x0
    // 0xdcdb88: ldur            x0, [fp, #-0x28]
    // 0xdcdb8c: stur            x2, [fp, #-0x30]
    // 0xdcdb90: LoadField: r1 = r0->field_b
    //     0xdcdb90: ldur            w1, [x0, #0xb]
    // 0xdcdb94: LoadField: r3 = r0->field_f
    //     0xdcdb94: ldur            w3, [x0, #0xf]
    // 0xdcdb98: DecompressPointer r3
    //     0xdcdb98: add             x3, x3, HEAP, lsl #32
    // 0xdcdb9c: LoadField: r4 = r3->field_b
    //     0xdcdb9c: ldur            w4, [x3, #0xb]
    // 0xdcdba0: r3 = LoadInt32Instr(r1)
    //     0xdcdba0: sbfx            x3, x1, #1, #0x1f
    // 0xdcdba4: stur            x3, [fp, #-0x20]
    // 0xdcdba8: r1 = LoadInt32Instr(r4)
    //     0xdcdba8: sbfx            x1, x4, #1, #0x1f
    // 0xdcdbac: cmp             x3, x1
    // 0xdcdbb0: b.ne            #0xdcdbbc
    // 0xdcdbb4: mov             x1, x0
    // 0xdcdbb8: r0 = _growToNextCapacity()
    //     0xdcdbb8: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xdcdbbc: ldur            x2, [fp, #-0x28]
    // 0xdcdbc0: ldur            x3, [fp, #-0x20]
    // 0xdcdbc4: add             x0, x3, #1
    // 0xdcdbc8: lsl             x1, x0, #1
    // 0xdcdbcc: StoreField: r2->field_b = r1
    //     0xdcdbcc: stur            w1, [x2, #0xb]
    // 0xdcdbd0: LoadField: r1 = r2->field_f
    //     0xdcdbd0: ldur            w1, [x2, #0xf]
    // 0xdcdbd4: DecompressPointer r1
    //     0xdcdbd4: add             x1, x1, HEAP, lsl #32
    // 0xdcdbd8: ldur            x0, [fp, #-0x30]
    // 0xdcdbdc: ArrayStore: r1[r3] = r0  ; List_4
    //     0xdcdbdc: add             x25, x1, x3, lsl #2
    //     0xdcdbe0: add             x25, x25, #0xf
    //     0xdcdbe4: str             w0, [x25]
    //     0xdcdbe8: tbz             w0, #0, #0xdcdc04
    //     0xdcdbec: ldurb           w16, [x1, #-1]
    //     0xdcdbf0: ldurb           w17, [x0, #-1]
    //     0xdcdbf4: and             x16, x17, x16, lsr #2
    //     0xdcdbf8: tst             x16, HEAP, lsr #32
    //     0xdcdbfc: b.eq            #0xdcdc04
    //     0xdcdc00: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdcdc04: ldur            x1, [fp, #-8]
    // 0xdcdc08: ldur            d0, [fp, #-0x48]
    // 0xdcdc0c: ldur            d1, [fp, #-0x40]
    // 0xdcdc10: r0 = _buildTopBar()
    //     0xdcdc10: bl              #0xdd2448  ; [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_buildTopBar
    // 0xdcdc14: r1 = Null
    //     0xdcdc14: mov             x1, NULL
    // 0xdcdc18: r2 = 4
    //     0xdcdc18: mov             x2, #4
    // 0xdcdc1c: stur            x0, [fp, #-0x30]
    // 0xdcdc20: r0 = AllocateArray()
    //     0xdcdc20: bl              #0x13df928  ; AllocateArrayStub
    // 0xdcdc24: mov             x2, x0
    // 0xdcdc28: ldur            x0, [fp, #-0x30]
    // 0xdcdc2c: stur            x2, [fp, #-0x38]
    // 0xdcdc30: StoreField: r2->field_f = r0
    //     0xdcdc30: stur            w0, [x2, #0xf]
    // 0xdcdc34: r16 = Instance_Spacer
    //     0xdcdc34: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1ee78] Obj!Spacer@12b5c01
    //     0xdcdc38: ldr             x16, [x16, #0xe78]
    // 0xdcdc3c: StoreField: r2->field_13 = r16
    //     0xdcdc3c: stur            w16, [x2, #0x13]
    // 0xdcdc40: r1 = <Widget>
    //     0xdcdc40: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xdcdc44: r0 = AllocateGrowableArray()
    //     0xdcdc44: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xdcdc48: mov             x2, x0
    // 0xdcdc4c: ldur            x0, [fp, #-0x38]
    // 0xdcdc50: stur            x2, [fp, #-0x30]
    // 0xdcdc54: StoreField: r2->field_f = r0
    //     0xdcdc54: stur            w0, [x2, #0xf]
    // 0xdcdc58: r0 = 4
    //     0xdcdc58: mov             x0, #4
    // 0xdcdc5c: StoreField: r2->field_b = r0
    //     0xdcdc5c: stur            w0, [x2, #0xb]
    // 0xdcdc60: ldur            x1, [fp, #-8]
    // 0xdcdc64: ldur            d0, [fp, #-0x48]
    // 0xdcdc68: r0 = _buildBottomBar()
    //     0xdcdc68: bl              #0xdcdeb8  ; [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_buildBottomBar
    // 0xdcdc6c: mov             x2, x0
    // 0xdcdc70: ldur            x0, [fp, #-0x30]
    // 0xdcdc74: stur            x2, [fp, #-8]
    // 0xdcdc78: LoadField: r1 = r0->field_b
    //     0xdcdc78: ldur            w1, [x0, #0xb]
    // 0xdcdc7c: LoadField: r3 = r0->field_f
    //     0xdcdc7c: ldur            w3, [x0, #0xf]
    // 0xdcdc80: DecompressPointer r3
    //     0xdcdc80: add             x3, x3, HEAP, lsl #32
    // 0xdcdc84: LoadField: r4 = r3->field_b
    //     0xdcdc84: ldur            w4, [x3, #0xb]
    // 0xdcdc88: r3 = LoadInt32Instr(r1)
    //     0xdcdc88: sbfx            x3, x1, #1, #0x1f
    // 0xdcdc8c: stur            x3, [fp, #-0x20]
    // 0xdcdc90: r1 = LoadInt32Instr(r4)
    //     0xdcdc90: sbfx            x1, x4, #1, #0x1f
    // 0xdcdc94: cmp             x3, x1
    // 0xdcdc98: b.ne            #0xdcdca4
    // 0xdcdc9c: mov             x1, x0
    // 0xdcdca0: r0 = _growToNextCapacity()
    //     0xdcdca0: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xdcdca4: ldur            x4, [fp, #-0x28]
    // 0xdcdca8: ldur            x2, [fp, #-0x30]
    // 0xdcdcac: ldur            x3, [fp, #-0x20]
    // 0xdcdcb0: add             x0, x3, #1
    // 0xdcdcb4: lsl             x1, x0, #1
    // 0xdcdcb8: StoreField: r2->field_b = r1
    //     0xdcdcb8: stur            w1, [x2, #0xb]
    // 0xdcdcbc: LoadField: r1 = r2->field_f
    //     0xdcdcbc: ldur            w1, [x2, #0xf]
    // 0xdcdcc0: DecompressPointer r1
    //     0xdcdcc0: add             x1, x1, HEAP, lsl #32
    // 0xdcdcc4: ldur            x0, [fp, #-8]
    // 0xdcdcc8: ArrayStore: r1[r3] = r0  ; List_4
    //     0xdcdcc8: add             x25, x1, x3, lsl #2
    //     0xdcdccc: add             x25, x25, #0xf
    //     0xdcdcd0: str             w0, [x25]
    //     0xdcdcd4: tbz             w0, #0, #0xdcdcf0
    //     0xdcdcd8: ldurb           w16, [x1, #-1]
    //     0xdcdcdc: ldurb           w17, [x0, #-1]
    //     0xdcdce0: and             x16, x17, x16, lsr #2
    //     0xdcdce4: tst             x16, HEAP, lsr #32
    //     0xdcdce8: b.eq            #0xdcdcf0
    //     0xdcdcec: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdcdcf0: r0 = Column()
    //     0xdcdcf0: bl              #0x8a5b1c  ; AllocateColumnStub -> Column (size=0x38)
    // 0xdcdcf4: mov             x2, x0
    // 0xdcdcf8: r0 = Instance_Axis
    //     0xdcdcf8: ldr             x0, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xdcdcfc: stur            x2, [fp, #-8]
    // 0xdcdd00: StoreField: r2->field_f = r0
    //     0xdcdd00: stur            w0, [x2, #0xf]
    // 0xdcdd04: r0 = Instance_MainAxisAlignment
    //     0xdcdd04: add             x0, PP, #0x17, lsl #12  ; [pp+0x177b0] Obj!MainAxisAlignment@12c45c1
    //     0xdcdd08: ldr             x0, [x0, #0x7b0]
    // 0xdcdd0c: StoreField: r2->field_13 = r0
    //     0xdcdd0c: stur            w0, [x2, #0x13]
    // 0xdcdd10: r0 = Instance_MainAxisSize
    //     0xdcdd10: add             x0, PP, #0x15, lsl #12  ; [pp+0x15828] Obj!MainAxisSize@12c4621
    //     0xdcdd14: ldr             x0, [x0, #0x828]
    // 0xdcdd18: ArrayStore: r2[0] = r0  ; List_4
    //     0xdcdd18: stur            w0, [x2, #0x17]
    // 0xdcdd1c: r0 = Instance_CrossAxisAlignment
    //     0xdcdd1c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15888] Obj!CrossAxisAlignment@12c44a1
    //     0xdcdd20: ldr             x0, [x0, #0x888]
    // 0xdcdd24: StoreField: r2->field_1b = r0
    //     0xdcdd24: stur            w0, [x2, #0x1b]
    // 0xdcdd28: r0 = Instance_VerticalDirection
    //     0xdcdd28: add             x0, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xdcdd2c: ldr             x0, [x0, #0x838]
    // 0xdcdd30: StoreField: r2->field_23 = r0
    //     0xdcdd30: stur            w0, [x2, #0x23]
    // 0xdcdd34: r0 = Instance_Clip
    //     0xdcdd34: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xdcdd38: ldr             x0, [x0, #0x840]
    // 0xdcdd3c: StoreField: r2->field_2b = r0
    //     0xdcdd3c: stur            w0, [x2, #0x2b]
    // 0xdcdd40: StoreField: r2->field_2f = rZR
    //     0xdcdd40: stur            xzr, [x2, #0x2f]
    // 0xdcdd44: ldur            x0, [fp, #-0x30]
    // 0xdcdd48: StoreField: r2->field_b = r0
    //     0xdcdd48: stur            w0, [x2, #0xb]
    // 0xdcdd4c: ldur            x0, [fp, #-0x28]
    // 0xdcdd50: LoadField: r1 = r0->field_b
    //     0xdcdd50: ldur            w1, [x0, #0xb]
    // 0xdcdd54: LoadField: r3 = r0->field_f
    //     0xdcdd54: ldur            w3, [x0, #0xf]
    // 0xdcdd58: DecompressPointer r3
    //     0xdcdd58: add             x3, x3, HEAP, lsl #32
    // 0xdcdd5c: LoadField: r4 = r3->field_b
    //     0xdcdd5c: ldur            w4, [x3, #0xb]
    // 0xdcdd60: r3 = LoadInt32Instr(r1)
    //     0xdcdd60: sbfx            x3, x1, #1, #0x1f
    // 0xdcdd64: stur            x3, [fp, #-0x20]
    // 0xdcdd68: r1 = LoadInt32Instr(r4)
    //     0xdcdd68: sbfx            x1, x4, #1, #0x1f
    // 0xdcdd6c: cmp             x3, x1
    // 0xdcdd70: b.ne            #0xdcdd7c
    // 0xdcdd74: mov             x1, x0
    // 0xdcdd78: r0 = _growToNextCapacity()
    //     0xdcdd78: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xdcdd7c: ldur            x2, [fp, #-0x28]
    // 0xdcdd80: ldur            x4, [fp, #-0x10]
    // 0xdcdd84: ldur            x3, [fp, #-0x20]
    // 0xdcdd88: add             x0, x3, #1
    // 0xdcdd8c: lsl             x1, x0, #1
    // 0xdcdd90: StoreField: r2->field_b = r1
    //     0xdcdd90: stur            w1, [x2, #0xb]
    // 0xdcdd94: LoadField: r1 = r2->field_f
    //     0xdcdd94: ldur            w1, [x2, #0xf]
    // 0xdcdd98: DecompressPointer r1
    //     0xdcdd98: add             x1, x1, HEAP, lsl #32
    // 0xdcdd9c: ldur            x0, [fp, #-8]
    // 0xdcdda0: ArrayStore: r1[r3] = r0  ; List_4
    //     0xdcdda0: add             x25, x1, x3, lsl #2
    //     0xdcdda4: add             x25, x25, #0xf
    //     0xdcdda8: str             w0, [x25]
    //     0xdcddac: tbz             w0, #0, #0xdcddc8
    //     0xdcddb0: ldurb           w16, [x1, #-1]
    //     0xdcddb4: ldurb           w17, [x0, #-1]
    //     0xdcddb8: and             x16, x17, x16, lsr #2
    //     0xdcddbc: tst             x16, HEAP, lsr #32
    //     0xdcddc0: b.eq            #0xdcddc8
    //     0xdcddc4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdcddc8: r0 = Stack()
    //     0xdcddc8: bl              #0xd1a854  ; AllocateStackStub -> Stack (size=0x20)
    // 0xdcddcc: mov             x1, x0
    // 0xdcddd0: r0 = Instance_AlignmentDirectional
    //     0xdcddd0: add             x0, PP, #0x15, lsl #12  ; [pp+0x158d8] Obj!AlignmentDirectional@129e611
    //     0xdcddd4: ldr             x0, [x0, #0x8d8]
    // 0xdcddd8: stur            x1, [fp, #-8]
    // 0xdcdddc: StoreField: r1->field_f = r0
    //     0xdcdddc: stur            w0, [x1, #0xf]
    // 0xdcdde0: r0 = Instance_StackFit
    //     0xdcdde0: add             x0, PP, #0x15, lsl #12  ; [pp+0x158e0] Obj!StackFit@12c4221
    //     0xdcdde4: ldr             x0, [x0, #0x8e0]
    // 0xdcdde8: ArrayStore: r1[0] = r0  ; List_4
    //     0xdcdde8: stur            w0, [x1, #0x17]
    // 0xdcddec: r0 = Instance_Clip
    //     0xdcddec: add             x0, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xdcddf0: ldr             x0, [x0, #0x850]
    // 0xdcddf4: StoreField: r1->field_1b = r0
    //     0xdcddf4: stur            w0, [x1, #0x1b]
    // 0xdcddf8: ldur            x0, [fp, #-0x28]
    // 0xdcddfc: StoreField: r1->field_b = r0
    //     0xdcddfc: stur            w0, [x1, #0xb]
    // 0xdcde00: r0 = AbsorbPointer()
    //     0xdcde00: bl              #0xd6cda8  ; AllocateAbsorbPointerStub -> AbsorbPointer (size=0x18)
    // 0xdcde04: mov             x1, x0
    // 0xdcde08: ldur            x0, [fp, #-0x10]
    // 0xdcde0c: stur            x1, [fp, #-0x28]
    // 0xdcde10: StoreField: r1->field_f = r0
    //     0xdcde10: stur            w0, [x1, #0xf]
    // 0xdcde14: ldur            x0, [fp, #-8]
    // 0xdcde18: StoreField: r1->field_b = r0
    //     0xdcde18: stur            w0, [x1, #0xb]
    // 0xdcde1c: r0 = GestureDetector()
    //     0xdcde1c: bl              #0x918e18  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0xdcde20: ldur            x2, [fp, #-0x18]
    // 0xdcde24: r1 = Function '<anonymous closure>':.
    //     0xdcde24: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3fe0] AnonymousClosure: (0xdd3148), in [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::build (0xdcd9bc)
    //     0xdcde28: ldr             x1, [x1, #0xfe0]
    // 0xdcde2c: stur            x0, [fp, #-8]
    // 0xdcde30: r0 = AllocateClosure()
    //     0xdcde30: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdcde34: ldur            x16, [fp, #-0x28]
    // 0xdcde38: stp             x16, x0, [SP]
    // 0xdcde3c: ldur            x1, [fp, #-8]
    // 0xdcde40: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0xdcde40: add             x4, PP, #0x16, lsl #12  ; [pp+0x16e90] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0xdcde44: ldr             x4, [x4, #0xe90]
    // 0xdcde48: r0 = GestureDetector()
    //     0xdcde48: bl              #0x9182dc  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0xdcde4c: ldur            x2, [fp, #-0x18]
    // 0xdcde50: r1 = Function '<anonymous closure>':.
    //     0xdcde50: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3fe8] AnonymousClosure: (0xdd3974), in [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::build (0xdcd9bc)
    //     0xdcde54: ldr             x1, [x1, #0xfe8]
    // 0xdcde58: r0 = AllocateClosure()
    //     0xdcde58: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdcde5c: stur            x0, [fp, #-0x10]
    // 0xdcde60: r0 = MouseRegion()
    //     0xdcde60: bl              #0xd1c8fc  ; AllocateMouseRegionStub -> MouseRegion (size=0x28)
    // 0xdcde64: ldur            x1, [fp, #-0x10]
    // 0xdcde68: StoreField: r0->field_13 = r1
    //     0xdcde68: stur            w1, [x0, #0x13]
    // 0xdcde6c: r1 = Instance__DeferringMouseCursor
    //     0xdcde6c: ldr             x1, [PP, #0x2208]  ; [pp+0x2208] Obj!_DeferringMouseCursor@12b3241
    // 0xdcde70: StoreField: r0->field_1b = r1
    //     0xdcde70: stur            w1, [x0, #0x1b]
    // 0xdcde74: r1 = true
    //     0xdcde74: add             x1, NULL, #0x20  ; true
    // 0xdcde78: StoreField: r0->field_1f = r1
    //     0xdcde78: stur            w1, [x0, #0x1f]
    // 0xdcde7c: ldur            x1, [fp, #-8]
    // 0xdcde80: StoreField: r0->field_b = r1
    //     0xdcde80: stur            w1, [x0, #0xb]
    // 0xdcde84: LeaveFrame
    //     0xdcde84: mov             SP, fp
    //     0xdcde88: ldp             fp, lr, [SP], #0x10
    // 0xdcde8c: ret
    //     0xdcde8c: ret             
    // 0xdcde90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdcde90: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdcde94: b               #0xdcd9e4
    // 0xdcde98: r9 = _latestValue
    //     0xdcde98: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3ff0] Field <_CupertinoControlsState@450205881._latestValue@450205881>: late (offset: 0x20)
    //     0xdcde9c: ldr             x9, [x9, #0xff0]
    // 0xdcdea0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdcdea0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdcdea4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdcdea4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdcdea8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdcdea8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdcdeac: r9 = notifier
    //     0xdcdeac: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3fb0] Field <_CupertinoControlsState@450205881.notifier>: late (offset: 0x1c)
    //     0xdcdeb0: ldr             x9, [x9, #0xfb0]
    // 0xdcdeb4: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xdcdeb4: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
  }
  _ _buildBottomBar(/* No info */) {
    // ** addr: 0xdcdeb8, size: 0x57c
    // 0xdcdeb8: EnterFrame
    //     0xdcdeb8: stp             fp, lr, [SP, #-0x10]!
    //     0xdcdebc: mov             fp, SP
    // 0xdcdec0: AllocStack(0x98)
    //     0xdcdec0: sub             SP, SP, #0x98
    // 0xdcdec4: SetupParameters(_CupertinoControlsState this /* r1 => r1, fp-0x10 */, dynamic _ /* d0 => d0, fp-0x78 */)
    //     0xdcdec4: stur            x1, [fp, #-0x10]
    //     0xdcdec8: stur            d0, [fp, #-0x78]
    // 0xdcdecc: CheckStackOverflow
    //     0xdcdecc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdcded0: cmp             SP, x16
    //     0xdcded4: b.ls            #0xdce3ec
    // 0xdcded8: LoadField: r0 = r1->field_57
    //     0xdcded8: ldur            w0, [x1, #0x57]
    // 0xdcdedc: DecompressPointer r0
    //     0xdcdedc: add             x0, x0, HEAP, lsl #32
    // 0xdcdee0: cmp             w0, NULL
    // 0xdcdee4: b.eq            #0xdce3f4
    // 0xdcdee8: LoadField: r2 = r0->field_cf
    //     0xdcdee8: ldur            w2, [x0, #0xcf]
    // 0xdcdeec: DecompressPointer r2
    //     0xdcdeec: add             x2, x2, HEAP, lsl #32
    // 0xdcdef0: stur            x2, [fp, #-8]
    // 0xdcdef4: LoadField: r0 = r1->field_1b
    //     0xdcdef4: ldur            w0, [x1, #0x1b]
    // 0xdcdef8: DecompressPointer r0
    //     0xdcdef8: add             x0, x0, HEAP, lsl #32
    // 0xdcdefc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdcdf00: cmp             w0, w16
    // 0xdcdf04: b.eq            #0xdce3f8
    // 0xdcdf08: LoadField: r3 = r0->field_23
    //     0xdcdf08: ldur            w3, [x0, #0x23]
    // 0xdcdf0c: DecompressPointer r3
    //     0xdcdf0c: add             x3, x3, HEAP, lsl #32
    // 0xdcdf10: tbnz            w3, #4, #0xdcdf1c
    // 0xdcdf14: d1 = 0.000000
    //     0xdcdf14: eor             v1.16b, v1.16b, v1.16b
    // 0xdcdf18: b               #0xdcdf20
    // 0xdcdf1c: d1 = 1.000000
    //     0xdcdf1c: fmov            d1, #1.00000000
    // 0xdcdf20: stur            d1, [fp, #-0x70]
    // 0xdcdf24: r0 = EdgeInsets()
    //     0xdcdf24: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xdcdf28: d0 = 5.000000
    //     0xdcdf28: fmov            d0, #5.00000000
    // 0xdcdf2c: stur            x0, [fp, #-0x18]
    // 0xdcdf30: StoreField: r0->field_7 = d0
    //     0xdcdf30: stur            d0, [x0, #7]
    // 0xdcdf34: StoreField: r0->field_f = d0
    //     0xdcdf34: stur            d0, [x0, #0xf]
    // 0xdcdf38: ArrayStore: r0[0] = d0  ; List_8
    //     0xdcdf38: stur            d0, [x0, #0x17]
    // 0xdcdf3c: StoreField: r0->field_1f = d0
    //     0xdcdf3c: stur            d0, [x0, #0x1f]
    // 0xdcdf40: r0 = Radius()
    //     0xdcdf40: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0xdcdf44: d0 = 10.000000
    //     0xdcdf44: fmov            d0, #10.00000000
    // 0xdcdf48: stur            x0, [fp, #-0x20]
    // 0xdcdf4c: StoreField: r0->field_7 = d0
    //     0xdcdf4c: stur            d0, [x0, #7]
    // 0xdcdf50: StoreField: r0->field_f = d0
    //     0xdcdf50: stur            d0, [x0, #0xf]
    // 0xdcdf54: r0 = BorderRadius()
    //     0xdcdf54: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0xdcdf58: mov             x1, x0
    // 0xdcdf5c: ldur            x0, [fp, #-0x20]
    // 0xdcdf60: stur            x1, [fp, #-0x28]
    // 0xdcdf64: StoreField: r1->field_7 = r0
    //     0xdcdf64: stur            w0, [x1, #7]
    // 0xdcdf68: StoreField: r1->field_b = r0
    //     0xdcdf68: stur            w0, [x1, #0xb]
    // 0xdcdf6c: StoreField: r1->field_f = r0
    //     0xdcdf6c: stur            w0, [x1, #0xf]
    // 0xdcdf70: StoreField: r1->field_13 = r0
    //     0xdcdf70: stur            w0, [x1, #0x13]
    // 0xdcdf74: r0 = _GaussianBlurImageFilter()
    //     0xdcdf74: bl              #0x9191c8  ; Allocate_GaussianBlurImageFilterStub -> _GaussianBlurImageFilter (size=0x24)
    // 0xdcdf78: mov             x2, x0
    // 0xdcdf7c: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xdcdf80: stur            x2, [fp, #-0x20]
    // 0xdcdf84: StoreField: r2->field_1f = r0
    //     0xdcdf84: stur            w0, [x2, #0x1f]
    // 0xdcdf88: d0 = 10.000000
    //     0xdcdf88: fmov            d0, #10.00000000
    // 0xdcdf8c: StoreField: r2->field_7 = d0
    //     0xdcdf8c: stur            d0, [x2, #7]
    // 0xdcdf90: StoreField: r2->field_f = d0
    //     0xdcdf90: stur            d0, [x2, #0xf]
    // 0xdcdf94: ldur            x1, [fp, #-0x10]
    // 0xdcdf98: ldur            d0, [fp, #-0x78]
    // 0xdcdf9c: r0 = _buildSkipBack()
    //     0xdcdf9c: bl              #0xdd21c0  ; [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_buildSkipBack
    // 0xdcdfa0: mov             x3, x0
    // 0xdcdfa4: ldur            x0, [fp, #-0x10]
    // 0xdcdfa8: stur            x3, [fp, #-0x30]
    // 0xdcdfac: LoadField: r2 = r0->field_53
    //     0xdcdfac: ldur            w2, [x0, #0x53]
    // 0xdcdfb0: DecompressPointer r2
    //     0xdcdfb0: add             x2, x2, HEAP, lsl #32
    // 0xdcdfb4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdcdfb8: cmp             w2, w16
    // 0xdcdfbc: b.eq            #0xdce404
    // 0xdcdfc0: mov             x1, x0
    // 0xdcdfc4: ldur            d0, [fp, #-0x78]
    // 0xdcdfc8: r0 = _buildPlayPause()
    //     0xdcdfc8: bl              #0xdd0f08  ; [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_buildPlayPause
    // 0xdcdfcc: ldur            x1, [fp, #-0x10]
    // 0xdcdfd0: ldur            d0, [fp, #-0x78]
    // 0xdcdfd4: stur            x0, [fp, #-0x38]
    // 0xdcdfd8: r0 = _buildSkipForward()
    //     0xdcdfd8: bl              #0xdd0ad0  ; [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_buildSkipForward
    // 0xdcdfdc: ldur            x1, [fp, #-0x10]
    // 0xdcdfe0: stur            x0, [fp, #-0x40]
    // 0xdcdfe4: r0 = _buildPosition()
    //     0xdcdfe4: bl              #0xdd0a14  ; [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_buildPosition
    // 0xdcdfe8: ldur            x1, [fp, #-0x10]
    // 0xdcdfec: stur            x0, [fp, #-0x48]
    // 0xdcdff0: r0 = _buildProgressBar()
    //     0xdcdff0: bl              #0xdcf6e0  ; [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_buildProgressBar
    // 0xdcdff4: ldur            x1, [fp, #-0x10]
    // 0xdcdff8: stur            x0, [fp, #-0x50]
    // 0xdcdffc: r0 = _buildRemaining()
    //     0xdcdffc: bl              #0xdcf33c  ; [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_buildRemaining
    // 0xdce000: mov             x3, x0
    // 0xdce004: ldur            x0, [fp, #-0x10]
    // 0xdce008: stur            x3, [fp, #-0x58]
    // 0xdce00c: LoadField: r1 = r0->field_57
    //     0xdce00c: ldur            w1, [x0, #0x57]
    // 0xdce010: DecompressPointer r1
    //     0xdce010: add             x1, x1, HEAP, lsl #32
    // 0xdce014: cmp             w1, NULL
    // 0xdce018: b.eq            #0xdce410
    // 0xdce01c: r1 = Null
    //     0xdce01c: mov             x1, NULL
    // 0xdce020: r2 = 14
    //     0xdce020: mov             x2, #0xe
    // 0xdce024: r0 = AllocateArray()
    //     0xdce024: bl              #0x13df928  ; AllocateArrayStub
    // 0xdce028: mov             x2, x0
    // 0xdce02c: ldur            x0, [fp, #-0x30]
    // 0xdce030: stur            x2, [fp, #-0x60]
    // 0xdce034: StoreField: r2->field_f = r0
    //     0xdce034: stur            w0, [x2, #0xf]
    // 0xdce038: ldur            x0, [fp, #-0x38]
    // 0xdce03c: StoreField: r2->field_13 = r0
    //     0xdce03c: stur            w0, [x2, #0x13]
    // 0xdce040: ldur            x0, [fp, #-0x40]
    // 0xdce044: ArrayStore: r2[0] = r0  ; List_4
    //     0xdce044: stur            w0, [x2, #0x17]
    // 0xdce048: ldur            x0, [fp, #-0x48]
    // 0xdce04c: StoreField: r2->field_1b = r0
    //     0xdce04c: stur            w0, [x2, #0x1b]
    // 0xdce050: ldur            x0, [fp, #-0x50]
    // 0xdce054: StoreField: r2->field_1f = r0
    //     0xdce054: stur            w0, [x2, #0x1f]
    // 0xdce058: ldur            x0, [fp, #-0x58]
    // 0xdce05c: StoreField: r2->field_23 = r0
    //     0xdce05c: stur            w0, [x2, #0x23]
    // 0xdce060: r16 = Instance_SizedBox
    //     0xdce060: add             x16, PP, #0x13, lsl #12  ; [pp+0x13db8] Obj!SizedBox@12b7241
    //     0xdce064: ldr             x16, [x16, #0xdb8]
    // 0xdce068: StoreField: r2->field_27 = r16
    //     0xdce068: stur            w16, [x2, #0x27]
    // 0xdce06c: r1 = <Widget>
    //     0xdce06c: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xdce070: r0 = AllocateGrowableArray()
    //     0xdce070: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xdce074: mov             x3, x0
    // 0xdce078: ldur            x0, [fp, #-0x60]
    // 0xdce07c: stur            x3, [fp, #-0x30]
    // 0xdce080: StoreField: r3->field_f = r0
    //     0xdce080: stur            w0, [x3, #0xf]
    // 0xdce084: r0 = 14
    //     0xdce084: mov             x0, #0xe
    // 0xdce088: StoreField: r3->field_b = r0
    //     0xdce088: stur            w0, [x3, #0xb]
    // 0xdce08c: ldur            x0, [fp, #-0x10]
    // 0xdce090: LoadField: r2 = r0->field_53
    //     0xdce090: ldur            w2, [x0, #0x53]
    // 0xdce094: DecompressPointer r2
    //     0xdce094: add             x2, x2, HEAP, lsl #32
    // 0xdce098: mov             x1, x0
    // 0xdce09c: ldur            d0, [fp, #-0x78]
    // 0xdce0a0: r0 = _buildSpeedButton()
    //     0xdce0a0: bl              #0xdceb90  ; [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_buildSpeedButton
    // 0xdce0a4: mov             x2, x0
    // 0xdce0a8: ldur            x0, [fp, #-0x30]
    // 0xdce0ac: stur            x2, [fp, #-0x38]
    // 0xdce0b0: LoadField: r1 = r0->field_b
    //     0xdce0b0: ldur            w1, [x0, #0xb]
    // 0xdce0b4: LoadField: r3 = r0->field_f
    //     0xdce0b4: ldur            w3, [x0, #0xf]
    // 0xdce0b8: DecompressPointer r3
    //     0xdce0b8: add             x3, x3, HEAP, lsl #32
    // 0xdce0bc: LoadField: r4 = r3->field_b
    //     0xdce0bc: ldur            w4, [x3, #0xb]
    // 0xdce0c0: r3 = LoadInt32Instr(r1)
    //     0xdce0c0: sbfx            x3, x1, #1, #0x1f
    // 0xdce0c4: stur            x3, [fp, #-0x68]
    // 0xdce0c8: r1 = LoadInt32Instr(r4)
    //     0xdce0c8: sbfx            x1, x4, #1, #0x1f
    // 0xdce0cc: cmp             x3, x1
    // 0xdce0d0: b.ne            #0xdce0dc
    // 0xdce0d4: mov             x1, x0
    // 0xdce0d8: r0 = _growToNextCapacity()
    //     0xdce0d8: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xdce0dc: ldur            x4, [fp, #-0x10]
    // 0xdce0e0: ldur            x2, [fp, #-0x30]
    // 0xdce0e4: ldur            x3, [fp, #-0x68]
    // 0xdce0e8: add             x0, x3, #1
    // 0xdce0ec: lsl             x1, x0, #1
    // 0xdce0f0: StoreField: r2->field_b = r1
    //     0xdce0f0: stur            w1, [x2, #0xb]
    // 0xdce0f4: LoadField: r1 = r2->field_f
    //     0xdce0f4: ldur            w1, [x2, #0xf]
    // 0xdce0f8: DecompressPointer r1
    //     0xdce0f8: add             x1, x1, HEAP, lsl #32
    // 0xdce0fc: ldur            x0, [fp, #-0x38]
    // 0xdce100: ArrayStore: r1[r3] = r0  ; List_4
    //     0xdce100: add             x25, x1, x3, lsl #2
    //     0xdce104: add             x25, x25, #0xf
    //     0xdce108: str             w0, [x25]
    //     0xdce10c: tbz             w0, #0, #0xdce128
    //     0xdce110: ldurb           w16, [x1, #-1]
    //     0xdce114: ldurb           w17, [x0, #-1]
    //     0xdce118: and             x16, x17, x16, lsr #2
    //     0xdce11c: tst             x16, HEAP, lsr #32
    //     0xdce120: b.eq            #0xdce128
    //     0xdce124: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdce128: LoadField: r0 = r4->field_57
    //     0xdce128: ldur            w0, [x4, #0x57]
    // 0xdce12c: DecompressPointer r0
    //     0xdce12c: add             x0, x0, HEAP, lsl #32
    // 0xdce130: cmp             w0, NULL
    // 0xdce134: b.eq            #0xdce414
    // 0xdce138: LoadField: r1 = r0->field_2f
    //     0xdce138: ldur            w1, [x0, #0x2f]
    // 0xdce13c: DecompressPointer r1
    //     0xdce13c: add             x1, x1, HEAP, lsl #32
    // 0xdce140: cmp             w1, NULL
    // 0xdce144: b.eq            #0xdce20c
    // 0xdce148: LoadField: r0 = r4->field_f
    //     0xdce148: ldur            w0, [x4, #0xf]
    // 0xdce14c: DecompressPointer r0
    //     0xdce14c: add             x0, x0, HEAP, lsl #32
    // 0xdce150: cmp             w0, NULL
    // 0xdce154: b.eq            #0xdce418
    // 0xdce158: stp             x0, x1, [SP]
    // 0xdce15c: mov             x0, x1
    // 0xdce160: ClosureCall
    //     0xdce160: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xdce164: ldur            x2, [x0, #0x1f]
    //     0xdce168: blr             x2
    // 0xdce16c: LoadField: r1 = r0->field_b
    //     0xdce16c: ldur            w1, [x0, #0xb]
    // 0xdce170: cbz             w1, #0xdce208
    // 0xdce174: ldur            x0, [fp, #-0x30]
    // 0xdce178: ldur            x1, [fp, #-0x10]
    // 0xdce17c: ldur            d0, [fp, #-0x78]
    // 0xdce180: r0 = _buildOptionsButton()
    //     0xdce180: bl              #0xdce434  ; [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_buildOptionsButton
    // 0xdce184: mov             x2, x0
    // 0xdce188: ldur            x0, [fp, #-0x30]
    // 0xdce18c: stur            x2, [fp, #-0x10]
    // 0xdce190: LoadField: r1 = r0->field_b
    //     0xdce190: ldur            w1, [x0, #0xb]
    // 0xdce194: LoadField: r3 = r0->field_f
    //     0xdce194: ldur            w3, [x0, #0xf]
    // 0xdce198: DecompressPointer r3
    //     0xdce198: add             x3, x3, HEAP, lsl #32
    // 0xdce19c: LoadField: r4 = r3->field_b
    //     0xdce19c: ldur            w4, [x3, #0xb]
    // 0xdce1a0: r3 = LoadInt32Instr(r1)
    //     0xdce1a0: sbfx            x3, x1, #1, #0x1f
    // 0xdce1a4: stur            x3, [fp, #-0x68]
    // 0xdce1a8: r1 = LoadInt32Instr(r4)
    //     0xdce1a8: sbfx            x1, x4, #1, #0x1f
    // 0xdce1ac: cmp             x3, x1
    // 0xdce1b0: b.ne            #0xdce1bc
    // 0xdce1b4: mov             x1, x0
    // 0xdce1b8: r0 = _growToNextCapacity()
    //     0xdce1b8: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xdce1bc: ldur            x2, [fp, #-0x30]
    // 0xdce1c0: ldur            x3, [fp, #-0x68]
    // 0xdce1c4: add             x0, x3, #1
    // 0xdce1c8: lsl             x1, x0, #1
    // 0xdce1cc: StoreField: r2->field_b = r1
    //     0xdce1cc: stur            w1, [x2, #0xb]
    // 0xdce1d0: LoadField: r1 = r2->field_f
    //     0xdce1d0: ldur            w1, [x2, #0xf]
    // 0xdce1d4: DecompressPointer r1
    //     0xdce1d4: add             x1, x1, HEAP, lsl #32
    // 0xdce1d8: ldur            x0, [fp, #-0x10]
    // 0xdce1dc: ArrayStore: r1[r3] = r0  ; List_4
    //     0xdce1dc: add             x25, x1, x3, lsl #2
    //     0xdce1e0: add             x25, x25, #0xf
    //     0xdce1e4: str             w0, [x25]
    //     0xdce1e8: tbz             w0, #0, #0xdce204
    //     0xdce1ec: ldurb           w16, [x1, #-1]
    //     0xdce1f0: ldurb           w17, [x0, #-1]
    //     0xdce1f4: and             x16, x17, x16, lsr #2
    //     0xdce1f8: tst             x16, HEAP, lsr #32
    //     0xdce1fc: b.eq            #0xdce204
    //     0xdce200: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdce204: b               #0xdce20c
    // 0xdce208: ldur            x2, [fp, #-0x30]
    // 0xdce20c: ldur            d0, [fp, #-0x78]
    // 0xdce210: ldur            d1, [fp, #-0x70]
    // 0xdce214: ldur            x1, [fp, #-0x28]
    // 0xdce218: ldur            x0, [fp, #-0x20]
    // 0xdce21c: ldur            x3, [fp, #-8]
    // 0xdce220: r0 = Row()
    //     0xdce220: bl              #0x8a5b04  ; AllocateRowStub -> Row (size=0x38)
    // 0xdce224: mov             x1, x0
    // 0xdce228: r0 = Instance_Axis
    //     0xdce228: ldr             x0, [PP, #0x49c8]  ; [pp+0x49c8] Obj!Axis@12c4a61
    // 0xdce22c: stur            x1, [fp, #-0x38]
    // 0xdce230: StoreField: r1->field_f = r0
    //     0xdce230: stur            w0, [x1, #0xf]
    // 0xdce234: r0 = Instance_MainAxisAlignment
    //     0xdce234: add             x0, PP, #0x15, lsl #12  ; [pp+0x15820] Obj!MainAxisAlignment@12c4541
    //     0xdce238: ldr             x0, [x0, #0x820]
    // 0xdce23c: StoreField: r1->field_13 = r0
    //     0xdce23c: stur            w0, [x1, #0x13]
    // 0xdce240: r0 = Instance_MainAxisSize
    //     0xdce240: add             x0, PP, #0x15, lsl #12  ; [pp+0x15828] Obj!MainAxisSize@12c4621
    //     0xdce244: ldr             x0, [x0, #0x828]
    // 0xdce248: ArrayStore: r1[0] = r0  ; List_4
    //     0xdce248: stur            w0, [x1, #0x17]
    // 0xdce24c: r0 = Instance_CrossAxisAlignment
    //     0xdce24c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15888] Obj!CrossAxisAlignment@12c44a1
    //     0xdce250: ldr             x0, [x0, #0x888]
    // 0xdce254: StoreField: r1->field_1b = r0
    //     0xdce254: stur            w0, [x1, #0x1b]
    // 0xdce258: r0 = Instance_VerticalDirection
    //     0xdce258: add             x0, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xdce25c: ldr             x0, [x0, #0x838]
    // 0xdce260: StoreField: r1->field_23 = r0
    //     0xdce260: stur            w0, [x1, #0x23]
    // 0xdce264: r0 = Instance_Clip
    //     0xdce264: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xdce268: ldr             x0, [x0, #0x840]
    // 0xdce26c: StoreField: r1->field_2b = r0
    //     0xdce26c: stur            w0, [x1, #0x2b]
    // 0xdce270: StoreField: r1->field_2f = rZR
    //     0xdce270: stur            xzr, [x1, #0x2f]
    // 0xdce274: ldur            x0, [fp, #-0x30]
    // 0xdce278: StoreField: r1->field_b = r0
    //     0xdce278: stur            w0, [x1, #0xb]
    // 0xdce27c: ldur            d0, [fp, #-0x78]
    // 0xdce280: r0 = inline_Allocate_Double()
    //     0xdce280: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xdce284: add             x0, x0, #0x10
    //     0xdce288: cmp             x2, x0
    //     0xdce28c: b.ls            #0xdce41c
    //     0xdce290: str             x0, [THR, #0x60]  ; THR::top
    //     0xdce294: sub             x0, x0, #0xf
    //     0xdce298: mov             x2, #0xe19c
    //     0xdce29c: movk            x2, #3, lsl #16
    //     0xdce2a0: stur            x2, [x0, #-1]
    // 0xdce2a4: dmb             ishst
    // 0xdce2a8: StoreField: r0->field_7 = d0
    //     0xdce2a8: stur            d0, [x0, #7]
    // 0xdce2ac: stur            x0, [fp, #-0x10]
    // 0xdce2b0: r0 = Container()
    //     0xdce2b0: bl              #0x8a5af8  ; AllocateContainerStub -> Container (size=0x38)
    // 0xdce2b4: stur            x0, [fp, #-0x30]
    // 0xdce2b8: ldur            x16, [fp, #-0x10]
    // 0xdce2bc: r30 = Instance_Color
    //     0xdce2bc: add             lr, PP, #0xd4, lsl #12  ; [pp+0xd4000] Obj!Color@12a3c61
    //     0xdce2c0: ldr             lr, [lr]
    // 0xdce2c4: stp             lr, x16, [SP, #8]
    // 0xdce2c8: ldur            x16, [fp, #-0x38]
    // 0xdce2cc: str             x16, [SP]
    // 0xdce2d0: mov             x1, x0
    // 0xdce2d4: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, color, 0x2, height, 0x1, null]
    //     0xdce2d4: add             x4, PP, #0x7b, lsl #12  ; [pp+0x7bcf0] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "color", 0x2, "height", 0x1, Null]
    //     0xdce2d8: ldr             x4, [x4, #0xcf0]
    // 0xdce2dc: r0 = Container()
    //     0xdce2dc: bl              #0x8a54e0  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0xdce2e0: r0 = BackdropFilter()
    //     0xdce2e0: bl              #0x9190e4  ; AllocateBackdropFilterStub -> BackdropFilter (size=0x28)
    // 0xdce2e4: mov             x1, x0
    // 0xdce2e8: ldur            x0, [fp, #-0x20]
    // 0xdce2ec: stur            x1, [fp, #-0x10]
    // 0xdce2f0: StoreField: r1->field_f = r0
    //     0xdce2f0: stur            w0, [x1, #0xf]
    // 0xdce2f4: r0 = Instance_BlendMode
    //     0xdce2f4: add             x0, PP, #0x16, lsl #12  ; [pp+0x16eb8] Obj!BlendMode@12c82e1
    //     0xdce2f8: ldr             x0, [x0, #0xeb8]
    // 0xdce2fc: ArrayStore: r1[0] = r0  ; List_4
    //     0xdce2fc: stur            w0, [x1, #0x17]
    // 0xdce300: r0 = true
    //     0xdce300: add             x0, NULL, #0x20  ; true
    // 0xdce304: StoreField: r1->field_1b = r0
    //     0xdce304: stur            w0, [x1, #0x1b]
    // 0xdce308: r2 = false
    //     0xdce308: add             x2, NULL, #0x30  ; false
    // 0xdce30c: StoreField: r1->field_23 = r2
    //     0xdce30c: stur            w2, [x1, #0x23]
    // 0xdce310: ldur            x3, [fp, #-0x30]
    // 0xdce314: StoreField: r1->field_b = r3
    //     0xdce314: stur            w3, [x1, #0xb]
    // 0xdce318: r0 = ClipRRect()
    //     0xdce318: bl              #0xd30168  ; AllocateClipRRectStub -> ClipRRect (size=0x1c)
    // 0xdce31c: mov             x1, x0
    // 0xdce320: ldur            x0, [fp, #-0x28]
    // 0xdce324: stur            x1, [fp, #-0x20]
    // 0xdce328: StoreField: r1->field_f = r0
    //     0xdce328: stur            w0, [x1, #0xf]
    // 0xdce32c: r0 = Instance_Clip
    //     0xdce32c: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e6f0] Obj!Clip@12c8101
    //     0xdce330: ldr             x0, [x0, #0x6f0]
    // 0xdce334: ArrayStore: r1[0] = r0  ; List_4
    //     0xdce334: stur            w0, [x1, #0x17]
    // 0xdce338: ldur            x0, [fp, #-0x10]
    // 0xdce33c: StoreField: r1->field_b = r0
    //     0xdce33c: stur            w0, [x1, #0xb]
    // 0xdce340: r0 = Container()
    //     0xdce340: bl              #0x8a5af8  ; AllocateContainerStub -> Container (size=0x38)
    // 0xdce344: stur            x0, [fp, #-0x10]
    // 0xdce348: r16 = Instance_Color
    //     0xdce348: add             x16, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xdce34c: ldr             x16, [x16, #0x810]
    // 0xdce350: r30 = Instance_Alignment
    //     0xdce350: add             lr, PP, #0x1e, lsl #12  ; [pp+0x1e1b8] Obj!Alignment@129e6f1
    //     0xdce354: ldr             lr, [lr, #0x1b8]
    // 0xdce358: stp             lr, x16, [SP, #0x10]
    // 0xdce35c: ldur            x16, [fp, #-0x18]
    // 0xdce360: ldur            lr, [fp, #-0x20]
    // 0xdce364: stp             lr, x16, [SP]
    // 0xdce368: mov             x1, x0
    // 0xdce36c: r4 = const [0, 0x5, 0x4, 0x1, alignment, 0x2, child, 0x4, color, 0x1, margin, 0x3, null]
    //     0xdce36c: add             x4, PP, #0xd4, lsl #12  ; [pp+0xd4008] List(13) [0, 0x5, 0x4, 0x1, "alignment", 0x2, "child", 0x4, "color", 0x1, "margin", 0x3, Null]
    //     0xdce370: ldr             x4, [x4, #8]
    // 0xdce374: r0 = Container()
    //     0xdce374: bl              #0x8a54e0  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0xdce378: r0 = AnimatedOpacity()
    //     0xdce378: bl              #0xd2cf50  ; AllocateAnimatedOpacityStub -> AnimatedOpacity (size=0x28)
    // 0xdce37c: mov             x1, x0
    // 0xdce380: ldur            x0, [fp, #-0x10]
    // 0xdce384: stur            x1, [fp, #-0x18]
    // 0xdce388: ArrayStore: r1[0] = r0  ; List_4
    //     0xdce388: stur            w0, [x1, #0x17]
    // 0xdce38c: ldur            d0, [fp, #-0x70]
    // 0xdce390: StoreField: r1->field_1b = d0
    //     0xdce390: stur            d0, [x1, #0x1b]
    // 0xdce394: r0 = false
    //     0xdce394: add             x0, NULL, #0x30  ; false
    // 0xdce398: StoreField: r1->field_23 = r0
    //     0xdce398: stur            w0, [x1, #0x23]
    // 0xdce39c: r2 = Instance__Linear
    //     0xdce39c: ldr             x2, [PP, #0x5168]  ; [pp+0x5168] Obj!_Linear@129fef1
    // 0xdce3a0: StoreField: r1->field_b = r2
    //     0xdce3a0: stur            w2, [x1, #0xb]
    // 0xdce3a4: r2 = Instance_Duration
    //     0xdce3a4: ldr             x2, [PP, #0x7cd8]  ; [pp+0x7cd8] Obj!Duration@12c8971
    // 0xdce3a8: StoreField: r1->field_f = r2
    //     0xdce3a8: stur            w2, [x1, #0xf]
    // 0xdce3ac: r0 = SafeArea()
    //     0xdce3ac: bl              #0xd73100  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0xdce3b0: r1 = true
    //     0xdce3b0: add             x1, NULL, #0x20  ; true
    // 0xdce3b4: StoreField: r0->field_b = r1
    //     0xdce3b4: stur            w1, [x0, #0xb]
    // 0xdce3b8: StoreField: r0->field_f = r1
    //     0xdce3b8: stur            w1, [x0, #0xf]
    // 0xdce3bc: StoreField: r0->field_13 = r1
    //     0xdce3bc: stur            w1, [x0, #0x13]
    // 0xdce3c0: ldur            x1, [fp, #-8]
    // 0xdce3c4: ArrayStore: r0[0] = r1  ; List_4
    //     0xdce3c4: stur            w1, [x0, #0x17]
    // 0xdce3c8: r1 = Instance_EdgeInsets
    //     0xdce3c8: ldr             x1, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0xdce3cc: StoreField: r0->field_1b = r1
    //     0xdce3cc: stur            w1, [x0, #0x1b]
    // 0xdce3d0: r1 = false
    //     0xdce3d0: add             x1, NULL, #0x30  ; false
    // 0xdce3d4: StoreField: r0->field_1f = r1
    //     0xdce3d4: stur            w1, [x0, #0x1f]
    // 0xdce3d8: ldur            x1, [fp, #-0x18]
    // 0xdce3dc: StoreField: r0->field_23 = r1
    //     0xdce3dc: stur            w1, [x0, #0x23]
    // 0xdce3e0: LeaveFrame
    //     0xdce3e0: mov             SP, fp
    //     0xdce3e4: ldp             fp, lr, [SP], #0x10
    // 0xdce3e8: ret
    //     0xdce3e8: ret             
    // 0xdce3ec: r0 = StackOverflowSharedWithFPURegs()
    //     0xdce3ec: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xdce3f0: b               #0xdcded8
    // 0xdce3f4: r0 = NullCastErrorSharedWithFPURegs()
    //     0xdce3f4: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xdce3f8: r9 = notifier
    //     0xdce3f8: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3fb0] Field <_CupertinoControlsState@450205881.notifier>: late (offset: 0x1c)
    //     0xdce3fc: ldr             x9, [x9, #0xfb0]
    // 0xdce400: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xdce400: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xdce404: r9 = controller
    //     0xdce404: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3fa0] Field <_CupertinoControlsState@450205881.controller>: late (offset: 0x54)
    //     0xdce408: ldr             x9, [x9, #0xfa0]
    // 0xdce40c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdce40c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdce410: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdce410: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdce414: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdce414: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdce418: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdce418: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdce41c: SaveReg d0
    //     0xdce41c: str             q0, [SP, #-0x10]!
    // 0xdce420: SaveReg r1
    //     0xdce420: str             x1, [SP, #-8]!
    // 0xdce424: r0 = AllocateDouble()
    //     0xdce424: bl              #0x13df878  ; AllocateDoubleStub
    // 0xdce428: RestoreReg r1
    //     0xdce428: ldr             x1, [SP], #8
    // 0xdce42c: RestoreReg d0
    //     0xdce42c: ldr             q0, [SP], #0x10
    // 0xdce430: b               #0xdce2a8
  }
  _ _buildOptionsButton(/* No info */) {
    // ** addr: 0xdce434, size: 0x234
    // 0xdce434: EnterFrame
    //     0xdce434: stp             fp, lr, [SP, #-0x10]!
    //     0xdce438: mov             fp, SP
    // 0xdce43c: AllocStack(0x50)
    //     0xdce43c: sub             SP, SP, #0x50
    // 0xdce440: SetupParameters(_CupertinoControlsState this /* r1 => r1, fp-0x8 */, dynamic _ /* d0 => d0, fp-0x28 */)
    //     0xdce440: stur            x1, [fp, #-8]
    //     0xdce444: stur            d0, [fp, #-0x28]
    // 0xdce448: CheckStackOverflow
    //     0xdce448: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdce44c: cmp             SP, x16
    //     0xdce450: b.ls            #0xdce634
    // 0xdce454: r1 = 2
    //     0xdce454: mov             x1, #2
    // 0xdce458: r0 = AllocateContext()
    //     0xdce458: bl              #0x13de838  ; AllocateContextStub
    // 0xdce45c: mov             x3, x0
    // 0xdce460: ldur            x0, [fp, #-8]
    // 0xdce464: stur            x3, [fp, #-0x10]
    // 0xdce468: StoreField: r3->field_f = r0
    //     0xdce468: stur            w0, [x3, #0xf]
    // 0xdce46c: r1 = <OptionItem>
    //     0xdce46c: add             x1, PP, #0xcf, lsl #12  ; [pp+0xcf380] TypeArguments: <OptionItem>
    //     0xdce470: ldr             x1, [x1, #0x380]
    // 0xdce474: r2 = 0
    //     0xdce474: mov             x2, #0
    // 0xdce478: r0 = _GrowableList()
    //     0xdce478: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xdce47c: mov             x1, x0
    // 0xdce480: ldur            x2, [fp, #-0x10]
    // 0xdce484: stur            x1, [fp, #-0x18]
    // 0xdce488: StoreField: r2->field_13 = r0
    //     0xdce488: stur            w0, [x2, #0x13]
    //     0xdce48c: ldurb           w16, [x2, #-1]
    //     0xdce490: ldurb           w17, [x0, #-1]
    //     0xdce494: and             x16, x17, x16, lsr #2
    //     0xdce498: tst             x16, HEAP, lsr #32
    //     0xdce49c: b.eq            #0xdce4a4
    //     0xdce4a0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xdce4a4: ldur            x3, [fp, #-8]
    // 0xdce4a8: LoadField: r0 = r3->field_57
    //     0xdce4a8: ldur            w0, [x3, #0x57]
    // 0xdce4ac: DecompressPointer r0
    //     0xdce4ac: add             x0, x0, HEAP, lsl #32
    // 0xdce4b0: cmp             w0, NULL
    // 0xdce4b4: b.eq            #0xdce63c
    // 0xdce4b8: LoadField: r4 = r0->field_2f
    //     0xdce4b8: ldur            w4, [x0, #0x2f]
    // 0xdce4bc: DecompressPointer r4
    //     0xdce4bc: add             x4, x4, HEAP, lsl #32
    // 0xdce4c0: cmp             w4, NULL
    // 0xdce4c4: b.eq            #0xdce548
    // 0xdce4c8: LoadField: r0 = r3->field_f
    //     0xdce4c8: ldur            w0, [x3, #0xf]
    // 0xdce4cc: DecompressPointer r0
    //     0xdce4cc: add             x0, x0, HEAP, lsl #32
    // 0xdce4d0: cmp             w0, NULL
    // 0xdce4d4: b.eq            #0xdce640
    // 0xdce4d8: stp             x0, x4, [SP]
    // 0xdce4dc: mov             x0, x4
    // 0xdce4e0: ClosureCall
    //     0xdce4e0: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xdce4e4: ldur            x2, [x0, #0x1f]
    //     0xdce4e8: blr             x2
    // 0xdce4ec: LoadField: r1 = r0->field_b
    //     0xdce4ec: ldur            w1, [x0, #0xb]
    // 0xdce4f0: cbz             w1, #0xdce548
    // 0xdce4f4: ldur            x0, [fp, #-8]
    // 0xdce4f8: LoadField: r1 = r0->field_57
    //     0xdce4f8: ldur            w1, [x0, #0x57]
    // 0xdce4fc: DecompressPointer r1
    //     0xdce4fc: add             x1, x1, HEAP, lsl #32
    // 0xdce500: cmp             w1, NULL
    // 0xdce504: b.eq            #0xdce644
    // 0xdce508: LoadField: r2 = r1->field_2f
    //     0xdce508: ldur            w2, [x1, #0x2f]
    // 0xdce50c: DecompressPointer r2
    //     0xdce50c: add             x2, x2, HEAP, lsl #32
    // 0xdce510: cmp             w2, NULL
    // 0xdce514: b.eq            #0xdce648
    // 0xdce518: LoadField: r1 = r0->field_f
    //     0xdce518: ldur            w1, [x0, #0xf]
    // 0xdce51c: DecompressPointer r1
    //     0xdce51c: add             x1, x1, HEAP, lsl #32
    // 0xdce520: cmp             w1, NULL
    // 0xdce524: b.eq            #0xdce64c
    // 0xdce528: stp             x1, x2, [SP]
    // 0xdce52c: mov             x0, x2
    // 0xdce530: ClosureCall
    //     0xdce530: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xdce534: ldur            x2, [x0, #0x1f]
    //     0xdce538: blr             x2
    // 0xdce53c: ldur            x1, [fp, #-0x18]
    // 0xdce540: mov             x2, x0
    // 0xdce544: r0 = addAll()
    //     0xdce544: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0xdce548: ldur            d0, [fp, #-0x28]
    // 0xdce54c: r0 = Icon()
    //     0xdce54c: bl              #0xd0fd5c  ; AllocateIconStub -> Icon (size=0x40)
    // 0xdce550: mov             x1, x0
    // 0xdce554: r0 = Instance_IconData
    //     0xdce554: add             x0, PP, #0x21, lsl #12  ; [pp+0x21ec8] Obj!IconData@128a2b1
    //     0xdce558: ldr             x0, [x0, #0xec8]
    // 0xdce55c: stur            x1, [fp, #-0x18]
    // 0xdce560: StoreField: r1->field_b = r0
    //     0xdce560: stur            w0, [x1, #0xb]
    // 0xdce564: r0 = 18.000000
    //     0xdce564: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e530] 18
    //     0xdce568: ldr             x0, [x0, #0x530]
    // 0xdce56c: StoreField: r1->field_f = r0
    //     0xdce56c: stur            w0, [x1, #0xf]
    // 0xdce570: r0 = Instance_Color
    //     0xdce570: add             x0, PP, #0xd4, lsl #12  ; [pp+0xd4010] Obj!Color@12a3ba1
    //     0xdce574: ldr             x0, [x0, #0x10]
    // 0xdce578: StoreField: r1->field_23 = r0
    //     0xdce578: stur            w0, [x1, #0x23]
    // 0xdce57c: ldur            d0, [fp, #-0x28]
    // 0xdce580: r0 = inline_Allocate_Double()
    //     0xdce580: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xdce584: add             x0, x0, #0x10
    //     0xdce588: cmp             x2, x0
    //     0xdce58c: b.ls            #0xdce650
    //     0xdce590: str             x0, [THR, #0x60]  ; THR::top
    //     0xdce594: sub             x0, x0, #0xf
    //     0xdce598: mov             x2, #0xe19c
    //     0xdce59c: movk            x2, #3, lsl #16
    //     0xdce5a0: stur            x2, [x0, #-1]
    // 0xdce5a4: dmb             ishst
    // 0xdce5a8: StoreField: r0->field_7 = d0
    //     0xdce5a8: stur            d0, [x0, #7]
    // 0xdce5ac: stur            x0, [fp, #-8]
    // 0xdce5b0: r0 = Container()
    //     0xdce5b0: bl              #0x8a5af8  ; AllocateContainerStub -> Container (size=0x38)
    // 0xdce5b4: stur            x0, [fp, #-0x20]
    // 0xdce5b8: ldur            x16, [fp, #-8]
    // 0xdce5bc: r30 = Instance_Color
    //     0xdce5bc: add             lr, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xdce5c0: ldr             lr, [lr, #0x810]
    // 0xdce5c4: stp             lr, x16, [SP, #0x18]
    // 0xdce5c8: r16 = Instance_EdgeInsets
    //     0xdce5c8: add             x16, PP, #0xd4, lsl #12  ; [pp+0xd4018] Obj!EdgeInsets@129d2c1
    //     0xdce5cc: ldr             x16, [x16, #0x18]
    // 0xdce5d0: r30 = Instance_EdgeInsets
    //     0xdce5d0: add             lr, PP, #0xd4, lsl #12  ; [pp+0xd4020] Obj!EdgeInsets@129d291
    //     0xdce5d4: ldr             lr, [lr, #0x20]
    // 0xdce5d8: stp             lr, x16, [SP, #8]
    // 0xdce5dc: ldur            x16, [fp, #-0x18]
    // 0xdce5e0: str             x16, [SP]
    // 0xdce5e4: mov             x1, x0
    // 0xdce5e8: r4 = const [0, 0x6, 0x5, 0x1, child, 0x5, color, 0x2, height, 0x1, margin, 0x4, padding, 0x3, null]
    //     0xdce5e8: add             x4, PP, #0xd4, lsl #12  ; [pp+0xd4028] List(15) [0, 0x6, 0x5, 0x1, "child", 0x5, "color", 0x2, "height", 0x1, "margin", 0x4, "padding", 0x3, Null]
    //     0xdce5ec: ldr             x4, [x4, #0x28]
    // 0xdce5f0: r0 = Container()
    //     0xdce5f0: bl              #0x8a54e0  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0xdce5f4: r0 = GestureDetector()
    //     0xdce5f4: bl              #0x918e18  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0xdce5f8: ldur            x2, [fp, #-0x10]
    // 0xdce5fc: r1 = Function '<anonymous closure>':.
    //     0xdce5fc: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4030] AnonymousClosure: (0xdce668), in [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_buildOptionsButton (0xdce434)
    //     0xdce600: ldr             x1, [x1, #0x30]
    // 0xdce604: stur            x0, [fp, #-8]
    // 0xdce608: r0 = AllocateClosure()
    //     0xdce608: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdce60c: ldur            x16, [fp, #-0x20]
    // 0xdce610: stp             x16, x0, [SP]
    // 0xdce614: ldur            x1, [fp, #-8]
    // 0xdce618: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0xdce618: add             x4, PP, #0x16, lsl #12  ; [pp+0x16e90] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0xdce61c: ldr             x4, [x4, #0xe90]
    // 0xdce620: r0 = GestureDetector()
    //     0xdce620: bl              #0x9182dc  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0xdce624: ldur            x0, [fp, #-8]
    // 0xdce628: LeaveFrame
    //     0xdce628: mov             SP, fp
    //     0xdce62c: ldp             fp, lr, [SP], #0x10
    // 0xdce630: ret
    //     0xdce630: ret             
    // 0xdce634: r0 = StackOverflowSharedWithFPURegs()
    //     0xdce634: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xdce638: b               #0xdce454
    // 0xdce63c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdce63c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdce640: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdce640: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdce644: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdce644: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdce648: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdce648: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdce64c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdce64c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdce650: SaveReg d0
    //     0xdce650: str             q0, [SP, #-0x10]!
    // 0xdce654: SaveReg r1
    //     0xdce654: str             x1, [SP, #-8]!
    // 0xdce658: r0 = AllocateDouble()
    //     0xdce658: bl              #0x13df878  ; AllocateDoubleStub
    // 0xdce65c: RestoreReg r1
    //     0xdce65c: ldr             x1, [SP], #8
    // 0xdce660: RestoreReg d0
    //     0xdce660: ldr             q0, [SP], #0x10
    // 0xdce664: b               #0xdce5a8
  }
  [closure] Future<void> <anonymous closure>(dynamic) async {
    // ** addr: 0xdce668, size: 0x128
    // 0xdce668: EnterFrame
    //     0xdce668: stp             fp, lr, [SP, #-0x10]!
    //     0xdce66c: mov             fp, SP
    // 0xdce670: AllocStack(0x38)
    //     0xdce670: sub             SP, SP, #0x38
    // 0xdce674: SetupParameters(_CupertinoControlsState this /* r1 */)
    //     0xdce674: stur            NULL, [fp, #-8]
    //     0xdce678: mov             x0, #0
    //     0xdce67c: add             x1, fp, w0, sxtw #2
    //     0xdce680: ldr             x1, [x1, #0x10]
    //     0xdce684: ldur            w2, [x1, #0x17]
    //     0xdce688: add             x2, x2, HEAP, lsl #32
    //     0xdce68c: stur            x2, [fp, #-0x10]
    // 0xdce690: CheckStackOverflow
    //     0xdce690: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdce694: cmp             SP, x16
    //     0xdce698: b.ls            #0xdce774
    // 0xdce69c: InitAsync() -> Future<void?>
    //     0xdce69c: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0xdce6a0: bl              #0x7f5e44  ; InitAsyncStub
    // 0xdce6a4: ldur            x2, [fp, #-0x10]
    // 0xdce6a8: LoadField: r0 = r2->field_f
    //     0xdce6a8: ldur            w0, [x2, #0xf]
    // 0xdce6ac: DecompressPointer r0
    //     0xdce6ac: add             x0, x0, HEAP, lsl #32
    // 0xdce6b0: LoadField: r1 = r0->field_27
    //     0xdce6b0: ldur            w1, [x0, #0x27]
    // 0xdce6b4: DecompressPointer r1
    //     0xdce6b4: add             x1, x1, HEAP, lsl #32
    // 0xdce6b8: cmp             w1, NULL
    // 0xdce6bc: b.ne            #0xdce6c8
    // 0xdce6c0: mov             x0, x2
    // 0xdce6c4: b               #0xdce6d0
    // 0xdce6c8: r0 = cancel()
    //     0xdce6c8: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0xdce6cc: ldur            x0, [fp, #-0x10]
    // 0xdce6d0: LoadField: r1 = r0->field_f
    //     0xdce6d0: ldur            w1, [x0, #0xf]
    // 0xdce6d4: DecompressPointer r1
    //     0xdce6d4: add             x1, x1, HEAP, lsl #32
    // 0xdce6d8: LoadField: r2 = r1->field_57
    //     0xdce6d8: ldur            w2, [x1, #0x57]
    // 0xdce6dc: DecompressPointer r2
    //     0xdce6dc: add             x2, x2, HEAP, lsl #32
    // 0xdce6e0: cmp             w2, NULL
    // 0xdce6e4: b.eq            #0xdce77c
    // 0xdce6e8: LoadField: r3 = r1->field_f
    //     0xdce6e8: ldur            w3, [x1, #0xf]
    // 0xdce6ec: DecompressPointer r3
    //     0xdce6ec: add             x3, x3, HEAP, lsl #32
    // 0xdce6f0: stur            x3, [fp, #-0x18]
    // 0xdce6f4: cmp             w3, NULL
    // 0xdce6f8: b.eq            #0xdce780
    // 0xdce6fc: mov             x2, x0
    // 0xdce700: r1 = Function '<anonymous closure>':.
    //     0xdce700: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4038] AnonymousClosure: (0xdceae8), in [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_buildOptionsButton (0xdce434)
    //     0xdce704: ldr             x1, [x1, #0x38]
    // 0xdce708: r0 = AllocateClosure()
    //     0xdce708: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdce70c: r16 = <OptionItem>
    //     0xdce70c: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf380] TypeArguments: <OptionItem>
    //     0xdce710: ldr             x16, [x16, #0x380]
    // 0xdce714: stp             x0, x16, [SP, #0x10]
    // 0xdce718: ldur            x16, [fp, #-0x18]
    // 0xdce71c: r30 = true
    //     0xdce71c: add             lr, NULL, #0x20  ; true
    // 0xdce720: stp             lr, x16, [SP]
    // 0xdce724: r4 = const [0x1, 0x3, 0x3, 0x2, semanticsDismissible, 0x2, null]
    //     0xdce724: add             x4, PP, #0xd4, lsl #12  ; [pp+0xd4040] List(7) [0x1, 0x3, 0x3, 0x2, "semanticsDismissible", 0x2, Null]
    //     0xdce728: ldr             x4, [x4, #0x40]
    // 0xdce72c: r0 = showCupertinoModalPopup()
    //     0xdce72c: bl              #0xdce924  ; [package:flutter/src/cupertino/route.dart] ::showCupertinoModalPopup
    // 0xdce730: mov             x1, x0
    // 0xdce734: stur            x1, [fp, #-0x18]
    // 0xdce738: r0 = Await()
    //     0xdce738: bl              #0x7f5c00  ; AwaitStub
    // 0xdce73c: ldur            x0, [fp, #-0x10]
    // 0xdce740: LoadField: r1 = r0->field_f
    //     0xdce740: ldur            w1, [x0, #0xf]
    // 0xdce744: DecompressPointer r1
    //     0xdce744: add             x1, x1, HEAP, lsl #32
    // 0xdce748: LoadField: r0 = r1->field_1f
    //     0xdce748: ldur            w0, [x1, #0x1f]
    // 0xdce74c: DecompressPointer r0
    //     0xdce74c: add             x0, x0, HEAP, lsl #32
    // 0xdce750: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdce754: cmp             w0, w16
    // 0xdce758: b.eq            #0xdce784
    // 0xdce75c: LoadField: r2 = r0->field_1b
    //     0xdce75c: ldur            w2, [x0, #0x1b]
    // 0xdce760: DecompressPointer r2
    //     0xdce760: add             x2, x2, HEAP, lsl #32
    // 0xdce764: tbnz            w2, #4, #0xdce76c
    // 0xdce768: r0 = _startHideTimer()
    //     0xdce768: bl              #0xdce790  ; [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_startHideTimer
    // 0xdce76c: r0 = Null
    //     0xdce76c: mov             x0, NULL
    // 0xdce770: r0 = ReturnAsyncNotFuture()
    //     0xdce770: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xdce774: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdce774: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdce778: b               #0xdce69c
    // 0xdce77c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdce77c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdce780: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdce780: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdce784: r9 = _latestValue
    //     0xdce784: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3ff0] Field <_CupertinoControlsState@450205881._latestValue@450205881>: late (offset: 0x20)
    //     0xdce788: ldr             x9, [x9, #0xff0]
    // 0xdce78c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdce78c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _startHideTimer(/* No info */) {
    // ** addr: 0xdce790, size: 0xa0
    // 0xdce790: EnterFrame
    //     0xdce790: stp             fp, lr, [SP, #-0x10]!
    //     0xdce794: mov             fp, SP
    // 0xdce798: AllocStack(0x8)
    //     0xdce798: sub             SP, SP, #8
    // 0xdce79c: SetupParameters(_CupertinoControlsState this /* r1 => r1, fp-0x8 */)
    //     0xdce79c: stur            x1, [fp, #-8]
    // 0xdce7a0: CheckStackOverflow
    //     0xdce7a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdce7a4: cmp             SP, x16
    //     0xdce7a8: b.ls            #0xdce824
    // 0xdce7ac: r1 = 1
    //     0xdce7ac: mov             x1, #1
    // 0xdce7b0: r0 = AllocateContext()
    //     0xdce7b0: bl              #0x13de838  ; AllocateContextStub
    // 0xdce7b4: mov             x1, x0
    // 0xdce7b8: ldur            x0, [fp, #-8]
    // 0xdce7bc: StoreField: r1->field_f = r0
    //     0xdce7bc: stur            w0, [x1, #0xf]
    // 0xdce7c0: LoadField: r2 = r0->field_57
    //     0xdce7c0: ldur            w2, [x0, #0x57]
    // 0xdce7c4: DecompressPointer r2
    //     0xdce7c4: add             x2, x2, HEAP, lsl #32
    // 0xdce7c8: cmp             w2, NULL
    // 0xdce7cc: b.eq            #0xdce82c
    // 0xdce7d0: mov             x2, x1
    // 0xdce7d4: r1 = Function '<anonymous closure>':.
    //     0xdce7d4: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3fb8] AnonymousClosure: (0xdce830), in [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_startHideTimer (0xdce790)
    //     0xdce7d8: ldr             x1, [x1, #0xfb8]
    // 0xdce7dc: r0 = AllocateClosure()
    //     0xdce7dc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdce7e0: mov             x3, x0
    // 0xdce7e4: r1 = Null
    //     0xdce7e4: mov             x1, NULL
    // 0xdce7e8: r2 = Instance_Duration
    //     0xdce7e8: add             x2, PP, #0x16, lsl #12  ; [pp+0x16670] Obj!Duration@12c8961
    //     0xdce7ec: ldr             x2, [x2, #0x670]
    // 0xdce7f0: r0 = Timer()
    //     0xdce7f0: bl              #0x7eed74  ; [dart:async] Timer::Timer
    // 0xdce7f4: ldur            x1, [fp, #-8]
    // 0xdce7f8: StoreField: r1->field_27 = r0
    //     0xdce7f8: stur            w0, [x1, #0x27]
    //     0xdce7fc: ldurb           w16, [x1, #-1]
    //     0xdce800: ldurb           w17, [x0, #-1]
    //     0xdce804: and             x16, x17, x16, lsr #2
    //     0xdce808: tst             x16, HEAP, lsr #32
    //     0xdce80c: b.eq            #0xdce814
    //     0xdce810: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdce814: r0 = Null
    //     0xdce814: mov             x0, NULL
    // 0xdce818: LeaveFrame
    //     0xdce818: mov             SP, fp
    //     0xdce81c: ldp             fp, lr, [SP], #0x10
    // 0xdce820: ret
    //     0xdce820: ret             
    // 0xdce824: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdce824: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdce828: b               #0xdce7ac
    // 0xdce82c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdce82c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xdce830, size: 0x60
    // 0xdce830: EnterFrame
    //     0xdce830: stp             fp, lr, [SP, #-0x10]!
    //     0xdce834: mov             fp, SP
    // 0xdce838: AllocStack(0x8)
    //     0xdce838: sub             SP, SP, #8
    // 0xdce83c: SetupParameters([dynamic _ /* r0 */])
    //     0xdce83c: ldr             x0, [fp, #0x10]
    //     0xdce840: ldur            w2, [x0, #0x17]
    //     0xdce844: add             x2, x2, HEAP, lsl #32
    // 0xdce848: CheckStackOverflow
    //     0xdce848: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdce84c: cmp             SP, x16
    //     0xdce850: b.ls            #0xdce888
    // 0xdce854: LoadField: r0 = r2->field_f
    //     0xdce854: ldur            w0, [x2, #0xf]
    // 0xdce858: DecompressPointer r0
    //     0xdce858: add             x0, x0, HEAP, lsl #32
    // 0xdce85c: stur            x0, [fp, #-8]
    // 0xdce860: r1 = Function '<anonymous closure>':.
    //     0xdce860: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3fc0] AnonymousClosure: (0xdce890), in [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_startHideTimer (0xdce790)
    //     0xdce864: ldr             x1, [x1, #0xfc0]
    // 0xdce868: r0 = AllocateClosure()
    //     0xdce868: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdce86c: ldur            x1, [fp, #-8]
    // 0xdce870: mov             x2, x0
    // 0xdce874: r0 = setState()
    //     0xdce874: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xdce878: r0 = Null
    //     0xdce878: mov             x0, NULL
    // 0xdce87c: LeaveFrame
    //     0xdce87c: mov             SP, fp
    //     0xdce880: ldp             fp, lr, [SP], #0x10
    // 0xdce884: ret
    //     0xdce884: ret             
    // 0xdce888: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdce888: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdce88c: b               #0xdce854
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xdce890, size: 0x70
    // 0xdce890: EnterFrame
    //     0xdce890: stp             fp, lr, [SP, #-0x10]!
    //     0xdce894: mov             fp, SP
    // 0xdce898: r0 = true
    //     0xdce898: add             x0, NULL, #0x20  ; true
    // 0xdce89c: ldr             x1, [fp, #0x10]
    // 0xdce8a0: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xdce8a0: ldur            w2, [x1, #0x17]
    // 0xdce8a4: DecompressPointer r2
    //     0xdce8a4: add             x2, x2, HEAP, lsl #32
    // 0xdce8a8: CheckStackOverflow
    //     0xdce8a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdce8ac: cmp             SP, x16
    //     0xdce8b0: b.ls            #0xdce8ec
    // 0xdce8b4: LoadField: r1 = r2->field_f
    //     0xdce8b4: ldur            w1, [x2, #0xf]
    // 0xdce8b8: DecompressPointer r1
    //     0xdce8b8: add             x1, x1, HEAP, lsl #32
    // 0xdce8bc: LoadField: r2 = r1->field_1b
    //     0xdce8bc: ldur            w2, [x1, #0x1b]
    // 0xdce8c0: DecompressPointer r2
    //     0xdce8c0: add             x2, x2, HEAP, lsl #32
    // 0xdce8c4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdce8c8: cmp             w2, w16
    // 0xdce8cc: b.eq            #0xdce8f4
    // 0xdce8d0: StoreField: r2->field_23 = r0
    //     0xdce8d0: stur            w0, [x2, #0x23]
    // 0xdce8d4: mov             x1, x2
    // 0xdce8d8: r0 = notifyListeners()
    //     0xdce8d8: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xdce8dc: r0 = Null
    //     0xdce8dc: mov             x0, NULL
    // 0xdce8e0: LeaveFrame
    //     0xdce8e0: mov             SP, fp
    //     0xdce8e4: ldp             fp, lr, [SP], #0x10
    // 0xdce8e8: ret
    //     0xdce8e8: ret             
    // 0xdce8ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdce8ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdce8f0: b               #0xdce8b4
    // 0xdce8f4: r9 = notifier
    //     0xdce8f4: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3fb0] Field <_CupertinoControlsState@450205881.notifier>: late (offset: 0x1c)
    //     0xdce8f8: ldr             x9, [x9, #0xfb0]
    // 0xdce8fc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdce8fc: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] CupertinoOptionsDialog <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0xdceae8, size: 0x58
    // 0xdceae8: EnterFrame
    //     0xdceae8: stp             fp, lr, [SP, #-0x10]!
    //     0xdceaec: mov             fp, SP
    // 0xdceaf0: AllocStack(0x8)
    //     0xdceaf0: sub             SP, SP, #8
    // 0xdceaf4: SetupParameters([dynamic _ /* r0 */])
    //     0xdceaf4: ldr             x0, [fp, #0x18]
    //     0xdceaf8: ldur            w1, [x0, #0x17]
    //     0xdceafc: add             x1, x1, HEAP, lsl #32
    // 0xdceb00: LoadField: r0 = r1->field_f
    //     0xdceb00: ldur            w0, [x1, #0xf]
    // 0xdceb04: DecompressPointer r0
    //     0xdceb04: add             x0, x0, HEAP, lsl #32
    // 0xdceb08: LoadField: r2 = r0->field_57
    //     0xdceb08: ldur            w2, [x0, #0x57]
    // 0xdceb0c: DecompressPointer r2
    //     0xdceb0c: add             x2, x2, HEAP, lsl #32
    // 0xdceb10: cmp             w2, NULL
    // 0xdceb14: b.eq            #0xdceb3c
    // 0xdceb18: LoadField: r0 = r1->field_13
    //     0xdceb18: ldur            w0, [x1, #0x13]
    // 0xdceb1c: DecompressPointer r0
    //     0xdceb1c: add             x0, x0, HEAP, lsl #32
    // 0xdceb20: stur            x0, [fp, #-8]
    // 0xdceb24: r0 = CupertinoOptionsDialog()
    //     0xdceb24: bl              #0xdceb40  ; AllocateCupertinoOptionsDialogStub -> CupertinoOptionsDialog (size=0x14)
    // 0xdceb28: ldur            x1, [fp, #-8]
    // 0xdceb2c: StoreField: r0->field_b = r1
    //     0xdceb2c: stur            w1, [x0, #0xb]
    // 0xdceb30: LeaveFrame
    //     0xdceb30: mov             SP, fp
    //     0xdceb34: ldp             fp, lr, [SP], #0x10
    // 0xdceb38: ret
    //     0xdceb38: ret             
    // 0xdceb3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdceb3c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _buildSpeedButton(/* No info */) {
    // ** addr: 0xdceb90, size: 0x1a8
    // 0xdceb90: EnterFrame
    //     0xdceb90: stp             fp, lr, [SP, #-0x10]!
    //     0xdceb94: mov             fp, SP
    // 0xdceb98: AllocStack(0x50)
    //     0xdceb98: sub             SP, SP, #0x50
    // 0xdceb9c: SetupParameters(_CupertinoControlsState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* d0 => d0, fp-0x28 */)
    //     0xdceb9c: stur            x1, [fp, #-8]
    //     0xdceba0: stur            x2, [fp, #-0x10]
    //     0xdceba4: stur            d0, [fp, #-0x28]
    // 0xdceba8: CheckStackOverflow
    //     0xdceba8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdcebac: cmp             SP, x16
    //     0xdcebb0: b.ls            #0xdced18
    // 0xdcebb4: r1 = 2
    //     0xdcebb4: mov             x1, #2
    // 0xdcebb8: r0 = AllocateContext()
    //     0xdcebb8: bl              #0x13de838  ; AllocateContextStub
    // 0xdcebbc: mov             x2, x0
    // 0xdcebc0: ldur            x0, [fp, #-8]
    // 0xdcebc4: stur            x2, [fp, #-0x18]
    // 0xdcebc8: StoreField: r2->field_f = r0
    //     0xdcebc8: stur            w0, [x2, #0xf]
    // 0xdcebcc: ldur            x0, [fp, #-0x10]
    // 0xdcebd0: StoreField: r2->field_13 = r0
    //     0xdcebd0: stur            w0, [x2, #0x13]
    // 0xdcebd4: r1 = Null
    //     0xdcebd4: mov             x1, NULL
    // 0xdcebd8: r0 = Matrix4.skewY()
    //     0xdcebd8: bl              #0xdceef0  ; [package:vector_math/vector_math_64.dart] Matrix4::Matrix4.skewY
    // 0xdcebdc: mov             x1, x0
    // 0xdcebe0: d0 = 3.141593
    //     0xdcebe0: add             x17, PP, #0x13, lsl #12  ; [pp+0x13178] IMM: double(3.141592653589793) from 0x400921fb54442d18
    //     0xdcebe4: ldr             d0, [x17, #0x178]
    // 0xdcebe8: stur            x0, [fp, #-8]
    // 0xdcebec: r0 = rotateX()
    //     0xdcebec: bl              #0xdced38  ; [package:vector_math/vector_math_64.dart] Matrix4::rotateX
    // 0xdcebf0: ldur            x1, [fp, #-8]
    // 0xdcebf4: d0 = 2.513274
    //     0xdcebf4: add             x17, PP, #0xd4, lsl #12  ; [pp+0xd4048] IMM: double(2.5132741228718345) from 0x40041b2f769cf0e0
    //     0xdcebf8: ldr             d0, [x17, #0x48]
    // 0xdcebfc: r0 = rotateZ()
    //     0xdcebfc: bl              #0xb75838  ; [package:vector_math/vector_math_64.dart] Matrix4::rotateZ
    // 0xdcec00: r0 = Icon()
    //     0xdcec00: bl              #0xd0fd5c  ; AllocateIconStub -> Icon (size=0x40)
    // 0xdcec04: mov             x1, x0
    // 0xdcec08: r0 = Instance_IconData
    //     0xdcec08: add             x0, PP, #0xd3, lsl #12  ; [pp+0xd3db8] Obj!IconData@128a631
    //     0xdcec0c: ldr             x0, [x0, #0xdb8]
    // 0xdcec10: stur            x1, [fp, #-0x10]
    // 0xdcec14: StoreField: r1->field_b = r0
    //     0xdcec14: stur            w0, [x1, #0xb]
    // 0xdcec18: r0 = 18.000000
    //     0xdcec18: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e530] 18
    //     0xdcec1c: ldr             x0, [x0, #0x530]
    // 0xdcec20: StoreField: r1->field_f = r0
    //     0xdcec20: stur            w0, [x1, #0xf]
    // 0xdcec24: r0 = Instance_Color
    //     0xdcec24: add             x0, PP, #0xd4, lsl #12  ; [pp+0xd4010] Obj!Color@12a3ba1
    //     0xdcec28: ldr             x0, [x0, #0x10]
    // 0xdcec2c: StoreField: r1->field_23 = r0
    //     0xdcec2c: stur            w0, [x1, #0x23]
    // 0xdcec30: r0 = Transform()
    //     0xdcec30: bl              #0xd30150  ; AllocateTransformStub -> Transform (size=0x24)
    // 0xdcec34: mov             x1, x0
    // 0xdcec38: ldur            x0, [fp, #-8]
    // 0xdcec3c: stur            x1, [fp, #-0x20]
    // 0xdcec40: StoreField: r1->field_f = r0
    //     0xdcec40: stur            w0, [x1, #0xf]
    // 0xdcec44: r0 = Instance_Alignment
    //     0xdcec44: add             x0, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xdcec48: ldr             x0, [x0, #0xb80]
    // 0xdcec4c: ArrayStore: r1[0] = r0  ; List_4
    //     0xdcec4c: stur            w0, [x1, #0x17]
    // 0xdcec50: r0 = true
    //     0xdcec50: add             x0, NULL, #0x20  ; true
    // 0xdcec54: StoreField: r1->field_1b = r0
    //     0xdcec54: stur            w0, [x1, #0x1b]
    // 0xdcec58: ldur            x0, [fp, #-0x10]
    // 0xdcec5c: StoreField: r1->field_b = r0
    //     0xdcec5c: stur            w0, [x1, #0xb]
    // 0xdcec60: ldur            d0, [fp, #-0x28]
    // 0xdcec64: r0 = inline_Allocate_Double()
    //     0xdcec64: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xdcec68: add             x0, x0, #0x10
    //     0xdcec6c: cmp             x2, x0
    //     0xdcec70: b.ls            #0xdced20
    //     0xdcec74: str             x0, [THR, #0x60]  ; THR::top
    //     0xdcec78: sub             x0, x0, #0xf
    //     0xdcec7c: mov             x2, #0xe19c
    //     0xdcec80: movk            x2, #3, lsl #16
    //     0xdcec84: stur            x2, [x0, #-1]
    // 0xdcec88: dmb             ishst
    // 0xdcec8c: StoreField: r0->field_7 = d0
    //     0xdcec8c: stur            d0, [x0, #7]
    // 0xdcec90: stur            x0, [fp, #-8]
    // 0xdcec94: r0 = Container()
    //     0xdcec94: bl              #0x8a5af8  ; AllocateContainerStub -> Container (size=0x38)
    // 0xdcec98: stur            x0, [fp, #-0x10]
    // 0xdcec9c: ldur            x16, [fp, #-8]
    // 0xdceca0: r30 = Instance_Color
    //     0xdceca0: add             lr, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xdceca4: ldr             lr, [lr, #0x810]
    // 0xdceca8: stp             lr, x16, [SP, #0x18]
    // 0xdcecac: r16 = Instance_EdgeInsets
    //     0xdcecac: add             x16, PP, #0xd4, lsl #12  ; [pp+0xd4050] Obj!EdgeInsets@129d2f1
    //     0xdcecb0: ldr             x16, [x16, #0x50]
    // 0xdcecb4: r30 = Instance_EdgeInsets
    //     0xdcecb4: add             lr, PP, #0xc6, lsl #12  ; [pp+0xc69d8] Obj!EdgeInsets@129cfc1
    //     0xdcecb8: ldr             lr, [lr, #0x9d8]
    // 0xdcecbc: stp             lr, x16, [SP, #8]
    // 0xdcecc0: ldur            x16, [fp, #-0x20]
    // 0xdcecc4: str             x16, [SP]
    // 0xdcecc8: mov             x1, x0
    // 0xdceccc: r4 = const [0, 0x6, 0x5, 0x1, child, 0x5, color, 0x2, height, 0x1, margin, 0x4, padding, 0x3, null]
    //     0xdceccc: add             x4, PP, #0xd4, lsl #12  ; [pp+0xd4028] List(15) [0, 0x6, 0x5, 0x1, "child", 0x5, "color", 0x2, "height", 0x1, "margin", 0x4, "padding", 0x3, Null]
    //     0xdcecd0: ldr             x4, [x4, #0x28]
    // 0xdcecd4: r0 = Container()
    //     0xdcecd4: bl              #0x8a54e0  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0xdcecd8: r0 = GestureDetector()
    //     0xdcecd8: bl              #0x918e18  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0xdcecdc: ldur            x2, [fp, #-0x18]
    // 0xdcece0: r1 = Function '<anonymous closure>':.
    //     0xdcece0: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4058] AnonymousClosure: (0xdcef88), in [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_buildSpeedButton (0xdceb90)
    //     0xdcece4: ldr             x1, [x1, #0x58]
    // 0xdcece8: stur            x0, [fp, #-8]
    // 0xdcecec: r0 = AllocateClosure()
    //     0xdcecec: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdcecf0: ldur            x16, [fp, #-0x10]
    // 0xdcecf4: stp             x16, x0, [SP]
    // 0xdcecf8: ldur            x1, [fp, #-8]
    // 0xdcecfc: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0xdcecfc: add             x4, PP, #0x16, lsl #12  ; [pp+0x16e90] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0xdced00: ldr             x4, [x4, #0xe90]
    // 0xdced04: r0 = GestureDetector()
    //     0xdced04: bl              #0x9182dc  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0xdced08: ldur            x0, [fp, #-8]
    // 0xdced0c: LeaveFrame
    //     0xdced0c: mov             SP, fp
    //     0xdced10: ldp             fp, lr, [SP], #0x10
    // 0xdced14: ret
    //     0xdced14: ret             
    // 0xdced18: r0 = StackOverflowSharedWithFPURegs()
    //     0xdced18: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xdced1c: b               #0xdcebb4
    // 0xdced20: SaveReg d0
    //     0xdced20: str             q0, [SP, #-0x10]!
    // 0xdced24: SaveReg r1
    //     0xdced24: str             x1, [SP, #-8]!
    // 0xdced28: r0 = AllocateDouble()
    //     0xdced28: bl              #0x13df878  ; AllocateDoubleStub
    // 0xdced2c: RestoreReg r1
    //     0xdced2c: ldr             x1, [SP], #8
    // 0xdced30: RestoreReg d0
    //     0xdced30: ldr             q0, [SP], #0x10
    // 0xdced34: b               #0xdcec8c
  }
  [closure] Future<void> <anonymous closure>(dynamic) async {
    // ** addr: 0xdcef88, size: 0x160
    // 0xdcef88: EnterFrame
    //     0xdcef88: stp             fp, lr, [SP, #-0x10]!
    //     0xdcef8c: mov             fp, SP
    // 0xdcef90: AllocStack(0x40)
    //     0xdcef90: sub             SP, SP, #0x40
    // 0xdcef94: SetupParameters(_CupertinoControlsState this /* r1 */)
    //     0xdcef94: stur            NULL, [fp, #-8]
    //     0xdcef98: mov             x0, #0
    //     0xdcef9c: add             x1, fp, w0, sxtw #2
    //     0xdcefa0: ldr             x1, [x1, #0x10]
    //     0xdcefa4: ldur            w2, [x1, #0x17]
    //     0xdcefa8: add             x2, x2, HEAP, lsl #32
    //     0xdcefac: stur            x2, [fp, #-0x10]
    // 0xdcefb0: CheckStackOverflow
    //     0xdcefb0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdcefb4: cmp             SP, x16
    //     0xdcefb8: b.ls            #0xdcf0cc
    // 0xdcefbc: InitAsync() -> Future<void?>
    //     0xdcefbc: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0xdcefc0: bl              #0x7f5e44  ; InitAsyncStub
    // 0xdcefc4: ldur            x2, [fp, #-0x10]
    // 0xdcefc8: LoadField: r0 = r2->field_f
    //     0xdcefc8: ldur            w0, [x2, #0xf]
    // 0xdcefcc: DecompressPointer r0
    //     0xdcefcc: add             x0, x0, HEAP, lsl #32
    // 0xdcefd0: LoadField: r1 = r0->field_27
    //     0xdcefd0: ldur            w1, [x0, #0x27]
    // 0xdcefd4: DecompressPointer r1
    //     0xdcefd4: add             x1, x1, HEAP, lsl #32
    // 0xdcefd8: cmp             w1, NULL
    // 0xdcefdc: b.ne            #0xdcefe8
    // 0xdcefe0: mov             x0, x2
    // 0xdcefe4: b               #0xdceff0
    // 0xdcefe8: r0 = cancel()
    //     0xdcefe8: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0xdcefec: ldur            x0, [fp, #-0x10]
    // 0xdceff0: LoadField: r1 = r0->field_f
    //     0xdceff0: ldur            w1, [x0, #0xf]
    // 0xdceff4: DecompressPointer r1
    //     0xdceff4: add             x1, x1, HEAP, lsl #32
    // 0xdceff8: LoadField: r3 = r1->field_f
    //     0xdceff8: ldur            w3, [x1, #0xf]
    // 0xdceffc: DecompressPointer r3
    //     0xdceffc: add             x3, x3, HEAP, lsl #32
    // 0xdcf000: stur            x3, [fp, #-0x18]
    // 0xdcf004: cmp             w3, NULL
    // 0xdcf008: b.eq            #0xdcf0d4
    // 0xdcf00c: LoadField: r2 = r1->field_57
    //     0xdcf00c: ldur            w2, [x1, #0x57]
    // 0xdcf010: DecompressPointer r2
    //     0xdcf010: add             x2, x2, HEAP, lsl #32
    // 0xdcf014: cmp             w2, NULL
    // 0xdcf018: b.eq            #0xdcf0d8
    // 0xdcf01c: mov             x2, x0
    // 0xdcf020: r1 = Function '<anonymous closure>':.
    //     0xdcf020: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4060] AnonymousClosure: (0xdcf2b0), in [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_buildSpeedButton (0xdceb90)
    //     0xdcf024: ldr             x1, [x1, #0x60]
    // 0xdcf028: r0 = AllocateClosure()
    //     0xdcf028: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdcf02c: r16 = <double>
    //     0xdcf02c: ldr             x16, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xdcf030: stp             x0, x16, [SP, #0x10]
    // 0xdcf034: ldur            x16, [fp, #-0x18]
    // 0xdcf038: r30 = true
    //     0xdcf038: add             lr, NULL, #0x20  ; true
    // 0xdcf03c: stp             lr, x16, [SP]
    // 0xdcf040: r4 = const [0x1, 0x3, 0x3, 0x2, semanticsDismissible, 0x2, null]
    //     0xdcf040: add             x4, PP, #0xd4, lsl #12  ; [pp+0xd4040] List(7) [0x1, 0x3, 0x3, 0x2, "semanticsDismissible", 0x2, Null]
    //     0xdcf044: ldr             x4, [x4, #0x40]
    // 0xdcf048: r0 = showCupertinoModalPopup()
    //     0xdcf048: bl              #0xdce924  ; [package:flutter/src/cupertino/route.dart] ::showCupertinoModalPopup
    // 0xdcf04c: mov             x1, x0
    // 0xdcf050: stur            x1, [fp, #-0x18]
    // 0xdcf054: r0 = Await()
    //     0xdcf054: bl              #0x7f5c00  ; AwaitStub
    // 0xdcf058: cmp             w0, NULL
    // 0xdcf05c: b.eq            #0xdcf094
    // 0xdcf060: ldur            x2, [fp, #-0x10]
    // 0xdcf064: LoadField: r1 = r2->field_13
    //     0xdcf064: ldur            w1, [x2, #0x13]
    // 0xdcf068: DecompressPointer r1
    //     0xdcf068: add             x1, x1, HEAP, lsl #32
    // 0xdcf06c: LoadField: d1 = r0->field_7
    //     0xdcf06c: ldur            d1, [x0, #7]
    // 0xdcf070: mov             v0.16b, v1.16b
    // 0xdcf074: stur            d1, [fp, #-0x20]
    // 0xdcf078: r0 = setPlaybackSpeed()
    //     0xdcf078: bl              #0xdcf0e8  ; [package:video_player/video_player.dart] VideoPlayerController::setPlaybackSpeed
    // 0xdcf07c: ldur            x0, [fp, #-0x10]
    // 0xdcf080: LoadField: r1 = r0->field_f
    //     0xdcf080: ldur            w1, [x0, #0xf]
    // 0xdcf084: DecompressPointer r1
    //     0xdcf084: add             x1, x1, HEAP, lsl #32
    // 0xdcf088: ldur            d0, [fp, #-0x20]
    // 0xdcf08c: StoreField: r1->field_4b = d0
    //     0xdcf08c: stur            d0, [x1, #0x4b]
    // 0xdcf090: b               #0xdcf098
    // 0xdcf094: ldur            x0, [fp, #-0x10]
    // 0xdcf098: LoadField: r1 = r0->field_f
    //     0xdcf098: ldur            w1, [x0, #0xf]
    // 0xdcf09c: DecompressPointer r1
    //     0xdcf09c: add             x1, x1, HEAP, lsl #32
    // 0xdcf0a0: LoadField: r0 = r1->field_1f
    //     0xdcf0a0: ldur            w0, [x1, #0x1f]
    // 0xdcf0a4: DecompressPointer r0
    //     0xdcf0a4: add             x0, x0, HEAP, lsl #32
    // 0xdcf0a8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdcf0ac: cmp             w0, w16
    // 0xdcf0b0: b.eq            #0xdcf0dc
    // 0xdcf0b4: LoadField: r2 = r0->field_1b
    //     0xdcf0b4: ldur            w2, [x0, #0x1b]
    // 0xdcf0b8: DecompressPointer r2
    //     0xdcf0b8: add             x2, x2, HEAP, lsl #32
    // 0xdcf0bc: tbnz            w2, #4, #0xdcf0c4
    // 0xdcf0c0: r0 = _startHideTimer()
    //     0xdcf0c0: bl              #0xdce790  ; [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_startHideTimer
    // 0xdcf0c4: r0 = Null
    //     0xdcf0c4: mov             x0, NULL
    // 0xdcf0c8: r0 = ReturnAsyncNotFuture()
    //     0xdcf0c8: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xdcf0cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdcf0cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdcf0d0: b               #0xdcefbc
    // 0xdcf0d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdcf0d4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdcf0d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdcf0d8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdcf0dc: r9 = _latestValue
    //     0xdcf0dc: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3ff0] Field <_CupertinoControlsState@450205881._latestValue@450205881>: late (offset: 0x20)
    //     0xdcf0e0: ldr             x9, [x9, #0xff0]
    // 0xdcf0e4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdcf0e4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] _PlaybackSpeedDialog <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0xdcf2b0, size: 0x80
    // 0xdcf2b0: EnterFrame
    //     0xdcf2b0: stp             fp, lr, [SP, #-0x10]!
    //     0xdcf2b4: mov             fp, SP
    // 0xdcf2b8: AllocStack(0x8)
    //     0xdcf2b8: sub             SP, SP, #8
    // 0xdcf2bc: SetupParameters([dynamic _ /* r0 */])
    //     0xdcf2bc: ldr             x0, [fp, #0x18]
    //     0xdcf2c0: ldur            w1, [x0, #0x17]
    //     0xdcf2c4: add             x1, x1, HEAP, lsl #32
    // 0xdcf2c8: LoadField: r0 = r1->field_f
    //     0xdcf2c8: ldur            w0, [x1, #0xf]
    // 0xdcf2cc: DecompressPointer r0
    //     0xdcf2cc: add             x0, x0, HEAP, lsl #32
    // 0xdcf2d0: LoadField: r1 = r0->field_57
    //     0xdcf2d0: ldur            w1, [x0, #0x57]
    // 0xdcf2d4: DecompressPointer r1
    //     0xdcf2d4: add             x1, x1, HEAP, lsl #32
    // 0xdcf2d8: cmp             w1, NULL
    // 0xdcf2dc: b.eq            #0xdcf320
    // 0xdcf2e0: LoadField: r1 = r0->field_1f
    //     0xdcf2e0: ldur            w1, [x0, #0x1f]
    // 0xdcf2e4: DecompressPointer r1
    //     0xdcf2e4: add             x1, x1, HEAP, lsl #32
    // 0xdcf2e8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdcf2ec: cmp             w1, w16
    // 0xdcf2f0: b.eq            #0xdcf324
    // 0xdcf2f4: LoadField: d0 = r1->field_2f
    //     0xdcf2f4: ldur            d0, [x1, #0x2f]
    // 0xdcf2f8: stur            d0, [fp, #-8]
    // 0xdcf2fc: r0 = _PlaybackSpeedDialog()
    //     0xdcf2fc: bl              #0xdcf330  ; Allocate_PlaybackSpeedDialogStub -> _PlaybackSpeedDialog (size=0x18)
    // 0xdcf300: r1 = const [0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0]
    //     0xdcf300: add             x1, PP, #0xa5, lsl #12  ; [pp+0xa5f68] List<double>(8)
    //     0xdcf304: ldr             x1, [x1, #0xf68]
    // 0xdcf308: StoreField: r0->field_b = r1
    //     0xdcf308: stur            w1, [x0, #0xb]
    // 0xdcf30c: ldur            d0, [fp, #-8]
    // 0xdcf310: StoreField: r0->field_f = d0
    //     0xdcf310: stur            d0, [x0, #0xf]
    // 0xdcf314: LeaveFrame
    //     0xdcf314: mov             SP, fp
    //     0xdcf318: ldp             fp, lr, [SP], #0x10
    // 0xdcf31c: ret
    //     0xdcf31c: ret             
    // 0xdcf320: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdcf320: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdcf324: r9 = _latestValue
    //     0xdcf324: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3ff0] Field <_CupertinoControlsState@450205881._latestValue@450205881>: late (offset: 0x20)
    //     0xdcf328: ldr             x9, [x9, #0xff0]
    // 0xdcf32c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdcf32c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _buildRemaining(/* No info */) {
    // ** addr: 0xdcf33c, size: 0x138
    // 0xdcf33c: EnterFrame
    //     0xdcf33c: stp             fp, lr, [SP, #-0x10]!
    //     0xdcf340: mov             fp, SP
    // 0xdcf344: AllocStack(0x28)
    //     0xdcf344: sub             SP, SP, #0x28
    // 0xdcf348: CheckStackOverflow
    //     0xdcf348: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdcf34c: cmp             SP, x16
    //     0xdcf350: b.ls            #0xdcf460
    // 0xdcf354: LoadField: r0 = r1->field_1f
    //     0xdcf354: ldur            w0, [x1, #0x1f]
    // 0xdcf358: DecompressPointer r0
    //     0xdcf358: add             x0, x0, HEAP, lsl #32
    // 0xdcf35c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdcf360: cmp             w0, w16
    // 0xdcf364: b.eq            #0xdcf468
    // 0xdcf368: LoadField: r1 = r0->field_7
    //     0xdcf368: ldur            w1, [x0, #7]
    // 0xdcf36c: DecompressPointer r1
    //     0xdcf36c: add             x1, x1, HEAP, lsl #32
    // 0xdcf370: LoadField: r2 = r0->field_b
    //     0xdcf370: ldur            w2, [x0, #0xb]
    // 0xdcf374: DecompressPointer r2
    //     0xdcf374: add             x2, x2, HEAP, lsl #32
    // 0xdcf378: LoadField: r0 = r1->field_7
    //     0xdcf378: ldur            x0, [x1, #7]
    // 0xdcf37c: LoadField: r1 = r2->field_7
    //     0xdcf37c: ldur            x1, [x2, #7]
    // 0xdcf380: sub             x2, x0, x1
    // 0xdcf384: stur            x2, [fp, #-8]
    // 0xdcf388: r0 = Duration()
    //     0xdcf388: bl              #0x7dd0d0  ; AllocateDurationStub -> Duration (size=0x10)
    // 0xdcf38c: mov             x3, x0
    // 0xdcf390: ldur            x0, [fp, #-8]
    // 0xdcf394: stur            x3, [fp, #-0x10]
    // 0xdcf398: StoreField: r3->field_7 = r0
    //     0xdcf398: stur            x0, [x3, #7]
    // 0xdcf39c: r1 = Null
    //     0xdcf39c: mov             x1, NULL
    // 0xdcf3a0: r2 = 4
    //     0xdcf3a0: mov             x2, #4
    // 0xdcf3a4: r0 = AllocateArray()
    //     0xdcf3a4: bl              #0x13df928  ; AllocateArrayStub
    // 0xdcf3a8: stur            x0, [fp, #-0x18]
    // 0xdcf3ac: r16 = "-"
    //     0xdcf3ac: ldr             x16, [PP, #0x24e8]  ; [pp+0x24e8] "-"
    // 0xdcf3b0: StoreField: r0->field_f = r16
    //     0xdcf3b0: stur            w16, [x0, #0xf]
    // 0xdcf3b4: ldur            x1, [fp, #-0x10]
    // 0xdcf3b8: r0 = formatDuration()
    //     0xdcf3b8: bl              #0xdcf474  ; [package:chewie/src/helpers/utils.dart] ::formatDuration
    // 0xdcf3bc: ldur            x1, [fp, #-0x18]
    // 0xdcf3c0: ArrayStore: r1[1] = r0  ; List_4
    //     0xdcf3c0: add             x25, x1, #0x13
    //     0xdcf3c4: str             w0, [x25]
    //     0xdcf3c8: tbz             w0, #0, #0xdcf3e4
    //     0xdcf3cc: ldurb           w16, [x1, #-1]
    //     0xdcf3d0: ldurb           w17, [x0, #-1]
    //     0xdcf3d4: and             x16, x17, x16, lsr #2
    //     0xdcf3d8: tst             x16, HEAP, lsr #32
    //     0xdcf3dc: b.eq            #0xdcf3e4
    //     0xdcf3e0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdcf3e4: ldur            x16, [fp, #-0x18]
    // 0xdcf3e8: str             x16, [SP]
    // 0xdcf3ec: r0 = _interpolate()
    //     0xdcf3ec: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xdcf3f0: stur            x0, [fp, #-0x10]
    // 0xdcf3f4: r0 = TextStyle()
    //     0xdcf3f4: bl              #0x8a68f4  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0xdcf3f8: mov             x1, x0
    // 0xdcf3fc: r0 = true
    //     0xdcf3fc: add             x0, NULL, #0x20  ; true
    // 0xdcf400: stur            x1, [fp, #-0x18]
    // 0xdcf404: StoreField: r1->field_7 = r0
    //     0xdcf404: stur            w0, [x1, #7]
    // 0xdcf408: r0 = Instance_Color
    //     0xdcf408: add             x0, PP, #0xd4, lsl #12  ; [pp+0xd4010] Obj!Color@12a3ba1
    //     0xdcf40c: ldr             x0, [x0, #0x10]
    // 0xdcf410: StoreField: r1->field_b = r0
    //     0xdcf410: stur            w0, [x1, #0xb]
    // 0xdcf414: r0 = 12.000000
    //     0xdcf414: add             x0, PP, #0x19, lsl #12  ; [pp+0x19c58] 12
    //     0xdcf418: ldr             x0, [x0, #0xc58]
    // 0xdcf41c: StoreField: r1->field_1f = r0
    //     0xdcf41c: stur            w0, [x1, #0x1f]
    // 0xdcf420: r0 = Text()
    //     0xdcf420: bl              #0x8a70a4  ; AllocateTextStub -> Text (size=0x50)
    // 0xdcf424: mov             x1, x0
    // 0xdcf428: ldur            x0, [fp, #-0x10]
    // 0xdcf42c: stur            x1, [fp, #-0x20]
    // 0xdcf430: StoreField: r1->field_b = r0
    //     0xdcf430: stur            w0, [x1, #0xb]
    // 0xdcf434: ldur            x0, [fp, #-0x18]
    // 0xdcf438: StoreField: r1->field_13 = r0
    //     0xdcf438: stur            w0, [x1, #0x13]
    // 0xdcf43c: r0 = Padding()
    //     0xdcf43c: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xdcf440: r1 = Instance_EdgeInsets
    //     0xdcf440: add             x1, PP, #0xd2, lsl #12  ; [pp+0xd2cc8] Obj!EdgeInsets@129d321
    //     0xdcf444: ldr             x1, [x1, #0xcc8]
    // 0xdcf448: StoreField: r0->field_f = r1
    //     0xdcf448: stur            w1, [x0, #0xf]
    // 0xdcf44c: ldur            x1, [fp, #-0x20]
    // 0xdcf450: StoreField: r0->field_b = r1
    //     0xdcf450: stur            w1, [x0, #0xb]
    // 0xdcf454: LeaveFrame
    //     0xdcf454: mov             SP, fp
    //     0xdcf458: ldp             fp, lr, [SP], #0x10
    // 0xdcf45c: ret
    //     0xdcf45c: ret             
    // 0xdcf460: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdcf460: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdcf464: b               #0xdcf354
    // 0xdcf468: r9 = _latestValue
    //     0xdcf468: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3ff0] Field <_CupertinoControlsState@450205881._latestValue@450205881>: late (offset: 0x20)
    //     0xdcf46c: ldr             x9, [x9, #0xff0]
    // 0xdcf470: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdcf470: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _buildProgressBar(/* No info */) {
    // ** addr: 0xdcf6e0, size: 0x188
    // 0xdcf6e0: EnterFrame
    //     0xdcf6e0: stp             fp, lr, [SP, #-0x10]!
    //     0xdcf6e4: mov             fp, SP
    // 0xdcf6e8: AllocStack(0x20)
    //     0xdcf6e8: sub             SP, SP, #0x20
    // 0xdcf6ec: SetupParameters(_CupertinoControlsState this /* r1 => r1, fp-0x8 */)
    //     0xdcf6ec: stur            x1, [fp, #-8]
    // 0xdcf6f0: CheckStackOverflow
    //     0xdcf6f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdcf6f4: cmp             SP, x16
    //     0xdcf6f8: b.ls            #0xdcf84c
    // 0xdcf6fc: r1 = 1
    //     0xdcf6fc: mov             x1, #1
    // 0xdcf700: r0 = AllocateContext()
    //     0xdcf700: bl              #0x13de838  ; AllocateContextStub
    // 0xdcf704: mov             x1, x0
    // 0xdcf708: ldur            x0, [fp, #-8]
    // 0xdcf70c: stur            x1, [fp, #-0x18]
    // 0xdcf710: StoreField: r1->field_f = r0
    //     0xdcf710: stur            w0, [x1, #0xf]
    // 0xdcf714: LoadField: r2 = r0->field_53
    //     0xdcf714: ldur            w2, [x0, #0x53]
    // 0xdcf718: DecompressPointer r2
    //     0xdcf718: add             x2, x2, HEAP, lsl #32
    // 0xdcf71c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdcf720: cmp             w2, w16
    // 0xdcf724: b.eq            #0xdcf854
    // 0xdcf728: stur            x2, [fp, #-0x10]
    // 0xdcf72c: LoadField: r3 = r0->field_57
    //     0xdcf72c: ldur            w3, [x0, #0x57]
    // 0xdcf730: DecompressPointer r3
    //     0xdcf730: add             x3, x3, HEAP, lsl #32
    // 0xdcf734: cmp             w3, NULL
    // 0xdcf738: b.eq            #0xdcf860
    // 0xdcf73c: r0 = ChewieProgressColors()
    //     0xdcf73c: bl              #0xdcfa1c  ; AllocateChewieProgressColorsStub -> ChewieProgressColors (size=0x18)
    // 0xdcf740: mov             x1, x0
    // 0xdcf744: r2 = Instance_Color
    //     0xdcf744: add             x2, PP, #0xd4, lsl #12  ; [pp+0xd4068] Obj!Color@12a3c31
    //     0xdcf748: ldr             x2, [x2, #0x68]
    // 0xdcf74c: r3 = Instance_Color
    //     0xdcf74c: add             x3, PP, #0xd4, lsl #12  ; [pp+0xd4070] Obj!Color@12a3c01
    //     0xdcf750: ldr             x3, [x3, #0x70]
    // 0xdcf754: r5 = Instance_Color
    //     0xdcf754: add             x5, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0xdcf758: ldr             x5, [x5, #0xc38]
    // 0xdcf75c: r6 = Instance_Color
    //     0xdcf75c: add             x6, PP, #0xd4, lsl #12  ; [pp+0xd4078] Obj!Color@12a3bd1
    //     0xdcf760: ldr             x6, [x6, #0x78]
    // 0xdcf764: stur            x0, [fp, #-0x20]
    // 0xdcf768: r0 = ChewieProgressColors()
    //     0xdcf768: bl              #0xdcf874  ; [package:chewie/src/chewie_progress_colors.dart] ChewieProgressColors::ChewieProgressColors
    // 0xdcf76c: ldur            x0, [fp, #-8]
    // 0xdcf770: LoadField: r1 = r0->field_57
    //     0xdcf770: ldur            w1, [x0, #0x57]
    // 0xdcf774: DecompressPointer r1
    //     0xdcf774: add             x1, x1, HEAP, lsl #32
    // 0xdcf778: cmp             w1, NULL
    // 0xdcf77c: b.eq            #0xdcf864
    // 0xdcf780: r0 = CupertinoVideoProgressBar()
    //     0xdcf780: bl              #0xdcf868  ; AllocateCupertinoVideoProgressBarStub -> CupertinoVideoProgressBar (size=0x24)
    // 0xdcf784: mov             x3, x0
    // 0xdcf788: ldur            x0, [fp, #-0x10]
    // 0xdcf78c: stur            x3, [fp, #-8]
    // 0xdcf790: StoreField: r3->field_b = r0
    //     0xdcf790: stur            w0, [x3, #0xb]
    // 0xdcf794: ldur            x2, [fp, #-0x18]
    // 0xdcf798: r1 = Function '<anonymous closure>':.
    //     0xdcf798: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4080] AnonymousClosure: (0xdd099c), in [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_buildProgressBar (0xdcf6e0)
    //     0xdcf79c: ldr             x1, [x1, #0x80]
    // 0xdcf7a0: r0 = AllocateClosure()
    //     0xdcf7a0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdcf7a4: mov             x1, x0
    // 0xdcf7a8: ldur            x0, [fp, #-8]
    // 0xdcf7ac: ArrayStore: r0[0] = r1  ; List_4
    //     0xdcf7ac: stur            w1, [x0, #0x17]
    // 0xdcf7b0: ldur            x2, [fp, #-0x18]
    // 0xdcf7b4: r1 = Function '<anonymous closure>':.
    //     0xdcf7b4: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4088] AnonymousClosure: (0xdd0910), in [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_buildProgressBar (0xdcf6e0)
    //     0xdcf7b8: ldr             x1, [x1, #0x88]
    // 0xdcf7bc: r0 = AllocateClosure()
    //     0xdcf7bc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdcf7c0: mov             x1, x0
    // 0xdcf7c4: ldur            x0, [fp, #-8]
    // 0xdcf7c8: StoreField: r0->field_13 = r1
    //     0xdcf7c8: stur            w1, [x0, #0x13]
    // 0xdcf7cc: ldur            x2, [fp, #-0x18]
    // 0xdcf7d0: r1 = Function '<anonymous closure>':.
    //     0xdcf7d0: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4090] AnonymousClosure: (0xdcfa28), in [package:chewie/src/material/material_desktop_controls.dart] _MaterialDesktopControlsState::_buildProgressBar (0xdcfa7c)
    //     0xdcf7d4: ldr             x1, [x1, #0x90]
    // 0xdcf7d8: r0 = AllocateClosure()
    //     0xdcf7d8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdcf7dc: mov             x1, x0
    // 0xdcf7e0: ldur            x0, [fp, #-8]
    // 0xdcf7e4: StoreField: r0->field_1b = r1
    //     0xdcf7e4: stur            w1, [x0, #0x1b]
    // 0xdcf7e8: r1 = true
    //     0xdcf7e8: add             x1, NULL, #0x20  ; true
    // 0xdcf7ec: StoreField: r0->field_1f = r1
    //     0xdcf7ec: stur            w1, [x0, #0x1f]
    // 0xdcf7f0: ldur            x1, [fp, #-0x20]
    // 0xdcf7f4: StoreField: r0->field_f = r1
    //     0xdcf7f4: stur            w1, [x0, #0xf]
    // 0xdcf7f8: r0 = Padding()
    //     0xdcf7f8: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xdcf7fc: mov             x2, x0
    // 0xdcf800: r0 = Instance_EdgeInsets
    //     0xdcf800: add             x0, PP, #0xd3, lsl #12  ; [pp+0xd3d98] Obj!EdgeInsets@129d351
    //     0xdcf804: ldr             x0, [x0, #0xd98]
    // 0xdcf808: stur            x2, [fp, #-0x10]
    // 0xdcf80c: StoreField: r2->field_f = r0
    //     0xdcf80c: stur            w0, [x2, #0xf]
    // 0xdcf810: ldur            x0, [fp, #-8]
    // 0xdcf814: StoreField: r2->field_b = r0
    //     0xdcf814: stur            w0, [x2, #0xb]
    // 0xdcf818: r1 = <FlexParentData>
    //     0xdcf818: add             x1, PP, #0x15, lsl #12  ; [pp+0x15878] TypeArguments: <FlexParentData>
    //     0xdcf81c: ldr             x1, [x1, #0x878]
    // 0xdcf820: r0 = Expanded()
    //     0xdcf820: bl              #0x8a5b10  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0xdcf824: r1 = 1
    //     0xdcf824: mov             x1, #1
    // 0xdcf828: StoreField: r0->field_13 = r1
    //     0xdcf828: stur            x1, [x0, #0x13]
    // 0xdcf82c: r1 = Instance_FlexFit
    //     0xdcf82c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15880] Obj!FlexFit@12c4641
    //     0xdcf830: ldr             x1, [x1, #0x880]
    // 0xdcf834: StoreField: r0->field_1b = r1
    //     0xdcf834: stur            w1, [x0, #0x1b]
    // 0xdcf838: ldur            x1, [fp, #-0x10]
    // 0xdcf83c: StoreField: r0->field_b = r1
    //     0xdcf83c: stur            w1, [x0, #0xb]
    // 0xdcf840: LeaveFrame
    //     0xdcf840: mov             SP, fp
    //     0xdcf844: ldp             fp, lr, [SP], #0x10
    // 0xdcf848: ret
    //     0xdcf848: ret             
    // 0xdcf84c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdcf84c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdcf850: b               #0xdcf6fc
    // 0xdcf854: r9 = controller
    //     0xdcf854: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3fa0] Field <_CupertinoControlsState@450205881.controller>: late (offset: 0x54)
    //     0xdcf858: ldr             x9, [x9, #0xfa0]
    // 0xdcf85c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdcf85c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdcf860: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdcf860: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdcf864: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdcf864: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Null <anonymous closure>(dynamic) {
    // ** addr: 0xdd0910, size: 0x8c
    // 0xdd0910: EnterFrame
    //     0xdd0910: stp             fp, lr, [SP, #-0x10]!
    //     0xdd0914: mov             fp, SP
    // 0xdd0918: AllocStack(0x10)
    //     0xdd0918: sub             SP, SP, #0x10
    // 0xdd091c: SetupParameters([dynamic _ /* r0 */])
    //     0xdd091c: ldr             x0, [fp, #0x10]
    //     0xdd0920: ldur            w3, [x0, #0x17]
    //     0xdd0924: add             x3, x3, HEAP, lsl #32
    //     0xdd0928: stur            x3, [fp, #-0x10]
    // 0xdd092c: CheckStackOverflow
    //     0xdd092c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd0930: cmp             SP, x16
    //     0xdd0934: b.ls            #0xdd0994
    // 0xdd0938: LoadField: r0 = r3->field_f
    //     0xdd0938: ldur            w0, [x3, #0xf]
    // 0xdd093c: DecompressPointer r0
    //     0xdd093c: add             x0, x0, HEAP, lsl #32
    // 0xdd0940: mov             x2, x3
    // 0xdd0944: stur            x0, [fp, #-8]
    // 0xdd0948: r1 = Function '<anonymous closure>':.
    //     0xdd0948: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4098] AnonymousClosure: (0xbf994c), in [package:flutter/src/material/slider.dart] _SliderState::_handleDragStart (0xbf98d0)
    //     0xdd094c: ldr             x1, [x1, #0x98]
    // 0xdd0950: r0 = AllocateClosure()
    //     0xdd0950: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd0954: ldur            x1, [fp, #-8]
    // 0xdd0958: mov             x2, x0
    // 0xdd095c: r0 = setState()
    //     0xdd095c: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xdd0960: ldur            x0, [fp, #-0x10]
    // 0xdd0964: LoadField: r1 = r0->field_f
    //     0xdd0964: ldur            w1, [x0, #0xf]
    // 0xdd0968: DecompressPointer r1
    //     0xdd0968: add             x1, x1, HEAP, lsl #32
    // 0xdd096c: LoadField: r0 = r1->field_27
    //     0xdd096c: ldur            w0, [x1, #0x27]
    // 0xdd0970: DecompressPointer r0
    //     0xdd0970: add             x0, x0, HEAP, lsl #32
    // 0xdd0974: cmp             w0, NULL
    // 0xdd0978: b.eq            #0xdd0984
    // 0xdd097c: mov             x1, x0
    // 0xdd0980: r0 = cancel()
    //     0xdd0980: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0xdd0984: r0 = Null
    //     0xdd0984: mov             x0, NULL
    // 0xdd0988: LeaveFrame
    //     0xdd0988: mov             SP, fp
    //     0xdd098c: ldp             fp, lr, [SP], #0x10
    // 0xdd0990: ret
    //     0xdd0990: ret             
    // 0xdd0994: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd0994: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd0998: b               #0xdd0938
  }
  [closure] Null <anonymous closure>(dynamic) {
    // ** addr: 0xdd099c, size: 0x78
    // 0xdd099c: EnterFrame
    //     0xdd099c: stp             fp, lr, [SP, #-0x10]!
    //     0xdd09a0: mov             fp, SP
    // 0xdd09a4: AllocStack(0x10)
    //     0xdd09a4: sub             SP, SP, #0x10
    // 0xdd09a8: SetupParameters([dynamic _ /* r0 */])
    //     0xdd09a8: ldr             x0, [fp, #0x10]
    //     0xdd09ac: ldur            w3, [x0, #0x17]
    //     0xdd09b0: add             x3, x3, HEAP, lsl #32
    //     0xdd09b4: stur            x3, [fp, #-0x10]
    // 0xdd09b8: CheckStackOverflow
    //     0xdd09b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd09bc: cmp             SP, x16
    //     0xdd09c0: b.ls            #0xdd0a0c
    // 0xdd09c4: LoadField: r0 = r3->field_f
    //     0xdd09c4: ldur            w0, [x3, #0xf]
    // 0xdd09c8: DecompressPointer r0
    //     0xdd09c8: add             x0, x0, HEAP, lsl #32
    // 0xdd09cc: mov             x2, x3
    // 0xdd09d0: stur            x0, [fp, #-8]
    // 0xdd09d4: r1 = Function '<anonymous closure>':.
    //     0xdd09d4: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd40a0] AnonymousClosure: (0xbf9648), in [package:flutter/src/material/slider.dart] _SliderState::_handleDragEnd (0xbf95c8)
    //     0xdd09d8: ldr             x1, [x1, #0xa0]
    // 0xdd09dc: r0 = AllocateClosure()
    //     0xdd09dc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd09e0: ldur            x1, [fp, #-8]
    // 0xdd09e4: mov             x2, x0
    // 0xdd09e8: r0 = setState()
    //     0xdd09e8: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xdd09ec: ldur            x0, [fp, #-0x10]
    // 0xdd09f0: LoadField: r1 = r0->field_f
    //     0xdd09f0: ldur            w1, [x0, #0xf]
    // 0xdd09f4: DecompressPointer r1
    //     0xdd09f4: add             x1, x1, HEAP, lsl #32
    // 0xdd09f8: r0 = _startHideTimer()
    //     0xdd09f8: bl              #0xdce790  ; [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_startHideTimer
    // 0xdd09fc: r0 = Null
    //     0xdd09fc: mov             x0, NULL
    // 0xdd0a00: LeaveFrame
    //     0xdd0a00: mov             SP, fp
    //     0xdd0a04: ldp             fp, lr, [SP], #0x10
    // 0xdd0a08: ret
    //     0xdd0a08: ret             
    // 0xdd0a0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd0a0c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd0a10: b               #0xdd09c4
  }
  _ _buildPosition(/* No info */) {
    // ** addr: 0xdd0a14, size: 0xbc
    // 0xdd0a14: EnterFrame
    //     0xdd0a14: stp             fp, lr, [SP, #-0x10]!
    //     0xdd0a18: mov             fp, SP
    // 0xdd0a1c: AllocStack(0x18)
    //     0xdd0a1c: sub             SP, SP, #0x18
    // 0xdd0a20: CheckStackOverflow
    //     0xdd0a20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd0a24: cmp             SP, x16
    //     0xdd0a28: b.ls            #0xdd0abc
    // 0xdd0a2c: LoadField: r0 = r1->field_1f
    //     0xdd0a2c: ldur            w0, [x1, #0x1f]
    // 0xdd0a30: DecompressPointer r0
    //     0xdd0a30: add             x0, x0, HEAP, lsl #32
    // 0xdd0a34: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd0a38: cmp             w0, w16
    // 0xdd0a3c: b.eq            #0xdd0ac4
    // 0xdd0a40: LoadField: r1 = r0->field_b
    //     0xdd0a40: ldur            w1, [x0, #0xb]
    // 0xdd0a44: DecompressPointer r1
    //     0xdd0a44: add             x1, x1, HEAP, lsl #32
    // 0xdd0a48: r0 = formatDuration()
    //     0xdd0a48: bl              #0xdcf474  ; [package:chewie/src/helpers/utils.dart] ::formatDuration
    // 0xdd0a4c: stur            x0, [fp, #-8]
    // 0xdd0a50: r0 = TextStyle()
    //     0xdd0a50: bl              #0x8a68f4  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0xdd0a54: mov             x1, x0
    // 0xdd0a58: r0 = true
    //     0xdd0a58: add             x0, NULL, #0x20  ; true
    // 0xdd0a5c: stur            x1, [fp, #-0x10]
    // 0xdd0a60: StoreField: r1->field_7 = r0
    //     0xdd0a60: stur            w0, [x1, #7]
    // 0xdd0a64: r0 = Instance_Color
    //     0xdd0a64: add             x0, PP, #0xd4, lsl #12  ; [pp+0xd4010] Obj!Color@12a3ba1
    //     0xdd0a68: ldr             x0, [x0, #0x10]
    // 0xdd0a6c: StoreField: r1->field_b = r0
    //     0xdd0a6c: stur            w0, [x1, #0xb]
    // 0xdd0a70: r0 = 12.000000
    //     0xdd0a70: add             x0, PP, #0x19, lsl #12  ; [pp+0x19c58] 12
    //     0xdd0a74: ldr             x0, [x0, #0xc58]
    // 0xdd0a78: StoreField: r1->field_1f = r0
    //     0xdd0a78: stur            w0, [x1, #0x1f]
    // 0xdd0a7c: r0 = Text()
    //     0xdd0a7c: bl              #0x8a70a4  ; AllocateTextStub -> Text (size=0x50)
    // 0xdd0a80: mov             x1, x0
    // 0xdd0a84: ldur            x0, [fp, #-8]
    // 0xdd0a88: stur            x1, [fp, #-0x18]
    // 0xdd0a8c: StoreField: r1->field_b = r0
    //     0xdd0a8c: stur            w0, [x1, #0xb]
    // 0xdd0a90: ldur            x0, [fp, #-0x10]
    // 0xdd0a94: StoreField: r1->field_13 = r0
    //     0xdd0a94: stur            w0, [x1, #0x13]
    // 0xdd0a98: r0 = Padding()
    //     0xdd0a98: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xdd0a9c: r1 = Instance_EdgeInsets
    //     0xdd0a9c: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3d98] Obj!EdgeInsets@129d351
    //     0xdd0aa0: ldr             x1, [x1, #0xd98]
    // 0xdd0aa4: StoreField: r0->field_f = r1
    //     0xdd0aa4: stur            w1, [x0, #0xf]
    // 0xdd0aa8: ldur            x1, [fp, #-0x18]
    // 0xdd0aac: StoreField: r0->field_b = r1
    //     0xdd0aac: stur            w1, [x0, #0xb]
    // 0xdd0ab0: LeaveFrame
    //     0xdd0ab0: mov             SP, fp
    //     0xdd0ab4: ldp             fp, lr, [SP], #0x10
    // 0xdd0ab8: ret
    //     0xdd0ab8: ret             
    // 0xdd0abc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd0abc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd0ac0: b               #0xdd0a2c
    // 0xdd0ac4: r9 = _latestValue
    //     0xdd0ac4: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3ff0] Field <_CupertinoControlsState@450205881._latestValue@450205881>: late (offset: 0x20)
    //     0xdd0ac8: ldr             x9, [x9, #0xff0]
    // 0xdd0acc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd0acc: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _buildSkipForward(/* No info */) {
    // ** addr: 0xdd0ad0, size: 0x12c
    // 0xdd0ad0: EnterFrame
    //     0xdd0ad0: stp             fp, lr, [SP, #-0x10]!
    //     0xdd0ad4: mov             fp, SP
    // 0xdd0ad8: AllocStack(0x50)
    //     0xdd0ad8: sub             SP, SP, #0x50
    // 0xdd0adc: SetupParameters(_CupertinoControlsState this /* r1 => r2, fp-0x8 */, dynamic _ /* d0 => d0, fp-0x28 */)
    //     0xdd0adc: mov             x2, x1
    //     0xdd0ae0: stur            x1, [fp, #-8]
    //     0xdd0ae4: stur            d0, [fp, #-0x28]
    // 0xdd0ae8: CheckStackOverflow
    //     0xdd0ae8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd0aec: cmp             SP, x16
    //     0xdd0af0: b.ls            #0xdd0bdc
    // 0xdd0af4: r0 = Icon()
    //     0xdd0af4: bl              #0xd0fd5c  ; AllocateIconStub -> Icon (size=0x40)
    // 0xdd0af8: mov             x1, x0
    // 0xdd0afc: r0 = Instance_IconData
    //     0xdd0afc: add             x0, PP, #0xd4, lsl #12  ; [pp+0xd40a8] Obj!IconData@128a651
    //     0xdd0b00: ldr             x0, [x0, #0xa8]
    // 0xdd0b04: stur            x1, [fp, #-0x18]
    // 0xdd0b08: StoreField: r1->field_b = r0
    //     0xdd0b08: stur            w0, [x1, #0xb]
    // 0xdd0b0c: r0 = 18.000000
    //     0xdd0b0c: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e530] 18
    //     0xdd0b10: ldr             x0, [x0, #0x530]
    // 0xdd0b14: StoreField: r1->field_f = r0
    //     0xdd0b14: stur            w0, [x1, #0xf]
    // 0xdd0b18: r0 = Instance_Color
    //     0xdd0b18: add             x0, PP, #0xd4, lsl #12  ; [pp+0xd4010] Obj!Color@12a3ba1
    //     0xdd0b1c: ldr             x0, [x0, #0x10]
    // 0xdd0b20: StoreField: r1->field_23 = r0
    //     0xdd0b20: stur            w0, [x1, #0x23]
    // 0xdd0b24: ldur            d0, [fp, #-0x28]
    // 0xdd0b28: r0 = inline_Allocate_Double()
    //     0xdd0b28: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xdd0b2c: add             x0, x0, #0x10
    //     0xdd0b30: cmp             x2, x0
    //     0xdd0b34: b.ls            #0xdd0be4
    //     0xdd0b38: str             x0, [THR, #0x60]  ; THR::top
    //     0xdd0b3c: sub             x0, x0, #0xf
    //     0xdd0b40: mov             x2, #0xe19c
    //     0xdd0b44: movk            x2, #3, lsl #16
    //     0xdd0b48: stur            x2, [x0, #-1]
    // 0xdd0b4c: dmb             ishst
    // 0xdd0b50: StoreField: r0->field_7 = d0
    //     0xdd0b50: stur            d0, [x0, #7]
    // 0xdd0b54: stur            x0, [fp, #-0x10]
    // 0xdd0b58: r0 = Container()
    //     0xdd0b58: bl              #0x8a5af8  ; AllocateContainerStub -> Container (size=0x38)
    // 0xdd0b5c: stur            x0, [fp, #-0x20]
    // 0xdd0b60: ldur            x16, [fp, #-0x10]
    // 0xdd0b64: r30 = Instance_Color
    //     0xdd0b64: add             lr, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xdd0b68: ldr             lr, [lr, #0x810]
    // 0xdd0b6c: stp             lr, x16, [SP, #0x18]
    // 0xdd0b70: r16 = Instance_EdgeInsets
    //     0xdd0b70: add             x16, PP, #0xd4, lsl #12  ; [pp+0xd4050] Obj!EdgeInsets@129d2f1
    //     0xdd0b74: ldr             x16, [x16, #0x50]
    // 0xdd0b78: r30 = Instance_EdgeInsets
    //     0xdd0b78: add             lr, PP, #0xc6, lsl #12  ; [pp+0xc69d8] Obj!EdgeInsets@129cfc1
    //     0xdd0b7c: ldr             lr, [lr, #0x9d8]
    // 0xdd0b80: stp             lr, x16, [SP, #8]
    // 0xdd0b84: ldur            x16, [fp, #-0x18]
    // 0xdd0b88: str             x16, [SP]
    // 0xdd0b8c: mov             x1, x0
    // 0xdd0b90: r4 = const [0, 0x6, 0x5, 0x1, child, 0x5, color, 0x2, height, 0x1, margin, 0x4, padding, 0x3, null]
    //     0xdd0b90: add             x4, PP, #0xd4, lsl #12  ; [pp+0xd4028] List(15) [0, 0x6, 0x5, 0x1, "child", 0x5, "color", 0x2, "height", 0x1, "margin", 0x4, "padding", 0x3, Null]
    //     0xdd0b94: ldr             x4, [x4, #0x28]
    // 0xdd0b98: r0 = Container()
    //     0xdd0b98: bl              #0x8a54e0  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0xdd0b9c: r0 = GestureDetector()
    //     0xdd0b9c: bl              #0x918e18  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0xdd0ba0: ldur            x2, [fp, #-8]
    // 0xdd0ba4: r1 = Function '_skipForward@450205881':.
    //     0xdd0ba4: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd40b0] AnonymousClosure: (0xdd0bfc), in [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_skipForward (0xdd0c34)
    //     0xdd0ba8: ldr             x1, [x1, #0xb0]
    // 0xdd0bac: stur            x0, [fp, #-8]
    // 0xdd0bb0: r0 = AllocateClosure()
    //     0xdd0bb0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd0bb4: ldur            x16, [fp, #-0x20]
    // 0xdd0bb8: stp             x16, x0, [SP]
    // 0xdd0bbc: ldur            x1, [fp, #-8]
    // 0xdd0bc0: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0xdd0bc0: add             x4, PP, #0x16, lsl #12  ; [pp+0x16e90] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0xdd0bc4: ldr             x4, [x4, #0xe90]
    // 0xdd0bc8: r0 = GestureDetector()
    //     0xdd0bc8: bl              #0x9182dc  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0xdd0bcc: ldur            x0, [fp, #-8]
    // 0xdd0bd0: LeaveFrame
    //     0xdd0bd0: mov             SP, fp
    //     0xdd0bd4: ldp             fp, lr, [SP], #0x10
    // 0xdd0bd8: ret
    //     0xdd0bd8: ret             
    // 0xdd0bdc: r0 = StackOverflowSharedWithFPURegs()
    //     0xdd0bdc: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xdd0be0: b               #0xdd0af4
    // 0xdd0be4: SaveReg d0
    //     0xdd0be4: str             q0, [SP, #-0x10]!
    // 0xdd0be8: SaveReg r1
    //     0xdd0be8: str             x1, [SP, #-8]!
    // 0xdd0bec: r0 = AllocateDouble()
    //     0xdd0bec: bl              #0x13df878  ; AllocateDoubleStub
    // 0xdd0bf0: RestoreReg r1
    //     0xdd0bf0: ldr             x1, [SP], #8
    // 0xdd0bf4: RestoreReg d0
    //     0xdd0bf4: ldr             q0, [SP], #0x10
    // 0xdd0bf8: b               #0xdd0b50
  }
  [closure] Future<void> _skipForward(dynamic) {
    // ** addr: 0xdd0bfc, size: 0x38
    // 0xdd0bfc: EnterFrame
    //     0xdd0bfc: stp             fp, lr, [SP, #-0x10]!
    //     0xdd0c00: mov             fp, SP
    // 0xdd0c04: ldr             x0, [fp, #0x10]
    // 0xdd0c08: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdd0c08: ldur            w1, [x0, #0x17]
    // 0xdd0c0c: DecompressPointer r1
    //     0xdd0c0c: add             x1, x1, HEAP, lsl #32
    // 0xdd0c10: CheckStackOverflow
    //     0xdd0c10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd0c14: cmp             SP, x16
    //     0xdd0c18: b.ls            #0xdd0c2c
    // 0xdd0c1c: r0 = _skipForward()
    //     0xdd0c1c: bl              #0xdd0c34  ; [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_skipForward
    // 0xdd0c20: LeaveFrame
    //     0xdd0c20: mov             SP, fp
    //     0xdd0c24: ldp             fp, lr, [SP], #0x10
    // 0xdd0c28: ret
    //     0xdd0c28: ret             
    // 0xdd0c2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd0c2c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd0c30: b               #0xdd0c1c
  }
  _ _skipForward(/* No info */) async {
    // ** addr: 0xdd0c34, size: 0x130
    // 0xdd0c34: EnterFrame
    //     0xdd0c34: stp             fp, lr, [SP, #-0x10]!
    //     0xdd0c38: mov             fp, SP
    // 0xdd0c3c: AllocStack(0x30)
    //     0xdd0c3c: sub             SP, SP, #0x30
    // 0xdd0c40: SetupParameters(_CupertinoControlsState this /* r1 => r1, fp-0x10 */)
    //     0xdd0c40: stur            NULL, [fp, #-8]
    //     0xdd0c44: stur            x1, [fp, #-0x10]
    // 0xdd0c48: CheckStackOverflow
    //     0xdd0c48: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd0c4c: cmp             SP, x16
    //     0xdd0c50: b.ls            #0xdd0d44
    // 0xdd0c54: r1 = 1
    //     0xdd0c54: mov             x1, #1
    // 0xdd0c58: r0 = AllocateContext()
    //     0xdd0c58: bl              #0x13de838  ; AllocateContextStub
    // 0xdd0c5c: mov             x2, x0
    // 0xdd0c60: ldur            x1, [fp, #-0x10]
    // 0xdd0c64: stur            x2, [fp, #-0x18]
    // 0xdd0c68: StoreField: r2->field_f = r1
    //     0xdd0c68: stur            w1, [x2, #0xf]
    // 0xdd0c6c: InitAsync() -> Future<void?>
    //     0xdd0c6c: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0xdd0c70: bl              #0x7f5e44  ; InitAsyncStub
    // 0xdd0c74: ldur            x1, [fp, #-0x10]
    // 0xdd0c78: r0 = _cancelAndRestartTimer()
    //     0xdd0c78: bl              #0xdd0d64  ; [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_cancelAndRestartTimer
    // 0xdd0c7c: ldur            x0, [fp, #-0x10]
    // 0xdd0c80: LoadField: r1 = r0->field_1f
    //     0xdd0c80: ldur            w1, [x0, #0x1f]
    // 0xdd0c84: DecompressPointer r1
    //     0xdd0c84: add             x1, x1, HEAP, lsl #32
    // 0xdd0c88: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd0c8c: cmp             w1, w16
    // 0xdd0c90: b.eq            #0xdd0d4c
    // 0xdd0c94: LoadField: r2 = r1->field_7
    //     0xdd0c94: ldur            w2, [x1, #7]
    // 0xdd0c98: DecompressPointer r2
    //     0xdd0c98: add             x2, x2, HEAP, lsl #32
    // 0xdd0c9c: LoadField: r3 = r2->field_7
    //     0xdd0c9c: ldur            x3, [x2, #7]
    // 0xdd0ca0: r2 = 1000
    //     0xdd0ca0: mov             x2, #0x3e8
    // 0xdd0ca4: sdiv            x4, x3, x2
    // 0xdd0ca8: LoadField: r3 = r1->field_b
    //     0xdd0ca8: ldur            w3, [x1, #0xb]
    // 0xdd0cac: DecompressPointer r3
    //     0xdd0cac: add             x3, x3, HEAP, lsl #32
    // 0xdd0cb0: LoadField: r1 = r3->field_7
    //     0xdd0cb0: ldur            x1, [x3, #7]
    // 0xdd0cb4: r17 = 15000000
    //     0xdd0cb4: mov             x17, #0xe1c0
    //     0xdd0cb8: movk            x17, #0xe4, lsl #16
    // 0xdd0cbc: add             x3, x1, x17
    // 0xdd0cc0: sdiv            x1, x3, x2
    // 0xdd0cc4: LoadField: r2 = r0->field_53
    //     0xdd0cc4: ldur            w2, [x0, #0x53]
    // 0xdd0cc8: DecompressPointer r2
    //     0xdd0cc8: add             x2, x2, HEAP, lsl #32
    // 0xdd0ccc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd0cd0: cmp             w2, w16
    // 0xdd0cd4: b.eq            #0xdd0d58
    // 0xdd0cd8: stur            x2, [fp, #-0x28]
    // 0xdd0cdc: cmp             x1, x4
    // 0xdd0ce0: csel            x0, x4, x1, gt
    // 0xdd0ce4: r16 = 1000
    //     0xdd0ce4: mov             x16, #0x3e8
    // 0xdd0ce8: mul             x1, x0, x16
    // 0xdd0cec: stur            x1, [fp, #-0x20]
    // 0xdd0cf0: r0 = Duration()
    //     0xdd0cf0: bl              #0x7dd0d0  ; AllocateDurationStub -> Duration (size=0x10)
    // 0xdd0cf4: mov             x1, x0
    // 0xdd0cf8: ldur            x0, [fp, #-0x20]
    // 0xdd0cfc: StoreField: r1->field_7 = r0
    //     0xdd0cfc: stur            x0, [x1, #7]
    // 0xdd0d00: mov             x2, x1
    // 0xdd0d04: ldur            x1, [fp, #-0x28]
    // 0xdd0d08: r0 = seekTo()
    //     0xdd0d08: bl              #0x8d6e4c  ; [package:video_player/video_player.dart] VideoPlayerController::seekTo
    // 0xdd0d0c: mov             x1, x0
    // 0xdd0d10: stur            x1, [fp, #-0x10]
    // 0xdd0d14: r0 = Await()
    //     0xdd0d14: bl              #0x7f5c00  ; AwaitStub
    // 0xdd0d18: ldur            x2, [fp, #-0x18]
    // 0xdd0d1c: r1 = Function '<anonymous closure>':.
    //     0xdd0d1c: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd40b8] AnonymousClosure: (0xdd0ea0), in [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_skipForward (0xdd0c34)
    //     0xdd0d20: ldr             x1, [x1, #0xb8]
    // 0xdd0d24: r0 = AllocateClosure()
    //     0xdd0d24: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd0d28: str             x0, [SP]
    // 0xdd0d2c: r1 = <Null?>
    //     0xdd0d2c: ldr             x1, [PP, #0x70]  ; [pp+0x70] TypeArguments: <Null?>
    // 0xdd0d30: r2 = Instance_Duration
    //     0xdd0d30: ldr             x2, [PP, #0xa80]  ; [pp+0xa80] Obj!Duration@12c8921
    // 0xdd0d34: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0xdd0d34: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0xdd0d38: r0 = Future.delayed()
    //     0xdd0d38: bl              #0x82fe1c  ; [dart:async] Future::Future.delayed
    // 0xdd0d3c: r0 = Null
    //     0xdd0d3c: mov             x0, NULL
    // 0xdd0d40: r0 = ReturnAsyncNotFuture()
    //     0xdd0d40: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xdd0d44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd0d44: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd0d48: b               #0xdd0c54
    // 0xdd0d4c: r9 = _latestValue
    //     0xdd0d4c: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3ff0] Field <_CupertinoControlsState@450205881._latestValue@450205881>: late (offset: 0x20)
    //     0xdd0d50: ldr             x9, [x9, #0xff0]
    // 0xdd0d54: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd0d54: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdd0d58: r9 = controller
    //     0xdd0d58: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3fa0] Field <_CupertinoControlsState@450205881.controller>: late (offset: 0x54)
    //     0xdd0d5c: ldr             x9, [x9, #0xfa0]
    // 0xdd0d60: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd0d60: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _cancelAndRestartTimer(/* No info */) {
    // ** addr: 0xdd0d64, size: 0x7c
    // 0xdd0d64: EnterFrame
    //     0xdd0d64: stp             fp, lr, [SP, #-0x10]!
    //     0xdd0d68: mov             fp, SP
    // 0xdd0d6c: AllocStack(0x10)
    //     0xdd0d6c: sub             SP, SP, #0x10
    // 0xdd0d70: SetupParameters(_CupertinoControlsState this /* r1 => r1, fp-0x8 */)
    //     0xdd0d70: stur            x1, [fp, #-8]
    // 0xdd0d74: CheckStackOverflow
    //     0xdd0d74: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd0d78: cmp             SP, x16
    //     0xdd0d7c: b.ls            #0xdd0dd8
    // 0xdd0d80: r1 = 1
    //     0xdd0d80: mov             x1, #1
    // 0xdd0d84: r0 = AllocateContext()
    //     0xdd0d84: bl              #0x13de838  ; AllocateContextStub
    // 0xdd0d88: mov             x2, x0
    // 0xdd0d8c: ldur            x0, [fp, #-8]
    // 0xdd0d90: stur            x2, [fp, #-0x10]
    // 0xdd0d94: StoreField: r2->field_f = r0
    //     0xdd0d94: stur            w0, [x2, #0xf]
    // 0xdd0d98: LoadField: r1 = r0->field_27
    //     0xdd0d98: ldur            w1, [x0, #0x27]
    // 0xdd0d9c: DecompressPointer r1
    //     0xdd0d9c: add             x1, x1, HEAP, lsl #32
    // 0xdd0da0: cmp             w1, NULL
    // 0xdd0da4: b.eq            #0xdd0dac
    // 0xdd0da8: r0 = cancel()
    //     0xdd0da8: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0xdd0dac: ldur            x2, [fp, #-0x10]
    // 0xdd0db0: r1 = Function '<anonymous closure>':.
    //     0xdd0db0: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3ff8] AnonymousClosure: (0xdd0e18), in [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_cancelAndRestartTimer (0xdd0d64)
    //     0xdd0db4: ldr             x1, [x1, #0xff8]
    // 0xdd0db8: r0 = AllocateClosure()
    //     0xdd0db8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd0dbc: ldur            x1, [fp, #-8]
    // 0xdd0dc0: mov             x2, x0
    // 0xdd0dc4: r0 = setState()
    //     0xdd0dc4: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xdd0dc8: r0 = Null
    //     0xdd0dc8: mov             x0, NULL
    // 0xdd0dcc: LeaveFrame
    //     0xdd0dcc: mov             SP, fp
    //     0xdd0dd0: ldp             fp, lr, [SP], #0x10
    // 0xdd0dd4: ret
    //     0xdd0dd4: ret             
    // 0xdd0dd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd0dd8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd0ddc: b               #0xdd0d80
  }
  [closure] void _cancelAndRestartTimer(dynamic) {
    // ** addr: 0xdd0de0, size: 0x38
    // 0xdd0de0: EnterFrame
    //     0xdd0de0: stp             fp, lr, [SP, #-0x10]!
    //     0xdd0de4: mov             fp, SP
    // 0xdd0de8: ldr             x0, [fp, #0x10]
    // 0xdd0dec: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdd0dec: ldur            w1, [x0, #0x17]
    // 0xdd0df0: DecompressPointer r1
    //     0xdd0df0: add             x1, x1, HEAP, lsl #32
    // 0xdd0df4: CheckStackOverflow
    //     0xdd0df4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd0df8: cmp             SP, x16
    //     0xdd0dfc: b.ls            #0xdd0e10
    // 0xdd0e00: r0 = _cancelAndRestartTimer()
    //     0xdd0e00: bl              #0xdd0d64  ; [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_cancelAndRestartTimer
    // 0xdd0e04: LeaveFrame
    //     0xdd0e04: mov             SP, fp
    //     0xdd0e08: ldp             fp, lr, [SP], #0x10
    // 0xdd0e0c: ret
    //     0xdd0e0c: ret             
    // 0xdd0e10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd0e10: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd0e14: b               #0xdd0e00
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xdd0e18, size: 0x88
    // 0xdd0e18: EnterFrame
    //     0xdd0e18: stp             fp, lr, [SP, #-0x10]!
    //     0xdd0e1c: mov             fp, SP
    // 0xdd0e20: AllocStack(0x8)
    //     0xdd0e20: sub             SP, SP, #8
    // 0xdd0e24: SetupParameters([dynamic _ /* r1 */])
    //     0xdd0e24: add             x0, NULL, #0x30  ; false
    //     0xdd0e28: ldr             x1, [fp, #0x10]
    //     0xdd0e2c: ldur            w2, [x1, #0x17]
    //     0xdd0e30: add             x2, x2, HEAP, lsl #32
    //     0xdd0e34: stur            x2, [fp, #-8]
    // 0xdd0e24: r0 = false
    // 0xdd0e38: CheckStackOverflow
    //     0xdd0e38: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd0e3c: cmp             SP, x16
    //     0xdd0e40: b.ls            #0xdd0e8c
    // 0xdd0e44: LoadField: r1 = r2->field_f
    //     0xdd0e44: ldur            w1, [x2, #0xf]
    // 0xdd0e48: DecompressPointer r1
    //     0xdd0e48: add             x1, x1, HEAP, lsl #32
    // 0xdd0e4c: LoadField: r3 = r1->field_1b
    //     0xdd0e4c: ldur            w3, [x1, #0x1b]
    // 0xdd0e50: DecompressPointer r3
    //     0xdd0e50: add             x3, x3, HEAP, lsl #32
    // 0xdd0e54: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd0e58: cmp             w3, w16
    // 0xdd0e5c: b.eq            #0xdd0e94
    // 0xdd0e60: StoreField: r3->field_23 = r0
    //     0xdd0e60: stur            w0, [x3, #0x23]
    // 0xdd0e64: mov             x1, x3
    // 0xdd0e68: r0 = notifyListeners()
    //     0xdd0e68: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xdd0e6c: ldur            x0, [fp, #-8]
    // 0xdd0e70: LoadField: r1 = r0->field_f
    //     0xdd0e70: ldur            w1, [x0, #0xf]
    // 0xdd0e74: DecompressPointer r1
    //     0xdd0e74: add             x1, x1, HEAP, lsl #32
    // 0xdd0e78: r0 = _startHideTimer()
    //     0xdd0e78: bl              #0xdce790  ; [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_startHideTimer
    // 0xdd0e7c: r0 = Null
    //     0xdd0e7c: mov             x0, NULL
    // 0xdd0e80: LeaveFrame
    //     0xdd0e80: mov             SP, fp
    //     0xdd0e84: ldp             fp, lr, [SP], #0x10
    // 0xdd0e88: ret
    //     0xdd0e88: ret             
    // 0xdd0e8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd0e8c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd0e90: b               #0xdd0e44
    // 0xdd0e94: r9 = notifier
    //     0xdd0e94: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3fb0] Field <_CupertinoControlsState@450205881.notifier>: late (offset: 0x1c)
    //     0xdd0e98: ldr             x9, [x9, #0xfb0]
    // 0xdd0e9c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd0e9c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Null <anonymous closure>(dynamic) {
    // ** addr: 0xdd0ea0, size: 0x68
    // 0xdd0ea0: EnterFrame
    //     0xdd0ea0: stp             fp, lr, [SP, #-0x10]!
    //     0xdd0ea4: mov             fp, SP
    // 0xdd0ea8: ldr             x0, [fp, #0x10]
    // 0xdd0eac: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdd0eac: ldur            w1, [x0, #0x17]
    // 0xdd0eb0: DecompressPointer r1
    //     0xdd0eb0: add             x1, x1, HEAP, lsl #32
    // 0xdd0eb4: CheckStackOverflow
    //     0xdd0eb4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd0eb8: cmp             SP, x16
    //     0xdd0ebc: b.ls            #0xdd0ef4
    // 0xdd0ec0: LoadField: r0 = r1->field_f
    //     0xdd0ec0: ldur            w0, [x1, #0xf]
    // 0xdd0ec4: DecompressPointer r0
    //     0xdd0ec4: add             x0, x0, HEAP, lsl #32
    // 0xdd0ec8: LoadField: r1 = r0->field_53
    //     0xdd0ec8: ldur            w1, [x0, #0x53]
    // 0xdd0ecc: DecompressPointer r1
    //     0xdd0ecc: add             x1, x1, HEAP, lsl #32
    // 0xdd0ed0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd0ed4: cmp             w1, w16
    // 0xdd0ed8: b.eq            #0xdd0efc
    // 0xdd0edc: LoadField: d0 = r0->field_4b
    //     0xdd0edc: ldur            d0, [x0, #0x4b]
    // 0xdd0ee0: r0 = setPlaybackSpeed()
    //     0xdd0ee0: bl              #0xdcf0e8  ; [package:video_player/video_player.dart] VideoPlayerController::setPlaybackSpeed
    // 0xdd0ee4: r0 = Null
    //     0xdd0ee4: mov             x0, NULL
    // 0xdd0ee8: LeaveFrame
    //     0xdd0ee8: mov             SP, fp
    //     0xdd0eec: ldp             fp, lr, [SP], #0x10
    // 0xdd0ef0: ret
    //     0xdd0ef0: ret             
    // 0xdd0ef4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd0ef4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd0ef8: b               #0xdd0ec0
    // 0xdd0efc: r9 = controller
    //     0xdd0efc: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3fa0] Field <_CupertinoControlsState@450205881.controller>: late (offset: 0x54)
    //     0xdd0f00: ldr             x9, [x9, #0xfa0]
    // 0xdd0f04: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd0f04: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _buildPlayPause(/* No info */) {
    // ** addr: 0xdd0f08, size: 0x138
    // 0xdd0f08: EnterFrame
    //     0xdd0f08: stp             fp, lr, [SP, #-0x10]!
    //     0xdd0f0c: mov             fp, SP
    // 0xdd0f10: AllocStack(0x48)
    //     0xdd0f10: sub             SP, SP, #0x48
    // 0xdd0f14: SetupParameters(_CupertinoControlsState this /* r1 => r0, fp-0x10 */, dynamic _ /* d0 => d0, fp-0x28 */)
    //     0xdd0f14: mov             x0, x1
    //     0xdd0f18: stur            x1, [fp, #-0x10]
    //     0xdd0f1c: stur            d0, [fp, #-0x28]
    // 0xdd0f20: CheckStackOverflow
    //     0xdd0f20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd0f24: cmp             SP, x16
    //     0xdd0f28: b.ls            #0xdd101c
    // 0xdd0f2c: LoadField: r1 = r0->field_b
    //     0xdd0f2c: ldur            w1, [x0, #0xb]
    // 0xdd0f30: DecompressPointer r1
    //     0xdd0f30: add             x1, x1, HEAP, lsl #32
    // 0xdd0f34: cmp             w1, NULL
    // 0xdd0f38: b.eq            #0xdd1024
    // 0xdd0f3c: LoadField: r1 = r2->field_27
    //     0xdd0f3c: ldur            w1, [x2, #0x27]
    // 0xdd0f40: DecompressPointer r1
    //     0xdd0f40: add             x1, x1, HEAP, lsl #32
    // 0xdd0f44: LoadField: r2 = r1->field_1b
    //     0xdd0f44: ldur            w2, [x1, #0x1b]
    // 0xdd0f48: DecompressPointer r2
    //     0xdd0f48: add             x2, x2, HEAP, lsl #32
    // 0xdd0f4c: stur            x2, [fp, #-8]
    // 0xdd0f50: r0 = AnimatedPlayPause()
    //     0xdd0f50: bl              #0xdd1040  ; AllocateAnimatedPlayPauseStub -> AnimatedPlayPause (size=0x18)
    // 0xdd0f54: mov             x1, x0
    // 0xdd0f58: ldur            x0, [fp, #-8]
    // 0xdd0f5c: stur            x1, [fp, #-0x18]
    // 0xdd0f60: StoreField: r1->field_f = r0
    //     0xdd0f60: stur            w0, [x1, #0xf]
    // 0xdd0f64: r0 = Instance_Color
    //     0xdd0f64: add             x0, PP, #0xd4, lsl #12  ; [pp+0xd4010] Obj!Color@12a3ba1
    //     0xdd0f68: ldr             x0, [x0, #0x10]
    // 0xdd0f6c: StoreField: r1->field_13 = r0
    //     0xdd0f6c: stur            w0, [x1, #0x13]
    // 0xdd0f70: ldur            d0, [fp, #-0x28]
    // 0xdd0f74: r0 = inline_Allocate_Double()
    //     0xdd0f74: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xdd0f78: add             x0, x0, #0x10
    //     0xdd0f7c: cmp             x2, x0
    //     0xdd0f80: b.ls            #0xdd1028
    //     0xdd0f84: str             x0, [THR, #0x60]  ; THR::top
    //     0xdd0f88: sub             x0, x0, #0xf
    //     0xdd0f8c: mov             x2, #0xe19c
    //     0xdd0f90: movk            x2, #3, lsl #16
    //     0xdd0f94: stur            x2, [x0, #-1]
    // 0xdd0f98: dmb             ishst
    // 0xdd0f9c: StoreField: r0->field_7 = d0
    //     0xdd0f9c: stur            d0, [x0, #7]
    // 0xdd0fa0: stur            x0, [fp, #-8]
    // 0xdd0fa4: r0 = Container()
    //     0xdd0fa4: bl              #0x8a5af8  ; AllocateContainerStub -> Container (size=0x38)
    // 0xdd0fa8: stur            x0, [fp, #-0x20]
    // 0xdd0fac: ldur            x16, [fp, #-8]
    // 0xdd0fb0: r30 = Instance_Color
    //     0xdd0fb0: add             lr, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xdd0fb4: ldr             lr, [lr, #0x810]
    // 0xdd0fb8: stp             lr, x16, [SP, #0x10]
    // 0xdd0fbc: r16 = Instance_EdgeInsets
    //     0xdd0fbc: add             x16, PP, #0xd4, lsl #12  ; [pp+0xd40c0] Obj!EdgeInsets@129d381
    //     0xdd0fc0: ldr             x16, [x16, #0xc0]
    // 0xdd0fc4: ldur            lr, [fp, #-0x18]
    // 0xdd0fc8: stp             lr, x16, [SP]
    // 0xdd0fcc: mov             x1, x0
    // 0xdd0fd0: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, color, 0x2, height, 0x1, padding, 0x3, null]
    //     0xdd0fd0: add             x4, PP, #0xd4, lsl #12  ; [pp+0xd40c8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "color", 0x2, "height", 0x1, "padding", 0x3, Null]
    //     0xdd0fd4: ldr             x4, [x4, #0xc8]
    // 0xdd0fd8: r0 = Container()
    //     0xdd0fd8: bl              #0x8a54e0  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0xdd0fdc: r0 = GestureDetector()
    //     0xdd0fdc: bl              #0x918e18  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0xdd0fe0: ldur            x2, [fp, #-0x10]
    // 0xdd0fe4: r1 = Function '_playPause@450205881':.
    //     0xdd0fe4: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd40d0] AnonymousClosure: (0xdd104c), in [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_playPause (0xdd1084)
    //     0xdd0fe8: ldr             x1, [x1, #0xd0]
    // 0xdd0fec: stur            x0, [fp, #-8]
    // 0xdd0ff0: r0 = AllocateClosure()
    //     0xdd0ff0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd0ff4: ldur            x16, [fp, #-0x20]
    // 0xdd0ff8: stp             x16, x0, [SP]
    // 0xdd0ffc: ldur            x1, [fp, #-8]
    // 0xdd1000: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0xdd1000: add             x4, PP, #0x16, lsl #12  ; [pp+0x16e90] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0xdd1004: ldr             x4, [x4, #0xe90]
    // 0xdd1008: r0 = GestureDetector()
    //     0xdd1008: bl              #0x9182dc  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0xdd100c: ldur            x0, [fp, #-8]
    // 0xdd1010: LeaveFrame
    //     0xdd1010: mov             SP, fp
    //     0xdd1014: ldp             fp, lr, [SP], #0x10
    // 0xdd1018: ret
    //     0xdd1018: ret             
    // 0xdd101c: r0 = StackOverflowSharedWithFPURegs()
    //     0xdd101c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xdd1020: b               #0xdd0f2c
    // 0xdd1024: r0 = NullCastErrorSharedWithFPURegs()
    //     0xdd1024: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xdd1028: SaveReg d0
    //     0xdd1028: str             q0, [SP, #-0x10]!
    // 0xdd102c: SaveReg r1
    //     0xdd102c: str             x1, [SP, #-8]!
    // 0xdd1030: r0 = AllocateDouble()
    //     0xdd1030: bl              #0x13df878  ; AllocateDoubleStub
    // 0xdd1034: RestoreReg r1
    //     0xdd1034: ldr             x1, [SP], #8
    // 0xdd1038: RestoreReg d0
    //     0xdd1038: ldr             q0, [SP], #0x10
    // 0xdd103c: b               #0xdd0f9c
  }
  [closure] void _playPause(dynamic) {
    // ** addr: 0xdd104c, size: 0x38
    // 0xdd104c: EnterFrame
    //     0xdd104c: stp             fp, lr, [SP, #-0x10]!
    //     0xdd1050: mov             fp, SP
    // 0xdd1054: ldr             x0, [fp, #0x10]
    // 0xdd1058: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdd1058: ldur            w1, [x0, #0x17]
    // 0xdd105c: DecompressPointer r1
    //     0xdd105c: add             x1, x1, HEAP, lsl #32
    // 0xdd1060: CheckStackOverflow
    //     0xdd1060: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd1064: cmp             SP, x16
    //     0xdd1068: b.ls            #0xdd107c
    // 0xdd106c: r0 = _playPause()
    //     0xdd106c: bl              #0xdd1084  ; [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_playPause
    // 0xdd1070: LeaveFrame
    //     0xdd1070: mov             SP, fp
    //     0xdd1074: ldp             fp, lr, [SP], #0x10
    // 0xdd1078: ret
    //     0xdd1078: ret             
    // 0xdd107c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd107c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd1080: b               #0xdd106c
  }
  _ _playPause(/* No info */) {
    // ** addr: 0xdd1084, size: 0xcc
    // 0xdd1084: EnterFrame
    //     0xdd1084: stp             fp, lr, [SP, #-0x10]!
    //     0xdd1088: mov             fp, SP
    // 0xdd108c: AllocStack(0x8)
    //     0xdd108c: sub             SP, SP, #8
    // 0xdd1090: SetupParameters(_CupertinoControlsState this /* r1 => r1, fp-0x8 */)
    //     0xdd1090: stur            x1, [fp, #-8]
    // 0xdd1094: CheckStackOverflow
    //     0xdd1094: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd1098: cmp             SP, x16
    //     0xdd109c: b.ls            #0xdd113c
    // 0xdd10a0: r1 = 2
    //     0xdd10a0: mov             x1, #2
    // 0xdd10a4: r0 = AllocateContext()
    //     0xdd10a4: bl              #0x13de838  ; AllocateContextStub
    // 0xdd10a8: mov             x1, x0
    // 0xdd10ac: ldur            x0, [fp, #-8]
    // 0xdd10b0: StoreField: r1->field_f = r0
    //     0xdd10b0: stur            w0, [x1, #0xf]
    // 0xdd10b4: LoadField: r2 = r0->field_1f
    //     0xdd10b4: ldur            w2, [x0, #0x1f]
    // 0xdd10b8: DecompressPointer r2
    //     0xdd10b8: add             x2, x2, HEAP, lsl #32
    // 0xdd10bc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd10c0: cmp             w2, w16
    // 0xdd10c4: b.eq            #0xdd1144
    // 0xdd10c8: LoadField: r3 = r2->field_b
    //     0xdd10c8: ldur            w3, [x2, #0xb]
    // 0xdd10cc: DecompressPointer r3
    //     0xdd10cc: add             x3, x3, HEAP, lsl #32
    // 0xdd10d0: LoadField: r4 = r2->field_7
    //     0xdd10d0: ldur            w4, [x2, #7]
    // 0xdd10d4: DecompressPointer r4
    //     0xdd10d4: add             x4, x4, HEAP, lsl #32
    // 0xdd10d8: LoadField: r2 = r3->field_7
    //     0xdd10d8: ldur            x2, [x3, #7]
    // 0xdd10dc: LoadField: r3 = r4->field_7
    //     0xdd10dc: ldur            x3, [x4, #7]
    // 0xdd10e0: cmp             x2, x3
    // 0xdd10e4: b.lt            #0xdd1108
    // 0xdd10e8: r2 = 1000000
    //     0xdd10e8: mov             x2, #0x4240
    //     0xdd10ec: movk            x2, #0xf, lsl #16
    // 0xdd10f0: sdiv            x4, x3, x2
    // 0xdd10f4: cmp             x4, #0
    // 0xdd10f8: r16 = true
    //     0xdd10f8: add             x16, NULL, #0x20  ; true
    // 0xdd10fc: r17 = false
    //     0xdd10fc: add             x17, NULL, #0x30  ; false
    // 0xdd1100: csel            x2, x16, x17, gt
    // 0xdd1104: b               #0xdd110c
    // 0xdd1108: r2 = false
    //     0xdd1108: add             x2, NULL, #0x30  ; false
    // 0xdd110c: StoreField: r1->field_13 = r2
    //     0xdd110c: stur            w2, [x1, #0x13]
    // 0xdd1110: mov             x2, x1
    // 0xdd1114: r1 = Function '<anonymous closure>':.
    //     0xdd1114: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd40d8] AnonymousClosure: (0xdd1150), in [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_playPause (0xdd1084)
    //     0xdd1118: ldr             x1, [x1, #0xd8]
    // 0xdd111c: r0 = AllocateClosure()
    //     0xdd111c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd1120: ldur            x1, [fp, #-8]
    // 0xdd1124: mov             x2, x0
    // 0xdd1128: r0 = setState()
    //     0xdd1128: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xdd112c: r0 = Null
    //     0xdd112c: mov             x0, NULL
    // 0xdd1130: LeaveFrame
    //     0xdd1130: mov             SP, fp
    //     0xdd1134: ldp             fp, lr, [SP], #0x10
    // 0xdd1138: ret
    //     0xdd1138: ret             
    // 0xdd113c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd113c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd1140: b               #0xdd10a0
    // 0xdd1144: r9 = _latestValue
    //     0xdd1144: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3ff0] Field <_CupertinoControlsState@450205881._latestValue@450205881>: late (offset: 0x20)
    //     0xdd1148: ldr             x9, [x9, #0xff0]
    // 0xdd114c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd114c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xdd1150, size: 0x1c4
    // 0xdd1150: EnterFrame
    //     0xdd1150: stp             fp, lr, [SP, #-0x10]!
    //     0xdd1154: mov             fp, SP
    // 0xdd1158: AllocStack(0x28)
    //     0xdd1158: sub             SP, SP, #0x28
    // 0xdd115c: SetupParameters([dynamic _ /* r0 */])
    //     0xdd115c: ldr             x0, [fp, #0x10]
    //     0xdd1160: ldur            w2, [x0, #0x17]
    //     0xdd1164: add             x2, x2, HEAP, lsl #32
    //     0xdd1168: stur            x2, [fp, #-8]
    // 0xdd116c: CheckStackOverflow
    //     0xdd116c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd1170: cmp             SP, x16
    //     0xdd1174: b.ls            #0xdd12d0
    // 0xdd1178: LoadField: r1 = r2->field_f
    //     0xdd1178: ldur            w1, [x2, #0xf]
    // 0xdd117c: DecompressPointer r1
    //     0xdd117c: add             x1, x1, HEAP, lsl #32
    // 0xdd1180: LoadField: r0 = r1->field_53
    //     0xdd1180: ldur            w0, [x1, #0x53]
    // 0xdd1184: DecompressPointer r0
    //     0xdd1184: add             x0, x0, HEAP, lsl #32
    // 0xdd1188: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd118c: cmp             w0, w16
    // 0xdd1190: b.eq            #0xdd12d8
    // 0xdd1194: LoadField: r3 = r0->field_27
    //     0xdd1194: ldur            w3, [x0, #0x27]
    // 0xdd1198: DecompressPointer r3
    //     0xdd1198: add             x3, x3, HEAP, lsl #32
    // 0xdd119c: LoadField: r0 = r3->field_1b
    //     0xdd119c: ldur            w0, [x3, #0x1b]
    // 0xdd11a0: DecompressPointer r0
    //     0xdd11a0: add             x0, x0, HEAP, lsl #32
    // 0xdd11a4: tbnz            w0, #4, #0xdd1214
    // 0xdd11a8: r0 = false
    //     0xdd11a8: add             x0, NULL, #0x30  ; false
    // 0xdd11ac: LoadField: r3 = r1->field_1b
    //     0xdd11ac: ldur            w3, [x1, #0x1b]
    // 0xdd11b0: DecompressPointer r3
    //     0xdd11b0: add             x3, x3, HEAP, lsl #32
    // 0xdd11b4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd11b8: cmp             w3, w16
    // 0xdd11bc: b.eq            #0xdd12e4
    // 0xdd11c0: StoreField: r3->field_23 = r0
    //     0xdd11c0: stur            w0, [x3, #0x23]
    // 0xdd11c4: mov             x1, x3
    // 0xdd11c8: r0 = notifyListeners()
    //     0xdd11c8: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xdd11cc: ldur            x2, [fp, #-8]
    // 0xdd11d0: LoadField: r0 = r2->field_f
    //     0xdd11d0: ldur            w0, [x2, #0xf]
    // 0xdd11d4: DecompressPointer r0
    //     0xdd11d4: add             x0, x0, HEAP, lsl #32
    // 0xdd11d8: LoadField: r1 = r0->field_27
    //     0xdd11d8: ldur            w1, [x0, #0x27]
    // 0xdd11dc: DecompressPointer r1
    //     0xdd11dc: add             x1, x1, HEAP, lsl #32
    // 0xdd11e0: cmp             w1, NULL
    // 0xdd11e4: b.eq            #0xdd11f0
    // 0xdd11e8: r0 = cancel()
    //     0xdd11e8: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0xdd11ec: ldur            x2, [fp, #-8]
    // 0xdd11f0: LoadField: r0 = r2->field_f
    //     0xdd11f0: ldur            w0, [x2, #0xf]
    // 0xdd11f4: DecompressPointer r0
    //     0xdd11f4: add             x0, x0, HEAP, lsl #32
    // 0xdd11f8: LoadField: r1 = r0->field_53
    //     0xdd11f8: ldur            w1, [x0, #0x53]
    // 0xdd11fc: DecompressPointer r1
    //     0xdd11fc: add             x1, x1, HEAP, lsl #32
    // 0xdd1200: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd1204: cmp             w1, w16
    // 0xdd1208: b.eq            #0xdd12f0
    // 0xdd120c: r0 = pause()
    //     0xdd120c: bl              #0x8d70ec  ; [package:video_player/video_player.dart] VideoPlayerController::pause
    // 0xdd1210: b               #0xdd12c0
    // 0xdd1214: r0 = _cancelAndRestartTimer()
    //     0xdd1214: bl              #0xdd0d64  ; [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_cancelAndRestartTimer
    // 0xdd1218: ldur            x2, [fp, #-8]
    // 0xdd121c: LoadField: r0 = r2->field_f
    //     0xdd121c: ldur            w0, [x2, #0xf]
    // 0xdd1220: DecompressPointer r0
    //     0xdd1220: add             x0, x0, HEAP, lsl #32
    // 0xdd1224: LoadField: r1 = r0->field_53
    //     0xdd1224: ldur            w1, [x0, #0x53]
    // 0xdd1228: DecompressPointer r1
    //     0xdd1228: add             x1, x1, HEAP, lsl #32
    // 0xdd122c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd1230: cmp             w1, w16
    // 0xdd1234: b.eq            #0xdd12fc
    // 0xdd1238: LoadField: r0 = r1->field_27
    //     0xdd1238: ldur            w0, [x1, #0x27]
    // 0xdd123c: DecompressPointer r0
    //     0xdd123c: add             x0, x0, HEAP, lsl #32
    // 0xdd1240: LoadField: r3 = r0->field_4f
    //     0xdd1240: ldur            w3, [x0, #0x4f]
    // 0xdd1244: DecompressPointer r3
    //     0xdd1244: add             x3, x3, HEAP, lsl #32
    // 0xdd1248: tbz             w3, #4, #0xdd1280
    // 0xdd124c: r0 = initialize()
    //     0xdd124c: bl              #0xdd1314  ; [package:video_player/video_player.dart] VideoPlayerController::initialize
    // 0xdd1250: ldur            x2, [fp, #-8]
    // 0xdd1254: r1 = Function '<anonymous closure>':.
    //     0xdd1254: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd40e0] AnonymousClosure: (0xdd215c), in [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_playPause (0xdd1084)
    //     0xdd1258: ldr             x1, [x1, #0xe0]
    // 0xdd125c: stur            x0, [fp, #-0x10]
    // 0xdd1260: r0 = AllocateClosure()
    //     0xdd1260: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd1264: r16 = <Null?>
    //     0xdd1264: ldr             x16, [PP, #0x70]  ; [pp+0x70] TypeArguments: <Null?>
    // 0xdd1268: ldur            lr, [fp, #-0x10]
    // 0xdd126c: stp             lr, x16, [SP, #8]
    // 0xdd1270: str             x0, [SP]
    // 0xdd1274: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xdd1274: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xdd1278: r0 = then()
    //     0xdd1278: bl              #0x1293070  ; [dart:async] _Future::then
    // 0xdd127c: b               #0xdd12c0
    // 0xdd1280: mov             x0, x2
    // 0xdd1284: LoadField: r2 = r0->field_13
    //     0xdd1284: ldur            w2, [x0, #0x13]
    // 0xdd1288: DecompressPointer r2
    //     0xdd1288: add             x2, x2, HEAP, lsl #32
    // 0xdd128c: tbnz            w2, #4, #0xdd1298
    // 0xdd1290: r2 = Instance_Duration
    //     0xdd1290: ldr             x2, [PP, #0x1808]  ; [pp+0x1808] Obj!Duration@12c8901
    // 0xdd1294: r0 = seekTo()
    //     0xdd1294: bl              #0x8d6e4c  ; [package:video_player/video_player.dart] VideoPlayerController::seekTo
    // 0xdd1298: ldur            x0, [fp, #-8]
    // 0xdd129c: LoadField: r1 = r0->field_f
    //     0xdd129c: ldur            w1, [x0, #0xf]
    // 0xdd12a0: DecompressPointer r1
    //     0xdd12a0: add             x1, x1, HEAP, lsl #32
    // 0xdd12a4: LoadField: r0 = r1->field_53
    //     0xdd12a4: ldur            w0, [x1, #0x53]
    // 0xdd12a8: DecompressPointer r0
    //     0xdd12a8: add             x0, x0, HEAP, lsl #32
    // 0xdd12ac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd12b0: cmp             w0, w16
    // 0xdd12b4: b.eq            #0xdd1308
    // 0xdd12b8: mov             x1, x0
    // 0xdd12bc: r0 = play()
    //     0xdd12bc: bl              #0x8d57ac  ; [package:video_player/video_player.dart] VideoPlayerController::play
    // 0xdd12c0: r0 = Null
    //     0xdd12c0: mov             x0, NULL
    // 0xdd12c4: LeaveFrame
    //     0xdd12c4: mov             SP, fp
    //     0xdd12c8: ldp             fp, lr, [SP], #0x10
    // 0xdd12cc: ret
    //     0xdd12cc: ret             
    // 0xdd12d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd12d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd12d4: b               #0xdd1178
    // 0xdd12d8: r9 = controller
    //     0xdd12d8: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3fa0] Field <_CupertinoControlsState@450205881.controller>: late (offset: 0x54)
    //     0xdd12dc: ldr             x9, [x9, #0xfa0]
    // 0xdd12e0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd12e0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdd12e4: r9 = notifier
    //     0xdd12e4: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3fb0] Field <_CupertinoControlsState@450205881.notifier>: late (offset: 0x1c)
    //     0xdd12e8: ldr             x9, [x9, #0xfb0]
    // 0xdd12ec: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd12ec: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdd12f0: r9 = controller
    //     0xdd12f0: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3fa0] Field <_CupertinoControlsState@450205881.controller>: late (offset: 0x54)
    //     0xdd12f4: ldr             x9, [x9, #0xfa0]
    // 0xdd12f8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd12f8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdd12fc: r9 = controller
    //     0xdd12fc: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3fa0] Field <_CupertinoControlsState@450205881.controller>: late (offset: 0x54)
    //     0xdd1300: ldr             x9, [x9, #0xfa0]
    // 0xdd1304: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd1304: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdd1308: r9 = controller
    //     0xdd1308: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3fa0] Field <_CupertinoControlsState@450205881.controller>: late (offset: 0x54)
    //     0xdd130c: ldr             x9, [x9, #0xfa0]
    // 0xdd1310: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd1310: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Null <anonymous closure>(dynamic, void) {
    // ** addr: 0xdd215c, size: 0x64
    // 0xdd215c: EnterFrame
    //     0xdd215c: stp             fp, lr, [SP, #-0x10]!
    //     0xdd2160: mov             fp, SP
    // 0xdd2164: ldr             x0, [fp, #0x18]
    // 0xdd2168: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdd2168: ldur            w1, [x0, #0x17]
    // 0xdd216c: DecompressPointer r1
    //     0xdd216c: add             x1, x1, HEAP, lsl #32
    // 0xdd2170: CheckStackOverflow
    //     0xdd2170: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd2174: cmp             SP, x16
    //     0xdd2178: b.ls            #0xdd21ac
    // 0xdd217c: LoadField: r0 = r1->field_f
    //     0xdd217c: ldur            w0, [x1, #0xf]
    // 0xdd2180: DecompressPointer r0
    //     0xdd2180: add             x0, x0, HEAP, lsl #32
    // 0xdd2184: LoadField: r1 = r0->field_53
    //     0xdd2184: ldur            w1, [x0, #0x53]
    // 0xdd2188: DecompressPointer r1
    //     0xdd2188: add             x1, x1, HEAP, lsl #32
    // 0xdd218c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd2190: cmp             w1, w16
    // 0xdd2194: b.eq            #0xdd21b4
    // 0xdd2198: r0 = play()
    //     0xdd2198: bl              #0x8d57ac  ; [package:video_player/video_player.dart] VideoPlayerController::play
    // 0xdd219c: r0 = Null
    //     0xdd219c: mov             x0, NULL
    // 0xdd21a0: LeaveFrame
    //     0xdd21a0: mov             SP, fp
    //     0xdd21a4: ldp             fp, lr, [SP], #0x10
    // 0xdd21a8: ret
    //     0xdd21a8: ret             
    // 0xdd21ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd21ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd21b0: b               #0xdd217c
    // 0xdd21b4: r9 = controller
    //     0xdd21b4: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3fa0] Field <_CupertinoControlsState@450205881.controller>: late (offset: 0x54)
    //     0xdd21b8: ldr             x9, [x9, #0xfa0]
    // 0xdd21bc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd21bc: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _buildSkipBack(/* No info */) {
    // ** addr: 0xdd21c0, size: 0x12c
    // 0xdd21c0: EnterFrame
    //     0xdd21c0: stp             fp, lr, [SP, #-0x10]!
    //     0xdd21c4: mov             fp, SP
    // 0xdd21c8: AllocStack(0x50)
    //     0xdd21c8: sub             SP, SP, #0x50
    // 0xdd21cc: SetupParameters(_CupertinoControlsState this /* r1 => r2, fp-0x8 */, dynamic _ /* d0 => d0, fp-0x28 */)
    //     0xdd21cc: mov             x2, x1
    //     0xdd21d0: stur            x1, [fp, #-8]
    //     0xdd21d4: stur            d0, [fp, #-0x28]
    // 0xdd21d8: CheckStackOverflow
    //     0xdd21d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd21dc: cmp             SP, x16
    //     0xdd21e0: b.ls            #0xdd22cc
    // 0xdd21e4: r0 = Icon()
    //     0xdd21e4: bl              #0xd0fd5c  ; AllocateIconStub -> Icon (size=0x40)
    // 0xdd21e8: mov             x1, x0
    // 0xdd21ec: r0 = Instance_IconData
    //     0xdd21ec: add             x0, PP, #0xd4, lsl #12  ; [pp+0xd40e8] Obj!IconData@128a671
    //     0xdd21f0: ldr             x0, [x0, #0xe8]
    // 0xdd21f4: stur            x1, [fp, #-0x18]
    // 0xdd21f8: StoreField: r1->field_b = r0
    //     0xdd21f8: stur            w0, [x1, #0xb]
    // 0xdd21fc: r0 = 18.000000
    //     0xdd21fc: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e530] 18
    //     0xdd2200: ldr             x0, [x0, #0x530]
    // 0xdd2204: StoreField: r1->field_f = r0
    //     0xdd2204: stur            w0, [x1, #0xf]
    // 0xdd2208: r0 = Instance_Color
    //     0xdd2208: add             x0, PP, #0xd4, lsl #12  ; [pp+0xd4010] Obj!Color@12a3ba1
    //     0xdd220c: ldr             x0, [x0, #0x10]
    // 0xdd2210: StoreField: r1->field_23 = r0
    //     0xdd2210: stur            w0, [x1, #0x23]
    // 0xdd2214: ldur            d0, [fp, #-0x28]
    // 0xdd2218: r0 = inline_Allocate_Double()
    //     0xdd2218: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xdd221c: add             x0, x0, #0x10
    //     0xdd2220: cmp             x2, x0
    //     0xdd2224: b.ls            #0xdd22d4
    //     0xdd2228: str             x0, [THR, #0x60]  ; THR::top
    //     0xdd222c: sub             x0, x0, #0xf
    //     0xdd2230: mov             x2, #0xe19c
    //     0xdd2234: movk            x2, #3, lsl #16
    //     0xdd2238: stur            x2, [x0, #-1]
    // 0xdd223c: dmb             ishst
    // 0xdd2240: StoreField: r0->field_7 = d0
    //     0xdd2240: stur            d0, [x0, #7]
    // 0xdd2244: stur            x0, [fp, #-0x10]
    // 0xdd2248: r0 = Container()
    //     0xdd2248: bl              #0x8a5af8  ; AllocateContainerStub -> Container (size=0x38)
    // 0xdd224c: stur            x0, [fp, #-0x20]
    // 0xdd2250: ldur            x16, [fp, #-0x10]
    // 0xdd2254: r30 = Instance_Color
    //     0xdd2254: add             lr, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xdd2258: ldr             lr, [lr, #0x810]
    // 0xdd225c: stp             lr, x16, [SP, #0x18]
    // 0xdd2260: r16 = Instance_EdgeInsets
    //     0xdd2260: add             x16, PP, #0xd4, lsl #12  ; [pp+0xd40f0] Obj!EdgeInsets@129d3b1
    //     0xdd2264: ldr             x16, [x16, #0xf0]
    // 0xdd2268: r30 = Instance_EdgeInsets
    //     0xdd2268: add             lr, PP, #0xd4, lsl #12  ; [pp+0xd40c0] Obj!EdgeInsets@129d381
    //     0xdd226c: ldr             lr, [lr, #0xc0]
    // 0xdd2270: stp             lr, x16, [SP, #8]
    // 0xdd2274: ldur            x16, [fp, #-0x18]
    // 0xdd2278: str             x16, [SP]
    // 0xdd227c: mov             x1, x0
    // 0xdd2280: r4 = const [0, 0x6, 0x5, 0x1, child, 0x5, color, 0x2, height, 0x1, margin, 0x3, padding, 0x4, null]
    //     0xdd2280: add             x4, PP, #0xd3, lsl #12  ; [pp+0xd3e30] List(15) [0, 0x6, 0x5, 0x1, "child", 0x5, "color", 0x2, "height", 0x1, "margin", 0x3, "padding", 0x4, Null]
    //     0xdd2284: ldr             x4, [x4, #0xe30]
    // 0xdd2288: r0 = Container()
    //     0xdd2288: bl              #0x8a54e0  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0xdd228c: r0 = GestureDetector()
    //     0xdd228c: bl              #0x918e18  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0xdd2290: ldur            x2, [fp, #-8]
    // 0xdd2294: r1 = Function '_skipBack@450205881':.
    //     0xdd2294: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd40f8] AnonymousClosure: (0xdd22ec), in [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_skipBack (0xdd2324)
    //     0xdd2298: ldr             x1, [x1, #0xf8]
    // 0xdd229c: stur            x0, [fp, #-8]
    // 0xdd22a0: r0 = AllocateClosure()
    //     0xdd22a0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd22a4: ldur            x16, [fp, #-0x20]
    // 0xdd22a8: stp             x16, x0, [SP]
    // 0xdd22ac: ldur            x1, [fp, #-8]
    // 0xdd22b0: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0xdd22b0: add             x4, PP, #0x16, lsl #12  ; [pp+0x16e90] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0xdd22b4: ldr             x4, [x4, #0xe90]
    // 0xdd22b8: r0 = GestureDetector()
    //     0xdd22b8: bl              #0x9182dc  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0xdd22bc: ldur            x0, [fp, #-8]
    // 0xdd22c0: LeaveFrame
    //     0xdd22c0: mov             SP, fp
    //     0xdd22c4: ldp             fp, lr, [SP], #0x10
    // 0xdd22c8: ret
    //     0xdd22c8: ret             
    // 0xdd22cc: r0 = StackOverflowSharedWithFPURegs()
    //     0xdd22cc: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xdd22d0: b               #0xdd21e4
    // 0xdd22d4: SaveReg d0
    //     0xdd22d4: str             q0, [SP, #-0x10]!
    // 0xdd22d8: SaveReg r1
    //     0xdd22d8: str             x1, [SP, #-8]!
    // 0xdd22dc: r0 = AllocateDouble()
    //     0xdd22dc: bl              #0x13df878  ; AllocateDoubleStub
    // 0xdd22e0: RestoreReg r1
    //     0xdd22e0: ldr             x1, [SP], #8
    // 0xdd22e4: RestoreReg d0
    //     0xdd22e4: ldr             q0, [SP], #0x10
    // 0xdd22e8: b               #0xdd2240
  }
  [closure] Future<void> _skipBack(dynamic) {
    // ** addr: 0xdd22ec, size: 0x38
    // 0xdd22ec: EnterFrame
    //     0xdd22ec: stp             fp, lr, [SP, #-0x10]!
    //     0xdd22f0: mov             fp, SP
    // 0xdd22f4: ldr             x0, [fp, #0x10]
    // 0xdd22f8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdd22f8: ldur            w1, [x0, #0x17]
    // 0xdd22fc: DecompressPointer r1
    //     0xdd22fc: add             x1, x1, HEAP, lsl #32
    // 0xdd2300: CheckStackOverflow
    //     0xdd2300: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd2304: cmp             SP, x16
    //     0xdd2308: b.ls            #0xdd231c
    // 0xdd230c: r0 = _skipBack()
    //     0xdd230c: bl              #0xdd2324  ; [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_skipBack
    // 0xdd2310: LeaveFrame
    //     0xdd2310: mov             SP, fp
    //     0xdd2314: ldp             fp, lr, [SP], #0x10
    // 0xdd2318: ret
    //     0xdd2318: ret             
    // 0xdd231c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd231c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd2320: b               #0xdd230c
  }
  _ _skipBack(/* No info */) async {
    // ** addr: 0xdd2324, size: 0x124
    // 0xdd2324: EnterFrame
    //     0xdd2324: stp             fp, lr, [SP, #-0x10]!
    //     0xdd2328: mov             fp, SP
    // 0xdd232c: AllocStack(0x30)
    //     0xdd232c: sub             SP, SP, #0x30
    // 0xdd2330: SetupParameters(_CupertinoControlsState this /* r1 => r1, fp-0x10 */)
    //     0xdd2330: stur            NULL, [fp, #-8]
    //     0xdd2334: stur            x1, [fp, #-0x10]
    // 0xdd2338: CheckStackOverflow
    //     0xdd2338: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd233c: cmp             SP, x16
    //     0xdd2340: b.ls            #0xdd2428
    // 0xdd2344: r1 = 1
    //     0xdd2344: mov             x1, #1
    // 0xdd2348: r0 = AllocateContext()
    //     0xdd2348: bl              #0x13de838  ; AllocateContextStub
    // 0xdd234c: mov             x2, x0
    // 0xdd2350: ldur            x1, [fp, #-0x10]
    // 0xdd2354: stur            x2, [fp, #-0x18]
    // 0xdd2358: StoreField: r2->field_f = r1
    //     0xdd2358: stur            w1, [x2, #0xf]
    // 0xdd235c: InitAsync() -> Future<void?>
    //     0xdd235c: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0xdd2360: bl              #0x7f5e44  ; InitAsyncStub
    // 0xdd2364: ldur            x1, [fp, #-0x10]
    // 0xdd2368: r0 = _cancelAndRestartTimer()
    //     0xdd2368: bl              #0xdd0d64  ; [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_cancelAndRestartTimer
    // 0xdd236c: ldur            x0, [fp, #-0x10]
    // 0xdd2370: LoadField: r1 = r0->field_1f
    //     0xdd2370: ldur            w1, [x0, #0x1f]
    // 0xdd2374: DecompressPointer r1
    //     0xdd2374: add             x1, x1, HEAP, lsl #32
    // 0xdd2378: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd237c: cmp             w1, w16
    // 0xdd2380: b.eq            #0xdd2430
    // 0xdd2384: LoadField: r2 = r1->field_b
    //     0xdd2384: ldur            w2, [x1, #0xb]
    // 0xdd2388: DecompressPointer r2
    //     0xdd2388: add             x2, x2, HEAP, lsl #32
    // 0xdd238c: LoadField: r1 = r2->field_7
    //     0xdd238c: ldur            x1, [x2, #7]
    // 0xdd2390: r17 = -14942209
    //     0xdd2390: mov             x17, #-0xe40001
    // 0xdd2394: movk            x17, #0x1e40
    // 0xdd2398: add             x2, x1, x17
    // 0xdd239c: r1 = 1000
    //     0xdd239c: mov             x1, #0x3e8
    // 0xdd23a0: sdiv            x3, x2, x1
    // 0xdd23a4: LoadField: r1 = r0->field_53
    //     0xdd23a4: ldur            w1, [x0, #0x53]
    // 0xdd23a8: DecompressPointer r1
    //     0xdd23a8: add             x1, x1, HEAP, lsl #32
    // 0xdd23ac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd23b0: cmp             w1, w16
    // 0xdd23b4: b.eq            #0xdd243c
    // 0xdd23b8: stur            x1, [fp, #-0x28]
    // 0xdd23bc: r0 = 0
    //     0xdd23bc: mov             x0, #0
    // 0xdd23c0: cmp             x3, x0
    // 0xdd23c4: csel            x2, x0, x3, lt
    // 0xdd23c8: r16 = 1000
    //     0xdd23c8: mov             x16, #0x3e8
    // 0xdd23cc: mul             x0, x2, x16
    // 0xdd23d0: stur            x0, [fp, #-0x20]
    // 0xdd23d4: r0 = Duration()
    //     0xdd23d4: bl              #0x7dd0d0  ; AllocateDurationStub -> Duration (size=0x10)
    // 0xdd23d8: mov             x1, x0
    // 0xdd23dc: ldur            x0, [fp, #-0x20]
    // 0xdd23e0: StoreField: r1->field_7 = r0
    //     0xdd23e0: stur            x0, [x1, #7]
    // 0xdd23e4: mov             x2, x1
    // 0xdd23e8: ldur            x1, [fp, #-0x28]
    // 0xdd23ec: r0 = seekTo()
    //     0xdd23ec: bl              #0x8d6e4c  ; [package:video_player/video_player.dart] VideoPlayerController::seekTo
    // 0xdd23f0: mov             x1, x0
    // 0xdd23f4: stur            x1, [fp, #-0x10]
    // 0xdd23f8: r0 = Await()
    //     0xdd23f8: bl              #0x7f5c00  ; AwaitStub
    // 0xdd23fc: ldur            x2, [fp, #-0x18]
    // 0xdd2400: r1 = Function '<anonymous closure>':.
    //     0xdd2400: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4100] AnonymousClosure: (0xdd0ea0), in [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_skipForward (0xdd0c34)
    //     0xdd2404: ldr             x1, [x1, #0x100]
    // 0xdd2408: r0 = AllocateClosure()
    //     0xdd2408: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd240c: str             x0, [SP]
    // 0xdd2410: r1 = <Null?>
    //     0xdd2410: ldr             x1, [PP, #0x70]  ; [pp+0x70] TypeArguments: <Null?>
    // 0xdd2414: r2 = Instance_Duration
    //     0xdd2414: ldr             x2, [PP, #0xa80]  ; [pp+0xa80] Obj!Duration@12c8921
    // 0xdd2418: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0xdd2418: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0xdd241c: r0 = Future.delayed()
    //     0xdd241c: bl              #0x82fe1c  ; [dart:async] Future::Future.delayed
    // 0xdd2420: r0 = Null
    //     0xdd2420: mov             x0, NULL
    // 0xdd2424: r0 = ReturnAsyncNotFuture()
    //     0xdd2424: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xdd2428: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd2428: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd242c: b               #0xdd2344
    // 0xdd2430: r9 = _latestValue
    //     0xdd2430: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3ff0] Field <_CupertinoControlsState@450205881._latestValue@450205881>: late (offset: 0x20)
    //     0xdd2434: ldr             x9, [x9, #0xff0]
    // 0xdd2438: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd2438: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdd243c: r9 = controller
    //     0xdd243c: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3fa0] Field <_CupertinoControlsState@450205881.controller>: late (offset: 0x54)
    //     0xdd2440: ldr             x9, [x9, #0xfa0]
    // 0xdd2444: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd2444: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _buildTopBar(/* No info */) {
    // ** addr: 0xdd2448, size: 0x308
    // 0xdd2448: EnterFrame
    //     0xdd2448: stp             fp, lr, [SP, #-0x10]!
    //     0xdd244c: mov             fp, SP
    // 0xdd2450: AllocStack(0x58)
    //     0xdd2450: sub             SP, SP, #0x58
    // 0xdd2454: SetupParameters(_CupertinoControlsState this /* r1 => r1, fp-0x8 */, dynamic _ /* d0 => d0, fp-0x38 */, dynamic _ /* d1 => d1, fp-0x40 */)
    //     0xdd2454: stur            x1, [fp, #-8]
    //     0xdd2458: stur            d0, [fp, #-0x38]
    //     0xdd245c: stur            d1, [fp, #-0x40]
    // 0xdd2460: CheckStackOverflow
    //     0xdd2460: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd2464: cmp             SP, x16
    //     0xdd2468: b.ls            #0xdd271c
    // 0xdd246c: r0 = EdgeInsets()
    //     0xdd246c: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xdd2470: d0 = 5.000000
    //     0xdd2470: fmov            d0, #5.00000000
    // 0xdd2474: stur            x0, [fp, #-0x10]
    // 0xdd2478: StoreField: r0->field_7 = d0
    //     0xdd2478: stur            d0, [x0, #7]
    // 0xdd247c: StoreField: r0->field_f = d0
    //     0xdd247c: stur            d0, [x0, #0xf]
    // 0xdd2480: ArrayStore: r0[0] = d0  ; List_8
    //     0xdd2480: stur            d0, [x0, #0x17]
    // 0xdd2484: StoreField: r0->field_1f = rZR
    //     0xdd2484: stur            xzr, [x0, #0x1f]
    // 0xdd2488: r1 = <Widget>
    //     0xdd2488: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xdd248c: r2 = 0
    //     0xdd248c: mov             x2, #0
    // 0xdd2490: r0 = _GrowableList()
    //     0xdd2490: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xdd2494: mov             x2, x0
    // 0xdd2498: ldur            x0, [fp, #-8]
    // 0xdd249c: stur            x2, [fp, #-0x18]
    // 0xdd24a0: LoadField: r1 = r0->field_57
    //     0xdd24a0: ldur            w1, [x0, #0x57]
    // 0xdd24a4: DecompressPointer r1
    //     0xdd24a4: add             x1, x1, HEAP, lsl #32
    // 0xdd24a8: cmp             w1, NULL
    // 0xdd24ac: b.eq            #0xdd2724
    // 0xdd24b0: mov             x1, x0
    // 0xdd24b4: ldur            d0, [fp, #-0x38]
    // 0xdd24b8: ldur            d1, [fp, #-0x40]
    // 0xdd24bc: r0 = _buildExpandButton()
    //     0xdd24bc: bl              #0xdd2c5c  ; [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_buildExpandButton
    // 0xdd24c0: mov             x2, x0
    // 0xdd24c4: ldur            x0, [fp, #-0x18]
    // 0xdd24c8: stur            x2, [fp, #-0x28]
    // 0xdd24cc: LoadField: r1 = r0->field_b
    //     0xdd24cc: ldur            w1, [x0, #0xb]
    // 0xdd24d0: LoadField: r3 = r0->field_f
    //     0xdd24d0: ldur            w3, [x0, #0xf]
    // 0xdd24d4: DecompressPointer r3
    //     0xdd24d4: add             x3, x3, HEAP, lsl #32
    // 0xdd24d8: LoadField: r4 = r3->field_b
    //     0xdd24d8: ldur            w4, [x3, #0xb]
    // 0xdd24dc: r3 = LoadInt32Instr(r1)
    //     0xdd24dc: sbfx            x3, x1, #1, #0x1f
    // 0xdd24e0: stur            x3, [fp, #-0x20]
    // 0xdd24e4: r1 = LoadInt32Instr(r4)
    //     0xdd24e4: sbfx            x1, x4, #1, #0x1f
    // 0xdd24e8: cmp             x3, x1
    // 0xdd24ec: b.ne            #0xdd24f8
    // 0xdd24f0: mov             x1, x0
    // 0xdd24f4: r0 = _growToNextCapacity()
    //     0xdd24f4: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xdd24f8: ldur            x2, [fp, #-0x18]
    // 0xdd24fc: ldur            x3, [fp, #-0x20]
    // 0xdd2500: add             x4, x3, #1
    // 0xdd2504: stur            x4, [fp, #-0x30]
    // 0xdd2508: lsl             x0, x4, #1
    // 0xdd250c: StoreField: r2->field_b = r0
    //     0xdd250c: stur            w0, [x2, #0xb]
    // 0xdd2510: LoadField: r5 = r2->field_f
    //     0xdd2510: ldur            w5, [x2, #0xf]
    // 0xdd2514: DecompressPointer r5
    //     0xdd2514: add             x5, x5, HEAP, lsl #32
    // 0xdd2518: mov             x1, x5
    // 0xdd251c: ldur            x0, [fp, #-0x28]
    // 0xdd2520: ArrayStore: r1[r3] = r0  ; List_4
    //     0xdd2520: add             x25, x1, x3, lsl #2
    //     0xdd2524: add             x25, x25, #0xf
    //     0xdd2528: str             w0, [x25]
    //     0xdd252c: tbz             w0, #0, #0xdd2548
    //     0xdd2530: ldurb           w16, [x1, #-1]
    //     0xdd2534: ldurb           w17, [x0, #-1]
    //     0xdd2538: and             x16, x17, x16, lsr #2
    //     0xdd253c: tst             x16, HEAP, lsr #32
    //     0xdd2540: b.eq            #0xdd2548
    //     0xdd2544: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdd2548: LoadField: r0 = r5->field_b
    //     0xdd2548: ldur            w0, [x5, #0xb]
    // 0xdd254c: r1 = LoadInt32Instr(r0)
    //     0xdd254c: sbfx            x1, x0, #1, #0x1f
    // 0xdd2550: cmp             x4, x1
    // 0xdd2554: b.ne            #0xdd2560
    // 0xdd2558: mov             x1, x2
    // 0xdd255c: r0 = _growToNextCapacity()
    //     0xdd255c: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xdd2560: ldur            x2, [fp, #-8]
    // 0xdd2564: ldur            x0, [fp, #-0x18]
    // 0xdd2568: ldur            x1, [fp, #-0x30]
    // 0xdd256c: add             x3, x1, #1
    // 0xdd2570: lsl             x4, x3, #1
    // 0xdd2574: StoreField: r0->field_b = r4
    //     0xdd2574: stur            w4, [x0, #0xb]
    // 0xdd2578: LoadField: r3 = r0->field_f
    //     0xdd2578: ldur            w3, [x0, #0xf]
    // 0xdd257c: DecompressPointer r3
    //     0xdd257c: add             x3, x3, HEAP, lsl #32
    // 0xdd2580: add             x4, x3, x1, lsl #2
    // 0xdd2584: r16 = Instance_Spacer
    //     0xdd2584: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1ee78] Obj!Spacer@12b5c01
    //     0xdd2588: ldr             x16, [x16, #0xe78]
    // 0xdd258c: StoreField: r4->field_f = r16
    //     0xdd258c: stur            w16, [x4, #0xf]
    // 0xdd2590: LoadField: r1 = r2->field_57
    //     0xdd2590: ldur            w1, [x2, #0x57]
    // 0xdd2594: DecompressPointer r1
    //     0xdd2594: add             x1, x1, HEAP, lsl #32
    // 0xdd2598: cmp             w1, NULL
    // 0xdd259c: b.eq            #0xdd2728
    // 0xdd25a0: LoadField: r1 = r2->field_53
    //     0xdd25a0: ldur            w1, [x2, #0x53]
    // 0xdd25a4: DecompressPointer r1
    //     0xdd25a4: add             x1, x1, HEAP, lsl #32
    // 0xdd25a8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd25ac: cmp             w1, w16
    // 0xdd25b0: b.eq            #0xdd272c
    // 0xdd25b4: mov             x16, x1
    // 0xdd25b8: mov             x1, x2
    // 0xdd25bc: mov             x2, x16
    // 0xdd25c0: ldur            d0, [fp, #-0x38]
    // 0xdd25c4: ldur            d1, [fp, #-0x40]
    // 0xdd25c8: r0 = _buildMuteButton()
    //     0xdd25c8: bl              #0xdd2750  ; [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_buildMuteButton
    // 0xdd25cc: mov             x2, x0
    // 0xdd25d0: ldur            x0, [fp, #-0x18]
    // 0xdd25d4: stur            x2, [fp, #-8]
    // 0xdd25d8: LoadField: r1 = r0->field_b
    //     0xdd25d8: ldur            w1, [x0, #0xb]
    // 0xdd25dc: LoadField: r3 = r0->field_f
    //     0xdd25dc: ldur            w3, [x0, #0xf]
    // 0xdd25e0: DecompressPointer r3
    //     0xdd25e0: add             x3, x3, HEAP, lsl #32
    // 0xdd25e4: LoadField: r4 = r3->field_b
    //     0xdd25e4: ldur            w4, [x3, #0xb]
    // 0xdd25e8: r3 = LoadInt32Instr(r1)
    //     0xdd25e8: sbfx            x3, x1, #1, #0x1f
    // 0xdd25ec: stur            x3, [fp, #-0x20]
    // 0xdd25f0: r1 = LoadInt32Instr(r4)
    //     0xdd25f0: sbfx            x1, x4, #1, #0x1f
    // 0xdd25f4: cmp             x3, x1
    // 0xdd25f8: b.ne            #0xdd2604
    // 0xdd25fc: mov             x1, x0
    // 0xdd2600: r0 = _growToNextCapacity()
    //     0xdd2600: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xdd2604: ldur            d0, [fp, #-0x38]
    // 0xdd2608: ldur            x2, [fp, #-0x18]
    // 0xdd260c: ldur            x3, [fp, #-0x20]
    // 0xdd2610: add             x0, x3, #1
    // 0xdd2614: lsl             x1, x0, #1
    // 0xdd2618: StoreField: r2->field_b = r1
    //     0xdd2618: stur            w1, [x2, #0xb]
    // 0xdd261c: LoadField: r1 = r2->field_f
    //     0xdd261c: ldur            w1, [x2, #0xf]
    // 0xdd2620: DecompressPointer r1
    //     0xdd2620: add             x1, x1, HEAP, lsl #32
    // 0xdd2624: ldur            x0, [fp, #-8]
    // 0xdd2628: ArrayStore: r1[r3] = r0  ; List_4
    //     0xdd2628: add             x25, x1, x3, lsl #2
    //     0xdd262c: add             x25, x25, #0xf
    //     0xdd2630: str             w0, [x25]
    //     0xdd2634: tbz             w0, #0, #0xdd2650
    //     0xdd2638: ldurb           w16, [x1, #-1]
    //     0xdd263c: ldurb           w17, [x0, #-1]
    //     0xdd2640: and             x16, x17, x16, lsr #2
    //     0xdd2644: tst             x16, HEAP, lsr #32
    //     0xdd2648: b.eq            #0xdd2650
    //     0xdd264c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdd2650: r0 = Row()
    //     0xdd2650: bl              #0x8a5b04  ; AllocateRowStub -> Row (size=0x38)
    // 0xdd2654: mov             x1, x0
    // 0xdd2658: r0 = Instance_Axis
    //     0xdd2658: ldr             x0, [PP, #0x49c8]  ; [pp+0x49c8] Obj!Axis@12c4a61
    // 0xdd265c: stur            x1, [fp, #-0x28]
    // 0xdd2660: StoreField: r1->field_f = r0
    //     0xdd2660: stur            w0, [x1, #0xf]
    // 0xdd2664: r0 = Instance_MainAxisAlignment
    //     0xdd2664: add             x0, PP, #0x15, lsl #12  ; [pp+0x15820] Obj!MainAxisAlignment@12c4541
    //     0xdd2668: ldr             x0, [x0, #0x820]
    // 0xdd266c: StoreField: r1->field_13 = r0
    //     0xdd266c: stur            w0, [x1, #0x13]
    // 0xdd2670: r0 = Instance_MainAxisSize
    //     0xdd2670: add             x0, PP, #0x15, lsl #12  ; [pp+0x15828] Obj!MainAxisSize@12c4621
    //     0xdd2674: ldr             x0, [x0, #0x828]
    // 0xdd2678: ArrayStore: r1[0] = r0  ; List_4
    //     0xdd2678: stur            w0, [x1, #0x17]
    // 0xdd267c: r0 = Instance_CrossAxisAlignment
    //     0xdd267c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15888] Obj!CrossAxisAlignment@12c44a1
    //     0xdd2680: ldr             x0, [x0, #0x888]
    // 0xdd2684: StoreField: r1->field_1b = r0
    //     0xdd2684: stur            w0, [x1, #0x1b]
    // 0xdd2688: r0 = Instance_VerticalDirection
    //     0xdd2688: add             x0, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xdd268c: ldr             x0, [x0, #0x838]
    // 0xdd2690: StoreField: r1->field_23 = r0
    //     0xdd2690: stur            w0, [x1, #0x23]
    // 0xdd2694: r0 = Instance_Clip
    //     0xdd2694: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xdd2698: ldr             x0, [x0, #0x840]
    // 0xdd269c: StoreField: r1->field_2b = r0
    //     0xdd269c: stur            w0, [x1, #0x2b]
    // 0xdd26a0: StoreField: r1->field_2f = rZR
    //     0xdd26a0: stur            xzr, [x1, #0x2f]
    // 0xdd26a4: ldur            x0, [fp, #-0x18]
    // 0xdd26a8: StoreField: r1->field_b = r0
    //     0xdd26a8: stur            w0, [x1, #0xb]
    // 0xdd26ac: ldur            d0, [fp, #-0x38]
    // 0xdd26b0: r0 = inline_Allocate_Double()
    //     0xdd26b0: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xdd26b4: add             x0, x0, #0x10
    //     0xdd26b8: cmp             x2, x0
    //     0xdd26bc: b.ls            #0xdd2738
    //     0xdd26c0: str             x0, [THR, #0x60]  ; THR::top
    //     0xdd26c4: sub             x0, x0, #0xf
    //     0xdd26c8: mov             x2, #0xe19c
    //     0xdd26cc: movk            x2, #3, lsl #16
    //     0xdd26d0: stur            x2, [x0, #-1]
    // 0xdd26d4: dmb             ishst
    // 0xdd26d8: StoreField: r0->field_7 = d0
    //     0xdd26d8: stur            d0, [x0, #7]
    // 0xdd26dc: stur            x0, [fp, #-8]
    // 0xdd26e0: r0 = Container()
    //     0xdd26e0: bl              #0x8a5af8  ; AllocateContainerStub -> Container (size=0x38)
    // 0xdd26e4: stur            x0, [fp, #-0x18]
    // 0xdd26e8: ldur            x16, [fp, #-8]
    // 0xdd26ec: ldur            lr, [fp, #-0x10]
    // 0xdd26f0: stp             lr, x16, [SP, #8]
    // 0xdd26f4: ldur            x16, [fp, #-0x28]
    // 0xdd26f8: str             x16, [SP]
    // 0xdd26fc: mov             x1, x0
    // 0xdd2700: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, height, 0x1, margin, 0x2, null]
    //     0xdd2700: add             x4, PP, #0xd4, lsl #12  ; [pp+0xd4108] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "height", 0x1, "margin", 0x2, Null]
    //     0xdd2704: ldr             x4, [x4, #0x108]
    // 0xdd2708: r0 = Container()
    //     0xdd2708: bl              #0x8a54e0  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0xdd270c: ldur            x0, [fp, #-0x18]
    // 0xdd2710: LeaveFrame
    //     0xdd2710: mov             SP, fp
    //     0xdd2714: ldp             fp, lr, [SP], #0x10
    // 0xdd2718: ret
    //     0xdd2718: ret             
    // 0xdd271c: r0 = StackOverflowSharedWithFPURegs()
    //     0xdd271c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xdd2720: b               #0xdd246c
    // 0xdd2724: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd2724: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdd2728: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd2728: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdd272c: r9 = controller
    //     0xdd272c: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3fa0] Field <_CupertinoControlsState@450205881.controller>: late (offset: 0x54)
    //     0xdd2730: ldr             x9, [x9, #0xfa0]
    // 0xdd2734: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd2734: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdd2738: SaveReg d0
    //     0xdd2738: str             q0, [SP, #-0x10]!
    // 0xdd273c: SaveReg r1
    //     0xdd273c: str             x1, [SP, #-8]!
    // 0xdd2740: r0 = AllocateDouble()
    //     0xdd2740: bl              #0x13df878  ; AllocateDoubleStub
    // 0xdd2744: RestoreReg r1
    //     0xdd2744: ldr             x1, [SP], #8
    // 0xdd2748: RestoreReg d0
    //     0xdd2748: ldr             q0, [SP], #0x10
    // 0xdd274c: b               #0xdd26d8
  }
  _ _buildMuteButton(/* No info */) {
    // ** addr: 0xdd2750, size: 0x2fc
    // 0xdd2750: EnterFrame
    //     0xdd2750: stp             fp, lr, [SP, #-0x10]!
    //     0xdd2754: mov             fp, SP
    // 0xdd2758: AllocStack(0x68)
    //     0xdd2758: sub             SP, SP, #0x68
    // 0xdd275c: SetupParameters(_CupertinoControlsState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* d0 => d0, fp-0x40 */, dynamic _ /* d1 => d1, fp-0x48 */)
    //     0xdd275c: stur            x1, [fp, #-8]
    //     0xdd2760: stur            x2, [fp, #-0x10]
    //     0xdd2764: stur            d0, [fp, #-0x40]
    //     0xdd2768: stur            d1, [fp, #-0x48]
    // 0xdd276c: CheckStackOverflow
    //     0xdd276c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd2770: cmp             SP, x16
    //     0xdd2774: b.ls            #0xdd2a14
    // 0xdd2778: r1 = 2
    //     0xdd2778: mov             x1, #2
    // 0xdd277c: r0 = AllocateContext()
    //     0xdd277c: bl              #0x13de838  ; AllocateContextStub
    // 0xdd2780: mov             x1, x0
    // 0xdd2784: ldur            x0, [fp, #-8]
    // 0xdd2788: stur            x1, [fp, #-0x18]
    // 0xdd278c: StoreField: r1->field_f = r0
    //     0xdd278c: stur            w0, [x1, #0xf]
    // 0xdd2790: ldur            x2, [fp, #-0x10]
    // 0xdd2794: StoreField: r1->field_13 = r2
    //     0xdd2794: stur            w2, [x1, #0x13]
    // 0xdd2798: LoadField: r2 = r0->field_1b
    //     0xdd2798: ldur            w2, [x0, #0x1b]
    // 0xdd279c: DecompressPointer r2
    //     0xdd279c: add             x2, x2, HEAP, lsl #32
    // 0xdd27a0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd27a4: cmp             w2, w16
    // 0xdd27a8: b.eq            #0xdd2a1c
    // 0xdd27ac: LoadField: r3 = r2->field_23
    //     0xdd27ac: ldur            w3, [x2, #0x23]
    // 0xdd27b0: DecompressPointer r3
    //     0xdd27b0: add             x3, x3, HEAP, lsl #32
    // 0xdd27b4: tbnz            w3, #4, #0xdd27c0
    // 0xdd27b8: d1 = 0.000000
    //     0xdd27b8: eor             v1.16b, v1.16b, v1.16b
    // 0xdd27bc: b               #0xdd27c4
    // 0xdd27c0: d1 = 1.000000
    //     0xdd27c0: fmov            d1, #1.00000000
    // 0xdd27c4: ldur            d0, [fp, #-0x48]
    // 0xdd27c8: stur            d1, [fp, #-0x50]
    // 0xdd27cc: r0 = Radius()
    //     0xdd27cc: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0xdd27d0: d0 = 10.000000
    //     0xdd27d0: fmov            d0, #10.00000000
    // 0xdd27d4: stur            x0, [fp, #-0x10]
    // 0xdd27d8: StoreField: r0->field_7 = d0
    //     0xdd27d8: stur            d0, [x0, #7]
    // 0xdd27dc: StoreField: r0->field_f = d0
    //     0xdd27dc: stur            d0, [x0, #0xf]
    // 0xdd27e0: r0 = BorderRadius()
    //     0xdd27e0: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0xdd27e4: mov             x1, x0
    // 0xdd27e8: ldur            x0, [fp, #-0x10]
    // 0xdd27ec: stur            x1, [fp, #-0x20]
    // 0xdd27f0: StoreField: r1->field_7 = r0
    //     0xdd27f0: stur            w0, [x1, #7]
    // 0xdd27f4: StoreField: r1->field_b = r0
    //     0xdd27f4: stur            w0, [x1, #0xb]
    // 0xdd27f8: StoreField: r1->field_f = r0
    //     0xdd27f8: stur            w0, [x1, #0xf]
    // 0xdd27fc: StoreField: r1->field_13 = r0
    //     0xdd27fc: stur            w0, [x1, #0x13]
    // 0xdd2800: r0 = _GaussianBlurImageFilter()
    //     0xdd2800: bl              #0x9191c8  ; Allocate_GaussianBlurImageFilterStub -> _GaussianBlurImageFilter (size=0x24)
    // 0xdd2804: mov             x1, x0
    // 0xdd2808: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd280c: stur            x1, [fp, #-0x10]
    // 0xdd2810: StoreField: r1->field_1f = r0
    //     0xdd2810: stur            w0, [x1, #0x1f]
    // 0xdd2814: d0 = 10.000000
    //     0xdd2814: fmov            d0, #10.00000000
    // 0xdd2818: StoreField: r1->field_7 = d0
    //     0xdd2818: stur            d0, [x1, #7]
    // 0xdd281c: StoreField: r1->field_f = rZR
    //     0xdd281c: stur            xzr, [x1, #0xf]
    // 0xdd2820: r0 = EdgeInsets()
    //     0xdd2820: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xdd2824: ldur            d0, [fp, #-0x48]
    // 0xdd2828: stur            x0, [fp, #-0x28]
    // 0xdd282c: StoreField: r0->field_7 = d0
    //     0xdd282c: stur            d0, [x0, #7]
    // 0xdd2830: StoreField: r0->field_f = rZR
    //     0xdd2830: stur            xzr, [x0, #0xf]
    // 0xdd2834: ArrayStore: r0[0] = d0  ; List_8
    //     0xdd2834: stur            d0, [x0, #0x17]
    // 0xdd2838: StoreField: r0->field_1f = rZR
    //     0xdd2838: stur            xzr, [x0, #0x1f]
    // 0xdd283c: ldur            x1, [fp, #-8]
    // 0xdd2840: LoadField: r2 = r1->field_1f
    //     0xdd2840: ldur            w2, [x1, #0x1f]
    // 0xdd2844: DecompressPointer r2
    //     0xdd2844: add             x2, x2, HEAP, lsl #32
    // 0xdd2848: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd284c: cmp             w2, w16
    // 0xdd2850: b.eq            #0xdd2a28
    // 0xdd2854: LoadField: d0 = r2->field_27
    //     0xdd2854: ldur            d0, [x2, #0x27]
    // 0xdd2858: d1 = 0.000000
    //     0xdd2858: eor             v1.16b, v1.16b, v1.16b
    // 0xdd285c: fcmp            d0, d1
    // 0xdd2860: b.le            #0xdd2870
    // 0xdd2864: r3 = Instance_IconData
    //     0xdd2864: add             x3, PP, #0xd3, lsl #12  ; [pp+0xd3e00] Obj!IconData@128a6b1
    //     0xdd2868: ldr             x3, [x3, #0xe00]
    // 0xdd286c: b               #0xdd2878
    // 0xdd2870: r3 = Instance_IconData
    //     0xdd2870: add             x3, PP, #0xd3, lsl #12  ; [pp+0xd3e08] Obj!IconData@128a691
    //     0xdd2874: ldr             x3, [x3, #0xe08]
    // 0xdd2878: ldur            d1, [fp, #-0x40]
    // 0xdd287c: ldur            d0, [fp, #-0x50]
    // 0xdd2880: ldur            x2, [fp, #-0x20]
    // 0xdd2884: ldur            x1, [fp, #-0x10]
    // 0xdd2888: stur            x3, [fp, #-8]
    // 0xdd288c: r0 = Icon()
    //     0xdd288c: bl              #0xd0fd5c  ; AllocateIconStub -> Icon (size=0x40)
    // 0xdd2890: mov             x1, x0
    // 0xdd2894: ldur            x0, [fp, #-8]
    // 0xdd2898: stur            x1, [fp, #-0x30]
    // 0xdd289c: StoreField: r1->field_b = r0
    //     0xdd289c: stur            w0, [x1, #0xb]
    // 0xdd28a0: r0 = 16.000000
    //     0xdd28a0: add             x0, PP, #0x13, lsl #12  ; [pp+0x13df8] 16
    //     0xdd28a4: ldr             x0, [x0, #0xdf8]
    // 0xdd28a8: StoreField: r1->field_f = r0
    //     0xdd28a8: stur            w0, [x1, #0xf]
    // 0xdd28ac: r0 = Instance_Color
    //     0xdd28ac: add             x0, PP, #0xd4, lsl #12  ; [pp+0xd4010] Obj!Color@12a3ba1
    //     0xdd28b0: ldr             x0, [x0, #0x10]
    // 0xdd28b4: StoreField: r1->field_23 = r0
    //     0xdd28b4: stur            w0, [x1, #0x23]
    // 0xdd28b8: ldur            d0, [fp, #-0x40]
    // 0xdd28bc: r0 = inline_Allocate_Double()
    //     0xdd28bc: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xdd28c0: add             x0, x0, #0x10
    //     0xdd28c4: cmp             x2, x0
    //     0xdd28c8: b.ls            #0xdd2a34
    //     0xdd28cc: str             x0, [THR, #0x60]  ; THR::top
    //     0xdd28d0: sub             x0, x0, #0xf
    //     0xdd28d4: mov             x2, #0xe19c
    //     0xdd28d8: movk            x2, #3, lsl #16
    //     0xdd28dc: stur            x2, [x0, #-1]
    // 0xdd28e0: dmb             ishst
    // 0xdd28e4: StoreField: r0->field_7 = d0
    //     0xdd28e4: stur            d0, [x0, #7]
    // 0xdd28e8: stur            x0, [fp, #-8]
    // 0xdd28ec: r0 = Container()
    //     0xdd28ec: bl              #0x8a5af8  ; AllocateContainerStub -> Container (size=0x38)
    // 0xdd28f0: stur            x0, [fp, #-0x38]
    // 0xdd28f4: ldur            x16, [fp, #-8]
    // 0xdd28f8: ldur            lr, [fp, #-0x28]
    // 0xdd28fc: stp             lr, x16, [SP, #8]
    // 0xdd2900: ldur            x16, [fp, #-0x30]
    // 0xdd2904: str             x16, [SP]
    // 0xdd2908: mov             x1, x0
    // 0xdd290c: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, height, 0x1, padding, 0x2, null]
    //     0xdd290c: add             x4, PP, #0x91, lsl #12  ; [pp+0x91970] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "height", 0x1, "padding", 0x2, Null]
    //     0xdd2910: ldr             x4, [x4, #0x970]
    // 0xdd2914: r0 = Container()
    //     0xdd2914: bl              #0x8a54e0  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0xdd2918: r0 = ColoredBox()
    //     0xdd2918: bl              #0xd1a914  ; AllocateColoredBoxStub -> ColoredBox (size=0x18)
    // 0xdd291c: mov             x1, x0
    // 0xdd2920: r0 = Instance_Color
    //     0xdd2920: add             x0, PP, #0xd4, lsl #12  ; [pp+0xd4000] Obj!Color@12a3c61
    //     0xdd2924: ldr             x0, [x0]
    // 0xdd2928: stur            x1, [fp, #-8]
    // 0xdd292c: StoreField: r1->field_f = r0
    //     0xdd292c: stur            w0, [x1, #0xf]
    // 0xdd2930: r0 = true
    //     0xdd2930: add             x0, NULL, #0x20  ; true
    // 0xdd2934: StoreField: r1->field_13 = r0
    //     0xdd2934: stur            w0, [x1, #0x13]
    // 0xdd2938: ldur            x2, [fp, #-0x38]
    // 0xdd293c: StoreField: r1->field_b = r2
    //     0xdd293c: stur            w2, [x1, #0xb]
    // 0xdd2940: r0 = BackdropFilter()
    //     0xdd2940: bl              #0x9190e4  ; AllocateBackdropFilterStub -> BackdropFilter (size=0x28)
    // 0xdd2944: mov             x1, x0
    // 0xdd2948: ldur            x0, [fp, #-0x10]
    // 0xdd294c: stur            x1, [fp, #-0x28]
    // 0xdd2950: StoreField: r1->field_f = r0
    //     0xdd2950: stur            w0, [x1, #0xf]
    // 0xdd2954: r0 = Instance_BlendMode
    //     0xdd2954: add             x0, PP, #0x16, lsl #12  ; [pp+0x16eb8] Obj!BlendMode@12c82e1
    //     0xdd2958: ldr             x0, [x0, #0xeb8]
    // 0xdd295c: ArrayStore: r1[0] = r0  ; List_4
    //     0xdd295c: stur            w0, [x1, #0x17]
    // 0xdd2960: r0 = true
    //     0xdd2960: add             x0, NULL, #0x20  ; true
    // 0xdd2964: StoreField: r1->field_1b = r0
    //     0xdd2964: stur            w0, [x1, #0x1b]
    // 0xdd2968: r0 = false
    //     0xdd2968: add             x0, NULL, #0x30  ; false
    // 0xdd296c: StoreField: r1->field_23 = r0
    //     0xdd296c: stur            w0, [x1, #0x23]
    // 0xdd2970: ldur            x2, [fp, #-8]
    // 0xdd2974: StoreField: r1->field_b = r2
    //     0xdd2974: stur            w2, [x1, #0xb]
    // 0xdd2978: r0 = ClipRRect()
    //     0xdd2978: bl              #0xd30168  ; AllocateClipRRectStub -> ClipRRect (size=0x1c)
    // 0xdd297c: mov             x1, x0
    // 0xdd2980: ldur            x0, [fp, #-0x20]
    // 0xdd2984: stur            x1, [fp, #-8]
    // 0xdd2988: StoreField: r1->field_f = r0
    //     0xdd2988: stur            w0, [x1, #0xf]
    // 0xdd298c: r0 = Instance_Clip
    //     0xdd298c: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e6f0] Obj!Clip@12c8101
    //     0xdd2990: ldr             x0, [x0, #0x6f0]
    // 0xdd2994: ArrayStore: r1[0] = r0  ; List_4
    //     0xdd2994: stur            w0, [x1, #0x17]
    // 0xdd2998: ldur            x0, [fp, #-0x28]
    // 0xdd299c: StoreField: r1->field_b = r0
    //     0xdd299c: stur            w0, [x1, #0xb]
    // 0xdd29a0: r0 = AnimatedOpacity()
    //     0xdd29a0: bl              #0xd2cf50  ; AllocateAnimatedOpacityStub -> AnimatedOpacity (size=0x28)
    // 0xdd29a4: mov             x1, x0
    // 0xdd29a8: ldur            x0, [fp, #-8]
    // 0xdd29ac: stur            x1, [fp, #-0x10]
    // 0xdd29b0: ArrayStore: r1[0] = r0  ; List_4
    //     0xdd29b0: stur            w0, [x1, #0x17]
    // 0xdd29b4: ldur            d0, [fp, #-0x50]
    // 0xdd29b8: StoreField: r1->field_1b = d0
    //     0xdd29b8: stur            d0, [x1, #0x1b]
    // 0xdd29bc: r0 = false
    //     0xdd29bc: add             x0, NULL, #0x30  ; false
    // 0xdd29c0: StoreField: r1->field_23 = r0
    //     0xdd29c0: stur            w0, [x1, #0x23]
    // 0xdd29c4: r0 = Instance__Linear
    //     0xdd29c4: ldr             x0, [PP, #0x5168]  ; [pp+0x5168] Obj!_Linear@129fef1
    // 0xdd29c8: StoreField: r1->field_b = r0
    //     0xdd29c8: stur            w0, [x1, #0xb]
    // 0xdd29cc: r0 = Instance_Duration
    //     0xdd29cc: ldr             x0, [PP, #0x7cd8]  ; [pp+0x7cd8] Obj!Duration@12c8971
    // 0xdd29d0: StoreField: r1->field_f = r0
    //     0xdd29d0: stur            w0, [x1, #0xf]
    // 0xdd29d4: r0 = GestureDetector()
    //     0xdd29d4: bl              #0x918e18  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0xdd29d8: ldur            x2, [fp, #-0x18]
    // 0xdd29dc: r1 = Function '<anonymous closure>':.
    //     0xdd29dc: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4110] AnonymousClosure: (0xdd2a4c), in [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_buildMuteButton (0xdd2750)
    //     0xdd29e0: ldr             x1, [x1, #0x110]
    // 0xdd29e4: stur            x0, [fp, #-8]
    // 0xdd29e8: r0 = AllocateClosure()
    //     0xdd29e8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd29ec: ldur            x16, [fp, #-0x10]
    // 0xdd29f0: stp             x16, x0, [SP]
    // 0xdd29f4: ldur            x1, [fp, #-8]
    // 0xdd29f8: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0xdd29f8: add             x4, PP, #0x16, lsl #12  ; [pp+0x16e90] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0xdd29fc: ldr             x4, [x4, #0xe90]
    // 0xdd2a00: r0 = GestureDetector()
    //     0xdd2a00: bl              #0x9182dc  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0xdd2a04: ldur            x0, [fp, #-8]
    // 0xdd2a08: LeaveFrame
    //     0xdd2a08: mov             SP, fp
    //     0xdd2a0c: ldp             fp, lr, [SP], #0x10
    // 0xdd2a10: ret
    //     0xdd2a10: ret             
    // 0xdd2a14: r0 = StackOverflowSharedWithFPURegs()
    //     0xdd2a14: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xdd2a18: b               #0xdd2778
    // 0xdd2a1c: r9 = notifier
    //     0xdd2a1c: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3fb0] Field <_CupertinoControlsState@450205881.notifier>: late (offset: 0x1c)
    //     0xdd2a20: ldr             x9, [x9, #0xfb0]
    // 0xdd2a24: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd2a24: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdd2a28: r9 = _latestValue
    //     0xdd2a28: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3ff0] Field <_CupertinoControlsState@450205881._latestValue@450205881>: late (offset: 0x20)
    //     0xdd2a2c: ldr             x9, [x9, #0xff0]
    // 0xdd2a30: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd2a30: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdd2a34: SaveReg d0
    //     0xdd2a34: str             q0, [SP, #-0x10]!
    // 0xdd2a38: SaveReg r1
    //     0xdd2a38: str             x1, [SP, #-8]!
    // 0xdd2a3c: r0 = AllocateDouble()
    //     0xdd2a3c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xdd2a40: RestoreReg r1
    //     0xdd2a40: ldr             x1, [SP], #8
    // 0xdd2a44: RestoreReg d0
    //     0xdd2a44: ldr             q0, [SP], #0x10
    // 0xdd2a48: b               #0xdd28e4
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xdd2a4c, size: 0x138
    // 0xdd2a4c: EnterFrame
    //     0xdd2a4c: stp             fp, lr, [SP, #-0x10]!
    //     0xdd2a50: mov             fp, SP
    // 0xdd2a54: AllocStack(0x8)
    //     0xdd2a54: sub             SP, SP, #8
    // 0xdd2a58: SetupParameters([dynamic _ /* r0 */])
    //     0xdd2a58: ldr             x0, [fp, #0x10]
    //     0xdd2a5c: ldur            w2, [x0, #0x17]
    //     0xdd2a60: add             x2, x2, HEAP, lsl #32
    //     0xdd2a64: stur            x2, [fp, #-8]
    // 0xdd2a68: CheckStackOverflow
    //     0xdd2a68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd2a6c: cmp             SP, x16
    //     0xdd2a70: b.ls            #0xdd2b58
    // 0xdd2a74: LoadField: r1 = r2->field_f
    //     0xdd2a74: ldur            w1, [x2, #0xf]
    // 0xdd2a78: DecompressPointer r1
    //     0xdd2a78: add             x1, x1, HEAP, lsl #32
    // 0xdd2a7c: r0 = _cancelAndRestartTimer()
    //     0xdd2a7c: bl              #0xdd0d64  ; [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_cancelAndRestartTimer
    // 0xdd2a80: ldur            x0, [fp, #-8]
    // 0xdd2a84: LoadField: r1 = r0->field_f
    //     0xdd2a84: ldur            w1, [x0, #0xf]
    // 0xdd2a88: DecompressPointer r1
    //     0xdd2a88: add             x1, x1, HEAP, lsl #32
    // 0xdd2a8c: LoadField: r2 = r1->field_1f
    //     0xdd2a8c: ldur            w2, [x1, #0x1f]
    // 0xdd2a90: DecompressPointer r2
    //     0xdd2a90: add             x2, x2, HEAP, lsl #32
    // 0xdd2a94: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd2a98: cmp             w2, w16
    // 0xdd2a9c: b.eq            #0xdd2b60
    // 0xdd2aa0: LoadField: d0 = r2->field_27
    //     0xdd2aa0: ldur            d0, [x2, #0x27]
    // 0xdd2aa4: d1 = 0.000000
    //     0xdd2aa4: eor             v1.16b, v1.16b, v1.16b
    // 0xdd2aa8: fcmp            d0, d1
    // 0xdd2aac: b.ne            #0xdd2ae0
    // 0xdd2ab0: LoadField: r2 = r0->field_13
    //     0xdd2ab0: ldur            w2, [x0, #0x13]
    // 0xdd2ab4: DecompressPointer r2
    //     0xdd2ab4: add             x2, x2, HEAP, lsl #32
    // 0xdd2ab8: LoadField: r0 = r1->field_23
    //     0xdd2ab8: ldur            w0, [x1, #0x23]
    // 0xdd2abc: DecompressPointer r0
    //     0xdd2abc: add             x0, x0, HEAP, lsl #32
    // 0xdd2ac0: cmp             w0, NULL
    // 0xdd2ac4: b.ne            #0xdd2ad0
    // 0xdd2ac8: d0 = 0.500000
    //     0xdd2ac8: fmov            d0, #0.50000000
    // 0xdd2acc: b               #0xdd2ad4
    // 0xdd2ad0: LoadField: d0 = r0->field_7
    //     0xdd2ad0: ldur            d0, [x0, #7]
    // 0xdd2ad4: mov             x1, x2
    // 0xdd2ad8: r0 = setVolume()
    //     0xdd2ad8: bl              #0xdd2b84  ; [package:video_player/video_player.dart] VideoPlayerController::setVolume
    // 0xdd2adc: b               #0xdd2b48
    // 0xdd2ae0: LoadField: r2 = r0->field_13
    //     0xdd2ae0: ldur            w2, [x0, #0x13]
    // 0xdd2ae4: DecompressPointer r2
    //     0xdd2ae4: add             x2, x2, HEAP, lsl #32
    // 0xdd2ae8: LoadField: r0 = r2->field_27
    //     0xdd2ae8: ldur            w0, [x2, #0x27]
    // 0xdd2aec: DecompressPointer r0
    //     0xdd2aec: add             x0, x0, HEAP, lsl #32
    // 0xdd2af0: LoadField: d0 = r0->field_27
    //     0xdd2af0: ldur            d0, [x0, #0x27]
    // 0xdd2af4: r0 = inline_Allocate_Double()
    //     0xdd2af4: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0xdd2af8: add             x0, x0, #0x10
    //     0xdd2afc: cmp             x3, x0
    //     0xdd2b00: b.ls            #0xdd2b6c
    //     0xdd2b04: str             x0, [THR, #0x60]  ; THR::top
    //     0xdd2b08: sub             x0, x0, #0xf
    //     0xdd2b0c: mov             x3, #0xe19c
    //     0xdd2b10: movk            x3, #3, lsl #16
    //     0xdd2b14: stur            x3, [x0, #-1]
    // 0xdd2b18: dmb             ishst
    // 0xdd2b1c: StoreField: r0->field_7 = d0
    //     0xdd2b1c: stur            d0, [x0, #7]
    // 0xdd2b20: StoreField: r1->field_23 = r0
    //     0xdd2b20: stur            w0, [x1, #0x23]
    //     0xdd2b24: ldurb           w16, [x1, #-1]
    //     0xdd2b28: ldurb           w17, [x0, #-1]
    //     0xdd2b2c: and             x16, x17, x16, lsr #2
    //     0xdd2b30: tst             x16, HEAP, lsr #32
    //     0xdd2b34: b.eq            #0xdd2b3c
    //     0xdd2b38: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdd2b3c: mov             x1, x2
    // 0xdd2b40: mov             v0.16b, v1.16b
    // 0xdd2b44: r0 = setVolume()
    //     0xdd2b44: bl              #0xdd2b84  ; [package:video_player/video_player.dart] VideoPlayerController::setVolume
    // 0xdd2b48: r0 = Null
    //     0xdd2b48: mov             x0, NULL
    // 0xdd2b4c: LeaveFrame
    //     0xdd2b4c: mov             SP, fp
    //     0xdd2b50: ldp             fp, lr, [SP], #0x10
    // 0xdd2b54: ret
    //     0xdd2b54: ret             
    // 0xdd2b58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd2b58: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd2b5c: b               #0xdd2a74
    // 0xdd2b60: r9 = _latestValue
    //     0xdd2b60: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3ff0] Field <_CupertinoControlsState@450205881._latestValue@450205881>: late (offset: 0x20)
    //     0xdd2b64: ldr             x9, [x9, #0xff0]
    // 0xdd2b68: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd2b68: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdd2b6c: stp             q0, q1, [SP, #-0x20]!
    // 0xdd2b70: stp             x1, x2, [SP, #-0x10]!
    // 0xdd2b74: r0 = AllocateDouble()
    //     0xdd2b74: bl              #0x13df878  ; AllocateDoubleStub
    // 0xdd2b78: ldp             x1, x2, [SP], #0x10
    // 0xdd2b7c: ldp             q0, q1, [SP], #0x20
    // 0xdd2b80: b               #0xdd2b1c
  }
  _ _buildExpandButton(/* No info */) {
    // ** addr: 0xdd2c5c, size: 0x2c8
    // 0xdd2c5c: EnterFrame
    //     0xdd2c5c: stp             fp, lr, [SP, #-0x10]!
    //     0xdd2c60: mov             fp, SP
    // 0xdd2c64: AllocStack(0x70)
    //     0xdd2c64: sub             SP, SP, #0x70
    // 0xdd2c68: SetupParameters(_CupertinoControlsState this /* r1 => r2, fp-0x8 */, dynamic _ /* d0 => d0, fp-0x48 */, dynamic _ /* d1 => d1, fp-0x50 */)
    //     0xdd2c68: mov             x2, x1
    //     0xdd2c6c: stur            x1, [fp, #-8]
    //     0xdd2c70: stur            d0, [fp, #-0x48]
    //     0xdd2c74: stur            d1, [fp, #-0x50]
    // 0xdd2c78: CheckStackOverflow
    //     0xdd2c78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd2c7c: cmp             SP, x16
    //     0xdd2c80: b.ls            #0xdd2ef4
    // 0xdd2c84: LoadField: r0 = r2->field_1b
    //     0xdd2c84: ldur            w0, [x2, #0x1b]
    // 0xdd2c88: DecompressPointer r0
    //     0xdd2c88: add             x0, x0, HEAP, lsl #32
    // 0xdd2c8c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd2c90: cmp             w0, w16
    // 0xdd2c94: b.eq            #0xdd2efc
    // 0xdd2c98: LoadField: r1 = r0->field_23
    //     0xdd2c98: ldur            w1, [x0, #0x23]
    // 0xdd2c9c: DecompressPointer r1
    //     0xdd2c9c: add             x1, x1, HEAP, lsl #32
    // 0xdd2ca0: tbnz            w1, #4, #0xdd2cac
    // 0xdd2ca4: d2 = 0.000000
    //     0xdd2ca4: eor             v2.16b, v2.16b, v2.16b
    // 0xdd2ca8: b               #0xdd2cb0
    // 0xdd2cac: d2 = 1.000000
    //     0xdd2cac: fmov            d2, #1.00000000
    // 0xdd2cb0: stur            d2, [fp, #-0x40]
    // 0xdd2cb4: r0 = Radius()
    //     0xdd2cb4: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0xdd2cb8: d0 = 10.000000
    //     0xdd2cb8: fmov            d0, #10.00000000
    // 0xdd2cbc: stur            x0, [fp, #-0x10]
    // 0xdd2cc0: StoreField: r0->field_7 = d0
    //     0xdd2cc0: stur            d0, [x0, #7]
    // 0xdd2cc4: StoreField: r0->field_f = d0
    //     0xdd2cc4: stur            d0, [x0, #0xf]
    // 0xdd2cc8: r0 = BorderRadius()
    //     0xdd2cc8: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0xdd2ccc: mov             x1, x0
    // 0xdd2cd0: ldur            x0, [fp, #-0x10]
    // 0xdd2cd4: stur            x1, [fp, #-0x18]
    // 0xdd2cd8: StoreField: r1->field_7 = r0
    //     0xdd2cd8: stur            w0, [x1, #7]
    // 0xdd2cdc: StoreField: r1->field_b = r0
    //     0xdd2cdc: stur            w0, [x1, #0xb]
    // 0xdd2ce0: StoreField: r1->field_f = r0
    //     0xdd2ce0: stur            w0, [x1, #0xf]
    // 0xdd2ce4: StoreField: r1->field_13 = r0
    //     0xdd2ce4: stur            w0, [x1, #0x13]
    // 0xdd2ce8: r0 = _GaussianBlurImageFilter()
    //     0xdd2ce8: bl              #0x9191c8  ; Allocate_GaussianBlurImageFilterStub -> _GaussianBlurImageFilter (size=0x24)
    // 0xdd2cec: mov             x1, x0
    // 0xdd2cf0: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd2cf4: stur            x1, [fp, #-0x10]
    // 0xdd2cf8: StoreField: r1->field_1f = r0
    //     0xdd2cf8: stur            w0, [x1, #0x1f]
    // 0xdd2cfc: d0 = 10.000000
    //     0xdd2cfc: fmov            d0, #10.00000000
    // 0xdd2d00: StoreField: r1->field_7 = d0
    //     0xdd2d00: stur            d0, [x1, #7]
    // 0xdd2d04: StoreField: r1->field_f = rZR
    //     0xdd2d04: stur            xzr, [x1, #0xf]
    // 0xdd2d08: r0 = EdgeInsets()
    //     0xdd2d08: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xdd2d0c: ldur            d0, [fp, #-0x50]
    // 0xdd2d10: stur            x0, [fp, #-0x28]
    // 0xdd2d14: StoreField: r0->field_7 = d0
    //     0xdd2d14: stur            d0, [x0, #7]
    // 0xdd2d18: StoreField: r0->field_f = rZR
    //     0xdd2d18: stur            xzr, [x0, #0xf]
    // 0xdd2d1c: ArrayStore: r0[0] = d0  ; List_8
    //     0xdd2d1c: stur            d0, [x0, #0x17]
    // 0xdd2d20: StoreField: r0->field_1f = rZR
    //     0xdd2d20: stur            xzr, [x0, #0x1f]
    // 0xdd2d24: ldur            x2, [fp, #-8]
    // 0xdd2d28: LoadField: r1 = r2->field_57
    //     0xdd2d28: ldur            w1, [x2, #0x57]
    // 0xdd2d2c: DecompressPointer r1
    //     0xdd2d2c: add             x1, x1, HEAP, lsl #32
    // 0xdd2d30: cmp             w1, NULL
    // 0xdd2d34: b.eq            #0xdd2f08
    // 0xdd2d38: LoadField: r3 = r1->field_cf
    //     0xdd2d38: ldur            w3, [x1, #0xcf]
    // 0xdd2d3c: DecompressPointer r3
    //     0xdd2d3c: add             x3, x3, HEAP, lsl #32
    // 0xdd2d40: tbnz            w3, #4, #0xdd2d50
    // 0xdd2d44: r4 = Instance_IconData
    //     0xdd2d44: add             x4, PP, #0xd4, lsl #12  ; [pp+0xd4118] Obj!IconData@128a6f1
    //     0xdd2d48: ldr             x4, [x4, #0x118]
    // 0xdd2d4c: b               #0xdd2d58
    // 0xdd2d50: r4 = Instance_IconData
    //     0xdd2d50: add             x4, PP, #0xd4, lsl #12  ; [pp+0xd4120] Obj!IconData@128a6d1
    //     0xdd2d54: ldr             x4, [x4, #0x120]
    // 0xdd2d58: ldur            d0, [fp, #-0x48]
    // 0xdd2d5c: ldur            d1, [fp, #-0x40]
    // 0xdd2d60: ldur            x3, [fp, #-0x18]
    // 0xdd2d64: ldur            x1, [fp, #-0x10]
    // 0xdd2d68: stur            x4, [fp, #-0x20]
    // 0xdd2d6c: r0 = Icon()
    //     0xdd2d6c: bl              #0xd0fd5c  ; AllocateIconStub -> Icon (size=0x40)
    // 0xdd2d70: mov             x1, x0
    // 0xdd2d74: ldur            x0, [fp, #-0x20]
    // 0xdd2d78: stur            x1, [fp, #-0x30]
    // 0xdd2d7c: StoreField: r1->field_b = r0
    //     0xdd2d7c: stur            w0, [x1, #0xb]
    // 0xdd2d80: r0 = 16.000000
    //     0xdd2d80: add             x0, PP, #0x13, lsl #12  ; [pp+0x13df8] 16
    //     0xdd2d84: ldr             x0, [x0, #0xdf8]
    // 0xdd2d88: StoreField: r1->field_f = r0
    //     0xdd2d88: stur            w0, [x1, #0xf]
    // 0xdd2d8c: r0 = Instance_Color
    //     0xdd2d8c: add             x0, PP, #0xd4, lsl #12  ; [pp+0xd4010] Obj!Color@12a3ba1
    //     0xdd2d90: ldr             x0, [x0, #0x10]
    // 0xdd2d94: StoreField: r1->field_23 = r0
    //     0xdd2d94: stur            w0, [x1, #0x23]
    // 0xdd2d98: r0 = Center()
    //     0xdd2d98: bl              #0xd0c898  ; AllocateCenterStub -> Center (size=0x1c)
    // 0xdd2d9c: mov             x1, x0
    // 0xdd2da0: r0 = Instance_Alignment
    //     0xdd2da0: add             x0, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xdd2da4: ldr             x0, [x0, #0xb80]
    // 0xdd2da8: stur            x1, [fp, #-0x38]
    // 0xdd2dac: StoreField: r1->field_f = r0
    //     0xdd2dac: stur            w0, [x1, #0xf]
    // 0xdd2db0: ldur            x0, [fp, #-0x30]
    // 0xdd2db4: StoreField: r1->field_b = r0
    //     0xdd2db4: stur            w0, [x1, #0xb]
    // 0xdd2db8: ldur            d0, [fp, #-0x48]
    // 0xdd2dbc: r0 = inline_Allocate_Double()
    //     0xdd2dbc: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xdd2dc0: add             x0, x0, #0x10
    //     0xdd2dc4: cmp             x2, x0
    //     0xdd2dc8: b.ls            #0xdd2f0c
    //     0xdd2dcc: str             x0, [THR, #0x60]  ; THR::top
    //     0xdd2dd0: sub             x0, x0, #0xf
    //     0xdd2dd4: mov             x2, #0xe19c
    //     0xdd2dd8: movk            x2, #3, lsl #16
    //     0xdd2ddc: stur            x2, [x0, #-1]
    // 0xdd2de0: dmb             ishst
    // 0xdd2de4: StoreField: r0->field_7 = d0
    //     0xdd2de4: stur            d0, [x0, #7]
    // 0xdd2de8: stur            x0, [fp, #-0x20]
    // 0xdd2dec: r0 = Container()
    //     0xdd2dec: bl              #0x8a5af8  ; AllocateContainerStub -> Container (size=0x38)
    // 0xdd2df0: stur            x0, [fp, #-0x30]
    // 0xdd2df4: ldur            x16, [fp, #-0x20]
    // 0xdd2df8: ldur            lr, [fp, #-0x28]
    // 0xdd2dfc: stp             lr, x16, [SP, #0x10]
    // 0xdd2e00: r16 = Instance_Color
    //     0xdd2e00: add             x16, PP, #0xd4, lsl #12  ; [pp+0xd4000] Obj!Color@12a3c61
    //     0xdd2e04: ldr             x16, [x16]
    // 0xdd2e08: ldur            lr, [fp, #-0x38]
    // 0xdd2e0c: stp             lr, x16, [SP]
    // 0xdd2e10: mov             x1, x0
    // 0xdd2e14: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, color, 0x3, height, 0x1, padding, 0x2, null]
    //     0xdd2e14: add             x4, PP, #0xd4, lsl #12  ; [pp+0xd4128] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "color", 0x3, "height", 0x1, "padding", 0x2, Null]
    //     0xdd2e18: ldr             x4, [x4, #0x128]
    // 0xdd2e1c: r0 = Container()
    //     0xdd2e1c: bl              #0x8a54e0  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0xdd2e20: r0 = BackdropFilter()
    //     0xdd2e20: bl              #0x9190e4  ; AllocateBackdropFilterStub -> BackdropFilter (size=0x28)
    // 0xdd2e24: mov             x1, x0
    // 0xdd2e28: ldur            x0, [fp, #-0x10]
    // 0xdd2e2c: stur            x1, [fp, #-0x20]
    // 0xdd2e30: StoreField: r1->field_f = r0
    //     0xdd2e30: stur            w0, [x1, #0xf]
    // 0xdd2e34: r0 = Instance_BlendMode
    //     0xdd2e34: add             x0, PP, #0x16, lsl #12  ; [pp+0x16eb8] Obj!BlendMode@12c82e1
    //     0xdd2e38: ldr             x0, [x0, #0xeb8]
    // 0xdd2e3c: ArrayStore: r1[0] = r0  ; List_4
    //     0xdd2e3c: stur            w0, [x1, #0x17]
    // 0xdd2e40: r0 = true
    //     0xdd2e40: add             x0, NULL, #0x20  ; true
    // 0xdd2e44: StoreField: r1->field_1b = r0
    //     0xdd2e44: stur            w0, [x1, #0x1b]
    // 0xdd2e48: r0 = false
    //     0xdd2e48: add             x0, NULL, #0x30  ; false
    // 0xdd2e4c: StoreField: r1->field_23 = r0
    //     0xdd2e4c: stur            w0, [x1, #0x23]
    // 0xdd2e50: ldur            x2, [fp, #-0x30]
    // 0xdd2e54: StoreField: r1->field_b = r2
    //     0xdd2e54: stur            w2, [x1, #0xb]
    // 0xdd2e58: r0 = ClipRRect()
    //     0xdd2e58: bl              #0xd30168  ; AllocateClipRRectStub -> ClipRRect (size=0x1c)
    // 0xdd2e5c: mov             x1, x0
    // 0xdd2e60: ldur            x0, [fp, #-0x18]
    // 0xdd2e64: stur            x1, [fp, #-0x10]
    // 0xdd2e68: StoreField: r1->field_f = r0
    //     0xdd2e68: stur            w0, [x1, #0xf]
    // 0xdd2e6c: r0 = Instance_Clip
    //     0xdd2e6c: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e6f0] Obj!Clip@12c8101
    //     0xdd2e70: ldr             x0, [x0, #0x6f0]
    // 0xdd2e74: ArrayStore: r1[0] = r0  ; List_4
    //     0xdd2e74: stur            w0, [x1, #0x17]
    // 0xdd2e78: ldur            x0, [fp, #-0x20]
    // 0xdd2e7c: StoreField: r1->field_b = r0
    //     0xdd2e7c: stur            w0, [x1, #0xb]
    // 0xdd2e80: r0 = AnimatedOpacity()
    //     0xdd2e80: bl              #0xd2cf50  ; AllocateAnimatedOpacityStub -> AnimatedOpacity (size=0x28)
    // 0xdd2e84: mov             x1, x0
    // 0xdd2e88: ldur            x0, [fp, #-0x10]
    // 0xdd2e8c: stur            x1, [fp, #-0x18]
    // 0xdd2e90: ArrayStore: r1[0] = r0  ; List_4
    //     0xdd2e90: stur            w0, [x1, #0x17]
    // 0xdd2e94: ldur            d0, [fp, #-0x40]
    // 0xdd2e98: StoreField: r1->field_1b = d0
    //     0xdd2e98: stur            d0, [x1, #0x1b]
    // 0xdd2e9c: r0 = false
    //     0xdd2e9c: add             x0, NULL, #0x30  ; false
    // 0xdd2ea0: StoreField: r1->field_23 = r0
    //     0xdd2ea0: stur            w0, [x1, #0x23]
    // 0xdd2ea4: r0 = Instance__Linear
    //     0xdd2ea4: ldr             x0, [PP, #0x5168]  ; [pp+0x5168] Obj!_Linear@129fef1
    // 0xdd2ea8: StoreField: r1->field_b = r0
    //     0xdd2ea8: stur            w0, [x1, #0xb]
    // 0xdd2eac: r0 = Instance_Duration
    //     0xdd2eac: ldr             x0, [PP, #0x7cd8]  ; [pp+0x7cd8] Obj!Duration@12c8971
    // 0xdd2eb0: StoreField: r1->field_f = r0
    //     0xdd2eb0: stur            w0, [x1, #0xf]
    // 0xdd2eb4: r0 = GestureDetector()
    //     0xdd2eb4: bl              #0x918e18  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0xdd2eb8: ldur            x2, [fp, #-8]
    // 0xdd2ebc: r1 = Function '_onExpandCollapse@450205881':.
    //     0xdd2ebc: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4130] AnonymousClosure: (0xdd2f24), in [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_onExpandCollapse (0xdd2f5c)
    //     0xdd2ec0: ldr             x1, [x1, #0x130]
    // 0xdd2ec4: stur            x0, [fp, #-8]
    // 0xdd2ec8: r0 = AllocateClosure()
    //     0xdd2ec8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd2ecc: ldur            x16, [fp, #-0x18]
    // 0xdd2ed0: stp             x16, x0, [SP]
    // 0xdd2ed4: ldur            x1, [fp, #-8]
    // 0xdd2ed8: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0xdd2ed8: add             x4, PP, #0x16, lsl #12  ; [pp+0x16e90] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0xdd2edc: ldr             x4, [x4, #0xe90]
    // 0xdd2ee0: r0 = GestureDetector()
    //     0xdd2ee0: bl              #0x9182dc  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0xdd2ee4: ldur            x0, [fp, #-8]
    // 0xdd2ee8: LeaveFrame
    //     0xdd2ee8: mov             SP, fp
    //     0xdd2eec: ldp             fp, lr, [SP], #0x10
    // 0xdd2ef0: ret
    //     0xdd2ef0: ret             
    // 0xdd2ef4: r0 = StackOverflowSharedWithFPURegs()
    //     0xdd2ef4: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xdd2ef8: b               #0xdd2c84
    // 0xdd2efc: r9 = notifier
    //     0xdd2efc: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3fb0] Field <_CupertinoControlsState@450205881.notifier>: late (offset: 0x1c)
    //     0xdd2f00: ldr             x9, [x9, #0xfb0]
    // 0xdd2f04: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xdd2f04: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xdd2f08: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd2f08: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdd2f0c: SaveReg d0
    //     0xdd2f0c: str             q0, [SP, #-0x10]!
    // 0xdd2f10: SaveReg r1
    //     0xdd2f10: str             x1, [SP, #-8]!
    // 0xdd2f14: r0 = AllocateDouble()
    //     0xdd2f14: bl              #0x13df878  ; AllocateDoubleStub
    // 0xdd2f18: RestoreReg r1
    //     0xdd2f18: ldr             x1, [SP], #8
    // 0xdd2f1c: RestoreReg d0
    //     0xdd2f1c: ldr             q0, [SP], #0x10
    // 0xdd2f20: b               #0xdd2de4
  }
  [closure] void _onExpandCollapse(dynamic) {
    // ** addr: 0xdd2f24, size: 0x38
    // 0xdd2f24: EnterFrame
    //     0xdd2f24: stp             fp, lr, [SP, #-0x10]!
    //     0xdd2f28: mov             fp, SP
    // 0xdd2f2c: ldr             x0, [fp, #0x10]
    // 0xdd2f30: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdd2f30: ldur            w1, [x0, #0x17]
    // 0xdd2f34: DecompressPointer r1
    //     0xdd2f34: add             x1, x1, HEAP, lsl #32
    // 0xdd2f38: CheckStackOverflow
    //     0xdd2f38: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd2f3c: cmp             SP, x16
    //     0xdd2f40: b.ls            #0xdd2f54
    // 0xdd2f44: r0 = _onExpandCollapse()
    //     0xdd2f44: bl              #0xdd2f5c  ; [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_onExpandCollapse
    // 0xdd2f48: LeaveFrame
    //     0xdd2f48: mov             SP, fp
    //     0xdd2f4c: ldp             fp, lr, [SP], #0x10
    // 0xdd2f50: ret
    //     0xdd2f50: ret             
    // 0xdd2f54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd2f54: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd2f58: b               #0xdd2f44
  }
  _ _onExpandCollapse(/* No info */) {
    // ** addr: 0xdd2f5c, size: 0x64
    // 0xdd2f5c: EnterFrame
    //     0xdd2f5c: stp             fp, lr, [SP, #-0x10]!
    //     0xdd2f60: mov             fp, SP
    // 0xdd2f64: AllocStack(0x8)
    //     0xdd2f64: sub             SP, SP, #8
    // 0xdd2f68: SetupParameters(_CupertinoControlsState this /* r1 => r1, fp-0x8 */)
    //     0xdd2f68: stur            x1, [fp, #-8]
    // 0xdd2f6c: CheckStackOverflow
    //     0xdd2f6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd2f70: cmp             SP, x16
    //     0xdd2f74: b.ls            #0xdd2fb8
    // 0xdd2f78: r1 = 1
    //     0xdd2f78: mov             x1, #1
    // 0xdd2f7c: r0 = AllocateContext()
    //     0xdd2f7c: bl              #0x13de838  ; AllocateContextStub
    // 0xdd2f80: mov             x1, x0
    // 0xdd2f84: ldur            x0, [fp, #-8]
    // 0xdd2f88: StoreField: r1->field_f = r0
    //     0xdd2f88: stur            w0, [x1, #0xf]
    // 0xdd2f8c: mov             x2, x1
    // 0xdd2f90: r1 = Function '<anonymous closure>':.
    //     0xdd2f90: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4138] AnonymousClosure: (0xdd2fc0), in [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_onExpandCollapse (0xdd2f5c)
    //     0xdd2f94: ldr             x1, [x1, #0x138]
    // 0xdd2f98: r0 = AllocateClosure()
    //     0xdd2f98: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd2f9c: ldur            x1, [fp, #-8]
    // 0xdd2fa0: mov             x2, x0
    // 0xdd2fa4: r0 = setState()
    //     0xdd2fa4: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xdd2fa8: r0 = Null
    //     0xdd2fa8: mov             x0, NULL
    // 0xdd2fac: LeaveFrame
    //     0xdd2fac: mov             SP, fp
    //     0xdd2fb0: ldp             fp, lr, [SP], #0x10
    // 0xdd2fb4: ret
    //     0xdd2fb4: ret             
    // 0xdd2fb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd2fb8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd2fbc: b               #0xdd2f78
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xdd2fc0, size: 0xe8
    // 0xdd2fc0: EnterFrame
    //     0xdd2fc0: stp             fp, lr, [SP, #-0x10]!
    //     0xdd2fc4: mov             fp, SP
    // 0xdd2fc8: AllocStack(0x10)
    //     0xdd2fc8: sub             SP, SP, #0x10
    // 0xdd2fcc: SetupParameters([dynamic _ /* r1 */])
    //     0xdd2fcc: add             x0, NULL, #0x20  ; true
    //     0xdd2fd0: ldr             x1, [fp, #0x10]
    //     0xdd2fd4: ldur            w2, [x1, #0x17]
    //     0xdd2fd8: add             x2, x2, HEAP, lsl #32
    //     0xdd2fdc: stur            x2, [fp, #-8]
    // 0xdd2fcc: r0 = true
    // 0xdd2fe0: CheckStackOverflow
    //     0xdd2fe0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd2fe4: cmp             SP, x16
    //     0xdd2fe8: b.ls            #0xdd3090
    // 0xdd2fec: LoadField: r1 = r2->field_f
    //     0xdd2fec: ldur            w1, [x2, #0xf]
    // 0xdd2ff0: DecompressPointer r1
    //     0xdd2ff0: add             x1, x1, HEAP, lsl #32
    // 0xdd2ff4: LoadField: r3 = r1->field_1b
    //     0xdd2ff4: ldur            w3, [x1, #0x1b]
    // 0xdd2ff8: DecompressPointer r3
    //     0xdd2ff8: add             x3, x3, HEAP, lsl #32
    // 0xdd2ffc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd3000: cmp             w3, w16
    // 0xdd3004: b.eq            #0xdd3098
    // 0xdd3008: StoreField: r3->field_23 = r0
    //     0xdd3008: stur            w0, [x3, #0x23]
    // 0xdd300c: mov             x1, x3
    // 0xdd3010: r0 = notifyListeners()
    //     0xdd3010: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xdd3014: ldur            x2, [fp, #-8]
    // 0xdd3018: LoadField: r0 = r2->field_f
    //     0xdd3018: ldur            w0, [x2, #0xf]
    // 0xdd301c: DecompressPointer r0
    //     0xdd301c: add             x0, x0, HEAP, lsl #32
    // 0xdd3020: LoadField: r1 = r0->field_57
    //     0xdd3020: ldur            w1, [x0, #0x57]
    // 0xdd3024: DecompressPointer r1
    //     0xdd3024: add             x1, x1, HEAP, lsl #32
    // 0xdd3028: cmp             w1, NULL
    // 0xdd302c: b.eq            #0xdd30a4
    // 0xdd3030: r0 = toggleFullScreen()
    //     0xdd3030: bl              #0xdd30a8  ; [package:chewie/src/chewie_player.dart] ChewieController::toggleFullScreen
    // 0xdd3034: ldur            x2, [fp, #-8]
    // 0xdd3038: LoadField: r0 = r2->field_f
    //     0xdd3038: ldur            w0, [x2, #0xf]
    // 0xdd303c: DecompressPointer r0
    //     0xdd303c: add             x0, x0, HEAP, lsl #32
    // 0xdd3040: stur            x0, [fp, #-0x10]
    // 0xdd3044: r1 = Function '<anonymous closure>':.
    //     0xdd3044: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4140] AnonymousClosure: (0xdd30e8), in [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_onExpandCollapse (0xdd2f5c)
    //     0xdd3048: ldr             x1, [x1, #0x140]
    // 0xdd304c: r0 = AllocateClosure()
    //     0xdd304c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd3050: mov             x3, x0
    // 0xdd3054: r1 = Null
    //     0xdd3054: mov             x1, NULL
    // 0xdd3058: r2 = Instance_Duration
    //     0xdd3058: ldr             x2, [PP, #0x7cd8]  ; [pp+0x7cd8] Obj!Duration@12c8971
    // 0xdd305c: r0 = Timer()
    //     0xdd305c: bl              #0x7eed74  ; [dart:async] Timer::Timer
    // 0xdd3060: ldur            x1, [fp, #-0x10]
    // 0xdd3064: StoreField: r1->field_33 = r0
    //     0xdd3064: stur            w0, [x1, #0x33]
    //     0xdd3068: ldurb           w16, [x1, #-1]
    //     0xdd306c: ldurb           w17, [x0, #-1]
    //     0xdd3070: and             x16, x17, x16, lsr #2
    //     0xdd3074: tst             x16, HEAP, lsr #32
    //     0xdd3078: b.eq            #0xdd3080
    //     0xdd307c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdd3080: r0 = Null
    //     0xdd3080: mov             x0, NULL
    // 0xdd3084: LeaveFrame
    //     0xdd3084: mov             SP, fp
    //     0xdd3088: ldp             fp, lr, [SP], #0x10
    // 0xdd308c: ret
    //     0xdd308c: ret             
    // 0xdd3090: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd3090: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd3094: b               #0xdd2fec
    // 0xdd3098: r9 = notifier
    //     0xdd3098: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3fb0] Field <_CupertinoControlsState@450205881.notifier>: late (offset: 0x1c)
    //     0xdd309c: ldr             x9, [x9, #0xfb0]
    // 0xdd30a0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd30a0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdd30a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd30a4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xdd30e8, size: 0x60
    // 0xdd30e8: EnterFrame
    //     0xdd30e8: stp             fp, lr, [SP, #-0x10]!
    //     0xdd30ec: mov             fp, SP
    // 0xdd30f0: AllocStack(0x8)
    //     0xdd30f0: sub             SP, SP, #8
    // 0xdd30f4: SetupParameters([dynamic _ /* r0 */])
    //     0xdd30f4: ldr             x0, [fp, #0x10]
    //     0xdd30f8: ldur            w2, [x0, #0x17]
    //     0xdd30fc: add             x2, x2, HEAP, lsl #32
    // 0xdd3100: CheckStackOverflow
    //     0xdd3100: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd3104: cmp             SP, x16
    //     0xdd3108: b.ls            #0xdd3140
    // 0xdd310c: LoadField: r0 = r2->field_f
    //     0xdd310c: ldur            w0, [x2, #0xf]
    // 0xdd3110: DecompressPointer r0
    //     0xdd3110: add             x0, x0, HEAP, lsl #32
    // 0xdd3114: stur            x0, [fp, #-8]
    // 0xdd3118: r1 = Function '<anonymous closure>':.
    //     0xdd3118: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4148] AnonymousClosure: (0xdd3148), in [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::build (0xdcd9bc)
    //     0xdd311c: ldr             x1, [x1, #0x148]
    // 0xdd3120: r0 = AllocateClosure()
    //     0xdd3120: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd3124: ldur            x1, [fp, #-8]
    // 0xdd3128: mov             x2, x0
    // 0xdd312c: r0 = setState()
    //     0xdd312c: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xdd3130: r0 = Null
    //     0xdd3130: mov             x0, NULL
    // 0xdd3134: LeaveFrame
    //     0xdd3134: mov             SP, fp
    //     0xdd3138: ldp             fp, lr, [SP], #0x10
    // 0xdd313c: ret
    //     0xdd313c: ret             
    // 0xdd3140: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd3140: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd3144: b               #0xdd310c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xdd3148, size: 0x48
    // 0xdd3148: EnterFrame
    //     0xdd3148: stp             fp, lr, [SP, #-0x10]!
    //     0xdd314c: mov             fp, SP
    // 0xdd3150: ldr             x0, [fp, #0x10]
    // 0xdd3154: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdd3154: ldur            w1, [x0, #0x17]
    // 0xdd3158: DecompressPointer r1
    //     0xdd3158: add             x1, x1, HEAP, lsl #32
    // 0xdd315c: CheckStackOverflow
    //     0xdd315c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd3160: cmp             SP, x16
    //     0xdd3164: b.ls            #0xdd3188
    // 0xdd3168: LoadField: r0 = r1->field_f
    //     0xdd3168: ldur            w0, [x1, #0xf]
    // 0xdd316c: DecompressPointer r0
    //     0xdd316c: add             x0, x0, HEAP, lsl #32
    // 0xdd3170: mov             x1, x0
    // 0xdd3174: r0 = _cancelAndRestartTimer()
    //     0xdd3174: bl              #0xdd0d64  ; [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_cancelAndRestartTimer
    // 0xdd3178: r0 = Null
    //     0xdd3178: mov             x0, NULL
    // 0xdd317c: LeaveFrame
    //     0xdd317c: mov             SP, fp
    //     0xdd3180: ldp             fp, lr, [SP], #0x10
    // 0xdd3184: ret
    //     0xdd3184: ret             
    // 0xdd3188: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd3188: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd318c: b               #0xdd3168
  }
  _ _buildHitArea(/* No info */) {
    // ** addr: 0xdd3190, size: 0x218
    // 0xdd3190: EnterFrame
    //     0xdd3190: stp             fp, lr, [SP, #-0x10]!
    //     0xdd3194: mov             fp, SP
    // 0xdd3198: AllocStack(0x40)
    //     0xdd3198: sub             SP, SP, #0x40
    // 0xdd319c: SetupParameters(_CupertinoControlsState this /* r1 => r2, fp-0x8 */)
    //     0xdd319c: mov             x2, x1
    //     0xdd31a0: stur            x1, [fp, #-8]
    // 0xdd31a4: CheckStackOverflow
    //     0xdd31a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd31a8: cmp             SP, x16
    //     0xdd31ac: b.ls            #0xdd3384
    // 0xdd31b0: r1 = 1
    //     0xdd31b0: mov             x1, #1
    // 0xdd31b4: r0 = AllocateContext()
    //     0xdd31b4: bl              #0x13de838  ; AllocateContextStub
    // 0xdd31b8: mov             x1, x0
    // 0xdd31bc: ldur            x0, [fp, #-8]
    // 0xdd31c0: StoreField: r1->field_f = r0
    //     0xdd31c0: stur            w0, [x1, #0xf]
    // 0xdd31c4: LoadField: r2 = r0->field_1f
    //     0xdd31c4: ldur            w2, [x0, #0x1f]
    // 0xdd31c8: DecompressPointer r2
    //     0xdd31c8: add             x2, x2, HEAP, lsl #32
    // 0xdd31cc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd31d0: cmp             w2, w16
    // 0xdd31d4: b.eq            #0xdd338c
    // 0xdd31d8: LoadField: r3 = r2->field_b
    //     0xdd31d8: ldur            w3, [x2, #0xb]
    // 0xdd31dc: DecompressPointer r3
    //     0xdd31dc: add             x3, x3, HEAP, lsl #32
    // 0xdd31e0: LoadField: r4 = r2->field_7
    //     0xdd31e0: ldur            w4, [x2, #7]
    // 0xdd31e4: DecompressPointer r4
    //     0xdd31e4: add             x4, x4, HEAP, lsl #32
    // 0xdd31e8: LoadField: r5 = r3->field_7
    //     0xdd31e8: ldur            x5, [x3, #7]
    // 0xdd31ec: LoadField: r3 = r4->field_7
    //     0xdd31ec: ldur            x3, [x4, #7]
    // 0xdd31f0: cmp             x5, x3
    // 0xdd31f4: b.lt            #0xdd3218
    // 0xdd31f8: r4 = 1000000
    //     0xdd31f8: mov             x4, #0x4240
    //     0xdd31fc: movk            x4, #0xf, lsl #16
    // 0xdd3200: sdiv            x5, x3, x4
    // 0xdd3204: cmp             x5, #0
    // 0xdd3208: r16 = true
    //     0xdd3208: add             x16, NULL, #0x20  ; true
    // 0xdd320c: r17 = false
    //     0xdd320c: add             x17, NULL, #0x30  ; false
    // 0xdd3210: csel            x3, x16, x17, gt
    // 0xdd3214: b               #0xdd321c
    // 0xdd3218: r3 = false
    //     0xdd3218: add             x3, NULL, #0x30  ; false
    // 0xdd321c: stur            x3, [fp, #-0x18]
    // 0xdd3220: LoadField: r4 = r0->field_b
    //     0xdd3220: ldur            w4, [x0, #0xb]
    // 0xdd3224: DecompressPointer r4
    //     0xdd3224: add             x4, x4, HEAP, lsl #32
    // 0xdd3228: cmp             w4, NULL
    // 0xdd322c: b.eq            #0xdd3398
    // 0xdd3230: LoadField: r4 = r2->field_1b
    //     0xdd3230: ldur            w4, [x2, #0x1b]
    // 0xdd3234: DecompressPointer r4
    //     0xdd3234: add             x4, x4, HEAP, lsl #32
    // 0xdd3238: tbz             w4, #4, #0xdd324c
    // 0xdd323c: LoadField: r2 = r0->field_3b
    //     0xdd323c: ldur            w2, [x0, #0x3b]
    // 0xdd3240: DecompressPointer r2
    //     0xdd3240: add             x2, x2, HEAP, lsl #32
    // 0xdd3244: eor             x5, x2, #0x10
    // 0xdd3248: b               #0xdd3250
    // 0xdd324c: r5 = false
    //     0xdd324c: add             x5, NULL, #0x30  ; false
    // 0xdd3250: stur            x5, [fp, #-0x10]
    // 0xdd3254: tbnz            w4, #4, #0xdd32ac
    // 0xdd3258: LoadField: r2 = r0->field_57
    //     0xdd3258: ldur            w2, [x0, #0x57]
    // 0xdd325c: DecompressPointer r2
    //     0xdd325c: add             x2, x2, HEAP, lsl #32
    // 0xdd3260: cmp             w2, NULL
    // 0xdd3264: b.ne            #0xdd3270
    // 0xdd3268: r2 = Null
    //     0xdd3268: mov             x2, NULL
    // 0xdd326c: b               #0xdd3274
    // 0xdd3270: r2 = false
    //     0xdd3270: add             x2, NULL, #0x30  ; false
    // 0xdd3274: cmp             w2, NULL
    // 0xdd3278: b.eq            #0xdd3294
    // 0xdd327c: tbnz            w2, #4, #0xdd3294
    // 0xdd3280: mov             x2, x1
    // 0xdd3284: r1 = Function '<anonymous closure>':.
    //     0xdd3284: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4150] AnonymousClosure: (0xdd3900), in [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_buildHitArea (0xdd3190)
    //     0xdd3288: ldr             x1, [x1, #0x150]
    // 0xdd328c: r0 = AllocateClosure()
    //     0xdd328c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd3290: b               #0xdd32a4
    // 0xdd3294: ldur            x2, [fp, #-8]
    // 0xdd3298: r1 = Function '_cancelAndRestartTimer@450205881':.
    //     0xdd3298: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4158] AnonymousClosure: (0xdd0de0), in [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_cancelAndRestartTimer (0xdd0d64)
    //     0xdd329c: ldr             x1, [x1, #0x158]
    // 0xdd32a0: r0 = AllocateClosure()
    //     0xdd32a0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd32a4: mov             x3, x0
    // 0xdd32a8: b               #0xdd32c0
    // 0xdd32ac: mov             x2, x1
    // 0xdd32b0: r1 = Function '<anonymous closure>':.
    //     0xdd32b0: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4160] AnonymousClosure: (0xdd33b4), in [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_buildHitArea (0xdd3190)
    //     0xdd32b4: ldr             x1, [x1, #0x160]
    // 0xdd32b8: r0 = AllocateClosure()
    //     0xdd32b8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd32bc: mov             x3, x0
    // 0xdd32c0: ldur            x2, [fp, #-8]
    // 0xdd32c4: ldur            x0, [fp, #-0x18]
    // 0xdd32c8: ldur            x1, [fp, #-0x10]
    // 0xdd32cc: stur            x3, [fp, #-0x28]
    // 0xdd32d0: LoadField: r4 = r2->field_53
    //     0xdd32d0: ldur            w4, [x2, #0x53]
    // 0xdd32d4: DecompressPointer r4
    //     0xdd32d4: add             x4, x4, HEAP, lsl #32
    // 0xdd32d8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd32dc: cmp             w4, w16
    // 0xdd32e0: b.eq            #0xdd339c
    // 0xdd32e4: LoadField: r5 = r4->field_27
    //     0xdd32e4: ldur            w5, [x4, #0x27]
    // 0xdd32e8: DecompressPointer r5
    //     0xdd32e8: add             x5, x5, HEAP, lsl #32
    // 0xdd32ec: LoadField: r4 = r5->field_1b
    //     0xdd32ec: ldur            w4, [x5, #0x1b]
    // 0xdd32f0: DecompressPointer r4
    //     0xdd32f0: add             x4, x4, HEAP, lsl #32
    // 0xdd32f4: stur            x4, [fp, #-0x20]
    // 0xdd32f8: r0 = CenterPlayButton()
    //     0xdd32f8: bl              #0xdd33a8  ; AllocateCenterPlayButtonStub -> CenterPlayButton (size=0x24)
    // 0xdd32fc: mov             x3, x0
    // 0xdd3300: r0 = Instance_Color
    //     0xdd3300: add             x0, PP, #0xd4, lsl #12  ; [pp+0xd4000] Obj!Color@12a3c61
    //     0xdd3304: ldr             x0, [x0]
    // 0xdd3308: stur            x3, [fp, #-0x30]
    // 0xdd330c: StoreField: r3->field_b = r0
    //     0xdd330c: stur            w0, [x3, #0xb]
    // 0xdd3310: r0 = Instance_Color
    //     0xdd3310: add             x0, PP, #0xd4, lsl #12  ; [pp+0xd4010] Obj!Color@12a3ba1
    //     0xdd3314: ldr             x0, [x0, #0x10]
    // 0xdd3318: StoreField: r3->field_f = r0
    //     0xdd3318: stur            w0, [x3, #0xf]
    // 0xdd331c: ldur            x0, [fp, #-0x10]
    // 0xdd3320: StoreField: r3->field_13 = r0
    //     0xdd3320: stur            w0, [x3, #0x13]
    // 0xdd3324: ldur            x0, [fp, #-0x20]
    // 0xdd3328: ArrayStore: r3[0] = r0  ; List_4
    //     0xdd3328: stur            w0, [x3, #0x17]
    // 0xdd332c: ldur            x0, [fp, #-0x18]
    // 0xdd3330: StoreField: r3->field_1b = r0
    //     0xdd3330: stur            w0, [x3, #0x1b]
    // 0xdd3334: ldur            x2, [fp, #-8]
    // 0xdd3338: r1 = Function '_playPause@450205881':.
    //     0xdd3338: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd40d0] AnonymousClosure: (0xdd104c), in [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_playPause (0xdd1084)
    //     0xdd333c: ldr             x1, [x1, #0xd0]
    // 0xdd3340: r0 = AllocateClosure()
    //     0xdd3340: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd3344: mov             x1, x0
    // 0xdd3348: ldur            x0, [fp, #-0x30]
    // 0xdd334c: StoreField: r0->field_1f = r1
    //     0xdd334c: stur            w1, [x0, #0x1f]
    // 0xdd3350: r0 = GestureDetector()
    //     0xdd3350: bl              #0x918e18  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0xdd3354: stur            x0, [fp, #-8]
    // 0xdd3358: ldur            x16, [fp, #-0x28]
    // 0xdd335c: ldur            lr, [fp, #-0x30]
    // 0xdd3360: stp             lr, x16, [SP]
    // 0xdd3364: mov             x1, x0
    // 0xdd3368: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0xdd3368: add             x4, PP, #0x16, lsl #12  ; [pp+0x16e90] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0xdd336c: ldr             x4, [x4, #0xe90]
    // 0xdd3370: r0 = GestureDetector()
    //     0xdd3370: bl              #0x9182dc  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0xdd3374: ldur            x0, [fp, #-8]
    // 0xdd3378: LeaveFrame
    //     0xdd3378: mov             SP, fp
    //     0xdd337c: ldp             fp, lr, [SP], #0x10
    // 0xdd3380: ret
    //     0xdd3380: ret             
    // 0xdd3384: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd3384: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd3388: b               #0xdd31b0
    // 0xdd338c: r9 = _latestValue
    //     0xdd338c: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3ff0] Field <_CupertinoControlsState@450205881._latestValue@450205881>: late (offset: 0x20)
    //     0xdd3390: ldr             x9, [x9, #0xff0]
    // 0xdd3394: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd3394: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdd3398: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd3398: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdd339c: r9 = controller
    //     0xdd339c: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3fa0] Field <_CupertinoControlsState@450205881.controller>: late (offset: 0x54)
    //     0xdd33a0: ldr             x9, [x9, #0xfa0]
    // 0xdd33a4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd33a4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xdd33b4, size: 0x84
    // 0xdd33b4: EnterFrame
    //     0xdd33b4: stp             fp, lr, [SP, #-0x10]!
    //     0xdd33b8: mov             fp, SP
    // 0xdd33bc: AllocStack(0x10)
    //     0xdd33bc: sub             SP, SP, #0x10
    // 0xdd33c0: SetupParameters([dynamic _ /* r0 */])
    //     0xdd33c0: ldr             x0, [fp, #0x10]
    //     0xdd33c4: ldur            w2, [x0, #0x17]
    //     0xdd33c8: add             x2, x2, HEAP, lsl #32
    //     0xdd33cc: stur            x2, [fp, #-8]
    // 0xdd33d0: CheckStackOverflow
    //     0xdd33d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd33d4: cmp             SP, x16
    //     0xdd33d8: b.ls            #0xdd3430
    // 0xdd33dc: LoadField: r0 = r2->field_f
    //     0xdd33dc: ldur            w0, [x2, #0xf]
    // 0xdd33e0: DecompressPointer r0
    //     0xdd33e0: add             x0, x0, HEAP, lsl #32
    // 0xdd33e4: LoadField: r1 = r0->field_27
    //     0xdd33e4: ldur            w1, [x0, #0x27]
    // 0xdd33e8: DecompressPointer r1
    //     0xdd33e8: add             x1, x1, HEAP, lsl #32
    // 0xdd33ec: cmp             w1, NULL
    // 0xdd33f0: b.eq            #0xdd33fc
    // 0xdd33f4: r0 = cancel()
    //     0xdd33f4: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0xdd33f8: ldur            x2, [fp, #-8]
    // 0xdd33fc: LoadField: r0 = r2->field_f
    //     0xdd33fc: ldur            w0, [x2, #0xf]
    // 0xdd3400: DecompressPointer r0
    //     0xdd3400: add             x0, x0, HEAP, lsl #32
    // 0xdd3404: stur            x0, [fp, #-0x10]
    // 0xdd3408: r1 = Function '<anonymous closure>':.
    //     0xdd3408: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4168] AnonymousClosure: (0xdd3438), in [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_initialize (0xdd3508)
    //     0xdd340c: ldr             x1, [x1, #0x168]
    // 0xdd3410: r0 = AllocateClosure()
    //     0xdd3410: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd3414: ldur            x1, [fp, #-0x10]
    // 0xdd3418: mov             x2, x0
    // 0xdd341c: r0 = setState()
    //     0xdd341c: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xdd3420: r0 = Null
    //     0xdd3420: mov             x0, NULL
    // 0xdd3424: LeaveFrame
    //     0xdd3424: mov             SP, fp
    //     0xdd3428: ldp             fp, lr, [SP], #0x10
    // 0xdd342c: ret
    //     0xdd342c: ret             
    // 0xdd3430: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd3430: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd3434: b               #0xdd33dc
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xdd3438, size: 0x70
    // 0xdd3438: EnterFrame
    //     0xdd3438: stp             fp, lr, [SP, #-0x10]!
    //     0xdd343c: mov             fp, SP
    // 0xdd3440: r0 = false
    //     0xdd3440: add             x0, NULL, #0x30  ; false
    // 0xdd3444: ldr             x1, [fp, #0x10]
    // 0xdd3448: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xdd3448: ldur            w2, [x1, #0x17]
    // 0xdd344c: DecompressPointer r2
    //     0xdd344c: add             x2, x2, HEAP, lsl #32
    // 0xdd3450: CheckStackOverflow
    //     0xdd3450: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd3454: cmp             SP, x16
    //     0xdd3458: b.ls            #0xdd3494
    // 0xdd345c: LoadField: r1 = r2->field_f
    //     0xdd345c: ldur            w1, [x2, #0xf]
    // 0xdd3460: DecompressPointer r1
    //     0xdd3460: add             x1, x1, HEAP, lsl #32
    // 0xdd3464: LoadField: r2 = r1->field_1b
    //     0xdd3464: ldur            w2, [x1, #0x1b]
    // 0xdd3468: DecompressPointer r2
    //     0xdd3468: add             x2, x2, HEAP, lsl #32
    // 0xdd346c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd3470: cmp             w2, w16
    // 0xdd3474: b.eq            #0xdd349c
    // 0xdd3478: StoreField: r2->field_23 = r0
    //     0xdd3478: stur            w0, [x2, #0x23]
    // 0xdd347c: mov             x1, x2
    // 0xdd3480: r0 = notifyListeners()
    //     0xdd3480: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xdd3484: r0 = Null
    //     0xdd3484: mov             x0, NULL
    // 0xdd3488: LeaveFrame
    //     0xdd3488: mov             SP, fp
    //     0xdd348c: ldp             fp, lr, [SP], #0x10
    // 0xdd3490: ret
    //     0xdd3490: ret             
    // 0xdd3494: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd3494: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd3498: b               #0xdd345c
    // 0xdd349c: r9 = notifier
    //     0xdd349c: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3fb0] Field <_CupertinoControlsState@450205881.notifier>: late (offset: 0x1c)
    //     0xdd34a0: ldr             x9, [x9, #0xfb0]
    // 0xdd34a4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd34a4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xdd34a8, size: 0x60
    // 0xdd34a8: EnterFrame
    //     0xdd34a8: stp             fp, lr, [SP, #-0x10]!
    //     0xdd34ac: mov             fp, SP
    // 0xdd34b0: AllocStack(0x8)
    //     0xdd34b0: sub             SP, SP, #8
    // 0xdd34b4: SetupParameters([dynamic _ /* r0 */])
    //     0xdd34b4: ldr             x0, [fp, #0x10]
    //     0xdd34b8: ldur            w2, [x0, #0x17]
    //     0xdd34bc: add             x2, x2, HEAP, lsl #32
    // 0xdd34c0: CheckStackOverflow
    //     0xdd34c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd34c4: cmp             SP, x16
    //     0xdd34c8: b.ls            #0xdd3500
    // 0xdd34cc: LoadField: r0 = r2->field_f
    //     0xdd34cc: ldur            w0, [x2, #0xf]
    // 0xdd34d0: DecompressPointer r0
    //     0xdd34d0: add             x0, x0, HEAP, lsl #32
    // 0xdd34d4: stur            x0, [fp, #-8]
    // 0xdd34d8: r1 = Function '<anonymous closure>':.
    //     0xdd34d8: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3fa8] AnonymousClosure: (0xdd3438), in [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_initialize (0xdd3508)
    //     0xdd34dc: ldr             x1, [x1, #0xfa8]
    // 0xdd34e0: r0 = AllocateClosure()
    //     0xdd34e0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd34e4: ldur            x1, [fp, #-8]
    // 0xdd34e8: mov             x2, x0
    // 0xdd34ec: r0 = setState()
    //     0xdd34ec: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xdd34f0: r0 = Null
    //     0xdd34f0: mov             x0, NULL
    // 0xdd34f4: LeaveFrame
    //     0xdd34f4: mov             SP, fp
    //     0xdd34f8: ldp             fp, lr, [SP], #0x10
    // 0xdd34fc: ret
    //     0xdd34fc: ret             
    // 0xdd3500: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd3500: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd3504: b               #0xdd34cc
  }
  _ _initialize(/* No info */) async {
    // ** addr: 0xdd3508, size: 0x16c
    // 0xdd3508: EnterFrame
    //     0xdd3508: stp             fp, lr, [SP, #-0x10]!
    //     0xdd350c: mov             fp, SP
    // 0xdd3510: AllocStack(0x20)
    //     0xdd3510: sub             SP, SP, #0x20
    // 0xdd3514: SetupParameters(_CupertinoControlsState this /* r1 => r2, fp-0x10 */)
    //     0xdd3514: stur            NULL, [fp, #-8]
    //     0xdd3518: mov             x2, x1
    //     0xdd351c: stur            x1, [fp, #-0x10]
    // 0xdd3520: CheckStackOverflow
    //     0xdd3520: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd3524: cmp             SP, x16
    //     0xdd3528: b.ls            #0xdd3654
    // 0xdd352c: r1 = 1
    //     0xdd352c: mov             x1, #1
    // 0xdd3530: r0 = AllocateContext()
    //     0xdd3530: bl              #0x13de838  ; AllocateContextStub
    // 0xdd3534: mov             x1, x0
    // 0xdd3538: ldur            x2, [fp, #-0x10]
    // 0xdd353c: stur            x1, [fp, #-0x18]
    // 0xdd3540: StoreField: r1->field_f = r2
    //     0xdd3540: stur            w2, [x1, #0xf]
    // 0xdd3544: InitAsync() -> Future<void?>
    //     0xdd3544: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0xdd3548: bl              #0x7f5e44  ; InitAsyncStub
    // 0xdd354c: ldur            x0, [fp, #-0x10]
    // 0xdd3550: LoadField: r1 = r0->field_57
    //     0xdd3550: ldur            w1, [x0, #0x57]
    // 0xdd3554: DecompressPointer r1
    //     0xdd3554: add             x1, x1, HEAP, lsl #32
    // 0xdd3558: cmp             w1, NULL
    // 0xdd355c: b.eq            #0xdd365c
    // 0xdd3560: r1 = false
    //     0xdd3560: add             x1, NULL, #0x30  ; false
    // 0xdd3564: StoreField: r0->field_3f = r1
    //     0xdd3564: stur            w1, [x0, #0x3f]
    // 0xdd3568: LoadField: r3 = r0->field_53
    //     0xdd3568: ldur            w3, [x0, #0x53]
    // 0xdd356c: DecompressPointer r3
    //     0xdd356c: add             x3, x3, HEAP, lsl #32
    // 0xdd3570: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd3574: cmp             w3, w16
    // 0xdd3578: b.eq            #0xdd3660
    // 0xdd357c: mov             x2, x0
    // 0xdd3580: stur            x3, [fp, #-0x20]
    // 0xdd3584: r1 = Function '_updateState@450205881':.
    //     0xdd3584: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3f90] AnonymousClosure: (0xdd38c8), in [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_updateState (0xdd3674)
    //     0xdd3588: ldr             x1, [x1, #0xf90]
    // 0xdd358c: r0 = AllocateClosure()
    //     0xdd358c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd3590: ldur            x1, [fp, #-0x20]
    // 0xdd3594: mov             x2, x0
    // 0xdd3598: r0 = addListener()
    //     0xdd3598: bl              #0xd038e0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0xdd359c: ldur            x1, [fp, #-0x10]
    // 0xdd35a0: r0 = _updateState()
    //     0xdd35a0: bl              #0xdd3674  ; [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_updateState
    // 0xdd35a4: ldur            x0, [fp, #-0x10]
    // 0xdd35a8: LoadField: r1 = r0->field_53
    //     0xdd35a8: ldur            w1, [x0, #0x53]
    // 0xdd35ac: DecompressPointer r1
    //     0xdd35ac: add             x1, x1, HEAP, lsl #32
    // 0xdd35b0: LoadField: r2 = r1->field_27
    //     0xdd35b0: ldur            w2, [x1, #0x27]
    // 0xdd35b4: DecompressPointer r2
    //     0xdd35b4: add             x2, x2, HEAP, lsl #32
    // 0xdd35b8: LoadField: r1 = r2->field_1b
    //     0xdd35b8: ldur            w1, [x2, #0x1b]
    // 0xdd35bc: DecompressPointer r1
    //     0xdd35bc: add             x1, x1, HEAP, lsl #32
    // 0xdd35c0: tbz             w1, #4, #0xdd35e0
    // 0xdd35c4: LoadField: r1 = r0->field_57
    //     0xdd35c4: ldur            w1, [x0, #0x57]
    // 0xdd35c8: DecompressPointer r1
    //     0xdd35c8: add             x1, x1, HEAP, lsl #32
    // 0xdd35cc: cmp             w1, NULL
    // 0xdd35d0: b.eq            #0xdd366c
    // 0xdd35d4: LoadField: r2 = r1->field_43
    //     0xdd35d4: ldur            w2, [x1, #0x43]
    // 0xdd35d8: DecompressPointer r2
    //     0xdd35d8: add             x2, x2, HEAP, lsl #32
    // 0xdd35dc: tbnz            w2, #4, #0xdd35e8
    // 0xdd35e0: mov             x1, x0
    // 0xdd35e4: r0 = _startHideTimer()
    //     0xdd35e4: bl              #0xdce790  ; [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_startHideTimer
    // 0xdd35e8: ldur            x0, [fp, #-0x10]
    // 0xdd35ec: LoadField: r1 = r0->field_57
    //     0xdd35ec: ldur            w1, [x0, #0x57]
    // 0xdd35f0: DecompressPointer r1
    //     0xdd35f0: add             x1, x1, HEAP, lsl #32
    // 0xdd35f4: cmp             w1, NULL
    // 0xdd35f8: b.eq            #0xdd3670
    // 0xdd35fc: LoadField: r2 = r1->field_53
    //     0xdd35fc: ldur            w2, [x1, #0x53]
    // 0xdd3600: DecompressPointer r2
    //     0xdd3600: add             x2, x2, HEAP, lsl #32
    // 0xdd3604: tbnz            w2, #4, #0xdd364c
    // 0xdd3608: ldur            x2, [fp, #-0x18]
    // 0xdd360c: r1 = Function '<anonymous closure>':.
    //     0xdd360c: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3f98] AnonymousClosure: (0xdd34a8), in [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_initialize (0xdd3508)
    //     0xdd3610: ldr             x1, [x1, #0xf98]
    // 0xdd3614: r0 = AllocateClosure()
    //     0xdd3614: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd3618: mov             x3, x0
    // 0xdd361c: r1 = Null
    //     0xdd361c: mov             x1, NULL
    // 0xdd3620: r2 = Instance_Duration
    //     0xdd3620: add             x2, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xdd3624: ldr             x2, [x2, #0x318]
    // 0xdd3628: r0 = Timer()
    //     0xdd3628: bl              #0x7eed74  ; [dart:async] Timer::Timer
    // 0xdd362c: ldur            x1, [fp, #-0x10]
    // 0xdd3630: StoreField: r1->field_37 = r0
    //     0xdd3630: stur            w0, [x1, #0x37]
    //     0xdd3634: ldurb           w16, [x1, #-1]
    //     0xdd3638: ldurb           w17, [x0, #-1]
    //     0xdd363c: and             x16, x17, x16, lsr #2
    //     0xdd3640: tst             x16, HEAP, lsr #32
    //     0xdd3644: b.eq            #0xdd364c
    //     0xdd3648: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdd364c: r0 = Null
    //     0xdd364c: mov             x0, NULL
    // 0xdd3650: r0 = ReturnAsyncNotFuture()
    //     0xdd3650: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xdd3654: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd3654: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd3658: b               #0xdd352c
    // 0xdd365c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd365c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdd3660: r9 = controller
    //     0xdd3660: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3fa0] Field <_CupertinoControlsState@450205881.controller>: late (offset: 0x54)
    //     0xdd3664: ldr             x9, [x9, #0xfa0]
    // 0xdd3668: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd3668: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdd366c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd366c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdd3670: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd3670: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateState(/* No info */) {
    // ** addr: 0xdd3674, size: 0xcc
    // 0xdd3674: EnterFrame
    //     0xdd3674: stp             fp, lr, [SP, #-0x10]!
    //     0xdd3678: mov             fp, SP
    // 0xdd367c: AllocStack(0x10)
    //     0xdd367c: sub             SP, SP, #0x10
    // 0xdd3680: SetupParameters(_CupertinoControlsState this /* r1 => r1, fp-0x8 */)
    //     0xdd3680: stur            x1, [fp, #-8]
    // 0xdd3684: CheckStackOverflow
    //     0xdd3684: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd3688: cmp             SP, x16
    //     0xdd368c: b.ls            #0xdd3728
    // 0xdd3690: r1 = 1
    //     0xdd3690: mov             x1, #1
    // 0xdd3694: r0 = AllocateContext()
    //     0xdd3694: bl              #0x13de838  ; AllocateContextStub
    // 0xdd3698: mov             x2, x0
    // 0xdd369c: ldur            x0, [fp, #-8]
    // 0xdd36a0: stur            x2, [fp, #-0x10]
    // 0xdd36a4: StoreField: r2->field_f = r0
    //     0xdd36a4: stur            w0, [x2, #0xf]
    // 0xdd36a8: LoadField: r1 = r0->field_f
    //     0xdd36a8: ldur            w1, [x0, #0xf]
    // 0xdd36ac: DecompressPointer r1
    //     0xdd36ac: add             x1, x1, HEAP, lsl #32
    // 0xdd36b0: cmp             w1, NULL
    // 0xdd36b4: b.ne            #0xdd36c8
    // 0xdd36b8: r0 = Null
    //     0xdd36b8: mov             x0, NULL
    // 0xdd36bc: LeaveFrame
    //     0xdd36bc: mov             SP, fp
    //     0xdd36c0: ldp             fp, lr, [SP], #0x10
    // 0xdd36c4: ret
    //     0xdd36c4: ret             
    // 0xdd36c8: LoadField: r1 = r0->field_53
    //     0xdd36c8: ldur            w1, [x0, #0x53]
    // 0xdd36cc: DecompressPointer r1
    //     0xdd36cc: add             x1, x1, HEAP, lsl #32
    // 0xdd36d0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd36d4: cmp             w1, w16
    // 0xdd36d8: b.eq            #0xdd3730
    // 0xdd36dc: r0 = getIsBuffering()
    //     0xdd36dc: bl              #0xdd3740  ; [package:chewie/src/helpers/utils.dart] ::getIsBuffering
    // 0xdd36e0: mov             x1, x0
    // 0xdd36e4: ldur            x0, [fp, #-8]
    // 0xdd36e8: LoadField: r2 = r0->field_57
    //     0xdd36e8: ldur            w2, [x0, #0x57]
    // 0xdd36ec: DecompressPointer r2
    //     0xdd36ec: add             x2, x2, HEAP, lsl #32
    // 0xdd36f0: cmp             w2, NULL
    // 0xdd36f4: b.eq            #0xdd373c
    // 0xdd36f8: StoreField: r0->field_47 = r1
    //     0xdd36f8: stur            w1, [x0, #0x47]
    // 0xdd36fc: ldur            x2, [fp, #-0x10]
    // 0xdd3700: r1 = Function '<anonymous closure>':.
    //     0xdd3700: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3fc8] AnonymousClosure: (0xdd3858), in [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_updateState (0xdd3674)
    //     0xdd3704: ldr             x1, [x1, #0xfc8]
    // 0xdd3708: r0 = AllocateClosure()
    //     0xdd3708: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd370c: ldur            x1, [fp, #-8]
    // 0xdd3710: mov             x2, x0
    // 0xdd3714: r0 = setState()
    //     0xdd3714: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xdd3718: r0 = Null
    //     0xdd3718: mov             x0, NULL
    // 0xdd371c: LeaveFrame
    //     0xdd371c: mov             SP, fp
    //     0xdd3720: ldp             fp, lr, [SP], #0x10
    // 0xdd3724: ret
    //     0xdd3724: ret             
    // 0xdd3728: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd3728: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd372c: b               #0xdd3690
    // 0xdd3730: r9 = controller
    //     0xdd3730: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3fa0] Field <_CupertinoControlsState@450205881.controller>: late (offset: 0x54)
    //     0xdd3734: ldr             x9, [x9, #0xfa0]
    // 0xdd3738: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd3738: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdd373c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd373c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xdd3858, size: 0x70
    // 0xdd3858: ldr             x1, [SP]
    // 0xdd385c: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xdd385c: ldur            w2, [x1, #0x17]
    // 0xdd3860: DecompressPointer r2
    //     0xdd3860: add             x2, x2, HEAP, lsl #32
    // 0xdd3864: LoadField: r1 = r2->field_f
    //     0xdd3864: ldur            w1, [x2, #0xf]
    // 0xdd3868: DecompressPointer r1
    //     0xdd3868: add             x1, x1, HEAP, lsl #32
    // 0xdd386c: LoadField: r2 = r1->field_53
    //     0xdd386c: ldur            w2, [x1, #0x53]
    // 0xdd3870: DecompressPointer r2
    //     0xdd3870: add             x2, x2, HEAP, lsl #32
    // 0xdd3874: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd3878: cmp             w2, w16
    // 0xdd387c: b.eq            #0xdd38b4
    // 0xdd3880: LoadField: r0 = r2->field_27
    //     0xdd3880: ldur            w0, [x2, #0x27]
    // 0xdd3884: DecompressPointer r0
    //     0xdd3884: add             x0, x0, HEAP, lsl #32
    // 0xdd3888: StoreField: r1->field_1f = r0
    //     0xdd3888: stur            w0, [x1, #0x1f]
    //     0xdd388c: ldurb           w16, [x1, #-1]
    //     0xdd3890: ldurb           w17, [x0, #-1]
    //     0xdd3894: and             x16, x17, x16, lsr #2
    //     0xdd3898: tst             x16, HEAP, lsr #32
    //     0xdd389c: b.eq            #0xdd38ac
    //     0xdd38a0: str             lr, [SP, #-8]!
    //     0xdd38a4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    //     0xdd38a8: ldr             lr, [SP], #8
    // 0xdd38ac: r0 = Null
    //     0xdd38ac: mov             x0, NULL
    // 0xdd38b0: ret
    //     0xdd38b0: ret             
    // 0xdd38b4: EnterFrame
    //     0xdd38b4: stp             fp, lr, [SP, #-0x10]!
    //     0xdd38b8: mov             fp, SP
    // 0xdd38bc: r9 = controller
    //     0xdd38bc: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3fa0] Field <_CupertinoControlsState@450205881.controller>: late (offset: 0x54)
    //     0xdd38c0: ldr             x9, [x9, #0xfa0]
    // 0xdd38c4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdd38c4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void _updateState(dynamic) {
    // ** addr: 0xdd38c8, size: 0x38
    // 0xdd38c8: EnterFrame
    //     0xdd38c8: stp             fp, lr, [SP, #-0x10]!
    //     0xdd38cc: mov             fp, SP
    // 0xdd38d0: ldr             x0, [fp, #0x10]
    // 0xdd38d4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdd38d4: ldur            w1, [x0, #0x17]
    // 0xdd38d8: DecompressPointer r1
    //     0xdd38d8: add             x1, x1, HEAP, lsl #32
    // 0xdd38dc: CheckStackOverflow
    //     0xdd38dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd38e0: cmp             SP, x16
    //     0xdd38e4: b.ls            #0xdd38f8
    // 0xdd38e8: r0 = _updateState()
    //     0xdd38e8: bl              #0xdd3674  ; [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_updateState
    // 0xdd38ec: LeaveFrame
    //     0xdd38ec: mov             SP, fp
    //     0xdd38f0: ldp             fp, lr, [SP], #0x10
    // 0xdd38f4: ret
    //     0xdd38f4: ret             
    // 0xdd38f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd38f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd38fc: b               #0xdd38e8
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xdd3900, size: 0x74
    // 0xdd3900: EnterFrame
    //     0xdd3900: stp             fp, lr, [SP, #-0x10]!
    //     0xdd3904: mov             fp, SP
    // 0xdd3908: AllocStack(0x10)
    //     0xdd3908: sub             SP, SP, #0x10
    // 0xdd390c: SetupParameters([dynamic _ /* r0 */])
    //     0xdd390c: ldr             x0, [fp, #0x10]
    //     0xdd3910: ldur            w2, [x0, #0x17]
    //     0xdd3914: add             x2, x2, HEAP, lsl #32
    //     0xdd3918: stur            x2, [fp, #-8]
    // 0xdd391c: CheckStackOverflow
    //     0xdd391c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd3920: cmp             SP, x16
    //     0xdd3924: b.ls            #0xdd396c
    // 0xdd3928: LoadField: r1 = r2->field_f
    //     0xdd3928: ldur            w1, [x2, #0xf]
    // 0xdd392c: DecompressPointer r1
    //     0xdd392c: add             x1, x1, HEAP, lsl #32
    // 0xdd3930: r0 = _playPause()
    //     0xdd3930: bl              #0xdd1084  ; [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_playPause
    // 0xdd3934: ldur            x2, [fp, #-8]
    // 0xdd3938: LoadField: r0 = r2->field_f
    //     0xdd3938: ldur            w0, [x2, #0xf]
    // 0xdd393c: DecompressPointer r0
    //     0xdd393c: add             x0, x0, HEAP, lsl #32
    // 0xdd3940: stur            x0, [fp, #-0x10]
    // 0xdd3944: r1 = Function '<anonymous closure>':.
    //     0xdd3944: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4170] AnonymousClosure: (0xdce890), in [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_startHideTimer (0xdce790)
    //     0xdd3948: ldr             x1, [x1, #0x170]
    // 0xdd394c: r0 = AllocateClosure()
    //     0xdd394c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdd3950: ldur            x1, [fp, #-0x10]
    // 0xdd3954: mov             x2, x0
    // 0xdd3958: r0 = setState()
    //     0xdd3958: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xdd395c: r0 = Null
    //     0xdd395c: mov             x0, NULL
    // 0xdd3960: LeaveFrame
    //     0xdd3960: mov             SP, fp
    //     0xdd3964: ldp             fp, lr, [SP], #0x10
    // 0xdd3968: ret
    //     0xdd3968: ret             
    // 0xdd396c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd396c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd3970: b               #0xdd3928
  }
  [closure] void <anonymous closure>(dynamic, PointerHoverEvent) {
    // ** addr: 0xdd3974, size: 0x48
    // 0xdd3974: EnterFrame
    //     0xdd3974: stp             fp, lr, [SP, #-0x10]!
    //     0xdd3978: mov             fp, SP
    // 0xdd397c: ldr             x0, [fp, #0x18]
    // 0xdd3980: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdd3980: ldur            w1, [x0, #0x17]
    // 0xdd3984: DecompressPointer r1
    //     0xdd3984: add             x1, x1, HEAP, lsl #32
    // 0xdd3988: CheckStackOverflow
    //     0xdd3988: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd398c: cmp             SP, x16
    //     0xdd3990: b.ls            #0xdd39b4
    // 0xdd3994: LoadField: r0 = r1->field_f
    //     0xdd3994: ldur            w0, [x1, #0xf]
    // 0xdd3998: DecompressPointer r0
    //     0xdd3998: add             x0, x0, HEAP, lsl #32
    // 0xdd399c: mov             x1, x0
    // 0xdd39a0: r0 = _cancelAndRestartTimer()
    //     0xdd39a0: bl              #0xdd0d64  ; [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_cancelAndRestartTimer
    // 0xdd39a4: r0 = Null
    //     0xdd39a4: mov             x0, NULL
    // 0xdd39a8: LeaveFrame
    //     0xdd39a8: mov             SP, fp
    //     0xdd39ac: ldp             fp, lr, [SP], #0x10
    // 0xdd39b0: ret
    //     0xdd39b0: ret             
    // 0xdd39b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd39b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd39b8: b               #0xdd3994
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0xef2f1c, size: 0xc0
    // 0xef2f1c: EnterFrame
    //     0xef2f1c: stp             fp, lr, [SP, #-0x10]!
    //     0xef2f20: mov             fp, SP
    // 0xef2f24: AllocStack(0x10)
    //     0xef2f24: sub             SP, SP, #0x10
    // 0xef2f28: SetupParameters(_CupertinoControlsState this /* r1 => r0, fp-0x10 */)
    //     0xef2f28: mov             x0, x1
    //     0xef2f2c: stur            x1, [fp, #-0x10]
    // 0xef2f30: CheckStackOverflow
    //     0xef2f30: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef2f34: cmp             SP, x16
    //     0xef2f38: b.ls            #0xef2fd0
    // 0xef2f3c: LoadField: r2 = r0->field_57
    //     0xef2f3c: ldur            w2, [x0, #0x57]
    // 0xef2f40: DecompressPointer r2
    //     0xef2f40: add             x2, x2, HEAP, lsl #32
    // 0xef2f44: stur            x2, [fp, #-8]
    // 0xef2f48: LoadField: r1 = r0->field_f
    //     0xef2f48: ldur            w1, [x0, #0xf]
    // 0xef2f4c: DecompressPointer r1
    //     0xef2f4c: add             x1, x1, HEAP, lsl #32
    // 0xef2f50: cmp             w1, NULL
    // 0xef2f54: b.eq            #0xef2fd8
    // 0xef2f58: r0 = of()
    //     0xef2f58: bl              #0xef309c  ; [package:chewie/src/chewie_player.dart] ChewieController::of
    // 0xef2f5c: mov             x1, x0
    // 0xef2f60: ldur            x2, [fp, #-0x10]
    // 0xef2f64: StoreField: r2->field_57 = r0
    //     0xef2f64: stur            w0, [x2, #0x57]
    //     0xef2f68: ldurb           w16, [x2, #-1]
    //     0xef2f6c: ldurb           w17, [x0, #-1]
    //     0xef2f70: and             x16, x17, x16, lsr #2
    //     0xef2f74: tst             x16, HEAP, lsr #32
    //     0xef2f78: b.eq            #0xef2f80
    //     0xef2f7c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xef2f80: LoadField: r0 = r1->field_3b
    //     0xef2f80: ldur            w0, [x1, #0x3b]
    // 0xef2f84: DecompressPointer r0
    //     0xef2f84: add             x0, x0, HEAP, lsl #32
    // 0xef2f88: StoreField: r2->field_53 = r0
    //     0xef2f88: stur            w0, [x2, #0x53]
    //     0xef2f8c: ldurb           w16, [x2, #-1]
    //     0xef2f90: ldurb           w17, [x0, #-1]
    //     0xef2f94: and             x16, x17, x16, lsr #2
    //     0xef2f98: tst             x16, HEAP, lsr #32
    //     0xef2f9c: b.eq            #0xef2fa4
    //     0xef2fa0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xef2fa4: ldur            x0, [fp, #-8]
    // 0xef2fa8: cmp             w0, w1
    // 0xef2fac: b.eq            #0xef2fc0
    // 0xef2fb0: mov             x1, x2
    // 0xef2fb4: r0 = _dispose()
    //     0xef2fb4: bl              #0xef2fdc  ; [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_dispose
    // 0xef2fb8: ldur            x1, [fp, #-0x10]
    // 0xef2fbc: r0 = _initialize()
    //     0xef2fbc: bl              #0xdd3508  ; [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_initialize
    // 0xef2fc0: r0 = Null
    //     0xef2fc0: mov             x0, NULL
    // 0xef2fc4: LeaveFrame
    //     0xef2fc4: mov             SP, fp
    //     0xef2fc8: ldp             fp, lr, [SP], #0x10
    // 0xef2fcc: ret
    //     0xef2fcc: ret             
    // 0xef2fd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef2fd0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef2fd4: b               #0xef2f3c
    // 0xef2fd8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef2fd8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _dispose(/* No info */) {
    // ** addr: 0xef2fdc, size: 0xc0
    // 0xef2fdc: EnterFrame
    //     0xef2fdc: stp             fp, lr, [SP, #-0x10]!
    //     0xef2fe0: mov             fp, SP
    // 0xef2fe4: AllocStack(0x10)
    //     0xef2fe4: sub             SP, SP, #0x10
    // 0xef2fe8: SetupParameters(_CupertinoControlsState this /* r1 => r0, fp-0x10 */)
    //     0xef2fe8: mov             x0, x1
    //     0xef2fec: stur            x1, [fp, #-0x10]
    // 0xef2ff0: CheckStackOverflow
    //     0xef2ff0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef2ff4: cmp             SP, x16
    //     0xef2ff8: b.ls            #0xef3088
    // 0xef2ffc: LoadField: r3 = r0->field_53
    //     0xef2ffc: ldur            w3, [x0, #0x53]
    // 0xef3000: DecompressPointer r3
    //     0xef3000: add             x3, x3, HEAP, lsl #32
    // 0xef3004: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xef3008: cmp             w3, w16
    // 0xef300c: b.eq            #0xef3090
    // 0xef3010: mov             x2, x0
    // 0xef3014: stur            x3, [fp, #-8]
    // 0xef3018: r1 = Function '_updateState@450205881':.
    //     0xef3018: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3f90] AnonymousClosure: (0xdd38c8), in [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_updateState (0xdd3674)
    //     0xef301c: ldr             x1, [x1, #0xf90]
    // 0xef3020: r0 = AllocateClosure()
    //     0xef3020: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xef3024: ldur            x1, [fp, #-8]
    // 0xef3028: mov             x2, x0
    // 0xef302c: r0 = removeListener()
    //     0xef302c: bl              #0xcff784  ; [package:video_player/video_player.dart] VideoPlayerController::removeListener
    // 0xef3030: ldur            x0, [fp, #-0x10]
    // 0xef3034: LoadField: r1 = r0->field_27
    //     0xef3034: ldur            w1, [x0, #0x27]
    // 0xef3038: DecompressPointer r1
    //     0xef3038: add             x1, x1, HEAP, lsl #32
    // 0xef303c: cmp             w1, NULL
    // 0xef3040: b.eq            #0xef304c
    // 0xef3044: r0 = cancel()
    //     0xef3044: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0xef3048: ldur            x0, [fp, #-0x10]
    // 0xef304c: LoadField: r1 = r0->field_33
    //     0xef304c: ldur            w1, [x0, #0x33]
    // 0xef3050: DecompressPointer r1
    //     0xef3050: add             x1, x1, HEAP, lsl #32
    // 0xef3054: cmp             w1, NULL
    // 0xef3058: b.eq            #0xef3064
    // 0xef305c: r0 = cancel()
    //     0xef305c: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0xef3060: ldur            x0, [fp, #-0x10]
    // 0xef3064: LoadField: r1 = r0->field_37
    //     0xef3064: ldur            w1, [x0, #0x37]
    // 0xef3068: DecompressPointer r1
    //     0xef3068: add             x1, x1, HEAP, lsl #32
    // 0xef306c: cmp             w1, NULL
    // 0xef3070: b.eq            #0xef3078
    // 0xef3074: r0 = cancel()
    //     0xef3074: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0xef3078: r0 = Null
    //     0xef3078: mov             x0, NULL
    // 0xef307c: LeaveFrame
    //     0xef307c: mov             SP, fp
    //     0xef3080: ldp             fp, lr, [SP], #0x10
    // 0xef3084: ret
    //     0xef3084: ret             
    // 0xef3088: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef3088: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef308c: b               #0xef2ffc
    // 0xef3090: r9 = controller
    //     0xef3090: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3fa0] Field <_CupertinoControlsState@450205881.controller>: late (offset: 0x54)
    //     0xef3094: ldr             x9, [x9, #0xfa0]
    // 0xef3098: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xef3098: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10e2744, size: 0x48
    // 0x10e2744: EnterFrame
    //     0x10e2744: stp             fp, lr, [SP, #-0x10]!
    //     0x10e2748: mov             fp, SP
    // 0x10e274c: AllocStack(0x8)
    //     0x10e274c: sub             SP, SP, #8
    // 0x10e2750: SetupParameters(_CupertinoControlsState this /* r1 => r0, fp-0x8 */)
    //     0x10e2750: mov             x0, x1
    //     0x10e2754: stur            x1, [fp, #-8]
    // 0x10e2758: CheckStackOverflow
    //     0x10e2758: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e275c: cmp             SP, x16
    //     0x10e2760: b.ls            #0x10e2784
    // 0x10e2764: mov             x1, x0
    // 0x10e2768: r0 = _dispose()
    //     0x10e2768: bl              #0xef2fdc  ; [package:chewie/src/cupertino/cupertino_controls.dart] _CupertinoControlsState::_dispose
    // 0x10e276c: ldur            x1, [fp, #-8]
    // 0x10e2770: r0 = dispose()
    //     0x10e2770: bl              #0x10e278c  ; [dart:mixin_deduplication] _MixinApplication737&State&SingleTickerProviderStateMixin::dispose
    // 0x10e2774: r0 = Null
    //     0x10e2774: mov             x0, NULL
    // 0x10e2778: LeaveFrame
    //     0x10e2778: mov             SP, fp
    //     0x10e277c: ldp             fp, lr, [SP], #0x10
    // 0x10e2780: ret
    //     0x10e2780: ret             
    // 0x10e2784: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e2784: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e2788: b               #0x10e2764
  }
}

// class id: 6216, size: 0x18, field offset: 0xc
//   const constructor, 
class _PlaybackSpeedDialog extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfaa378, size: 0x1e8
    // 0xfaa378: EnterFrame
    //     0xfaa378: stp             fp, lr, [SP, #-0x10]!
    //     0xfaa37c: mov             fp, SP
    // 0xfaa380: AllocStack(0x30)
    //     0xfaa380: sub             SP, SP, #0x30
    // 0xfaa384: SetupParameters(_PlaybackSpeedDialog this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xfaa384: mov             x0, x1
    //     0xfaa388: stur            x1, [fp, #-8]
    //     0xfaa38c: mov             x1, x2
    //     0xfaa390: stur            x2, [fp, #-0x10]
    // 0xfaa394: CheckStackOverflow
    //     0xfaa394: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfaa398: cmp             SP, x16
    //     0xfaa39c: b.ls            #0xfaa558
    // 0xfaa3a0: r1 = 3
    //     0xfaa3a0: mov             x1, #3
    // 0xfaa3a4: r0 = AllocateContext()
    //     0xfaa3a4: bl              #0x13de838  ; AllocateContextStub
    // 0xfaa3a8: mov             x2, x0
    // 0xfaa3ac: ldur            x0, [fp, #-8]
    // 0xfaa3b0: stur            x2, [fp, #-0x18]
    // 0xfaa3b4: StoreField: r2->field_f = r0
    //     0xfaa3b4: stur            w0, [x2, #0xf]
    // 0xfaa3b8: ldur            x1, [fp, #-0x10]
    // 0xfaa3bc: StoreField: r2->field_13 = r1
    //     0xfaa3bc: stur            w1, [x2, #0x13]
    // 0xfaa3c0: r0 = of()
    //     0xfaa3c0: bl              #0xccc364  ; [package:flutter/src/cupertino/theme.dart] CupertinoTheme::of
    // 0xfaa3c4: r1 = LoadClassIdInstr(r0)
    //     0xfaa3c4: ldur            x1, [x0, #-1]
    //     0xfaa3c8: ubfx            x1, x1, #0xc, #0x14
    // 0xfaa3cc: r17 = 4617
    //     0xfaa3cc: mov             x17, #0x1209
    // 0xfaa3d0: cmp             x1, x17
    // 0xfaa3d4: b.ne            #0xfaa3ec
    // 0xfaa3d8: LoadField: r1 = r0->field_27
    //     0xfaa3d8: ldur            w1, [x0, #0x27]
    // 0xfaa3dc: DecompressPointer r1
    //     0xfaa3dc: add             x1, x1, HEAP, lsl #32
    // 0xfaa3e0: LoadField: r0 = r1->field_b
    //     0xfaa3e0: ldur            w0, [x1, #0xb]
    // 0xfaa3e4: DecompressPointer r0
    //     0xfaa3e4: add             x0, x0, HEAP, lsl #32
    // 0xfaa3e8: b               #0xfaa408
    // 0xfaa3ec: LoadField: r1 = r0->field_2b
    //     0xfaa3ec: ldur            w1, [x0, #0x2b]
    // 0xfaa3f0: DecompressPointer r1
    //     0xfaa3f0: add             x1, x1, HEAP, lsl #32
    // 0xfaa3f4: LoadField: r0 = r1->field_3f
    //     0xfaa3f4: ldur            w0, [x1, #0x3f]
    // 0xfaa3f8: DecompressPointer r0
    //     0xfaa3f8: add             x0, x0, HEAP, lsl #32
    // 0xfaa3fc: LoadField: r1 = r0->field_b
    //     0xfaa3fc: ldur            w1, [x0, #0xb]
    // 0xfaa400: DecompressPointer r1
    //     0xfaa400: add             x1, x1, HEAP, lsl #32
    // 0xfaa404: mov             x0, x1
    // 0xfaa408: ldur            x2, [fp, #-0x18]
    // 0xfaa40c: ArrayStore: r2[0] = r0  ; List_4
    //     0xfaa40c: stur            w0, [x2, #0x17]
    //     0xfaa410: ldurb           w16, [x2, #-1]
    //     0xfaa414: ldurb           w17, [x0, #-1]
    //     0xfaa418: and             x16, x17, x16, lsr #2
    //     0xfaa41c: tst             x16, HEAP, lsr #32
    //     0xfaa420: b.eq            #0xfaa428
    //     0xfaa424: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xfaa428: r1 = Function '<anonymous closure>':.
    //     0xfaa428: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4728] AnonymousClosure: (0xfaa560), in [package:chewie/src/cupertino/cupertino_controls.dart] _PlaybackSpeedDialog::build (0xfaa378)
    //     0xfaa42c: ldr             x1, [x1, #0x728]
    // 0xfaa430: r0 = AllocateClosure()
    //     0xfaa430: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfaa434: r16 = <CupertinoActionSheetAction>
    //     0xfaa434: add             x16, PP, #0xd4, lsl #12  ; [pp+0xd4730] TypeArguments: <CupertinoActionSheetAction>
    //     0xfaa438: ldr             x16, [x16, #0x730]
    // 0xfaa43c: r30 = const [0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0]
    //     0xfaa43c: add             lr, PP, #0xa5, lsl #12  ; [pp+0xa5f68] List<double>(8)
    //     0xfaa440: ldr             lr, [lr, #0xf68]
    // 0xfaa444: stp             lr, x16, [SP, #8]
    // 0xfaa448: str             x0, [SP]
    // 0xfaa44c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xfaa44c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xfaa450: r0 = map()
    //     0xfaa450: bl              #0xba574c  ; [dart:collection] ListBase::map
    // 0xfaa454: mov             x3, x0
    // 0xfaa458: stur            x3, [fp, #-0x10]
    // 0xfaa45c: LoadField: r4 = r3->field_7
    //     0xfaa45c: ldur            w4, [x3, #7]
    // 0xfaa460: DecompressPointer r4
    //     0xfaa460: add             x4, x4, HEAP, lsl #32
    // 0xfaa464: mov             x0, x3
    // 0xfaa468: stur            x4, [fp, #-8]
    // 0xfaa46c: r2 = Null
    //     0xfaa46c: mov             x2, NULL
    // 0xfaa470: r1 = Null
    //     0xfaa470: mov             x1, NULL
    // 0xfaa474: cmp             w0, NULL
    // 0xfaa478: b.eq            #0xfaa510
    // 0xfaa47c: branchIfSmi(r0, 0xfaa510)
    //     0xfaa47c: tbz             w0, #0, #0xfaa510
    // 0xfaa480: r3 = LoadClassIdInstr(r0)
    //     0xfaa480: ldur            x3, [x0, #-1]
    //     0xfaa484: ubfx            x3, x3, #0xc, #0x14
    // 0xfaa488: r17 = 7724
    //     0xfaa488: mov             x17, #0x1e2c
    // 0xfaa48c: cmp             x3, x17
    // 0xfaa490: b.eq            #0xfaa518
    // 0xfaa494: r4 = LoadClassIdInstr(r0)
    //     0xfaa494: ldur            x4, [x0, #-1]
    //     0xfaa498: ubfx            x4, x4, #0xc, #0x14
    // 0xfaa49c: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0xfaa4a0: ldr             x3, [x3, #0x18]
    // 0xfaa4a4: ldr             x3, [x3, x4, lsl #3]
    // 0xfaa4a8: LoadField: r3 = r3->field_2b
    //     0xfaa4a8: ldur            w3, [x3, #0x2b]
    // 0xfaa4ac: DecompressPointer r3
    //     0xfaa4ac: add             x3, x3, HEAP, lsl #32
    // 0xfaa4b0: cmp             w3, NULL
    // 0xfaa4b4: b.eq            #0xfaa510
    // 0xfaa4b8: LoadField: r3 = r3->field_f
    //     0xfaa4b8: ldur            w3, [x3, #0xf]
    // 0xfaa4bc: lsr             x3, x3, #3
    // 0xfaa4c0: r17 = 7724
    //     0xfaa4c0: mov             x17, #0x1e2c
    // 0xfaa4c4: cmp             x3, x17
    // 0xfaa4c8: b.eq            #0xfaa518
    // 0xfaa4cc: r3 = SubtypeTestCache
    //     0xfaa4cc: add             x3, PP, #0xd4, lsl #12  ; [pp+0xd4738] SubtypeTestCache
    //     0xfaa4d0: ldr             x3, [x3, #0x738]
    // 0xfaa4d4: r30 = Subtype1TestCacheStub
    //     0xfaa4d4: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0xfaa4d8: LoadField: r30 = r30->field_7
    //     0xfaa4d8: ldur            lr, [lr, #7]
    // 0xfaa4dc: blr             lr
    // 0xfaa4e0: cmp             w7, NULL
    // 0xfaa4e4: b.eq            #0xfaa4f0
    // 0xfaa4e8: tbnz            w7, #4, #0xfaa510
    // 0xfaa4ec: b               #0xfaa518
    // 0xfaa4f0: r8 = EfficientLengthIterable
    //     0xfaa4f0: add             x8, PP, #0xd4, lsl #12  ; [pp+0xd4740] Type: EfficientLengthIterable
    //     0xfaa4f4: ldr             x8, [x8, #0x740]
    // 0xfaa4f8: r3 = SubtypeTestCache
    //     0xfaa4f8: add             x3, PP, #0xd4, lsl #12  ; [pp+0xd4748] SubtypeTestCache
    //     0xfaa4fc: ldr             x3, [x3, #0x748]
    // 0xfaa500: r30 = InstanceOfStub
    //     0xfaa500: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0xfaa504: LoadField: r30 = r30->field_7
    //     0xfaa504: ldur            lr, [lr, #7]
    // 0xfaa508: blr             lr
    // 0xfaa50c: b               #0xfaa51c
    // 0xfaa510: r0 = false
    //     0xfaa510: add             x0, NULL, #0x30  ; false
    // 0xfaa514: b               #0xfaa51c
    // 0xfaa518: r0 = true
    //     0xfaa518: add             x0, NULL, #0x20  ; true
    // 0xfaa51c: tbnz            w0, #4, #0xfaa530
    // 0xfaa520: ldur            x1, [fp, #-8]
    // 0xfaa524: ldur            x2, [fp, #-0x10]
    // 0xfaa528: r0 = _GrowableList._ofEfficientLengthIterable()
    //     0xfaa528: bl              #0x7d732c  ; [dart:core] _GrowableList::_GrowableList._ofEfficientLengthIterable
    // 0xfaa52c: b               #0xfaa53c
    // 0xfaa530: ldur            x1, [fp, #-8]
    // 0xfaa534: ldur            x2, [fp, #-0x10]
    // 0xfaa538: r0 = _GrowableList._ofOther()
    //     0xfaa538: bl              #0x7d94b4  ; [dart:core] _GrowableList::_GrowableList._ofOther
    // 0xfaa53c: stur            x0, [fp, #-8]
    // 0xfaa540: r0 = CupertinoActionSheet()
    //     0xfaa540: bl              #0xde20cc  ; AllocateCupertinoActionSheetStub -> CupertinoActionSheet (size=0x20)
    // 0xfaa544: ldur            x1, [fp, #-8]
    // 0xfaa548: StoreField: r0->field_13 = r1
    //     0xfaa548: stur            w1, [x0, #0x13]
    // 0xfaa54c: LeaveFrame
    //     0xfaa54c: mov             SP, fp
    //     0xfaa550: ldp             fp, lr, [SP], #0x10
    // 0xfaa554: ret
    //     0xfaa554: ret             
    // 0xfaa558: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfaa558: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfaa55c: b               #0xfaa3a0
  }
  [closure] CupertinoActionSheetAction <anonymous closure>(dynamic, double) {
    // ** addr: 0xfaa560, size: 0x274
    // 0xfaa560: EnterFrame
    //     0xfaa560: stp             fp, lr, [SP, #-0x10]!
    //     0xfaa564: mov             fp, SP
    // 0xfaa568: AllocStack(0x30)
    //     0xfaa568: sub             SP, SP, #0x30
    // 0xfaa56c: SetupParameters([dynamic _ /* r0 */])
    //     0xfaa56c: ldr             x0, [fp, #0x18]
    //     0xfaa570: ldur            w1, [x0, #0x17]
    //     0xfaa574: add             x1, x1, HEAP, lsl #32
    //     0xfaa578: stur            x1, [fp, #-8]
    // 0xfaa57c: CheckStackOverflow
    //     0xfaa57c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfaa580: cmp             SP, x16
    //     0xfaa584: b.ls            #0xfaa7cc
    // 0xfaa588: r1 = 1
    //     0xfaa588: mov             x1, #1
    // 0xfaa58c: r0 = AllocateContext()
    //     0xfaa58c: bl              #0x13de838  ; AllocateContextStub
    // 0xfaa590: mov             x3, x0
    // 0xfaa594: ldur            x0, [fp, #-8]
    // 0xfaa598: stur            x3, [fp, #-0x10]
    // 0xfaa59c: StoreField: r3->field_b = r0
    //     0xfaa59c: stur            w0, [x3, #0xb]
    // 0xfaa5a0: ldr             x4, [fp, #0x10]
    // 0xfaa5a4: StoreField: r3->field_f = r4
    //     0xfaa5a4: stur            w4, [x3, #0xf]
    // 0xfaa5a8: r1 = <Widget>
    //     0xfaa5a8: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xfaa5ac: r2 = 0
    //     0xfaa5ac: mov             x2, #0
    // 0xfaa5b0: r0 = _GrowableList()
    //     0xfaa5b0: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xfaa5b4: mov             x1, x0
    // 0xfaa5b8: ldur            x0, [fp, #-8]
    // 0xfaa5bc: stur            x1, [fp, #-0x20]
    // 0xfaa5c0: LoadField: r2 = r0->field_f
    //     0xfaa5c0: ldur            w2, [x0, #0xf]
    // 0xfaa5c4: DecompressPointer r2
    //     0xfaa5c4: add             x2, x2, HEAP, lsl #32
    // 0xfaa5c8: LoadField: d0 = r2->field_f
    //     0xfaa5c8: ldur            d0, [x2, #0xf]
    // 0xfaa5cc: ldr             x2, [fp, #0x10]
    // 0xfaa5d0: LoadField: d1 = r2->field_7
    //     0xfaa5d0: ldur            d1, [x2, #7]
    // 0xfaa5d4: fcmp            d1, d0
    // 0xfaa5d8: b.ne            #0xfaa690
    // 0xfaa5dc: ArrayLoad: r3 = r0[0]  ; List_4
    //     0xfaa5dc: ldur            w3, [x0, #0x17]
    // 0xfaa5e0: DecompressPointer r3
    //     0xfaa5e0: add             x3, x3, HEAP, lsl #32
    // 0xfaa5e4: stur            x3, [fp, #-0x18]
    // 0xfaa5e8: r0 = Icon()
    //     0xfaa5e8: bl              #0xd0fd5c  ; AllocateIconStub -> Icon (size=0x40)
    // 0xfaa5ec: mov             x2, x0
    // 0xfaa5f0: r0 = Instance_IconData
    //     0xfaa5f0: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1ad80] Obj!IconData@128a9b1
    //     0xfaa5f4: ldr             x0, [x0, #0xd80]
    // 0xfaa5f8: stur            x2, [fp, #-8]
    // 0xfaa5fc: StoreField: r2->field_b = r0
    //     0xfaa5fc: stur            w0, [x2, #0xb]
    // 0xfaa600: r0 = 20.000000
    //     0xfaa600: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1ae98] 20
    //     0xfaa604: ldr             x0, [x0, #0xe98]
    // 0xfaa608: StoreField: r2->field_f = r0
    //     0xfaa608: stur            w0, [x2, #0xf]
    // 0xfaa60c: ldur            x0, [fp, #-0x18]
    // 0xfaa610: StoreField: r2->field_23 = r0
    //     0xfaa610: stur            w0, [x2, #0x23]
    // 0xfaa614: ldur            x0, [fp, #-0x20]
    // 0xfaa618: LoadField: r1 = r0->field_b
    //     0xfaa618: ldur            w1, [x0, #0xb]
    // 0xfaa61c: LoadField: r3 = r0->field_f
    //     0xfaa61c: ldur            w3, [x0, #0xf]
    // 0xfaa620: DecompressPointer r3
    //     0xfaa620: add             x3, x3, HEAP, lsl #32
    // 0xfaa624: LoadField: r4 = r3->field_b
    //     0xfaa624: ldur            w4, [x3, #0xb]
    // 0xfaa628: r3 = LoadInt32Instr(r1)
    //     0xfaa628: sbfx            x3, x1, #1, #0x1f
    // 0xfaa62c: stur            x3, [fp, #-0x28]
    // 0xfaa630: r1 = LoadInt32Instr(r4)
    //     0xfaa630: sbfx            x1, x4, #1, #0x1f
    // 0xfaa634: cmp             x3, x1
    // 0xfaa638: b.ne            #0xfaa644
    // 0xfaa63c: mov             x1, x0
    // 0xfaa640: r0 = _growToNextCapacity()
    //     0xfaa640: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xfaa644: ldur            x2, [fp, #-0x20]
    // 0xfaa648: ldur            x3, [fp, #-0x28]
    // 0xfaa64c: add             x0, x3, #1
    // 0xfaa650: lsl             x1, x0, #1
    // 0xfaa654: StoreField: r2->field_b = r1
    //     0xfaa654: stur            w1, [x2, #0xb]
    // 0xfaa658: LoadField: r1 = r2->field_f
    //     0xfaa658: ldur            w1, [x2, #0xf]
    // 0xfaa65c: DecompressPointer r1
    //     0xfaa65c: add             x1, x1, HEAP, lsl #32
    // 0xfaa660: ldur            x0, [fp, #-8]
    // 0xfaa664: ArrayStore: r1[r3] = r0  ; List_4
    //     0xfaa664: add             x25, x1, x3, lsl #2
    //     0xfaa668: add             x25, x25, #0xf
    //     0xfaa66c: str             w0, [x25]
    //     0xfaa670: tbz             w0, #0, #0xfaa68c
    //     0xfaa674: ldurb           w16, [x1, #-1]
    //     0xfaa678: ldurb           w17, [x0, #-1]
    //     0xfaa67c: and             x16, x17, x16, lsr #2
    //     0xfaa680: tst             x16, HEAP, lsr #32
    //     0xfaa684: b.eq            #0xfaa68c
    //     0xfaa688: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xfaa68c: b               #0xfaa694
    // 0xfaa690: mov             x2, x1
    // 0xfaa694: ldr             x16, [fp, #0x10]
    // 0xfaa698: str             x16, [SP]
    // 0xfaa69c: r0 = toString()
    //     0xfaa69c: bl              #0x112a5f0  ; [dart:core] _Double::toString
    // 0xfaa6a0: stur            x0, [fp, #-8]
    // 0xfaa6a4: r0 = Text()
    //     0xfaa6a4: bl              #0x8a70a4  ; AllocateTextStub -> Text (size=0x50)
    // 0xfaa6a8: mov             x2, x0
    // 0xfaa6ac: ldur            x0, [fp, #-8]
    // 0xfaa6b0: stur            x2, [fp, #-0x18]
    // 0xfaa6b4: StoreField: r2->field_b = r0
    //     0xfaa6b4: stur            w0, [x2, #0xb]
    // 0xfaa6b8: ldur            x0, [fp, #-0x20]
    // 0xfaa6bc: LoadField: r1 = r0->field_b
    //     0xfaa6bc: ldur            w1, [x0, #0xb]
    // 0xfaa6c0: LoadField: r3 = r0->field_f
    //     0xfaa6c0: ldur            w3, [x0, #0xf]
    // 0xfaa6c4: DecompressPointer r3
    //     0xfaa6c4: add             x3, x3, HEAP, lsl #32
    // 0xfaa6c8: LoadField: r4 = r3->field_b
    //     0xfaa6c8: ldur            w4, [x3, #0xb]
    // 0xfaa6cc: r3 = LoadInt32Instr(r1)
    //     0xfaa6cc: sbfx            x3, x1, #1, #0x1f
    // 0xfaa6d0: stur            x3, [fp, #-0x28]
    // 0xfaa6d4: r1 = LoadInt32Instr(r4)
    //     0xfaa6d4: sbfx            x1, x4, #1, #0x1f
    // 0xfaa6d8: cmp             x3, x1
    // 0xfaa6dc: b.ne            #0xfaa6e8
    // 0xfaa6e0: mov             x1, x0
    // 0xfaa6e4: r0 = _growToNextCapacity()
    //     0xfaa6e4: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xfaa6e8: ldur            x2, [fp, #-0x20]
    // 0xfaa6ec: ldur            x3, [fp, #-0x28]
    // 0xfaa6f0: add             x0, x3, #1
    // 0xfaa6f4: lsl             x1, x0, #1
    // 0xfaa6f8: StoreField: r2->field_b = r1
    //     0xfaa6f8: stur            w1, [x2, #0xb]
    // 0xfaa6fc: LoadField: r1 = r2->field_f
    //     0xfaa6fc: ldur            w1, [x2, #0xf]
    // 0xfaa700: DecompressPointer r1
    //     0xfaa700: add             x1, x1, HEAP, lsl #32
    // 0xfaa704: ldur            x0, [fp, #-0x18]
    // 0xfaa708: ArrayStore: r1[r3] = r0  ; List_4
    //     0xfaa708: add             x25, x1, x3, lsl #2
    //     0xfaa70c: add             x25, x25, #0xf
    //     0xfaa710: str             w0, [x25]
    //     0xfaa714: tbz             w0, #0, #0xfaa730
    //     0xfaa718: ldurb           w16, [x1, #-1]
    //     0xfaa71c: ldurb           w17, [x0, #-1]
    //     0xfaa720: and             x16, x17, x16, lsr #2
    //     0xfaa724: tst             x16, HEAP, lsr #32
    //     0xfaa728: b.eq            #0xfaa730
    //     0xfaa72c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xfaa730: r0 = Row()
    //     0xfaa730: bl              #0x8a5b04  ; AllocateRowStub -> Row (size=0x38)
    // 0xfaa734: mov             x3, x0
    // 0xfaa738: r0 = Instance_Axis
    //     0xfaa738: ldr             x0, [PP, #0x49c8]  ; [pp+0x49c8] Obj!Axis@12c4a61
    // 0xfaa73c: stur            x3, [fp, #-8]
    // 0xfaa740: StoreField: r3->field_f = r0
    //     0xfaa740: stur            w0, [x3, #0xf]
    // 0xfaa744: r0 = Instance_MainAxisAlignment
    //     0xfaa744: add             x0, PP, #0x18, lsl #12  ; [pp+0x180f0] Obj!MainAxisAlignment@12c4581
    //     0xfaa748: ldr             x0, [x0, #0xf0]
    // 0xfaa74c: StoreField: r3->field_13 = r0
    //     0xfaa74c: stur            w0, [x3, #0x13]
    // 0xfaa750: r0 = Instance_MainAxisSize
    //     0xfaa750: add             x0, PP, #0x15, lsl #12  ; [pp+0x15828] Obj!MainAxisSize@12c4621
    //     0xfaa754: ldr             x0, [x0, #0x828]
    // 0xfaa758: ArrayStore: r3[0] = r0  ; List_4
    //     0xfaa758: stur            w0, [x3, #0x17]
    // 0xfaa75c: r0 = Instance_CrossAxisAlignment
    //     0xfaa75c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15888] Obj!CrossAxisAlignment@12c44a1
    //     0xfaa760: ldr             x0, [x0, #0x888]
    // 0xfaa764: StoreField: r3->field_1b = r0
    //     0xfaa764: stur            w0, [x3, #0x1b]
    // 0xfaa768: r0 = Instance_VerticalDirection
    //     0xfaa768: add             x0, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xfaa76c: ldr             x0, [x0, #0x838]
    // 0xfaa770: StoreField: r3->field_23 = r0
    //     0xfaa770: stur            w0, [x3, #0x23]
    // 0xfaa774: r0 = Instance_Clip
    //     0xfaa774: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xfaa778: ldr             x0, [x0, #0x840]
    // 0xfaa77c: StoreField: r3->field_2b = r0
    //     0xfaa77c: stur            w0, [x3, #0x2b]
    // 0xfaa780: StoreField: r3->field_2f = rZR
    //     0xfaa780: stur            xzr, [x3, #0x2f]
    // 0xfaa784: ldur            x0, [fp, #-0x20]
    // 0xfaa788: StoreField: r3->field_b = r0
    //     0xfaa788: stur            w0, [x3, #0xb]
    // 0xfaa78c: ldur            x2, [fp, #-0x10]
    // 0xfaa790: r1 = Function '<anonymous closure>':.
    //     0xfaa790: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4750] AnonymousClosure: (0xfaa7d4), in [package:chewie/src/cupertino/cupertino_controls.dart] _PlaybackSpeedDialog::build (0xfaa378)
    //     0xfaa794: ldr             x1, [x1, #0x750]
    // 0xfaa798: r0 = AllocateClosure()
    //     0xfaa798: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfaa79c: stur            x0, [fp, #-0x10]
    // 0xfaa7a0: r0 = CupertinoActionSheetAction()
    //     0xfaa7a0: bl              #0xde20fc  ; AllocateCupertinoActionSheetActionStub -> CupertinoActionSheetAction (size=0x28)
    // 0xfaa7a4: ldur            x1, [fp, #-0x10]
    // 0xfaa7a8: StoreField: r0->field_b = r1
    //     0xfaa7a8: stur            w1, [x0, #0xb]
    // 0xfaa7ac: r1 = false
    //     0xfaa7ac: add             x1, NULL, #0x30  ; false
    // 0xfaa7b0: StoreField: r0->field_f = r1
    //     0xfaa7b0: stur            w1, [x0, #0xf]
    // 0xfaa7b4: StoreField: r0->field_13 = r1
    //     0xfaa7b4: stur            w1, [x0, #0x13]
    // 0xfaa7b8: ldur            x1, [fp, #-8]
    // 0xfaa7bc: StoreField: r0->field_23 = r1
    //     0xfaa7bc: stur            w1, [x0, #0x23]
    // 0xfaa7c0: LeaveFrame
    //     0xfaa7c0: mov             SP, fp
    //     0xfaa7c4: ldp             fp, lr, [SP], #0x10
    // 0xfaa7c8: ret
    //     0xfaa7c8: ret             
    // 0xfaa7cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfaa7cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfaa7d0: b               #0xfaa588
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xfaa7d4, size: 0x7c
    // 0xfaa7d4: EnterFrame
    //     0xfaa7d4: stp             fp, lr, [SP, #-0x10]!
    //     0xfaa7d8: mov             fp, SP
    // 0xfaa7dc: AllocStack(0x20)
    //     0xfaa7dc: sub             SP, SP, #0x20
    // 0xfaa7e0: SetupParameters([dynamic _ /* r0 */])
    //     0xfaa7e0: ldr             x0, [fp, #0x10]
    //     0xfaa7e4: ldur            w2, [x0, #0x17]
    //     0xfaa7e8: add             x2, x2, HEAP, lsl #32
    //     0xfaa7ec: stur            x2, [fp, #-8]
    // 0xfaa7f0: CheckStackOverflow
    //     0xfaa7f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfaa7f4: cmp             SP, x16
    //     0xfaa7f8: b.ls            #0xfaa848
    // 0xfaa7fc: LoadField: r0 = r2->field_b
    //     0xfaa7fc: ldur            w0, [x2, #0xb]
    // 0xfaa800: DecompressPointer r0
    //     0xfaa800: add             x0, x0, HEAP, lsl #32
    // 0xfaa804: LoadField: r1 = r0->field_13
    //     0xfaa804: ldur            w1, [x0, #0x13]
    // 0xfaa808: DecompressPointer r1
    //     0xfaa808: add             x1, x1, HEAP, lsl #32
    // 0xfaa80c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xfaa80c: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xfaa810: r0 = of()
    //     0xfaa810: bl              #0xb35e68  ; [package:flutter/src/widgets/navigator.dart] Navigator::of
    // 0xfaa814: mov             x1, x0
    // 0xfaa818: ldur            x0, [fp, #-8]
    // 0xfaa81c: LoadField: r2 = r0->field_f
    //     0xfaa81c: ldur            w2, [x0, #0xf]
    // 0xfaa820: DecompressPointer r2
    //     0xfaa820: add             x2, x2, HEAP, lsl #32
    // 0xfaa824: r16 = <double>
    //     0xfaa824: ldr             x16, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xfaa828: stp             x1, x16, [SP, #8]
    // 0xfaa82c: str             x2, [SP]
    // 0xfaa830: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xfaa830: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xfaa834: r0 = pop()
    //     0xfaa834: bl              #0x8c87a0  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::pop
    // 0xfaa838: r0 = Null
    //     0xfaa838: mov             x0, NULL
    // 0xfaa83c: LeaveFrame
    //     0xfaa83c: mov             SP, fp
    //     0xfaa840: ldp             fp, lr, [SP], #0x10
    // 0xfaa844: ret
    //     0xfaa844: ret             
    // 0xfaa848: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfaa848: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfaa84c: b               #0xfaa7fc
  }
}

// class id: 6537, size: 0x18, field offset: 0xc
//   const constructor, 
class CupertinoControls extends StatefulWidget {

  Color field_c;
  Color field_10;
  bool field_14;

  _ createState(/* No info */) {
    // ** addr: 0xf9feec, size: 0x54
    // 0xf9feec: EnterFrame
    //     0xf9feec: stp             fp, lr, [SP, #-0x10]!
    //     0xf9fef0: mov             fp, SP
    // 0xf9fef4: mov             x0, x1
    // 0xf9fef8: r1 = <CupertinoControls>
    //     0xf9fef8: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3308] TypeArguments: <CupertinoControls>
    //     0xf9fefc: ldr             x1, [x1, #0x308]
    // 0xf9ff00: r0 = _CupertinoControlsState()
    //     0xf9ff00: bl              #0xf9ff40  ; Allocate_CupertinoControlsStateStub -> _CupertinoControlsState (size=0x5c)
    // 0xf9ff04: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xf9ff08: StoreField: r0->field_1b = r1
    //     0xf9ff08: stur            w1, [x0, #0x1b]
    // 0xf9ff0c: StoreField: r0->field_1f = r1
    //     0xf9ff0c: stur            w1, [x0, #0x1f]
    // 0xf9ff10: d0 = 5.000000
    //     0xf9ff10: fmov            d0, #5.00000000
    // 0xf9ff14: StoreField: r0->field_2b = d0
    //     0xf9ff14: stur            d0, [x0, #0x2b]
    // 0xf9ff18: r2 = false
    //     0xf9ff18: add             x2, NULL, #0x30  ; false
    // 0xf9ff1c: StoreField: r0->field_3b = r2
    //     0xf9ff1c: stur            w2, [x0, #0x3b]
    // 0xf9ff20: StoreField: r0->field_3f = r2
    //     0xf9ff20: stur            w2, [x0, #0x3f]
    // 0xf9ff24: StoreField: r0->field_47 = r2
    //     0xf9ff24: stur            w2, [x0, #0x47]
    // 0xf9ff28: d0 = 1.000000
    //     0xf9ff28: fmov            d0, #1.00000000
    // 0xf9ff2c: StoreField: r0->field_4b = d0
    //     0xf9ff2c: stur            d0, [x0, #0x4b]
    // 0xf9ff30: StoreField: r0->field_53 = r1
    //     0xf9ff30: stur            w1, [x0, #0x53]
    // 0xf9ff34: LeaveFrame
    //     0xf9ff34: mov             SP, fp
    //     0xf9ff38: ldp             fp, lr, [SP], #0x10
    // 0xf9ff3c: ret
    //     0xf9ff3c: ret             
  }
}
