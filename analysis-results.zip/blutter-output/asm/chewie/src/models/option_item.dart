// lib: , url: package:chewie/src/models/option_item.dart

// class id: 1048641, size: 0x8
class :: {
}

// class id: 3584, size: 0x18, field offset: 0x8
class OptionItem extends Object {

  _ toString(/* No info */) {
    // ** addr: 0x110ae8c, size: 0xac
    // 0x110ae8c: EnterFrame
    //     0x110ae8c: stp             fp, lr, [SP, #-0x10]!
    //     0x110ae90: mov             fp, SP
    // 0x110ae94: AllocStack(0x8)
    //     0x110ae94: sub             SP, SP, #8
    // 0x110ae98: CheckStackOverflow
    //     0x110ae98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x110ae9c: cmp             SP, x16
    //     0x110aea0: b.ls            #0x110af30
    // 0x110aea4: r1 = Null
    //     0x110aea4: mov             x1, NULL
    // 0x110aea8: r2 = 18
    //     0x110aea8: mov             x2, #0x12
    // 0x110aeac: r0 = AllocateArray()
    //     0x110aeac: bl              #0x13df928  ; AllocateArrayStub
    // 0x110aeb0: r16 = "OptionItem(onTap: "
    //     0x110aeb0: add             x16, PP, #0xd1, lsl #12  ; [pp+0xd1938] "OptionItem(onTap: "
    //     0x110aeb4: ldr             x16, [x16, #0x938]
    // 0x110aeb8: StoreField: r0->field_f = r16
    //     0x110aeb8: stur            w16, [x0, #0xf]
    // 0x110aebc: ldr             x1, [fp, #0x10]
    // 0x110aec0: LoadField: r2 = r1->field_7
    //     0x110aec0: ldur            w2, [x1, #7]
    // 0x110aec4: DecompressPointer r2
    //     0x110aec4: add             x2, x2, HEAP, lsl #32
    // 0x110aec8: StoreField: r0->field_13 = r2
    //     0x110aec8: stur            w2, [x0, #0x13]
    // 0x110aecc: r16 = ", iconData: "
    //     0x110aecc: add             x16, PP, #0xd1, lsl #12  ; [pp+0xd1940] ", iconData: "
    //     0x110aed0: ldr             x16, [x16, #0x940]
    // 0x110aed4: ArrayStore: r0[0] = r16  ; List_4
    //     0x110aed4: stur            w16, [x0, #0x17]
    // 0x110aed8: LoadField: r2 = r1->field_b
    //     0x110aed8: ldur            w2, [x1, #0xb]
    // 0x110aedc: DecompressPointer r2
    //     0x110aedc: add             x2, x2, HEAP, lsl #32
    // 0x110aee0: StoreField: r0->field_1b = r2
    //     0x110aee0: stur            w2, [x0, #0x1b]
    // 0x110aee4: r16 = ", title: "
    //     0x110aee4: add             x16, PP, #0x28, lsl #12  ; [pp+0x28790] ", title: "
    //     0x110aee8: ldr             x16, [x16, #0x790]
    // 0x110aeec: StoreField: r0->field_1f = r16
    //     0x110aeec: stur            w16, [x0, #0x1f]
    // 0x110aef0: LoadField: r2 = r1->field_f
    //     0x110aef0: ldur            w2, [x1, #0xf]
    // 0x110aef4: DecompressPointer r2
    //     0x110aef4: add             x2, x2, HEAP, lsl #32
    // 0x110aef8: StoreField: r0->field_23 = r2
    //     0x110aef8: stur            w2, [x0, #0x23]
    // 0x110aefc: r16 = ", subtitle: "
    //     0x110aefc: add             x16, PP, #0xd1, lsl #12  ; [pp+0xd1948] ", subtitle: "
    //     0x110af00: ldr             x16, [x16, #0x948]
    // 0x110af04: StoreField: r0->field_27 = r16
    //     0x110af04: stur            w16, [x0, #0x27]
    // 0x110af08: LoadField: r2 = r1->field_13
    //     0x110af08: ldur            w2, [x1, #0x13]
    // 0x110af0c: DecompressPointer r2
    //     0x110af0c: add             x2, x2, HEAP, lsl #32
    // 0x110af10: StoreField: r0->field_2b = r2
    //     0x110af10: stur            w2, [x0, #0x2b]
    // 0x110af14: r16 = ")"
    //     0x110af14: ldr             x16, [PP, #0xe60]  ; [pp+0xe60] ")"
    // 0x110af18: StoreField: r0->field_2f = r16
    //     0x110af18: stur            w16, [x0, #0x2f]
    // 0x110af1c: str             x0, [SP]
    // 0x110af20: r0 = _interpolate()
    //     0x110af20: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x110af24: LeaveFrame
    //     0x110af24: mov             SP, fp
    //     0x110af28: ldp             fp, lr, [SP], #0x10
    // 0x110af2c: ret
    //     0x110af2c: ret             
    // 0x110af30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x110af30: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x110af34: b               #0x110aea4
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x11494f4, size: 0xc0
    // 0x11494f4: EnterFrame
    //     0x11494f4: stp             fp, lr, [SP, #-0x10]!
    //     0x11494f8: mov             fp, SP
    // 0x11494fc: AllocStack(0x18)
    //     0x11494fc: sub             SP, SP, #0x18
    // 0x1149500: CheckStackOverflow
    //     0x1149500: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1149504: cmp             SP, x16
    //     0x1149508: b.ls            #0x11495ac
    // 0x114950c: ldr             x0, [fp, #0x10]
    // 0x1149510: LoadField: r1 = r0->field_7
    //     0x1149510: ldur            w1, [x0, #7]
    // 0x1149514: DecompressPointer r1
    //     0x1149514: add             x1, x1, HEAP, lsl #32
    // 0x1149518: str             x1, [SP]
    // 0x114951c: r0 = hashCode()
    //     0x114951c: bl              #0x1159abc  ; [dart:core] _Closure::hashCode
    // 0x1149520: mov             x1, x0
    // 0x1149524: ldr             x0, [fp, #0x10]
    // 0x1149528: stur            x1, [fp, #-8]
    // 0x114952c: LoadField: r2 = r0->field_b
    //     0x114952c: ldur            w2, [x0, #0xb]
    // 0x1149530: DecompressPointer r2
    //     0x1149530: add             x2, x2, HEAP, lsl #32
    // 0x1149534: str             x2, [SP]
    // 0x1149538: r0 = hashCode()
    //     0x1149538: bl              #0x114d254  ; [package:flutter/src/widgets/icon_data.dart] IconData::hashCode
    // 0x114953c: mov             x1, x0
    // 0x1149540: ldur            x0, [fp, #-8]
    // 0x1149544: r2 = LoadInt32Instr(r0)
    //     0x1149544: sbfx            x2, x0, #1, #0x1f
    //     0x1149548: tbz             w0, #0, #0x1149550
    //     0x114954c: ldur            x2, [x0, #7]
    // 0x1149550: r0 = LoadInt32Instr(r1)
    //     0x1149550: sbfx            x0, x1, #1, #0x1f
    //     0x1149554: tbz             w1, #0, #0x114955c
    //     0x1149558: ldur            x0, [x1, #7]
    // 0x114955c: eor             x1, x2, x0
    // 0x1149560: ldr             x0, [fp, #0x10]
    // 0x1149564: stur            x1, [fp, #-0x10]
    // 0x1149568: LoadField: r2 = r0->field_f
    //     0x1149568: ldur            w2, [x0, #0xf]
    // 0x114956c: DecompressPointer r2
    //     0x114956c: add             x2, x2, HEAP, lsl #32
    // 0x1149570: str             x2, [SP]
    // 0x1149574: r0 = hashCode()
    //     0x1149574: bl              #0x1159684  ; [dart:core] _OneByteString::hashCode
    // 0x1149578: r2 = LoadInt32Instr(r0)
    //     0x1149578: sbfx            x2, x0, #1, #0x1f
    // 0x114957c: ldur            x3, [fp, #-0x10]
    // 0x1149580: eor             x4, x3, x2
    // 0x1149584: r16 = 2011
    //     0x1149584: mov             x16, #0x7db
    // 0x1149588: eor             x2, x4, x16
    // 0x114958c: r0 = BoxInt64Instr(r2)
    //     0x114958c: sbfiz           x0, x2, #1, #0x1f
    //     0x1149590: cmp             x2, x0, asr #1
    //     0x1149594: b.eq            #0x11495a0
    //     0x1149598: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x114959c: stur            x2, [x0, #7]
    // 0x11495a0: LeaveFrame
    //     0x11495a0: mov             SP, fp
    //     0x11495a4: ldp             fp, lr, [SP], #0x10
    // 0x11495a8: ret
    //     0x11495a8: ret             
    // 0x11495ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11495ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11495b0: b               #0x114950c
  }
  _ ==(/* No info */) {
    // ** addr: 0x12927d0, size: 0xec
    // 0x12927d0: EnterFrame
    //     0x12927d0: stp             fp, lr, [SP, #-0x10]!
    //     0x12927d4: mov             fp, SP
    // 0x12927d8: AllocStack(0x10)
    //     0x12927d8: sub             SP, SP, #0x10
    // 0x12927dc: CheckStackOverflow
    //     0x12927dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12927e0: cmp             SP, x16
    //     0x12927e4: b.ls            #0x12928b4
    // 0x12927e8: ldr             x0, [fp, #0x10]
    // 0x12927ec: cmp             w0, NULL
    // 0x12927f0: b.ne            #0x1292804
    // 0x12927f4: r0 = false
    //     0x12927f4: add             x0, NULL, #0x30  ; false
    // 0x12927f8: LeaveFrame
    //     0x12927f8: mov             SP, fp
    //     0x12927fc: ldp             fp, lr, [SP], #0x10
    // 0x1292800: ret
    //     0x1292800: ret             
    // 0x1292804: ldr             x1, [fp, #0x18]
    // 0x1292808: cmp             w1, w0
    // 0x129280c: b.ne            #0x1292820
    // 0x1292810: r0 = true
    //     0x1292810: add             x0, NULL, #0x20  ; true
    // 0x1292814: LeaveFrame
    //     0x1292814: mov             SP, fp
    //     0x1292818: ldp             fp, lr, [SP], #0x10
    // 0x129281c: ret
    //     0x129281c: ret             
    // 0x1292820: r2 = 60
    //     0x1292820: mov             x2, #0x3c
    // 0x1292824: branchIfSmi(r0, 0x1292830)
    //     0x1292824: tbz             w0, #0, #0x1292830
    // 0x1292828: r2 = LoadClassIdInstr(r0)
    //     0x1292828: ldur            x2, [x0, #-1]
    //     0x129282c: ubfx            x2, x2, #0xc, #0x14
    // 0x1292830: cmp             x2, #0xe00
    // 0x1292834: b.ne            #0x12928a4
    // 0x1292838: LoadField: r2 = r0->field_7
    //     0x1292838: ldur            w2, [x0, #7]
    // 0x129283c: DecompressPointer r2
    //     0x129283c: add             x2, x2, HEAP, lsl #32
    // 0x1292840: LoadField: r3 = r1->field_7
    //     0x1292840: ldur            w3, [x1, #7]
    // 0x1292844: DecompressPointer r3
    //     0x1292844: add             x3, x3, HEAP, lsl #32
    // 0x1292848: stp             x3, x2, [SP]
    // 0x129284c: r0 = ==()
    //     0x129284c: bl              #0x12b7e74  ; [dart:core] _Closure::==
    // 0x1292850: tbnz            w0, #4, #0x12928a4
    // 0x1292854: ldr             x1, [fp, #0x18]
    // 0x1292858: ldr             x0, [fp, #0x10]
    // 0x129285c: LoadField: r2 = r0->field_b
    //     0x129285c: ldur            w2, [x0, #0xb]
    // 0x1292860: DecompressPointer r2
    //     0x1292860: add             x2, x2, HEAP, lsl #32
    // 0x1292864: LoadField: r3 = r1->field_b
    //     0x1292864: ldur            w3, [x1, #0xb]
    // 0x1292868: DecompressPointer r3
    //     0x1292868: add             x3, x3, HEAP, lsl #32
    // 0x129286c: stp             x3, x2, [SP]
    // 0x1292870: r0 = ==()
    //     0x1292870: bl              #0x129b76c  ; [package:flutter/src/widgets/icon_data.dart] IconData::==
    // 0x1292874: tbnz            w0, #4, #0x12928a4
    // 0x1292878: ldr             x1, [fp, #0x18]
    // 0x129287c: ldr             x0, [fp, #0x10]
    // 0x1292880: LoadField: r2 = r0->field_f
    //     0x1292880: ldur            w2, [x0, #0xf]
    // 0x1292884: DecompressPointer r2
    //     0x1292884: add             x2, x2, HEAP, lsl #32
    // 0x1292888: LoadField: r0 = r1->field_f
    //     0x1292888: ldur            w0, [x1, #0xf]
    // 0x129288c: DecompressPointer r0
    //     0x129288c: add             x0, x0, HEAP, lsl #32
    // 0x1292890: stp             x0, x2, [SP]
    // 0x1292894: r0 = ==()
    //     0x1292894: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x1292898: tbnz            w0, #4, #0x12928a4
    // 0x129289c: r0 = true
    //     0x129289c: add             x0, NULL, #0x20  ; true
    // 0x12928a0: b               #0x12928a8
    // 0x12928a4: r0 = false
    //     0x12928a4: add             x0, NULL, #0x30  ; false
    // 0x12928a8: LeaveFrame
    //     0x12928a8: mov             SP, fp
    //     0x12928ac: ldp             fp, lr, [SP], #0x10
    // 0x12928b0: ret
    //     0x12928b0: ret             
    // 0x12928b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12928b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12928b8: b               #0x12927e8
  }
}
