// lib: , url: package:chewie/src/notifiers/player_notifier.dart

// class id: 1048644, size: 0x8
class :: {
}

// class id: 4517, size: 0x28, field offset: 0x24
class PlayerNotifier extends ChangeNotifier {

  static _ init(/* No info */) {
    // ** addr: 0xf8e8b0, size: 0x74
    // 0xf8e8b0: EnterFrame
    //     0xf8e8b0: stp             fp, lr, [SP, #-0x10]!
    //     0xf8e8b4: mov             fp, SP
    // 0xf8e8b8: AllocStack(0x8)
    //     0xf8e8b8: sub             SP, SP, #8
    // 0xf8e8bc: CheckStackOverflow
    //     0xf8e8bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf8e8c0: cmp             SP, x16
    //     0xf8e8c4: b.ls            #0xf8e91c
    // 0xf8e8c8: r0 = PlayerNotifier()
    //     0xf8e8c8: bl              #0xf8e924  ; AllocatePlayerNotifierStub -> PlayerNotifier (size=0x28)
    // 0xf8e8cc: mov             x1, x0
    // 0xf8e8d0: r0 = true
    //     0xf8e8d0: add             x0, NULL, #0x20  ; true
    // 0xf8e8d4: stur            x1, [fp, #-8]
    // 0xf8e8d8: StoreField: r1->field_23 = r0
    //     0xf8e8d8: stur            w0, [x1, #0x23]
    // 0xf8e8dc: StoreField: r1->field_7 = rZR
    //     0xf8e8dc: stur            xzr, [x1, #7]
    // 0xf8e8e0: StoreField: r1->field_13 = rZR
    //     0xf8e8e0: stur            xzr, [x1, #0x13]
    // 0xf8e8e4: StoreField: r1->field_1b = rZR
    //     0xf8e8e4: stur            xzr, [x1, #0x1b]
    // 0xf8e8e8: r0 = LoadStaticField(0x45c)
    //     0xf8e8e8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf8e8ec: ldr             x0, [x0, #0x8b8]
    // 0xf8e8f0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf8e8f4: cmp             w0, w16
    // 0xf8e8f8: b.ne            #0xf8e904
    // 0xf8e8fc: r2 = _emptyListeners
    //     0xf8e8fc: ldr             x2, [PP, #0x17f0]  ; [pp+0x17f0] Field <ChangeNotifier._emptyListeners@28329750>: static late final (offset: 0x45c)
    // 0xf8e900: r0 = InitLateFinalStaticField()
    //     0xf8e900: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xf8e904: mov             x1, x0
    // 0xf8e908: ldur            x0, [fp, #-8]
    // 0xf8e90c: StoreField: r0->field_f = r1
    //     0xf8e90c: stur            w1, [x0, #0xf]
    // 0xf8e910: LeaveFrame
    //     0xf8e910: mov             SP, fp
    //     0xf8e914: ldp             fp, lr, [SP], #0x10
    // 0xf8e918: ret
    //     0xf8e918: ret             
    // 0xf8e91c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf8e91c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf8e920: b               #0xf8e8c8
  }
}
