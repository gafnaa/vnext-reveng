// lib: , url: package:chewie/src/animated_play_pause.dart

// class id: 1048626, size: 0x8
class :: {
}

// class id: 5508, size: 0x20, field offset: 0x1c
class AnimatedPlayPauseState extends _MixinApplication780&State&SingleTickerProviderStateMixin {

  late final AnimationController animationController; // offset: 0x1c

  _ build(/* No info */) {
    // ** addr: 0xde1928, size: 0xb0
    // 0xde1928: EnterFrame
    //     0xde1928: stp             fp, lr, [SP, #-0x10]!
    //     0xde192c: mov             fp, SP
    // 0xde1930: AllocStack(0x18)
    //     0xde1930: sub             SP, SP, #0x18
    // 0xde1934: CheckStackOverflow
    //     0xde1934: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde1938: cmp             SP, x16
    //     0xde193c: b.ls            #0xde19cc
    // 0xde1940: LoadField: r0 = r1->field_b
    //     0xde1940: ldur            w0, [x1, #0xb]
    // 0xde1944: DecompressPointer r0
    //     0xde1944: add             x0, x0, HEAP, lsl #32
    // 0xde1948: cmp             w0, NULL
    // 0xde194c: b.eq            #0xde19d4
    // 0xde1950: LoadField: r2 = r0->field_13
    //     0xde1950: ldur            w2, [x0, #0x13]
    // 0xde1954: DecompressPointer r2
    //     0xde1954: add             x2, x2, HEAP, lsl #32
    // 0xde1958: stur            x2, [fp, #-8]
    // 0xde195c: LoadField: r0 = r1->field_1b
    //     0xde195c: ldur            w0, [x1, #0x1b]
    // 0xde1960: DecompressPointer r0
    //     0xde1960: add             x0, x0, HEAP, lsl #32
    // 0xde1964: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xde1968: cmp             w0, w16
    // 0xde196c: b.ne            #0xde197c
    // 0xde1970: r2 = animationController
    //     0xde1970: add             x2, PP, #0xd4, lsl #12  ; [pp+0xd4a08] Field <AnimatedPlayPauseState.animationController>: late final (offset: 0x1c)
    //     0xde1974: ldr             x2, [x2, #0xa08]
    // 0xde1978: r0 = InitLateFinalInstanceField()
    //     0xde1978: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xde197c: stur            x0, [fp, #-0x10]
    // 0xde1980: r0 = AnimatedIcon()
    //     0xde1980: bl              #0xde19d8  ; AllocateAnimatedIconStub -> AnimatedIcon (size=0x24)
    // 0xde1984: mov             x1, x0
    // 0xde1988: r0 = Instance__AnimatedIconData
    //     0xde1988: add             x0, PP, #0xd4, lsl #12  ; [pp+0xd4a10] Obj!_AnimatedIconData@129ef11
    //     0xde198c: ldr             x0, [x0, #0xa10]
    // 0xde1990: stur            x1, [fp, #-0x18]
    // 0xde1994: ArrayStore: r1[0] = r0  ; List_4
    //     0xde1994: stur            w0, [x1, #0x17]
    // 0xde1998: ldur            x0, [fp, #-0x10]
    // 0xde199c: StoreField: r1->field_b = r0
    //     0xde199c: stur            w0, [x1, #0xb]
    // 0xde19a0: ldur            x0, [fp, #-8]
    // 0xde19a4: StoreField: r1->field_f = r0
    //     0xde19a4: stur            w0, [x1, #0xf]
    // 0xde19a8: r0 = Center()
    //     0xde19a8: bl              #0xd0c898  ; AllocateCenterStub -> Center (size=0x1c)
    // 0xde19ac: r1 = Instance_Alignment
    //     0xde19ac: add             x1, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xde19b0: ldr             x1, [x1, #0xb80]
    // 0xde19b4: StoreField: r0->field_f = r1
    //     0xde19b4: stur            w1, [x0, #0xf]
    // 0xde19b8: ldur            x1, [fp, #-0x18]
    // 0xde19bc: StoreField: r0->field_b = r1
    //     0xde19bc: stur            w1, [x0, #0xb]
    // 0xde19c0: LeaveFrame
    //     0xde19c0: mov             SP, fp
    //     0xde19c4: ldp             fp, lr, [SP], #0x10
    // 0xde19c8: ret
    //     0xde19c8: ret             
    // 0xde19cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde19cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde19d0: b               #0xde1940
    // 0xde19d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde19d4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  AnimationController animationController(AnimatedPlayPauseState) {
    // ** addr: 0xde19e4, size: 0xd8
    // 0xde19e4: EnterFrame
    //     0xde19e4: stp             fp, lr, [SP, #-0x10]!
    //     0xde19e8: mov             fp, SP
    // 0xde19ec: AllocStack(0x20)
    //     0xde19ec: sub             SP, SP, #0x20
    // 0xde19f0: CheckStackOverflow
    //     0xde19f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde19f4: cmp             SP, x16
    //     0xde19f8: b.ls            #0xde1a98
    // 0xde19fc: ldr             x2, [fp, #0x10]
    // 0xde1a00: LoadField: r0 = r2->field_b
    //     0xde1a00: ldur            w0, [x2, #0xb]
    // 0xde1a04: DecompressPointer r0
    //     0xde1a04: add             x0, x0, HEAP, lsl #32
    // 0xde1a08: cmp             w0, NULL
    // 0xde1a0c: b.eq            #0xde1aa0
    // 0xde1a10: LoadField: r1 = r0->field_f
    //     0xde1a10: ldur            w1, [x0, #0xf]
    // 0xde1a14: DecompressPointer r1
    //     0xde1a14: add             x1, x1, HEAP, lsl #32
    // 0xde1a18: tbnz            w1, #4, #0xde1a24
    // 0xde1a1c: d0 = 1.000000
    //     0xde1a1c: fmov            d0, #1.00000000
    // 0xde1a20: b               #0xde1a28
    // 0xde1a24: d0 = 0.000000
    //     0xde1a24: eor             v0.16b, v0.16b, v0.16b
    // 0xde1a28: r0 = inline_Allocate_Double()
    //     0xde1a28: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xde1a2c: add             x0, x0, #0x10
    //     0xde1a30: cmp             x1, x0
    //     0xde1a34: b.ls            #0xde1aa4
    //     0xde1a38: str             x0, [THR, #0x60]  ; THR::top
    //     0xde1a3c: sub             x0, x0, #0xf
    //     0xde1a40: mov             x1, #0xe19c
    //     0xde1a44: movk            x1, #3, lsl #16
    //     0xde1a48: stur            x1, [x0, #-1]
    // 0xde1a4c: dmb             ishst
    // 0xde1a50: StoreField: r0->field_7 = d0
    //     0xde1a50: stur            d0, [x0, #7]
    // 0xde1a54: stur            x0, [fp, #-8]
    // 0xde1a58: r1 = <double>
    //     0xde1a58: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xde1a5c: r0 = AnimationController()
    //     0xde1a5c: bl              #0x87522c  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0xde1a60: stur            x0, [fp, #-0x10]
    // 0xde1a64: ldur            x16, [fp, #-8]
    // 0xde1a68: r30 = Instance_Duration
    //     0xde1a68: add             lr, PP, #0xb0, lsl #12  ; [pp+0xb0c30] Obj!Duration@12c8a51
    //     0xde1a6c: ldr             lr, [lr, #0xc30]
    // 0xde1a70: stp             lr, x16, [SP]
    // 0xde1a74: mov             x1, x0
    // 0xde1a78: ldr             x2, [fp, #0x10]
    // 0xde1a7c: r4 = const [0, 0x4, 0x2, 0x2, duration, 0x3, value, 0x2, null]
    //     0xde1a7c: add             x4, PP, #0x84, lsl #12  ; [pp+0x84ce0] List(9) [0, 0x4, 0x2, 0x2, "duration", 0x3, "value", 0x2, Null]
    //     0xde1a80: ldr             x4, [x4, #0xce0]
    // 0xde1a84: r0 = AnimationController()
    //     0xde1a84: bl              #0x874ea4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0xde1a88: ldur            x0, [fp, #-0x10]
    // 0xde1a8c: LeaveFrame
    //     0xde1a8c: mov             SP, fp
    //     0xde1a90: ldp             fp, lr, [SP], #0x10
    // 0xde1a94: ret
    //     0xde1a94: ret             
    // 0xde1a98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde1a98: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde1a9c: b               #0xde19fc
    // 0xde1aa0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde1aa0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde1aa4: SaveReg d0
    //     0xde1aa4: str             q0, [SP, #-0x10]!
    // 0xde1aa8: SaveReg r2
    //     0xde1aa8: str             x2, [SP, #-8]!
    // 0xde1aac: r0 = AllocateDouble()
    //     0xde1aac: bl              #0x13df878  ; AllocateDoubleStub
    // 0xde1ab0: RestoreReg r2
    //     0xde1ab0: ldr             x2, [SP], #8
    // 0xde1ab4: RestoreReg d0
    //     0xde1ab4: ldr             q0, [SP], #0x10
    // 0xde1ab8: b               #0xde1a50
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf6b5a4, size: 0x14c
    // 0xf6b5a4: EnterFrame
    //     0xf6b5a4: stp             fp, lr, [SP, #-0x10]!
    //     0xf6b5a8: mov             fp, SP
    // 0xf6b5ac: AllocStack(0x10)
    //     0xf6b5ac: sub             SP, SP, #0x10
    // 0xf6b5b0: SetupParameters(AnimatedPlayPauseState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xf6b5b0: mov             x4, x1
    //     0xf6b5b4: mov             x3, x2
    //     0xf6b5b8: stur            x1, [fp, #-8]
    //     0xf6b5bc: stur            x2, [fp, #-0x10]
    // 0xf6b5c0: CheckStackOverflow
    //     0xf6b5c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6b5c4: cmp             SP, x16
    //     0xf6b5c8: b.ls            #0xf6b6e4
    // 0xf6b5cc: mov             x0, x3
    // 0xf6b5d0: r2 = Null
    //     0xf6b5d0: mov             x2, NULL
    // 0xf6b5d4: r1 = Null
    //     0xf6b5d4: mov             x1, NULL
    // 0xf6b5d8: r4 = 60
    //     0xf6b5d8: mov             x4, #0x3c
    // 0xf6b5dc: branchIfSmi(r0, 0xf6b5e8)
    //     0xf6b5dc: tbz             w0, #0, #0xf6b5e8
    // 0xf6b5e0: r4 = LoadClassIdInstr(r0)
    //     0xf6b5e0: ldur            x4, [x0, #-1]
    //     0xf6b5e4: ubfx            x4, x4, #0xc, #0x14
    // 0xf6b5e8: r17 = 6539
    //     0xf6b5e8: mov             x17, #0x198b
    // 0xf6b5ec: cmp             x4, x17
    // 0xf6b5f0: b.eq            #0xf6b608
    // 0xf6b5f4: r8 = AnimatedPlayPause
    //     0xf6b5f4: add             x8, PP, #0xd4, lsl #12  ; [pp+0xd4a18] Type: AnimatedPlayPause
    //     0xf6b5f8: ldr             x8, [x8, #0xa18]
    // 0xf6b5fc: r3 = Null
    //     0xf6b5fc: add             x3, PP, #0xd4, lsl #12  ; [pp+0xd4a20] Null
    //     0xf6b600: ldr             x3, [x3, #0xa20]
    // 0xf6b604: r0 = AnimatedPlayPause()
    //     0xf6b604: bl              #0xadcf7c  ; IsType_AnimatedPlayPause_Stub
    // 0xf6b608: ldur            x3, [fp, #-8]
    // 0xf6b60c: LoadField: r2 = r3->field_7
    //     0xf6b60c: ldur            w2, [x3, #7]
    // 0xf6b610: DecompressPointer r2
    //     0xf6b610: add             x2, x2, HEAP, lsl #32
    // 0xf6b614: ldur            x0, [fp, #-0x10]
    // 0xf6b618: r1 = Null
    //     0xf6b618: mov             x1, NULL
    // 0xf6b61c: cmp             w2, NULL
    // 0xf6b620: b.eq            #0xf6b644
    // 0xf6b624: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf6b624: ldur            w4, [x2, #0x17]
    // 0xf6b628: DecompressPointer r4
    //     0xf6b628: add             x4, x4, HEAP, lsl #32
    // 0xf6b62c: r8 = X0 bound StatefulWidget
    //     0xf6b62c: add             x8, PP, #0x12, lsl #12  ; [pp+0x12498] TypeParameter: X0 bound StatefulWidget
    //     0xf6b630: ldr             x8, [x8, #0x498]
    // 0xf6b634: LoadField: r9 = r4->field_7
    //     0xf6b634: ldur            x9, [x4, #7]
    // 0xf6b638: r3 = Null
    //     0xf6b638: add             x3, PP, #0xd4, lsl #12  ; [pp+0xd4a30] Null
    //     0xf6b63c: ldr             x3, [x3, #0xa30]
    // 0xf6b640: blr             x9
    // 0xf6b644: ldur            x1, [fp, #-8]
    // 0xf6b648: LoadField: r0 = r1->field_b
    //     0xf6b648: ldur            w0, [x1, #0xb]
    // 0xf6b64c: DecompressPointer r0
    //     0xf6b64c: add             x0, x0, HEAP, lsl #32
    // 0xf6b650: cmp             w0, NULL
    // 0xf6b654: b.eq            #0xf6b6ec
    // 0xf6b658: LoadField: r2 = r0->field_f
    //     0xf6b658: ldur            w2, [x0, #0xf]
    // 0xf6b65c: DecompressPointer r2
    //     0xf6b65c: add             x2, x2, HEAP, lsl #32
    // 0xf6b660: ldur            x0, [fp, #-0x10]
    // 0xf6b664: LoadField: r3 = r0->field_f
    //     0xf6b664: ldur            w3, [x0, #0xf]
    // 0xf6b668: DecompressPointer r3
    //     0xf6b668: add             x3, x3, HEAP, lsl #32
    // 0xf6b66c: cmp             w2, w3
    // 0xf6b670: b.eq            #0xf6b6d4
    // 0xf6b674: tbnz            w2, #4, #0xf6b6a8
    // 0xf6b678: LoadField: r0 = r1->field_1b
    //     0xf6b678: ldur            w0, [x1, #0x1b]
    // 0xf6b67c: DecompressPointer r0
    //     0xf6b67c: add             x0, x0, HEAP, lsl #32
    // 0xf6b680: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf6b684: cmp             w0, w16
    // 0xf6b688: b.ne            #0xf6b698
    // 0xf6b68c: r2 = animationController
    //     0xf6b68c: add             x2, PP, #0xd4, lsl #12  ; [pp+0xd4a08] Field <AnimatedPlayPauseState.animationController>: late final (offset: 0x1c)
    //     0xf6b690: ldr             x2, [x2, #0xa08]
    // 0xf6b694: r0 = InitLateFinalInstanceField()
    //     0xf6b694: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xf6b698: mov             x1, x0
    // 0xf6b69c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xf6b69c: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xf6b6a0: r0 = forward()
    //     0xf6b6a0: bl              #0x8cd83c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0xf6b6a4: b               #0xf6b6d4
    // 0xf6b6a8: LoadField: r0 = r1->field_1b
    //     0xf6b6a8: ldur            w0, [x1, #0x1b]
    // 0xf6b6ac: DecompressPointer r0
    //     0xf6b6ac: add             x0, x0, HEAP, lsl #32
    // 0xf6b6b0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf6b6b4: cmp             w0, w16
    // 0xf6b6b8: b.ne            #0xf6b6c8
    // 0xf6b6bc: r2 = animationController
    //     0xf6b6bc: add             x2, PP, #0xd4, lsl #12  ; [pp+0xd4a08] Field <AnimatedPlayPauseState.animationController>: late final (offset: 0x1c)
    //     0xf6b6c0: ldr             x2, [x2, #0xa08]
    // 0xf6b6c4: r0 = InitLateFinalInstanceField()
    //     0xf6b6c4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xf6b6c8: mov             x1, x0
    // 0xf6b6cc: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xf6b6cc: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xf6b6d0: r0 = reverse()
    //     0xf6b6d0: bl              #0x8c8688  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0xf6b6d4: r0 = Null
    //     0xf6b6d4: mov             x0, NULL
    // 0xf6b6d8: LeaveFrame
    //     0xf6b6d8: mov             SP, fp
    //     0xf6b6dc: ldp             fp, lr, [SP], #0x10
    // 0xf6b6e0: ret
    //     0xf6b6e0: ret             
    // 0xf6b6e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6b6e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6b6e8: b               #0xf6b5cc
    // 0xf6b6ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6b6ec: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10e4480, size: 0x6c
    // 0x10e4480: EnterFrame
    //     0x10e4480: stp             fp, lr, [SP, #-0x10]!
    //     0x10e4484: mov             fp, SP
    // 0x10e4488: AllocStack(0x8)
    //     0x10e4488: sub             SP, SP, #8
    // 0x10e448c: SetupParameters(AnimatedPlayPauseState this /* r1 => r0, fp-0x8 */)
    //     0x10e448c: mov             x0, x1
    //     0x10e4490: stur            x1, [fp, #-8]
    // 0x10e4494: CheckStackOverflow
    //     0x10e4494: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e4498: cmp             SP, x16
    //     0x10e449c: b.ls            #0x10e44e4
    // 0x10e44a0: mov             x1, x0
    // 0x10e44a4: LoadField: r0 = r1->field_1b
    //     0x10e44a4: ldur            w0, [x1, #0x1b]
    // 0x10e44a8: DecompressPointer r0
    //     0x10e44a8: add             x0, x0, HEAP, lsl #32
    // 0x10e44ac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10e44b0: cmp             w0, w16
    // 0x10e44b4: b.ne            #0x10e44c4
    // 0x10e44b8: r2 = animationController
    //     0x10e44b8: add             x2, PP, #0xd4, lsl #12  ; [pp+0xd4a08] Field <AnimatedPlayPauseState.animationController>: late final (offset: 0x1c)
    //     0x10e44bc: ldr             x2, [x2, #0xa08]
    // 0x10e44c0: r0 = InitLateFinalInstanceField()
    //     0x10e44c0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x10e44c4: mov             x1, x0
    // 0x10e44c8: r0 = dispose()
    //     0x10e44c8: bl              #0x9164f4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x10e44cc: ldur            x1, [fp, #-8]
    // 0x10e44d0: r0 = dispose()
    //     0x10e44d0: bl              #0x10e44ec  ; [dart:mixin_deduplication] _MixinApplication780&State&SingleTickerProviderStateMixin::dispose
    // 0x10e44d4: r0 = Null
    //     0x10e44d4: mov             x0, NULL
    // 0x10e44d8: LeaveFrame
    //     0x10e44d8: mov             SP, fp
    //     0x10e44dc: ldp             fp, lr, [SP], #0x10
    // 0x10e44e0: ret
    //     0x10e44e0: ret             
    // 0x10e44e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e44e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e44e8: b               #0x10e44a0
  }
}

// class id: 6539, size: 0x18, field offset: 0xc
//   const constructor, 
class AnimatedPlayPause extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xf9fe74, size: 0x2c
    // 0xf9fe74: EnterFrame
    //     0xf9fe74: stp             fp, lr, [SP, #-0x10]!
    //     0xf9fe78: mov             fp, SP
    // 0xf9fe7c: mov             x0, x1
    // 0xf9fe80: r1 = <AnimatedPlayPause>
    //     0xf9fe80: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4720] TypeArguments: <AnimatedPlayPause>
    //     0xf9fe84: ldr             x1, [x1, #0x720]
    // 0xf9fe88: r0 = AnimatedPlayPauseState()
    //     0xf9fe88: bl              #0xf9fea0  ; AllocateAnimatedPlayPauseStateStub -> AnimatedPlayPauseState (size=0x20)
    // 0xf9fe8c: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xf9fe90: StoreField: r0->field_1b = r1
    //     0xf9fe90: stur            w1, [x0, #0x1b]
    // 0xf9fe94: LeaveFrame
    //     0xf9fe94: mov             SP, fp
    //     0xf9fe98: ldp             fp, lr, [SP], #0x10
    // 0xf9fe9c: ret
    //     0xf9fe9c: ret             
  }
}
