// lib: , url: package:chewie/src/center_seek_button.dart

// class id: 1048628, size: 0x8
class :: {
}

// class id: 6217, size: 0x2c, field offset: 0xc
//   const constructor, 
class CenterSeekButton extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfaa1cc, size: 0x1ac
    // 0xfaa1cc: EnterFrame
    //     0xfaa1cc: stp             fp, lr, [SP, #-0x10]!
    //     0xfaa1d0: mov             fp, SP
    // 0xfaa1d4: AllocStack(0x28)
    //     0xfaa1d4: sub             SP, SP, #0x28
    // 0xfaa1d8: SetupParameters(CenterSeekButton this /* r1 => r1, fp-0x8 */)
    //     0xfaa1d8: stur            x1, [fp, #-8]
    // 0xfaa1dc: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xfaa1dc: ldur            w0, [x1, #0x17]
    // 0xfaa1e0: DecompressPointer r0
    //     0xfaa1e0: add             x0, x0, HEAP, lsl #32
    // 0xfaa1e4: tbnz            w0, #4, #0xfaa1f0
    // 0xfaa1e8: d0 = 1.000000
    //     0xfaa1e8: fmov            d0, #1.00000000
    // 0xfaa1ec: b               #0xfaa1f4
    // 0xfaa1f0: d0 = 0.000000
    //     0xfaa1f0: eor             v0.16b, v0.16b, v0.16b
    // 0xfaa1f4: stur            d0, [fp, #-0x28]
    // 0xfaa1f8: r0 = BoxDecoration()
    //     0xfaa1f8: bl              #0x8a721c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0xfaa1fc: mov             x1, x0
    // 0xfaa200: r0 = Instance_Color
    //     0xfaa200: add             x0, PP, #0x12, lsl #12  ; [pp+0x12c78] Obj!Color@12a1741
    //     0xfaa204: ldr             x0, [x0, #0xc78]
    // 0xfaa208: stur            x1, [fp, #-0x18]
    // 0xfaa20c: StoreField: r1->field_7 = r0
    //     0xfaa20c: stur            w0, [x1, #7]
    // 0xfaa210: r0 = Instance_BoxShape
    //     0xfaa210: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1abf0] Obj!BoxShape@12c4941
    //     0xfaa214: ldr             x0, [x0, #0xbf0]
    // 0xfaa218: StoreField: r1->field_23 = r0
    //     0xfaa218: stur            w0, [x1, #0x23]
    // 0xfaa21c: ldur            x0, [fp, #-8]
    // 0xfaa220: LoadField: r2 = r0->field_b
    //     0xfaa220: ldur            w2, [x0, #0xb]
    // 0xfaa224: DecompressPointer r2
    //     0xfaa224: add             x2, x2, HEAP, lsl #32
    // 0xfaa228: stur            x2, [fp, #-0x10]
    // 0xfaa22c: r0 = Icon()
    //     0xfaa22c: bl              #0xd0fd5c  ; AllocateIconStub -> Icon (size=0x40)
    // 0xfaa230: mov             x1, x0
    // 0xfaa234: ldur            x0, [fp, #-0x10]
    // 0xfaa238: stur            x1, [fp, #-0x20]
    // 0xfaa23c: StoreField: r1->field_b = r0
    //     0xfaa23c: stur            w0, [x1, #0xb]
    // 0xfaa240: r0 = Instance_Color
    //     0xfaa240: add             x0, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0xfaa244: ldr             x0, [x0, #0xc38]
    // 0xfaa248: StoreField: r1->field_23 = r0
    //     0xfaa248: stur            w0, [x1, #0x23]
    // 0xfaa24c: ldur            x0, [fp, #-8]
    // 0xfaa250: LoadField: r2 = r0->field_1b
    //     0xfaa250: ldur            w2, [x0, #0x1b]
    // 0xfaa254: DecompressPointer r2
    //     0xfaa254: add             x2, x2, HEAP, lsl #32
    // 0xfaa258: stur            x2, [fp, #-0x10]
    // 0xfaa25c: r0 = IconButton()
    //     0xfaa25c: bl              #0xd16288  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0xfaa260: mov             x1, x0
    // 0xfaa264: r0 = 26.000000
    //     0xfaa264: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1ecb0] 26
    //     0xfaa268: ldr             x0, [x0, #0xcb0]
    // 0xfaa26c: stur            x1, [fp, #-8]
    // 0xfaa270: StoreField: r1->field_b = r0
    //     0xfaa270: stur            w0, [x1, #0xb]
    // 0xfaa274: r0 = Instance_EdgeInsets
    //     0xfaa274: add             x0, PP, #0x18, lsl #12  ; [pp+0x18338] Obj!EdgeInsets@129d051
    //     0xfaa278: ldr             x0, [x0, #0x338]
    // 0xfaa27c: StoreField: r1->field_13 = r0
    //     0xfaa27c: stur            w0, [x1, #0x13]
    // 0xfaa280: ldur            x0, [fp, #-0x10]
    // 0xfaa284: StoreField: r1->field_3b = r0
    //     0xfaa284: stur            w0, [x1, #0x3b]
    // 0xfaa288: r0 = false
    //     0xfaa288: add             x0, NULL, #0x30  ; false
    // 0xfaa28c: StoreField: r1->field_4f = r0
    //     0xfaa28c: stur            w0, [x1, #0x4f]
    // 0xfaa290: ldur            x2, [fp, #-0x20]
    // 0xfaa294: StoreField: r1->field_1f = r2
    //     0xfaa294: stur            w2, [x1, #0x1f]
    // 0xfaa298: r2 = Instance__IconButtonVariant
    //     0xfaa298: add             x2, PP, #0x17, lsl #12  ; [pp+0x177a8] Obj!_IconButtonVariant@12c57a1
    //     0xfaa29c: ldr             x2, [x2, #0x7a8]
    // 0xfaa2a0: StoreField: r1->field_6f = r2
    //     0xfaa2a0: stur            w2, [x1, #0x6f]
    // 0xfaa2a4: r0 = DecoratedBox()
    //     0xfaa2a4: bl              #0xd66318  ; AllocateDecoratedBoxStub -> DecoratedBox (size=0x18)
    // 0xfaa2a8: mov             x1, x0
    // 0xfaa2ac: ldur            x0, [fp, #-0x18]
    // 0xfaa2b0: stur            x1, [fp, #-0x10]
    // 0xfaa2b4: StoreField: r1->field_f = r0
    //     0xfaa2b4: stur            w0, [x1, #0xf]
    // 0xfaa2b8: r0 = Instance_DecorationPosition
    //     0xfaa2b8: add             x0, PP, #0x80, lsl #12  ; [pp+0x80ef0] Obj!DecorationPosition@12c4381
    //     0xfaa2bc: ldr             x0, [x0, #0xef0]
    // 0xfaa2c0: StoreField: r1->field_13 = r0
    //     0xfaa2c0: stur            w0, [x1, #0x13]
    // 0xfaa2c4: ldur            x0, [fp, #-8]
    // 0xfaa2c8: StoreField: r1->field_b = r0
    //     0xfaa2c8: stur            w0, [x1, #0xb]
    // 0xfaa2cc: r0 = AnimatedOpacity()
    //     0xfaa2cc: bl              #0xd2cf50  ; AllocateAnimatedOpacityStub -> AnimatedOpacity (size=0x28)
    // 0xfaa2d0: mov             x1, x0
    // 0xfaa2d4: ldur            x0, [fp, #-0x10]
    // 0xfaa2d8: stur            x1, [fp, #-8]
    // 0xfaa2dc: ArrayStore: r1[0] = r0  ; List_4
    //     0xfaa2dc: stur            w0, [x1, #0x17]
    // 0xfaa2e0: ldur            d0, [fp, #-0x28]
    // 0xfaa2e4: StoreField: r1->field_1b = d0
    //     0xfaa2e4: stur            d0, [x1, #0x1b]
    // 0xfaa2e8: r0 = false
    //     0xfaa2e8: add             x0, NULL, #0x30  ; false
    // 0xfaa2ec: StoreField: r1->field_23 = r0
    //     0xfaa2ec: stur            w0, [x1, #0x23]
    // 0xfaa2f0: r0 = Instance__Linear
    //     0xfaa2f0: ldr             x0, [PP, #0x5168]  ; [pp+0x5168] Obj!_Linear@129fef1
    // 0xfaa2f4: StoreField: r1->field_b = r0
    //     0xfaa2f4: stur            w0, [x1, #0xb]
    // 0xfaa2f8: r0 = Instance_Duration
    //     0xfaa2f8: ldr             x0, [PP, #0x7cd8]  ; [pp+0x7cd8] Obj!Duration@12c8971
    // 0xfaa2fc: StoreField: r1->field_f = r0
    //     0xfaa2fc: stur            w0, [x1, #0xf]
    // 0xfaa300: r0 = UnconstrainedBox()
    //     0xfaa300: bl              #0xfaa1c0  ; AllocateUnconstrainedBoxStub -> UnconstrainedBox (size=0x20)
    // 0xfaa304: mov             x1, x0
    // 0xfaa308: ldur            x0, [fp, #-8]
    // 0xfaa30c: stur            x1, [fp, #-0x10]
    // 0xfaa310: StoreField: r1->field_1b = r0
    //     0xfaa310: stur            w0, [x1, #0x1b]
    // 0xfaa314: r0 = Instance_Alignment
    //     0xfaa314: add             x0, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xfaa318: ldr             x0, [x0, #0xb80]
    // 0xfaa31c: StoreField: r1->field_f = r0
    //     0xfaa31c: stur            w0, [x1, #0xf]
    // 0xfaa320: r2 = Instance_Clip
    //     0xfaa320: add             x2, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xfaa324: ldr             x2, [x2, #0x840]
    // 0xfaa328: ArrayStore: r1[0] = r2  ; List_4
    //     0xfaa328: stur            w2, [x1, #0x17]
    // 0xfaa32c: r0 = Center()
    //     0xfaa32c: bl              #0xd0c898  ; AllocateCenterStub -> Center (size=0x1c)
    // 0xfaa330: mov             x1, x0
    // 0xfaa334: r0 = Instance_Alignment
    //     0xfaa334: add             x0, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xfaa338: ldr             x0, [x0, #0xb80]
    // 0xfaa33c: stur            x1, [fp, #-8]
    // 0xfaa340: StoreField: r1->field_f = r0
    //     0xfaa340: stur            w0, [x1, #0xf]
    // 0xfaa344: ldur            x0, [fp, #-0x10]
    // 0xfaa348: StoreField: r1->field_b = r0
    //     0xfaa348: stur            w0, [x1, #0xb]
    // 0xfaa34c: r0 = ColoredBox()
    //     0xfaa34c: bl              #0xd1a914  ; AllocateColoredBoxStub -> ColoredBox (size=0x18)
    // 0xfaa350: r1 = Instance_Color
    //     0xfaa350: add             x1, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xfaa354: ldr             x1, [x1, #0x810]
    // 0xfaa358: StoreField: r0->field_f = r1
    //     0xfaa358: stur            w1, [x0, #0xf]
    // 0xfaa35c: r1 = true
    //     0xfaa35c: add             x1, NULL, #0x20  ; true
    // 0xfaa360: StoreField: r0->field_13 = r1
    //     0xfaa360: stur            w1, [x0, #0x13]
    // 0xfaa364: ldur            x1, [fp, #-8]
    // 0xfaa368: StoreField: r0->field_b = r1
    //     0xfaa368: stur            w1, [x0, #0xb]
    // 0xfaa36c: LeaveFrame
    //     0xfaa36c: mov             SP, fp
    //     0xfaa370: ldp             fp, lr, [SP], #0x10
    // 0xfaa374: ret
    //     0xfaa374: ret             
  }
}
