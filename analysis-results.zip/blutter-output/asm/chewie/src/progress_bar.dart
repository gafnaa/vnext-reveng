// lib: , url: package:chewie/src/progress_bar.dart

// class id: 1048646, size: 0x8
class :: {

  static _ RelativePositionExtensions.calcRelativePosition(/* No info */) {
    // ** addr: 0xde2978, size: 0x108
    // 0xde2978: EnterFrame
    //     0xde2978: stp             fp, lr, [SP, #-0x10]!
    //     0xde297c: mov             fp, SP
    // 0xde2980: AllocStack(0x20)
    //     0xde2980: sub             SP, SP, #0x20
    // 0xde2984: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */, dynamic _ /* r3 => r2, fp-0x10 */)
    //     0xde2984: mov             x0, x2
    //     0xde2988: stur            x2, [fp, #-8]
    //     0xde298c: mov             x2, x3
    //     0xde2990: stur            x3, [fp, #-0x10]
    // 0xde2994: CheckStackOverflow
    //     0xde2994: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde2998: cmp             SP, x16
    //     0xde299c: b.ls            #0xde2a60
    // 0xde29a0: r0 = findRenderObject()
    //     0xde29a0: bl              #0x8418fc  ; [package:flutter/src/widgets/framework.dart] Element::findRenderObject
    // 0xde29a4: mov             x3, x0
    // 0xde29a8: stur            x3, [fp, #-0x18]
    // 0xde29ac: cmp             w3, NULL
    // 0xde29b0: b.eq            #0xde2a68
    // 0xde29b4: mov             x0, x3
    // 0xde29b8: r2 = Null
    //     0xde29b8: mov             x2, NULL
    // 0xde29bc: r1 = Null
    //     0xde29bc: mov             x1, NULL
    // 0xde29c0: r4 = LoadClassIdInstr(r0)
    //     0xde29c0: ldur            x4, [x0, #-1]
    //     0xde29c4: ubfx            x4, x4, #0xc, #0x14
    // 0xde29c8: r17 = -4710
    //     0xde29c8: mov             x17, #-0x1266
    // 0xde29cc: add             x4, x4, x17
    // 0xde29d0: cmp             x4, #0x109
    // 0xde29d4: b.ls            #0xde29e8
    // 0xde29d8: r8 = RenderBox
    //     0xde29d8: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0xde29dc: r3 = Null
    //     0xde29dc: add             x3, PP, #0xd4, lsl #12  ; [pp+0xd4d58] Null
    //     0xde29e0: ldr             x3, [x3, #0xd58]
    // 0xde29e4: r0 = RenderBox()
    //     0xde29e4: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0xde29e8: ldur            x1, [fp, #-0x18]
    // 0xde29ec: ldur            x2, [fp, #-0x10]
    // 0xde29f0: r0 = globalToLocal()
    //     0xde29f0: bl              #0x867840  ; [package:flutter/src/rendering/box.dart] RenderBox::globalToLocal
    // 0xde29f4: LoadField: d0 = r0->field_7
    //     0xde29f4: ldur            d0, [x0, #7]
    // 0xde29f8: ldur            x1, [fp, #-0x18]
    // 0xde29fc: stur            d0, [fp, #-0x20]
    // 0xde2a00: r0 = size()
    //     0xde2a00: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xde2a04: LoadField: d0 = r0->field_7
    //     0xde2a04: ldur            d0, [x0, #7]
    // 0xde2a08: ldur            d1, [fp, #-0x20]
    // 0xde2a0c: fdiv            d2, d1, d0
    // 0xde2a10: r1 = inline_Allocate_Double()
    //     0xde2a10: ldp             x1, x0, [THR, #0x60]  ; THR::top
    //     0xde2a14: add             x1, x1, #0x10
    //     0xde2a18: cmp             x0, x1
    //     0xde2a1c: b.ls            #0xde2a6c
    //     0xde2a20: str             x1, [THR, #0x60]  ; THR::top
    //     0xde2a24: sub             x1, x1, #0xf
    //     0xde2a28: mov             x0, #0xe19c
    //     0xde2a2c: movk            x0, #3, lsl #16
    //     0xde2a30: stur            x0, [x1, #-1]
    // 0xde2a34: dmb             ishst
    // 0xde2a38: StoreField: r1->field_7 = d2
    //     0xde2a38: stur            d2, [x1, #7]
    // 0xde2a3c: r2 = 0.000000
    //     0xde2a3c: ldr             x2, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xde2a40: r3 = 1.000000
    //     0xde2a40: ldr             x3, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xde2a44: r0 = clamp()
    //     0xde2a44: bl              #0x13db384  ; [dart:core] _Double::clamp
    // 0xde2a48: ldur            x1, [fp, #-8]
    // 0xde2a4c: mov             x2, x0
    // 0xde2a50: r0 = *()
    //     0xde2a50: bl              #0x7dd190  ; [dart:core] Duration::*
    // 0xde2a54: LeaveFrame
    //     0xde2a54: mov             SP, fp
    //     0xde2a58: ldp             fp, lr, [SP], #0x10
    // 0xde2a5c: ret
    //     0xde2a5c: ret             
    // 0xde2a60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde2a60: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde2a64: b               #0xde29a0
    // 0xde2a68: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde2a68: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde2a6c: SaveReg d2
    //     0xde2a6c: str             q2, [SP, #-0x10]!
    // 0xde2a70: r0 = AllocateDouble()
    //     0xde2a70: bl              #0x13df878  ; AllocateDoubleStub
    // 0xde2a74: mov             x1, x0
    // 0xde2a78: RestoreReg d2
    //     0xde2a78: ldr             q2, [SP], #0x10
    // 0xde2a7c: b               #0xde2a38
  }
}

// class id: 4347, size: 0x2c, field offset: 0xc
class _ProgressBarPainter extends CustomPainter {

  _ paint(/* No info */) {
    // ** addr: 0xb73c98, size: 0x644
    // 0xb73c98: EnterFrame
    //     0xb73c98: stp             fp, lr, [SP, #-0x10]!
    //     0xb73c9c: mov             fp, SP
    // 0xb73ca0: AllocStack(0x98)
    //     0xb73ca0: sub             SP, SP, #0x98
    // 0xb73ca4: d0 = 2.000000
    //     0xb73ca4: fmov            d0, #2.00000000
    // 0xb73ca8: mov             x0, x1
    // 0xb73cac: stur            x1, [fp, #-8]
    // 0xb73cb0: mov             x1, x2
    // 0xb73cb4: stur            x2, [fp, #-0x10]
    // 0xb73cb8: stur            x3, [fp, #-0x18]
    // 0xb73cbc: CheckStackOverflow
    //     0xb73cbc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb73cc0: cmp             SP, x16
    //     0xb73cc4: b.ls            #0xb742c0
    // 0xb73cc8: LoadField: d1 = r3->field_f
    //     0xb73cc8: ldur            d1, [x3, #0xf]
    // 0xb73ccc: fdiv            d2, d1, d0
    // 0xb73cd0: LoadField: d1 = r0->field_13
    //     0xb73cd0: ldur            d1, [x0, #0x13]
    // 0xb73cd4: stur            d1, [fp, #-0x50]
    // 0xb73cd8: fdiv            d3, d1, d0
    // 0xb73cdc: stur            d3, [fp, #-0x48]
    // 0xb73ce0: fsub            d0, d2, d3
    // 0xb73ce4: stur            d0, [fp, #-0x40]
    // 0xb73ce8: r0 = Offset()
    //     0xb73ce8: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xb73cec: stur            x0, [fp, #-0x20]
    // 0xb73cf0: StoreField: r0->field_7 = rZR
    //     0xb73cf0: stur            xzr, [x0, #7]
    // 0xb73cf4: ldur            d0, [fp, #-0x40]
    // 0xb73cf8: StoreField: r0->field_f = d0
    //     0xb73cf8: stur            d0, [x0, #0xf]
    // 0xb73cfc: ldur            x1, [fp, #-0x18]
    // 0xb73d00: LoadField: d1 = r1->field_7
    //     0xb73d00: ldur            d1, [x1, #7]
    // 0xb73d04: ldur            d2, [fp, #-0x50]
    // 0xb73d08: stur            d1, [fp, #-0x60]
    // 0xb73d0c: fadd            d3, d0, d2
    // 0xb73d10: stur            d3, [fp, #-0x58]
    // 0xb73d14: r0 = Offset()
    //     0xb73d14: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xb73d18: ldur            d0, [fp, #-0x60]
    // 0xb73d1c: stur            x0, [fp, #-0x18]
    // 0xb73d20: StoreField: r0->field_7 = d0
    //     0xb73d20: stur            d0, [x0, #7]
    // 0xb73d24: ldur            d1, [fp, #-0x58]
    // 0xb73d28: StoreField: r0->field_f = d1
    //     0xb73d28: stur            d1, [x0, #0xf]
    // 0xb73d2c: r0 = Rect()
    //     0xb73d2c: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0xb73d30: mov             x1, x0
    // 0xb73d34: ldur            x2, [fp, #-0x20]
    // 0xb73d38: ldur            x3, [fp, #-0x18]
    // 0xb73d3c: stur            x0, [fp, #-0x18]
    // 0xb73d40: r0 = Rect.fromPoints()
    //     0xb73d40: bl              #0x858780  ; [dart:ui] Rect::Rect.fromPoints
    // 0xb73d44: r1 = <RRect>
    //     0xb73d44: add             x1, PP, #0x85, lsl #12  ; [pp+0x85108] TypeArguments: <RRect>
    //     0xb73d48: ldr             x1, [x1, #0x108]
    // 0xb73d4c: r0 = RRect()
    //     0xb73d4c: bl              #0xb6e214  ; AllocateRRectStub -> RRect (size=0x6c)
    // 0xb73d50: mov             x1, x0
    // 0xb73d54: ldur            x2, [fp, #-0x18]
    // 0xb73d58: r3 = Instance_Radius
    //     0xb73d58: add             x3, PP, #0x9d, lsl #12  ; [pp+0x9d080] Obj!Radius@12a7121
    //     0xb73d5c: ldr             x3, [x3, #0x80]
    // 0xb73d60: stur            x0, [fp, #-0x18]
    // 0xb73d64: r0 = RRect.fromRectAndRadius()
    //     0xb73d64: bl              #0xb6e920  ; [dart:ui] RRect::RRect.fromRectAndRadius
    // 0xb73d68: ldur            x0, [fp, #-8]
    // 0xb73d6c: LoadField: r1 = r0->field_f
    //     0xb73d6c: ldur            w1, [x0, #0xf]
    // 0xb73d70: DecompressPointer r1
    //     0xb73d70: add             x1, x1, HEAP, lsl #32
    // 0xb73d74: LoadField: r3 = r1->field_13
    //     0xb73d74: ldur            w3, [x1, #0x13]
    // 0xb73d78: DecompressPointer r3
    //     0xb73d78: add             x3, x3, HEAP, lsl #32
    // 0xb73d7c: ldur            x1, [fp, #-0x10]
    // 0xb73d80: ldur            x2, [fp, #-0x18]
    // 0xb73d84: r0 = drawRRect()
    //     0xb73d84: bl              #0xb6dce0  ; [dart:ui] _NativeCanvas::drawRRect
    // 0xb73d88: ldur            x2, [fp, #-8]
    // 0xb73d8c: LoadField: r0 = r2->field_b
    //     0xb73d8c: ldur            w0, [x2, #0xb]
    // 0xb73d90: DecompressPointer r0
    //     0xb73d90: add             x0, x0, HEAP, lsl #32
    // 0xb73d94: LoadField: r1 = r0->field_4f
    //     0xb73d94: ldur            w1, [x0, #0x4f]
    // 0xb73d98: DecompressPointer r1
    //     0xb73d98: add             x1, x1, HEAP, lsl #32
    // 0xb73d9c: tbz             w1, #4, #0xb73db0
    // 0xb73da0: r0 = Null
    //     0xb73da0: mov             x0, NULL
    // 0xb73da4: LeaveFrame
    //     0xb73da4: mov             SP, fp
    //     0xb73da8: ldp             fp, lr, [SP], #0x10
    // 0xb73dac: ret
    //     0xb73dac: ret             
    // 0xb73db0: LoadField: r1 = r2->field_27
    //     0xb73db0: ldur            w1, [x2, #0x27]
    // 0xb73db4: DecompressPointer r1
    //     0xb73db4: add             x1, x1, HEAP, lsl #32
    // 0xb73db8: cmp             w1, NULL
    // 0xb73dbc: b.eq            #0xb73dd0
    // 0xb73dc0: r3 = 1000
    //     0xb73dc0: mov             x3, #0x3e8
    // 0xb73dc4: LoadField: r4 = r1->field_7
    //     0xb73dc4: ldur            x4, [x1, #7]
    // 0xb73dc8: sdiv            x1, x4, x3
    // 0xb73dcc: b               #0xb73de4
    // 0xb73dd0: r3 = 1000
    //     0xb73dd0: mov             x3, #0x3e8
    // 0xb73dd4: LoadField: r1 = r0->field_b
    //     0xb73dd4: ldur            w1, [x0, #0xb]
    // 0xb73dd8: DecompressPointer r1
    //     0xb73dd8: add             x1, x1, HEAP, lsl #32
    // 0xb73ddc: LoadField: r4 = r1->field_7
    //     0xb73ddc: ldur            x4, [x1, #7]
    // 0xb73de0: sdiv            x1, x4, x3
    // 0xb73de4: d0 = 1.000000
    //     0xb73de4: fmov            d0, #1.00000000
    // 0xb73de8: LoadField: r4 = r0->field_7
    //     0xb73de8: ldur            w4, [x0, #7]
    // 0xb73dec: DecompressPointer r4
    //     0xb73dec: add             x4, x4, HEAP, lsl #32
    // 0xb73df0: LoadField: r5 = r4->field_7
    //     0xb73df0: ldur            x5, [x4, #7]
    // 0xb73df4: sdiv            x4, x5, x3
    // 0xb73df8: scvtf           d1, x1
    // 0xb73dfc: scvtf           d2, x4
    // 0xb73e00: fdiv            d3, d1, d2
    // 0xb73e04: fcmp            d3, d0
    // 0xb73e08: b.le            #0xb73e18
    // 0xb73e0c: ldur            d1, [fp, #-0x60]
    // 0xb73e10: ldur            d0, [fp, #-0x60]
    // 0xb73e14: b               #0xb73e20
    // 0xb73e18: ldur            d0, [fp, #-0x60]
    // 0xb73e1c: fmul            d1, d3, d0
    // 0xb73e20: stur            d1, [fp, #-0x50]
    // 0xb73e24: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb73e24: ldur            w1, [x0, #0x17]
    // 0xb73e28: DecompressPointer r1
    //     0xb73e28: add             x1, x1, HEAP, lsl #32
    // 0xb73e2c: r0 = LoadClassIdInstr(r1)
    //     0xb73e2c: ldur            x0, [x1, #-1]
    //     0xb73e30: ubfx            x0, x0, #0xc, #0x14
    // 0xb73e34: r0 = GDT[cid_x0 + 0x12641]()
    //     0xb73e34: mov             x17, #0x2641
    //     0xb73e38: movk            x17, #1, lsl #16
    //     0xb73e3c: add             lr, x0, x17
    //     0xb73e40: ldr             lr, [x21, lr, lsl #3]
    //     0xb73e44: blr             lr
    // 0xb73e48: mov             x2, x0
    // 0xb73e4c: r3 = Instance_Radius
    //     0xb73e4c: add             x3, PP, #0x9d, lsl #12  ; [pp+0x9d080] Obj!Radius@12a7121
    //     0xb73e50: ldr             x3, [x3, #0x80]
    // 0xb73e54: stur            x2, [fp, #-0x18]
    // 0xb73e58: LoadField: d0 = r3->field_7
    //     0xb73e58: ldur            d0, [x3, #7]
    // 0xb73e5c: stur            d0, [fp, #-0x70]
    // 0xb73e60: LoadField: d1 = r3->field_f
    //     0xb73e60: ldur            d1, [x3, #0xf]
    // 0xb73e64: stur            d1, [fp, #-0x68]
    // 0xb73e68: ldur            x4, [fp, #-8]
    // 0xb73e6c: ldur            d4, [fp, #-0x40]
    // 0xb73e70: ldur            d3, [fp, #-0x58]
    // 0xb73e74: ldur            d2, [fp, #-0x60]
    // 0xb73e78: CheckStackOverflow
    //     0xb73e78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb73e7c: cmp             SP, x16
    //     0xb73e80: b.ls            #0xb742c8
    // 0xb73e84: r0 = LoadClassIdInstr(r2)
    //     0xb73e84: ldur            x0, [x2, #-1]
    //     0xb73e88: ubfx            x0, x0, #0xc, #0x14
    // 0xb73e8c: mov             x1, x2
    // 0xb73e90: r0 = GDT[cid_x0 + 0x1845b]()
    //     0xb73e90: mov             x17, #0x845b
    //     0xb73e94: movk            x17, #1, lsl #16
    //     0xb73e98: add             lr, x0, x17
    //     0xb73e9c: ldr             lr, [x21, lr, lsl #3]
    //     0xb73ea0: blr             lr
    // 0xb73ea4: tbnz            w0, #4, #0xb74038
    // 0xb73ea8: ldur            x3, [fp, #-8]
    // 0xb73eac: ldur            d4, [fp, #-0x40]
    // 0xb73eb0: ldur            d3, [fp, #-0x58]
    // 0xb73eb4: ldur            x2, [fp, #-0x18]
    // 0xb73eb8: ldur            d0, [fp, #-0x70]
    // 0xb73ebc: ldur            d1, [fp, #-0x68]
    // 0xb73ec0: ldur            d2, [fp, #-0x60]
    // 0xb73ec4: r0 = LoadClassIdInstr(r2)
    //     0xb73ec4: ldur            x0, [x2, #-1]
    //     0xb73ec8: ubfx            x0, x0, #0xc, #0x14
    // 0xb73ecc: mov             x1, x2
    // 0xb73ed0: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0xb73ed0: mov             x17, #0x7d4c
    //     0xb73ed4: movk            x17, #1, lsl #16
    //     0xb73ed8: add             lr, x0, x17
    //     0xb73edc: ldr             lr, [x21, lr, lsl #3]
    //     0xb73ee0: blr             lr
    // 0xb73ee4: mov             x1, x0
    // 0xb73ee8: ldur            x0, [fp, #-8]
    // 0xb73eec: LoadField: r2 = r0->field_b
    //     0xb73eec: ldur            w2, [x0, #0xb]
    // 0xb73ef0: DecompressPointer r2
    //     0xb73ef0: add             x2, x2, HEAP, lsl #32
    // 0xb73ef4: LoadField: r3 = r2->field_7
    //     0xb73ef4: ldur            w3, [x2, #7]
    // 0xb73ef8: DecompressPointer r3
    //     0xb73ef8: add             x3, x3, HEAP, lsl #32
    // 0xb73efc: LoadField: r2 = r3->field_7
    //     0xb73efc: ldur            x2, [x3, #7]
    // 0xb73f00: r3 = 1000
    //     0xb73f00: mov             x3, #0x3e8
    // 0xb73f04: sdiv            x4, x2, x3
    // 0xb73f08: scvtf           d0, x4
    // 0xb73f0c: d1 = 0.000000
    //     0xb73f0c: eor             v1.16b, v1.16b, v1.16b
    // 0xb73f10: fdiv            d2, d1, d0
    // 0xb73f14: ldur            d3, [fp, #-0x60]
    // 0xb73f18: fmul            d4, d2, d3
    // 0xb73f1c: stur            d4, [fp, #-0x80]
    // 0xb73f20: LoadField: r2 = r1->field_b
    //     0xb73f20: ldur            w2, [x1, #0xb]
    // 0xb73f24: DecompressPointer r2
    //     0xb73f24: add             x2, x2, HEAP, lsl #32
    // 0xb73f28: LoadField: r1 = r2->field_7
    //     0xb73f28: ldur            x1, [x2, #7]
    // 0xb73f2c: sdiv            x2, x1, x3
    // 0xb73f30: scvtf           d2, x2
    // 0xb73f34: fdiv            d5, d2, d0
    // 0xb73f38: fmul            d0, d5, d3
    // 0xb73f3c: stur            d0, [fp, #-0x78]
    // 0xb73f40: r0 = Offset()
    //     0xb73f40: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xb73f44: ldur            d0, [fp, #-0x80]
    // 0xb73f48: stur            x0, [fp, #-0x20]
    // 0xb73f4c: StoreField: r0->field_7 = d0
    //     0xb73f4c: stur            d0, [x0, #7]
    // 0xb73f50: ldur            d0, [fp, #-0x40]
    // 0xb73f54: StoreField: r0->field_f = d0
    //     0xb73f54: stur            d0, [x0, #0xf]
    // 0xb73f58: r0 = Offset()
    //     0xb73f58: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xb73f5c: ldur            d0, [fp, #-0x78]
    // 0xb73f60: stur            x0, [fp, #-0x28]
    // 0xb73f64: StoreField: r0->field_7 = d0
    //     0xb73f64: stur            d0, [x0, #7]
    // 0xb73f68: ldur            d0, [fp, #-0x58]
    // 0xb73f6c: StoreField: r0->field_f = d0
    //     0xb73f6c: stur            d0, [x0, #0xf]
    // 0xb73f70: r0 = Rect()
    //     0xb73f70: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0xb73f74: mov             x1, x0
    // 0xb73f78: ldur            x2, [fp, #-0x20]
    // 0xb73f7c: ldur            x3, [fp, #-0x28]
    // 0xb73f80: stur            x0, [fp, #-0x20]
    // 0xb73f84: r0 = Rect.fromPoints()
    //     0xb73f84: bl              #0x858780  ; [dart:ui] Rect::Rect.fromPoints
    // 0xb73f88: ldur            x0, [fp, #-0x20]
    // 0xb73f8c: LoadField: d0 = r0->field_f
    //     0xb73f8c: ldur            d0, [x0, #0xf]
    // 0xb73f90: stur            d0, [fp, #-0x90]
    // 0xb73f94: LoadField: d1 = r0->field_7
    //     0xb73f94: ldur            d1, [x0, #7]
    // 0xb73f98: stur            d1, [fp, #-0x88]
    // 0xb73f9c: ArrayLoad: d2 = r0[0]  ; List_8
    //     0xb73f9c: ldur            d2, [x0, #0x17]
    // 0xb73fa0: stur            d2, [fp, #-0x80]
    // 0xb73fa4: LoadField: d3 = r0->field_1f
    //     0xb73fa4: ldur            d3, [x0, #0x1f]
    // 0xb73fa8: stur            d3, [fp, #-0x78]
    // 0xb73fac: r1 = <RRect>
    //     0xb73fac: add             x1, PP, #0x85, lsl #12  ; [pp+0x85108] TypeArguments: <RRect>
    //     0xb73fb0: ldr             x1, [x1, #0x108]
    // 0xb73fb4: r0 = RRect()
    //     0xb73fb4: bl              #0xb6e214  ; AllocateRRectStub -> RRect (size=0x6c)
    // 0xb73fb8: ldur            d0, [fp, #-0x88]
    // 0xb73fbc: StoreField: r0->field_b = d0
    //     0xb73fbc: stur            d0, [x0, #0xb]
    // 0xb73fc0: ldur            d0, [fp, #-0x90]
    // 0xb73fc4: StoreField: r0->field_13 = d0
    //     0xb73fc4: stur            d0, [x0, #0x13]
    // 0xb73fc8: ldur            d0, [fp, #-0x80]
    // 0xb73fcc: StoreField: r0->field_1b = d0
    //     0xb73fcc: stur            d0, [x0, #0x1b]
    // 0xb73fd0: ldur            d0, [fp, #-0x78]
    // 0xb73fd4: StoreField: r0->field_23 = d0
    //     0xb73fd4: stur            d0, [x0, #0x23]
    // 0xb73fd8: ldur            d0, [fp, #-0x70]
    // 0xb73fdc: StoreField: r0->field_2b = d0
    //     0xb73fdc: stur            d0, [x0, #0x2b]
    // 0xb73fe0: ldur            d1, [fp, #-0x68]
    // 0xb73fe4: StoreField: r0->field_33 = d1
    //     0xb73fe4: stur            d1, [x0, #0x33]
    // 0xb73fe8: StoreField: r0->field_3b = d0
    //     0xb73fe8: stur            d0, [x0, #0x3b]
    // 0xb73fec: StoreField: r0->field_43 = d1
    //     0xb73fec: stur            d1, [x0, #0x43]
    // 0xb73ff0: StoreField: r0->field_4b = d0
    //     0xb73ff0: stur            d0, [x0, #0x4b]
    // 0xb73ff4: StoreField: r0->field_53 = d1
    //     0xb73ff4: stur            d1, [x0, #0x53]
    // 0xb73ff8: StoreField: r0->field_5b = d0
    //     0xb73ff8: stur            d0, [x0, #0x5b]
    // 0xb73ffc: StoreField: r0->field_63 = d1
    //     0xb73ffc: stur            d1, [x0, #0x63]
    // 0xb74000: ldur            x4, [fp, #-8]
    // 0xb74004: LoadField: r1 = r4->field_f
    //     0xb74004: ldur            w1, [x4, #0xf]
    // 0xb74008: DecompressPointer r1
    //     0xb74008: add             x1, x1, HEAP, lsl #32
    // 0xb7400c: LoadField: r3 = r1->field_b
    //     0xb7400c: ldur            w3, [x1, #0xb]
    // 0xb74010: DecompressPointer r3
    //     0xb74010: add             x3, x3, HEAP, lsl #32
    // 0xb74014: ldur            x1, [fp, #-0x10]
    // 0xb74018: mov             x2, x0
    // 0xb7401c: r0 = drawRRect()
    //     0xb7401c: bl              #0xb6dce0  ; [dart:ui] _NativeCanvas::drawRRect
    // 0xb74020: ldur            x2, [fp, #-0x18]
    // 0xb74024: ldur            d0, [fp, #-0x70]
    // 0xb74028: ldur            d1, [fp, #-0x68]
    // 0xb7402c: r3 = Instance_Radius
    //     0xb7402c: add             x3, PP, #0x9d, lsl #12  ; [pp+0x9d080] Obj!Radius@12a7121
    //     0xb74030: ldr             x3, [x3, #0x80]
    // 0xb74034: b               #0xb73e68
    // 0xb74038: ldur            x0, [fp, #-8]
    // 0xb7403c: ldur            d3, [fp, #-0x48]
    // 0xb74040: ldur            d1, [fp, #-0x40]
    // 0xb74044: ldur            d0, [fp, #-0x58]
    // 0xb74048: ldur            d2, [fp, #-0x50]
    // 0xb7404c: r0 = Offset()
    //     0xb7404c: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xb74050: stur            x0, [fp, #-0x18]
    // 0xb74054: StoreField: r0->field_7 = rZR
    //     0xb74054: stur            xzr, [x0, #7]
    // 0xb74058: ldur            d0, [fp, #-0x40]
    // 0xb7405c: StoreField: r0->field_f = d0
    //     0xb7405c: stur            d0, [x0, #0xf]
    // 0xb74060: r0 = Offset()
    //     0xb74060: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xb74064: ldur            d0, [fp, #-0x50]
    // 0xb74068: stur            x0, [fp, #-0x20]
    // 0xb7406c: StoreField: r0->field_7 = d0
    //     0xb7406c: stur            d0, [x0, #7]
    // 0xb74070: ldur            d1, [fp, #-0x58]
    // 0xb74074: StoreField: r0->field_f = d1
    //     0xb74074: stur            d1, [x0, #0xf]
    // 0xb74078: r0 = Rect()
    //     0xb74078: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0xb7407c: mov             x1, x0
    // 0xb74080: ldur            x2, [fp, #-0x18]
    // 0xb74084: ldur            x3, [fp, #-0x20]
    // 0xb74088: stur            x0, [fp, #-0x18]
    // 0xb7408c: r0 = Rect.fromPoints()
    //     0xb7408c: bl              #0x858780  ; [dart:ui] Rect::Rect.fromPoints
    // 0xb74090: r1 = <RRect>
    //     0xb74090: add             x1, PP, #0x85, lsl #12  ; [pp+0x85108] TypeArguments: <RRect>
    //     0xb74094: ldr             x1, [x1, #0x108]
    // 0xb74098: r0 = RRect()
    //     0xb74098: bl              #0xb6e214  ; AllocateRRectStub -> RRect (size=0x6c)
    // 0xb7409c: mov             x1, x0
    // 0xb740a0: ldur            x2, [fp, #-0x18]
    // 0xb740a4: r3 = Instance_Radius
    //     0xb740a4: add             x3, PP, #0x9d, lsl #12  ; [pp+0x9d080] Obj!Radius@12a7121
    //     0xb740a8: ldr             x3, [x3, #0x80]
    // 0xb740ac: stur            x0, [fp, #-0x18]
    // 0xb740b0: r0 = RRect.fromRectAndRadius()
    //     0xb740b0: bl              #0xb6e920  ; [dart:ui] RRect::RRect.fromRectAndRadius
    // 0xb740b4: ldur            x0, [fp, #-8]
    // 0xb740b8: LoadField: r1 = r0->field_f
    //     0xb740b8: ldur            w1, [x0, #0xf]
    // 0xb740bc: DecompressPointer r1
    //     0xb740bc: add             x1, x1, HEAP, lsl #32
    // 0xb740c0: LoadField: r3 = r1->field_7
    //     0xb740c0: ldur            w3, [x1, #7]
    // 0xb740c4: DecompressPointer r3
    //     0xb740c4: add             x3, x3, HEAP, lsl #32
    // 0xb740c8: ldur            x1, [fp, #-0x10]
    // 0xb740cc: ldur            x2, [fp, #-0x18]
    // 0xb740d0: r0 = drawRRect()
    //     0xb740d0: bl              #0xb6dce0  ; [dart:ui] _NativeCanvas::drawRRect
    // 0xb740d4: r0 = _NativePath()
    //     0xb740d4: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0xb740d8: mov             x1, x0
    // 0xb740dc: stur            x0, [fp, #-0x18]
    // 0xb740e0: r0 = __constructor$Method$FfiNative()
    //     0xb740e0: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0xb740e4: ldur            d1, [fp, #-0x48]
    // 0xb740e8: ldur            d0, [fp, #-0x40]
    // 0xb740ec: fadd            d2, d0, d1
    // 0xb740f0: stur            d2, [fp, #-0x58]
    // 0xb740f4: r0 = Offset()
    //     0xb740f4: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xb740f8: ldur            d0, [fp, #-0x50]
    // 0xb740fc: stur            x0, [fp, #-0x20]
    // 0xb74100: StoreField: r0->field_7 = d0
    //     0xb74100: stur            d0, [x0, #7]
    // 0xb74104: ldur            d1, [fp, #-0x58]
    // 0xb74108: StoreField: r0->field_f = d1
    //     0xb74108: stur            d1, [x0, #0xf]
    // 0xb7410c: r0 = Rect()
    //     0xb7410c: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0xb74110: mov             x1, x0
    // 0xb74114: ldur            x2, [fp, #-0x20]
    // 0xb74118: d0 = 12.000000
    //     0xb74118: fmov            d0, #12.00000000
    // 0xb7411c: d1 = 12.000000
    //     0xb7411c: fmov            d1, #12.00000000
    // 0xb74120: stur            x0, [fp, #-0x20]
    // 0xb74124: r0 = Rect.fromCenter()
    //     0xb74124: bl              #0x86ddc8  ; [dart:ui] Rect::Rect.fromCenter
    // 0xb74128: ldur            x0, [fp, #-0x20]
    // 0xb7412c: LoadField: d0 = r0->field_7
    //     0xb7412c: ldur            d0, [x0, #7]
    // 0xb74130: stur            d0, [fp, #-0x68]
    // 0xb74134: LoadField: d1 = r0->field_f
    //     0xb74134: ldur            d1, [x0, #0xf]
    // 0xb74138: stur            d1, [fp, #-0x60]
    // 0xb7413c: ArrayLoad: d2 = r0[0]  ; List_8
    //     0xb7413c: ldur            d2, [x0, #0x17]
    // 0xb74140: stur            d2, [fp, #-0x48]
    // 0xb74144: LoadField: d3 = r0->field_1f
    //     0xb74144: ldur            d3, [x0, #0x1f]
    // 0xb74148: ldur            x0, [fp, #-0x18]
    // 0xb7414c: stur            d3, [fp, #-0x40]
    // 0xb74150: LoadField: r1 = r0->field_7
    //     0xb74150: ldur            w1, [x0, #7]
    // 0xb74154: DecompressPointer r1
    //     0xb74154: add             x1, x1, HEAP, lsl #32
    // 0xb74158: cmp             w1, NULL
    // 0xb7415c: b.eq            #0xb742d0
    // 0xb74160: LoadField: r2 = r1->field_7
    //     0xb74160: ldur            x2, [x1, #7]
    // 0xb74164: ldr             x1, [x2]
    // 0xb74168: cbz             x1, #0xb742a0
    // 0xb7416c: ldur            x2, [fp, #-0x10]
    // 0xb74170: mov             x3, x1
    // 0xb74174: stur            x3, [fp, #-0x30]
    // 0xb74178: r1 = <Never>
    //     0xb74178: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb7417c: r0 = Pointer()
    //     0xb7417c: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb74180: mov             x1, x0
    // 0xb74184: ldur            x0, [fp, #-0x30]
    // 0xb74188: StoreField: r1->field_7 = r0
    //     0xb74188: stur            x0, [x1, #7]
    // 0xb7418c: ldur            d0, [fp, #-0x68]
    // 0xb74190: ldur            d1, [fp, #-0x60]
    // 0xb74194: ldur            d2, [fp, #-0x48]
    // 0xb74198: ldur            d3, [fp, #-0x40]
    // 0xb7419c: r0 = __addOval$Method$FfiNative()
    //     0xb7419c: bl              #0xb6b218  ; [dart:ui] _NativePath::__addOval$Method$FfiNative
    // 0xb741a0: r1 = Instance_Color
    //     0xb741a0: add             x1, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0xb741a4: ldr             x1, [x1, #0x948]
    // 0xb741a8: r0 = toARGB32()
    //     0xb741a8: bl              #0x119defc  ; [dart:ui] Color::toARGB32
    // 0xb741ac: mov             x2, x0
    // 0xb741b0: ldur            x0, [fp, #-0x10]
    // 0xb741b4: stur            x2, [fp, #-0x38]
    // 0xb741b8: LoadField: r1 = r0->field_7
    //     0xb741b8: ldur            w1, [x0, #7]
    // 0xb741bc: DecompressPointer r1
    //     0xb741bc: add             x1, x1, HEAP, lsl #32
    // 0xb741c0: cmp             w1, NULL
    // 0xb741c4: b.eq            #0xb742d4
    // 0xb741c8: LoadField: r3 = r1->field_7
    //     0xb741c8: ldur            x3, [x1, #7]
    // 0xb741cc: ldr             x1, [x3]
    // 0xb741d0: cbz             x1, #0xb742b0
    // 0xb741d4: ldur            x4, [fp, #-8]
    // 0xb741d8: ldur            d0, [fp, #-0x50]
    // 0xb741dc: ldur            x3, [fp, #-0x18]
    // 0xb741e0: ldur            d1, [fp, #-0x58]
    // 0xb741e4: mov             x5, x1
    // 0xb741e8: stur            x5, [fp, #-0x30]
    // 0xb741ec: r1 = <Never>
    //     0xb741ec: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb741f0: r0 = Pointer()
    //     0xb741f0: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb741f4: mov             x2, x0
    // 0xb741f8: ldur            x0, [fp, #-0x30]
    // 0xb741fc: stur            x2, [fp, #-0x20]
    // 0xb74200: StoreField: r2->field_7 = r0
    //     0xb74200: stur            x0, [x2, #7]
    // 0xb74204: ldur            x0, [fp, #-0x18]
    // 0xb74208: LoadField: r1 = r0->field_7
    //     0xb74208: ldur            w1, [x0, #7]
    // 0xb7420c: DecompressPointer r1
    //     0xb7420c: add             x1, x1, HEAP, lsl #32
    // 0xb74210: cmp             w1, NULL
    // 0xb74214: b.eq            #0xb742d8
    // 0xb74218: LoadField: r3 = r1->field_7
    //     0xb74218: ldur            x3, [x1, #7]
    // 0xb7421c: ldr             x1, [x3]
    // 0xb74220: mov             x3, x1
    // 0xb74224: stur            x3, [fp, #-0x30]
    // 0xb74228: r1 = <Never>
    //     0xb74228: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb7422c: r0 = Pointer()
    //     0xb7422c: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb74230: mov             x1, x0
    // 0xb74234: ldur            x0, [fp, #-0x30]
    // 0xb74238: StoreField: r1->field_7 = r0
    //     0xb74238: stur            x0, [x1, #7]
    // 0xb7423c: mov             x2, x1
    // 0xb74240: ldur            x1, [fp, #-0x20]
    // 0xb74244: ldur            x3, [fp, #-0x38]
    // 0xb74248: d0 = 0.200000
    //     0xb74248: add             x17, PP, #0x13, lsl #12  ; [pp+0x13230] IMM: double(0.2) from 0x3fc999999999999a
    //     0xb7424c: ldr             d0, [x17, #0x230]
    // 0xb74250: r5 = false
    //     0xb74250: add             x5, NULL, #0x30  ; false
    // 0xb74254: r0 = __drawShadow$Method$FfiNative()
    //     0xb74254: bl              #0xb7447c  ; [dart:ui] _NativeCanvas::__drawShadow$Method$FfiNative
    // 0xb74258: r0 = Offset()
    //     0xb74258: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xb7425c: ldur            d0, [fp, #-0x50]
    // 0xb74260: StoreField: r0->field_7 = d0
    //     0xb74260: stur            d0, [x0, #7]
    // 0xb74264: ldur            d0, [fp, #-0x58]
    // 0xb74268: StoreField: r0->field_f = d0
    //     0xb74268: stur            d0, [x0, #0xf]
    // 0xb7426c: ldur            x1, [fp, #-8]
    // 0xb74270: LoadField: r2 = r1->field_f
    //     0xb74270: ldur            w2, [x1, #0xf]
    // 0xb74274: DecompressPointer r2
    //     0xb74274: add             x2, x2, HEAP, lsl #32
    // 0xb74278: LoadField: r3 = r2->field_f
    //     0xb74278: ldur            w3, [x2, #0xf]
    // 0xb7427c: DecompressPointer r3
    //     0xb7427c: add             x3, x3, HEAP, lsl #32
    // 0xb74280: ldur            x1, [fp, #-0x10]
    // 0xb74284: mov             x2, x0
    // 0xb74288: d0 = 6.000000
    //     0xb74288: fmov            d0, #6.00000000
    // 0xb7428c: r0 = drawCircle()
    //     0xb7428c: bl              #0xb6acd4  ; [dart:ui] _NativeCanvas::drawCircle
    // 0xb74290: r0 = Null
    //     0xb74290: mov             x0, NULL
    // 0xb74294: LeaveFrame
    //     0xb74294: mov             SP, fp
    //     0xb74298: ldp             fp, lr, [SP], #0x10
    // 0xb7429c: ret
    //     0xb7429c: ret             
    // 0xb742a0: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb742a0: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb742a4: str             x16, [SP]
    // 0xb742a8: r0 = _throwNew()
    //     0xb742a8: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb742ac: brk             #0
    // 0xb742b0: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb742b0: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb742b4: str             x16, [SP]
    // 0xb742b8: r0 = _throwNew()
    //     0xb742b8: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb742bc: brk             #0
    // 0xb742c0: r0 = StackOverflowSharedWithFPURegs()
    //     0xb742c0: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb742c4: b               #0xb73cc8
    // 0xb742c8: r0 = StackOverflowSharedWithFPURegs()
    //     0xb742c8: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb742cc: b               #0xb73e84
    // 0xb742d0: r0 = NullErrorSharedWithFPURegs()
    //     0xb742d0: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0xb742d4: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb742d4: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xb742d8: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb742d8: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  void dyn:set:value(_ProgressBarPainter, VideoPlayerValue) {
    // ** addr: 0xb74408, size: 0x8c
    // 0xb74408: EnterFrame
    //     0xb74408: stp             fp, lr, [SP, #-0x10]!
    //     0xb7440c: mov             fp, SP
    // 0xb74410: ldr             x0, [fp, #0x10]
    // 0xb74414: r2 = Null
    //     0xb74414: mov             x2, NULL
    // 0xb74418: r1 = Null
    //     0xb74418: mov             x1, NULL
    // 0xb7441c: r4 = 60
    //     0xb7441c: mov             x4, #0x3c
    // 0xb74420: branchIfSmi(r0, 0xb7442c)
    //     0xb74420: tbz             w0, #0, #0xb7442c
    // 0xb74424: r4 = LoadClassIdInstr(r0)
    //     0xb74424: ldur            x4, [x0, #-1]
    //     0xb74428: ubfx            x4, x4, #0xc, #0x14
    // 0xb7442c: cmp             x4, #0x16d
    // 0xb74430: b.eq            #0xb74448
    // 0xb74434: r8 = VideoPlayerValue
    //     0xb74434: add             x8, PP, #0xa0, lsl #12  ; [pp+0xa0670] Type: VideoPlayerValue
    //     0xb74438: ldr             x8, [x8, #0x670]
    // 0xb7443c: r3 = Null
    //     0xb7443c: add             x3, PP, #0xd4, lsl #12  ; [pp+0xd4f78] Null
    //     0xb74440: ldr             x3, [x3, #0xf78]
    // 0xb74444: r0 = VideoPlayerValue()
    //     0xb74444: bl              #0x8d5888  ; IsType_VideoPlayerValue_Stub
    // 0xb74448: ldr             x0, [fp, #0x10]
    // 0xb7444c: ldr             x1, [fp, #0x18]
    // 0xb74450: StoreField: r1->field_b = r0
    //     0xb74450: stur            w0, [x1, #0xb]
    //     0xb74454: ldurb           w16, [x1, #-1]
    //     0xb74458: ldurb           w17, [x0, #-1]
    //     0xb7445c: and             x16, x17, x16, lsr #2
    //     0xb74460: tst             x16, HEAP, lsr #32
    //     0xb74464: b.eq            #0xb7446c
    //     0xb74468: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb7446c: r0 = Null
    //     0xb7446c: mov             x0, NULL
    // 0xb74470: LeaveFrame
    //     0xb74470: mov             SP, fp
    //     0xb74474: ldp             fp, lr, [SP], #0x10
    // 0xb74478: ret
    //     0xb74478: ret             
  }
}

// class id: 5497, size: 0x1c, field offset: 0x14
class _VideoProgressBarState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0xde26b4, size: 0x174
    // 0xde26b4: EnterFrame
    //     0xde26b4: stp             fp, lr, [SP, #-0x10]!
    //     0xde26b8: mov             fp, SP
    // 0xde26bc: AllocStack(0x58)
    //     0xde26bc: sub             SP, SP, #0x58
    // 0xde26c0: SetupParameters(_VideoProgressBarState this /* r1 => r1, fp-0x8 */)
    //     0xde26c0: stur            x1, [fp, #-8]
    // 0xde26c4: CheckStackOverflow
    //     0xde26c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde26c8: cmp             SP, x16
    //     0xde26cc: b.ls            #0xde281c
    // 0xde26d0: r1 = 1
    //     0xde26d0: mov             x1, #1
    // 0xde26d4: r0 = AllocateContext()
    //     0xde26d4: bl              #0x13de838  ; AllocateContextStub
    // 0xde26d8: mov             x2, x0
    // 0xde26dc: ldur            x0, [fp, #-8]
    // 0xde26e0: stur            x2, [fp, #-0x10]
    // 0xde26e4: StoreField: r2->field_f = r0
    //     0xde26e4: stur            w0, [x2, #0xf]
    // 0xde26e8: mov             x1, x0
    // 0xde26ec: r0 = value()
    //     0xde26ec: bl              #0x11a0f58  ; [package:flutter/src/cupertino/checkbox.dart] _CupertinoCheckboxState::value
    // 0xde26f0: LoadField: r1 = r0->field_27
    //     0xde26f0: ldur            w1, [x0, #0x27]
    // 0xde26f4: DecompressPointer r1
    //     0xde26f4: add             x1, x1, HEAP, lsl #32
    // 0xde26f8: ldur            x0, [fp, #-8]
    // 0xde26fc: stur            x1, [fp, #-0x28]
    // 0xde2700: LoadField: r2 = r0->field_b
    //     0xde2700: ldur            w2, [x0, #0xb]
    // 0xde2704: DecompressPointer r2
    //     0xde2704: add             x2, x2, HEAP, lsl #32
    // 0xde2708: cmp             w2, NULL
    // 0xde270c: b.eq            #0xde2824
    // 0xde2710: LoadField: r3 = r2->field_f
    //     0xde2710: ldur            w3, [x2, #0xf]
    // 0xde2714: DecompressPointer r3
    //     0xde2714: add             x3, x3, HEAP, lsl #32
    // 0xde2718: stur            x3, [fp, #-0x20]
    // 0xde271c: LoadField: d0 = r2->field_1f
    //     0xde271c: ldur            d0, [x2, #0x1f]
    // 0xde2720: stur            d0, [fp, #-0x30]
    // 0xde2724: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xde2724: ldur            w2, [x0, #0x17]
    // 0xde2728: DecompressPointer r2
    //     0xde2728: add             x2, x2, HEAP, lsl #32
    // 0xde272c: stur            x2, [fp, #-0x18]
    // 0xde2730: r0 = StaticProgressBar()
    //     0xde2730: bl              #0xde284c  ; AllocateStaticProgressBarStub -> StaticProgressBar (size=0x2c)
    // 0xde2734: mov             x1, x0
    // 0xde2738: ldur            x0, [fp, #-0x28]
    // 0xde273c: stur            x1, [fp, #-8]
    // 0xde2740: StoreField: r1->field_f = r0
    //     0xde2740: stur            w0, [x1, #0xf]
    // 0xde2744: ldur            x0, [fp, #-0x20]
    // 0xde2748: StoreField: r1->field_13 = r0
    //     0xde2748: stur            w0, [x1, #0x13]
    // 0xde274c: ldur            d0, [fp, #-0x30]
    // 0xde2750: ArrayStore: r1[0] = d0  ; List_8
    //     0xde2750: stur            d0, [x1, #0x17]
    // 0xde2754: d0 = 6.000000
    //     0xde2754: fmov            d0, #6.00000000
    // 0xde2758: StoreField: r1->field_1f = d0
    //     0xde2758: stur            d0, [x1, #0x1f]
    // 0xde275c: r0 = true
    //     0xde275c: add             x0, NULL, #0x20  ; true
    // 0xde2760: StoreField: r1->field_27 = r0
    //     0xde2760: stur            w0, [x1, #0x27]
    // 0xde2764: ldur            x0, [fp, #-0x18]
    // 0xde2768: StoreField: r1->field_b = r0
    //     0xde2768: stur            w0, [x1, #0xb]
    // 0xde276c: r0 = Center()
    //     0xde276c: bl              #0xd0c898  ; AllocateCenterStub -> Center (size=0x1c)
    // 0xde2770: mov             x1, x0
    // 0xde2774: r0 = Instance_Alignment
    //     0xde2774: add             x0, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xde2778: ldr             x0, [x0, #0xb80]
    // 0xde277c: stur            x1, [fp, #-0x18]
    // 0xde2780: StoreField: r1->field_f = r0
    //     0xde2780: stur            w0, [x1, #0xf]
    // 0xde2784: ldur            x0, [fp, #-8]
    // 0xde2788: StoreField: r1->field_b = r0
    //     0xde2788: stur            w0, [x1, #0xb]
    // 0xde278c: r0 = GestureDetector()
    //     0xde278c: bl              #0x918e18  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0xde2790: ldur            x2, [fp, #-0x10]
    // 0xde2794: r1 = Function '<anonymous closure>':.
    //     0xde2794: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4d30] AnonymousClosure: (0xde2d18), in [package:chewie/src/progress_bar.dart] _VideoProgressBarState::build (0xde26b4)
    //     0xde2798: ldr             x1, [x1, #0xd30]
    // 0xde279c: stur            x0, [fp, #-8]
    // 0xde27a0: r0 = AllocateClosure()
    //     0xde27a0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xde27a4: ldur            x2, [fp, #-0x10]
    // 0xde27a8: r1 = Function '<anonymous closure>':.
    //     0xde27a8: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4d38] AnonymousClosure: (0xde2b6c), in [package:chewie/src/progress_bar.dart] _VideoProgressBarState::build (0xde26b4)
    //     0xde27ac: ldr             x1, [x1, #0xd38]
    // 0xde27b0: stur            x0, [fp, #-0x20]
    // 0xde27b4: r0 = AllocateClosure()
    //     0xde27b4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xde27b8: ldur            x2, [fp, #-0x10]
    // 0xde27bc: r1 = Function '<anonymous closure>':.
    //     0xde27bc: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4d40] AnonymousClosure: (0xde2a80), in [package:chewie/src/progress_bar.dart] _VideoProgressBarState::build (0xde26b4)
    //     0xde27c0: ldr             x1, [x1, #0xd40]
    // 0xde27c4: stur            x0, [fp, #-0x28]
    // 0xde27c8: r0 = AllocateClosure()
    //     0xde27c8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xde27cc: ldur            x2, [fp, #-0x10]
    // 0xde27d0: r1 = Function '<anonymous closure>':.
    //     0xde27d0: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4d48] AnonymousClosure: (0xde2858), in [package:chewie/src/progress_bar.dart] _VideoProgressBarState::build (0xde26b4)
    //     0xde27d4: ldr             x1, [x1, #0xd48]
    // 0xde27d8: stur            x0, [fp, #-0x10]
    // 0xde27dc: r0 = AllocateClosure()
    //     0xde27dc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xde27e0: ldur            x16, [fp, #-0x20]
    // 0xde27e4: ldur            lr, [fp, #-0x28]
    // 0xde27e8: stp             lr, x16, [SP, #0x18]
    // 0xde27ec: ldur            x16, [fp, #-0x10]
    // 0xde27f0: stp             x0, x16, [SP, #8]
    // 0xde27f4: ldur            x16, [fp, #-0x18]
    // 0xde27f8: str             x16, [SP]
    // 0xde27fc: ldur            x1, [fp, #-8]
    // 0xde2800: r4 = const [0, 0x6, 0x5, 0x1, child, 0x5, onHorizontalDragEnd, 0x3, onHorizontalDragStart, 0x1, onHorizontalDragUpdate, 0x2, onTapDown, 0x4, null]
    //     0xde2800: add             x4, PP, #0xd4, lsl #12  ; [pp+0xd4d50] List(15) [0, 0x6, 0x5, 0x1, "child", 0x5, "onHorizontalDragEnd", 0x3, "onHorizontalDragStart", 0x1, "onHorizontalDragUpdate", 0x2, "onTapDown", 0x4, Null]
    //     0xde2804: ldr             x4, [x4, #0xd50]
    // 0xde2808: r0 = GestureDetector()
    //     0xde2808: bl              #0x9182dc  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0xde280c: ldur            x0, [fp, #-8]
    // 0xde2810: LeaveFrame
    //     0xde2810: mov             SP, fp
    //     0xde2814: ldp             fp, lr, [SP], #0x10
    // 0xde2818: ret
    //     0xde2818: ret             
    // 0xde281c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde281c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde2820: b               #0xde26d0
    // 0xde2824: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde2824: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, TapDownDetails) {
    // ** addr: 0xde2858, size: 0x94
    // 0xde2858: EnterFrame
    //     0xde2858: stp             fp, lr, [SP, #-0x10]!
    //     0xde285c: mov             fp, SP
    // 0xde2860: ldr             x0, [fp, #0x18]
    // 0xde2864: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xde2864: ldur            w1, [x0, #0x17]
    // 0xde2868: DecompressPointer r1
    //     0xde2868: add             x1, x1, HEAP, lsl #32
    // 0xde286c: CheckStackOverflow
    //     0xde286c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde2870: cmp             SP, x16
    //     0xde2874: b.ls            #0xde28e0
    // 0xde2878: LoadField: r0 = r1->field_f
    //     0xde2878: ldur            w0, [x1, #0xf]
    // 0xde287c: DecompressPointer r0
    //     0xde287c: add             x0, x0, HEAP, lsl #32
    // 0xde2880: LoadField: r1 = r0->field_b
    //     0xde2880: ldur            w1, [x0, #0xb]
    // 0xde2884: DecompressPointer r1
    //     0xde2884: add             x1, x1, HEAP, lsl #32
    // 0xde2888: cmp             w1, NULL
    // 0xde288c: b.eq            #0xde28e8
    // 0xde2890: LoadField: r2 = r1->field_b
    //     0xde2890: ldur            w2, [x1, #0xb]
    // 0xde2894: DecompressPointer r2
    //     0xde2894: add             x2, x2, HEAP, lsl #32
    // 0xde2898: LoadField: r1 = r2->field_27
    //     0xde2898: ldur            w1, [x2, #0x27]
    // 0xde289c: DecompressPointer r1
    //     0xde289c: add             x1, x1, HEAP, lsl #32
    // 0xde28a0: LoadField: r2 = r1->field_4f
    //     0xde28a0: ldur            w2, [x1, #0x4f]
    // 0xde28a4: DecompressPointer r2
    //     0xde28a4: add             x2, x2, HEAP, lsl #32
    // 0xde28a8: tbz             w2, #4, #0xde28bc
    // 0xde28ac: r0 = Null
    //     0xde28ac: mov             x0, NULL
    // 0xde28b0: LeaveFrame
    //     0xde28b0: mov             SP, fp
    //     0xde28b4: ldp             fp, lr, [SP], #0x10
    // 0xde28b8: ret
    //     0xde28b8: ret             
    // 0xde28bc: ldr             x1, [fp, #0x10]
    // 0xde28c0: LoadField: r2 = r1->field_7
    //     0xde28c0: ldur            w2, [x1, #7]
    // 0xde28c4: DecompressPointer r2
    //     0xde28c4: add             x2, x2, HEAP, lsl #32
    // 0xde28c8: mov             x1, x0
    // 0xde28cc: r0 = _seekToRelativePosition()
    //     0xde28cc: bl              #0xde28ec  ; [package:chewie/src/progress_bar.dart] _VideoProgressBarState::_seekToRelativePosition
    // 0xde28d0: r0 = Null
    //     0xde28d0: mov             x0, NULL
    // 0xde28d4: LeaveFrame
    //     0xde28d4: mov             SP, fp
    //     0xde28d8: ldp             fp, lr, [SP], #0x10
    // 0xde28dc: ret
    //     0xde28dc: ret             
    // 0xde28e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde28e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde28e4: b               #0xde2878
    // 0xde28e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde28e8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _seekToRelativePosition(/* No info */) {
    // ** addr: 0xde28ec, size: 0x8c
    // 0xde28ec: EnterFrame
    //     0xde28ec: stp             fp, lr, [SP, #-0x10]!
    //     0xde28f0: mov             fp, SP
    // 0xde28f4: AllocStack(0x8)
    //     0xde28f4: sub             SP, SP, #8
    // 0xde28f8: SetupParameters(dynamic _ /* r2 => r3 */)
    //     0xde28f8: mov             x3, x2
    // 0xde28fc: CheckStackOverflow
    //     0xde28fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde2900: cmp             SP, x16
    //     0xde2904: b.ls            #0xde2968
    // 0xde2908: LoadField: r0 = r1->field_b
    //     0xde2908: ldur            w0, [x1, #0xb]
    // 0xde290c: DecompressPointer r0
    //     0xde290c: add             x0, x0, HEAP, lsl #32
    // 0xde2910: cmp             w0, NULL
    // 0xde2914: b.eq            #0xde2970
    // 0xde2918: LoadField: r4 = r0->field_b
    //     0xde2918: ldur            w4, [x0, #0xb]
    // 0xde291c: DecompressPointer r4
    //     0xde291c: add             x4, x4, HEAP, lsl #32
    // 0xde2920: stur            x4, [fp, #-8]
    // 0xde2924: LoadField: r0 = r1->field_f
    //     0xde2924: ldur            w0, [x1, #0xf]
    // 0xde2928: DecompressPointer r0
    //     0xde2928: add             x0, x0, HEAP, lsl #32
    // 0xde292c: cmp             w0, NULL
    // 0xde2930: b.eq            #0xde2974
    // 0xde2934: LoadField: r1 = r4->field_27
    //     0xde2934: ldur            w1, [x4, #0x27]
    // 0xde2938: DecompressPointer r1
    //     0xde2938: add             x1, x1, HEAP, lsl #32
    // 0xde293c: LoadField: r2 = r1->field_7
    //     0xde293c: ldur            w2, [x1, #7]
    // 0xde2940: DecompressPointer r2
    //     0xde2940: add             x2, x2, HEAP, lsl #32
    // 0xde2944: mov             x1, x0
    // 0xde2948: r0 = RelativePositionExtensions.calcRelativePosition()
    //     0xde2948: bl              #0xde2978  ; [package:chewie/src/progress_bar.dart] ::RelativePositionExtensions.calcRelativePosition
    // 0xde294c: ldur            x1, [fp, #-8]
    // 0xde2950: mov             x2, x0
    // 0xde2954: r0 = seekTo()
    //     0xde2954: bl              #0x8d6e4c  ; [package:video_player/video_player.dart] VideoPlayerController::seekTo
    // 0xde2958: r0 = Null
    //     0xde2958: mov             x0, NULL
    // 0xde295c: LeaveFrame
    //     0xde295c: mov             SP, fp
    //     0xde2960: ldp             fp, lr, [SP], #0x10
    // 0xde2964: ret
    //     0xde2964: ret             
    // 0xde2968: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde2968: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde296c: b               #0xde2908
    // 0xde2970: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde2970: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde2974: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde2974: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, DragEndDetails) {
    // ** addr: 0xde2a80, size: 0xec
    // 0xde2a80: EnterFrame
    //     0xde2a80: stp             fp, lr, [SP, #-0x10]!
    //     0xde2a84: mov             fp, SP
    // 0xde2a88: AllocStack(0x10)
    //     0xde2a88: sub             SP, SP, #0x10
    // 0xde2a8c: SetupParameters([dynamic _ /* r0 */])
    //     0xde2a8c: ldr             x0, [fp, #0x18]
    //     0xde2a90: ldur            w2, [x0, #0x17]
    //     0xde2a94: add             x2, x2, HEAP, lsl #32
    //     0xde2a98: stur            x2, [fp, #-8]
    // 0xde2a9c: CheckStackOverflow
    //     0xde2a9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde2aa0: cmp             SP, x16
    //     0xde2aa4: b.ls            #0xde2b58
    // 0xde2aa8: LoadField: r0 = r2->field_f
    //     0xde2aa8: ldur            w0, [x2, #0xf]
    // 0xde2aac: DecompressPointer r0
    //     0xde2aac: add             x0, x0, HEAP, lsl #32
    // 0xde2ab0: LoadField: r1 = r0->field_13
    //     0xde2ab0: ldur            w1, [x0, #0x13]
    // 0xde2ab4: DecompressPointer r1
    //     0xde2ab4: add             x1, x1, HEAP, lsl #32
    // 0xde2ab8: tbnz            w1, #4, #0xde2adc
    // 0xde2abc: LoadField: r1 = r0->field_b
    //     0xde2abc: ldur            w1, [x0, #0xb]
    // 0xde2ac0: DecompressPointer r1
    //     0xde2ac0: add             x1, x1, HEAP, lsl #32
    // 0xde2ac4: cmp             w1, NULL
    // 0xde2ac8: b.eq            #0xde2b60
    // 0xde2acc: LoadField: r0 = r1->field_b
    //     0xde2acc: ldur            w0, [x1, #0xb]
    // 0xde2ad0: DecompressPointer r0
    //     0xde2ad0: add             x0, x0, HEAP, lsl #32
    // 0xde2ad4: mov             x1, x0
    // 0xde2ad8: r0 = play()
    //     0xde2ad8: bl              #0x8d57ac  ; [package:video_player/video_player.dart] VideoPlayerController::play
    // 0xde2adc: ldur            x0, [fp, #-8]
    // 0xde2ae0: LoadField: r1 = r0->field_f
    //     0xde2ae0: ldur            w1, [x0, #0xf]
    // 0xde2ae4: DecompressPointer r1
    //     0xde2ae4: add             x1, x1, HEAP, lsl #32
    // 0xde2ae8: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xde2ae8: ldur            w2, [x1, #0x17]
    // 0xde2aec: DecompressPointer r2
    //     0xde2aec: add             x2, x2, HEAP, lsl #32
    // 0xde2af0: cmp             w2, NULL
    // 0xde2af4: b.eq            #0xde2b14
    // 0xde2af8: r0 = _seekToRelativePosition()
    //     0xde2af8: bl              #0xde28ec  ; [package:chewie/src/progress_bar.dart] _VideoProgressBarState::_seekToRelativePosition
    // 0xde2afc: ldur            x0, [fp, #-8]
    // 0xde2b00: LoadField: r1 = r0->field_f
    //     0xde2b00: ldur            w1, [x0, #0xf]
    // 0xde2b04: DecompressPointer r1
    //     0xde2b04: add             x1, x1, HEAP, lsl #32
    // 0xde2b08: ArrayStore: r1[0] = rNULL  ; List_4
    //     0xde2b08: stur            NULL, [x1, #0x17]
    // 0xde2b0c: mov             x0, x1
    // 0xde2b10: b               #0xde2b18
    // 0xde2b14: mov             x0, x1
    // 0xde2b18: LoadField: r1 = r0->field_b
    //     0xde2b18: ldur            w1, [x0, #0xb]
    // 0xde2b1c: DecompressPointer r1
    //     0xde2b1c: add             x1, x1, HEAP, lsl #32
    // 0xde2b20: cmp             w1, NULL
    // 0xde2b24: b.eq            #0xde2b64
    // 0xde2b28: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xde2b28: ldur            w0, [x1, #0x17]
    // 0xde2b2c: DecompressPointer r0
    //     0xde2b2c: add             x0, x0, HEAP, lsl #32
    // 0xde2b30: cmp             w0, NULL
    // 0xde2b34: b.eq            #0xde2b68
    // 0xde2b38: str             x0, [SP]
    // 0xde2b3c: ClosureCall
    //     0xde2b3c: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xde2b40: ldur            x2, [x0, #0x1f]
    //     0xde2b44: blr             x2
    // 0xde2b48: r0 = Null
    //     0xde2b48: mov             x0, NULL
    // 0xde2b4c: LeaveFrame
    //     0xde2b4c: mov             SP, fp
    //     0xde2b50: ldp             fp, lr, [SP], #0x10
    // 0xde2b54: ret
    //     0xde2b54: ret             
    // 0xde2b58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde2b58: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde2b5c: b               #0xde2aa8
    // 0xde2b60: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde2b60: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde2b64: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde2b64: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde2b68: r0 = NullErrorSharedWithoutFPURegs()
    //     0xde2b68: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, DragUpdateDetails) {
    // ** addr: 0xde2b6c, size: 0x100
    // 0xde2b6c: EnterFrame
    //     0xde2b6c: stp             fp, lr, [SP, #-0x10]!
    //     0xde2b70: mov             fp, SP
    // 0xde2b74: AllocStack(0x10)
    //     0xde2b74: sub             SP, SP, #0x10
    // 0xde2b78: SetupParameters([dynamic _ /* r0 */])
    //     0xde2b78: ldr             x0, [fp, #0x18]
    //     0xde2b7c: ldur            w2, [x0, #0x17]
    //     0xde2b80: add             x2, x2, HEAP, lsl #32
    //     0xde2b84: stur            x2, [fp, #-8]
    // 0xde2b88: CheckStackOverflow
    //     0xde2b88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde2b8c: cmp             SP, x16
    //     0xde2b90: b.ls            #0xde2c58
    // 0xde2b94: LoadField: r1 = r2->field_f
    //     0xde2b94: ldur            w1, [x2, #0xf]
    // 0xde2b98: DecompressPointer r1
    //     0xde2b98: add             x1, x1, HEAP, lsl #32
    // 0xde2b9c: LoadField: r0 = r1->field_b
    //     0xde2b9c: ldur            w0, [x1, #0xb]
    // 0xde2ba0: DecompressPointer r0
    //     0xde2ba0: add             x0, x0, HEAP, lsl #32
    // 0xde2ba4: cmp             w0, NULL
    // 0xde2ba8: b.eq            #0xde2c60
    // 0xde2bac: LoadField: r3 = r0->field_b
    //     0xde2bac: ldur            w3, [x0, #0xb]
    // 0xde2bb0: DecompressPointer r3
    //     0xde2bb0: add             x3, x3, HEAP, lsl #32
    // 0xde2bb4: LoadField: r0 = r3->field_27
    //     0xde2bb4: ldur            w0, [x3, #0x27]
    // 0xde2bb8: DecompressPointer r0
    //     0xde2bb8: add             x0, x0, HEAP, lsl #32
    // 0xde2bbc: LoadField: r3 = r0->field_4f
    //     0xde2bbc: ldur            w3, [x0, #0x4f]
    // 0xde2bc0: DecompressPointer r3
    //     0xde2bc0: add             x3, x3, HEAP, lsl #32
    // 0xde2bc4: tbz             w3, #4, #0xde2bd8
    // 0xde2bc8: r0 = Null
    //     0xde2bc8: mov             x0, NULL
    // 0xde2bcc: LeaveFrame
    //     0xde2bcc: mov             SP, fp
    //     0xde2bd0: ldp             fp, lr, [SP], #0x10
    // 0xde2bd4: ret
    //     0xde2bd4: ret             
    // 0xde2bd8: ldr             x0, [fp, #0x10]
    // 0xde2bdc: LoadField: r3 = r0->field_7
    //     0xde2bdc: ldur            w3, [x0, #7]
    // 0xde2be0: DecompressPointer r3
    //     0xde2be0: add             x3, x3, HEAP, lsl #32
    // 0xde2be4: mov             x0, x3
    // 0xde2be8: ArrayStore: r1[0] = r0  ; List_4
    //     0xde2be8: stur            w0, [x1, #0x17]
    //     0xde2bec: ldurb           w16, [x1, #-1]
    //     0xde2bf0: ldurb           w17, [x0, #-1]
    //     0xde2bf4: and             x16, x17, x16, lsr #2
    //     0xde2bf8: tst             x16, HEAP, lsr #32
    //     0xde2bfc: b.eq            #0xde2c04
    //     0xde2c00: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xde2c04: r0 = listener()
    //     0xde2c04: bl              #0xde2c6c  ; [package:chewie/src/progress_bar.dart] _VideoProgressBarState::listener
    // 0xde2c08: ldur            x0, [fp, #-8]
    // 0xde2c0c: LoadField: r1 = r0->field_f
    //     0xde2c0c: ldur            w1, [x0, #0xf]
    // 0xde2c10: DecompressPointer r1
    //     0xde2c10: add             x1, x1, HEAP, lsl #32
    // 0xde2c14: LoadField: r0 = r1->field_b
    //     0xde2c14: ldur            w0, [x1, #0xb]
    // 0xde2c18: DecompressPointer r0
    //     0xde2c18: add             x0, x0, HEAP, lsl #32
    // 0xde2c1c: cmp             w0, NULL
    // 0xde2c20: b.eq            #0xde2c64
    // 0xde2c24: LoadField: r1 = r0->field_1b
    //     0xde2c24: ldur            w1, [x0, #0x1b]
    // 0xde2c28: DecompressPointer r1
    //     0xde2c28: add             x1, x1, HEAP, lsl #32
    // 0xde2c2c: cmp             w1, NULL
    // 0xde2c30: b.eq            #0xde2c68
    // 0xde2c34: str             x1, [SP]
    // 0xde2c38: mov             x0, x1
    // 0xde2c3c: ClosureCall
    //     0xde2c3c: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xde2c40: ldur            x2, [x0, #0x1f]
    //     0xde2c44: blr             x2
    // 0xde2c48: r0 = Null
    //     0xde2c48: mov             x0, NULL
    // 0xde2c4c: LeaveFrame
    //     0xde2c4c: mov             SP, fp
    //     0xde2c50: ldp             fp, lr, [SP], #0x10
    // 0xde2c54: ret
    //     0xde2c54: ret             
    // 0xde2c58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde2c58: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde2c5c: b               #0xde2b94
    // 0xde2c60: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde2c60: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde2c64: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde2c64: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde2c68: r0 = NullErrorSharedWithoutFPURegs()
    //     0xde2c68: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ listener(/* No info */) {
    // ** addr: 0xde2c6c, size: 0x74
    // 0xde2c6c: EnterFrame
    //     0xde2c6c: stp             fp, lr, [SP, #-0x10]!
    //     0xde2c70: mov             fp, SP
    // 0xde2c74: AllocStack(0x8)
    //     0xde2c74: sub             SP, SP, #8
    // 0xde2c78: SetupParameters(_VideoProgressBarState this /* r1 => r0, fp-0x8 */)
    //     0xde2c78: mov             x0, x1
    //     0xde2c7c: stur            x1, [fp, #-8]
    // 0xde2c80: CheckStackOverflow
    //     0xde2c80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde2c84: cmp             SP, x16
    //     0xde2c88: b.ls            #0xde2cd8
    // 0xde2c8c: LoadField: r1 = r0->field_f
    //     0xde2c8c: ldur            w1, [x0, #0xf]
    // 0xde2c90: DecompressPointer r1
    //     0xde2c90: add             x1, x1, HEAP, lsl #32
    // 0xde2c94: cmp             w1, NULL
    // 0xde2c98: b.ne            #0xde2cac
    // 0xde2c9c: r0 = Null
    //     0xde2c9c: mov             x0, NULL
    // 0xde2ca0: LeaveFrame
    //     0xde2ca0: mov             SP, fp
    //     0xde2ca4: ldp             fp, lr, [SP], #0x10
    // 0xde2ca8: ret
    //     0xde2ca8: ret             
    // 0xde2cac: r1 = Function '<anonymous closure>':.
    //     0xde2cac: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4d68] Function: [dart:ui] Shader::Shader._ (0x13cf838)
    //     0xde2cb0: ldr             x1, [x1, #0xd68]
    // 0xde2cb4: r2 = Null
    //     0xde2cb4: mov             x2, NULL
    // 0xde2cb8: r0 = AllocateClosure()
    //     0xde2cb8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xde2cbc: ldur            x1, [fp, #-8]
    // 0xde2cc0: mov             x2, x0
    // 0xde2cc4: r0 = setState()
    //     0xde2cc4: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xde2cc8: r0 = Null
    //     0xde2cc8: mov             x0, NULL
    // 0xde2ccc: LeaveFrame
    //     0xde2ccc: mov             SP, fp
    //     0xde2cd0: ldp             fp, lr, [SP], #0x10
    // 0xde2cd4: ret
    //     0xde2cd4: ret             
    // 0xde2cd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde2cd8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde2cdc: b               #0xde2c8c
  }
  [closure] void listener(dynamic) {
    // ** addr: 0xde2ce0, size: 0x38
    // 0xde2ce0: EnterFrame
    //     0xde2ce0: stp             fp, lr, [SP, #-0x10]!
    //     0xde2ce4: mov             fp, SP
    // 0xde2ce8: ldr             x0, [fp, #0x10]
    // 0xde2cec: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xde2cec: ldur            w1, [x0, #0x17]
    // 0xde2cf0: DecompressPointer r1
    //     0xde2cf0: add             x1, x1, HEAP, lsl #32
    // 0xde2cf4: CheckStackOverflow
    //     0xde2cf4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde2cf8: cmp             SP, x16
    //     0xde2cfc: b.ls            #0xde2d10
    // 0xde2d00: r0 = listener()
    //     0xde2d00: bl              #0xde2c6c  ; [package:chewie/src/progress_bar.dart] _VideoProgressBarState::listener
    // 0xde2d04: LeaveFrame
    //     0xde2d04: mov             SP, fp
    //     0xde2d08: ldp             fp, lr, [SP], #0x10
    // 0xde2d0c: ret
    //     0xde2d0c: ret             
    // 0xde2d10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde2d10: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde2d14: b               #0xde2d00
  }
  [closure] void <anonymous closure>(dynamic, DragStartDetails) {
    // ** addr: 0xde2d18, size: 0xe8
    // 0xde2d18: EnterFrame
    //     0xde2d18: stp             fp, lr, [SP, #-0x10]!
    //     0xde2d1c: mov             fp, SP
    // 0xde2d20: AllocStack(0x10)
    //     0xde2d20: sub             SP, SP, #0x10
    // 0xde2d24: SetupParameters([dynamic _ /* r0 */])
    //     0xde2d24: ldr             x0, [fp, #0x18]
    //     0xde2d28: ldur            w2, [x0, #0x17]
    //     0xde2d2c: add             x2, x2, HEAP, lsl #32
    //     0xde2d30: stur            x2, [fp, #-8]
    // 0xde2d34: CheckStackOverflow
    //     0xde2d34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde2d38: cmp             SP, x16
    //     0xde2d3c: b.ls            #0xde2dec
    // 0xde2d40: LoadField: r0 = r2->field_f
    //     0xde2d40: ldur            w0, [x2, #0xf]
    // 0xde2d44: DecompressPointer r0
    //     0xde2d44: add             x0, x0, HEAP, lsl #32
    // 0xde2d48: LoadField: r1 = r0->field_b
    //     0xde2d48: ldur            w1, [x0, #0xb]
    // 0xde2d4c: DecompressPointer r1
    //     0xde2d4c: add             x1, x1, HEAP, lsl #32
    // 0xde2d50: cmp             w1, NULL
    // 0xde2d54: b.eq            #0xde2df4
    // 0xde2d58: LoadField: r3 = r1->field_b
    //     0xde2d58: ldur            w3, [x1, #0xb]
    // 0xde2d5c: DecompressPointer r3
    //     0xde2d5c: add             x3, x3, HEAP, lsl #32
    // 0xde2d60: LoadField: r1 = r3->field_27
    //     0xde2d60: ldur            w1, [x3, #0x27]
    // 0xde2d64: DecompressPointer r1
    //     0xde2d64: add             x1, x1, HEAP, lsl #32
    // 0xde2d68: LoadField: r4 = r1->field_4f
    //     0xde2d68: ldur            w4, [x1, #0x4f]
    // 0xde2d6c: DecompressPointer r4
    //     0xde2d6c: add             x4, x4, HEAP, lsl #32
    // 0xde2d70: tbz             w4, #4, #0xde2d84
    // 0xde2d74: r0 = Null
    //     0xde2d74: mov             x0, NULL
    // 0xde2d78: LeaveFrame
    //     0xde2d78: mov             SP, fp
    //     0xde2d7c: ldp             fp, lr, [SP], #0x10
    // 0xde2d80: ret
    //     0xde2d80: ret             
    // 0xde2d84: LoadField: r4 = r1->field_1b
    //     0xde2d84: ldur            w4, [x1, #0x1b]
    // 0xde2d88: DecompressPointer r4
    //     0xde2d88: add             x4, x4, HEAP, lsl #32
    // 0xde2d8c: StoreField: r0->field_13 = r4
    //     0xde2d8c: stur            w4, [x0, #0x13]
    // 0xde2d90: tbnz            w4, #4, #0xde2d9c
    // 0xde2d94: mov             x1, x3
    // 0xde2d98: r0 = pause()
    //     0xde2d98: bl              #0x8d70ec  ; [package:video_player/video_player.dart] VideoPlayerController::pause
    // 0xde2d9c: ldur            x0, [fp, #-8]
    // 0xde2da0: LoadField: r1 = r0->field_f
    //     0xde2da0: ldur            w1, [x0, #0xf]
    // 0xde2da4: DecompressPointer r1
    //     0xde2da4: add             x1, x1, HEAP, lsl #32
    // 0xde2da8: LoadField: r0 = r1->field_b
    //     0xde2da8: ldur            w0, [x1, #0xb]
    // 0xde2dac: DecompressPointer r0
    //     0xde2dac: add             x0, x0, HEAP, lsl #32
    // 0xde2db0: cmp             w0, NULL
    // 0xde2db4: b.eq            #0xde2df8
    // 0xde2db8: LoadField: r1 = r0->field_13
    //     0xde2db8: ldur            w1, [x0, #0x13]
    // 0xde2dbc: DecompressPointer r1
    //     0xde2dbc: add             x1, x1, HEAP, lsl #32
    // 0xde2dc0: cmp             w1, NULL
    // 0xde2dc4: b.eq            #0xde2dfc
    // 0xde2dc8: str             x1, [SP]
    // 0xde2dcc: mov             x0, x1
    // 0xde2dd0: ClosureCall
    //     0xde2dd0: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xde2dd4: ldur            x2, [x0, #0x1f]
    //     0xde2dd8: blr             x2
    // 0xde2ddc: r0 = Null
    //     0xde2ddc: mov             x0, NULL
    // 0xde2de0: LeaveFrame
    //     0xde2de0: mov             SP, fp
    //     0xde2de4: ldp             fp, lr, [SP], #0x10
    // 0xde2de8: ret
    //     0xde2de8: ret             
    // 0xde2dec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde2dec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde2df0: b               #0xde2d40
    // 0xde2df4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde2df4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde2df8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde2df8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde2dfc: r0 = NullErrorSharedWithoutFPURegs()
    //     0xde2dfc: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ deactivate(/* No info */) {
    // ** addr: 0xf78a54, size: 0x6c
    // 0xf78a54: EnterFrame
    //     0xf78a54: stp             fp, lr, [SP, #-0x10]!
    //     0xf78a58: mov             fp, SP
    // 0xf78a5c: AllocStack(0x8)
    //     0xf78a5c: sub             SP, SP, #8
    // 0xf78a60: SetupParameters(_VideoProgressBarState this /* r1 => r2 */)
    //     0xf78a60: mov             x2, x1
    // 0xf78a64: CheckStackOverflow
    //     0xf78a64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf78a68: cmp             SP, x16
    //     0xf78a6c: b.ls            #0xf78ab4
    // 0xf78a70: LoadField: r0 = r2->field_b
    //     0xf78a70: ldur            w0, [x2, #0xb]
    // 0xf78a74: DecompressPointer r0
    //     0xf78a74: add             x0, x0, HEAP, lsl #32
    // 0xf78a78: cmp             w0, NULL
    // 0xf78a7c: b.eq            #0xf78abc
    // 0xf78a80: LoadField: r3 = r0->field_b
    //     0xf78a80: ldur            w3, [x0, #0xb]
    // 0xf78a84: DecompressPointer r3
    //     0xf78a84: add             x3, x3, HEAP, lsl #32
    // 0xf78a88: stur            x3, [fp, #-8]
    // 0xf78a8c: r1 = Function 'listener':.
    //     0xf78a8c: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4d70] AnonymousClosure: (0xde2ce0), in [package:chewie/src/progress_bar.dart] _VideoProgressBarState::listener (0xde2c6c)
    //     0xf78a90: ldr             x1, [x1, #0xd70]
    // 0xf78a94: r0 = AllocateClosure()
    //     0xf78a94: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf78a98: ldur            x1, [fp, #-8]
    // 0xf78a9c: mov             x2, x0
    // 0xf78aa0: r0 = removeListener()
    //     0xf78aa0: bl              #0xcff784  ; [package:video_player/video_player.dart] VideoPlayerController::removeListener
    // 0xf78aa4: r0 = Null
    //     0xf78aa4: mov             x0, NULL
    // 0xf78aa8: LeaveFrame
    //     0xf78aa8: mov             SP, fp
    //     0xf78aac: ldp             fp, lr, [SP], #0x10
    // 0xf78ab0: ret
    //     0xf78ab0: ret             
    // 0xf78ab4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf78ab4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf78ab8: b               #0xf78a70
    // 0xf78abc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf78abc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0xf8e930, size: 0x6c
    // 0xf8e930: EnterFrame
    //     0xf8e930: stp             fp, lr, [SP, #-0x10]!
    //     0xf8e934: mov             fp, SP
    // 0xf8e938: AllocStack(0x8)
    //     0xf8e938: sub             SP, SP, #8
    // 0xf8e93c: SetupParameters(_VideoProgressBarState this /* r1 => r2 */)
    //     0xf8e93c: mov             x2, x1
    // 0xf8e940: CheckStackOverflow
    //     0xf8e940: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf8e944: cmp             SP, x16
    //     0xf8e948: b.ls            #0xf8e990
    // 0xf8e94c: LoadField: r0 = r2->field_b
    //     0xf8e94c: ldur            w0, [x2, #0xb]
    // 0xf8e950: DecompressPointer r0
    //     0xf8e950: add             x0, x0, HEAP, lsl #32
    // 0xf8e954: cmp             w0, NULL
    // 0xf8e958: b.eq            #0xf8e998
    // 0xf8e95c: LoadField: r3 = r0->field_b
    //     0xf8e95c: ldur            w3, [x0, #0xb]
    // 0xf8e960: DecompressPointer r3
    //     0xf8e960: add             x3, x3, HEAP, lsl #32
    // 0xf8e964: stur            x3, [fp, #-8]
    // 0xf8e968: r1 = Function 'listener':.
    //     0xf8e968: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4d70] AnonymousClosure: (0xde2ce0), in [package:chewie/src/progress_bar.dart] _VideoProgressBarState::listener (0xde2c6c)
    //     0xf8e96c: ldr             x1, [x1, #0xd70]
    // 0xf8e970: r0 = AllocateClosure()
    //     0xf8e970: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf8e974: ldur            x1, [fp, #-8]
    // 0xf8e978: mov             x2, x0
    // 0xf8e97c: r0 = addListener()
    //     0xf8e97c: bl              #0xd038e0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0xf8e980: r0 = Null
    //     0xf8e980: mov             x0, NULL
    // 0xf8e984: LeaveFrame
    //     0xf8e984: mov             SP, fp
    //     0xf8e988: ldp             fp, lr, [SP], #0x10
    // 0xf8e98c: ret
    //     0xf8e98c: ret             
    // 0xf8e990: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf8e990: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf8e994: b               #0xf8e94c
    // 0xf8e998: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf8e998: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 6210, size: 0x2c, field offset: 0xc
//   const constructor, 
class StaticProgressBar extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfab7fc, size: 0x210
    // 0xfab7fc: EnterFrame
    //     0xfab7fc: stp             fp, lr, [SP, #-0x10]!
    //     0xfab800: mov             fp, SP
    // 0xfab804: AllocStack(0x58)
    //     0xfab804: sub             SP, SP, #0x58
    // 0xfab808: SetupParameters(StaticProgressBar this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xfab808: mov             x0, x2
    //     0xfab80c: stur            x2, [fp, #-0x10]
    //     0xfab810: mov             x2, x1
    //     0xfab814: stur            x1, [fp, #-8]
    // 0xfab818: CheckStackOverflow
    //     0xfab818: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfab81c: cmp             SP, x16
    //     0xfab820: b.ls            #0xfab9d0
    // 0xfab824: mov             x1, x0
    // 0xfab828: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xfab828: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xfab82c: r0 = _of()
    //     0xfab82c: bl              #0x8651cc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::_of
    // 0xfab830: LoadField: r1 = r0->field_7
    //     0xfab830: ldur            w1, [x0, #7]
    // 0xfab834: DecompressPointer r1
    //     0xfab834: add             x1, x1, HEAP, lsl #32
    // 0xfab838: LoadField: d0 = r1->field_f
    //     0xfab838: ldur            d0, [x1, #0xf]
    // 0xfab83c: ldur            x1, [fp, #-0x10]
    // 0xfab840: stur            d0, [fp, #-0x28]
    // 0xfab844: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xfab844: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xfab848: r0 = _of()
    //     0xfab848: bl              #0x8651cc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::_of
    // 0xfab84c: LoadField: r1 = r0->field_7
    //     0xfab84c: ldur            w1, [x0, #7]
    // 0xfab850: DecompressPointer r1
    //     0xfab850: add             x1, x1, HEAP, lsl #32
    // 0xfab854: LoadField: d0 = r1->field_7
    //     0xfab854: ldur            d0, [x1, #7]
    // 0xfab858: ldur            x0, [fp, #-8]
    // 0xfab85c: stur            d0, [fp, #-0x30]
    // 0xfab860: LoadField: r4 = r0->field_f
    //     0xfab860: ldur            w4, [x0, #0xf]
    // 0xfab864: DecompressPointer r4
    //     0xfab864: add             x4, x4, HEAP, lsl #32
    // 0xfab868: stur            x4, [fp, #-0x18]
    // 0xfab86c: LoadField: r3 = r0->field_b
    //     0xfab86c: ldur            w3, [x0, #0xb]
    // 0xfab870: DecompressPointer r3
    //     0xfab870: add             x3, x3, HEAP, lsl #32
    // 0xfab874: cmp             w3, NULL
    // 0xfab878: b.eq            #0xfab894
    // 0xfab87c: LoadField: r2 = r4->field_7
    //     0xfab87c: ldur            w2, [x4, #7]
    // 0xfab880: DecompressPointer r2
    //     0xfab880: add             x2, x2, HEAP, lsl #32
    // 0xfab884: ldur            x1, [fp, #-0x10]
    // 0xfab888: r0 = RelativePositionExtensions.calcRelativePosition()
    //     0xfab888: bl              #0xde2978  ; [package:chewie/src/progress_bar.dart] ::RelativePositionExtensions.calcRelativePosition
    // 0xfab88c: mov             x2, x0
    // 0xfab890: b               #0xfab898
    // 0xfab894: r2 = Null
    //     0xfab894: mov             x2, NULL
    // 0xfab898: ldur            x0, [fp, #-8]
    // 0xfab89c: ldur            x1, [fp, #-0x18]
    // 0xfab8a0: ldur            d1, [fp, #-0x28]
    // 0xfab8a4: ldur            d0, [fp, #-0x30]
    // 0xfab8a8: stur            x2, [fp, #-0x20]
    // 0xfab8ac: LoadField: r3 = r0->field_13
    //     0xfab8ac: ldur            w3, [x0, #0x13]
    // 0xfab8b0: DecompressPointer r3
    //     0xfab8b0: add             x3, x3, HEAP, lsl #32
    // 0xfab8b4: stur            x3, [fp, #-0x10]
    // 0xfab8b8: ArrayLoad: d2 = r0[0]  ; List_8
    //     0xfab8b8: ldur            d2, [x0, #0x17]
    // 0xfab8bc: stur            d2, [fp, #-0x38]
    // 0xfab8c0: r0 = _ProgressBarPainter()
    //     0xfab8c0: bl              #0xfaba0c  ; Allocate_ProgressBarPainterStub -> _ProgressBarPainter (size=0x2c)
    // 0xfab8c4: mov             x1, x0
    // 0xfab8c8: ldur            x0, [fp, #-0x18]
    // 0xfab8cc: stur            x1, [fp, #-8]
    // 0xfab8d0: StoreField: r1->field_b = r0
    //     0xfab8d0: stur            w0, [x1, #0xb]
    // 0xfab8d4: ldur            x0, [fp, #-0x10]
    // 0xfab8d8: StoreField: r1->field_f = r0
    //     0xfab8d8: stur            w0, [x1, #0xf]
    // 0xfab8dc: ldur            d0, [fp, #-0x38]
    // 0xfab8e0: StoreField: r1->field_13 = d0
    //     0xfab8e0: stur            d0, [x1, #0x13]
    // 0xfab8e4: d0 = 6.000000
    //     0xfab8e4: fmov            d0, #6.00000000
    // 0xfab8e8: StoreField: r1->field_1b = d0
    //     0xfab8e8: stur            d0, [x1, #0x1b]
    // 0xfab8ec: r0 = true
    //     0xfab8ec: add             x0, NULL, #0x20  ; true
    // 0xfab8f0: StoreField: r1->field_23 = r0
    //     0xfab8f0: stur            w0, [x1, #0x23]
    // 0xfab8f4: ldur            x0, [fp, #-0x20]
    // 0xfab8f8: StoreField: r1->field_27 = r0
    //     0xfab8f8: stur            w0, [x1, #0x27]
    // 0xfab8fc: r0 = CustomPaint()
    //     0xfab8fc: bl              #0xd0a594  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0xfab900: mov             x1, x0
    // 0xfab904: ldur            x0, [fp, #-8]
    // 0xfab908: stur            x1, [fp, #-0x18]
    // 0xfab90c: StoreField: r1->field_f = r0
    //     0xfab90c: stur            w0, [x1, #0xf]
    // 0xfab910: r0 = Instance_Size
    //     0xfab910: ldr             x0, [PP, #0x7f28]  ; [pp+0x7f28] Obj!Size@12a74d1
    // 0xfab914: ArrayStore: r1[0] = r0  ; List_4
    //     0xfab914: stur            w0, [x1, #0x17]
    // 0xfab918: r0 = false
    //     0xfab918: add             x0, NULL, #0x30  ; false
    // 0xfab91c: StoreField: r1->field_1b = r0
    //     0xfab91c: stur            w0, [x1, #0x1b]
    // 0xfab920: StoreField: r1->field_1f = r0
    //     0xfab920: stur            w0, [x1, #0x1f]
    // 0xfab924: ldur            d0, [fp, #-0x28]
    // 0xfab928: r0 = inline_Allocate_Double()
    //     0xfab928: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xfab92c: add             x0, x0, #0x10
    //     0xfab930: cmp             x2, x0
    //     0xfab934: b.ls            #0xfab9d8
    //     0xfab938: str             x0, [THR, #0x60]  ; THR::top
    //     0xfab93c: sub             x0, x0, #0xf
    //     0xfab940: mov             x2, #0xe19c
    //     0xfab944: movk            x2, #3, lsl #16
    //     0xfab948: stur            x2, [x0, #-1]
    // 0xfab94c: dmb             ishst
    // 0xfab950: StoreField: r0->field_7 = d0
    //     0xfab950: stur            d0, [x0, #7]
    // 0xfab954: ldur            d0, [fp, #-0x30]
    // 0xfab958: stur            x0, [fp, #-0x10]
    // 0xfab95c: r2 = inline_Allocate_Double()
    //     0xfab95c: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xfab960: add             x2, x2, #0x10
    //     0xfab964: cmp             x3, x2
    //     0xfab968: b.ls            #0xfab9f0
    //     0xfab96c: str             x2, [THR, #0x60]  ; THR::top
    //     0xfab970: sub             x2, x2, #0xf
    //     0xfab974: mov             x3, #0xe19c
    //     0xfab978: movk            x3, #3, lsl #16
    //     0xfab97c: stur            x3, [x2, #-1]
    // 0xfab980: dmb             ishst
    // 0xfab984: StoreField: r2->field_7 = d0
    //     0xfab984: stur            d0, [x2, #7]
    // 0xfab988: stur            x2, [fp, #-8]
    // 0xfab98c: r0 = Container()
    //     0xfab98c: bl              #0x8a5af8  ; AllocateContainerStub -> Container (size=0x38)
    // 0xfab990: stur            x0, [fp, #-0x20]
    // 0xfab994: ldur            x16, [fp, #-0x10]
    // 0xfab998: ldur            lr, [fp, #-8]
    // 0xfab99c: stp             lr, x16, [SP, #0x10]
    // 0xfab9a0: r16 = Instance_Color
    //     0xfab9a0: add             x16, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xfab9a4: ldr             x16, [x16, #0x810]
    // 0xfab9a8: ldur            lr, [fp, #-0x18]
    // 0xfab9ac: stp             lr, x16, [SP]
    // 0xfab9b0: mov             x1, x0
    // 0xfab9b4: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, color, 0x3, height, 0x1, width, 0x2, null]
    //     0xfab9b4: add             x4, PP, #0xd4, lsl #12  ; [pp+0xd4ea8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "color", 0x3, "height", 0x1, "width", 0x2, Null]
    //     0xfab9b8: ldr             x4, [x4, #0xea8]
    // 0xfab9bc: r0 = Container()
    //     0xfab9bc: bl              #0x8a54e0  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0xfab9c0: ldur            x0, [fp, #-0x20]
    // 0xfab9c4: LeaveFrame
    //     0xfab9c4: mov             SP, fp
    //     0xfab9c8: ldp             fp, lr, [SP], #0x10
    // 0xfab9cc: ret
    //     0xfab9cc: ret             
    // 0xfab9d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfab9d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfab9d4: b               #0xfab824
    // 0xfab9d8: SaveReg d0
    //     0xfab9d8: str             q0, [SP, #-0x10]!
    // 0xfab9dc: SaveReg r1
    //     0xfab9dc: str             x1, [SP, #-8]!
    // 0xfab9e0: r0 = AllocateDouble()
    //     0xfab9e0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xfab9e4: RestoreReg r1
    //     0xfab9e4: ldr             x1, [SP], #8
    // 0xfab9e8: RestoreReg d0
    //     0xfab9e8: ldr             q0, [SP], #0x10
    // 0xfab9ec: b               #0xfab950
    // 0xfab9f0: SaveReg d0
    //     0xfab9f0: str             q0, [SP, #-0x10]!
    // 0xfab9f4: stp             x0, x1, [SP, #-0x10]!
    // 0xfab9f8: r0 = AllocateDouble()
    //     0xfab9f8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xfab9fc: mov             x2, x0
    // 0xfaba00: ldp             x0, x1, [SP], #0x10
    // 0xfaba04: RestoreReg d0
    //     0xfaba04: ldr             q0, [SP], #0x10
    // 0xfaba08: b               #0xfab984
  }
}

// class id: 6532, size: 0x38, field offset: 0xc
class VideoProgressBar extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa00d0, size: 0x2c
    // 0xfa00d0: EnterFrame
    //     0xfa00d0: stp             fp, lr, [SP, #-0x10]!
    //     0xfa00d4: mov             fp, SP
    // 0xfa00d8: mov             x0, x1
    // 0xfa00dc: r1 = <VideoProgressBar>
    //     0xfa00dc: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd49b8] TypeArguments: <VideoProgressBar>
    //     0xfa00e0: ldr             x1, [x1, #0x9b8]
    // 0xfa00e4: r0 = _VideoProgressBarState()
    //     0xfa00e4: bl              #0xfa00fc  ; Allocate_VideoProgressBarStateStub -> _VideoProgressBarState (size=0x1c)
    // 0xfa00e8: r1 = false
    //     0xfa00e8: add             x1, NULL, #0x30  ; false
    // 0xfa00ec: StoreField: r0->field_13 = r1
    //     0xfa00ec: stur            w1, [x0, #0x13]
    // 0xfa00f0: LeaveFrame
    //     0xfa00f0: mov             SP, fp
    //     0xfa00f4: ldp             fp, lr, [SP], #0x10
    // 0xfa00f8: ret
    //     0xfa00f8: ret             
  }
  _ VideoProgressBar(/* No info */) {
    // ** addr: 0xfaa8e4, size: 0xf4
    // 0xfaa8e4: EnterFrame
    //     0xfaa8e4: stp             fp, lr, [SP, #-0x10]!
    //     0xfaa8e8: mov             fp, SP
    // 0xfaa8ec: r4 = true
    //     0xfaa8ec: add             x4, NULL, #0x20  ; true
    // 0xfaa8f0: d1 = 6.000000
    //     0xfaa8f0: fmov            d1, #6.00000000
    // 0xfaa8f4: mov             x0, x2
    // 0xfaa8f8: mov             x16, x7
    // 0xfaa8fc: mov             x7, x1
    // 0xfaa900: mov             x1, x16
    // 0xfaa904: mov             x16, x6
    // 0xfaa908: mov             x6, x2
    // 0xfaa90c: mov             x2, x16
    // 0xfaa910: mov             x16, x5
    // 0xfaa914: mov             x5, x3
    // 0xfaa918: mov             x3, x16
    // 0xfaa91c: StoreField: r7->field_b = r0
    //     0xfaa91c: stur            w0, [x7, #0xb]
    //     0xfaa920: ldurb           w16, [x7, #-1]
    //     0xfaa924: ldurb           w17, [x0, #-1]
    //     0xfaa928: and             x16, x17, x16, lsr #2
    //     0xfaa92c: tst             x16, HEAP, lsr #32
    //     0xfaa930: b.eq            #0xfaa938
    //     0xfaa934: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xfaa938: mov             x0, x3
    // 0xfaa93c: ArrayStore: r7[0] = r0  ; List_4
    //     0xfaa93c: stur            w0, [x7, #0x17]
    //     0xfaa940: ldurb           w16, [x7, #-1]
    //     0xfaa944: ldurb           w17, [x0, #-1]
    //     0xfaa948: and             x16, x17, x16, lsr #2
    //     0xfaa94c: tst             x16, HEAP, lsr #32
    //     0xfaa950: b.eq            #0xfaa958
    //     0xfaa954: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xfaa958: mov             x0, x2
    // 0xfaa95c: StoreField: r7->field_13 = r0
    //     0xfaa95c: stur            w0, [x7, #0x13]
    //     0xfaa960: ldurb           w16, [x7, #-1]
    //     0xfaa964: ldurb           w17, [x0, #-1]
    //     0xfaa968: and             x16, x17, x16, lsr #2
    //     0xfaa96c: tst             x16, HEAP, lsr #32
    //     0xfaa970: b.eq            #0xfaa978
    //     0xfaa974: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xfaa978: mov             x0, x1
    // 0xfaa97c: StoreField: r7->field_1b = r0
    //     0xfaa97c: stur            w0, [x7, #0x1b]
    //     0xfaa980: ldurb           w16, [x7, #-1]
    //     0xfaa984: ldurb           w17, [x0, #-1]
    //     0xfaa988: and             x16, x17, x16, lsr #2
    //     0xfaa98c: tst             x16, HEAP, lsr #32
    //     0xfaa990: b.eq            #0xfaa998
    //     0xfaa994: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xfaa998: StoreField: r7->field_33 = r4
    //     0xfaa998: stur            w4, [x7, #0x33]
    // 0xfaa99c: StoreField: r7->field_1f = d0
    //     0xfaa99c: stur            d0, [x7, #0x1f]
    // 0xfaa9a0: StoreField: r7->field_27 = d1
    //     0xfaa9a0: stur            d1, [x7, #0x27]
    // 0xfaa9a4: StoreField: r7->field_2f = r4
    //     0xfaa9a4: stur            w4, [x7, #0x2f]
    // 0xfaa9a8: mov             x0, x5
    // 0xfaa9ac: StoreField: r7->field_f = r0
    //     0xfaa9ac: stur            w0, [x7, #0xf]
    //     0xfaa9b0: ldurb           w16, [x7, #-1]
    //     0xfaa9b4: ldurb           w17, [x0, #-1]
    //     0xfaa9b8: and             x16, x17, x16, lsr #2
    //     0xfaa9bc: tst             x16, HEAP, lsr #32
    //     0xfaa9c0: b.eq            #0xfaa9c8
    //     0xfaa9c4: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xfaa9c8: r0 = Null
    //     0xfaa9c8: mov             x0, NULL
    // 0xfaa9cc: LeaveFrame
    //     0xfaa9cc: mov             SP, fp
    //     0xfaa9d0: ldp             fp, lr, [SP], #0x10
    // 0xfaa9d4: ret
    //     0xfaa9d4: ret             
  }
}
