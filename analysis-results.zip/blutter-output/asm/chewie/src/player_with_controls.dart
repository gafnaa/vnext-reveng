// lib: , url: package:chewie/src/player_with_controls.dart

// class id: 1048645, size: 0x8
class :: {
}

// class id: 6211, size: 0xc, field offset: 0xc
//   const constructor, 
class PlayerWithControls extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfab050, size: 0xc8
    // 0xfab050: EnterFrame
    //     0xfab050: stp             fp, lr, [SP, #-0x10]!
    //     0xfab054: mov             fp, SP
    // 0xfab058: AllocStack(0x10)
    //     0xfab058: sub             SP, SP, #0x10
    // 0xfab05c: SetupParameters(PlayerWithControls this /* r1 => r0 */, dynamic _ /* r2 => r1 */)
    //     0xfab05c: mov             x0, x1
    //     0xfab060: mov             x1, x2
    // 0xfab064: CheckStackOverflow
    //     0xfab064: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfab068: cmp             SP, x16
    //     0xfab06c: b.ls            #0xfab110
    // 0xfab070: r0 = of()
    //     0xfab070: bl              #0xef309c  ; [package:chewie/src/chewie_player.dart] ChewieController::of
    // 0xfab074: stur            x0, [fp, #-8]
    // 0xfab078: r1 = 4
    //     0xfab078: mov             x1, #4
    // 0xfab07c: r0 = AllocateContext()
    //     0xfab07c: bl              #0x13de838  ; AllocateContextStub
    // 0xfab080: mov             x3, x0
    // 0xfab084: ldur            x0, [fp, #-8]
    // 0xfab088: stur            x3, [fp, #-0x10]
    // 0xfab08c: StoreField: r3->field_f = r0
    //     0xfab08c: stur            w0, [x3, #0xf]
    // 0xfab090: r1 = Function 'calculateAspectRatio':.
    //     0xfab090: add             x1, PP, #0xd1, lsl #12  ; [pp+0xd17c0] AnonymousClosure: (0xfab760), in [package:chewie/src/player_with_controls.dart] PlayerWithControls::build (0xfab050)
    //     0xfab094: ldr             x1, [x1, #0x7c0]
    // 0xfab098: r2 = Null
    //     0xfab098: mov             x2, NULL
    // 0xfab09c: r0 = AllocateClosure()
    //     0xfab09c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfab0a0: mov             x1, x0
    // 0xfab0a4: ldur            x0, [fp, #-0x10]
    // 0xfab0a8: StoreField: r0->field_13 = r1
    //     0xfab0a8: stur            w1, [x0, #0x13]
    // 0xfab0ac: r1 = Function 'buildControls':.
    //     0xfab0ac: add             x1, PP, #0xd1, lsl #12  ; [pp+0xd17c8] AnonymousClosure: (0xfab754), in [package:chewie/src/player_with_controls.dart] PlayerWithControls::build (0xfab050)
    //     0xfab0b0: ldr             x1, [x1, #0x7c8]
    // 0xfab0b4: r2 = Null
    //     0xfab0b4: mov             x2, NULL
    // 0xfab0b8: r0 = AllocateClosure()
    //     0xfab0b8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfab0bc: mov             x1, x0
    // 0xfab0c0: ldur            x0, [fp, #-0x10]
    // 0xfab0c4: ArrayStore: r0[0] = r1  ; List_4
    //     0xfab0c4: stur            w1, [x0, #0x17]
    // 0xfab0c8: mov             x2, x0
    // 0xfab0cc: r1 = Function 'buildPlayerWithControls':.
    //     0xfab0cc: add             x1, PP, #0xd1, lsl #12  ; [pp+0xd17d0] AnonymousClosure: (0xfab2c0), in [package:chewie/src/player_with_controls.dart] PlayerWithControls::build (0xfab050)
    //     0xfab0d0: ldr             x1, [x1, #0x7d0]
    // 0xfab0d4: r0 = AllocateClosure()
    //     0xfab0d4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfab0d8: ldur            x2, [fp, #-0x10]
    // 0xfab0dc: StoreField: r2->field_1b = r0
    //     0xfab0dc: stur            w0, [x2, #0x1b]
    // 0xfab0e0: r1 = Function '<anonymous closure>':.
    //     0xfab0e0: add             x1, PP, #0xd1, lsl #12  ; [pp+0xd17d8] AnonymousClosure: (0xfab118), in [package:chewie/src/player_with_controls.dart] PlayerWithControls::build (0xfab050)
    //     0xfab0e4: ldr             x1, [x1, #0x7d8]
    // 0xfab0e8: r0 = AllocateClosure()
    //     0xfab0e8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfab0ec: r1 = <BoxConstraints>
    //     0xfab0ec: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c3f0] TypeArguments: <BoxConstraints>
    //     0xfab0f0: ldr             x1, [x1, #0x3f0]
    // 0xfab0f4: stur            x0, [fp, #-8]
    // 0xfab0f8: r0 = LayoutBuilder()
    //     0xfab0f8: bl              #0xd15d50  ; AllocateLayoutBuilderStub -> LayoutBuilder (size=0x14)
    // 0xfab0fc: ldur            x1, [fp, #-8]
    // 0xfab100: StoreField: r0->field_f = r1
    //     0xfab100: stur            w1, [x0, #0xf]
    // 0xfab104: LeaveFrame
    //     0xfab104: mov             SP, fp
    //     0xfab108: ldp             fp, lr, [SP], #0x10
    // 0xfab10c: ret
    //     0xfab10c: ret             
    // 0xfab110: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfab110: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfab114: b               #0xfab070
  }
  [closure] Center <anonymous closure>(dynamic, BuildContext, BoxConstraints) {
    // ** addr: 0xfab118, size: 0x1a8
    // 0xfab118: EnterFrame
    //     0xfab118: stp             fp, lr, [SP, #-0x10]!
    //     0xfab11c: mov             fp, SP
    // 0xfab120: AllocStack(0x48)
    //     0xfab120: sub             SP, SP, #0x48
    // 0xfab124: SetupParameters([dynamic _ /* r0 */])
    //     0xfab124: ldr             x0, [fp, #0x20]
    //     0xfab128: ldur            w2, [x0, #0x17]
    //     0xfab12c: add             x2, x2, HEAP, lsl #32
    //     0xfab130: stur            x2, [fp, #-8]
    // 0xfab134: CheckStackOverflow
    //     0xfab134: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfab138: cmp             SP, x16
    //     0xfab13c: b.ls            #0xfab284
    // 0xfab140: ldr             x0, [fp, #0x10]
    // 0xfab144: LoadField: d0 = r0->field_1f
    //     0xfab144: ldur            d0, [x0, #0x1f]
    // 0xfab148: stur            d0, [fp, #-0x28]
    // 0xfab14c: LoadField: d1 = r0->field_f
    //     0xfab14c: ldur            d1, [x0, #0xf]
    // 0xfab150: ldr             x1, [fp, #0x18]
    // 0xfab154: stur            d1, [fp, #-0x20]
    // 0xfab158: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xfab158: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xfab15c: r0 = _of()
    //     0xfab15c: bl              #0x8651cc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::_of
    // 0xfab160: LoadField: r1 = r0->field_7
    //     0xfab160: ldur            w1, [x0, #7]
    // 0xfab164: DecompressPointer r1
    //     0xfab164: add             x1, x1, HEAP, lsl #32
    // 0xfab168: LoadField: d0 = r1->field_7
    //     0xfab168: ldur            d0, [x1, #7]
    // 0xfab16c: LoadField: d1 = r1->field_f
    //     0xfab16c: ldur            d1, [x1, #0xf]
    // 0xfab170: fcmp            d0, d1
    // 0xfab174: b.le            #0xfab180
    // 0xfab178: fdiv            d2, d0, d1
    // 0xfab17c: b               #0xfab184
    // 0xfab180: fdiv            d2, d1, d0
    // 0xfab184: ldur            x0, [fp, #-8]
    // 0xfab188: ldur            d0, [fp, #-0x28]
    // 0xfab18c: ldur            d1, [fp, #-0x20]
    // 0xfab190: stur            d2, [fp, #-0x30]
    // 0xfab194: LoadField: r1 = r0->field_1b
    //     0xfab194: ldur            w1, [x0, #0x1b]
    // 0xfab198: DecompressPointer r1
    //     0xfab198: add             x1, x1, HEAP, lsl #32
    // 0xfab19c: LoadField: r2 = r0->field_f
    //     0xfab19c: ldur            w2, [x0, #0xf]
    // 0xfab1a0: DecompressPointer r2
    //     0xfab1a0: add             x2, x2, HEAP, lsl #32
    // 0xfab1a4: stp             x2, x1, [SP, #8]
    // 0xfab1a8: ldr             x16, [fp, #0x18]
    // 0xfab1ac: str             x16, [SP]
    // 0xfab1b0: mov             x0, x1
    // 0xfab1b4: ClosureCall
    //     0xfab1b4: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xfab1b8: ldur            x2, [x0, #0x1f]
    //     0xfab1bc: blr             x2
    // 0xfab1c0: stur            x0, [fp, #-8]
    // 0xfab1c4: r0 = AspectRatio()
    //     0xfab1c4: bl              #0xdcd2dc  ; AllocateAspectRatioStub -> AspectRatio (size=0x18)
    // 0xfab1c8: ldur            d0, [fp, #-0x30]
    // 0xfab1cc: stur            x0, [fp, #-0x10]
    // 0xfab1d0: StoreField: r0->field_f = d0
    //     0xfab1d0: stur            d0, [x0, #0xf]
    // 0xfab1d4: ldur            x1, [fp, #-8]
    // 0xfab1d8: StoreField: r0->field_b = r1
    //     0xfab1d8: stur            w1, [x0, #0xb]
    // 0xfab1dc: ldur            d0, [fp, #-0x20]
    // 0xfab1e0: r1 = inline_Allocate_Double()
    //     0xfab1e0: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xfab1e4: add             x1, x1, #0x10
    //     0xfab1e8: cmp             x2, x1
    //     0xfab1ec: b.ls            #0xfab28c
    //     0xfab1f0: str             x1, [THR, #0x60]  ; THR::top
    //     0xfab1f4: sub             x1, x1, #0xf
    //     0xfab1f8: mov             x2, #0xe19c
    //     0xfab1fc: movk            x2, #3, lsl #16
    //     0xfab200: stur            x2, [x1, #-1]
    // 0xfab204: dmb             ishst
    // 0xfab208: StoreField: r1->field_7 = d0
    //     0xfab208: stur            d0, [x1, #7]
    // 0xfab20c: stur            x1, [fp, #-8]
    // 0xfab210: r0 = SizedBox()
    //     0xfab210: bl              #0x8a7210  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0xfab214: mov             x1, x0
    // 0xfab218: ldur            x0, [fp, #-8]
    // 0xfab21c: stur            x1, [fp, #-0x18]
    // 0xfab220: StoreField: r1->field_f = r0
    //     0xfab220: stur            w0, [x1, #0xf]
    // 0xfab224: ldur            d0, [fp, #-0x28]
    // 0xfab228: r0 = inline_Allocate_Double()
    //     0xfab228: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xfab22c: add             x0, x0, #0x10
    //     0xfab230: cmp             x2, x0
    //     0xfab234: b.ls            #0xfab2a8
    //     0xfab238: str             x0, [THR, #0x60]  ; THR::top
    //     0xfab23c: sub             x0, x0, #0xf
    //     0xfab240: mov             x2, #0xe19c
    //     0xfab244: movk            x2, #3, lsl #16
    //     0xfab248: stur            x2, [x0, #-1]
    // 0xfab24c: dmb             ishst
    // 0xfab250: StoreField: r0->field_7 = d0
    //     0xfab250: stur            d0, [x0, #7]
    // 0xfab254: StoreField: r1->field_13 = r0
    //     0xfab254: stur            w0, [x1, #0x13]
    // 0xfab258: ldur            x0, [fp, #-0x10]
    // 0xfab25c: StoreField: r1->field_b = r0
    //     0xfab25c: stur            w0, [x1, #0xb]
    // 0xfab260: r0 = Center()
    //     0xfab260: bl              #0xd0c898  ; AllocateCenterStub -> Center (size=0x1c)
    // 0xfab264: r1 = Instance_Alignment
    //     0xfab264: add             x1, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xfab268: ldr             x1, [x1, #0xb80]
    // 0xfab26c: StoreField: r0->field_f = r1
    //     0xfab26c: stur            w1, [x0, #0xf]
    // 0xfab270: ldur            x1, [fp, #-0x18]
    // 0xfab274: StoreField: r0->field_b = r1
    //     0xfab274: stur            w1, [x0, #0xb]
    // 0xfab278: LeaveFrame
    //     0xfab278: mov             SP, fp
    //     0xfab27c: ldp             fp, lr, [SP], #0x10
    // 0xfab280: ret
    //     0xfab280: ret             
    // 0xfab284: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfab284: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfab288: b               #0xfab140
    // 0xfab28c: SaveReg d0
    //     0xfab28c: str             q0, [SP, #-0x10]!
    // 0xfab290: SaveReg r0
    //     0xfab290: str             x0, [SP, #-8]!
    // 0xfab294: r0 = AllocateDouble()
    //     0xfab294: bl              #0x13df878  ; AllocateDoubleStub
    // 0xfab298: mov             x1, x0
    // 0xfab29c: RestoreReg r0
    //     0xfab29c: ldr             x0, [SP], #8
    // 0xfab2a0: RestoreReg d0
    //     0xfab2a0: ldr             q0, [SP], #0x10
    // 0xfab2a4: b               #0xfab208
    // 0xfab2a8: SaveReg d0
    //     0xfab2a8: str             q0, [SP, #-0x10]!
    // 0xfab2ac: SaveReg r1
    //     0xfab2ac: str             x1, [SP, #-8]!
    // 0xfab2b0: r0 = AllocateDouble()
    //     0xfab2b0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xfab2b4: RestoreReg r1
    //     0xfab2b4: ldr             x1, [SP], #8
    // 0xfab2b8: RestoreReg d0
    //     0xfab2b8: ldr             q0, [SP], #0x10
    // 0xfab2bc: b               #0xfab250
  }
  [closure] Widget buildPlayerWithControls(dynamic, ChewieController, BuildContext) {
    // ** addr: 0xfab2c0, size: 0x35c
    // 0xfab2c0: EnterFrame
    //     0xfab2c0: stp             fp, lr, [SP, #-0x10]!
    //     0xfab2c4: mov             fp, SP
    // 0xfab2c8: AllocStack(0x40)
    //     0xfab2c8: sub             SP, SP, #0x40
    // 0xfab2cc: CheckStackOverflow
    //     0xfab2cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfab2d0: cmp             SP, x16
    //     0xfab2d4: b.ls            #0xfab614
    // 0xfab2d8: r16 = <PlayerNotifier>
    //     0xfab2d8: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf6f0] TypeArguments: <PlayerNotifier>
    //     0xfab2dc: ldr             x16, [x16, #0x6f0]
    // 0xfab2e0: ldr             lr, [fp, #0x10]
    // 0xfab2e4: stp             lr, x16, [SP]
    // 0xfab2e8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xfab2e8: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xfab2ec: r0 = ReadContext.read()
    //     0xfab2ec: bl              #0xfab634  ; [package:provider/src/provider.dart] ::ReadContext.read
    // 0xfab2f0: r1 = <Widget>
    //     0xfab2f0: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xfab2f4: r2 = 0
    //     0xfab2f4: mov             x2, #0
    // 0xfab2f8: r0 = _GrowableList()
    //     0xfab2f8: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xfab2fc: mov             x2, x0
    // 0xfab300: ldr             x0, [fp, #0x18]
    // 0xfab304: stur            x2, [fp, #-8]
    // 0xfab308: LoadField: r1 = r0->field_6f
    //     0xfab308: ldur            w1, [x0, #0x6f]
    // 0xfab30c: DecompressPointer r1
    //     0xfab30c: add             x1, x1, HEAP, lsl #32
    // 0xfab310: cmp             w1, NULL
    // 0xfab314: b.ne            #0xfab334
    // 0xfab318: LoadField: r1 = r0->field_3b
    //     0xfab318: ldur            w1, [x0, #0x3b]
    // 0xfab31c: DecompressPointer r1
    //     0xfab31c: add             x1, x1, HEAP, lsl #32
    // 0xfab320: LoadField: r3 = r1->field_27
    //     0xfab320: ldur            w3, [x1, #0x27]
    // 0xfab324: DecompressPointer r3
    //     0xfab324: add             x3, x3, HEAP, lsl #32
    // 0xfab328: mov             x1, x3
    // 0xfab32c: r0 = aspectRatio()
    //     0xfab32c: bl              #0xf9a0f0  ; [package:video_player/video_player.dart] VideoPlayerValue::aspectRatio
    // 0xfab330: b               #0xfab338
    // 0xfab334: LoadField: d0 = r1->field_7
    //     0xfab334: ldur            d0, [x1, #7]
    // 0xfab338: ldr             x0, [fp, #0x18]
    // 0xfab33c: ldur            x1, [fp, #-8]
    // 0xfab340: stur            d0, [fp, #-0x30]
    // 0xfab344: LoadField: r2 = r0->field_3b
    //     0xfab344: ldur            w2, [x0, #0x3b]
    // 0xfab348: DecompressPointer r2
    //     0xfab348: add             x2, x2, HEAP, lsl #32
    // 0xfab34c: stur            x2, [fp, #-0x10]
    // 0xfab350: r0 = VideoPlayer()
    //     0xfab350: bl              #0xfab628  ; AllocateVideoPlayerStub -> VideoPlayer (size=0x10)
    // 0xfab354: mov             x1, x0
    // 0xfab358: ldur            x0, [fp, #-0x10]
    // 0xfab35c: stur            x1, [fp, #-0x18]
    // 0xfab360: StoreField: r1->field_b = r0
    //     0xfab360: stur            w0, [x1, #0xb]
    // 0xfab364: r0 = AspectRatio()
    //     0xfab364: bl              #0xdcd2dc  ; AllocateAspectRatioStub -> AspectRatio (size=0x18)
    // 0xfab368: ldur            d0, [fp, #-0x30]
    // 0xfab36c: stur            x0, [fp, #-0x10]
    // 0xfab370: StoreField: r0->field_f = d0
    //     0xfab370: stur            d0, [x0, #0xf]
    // 0xfab374: ldur            x1, [fp, #-0x18]
    // 0xfab378: StoreField: r0->field_b = r1
    //     0xfab378: stur            w1, [x0, #0xb]
    // 0xfab37c: r0 = Center()
    //     0xfab37c: bl              #0xd0c898  ; AllocateCenterStub -> Center (size=0x1c)
    // 0xfab380: mov             x2, x0
    // 0xfab384: r0 = Instance_Alignment
    //     0xfab384: add             x0, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xfab388: ldr             x0, [x0, #0xb80]
    // 0xfab38c: stur            x2, [fp, #-0x18]
    // 0xfab390: StoreField: r2->field_f = r0
    //     0xfab390: stur            w0, [x2, #0xf]
    // 0xfab394: ldur            x0, [fp, #-0x10]
    // 0xfab398: StoreField: r2->field_b = r0
    //     0xfab398: stur            w0, [x2, #0xb]
    // 0xfab39c: ldur            x0, [fp, #-8]
    // 0xfab3a0: LoadField: r1 = r0->field_b
    //     0xfab3a0: ldur            w1, [x0, #0xb]
    // 0xfab3a4: LoadField: r3 = r0->field_f
    //     0xfab3a4: ldur            w3, [x0, #0xf]
    // 0xfab3a8: DecompressPointer r3
    //     0xfab3a8: add             x3, x3, HEAP, lsl #32
    // 0xfab3ac: LoadField: r4 = r3->field_b
    //     0xfab3ac: ldur            w4, [x3, #0xb]
    // 0xfab3b0: r3 = LoadInt32Instr(r1)
    //     0xfab3b0: sbfx            x3, x1, #1, #0x1f
    // 0xfab3b4: stur            x3, [fp, #-0x20]
    // 0xfab3b8: r1 = LoadInt32Instr(r4)
    //     0xfab3b8: sbfx            x1, x4, #1, #0x1f
    // 0xfab3bc: cmp             x3, x1
    // 0xfab3c0: b.ne            #0xfab3cc
    // 0xfab3c4: mov             x1, x0
    // 0xfab3c8: r0 = _growToNextCapacity()
    //     0xfab3c8: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xfab3cc: ldur            x2, [fp, #-8]
    // 0xfab3d0: ldur            x3, [fp, #-0x20]
    // 0xfab3d4: add             x0, x3, #1
    // 0xfab3d8: lsl             x1, x0, #1
    // 0xfab3dc: StoreField: r2->field_b = r1
    //     0xfab3dc: stur            w1, [x2, #0xb]
    // 0xfab3e0: LoadField: r1 = r2->field_f
    //     0xfab3e0: ldur            w1, [x2, #0xf]
    // 0xfab3e4: DecompressPointer r1
    //     0xfab3e4: add             x1, x1, HEAP, lsl #32
    // 0xfab3e8: ldur            x0, [fp, #-0x18]
    // 0xfab3ec: ArrayStore: r1[r3] = r0  ; List_4
    //     0xfab3ec: add             x25, x1, x3, lsl #2
    //     0xfab3f0: add             x25, x25, #0xf
    //     0xfab3f4: str             w0, [x25]
    //     0xfab3f8: tbz             w0, #0, #0xfab414
    //     0xfab3fc: ldurb           w16, [x1, #-1]
    //     0xfab400: ldurb           w17, [x0, #-1]
    //     0xfab404: and             x16, x17, x16, lsr #2
    //     0xfab408: tst             x16, HEAP, lsr #32
    //     0xfab40c: b.eq            #0xfab414
    //     0xfab410: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xfab414: ldr             x1, [fp, #0x10]
    // 0xfab418: r0 = of()
    //     0xfab418: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfab41c: r1 = Function '<anonymous closure>':.
    //     0xfab41c: add             x1, PP, #0xd1, lsl #12  ; [pp+0xd17e0] AnonymousClosure: (0xfab69c), in [package:chewie/src/player_with_controls.dart] PlayerWithControls::build (0xfab050)
    //     0xfab420: ldr             x1, [x1, #0x7e0]
    // 0xfab424: r2 = Null
    //     0xfab424: mov             x2, NULL
    // 0xfab428: r0 = AllocateClosure()
    //     0xfab428: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfab42c: r1 = <PlayerNotifier>
    //     0xfab42c: add             x1, PP, #0xcf, lsl #12  ; [pp+0xcf6f0] TypeArguments: <PlayerNotifier>
    //     0xfab430: ldr             x1, [x1, #0x6f0]
    // 0xfab434: stur            x0, [fp, #-0x10]
    // 0xfab438: r0 = Consumer()
    //     0xfab438: bl              #0xfab61c  ; AllocateConsumerStub -> Consumer<X0> (size=0x18)
    // 0xfab43c: mov             x2, x0
    // 0xfab440: ldur            x0, [fp, #-0x10]
    // 0xfab444: stur            x2, [fp, #-0x18]
    // 0xfab448: StoreField: r2->field_13 = r0
    //     0xfab448: stur            w0, [x2, #0x13]
    // 0xfab44c: ldur            x0, [fp, #-8]
    // 0xfab450: LoadField: r1 = r0->field_b
    //     0xfab450: ldur            w1, [x0, #0xb]
    // 0xfab454: LoadField: r3 = r0->field_f
    //     0xfab454: ldur            w3, [x0, #0xf]
    // 0xfab458: DecompressPointer r3
    //     0xfab458: add             x3, x3, HEAP, lsl #32
    // 0xfab45c: LoadField: r4 = r3->field_b
    //     0xfab45c: ldur            w4, [x3, #0xb]
    // 0xfab460: r3 = LoadInt32Instr(r1)
    //     0xfab460: sbfx            x3, x1, #1, #0x1f
    // 0xfab464: stur            x3, [fp, #-0x20]
    // 0xfab468: r1 = LoadInt32Instr(r4)
    //     0xfab468: sbfx            x1, x4, #1, #0x1f
    // 0xfab46c: cmp             x3, x1
    // 0xfab470: b.ne            #0xfab47c
    // 0xfab474: mov             x1, x0
    // 0xfab478: r0 = _growToNextCapacity()
    //     0xfab478: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xfab47c: ldr             x4, [fp, #0x18]
    // 0xfab480: ldur            x2, [fp, #-8]
    // 0xfab484: ldur            x3, [fp, #-0x20]
    // 0xfab488: add             x5, x3, #1
    // 0xfab48c: stur            x5, [fp, #-0x28]
    // 0xfab490: lsl             x0, x5, #1
    // 0xfab494: StoreField: r2->field_b = r0
    //     0xfab494: stur            w0, [x2, #0xb]
    // 0xfab498: LoadField: r6 = r2->field_f
    //     0xfab498: ldur            w6, [x2, #0xf]
    // 0xfab49c: DecompressPointer r6
    //     0xfab49c: add             x6, x6, HEAP, lsl #32
    // 0xfab4a0: mov             x1, x6
    // 0xfab4a4: ldur            x0, [fp, #-0x18]
    // 0xfab4a8: stur            x6, [fp, #-0x10]
    // 0xfab4ac: ArrayStore: r1[r3] = r0  ; List_4
    //     0xfab4ac: add             x25, x1, x3, lsl #2
    //     0xfab4b0: add             x25, x25, #0xf
    //     0xfab4b4: str             w0, [x25]
    //     0xfab4b8: tbz             w0, #0, #0xfab4d4
    //     0xfab4bc: ldurb           w16, [x1, #-1]
    //     0xfab4c0: ldurb           w17, [x0, #-1]
    //     0xfab4c4: and             x16, x17, x16, lsr #2
    //     0xfab4c8: tst             x16, HEAP, lsr #32
    //     0xfab4cc: b.eq            #0xfab4d4
    //     0xfab4d0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xfab4d4: LoadField: r0 = r4->field_cf
    //     0xfab4d4: ldur            w0, [x4, #0xcf]
    // 0xfab4d8: DecompressPointer r0
    //     0xfab4d8: add             x0, x0, HEAP, lsl #32
    // 0xfab4dc: tbz             w0, #4, #0xfab52c
    // 0xfab4e0: LoadField: r0 = r6->field_b
    //     0xfab4e0: ldur            w0, [x6, #0xb]
    // 0xfab4e4: r1 = LoadInt32Instr(r0)
    //     0xfab4e4: sbfx            x1, x0, #1, #0x1f
    // 0xfab4e8: cmp             x5, x1
    // 0xfab4ec: b.ne            #0xfab4f8
    // 0xfab4f0: mov             x1, x2
    // 0xfab4f4: r0 = _growToNextCapacity()
    //     0xfab4f4: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xfab4f8: ldur            x1, [fp, #-8]
    // 0xfab4fc: ldur            x0, [fp, #-0x28]
    // 0xfab500: add             x2, x0, #1
    // 0xfab504: lsl             x3, x2, #1
    // 0xfab508: StoreField: r1->field_b = r3
    //     0xfab508: stur            w3, [x1, #0xb]
    // 0xfab50c: LoadField: r2 = r1->field_f
    //     0xfab50c: ldur            w2, [x1, #0xf]
    // 0xfab510: DecompressPointer r2
    //     0xfab510: add             x2, x2, HEAP, lsl #32
    // 0xfab514: add             x3, x2, x0, lsl #2
    // 0xfab518: r16 = Instance_AdaptiveControls
    //     0xfab518: add             x16, PP, #0xd1, lsl #12  ; [pp+0xd17e8] Obj!AdaptiveControls@12b6b01
    //     0xfab51c: ldr             x16, [x16, #0x7e8]
    // 0xfab520: StoreField: r3->field_f = r16
    //     0xfab520: stur            w16, [x3, #0xf]
    // 0xfab524: mov             x3, x1
    // 0xfab528: b               #0xfab5d8
    // 0xfab52c: mov             x1, x2
    // 0xfab530: mov             x0, x5
    // 0xfab534: r0 = SafeArea()
    //     0xfab534: bl              #0xd73100  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0xfab538: mov             x2, x0
    // 0xfab53c: r0 = true
    //     0xfab53c: add             x0, NULL, #0x20  ; true
    // 0xfab540: stur            x2, [fp, #-0x18]
    // 0xfab544: StoreField: r2->field_b = r0
    //     0xfab544: stur            w0, [x2, #0xb]
    // 0xfab548: StoreField: r2->field_f = r0
    //     0xfab548: stur            w0, [x2, #0xf]
    // 0xfab54c: StoreField: r2->field_13 = r0
    //     0xfab54c: stur            w0, [x2, #0x13]
    // 0xfab550: r0 = false
    //     0xfab550: add             x0, NULL, #0x30  ; false
    // 0xfab554: ArrayStore: r2[0] = r0  ; List_4
    //     0xfab554: stur            w0, [x2, #0x17]
    // 0xfab558: r1 = Instance_EdgeInsets
    //     0xfab558: ldr             x1, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0xfab55c: StoreField: r2->field_1b = r1
    //     0xfab55c: stur            w1, [x2, #0x1b]
    // 0xfab560: StoreField: r2->field_1f = r0
    //     0xfab560: stur            w0, [x2, #0x1f]
    // 0xfab564: r0 = Instance_AdaptiveControls
    //     0xfab564: add             x0, PP, #0xd1, lsl #12  ; [pp+0xd17e8] Obj!AdaptiveControls@12b6b01
    //     0xfab568: ldr             x0, [x0, #0x7e8]
    // 0xfab56c: StoreField: r2->field_23 = r0
    //     0xfab56c: stur            w0, [x2, #0x23]
    // 0xfab570: ldur            x0, [fp, #-0x10]
    // 0xfab574: LoadField: r1 = r0->field_b
    //     0xfab574: ldur            w1, [x0, #0xb]
    // 0xfab578: r0 = LoadInt32Instr(r1)
    //     0xfab578: sbfx            x0, x1, #1, #0x1f
    // 0xfab57c: ldur            x3, [fp, #-0x28]
    // 0xfab580: cmp             x3, x0
    // 0xfab584: b.ne            #0xfab590
    // 0xfab588: ldur            x1, [fp, #-8]
    // 0xfab58c: r0 = _growToNextCapacity()
    //     0xfab58c: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xfab590: ldur            x3, [fp, #-8]
    // 0xfab594: ldur            x2, [fp, #-0x28]
    // 0xfab598: add             x0, x2, #1
    // 0xfab59c: lsl             x1, x0, #1
    // 0xfab5a0: StoreField: r3->field_b = r1
    //     0xfab5a0: stur            w1, [x3, #0xb]
    // 0xfab5a4: LoadField: r1 = r3->field_f
    //     0xfab5a4: ldur            w1, [x3, #0xf]
    // 0xfab5a8: DecompressPointer r1
    //     0xfab5a8: add             x1, x1, HEAP, lsl #32
    // 0xfab5ac: ldur            x0, [fp, #-0x18]
    // 0xfab5b0: ArrayStore: r1[r2] = r0  ; List_4
    //     0xfab5b0: add             x25, x1, x2, lsl #2
    //     0xfab5b4: add             x25, x25, #0xf
    //     0xfab5b8: str             w0, [x25]
    //     0xfab5bc: tbz             w0, #0, #0xfab5d8
    //     0xfab5c0: ldurb           w16, [x1, #-1]
    //     0xfab5c4: ldurb           w17, [x0, #-1]
    //     0xfab5c8: and             x16, x17, x16, lsr #2
    //     0xfab5cc: tst             x16, HEAP, lsr #32
    //     0xfab5d0: b.eq            #0xfab5d8
    //     0xfab5d4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xfab5d8: r0 = Stack()
    //     0xfab5d8: bl              #0xd1a854  ; AllocateStackStub -> Stack (size=0x20)
    // 0xfab5dc: r1 = Instance_AlignmentDirectional
    //     0xfab5dc: add             x1, PP, #0x15, lsl #12  ; [pp+0x158d8] Obj!AlignmentDirectional@129e611
    //     0xfab5e0: ldr             x1, [x1, #0x8d8]
    // 0xfab5e4: StoreField: r0->field_f = r1
    //     0xfab5e4: stur            w1, [x0, #0xf]
    // 0xfab5e8: r1 = Instance_StackFit
    //     0xfab5e8: add             x1, PP, #0x15, lsl #12  ; [pp+0x158e0] Obj!StackFit@12c4221
    //     0xfab5ec: ldr             x1, [x1, #0x8e0]
    // 0xfab5f0: ArrayStore: r0[0] = r1  ; List_4
    //     0xfab5f0: stur            w1, [x0, #0x17]
    // 0xfab5f4: r1 = Instance_Clip
    //     0xfab5f4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xfab5f8: ldr             x1, [x1, #0x850]
    // 0xfab5fc: StoreField: r0->field_1b = r1
    //     0xfab5fc: stur            w1, [x0, #0x1b]
    // 0xfab600: ldur            x1, [fp, #-8]
    // 0xfab604: StoreField: r0->field_b = r1
    //     0xfab604: stur            w1, [x0, #0xb]
    // 0xfab608: LeaveFrame
    //     0xfab608: mov             SP, fp
    //     0xfab60c: ldp             fp, lr, [SP], #0x10
    // 0xfab610: ret
    //     0xfab610: ret             
    // 0xfab614: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfab614: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfab618: b               #0xfab2d8
  }
  [closure] Visibility <anonymous closure>(dynamic, BuildContext, PlayerNotifier, Widget?) {
    // ** addr: 0xfab69c, size: 0xb8
    // 0xfab69c: EnterFrame
    //     0xfab69c: stp             fp, lr, [SP, #-0x10]!
    //     0xfab6a0: mov             fp, SP
    // 0xfab6a4: AllocStack(0x18)
    //     0xfab6a4: sub             SP, SP, #0x18
    // 0xfab6a8: ldr             x0, [fp, #0x18]
    // 0xfab6ac: LoadField: r1 = r0->field_23
    //     0xfab6ac: ldur            w1, [x0, #0x23]
    // 0xfab6b0: DecompressPointer r1
    //     0xfab6b0: add             x1, x1, HEAP, lsl #32
    // 0xfab6b4: eor             x0, x1, #0x10
    // 0xfab6b8: stur            x0, [fp, #-8]
    // 0xfab6bc: tbnz            w1, #4, #0xfab6c8
    // 0xfab6c0: d0 = 0.000000
    //     0xfab6c0: eor             v0.16b, v0.16b, v0.16b
    // 0xfab6c4: b               #0xfab6d0
    // 0xfab6c8: d0 = 0.800000
    //     0xfab6c8: add             x17, PP, #0x13, lsl #12  ; [pp+0x13a58] IMM: double(0.8) from 0x3fe999999999999a
    //     0xfab6cc: ldr             d0, [x17, #0xa58]
    // 0xfab6d0: stur            d0, [fp, #-0x18]
    // 0xfab6d4: r0 = AnimatedOpacity()
    //     0xfab6d4: bl              #0xd2cf50  ; AllocateAnimatedOpacityStub -> AnimatedOpacity (size=0x28)
    // 0xfab6d8: mov             x1, x0
    // 0xfab6dc: r0 = Instance_DecoratedBox
    //     0xfab6dc: add             x0, PP, #0xd1, lsl #12  ; [pp+0xd17f0] Obj!DecoratedBox@12b7061
    //     0xfab6e0: ldr             x0, [x0, #0x7f0]
    // 0xfab6e4: stur            x1, [fp, #-0x10]
    // 0xfab6e8: ArrayStore: r1[0] = r0  ; List_4
    //     0xfab6e8: stur            w0, [x1, #0x17]
    // 0xfab6ec: ldur            d0, [fp, #-0x18]
    // 0xfab6f0: StoreField: r1->field_1b = d0
    //     0xfab6f0: stur            d0, [x1, #0x1b]
    // 0xfab6f4: r0 = false
    //     0xfab6f4: add             x0, NULL, #0x30  ; false
    // 0xfab6f8: StoreField: r1->field_23 = r0
    //     0xfab6f8: stur            w0, [x1, #0x23]
    // 0xfab6fc: r2 = Instance__Linear
    //     0xfab6fc: ldr             x2, [PP, #0x5168]  ; [pp+0x5168] Obj!_Linear@129fef1
    // 0xfab700: StoreField: r1->field_b = r2
    //     0xfab700: stur            w2, [x1, #0xb]
    // 0xfab704: r2 = Instance_Duration
    //     0xfab704: add             x2, PP, #0xc, lsl #12  ; [pp+0xc920] Obj!Duration@12c89c1
    //     0xfab708: ldr             x2, [x2, #0x920]
    // 0xfab70c: StoreField: r1->field_f = r2
    //     0xfab70c: stur            w2, [x1, #0xf]
    // 0xfab710: r0 = Visibility()
    //     0xfab710: bl              #0xd59568  ; AllocateVisibilityStub -> Visibility (size=0x30)
    // 0xfab714: ldur            x1, [fp, #-0x10]
    // 0xfab718: StoreField: r0->field_b = r1
    //     0xfab718: stur            w1, [x0, #0xb]
    // 0xfab71c: r1 = Instance_SizedBox
    //     0xfab71c: ldr             x1, [PP, #0x4f58]  ; [pp+0x4f58] Obj!SizedBox@12b70e1
    // 0xfab720: StoreField: r0->field_f = r1
    //     0xfab720: stur            w1, [x0, #0xf]
    // 0xfab724: ldur            x1, [fp, #-8]
    // 0xfab728: StoreField: r0->field_13 = r1
    //     0xfab728: stur            w1, [x0, #0x13]
    // 0xfab72c: r1 = false
    //     0xfab72c: add             x1, NULL, #0x30  ; false
    // 0xfab730: ArrayStore: r0[0] = r1  ; List_4
    //     0xfab730: stur            w1, [x0, #0x17]
    // 0xfab734: StoreField: r0->field_1b = r1
    //     0xfab734: stur            w1, [x0, #0x1b]
    // 0xfab738: StoreField: r0->field_1f = r1
    //     0xfab738: stur            w1, [x0, #0x1f]
    // 0xfab73c: StoreField: r0->field_23 = r1
    //     0xfab73c: stur            w1, [x0, #0x23]
    // 0xfab740: StoreField: r0->field_27 = r1
    //     0xfab740: stur            w1, [x0, #0x27]
    // 0xfab744: StoreField: r0->field_2b = r1
    //     0xfab744: stur            w1, [x0, #0x2b]
    // 0xfab748: LeaveFrame
    //     0xfab748: mov             SP, fp
    //     0xfab74c: ldp             fp, lr, [SP], #0x10
    // 0xfab750: ret
    //     0xfab750: ret             
  }
  [closure] Widget buildControls(dynamic, BuildContext, ChewieController) {
    // ** addr: 0xfab754, size: 0xc
    // 0xfab754: r0 = Instance_AdaptiveControls
    //     0xfab754: add             x0, PP, #0xd1, lsl #12  ; [pp+0xd17e8] Obj!AdaptiveControls@12b6b01
    //     0xfab758: ldr             x0, [x0, #0x7e8]
    // 0xfab75c: ret
    //     0xfab75c: ret             
  }
  [closure] double calculateAspectRatio(dynamic, BuildContext) {
    // ** addr: 0xfab760, size: 0x9c
    // 0xfab760: EnterFrame
    //     0xfab760: stp             fp, lr, [SP, #-0x10]!
    //     0xfab764: mov             fp, SP
    // 0xfab768: CheckStackOverflow
    //     0xfab768: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfab76c: cmp             SP, x16
    //     0xfab770: b.ls            #0xfab7e4
    // 0xfab774: ldr             x1, [fp, #0x10]
    // 0xfab778: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xfab778: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xfab77c: r0 = _of()
    //     0xfab77c: bl              #0x8651cc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::_of
    // 0xfab780: LoadField: r1 = r0->field_7
    //     0xfab780: ldur            w1, [x0, #7]
    // 0xfab784: DecompressPointer r1
    //     0xfab784: add             x1, x1, HEAP, lsl #32
    // 0xfab788: LoadField: d0 = r1->field_7
    //     0xfab788: ldur            d0, [x1, #7]
    // 0xfab78c: LoadField: d1 = r1->field_f
    //     0xfab78c: ldur            d1, [x1, #0xf]
    // 0xfab790: fcmp            d0, d1
    // 0xfab794: b.le            #0xfab7a4
    // 0xfab798: fdiv            d2, d0, d1
    // 0xfab79c: mov             v0.16b, v2.16b
    // 0xfab7a0: b               #0xfab7ac
    // 0xfab7a4: fdiv            d2, d1, d0
    // 0xfab7a8: mov             v0.16b, v2.16b
    // 0xfab7ac: r0 = inline_Allocate_Double()
    //     0xfab7ac: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xfab7b0: add             x0, x0, #0x10
    //     0xfab7b4: cmp             x1, x0
    //     0xfab7b8: b.ls            #0xfab7ec
    //     0xfab7bc: str             x0, [THR, #0x60]  ; THR::top
    //     0xfab7c0: sub             x0, x0, #0xf
    //     0xfab7c4: mov             x1, #0xe19c
    //     0xfab7c8: movk            x1, #3, lsl #16
    //     0xfab7cc: stur            x1, [x0, #-1]
    // 0xfab7d0: dmb             ishst
    // 0xfab7d4: StoreField: r0->field_7 = d0
    //     0xfab7d4: stur            d0, [x0, #7]
    // 0xfab7d8: LeaveFrame
    //     0xfab7d8: mov             SP, fp
    //     0xfab7dc: ldp             fp, lr, [SP], #0x10
    // 0xfab7e0: ret
    //     0xfab7e0: ret             
    // 0xfab7e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfab7e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfab7e8: b               #0xfab774
    // 0xfab7ec: SaveReg d0
    //     0xfab7ec: str             q0, [SP, #-0x10]!
    // 0xfab7f0: r0 = AllocateDouble()
    //     0xfab7f0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xfab7f4: RestoreReg d0
    //     0xfab7f4: ldr             q0, [SP], #0x10
    // 0xfab7f8: b               #0xfab7d4
  }
}
