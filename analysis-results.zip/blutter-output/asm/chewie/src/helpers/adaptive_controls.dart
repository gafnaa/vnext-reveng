// lib: , url: package:chewie/src/helpers/adaptive_controls.dart

// class id: 1048634, size: 0x8
class :: {
}

// class id: 6214, size: 0xc, field offset: 0xc
//   const constructor, 
class AdaptiveControls extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfaa9e4, size: 0x80
    // 0xfaa9e4: EnterFrame
    //     0xfaa9e4: stp             fp, lr, [SP, #-0x10]!
    //     0xfaa9e8: mov             fp, SP
    // 0xfaa9ec: mov             x0, x1
    // 0xfaa9f0: mov             x1, x2
    // 0xfaa9f4: CheckStackOverflow
    //     0xfaa9f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfaa9f8: cmp             SP, x16
    //     0xfaa9fc: b.ls            #0xfaaa5c
    // 0xfaaa00: r0 = of()
    //     0xfaaa00: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfaaa04: LoadField: r1 = r0->field_23
    //     0xfaaa04: ldur            w1, [x0, #0x23]
    // 0xfaaa08: DecompressPointer r1
    //     0xfaaa08: add             x1, x1, HEAP, lsl #32
    // 0xfaaa0c: LoadField: r2 = r1->field_7
    //     0xfaaa0c: ldur            x2, [x1, #7]
    // 0xfaaa10: cmp             x2, #2
    // 0xfaaa14: b.gt            #0xfaaa48
    // 0xfaaa18: cmp             x2, #1
    // 0xfaaa1c: b.gt            #0xfaaa34
    // 0xfaaa20: r0 = Instance_MaterialControls
    //     0xfaaa20: add             x0, PP, #0xd2, lsl #12  ; [pp+0xd2578] Obj!MaterialControls@12b7031
    //     0xfaaa24: ldr             x0, [x0, #0x578]
    // 0xfaaa28: LeaveFrame
    //     0xfaaa28: mov             SP, fp
    //     0xfaaa2c: ldp             fp, lr, [SP], #0x10
    // 0xfaaa30: ret
    //     0xfaaa30: ret             
    // 0xfaaa34: r0 = Instance_CupertinoControls
    //     0xfaaa34: add             x0, PP, #0xd2, lsl #12  ; [pp+0xd2580] Obj!CupertinoControls@12b7041
    //     0xfaaa38: ldr             x0, [x0, #0x580]
    // 0xfaaa3c: LeaveFrame
    //     0xfaaa3c: mov             SP, fp
    //     0xfaaa40: ldp             fp, lr, [SP], #0x10
    // 0xfaaa44: ret
    //     0xfaaa44: ret             
    // 0xfaaa48: r0 = Instance_MaterialDesktopControls
    //     0xfaaa48: add             x0, PP, #0xd2, lsl #12  ; [pp+0xd2588] Obj!MaterialDesktopControls@12b7021
    //     0xfaaa4c: ldr             x0, [x0, #0x588]
    // 0xfaaa50: LeaveFrame
    //     0xfaaa50: mov             SP, fp
    //     0xfaaa54: ldp             fp, lr, [SP], #0x10
    // 0xfaaa58: ret
    //     0xfaaa58: ret             
    // 0xfaaa5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfaaa5c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfaaa60: b               #0xfaaa00
  }
}
