// lib: , url: package:chewie/src/helpers/utils.dart

// class id: 1048635, size: 0x8
class :: {

  static _ formatDuration(/* No info */) {
    // ** addr: 0xdcf474, size: 0x26c
    // 0xdcf474: EnterFrame
    //     0xdcf474: stp             fp, lr, [SP, #-0x10]!
    //     0xdcf478: mov             fp, SP
    // 0xdcf47c: AllocStack(0x40)
    //     0xdcf47c: sub             SP, SP, #0x40
    // 0xdcf480: r3 = 1000
    //     0xdcf480: mov             x3, #0x3e8
    // 0xdcf484: r2 = 3600
    //     0xdcf484: mov             x2, #0xe10
    // 0xdcf488: r0 = 60
    //     0xdcf488: mov             x0, #0x3c
    // 0xdcf48c: CheckStackOverflow
    //     0xdcf48c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdcf490: cmp             SP, x16
    //     0xdcf494: b.ls            #0xdcf6c8
    // 0xdcf498: LoadField: r4 = r1->field_7
    //     0xdcf498: ldur            x4, [x1, #7]
    // 0xdcf49c: sdiv            x1, x4, x3
    // 0xdcf4a0: sdiv            x4, x1, x3
    // 0xdcf4a4: sdiv            x3, x4, x2
    // 0xdcf4a8: stur            x3, [fp, #-0x18]
    // 0xdcf4ac: sdiv            x5, x4, x2
    // 0xdcf4b0: msub            x1, x5, x2, x4
    // 0xdcf4b4: cmp             x1, xzr
    // 0xdcf4b8: b.lt            #0xdcf6d0
    // 0xdcf4bc: sdiv            x2, x1, x0
    // 0xdcf4c0: stur            x2, [fp, #-0x10]
    // 0xdcf4c4: sdiv            x5, x1, x0
    // 0xdcf4c8: msub            x4, x5, x0, x1
    // 0xdcf4cc: cmp             x4, xzr
    // 0xdcf4d0: b.lt            #0xdcf6d8
    // 0xdcf4d4: stur            x4, [fp, #-8]
    // 0xdcf4d8: cmp             x3, #0xa
    // 0xdcf4dc: b.lt            #0xdcf504
    // 0xdcf4e0: r0 = BoxInt64Instr(r3)
    //     0xdcf4e0: sbfiz           x0, x3, #1, #0x1f
    //     0xdcf4e4: cmp             x3, x0, asr #1
    //     0xdcf4e8: b.eq            #0xdcf4f4
    //     0xdcf4ec: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xdcf4f0: stur            x3, [x0, #7]
    // 0xdcf4f4: str             x0, [SP]
    // 0xdcf4f8: r0 = _interpolateSingle()
    //     0xdcf4f8: bl              #0x7e237c  ; [dart:core] _StringBase::_interpolateSingle
    // 0xdcf4fc: mov             x1, x0
    // 0xdcf500: b               #0xdcf554
    // 0xdcf504: cbnz            x3, #0xdcf514
    // 0xdcf508: r0 = "00"
    //     0xdcf508: add             x0, PP, #0x10, lsl #12  ; [pp+0x10360] "00"
    //     0xdcf50c: ldr             x0, [x0, #0x360]
    // 0xdcf510: b               #0xdcf550
    // 0xdcf514: r1 = Null
    //     0xdcf514: mov             x1, NULL
    // 0xdcf518: r2 = 4
    //     0xdcf518: mov             x2, #4
    // 0xdcf51c: r0 = AllocateArray()
    //     0xdcf51c: bl              #0x13df928  ; AllocateArrayStub
    // 0xdcf520: mov             x2, x0
    // 0xdcf524: r16 = "0"
    //     0xdcf524: ldr             x16, [PP, #0x47e8]  ; [pp+0x47e8] "0"
    // 0xdcf528: StoreField: r2->field_f = r16
    //     0xdcf528: stur            w16, [x2, #0xf]
    // 0xdcf52c: ldur            x3, [fp, #-0x18]
    // 0xdcf530: r0 = BoxInt64Instr(r3)
    //     0xdcf530: sbfiz           x0, x3, #1, #0x1f
    //     0xdcf534: cmp             x3, x0, asr #1
    //     0xdcf538: b.eq            #0xdcf544
    //     0xdcf53c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xdcf540: stur            x3, [x0, #7]
    // 0xdcf544: StoreField: r2->field_13 = r0
    //     0xdcf544: stur            w0, [x2, #0x13]
    // 0xdcf548: str             x2, [SP]
    // 0xdcf54c: r0 = _interpolate()
    //     0xdcf54c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xdcf550: mov             x1, x0
    // 0xdcf554: ldur            x0, [fp, #-0x10]
    // 0xdcf558: stur            x1, [fp, #-0x20]
    // 0xdcf55c: cmp             x0, #0xa
    // 0xdcf560: b.lt            #0xdcf578
    // 0xdcf564: lsl             x2, x0, #1
    // 0xdcf568: str             x2, [SP]
    // 0xdcf56c: r0 = _interpolateSingle()
    //     0xdcf56c: bl              #0x7e237c  ; [dart:core] _StringBase::_interpolateSingle
    // 0xdcf570: mov             x1, x0
    // 0xdcf574: b               #0xdcf5b4
    // 0xdcf578: cbnz            x0, #0xdcf588
    // 0xdcf57c: r0 = "00"
    //     0xdcf57c: add             x0, PP, #0x10, lsl #12  ; [pp+0x10360] "00"
    //     0xdcf580: ldr             x0, [x0, #0x360]
    // 0xdcf584: b               #0xdcf5b0
    // 0xdcf588: r1 = Null
    //     0xdcf588: mov             x1, NULL
    // 0xdcf58c: r2 = 4
    //     0xdcf58c: mov             x2, #4
    // 0xdcf590: r0 = AllocateArray()
    //     0xdcf590: bl              #0x13df928  ; AllocateArrayStub
    // 0xdcf594: r16 = "0"
    //     0xdcf594: ldr             x16, [PP, #0x47e8]  ; [pp+0x47e8] "0"
    // 0xdcf598: StoreField: r0->field_f = r16
    //     0xdcf598: stur            w16, [x0, #0xf]
    // 0xdcf59c: ldur            x1, [fp, #-0x10]
    // 0xdcf5a0: lsl             x2, x1, #1
    // 0xdcf5a4: StoreField: r0->field_13 = r2
    //     0xdcf5a4: stur            w2, [x0, #0x13]
    // 0xdcf5a8: str             x0, [SP]
    // 0xdcf5ac: r0 = _interpolate()
    //     0xdcf5ac: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xdcf5b0: mov             x1, x0
    // 0xdcf5b4: ldur            x0, [fp, #-8]
    // 0xdcf5b8: stur            x1, [fp, #-0x28]
    // 0xdcf5bc: cmp             x0, #0xa
    // 0xdcf5c0: b.lt            #0xdcf5d8
    // 0xdcf5c4: lsl             x2, x0, #1
    // 0xdcf5c8: str             x2, [SP]
    // 0xdcf5cc: r0 = _interpolateSingle()
    //     0xdcf5cc: bl              #0x7e237c  ; [dart:core] _StringBase::_interpolateSingle
    // 0xdcf5d0: mov             x2, x0
    // 0xdcf5d4: b               #0xdcf614
    // 0xdcf5d8: cbnz            x0, #0xdcf5e8
    // 0xdcf5dc: r0 = "00"
    //     0xdcf5dc: add             x0, PP, #0x10, lsl #12  ; [pp+0x10360] "00"
    //     0xdcf5e0: ldr             x0, [x0, #0x360]
    // 0xdcf5e4: b               #0xdcf610
    // 0xdcf5e8: r1 = Null
    //     0xdcf5e8: mov             x1, NULL
    // 0xdcf5ec: r2 = 4
    //     0xdcf5ec: mov             x2, #4
    // 0xdcf5f0: r0 = AllocateArray()
    //     0xdcf5f0: bl              #0x13df928  ; AllocateArrayStub
    // 0xdcf5f4: r16 = "0"
    //     0xdcf5f4: ldr             x16, [PP, #0x47e8]  ; [pp+0x47e8] "0"
    // 0xdcf5f8: StoreField: r0->field_f = r16
    //     0xdcf5f8: stur            w16, [x0, #0xf]
    // 0xdcf5fc: ldur            x1, [fp, #-8]
    // 0xdcf600: lsl             x2, x1, #1
    // 0xdcf604: StoreField: r0->field_13 = r2
    //     0xdcf604: stur            w2, [x0, #0x13]
    // 0xdcf608: str             x0, [SP]
    // 0xdcf60c: r0 = _interpolate()
    //     0xdcf60c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xdcf610: mov             x2, x0
    // 0xdcf614: ldur            x1, [fp, #-0x20]
    // 0xdcf618: stur            x2, [fp, #-0x30]
    // 0xdcf61c: r0 = LoadClassIdInstr(r1)
    //     0xdcf61c: ldur            x0, [x1, #-1]
    //     0xdcf620: ubfx            x0, x0, #0xc, #0x14
    // 0xdcf624: r16 = "00"
    //     0xdcf624: add             x16, PP, #0x10, lsl #12  ; [pp+0x10360] "00"
    //     0xdcf628: ldr             x16, [x16, #0x360]
    // 0xdcf62c: stp             x16, x1, [SP]
    // 0xdcf630: mov             lr, x0
    // 0xdcf634: ldr             lr, [x21, lr, lsl #3]
    // 0xdcf638: blr             lr
    // 0xdcf63c: tbnz            w0, #4, #0xdcf648
    // 0xdcf640: r4 = ""
    //     0xdcf640: ldr             x4, [PP, #0x900]  ; [pp+0x900] ""
    // 0xdcf644: b               #0xdcf678
    // 0xdcf648: ldur            x0, [fp, #-0x20]
    // 0xdcf64c: r1 = Null
    //     0xdcf64c: mov             x1, NULL
    // 0xdcf650: r2 = 4
    //     0xdcf650: mov             x2, #4
    // 0xdcf654: r0 = AllocateArray()
    //     0xdcf654: bl              #0x13df928  ; AllocateArrayStub
    // 0xdcf658: mov             x1, x0
    // 0xdcf65c: ldur            x0, [fp, #-0x20]
    // 0xdcf660: StoreField: r1->field_f = r0
    //     0xdcf660: stur            w0, [x1, #0xf]
    // 0xdcf664: r16 = ":"
    //     0xdcf664: ldr             x16, [PP, #0xdd0]  ; [pp+0xdd0] ":"
    // 0xdcf668: StoreField: r1->field_13 = r16
    //     0xdcf668: stur            w16, [x1, #0x13]
    // 0xdcf66c: str             x1, [SP]
    // 0xdcf670: r0 = _interpolate()
    //     0xdcf670: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xdcf674: mov             x4, x0
    // 0xdcf678: ldur            x3, [fp, #-0x28]
    // 0xdcf67c: ldur            x0, [fp, #-0x30]
    // 0xdcf680: stur            x4, [fp, #-0x20]
    // 0xdcf684: r1 = Null
    //     0xdcf684: mov             x1, NULL
    // 0xdcf688: r2 = 8
    //     0xdcf688: mov             x2, #8
    // 0xdcf68c: r0 = AllocateArray()
    //     0xdcf68c: bl              #0x13df928  ; AllocateArrayStub
    // 0xdcf690: mov             x1, x0
    // 0xdcf694: ldur            x0, [fp, #-0x20]
    // 0xdcf698: StoreField: r1->field_f = r0
    //     0xdcf698: stur            w0, [x1, #0xf]
    // 0xdcf69c: ldur            x0, [fp, #-0x28]
    // 0xdcf6a0: StoreField: r1->field_13 = r0
    //     0xdcf6a0: stur            w0, [x1, #0x13]
    // 0xdcf6a4: r16 = ":"
    //     0xdcf6a4: ldr             x16, [PP, #0xdd0]  ; [pp+0xdd0] ":"
    // 0xdcf6a8: ArrayStore: r1[0] = r16  ; List_4
    //     0xdcf6a8: stur            w16, [x1, #0x17]
    // 0xdcf6ac: ldur            x0, [fp, #-0x30]
    // 0xdcf6b0: StoreField: r1->field_1b = r0
    //     0xdcf6b0: stur            w0, [x1, #0x1b]
    // 0xdcf6b4: str             x1, [SP]
    // 0xdcf6b8: r0 = _interpolate()
    //     0xdcf6b8: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xdcf6bc: LeaveFrame
    //     0xdcf6bc: mov             SP, fp
    //     0xdcf6c0: ldp             fp, lr, [SP], #0x10
    // 0xdcf6c4: ret
    //     0xdcf6c4: ret             
    // 0xdcf6c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdcf6c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdcf6cc: b               #0xdcf498
    // 0xdcf6d0: add             x1, x1, x2
    // 0xdcf6d4: b               #0xdcf4bc
    // 0xdcf6d8: add             x4, x4, x0
    // 0xdcf6dc: b               #0xdcf4d4
  }
  static _ getIsBuffering(/* No info */) {
    // ** addr: 0xdd3740, size: 0x118
    // 0xdd3740: EnterFrame
    //     0xdd3740: stp             fp, lr, [SP, #-0x10]!
    //     0xdd3744: mov             fp, SP
    // 0xdd3748: AllocStack(0x18)
    //     0xdd3748: sub             SP, SP, #0x18
    // 0xdd374c: CheckStackOverflow
    //     0xdd374c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd3750: cmp             SP, x16
    //     0xdd3754: b.ls            #0xdd3850
    // 0xdd3758: LoadField: r0 = r1->field_27
    //     0xdd3758: ldur            w0, [x1, #0x27]
    // 0xdd375c: DecompressPointer r0
    //     0xdd375c: add             x0, x0, HEAP, lsl #32
    // 0xdd3760: LoadField: r1 = r0->field_23
    //     0xdd3760: ldur            w1, [x0, #0x23]
    // 0xdd3764: DecompressPointer r1
    //     0xdd3764: add             x1, x1, HEAP, lsl #32
    // 0xdd3768: tbnz            w1, #4, #0xdd3840
    // 0xdd376c: r1 = 1000
    //     0xdd376c: mov             x1, #0x3e8
    // 0xdd3770: LoadField: r2 = r0->field_b
    //     0xdd3770: ldur            w2, [x0, #0xb]
    // 0xdd3774: DecompressPointer r2
    //     0xdd3774: add             x2, x2, HEAP, lsl #32
    // 0xdd3778: LoadField: r3 = r2->field_7
    //     0xdd3778: ldur            x3, [x2, #7]
    // 0xdd377c: sdiv            x2, x3, x1
    // 0xdd3780: stur            x2, [fp, #-8]
    // 0xdd3784: LoadField: r3 = r0->field_7
    //     0xdd3784: ldur            w3, [x0, #7]
    // 0xdd3788: DecompressPointer r3
    //     0xdd3788: add             x3, x3, HEAP, lsl #32
    // 0xdd378c: LoadField: r4 = r3->field_7
    //     0xdd378c: ldur            x4, [x3, #7]
    // 0xdd3790: sdiv            x3, x4, x1
    // 0xdd3794: cmp             x2, x3
    // 0xdd3798: b.lt            #0xdd37ac
    // 0xdd379c: r0 = false
    //     0xdd379c: add             x0, NULL, #0x30  ; false
    // 0xdd37a0: LeaveFrame
    //     0xdd37a0: mov             SP, fp
    //     0xdd37a4: ldp             fp, lr, [SP], #0x10
    // 0xdd37a8: ret
    //     0xdd37a8: ret             
    // 0xdd37ac: ArrayLoad: r3 = r0[0]  ; List_4
    //     0xdd37ac: ldur            w3, [x0, #0x17]
    // 0xdd37b0: DecompressPointer r3
    //     0xdd37b0: add             x3, x3, HEAP, lsl #32
    // 0xdd37b4: r16 = <DurationRange>
    //     0xdd37b4: add             x16, PP, #0xa0, lsl #12  ; [pp+0xa0678] TypeArguments: <DurationRange>
    //     0xdd37b8: ldr             x16, [x16, #0x678]
    // 0xdd37bc: stp             x3, x16, [SP]
    // 0xdd37c0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdd37c0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdd37c4: r0 = IterableExtensions.lastOrNull()
    //     0xdd37c4: bl              #0x83e5b4  ; [dart:collection] ::IterableExtensions.lastOrNull
    // 0xdd37c8: cmp             w0, NULL
    // 0xdd37cc: b.ne            #0xdd37d8
    // 0xdd37d0: r1 = Null
    //     0xdd37d0: mov             x1, NULL
    // 0xdd37d4: b               #0xdd3804
    // 0xdd37d8: r2 = 1000
    //     0xdd37d8: mov             x2, #0x3e8
    // 0xdd37dc: LoadField: r3 = r0->field_b
    //     0xdd37dc: ldur            w3, [x0, #0xb]
    // 0xdd37e0: DecompressPointer r3
    //     0xdd37e0: add             x3, x3, HEAP, lsl #32
    // 0xdd37e4: LoadField: r4 = r3->field_7
    //     0xdd37e4: ldur            x4, [x3, #7]
    // 0xdd37e8: sdiv            x3, x4, x2
    // 0xdd37ec: r0 = BoxInt64Instr(r3)
    //     0xdd37ec: sbfiz           x0, x3, #1, #0x1f
    //     0xdd37f0: cmp             x3, x0, asr #1
    //     0xdd37f4: b.eq            #0xdd3800
    //     0xdd37f8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xdd37fc: stur            x3, [x0, #7]
    // 0xdd3800: mov             x1, x0
    // 0xdd3804: cmp             w1, NULL
    // 0xdd3808: b.ne            #0xdd3814
    // 0xdd380c: r2 = -1
    //     0xdd380c: mov             x2, #-1
    // 0xdd3810: b               #0xdd3820
    // 0xdd3814: r2 = LoadInt32Instr(r1)
    //     0xdd3814: sbfx            x2, x1, #1, #0x1f
    //     0xdd3818: tbz             w1, #0, #0xdd3820
    //     0xdd381c: ldur            x2, [x1, #7]
    // 0xdd3820: ldur            x1, [fp, #-8]
    // 0xdd3824: cmp             x1, x2
    // 0xdd3828: r16 = true
    //     0xdd3828: add             x16, NULL, #0x20  ; true
    // 0xdd382c: r17 = false
    //     0xdd382c: add             x17, NULL, #0x30  ; false
    // 0xdd3830: csel            x0, x16, x17, ge
    // 0xdd3834: LeaveFrame
    //     0xdd3834: mov             SP, fp
    //     0xdd3838: ldp             fp, lr, [SP], #0x10
    // 0xdd383c: ret
    //     0xdd383c: ret             
    // 0xdd3840: r0 = false
    //     0xdd3840: add             x0, NULL, #0x30  ; false
    // 0xdd3844: LeaveFrame
    //     0xdd3844: mov             SP, fp
    //     0xdd3848: ldp             fp, lr, [SP], #0x10
    // 0xdd384c: ret
    //     0xdd384c: ret             
    // 0xdd3850: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd3850: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd3854: b               #0xdd3758
  }
}
