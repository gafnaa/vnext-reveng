// lib: , url: package:chewie/src/center_play_button.dart

// class id: 1048627, size: 0x8
class :: {
}

// class id: 6218, size: 0x24, field offset: 0xc
//   const constructor, 
class CenterPlayButton extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfa9fbc, size: 0x204
    // 0xfa9fbc: EnterFrame
    //     0xfa9fbc: stp             fp, lr, [SP, #-0x10]!
    //     0xfa9fc0: mov             fp, SP
    // 0xfa9fc4: AllocStack(0x28)
    //     0xfa9fc4: sub             SP, SP, #0x28
    // 0xfa9fc8: SetupParameters(CenterPlayButton this /* r1 => r1, fp-0x10 */)
    //     0xfa9fc8: stur            x1, [fp, #-0x10]
    // 0xfa9fcc: LoadField: r0 = r1->field_13
    //     0xfa9fcc: ldur            w0, [x1, #0x13]
    // 0xfa9fd0: DecompressPointer r0
    //     0xfa9fd0: add             x0, x0, HEAP, lsl #32
    // 0xfa9fd4: tbnz            w0, #4, #0xfa9fe0
    // 0xfa9fd8: d0 = 1.000000
    //     0xfa9fd8: fmov            d0, #1.00000000
    // 0xfa9fdc: b               #0xfa9fe4
    // 0xfa9fe0: d0 = 0.000000
    //     0xfa9fe0: eor             v0.16b, v0.16b, v0.16b
    // 0xfa9fe4: stur            d0, [fp, #-0x28]
    // 0xfa9fe8: LoadField: r0 = r1->field_b
    //     0xfa9fe8: ldur            w0, [x1, #0xb]
    // 0xfa9fec: DecompressPointer r0
    //     0xfa9fec: add             x0, x0, HEAP, lsl #32
    // 0xfa9ff0: stur            x0, [fp, #-8]
    // 0xfa9ff4: r0 = BoxDecoration()
    //     0xfa9ff4: bl              #0x8a721c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0xfa9ff8: mov             x1, x0
    // 0xfa9ffc: ldur            x0, [fp, #-8]
    // 0xfaa000: stur            x1, [fp, #-0x18]
    // 0xfaa004: StoreField: r1->field_7 = r0
    //     0xfaa004: stur            w0, [x1, #7]
    // 0xfaa008: r0 = Instance_BoxShape
    //     0xfaa008: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1abf0] Obj!BoxShape@12c4941
    //     0xfaa00c: ldr             x0, [x0, #0xbf0]
    // 0xfaa010: StoreField: r1->field_23 = r0
    //     0xfaa010: stur            w0, [x1, #0x23]
    // 0xfaa014: ldur            x0, [fp, #-0x10]
    // 0xfaa018: LoadField: r2 = r0->field_1b
    //     0xfaa018: ldur            w2, [x0, #0x1b]
    // 0xfaa01c: DecompressPointer r2
    //     0xfaa01c: add             x2, x2, HEAP, lsl #32
    // 0xfaa020: tbnz            w2, #4, #0xfaa054
    // 0xfaa024: LoadField: r2 = r0->field_f
    //     0xfaa024: ldur            w2, [x0, #0xf]
    // 0xfaa028: DecompressPointer r2
    //     0xfaa028: add             x2, x2, HEAP, lsl #32
    // 0xfaa02c: stur            x2, [fp, #-8]
    // 0xfaa030: r0 = Icon()
    //     0xfaa030: bl              #0xd0fd5c  ; AllocateIconStub -> Icon (size=0x40)
    // 0xfaa034: mov             x1, x0
    // 0xfaa038: r0 = Instance_IconData
    //     0xfaa038: add             x0, PP, #0xd4, lsl #12  ; [pp+0xd4690] Obj!IconData@128ab91
    //     0xfaa03c: ldr             x0, [x0, #0x690]
    // 0xfaa040: StoreField: r1->field_b = r0
    //     0xfaa040: stur            w0, [x1, #0xb]
    // 0xfaa044: ldur            x0, [fp, #-8]
    // 0xfaa048: StoreField: r1->field_23 = r0
    //     0xfaa048: stur            w0, [x1, #0x23]
    // 0xfaa04c: mov             x2, x1
    // 0xfaa050: b               #0xfaa088
    // 0xfaa054: LoadField: r1 = r0->field_f
    //     0xfaa054: ldur            w1, [x0, #0xf]
    // 0xfaa058: DecompressPointer r1
    //     0xfaa058: add             x1, x1, HEAP, lsl #32
    // 0xfaa05c: stur            x1, [fp, #-0x20]
    // 0xfaa060: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xfaa060: ldur            w2, [x0, #0x17]
    // 0xfaa064: DecompressPointer r2
    //     0xfaa064: add             x2, x2, HEAP, lsl #32
    // 0xfaa068: stur            x2, [fp, #-8]
    // 0xfaa06c: r0 = AnimatedPlayPause()
    //     0xfaa06c: bl              #0xdd1040  ; AllocateAnimatedPlayPauseStub -> AnimatedPlayPause (size=0x18)
    // 0xfaa070: mov             x1, x0
    // 0xfaa074: ldur            x0, [fp, #-8]
    // 0xfaa078: StoreField: r1->field_f = r0
    //     0xfaa078: stur            w0, [x1, #0xf]
    // 0xfaa07c: ldur            x0, [fp, #-0x20]
    // 0xfaa080: StoreField: r1->field_13 = r0
    //     0xfaa080: stur            w0, [x1, #0x13]
    // 0xfaa084: mov             x2, x1
    // 0xfaa088: ldur            x0, [fp, #-0x10]
    // 0xfaa08c: ldur            d0, [fp, #-0x28]
    // 0xfaa090: ldur            x1, [fp, #-0x18]
    // 0xfaa094: stur            x2, [fp, #-0x20]
    // 0xfaa098: LoadField: r3 = r0->field_1f
    //     0xfaa098: ldur            w3, [x0, #0x1f]
    // 0xfaa09c: DecompressPointer r3
    //     0xfaa09c: add             x3, x3, HEAP, lsl #32
    // 0xfaa0a0: stur            x3, [fp, #-8]
    // 0xfaa0a4: r0 = IconButton()
    //     0xfaa0a4: bl              #0xd16288  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0xfaa0a8: mov             x1, x0
    // 0xfaa0ac: r0 = 32.000000
    //     0xfaa0ac: add             x0, PP, #0x7b, lsl #12  ; [pp+0x7b0a0] 32
    //     0xfaa0b0: ldr             x0, [x0, #0xa0]
    // 0xfaa0b4: stur            x1, [fp, #-0x10]
    // 0xfaa0b8: StoreField: r1->field_b = r0
    //     0xfaa0b8: stur            w0, [x1, #0xb]
    // 0xfaa0bc: r0 = Instance_EdgeInsets
    //     0xfaa0bc: add             x0, PP, #0x7b, lsl #12  ; [pp+0x7b208] Obj!EdgeInsets@129ce11
    //     0xfaa0c0: ldr             x0, [x0, #0x208]
    // 0xfaa0c4: StoreField: r1->field_13 = r0
    //     0xfaa0c4: stur            w0, [x1, #0x13]
    // 0xfaa0c8: ldur            x0, [fp, #-8]
    // 0xfaa0cc: StoreField: r1->field_3b = r0
    //     0xfaa0cc: stur            w0, [x1, #0x3b]
    // 0xfaa0d0: r0 = false
    //     0xfaa0d0: add             x0, NULL, #0x30  ; false
    // 0xfaa0d4: StoreField: r1->field_4f = r0
    //     0xfaa0d4: stur            w0, [x1, #0x4f]
    // 0xfaa0d8: ldur            x2, [fp, #-0x20]
    // 0xfaa0dc: StoreField: r1->field_1f = r2
    //     0xfaa0dc: stur            w2, [x1, #0x1f]
    // 0xfaa0e0: r2 = Instance__IconButtonVariant
    //     0xfaa0e0: add             x2, PP, #0x17, lsl #12  ; [pp+0x177a8] Obj!_IconButtonVariant@12c57a1
    //     0xfaa0e4: ldr             x2, [x2, #0x7a8]
    // 0xfaa0e8: StoreField: r1->field_6f = r2
    //     0xfaa0e8: stur            w2, [x1, #0x6f]
    // 0xfaa0ec: r0 = DecoratedBox()
    //     0xfaa0ec: bl              #0xd66318  ; AllocateDecoratedBoxStub -> DecoratedBox (size=0x18)
    // 0xfaa0f0: mov             x1, x0
    // 0xfaa0f4: ldur            x0, [fp, #-0x18]
    // 0xfaa0f8: stur            x1, [fp, #-8]
    // 0xfaa0fc: StoreField: r1->field_f = r0
    //     0xfaa0fc: stur            w0, [x1, #0xf]
    // 0xfaa100: r0 = Instance_DecorationPosition
    //     0xfaa100: add             x0, PP, #0x80, lsl #12  ; [pp+0x80ef0] Obj!DecorationPosition@12c4381
    //     0xfaa104: ldr             x0, [x0, #0xef0]
    // 0xfaa108: StoreField: r1->field_13 = r0
    //     0xfaa108: stur            w0, [x1, #0x13]
    // 0xfaa10c: ldur            x0, [fp, #-0x10]
    // 0xfaa110: StoreField: r1->field_b = r0
    //     0xfaa110: stur            w0, [x1, #0xb]
    // 0xfaa114: r0 = AnimatedOpacity()
    //     0xfaa114: bl              #0xd2cf50  ; AllocateAnimatedOpacityStub -> AnimatedOpacity (size=0x28)
    // 0xfaa118: mov             x1, x0
    // 0xfaa11c: ldur            x0, [fp, #-8]
    // 0xfaa120: stur            x1, [fp, #-0x10]
    // 0xfaa124: ArrayStore: r1[0] = r0  ; List_4
    //     0xfaa124: stur            w0, [x1, #0x17]
    // 0xfaa128: ldur            d0, [fp, #-0x28]
    // 0xfaa12c: StoreField: r1->field_1b = d0
    //     0xfaa12c: stur            d0, [x1, #0x1b]
    // 0xfaa130: r0 = false
    //     0xfaa130: add             x0, NULL, #0x30  ; false
    // 0xfaa134: StoreField: r1->field_23 = r0
    //     0xfaa134: stur            w0, [x1, #0x23]
    // 0xfaa138: r0 = Instance__Linear
    //     0xfaa138: ldr             x0, [PP, #0x5168]  ; [pp+0x5168] Obj!_Linear@129fef1
    // 0xfaa13c: StoreField: r1->field_b = r0
    //     0xfaa13c: stur            w0, [x1, #0xb]
    // 0xfaa140: r0 = Instance_Duration
    //     0xfaa140: ldr             x0, [PP, #0x7cd8]  ; [pp+0x7cd8] Obj!Duration@12c8971
    // 0xfaa144: StoreField: r1->field_f = r0
    //     0xfaa144: stur            w0, [x1, #0xf]
    // 0xfaa148: r0 = UnconstrainedBox()
    //     0xfaa148: bl              #0xfaa1c0  ; AllocateUnconstrainedBoxStub -> UnconstrainedBox (size=0x20)
    // 0xfaa14c: mov             x1, x0
    // 0xfaa150: ldur            x0, [fp, #-0x10]
    // 0xfaa154: stur            x1, [fp, #-8]
    // 0xfaa158: StoreField: r1->field_1b = r0
    //     0xfaa158: stur            w0, [x1, #0x1b]
    // 0xfaa15c: r0 = Instance_Alignment
    //     0xfaa15c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xfaa160: ldr             x0, [x0, #0xb80]
    // 0xfaa164: StoreField: r1->field_f = r0
    //     0xfaa164: stur            w0, [x1, #0xf]
    // 0xfaa168: r2 = Instance_Clip
    //     0xfaa168: add             x2, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xfaa16c: ldr             x2, [x2, #0x840]
    // 0xfaa170: ArrayStore: r1[0] = r2  ; List_4
    //     0xfaa170: stur            w2, [x1, #0x17]
    // 0xfaa174: r0 = Center()
    //     0xfaa174: bl              #0xd0c898  ; AllocateCenterStub -> Center (size=0x1c)
    // 0xfaa178: mov             x1, x0
    // 0xfaa17c: r0 = Instance_Alignment
    //     0xfaa17c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xfaa180: ldr             x0, [x0, #0xb80]
    // 0xfaa184: stur            x1, [fp, #-0x10]
    // 0xfaa188: StoreField: r1->field_f = r0
    //     0xfaa188: stur            w0, [x1, #0xf]
    // 0xfaa18c: ldur            x0, [fp, #-8]
    // 0xfaa190: StoreField: r1->field_b = r0
    //     0xfaa190: stur            w0, [x1, #0xb]
    // 0xfaa194: r0 = ColoredBox()
    //     0xfaa194: bl              #0xd1a914  ; AllocateColoredBoxStub -> ColoredBox (size=0x18)
    // 0xfaa198: r1 = Instance_Color
    //     0xfaa198: add             x1, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xfaa19c: ldr             x1, [x1, #0x810]
    // 0xfaa1a0: StoreField: r0->field_f = r1
    //     0xfaa1a0: stur            w1, [x0, #0xf]
    // 0xfaa1a4: r1 = true
    //     0xfaa1a4: add             x1, NULL, #0x20  ; true
    // 0xfaa1a8: StoreField: r0->field_13 = r1
    //     0xfaa1a8: stur            w1, [x0, #0x13]
    // 0xfaa1ac: ldur            x1, [fp, #-0x10]
    // 0xfaa1b0: StoreField: r0->field_b = r1
    //     0xfaa1b0: stur            w1, [x0, #0xb]
    // 0xfaa1b4: LeaveFrame
    //     0xfaa1b4: mov             SP, fp
    //     0xfaa1b8: ldp             fp, lr, [SP], #0x10
    // 0xfaa1bc: ret
    //     0xfaa1bc: ret             
  }
}
