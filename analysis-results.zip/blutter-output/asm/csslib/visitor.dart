// lib: , url: package:csslib/visitor.dart

// class id: 1048684, size: 0x8
class :: {
}

// class id: 3428, size: 0x8, field offset: 0x8
class BAD_HEX_VALUE extends Object {
}

// class id: 3429, size: 0xc, field offset: 0x8
abstract class TreeNode extends Object {
}

// class id: 3430, size: 0x14, field offset: 0xc
abstract class DartStyleExpression extends TreeNode {
}

// class id: 3431, size: 0x14, field offset: 0x14
class WidthExpression extends DartStyleExpression {

  _ visit(/* No info */) {
    // ** addr: 0xd035a0, size: 0x34
    // 0xd035a0: EnterFrame
    //     0xd035a0: stp             fp, lr, [SP, #-0x10]!
    //     0xd035a4: mov             fp, SP
    // 0xd035a8: mov             x0, x1
    // 0xd035ac: mov             x1, x2
    // 0xd035b0: CheckStackOverflow
    //     0xd035b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd035b4: cmp             SP, x16
    //     0xd035b8: b.ls            #0xd035cc
    // 0xd035bc: r0 = scale()
    //     0xd035bc: bl              #0x13114a4  ; [package:flutter/src/widgets/media_query.dart] _UnspecifiedTextScaler::scale
    // 0xd035c0: LeaveFrame
    //     0xd035c0: mov             SP, fp
    //     0xd035c4: ldp             fp, lr, [SP], #0x10
    // 0xd035c8: ret
    //     0xd035c8: ret             
    // 0xd035cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd035cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd035d0: b               #0xd035bc
  }
}

// class id: 3432, size: 0x14, field offset: 0x14
class HeightExpression extends DartStyleExpression {

  _ visit(/* No info */) {
    // ** addr: 0xd0356c, size: 0x34
    // 0xd0356c: EnterFrame
    //     0xd0356c: stp             fp, lr, [SP, #-0x10]!
    //     0xd03570: mov             fp, SP
    // 0xd03574: mov             x0, x1
    // 0xd03578: mov             x1, x2
    // 0xd0357c: CheckStackOverflow
    //     0xd0357c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd03580: cmp             SP, x16
    //     0xd03584: b.ls            #0xd03598
    // 0xd03588: r0 = scale()
    //     0xd03588: bl              #0x13114a4  ; [package:flutter/src/widgets/media_query.dart] _UnspecifiedTextScaler::scale
    // 0xd0358c: LeaveFrame
    //     0xd0358c: mov             SP, fp
    //     0xd03590: ldp             fp, lr, [SP], #0x10
    // 0xd03594: ret
    //     0xd03594: ret             
    // 0xd03598: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd03598: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0359c: b               #0xd03588
  }
}

// class id: 3433, size: 0x14, field offset: 0x14
abstract class BoxExpression extends DartStyleExpression {
}

// class id: 3434, size: 0x14, field offset: 0x14
class PaddingExpression extends BoxExpression {

  _ visit(/* No info */) {
    // ** addr: 0xd03538, size: 0x34
    // 0xd03538: EnterFrame
    //     0xd03538: stp             fp, lr, [SP, #-0x10]!
    //     0xd0353c: mov             fp, SP
    // 0xd03540: mov             x0, x1
    // 0xd03544: mov             x1, x2
    // 0xd03548: CheckStackOverflow
    //     0xd03548: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0354c: cmp             SP, x16
    //     0xd03550: b.ls            #0xd03564
    // 0xd03554: r0 = scale()
    //     0xd03554: bl              #0x13114a4  ; [package:flutter/src/widgets/media_query.dart] _UnspecifiedTextScaler::scale
    // 0xd03558: LeaveFrame
    //     0xd03558: mov             SP, fp
    //     0xd0355c: ldp             fp, lr, [SP], #0x10
    // 0xd03560: ret
    //     0xd03560: ret             
    // 0xd03564: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd03564: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd03568: b               #0xd03554
  }
}

// class id: 3435, size: 0x14, field offset: 0x14
class BorderExpression extends BoxExpression {

  _ visit(/* No info */) {
    // ** addr: 0xd03504, size: 0x34
    // 0xd03504: EnterFrame
    //     0xd03504: stp             fp, lr, [SP, #-0x10]!
    //     0xd03508: mov             fp, SP
    // 0xd0350c: mov             x0, x1
    // 0xd03510: mov             x1, x2
    // 0xd03514: CheckStackOverflow
    //     0xd03514: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd03518: cmp             SP, x16
    //     0xd0351c: b.ls            #0xd03530
    // 0xd03520: r0 = scale()
    //     0xd03520: bl              #0x13114a4  ; [package:flutter/src/widgets/media_query.dart] _UnspecifiedTextScaler::scale
    // 0xd03524: LeaveFrame
    //     0xd03524: mov             SP, fp
    //     0xd03528: ldp             fp, lr, [SP], #0x10
    // 0xd0352c: ret
    //     0xd0352c: ret             
    // 0xd03530: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd03530: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd03534: b               #0xd03520
  }
}

// class id: 3436, size: 0x14, field offset: 0x14
class MarginExpression extends BoxExpression {

  _ visit(/* No info */) {
    // ** addr: 0xd034d0, size: 0x34
    // 0xd034d0: EnterFrame
    //     0xd034d0: stp             fp, lr, [SP, #-0x10]!
    //     0xd034d4: mov             fp, SP
    // 0xd034d8: mov             x0, x1
    // 0xd034dc: mov             x1, x2
    // 0xd034e0: CheckStackOverflow
    //     0xd034e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd034e4: cmp             SP, x16
    //     0xd034e8: b.ls            #0xd034fc
    // 0xd034ec: r0 = scale()
    //     0xd034ec: bl              #0x13114a4  ; [package:flutter/src/widgets/media_query.dart] _UnspecifiedTextScaler::scale
    // 0xd034f0: LeaveFrame
    //     0xd034f0: mov             SP, fp
    //     0xd034f4: ldp             fp, lr, [SP], #0x10
    // 0xd034f8: ret
    //     0xd034f8: ret             
    // 0xd034fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd034fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd03500: b               #0xd034ec
  }
}

// class id: 3437, size: 0x18, field offset: 0x14
class FontExpression extends DartStyleExpression {

  _ visit(/* No info */) {
    // ** addr: 0xd03478, size: 0x34
    // 0xd03478: EnterFrame
    //     0xd03478: stp             fp, lr, [SP, #-0x10]!
    //     0xd0347c: mov             fp, SP
    // 0xd03480: mov             x0, x1
    // 0xd03484: mov             x1, x2
    // 0xd03488: CheckStackOverflow
    //     0xd03488: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0348c: cmp             SP, x16
    //     0xd03490: b.ls            #0xd034a4
    // 0xd03494: r0 = scale()
    //     0xd03494: bl              #0x13114a4  ; [package:flutter/src/widgets/media_query.dart] _UnspecifiedTextScaler::scale
    // 0xd03498: LeaveFrame
    //     0xd03498: mov             SP, fp
    //     0xd0349c: ldp             fp, lr, [SP], #0x10
    // 0xd034a0: ret
    //     0xd034a0: ret             
    // 0xd034a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd034a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd034a8: b               #0xd03494
  }
  _ FontExpression(/* No info */) {
    // ** addr: 0xe1ed14, size: 0x250
    // 0xe1ed14: EnterFrame
    //     0xe1ed14: stp             fp, lr, [SP, #-0x10]!
    //     0xe1ed18: mov             fp, SP
    // 0xe1ed1c: AllocStack(0x30)
    //     0xe1ed1c: sub             SP, SP, #0x30
    // 0xe1ed20: SetupParameters(FontExpression this /* r1 => r5, fp-0x28 */, dynamic _ /* r2 => r3, fp-0x30 */, {dynamic family = Null /* r6, fp-0x20 */, dynamic lineHeight = Null /* r7, fp-0x18 */, dynamic size = Null /* r2 */, dynamic weight = Null /* r4, fp-0x10 */})
    //     0xe1ed20: mov             x5, x1
    //     0xe1ed24: mov             x3, x2
    //     0xe1ed28: stur            x1, [fp, #-0x28]
    //     0xe1ed2c: stur            x2, [fp, #-0x30]
    //     0xe1ed30: ldur            w0, [x4, #0x13]
    //     0xe1ed34: ldur            w1, [x4, #0x1f]
    //     0xe1ed38: add             x1, x1, HEAP, lsl #32
    //     0xe1ed3c: add             x16, PP, #0x8a, lsl #12  ; [pp+0x8a508] "family"
    //     0xe1ed40: ldr             x16, [x16, #0x508]
    //     0xe1ed44: cmp             w1, w16
    //     0xe1ed48: b.ne            #0xe1ed6c
    //     0xe1ed4c: ldur            w1, [x4, #0x23]
    //     0xe1ed50: add             x1, x1, HEAP, lsl #32
    //     0xe1ed54: sub             w2, w0, w1
    //     0xe1ed58: add             x1, fp, w2, sxtw #2
    //     0xe1ed5c: ldr             x1, [x1, #8]
    //     0xe1ed60: mov             x6, x1
    //     0xe1ed64: mov             x1, #1
    //     0xe1ed68: b               #0xe1ed74
    //     0xe1ed6c: mov             x6, NULL
    //     0xe1ed70: mov             x1, #0
    //     0xe1ed74: stur            x6, [fp, #-0x20]
    //     0xe1ed78: lsl             x2, x1, #1
    //     0xe1ed7c: lsl             w7, w2, #1
    //     0xe1ed80: add             w8, w7, #8
    //     0xe1ed84: add             x16, x4, w8, sxtw #1
    //     0xe1ed88: ldur            w9, [x16, #0xf]
    //     0xe1ed8c: add             x9, x9, HEAP, lsl #32
    //     0xe1ed90: ldr             x16, [PP, #0x59e8]  ; [pp+0x59e8] "lineHeight"
    //     0xe1ed94: cmp             w9, w16
    //     0xe1ed98: b.ne            #0xe1edc8
    //     0xe1ed9c: add             w1, w7, #0xa
    //     0xe1eda0: add             x16, x4, w1, sxtw #1
    //     0xe1eda4: ldur            w7, [x16, #0xf]
    //     0xe1eda8: add             x7, x7, HEAP, lsl #32
    //     0xe1edac: sub             w1, w0, w7
    //     0xe1edb0: add             x7, fp, w1, sxtw #2
    //     0xe1edb4: ldr             x7, [x7, #8]
    //     0xe1edb8: add             w1, w2, #2
    //     0xe1edbc: sbfx            x2, x1, #1, #0x1f
    //     0xe1edc0: mov             x1, x2
    //     0xe1edc4: b               #0xe1edcc
    //     0xe1edc8: mov             x7, NULL
    //     0xe1edcc: stur            x7, [fp, #-0x18]
    //     0xe1edd0: lsl             x2, x1, #1
    //     0xe1edd4: lsl             w8, w2, #1
    //     0xe1edd8: add             w9, w8, #8
    //     0xe1eddc: add             x16, x4, w9, sxtw #1
    //     0xe1ede0: ldur            w10, [x16, #0xf]
    //     0xe1ede4: add             x10, x10, HEAP, lsl #32
    //     0xe1ede8: add             x16, PP, #0x22, lsl #12  ; [pp+0x22310] "size"
    //     0xe1edec: ldr             x16, [x16, #0x310]
    //     0xe1edf0: cmp             w10, w16
    //     0xe1edf4: b.ne            #0xe1ee28
    //     0xe1edf8: add             w1, w8, #0xa
    //     0xe1edfc: add             x16, x4, w1, sxtw #1
    //     0xe1ee00: ldur            w8, [x16, #0xf]
    //     0xe1ee04: add             x8, x8, HEAP, lsl #32
    //     0xe1ee08: sub             w1, w0, w8
    //     0xe1ee0c: add             x8, fp, w1, sxtw #2
    //     0xe1ee10: ldr             x8, [x8, #8]
    //     0xe1ee14: add             w1, w2, #2
    //     0xe1ee18: sbfx            x2, x1, #1, #0x1f
    //     0xe1ee1c: mov             x1, x2
    //     0xe1ee20: mov             x2, x8
    //     0xe1ee24: b               #0xe1ee2c
    //     0xe1ee28: mov             x2, NULL
    //     0xe1ee2c: lsl             x8, x1, #1
    //     0xe1ee30: lsl             w1, w8, #1
    //     0xe1ee34: add             w8, w1, #8
    //     0xe1ee38: add             x16, x4, w8, sxtw #1
    //     0xe1ee3c: ldur            w9, [x16, #0xf]
    //     0xe1ee40: add             x9, x9, HEAP, lsl #32
    //     0xe1ee44: add             x16, PP, #0x22, lsl #12  ; [pp+0x22d98] "weight"
    //     0xe1ee48: ldr             x16, [x16, #0xd98]
    //     0xe1ee4c: cmp             w9, w16
    //     0xe1ee50: b.ne            #0xe1ee78
    //     0xe1ee54: add             w8, w1, #0xa
    //     0xe1ee58: add             x16, x4, w8, sxtw #1
    //     0xe1ee5c: ldur            w1, [x16, #0xf]
    //     0xe1ee60: add             x1, x1, HEAP, lsl #32
    //     0xe1ee64: sub             w4, w0, w1
    //     0xe1ee68: add             x0, fp, w4, sxtw #2
    //     0xe1ee6c: ldr             x0, [x0, #8]
    //     0xe1ee70: mov             x4, x0
    //     0xe1ee74: b               #0xe1ee7c
    //     0xe1ee78: mov             x4, NULL
    //     0xe1ee7c: stur            x4, [fp, #-0x10]
    // 0xe1ee80: r0 = 60
    //     0xe1ee80: mov             x0, #0x3c
    // 0xe1ee84: branchIfSmi(r2, 0xe1ee90)
    //     0xe1ee84: tbz             w2, #0, #0xe1ee90
    // 0xe1ee88: r0 = LoadClassIdInstr(r2)
    //     0xe1ee88: ldur            x0, [x2, #-1]
    //     0xe1ee8c: ubfx            x0, x0, #0xc, #0x14
    // 0xe1ee90: cmp             x0, #0xdbb
    // 0xe1ee94: b.ne            #0xe1eea8
    // 0xe1ee98: LoadField: r0 = r2->field_b
    //     0xe1ee98: ldur            w0, [x2, #0xb]
    // 0xe1ee9c: DecompressPointer r0
    //     0xe1ee9c: add             x0, x0, HEAP, lsl #32
    // 0xe1eea0: mov             x8, x0
    // 0xe1eea4: b               #0xe1eeac
    // 0xe1eea8: mov             x8, x2
    // 0xe1eeac: mov             x0, x8
    // 0xe1eeb0: stur            x8, [fp, #-8]
    // 0xe1eeb4: r2 = Null
    //     0xe1eeb4: mov             x2, NULL
    // 0xe1eeb8: r1 = Null
    //     0xe1eeb8: mov             x1, NULL
    // 0xe1eebc: branchIfSmi(r0, 0xe1eee8)
    //     0xe1eebc: tbz             w0, #0, #0xe1eee8
    // 0xe1eec0: r4 = LoadClassIdInstr(r0)
    //     0xe1eec0: ldur            x4, [x0, #-1]
    //     0xe1eec4: ubfx            x4, x4, #0xc, #0x14
    // 0xe1eec8: sub             x4, x4, #0x3c
    // 0xe1eecc: cmp             x4, #2
    // 0xe1eed0: b.ls            #0xe1eee8
    // 0xe1eed4: r8 = num?
    //     0xe1eed4: add             x8, PP, #0x10, lsl #12  ; [pp+0x10430] Type: num?
    //     0xe1eed8: ldr             x8, [x8, #0x430]
    // 0xe1eedc: r3 = Null
    //     0xe1eedc: add             x3, PP, #0x8a, lsl #12  ; [pp+0x8a510] Null
    //     0xe1eee0: ldr             x3, [x3, #0x510]
    // 0xe1eee4: r0 = DefaultNullableTypeTest()
    //     0xe1eee4: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0xe1eee8: r0 = Font()
    //     0xe1eee8: bl              #0xe1ef64  ; AllocateFontStub -> Font (size=0x20)
    // 0xe1eeec: ldur            x1, [fp, #-8]
    // 0xe1eef0: StoreField: r0->field_7 = r1
    //     0xe1eef0: stur            w1, [x0, #7]
    // 0xe1eef4: ldur            x1, [fp, #-0x20]
    // 0xe1eef8: StoreField: r0->field_b = r1
    //     0xe1eef8: stur            w1, [x0, #0xb]
    // 0xe1eefc: ldur            x1, [fp, #-0x10]
    // 0xe1ef00: StoreField: r0->field_f = r1
    //     0xe1ef00: stur            w1, [x0, #0xf]
    // 0xe1ef04: ldur            x1, [fp, #-0x18]
    // 0xe1ef08: StoreField: r0->field_1b = r1
    //     0xe1ef08: stur            w1, [x0, #0x1b]
    // 0xe1ef0c: ldur            x1, [fp, #-0x28]
    // 0xe1ef10: StoreField: r1->field_13 = r0
    //     0xe1ef10: stur            w0, [x1, #0x13]
    //     0xe1ef14: ldurb           w16, [x1, #-1]
    //     0xe1ef18: ldurb           w17, [x0, #-1]
    //     0xe1ef1c: and             x16, x17, x16, lsr #2
    //     0xe1ef20: tst             x16, HEAP, lsr #32
    //     0xe1ef24: b.eq            #0xe1ef2c
    //     0xe1ef28: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xe1ef2c: r2 = 1
    //     0xe1ef2c: mov             x2, #1
    // 0xe1ef30: StoreField: r1->field_b = r2
    //     0xe1ef30: stur            x2, [x1, #0xb]
    // 0xe1ef34: ldur            x0, [fp, #-0x30]
    // 0xe1ef38: StoreField: r1->field_7 = r0
    //     0xe1ef38: stur            w0, [x1, #7]
    //     0xe1ef3c: ldurb           w16, [x1, #-1]
    //     0xe1ef40: ldurb           w17, [x0, #-1]
    //     0xe1ef44: and             x16, x17, x16, lsr #2
    //     0xe1ef48: tst             x16, HEAP, lsr #32
    //     0xe1ef4c: b.eq            #0xe1ef54
    //     0xe1ef50: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xe1ef54: r0 = Null
    //     0xe1ef54: mov             x0, NULL
    // 0xe1ef58: LeaveFrame
    //     0xe1ef58: mov             SP, fp
    //     0xe1ef5c: ldp             fp, lr, [SP], #0x10
    // 0xe1ef60: ret
    //     0xe1ef60: ret             
  }
  _ FontExpression._merge(/* No info */) {
    // ** addr: 0xe1f0b8, size: 0x9c
    // 0xe1f0b8: EnterFrame
    //     0xe1f0b8: stp             fp, lr, [SP, #-0x10]!
    //     0xe1f0bc: mov             fp, SP
    // 0xe1f0c0: AllocStack(0x10)
    //     0xe1f0c0: sub             SP, SP, #0x10
    // 0xe1f0c4: SetupParameters(FontExpression this /* r1 => r4, fp-0x8 */, dynamic _ /* r5 => r0, fp-0x10 */)
    //     0xe1f0c4: mov             x4, x1
    //     0xe1f0c8: mov             x0, x5
    //     0xe1f0cc: stur            x1, [fp, #-8]
    //     0xe1f0d0: stur            x5, [fp, #-0x10]
    // 0xe1f0d4: CheckStackOverflow
    //     0xe1f0d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe1f0d8: cmp             SP, x16
    //     0xe1f0dc: b.ls            #0xe1f14c
    // 0xe1f0e0: LoadField: r1 = r2->field_13
    //     0xe1f0e0: ldur            w1, [x2, #0x13]
    // 0xe1f0e4: DecompressPointer r1
    //     0xe1f0e4: add             x1, x1, HEAP, lsl #32
    // 0xe1f0e8: LoadField: r2 = r3->field_13
    //     0xe1f0e8: ldur            w2, [x3, #0x13]
    // 0xe1f0ec: DecompressPointer r2
    //     0xe1f0ec: add             x2, x2, HEAP, lsl #32
    // 0xe1f0f0: r0 = merge()
    //     0xe1f0f0: bl              #0xe1f154  ; [package:csslib/parser.dart] Font::merge
    // 0xe1f0f4: ldur            x1, [fp, #-8]
    // 0xe1f0f8: StoreField: r1->field_13 = r0
    //     0xe1f0f8: stur            w0, [x1, #0x13]
    //     0xe1f0fc: ldurb           w16, [x1, #-1]
    //     0xe1f100: ldurb           w17, [x0, #-1]
    //     0xe1f104: and             x16, x17, x16, lsr #2
    //     0xe1f108: tst             x16, HEAP, lsr #32
    //     0xe1f10c: b.eq            #0xe1f114
    //     0xe1f110: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xe1f114: r2 = 1
    //     0xe1f114: mov             x2, #1
    // 0xe1f118: StoreField: r1->field_b = r2
    //     0xe1f118: stur            x2, [x1, #0xb]
    // 0xe1f11c: ldur            x0, [fp, #-0x10]
    // 0xe1f120: StoreField: r1->field_7 = r0
    //     0xe1f120: stur            w0, [x1, #7]
    //     0xe1f124: ldurb           w16, [x1, #-1]
    //     0xe1f128: ldurb           w17, [x0, #-1]
    //     0xe1f12c: and             x16, x17, x16, lsr #2
    //     0xe1f130: tst             x16, HEAP, lsr #32
    //     0xe1f134: b.eq            #0xe1f13c
    //     0xe1f138: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xe1f13c: r0 = Null
    //     0xe1f13c: mov             x0, NULL
    // 0xe1f140: LeaveFrame
    //     0xe1f140: mov             SP, fp
    //     0xe1f144: ldp             fp, lr, [SP], #0x10
    // 0xe1f148: ret
    //     0xe1f148: ret             
    // 0xe1f14c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe1f14c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe1f150: b               #0xe1f0e0
  }
}

// class id: 3438, size: 0x10, field offset: 0xc
class DeclarationGroup extends TreeNode {

  _ visit(/* No info */) {
    // ** addr: 0xd0343c, size: 0x3c
    // 0xd0343c: EnterFrame
    //     0xd0343c: stp             fp, lr, [SP, #-0x10]!
    //     0xd03440: mov             fp, SP
    // 0xd03444: mov             x16, x2
    // 0xd03448: mov             x2, x1
    // 0xd0344c: mov             x1, x16
    // 0xd03450: CheckStackOverflow
    //     0xd03450: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd03454: cmp             SP, x16
    //     0xd03458: b.ls            #0xd03470
    // 0xd0345c: r0 = visitExpressions()
    //     0xd0345c: bl              #0x12ea488  ; [package:csslib/visitor.dart] Visitor::visitExpressions
    // 0xd03460: r0 = Null
    //     0xd03460: mov             x0, NULL
    // 0xd03464: LeaveFrame
    //     0xd03464: mov             SP, fp
    //     0xd03468: ldp             fp, lr, [SP], #0x10
    // 0xd0346c: ret
    //     0xd0346c: ret             
    // 0xd03470: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd03470: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd03474: b               #0xd0345c
  }
}

// class id: 3439, size: 0x10, field offset: 0x10
class MarginGroup extends DeclarationGroup {
}

// class id: 3440, size: 0x1c, field offset: 0xc
class Declaration extends TreeNode {

  _ visit(/* No info */) {
    // ** addr: 0xd033f0, size: 0x4c
    // 0xd033f0: EnterFrame
    //     0xd033f0: stp             fp, lr, [SP, #-0x10]!
    //     0xd033f4: mov             fp, SP
    // 0xd033f8: mov             x16, x2
    // 0xd033fc: mov             x2, x1
    // 0xd03400: mov             x1, x16
    // 0xd03404: CheckStackOverflow
    //     0xd03404: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd03408: cmp             SP, x16
    //     0xd0340c: b.ls            #0xd03434
    // 0xd03410: r0 = LoadClassIdInstr(r1)
    //     0xd03410: ldur            x0, [x1, #-1]
    //     0xd03414: ubfx            x0, x0, #0xc, #0x14
    // 0xd03418: r0 = GDT[cid_x0 + -0xffe]()
    //     0xd03418: sub             lr, x0, #0xffe
    //     0xd0341c: ldr             lr, [x21, lr, lsl #3]
    //     0xd03420: blr             lr
    // 0xd03424: r0 = Null
    //     0xd03424: mov             x0, NULL
    // 0xd03428: LeaveFrame
    //     0xd03428: mov             SP, fp
    //     0xd0342c: ldp             fp, lr, [SP], #0x10
    // 0xd03430: ret
    //     0xd03430: ret             
    // 0xd03434: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd03434: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd03438: b               #0xd03410
  }
  get _ property(/* No info */) {
    // ** addr: 0xe253e4, size: 0xac
    // 0xe253e4: EnterFrame
    //     0xe253e4: stp             fp, lr, [SP, #-0x10]!
    //     0xe253e8: mov             fp, SP
    // 0xe253ec: AllocStack(0x10)
    //     0xe253ec: sub             SP, SP, #0x10
    // 0xe253f0: SetupParameters(Declaration this /* r1 => r0, fp-0x8 */)
    //     0xe253f0: mov             x0, x1
    //     0xe253f4: stur            x1, [fp, #-8]
    // 0xe253f8: CheckStackOverflow
    //     0xe253f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe253fc: cmp             SP, x16
    //     0xe25400: b.ls            #0xe25480
    // 0xe25404: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xe25404: ldur            w1, [x0, #0x17]
    // 0xe25408: DecompressPointer r1
    //     0xe25408: add             x1, x1, HEAP, lsl #32
    // 0xe2540c: tbnz            w1, #4, #0xe25454
    // 0xe25410: r1 = Null
    //     0xe25410: mov             x1, NULL
    // 0xe25414: r2 = 4
    //     0xe25414: mov             x2, #4
    // 0xe25418: r0 = AllocateArray()
    //     0xe25418: bl              #0x13df928  ; AllocateArrayStub
    // 0xe2541c: r16 = "*"
    //     0xe2541c: add             x16, PP, #0x20, lsl #12  ; [pp+0x20388] "*"
    //     0xe25420: ldr             x16, [x16, #0x388]
    // 0xe25424: StoreField: r0->field_f = r16
    //     0xe25424: stur            w16, [x0, #0xf]
    // 0xe25428: ldur            x1, [fp, #-8]
    // 0xe2542c: LoadField: r2 = r1->field_b
    //     0xe2542c: ldur            w2, [x1, #0xb]
    // 0xe25430: DecompressPointer r2
    //     0xe25430: add             x2, x2, HEAP, lsl #32
    // 0xe25434: cmp             w2, NULL
    // 0xe25438: b.eq            #0xe25488
    // 0xe2543c: LoadField: r1 = r2->field_b
    //     0xe2543c: ldur            w1, [x2, #0xb]
    // 0xe25440: DecompressPointer r1
    //     0xe25440: add             x1, x1, HEAP, lsl #32
    // 0xe25444: StoreField: r0->field_13 = r1
    //     0xe25444: stur            w1, [x0, #0x13]
    // 0xe25448: str             x0, [SP]
    // 0xe2544c: r0 = _interpolate()
    //     0xe2544c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xe25450: b               #0xe25474
    // 0xe25454: mov             x1, x0
    // 0xe25458: LoadField: r2 = r1->field_b
    //     0xe25458: ldur            w2, [x1, #0xb]
    // 0xe2545c: DecompressPointer r2
    //     0xe2545c: add             x2, x2, HEAP, lsl #32
    // 0xe25460: cmp             w2, NULL
    // 0xe25464: b.eq            #0xe2548c
    // 0xe25468: LoadField: r1 = r2->field_b
    //     0xe25468: ldur            w1, [x2, #0xb]
    // 0xe2546c: DecompressPointer r1
    //     0xe2546c: add             x1, x1, HEAP, lsl #32
    // 0xe25470: mov             x0, x1
    // 0xe25474: LeaveFrame
    //     0xe25474: mov             SP, fp
    //     0xe25478: ldp             fp, lr, [SP], #0x10
    // 0xe2547c: ret
    //     0xe2547c: ret             
    // 0xe25480: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe25480: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe25484: b               #0xe25404
    // 0xe25488: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe25488: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xe2548c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe2548c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 3441, size: 0x20, field offset: 0x1c
class ExtendDeclaration extends Declaration {

  _ visit(/* No info */) {
    // ** addr: 0xd03378, size: 0x3c
    // 0xd03378: EnterFrame
    //     0xd03378: stp             fp, lr, [SP, #-0x10]!
    //     0xd0337c: mov             fp, SP
    // 0xd03380: mov             x16, x2
    // 0xd03384: mov             x2, x1
    // 0xd03388: mov             x1, x16
    // 0xd0338c: CheckStackOverflow
    //     0xd0338c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd03390: cmp             SP, x16
    //     0xd03394: b.ls            #0xd033ac
    // 0xd03398: r0 = visitExtendDeclaration()
    //     0xd03398: bl              #0xd033b4  ; [package:csslib/visitor.dart] Visitor::visitExtendDeclaration
    // 0xd0339c: r0 = Null
    //     0xd0339c: mov             x0, NULL
    // 0xd033a0: LeaveFrame
    //     0xd033a0: mov             SP, fp
    //     0xd033a4: ldp             fp, lr, [SP], #0x10
    // 0xd033a8: ret
    //     0xd033a8: ret             
    // 0xd033ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd033ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd033b0: b               #0xd03398
  }
}

// class id: 3442, size: 0x20, field offset: 0x1c
class IncludeMixinAtDeclaration extends Declaration {

  _ visit(/* No info */) {
    // ** addr: 0xd03300, size: 0x3c
    // 0xd03300: EnterFrame
    //     0xd03300: stp             fp, lr, [SP, #-0x10]!
    //     0xd03304: mov             fp, SP
    // 0xd03308: mov             x16, x2
    // 0xd0330c: mov             x2, x1
    // 0xd03310: mov             x1, x16
    // 0xd03314: CheckStackOverflow
    //     0xd03314: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd03318: cmp             SP, x16
    //     0xd0331c: b.ls            #0xd03334
    // 0xd03320: r0 = visitIncludeMixinAtDeclaration()
    //     0xd03320: bl              #0xd0333c  ; [package:csslib/visitor.dart] Visitor::visitIncludeMixinAtDeclaration
    // 0xd03324: r0 = Null
    //     0xd03324: mov             x0, NULL
    // 0xd03328: LeaveFrame
    //     0xd03328: mov             SP, fp
    //     0xd0332c: ldp             fp, lr, [SP], #0x10
    // 0xd03330: ret
    //     0xd03330: ret             
    // 0xd03334: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd03334: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd03338: b               #0xd03320
  }
}

// class id: 3443, size: 0x1c, field offset: 0x1c
class VarDefinition extends Declaration {

  _ visit(/* No info */) {
    // ** addr: 0xd032c4, size: 0x3c
    // 0xd032c4: EnterFrame
    //     0xd032c4: stp             fp, lr, [SP, #-0x10]!
    //     0xd032c8: mov             fp, SP
    // 0xd032cc: mov             x16, x2
    // 0xd032d0: mov             x2, x1
    // 0xd032d4: mov             x1, x16
    // 0xd032d8: CheckStackOverflow
    //     0xd032d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd032dc: cmp             SP, x16
    //     0xd032e0: b.ls            #0xd032f8
    // 0xd032e4: r0 = visitVarDefinition()
    //     0xd032e4: bl              #0xd02eac  ; [package:csslib/visitor.dart] Visitor::visitVarDefinition
    // 0xd032e8: r0 = Null
    //     0xd032e8: mov             x0, NULL
    // 0xd032ec: LeaveFrame
    //     0xd032ec: mov             SP, fp
    //     0xd032f0: ldp             fp, lr, [SP], #0x10
    // 0xd032f4: ret
    //     0xd032f4: ret             
    // 0xd032f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd032f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd032fc: b               #0xd032e4
  }
}

// class id: 3444, size: 0x10, field offset: 0xc
class MediaQuery extends TreeNode {

  _ visit(/* No info */) {
    // ** addr: 0xd03268, size: 0x3c
    // 0xd03268: EnterFrame
    //     0xd03268: stp             fp, lr, [SP, #-0x10]!
    //     0xd0326c: mov             fp, SP
    // 0xd03270: mov             x16, x2
    // 0xd03274: mov             x2, x1
    // 0xd03278: mov             x1, x16
    // 0xd0327c: CheckStackOverflow
    //     0xd0327c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd03280: cmp             SP, x16
    //     0xd03284: b.ls            #0xd0329c
    // 0xd03288: r0 = visitMediaQuery()
    //     0xd03288: bl              #0xd029b4  ; [package:csslib/visitor.dart] Visitor::visitMediaQuery
    // 0xd0328c: r0 = Null
    //     0xd0328c: mov             x0, NULL
    // 0xd03290: LeaveFrame
    //     0xd03290: mov             SP, fp
    //     0xd03294: ldp             fp, lr, [SP], #0x10
    // 0xd03298: ret
    //     0xd03298: ret             
    // 0xd0329c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0329c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd032a0: b               #0xd03288
  }
}

// class id: 3445, size: 0x10, field offset: 0xc
class MediaExpression extends TreeNode {

  _ visit(/* No info */) {
    // ** addr: 0xd0320c, size: 0x3c
    // 0xd0320c: EnterFrame
    //     0xd0320c: stp             fp, lr, [SP, #-0x10]!
    //     0xd03210: mov             fp, SP
    // 0xd03214: mov             x16, x2
    // 0xd03218: mov             x2, x1
    // 0xd0321c: mov             x1, x16
    // 0xd03220: CheckStackOverflow
    //     0xd03220: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd03224: cmp             SP, x16
    //     0xd03228: b.ls            #0xd03240
    // 0xd0322c: r0 = visitMediaExpression()
    //     0xd0322c: bl              #0xd02b10  ; [package:csslib/visitor.dart] Visitor::visitMediaExpression
    // 0xd03230: r0 = Null
    //     0xd03230: mov             x0, NULL
    // 0xd03234: LeaveFrame
    //     0xd03234: mov             SP, fp
    //     0xd03238: ldp             fp, lr, [SP], #0x10
    // 0xd0323c: ret
    //     0xd0323c: ret             
    // 0xd03240: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd03240: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd03244: b               #0xd0322c
  }
}

// class id: 3446, size: 0xc, field offset: 0xc
abstract class SupportsCondition extends TreeNode {
}

// class id: 3447, size: 0x10, field offset: 0xc
class SupportsDisjunction extends SupportsCondition {

  _ visit(/* No info */) {
    // ** addr: 0xd031d0, size: 0x3c
    // 0xd031d0: EnterFrame
    //     0xd031d0: stp             fp, lr, [SP, #-0x10]!
    //     0xd031d4: mov             fp, SP
    // 0xd031d8: mov             x16, x2
    // 0xd031dc: mov             x2, x1
    // 0xd031e0: mov             x1, x16
    // 0xd031e4: CheckStackOverflow
    //     0xd031e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd031e8: cmp             SP, x16
    //     0xd031ec: b.ls            #0xd03204
    // 0xd031f0: r0 = visitExpressions()
    //     0xd031f0: bl              #0x12ea488  ; [package:csslib/visitor.dart] Visitor::visitExpressions
    // 0xd031f4: r0 = Null
    //     0xd031f4: mov             x0, NULL
    // 0xd031f8: LeaveFrame
    //     0xd031f8: mov             SP, fp
    //     0xd031fc: ldp             fp, lr, [SP], #0x10
    // 0xd03200: ret
    //     0xd03200: ret             
    // 0xd03204: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd03204: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd03208: b               #0xd031f0
  }
}

// class id: 3448, size: 0x10, field offset: 0xc
class SupportsConjunction extends SupportsCondition {

  _ visit(/* No info */) {
    // ** addr: 0xd03194, size: 0x3c
    // 0xd03194: EnterFrame
    //     0xd03194: stp             fp, lr, [SP, #-0x10]!
    //     0xd03198: mov             fp, SP
    // 0xd0319c: mov             x16, x2
    // 0xd031a0: mov             x2, x1
    // 0xd031a4: mov             x1, x16
    // 0xd031a8: CheckStackOverflow
    //     0xd031a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd031ac: cmp             SP, x16
    //     0xd031b0: b.ls            #0xd031c8
    // 0xd031b4: r0 = visitExpressions()
    //     0xd031b4: bl              #0x12ea488  ; [package:csslib/visitor.dart] Visitor::visitExpressions
    // 0xd031b8: r0 = Null
    //     0xd031b8: mov             x0, NULL
    // 0xd031bc: LeaveFrame
    //     0xd031bc: mov             SP, fp
    //     0xd031c0: ldp             fp, lr, [SP], #0x10
    // 0xd031c4: ret
    //     0xd031c4: ret             
    // 0xd031c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd031c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd031cc: b               #0xd031b4
  }
}

// class id: 3449, size: 0x10, field offset: 0xc
class SupportsNegation extends SupportsCondition {

  _ visit(/* No info */) {
    // ** addr: 0xd03158, size: 0x3c
    // 0xd03158: EnterFrame
    //     0xd03158: stp             fp, lr, [SP, #-0x10]!
    //     0xd0315c: mov             fp, SP
    // 0xd03160: mov             x16, x2
    // 0xd03164: mov             x2, x1
    // 0xd03168: mov             x1, x16
    // 0xd0316c: CheckStackOverflow
    //     0xd0316c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd03170: cmp             SP, x16
    //     0xd03174: b.ls            #0xd0318c
    // 0xd03178: r0 = visitSupportsNegation()
    //     0xd03178: bl              #0xd027c4  ; [package:csslib/visitor.dart] Visitor::visitSupportsNegation
    // 0xd0317c: r0 = Null
    //     0xd0317c: mov             x0, NULL
    // 0xd03180: LeaveFrame
    //     0xd03180: mov             SP, fp
    //     0xd03184: ldp             fp, lr, [SP], #0x10
    // 0xd03188: ret
    //     0xd03188: ret             
    // 0xd0318c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0318c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd03190: b               #0xd03178
  }
}

// class id: 3450, size: 0x10, field offset: 0xc
class SupportsConditionInParens extends SupportsCondition {

  _ visit(/* No info */) {
    // ** addr: 0xd0311c, size: 0x3c
    // 0xd0311c: EnterFrame
    //     0xd0311c: stp             fp, lr, [SP, #-0x10]!
    //     0xd03120: mov             fp, SP
    // 0xd03124: mov             x16, x2
    // 0xd03128: mov             x2, x1
    // 0xd0312c: mov             x1, x16
    // 0xd03130: CheckStackOverflow
    //     0xd03130: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd03134: cmp             SP, x16
    //     0xd03138: b.ls            #0xd03150
    // 0xd0313c: r0 = visitSupportsConditionInParens()
    //     0xd0313c: bl              #0xd0275c  ; [package:csslib/visitor.dart] Visitor::visitSupportsConditionInParens
    // 0xd03140: r0 = Null
    //     0xd03140: mov             x0, NULL
    // 0xd03144: LeaveFrame
    //     0xd03144: mov             SP, fp
    //     0xd03148: ldp             fp, lr, [SP], #0x10
    // 0xd0314c: ret
    //     0xd0314c: ret             
    // 0xd03150: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd03150: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd03154: b               #0xd0313c
  }
}

// class id: 3451, size: 0xc, field offset: 0xc
abstract class Directive extends TreeNode {
}

// class id: 3452, size: 0x10, field offset: 0xc
class IncludeDirective extends Directive {

  _ visit(/* No info */) {
    // ** addr: 0xd02f80, size: 0x3c
    // 0xd02f80: EnterFrame
    //     0xd02f80: stp             fp, lr, [SP, #-0x10]!
    //     0xd02f84: mov             fp, SP
    // 0xd02f88: mov             x16, x2
    // 0xd02f8c: mov             x2, x1
    // 0xd02f90: mov             x1, x16
    // 0xd02f94: CheckStackOverflow
    //     0xd02f94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd02f98: cmp             SP, x16
    //     0xd02f9c: b.ls            #0xd02fb4
    // 0xd02fa0: r0 = visitIncludeDirective()
    //     0xd02fa0: bl              #0xd02fbc  ; [package:csslib/visitor.dart] Visitor::visitIncludeDirective
    // 0xd02fa4: r0 = Null
    //     0xd02fa4: mov             x0, NULL
    // 0xd02fa8: LeaveFrame
    //     0xd02fa8: mov             SP, fp
    //     0xd02fac: ldp             fp, lr, [SP], #0x10
    // 0xd02fb0: ret
    //     0xd02fb0: ret             
    // 0xd02fb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd02fb4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd02fb8: b               #0xd02fa0
  }
}

// class id: 3453, size: 0xc, field offset: 0xc
abstract class MixinDefinition extends Directive {
}

// class id: 3454, size: 0x10, field offset: 0xc
class MixinDeclarationDirective extends MixinDefinition {

  _ visit(/* No info */) {
    // ** addr: 0xd02f44, size: 0x3c
    // 0xd02f44: EnterFrame
    //     0xd02f44: stp             fp, lr, [SP, #-0x10]!
    //     0xd02f48: mov             fp, SP
    // 0xd02f4c: mov             x16, x2
    // 0xd02f50: mov             x2, x1
    // 0xd02f54: mov             x1, x16
    // 0xd02f58: CheckStackOverflow
    //     0xd02f58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd02f5c: cmp             SP, x16
    //     0xd02f60: b.ls            #0xd02f78
    // 0xd02f64: r0 = visitViewportDirective()
    //     0xd02f64: bl              #0xd0283c  ; [package:csslib/visitor.dart] Visitor::visitViewportDirective
    // 0xd02f68: r0 = Null
    //     0xd02f68: mov             x0, NULL
    // 0xd02f6c: LeaveFrame
    //     0xd02f6c: mov             SP, fp
    //     0xd02f70: ldp             fp, lr, [SP], #0x10
    // 0xd02f74: ret
    //     0xd02f74: ret             
    // 0xd02f78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd02f78: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd02f7c: b               #0xd02f64
  }
}

// class id: 3455, size: 0x10, field offset: 0xc
class MixinRulesetDirective extends MixinDefinition {

  _ visit(/* No info */) {
    // ** addr: 0xd02f08, size: 0x3c
    // 0xd02f08: EnterFrame
    //     0xd02f08: stp             fp, lr, [SP, #-0x10]!
    //     0xd02f0c: mov             fp, SP
    // 0xd02f10: mov             x16, x2
    // 0xd02f14: mov             x2, x1
    // 0xd02f18: mov             x1, x16
    // 0xd02f1c: CheckStackOverflow
    //     0xd02f1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd02f20: cmp             SP, x16
    //     0xd02f24: b.ls            #0xd02f3c
    // 0xd02f28: r0 = visitExpressions()
    //     0xd02f28: bl              #0x12ea488  ; [package:csslib/visitor.dart] Visitor::visitExpressions
    // 0xd02f2c: r0 = Null
    //     0xd02f2c: mov             x0, NULL
    // 0xd02f30: LeaveFrame
    //     0xd02f30: mov             SP, fp
    //     0xd02f34: ldp             fp, lr, [SP], #0x10
    // 0xd02f38: ret
    //     0xd02f38: ret             
    // 0xd02f3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd02f3c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd02f40: b               #0xd02f28
  }
}

// class id: 3456, size: 0x10, field offset: 0xc
class VarDefinitionDirective extends Directive {

  _ visit(/* No info */) {
    // ** addr: 0xd02e34, size: 0x3c
    // 0xd02e34: EnterFrame
    //     0xd02e34: stp             fp, lr, [SP, #-0x10]!
    //     0xd02e38: mov             fp, SP
    // 0xd02e3c: mov             x16, x2
    // 0xd02e40: mov             x2, x1
    // 0xd02e44: mov             x1, x16
    // 0xd02e48: CheckStackOverflow
    //     0xd02e48: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd02e4c: cmp             SP, x16
    //     0xd02e50: b.ls            #0xd02e68
    // 0xd02e54: r0 = visitVarDefinitionDirective()
    //     0xd02e54: bl              #0xd02e70  ; [package:csslib/visitor.dart] Visitor::visitVarDefinitionDirective
    // 0xd02e58: r0 = Null
    //     0xd02e58: mov             x0, NULL
    // 0xd02e5c: LeaveFrame
    //     0xd02e5c: mov             SP, fp
    //     0xd02e60: ldp             fp, lr, [SP], #0x10
    // 0xd02e64: ret
    //     0xd02e64: ret             
    // 0xd02e68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd02e68: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd02e6c: b               #0xd02e54
  }
}

// class id: 3457, size: 0xc, field offset: 0xc
class NamespaceDirective extends Directive {
}

// class id: 3459, size: 0x10, field offset: 0xc
class FontFaceDirective extends Directive {

  _ visit(/* No info */) {
    // ** addr: 0xd02df8, size: 0x3c
    // 0xd02df8: EnterFrame
    //     0xd02df8: stp             fp, lr, [SP, #-0x10]!
    //     0xd02dfc: mov             fp, SP
    // 0xd02e00: mov             x16, x2
    // 0xd02e04: mov             x2, x1
    // 0xd02e08: mov             x1, x16
    // 0xd02e0c: CheckStackOverflow
    //     0xd02e0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd02e10: cmp             SP, x16
    //     0xd02e14: b.ls            #0xd02e2c
    // 0xd02e18: r0 = visitViewportDirective()
    //     0xd02e18: bl              #0xd0283c  ; [package:csslib/visitor.dart] Visitor::visitViewportDirective
    // 0xd02e1c: r0 = Null
    //     0xd02e1c: mov             x0, NULL
    // 0xd02e20: LeaveFrame
    //     0xd02e20: mov             SP, fp
    //     0xd02e24: ldp             fp, lr, [SP], #0x10
    // 0xd02e28: ret
    //     0xd02e28: ret             
    // 0xd02e2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd02e2c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd02e30: b               #0xd02e18
  }
}

// class id: 3460, size: 0x14, field offset: 0xc
class KeyFrameDirective extends Directive {

  _ visit(/* No info */) {
    // ** addr: 0xd02d6c, size: 0x3c
    // 0xd02d6c: EnterFrame
    //     0xd02d6c: stp             fp, lr, [SP, #-0x10]!
    //     0xd02d70: mov             fp, SP
    // 0xd02d74: mov             x16, x2
    // 0xd02d78: mov             x2, x1
    // 0xd02d7c: mov             x1, x16
    // 0xd02d80: CheckStackOverflow
    //     0xd02d80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd02d84: cmp             SP, x16
    //     0xd02d88: b.ls            #0xd02da0
    // 0xd02d8c: r0 = visitKeyFrameDirective()
    //     0xd02d8c: bl              #0xd02da8  ; [package:csslib/visitor.dart] Visitor::visitKeyFrameDirective
    // 0xd02d90: r0 = Null
    //     0xd02d90: mov             x0, NULL
    // 0xd02d94: LeaveFrame
    //     0xd02d94: mov             SP, fp
    //     0xd02d98: ldp             fp, lr, [SP], #0x10
    // 0xd02d9c: ret
    //     0xd02d9c: ret             
    // 0xd02da0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd02da0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd02da4: b               #0xd02d8c
  }
}

// class id: 3461, size: 0xc, field offset: 0xc
class CharsetDirective extends Directive {
}

// class id: 3462, size: 0x10, field offset: 0xc
class PageDirective extends Directive {

  _ visit(/* No info */) {
    // ** addr: 0xd02c30, size: 0x3c
    // 0xd02c30: EnterFrame
    //     0xd02c30: stp             fp, lr, [SP, #-0x10]!
    //     0xd02c34: mov             fp, SP
    // 0xd02c38: mov             x16, x2
    // 0xd02c3c: mov             x2, x1
    // 0xd02c40: mov             x1, x16
    // 0xd02c44: CheckStackOverflow
    //     0xd02c44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd02c48: cmp             SP, x16
    //     0xd02c4c: b.ls            #0xd02c64
    // 0xd02c50: r0 = visitPageDirective()
    //     0xd02c50: bl              #0xd02c6c  ; [package:csslib/visitor.dart] Visitor::visitPageDirective
    // 0xd02c54: r0 = Null
    //     0xd02c54: mov             x0, NULL
    // 0xd02c58: LeaveFrame
    //     0xd02c58: mov             SP, fp
    //     0xd02c5c: ldp             fp, lr, [SP], #0x10
    // 0xd02c60: ret
    //     0xd02c60: ret             
    // 0xd02c64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd02c64: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd02c68: b               #0xd02c50
  }
}

// class id: 3463, size: 0x10, field offset: 0xc
class HostDirective extends Directive {

  _ visit(/* No info */) {
    // ** addr: 0xd02bf4, size: 0x3c
    // 0xd02bf4: EnterFrame
    //     0xd02bf4: stp             fp, lr, [SP, #-0x10]!
    //     0xd02bf8: mov             fp, SP
    // 0xd02bfc: mov             x16, x2
    // 0xd02c00: mov             x2, x1
    // 0xd02c04: mov             x1, x16
    // 0xd02c08: CheckStackOverflow
    //     0xd02c08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd02c0c: cmp             SP, x16
    //     0xd02c10: b.ls            #0xd02c28
    // 0xd02c14: r0 = visitExpressions()
    //     0xd02c14: bl              #0x12ea488  ; [package:csslib/visitor.dart] Visitor::visitExpressions
    // 0xd02c18: r0 = Null
    //     0xd02c18: mov             x0, NULL
    // 0xd02c1c: LeaveFrame
    //     0xd02c1c: mov             SP, fp
    //     0xd02c20: ldp             fp, lr, [SP], #0x10
    // 0xd02c24: ret
    //     0xd02c24: ret             
    // 0xd02c28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd02c28: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd02c2c: b               #0xd02c14
  }
}

// class id: 3464, size: 0x14, field offset: 0xc
class MediaDirective extends Directive {

  _ visit(/* No info */) {
    // ** addr: 0xd02bb8, size: 0x3c
    // 0xd02bb8: EnterFrame
    //     0xd02bb8: stp             fp, lr, [SP, #-0x10]!
    //     0xd02bbc: mov             fp, SP
    // 0xd02bc0: mov             x16, x2
    // 0xd02bc4: mov             x2, x1
    // 0xd02bc8: mov             x1, x16
    // 0xd02bcc: CheckStackOverflow
    //     0xd02bcc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd02bd0: cmp             SP, x16
    //     0xd02bd4: b.ls            #0xd02bec
    // 0xd02bd8: r0 = visitDocumentDirective()
    //     0xd02bd8: bl              #0xd025e8  ; [package:csslib/visitor.dart] Visitor::visitDocumentDirective
    // 0xd02bdc: r0 = Null
    //     0xd02bdc: mov             x0, NULL
    // 0xd02be0: LeaveFrame
    //     0xd02be0: mov             SP, fp
    //     0xd02be4: ldp             fp, lr, [SP], #0x10
    // 0xd02be8: ret
    //     0xd02be8: ret             
    // 0xd02bec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd02bec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd02bf0: b               #0xd02bd8
  }
}

// class id: 3465, size: 0x10, field offset: 0xc
class ImportDirective extends Directive {

  _ visit(/* No info */) {
    // ** addr: 0xd0289c, size: 0x3c
    // 0xd0289c: EnterFrame
    //     0xd0289c: stp             fp, lr, [SP, #-0x10]!
    //     0xd028a0: mov             fp, SP
    // 0xd028a4: mov             x16, x2
    // 0xd028a8: mov             x2, x1
    // 0xd028ac: mov             x1, x16
    // 0xd028b0: CheckStackOverflow
    //     0xd028b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd028b4: cmp             SP, x16
    //     0xd028b8: b.ls            #0xd028d0
    // 0xd028bc: r0 = visitImportDirective()
    //     0xd028bc: bl              #0xd028d8  ; [package:csslib/visitor.dart] Visitor::visitImportDirective
    // 0xd028c0: r0 = Null
    //     0xd028c0: mov             x0, NULL
    // 0xd028c4: LeaveFrame
    //     0xd028c4: mov             SP, fp
    //     0xd028c8: ldp             fp, lr, [SP], #0x10
    // 0xd028cc: ret
    //     0xd028cc: ret             
    // 0xd028d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd028d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd028d4: b               #0xd028bc
  }
}

// class id: 3466, size: 0x10, field offset: 0xc
class ViewportDirective extends Directive {

  _ visit(/* No info */) {
    // ** addr: 0xd02800, size: 0x3c
    // 0xd02800: EnterFrame
    //     0xd02800: stp             fp, lr, [SP, #-0x10]!
    //     0xd02804: mov             fp, SP
    // 0xd02808: mov             x16, x2
    // 0xd0280c: mov             x2, x1
    // 0xd02810: mov             x1, x16
    // 0xd02814: CheckStackOverflow
    //     0xd02814: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd02818: cmp             SP, x16
    //     0xd0281c: b.ls            #0xd02834
    // 0xd02820: r0 = visitViewportDirective()
    //     0xd02820: bl              #0xd0283c  ; [package:csslib/visitor.dart] Visitor::visitViewportDirective
    // 0xd02824: r0 = Null
    //     0xd02824: mov             x0, NULL
    // 0xd02828: LeaveFrame
    //     0xd02828: mov             SP, fp
    //     0xd0282c: ldp             fp, lr, [SP], #0x10
    // 0xd02830: ret
    //     0xd02830: ret             
    // 0xd02834: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd02834: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd02838: b               #0xd02820
  }
}

// class id: 3467, size: 0x14, field offset: 0xc
class SupportsDirective extends Directive {

  _ visit(/* No info */) {
    // ** addr: 0xd0264c, size: 0x3c
    // 0xd0264c: EnterFrame
    //     0xd0264c: stp             fp, lr, [SP, #-0x10]!
    //     0xd02650: mov             fp, SP
    // 0xd02654: mov             x16, x2
    // 0xd02658: mov             x2, x1
    // 0xd0265c: mov             x1, x16
    // 0xd02660: CheckStackOverflow
    //     0xd02660: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd02664: cmp             SP, x16
    //     0xd02668: b.ls            #0xd02680
    // 0xd0266c: r0 = visitSupportsDirective()
    //     0xd0266c: bl              #0xd02688  ; [package:csslib/visitor.dart] Visitor::visitSupportsDirective
    // 0xd02670: r0 = Null
    //     0xd02670: mov             x0, NULL
    // 0xd02674: LeaveFrame
    //     0xd02674: mov             SP, fp
    //     0xd02678: ldp             fp, lr, [SP], #0x10
    // 0xd0267c: ret
    //     0xd0267c: ret             
    // 0xd02680: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd02680: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd02684: b               #0xd0266c
  }
}

// class id: 3468, size: 0x14, field offset: 0xc
class DocumentDirective extends Directive {

  _ visit(/* No info */) {
    // ** addr: 0xd025ac, size: 0x3c
    // 0xd025ac: EnterFrame
    //     0xd025ac: stp             fp, lr, [SP, #-0x10]!
    //     0xd025b0: mov             fp, SP
    // 0xd025b4: mov             x16, x2
    // 0xd025b8: mov             x2, x1
    // 0xd025bc: mov             x1, x16
    // 0xd025c0: CheckStackOverflow
    //     0xd025c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd025c4: cmp             SP, x16
    //     0xd025c8: b.ls            #0xd025e0
    // 0xd025cc: r0 = visitDocumentDirective()
    //     0xd025cc: bl              #0xd025e8  ; [package:csslib/visitor.dart] Visitor::visitDocumentDirective
    // 0xd025d0: r0 = Null
    //     0xd025d0: mov             x0, NULL
    // 0xd025d4: LeaveFrame
    //     0xd025d4: mov             SP, fp
    //     0xd025d8: ldp             fp, lr, [SP], #0x10
    // 0xd025dc: ret
    //     0xd025dc: ret             
    // 0xd025e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd025e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd025e4: b               #0xd025cc
  }
}

// class id: 3469, size: 0xc, field offset: 0xc
abstract class TopLevelProduction extends TreeNode {
}

// class id: 3470, size: 0x14, field offset: 0xc
class RuleSet extends TopLevelProduction {

  _ visit(/* No info */) {
    // ** addr: 0xd0250c, size: 0x3c
    // 0xd0250c: EnterFrame
    //     0xd0250c: stp             fp, lr, [SP, #-0x10]!
    //     0xd02510: mov             fp, SP
    // 0xd02514: mov             x16, x2
    // 0xd02518: mov             x2, x1
    // 0xd0251c: mov             x1, x16
    // 0xd02520: CheckStackOverflow
    //     0xd02520: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd02524: cmp             SP, x16
    //     0xd02528: b.ls            #0xd02540
    // 0xd0252c: r0 = visitRuleSet()
    //     0xd0252c: bl              #0xd02548  ; [package:csslib/visitor.dart] Visitor::visitRuleSet
    // 0xd02530: r0 = Null
    //     0xd02530: mov             x0, NULL
    // 0xd02534: LeaveFrame
    //     0xd02534: mov             SP, fp
    //     0xd02538: ldp             fp, lr, [SP], #0x10
    // 0xd0253c: ret
    //     0xd0253c: ret             
    // 0xd02540: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd02540: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd02544: b               #0xd0252c
  }
}

// class id: 3471, size: 0x10, field offset: 0xc
class StyleSheet extends TreeNode {

  _ visit(/* No info */) {
    // ** addr: 0xd024d0, size: 0x3c
    // 0xd024d0: EnterFrame
    //     0xd024d0: stp             fp, lr, [SP, #-0x10]!
    //     0xd024d4: mov             fp, SP
    // 0xd024d8: mov             x16, x2
    // 0xd024dc: mov             x2, x1
    // 0xd024e0: mov             x1, x16
    // 0xd024e4: CheckStackOverflow
    //     0xd024e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd024e8: cmp             SP, x16
    //     0xd024ec: b.ls            #0xd02504
    // 0xd024f0: r0 = visitExpressions()
    //     0xd024f0: bl              #0x12ea488  ; [package:csslib/visitor.dart] Visitor::visitExpressions
    // 0xd024f4: r0 = Null
    //     0xd024f4: mov             x0, NULL
    // 0xd024f8: LeaveFrame
    //     0xd024f8: mov             SP, fp
    //     0xd024fc: ldp             fp, lr, [SP], #0x10
    // 0xd02500: ret
    //     0xd02500: ret             
    // 0xd02504: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd02504: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd02508: b               #0xd024f0
  }
  _ StyleSheet(/* No info */) {
    // ** addr: 0xe13c38, size: 0x98
    // 0xe13c38: EnterFrame
    //     0xe13c38: stp             fp, lr, [SP, #-0x10]!
    //     0xe13c3c: mov             fp, SP
    // 0xe13c40: mov             x0, x2
    // 0xe13c44: mov             x16, x3
    // 0xe13c48: mov             x3, x1
    // 0xe13c4c: mov             x1, x16
    // 0xe13c50: StoreField: r3->field_b = r0
    //     0xe13c50: stur            w0, [x3, #0xb]
    //     0xe13c54: ldurb           w16, [x3, #-1]
    //     0xe13c58: ldurb           w17, [x0, #-1]
    //     0xe13c5c: and             x16, x17, x16, lsr #2
    //     0xe13c60: tst             x16, HEAP, lsr #32
    //     0xe13c64: b.eq            #0xe13c6c
    //     0xe13c68: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xe13c6c: mov             x0, x1
    // 0xe13c70: StoreField: r3->field_7 = r0
    //     0xe13c70: stur            w0, [x3, #7]
    //     0xe13c74: ldurb           w16, [x3, #-1]
    //     0xe13c78: ldurb           w17, [x0, #-1]
    //     0xe13c7c: and             x16, x17, x16, lsr #2
    //     0xe13c80: tst             x16, HEAP, lsr #32
    //     0xe13c84: b.eq            #0xe13c8c
    //     0xe13c88: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xe13c8c: LoadField: r1 = r2->field_b
    //     0xe13c8c: ldur            w1, [x2, #0xb]
    // 0xe13c90: r2 = LoadInt32Instr(r1)
    //     0xe13c90: sbfx            x2, x1, #1, #0x1f
    // 0xe13c94: r1 = 0
    //     0xe13c94: mov             x1, #0
    // 0xe13c98: CheckStackOverflow
    //     0xe13c98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe13c9c: cmp             SP, x16
    //     0xe13ca0: b.ls            #0xe13cc8
    // 0xe13ca4: cmp             x1, x2
    // 0xe13ca8: b.ge            #0xe13cb8
    // 0xe13cac: add             x0, x1, #1
    // 0xe13cb0: mov             x1, x0
    // 0xe13cb4: b               #0xe13c98
    // 0xe13cb8: r0 = Null
    //     0xe13cb8: mov             x0, NULL
    // 0xe13cbc: LeaveFrame
    //     0xe13cbc: mov             SP, fp
    //     0xe13cc0: ldp             fp, lr, [SP], #0x10
    // 0xe13cc4: ret
    //     0xe13cc4: ret             
    // 0xe13cc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe13cc8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe13ccc: b               #0xe13ca4
  }
}

// class id: 3472, size: 0x10, field offset: 0xc
class SelectorExpression extends TreeNode {

  _ visit(/* No info */) {
    // ** addr: 0xd02494, size: 0x3c
    // 0xd02494: EnterFrame
    //     0xd02494: stp             fp, lr, [SP, #-0x10]!
    //     0xd02498: mov             fp, SP
    // 0xd0249c: mov             x16, x2
    // 0xd024a0: mov             x2, x1
    // 0xd024a4: mov             x1, x16
    // 0xd024a8: CheckStackOverflow
    //     0xd024a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd024ac: cmp             SP, x16
    //     0xd024b0: b.ls            #0xd024c8
    // 0xd024b4: r0 = visitExpressions()
    //     0xd024b4: bl              #0x12ea488  ; [package:csslib/visitor.dart] Visitor::visitExpressions
    // 0xd024b8: r0 = Null
    //     0xd024b8: mov             x0, NULL
    // 0xd024bc: LeaveFrame
    //     0xd024bc: mov             SP, fp
    //     0xd024c0: ldp             fp, lr, [SP], #0x10
    // 0xd024c4: ret
    //     0xd024c4: ret             
    // 0xd024c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd024c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd024cc: b               #0xd024b4
  }
}

// class id: 3473, size: 0x10, field offset: 0xc
abstract class SimpleSelector extends TreeNode {

  String dyn:get:name(SimpleSelector) {
    // ** addr: 0xd020e8, size: 0xac
    // 0xd020e8: EnterFrame
    //     0xd020e8: stp             fp, lr, [SP, #-0x10]!
    //     0xd020ec: mov             fp, SP
    // 0xd020f0: AllocStack(0x10)
    //     0xd020f0: sub             SP, SP, #0x10
    // 0xd020f4: CheckStackOverflow
    //     0xd020f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd020f8: cmp             SP, x16
    //     0xd020fc: b.ls            #0xd02174
    // 0xd02100: ldr             x0, [fp, #0x10]
    // 0xd02104: LoadField: r1 = r0->field_b
    //     0xd02104: ldur            w1, [x0, #0xb]
    // 0xd02108: DecompressPointer r1
    //     0xd02108: add             x1, x1, HEAP, lsl #32
    // 0xd0210c: str             x1, [SP]
    // 0xd02110: r4 = 0
    //     0xd02110: mov             x4, #0
    // 0xd02114: ldr             x0, [SP]
    // 0xd02118: r16 = 139822029843448
    //     0xd02118: add             x16, PP, #0x8a, lsl #12  ; [pp+0x8afc0] IMM: 0x7f2ada6babf8
    //     0xd0211c: add             x16, x16, #0xfc0
    // 0xd02120: ldp             lr, x5, [x16]
    // 0xd02124: blr             lr
    // 0xd02128: mov             x3, x0
    // 0xd0212c: r2 = Null
    //     0xd0212c: mov             x2, NULL
    // 0xd02130: r1 = Null
    //     0xd02130: mov             x1, NULL
    // 0xd02134: stur            x3, [fp, #-8]
    // 0xd02138: r4 = 60
    //     0xd02138: mov             x4, #0x3c
    // 0xd0213c: branchIfSmi(r0, 0xd02148)
    //     0xd0213c: tbz             w0, #0, #0xd02148
    // 0xd02140: r4 = LoadClassIdInstr(r0)
    //     0xd02140: ldur            x4, [x0, #-1]
    //     0xd02144: ubfx            x4, x4, #0xc, #0x14
    // 0xd02148: sub             x4, x4, #0x5e
    // 0xd0214c: cmp             x4, #1
    // 0xd02150: b.ls            #0xd02164
    // 0xd02154: r8 = String
    //     0xd02154: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0xd02158: r3 = Null
    //     0xd02158: add             x3, PP, #0x8a, lsl #12  ; [pp+0x8afd0] Null
    //     0xd0215c: ldr             x3, [x3, #0xfd0]
    // 0xd02160: r0 = String()
    //     0xd02160: bl              #0x13ee320  ; IsType_String_Stub
    // 0xd02164: ldur            x0, [fp, #-8]
    // 0xd02168: LeaveFrame
    //     0xd02168: mov             SP, fp
    //     0xd0216c: ldp             fp, lr, [SP], #0x10
    // 0xd02170: ret
    //     0xd02170: ret             
    // 0xd02174: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd02174: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd02178: b               #0xd02100
  }
  String name(SimpleSelector) {
    // ** addr: 0xd0217c, size: 0x90
    // 0xd0217c: EnterFrame
    //     0xd0217c: stp             fp, lr, [SP, #-0x10]!
    //     0xd02180: mov             fp, SP
    // 0xd02184: AllocStack(0x10)
    //     0xd02184: sub             SP, SP, #0x10
    // 0xd02188: CheckStackOverflow
    //     0xd02188: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0218c: cmp             SP, x16
    //     0xd02190: b.ls            #0xd02204
    // 0xd02194: LoadField: r0 = r1->field_b
    //     0xd02194: ldur            w0, [x1, #0xb]
    // 0xd02198: DecompressPointer r0
    //     0xd02198: add             x0, x0, HEAP, lsl #32
    // 0xd0219c: str             x0, [SP]
    // 0xd021a0: r4 = 0
    //     0xd021a0: mov             x4, #0
    // 0xd021a4: ldr             x0, [SP]
    // 0xd021a8: r16 = 139822029843448
    //     0xd021a8: add             x16, PP, #0x7e, lsl #12  ; [pp+0x7ec18] IMM: 0x7f2ada6babf8
    //     0xd021ac: add             x16, x16, #0xc18
    // 0xd021b0: ldp             lr, x5, [x16]
    // 0xd021b4: blr             lr
    // 0xd021b8: mov             x3, x0
    // 0xd021bc: r2 = Null
    //     0xd021bc: mov             x2, NULL
    // 0xd021c0: r1 = Null
    //     0xd021c0: mov             x1, NULL
    // 0xd021c4: stur            x3, [fp, #-8]
    // 0xd021c8: r4 = 60
    //     0xd021c8: mov             x4, #0x3c
    // 0xd021cc: branchIfSmi(r0, 0xd021d8)
    //     0xd021cc: tbz             w0, #0, #0xd021d8
    // 0xd021d0: r4 = LoadClassIdInstr(r0)
    //     0xd021d0: ldur            x4, [x0, #-1]
    //     0xd021d4: ubfx            x4, x4, #0xc, #0x14
    // 0xd021d8: sub             x4, x4, #0x5e
    // 0xd021dc: cmp             x4, #1
    // 0xd021e0: b.ls            #0xd021f4
    // 0xd021e4: r8 = String
    //     0xd021e4: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0xd021e8: r3 = Null
    //     0xd021e8: add             x3, PP, #0x7e, lsl #12  ; [pp+0x7ec28] Null
    //     0xd021ec: ldr             x3, [x3, #0xc28]
    // 0xd021f0: r0 = String()
    //     0xd021f0: bl              #0x13ee320  ; IsType_String_Stub
    // 0xd021f4: ldur            x0, [fp, #-8]
    // 0xd021f8: LeaveFrame
    //     0xd021f8: mov             SP, fp
    //     0xd021fc: ldp             fp, lr, [SP], #0x10
    // 0xd02200: ret
    //     0xd02200: ret             
    // 0xd02204: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd02204: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd02208: b               #0xd02194
  }
}

// class id: 3474, size: 0x14, field offset: 0x10
class NegationSelector extends SimpleSelector {

  _ visit(/* No info */) {
    // ** addr: 0xd0244c, size: 0x48
    // 0xd0244c: EnterFrame
    //     0xd0244c: stp             fp, lr, [SP, #-0x10]!
    //     0xd02450: mov             fp, SP
    // 0xd02454: mov             x16, x2
    // 0xd02458: mov             x2, x1
    // 0xd0245c: mov             x1, x16
    // 0xd02460: CheckStackOverflow
    //     0xd02460: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd02464: cmp             SP, x16
    //     0xd02468: b.ls            #0xd0248c
    // 0xd0246c: r0 = LoadClassIdInstr(r1)
    //     0xd0246c: ldur            x0, [x1, #-1]
    //     0xd02470: ubfx            x0, x0, #0xc, #0x14
    // 0xd02474: r0 = GDT[cid_x0 + -0xff1]()
    //     0xd02474: sub             lr, x0, #0xff1
    //     0xd02478: ldr             lr, [x21, lr, lsl #3]
    //     0xd0247c: blr             lr
    // 0xd02480: LeaveFrame
    //     0xd02480: mov             SP, fp
    //     0xd02484: ldp             fp, lr, [SP], #0x10
    // 0xd02488: ret
    //     0xd02488: ret             
    // 0xd0248c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0248c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd02490: b               #0xd0246c
  }
}

// class id: 3475, size: 0x14, field offset: 0x10
class PseudoElementSelector extends SimpleSelector {

  _ visit(/* No info */) {
    // ** addr: 0xd02404, size: 0x48
    // 0xd02404: EnterFrame
    //     0xd02404: stp             fp, lr, [SP, #-0x10]!
    //     0xd02408: mov             fp, SP
    // 0xd0240c: mov             x16, x2
    // 0xd02410: mov             x2, x1
    // 0xd02414: mov             x1, x16
    // 0xd02418: CheckStackOverflow
    //     0xd02418: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0241c: cmp             SP, x16
    //     0xd02420: b.ls            #0xd02444
    // 0xd02424: r0 = LoadClassIdInstr(r1)
    //     0xd02424: ldur            x0, [x1, #-1]
    //     0xd02428: ubfx            x0, x0, #0xc, #0x14
    // 0xd0242c: r0 = GDT[cid_x0 + -0xfb7]()
    //     0xd0242c: sub             lr, x0, #0xfb7
    //     0xd02430: ldr             lr, [x21, lr, lsl #3]
    //     0xd02434: blr             lr
    // 0xd02438: LeaveFrame
    //     0xd02438: mov             SP, fp
    //     0xd0243c: ldp             fp, lr, [SP], #0x10
    // 0xd02440: ret
    //     0xd02440: ret             
    // 0xd02444: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd02444: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd02448: b               #0xd02424
  }
  _ toString(/* No info */) {
    // ** addr: 0x1114150, size: 0xa8
    // 0x1114150: EnterFrame
    //     0x1114150: stp             fp, lr, [SP, #-0x10]!
    //     0x1114154: mov             fp, SP
    // 0x1114158: AllocStack(0x18)
    //     0x1114158: sub             SP, SP, #0x18
    // 0x111415c: CheckStackOverflow
    //     0x111415c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1114160: cmp             SP, x16
    //     0x1114164: b.ls            #0x11141f0
    // 0x1114168: ldr             x0, [fp, #0x10]
    // 0x111416c: LoadField: r1 = r0->field_f
    //     0x111416c: ldur            w1, [x0, #0xf]
    // 0x1114170: DecompressPointer r1
    //     0x1114170: add             x1, x1, HEAP, lsl #32
    // 0x1114174: tbnz            w1, #4, #0x1114180
    // 0x1114178: r3 = ":"
    //     0x1114178: ldr             x3, [PP, #0xdd0]  ; [pp+0xdd0] ":"
    // 0x111417c: b               #0x1114188
    // 0x1114180: r3 = "::"
    //     0x1114180: add             x3, PP, #0x7e, lsl #12  ; [pp+0x7ec10] "::"
    //     0x1114184: ldr             x3, [x3, #0xc10]
    // 0x1114188: stur            x3, [fp, #-8]
    // 0x111418c: r1 = Null
    //     0x111418c: mov             x1, NULL
    // 0x1114190: r2 = 4
    //     0x1114190: mov             x2, #4
    // 0x1114194: r0 = AllocateArray()
    //     0x1114194: bl              #0x13df928  ; AllocateArrayStub
    // 0x1114198: mov             x2, x0
    // 0x111419c: ldur            x0, [fp, #-8]
    // 0x11141a0: stur            x2, [fp, #-0x10]
    // 0x11141a4: StoreField: r2->field_f = r0
    //     0x11141a4: stur            w0, [x2, #0xf]
    // 0x11141a8: ldr             x1, [fp, #0x10]
    // 0x11141ac: r0 = name()
    //     0x11141ac: bl              #0xd0217c  ; [package:csslib/visitor.dart] SimpleSelector::name
    // 0x11141b0: ldur            x1, [fp, #-0x10]
    // 0x11141b4: ArrayStore: r1[1] = r0  ; List_4
    //     0x11141b4: add             x25, x1, #0x13
    //     0x11141b8: str             w0, [x25]
    //     0x11141bc: tbz             w0, #0, #0x11141d8
    //     0x11141c0: ldurb           w16, [x1, #-1]
    //     0x11141c4: ldurb           w17, [x0, #-1]
    //     0x11141c8: and             x16, x17, x16, lsr #2
    //     0x11141cc: tst             x16, HEAP, lsr #32
    //     0x11141d0: b.eq            #0x11141d8
    //     0x11141d4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x11141d8: ldur            x16, [fp, #-0x10]
    // 0x11141dc: str             x16, [SP]
    // 0x11141e0: r0 = _interpolate()
    //     0x11141e0: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11141e4: LeaveFrame
    //     0x11141e4: mov             SP, fp
    //     0x11141e8: ldp             fp, lr, [SP], #0x10
    // 0x11141ec: ret
    //     0x11141ec: ret             
    // 0x11141f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11141f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11141f4: b               #0x1114168
  }
}

// class id: 3476, size: 0x14, field offset: 0x14
class PseudoElementFunctionSelector extends PseudoElementSelector {

  _ visit(/* No info */) {
    // ** addr: 0xd023bc, size: 0x48
    // 0xd023bc: EnterFrame
    //     0xd023bc: stp             fp, lr, [SP, #-0x10]!
    //     0xd023c0: mov             fp, SP
    // 0xd023c4: mov             x16, x2
    // 0xd023c8: mov             x2, x1
    // 0xd023cc: mov             x1, x16
    // 0xd023d0: CheckStackOverflow
    //     0xd023d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd023d4: cmp             SP, x16
    //     0xd023d8: b.ls            #0xd023fc
    // 0xd023dc: r0 = LoadClassIdInstr(r1)
    //     0xd023dc: ldur            x0, [x1, #-1]
    //     0xd023e0: ubfx            x0, x0, #0xc, #0x14
    // 0xd023e4: r0 = GDT[cid_x0 + -0xfbb]()
    //     0xd023e4: sub             lr, x0, #0xfbb
    //     0xd023e8: ldr             lr, [x21, lr, lsl #3]
    //     0xd023ec: blr             lr
    // 0xd023f0: LeaveFrame
    //     0xd023f0: mov             SP, fp
    //     0xd023f4: ldp             fp, lr, [SP], #0x10
    // 0xd023f8: ret
    //     0xd023f8: ret             
    // 0xd023fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd023fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd02400: b               #0xd023dc
  }
}

// class id: 3477, size: 0x10, field offset: 0x10
class PseudoClassSelector extends SimpleSelector {

  _ visit(/* No info */) {
    // ** addr: 0xd02374, size: 0x48
    // 0xd02374: EnterFrame
    //     0xd02374: stp             fp, lr, [SP, #-0x10]!
    //     0xd02378: mov             fp, SP
    // 0xd0237c: mov             x16, x2
    // 0xd02380: mov             x2, x1
    // 0xd02384: mov             x1, x16
    // 0xd02388: CheckStackOverflow
    //     0xd02388: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0238c: cmp             SP, x16
    //     0xd02390: b.ls            #0xd023b4
    // 0xd02394: r0 = LoadClassIdInstr(r1)
    //     0xd02394: ldur            x0, [x1, #-1]
    //     0xd02398: ubfx            x0, x0, #0xc, #0x14
    // 0xd0239c: r0 = GDT[cid_x0 + -0xfb3]()
    //     0xd0239c: sub             lr, x0, #0xfb3
    //     0xd023a0: ldr             lr, [x21, lr, lsl #3]
    //     0xd023a4: blr             lr
    // 0xd023a8: LeaveFrame
    //     0xd023a8: mov             SP, fp
    //     0xd023ac: ldp             fp, lr, [SP], #0x10
    // 0xd023b0: ret
    //     0xd023b0: ret             
    // 0xd023b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd023b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd023b8: b               #0xd02394
  }
  _ toString(/* No info */) {
    // ** addr: 0x1114070, size: 0xe0
    // 0x1114070: EnterFrame
    //     0x1114070: stp             fp, lr, [SP, #-0x10]!
    //     0x1114074: mov             fp, SP
    // 0x1114078: AllocStack(0x18)
    //     0x1114078: sub             SP, SP, #0x18
    // 0x111407c: CheckStackOverflow
    //     0x111407c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1114080: cmp             SP, x16
    //     0x1114084: b.ls            #0x1114148
    // 0x1114088: r1 = Null
    //     0x1114088: mov             x1, NULL
    // 0x111408c: r2 = 4
    //     0x111408c: mov             x2, #4
    // 0x1114090: r0 = AllocateArray()
    //     0x1114090: bl              #0x13df928  ; AllocateArrayStub
    // 0x1114094: stur            x0, [fp, #-8]
    // 0x1114098: r16 = ":"
    //     0x1114098: ldr             x16, [PP, #0xdd0]  ; [pp+0xdd0] ":"
    // 0x111409c: StoreField: r0->field_f = r16
    //     0x111409c: stur            w16, [x0, #0xf]
    // 0x11140a0: ldr             x1, [fp, #0x10]
    // 0x11140a4: LoadField: r2 = r1->field_b
    //     0x11140a4: ldur            w2, [x1, #0xb]
    // 0x11140a8: DecompressPointer r2
    //     0x11140a8: add             x2, x2, HEAP, lsl #32
    // 0x11140ac: str             x2, [SP]
    // 0x11140b0: r4 = 0
    //     0x11140b0: mov             x4, #0
    // 0x11140b4: ldr             x0, [SP]
    // 0x11140b8: r16 = 139822029843448
    //     0x11140b8: add             x16, PP, #0x7e, lsl #12  ; [pp+0x7ed28] IMM: 0x7f2ada6babf8
    //     0x11140bc: add             x16, x16, #0xd28
    // 0x11140c0: ldp             lr, x5, [x16]
    // 0x11140c4: blr             lr
    // 0x11140c8: mov             x3, x0
    // 0x11140cc: r2 = Null
    //     0x11140cc: mov             x2, NULL
    // 0x11140d0: r1 = Null
    //     0x11140d0: mov             x1, NULL
    // 0x11140d4: stur            x3, [fp, #-0x10]
    // 0x11140d8: r4 = 60
    //     0x11140d8: mov             x4, #0x3c
    // 0x11140dc: branchIfSmi(r0, 0x11140e8)
    //     0x11140dc: tbz             w0, #0, #0x11140e8
    // 0x11140e0: r4 = LoadClassIdInstr(r0)
    //     0x11140e0: ldur            x4, [x0, #-1]
    //     0x11140e4: ubfx            x4, x4, #0xc, #0x14
    // 0x11140e8: sub             x4, x4, #0x5e
    // 0x11140ec: cmp             x4, #1
    // 0x11140f0: b.ls            #0x1114104
    // 0x11140f4: r8 = String
    //     0x11140f4: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x11140f8: r3 = Null
    //     0x11140f8: add             x3, PP, #0x7e, lsl #12  ; [pp+0x7ed38] Null
    //     0x11140fc: ldr             x3, [x3, #0xd38]
    // 0x1114100: r0 = String()
    //     0x1114100: bl              #0x13ee320  ; IsType_String_Stub
    // 0x1114104: ldur            x1, [fp, #-8]
    // 0x1114108: ldur            x0, [fp, #-0x10]
    // 0x111410c: ArrayStore: r1[1] = r0  ; List_4
    //     0x111410c: add             x25, x1, #0x13
    //     0x1114110: str             w0, [x25]
    //     0x1114114: tbz             w0, #0, #0x1114130
    //     0x1114118: ldurb           w16, [x1, #-1]
    //     0x111411c: ldurb           w17, [x0, #-1]
    //     0x1114120: and             x16, x17, x16, lsr #2
    //     0x1114124: tst             x16, HEAP, lsr #32
    //     0x1114128: b.eq            #0x1114130
    //     0x111412c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1114130: ldur            x16, [fp, #-8]
    // 0x1114134: str             x16, [SP]
    // 0x1114138: r0 = _interpolate()
    //     0x1114138: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x111413c: LeaveFrame
    //     0x111413c: mov             SP, fp
    //     0x1114140: ldp             fp, lr, [SP], #0x10
    // 0x1114144: ret
    //     0x1114144: ret             
    // 0x1114148: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1114148: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x111414c: b               #0x1114088
  }
}

// class id: 3478, size: 0x14, field offset: 0x10
class PseudoClassFunctionSelector extends PseudoClassSelector {

  _ visit(/* No info */) {
    // ** addr: 0xd0232c, size: 0x48
    // 0xd0232c: EnterFrame
    //     0xd0232c: stp             fp, lr, [SP, #-0x10]!
    //     0xd02330: mov             fp, SP
    // 0xd02334: mov             x16, x2
    // 0xd02338: mov             x2, x1
    // 0xd0233c: mov             x1, x16
    // 0xd02340: CheckStackOverflow
    //     0xd02340: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd02344: cmp             SP, x16
    //     0xd02348: b.ls            #0xd0236c
    // 0xd0234c: r0 = LoadClassIdInstr(r1)
    //     0xd0234c: ldur            x0, [x1, #-1]
    //     0xd02350: ubfx            x0, x0, #0xc, #0x14
    // 0xd02354: r0 = GDT[cid_x0 + -0xfc1]()
    //     0xd02354: sub             lr, x0, #0xfc1
    //     0xd02358: ldr             lr, [x21, lr, lsl #3]
    //     0xd0235c: blr             lr
    // 0xd02360: LeaveFrame
    //     0xd02360: mov             SP, fp
    //     0xd02364: ldp             fp, lr, [SP], #0x10
    // 0xd02368: ret
    //     0xd02368: ret             
    // 0xd0236c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0236c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd02370: b               #0xd0234c
  }
}

// class id: 3479, size: 0x10, field offset: 0x10
class ClassSelector extends SimpleSelector {

  _ visit(/* No info */) {
    // ** addr: 0xd022e4, size: 0x48
    // 0xd022e4: EnterFrame
    //     0xd022e4: stp             fp, lr, [SP, #-0x10]!
    //     0xd022e8: mov             fp, SP
    // 0xd022ec: mov             x16, x2
    // 0xd022f0: mov             x2, x1
    // 0xd022f4: mov             x1, x16
    // 0xd022f8: CheckStackOverflow
    //     0xd022f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd022fc: cmp             SP, x16
    //     0xd02300: b.ls            #0xd02324
    // 0xd02304: r0 = LoadClassIdInstr(r1)
    //     0xd02304: ldur            x0, [x1, #-1]
    //     0xd02308: ubfx            x0, x0, #0xc, #0x14
    // 0xd0230c: r0 = GDT[cid_x0 + -0xfed]()
    //     0xd0230c: sub             lr, x0, #0xfed
    //     0xd02310: ldr             lr, [x21, lr, lsl #3]
    //     0xd02314: blr             lr
    // 0xd02318: LeaveFrame
    //     0xd02318: mov             SP, fp
    //     0xd0231c: ldp             fp, lr, [SP], #0x10
    // 0xd02320: ret
    //     0xd02320: ret             
    // 0xd02324: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd02324: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd02328: b               #0xd02304
  }
  _ toString(/* No info */) {
    // ** addr: 0x1114018, size: 0x58
    // 0x1114018: EnterFrame
    //     0x1114018: stp             fp, lr, [SP, #-0x10]!
    //     0x111401c: mov             fp, SP
    // 0x1114020: AllocStack(0x8)
    //     0x1114020: sub             SP, SP, #8
    // 0x1114024: CheckStackOverflow
    //     0x1114024: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1114028: cmp             SP, x16
    //     0x111402c: b.ls            #0x1114068
    // 0x1114030: r1 = Null
    //     0x1114030: mov             x1, NULL
    // 0x1114034: r2 = 4
    //     0x1114034: mov             x2, #4
    // 0x1114038: r0 = AllocateArray()
    //     0x1114038: bl              #0x13df928  ; AllocateArrayStub
    // 0x111403c: r16 = "."
    //     0x111403c: ldr             x16, [PP, #0xfc8]  ; [pp+0xfc8] "."
    // 0x1114040: StoreField: r0->field_f = r16
    //     0x1114040: stur            w16, [x0, #0xf]
    // 0x1114044: ldr             x1, [fp, #0x10]
    // 0x1114048: LoadField: r2 = r1->field_b
    //     0x1114048: ldur            w2, [x1, #0xb]
    // 0x111404c: DecompressPointer r2
    //     0x111404c: add             x2, x2, HEAP, lsl #32
    // 0x1114050: StoreField: r0->field_13 = r2
    //     0x1114050: stur            w2, [x0, #0x13]
    // 0x1114054: str             x0, [SP]
    // 0x1114058: r0 = _interpolate()
    //     0x1114058: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x111405c: LeaveFrame
    //     0x111405c: mov             SP, fp
    //     0x1114060: ldp             fp, lr, [SP], #0x10
    // 0x1114064: ret
    //     0x1114064: ret             
    // 0x1114068: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1114068: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x111406c: b               #0x1114030
  }
}

// class id: 3480, size: 0x10, field offset: 0x10
class IdSelector extends SimpleSelector {

  _ visit(/* No info */) {
    // ** addr: 0xd0229c, size: 0x48
    // 0xd0229c: EnterFrame
    //     0xd0229c: stp             fp, lr, [SP, #-0x10]!
    //     0xd022a0: mov             fp, SP
    // 0xd022a4: mov             x16, x2
    // 0xd022a8: mov             x2, x1
    // 0xd022ac: mov             x1, x16
    // 0xd022b0: CheckStackOverflow
    //     0xd022b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd022b4: cmp             SP, x16
    //     0xd022b8: b.ls            #0xd022dc
    // 0xd022bc: r0 = LoadClassIdInstr(r1)
    //     0xd022bc: ldur            x0, [x1, #-1]
    //     0xd022c0: ubfx            x0, x0, #0xc, #0x14
    // 0xd022c4: r0 = GDT[cid_x0 + -0xfdf]()
    //     0xd022c4: sub             lr, x0, #0xfdf
    //     0xd022c8: ldr             lr, [x21, lr, lsl #3]
    //     0xd022cc: blr             lr
    // 0xd022d0: LeaveFrame
    //     0xd022d0: mov             SP, fp
    //     0xd022d4: ldp             fp, lr, [SP], #0x10
    // 0xd022d8: ret
    //     0xd022d8: ret             
    // 0xd022dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd022dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd022e0: b               #0xd022bc
  }
  _ toString(/* No info */) {
    // ** addr: 0x1113fc0, size: 0x58
    // 0x1113fc0: EnterFrame
    //     0x1113fc0: stp             fp, lr, [SP, #-0x10]!
    //     0x1113fc4: mov             fp, SP
    // 0x1113fc8: AllocStack(0x8)
    //     0x1113fc8: sub             SP, SP, #8
    // 0x1113fcc: CheckStackOverflow
    //     0x1113fcc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1113fd0: cmp             SP, x16
    //     0x1113fd4: b.ls            #0x1114010
    // 0x1113fd8: r1 = Null
    //     0x1113fd8: mov             x1, NULL
    // 0x1113fdc: r2 = 4
    //     0x1113fdc: mov             x2, #4
    // 0x1113fe0: r0 = AllocateArray()
    //     0x1113fe0: bl              #0x13df928  ; AllocateArrayStub
    // 0x1113fe4: r16 = "#"
    //     0x1113fe4: ldr             x16, [PP, #0x8e8]  ; [pp+0x8e8] "#"
    // 0x1113fe8: StoreField: r0->field_f = r16
    //     0x1113fe8: stur            w16, [x0, #0xf]
    // 0x1113fec: ldr             x1, [fp, #0x10]
    // 0x1113ff0: LoadField: r2 = r1->field_b
    //     0x1113ff0: ldur            w2, [x1, #0xb]
    // 0x1113ff4: DecompressPointer r2
    //     0x1113ff4: add             x2, x2, HEAP, lsl #32
    // 0x1113ff8: StoreField: r0->field_13 = r2
    //     0x1113ff8: stur            w2, [x0, #0x13]
    // 0x1113ffc: str             x0, [SP]
    // 0x1114000: r0 = _interpolate()
    //     0x1114000: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x1114004: LeaveFrame
    //     0x1114004: mov             SP, fp
    //     0x1114008: ldp             fp, lr, [SP], #0x10
    // 0x111400c: ret
    //     0x111400c: ret             
    // 0x1114010: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1114010: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1114014: b               #0x1113fd8
  }
}

// class id: 3481, size: 0x1c, field offset: 0x10
class AttributeSelector extends SimpleSelector {

  _ visit(/* No info */) {
    // ** addr: 0xd02254, size: 0x48
    // 0xd02254: EnterFrame
    //     0xd02254: stp             fp, lr, [SP, #-0x10]!
    //     0xd02258: mov             fp, SP
    // 0xd0225c: mov             x16, x2
    // 0xd02260: mov             x2, x1
    // 0xd02264: mov             x1, x16
    // 0xd02268: CheckStackOverflow
    //     0xd02268: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0226c: cmp             SP, x16
    //     0xd02270: b.ls            #0xd02294
    // 0xd02274: r0 = LoadClassIdInstr(r1)
    //     0xd02274: ldur            x0, [x1, #-1]
    //     0xd02278: ubfx            x0, x0, #0xc, #0x14
    // 0xd0227c: r0 = GDT[cid_x0 + -0xffa]()
    //     0xd0227c: sub             lr, x0, #0xffa
    //     0xd02280: ldr             lr, [x21, lr, lsl #3]
    //     0xd02284: blr             lr
    // 0xd02288: LeaveFrame
    //     0xd02288: mov             SP, fp
    //     0xd0228c: ldp             fp, lr, [SP], #0x10
    // 0xd02290: ret
    //     0xd02290: ret             
    // 0xd02294: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd02294: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd02298: b               #0xd02274
  }
  _ toString(/* No info */) {
    // ** addr: 0x1113d18, size: 0x1d4
    // 0x1113d18: EnterFrame
    //     0x1113d18: stp             fp, lr, [SP, #-0x10]!
    //     0x1113d1c: mov             fp, SP
    // 0x1113d20: AllocStack(0x18)
    //     0x1113d20: sub             SP, SP, #0x18
    // 0x1113d24: CheckStackOverflow
    //     0x1113d24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1113d28: cmp             SP, x16
    //     0x1113d2c: b.ls            #0x1113ee4
    // 0x1113d30: r1 = Null
    //     0x1113d30: mov             x1, NULL
    // 0x1113d34: r2 = 10
    //     0x1113d34: mov             x2, #0xa
    // 0x1113d38: r0 = AllocateArray()
    //     0x1113d38: bl              #0x13df928  ; AllocateArrayStub
    // 0x1113d3c: stur            x0, [fp, #-8]
    // 0x1113d40: r16 = "["
    //     0x1113d40: ldr             x16, [PP, #0x1290]  ; [pp+0x1290] "["
    // 0x1113d44: StoreField: r0->field_f = r16
    //     0x1113d44: stur            w16, [x0, #0xf]
    // 0x1113d48: ldr             x1, [fp, #0x10]
    // 0x1113d4c: LoadField: r2 = r1->field_b
    //     0x1113d4c: ldur            w2, [x1, #0xb]
    // 0x1113d50: DecompressPointer r2
    //     0x1113d50: add             x2, x2, HEAP, lsl #32
    // 0x1113d54: str             x2, [SP]
    // 0x1113d58: r4 = 0
    //     0x1113d58: mov             x4, #0
    // 0x1113d5c: ldr             x0, [SP]
    // 0x1113d60: r16 = 139822029843448
    //     0x1113d60: add             x16, PP, #0x7e, lsl #12  ; [pp+0x7ec90] IMM: 0x7f2ada6babf8
    //     0x1113d64: add             x16, x16, #0xc90
    // 0x1113d68: ldp             lr, x5, [x16]
    // 0x1113d6c: blr             lr
    // 0x1113d70: mov             x3, x0
    // 0x1113d74: r2 = Null
    //     0x1113d74: mov             x2, NULL
    // 0x1113d78: r1 = Null
    //     0x1113d78: mov             x1, NULL
    // 0x1113d7c: stur            x3, [fp, #-0x10]
    // 0x1113d80: r4 = 60
    //     0x1113d80: mov             x4, #0x3c
    // 0x1113d84: branchIfSmi(r0, 0x1113d90)
    //     0x1113d84: tbz             w0, #0, #0x1113d90
    // 0x1113d88: r4 = LoadClassIdInstr(r0)
    //     0x1113d88: ldur            x4, [x0, #-1]
    //     0x1113d8c: ubfx            x4, x4, #0xc, #0x14
    // 0x1113d90: sub             x4, x4, #0x5e
    // 0x1113d94: cmp             x4, #1
    // 0x1113d98: b.ls            #0x1113dac
    // 0x1113d9c: r8 = String
    //     0x1113d9c: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x1113da0: r3 = Null
    //     0x1113da0: add             x3, PP, #0x7e, lsl #12  ; [pp+0x7eca0] Null
    //     0x1113da4: ldr             x3, [x3, #0xca0]
    // 0x1113da8: r0 = String()
    //     0x1113da8: bl              #0x13ee320  ; IsType_String_Stub
    // 0x1113dac: ldur            x1, [fp, #-8]
    // 0x1113db0: ldur            x0, [fp, #-0x10]
    // 0x1113db4: ArrayStore: r1[1] = r0  ; List_4
    //     0x1113db4: add             x25, x1, #0x13
    //     0x1113db8: str             w0, [x25]
    //     0x1113dbc: tbz             w0, #0, #0x1113dd8
    //     0x1113dc0: ldurb           w16, [x1, #-1]
    //     0x1113dc4: ldurb           w17, [x0, #-1]
    //     0x1113dc8: and             x16, x17, x16, lsr #2
    //     0x1113dcc: tst             x16, HEAP, lsr #32
    //     0x1113dd0: b.eq            #0x1113dd8
    //     0x1113dd4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1113dd8: ldr             x2, [fp, #0x10]
    // 0x1113ddc: LoadField: r0 = r2->field_f
    //     0x1113ddc: ldur            x0, [x2, #0xf]
    // 0x1113de0: cmp             x0, #0x1c
    // 0x1113de4: b.ne            #0x1113df0
    // 0x1113de8: r0 = "="
    //     0x1113de8: ldr             x0, [PP, #0x11d0]  ; [pp+0x11d0] "="
    // 0x1113dec: b               #0x1113e68
    // 0x1113df0: cmp             x0, #0x212
    // 0x1113df4: b.ne            #0x1113e04
    // 0x1113df8: r0 = "~="
    //     0x1113df8: add             x0, PP, #0x7e, lsl #12  ; [pp+0x7ecb0] "~="
    //     0x1113dfc: ldr             x0, [x0, #0xcb0]
    // 0x1113e00: b               #0x1113e68
    // 0x1113e04: cmp             x0, #0x213
    // 0x1113e08: b.ne            #0x1113e18
    // 0x1113e0c: r0 = "|="
    //     0x1113e0c: add             x0, PP, #0x7e, lsl #12  ; [pp+0x7ecb8] "|="
    //     0x1113e10: ldr             x0, [x0, #0xcb8]
    // 0x1113e14: b               #0x1113e68
    // 0x1113e18: cmp             x0, #0x214
    // 0x1113e1c: b.ne            #0x1113e2c
    // 0x1113e20: r0 = "^="
    //     0x1113e20: add             x0, PP, #0x7e, lsl #12  ; [pp+0x7ecc0] "^="
    //     0x1113e24: ldr             x0, [x0, #0xcc0]
    // 0x1113e28: b               #0x1113e68
    // 0x1113e2c: cmp             x0, #0x215
    // 0x1113e30: b.ne            #0x1113e40
    // 0x1113e34: r0 = "$="
    //     0x1113e34: add             x0, PP, #0x7e, lsl #12  ; [pp+0x7ecc8] "$="
    //     0x1113e38: ldr             x0, [x0, #0xcc8]
    // 0x1113e3c: b               #0x1113e68
    // 0x1113e40: cmp             x0, #0x216
    // 0x1113e44: b.ne            #0x1113e54
    // 0x1113e48: r0 = "*="
    //     0x1113e48: add             x0, PP, #0x7e, lsl #12  ; [pp+0x7ecd0] "*="
    //     0x1113e4c: ldr             x0, [x0, #0xcd0]
    // 0x1113e50: b               #0x1113e68
    // 0x1113e54: cmp             x0, #0x217
    // 0x1113e58: b.ne            #0x1113e64
    // 0x1113e5c: r0 = ""
    //     0x1113e5c: ldr             x0, [PP, #0x900]  ; [pp+0x900] ""
    // 0x1113e60: b               #0x1113e68
    // 0x1113e64: r0 = Null
    //     0x1113e64: mov             x0, NULL
    // 0x1113e68: ldur            x3, [fp, #-8]
    // 0x1113e6c: mov             x1, x3
    // 0x1113e70: ArrayStore: r1[2] = r0  ; List_4
    //     0x1113e70: add             x25, x1, #0x17
    //     0x1113e74: str             w0, [x25]
    //     0x1113e78: tbz             w0, #0, #0x1113e94
    //     0x1113e7c: ldurb           w16, [x1, #-1]
    //     0x1113e80: ldurb           w17, [x0, #-1]
    //     0x1113e84: and             x16, x17, x16, lsr #2
    //     0x1113e88: tst             x16, HEAP, lsr #32
    //     0x1113e8c: b.eq            #0x1113e94
    //     0x1113e90: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1113e94: mov             x1, x2
    // 0x1113e98: r0 = valueToString()
    //     0x1113e98: bl              #0x1113eec  ; [package:csslib/visitor.dart] AttributeSelector::valueToString
    // 0x1113e9c: ldur            x1, [fp, #-8]
    // 0x1113ea0: ArrayStore: r1[3] = r0  ; List_4
    //     0x1113ea0: add             x25, x1, #0x1b
    //     0x1113ea4: str             w0, [x25]
    //     0x1113ea8: tbz             w0, #0, #0x1113ec4
    //     0x1113eac: ldurb           w16, [x1, #-1]
    //     0x1113eb0: ldurb           w17, [x0, #-1]
    //     0x1113eb4: and             x16, x17, x16, lsr #2
    //     0x1113eb8: tst             x16, HEAP, lsr #32
    //     0x1113ebc: b.eq            #0x1113ec4
    //     0x1113ec0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1113ec4: ldur            x0, [fp, #-8]
    // 0x1113ec8: r16 = "]"
    //     0x1113ec8: ldr             x16, [PP, #0x1298]  ; [pp+0x1298] "]"
    // 0x1113ecc: StoreField: r0->field_1f = r16
    //     0x1113ecc: stur            w16, [x0, #0x1f]
    // 0x1113ed0: str             x0, [SP]
    // 0x1113ed4: r0 = _interpolate()
    //     0x1113ed4: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x1113ed8: LeaveFrame
    //     0x1113ed8: mov             SP, fp
    //     0x1113edc: ldp             fp, lr, [SP], #0x10
    // 0x1113ee0: ret
    //     0x1113ee0: ret             
    // 0x1113ee4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1113ee4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1113ee8: b               #0x1113d30
  }
  _ valueToString(/* No info */) {
    // ** addr: 0x1113eec, size: 0xd4
    // 0x1113eec: EnterFrame
    //     0x1113eec: stp             fp, lr, [SP, #-0x10]!
    //     0x1113ef0: mov             fp, SP
    // 0x1113ef4: AllocStack(0x10)
    //     0x1113ef4: sub             SP, SP, #0x10
    // 0x1113ef8: CheckStackOverflow
    //     0x1113ef8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1113efc: cmp             SP, x16
    //     0x1113f00: b.ls            #0x1113fb8
    // 0x1113f04: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x1113f04: ldur            w0, [x1, #0x17]
    // 0x1113f08: DecompressPointer r0
    //     0x1113f08: add             x0, x0, HEAP, lsl #32
    // 0x1113f0c: stur            x0, [fp, #-8]
    // 0x1113f10: cmp             w0, NULL
    // 0x1113f14: b.eq            #0x1113fa8
    // 0x1113f18: r1 = 60
    //     0x1113f18: mov             x1, #0x3c
    // 0x1113f1c: branchIfSmi(r0, 0x1113f28)
    //     0x1113f1c: tbz             w0, #0, #0x1113f28
    // 0x1113f20: r1 = LoadClassIdInstr(r0)
    //     0x1113f20: ldur            x1, [x0, #-1]
    //     0x1113f24: ubfx            x1, x1, #0xc, #0x14
    // 0x1113f28: cmp             x1, #0xdc2
    // 0x1113f2c: b.ne            #0x1113f68
    // 0x1113f30: r1 = 60
    //     0x1113f30: mov             x1, #0x3c
    // 0x1113f34: branchIfSmi(r0, 0x1113f40)
    //     0x1113f34: tbz             w0, #0, #0x1113f40
    // 0x1113f38: r1 = LoadClassIdInstr(r0)
    //     0x1113f38: ldur            x1, [x0, #-1]
    //     0x1113f3c: ubfx            x1, x1, #0xc, #0x14
    // 0x1113f40: str             x0, [SP]
    // 0x1113f44: mov             x0, x1
    // 0x1113f48: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x1113f48: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x1113f4c: r0 = GDT[cid_x0 + 0x91c1]()
    //     0x1113f4c: mov             x17, #0x91c1
    //     0x1113f50: add             lr, x0, x17
    //     0x1113f54: ldr             lr, [x21, lr, lsl #3]
    //     0x1113f58: blr             lr
    // 0x1113f5c: LeaveFrame
    //     0x1113f5c: mov             SP, fp
    //     0x1113f60: ldp             fp, lr, [SP], #0x10
    // 0x1113f64: ret
    //     0x1113f64: ret             
    // 0x1113f68: r1 = Null
    //     0x1113f68: mov             x1, NULL
    // 0x1113f6c: r2 = 6
    //     0x1113f6c: mov             x2, #6
    // 0x1113f70: r0 = AllocateArray()
    //     0x1113f70: bl              #0x13df928  ; AllocateArrayStub
    // 0x1113f74: r16 = "\""
    //     0x1113f74: add             x16, PP, #8, lsl #12  ; [pp+0x84a0] "\""
    //     0x1113f78: ldr             x16, [x16, #0x4a0]
    // 0x1113f7c: StoreField: r0->field_f = r16
    //     0x1113f7c: stur            w16, [x0, #0xf]
    // 0x1113f80: ldur            x1, [fp, #-8]
    // 0x1113f84: StoreField: r0->field_13 = r1
    //     0x1113f84: stur            w1, [x0, #0x13]
    // 0x1113f88: r16 = "\""
    //     0x1113f88: add             x16, PP, #8, lsl #12  ; [pp+0x84a0] "\""
    //     0x1113f8c: ldr             x16, [x16, #0x4a0]
    // 0x1113f90: ArrayStore: r0[0] = r16  ; List_4
    //     0x1113f90: stur            w16, [x0, #0x17]
    // 0x1113f94: str             x0, [SP]
    // 0x1113f98: r0 = _interpolate()
    //     0x1113f98: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x1113f9c: LeaveFrame
    //     0x1113f9c: mov             SP, fp
    //     0x1113fa0: ldp             fp, lr, [SP], #0x10
    // 0x1113fa4: ret
    //     0x1113fa4: ret             
    // 0x1113fa8: r0 = ""
    //     0x1113fa8: ldr             x0, [PP, #0x900]  ; [pp+0x900] ""
    // 0x1113fac: LeaveFrame
    //     0x1113fac: mov             SP, fp
    //     0x1113fb0: ldp             fp, lr, [SP], #0x10
    // 0x1113fb4: ret
    //     0x1113fb4: ret             
    // 0x1113fb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1113fb8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1113fbc: b               #0x1113f04
  }
}

// class id: 3482, size: 0x14, field offset: 0x10
class NamespaceSelector extends SimpleSelector {

  _ visit(/* No info */) {
    // ** addr: 0xd0220c, size: 0x48
    // 0xd0220c: EnterFrame
    //     0xd0220c: stp             fp, lr, [SP, #-0x10]!
    //     0xd02210: mov             fp, SP
    // 0xd02214: mov             x16, x2
    // 0xd02218: mov             x2, x1
    // 0xd0221c: mov             x1, x16
    // 0xd02220: CheckStackOverflow
    //     0xd02220: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd02224: cmp             SP, x16
    //     0xd02228: b.ls            #0xd0224c
    // 0xd0222c: r0 = LoadClassIdInstr(r1)
    //     0xd0222c: ldur            x0, [x1, #-1]
    //     0xd02230: ubfx            x0, x0, #0xc, #0x14
    // 0xd02234: r0 = GDT[cid_x0 + -0xfd7]()
    //     0xd02234: sub             lr, x0, #0xfd7
    //     0xd02238: ldr             lr, [x21, lr, lsl #3]
    //     0xd0223c: blr             lr
    // 0xd02240: LeaveFrame
    //     0xd02240: mov             SP, fp
    //     0xd02244: ldp             fp, lr, [SP], #0x10
    // 0xd02248: ret
    //     0xd02248: ret             
    // 0xd0224c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0224c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd02250: b               #0xd0222c
  }
  _ toString(/* No info */) {
    // ** addr: 0x1113b34, size: 0x1e4
    // 0x1113b34: EnterFrame
    //     0x1113b34: stp             fp, lr, [SP, #-0x10]!
    //     0x1113b38: mov             fp, SP
    // 0x1113b3c: AllocStack(0x18)
    //     0x1113b3c: sub             SP, SP, #0x18
    // 0x1113b40: CheckStackOverflow
    //     0x1113b40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1113b44: cmp             SP, x16
    //     0x1113b48: b.ls            #0x1113d0c
    // 0x1113b4c: ldr             x3, [fp, #0x10]
    // 0x1113b50: LoadField: r4 = r3->field_f
    //     0x1113b50: ldur            w4, [x3, #0xf]
    // 0x1113b54: DecompressPointer r4
    //     0x1113b54: add             x4, x4, HEAP, lsl #32
    // 0x1113b58: stur            x4, [fp, #-8]
    // 0x1113b5c: r0 = 60
    //     0x1113b5c: mov             x0, #0x3c
    // 0x1113b60: branchIfSmi(r4, 0x1113b6c)
    //     0x1113b60: tbz             w4, #0, #0x1113b6c
    // 0x1113b64: r0 = LoadClassIdInstr(r4)
    //     0x1113b64: ldur            x0, [x4, #-1]
    //     0x1113b68: ubfx            x0, x0, #0xc, #0x14
    // 0x1113b6c: cmp             x0, #0xdc1
    // 0x1113b70: b.ne            #0x1113b84
    // 0x1113b74: mov             x0, x3
    // 0x1113b78: r3 = "*"
    //     0x1113b78: add             x3, PP, #0x20, lsl #12  ; [pp+0x20388] "*"
    //     0x1113b7c: ldr             x3, [x3, #0x388]
    // 0x1113b80: b               #0x1113be4
    // 0x1113b84: cmp             w4, NULL
    // 0x1113b88: b.ne            #0x1113b94
    // 0x1113b8c: r0 = ""
    //     0x1113b8c: ldr             x0, [PP, #0x900]  ; [pp+0x900] ""
    // 0x1113b90: b               #0x1113bdc
    // 0x1113b94: mov             x0, x4
    // 0x1113b98: r2 = Null
    //     0x1113b98: mov             x2, NULL
    // 0x1113b9c: r1 = Null
    //     0x1113b9c: mov             x1, NULL
    // 0x1113ba0: r4 = 60
    //     0x1113ba0: mov             x4, #0x3c
    // 0x1113ba4: branchIfSmi(r0, 0x1113bb0)
    //     0x1113ba4: tbz             w0, #0, #0x1113bb0
    // 0x1113ba8: r4 = LoadClassIdInstr(r0)
    //     0x1113ba8: ldur            x4, [x0, #-1]
    //     0x1113bac: ubfx            x4, x4, #0xc, #0x14
    // 0x1113bb0: cmp             x4, #0xdc2
    // 0x1113bb4: b.eq            #0x1113bcc
    // 0x1113bb8: r8 = Identifier
    //     0x1113bb8: add             x8, PP, #0x7e, lsl #12  ; [pp+0x7ecd8] Type: Identifier
    //     0x1113bbc: ldr             x8, [x8, #0xcd8]
    // 0x1113bc0: r3 = Null
    //     0x1113bc0: add             x3, PP, #0x7e, lsl #12  ; [pp+0x7ece0] Null
    //     0x1113bc4: ldr             x3, [x3, #0xce0]
    // 0x1113bc8: r0 = DefaultTypeTest()
    //     0x1113bc8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x1113bcc: ldur            x0, [fp, #-8]
    // 0x1113bd0: LoadField: r1 = r0->field_b
    //     0x1113bd0: ldur            w1, [x0, #0xb]
    // 0x1113bd4: DecompressPointer r1
    //     0x1113bd4: add             x1, x1, HEAP, lsl #32
    // 0x1113bd8: mov             x0, x1
    // 0x1113bdc: mov             x3, x0
    // 0x1113be0: ldr             x0, [fp, #0x10]
    // 0x1113be4: stur            x3, [fp, #-8]
    // 0x1113be8: r1 = Null
    //     0x1113be8: mov             x1, NULL
    // 0x1113bec: r2 = 6
    //     0x1113bec: mov             x2, #6
    // 0x1113bf0: r0 = AllocateArray()
    //     0x1113bf0: bl              #0x13df928  ; AllocateArrayStub
    // 0x1113bf4: mov             x3, x0
    // 0x1113bf8: ldur            x0, [fp, #-8]
    // 0x1113bfc: stur            x3, [fp, #-0x10]
    // 0x1113c00: StoreField: r3->field_f = r0
    //     0x1113c00: stur            w0, [x3, #0xf]
    // 0x1113c04: r16 = "|"
    //     0x1113c04: add             x16, PP, #0x18, lsl #12  ; [pp+0x18708] "|"
    //     0x1113c08: ldr             x16, [x16, #0x708]
    // 0x1113c0c: StoreField: r3->field_13 = r16
    //     0x1113c0c: stur            w16, [x3, #0x13]
    // 0x1113c10: ldr             x0, [fp, #0x10]
    // 0x1113c14: LoadField: r4 = r0->field_b
    //     0x1113c14: ldur            w4, [x0, #0xb]
    // 0x1113c18: DecompressPointer r4
    //     0x1113c18: add             x4, x4, HEAP, lsl #32
    // 0x1113c1c: mov             x0, x4
    // 0x1113c20: stur            x4, [fp, #-8]
    // 0x1113c24: r2 = Null
    //     0x1113c24: mov             x2, NULL
    // 0x1113c28: r1 = Null
    //     0x1113c28: mov             x1, NULL
    // 0x1113c2c: r4 = 60
    //     0x1113c2c: mov             x4, #0x3c
    // 0x1113c30: branchIfSmi(r0, 0x1113c3c)
    //     0x1113c30: tbz             w0, #0, #0x1113c3c
    // 0x1113c34: r4 = LoadClassIdInstr(r0)
    //     0x1113c34: ldur            x4, [x0, #-1]
    //     0x1113c38: ubfx            x4, x4, #0xc, #0x14
    // 0x1113c3c: sub             x4, x4, #0xd92
    // 0x1113c40: cmp             x4, #9
    // 0x1113c44: b.ls            #0x1113c5c
    // 0x1113c48: r8 = SimpleSelector?
    //     0x1113c48: add             x8, PP, #0x7e, lsl #12  ; [pp+0x7ecf0] Type: SimpleSelector?
    //     0x1113c4c: ldr             x8, [x8, #0xcf0]
    // 0x1113c50: r3 = Null
    //     0x1113c50: add             x3, PP, #0x7e, lsl #12  ; [pp+0x7ecf8] Null
    //     0x1113c54: ldr             x3, [x3, #0xcf8]
    // 0x1113c58: r0 = DefaultNullableTypeTest()
    //     0x1113c58: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0x1113c5c: ldur            x0, [fp, #-8]
    // 0x1113c60: cmp             w0, NULL
    // 0x1113c64: b.eq            #0x1113d14
    // 0x1113c68: LoadField: r1 = r0->field_b
    //     0x1113c68: ldur            w1, [x0, #0xb]
    // 0x1113c6c: DecompressPointer r1
    //     0x1113c6c: add             x1, x1, HEAP, lsl #32
    // 0x1113c70: str             x1, [SP]
    // 0x1113c74: r4 = 0
    //     0x1113c74: mov             x4, #0
    // 0x1113c78: ldr             x0, [SP]
    // 0x1113c7c: r16 = 139822029843448
    //     0x1113c7c: add             x16, PP, #0x7e, lsl #12  ; [pp+0x7ed08] IMM: 0x7f2ada6babf8
    //     0x1113c80: add             x16, x16, #0xd08
    // 0x1113c84: ldp             lr, x5, [x16]
    // 0x1113c88: blr             lr
    // 0x1113c8c: mov             x3, x0
    // 0x1113c90: r2 = Null
    //     0x1113c90: mov             x2, NULL
    // 0x1113c94: r1 = Null
    //     0x1113c94: mov             x1, NULL
    // 0x1113c98: stur            x3, [fp, #-8]
    // 0x1113c9c: r4 = 60
    //     0x1113c9c: mov             x4, #0x3c
    // 0x1113ca0: branchIfSmi(r0, 0x1113cac)
    //     0x1113ca0: tbz             w0, #0, #0x1113cac
    // 0x1113ca4: r4 = LoadClassIdInstr(r0)
    //     0x1113ca4: ldur            x4, [x0, #-1]
    //     0x1113ca8: ubfx            x4, x4, #0xc, #0x14
    // 0x1113cac: sub             x4, x4, #0x5e
    // 0x1113cb0: cmp             x4, #1
    // 0x1113cb4: b.ls            #0x1113cc8
    // 0x1113cb8: r8 = String
    //     0x1113cb8: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x1113cbc: r3 = Null
    //     0x1113cbc: add             x3, PP, #0x7e, lsl #12  ; [pp+0x7ed18] Null
    //     0x1113cc0: ldr             x3, [x3, #0xd18]
    // 0x1113cc4: r0 = String()
    //     0x1113cc4: bl              #0x13ee320  ; IsType_String_Stub
    // 0x1113cc8: ldur            x1, [fp, #-0x10]
    // 0x1113ccc: ldur            x0, [fp, #-8]
    // 0x1113cd0: ArrayStore: r1[2] = r0  ; List_4
    //     0x1113cd0: add             x25, x1, #0x17
    //     0x1113cd4: str             w0, [x25]
    //     0x1113cd8: tbz             w0, #0, #0x1113cf4
    //     0x1113cdc: ldurb           w16, [x1, #-1]
    //     0x1113ce0: ldurb           w17, [x0, #-1]
    //     0x1113ce4: and             x16, x17, x16, lsr #2
    //     0x1113ce8: tst             x16, HEAP, lsr #32
    //     0x1113cec: b.eq            #0x1113cf4
    //     0x1113cf0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1113cf4: ldur            x16, [fp, #-0x10]
    // 0x1113cf8: str             x16, [SP]
    // 0x1113cfc: r0 = _interpolate()
    //     0x1113cfc: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x1113d00: LeaveFrame
    //     0x1113d00: mov             SP, fp
    //     0x1113d04: ldp             fp, lr, [SP], #0x10
    // 0x1113d08: ret
    //     0x1113d08: ret             
    // 0x1113d0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1113d0c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1113d10: b               #0x1113b4c
    // 0x1113d14: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1113d14: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 3483, size: 0x10, field offset: 0x10
class ElementSelector extends SimpleSelector {

  _ visit(/* No info */) {
    // ** addr: 0xd02088, size: 0x48
    // 0xd02088: EnterFrame
    //     0xd02088: stp             fp, lr, [SP, #-0x10]!
    //     0xd0208c: mov             fp, SP
    // 0xd02090: mov             x16, x2
    // 0xd02094: mov             x2, x1
    // 0xd02098: mov             x1, x16
    // 0xd0209c: CheckStackOverflow
    //     0xd0209c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd020a0: cmp             SP, x16
    //     0xd020a4: b.ls            #0xd020c8
    // 0xd020a8: r0 = LoadClassIdInstr(r1)
    //     0xd020a8: ldur            x0, [x1, #-1]
    //     0xd020ac: ubfx            x0, x0, #0xc, #0x14
    // 0xd020b0: r0 = GDT[cid_x0 + -0xfdb]()
    //     0xd020b0: sub             lr, x0, #0xfdb
    //     0xd020b4: ldr             lr, [x21, lr, lsl #3]
    //     0xd020b8: blr             lr
    // 0xd020bc: LeaveFrame
    //     0xd020bc: mov             SP, fp
    //     0xd020c0: ldp             fp, lr, [SP], #0x10
    // 0xd020c4: ret
    //     0xd020c4: ret             
    // 0xd020c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd020c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd020cc: b               #0xd020a8
  }
  _ toString(/* No info */) {
    // ** addr: 0x1113aa0, size: 0x94
    // 0x1113aa0: EnterFrame
    //     0x1113aa0: stp             fp, lr, [SP, #-0x10]!
    //     0x1113aa4: mov             fp, SP
    // 0x1113aa8: AllocStack(0x10)
    //     0x1113aa8: sub             SP, SP, #0x10
    // 0x1113aac: CheckStackOverflow
    //     0x1113aac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1113ab0: cmp             SP, x16
    //     0x1113ab4: b.ls            #0x1113b2c
    // 0x1113ab8: ldr             x0, [fp, #0x10]
    // 0x1113abc: LoadField: r1 = r0->field_b
    //     0x1113abc: ldur            w1, [x0, #0xb]
    // 0x1113ac0: DecompressPointer r1
    //     0x1113ac0: add             x1, x1, HEAP, lsl #32
    // 0x1113ac4: str             x1, [SP]
    // 0x1113ac8: r4 = 0
    //     0x1113ac8: mov             x4, #0
    // 0x1113acc: ldr             x0, [SP]
    // 0x1113ad0: r16 = 139822029843448
    //     0x1113ad0: add             x16, PP, #0x7e, lsl #12  ; [pp+0x7ed48] IMM: 0x7f2ada6babf8
    //     0x1113ad4: add             x16, x16, #0xd48
    // 0x1113ad8: ldp             lr, x5, [x16]
    // 0x1113adc: blr             lr
    // 0x1113ae0: mov             x3, x0
    // 0x1113ae4: r2 = Null
    //     0x1113ae4: mov             x2, NULL
    // 0x1113ae8: r1 = Null
    //     0x1113ae8: mov             x1, NULL
    // 0x1113aec: stur            x3, [fp, #-8]
    // 0x1113af0: r4 = 60
    //     0x1113af0: mov             x4, #0x3c
    // 0x1113af4: branchIfSmi(r0, 0x1113b00)
    //     0x1113af4: tbz             w0, #0, #0x1113b00
    // 0x1113af8: r4 = LoadClassIdInstr(r0)
    //     0x1113af8: ldur            x4, [x0, #-1]
    //     0x1113afc: ubfx            x4, x4, #0xc, #0x14
    // 0x1113b00: sub             x4, x4, #0x5e
    // 0x1113b04: cmp             x4, #1
    // 0x1113b08: b.ls            #0x1113b1c
    // 0x1113b0c: r8 = String
    //     0x1113b0c: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x1113b10: r3 = Null
    //     0x1113b10: add             x3, PP, #0x7e, lsl #12  ; [pp+0x7ed58] Null
    //     0x1113b14: ldr             x3, [x3, #0xd58]
    // 0x1113b18: r0 = String()
    //     0x1113b18: bl              #0x13ee320  ; IsType_String_Stub
    // 0x1113b1c: ldur            x0, [fp, #-8]
    // 0x1113b20: LeaveFrame
    //     0x1113b20: mov             SP, fp
    //     0x1113b24: ldp             fp, lr, [SP], #0x10
    // 0x1113b28: ret
    //     0x1113b28: ret             
    // 0x1113b2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1113b2c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1113b30: b               #0x1113ab8
  }
}

// class id: 3484, size: 0x18, field offset: 0xc
class SimpleSelectorSequence extends TreeNode {

  _ visit(/* No info */) {
    // ** addr: 0xd01fd0, size: 0x3c
    // 0xd01fd0: EnterFrame
    //     0xd01fd0: stp             fp, lr, [SP, #-0x10]!
    //     0xd01fd4: mov             fp, SP
    // 0xd01fd8: mov             x16, x2
    // 0xd01fdc: mov             x2, x1
    // 0xd01fe0: mov             x1, x16
    // 0xd01fe4: CheckStackOverflow
    //     0xd01fe4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd01fe8: cmp             SP, x16
    //     0xd01fec: b.ls            #0xd02004
    // 0xd01ff0: r0 = visitSimpleSelectorSequence()
    //     0xd01ff0: bl              #0xd0202c  ; [package:csslib/visitor.dart] Visitor::visitSimpleSelectorSequence
    // 0xd01ff4: r0 = Null
    //     0xd01ff4: mov             x0, NULL
    // 0xd01ff8: LeaveFrame
    //     0xd01ff8: mov             SP, fp
    //     0xd01ffc: ldp             fp, lr, [SP], #0x10
    // 0xd02000: ret
    //     0xd02000: ret             
    // 0xd02004: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd02004: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd02008: b               #0xd01ff0
  }
  _ toString(/* No info */) {
    // ** addr: 0x1113a04, size: 0x9c
    // 0x1113a04: EnterFrame
    //     0x1113a04: stp             fp, lr, [SP, #-0x10]!
    //     0x1113a08: mov             fp, SP
    // 0x1113a0c: AllocStack(0x10)
    //     0x1113a0c: sub             SP, SP, #0x10
    // 0x1113a10: CheckStackOverflow
    //     0x1113a10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1113a14: cmp             SP, x16
    //     0x1113a18: b.ls            #0x1113a98
    // 0x1113a1c: ldr             x0, [fp, #0x10]
    // 0x1113a20: LoadField: r1 = r0->field_13
    //     0x1113a20: ldur            w1, [x0, #0x13]
    // 0x1113a24: DecompressPointer r1
    //     0x1113a24: add             x1, x1, HEAP, lsl #32
    // 0x1113a28: LoadField: r0 = r1->field_b
    //     0x1113a28: ldur            w0, [x1, #0xb]
    // 0x1113a2c: DecompressPointer r0
    //     0x1113a2c: add             x0, x0, HEAP, lsl #32
    // 0x1113a30: str             x0, [SP]
    // 0x1113a34: r4 = 0
    //     0x1113a34: mov             x4, #0
    // 0x1113a38: ldr             x0, [SP]
    // 0x1113a3c: r16 = 139822029843448
    //     0x1113a3c: add             x16, PP, #0x7e, lsl #12  ; [pp+0x7ec60] IMM: 0x7f2ada6babf8
    //     0x1113a40: add             x16, x16, #0xc60
    // 0x1113a44: ldp             lr, x5, [x16]
    // 0x1113a48: blr             lr
    // 0x1113a4c: mov             x3, x0
    // 0x1113a50: r2 = Null
    //     0x1113a50: mov             x2, NULL
    // 0x1113a54: r1 = Null
    //     0x1113a54: mov             x1, NULL
    // 0x1113a58: stur            x3, [fp, #-8]
    // 0x1113a5c: r4 = 60
    //     0x1113a5c: mov             x4, #0x3c
    // 0x1113a60: branchIfSmi(r0, 0x1113a6c)
    //     0x1113a60: tbz             w0, #0, #0x1113a6c
    // 0x1113a64: r4 = LoadClassIdInstr(r0)
    //     0x1113a64: ldur            x4, [x0, #-1]
    //     0x1113a68: ubfx            x4, x4, #0xc, #0x14
    // 0x1113a6c: sub             x4, x4, #0x5e
    // 0x1113a70: cmp             x4, #1
    // 0x1113a74: b.ls            #0x1113a88
    // 0x1113a78: r8 = String
    //     0x1113a78: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x1113a7c: r3 = Null
    //     0x1113a7c: add             x3, PP, #0x7e, lsl #12  ; [pp+0x7ec70] Null
    //     0x1113a80: ldr             x3, [x3, #0xc70]
    // 0x1113a84: r0 = String()
    //     0x1113a84: bl              #0x13ee320  ; IsType_String_Stub
    // 0x1113a88: ldur            x0, [fp, #-8]
    // 0x1113a8c: LeaveFrame
    //     0x1113a8c: mov             SP, fp
    //     0x1113a90: ldp             fp, lr, [SP], #0x10
    // 0x1113a94: ret
    //     0x1113a94: ret             
    // 0x1113a98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1113a98: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1113a9c: b               #0x1113a1c
  }
}

// class id: 3485, size: 0x10, field offset: 0xc
class Selector extends TreeNode {

  _ visit(/* No info */) {
    // ** addr: 0xd01f74, size: 0x3c
    // 0xd01f74: EnterFrame
    //     0xd01f74: stp             fp, lr, [SP, #-0x10]!
    //     0xd01f78: mov             fp, SP
    // 0xd01f7c: mov             x16, x2
    // 0xd01f80: mov             x2, x1
    // 0xd01f84: mov             x1, x16
    // 0xd01f88: CheckStackOverflow
    //     0xd01f88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd01f8c: cmp             SP, x16
    //     0xd01f90: b.ls            #0xd01fa8
    // 0xd01f94: r0 = visitExpressions()
    //     0xd01f94: bl              #0x12ea488  ; [package:csslib/visitor.dart] Visitor::visitExpressions
    // 0xd01f98: r0 = Null
    //     0xd01f98: mov             x0, NULL
    // 0xd01f9c: LeaveFrame
    //     0xd01f9c: mov             SP, fp
    //     0xd01fa0: ldp             fp, lr, [SP], #0x10
    // 0xd01fa4: ret
    //     0xd01fa4: ret             
    // 0xd01fa8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd01fa8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd01fac: b               #0xd01f94
  }
}

// class id: 3486, size: 0x10, field offset: 0xc
class SelectorGroup extends TreeNode {

  _ visit(/* No info */) {
    // ** addr: 0xd01f38, size: 0x3c
    // 0xd01f38: EnterFrame
    //     0xd01f38: stp             fp, lr, [SP, #-0x10]!
    //     0xd01f3c: mov             fp, SP
    // 0xd01f40: mov             x16, x2
    // 0xd01f44: mov             x2, x1
    // 0xd01f48: mov             x1, x16
    // 0xd01f4c: CheckStackOverflow
    //     0xd01f4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd01f50: cmp             SP, x16
    //     0xd01f54: b.ls            #0xd01f6c
    // 0xd01f58: r0 = visitExpressions()
    //     0xd01f58: bl              #0x12ea488  ; [package:csslib/visitor.dart] Visitor::visitExpressions
    // 0xd01f5c: r0 = Null
    //     0xd01f5c: mov             x0, NULL
    // 0xd01f60: LeaveFrame
    //     0xd01f60: mov             SP, fp
    //     0xd01f64: ldp             fp, lr, [SP], #0x10
    // 0xd01f68: ret
    //     0xd01f68: ret             
    // 0xd01f6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd01f6c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd01f70: b               #0xd01f58
  }
}

// class id: 3487, size: 0xc, field offset: 0xc
abstract class Expression extends TreeNode {
}

// class id: 3488, size: 0x10, field offset: 0xc
class Expressions extends Expression {

  _ visit(/* No info */) {
    // ** addr: 0xd01eec, size: 0x4c
    // 0xd01eec: EnterFrame
    //     0xd01eec: stp             fp, lr, [SP, #-0x10]!
    //     0xd01ef0: mov             fp, SP
    // 0xd01ef4: mov             x16, x2
    // 0xd01ef8: mov             x2, x1
    // 0xd01efc: mov             x1, x16
    // 0xd01f00: CheckStackOverflow
    //     0xd01f00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd01f04: cmp             SP, x16
    //     0xd01f08: b.ls            #0xd01f30
    // 0xd01f0c: r0 = LoadClassIdInstr(r1)
    //     0xd01f0c: ldur            x0, [x1, #-1]
    //     0xd01f10: ubfx            x0, x0, #0xc, #0x14
    // 0xd01f14: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd01f14: sub             lr, x0, #1, lsl #12
    //     0xd01f18: ldr             lr, [x21, lr, lsl #3]
    //     0xd01f1c: blr             lr
    // 0xd01f20: r0 = Null
    //     0xd01f20: mov             x0, NULL
    // 0xd01f24: LeaveFrame
    //     0xd01f24: mov             SP, fp
    //     0xd01f28: ldp             fp, lr, [SP], #0x10
    // 0xd01f2c: ret
    //     0xd01f2c: ret             
    // 0xd01f30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd01f30: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd01f34: b               #0xd01f0c
  }
}

// class id: 3489, size: 0x10, field offset: 0xc
class GroupTerm extends Expression {

  _ visit(/* No info */) {
    // ** addr: 0xd01dc0, size: 0x3c
    // 0xd01dc0: EnterFrame
    //     0xd01dc0: stp             fp, lr, [SP, #-0x10]!
    //     0xd01dc4: mov             fp, SP
    // 0xd01dc8: mov             x16, x2
    // 0xd01dcc: mov             x2, x1
    // 0xd01dd0: mov             x1, x16
    // 0xd01dd4: CheckStackOverflow
    //     0xd01dd4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd01dd8: cmp             SP, x16
    //     0xd01ddc: b.ls            #0xd01df4
    // 0xd01de0: r0 = visitGroupTerm()
    //     0xd01de0: bl              #0xd01dfc  ; [package:csslib/visitor.dart] Visitor::visitGroupTerm
    // 0xd01de4: r0 = Null
    //     0xd01de4: mov             x0, NULL
    // 0xd01de8: LeaveFrame
    //     0xd01de8: mov             SP, fp
    //     0xd01dec: ldp             fp, lr, [SP], #0x10
    // 0xd01df0: ret
    //     0xd01df0: ret             
    // 0xd01df4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd01df4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd01df8: b               #0xd01de0
  }
}

// class id: 3490, size: 0xc, field offset: 0xc
class UnicodeRangeTerm extends Expression {
}

// class id: 3491, size: 0xc, field offset: 0xc
class OperatorMinus extends Expression {
}

// class id: 3492, size: 0xc, field offset: 0xc
class OperatorPlus extends Expression {
}

// class id: 3493, size: 0xc, field offset: 0xc
class OperatorComma extends Expression {
}

// class id: 3494, size: 0xc, field offset: 0xc
class OperatorSlash extends Expression {
}

// class id: 3495, size: 0x10, field offset: 0xc
class VarUsage extends Expression {

  _ visit(/* No info */) {
    // ** addr: 0xd01d84, size: 0x3c
    // 0xd01d84: EnterFrame
    //     0xd01d84: stp             fp, lr, [SP, #-0x10]!
    //     0xd01d88: mov             fp, SP
    // 0xd01d8c: mov             x16, x2
    // 0xd01d90: mov             x2, x1
    // 0xd01d94: mov             x1, x16
    // 0xd01d98: CheckStackOverflow
    //     0xd01d98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd01d9c: cmp             SP, x16
    //     0xd01da0: b.ls            #0xd01db8
    // 0xd01da4: r0 = visitExpressions()
    //     0xd01da4: bl              #0x12ea488  ; [package:csslib/visitor.dart] Visitor::visitExpressions
    // 0xd01da8: r0 = Null
    //     0xd01da8: mov             x0, NULL
    // 0xd01dac: LeaveFrame
    //     0xd01dac: mov             SP, fp
    //     0xd01db0: ldp             fp, lr, [SP], #0x10
    // 0xd01db4: ret
    //     0xd01db4: ret             
    // 0xd01db8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd01db8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd01dbc: b               #0xd01da4
  }
}

// class id: 3496, size: 0x14, field offset: 0xc
class KeyFrameBlock extends Expression {

  _ visit(/* No info */) {
    // ** addr: 0xd01c5c, size: 0x3c
    // 0xd01c5c: EnterFrame
    //     0xd01c5c: stp             fp, lr, [SP, #-0x10]!
    //     0xd01c60: mov             fp, SP
    // 0xd01c64: mov             x16, x2
    // 0xd01c68: mov             x2, x1
    // 0xd01c6c: mov             x1, x16
    // 0xd01c70: CheckStackOverflow
    //     0xd01c70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd01c74: cmp             SP, x16
    //     0xd01c78: b.ls            #0xd01c90
    // 0xd01c7c: r0 = visitKeyFrameBlock()
    //     0xd01c7c: bl              #0xd01cb8  ; [package:csslib/visitor.dart] Visitor::visitKeyFrameBlock
    // 0xd01c80: r0 = Null
    //     0xd01c80: mov             x0, NULL
    // 0xd01c84: LeaveFrame
    //     0xd01c84: mov             SP, fp
    //     0xd01c88: ldp             fp, lr, [SP], #0x10
    // 0xd01c8c: ret
    //     0xd01c8c: ret             
    // 0xd01c90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd01c90: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd01c94: b               #0xd01c7c
  }
}

// class id: 3497, size: 0x14, field offset: 0xc
class LiteralTerm extends Expression {

  void dyn:set:value(LiteralTerm, Object) {
    // ** addr: 0xd019d4, size: 0x7c
    // 0xd019d4: EnterFrame
    //     0xd019d4: stp             fp, lr, [SP, #-0x10]!
    //     0xd019d8: mov             fp, SP
    // 0xd019dc: ldr             x0, [fp, #0x10]
    // 0xd019e0: r2 = Null
    //     0xd019e0: mov             x2, NULL
    // 0xd019e4: r1 = Null
    //     0xd019e4: mov             x1, NULL
    // 0xd019e8: cmp             w0, NULL
    // 0xd019ec: b.ne            #0xd01a00
    // 0xd019f0: r8 = Object
    //     0xd019f0: ldr             x8, [PP, #0xd0]  ; [pp+0xd0] Type: Object
    // 0xd019f4: r3 = Null
    //     0xd019f4: add             x3, PP, #0x7e, lsl #12  ; [pp+0x7ec80] Null
    //     0xd019f8: ldr             x3, [x3, #0xc80]
    // 0xd019fc: r0 = Object()
    //     0xd019fc: bl              #0x13ef428  ; IsType_Object_Stub
    // 0xd01a00: ldr             x0, [fp, #0x10]
    // 0xd01a04: ldr             x1, [fp, #0x18]
    // 0xd01a08: StoreField: r1->field_b = r0
    //     0xd01a08: stur            w0, [x1, #0xb]
    //     0xd01a0c: tbz             w0, #0, #0xd01a28
    //     0xd01a10: ldurb           w16, [x1, #-1]
    //     0xd01a14: ldurb           w17, [x0, #-1]
    //     0xd01a18: and             x16, x17, x16, lsr #2
    //     0xd01a1c: tst             x16, HEAP, lsr #32
    //     0xd01a20: b.eq            #0xd01a28
    //     0xd01a24: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd01a28: r0 = Null
    //     0xd01a28: mov             x0, NULL
    // 0xd01a2c: LeaveFrame
    //     0xd01a2c: mov             SP, fp
    //     0xd01a30: ldp             fp, lr, [SP], #0x10
    // 0xd01a34: ret
    //     0xd01a34: ret             
  }
}

// class id: 3498, size: 0x14, field offset: 0x14
class IE8Term extends LiteralTerm {
}

// class id: 3499, size: 0x18, field offset: 0x14
class FunctionTerm extends LiteralTerm {

  _ visit(/* No info */) {
    // ** addr: 0xd01a80, size: 0x3c
    // 0xd01a80: EnterFrame
    //     0xd01a80: stp             fp, lr, [SP, #-0x10]!
    //     0xd01a84: mov             fp, SP
    // 0xd01a88: mov             x16, x2
    // 0xd01a8c: mov             x2, x1
    // 0xd01a90: mov             x1, x16
    // 0xd01a94: CheckStackOverflow
    //     0xd01a94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd01a98: cmp             SP, x16
    //     0xd01a9c: b.ls            #0xd01ab4
    // 0xd01aa0: r0 = visitFunctionTerm()
    //     0xd01aa0: bl              #0xd01abc  ; [package:csslib/visitor.dart] Visitor::visitFunctionTerm
    // 0xd01aa4: r0 = Null
    //     0xd01aa4: mov             x0, NULL
    // 0xd01aa8: LeaveFrame
    //     0xd01aa8: mov             SP, fp
    //     0xd01aac: ldp             fp, lr, [SP], #0x10
    // 0xd01ab0: ret
    //     0xd01ab0: ret             
    // 0xd01ab4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd01ab4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd01ab8: b               #0xd01aa0
  }
}

// class id: 3500, size: 0x14, field offset: 0x14
class HexColorTerm extends LiteralTerm {
}

// class id: 3501, size: 0x14, field offset: 0x14
class UriTerm extends LiteralTerm {
}

// class id: 3502, size: 0x14, field offset: 0x14
class FractionTerm extends LiteralTerm {
}

// class id: 3503, size: 0x14, field offset: 0x14
class ExTerm extends LiteralTerm {
}

// class id: 3504, size: 0x14, field offset: 0x14
class EmTerm extends LiteralTerm {
}

// class id: 3505, size: 0x14, field offset: 0x14
class PercentageTerm extends LiteralTerm {
}

// class id: 3506, size: 0x1c, field offset: 0x14
abstract class UnitTerm extends LiteralTerm {

  _ toString(/* No info */) {
    // ** addr: 0x11137c0, size: 0x94
    // 0x11137c0: EnterFrame
    //     0x11137c0: stp             fp, lr, [SP, #-0x10]!
    //     0x11137c4: mov             fp, SP
    // 0x11137c8: AllocStack(0x18)
    //     0x11137c8: sub             SP, SP, #0x18
    // 0x11137cc: CheckStackOverflow
    //     0x11137cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11137d0: cmp             SP, x16
    //     0x11137d4: b.ls            #0x111384c
    // 0x11137d8: ldr             x0, [fp, #0x10]
    // 0x11137dc: LoadField: r3 = r0->field_f
    //     0x11137dc: ldur            w3, [x0, #0xf]
    // 0x11137e0: DecompressPointer r3
    //     0x11137e0: add             x3, x3, HEAP, lsl #32
    // 0x11137e4: stur            x3, [fp, #-8]
    // 0x11137e8: r1 = Null
    //     0x11137e8: mov             x1, NULL
    // 0x11137ec: r2 = 4
    //     0x11137ec: mov             x2, #4
    // 0x11137f0: r0 = AllocateArray()
    //     0x11137f0: bl              #0x13df928  ; AllocateArrayStub
    // 0x11137f4: mov             x2, x0
    // 0x11137f8: ldur            x0, [fp, #-8]
    // 0x11137fc: stur            x2, [fp, #-0x10]
    // 0x1113800: StoreField: r2->field_f = r0
    //     0x1113800: stur            w0, [x2, #0xf]
    // 0x1113804: ldr             x1, [fp, #0x10]
    // 0x1113808: r0 = unitToString()
    //     0x1113808: bl              #0x1113854  ; [package:csslib/visitor.dart] UnitTerm::unitToString
    // 0x111380c: ldur            x1, [fp, #-0x10]
    // 0x1113810: ArrayStore: r1[1] = r0  ; List_4
    //     0x1113810: add             x25, x1, #0x13
    //     0x1113814: str             w0, [x25]
    //     0x1113818: tbz             w0, #0, #0x1113834
    //     0x111381c: ldurb           w16, [x1, #-1]
    //     0x1113820: ldurb           w17, [x0, #-1]
    //     0x1113824: and             x16, x17, x16, lsr #2
    //     0x1113828: tst             x16, HEAP, lsr #32
    //     0x111382c: b.eq            #0x1113834
    //     0x1113830: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1113834: ldur            x16, [fp, #-0x10]
    // 0x1113838: str             x16, [SP]
    // 0x111383c: r0 = _interpolate()
    //     0x111383c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x1113840: LeaveFrame
    //     0x1113840: mov             SP, fp
    //     0x1113844: ldp             fp, lr, [SP], #0x10
    // 0x1113848: ret
    //     0x1113848: ret             
    // 0x111384c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x111384c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1113850: b               #0x11137d8
  }
  _ unitToString(/* No info */) {
    // ** addr: 0x1113854, size: 0x34
    // 0x1113854: EnterFrame
    //     0x1113854: stp             fp, lr, [SP, #-0x10]!
    //     0x1113858: mov             fp, SP
    // 0x111385c: CheckStackOverflow
    //     0x111385c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1113860: cmp             SP, x16
    //     0x1113864: b.ls            #0x1113880
    // 0x1113868: LoadField: r0 = r1->field_13
    //     0x1113868: ldur            x0, [x1, #0x13]
    // 0x111386c: mov             x1, x0
    // 0x1113870: r0 = unitToString()
    //     0x1113870: bl              #0x1113888  ; [package:csslib/parser.dart] TokenKind::unitToString
    // 0x1113874: LeaveFrame
    //     0x1113874: mov             SP, fp
    //     0x1113878: ldp             fp, lr, [SP], #0x10
    // 0x111387c: ret
    //     0x111387c: ret             
    // 0x1113880: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1113880: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1113884: b               #0x1113868
  }
}

// class id: 3507, size: 0x1c, field offset: 0x1c
class ViewportTerm extends UnitTerm {
}

// class id: 3508, size: 0x1c, field offset: 0x1c
class LineHeightTerm extends UnitTerm {
}

// class id: 3509, size: 0x1c, field offset: 0x1c
class RemTerm extends UnitTerm {
}

// class id: 3510, size: 0x1c, field offset: 0x1c
class ChTerm extends UnitTerm {
}

// class id: 3511, size: 0x1c, field offset: 0x1c
class ResolutionTerm extends UnitTerm {
}

// class id: 3512, size: 0x1c, field offset: 0x1c
class FreqTerm extends UnitTerm {
}

// class id: 3513, size: 0x1c, field offset: 0x1c
class TimeTerm extends UnitTerm {
}

// class id: 3514, size: 0x1c, field offset: 0x1c
class AngleTerm extends UnitTerm {
}

// class id: 3515, size: 0x1c, field offset: 0x1c
class LengthTerm extends UnitTerm {
}

// class id: 3516, size: 0x14, field offset: 0x14
class NumberTerm extends LiteralTerm {
}

// class id: 3517, size: 0x14, field offset: 0x14
class ItemTerm extends NumberTerm {
}

// class id: 3518, size: 0x18, field offset: 0x14
class CalcTerm extends LiteralTerm {

  _ visit(/* No info */) {
    // ** addr: 0xd01980, size: 0x3c
    // 0xd01980: EnterFrame
    //     0xd01980: stp             fp, lr, [SP, #-0x10]!
    //     0xd01984: mov             fp, SP
    // 0xd01988: mov             x16, x2
    // 0xd0198c: mov             x2, x1
    // 0xd01990: mov             x1, x16
    // 0xd01994: CheckStackOverflow
    //     0xd01994: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd01998: cmp             SP, x16
    //     0xd0199c: b.ls            #0xd019b4
    // 0xd019a0: r0 = Shader._()
    //     0xd019a0: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xd019a4: r0 = Null
    //     0xd019a4: mov             x0, NULL
    // 0xd019a8: LeaveFrame
    //     0xd019a8: mov             SP, fp
    //     0xd019ac: ldp             fp, lr, [SP], #0x10
    // 0xd019b0: ret
    //     0xd019b0: ret             
    // 0xd019b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd019b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd019b8: b               #0xd019a0
  }
  _ toString(/* No info */) {
    // ** addr: 0x1113740, size: 0x80
    // 0x1113740: EnterFrame
    //     0x1113740: stp             fp, lr, [SP, #-0x10]!
    //     0x1113744: mov             fp, SP
    // 0x1113748: AllocStack(0x10)
    //     0x1113748: sub             SP, SP, #0x10
    // 0x111374c: CheckStackOverflow
    //     0x111374c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1113750: cmp             SP, x16
    //     0x1113754: b.ls            #0x11137b8
    // 0x1113758: ldr             x0, [fp, #0x10]
    // 0x111375c: LoadField: r3 = r0->field_f
    //     0x111375c: ldur            w3, [x0, #0xf]
    // 0x1113760: DecompressPointer r3
    //     0x1113760: add             x3, x3, HEAP, lsl #32
    // 0x1113764: stur            x3, [fp, #-8]
    // 0x1113768: r1 = Null
    //     0x1113768: mov             x1, NULL
    // 0x111376c: r2 = 8
    //     0x111376c: mov             x2, #8
    // 0x1113770: r0 = AllocateArray()
    //     0x1113770: bl              #0x13df928  ; AllocateArrayStub
    // 0x1113774: mov             x1, x0
    // 0x1113778: ldur            x0, [fp, #-8]
    // 0x111377c: StoreField: r1->field_f = r0
    //     0x111377c: stur            w0, [x1, #0xf]
    // 0x1113780: r16 = "("
    //     0x1113780: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc98] "("
    //     0x1113784: ldr             x16, [x16, #0xc98]
    // 0x1113788: StoreField: r1->field_13 = r16
    //     0x1113788: stur            w16, [x1, #0x13]
    // 0x111378c: ldr             x0, [fp, #0x10]
    // 0x1113790: LoadField: r2 = r0->field_13
    //     0x1113790: ldur            w2, [x0, #0x13]
    // 0x1113794: DecompressPointer r2
    //     0x1113794: add             x2, x2, HEAP, lsl #32
    // 0x1113798: ArrayStore: r1[0] = r2  ; List_4
    //     0x1113798: stur            w2, [x1, #0x17]
    // 0x111379c: r16 = ")"
    //     0x111379c: ldr             x16, [PP, #0xe60]  ; [pp+0xe60] ")"
    // 0x11137a0: StoreField: r1->field_1b = r16
    //     0x11137a0: stur            w16, [x1, #0x1b]
    // 0x11137a4: str             x1, [SP]
    // 0x11137a8: r0 = _interpolate()
    //     0x11137a8: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11137ac: LeaveFrame
    //     0x11137ac: mov             SP, fp
    //     0x11137b0: ldp             fp, lr, [SP], #0x10
    // 0x11137b4: ret
    //     0x11137b4: ret             
    // 0x11137b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11137b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11137bc: b               #0x1113758
  }
}

// class id: 3519, size: 0xc, field offset: 0xc
class Negation extends TreeNode {

  String dyn:get:name(Negation) {
    // ** addr: 0xe199d4, size: 0x24
    // 0xe199d4: r0 = "not"
    //     0xe199d4: add             x0, PP, #0x20, lsl #12  ; [pp+0x202c8] "not"
    //     0xe199d8: ldr             x0, [x0, #0x2c8]
    // 0xe199dc: ret
    //     0xe199dc: ret             
  }
}

// class id: 3520, size: 0xc, field offset: 0xc
class ThisOperator extends TreeNode {

  String dyn:get:name(ThisOperator) {
    // ** addr: 0xe198d8, size: 0x20
    // 0xe198d8: r0 = "&"
    //     0xe198d8: ldr             x0, [PP, #0x11c8]  ; [pp+0x11c8] "&"
    // 0xe198dc: ret
    //     0xe198dc: ret             
  }
}

// class id: 3521, size: 0xc, field offset: 0xc
class Wildcard extends TreeNode {

  String dyn:get:name(Wildcard) {
    // ** addr: 0xe1a418, size: 0x24
    // 0xe1a418: r0 = "*"
    //     0xe1a418: add             x0, PP, #0x20, lsl #12  ; [pp+0x20388] "*"
    //     0xe1a41c: ldr             x0, [x0, #0x388]
    // 0xe1a420: ret
    //     0xe1a420: ret             
  }
}

// class id: 3522, size: 0x10, field offset: 0xc
class Identifier extends TreeNode {

  String toString(Identifier) {
    // ** addr: 0x11136f4, size: 0x4c
    // 0x11136f4: EnterFrame
    //     0x11136f4: stp             fp, lr, [SP, #-0x10]!
    //     0x11136f8: mov             fp, SP
    // 0x11136fc: CheckStackOverflow
    //     0x11136fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1113700: cmp             SP, x16
    //     0x1113704: b.ls            #0x1113738
    // 0x1113708: ldr             x0, [fp, #0x10]
    // 0x111370c: LoadField: r1 = r0->field_7
    //     0x111370c: ldur            w1, [x0, #7]
    // 0x1113710: DecompressPointer r1
    //     0x1113710: add             x1, x1, HEAP, lsl #32
    // 0x1113714: LoadField: r0 = r1->field_7
    //     0x1113714: ldur            w0, [x1, #7]
    // 0x1113718: DecompressPointer r0
    //     0x1113718: add             x0, x0, HEAP, lsl #32
    // 0x111371c: LoadField: r2 = r1->field_b
    //     0x111371c: ldur            x2, [x1, #0xb]
    // 0x1113720: LoadField: r3 = r1->field_13
    //     0x1113720: ldur            x3, [x1, #0x13]
    // 0x1113724: mov             x1, x0
    // 0x1113728: r0 = getText()
    //     0x1113728: bl              #0xe18ccc  ; [package:source_span/src/file.dart] SourceFile::getText
    // 0x111372c: LeaveFrame
    //     0x111372c: mov             SP, fp
    //     0x1113730: ldp             fp, lr, [SP], #0x10
    // 0x1113734: ret
    //     0x1113734: ret             
    // 0x1113738: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1113738: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x111373c: b               #0x1113708
  }
}

// class id: 3523, size: 0x8, field offset: 0x8
abstract class Visitor extends Object
    implements VisitorBase {

  _ visitFunctionTerm(/* No info */) {
    // ** addr: 0xd01abc, size: 0xa8
    // 0xd01abc: EnterFrame
    //     0xd01abc: stp             fp, lr, [SP, #-0x10]!
    //     0xd01ac0: mov             fp, SP
    // 0xd01ac4: CheckStackOverflow
    //     0xd01ac4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd01ac8: cmp             SP, x16
    //     0xd01acc: b.ls            #0xd01b5c
    // 0xd01ad0: LoadField: r0 = r2->field_13
    //     0xd01ad0: ldur            w0, [x2, #0x13]
    // 0xd01ad4: DecompressPointer r0
    //     0xd01ad4: add             x0, x0, HEAP, lsl #32
    // 0xd01ad8: r2 = LoadClassIdInstr(r1)
    //     0xd01ad8: ldur            x2, [x1, #-1]
    //     0xd01adc: ubfx            x2, x2, #0xc, #0x14
    // 0xd01ae0: cmp             x2, #0xdc4
    // 0xd01ae4: b.eq            #0xd01b1c
    // 0xd01ae8: cmp             x2, #0xdc5
    // 0xd01aec: b.ne            #0xd01b14
    // 0xd01af0: LoadField: r2 = r1->field_7
    //     0xd01af0: ldur            w2, [x1, #7]
    // 0xd01af4: DecompressPointer r2
    //     0xd01af4: add             x2, x2, HEAP, lsl #32
    // 0xd01af8: LoadField: r1 = r0->field_b
    //     0xd01af8: ldur            w1, [x0, #0xb]
    // 0xd01afc: DecompressPointer r1
    //     0xd01afc: add             x1, x1, HEAP, lsl #32
    // 0xd01b00: mov             x16, x1
    // 0xd01b04: mov             x1, x2
    // 0xd01b08: mov             x2, x16
    // 0xd01b0c: r0 = addAll()
    //     0xd01b0c: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0xd01b10: b               #0xd01b4c
    // 0xd01b14: cmp             x2, #0xdc6
    // 0xd01b18: b.ne            #0xd01b2c
    // 0xd01b1c: LoadField: r2 = r0->field_b
    //     0xd01b1c: ldur            w2, [x0, #0xb]
    // 0xd01b20: DecompressPointer r2
    //     0xd01b20: add             x2, x2, HEAP, lsl #32
    // 0xd01b24: r0 = _visitNodeList()
    //     0xd01b24: bl              #0xd01b64  ; [package:csslib/visitor.dart] Visitor::_visitNodeList
    // 0xd01b28: b               #0xd01b4c
    // 0xd01b2c: r2 = LoadClassIdInstr(r1)
    //     0xd01b2c: ldur            x2, [x1, #-1]
    //     0xd01b30: ubfx            x2, x2, #0xc, #0x14
    // 0xd01b34: mov             x16, x0
    // 0xd01b38: mov             x0, x2
    // 0xd01b3c: mov             x2, x16
    // 0xd01b40: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd01b40: sub             lr, x0, #1, lsl #12
    //     0xd01b44: ldr             lr, [x21, lr, lsl #3]
    //     0xd01b48: blr             lr
    // 0xd01b4c: r0 = Null
    //     0xd01b4c: mov             x0, NULL
    // 0xd01b50: LeaveFrame
    //     0xd01b50: mov             SP, fp
    //     0xd01b54: ldp             fp, lr, [SP], #0x10
    // 0xd01b58: ret
    //     0xd01b58: ret             
    // 0xd01b5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd01b5c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd01b60: b               #0xd01ad0
  }
  _ _visitNodeList(/* No info */) {
    // ** addr: 0xd01b64, size: 0xf8
    // 0xd01b64: EnterFrame
    //     0xd01b64: stp             fp, lr, [SP, #-0x10]!
    //     0xd01b68: mov             fp, SP
    // 0xd01b6c: AllocStack(0x28)
    //     0xd01b6c: sub             SP, SP, #0x28
    // 0xd01b70: SetupParameters(Visitor this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0xd01b70: stur            x1, [fp, #-0x10]
    //     0xd01b74: stur            x2, [fp, #-0x18]
    // 0xd01b78: CheckStackOverflow
    //     0xd01b78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd01b7c: cmp             SP, x16
    //     0xd01b80: b.ls            #0xd01c4c
    // 0xd01b84: r3 = 0
    //     0xd01b84: mov             x3, #0
    // 0xd01b88: stur            x3, [fp, #-8]
    // 0xd01b8c: CheckStackOverflow
    //     0xd01b8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd01b90: cmp             SP, x16
    //     0xd01b94: b.ls            #0xd01c54
    // 0xd01b98: r0 = LoadClassIdInstr(r2)
    //     0xd01b98: ldur            x0, [x2, #-1]
    //     0xd01b9c: ubfx            x0, x0, #0xc, #0x14
    // 0xd01ba0: str             x2, [SP]
    // 0xd01ba4: r0 = GDT[cid_x0 + 0xf078]()
    //     0xd01ba4: mov             x17, #0xf078
    //     0xd01ba8: add             lr, x0, x17
    //     0xd01bac: ldr             lr, [x21, lr, lsl #3]
    //     0xd01bb0: blr             lr
    // 0xd01bb4: r1 = LoadInt32Instr(r0)
    //     0xd01bb4: sbfx            x1, x0, #1, #0x1f
    //     0xd01bb8: tbz             w0, #0, #0xd01bc0
    //     0xd01bbc: ldur            x1, [x0, #7]
    // 0xd01bc0: ldur            x2, [fp, #-8]
    // 0xd01bc4: cmp             x2, x1
    // 0xd01bc8: b.ge            #0xd01c3c
    // 0xd01bcc: ldur            x3, [fp, #-0x18]
    // 0xd01bd0: r0 = BoxInt64Instr(r2)
    //     0xd01bd0: sbfiz           x0, x2, #1, #0x1f
    //     0xd01bd4: cmp             x2, x0, asr #1
    //     0xd01bd8: b.eq            #0xd01be4
    //     0xd01bdc: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xd01be0: stur            x2, [x0, #7]
    // 0xd01be4: r1 = LoadClassIdInstr(r3)
    //     0xd01be4: ldur            x1, [x3, #-1]
    //     0xd01be8: ubfx            x1, x1, #0xc, #0x14
    // 0xd01bec: stp             x0, x3, [SP]
    // 0xd01bf0: mov             x0, x1
    // 0xd01bf4: r0 = GDT[cid_x0 + -0xdfd]()
    //     0xd01bf4: sub             lr, x0, #0xdfd
    //     0xd01bf8: ldr             lr, [x21, lr, lsl #3]
    //     0xd01bfc: blr             lr
    // 0xd01c00: r1 = LoadClassIdInstr(r0)
    //     0xd01c00: ldur            x1, [x0, #-1]
    //     0xd01c04: ubfx            x1, x1, #0xc, #0x14
    // 0xd01c08: mov             x16, x0
    // 0xd01c0c: mov             x0, x1
    // 0xd01c10: mov             x1, x16
    // 0xd01c14: ldur            x2, [fp, #-0x10]
    // 0xd01c18: r0 = GDT[cid_x0 + 0xe553]()
    //     0xd01c18: mov             x17, #0xe553
    //     0xd01c1c: add             lr, x0, x17
    //     0xd01c20: ldr             lr, [x21, lr, lsl #3]
    //     0xd01c24: blr             lr
    // 0xd01c28: ldur            x1, [fp, #-8]
    // 0xd01c2c: add             x3, x1, #1
    // 0xd01c30: ldur            x1, [fp, #-0x10]
    // 0xd01c34: ldur            x2, [fp, #-0x18]
    // 0xd01c38: b               #0xd01b88
    // 0xd01c3c: r0 = Null
    //     0xd01c3c: mov             x0, NULL
    // 0xd01c40: LeaveFrame
    //     0xd01c40: mov             SP, fp
    //     0xd01c44: ldp             fp, lr, [SP], #0x10
    // 0xd01c48: ret
    //     0xd01c48: ret             
    // 0xd01c4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd01c4c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd01c50: b               #0xd01b84
    // 0xd01c54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd01c54: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd01c58: b               #0xd01b98
  }
  _ visitKeyFrameBlock(/* No info */) {
    // ** addr: 0xd01cb8, size: 0xcc
    // 0xd01cb8: EnterFrame
    //     0xd01cb8: stp             fp, lr, [SP, #-0x10]!
    //     0xd01cbc: mov             fp, SP
    // 0xd01cc0: AllocStack(0x10)
    //     0xd01cc0: sub             SP, SP, #0x10
    // 0xd01cc4: SetupParameters(Visitor this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xd01cc4: mov             x3, x1
    //     0xd01cc8: mov             x0, x2
    //     0xd01ccc: stur            x1, [fp, #-8]
    //     0xd01cd0: stur            x2, [fp, #-0x10]
    // 0xd01cd4: CheckStackOverflow
    //     0xd01cd4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd01cd8: cmp             SP, x16
    //     0xd01cdc: b.ls            #0xd01d7c
    // 0xd01ce0: LoadField: r2 = r0->field_b
    //     0xd01ce0: ldur            w2, [x0, #0xb]
    // 0xd01ce4: DecompressPointer r2
    //     0xd01ce4: add             x2, x2, HEAP, lsl #32
    // 0xd01ce8: r1 = LoadClassIdInstr(r3)
    //     0xd01ce8: ldur            x1, [x3, #-1]
    //     0xd01cec: ubfx            x1, x1, #0xc, #0x14
    // 0xd01cf0: cmp             x1, #0xdc4
    // 0xd01cf4: b.eq            #0xd01d24
    // 0xd01cf8: cmp             x1, #0xdc5
    // 0xd01cfc: b.ne            #0xd01d1c
    // 0xd01d00: LoadField: r1 = r3->field_7
    //     0xd01d00: ldur            w1, [x3, #7]
    // 0xd01d04: DecompressPointer r1
    //     0xd01d04: add             x1, x1, HEAP, lsl #32
    // 0xd01d08: LoadField: r4 = r2->field_b
    //     0xd01d08: ldur            w4, [x2, #0xb]
    // 0xd01d0c: DecompressPointer r4
    //     0xd01d0c: add             x4, x4, HEAP, lsl #32
    // 0xd01d10: mov             x2, x4
    // 0xd01d14: r0 = addAll()
    //     0xd01d14: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0xd01d18: b               #0xd01d58
    // 0xd01d1c: cmp             x1, #0xdc6
    // 0xd01d20: b.ne            #0xd01d3c
    // 0xd01d24: LoadField: r0 = r2->field_b
    //     0xd01d24: ldur            w0, [x2, #0xb]
    // 0xd01d28: DecompressPointer r0
    //     0xd01d28: add             x0, x0, HEAP, lsl #32
    // 0xd01d2c: ldur            x1, [fp, #-8]
    // 0xd01d30: mov             x2, x0
    // 0xd01d34: r0 = _visitNodeList()
    //     0xd01d34: bl              #0xd01b64  ; [package:csslib/visitor.dart] Visitor::_visitNodeList
    // 0xd01d38: b               #0xd01d58
    // 0xd01d3c: ldur            x3, [fp, #-8]
    // 0xd01d40: r0 = LoadClassIdInstr(r3)
    //     0xd01d40: ldur            x0, [x3, #-1]
    //     0xd01d44: ubfx            x0, x0, #0xc, #0x14
    // 0xd01d48: mov             x1, x3
    // 0xd01d4c: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd01d4c: sub             lr, x0, #1, lsl #12
    //     0xd01d50: ldr             lr, [x21, lr, lsl #3]
    //     0xd01d54: blr             lr
    // 0xd01d58: ldur            x0, [fp, #-0x10]
    // 0xd01d5c: LoadField: r2 = r0->field_f
    //     0xd01d5c: ldur            w2, [x0, #0xf]
    // 0xd01d60: DecompressPointer r2
    //     0xd01d60: add             x2, x2, HEAP, lsl #32
    // 0xd01d64: ldur            x1, [fp, #-8]
    // 0xd01d68: r0 = visitExpressions()
    //     0xd01d68: bl              #0x12ea488  ; [package:csslib/visitor.dart] Visitor::visitExpressions
    // 0xd01d6c: r0 = Null
    //     0xd01d6c: mov             x0, NULL
    // 0xd01d70: LeaveFrame
    //     0xd01d70: mov             SP, fp
    //     0xd01d74: ldp             fp, lr, [SP], #0x10
    // 0xd01d78: ret
    //     0xd01d78: ret             
    // 0xd01d7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd01d7c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd01d80: b               #0xd01ce0
  }
  _ visitGroupTerm(/* No info */) {
    // ** addr: 0xd01dfc, size: 0xf0
    // 0xd01dfc: EnterFrame
    //     0xd01dfc: stp             fp, lr, [SP, #-0x10]!
    //     0xd01e00: mov             fp, SP
    // 0xd01e04: AllocStack(0x20)
    //     0xd01e04: sub             SP, SP, #0x20
    // 0xd01e08: SetupParameters(Visitor this /* r1 => r3, fp-0x20 */)
    //     0xd01e08: mov             x3, x1
    //     0xd01e0c: stur            x1, [fp, #-0x20]
    // 0xd01e10: CheckStackOverflow
    //     0xd01e10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd01e14: cmp             SP, x16
    //     0xd01e18: b.ls            #0xd01edc
    // 0xd01e1c: LoadField: r4 = r2->field_b
    //     0xd01e1c: ldur            w4, [x2, #0xb]
    // 0xd01e20: DecompressPointer r4
    //     0xd01e20: add             x4, x4, HEAP, lsl #32
    // 0xd01e24: stur            x4, [fp, #-0x18]
    // 0xd01e28: LoadField: r0 = r4->field_b
    //     0xd01e28: ldur            w0, [x4, #0xb]
    // 0xd01e2c: r5 = LoadInt32Instr(r0)
    //     0xd01e2c: sbfx            x5, x0, #1, #0x1f
    // 0xd01e30: stur            x5, [fp, #-0x10]
    // 0xd01e34: r0 = 0
    //     0xd01e34: mov             x0, #0
    // 0xd01e38: CheckStackOverflow
    //     0xd01e38: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd01e3c: cmp             SP, x16
    //     0xd01e40: b.ls            #0xd01ee4
    // 0xd01e44: LoadField: r1 = r4->field_b
    //     0xd01e44: ldur            w1, [x4, #0xb]
    // 0xd01e48: r2 = LoadInt32Instr(r1)
    //     0xd01e48: sbfx            x2, x1, #1, #0x1f
    // 0xd01e4c: cmp             x5, x2
    // 0xd01e50: b.ne            #0xd01ebc
    // 0xd01e54: cmp             x0, x2
    // 0xd01e58: b.ge            #0xd01eac
    // 0xd01e5c: LoadField: r1 = r4->field_f
    //     0xd01e5c: ldur            w1, [x4, #0xf]
    // 0xd01e60: DecompressPointer r1
    //     0xd01e60: add             x1, x1, HEAP, lsl #32
    // 0xd01e64: ArrayLoad: r2 = r1[r0]  ; Unknown_4
    //     0xd01e64: add             x16, x1, x0, lsl #2
    //     0xd01e68: ldur            w2, [x16, #0xf]
    // 0xd01e6c: DecompressPointer r2
    //     0xd01e6c: add             x2, x2, HEAP, lsl #32
    // 0xd01e70: add             x6, x0, #1
    // 0xd01e74: stur            x6, [fp, #-8]
    // 0xd01e78: r0 = LoadClassIdInstr(r2)
    //     0xd01e78: ldur            x0, [x2, #-1]
    //     0xd01e7c: ubfx            x0, x0, #0xc, #0x14
    // 0xd01e80: mov             x1, x2
    // 0xd01e84: mov             x2, x3
    // 0xd01e88: r0 = GDT[cid_x0 + 0xe553]()
    //     0xd01e88: mov             x17, #0xe553
    //     0xd01e8c: add             lr, x0, x17
    //     0xd01e90: ldr             lr, [x21, lr, lsl #3]
    //     0xd01e94: blr             lr
    // 0xd01e98: ldur            x0, [fp, #-8]
    // 0xd01e9c: ldur            x3, [fp, #-0x20]
    // 0xd01ea0: ldur            x4, [fp, #-0x18]
    // 0xd01ea4: ldur            x5, [fp, #-0x10]
    // 0xd01ea8: b               #0xd01e38
    // 0xd01eac: r0 = Null
    //     0xd01eac: mov             x0, NULL
    // 0xd01eb0: LeaveFrame
    //     0xd01eb0: mov             SP, fp
    //     0xd01eb4: ldp             fp, lr, [SP], #0x10
    // 0xd01eb8: ret
    //     0xd01eb8: ret             
    // 0xd01ebc: mov             x0, x4
    // 0xd01ec0: r0 = ConcurrentModificationError()
    //     0xd01ec0: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xd01ec4: mov             x1, x0
    // 0xd01ec8: ldur            x0, [fp, #-0x18]
    // 0xd01ecc: StoreField: r1->field_b = r0
    //     0xd01ecc: stur            w0, [x1, #0xb]
    // 0xd01ed0: mov             x0, x1
    // 0xd01ed4: r0 = Throw()
    //     0xd01ed4: bl              #0x13ddb2c  ; ThrowStub
    // 0xd01ed8: brk             #0
    // 0xd01edc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd01edc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd01ee0: b               #0xd01e1c
    // 0xd01ee4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd01ee4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd01ee8: b               #0xd01e44
  }
  _ visitSimpleSelectorSequence(/* No info */) {
    // ** addr: 0xd0202c, size: 0x5c
    // 0xd0202c: EnterFrame
    //     0xd0202c: stp             fp, lr, [SP, #-0x10]!
    //     0xd02030: mov             fp, SP
    // 0xd02034: mov             x0, x1
    // 0xd02038: CheckStackOverflow
    //     0xd02038: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0203c: cmp             SP, x16
    //     0xd02040: b.ls            #0xd02080
    // 0xd02044: LoadField: r1 = r2->field_13
    //     0xd02044: ldur            w1, [x2, #0x13]
    // 0xd02048: DecompressPointer r1
    //     0xd02048: add             x1, x1, HEAP, lsl #32
    // 0xd0204c: r2 = LoadClassIdInstr(r1)
    //     0xd0204c: ldur            x2, [x1, #-1]
    //     0xd02050: ubfx            x2, x2, #0xc, #0x14
    // 0xd02054: mov             x16, x0
    // 0xd02058: mov             x0, x2
    // 0xd0205c: mov             x2, x16
    // 0xd02060: r0 = GDT[cid_x0 + 0xe553]()
    //     0xd02060: mov             x17, #0xe553
    //     0xd02064: add             lr, x0, x17
    //     0xd02068: ldr             lr, [x21, lr, lsl #3]
    //     0xd0206c: blr             lr
    // 0xd02070: r0 = Null
    //     0xd02070: mov             x0, NULL
    // 0xd02074: LeaveFrame
    //     0xd02074: mov             SP, fp
    //     0xd02078: ldp             fp, lr, [SP], #0x10
    // 0xd0207c: ret
    //     0xd0207c: ret             
    // 0xd02080: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd02080: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd02084: b               #0xd02044
  }
  _ visitRuleSet(/* No info */) {
    // ** addr: 0xd02548, size: 0x64
    // 0xd02548: EnterFrame
    //     0xd02548: stp             fp, lr, [SP, #-0x10]!
    //     0xd0254c: mov             fp, SP
    // 0xd02550: AllocStack(0x10)
    //     0xd02550: sub             SP, SP, #0x10
    // 0xd02554: SetupParameters(Visitor this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xd02554: mov             x3, x1
    //     0xd02558: mov             x0, x2
    //     0xd0255c: stur            x1, [fp, #-8]
    //     0xd02560: stur            x2, [fp, #-0x10]
    // 0xd02564: CheckStackOverflow
    //     0xd02564: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd02568: cmp             SP, x16
    //     0xd0256c: b.ls            #0xd025a4
    // 0xd02570: LoadField: r2 = r0->field_b
    //     0xd02570: ldur            w2, [x0, #0xb]
    // 0xd02574: DecompressPointer r2
    //     0xd02574: add             x2, x2, HEAP, lsl #32
    // 0xd02578: mov             x1, x3
    // 0xd0257c: r0 = visitExpressions()
    //     0xd0257c: bl              #0x12ea488  ; [package:csslib/visitor.dart] Visitor::visitExpressions
    // 0xd02580: ldur            x0, [fp, #-0x10]
    // 0xd02584: LoadField: r2 = r0->field_f
    //     0xd02584: ldur            w2, [x0, #0xf]
    // 0xd02588: DecompressPointer r2
    //     0xd02588: add             x2, x2, HEAP, lsl #32
    // 0xd0258c: ldur            x1, [fp, #-8]
    // 0xd02590: r0 = visitExpressions()
    //     0xd02590: bl              #0x12ea488  ; [package:csslib/visitor.dart] Visitor::visitExpressions
    // 0xd02594: r0 = Null
    //     0xd02594: mov             x0, NULL
    // 0xd02598: LeaveFrame
    //     0xd02598: mov             SP, fp
    //     0xd0259c: ldp             fp, lr, [SP], #0x10
    // 0xd025a0: ret
    //     0xd025a0: ret             
    // 0xd025a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd025a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd025a8: b               #0xd02570
  }
  _ visitDocumentDirective(/* No info */) {
    // ** addr: 0xd025e8, size: 0x64
    // 0xd025e8: EnterFrame
    //     0xd025e8: stp             fp, lr, [SP, #-0x10]!
    //     0xd025ec: mov             fp, SP
    // 0xd025f0: AllocStack(0x10)
    //     0xd025f0: sub             SP, SP, #0x10
    // 0xd025f4: SetupParameters(Visitor this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xd025f4: mov             x3, x1
    //     0xd025f8: mov             x0, x2
    //     0xd025fc: stur            x1, [fp, #-8]
    //     0xd02600: stur            x2, [fp, #-0x10]
    // 0xd02604: CheckStackOverflow
    //     0xd02604: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd02608: cmp             SP, x16
    //     0xd0260c: b.ls            #0xd02644
    // 0xd02610: LoadField: r2 = r0->field_b
    //     0xd02610: ldur            w2, [x0, #0xb]
    // 0xd02614: DecompressPointer r2
    //     0xd02614: add             x2, x2, HEAP, lsl #32
    // 0xd02618: mov             x1, x3
    // 0xd0261c: r0 = _visitNodeList()
    //     0xd0261c: bl              #0xd01b64  ; [package:csslib/visitor.dart] Visitor::_visitNodeList
    // 0xd02620: ldur            x0, [fp, #-0x10]
    // 0xd02624: LoadField: r2 = r0->field_f
    //     0xd02624: ldur            w2, [x0, #0xf]
    // 0xd02628: DecompressPointer r2
    //     0xd02628: add             x2, x2, HEAP, lsl #32
    // 0xd0262c: ldur            x1, [fp, #-8]
    // 0xd02630: r0 = _visitNodeList()
    //     0xd02630: bl              #0xd01b64  ; [package:csslib/visitor.dart] Visitor::_visitNodeList
    // 0xd02634: r0 = Null
    //     0xd02634: mov             x0, NULL
    // 0xd02638: LeaveFrame
    //     0xd02638: mov             SP, fp
    //     0xd0263c: ldp             fp, lr, [SP], #0x10
    // 0xd02640: ret
    //     0xd02640: ret             
    // 0xd02644: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd02644: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd02648: b               #0xd02610
  }
  _ visitSupportsDirective(/* No info */) {
    // ** addr: 0xd02688, size: 0xb4
    // 0xd02688: EnterFrame
    //     0xd02688: stp             fp, lr, [SP, #-0x10]!
    //     0xd0268c: mov             fp, SP
    // 0xd02690: AllocStack(0x10)
    //     0xd02690: sub             SP, SP, #0x10
    // 0xd02694: SetupParameters(Visitor this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xd02694: mov             x3, x1
    //     0xd02698: mov             x0, x2
    //     0xd0269c: stur            x1, [fp, #-8]
    //     0xd026a0: stur            x2, [fp, #-0x10]
    // 0xd026a4: CheckStackOverflow
    //     0xd026a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd026a8: cmp             SP, x16
    //     0xd026ac: b.ls            #0xd02730
    // 0xd026b0: LoadField: r2 = r0->field_b
    //     0xd026b0: ldur            w2, [x0, #0xb]
    // 0xd026b4: DecompressPointer r2
    //     0xd026b4: add             x2, x2, HEAP, lsl #32
    // 0xd026b8: cmp             w2, NULL
    // 0xd026bc: b.eq            #0xd02738
    // 0xd026c0: r1 = LoadClassIdInstr(r2)
    //     0xd026c0: ldur            x1, [x2, #-1]
    //     0xd026c4: ubfx            x1, x1, #0xc, #0x14
    // 0xd026c8: cmp             x1, #0xd77
    // 0xd026cc: b.ne            #0xd026dc
    // 0xd026d0: mov             x1, x3
    // 0xd026d4: r0 = visitExpressions()
    //     0xd026d4: bl              #0x12ea488  ; [package:csslib/visitor.dart] Visitor::visitExpressions
    // 0xd026d8: b               #0xd0270c
    // 0xd026dc: cmp             x1, #0xd78
    // 0xd026e0: b.ne            #0xd026f0
    // 0xd026e4: ldur            x1, [fp, #-8]
    // 0xd026e8: r0 = visitExpressions()
    //     0xd026e8: bl              #0x12ea488  ; [package:csslib/visitor.dart] Visitor::visitExpressions
    // 0xd026ec: b               #0xd0270c
    // 0xd026f0: cmp             x1, #0xd79
    // 0xd026f4: b.ne            #0xd02704
    // 0xd026f8: ldur            x1, [fp, #-8]
    // 0xd026fc: r0 = visitSupportsNegation()
    //     0xd026fc: bl              #0xd027c4  ; [package:csslib/visitor.dart] Visitor::visitSupportsNegation
    // 0xd02700: b               #0xd0270c
    // 0xd02704: ldur            x1, [fp, #-8]
    // 0xd02708: r0 = visitSupportsConditionInParens()
    //     0xd02708: bl              #0xd0275c  ; [package:csslib/visitor.dart] Visitor::visitSupportsConditionInParens
    // 0xd0270c: ldur            x0, [fp, #-0x10]
    // 0xd02710: LoadField: r2 = r0->field_f
    //     0xd02710: ldur            w2, [x0, #0xf]
    // 0xd02714: DecompressPointer r2
    //     0xd02714: add             x2, x2, HEAP, lsl #32
    // 0xd02718: ldur            x1, [fp, #-8]
    // 0xd0271c: r0 = _visitNodeList()
    //     0xd0271c: bl              #0xd01b64  ; [package:csslib/visitor.dart] Visitor::_visitNodeList
    // 0xd02720: r0 = Null
    //     0xd02720: mov             x0, NULL
    // 0xd02724: LeaveFrame
    //     0xd02724: mov             SP, fp
    //     0xd02728: ldp             fp, lr, [SP], #0x10
    // 0xd0272c: ret
    //     0xd0272c: ret             
    // 0xd02730: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd02730: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd02734: b               #0xd026b0
    // 0xd02738: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd02738: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ visitSupportsConditionInParens(/* No info */) {
    // ** addr: 0xd0275c, size: 0x68
    // 0xd0275c: EnterFrame
    //     0xd0275c: stp             fp, lr, [SP, #-0x10]!
    //     0xd02760: mov             fp, SP
    // 0xd02764: mov             x0, x1
    // 0xd02768: CheckStackOverflow
    //     0xd02768: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0276c: cmp             SP, x16
    //     0xd02770: b.ls            #0xd027b8
    // 0xd02774: LoadField: r1 = r2->field_b
    //     0xd02774: ldur            w1, [x2, #0xb]
    // 0xd02778: DecompressPointer r1
    //     0xd02778: add             x1, x1, HEAP, lsl #32
    // 0xd0277c: cmp             w1, NULL
    // 0xd02780: b.eq            #0xd027c0
    // 0xd02784: r2 = LoadClassIdInstr(r1)
    //     0xd02784: ldur            x2, [x1, #-1]
    //     0xd02788: ubfx            x2, x2, #0xc, #0x14
    // 0xd0278c: mov             x16, x0
    // 0xd02790: mov             x0, x2
    // 0xd02794: mov             x2, x16
    // 0xd02798: r0 = GDT[cid_x0 + 0xe553]()
    //     0xd02798: mov             x17, #0xe553
    //     0xd0279c: add             lr, x0, x17
    //     0xd027a0: ldr             lr, [x21, lr, lsl #3]
    //     0xd027a4: blr             lr
    // 0xd027a8: r0 = Null
    //     0xd027a8: mov             x0, NULL
    // 0xd027ac: LeaveFrame
    //     0xd027ac: mov             SP, fp
    //     0xd027b0: ldp             fp, lr, [SP], #0x10
    // 0xd027b4: ret
    //     0xd027b4: ret             
    // 0xd027b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd027b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd027bc: b               #0xd02774
    // 0xd027c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd027c0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ visitSupportsNegation(/* No info */) {
    // ** addr: 0xd027c4, size: 0x3c
    // 0xd027c4: EnterFrame
    //     0xd027c4: stp             fp, lr, [SP, #-0x10]!
    //     0xd027c8: mov             fp, SP
    // 0xd027cc: CheckStackOverflow
    //     0xd027cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd027d0: cmp             SP, x16
    //     0xd027d4: b.ls            #0xd027f8
    // 0xd027d8: LoadField: r0 = r2->field_b
    //     0xd027d8: ldur            w0, [x2, #0xb]
    // 0xd027dc: DecompressPointer r0
    //     0xd027dc: add             x0, x0, HEAP, lsl #32
    // 0xd027e0: mov             x2, x0
    // 0xd027e4: r0 = visitSupportsConditionInParens()
    //     0xd027e4: bl              #0xd0275c  ; [package:csslib/visitor.dart] Visitor::visitSupportsConditionInParens
    // 0xd027e8: r0 = Null
    //     0xd027e8: mov             x0, NULL
    // 0xd027ec: LeaveFrame
    //     0xd027ec: mov             SP, fp
    //     0xd027f0: ldp             fp, lr, [SP], #0x10
    // 0xd027f4: ret
    //     0xd027f4: ret             
    // 0xd027f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd027f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd027fc: b               #0xd027d8
  }
  _ visitViewportDirective(/* No info */) {
    // ** addr: 0xd0283c, size: 0x3c
    // 0xd0283c: EnterFrame
    //     0xd0283c: stp             fp, lr, [SP, #-0x10]!
    //     0xd02840: mov             fp, SP
    // 0xd02844: CheckStackOverflow
    //     0xd02844: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd02848: cmp             SP, x16
    //     0xd0284c: b.ls            #0xd02870
    // 0xd02850: LoadField: r0 = r2->field_b
    //     0xd02850: ldur            w0, [x2, #0xb]
    // 0xd02854: DecompressPointer r0
    //     0xd02854: add             x0, x0, HEAP, lsl #32
    // 0xd02858: mov             x2, x0
    // 0xd0285c: r0 = visitExpressions()
    //     0xd0285c: bl              #0x12ea488  ; [package:csslib/visitor.dart] Visitor::visitExpressions
    // 0xd02860: r0 = Null
    //     0xd02860: mov             x0, NULL
    // 0xd02864: LeaveFrame
    //     0xd02864: mov             SP, fp
    //     0xd02868: ldp             fp, lr, [SP], #0x10
    // 0xd0286c: ret
    //     0xd0286c: ret             
    // 0xd02870: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd02870: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd02874: b               #0xd02850
  }
  _ visitImportDirective(/* No info */) {
    // ** addr: 0xd028d8, size: 0xdc
    // 0xd028d8: EnterFrame
    //     0xd028d8: stp             fp, lr, [SP, #-0x10]!
    //     0xd028dc: mov             fp, SP
    // 0xd028e0: AllocStack(0x20)
    //     0xd028e0: sub             SP, SP, #0x20
    // 0xd028e4: SetupParameters(Visitor this /* r1 => r0, fp-0x20 */)
    //     0xd028e4: mov             x0, x1
    //     0xd028e8: stur            x1, [fp, #-0x20]
    // 0xd028ec: CheckStackOverflow
    //     0xd028ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd028f0: cmp             SP, x16
    //     0xd028f4: b.ls            #0xd029a4
    // 0xd028f8: LoadField: r3 = r2->field_b
    //     0xd028f8: ldur            w3, [x2, #0xb]
    // 0xd028fc: DecompressPointer r3
    //     0xd028fc: add             x3, x3, HEAP, lsl #32
    // 0xd02900: stur            x3, [fp, #-0x18]
    // 0xd02904: LoadField: r1 = r3->field_b
    //     0xd02904: ldur            w1, [x3, #0xb]
    // 0xd02908: r4 = LoadInt32Instr(r1)
    //     0xd02908: sbfx            x4, x1, #1, #0x1f
    // 0xd0290c: stur            x4, [fp, #-0x10]
    // 0xd02910: r1 = 0
    //     0xd02910: mov             x1, #0
    // 0xd02914: CheckStackOverflow
    //     0xd02914: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd02918: cmp             SP, x16
    //     0xd0291c: b.ls            #0xd029ac
    // 0xd02920: LoadField: r2 = r3->field_b
    //     0xd02920: ldur            w2, [x3, #0xb]
    // 0xd02924: r5 = LoadInt32Instr(r2)
    //     0xd02924: sbfx            x5, x2, #1, #0x1f
    // 0xd02928: cmp             x4, x5
    // 0xd0292c: b.ne            #0xd02984
    // 0xd02930: cmp             x1, x5
    // 0xd02934: b.ge            #0xd02974
    // 0xd02938: LoadField: r2 = r3->field_f
    //     0xd02938: ldur            w2, [x3, #0xf]
    // 0xd0293c: DecompressPointer r2
    //     0xd0293c: add             x2, x2, HEAP, lsl #32
    // 0xd02940: ArrayLoad: r5 = r2[r1]  ; Unknown_4
    //     0xd02940: add             x16, x2, x1, lsl #2
    //     0xd02944: ldur            w5, [x16, #0xf]
    // 0xd02948: DecompressPointer r5
    //     0xd02948: add             x5, x5, HEAP, lsl #32
    // 0xd0294c: add             x6, x1, #1
    // 0xd02950: mov             x1, x0
    // 0xd02954: mov             x2, x5
    // 0xd02958: stur            x6, [fp, #-8]
    // 0xd0295c: r0 = visitMediaQuery()
    //     0xd0295c: bl              #0xd029b4  ; [package:csslib/visitor.dart] Visitor::visitMediaQuery
    // 0xd02960: ldur            x1, [fp, #-8]
    // 0xd02964: ldur            x0, [fp, #-0x20]
    // 0xd02968: ldur            x3, [fp, #-0x18]
    // 0xd0296c: ldur            x4, [fp, #-0x10]
    // 0xd02970: b               #0xd02914
    // 0xd02974: r0 = Null
    //     0xd02974: mov             x0, NULL
    // 0xd02978: LeaveFrame
    //     0xd02978: mov             SP, fp
    //     0xd0297c: ldp             fp, lr, [SP], #0x10
    // 0xd02980: ret
    //     0xd02980: ret             
    // 0xd02984: mov             x0, x3
    // 0xd02988: r0 = ConcurrentModificationError()
    //     0xd02988: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xd0298c: mov             x1, x0
    // 0xd02990: ldur            x0, [fp, #-0x18]
    // 0xd02994: StoreField: r1->field_b = r0
    //     0xd02994: stur            w0, [x1, #0xb]
    // 0xd02998: mov             x0, x1
    // 0xd0299c: r0 = Throw()
    //     0xd0299c: bl              #0x13ddb2c  ; ThrowStub
    // 0xd029a0: brk             #0
    // 0xd029a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd029a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd029a8: b               #0xd028f8
    // 0xd029ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd029ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd029b0: b               #0xd02920
  }
  _ visitMediaQuery(/* No info */) {
    // ** addr: 0xd029b4, size: 0x15c
    // 0xd029b4: EnterFrame
    //     0xd029b4: stp             fp, lr, [SP, #-0x10]!
    //     0xd029b8: mov             fp, SP
    // 0xd029bc: AllocStack(0x28)
    //     0xd029bc: sub             SP, SP, #0x28
    // 0xd029c0: SetupParameters(Visitor this /* r1 => r0, fp-0x28 */)
    //     0xd029c0: mov             x0, x1
    //     0xd029c4: stur            x1, [fp, #-0x28]
    // 0xd029c8: CheckStackOverflow
    //     0xd029c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd029cc: cmp             SP, x16
    //     0xd029d0: b.ls            #0xd02b00
    // 0xd029d4: LoadField: r3 = r2->field_b
    //     0xd029d4: ldur            w3, [x2, #0xb]
    // 0xd029d8: DecompressPointer r3
    //     0xd029d8: add             x3, x3, HEAP, lsl #32
    // 0xd029dc: stur            x3, [fp, #-0x20]
    // 0xd029e0: LoadField: r1 = r3->field_b
    //     0xd029e0: ldur            w1, [x3, #0xb]
    // 0xd029e4: r4 = LoadInt32Instr(r1)
    //     0xd029e4: sbfx            x4, x1, #1, #0x1f
    // 0xd029e8: stur            x4, [fp, #-0x18]
    // 0xd029ec: r5 = LoadClassIdInstr(r0)
    //     0xd029ec: ldur            x5, [x0, #-1]
    //     0xd029f0: ubfx            x5, x5, #0xc, #0x14
    // 0xd029f4: stur            x5, [fp, #-0x10]
    // 0xd029f8: r1 = 0
    //     0xd029f8: mov             x1, #0
    // 0xd029fc: CheckStackOverflow
    //     0xd029fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd02a00: cmp             SP, x16
    //     0xd02a04: b.ls            #0xd02b08
    // 0xd02a08: LoadField: r2 = r3->field_b
    //     0xd02a08: ldur            w2, [x3, #0xb]
    // 0xd02a0c: r6 = LoadInt32Instr(r2)
    //     0xd02a0c: sbfx            x6, x2, #1, #0x1f
    // 0xd02a10: cmp             x4, x6
    // 0xd02a14: b.ne            #0xd02ae0
    // 0xd02a18: cmp             x1, x6
    // 0xd02a1c: b.ge            #0xd02ad0
    // 0xd02a20: LoadField: r2 = r3->field_f
    //     0xd02a20: ldur            w2, [x3, #0xf]
    // 0xd02a24: DecompressPointer r2
    //     0xd02a24: add             x2, x2, HEAP, lsl #32
    // 0xd02a28: ArrayLoad: r6 = r2[r1]  ; Unknown_4
    //     0xd02a28: add             x16, x2, x1, lsl #2
    //     0xd02a2c: ldur            w6, [x16, #0xf]
    // 0xd02a30: DecompressPointer r6
    //     0xd02a30: add             x6, x6, HEAP, lsl #32
    // 0xd02a34: add             x7, x1, #1
    // 0xd02a38: stur            x7, [fp, #-8]
    // 0xd02a3c: LoadField: r2 = r6->field_b
    //     0xd02a3c: ldur            w2, [x6, #0xb]
    // 0xd02a40: DecompressPointer r2
    //     0xd02a40: add             x2, x2, HEAP, lsl #32
    // 0xd02a44: cmp             x5, #0xdc4
    // 0xd02a48: b.ne            #0xd02a54
    // 0xd02a4c: mov             x0, x5
    // 0xd02a50: b               #0xd02a84
    // 0xd02a54: cmp             x5, #0xdc5
    // 0xd02a58: b.ne            #0xd02a78
    // 0xd02a5c: LoadField: r1 = r0->field_7
    //     0xd02a5c: ldur            w1, [x0, #7]
    // 0xd02a60: DecompressPointer r1
    //     0xd02a60: add             x1, x1, HEAP, lsl #32
    // 0xd02a64: LoadField: r6 = r2->field_b
    //     0xd02a64: ldur            w6, [x2, #0xb]
    // 0xd02a68: DecompressPointer r6
    //     0xd02a68: add             x6, x6, HEAP, lsl #32
    // 0xd02a6c: mov             x2, x6
    // 0xd02a70: r0 = addAll()
    //     0xd02a70: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0xd02a74: b               #0xd02ab8
    // 0xd02a78: mov             x0, x5
    // 0xd02a7c: cmp             x0, #0xdc6
    // 0xd02a80: b.ne            #0xd02a9c
    // 0xd02a84: LoadField: r1 = r2->field_b
    //     0xd02a84: ldur            w1, [x2, #0xb]
    // 0xd02a88: DecompressPointer r1
    //     0xd02a88: add             x1, x1, HEAP, lsl #32
    // 0xd02a8c: mov             x2, x1
    // 0xd02a90: ldur            x1, [fp, #-0x28]
    // 0xd02a94: r0 = _visitNodeList()
    //     0xd02a94: bl              #0xd01b64  ; [package:csslib/visitor.dart] Visitor::_visitNodeList
    // 0xd02a98: b               #0xd02ab8
    // 0xd02a9c: ldur            x3, [fp, #-0x28]
    // 0xd02aa0: r0 = LoadClassIdInstr(r3)
    //     0xd02aa0: ldur            x0, [x3, #-1]
    //     0xd02aa4: ubfx            x0, x0, #0xc, #0x14
    // 0xd02aa8: mov             x1, x3
    // 0xd02aac: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd02aac: sub             lr, x0, #1, lsl #12
    //     0xd02ab0: ldr             lr, [x21, lr, lsl #3]
    //     0xd02ab4: blr             lr
    // 0xd02ab8: ldur            x1, [fp, #-8]
    // 0xd02abc: ldur            x0, [fp, #-0x28]
    // 0xd02ac0: ldur            x3, [fp, #-0x20]
    // 0xd02ac4: ldur            x5, [fp, #-0x10]
    // 0xd02ac8: ldur            x4, [fp, #-0x18]
    // 0xd02acc: b               #0xd029fc
    // 0xd02ad0: r0 = Null
    //     0xd02ad0: mov             x0, NULL
    // 0xd02ad4: LeaveFrame
    //     0xd02ad4: mov             SP, fp
    //     0xd02ad8: ldp             fp, lr, [SP], #0x10
    // 0xd02adc: ret
    //     0xd02adc: ret             
    // 0xd02ae0: mov             x0, x3
    // 0xd02ae4: r0 = ConcurrentModificationError()
    //     0xd02ae4: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xd02ae8: mov             x1, x0
    // 0xd02aec: ldur            x0, [fp, #-0x20]
    // 0xd02af0: StoreField: r1->field_b = r0
    //     0xd02af0: stur            w0, [x1, #0xb]
    // 0xd02af4: mov             x0, x1
    // 0xd02af8: r0 = Throw()
    //     0xd02af8: bl              #0x13ddb2c  ; ThrowStub
    // 0xd02afc: brk             #0
    // 0xd02b00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd02b00: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd02b04: b               #0xd029d4
    // 0xd02b08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd02b08: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd02b0c: b               #0xd02a08
  }
  _ visitMediaExpression(/* No info */) {
    // ** addr: 0xd02b10, size: 0xa8
    // 0xd02b10: EnterFrame
    //     0xd02b10: stp             fp, lr, [SP, #-0x10]!
    //     0xd02b14: mov             fp, SP
    // 0xd02b18: CheckStackOverflow
    //     0xd02b18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd02b1c: cmp             SP, x16
    //     0xd02b20: b.ls            #0xd02bb0
    // 0xd02b24: LoadField: r0 = r2->field_b
    //     0xd02b24: ldur            w0, [x2, #0xb]
    // 0xd02b28: DecompressPointer r0
    //     0xd02b28: add             x0, x0, HEAP, lsl #32
    // 0xd02b2c: r2 = LoadClassIdInstr(r1)
    //     0xd02b2c: ldur            x2, [x1, #-1]
    //     0xd02b30: ubfx            x2, x2, #0xc, #0x14
    // 0xd02b34: cmp             x2, #0xdc4
    // 0xd02b38: b.eq            #0xd02b70
    // 0xd02b3c: cmp             x2, #0xdc5
    // 0xd02b40: b.ne            #0xd02b68
    // 0xd02b44: LoadField: r2 = r1->field_7
    //     0xd02b44: ldur            w2, [x1, #7]
    // 0xd02b48: DecompressPointer r2
    //     0xd02b48: add             x2, x2, HEAP, lsl #32
    // 0xd02b4c: LoadField: r1 = r0->field_b
    //     0xd02b4c: ldur            w1, [x0, #0xb]
    // 0xd02b50: DecompressPointer r1
    //     0xd02b50: add             x1, x1, HEAP, lsl #32
    // 0xd02b54: mov             x16, x1
    // 0xd02b58: mov             x1, x2
    // 0xd02b5c: mov             x2, x16
    // 0xd02b60: r0 = addAll()
    //     0xd02b60: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0xd02b64: b               #0xd02ba0
    // 0xd02b68: cmp             x2, #0xdc6
    // 0xd02b6c: b.ne            #0xd02b80
    // 0xd02b70: LoadField: r2 = r0->field_b
    //     0xd02b70: ldur            w2, [x0, #0xb]
    // 0xd02b74: DecompressPointer r2
    //     0xd02b74: add             x2, x2, HEAP, lsl #32
    // 0xd02b78: r0 = _visitNodeList()
    //     0xd02b78: bl              #0xd01b64  ; [package:csslib/visitor.dart] Visitor::_visitNodeList
    // 0xd02b7c: b               #0xd02ba0
    // 0xd02b80: r2 = LoadClassIdInstr(r1)
    //     0xd02b80: ldur            x2, [x1, #-1]
    //     0xd02b84: ubfx            x2, x2, #0xc, #0x14
    // 0xd02b88: mov             x16, x0
    // 0xd02b8c: mov             x0, x2
    // 0xd02b90: mov             x2, x16
    // 0xd02b94: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd02b94: sub             lr, x0, #1, lsl #12
    //     0xd02b98: ldr             lr, [x21, lr, lsl #3]
    //     0xd02b9c: blr             lr
    // 0xd02ba0: r0 = Null
    //     0xd02ba0: mov             x0, NULL
    // 0xd02ba4: LeaveFrame
    //     0xd02ba4: mov             SP, fp
    //     0xd02ba8: ldp             fp, lr, [SP], #0x10
    // 0xd02bac: ret
    //     0xd02bac: ret             
    // 0xd02bb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd02bb0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd02bb4: b               #0xd02b24
  }
  _ visitPageDirective(/* No info */) {
    // ** addr: 0xd02c6c, size: 0x100
    // 0xd02c6c: EnterFrame
    //     0xd02c6c: stp             fp, lr, [SP, #-0x10]!
    //     0xd02c70: mov             fp, SP
    // 0xd02c74: AllocStack(0x20)
    //     0xd02c74: sub             SP, SP, #0x20
    // 0xd02c78: SetupParameters(Visitor this /* r1 => r0, fp-0x20 */)
    //     0xd02c78: mov             x0, x1
    //     0xd02c7c: stur            x1, [fp, #-0x20]
    // 0xd02c80: CheckStackOverflow
    //     0xd02c80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd02c84: cmp             SP, x16
    //     0xd02c88: b.ls            #0xd02d5c
    // 0xd02c8c: LoadField: r3 = r2->field_b
    //     0xd02c8c: ldur            w3, [x2, #0xb]
    // 0xd02c90: DecompressPointer r3
    //     0xd02c90: add             x3, x3, HEAP, lsl #32
    // 0xd02c94: stur            x3, [fp, #-0x18]
    // 0xd02c98: LoadField: r1 = r3->field_b
    //     0xd02c98: ldur            w1, [x3, #0xb]
    // 0xd02c9c: r4 = LoadInt32Instr(r1)
    //     0xd02c9c: sbfx            x4, x1, #1, #0x1f
    // 0xd02ca0: stur            x4, [fp, #-0x10]
    // 0xd02ca4: r1 = 0
    //     0xd02ca4: mov             x1, #0
    // 0xd02ca8: CheckStackOverflow
    //     0xd02ca8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd02cac: cmp             SP, x16
    //     0xd02cb0: b.ls            #0xd02d64
    // 0xd02cb4: LoadField: r2 = r3->field_b
    //     0xd02cb4: ldur            w2, [x3, #0xb]
    // 0xd02cb8: r5 = LoadInt32Instr(r2)
    //     0xd02cb8: sbfx            x5, x2, #1, #0x1f
    // 0xd02cbc: cmp             x4, x5
    // 0xd02cc0: b.ne            #0xd02d3c
    // 0xd02cc4: cmp             x1, x5
    // 0xd02cc8: b.ge            #0xd02d2c
    // 0xd02ccc: LoadField: r2 = r3->field_f
    //     0xd02ccc: ldur            w2, [x3, #0xf]
    // 0xd02cd0: DecompressPointer r2
    //     0xd02cd0: add             x2, x2, HEAP, lsl #32
    // 0xd02cd4: ArrayLoad: r5 = r2[r1]  ; Unknown_4
    //     0xd02cd4: add             x16, x2, x1, lsl #2
    //     0xd02cd8: ldur            w5, [x16, #0xf]
    // 0xd02cdc: DecompressPointer r5
    //     0xd02cdc: add             x5, x5, HEAP, lsl #32
    // 0xd02ce0: add             x6, x1, #1
    // 0xd02ce4: stur            x6, [fp, #-8]
    // 0xd02ce8: r1 = LoadClassIdInstr(r5)
    //     0xd02ce8: ldur            x1, [x5, #-1]
    //     0xd02cec: ubfx            x1, x1, #0xc, #0x14
    // 0xd02cf0: cmp             x1, #0xd6f
    // 0xd02cf4: b.ne            #0xd02d08
    // 0xd02cf8: mov             x1, x0
    // 0xd02cfc: mov             x2, x5
    // 0xd02d00: r0 = visitExpressions()
    //     0xd02d00: bl              #0x12ea488  ; [package:csslib/visitor.dart] Visitor::visitExpressions
    // 0xd02d04: b               #0xd02d18
    // 0xd02d08: LoadField: r2 = r5->field_b
    //     0xd02d08: ldur            w2, [x5, #0xb]
    // 0xd02d0c: DecompressPointer r2
    //     0xd02d0c: add             x2, x2, HEAP, lsl #32
    // 0xd02d10: ldur            x1, [fp, #-0x20]
    // 0xd02d14: r0 = _visitNodeList()
    //     0xd02d14: bl              #0xd01b64  ; [package:csslib/visitor.dart] Visitor::_visitNodeList
    // 0xd02d18: ldur            x1, [fp, #-8]
    // 0xd02d1c: ldur            x0, [fp, #-0x20]
    // 0xd02d20: ldur            x3, [fp, #-0x18]
    // 0xd02d24: ldur            x4, [fp, #-0x10]
    // 0xd02d28: b               #0xd02ca8
    // 0xd02d2c: r0 = Null
    //     0xd02d2c: mov             x0, NULL
    // 0xd02d30: LeaveFrame
    //     0xd02d30: mov             SP, fp
    //     0xd02d34: ldp             fp, lr, [SP], #0x10
    // 0xd02d38: ret
    //     0xd02d38: ret             
    // 0xd02d3c: mov             x0, x3
    // 0xd02d40: r0 = ConcurrentModificationError()
    //     0xd02d40: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xd02d44: mov             x1, x0
    // 0xd02d48: ldur            x0, [fp, #-0x18]
    // 0xd02d4c: StoreField: r1->field_b = r0
    //     0xd02d4c: stur            w0, [x1, #0xb]
    // 0xd02d50: mov             x0, x1
    // 0xd02d54: r0 = Throw()
    //     0xd02d54: bl              #0x13ddb2c  ; ThrowStub
    // 0xd02d58: brk             #0
    // 0xd02d5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd02d5c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd02d60: b               #0xd02c8c
    // 0xd02d64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd02d64: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd02d68: b               #0xd02cb4
  }
  _ visitKeyFrameDirective(/* No info */) {
    // ** addr: 0xd02da8, size: 0x50
    // 0xd02da8: EnterFrame
    //     0xd02da8: stp             fp, lr, [SP, #-0x10]!
    //     0xd02dac: mov             fp, SP
    // 0xd02db0: CheckStackOverflow
    //     0xd02db0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd02db4: cmp             SP, x16
    //     0xd02db8: b.ls            #0xd02dec
    // 0xd02dbc: LoadField: r0 = r2->field_b
    //     0xd02dbc: ldur            w0, [x2, #0xb]
    // 0xd02dc0: DecompressPointer r0
    //     0xd02dc0: add             x0, x0, HEAP, lsl #32
    // 0xd02dc4: cmp             w0, NULL
    // 0xd02dc8: b.eq            #0xd02df4
    // 0xd02dcc: LoadField: r0 = r2->field_f
    //     0xd02dcc: ldur            w0, [x2, #0xf]
    // 0xd02dd0: DecompressPointer r0
    //     0xd02dd0: add             x0, x0, HEAP, lsl #32
    // 0xd02dd4: mov             x2, x0
    // 0xd02dd8: r0 = _visitNodeList()
    //     0xd02dd8: bl              #0xd01b64  ; [package:csslib/visitor.dart] Visitor::_visitNodeList
    // 0xd02ddc: r0 = Null
    //     0xd02ddc: mov             x0, NULL
    // 0xd02de0: LeaveFrame
    //     0xd02de0: mov             SP, fp
    //     0xd02de4: ldp             fp, lr, [SP], #0x10
    // 0xd02de8: ret
    //     0xd02de8: ret             
    // 0xd02dec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd02dec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd02df0: b               #0xd02dbc
    // 0xd02df4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd02df4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ visitVarDefinitionDirective(/* No info */) {
    // ** addr: 0xd02e70, size: 0x3c
    // 0xd02e70: EnterFrame
    //     0xd02e70: stp             fp, lr, [SP, #-0x10]!
    //     0xd02e74: mov             fp, SP
    // 0xd02e78: CheckStackOverflow
    //     0xd02e78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd02e7c: cmp             SP, x16
    //     0xd02e80: b.ls            #0xd02ea4
    // 0xd02e84: LoadField: r0 = r2->field_b
    //     0xd02e84: ldur            w0, [x2, #0xb]
    // 0xd02e88: DecompressPointer r0
    //     0xd02e88: add             x0, x0, HEAP, lsl #32
    // 0xd02e8c: mov             x2, x0
    // 0xd02e90: r0 = visitVarDefinition()
    //     0xd02e90: bl              #0xd02eac  ; [package:csslib/visitor.dart] Visitor::visitVarDefinition
    // 0xd02e94: r0 = Null
    //     0xd02e94: mov             x0, NULL
    // 0xd02e98: LeaveFrame
    //     0xd02e98: mov             SP, fp
    //     0xd02e9c: ldp             fp, lr, [SP], #0x10
    // 0xd02ea0: ret
    //     0xd02ea0: ret             
    // 0xd02ea4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd02ea4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd02ea8: b               #0xd02e84
  }
  _ visitVarDefinition(/* No info */) {
    // ** addr: 0xd02eac, size: 0x5c
    // 0xd02eac: EnterFrame
    //     0xd02eac: stp             fp, lr, [SP, #-0x10]!
    //     0xd02eb0: mov             fp, SP
    // 0xd02eb4: mov             x0, x1
    // 0xd02eb8: CheckStackOverflow
    //     0xd02eb8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd02ebc: cmp             SP, x16
    //     0xd02ec0: b.ls            #0xd02efc
    // 0xd02ec4: LoadField: r1 = r2->field_b
    //     0xd02ec4: ldur            w1, [x2, #0xb]
    // 0xd02ec8: DecompressPointer r1
    //     0xd02ec8: add             x1, x1, HEAP, lsl #32
    // 0xd02ecc: cmp             w1, NULL
    // 0xd02ed0: b.eq            #0xd02f04
    // 0xd02ed4: LoadField: r1 = r2->field_f
    //     0xd02ed4: ldur            w1, [x2, #0xf]
    // 0xd02ed8: DecompressPointer r1
    //     0xd02ed8: add             x1, x1, HEAP, lsl #32
    // 0xd02edc: cmp             w1, NULL
    // 0xd02ee0: b.eq            #0xd02eec
    // 0xd02ee4: mov             x2, x0
    // 0xd02ee8: r0 = visit()
    //     0xd02ee8: bl              #0xd01eec  ; [package:csslib/visitor.dart] Expressions::visit
    // 0xd02eec: r0 = Null
    //     0xd02eec: mov             x0, NULL
    // 0xd02ef0: LeaveFrame
    //     0xd02ef0: mov             SP, fp
    //     0xd02ef4: ldp             fp, lr, [SP], #0x10
    // 0xd02ef8: ret
    //     0xd02ef8: ret             
    // 0xd02efc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd02efc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd02f00: b               #0xd02ec4
    // 0xd02f04: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd02f04: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ visitIncludeDirective(/* No info */) {
    // ** addr: 0xd02fbc, size: 0x160
    // 0xd02fbc: EnterFrame
    //     0xd02fbc: stp             fp, lr, [SP, #-0x10]!
    //     0xd02fc0: mov             fp, SP
    // 0xd02fc4: AllocStack(0x38)
    //     0xd02fc4: sub             SP, SP, #0x38
    // 0xd02fc8: SetupParameters(Visitor this /* r1 => r1, fp-0x28 */)
    //     0xd02fc8: stur            x1, [fp, #-0x28]
    // 0xd02fcc: CheckStackOverflow
    //     0xd02fcc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd02fd0: cmp             SP, x16
    //     0xd02fd4: b.ls            #0xd03104
    // 0xd02fd8: LoadField: r3 = r2->field_b
    //     0xd02fd8: ldur            w3, [x2, #0xb]
    // 0xd02fdc: DecompressPointer r3
    //     0xd02fdc: add             x3, x3, HEAP, lsl #32
    // 0xd02fe0: stur            x3, [fp, #-0x20]
    // 0xd02fe4: r2 = 0
    //     0xd02fe4: mov             x2, #0
    // 0xd02fe8: stur            x2, [fp, #-0x18]
    // 0xd02fec: CheckStackOverflow
    //     0xd02fec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd02ff0: cmp             SP, x16
    //     0xd02ff4: b.ls            #0xd0310c
    // 0xd02ff8: LoadField: r0 = r3->field_b
    //     0xd02ff8: ldur            w0, [x3, #0xb]
    // 0xd02ffc: r4 = LoadInt32Instr(r0)
    //     0xd02ffc: sbfx            x4, x0, #1, #0x1f
    // 0xd03000: cmp             x2, x4
    // 0xd03004: b.ge            #0xd030f4
    // 0xd03008: LoadField: r0 = r3->field_f
    //     0xd03008: ldur            w0, [x3, #0xf]
    // 0xd0300c: DecompressPointer r0
    //     0xd0300c: add             x0, x0, HEAP, lsl #32
    // 0xd03010: ArrayLoad: r4 = r0[r2]  ; Unknown_4
    //     0xd03010: add             x16, x0, x2, lsl #2
    //     0xd03014: ldur            w4, [x16, #0xf]
    // 0xd03018: DecompressPointer r4
    //     0xd03018: add             x4, x4, HEAP, lsl #32
    // 0xd0301c: stur            x4, [fp, #-0x10]
    // 0xd03020: r5 = 0
    //     0xd03020: mov             x5, #0
    // 0xd03024: stur            x5, [fp, #-8]
    // 0xd03028: CheckStackOverflow
    //     0xd03028: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0302c: cmp             SP, x16
    //     0xd03030: b.ls            #0xd03114
    // 0xd03034: r0 = LoadClassIdInstr(r4)
    //     0xd03034: ldur            x0, [x4, #-1]
    //     0xd03038: ubfx            x0, x0, #0xc, #0x14
    // 0xd0303c: str             x4, [SP]
    // 0xd03040: r0 = GDT[cid_x0 + 0xf078]()
    //     0xd03040: mov             x17, #0xf078
    //     0xd03044: add             lr, x0, x17
    //     0xd03048: ldr             lr, [x21, lr, lsl #3]
    //     0xd0304c: blr             lr
    // 0xd03050: r1 = LoadInt32Instr(r0)
    //     0xd03050: sbfx            x1, x0, #1, #0x1f
    //     0xd03054: tbz             w0, #0, #0xd0305c
    //     0xd03058: ldur            x1, [x0, #7]
    // 0xd0305c: ldur            x2, [fp, #-8]
    // 0xd03060: cmp             x2, x1
    // 0xd03064: b.ge            #0xd030e0
    // 0xd03068: ldur            x3, [fp, #-0x10]
    // 0xd0306c: r0 = BoxInt64Instr(r2)
    //     0xd0306c: sbfiz           x0, x2, #1, #0x1f
    //     0xd03070: cmp             x2, x0, asr #1
    //     0xd03074: b.eq            #0xd03080
    //     0xd03078: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xd0307c: stur            x2, [x0, #7]
    // 0xd03080: r1 = LoadClassIdInstr(r3)
    //     0xd03080: ldur            x1, [x3, #-1]
    //     0xd03084: ubfx            x1, x1, #0xc, #0x14
    // 0xd03088: stp             x0, x3, [SP]
    // 0xd0308c: mov             x0, x1
    // 0xd03090: r0 = GDT[cid_x0 + -0xdfd]()
    //     0xd03090: sub             lr, x0, #0xdfd
    //     0xd03094: ldr             lr, [x21, lr, lsl #3]
    //     0xd03098: blr             lr
    // 0xd0309c: r1 = LoadClassIdInstr(r0)
    //     0xd0309c: ldur            x1, [x0, #-1]
    //     0xd030a0: ubfx            x1, x1, #0xc, #0x14
    // 0xd030a4: mov             x16, x0
    // 0xd030a8: mov             x0, x1
    // 0xd030ac: mov             x1, x16
    // 0xd030b0: ldur            x2, [fp, #-0x28]
    // 0xd030b4: r0 = GDT[cid_x0 + 0xe553]()
    //     0xd030b4: mov             x17, #0xe553
    //     0xd030b8: add             lr, x0, x17
    //     0xd030bc: ldr             lr, [x21, lr, lsl #3]
    //     0xd030c0: blr             lr
    // 0xd030c4: ldur            x1, [fp, #-8]
    // 0xd030c8: add             x5, x1, #1
    // 0xd030cc: ldur            x1, [fp, #-0x28]
    // 0xd030d0: ldur            x2, [fp, #-0x18]
    // 0xd030d4: ldur            x3, [fp, #-0x20]
    // 0xd030d8: ldur            x4, [fp, #-0x10]
    // 0xd030dc: b               #0xd03024
    // 0xd030e0: ldur            x1, [fp, #-0x18]
    // 0xd030e4: add             x2, x1, #1
    // 0xd030e8: ldur            x1, [fp, #-0x28]
    // 0xd030ec: ldur            x3, [fp, #-0x20]
    // 0xd030f0: b               #0xd02fe8
    // 0xd030f4: r0 = Null
    //     0xd030f4: mov             x0, NULL
    // 0xd030f8: LeaveFrame
    //     0xd030f8: mov             SP, fp
    //     0xd030fc: ldp             fp, lr, [SP], #0x10
    // 0xd03100: ret
    //     0xd03100: ret             
    // 0xd03104: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd03104: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd03108: b               #0xd02fd8
    // 0xd0310c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0310c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd03110: b               #0xd02ff8
    // 0xd03114: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd03114: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd03118: b               #0xd03034
  }
  _ visitIncludeMixinAtDeclaration(/* No info */) {
    // ** addr: 0xd0333c, size: 0x3c
    // 0xd0333c: EnterFrame
    //     0xd0333c: stp             fp, lr, [SP, #-0x10]!
    //     0xd03340: mov             fp, SP
    // 0xd03344: CheckStackOverflow
    //     0xd03344: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd03348: cmp             SP, x16
    //     0xd0334c: b.ls            #0xd03370
    // 0xd03350: LoadField: r0 = r2->field_1b
    //     0xd03350: ldur            w0, [x2, #0x1b]
    // 0xd03354: DecompressPointer r0
    //     0xd03354: add             x0, x0, HEAP, lsl #32
    // 0xd03358: mov             x2, x0
    // 0xd0335c: r0 = visitIncludeDirective()
    //     0xd0335c: bl              #0xd02fbc  ; [package:csslib/visitor.dart] Visitor::visitIncludeDirective
    // 0xd03360: r0 = Null
    //     0xd03360: mov             x0, NULL
    // 0xd03364: LeaveFrame
    //     0xd03364: mov             SP, fp
    //     0xd03368: ldp             fp, lr, [SP], #0x10
    // 0xd0336c: ret
    //     0xd0336c: ret             
    // 0xd03370: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd03370: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd03374: b               #0xd03350
  }
  _ visitExtendDeclaration(/* No info */) {
    // ** addr: 0xd033b4, size: 0x3c
    // 0xd033b4: EnterFrame
    //     0xd033b4: stp             fp, lr, [SP, #-0x10]!
    //     0xd033b8: mov             fp, SP
    // 0xd033bc: CheckStackOverflow
    //     0xd033bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd033c0: cmp             SP, x16
    //     0xd033c4: b.ls            #0xd033e8
    // 0xd033c8: LoadField: r0 = r2->field_1b
    //     0xd033c8: ldur            w0, [x2, #0x1b]
    // 0xd033cc: DecompressPointer r0
    //     0xd033cc: add             x0, x0, HEAP, lsl #32
    // 0xd033d0: mov             x2, x0
    // 0xd033d4: r0 = _visitNodeList()
    //     0xd033d4: bl              #0xd01b64  ; [package:csslib/visitor.dart] Visitor::_visitNodeList
    // 0xd033d8: r0 = Null
    //     0xd033d8: mov             x0, NULL
    // 0xd033dc: LeaveFrame
    //     0xd033dc: mov             SP, fp
    //     0xd033e0: ldp             fp, lr, [SP], #0x10
    // 0xd033e4: ret
    //     0xd033e4: ret             
    // 0xd033e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd033e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd033ec: b               #0xd033c8
  }
  _ visitNamespaceSelector(/* No info */) {
    // ** addr: 0x12e9548, size: 0x110
    // 0x12e9548: EnterFrame
    //     0x12e9548: stp             fp, lr, [SP, #-0x10]!
    //     0x12e954c: mov             fp, SP
    // 0x12e9550: AllocStack(0x18)
    //     0x12e9550: sub             SP, SP, #0x18
    // 0x12e9554: SetupParameters(Visitor this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r3, fp-0x18 */)
    //     0x12e9554: mov             x4, x1
    //     0x12e9558: mov             x3, x2
    //     0x12e955c: stur            x1, [fp, #-0x10]
    //     0x12e9560: stur            x2, [fp, #-0x18]
    // 0x12e9564: CheckStackOverflow
    //     0x12e9564: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e9568: cmp             SP, x16
    //     0x12e956c: b.ls            #0x12e9650
    // 0x12e9570: LoadField: r5 = r3->field_f
    //     0x12e9570: ldur            w5, [x3, #0xf]
    // 0x12e9574: DecompressPointer r5
    //     0x12e9574: add             x5, x5, HEAP, lsl #32
    // 0x12e9578: stur            x5, [fp, #-8]
    // 0x12e957c: cmp             w5, NULL
    // 0x12e9580: b.eq            #0x12e95e0
    // 0x12e9584: mov             x0, x5
    // 0x12e9588: r2 = Null
    //     0x12e9588: mov             x2, NULL
    // 0x12e958c: r1 = Null
    //     0x12e958c: mov             x1, NULL
    // 0x12e9590: r4 = 60
    //     0x12e9590: mov             x4, #0x3c
    // 0x12e9594: branchIfSmi(r0, 0x12e95a0)
    //     0x12e9594: tbz             w0, #0, #0x12e95a0
    // 0x12e9598: r4 = LoadClassIdInstr(r0)
    //     0x12e9598: ldur            x4, [x0, #-1]
    //     0x12e959c: ubfx            x4, x4, #0xc, #0x14
    // 0x12e95a0: sub             x4, x4, #0xd67
    // 0x12e95a4: cmp             x4, #0x5b
    // 0x12e95a8: b.ls            #0x12e95c0
    // 0x12e95ac: r8 = TreeNode
    //     0x12e95ac: add             x8, PP, #0x8a, lsl #12  ; [pp+0x8af88] Type: TreeNode
    //     0x12e95b0: ldr             x8, [x8, #0xf88]
    // 0x12e95b4: r3 = Null
    //     0x12e95b4: add             x3, PP, #0x8a, lsl #12  ; [pp+0x8afa0] Null
    //     0x12e95b8: ldr             x3, [x3, #0xfa0]
    // 0x12e95bc: r0 = TreeNode()
    //     0x12e95bc: bl              #0xb0a880  ; IsType_TreeNode_Stub
    // 0x12e95c0: ldur            x1, [fp, #-8]
    // 0x12e95c4: r0 = LoadClassIdInstr(r1)
    //     0x12e95c4: ldur            x0, [x1, #-1]
    //     0x12e95c8: ubfx            x0, x0, #0xc, #0x14
    // 0x12e95cc: ldur            x2, [fp, #-0x10]
    // 0x12e95d0: r0 = GDT[cid_x0 + 0xe553]()
    //     0x12e95d0: mov             x17, #0xe553
    //     0x12e95d4: add             lr, x0, x17
    //     0x12e95d8: ldr             lr, [x21, lr, lsl #3]
    //     0x12e95dc: blr             lr
    // 0x12e95e0: ldur            x0, [fp, #-0x18]
    // 0x12e95e4: LoadField: r3 = r0->field_b
    //     0x12e95e4: ldur            w3, [x0, #0xb]
    // 0x12e95e8: DecompressPointer r3
    //     0x12e95e8: add             x3, x3, HEAP, lsl #32
    // 0x12e95ec: mov             x0, x3
    // 0x12e95f0: stur            x3, [fp, #-8]
    // 0x12e95f4: r2 = Null
    //     0x12e95f4: mov             x2, NULL
    // 0x12e95f8: r1 = Null
    //     0x12e95f8: mov             x1, NULL
    // 0x12e95fc: r4 = 60
    //     0x12e95fc: mov             x4, #0x3c
    // 0x12e9600: branchIfSmi(r0, 0x12e960c)
    //     0x12e9600: tbz             w0, #0, #0x12e960c
    // 0x12e9604: r4 = LoadClassIdInstr(r0)
    //     0x12e9604: ldur            x4, [x0, #-1]
    //     0x12e9608: ubfx            x4, x4, #0xc, #0x14
    // 0x12e960c: sub             x4, x4, #0xd92
    // 0x12e9610: cmp             x4, #9
    // 0x12e9614: b.ls            #0x12e962c
    // 0x12e9618: r8 = SimpleSelector?
    //     0x12e9618: add             x8, PP, #0x7e, lsl #12  ; [pp+0x7ecf0] Type: SimpleSelector?
    //     0x12e961c: ldr             x8, [x8, #0xcf0]
    // 0x12e9620: r3 = Null
    //     0x12e9620: add             x3, PP, #0x8a, lsl #12  ; [pp+0x8afb0] Null
    //     0x12e9624: ldr             x3, [x3, #0xfb0]
    // 0x12e9628: r0 = DefaultNullableTypeTest()
    //     0x12e9628: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0x12e962c: ldur            x1, [fp, #-8]
    // 0x12e9630: cmp             w1, NULL
    // 0x12e9634: b.eq            #0x12e9640
    // 0x12e9638: ldur            x2, [fp, #-0x10]
    // 0x12e963c: r0 = visit()
    //     0x12e963c: bl              #0xd02088  ; [package:csslib/visitor.dart] ElementSelector::visit
    // 0x12e9640: r0 = Null
    //     0x12e9640: mov             x0, NULL
    // 0x12e9644: LeaveFrame
    //     0x12e9644: mov             SP, fp
    //     0x12e9648: ldp             fp, lr, [SP], #0x10
    // 0x12e964c: ret
    //     0x12e964c: ret             
    // 0x12e9650: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e9650: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e9654: b               #0x12e9570
  }
  _ visitNegationSelector(/* No info */) {
    // ** addr: 0x12e9c9c, size: 0x2c
    // 0x12e9c9c: EnterFrame
    //     0x12e9c9c: stp             fp, lr, [SP, #-0x10]!
    //     0x12e9ca0: mov             fp, SP
    // 0x12e9ca4: CheckStackOverflow
    //     0x12e9ca4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e9ca8: cmp             SP, x16
    //     0x12e9cac: b.ls            #0x12e9cc0
    // 0x12e9cb0: r0 = visitSimpleSelector()
    //     0x12e9cb0: bl              #0x12e9cc8  ; [package:csslib/visitor.dart] Visitor::visitSimpleSelector
    // 0x12e9cb4: LeaveFrame
    //     0x12e9cb4: mov             SP, fp
    //     0x12e9cb8: ldp             fp, lr, [SP], #0x10
    // 0x12e9cbc: ret
    //     0x12e9cbc: ret             
    // 0x12e9cc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e9cc0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e9cc4: b               #0x12e9cb0
  }
  _ visitSimpleSelector(/* No info */) {
    // ** addr: 0x12e9cc8, size: 0x9c
    // 0x12e9cc8: EnterFrame
    //     0x12e9cc8: stp             fp, lr, [SP, #-0x10]!
    //     0x12e9ccc: mov             fp, SP
    // 0x12e9cd0: AllocStack(0x10)
    //     0x12e9cd0: sub             SP, SP, #0x10
    // 0x12e9cd4: SetupParameters(Visitor this /* r1 => r3, fp-0x10 */)
    //     0x12e9cd4: mov             x3, x1
    //     0x12e9cd8: stur            x1, [fp, #-0x10]
    // 0x12e9cdc: CheckStackOverflow
    //     0x12e9cdc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e9ce0: cmp             SP, x16
    //     0x12e9ce4: b.ls            #0x12e9d5c
    // 0x12e9ce8: LoadField: r4 = r2->field_b
    //     0x12e9ce8: ldur            w4, [x2, #0xb]
    // 0x12e9cec: DecompressPointer r4
    //     0x12e9cec: add             x4, x4, HEAP, lsl #32
    // 0x12e9cf0: mov             x0, x4
    // 0x12e9cf4: stur            x4, [fp, #-8]
    // 0x12e9cf8: r2 = Null
    //     0x12e9cf8: mov             x2, NULL
    // 0x12e9cfc: r1 = Null
    //     0x12e9cfc: mov             x1, NULL
    // 0x12e9d00: r4 = 60
    //     0x12e9d00: mov             x4, #0x3c
    // 0x12e9d04: branchIfSmi(r0, 0x12e9d10)
    //     0x12e9d04: tbz             w0, #0, #0x12e9d10
    // 0x12e9d08: r4 = LoadClassIdInstr(r0)
    //     0x12e9d08: ldur            x4, [x0, #-1]
    //     0x12e9d0c: ubfx            x4, x4, #0xc, #0x14
    // 0x12e9d10: sub             x4, x4, #0xd67
    // 0x12e9d14: cmp             x4, #0x5b
    // 0x12e9d18: b.ls            #0x12e9d30
    // 0x12e9d1c: r8 = TreeNode
    //     0x12e9d1c: add             x8, PP, #0x8a, lsl #12  ; [pp+0x8af88] Type: TreeNode
    //     0x12e9d20: ldr             x8, [x8, #0xf88]
    // 0x12e9d24: r3 = Null
    //     0x12e9d24: add             x3, PP, #0x8a, lsl #12  ; [pp+0x8af90] Null
    //     0x12e9d28: ldr             x3, [x3, #0xf90]
    // 0x12e9d2c: r0 = TreeNode()
    //     0x12e9d2c: bl              #0xb0a880  ; IsType_TreeNode_Stub
    // 0x12e9d30: ldur            x1, [fp, #-8]
    // 0x12e9d34: r0 = LoadClassIdInstr(r1)
    //     0x12e9d34: ldur            x0, [x1, #-1]
    //     0x12e9d38: ubfx            x0, x0, #0xc, #0x14
    // 0x12e9d3c: ldur            x2, [fp, #-0x10]
    // 0x12e9d40: r0 = GDT[cid_x0 + 0xe553]()
    //     0x12e9d40: mov             x17, #0xe553
    //     0x12e9d44: add             lr, x0, x17
    //     0x12e9d48: ldr             lr, [x21, lr, lsl #3]
    //     0x12e9d4c: blr             lr
    // 0x12e9d50: LeaveFrame
    //     0x12e9d50: mov             SP, fp
    //     0x12e9d54: ldp             fp, lr, [SP], #0x10
    // 0x12e9d58: ret
    //     0x12e9d58: ret             
    // 0x12e9d5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e9d5c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e9d60: b               #0x12e9ce8
  }
  _ visitAttributeSelector(/* No info */) {
    // ** addr: 0x12e9e0c, size: 0x30
    // 0x12e9e0c: EnterFrame
    //     0x12e9e0c: stp             fp, lr, [SP, #-0x10]!
    //     0x12e9e10: mov             fp, SP
    // 0x12e9e14: CheckStackOverflow
    //     0x12e9e14: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e9e18: cmp             SP, x16
    //     0x12e9e1c: b.ls            #0x12e9e34
    // 0x12e9e20: r0 = visitSimpleSelector()
    //     0x12e9e20: bl              #0x12e9cc8  ; [package:csslib/visitor.dart] Visitor::visitSimpleSelector
    // 0x12e9e24: r0 = Null
    //     0x12e9e24: mov             x0, NULL
    // 0x12e9e28: LeaveFrame
    //     0x12e9e28: mov             SP, fp
    //     0x12e9e2c: ldp             fp, lr, [SP], #0x10
    // 0x12e9e30: ret
    //     0x12e9e30: ret             
    // 0x12e9e34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e9e34: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e9e38: b               #0x12e9e20
  }
  _ visitExpressions(/* No info */) {
    // ** addr: 0x12ea488, size: 0x3c
    // 0x12ea488: EnterFrame
    //     0x12ea488: stp             fp, lr, [SP, #-0x10]!
    //     0x12ea48c: mov             fp, SP
    // 0x12ea490: CheckStackOverflow
    //     0x12ea490: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12ea494: cmp             SP, x16
    //     0x12ea498: b.ls            #0x12ea4bc
    // 0x12ea49c: LoadField: r0 = r2->field_b
    //     0x12ea49c: ldur            w0, [x2, #0xb]
    // 0x12ea4a0: DecompressPointer r0
    //     0x12ea4a0: add             x0, x0, HEAP, lsl #32
    // 0x12ea4a4: mov             x2, x0
    // 0x12ea4a8: r0 = _visitNodeList()
    //     0x12ea4a8: bl              #0xd01b64  ; [package:csslib/visitor.dart] Visitor::_visitNodeList
    // 0x12ea4ac: r0 = Null
    //     0x12ea4ac: mov             x0, NULL
    // 0x12ea4b0: LeaveFrame
    //     0x12ea4b0: mov             SP, fp
    //     0x12ea4b4: ldp             fp, lr, [SP], #0x10
    // 0x12ea4b8: ret
    //     0x12ea4b8: ret             
    // 0x12ea4bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12ea4bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12ea4c0: b               #0x12ea49c
  }
}

// class id: 3528, size: 0x8, field offset: 0x8
abstract class VisitorBase extends Object {
}
