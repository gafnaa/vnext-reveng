// lib: , url: package:csslib/src/messages.dart

// class id: 1048682, size: 0x8
class :: {

  static late Messages messages; // offset: 0xf7c
}

// class id: 3530, size: 0x14, field offset: 0x8
class Messages extends Object {

  _ error(/* No info */) {
    // ** addr: 0xe13edc, size: 0x1b4
    // 0xe13edc: EnterFrame
    //     0xe13edc: stp             fp, lr, [SP, #-0x10]!
    //     0xe13ee0: mov             fp, SP
    // 0xe13ee4: AllocStack(0x28)
    //     0xe13ee4: sub             SP, SP, #0x28
    // 0xe13ee8: SetupParameters(Messages this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xe13ee8: stur            x1, [fp, #-8]
    //     0xe13eec: stur            x2, [fp, #-0x10]
    //     0xe13ef0: stur            x3, [fp, #-0x18]
    // 0xe13ef4: CheckStackOverflow
    //     0xe13ef4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe13ef8: cmp             SP, x16
    //     0xe13efc: b.ls            #0xe14088
    // 0xe13f00: r0 = Message()
    //     0xe13f00: bl              #0xe14090  ; AllocateMessageStub -> Message (size=0x18)
    // 0xe13f04: mov             x2, x0
    // 0xe13f08: r0 = Instance_MessageLevel
    //     0xe13f08: add             x0, PP, #0x20, lsl #12  ; [pp+0x20348] Obj!MessageLevel@12c65c1
    //     0xe13f0c: ldr             x0, [x0, #0x348]
    // 0xe13f10: stur            x2, [fp, #-0x28]
    // 0xe13f14: StoreField: r2->field_7 = r0
    //     0xe13f14: stur            w0, [x2, #7]
    // 0xe13f18: ldur            x0, [fp, #-0x10]
    // 0xe13f1c: StoreField: r2->field_b = r0
    //     0xe13f1c: stur            w0, [x2, #0xb]
    // 0xe13f20: ldur            x0, [fp, #-0x18]
    // 0xe13f24: StoreField: r2->field_f = r0
    //     0xe13f24: stur            w0, [x2, #0xf]
    // 0xe13f28: r0 = false
    //     0xe13f28: add             x0, NULL, #0x30  ; false
    // 0xe13f2c: StoreField: r2->field_13 = r0
    //     0xe13f2c: stur            w0, [x2, #0x13]
    // 0xe13f30: ldur            x0, [fp, #-8]
    // 0xe13f34: LoadField: r3 = r0->field_f
    //     0xe13f34: ldur            w3, [x0, #0xf]
    // 0xe13f38: DecompressPointer r3
    //     0xe13f38: add             x3, x3, HEAP, lsl #32
    // 0xe13f3c: stur            x3, [fp, #-0x10]
    // 0xe13f40: LoadField: r1 = r3->field_b
    //     0xe13f40: ldur            w1, [x3, #0xb]
    // 0xe13f44: LoadField: r4 = r3->field_f
    //     0xe13f44: ldur            w4, [x3, #0xf]
    // 0xe13f48: DecompressPointer r4
    //     0xe13f48: add             x4, x4, HEAP, lsl #32
    // 0xe13f4c: LoadField: r5 = r4->field_b
    //     0xe13f4c: ldur            w5, [x4, #0xb]
    // 0xe13f50: r4 = LoadInt32Instr(r1)
    //     0xe13f50: sbfx            x4, x1, #1, #0x1f
    // 0xe13f54: stur            x4, [fp, #-0x20]
    // 0xe13f58: r1 = LoadInt32Instr(r5)
    //     0xe13f58: sbfx            x1, x5, #1, #0x1f
    // 0xe13f5c: cmp             x4, x1
    // 0xe13f60: b.ne            #0xe13f6c
    // 0xe13f64: mov             x1, x3
    // 0xe13f68: r0 = _growToNextCapacity()
    //     0xe13f68: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xe13f6c: ldur            x2, [fp, #-8]
    // 0xe13f70: ldur            x0, [fp, #-0x10]
    // 0xe13f74: ldur            x3, [fp, #-0x20]
    // 0xe13f78: add             x1, x3, #1
    // 0xe13f7c: lsl             x4, x1, #1
    // 0xe13f80: StoreField: r0->field_b = r4
    //     0xe13f80: stur            w4, [x0, #0xb]
    // 0xe13f84: LoadField: r1 = r0->field_f
    //     0xe13f84: ldur            w1, [x0, #0xf]
    // 0xe13f88: DecompressPointer r1
    //     0xe13f88: add             x1, x1, HEAP, lsl #32
    // 0xe13f8c: ldur            x0, [fp, #-0x28]
    // 0xe13f90: ArrayStore: r1[r3] = r0  ; List_4
    //     0xe13f90: add             x25, x1, x3, lsl #2
    //     0xe13f94: add             x25, x25, #0xf
    //     0xe13f98: str             w0, [x25]
    //     0xe13f9c: tbz             w0, #0, #0xe13fb8
    //     0xe13fa0: ldurb           w16, [x1, #-1]
    //     0xe13fa4: ldurb           w17, [x0, #-1]
    //     0xe13fa8: and             x16, x17, x16, lsr #2
    //     0xe13fac: tst             x16, HEAP, lsr #32
    //     0xe13fb0: b.eq            #0xe13fb8
    //     0xe13fb4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xe13fb8: LoadField: r0 = r2->field_7
    //     0xe13fb8: ldur            w0, [x2, #7]
    // 0xe13fbc: DecompressPointer r0
    //     0xe13fbc: add             x0, x0, HEAP, lsl #32
    // 0xe13fc0: ArrayLoad: r3 = r0[0]  ; List_4
    //     0xe13fc0: ldur            w3, [x0, #0x17]
    // 0xe13fc4: DecompressPointer r3
    //     0xe13fc4: add             x3, x3, HEAP, lsl #32
    // 0xe13fc8: stur            x3, [fp, #-8]
    // 0xe13fcc: LoadField: r2 = r3->field_7
    //     0xe13fcc: ldur            w2, [x3, #7]
    // 0xe13fd0: DecompressPointer r2
    //     0xe13fd0: add             x2, x2, HEAP, lsl #32
    // 0xe13fd4: ldur            x0, [fp, #-0x28]
    // 0xe13fd8: r1 = Null
    //     0xe13fd8: mov             x1, NULL
    // 0xe13fdc: cmp             w2, NULL
    // 0xe13fe0: b.eq            #0xe14000
    // 0xe13fe4: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xe13fe4: ldur            w4, [x2, #0x17]
    // 0xe13fe8: DecompressPointer r4
    //     0xe13fe8: add             x4, x4, HEAP, lsl #32
    // 0xe13fec: r8 = X0
    //     0xe13fec: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xe13ff0: LoadField: r9 = r4->field_7
    //     0xe13ff0: ldur            x9, [x4, #7]
    // 0xe13ff4: r3 = Null
    //     0xe13ff4: add             x3, PP, #0x20, lsl #12  ; [pp+0x20350] Null
    //     0xe13ff8: ldr             x3, [x3, #0x350]
    // 0xe13ffc: blr             x9
    // 0xe14000: ldur            x0, [fp, #-8]
    // 0xe14004: LoadField: r1 = r0->field_b
    //     0xe14004: ldur            w1, [x0, #0xb]
    // 0xe14008: LoadField: r2 = r0->field_f
    //     0xe14008: ldur            w2, [x0, #0xf]
    // 0xe1400c: DecompressPointer r2
    //     0xe1400c: add             x2, x2, HEAP, lsl #32
    // 0xe14010: LoadField: r3 = r2->field_b
    //     0xe14010: ldur            w3, [x2, #0xb]
    // 0xe14014: r2 = LoadInt32Instr(r1)
    //     0xe14014: sbfx            x2, x1, #1, #0x1f
    // 0xe14018: stur            x2, [fp, #-0x20]
    // 0xe1401c: r1 = LoadInt32Instr(r3)
    //     0xe1401c: sbfx            x1, x3, #1, #0x1f
    // 0xe14020: cmp             x2, x1
    // 0xe14024: b.ne            #0xe14030
    // 0xe14028: mov             x1, x0
    // 0xe1402c: r0 = _growToNextCapacity()
    //     0xe1402c: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xe14030: ldur            x2, [fp, #-8]
    // 0xe14034: ldur            x3, [fp, #-0x20]
    // 0xe14038: add             x4, x3, #1
    // 0xe1403c: lsl             x5, x4, #1
    // 0xe14040: StoreField: r2->field_b = r5
    //     0xe14040: stur            w5, [x2, #0xb]
    // 0xe14044: LoadField: r1 = r2->field_f
    //     0xe14044: ldur            w1, [x2, #0xf]
    // 0xe14048: DecompressPointer r1
    //     0xe14048: add             x1, x1, HEAP, lsl #32
    // 0xe1404c: ldur            x0, [fp, #-0x28]
    // 0xe14050: ArrayStore: r1[r3] = r0  ; List_4
    //     0xe14050: add             x25, x1, x3, lsl #2
    //     0xe14054: add             x25, x25, #0xf
    //     0xe14058: str             w0, [x25]
    //     0xe1405c: tbz             w0, #0, #0xe14078
    //     0xe14060: ldurb           w16, [x1, #-1]
    //     0xe14064: ldurb           w17, [x0, #-1]
    //     0xe14068: and             x16, x17, x16, lsr #2
    //     0xe1406c: tst             x16, HEAP, lsr #32
    //     0xe14070: b.eq            #0xe14078
    //     0xe14074: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xe14078: r0 = Null
    //     0xe14078: mov             x0, NULL
    // 0xe1407c: LeaveFrame
    //     0xe1407c: mov             SP, fp
    //     0xe14080: ldp             fp, lr, [SP], #0x10
    // 0xe14084: ret
    //     0xe14084: ret             
    // 0xe14088: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe14088: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe1408c: b               #0xe13f00
  }
  _ warning(/* No info */) {
    // ** addr: 0xe19a40, size: 0xf0
    // 0xe19a40: EnterFrame
    //     0xe19a40: stp             fp, lr, [SP, #-0x10]!
    //     0xe19a44: mov             fp, SP
    // 0xe19a48: AllocStack(0x28)
    //     0xe19a48: sub             SP, SP, #0x28
    // 0xe19a4c: SetupParameters(Messages this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xe19a4c: stur            x1, [fp, #-8]
    //     0xe19a50: stur            x2, [fp, #-0x10]
    //     0xe19a54: stur            x3, [fp, #-0x18]
    // 0xe19a58: CheckStackOverflow
    //     0xe19a58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe19a5c: cmp             SP, x16
    //     0xe19a60: b.ls            #0xe19b28
    // 0xe19a64: r0 = Message()
    //     0xe19a64: bl              #0xe14090  ; AllocateMessageStub -> Message (size=0x18)
    // 0xe19a68: mov             x2, x0
    // 0xe19a6c: r0 = Instance_MessageLevel
    //     0xe19a6c: add             x0, PP, #0x8a, lsl #12  ; [pp+0x8a1e0] Obj!MessageLevel@12c65e1
    //     0xe19a70: ldr             x0, [x0, #0x1e0]
    // 0xe19a74: stur            x2, [fp, #-0x28]
    // 0xe19a78: StoreField: r2->field_7 = r0
    //     0xe19a78: stur            w0, [x2, #7]
    // 0xe19a7c: ldur            x0, [fp, #-0x10]
    // 0xe19a80: StoreField: r2->field_b = r0
    //     0xe19a80: stur            w0, [x2, #0xb]
    // 0xe19a84: ldur            x0, [fp, #-0x18]
    // 0xe19a88: StoreField: r2->field_f = r0
    //     0xe19a88: stur            w0, [x2, #0xf]
    // 0xe19a8c: r0 = false
    //     0xe19a8c: add             x0, NULL, #0x30  ; false
    // 0xe19a90: StoreField: r2->field_13 = r0
    //     0xe19a90: stur            w0, [x2, #0x13]
    // 0xe19a94: ldur            x0, [fp, #-8]
    // 0xe19a98: LoadField: r3 = r0->field_f
    //     0xe19a98: ldur            w3, [x0, #0xf]
    // 0xe19a9c: DecompressPointer r3
    //     0xe19a9c: add             x3, x3, HEAP, lsl #32
    // 0xe19aa0: stur            x3, [fp, #-0x10]
    // 0xe19aa4: LoadField: r0 = r3->field_b
    //     0xe19aa4: ldur            w0, [x3, #0xb]
    // 0xe19aa8: LoadField: r1 = r3->field_f
    //     0xe19aa8: ldur            w1, [x3, #0xf]
    // 0xe19aac: DecompressPointer r1
    //     0xe19aac: add             x1, x1, HEAP, lsl #32
    // 0xe19ab0: LoadField: r4 = r1->field_b
    //     0xe19ab0: ldur            w4, [x1, #0xb]
    // 0xe19ab4: r5 = LoadInt32Instr(r0)
    //     0xe19ab4: sbfx            x5, x0, #1, #0x1f
    // 0xe19ab8: stur            x5, [fp, #-0x20]
    // 0xe19abc: r0 = LoadInt32Instr(r4)
    //     0xe19abc: sbfx            x0, x4, #1, #0x1f
    // 0xe19ac0: cmp             x5, x0
    // 0xe19ac4: b.ne            #0xe19ad0
    // 0xe19ac8: mov             x1, x3
    // 0xe19acc: r0 = _growToNextCapacity()
    //     0xe19acc: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xe19ad0: ldur            x2, [fp, #-0x10]
    // 0xe19ad4: ldur            x3, [fp, #-0x20]
    // 0xe19ad8: add             x4, x3, #1
    // 0xe19adc: lsl             x5, x4, #1
    // 0xe19ae0: StoreField: r2->field_b = r5
    //     0xe19ae0: stur            w5, [x2, #0xb]
    // 0xe19ae4: LoadField: r1 = r2->field_f
    //     0xe19ae4: ldur            w1, [x2, #0xf]
    // 0xe19ae8: DecompressPointer r1
    //     0xe19ae8: add             x1, x1, HEAP, lsl #32
    // 0xe19aec: ldur            x0, [fp, #-0x28]
    // 0xe19af0: ArrayStore: r1[r3] = r0  ; List_4
    //     0xe19af0: add             x25, x1, x3, lsl #2
    //     0xe19af4: add             x25, x25, #0xf
    //     0xe19af8: str             w0, [x25]
    //     0xe19afc: tbz             w0, #0, #0xe19b18
    //     0xe19b00: ldurb           w16, [x1, #-1]
    //     0xe19b04: ldurb           w17, [x0, #-1]
    //     0xe19b08: and             x16, x17, x16, lsr #2
    //     0xe19b0c: tst             x16, HEAP, lsr #32
    //     0xe19b10: b.eq            #0xe19b18
    //     0xe19b14: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xe19b18: r0 = Null
    //     0xe19b18: mov             x0, NULL
    // 0xe19b1c: LeaveFrame
    //     0xe19b1c: mov             SP, fp
    //     0xe19b20: ldp             fp, lr, [SP], #0x10
    // 0xe19b24: ret
    //     0xe19b24: ret             
    // 0xe19b28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe19b28: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe19b2c: b               #0xe19a64
  }
  _ mergeMessages(/* No info */) {
    // ** addr: 0xe20148, size: 0xa0
    // 0xe20148: EnterFrame
    //     0xe20148: stp             fp, lr, [SP, #-0x10]!
    //     0xe2014c: mov             fp, SP
    // 0xe20150: AllocStack(0x20)
    //     0xe20150: sub             SP, SP, #0x20
    // 0xe20154: SetupParameters(Messages this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xe20154: stur            x1, [fp, #-8]
    //     0xe20158: stur            x2, [fp, #-0x10]
    // 0xe2015c: CheckStackOverflow
    //     0xe2015c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe20160: cmp             SP, x16
    //     0xe20164: b.ls            #0xe201e0
    // 0xe20168: r1 = 1
    //     0xe20168: mov             x1, #1
    // 0xe2016c: r0 = AllocateContext()
    //     0xe2016c: bl              #0x13de838  ; AllocateContextStub
    // 0xe20170: mov             x3, x0
    // 0xe20174: ldur            x0, [fp, #-8]
    // 0xe20178: stur            x3, [fp, #-0x20]
    // 0xe2017c: StoreField: r3->field_f = r0
    //     0xe2017c: stur            w0, [x3, #0xf]
    // 0xe20180: LoadField: r1 = r0->field_f
    //     0xe20180: ldur            w1, [x0, #0xf]
    // 0xe20184: DecompressPointer r1
    //     0xe20184: add             x1, x1, HEAP, lsl #32
    // 0xe20188: ldur            x2, [fp, #-0x10]
    // 0xe2018c: LoadField: r4 = r2->field_f
    //     0xe2018c: ldur            w4, [x2, #0xf]
    // 0xe20190: DecompressPointer r4
    //     0xe20190: add             x4, x4, HEAP, lsl #32
    // 0xe20194: mov             x2, x4
    // 0xe20198: stur            x4, [fp, #-0x18]
    // 0xe2019c: r0 = addAll()
    //     0xe2019c: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0xe201a0: ldur            x2, [fp, #-0x20]
    // 0xe201a4: r1 = Function '<anonymous closure>':.
    //     0xe201a4: add             x1, PP, #0x8a, lsl #12  ; [pp+0x8a588] AnonymousClosure: (0xe201e8), in [package:csslib/src/messages.dart] Messages::mergeMessages (0xe20148)
    //     0xe201a8: ldr             x1, [x1, #0x588]
    // 0xe201ac: r0 = AllocateClosure()
    //     0xe201ac: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xe201b0: ldur            x1, [fp, #-0x18]
    // 0xe201b4: mov             x2, x0
    // 0xe201b8: r0 = where()
    //     0xe201b8: bl              #0xb92e4c  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::where
    // 0xe201bc: mov             x1, x0
    // 0xe201c0: ldur            x0, [fp, #-8]
    // 0xe201c4: LoadField: r2 = r0->field_7
    //     0xe201c4: ldur            w2, [x0, #7]
    // 0xe201c8: DecompressPointer r2
    //     0xe201c8: add             x2, x2, HEAP, lsl #32
    // 0xe201cc: r0 = forEach()
    //     0xe201cc: bl              #0xaffee4  ; [dart:core] Iterable::forEach
    // 0xe201d0: r0 = Null
    //     0xe201d0: mov             x0, NULL
    // 0xe201d4: LeaveFrame
    //     0xe201d4: mov             SP, fp
    //     0xe201d8: ldp             fp, lr, [SP], #0x10
    // 0xe201dc: ret
    //     0xe201dc: ret             
    // 0xe201e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe201e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe201e4: b               #0xe20168
  }
  [closure] bool <anonymous closure>(dynamic, Message) {
    // ** addr: 0xe201e8, size: 0x2c
    // 0xe201e8: ldr             x1, [SP]
    // 0xe201ec: LoadField: r2 = r1->field_7
    //     0xe201ec: ldur            w2, [x1, #7]
    // 0xe201f0: DecompressPointer r2
    //     0xe201f0: add             x2, x2, HEAP, lsl #32
    // 0xe201f4: r16 = Instance_MessageLevel
    //     0xe201f4: add             x16, PP, #0x20, lsl #12  ; [pp+0x20348] Obj!MessageLevel@12c65c1
    //     0xe201f8: ldr             x16, [x16, #0x348]
    // 0xe201fc: cmp             w2, w16
    // 0xe20200: b.ne            #0xe2020c
    // 0xe20204: r0 = true
    //     0xe20204: add             x0, NULL, #0x20  ; true
    // 0xe20208: b               #0xe20210
    // 0xe2020c: r0 = false
    //     0xe2020c: add             x0, NULL, #0x30  ; false
    // 0xe20210: ret
    //     0xe20210: ret             
  }
}

// class id: 3531, size: 0x18, field offset: 0x8
class Message extends Object {

  _ toString(/* No info */) {
    // ** addr: 0x110b37c, size: 0x144
    // 0x110b37c: EnterFrame
    //     0x110b37c: stp             fp, lr, [SP, #-0x10]!
    //     0x110b380: mov             fp, SP
    // 0x110b384: AllocStack(0x20)
    //     0x110b384: sub             SP, SP, #0x20
    // 0x110b388: CheckStackOverflow
    //     0x110b388: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x110b38c: cmp             SP, x16
    //     0x110b390: b.ls            #0x110b4b8
    // 0x110b394: r0 = StringBuffer()
    //     0x110b394: bl              #0x7e51d4  ; AllocateStringBufferStub -> StringBuffer (size=0x38)
    // 0x110b398: mov             x1, x0
    // 0x110b39c: stur            x0, [fp, #-8]
    // 0x110b3a0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x110b3a0: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x110b3a4: r0 = StringBuffer()
    //     0x110b3a4: bl              #0x7e4a4c  ; [dart:core] StringBuffer::StringBuffer
    // 0x110b3a8: ldr             x0, [fp, #0x10]
    // 0x110b3ac: LoadField: r1 = r0->field_13
    //     0x110b3ac: ldur            w1, [x0, #0x13]
    // 0x110b3b0: DecompressPointer r1
    //     0x110b3b0: add             x1, x1, HEAP, lsl #32
    // 0x110b3b4: tbnz            w1, #4, #0x110b3d0
    // 0x110b3b8: LoadField: r2 = r0->field_7
    //     0x110b3b8: ldur            w2, [x0, #7]
    // 0x110b3bc: DecompressPointer r2
    //     0x110b3bc: add             x2, x2, HEAP, lsl #32
    // 0x110b3c0: r1 = _ConstMap len:3
    //     0x110b3c0: add             x1, PP, #0x7e, lsl #12  ; [pp+0x7ed68] Map<MessageLevel, String>(3)
    //     0x110b3c4: ldr             x1, [x1, #0xd68]
    // 0x110b3c8: r0 = containsKey()
    //     0x110b3c8: bl              #0x12d59fc  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::containsKey
    // 0x110b3cc: b               #0x110b3d4
    // 0x110b3d0: r0 = false
    //     0x110b3d0: add             x0, NULL, #0x30  ; false
    // 0x110b3d4: stur            x0, [fp, #-0x10]
    // 0x110b3d8: tbnz            w0, #4, #0x110b3fc
    // 0x110b3dc: ldr             x3, [fp, #0x10]
    // 0x110b3e0: LoadField: r2 = r3->field_7
    //     0x110b3e0: ldur            w2, [x3, #7]
    // 0x110b3e4: DecompressPointer r2
    //     0x110b3e4: add             x2, x2, HEAP, lsl #32
    // 0x110b3e8: r1 = _ConstMap len:3
    //     0x110b3e8: add             x1, PP, #0x7e, lsl #12  ; [pp+0x7ed68] Map<MessageLevel, String>(3)
    //     0x110b3ec: ldr             x1, [x1, #0xd68]
    // 0x110b3f0: r0 = []()
    //     0x110b3f0: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x110b3f4: mov             x3, x0
    // 0x110b3f8: b               #0x110b400
    // 0x110b3fc: r3 = Null
    //     0x110b3fc: mov             x3, NULL
    // 0x110b400: ldur            x0, [fp, #-0x10]
    // 0x110b404: stur            x3, [fp, #-0x18]
    // 0x110b408: tbnz            w0, #4, #0x110b418
    // 0x110b40c: ldur            x1, [fp, #-8]
    // 0x110b410: mov             x2, x3
    // 0x110b414: r0 = write()
    //     0x110b414: bl              #0x7e5154  ; [dart:core] StringBuffer::write
    // 0x110b418: ldr             x3, [fp, #0x10]
    // 0x110b41c: ldur            x0, [fp, #-0x10]
    // 0x110b420: LoadField: r2 = r3->field_7
    //     0x110b420: ldur            w2, [x3, #7]
    // 0x110b424: DecompressPointer r2
    //     0x110b424: add             x2, x2, HEAP, lsl #32
    // 0x110b428: r1 = _ConstMap len:3
    //     0x110b428: add             x1, PP, #0x7e, lsl #12  ; [pp+0x7ed70] Map<MessageLevel, String>(3)
    //     0x110b42c: ldr             x1, [x1, #0xd70]
    // 0x110b430: r0 = []()
    //     0x110b430: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x110b434: ldur            x1, [fp, #-8]
    // 0x110b438: mov             x2, x0
    // 0x110b43c: r0 = write()
    //     0x110b43c: bl              #0x7e5154  ; [dart:core] StringBuffer::write
    // 0x110b440: ldur            x1, [fp, #-8]
    // 0x110b444: r2 = " "
    //     0x110b444: ldr             x2, [PP, #0x8f8]  ; [pp+0x8f8] " "
    // 0x110b448: r0 = write()
    //     0x110b448: bl              #0x7e5154  ; [dart:core] StringBuffer::write
    // 0x110b44c: ldur            x0, [fp, #-0x10]
    // 0x110b450: tbnz            w0, #4, #0x110b464
    // 0x110b454: ldur            x1, [fp, #-8]
    // 0x110b458: r2 = "[0m"
    //     0x110b458: add             x2, PP, #0xd, lsl #12  ; [pp+0xdab8] "[0m"
    //     0x110b45c: ldr             x2, [x2, #0xab8]
    // 0x110b460: r0 = write()
    //     0x110b460: bl              #0x7e5154  ; [dart:core] StringBuffer::write
    // 0x110b464: ldr             x0, [fp, #0x10]
    // 0x110b468: ldur            x1, [fp, #-8]
    // 0x110b46c: r2 = "on "
    //     0x110b46c: add             x2, PP, #0x7e, lsl #12  ; [pp+0x7ed78] "on "
    //     0x110b470: ldr             x2, [x2, #0xd78]
    // 0x110b474: r0 = write()
    //     0x110b474: bl              #0x7e5154  ; [dart:core] StringBuffer::write
    // 0x110b478: ldr             x0, [fp, #0x10]
    // 0x110b47c: LoadField: r1 = r0->field_f
    //     0x110b47c: ldur            w1, [x0, #0xf]
    // 0x110b480: DecompressPointer r1
    //     0x110b480: add             x1, x1, HEAP, lsl #32
    // 0x110b484: LoadField: r2 = r0->field_b
    //     0x110b484: ldur            w2, [x0, #0xb]
    // 0x110b488: DecompressPointer r2
    //     0x110b488: add             x2, x2, HEAP, lsl #32
    // 0x110b48c: ldur            x3, [fp, #-0x18]
    // 0x110b490: r0 = message()
    //     0x110b490: bl              #0x110b4c0  ; [package:source_span/src/span_mixin.dart] SourceSpanMixin::message
    // 0x110b494: ldur            x1, [fp, #-8]
    // 0x110b498: mov             x2, x0
    // 0x110b49c: r0 = write()
    //     0x110b49c: bl              #0x7e5154  ; [dart:core] StringBuffer::write
    // 0x110b4a0: ldur            x16, [fp, #-8]
    // 0x110b4a4: str             x16, [SP]
    // 0x110b4a8: r0 = toString()
    //     0x110b4a8: bl              #0x1101d44  ; [dart:core] StringBuffer::toString
    // 0x110b4ac: LeaveFrame
    //     0x110b4ac: mov             SP, fp
    //     0x110b4b0: ldp             fp, lr, [SP], #0x10
    // 0x110b4b4: ret
    //     0x110b4b4: ret             
    // 0x110b4b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x110b4b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x110b4bc: b               #0x110b394
  }
}

// class id: 8338, size: 0x14, field offset: 0x14
enum MessageLevel extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11a9158, size: 0x64
    // 0x11a9158: EnterFrame
    //     0x11a9158: stp             fp, lr, [SP, #-0x10]!
    //     0x11a915c: mov             fp, SP
    // 0x11a9160: AllocStack(0x10)
    //     0x11a9160: sub             SP, SP, #0x10
    // 0x11a9164: SetupParameters(MessageLevel this /* r1 => r0, fp-0x8 */)
    //     0x11a9164: mov             x0, x1
    //     0x11a9168: stur            x1, [fp, #-8]
    // 0x11a916c: CheckStackOverflow
    //     0x11a916c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a9170: cmp             SP, x16
    //     0x11a9174: b.ls            #0x11a91b4
    // 0x11a9178: r1 = Null
    //     0x11a9178: mov             x1, NULL
    // 0x11a917c: r2 = 4
    //     0x11a917c: mov             x2, #4
    // 0x11a9180: r0 = AllocateArray()
    //     0x11a9180: bl              #0x13df928  ; AllocateArrayStub
    // 0x11a9184: r16 = "MessageLevel."
    //     0x11a9184: add             x16, PP, #0x7e, lsl #12  ; [pp+0x7ed80] "MessageLevel."
    //     0x11a9188: ldr             x16, [x16, #0xd80]
    // 0x11a918c: StoreField: r0->field_f = r16
    //     0x11a918c: stur            w16, [x0, #0xf]
    // 0x11a9190: ldur            x1, [fp, #-8]
    // 0x11a9194: LoadField: r2 = r1->field_f
    //     0x11a9194: ldur            w2, [x1, #0xf]
    // 0x11a9198: DecompressPointer r2
    //     0x11a9198: add             x2, x2, HEAP, lsl #32
    // 0x11a919c: StoreField: r0->field_13 = r2
    //     0x11a919c: stur            w2, [x0, #0x13]
    // 0x11a91a0: str             x0, [SP]
    // 0x11a91a4: r0 = _interpolate()
    //     0x11a91a4: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11a91a8: LeaveFrame
    //     0x11a91a8: mov             SP, fp
    //     0x11a91ac: ldp             fp, lr, [SP], #0x10
    // 0x11a91b0: ret
    //     0x11a91b0: ret             
    // 0x11a91b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a91b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a91b8: b               #0x11a9178
  }
}
