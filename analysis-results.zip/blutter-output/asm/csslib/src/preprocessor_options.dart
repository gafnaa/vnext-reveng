// lib: , url: package:csslib/src/preprocessor_options.dart

// class id: 1048683, size: 0x8
class :: {
}

// class id: 3529, size: 0x20, field offset: 0x8
//   const constructor, 
class PreprocessorOptions extends Object {

  bool field_8;
  bool field_c;
  bool field_10;
  bool field_14;
  bool field_18;
  _OneByteString field_1c;
}
