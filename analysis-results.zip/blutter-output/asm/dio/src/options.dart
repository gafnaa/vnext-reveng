// lib: , url: package:dio/src/options.dart

// class id: 1048708, size: 0x8
class :: {

  [closure] static bool _defaultValidateStatus(dynamic, int?) {
    // ** addr: 0x8eb9c4, size: 0x40
    // 0x8eb9c4: ldr             x1, [SP]
    // 0x8eb9c8: cmp             w1, NULL
    // 0x8eb9cc: b.eq            #0x8eb9fc
    // 0x8eb9d0: r2 = LoadInt32Instr(r1)
    //     0x8eb9d0: sbfx            x2, x1, #1, #0x1f
    //     0x8eb9d4: tbz             w1, #0, #0x8eb9dc
    //     0x8eb9d8: ldur            x2, [x1, #7]
    // 0x8eb9dc: cmp             x2, #0xc8
    // 0x8eb9e0: b.lt            #0x8eb9fc
    // 0x8eb9e4: cmp             x2, #0x12c
    // 0x8eb9e8: r16 = true
    //     0x8eb9e8: add             x16, NULL, #0x20  ; true
    // 0x8eb9ec: r17 = false
    //     0x8eb9ec: add             x17, NULL, #0x30  ; false
    // 0x8eb9f0: csel            x1, x16, x17, lt
    // 0x8eb9f4: mov             x0, x1
    // 0x8eb9f8: b               #0x8eba00
    // 0x8eb9fc: r0 = false
    //     0x8eb9fc: add             x0, NULL, #0x30  ; false
    // 0x8eba00: ret
    //     0x8eba00: ret             
  }
}

// class id: 3401, size: 0x50, field offset: 0x8
class Options extends Object {

  _ compose(/* No info */) {
    // ** addr: 0x9117a4, size: 0x690
    // 0x9117a4: EnterFrame
    //     0x9117a4: stp             fp, lr, [SP, #-0x10]!
    //     0x9117a8: mov             fp, SP
    // 0x9117ac: AllocStack(0x158)
    //     0x9117ac: sub             SP, SP, #0x158
    // 0x9117b0: SetupParameters(Options this /* r1 => r1, fp-0x18 */, dynamic _ /* r2 => r0, fp-0x20 */, dynamic _ /* r3 => r3, fp-0x28 */, dynamic _ /* r5 => r5, fp-0x30 */, dynamic _ /* r6 => r2, fp-0x38 */, {dynamic onReceiveProgress = Null /* r8, fp-0x10 */, dynamic sourceStackTrace = Null /* r4, fp-0x8 */})
    //     0x9117b0: mov             x0, x2
    //     0x9117b4: stur            x2, [fp, #-0x20]
    //     0x9117b8: mov             x2, x6
    //     0x9117bc: stur            x1, [fp, #-0x18]
    //     0x9117c0: stur            x3, [fp, #-0x28]
    //     0x9117c4: stur            x5, [fp, #-0x30]
    //     0x9117c8: stur            x6, [fp, #-0x38]
    //     0x9117cc: ldur            w6, [x4, #0x13]
    //     0x9117d0: ldur            w7, [x4, #0x1f]
    //     0x9117d4: add             x7, x7, HEAP, lsl #32
    //     0x9117d8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15d40] "onReceiveProgress"
    //     0x9117dc: ldr             x16, [x16, #0xd40]
    //     0x9117e0: cmp             w7, w16
    //     0x9117e4: b.ne            #0x911808
    //     0x9117e8: ldur            w7, [x4, #0x23]
    //     0x9117ec: add             x7, x7, HEAP, lsl #32
    //     0x9117f0: sub             w8, w6, w7
    //     0x9117f4: add             x7, fp, w8, sxtw #2
    //     0x9117f8: ldr             x7, [x7, #8]
    //     0x9117fc: mov             x8, x7
    //     0x911800: mov             x7, #1
    //     0x911804: b               #0x911810
    //     0x911808: mov             x8, NULL
    //     0x91180c: mov             x7, #0
    //     0x911810: stur            x8, [fp, #-0x10]
    //     0x911814: lsl             x9, x7, #1
    //     0x911818: lsl             w7, w9, #1
    //     0x91181c: add             w9, w7, #8
    //     0x911820: add             x16, x4, w9, sxtw #1
    //     0x911824: ldur            w10, [x16, #0xf]
    //     0x911828: add             x10, x10, HEAP, lsl #32
    //     0x91182c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15d68] "sourceStackTrace"
    //     0x911830: ldr             x16, [x16, #0xd68]
    //     0x911834: cmp             w10, w16
    //     0x911838: b.ne            #0x911860
    //     0x91183c: add             w9, w7, #0xa
    //     0x911840: add             x16, x4, w9, sxtw #1
    //     0x911844: ldur            w7, [x16, #0xf]
    //     0x911848: add             x7, x7, HEAP, lsl #32
    //     0x91184c: sub             w4, w6, w7
    //     0x911850: add             x6, fp, w4, sxtw #2
    //     0x911854: ldr             x6, [x6, #8]
    //     0x911858: mov             x4, x6
    //     0x91185c: b               #0x911864
    //     0x911860: mov             x4, NULL
    //     0x911864: stur            x4, [fp, #-8]
    // 0x911868: CheckStackOverflow
    //     0x911868: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91186c: cmp             SP, x16
    //     0x911870: b.ls            #0x911d90
    // 0x911874: r16 = <String, dynamic>
    //     0x911874: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x911878: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x91187c: stp             lr, x16, [SP]
    // 0x911880: r0 = Map._fromLiteral()
    //     0x911880: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x911884: mov             x3, x0
    // 0x911888: ldur            x0, [fp, #-0x20]
    // 0x91188c: stur            x3, [fp, #-0x40]
    // 0x911890: LoadField: r2 = r0->field_4f
    //     0x911890: ldur            w2, [x0, #0x4f]
    // 0x911894: DecompressPointer r2
    //     0x911894: add             x2, x2, HEAP, lsl #32
    // 0x911898: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x91189c: cmp             w2, w16
    // 0x9118a0: b.eq            #0x911d98
    // 0x9118a4: mov             x1, x3
    // 0x9118a8: r0 = addAll()
    //     0x9118a8: bl              #0xbb0e58  ; [dart:_compact_hash] _Map::addAll
    // 0x9118ac: ldur            x2, [fp, #-0x38]
    // 0x9118b0: cmp             w2, NULL
    // 0x9118b4: b.eq            #0x9118c0
    // 0x9118b8: ldur            x1, [fp, #-0x40]
    // 0x9118bc: r0 = addAll()
    //     0x9118bc: bl              #0xbb0e58  ; [dart:_compact_hash] _Map::addAll
    // 0x9118c0: ldur            x1, [fp, #-0x18]
    // 0x9118c4: ldur            x0, [fp, #-0x20]
    // 0x9118c8: LoadField: r2 = r0->field_b
    //     0x9118c8: ldur            w2, [x0, #0xb]
    // 0x9118cc: DecompressPointer r2
    //     0x9118cc: add             x2, x2, HEAP, lsl #32
    // 0x9118d0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9118d4: cmp             w2, w16
    // 0x9118d8: b.eq            #0x911da4
    // 0x9118dc: stp             x2, NULL, [SP]
    // 0x9118e0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x9118e0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x9118e4: r0 = caseInsensitiveKeyMap()
    //     0x9118e4: bl              #0x8eb034  ; [package:dio/src/utils.dart] ::caseInsensitiveKeyMap
    // 0x9118e8: mov             x4, x0
    // 0x9118ec: ldur            x3, [fp, #-0x18]
    // 0x9118f0: stur            x4, [fp, #-0x38]
    // 0x9118f4: LoadField: r2 = r3->field_b
    //     0x9118f4: ldur            w2, [x3, #0xb]
    // 0x9118f8: DecompressPointer r2
    //     0x9118f8: add             x2, x2, HEAP, lsl #32
    // 0x9118fc: cmp             w2, NULL
    // 0x911900: b.eq            #0x911924
    // 0x911904: r0 = LoadClassIdInstr(r4)
    //     0x911904: ldur            x0, [x4, #-1]
    //     0x911908: ubfx            x0, x0, #0xc, #0x14
    // 0x91190c: mov             x1, x4
    // 0x911910: r0 = GDT[cid_x0 + 0x12862]()
    //     0x911910: mov             x17, #0x2862
    //     0x911914: movk            x17, #1, lsl #16
    //     0x911918: add             lr, x0, x17
    //     0x91191c: ldr             lr, [x21, lr, lsl #3]
    //     0x911920: blr             lr
    // 0x911924: ldur            x4, [fp, #-0x18]
    // 0x911928: LoadField: r3 = r4->field_23
    //     0x911928: ldur            w3, [x4, #0x23]
    // 0x91192c: DecompressPointer r3
    //     0x91192c: add             x3, x3, HEAP, lsl #32
    // 0x911930: cmp             w3, NULL
    // 0x911934: b.eq            #0x91195c
    // 0x911938: ldur            x5, [fp, #-0x38]
    // 0x91193c: r0 = LoadClassIdInstr(r5)
    //     0x91193c: ldur            x0, [x5, #-1]
    //     0x911940: ubfx            x0, x0, #0xc, #0x14
    // 0x911944: mov             x1, x5
    // 0x911948: r2 = "content-type"
    //     0x911948: add             x2, PP, #8, lsl #12  ; [pp+0x85d8] "content-type"
    //     0x91194c: ldr             x2, [x2, #0x5d8]
    // 0x911950: r0 = GDT[cid_x0 + -0xd50]()
    //     0x911950: sub             lr, x0, #0xd50
    //     0x911954: ldr             lr, [x21, lr, lsl #3]
    //     0x911958: blr             lr
    // 0x91195c: ldur            x3, [fp, #-0x18]
    // 0x911960: ldur            x5, [fp, #-0x20]
    // 0x911964: ldur            x4, [fp, #-0x38]
    // 0x911968: r0 = LoadClassIdInstr(r4)
    //     0x911968: ldur            x0, [x4, #-1]
    //     0x91196c: ubfx            x0, x0, #0xc, #0x14
    // 0x911970: mov             x1, x4
    // 0x911974: r2 = "content-type"
    //     0x911974: add             x2, PP, #8, lsl #12  ; [pp+0x85d8] "content-type"
    //     0x911978: ldr             x2, [x2, #0x5d8]
    // 0x91197c: r0 = GDT[cid_x0 + -0xd48]()
    //     0x91197c: sub             lr, x0, #0xd48
    //     0x911980: ldr             lr, [x21, lr, lsl #3]
    //     0x911984: blr             lr
    // 0x911988: mov             x3, x0
    // 0x91198c: r2 = Null
    //     0x91198c: mov             x2, NULL
    // 0x911990: r1 = Null
    //     0x911990: mov             x1, NULL
    // 0x911994: stur            x3, [fp, #-0x48]
    // 0x911998: r4 = 60
    //     0x911998: mov             x4, #0x3c
    // 0x91199c: branchIfSmi(r0, 0x9119a8)
    //     0x91199c: tbz             w0, #0, #0x9119a8
    // 0x9119a0: r4 = LoadClassIdInstr(r0)
    //     0x9119a0: ldur            x4, [x0, #-1]
    //     0x9119a4: ubfx            x4, x4, #0xc, #0x14
    // 0x9119a8: sub             x4, x4, #0x5e
    // 0x9119ac: cmp             x4, #1
    // 0x9119b0: b.ls            #0x9119c4
    // 0x9119b4: r8 = String?
    //     0x9119b4: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x9119b8: r3 = Null
    //     0x9119b8: add             x3, PP, #0x16, lsl #12  ; [pp+0x16938] Null
    //     0x9119bc: ldr             x3, [x3, #0x938]
    // 0x9119c0: r0 = String?()
    //     0x9119c0: bl              #0x7db310  ; IsType_String?_Stub
    // 0x9119c4: ldur            x0, [fp, #-0x20]
    // 0x9119c8: LoadField: r2 = r0->field_2f
    //     0x9119c8: ldur            w2, [x0, #0x2f]
    // 0x9119cc: DecompressPointer r2
    //     0x9119cc: add             x2, x2, HEAP, lsl #32
    // 0x9119d0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9119d4: cmp             w2, w16
    // 0x9119d8: b.eq            #0x911db0
    // 0x9119dc: r1 = <String, dynamic>
    //     0x9119dc: ldr             x1, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x9119e0: r0 = LinkedHashMap.from()
    //     0x9119e0: bl              #0x8ac2e4  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x9119e4: mov             x3, x0
    // 0x9119e8: ldur            x0, [fp, #-0x18]
    // 0x9119ec: stur            x3, [fp, #-0x50]
    // 0x9119f0: LoadField: r2 = r0->field_33
    //     0x9119f0: ldur            w2, [x0, #0x33]
    // 0x9119f4: DecompressPointer r2
    //     0x9119f4: add             x2, x2, HEAP, lsl #32
    // 0x9119f8: cmp             w2, NULL
    // 0x9119fc: b.eq            #0x911a08
    // 0x911a00: mov             x1, x3
    // 0x911a04: r0 = addAll()
    //     0x911a04: bl              #0xbb0e58  ; [dart:_compact_hash] _Map::addAll
    // 0x911a08: ldur            x1, [fp, #-0x18]
    // 0x911a0c: LoadField: r0 = r1->field_7
    //     0x911a0c: ldur            w0, [x1, #7]
    // 0x911a10: DecompressPointer r0
    //     0x911a10: add             x0, x0, HEAP, lsl #32
    // 0x911a14: cmp             w0, NULL
    // 0x911a18: b.ne            #0x911a38
    // 0x911a1c: ldur            x2, [fp, #-0x20]
    // 0x911a20: LoadField: r0 = r2->field_7
    //     0x911a20: ldur            w0, [x2, #7]
    // 0x911a24: DecompressPointer r0
    //     0x911a24: add             x0, x0, HEAP, lsl #32
    // 0x911a28: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x911a2c: cmp             w0, w16
    // 0x911a30: b.eq            #0x911dbc
    // 0x911a34: b               #0x911a3c
    // 0x911a38: ldur            x2, [fp, #-0x20]
    // 0x911a3c: ldur            x3, [fp, #-8]
    // 0x911a40: r4 = LoadClassIdInstr(r0)
    //     0x911a40: ldur            x4, [x0, #-1]
    //     0x911a44: ubfx            x4, x4, #0xc, #0x14
    // 0x911a48: str             x0, [SP]
    // 0x911a4c: mov             x0, x4
    // 0x911a50: r0 = GDT[cid_x0 + -0xff8]()
    //     0x911a50: sub             lr, x0, #0xff8
    //     0x911a54: ldr             lr, [x21, lr, lsl #3]
    //     0x911a58: blr             lr
    // 0x911a5c: mov             x1, x0
    // 0x911a60: ldur            x0, [fp, #-0x20]
    // 0x911a64: stur            x1, [fp, #-0x60]
    // 0x911a68: LoadField: r2 = r0->field_4b
    //     0x911a68: ldur            w2, [x0, #0x4b]
    // 0x911a6c: DecompressPointer r2
    //     0x911a6c: add             x2, x2, HEAP, lsl #32
    // 0x911a70: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x911a74: cmp             w2, w16
    // 0x911a78: b.eq            #0x911dc8
    // 0x911a7c: stur            x2, [fp, #-0x58]
    // 0x911a80: LoadField: r3 = r0->field_f
    //     0x911a80: ldur            w3, [x0, #0xf]
    // 0x911a84: DecompressPointer r3
    //     0x911a84: add             x3, x3, HEAP, lsl #32
    // 0x911a88: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x911a8c: cmp             w3, w16
    // 0x911a90: b.eq            #0x911dd4
    // 0x911a94: ldur            x3, [fp, #-8]
    // 0x911a98: cmp             w3, NULL
    // 0x911a9c: b.ne            #0x911aa8
    // 0x911aa0: r0 = current()
    //     0x911aa0: bl              #0x7f0e88  ; [dart:core] StackTrace::current
    // 0x911aa4: mov             x3, x0
    // 0x911aa8: ldur            x1, [fp, #-0x18]
    // 0x911aac: ldur            x0, [fp, #-0x20]
    // 0x911ab0: stur            x3, [fp, #-0xb0]
    // 0x911ab4: LoadField: r4 = r0->field_53
    //     0x911ab4: ldur            w4, [x0, #0x53]
    // 0x911ab8: DecompressPointer r4
    //     0x911ab8: add             x4, x4, HEAP, lsl #32
    // 0x911abc: stur            x4, [fp, #-0xa8]
    // 0x911ac0: LoadField: r5 = r0->field_13
    //     0x911ac0: ldur            w5, [x0, #0x13]
    // 0x911ac4: DecompressPointer r5
    //     0x911ac4: add             x5, x5, HEAP, lsl #32
    // 0x911ac8: stur            x5, [fp, #-0xa0]
    // 0x911acc: ArrayLoad: r6 = r0[0]  ; List_4
    //     0x911acc: ldur            w6, [x0, #0x17]
    // 0x911ad0: DecompressPointer r6
    //     0x911ad0: add             x6, x6, HEAP, lsl #32
    // 0x911ad4: stur            x6, [fp, #-0x98]
    // 0x911ad8: LoadField: r2 = r1->field_27
    //     0x911ad8: ldur            w2, [x1, #0x27]
    // 0x911adc: DecompressPointer r2
    //     0x911adc: add             x2, x2, HEAP, lsl #32
    // 0x911ae0: cmp             w2, NULL
    // 0x911ae4: b.ne            #0x911b04
    // 0x911ae8: LoadField: r2 = r0->field_23
    //     0x911ae8: ldur            w2, [x0, #0x23]
    // 0x911aec: DecompressPointer r2
    //     0x911aec: add             x2, x2, HEAP, lsl #32
    // 0x911af0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x911af4: cmp             w2, w16
    // 0x911af8: b.eq            #0x911de0
    // 0x911afc: mov             x7, x2
    // 0x911b00: b               #0x911b08
    // 0x911b04: mov             x7, x2
    // 0x911b08: stur            x7, [fp, #-0x90]
    // 0x911b0c: LoadField: r2 = r1->field_2b
    //     0x911b0c: ldur            w2, [x1, #0x2b]
    // 0x911b10: DecompressPointer r2
    //     0x911b10: add             x2, x2, HEAP, lsl #32
    // 0x911b14: cmp             w2, NULL
    // 0x911b18: b.ne            #0x911b38
    // 0x911b1c: LoadField: r2 = r0->field_27
    //     0x911b1c: ldur            w2, [x0, #0x27]
    // 0x911b20: DecompressPointer r2
    //     0x911b20: add             x2, x2, HEAP, lsl #32
    // 0x911b24: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x911b28: cmp             w2, w16
    // 0x911b2c: b.eq            #0x911dec
    // 0x911b30: mov             x8, x2
    // 0x911b34: b               #0x911b3c
    // 0x911b38: mov             x8, x2
    // 0x911b3c: stur            x8, [fp, #-0x88]
    // 0x911b40: LoadField: r2 = r1->field_2f
    //     0x911b40: ldur            w2, [x1, #0x2f]
    // 0x911b44: DecompressPointer r2
    //     0x911b44: add             x2, x2, HEAP, lsl #32
    // 0x911b48: cmp             w2, NULL
    // 0x911b4c: b.ne            #0x911b6c
    // 0x911b50: LoadField: r2 = r0->field_2b
    //     0x911b50: ldur            w2, [x0, #0x2b]
    // 0x911b54: DecompressPointer r2
    //     0x911b54: add             x2, x2, HEAP, lsl #32
    // 0x911b58: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x911b5c: cmp             w2, w16
    // 0x911b60: b.eq            #0x911df8
    // 0x911b64: r10 = true
    //     0x911b64: add             x10, NULL, #0x20  ; true
    // 0x911b68: b               #0x911b70
    // 0x911b6c: mov             x10, x2
    // 0x911b70: stur            x10, [fp, #-0x80]
    // 0x911b74: LoadField: r2 = r1->field_37
    //     0x911b74: ldur            w2, [x1, #0x37]
    // 0x911b78: DecompressPointer r2
    //     0x911b78: add             x2, x2, HEAP, lsl #32
    // 0x911b7c: cmp             w2, NULL
    // 0x911b80: b.ne            #0x911ba0
    // 0x911b84: LoadField: r2 = r0->field_33
    //     0x911b84: ldur            w2, [x0, #0x33]
    // 0x911b88: DecompressPointer r2
    //     0x911b88: add             x2, x2, HEAP, lsl #32
    // 0x911b8c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x911b90: cmp             w2, w16
    // 0x911b94: b.eq            #0x911e04
    // 0x911b98: mov             x11, x2
    // 0x911b9c: b               #0x911ba4
    // 0x911ba0: mov             x11, x2
    // 0x911ba4: stur            x11, [fp, #-0x78]
    // 0x911ba8: LoadField: r2 = r1->field_3b
    //     0x911ba8: ldur            w2, [x1, #0x3b]
    // 0x911bac: DecompressPointer r2
    //     0x911bac: add             x2, x2, HEAP, lsl #32
    // 0x911bb0: cmp             w2, NULL
    // 0x911bb4: b.ne            #0x911bd4
    // 0x911bb8: LoadField: r2 = r0->field_37
    //     0x911bb8: ldur            w2, [x0, #0x37]
    // 0x911bbc: DecompressPointer r2
    //     0x911bbc: add             x2, x2, HEAP, lsl #32
    // 0x911bc0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x911bc4: cmp             w2, w16
    // 0x911bc8: b.eq            #0x911e10
    // 0x911bcc: r12 = 5
    //     0x911bcc: mov             x12, #5
    // 0x911bd0: b               #0x911bdc
    // 0x911bd4: r9 = LoadInt32Instr(r2)
    //     0x911bd4: sbfx            x9, x2, #1, #0x1f
    // 0x911bd8: mov             x12, x9
    // 0x911bdc: stur            x12, [fp, #-0x70]
    // 0x911be0: LoadField: r2 = r1->field_3f
    //     0x911be0: ldur            w2, [x1, #0x3f]
    // 0x911be4: DecompressPointer r2
    //     0x911be4: add             x2, x2, HEAP, lsl #32
    // 0x911be8: cmp             w2, NULL
    // 0x911bec: b.ne            #0x911c0c
    // 0x911bf0: LoadField: r2 = r0->field_3b
    //     0x911bf0: ldur            w2, [x0, #0x3b]
    // 0x911bf4: DecompressPointer r2
    //     0x911bf4: add             x2, x2, HEAP, lsl #32
    // 0x911bf8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x911bfc: cmp             w2, w16
    // 0x911c00: b.eq            #0x911e1c
    // 0x911c04: r13 = true
    //     0x911c04: add             x13, NULL, #0x20  ; true
    // 0x911c08: b               #0x911c10
    // 0x911c0c: mov             x13, x2
    // 0x911c10: stur            x13, [fp, #-0x68]
    // 0x911c14: LoadField: r2 = r1->field_4b
    //     0x911c14: ldur            w2, [x1, #0x4b]
    // 0x911c18: DecompressPointer r2
    //     0x911c18: add             x2, x2, HEAP, lsl #32
    // 0x911c1c: cmp             w2, NULL
    // 0x911c20: b.ne            #0x911c44
    // 0x911c24: LoadField: r2 = r0->field_47
    //     0x911c24: ldur            w2, [x0, #0x47]
    // 0x911c28: DecompressPointer r2
    //     0x911c28: add             x2, x2, HEAP, lsl #32
    // 0x911c2c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x911c30: cmp             w2, w16
    // 0x911c34: b.eq            #0x911e28
    // 0x911c38: r9 = Instance_ListFormat
    //     0x911c38: add             x9, PP, #0x15, lsl #12  ; [pp+0x15d88] Obj!ListFormat@12c63a1
    //     0x911c3c: ldr             x9, [x9, #0xd88]
    // 0x911c40: b               #0x911c48
    // 0x911c44: mov             x9, x2
    // 0x911c48: ldur            x2, [fp, #-0x48]
    // 0x911c4c: stur            x9, [fp, #-8]
    // 0x911c50: cmp             w2, NULL
    // 0x911c54: b.ne            #0x911c68
    // 0x911c58: LoadField: r2 = r1->field_23
    //     0x911c58: ldur            w2, [x1, #0x23]
    // 0x911c5c: DecompressPointer r2
    //     0x911c5c: add             x2, x2, HEAP, lsl #32
    // 0x911c60: mov             x1, x2
    // 0x911c64: b               #0x911c6c
    // 0x911c68: mov             x1, x2
    // 0x911c6c: cmp             w1, NULL
    // 0x911c70: b.ne            #0x911cd8
    // 0x911c74: LoadField: r1 = r0->field_b
    //     0x911c74: ldur            w1, [x0, #0xb]
    // 0x911c78: DecompressPointer r1
    //     0x911c78: add             x1, x1, HEAP, lsl #32
    // 0x911c7c: r0 = LoadClassIdInstr(r1)
    //     0x911c7c: ldur            x0, [x1, #-1]
    //     0x911c80: ubfx            x0, x0, #0xc, #0x14
    // 0x911c84: r2 = "content-type"
    //     0x911c84: add             x2, PP, #8, lsl #12  ; [pp+0x85d8] "content-type"
    //     0x911c88: ldr             x2, [x2, #0x5d8]
    // 0x911c8c: r0 = GDT[cid_x0 + -0xd48]()
    //     0x911c8c: sub             lr, x0, #0xd48
    //     0x911c90: ldr             lr, [x21, lr, lsl #3]
    //     0x911c94: blr             lr
    // 0x911c98: mov             x3, x0
    // 0x911c9c: r2 = Null
    //     0x911c9c: mov             x2, NULL
    // 0x911ca0: r1 = Null
    //     0x911ca0: mov             x1, NULL
    // 0x911ca4: stur            x3, [fp, #-0x18]
    // 0x911ca8: r4 = 60
    //     0x911ca8: mov             x4, #0x3c
    // 0x911cac: branchIfSmi(r0, 0x911cb8)
    //     0x911cac: tbz             w0, #0, #0x911cb8
    // 0x911cb0: r4 = LoadClassIdInstr(r0)
    //     0x911cb0: ldur            x4, [x0, #-1]
    //     0x911cb4: ubfx            x4, x4, #0xc, #0x14
    // 0x911cb8: sub             x4, x4, #0x5e
    // 0x911cbc: cmp             x4, #1
    // 0x911cc0: b.ls            #0x911cd4
    // 0x911cc4: r8 = String?
    //     0x911cc4: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x911cc8: r3 = Null
    //     0x911cc8: add             x3, PP, #0x16, lsl #12  ; [pp+0x16948] Null
    //     0x911ccc: ldr             x3, [x3, #0x948]
    // 0x911cd0: r0 = String?()
    //     0x911cd0: bl              #0x7db310  ; IsType_String?_Stub
    // 0x911cd4: ldur            x1, [fp, #-0x18]
    // 0x911cd8: ldur            x0, [fp, #-0x70]
    // 0x911cdc: stur            x1, [fp, #-0x20]
    // 0x911ce0: lsl             x2, x0, #1
    // 0x911ce4: stur            x2, [fp, #-0x18]
    // 0x911ce8: r0 = RequestOptions()
    //     0x911ce8: bl              #0x8eba04  ; AllocateRequestOptionsStub -> RequestOptions (size=0x70)
    // 0x911cec: stur            x0, [fp, #-0x48]
    // 0x911cf0: ldur            x16, [fp, #-0x60]
    // 0x911cf4: ldur            lr, [fp, #-0x38]
    // 0x911cf8: stp             lr, x16, [SP, #0x98]
    // 0x911cfc: ldur            x16, [fp, #-0x50]
    // 0x911d00: ldur            lr, [fp, #-0x58]
    // 0x911d04: stp             lr, x16, [SP, #0x88]
    // 0x911d08: ldur            x16, [fp, #-0x28]
    // 0x911d0c: ldur            lr, [fp, #-0x30]
    // 0x911d10: stp             lr, x16, [SP, #0x78]
    // 0x911d14: r16 = false
    //     0x911d14: add             x16, NULL, #0x30  ; false
    // 0x911d18: ldur            lr, [fp, #-0xb0]
    // 0x911d1c: stp             lr, x16, [SP, #0x68]
    // 0x911d20: ldur            x16, [fp, #-0xa8]
    // 0x911d24: ldur            lr, [fp, #-0xa0]
    // 0x911d28: stp             lr, x16, [SP, #0x58]
    // 0x911d2c: ldur            x16, [fp, #-0x98]
    // 0x911d30: ldur            lr, [fp, #-0x90]
    // 0x911d34: stp             lr, x16, [SP, #0x48]
    // 0x911d38: ldur            x16, [fp, #-0x88]
    // 0x911d3c: ldur            lr, [fp, #-0x80]
    // 0x911d40: stp             lr, x16, [SP, #0x38]
    // 0x911d44: ldur            x16, [fp, #-0x78]
    // 0x911d48: ldur            lr, [fp, #-0x18]
    // 0x911d4c: stp             lr, x16, [SP, #0x28]
    // 0x911d50: ldur            x16, [fp, #-0x68]
    // 0x911d54: ldur            lr, [fp, #-0x40]
    // 0x911d58: stp             lr, x16, [SP, #0x18]
    // 0x911d5c: ldur            x16, [fp, #-8]
    // 0x911d60: ldur            lr, [fp, #-0x10]
    // 0x911d64: stp             lr, x16, [SP, #8]
    // 0x911d68: ldur            x16, [fp, #-0x20]
    // 0x911d6c: str             x16, [SP]
    // 0x911d70: mov             x1, x0
    // 0x911d74: r4 = const [0, 0x16, 0x15, 0x1, baseUrl, 0x4, connectTimeout, 0x9, contentType, 0x15, data, 0x6, extra, 0x3, followRedirects, 0xf, headers, 0x2, listFormat, 0x13, maxRedirects, 0x10, method, 0x1, onReceiveProgress, 0x14, path, 0x5, persistentConnection, 0x11, preserveHeaderCase, 0x7, queryParameters, 0x12, receiveDataWhenStatusError, 0xe, receiveTimeout, 0xb, responseType, 0xc, sendTimeout, 0xa, sourceStackTrace, 0x8, validateStatus, 0xd, null]
    //     0x911d74: add             x4, PP, #0x16, lsl #12  ; [pp+0x16958] List(47) [0, 0x16, 0x15, 0x1, "baseUrl", 0x4, "connectTimeout", 0x9, "contentType", 0x15, "data", 0x6, "extra", 0x3, "followRedirects", 0xf, "headers", 0x2, "listFormat", 0x13, "maxRedirects", 0x10, "method", 0x1, "onReceiveProgress", 0x14, "path", 0x5, "persistentConnection", 0x11, "preserveHeaderCase", 0x7, "queryParameters", 0x12, "receiveDataWhenStatusError", 0xe, "receiveTimeout", 0xb, "responseType", 0xc, "sendTimeout", 0xa, "sourceStackTrace", 0x8, "validateStatus", 0xd, Null]
    //     0x911d78: ldr             x4, [x4, #0x958]
    // 0x911d7c: r0 = RequestOptions()
    //     0x911d7c: bl              #0x8ea020  ; [package:dio/src/options.dart] RequestOptions::RequestOptions
    // 0x911d80: ldur            x0, [fp, #-0x48]
    // 0x911d84: LeaveFrame
    //     0x911d84: mov             SP, fp
    //     0x911d88: ldp             fp, lr, [SP], #0x10
    // 0x911d8c: ret
    //     0x911d8c: ret             
    // 0x911d90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x911d90: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x911d94: b               #0x911874
    // 0x911d98: r9 = queryParameters
    //     0x911d98: add             x9, PP, #0x16, lsl #12  ; [pp+0x16588] Field <_MixinApplication368&_RequestConfig&OptionsMixin@18353248.queryParameters>: late (offset: 0x50)
    //     0x911d9c: ldr             x9, [x9, #0x588]
    // 0x911da0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x911da0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x911da4: r9 = _headers
    //     0x911da4: add             x9, PP, #0x15, lsl #12  ; [pp+0x15da8] Field <_RequestConfig@271184022._headers@271184022>: late (offset: 0xc)
    //     0x911da8: ldr             x9, [x9, #0xda8]
    // 0x911dac: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x911dac: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x911db0: r9 = extra
    //     0x911db0: add             x9, PP, #0x16, lsl #12  ; [pp+0x16928] Field <_RequestConfig@271184022.extra>: late (offset: 0x30)
    //     0x911db4: ldr             x9, [x9, #0x928]
    // 0x911db8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x911db8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x911dbc: r9 = method
    //     0x911dbc: add             x9, PP, #0x16, lsl #12  ; [pp+0x16500] Field <_RequestConfig@271184022.method>: late (offset: 0x8)
    //     0x911dc0: ldr             x9, [x9, #0x500]
    // 0x911dc4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x911dc4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x911dc8: r9 = _baseUrl
    //     0x911dc8: add             x9, PP, #0x15, lsl #12  ; [pp+0x15ec0] Field <_MixinApplication368&_RequestConfig&OptionsMixin@18353248._baseUrl@271184022>: late (offset: 0x4c)
    //     0x911dcc: ldr             x9, [x9, #0xec0]
    // 0x911dd0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x911dd0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x911dd4: r9 = preserveHeaderCase
    //     0x911dd4: add             x9, PP, #0x16, lsl #12  ; [pp+0x16070] Field <_RequestConfig@271184022.preserveHeaderCase>: late (offset: 0x10)
    //     0x911dd8: ldr             x9, [x9, #0x70]
    // 0x911ddc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x911ddc: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x911de0: r9 = responseType
    //     0x911de0: add             x9, PP, #0x15, lsl #12  ; [pp+0x15f58] Field <_RequestConfig@271184022.responseType>: late (offset: 0x24)
    //     0x911de4: ldr             x9, [x9, #0xf58]
    // 0x911de8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x911de8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x911dec: r9 = validateStatus
    //     0x911dec: add             x9, PP, #0x16, lsl #12  ; [pp+0x16078] Field <_RequestConfig@271184022.validateStatus>: late (offset: 0x28)
    //     0x911df0: ldr             x9, [x9, #0x78]
    // 0x911df4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x911df4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x911df8: r9 = receiveDataWhenStatusError
    //     0x911df8: add             x9, PP, #0x16, lsl #12  ; [pp+0x16080] Field <_RequestConfig@271184022.receiveDataWhenStatusError>: late (offset: 0x2c)
    //     0x911dfc: ldr             x9, [x9, #0x80]
    // 0x911e00: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x911e00: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x911e04: r9 = followRedirects
    //     0x911e04: add             x9, PP, #0x16, lsl #12  ; [pp+0x16508] Field <_RequestConfig@271184022.followRedirects>: late (offset: 0x34)
    //     0x911e08: ldr             x9, [x9, #0x508]
    // 0x911e0c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x911e0c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x911e10: r9 = maxRedirects
    //     0x911e10: add             x9, PP, #0x16, lsl #12  ; [pp+0x16510] Field <_RequestConfig@271184022.maxRedirects>: late (offset: 0x38)
    //     0x911e14: ldr             x9, [x9, #0x510]
    // 0x911e18: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x911e18: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x911e1c: r9 = persistentConnection
    //     0x911e1c: add             x9, PP, #0x16, lsl #12  ; [pp+0x16518] Field <_RequestConfig@271184022.persistentConnection>: late (offset: 0x3c)
    //     0x911e20: ldr             x9, [x9, #0x518]
    // 0x911e24: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x911e24: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x911e28: r9 = listFormat
    //     0x911e28: add             x9, PP, #0x16, lsl #12  ; [pp+0x16590] Field <_RequestConfig@271184022.listFormat>: late (offset: 0x48)
    //     0x911e2c: ldr             x9, [x9, #0x590]
    // 0x911e30: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x911e30: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 4259, size: 0x8, field offset: 0x8
abstract class OptionsMixin extends Object {
}

// class id: 4260, size: 0x4c, field offset: 0x8
abstract class _RequestConfig extends Object {

  late Map<String, dynamic> _headers; // offset: 0xc
  late ResponseType responseType; // offset: 0x24
  late bool preserveHeaderCase; // offset: 0x10
  late (dynamic, int?) => bool validateStatus; // offset: 0x28
  late bool receiveDataWhenStatusError; // offset: 0x2c
  late String method; // offset: 0x8
  late bool followRedirects; // offset: 0x34
  late int maxRedirects; // offset: 0x38
  late bool persistentConnection; // offset: 0x3c
  late ListFormat listFormat; // offset: 0x48
  late Map<String, dynamic> extra; // offset: 0x30

  Map<String, dynamic> dyn:get:headers(_RequestConfig) {
    // ** addr: 0x8ea928, size: 0x48
    // 0x8ea928: ldr             x1, [SP]
    // 0x8ea92c: LoadField: r0 = r1->field_b
    //     0x8ea92c: ldur            w0, [x1, #0xb]
    // 0x8ea930: DecompressPointer r0
    //     0x8ea930: add             x0, x0, HEAP, lsl #32
    // 0x8ea934: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8ea938: cmp             w0, w16
    // 0x8ea93c: b.eq            #0x8ea944
    // 0x8ea940: ret
    //     0x8ea940: ret             
    // 0x8ea944: EnterFrame
    //     0x8ea944: stp             fp, lr, [SP, #-0x10]!
    //     0x8ea948: mov             fp, SP
    // 0x8ea94c: r9 = _headers
    //     0x8ea94c: add             x9, PP, #0x15, lsl #12  ; [pp+0x15da8] Field <_RequestConfig@271184022._headers@271184022>: late (offset: 0xc)
    //     0x8ea950: ldr             x9, [x9, #0xda8]
    // 0x8ea954: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8ea954: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _RequestConfig(/* No info */) {
    // ** addr: 0x8eab18, size: 0x33c
    // 0x8eab18: EnterFrame
    //     0x8eab18: stp             fp, lr, [SP, #-0x10]!
    //     0x8eab1c: mov             fp, SP
    // 0x8eab20: AllocStack(0x30)
    //     0x8eab20: sub             SP, SP, #0x30
    // 0x8eab24: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x8eab28: mov             x4, x1
    // 0x8eab2c: stur            x1, [fp, #-8]
    // 0x8eab30: mov             x1, x2
    // 0x8eab34: stur            x2, [fp, #-0x10]
    // 0x8eab38: mov             x2, x6
    // 0x8eab3c: stur            x5, [fp, #-0x18]
    // 0x8eab40: stur            x6, [fp, #-0x20]
    // 0x8eab44: CheckStackOverflow
    //     0x8eab44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8eab48: cmp             SP, x16
    //     0x8eab4c: b.ls            #0x8eae40
    // 0x8eab50: StoreField: r4->field_b = r0
    //     0x8eab50: stur            w0, [x4, #0xb]
    // 0x8eab54: ldr             x0, [fp, #0x28]
    // 0x8eab58: ArrayStore: r4[0] = r0  ; List_4
    //     0x8eab58: stur            w0, [x4, #0x17]
    //     0x8eab5c: ldurb           w16, [x4, #-1]
    //     0x8eab60: ldurb           w17, [x0, #-1]
    //     0x8eab64: and             x16, x17, x16, lsr #2
    //     0x8eab68: tst             x16, HEAP, lsr #32
    //     0x8eab6c: b.eq            #0x8eab74
    //     0x8eab70: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0x8eab74: ldr             x0, [fp, #0x18]
    // 0x8eab78: StoreField: r4->field_13 = r0
    //     0x8eab78: stur            w0, [x4, #0x13]
    //     0x8eab7c: ldurb           w16, [x4, #-1]
    //     0x8eab80: ldurb           w17, [x0, #-1]
    //     0x8eab84: and             x16, x17, x16, lsr #2
    //     0x8eab88: tst             x16, HEAP, lsr #32
    //     0x8eab8c: b.eq            #0x8eab94
    //     0x8eab90: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0x8eab94: ldr             x0, [fp, #0x48]
    // 0x8eab98: cmp             w0, NULL
    // 0x8eab9c: b.ne            #0x8eaba8
    // 0x8eaba0: r0 = "GET"
    //     0x8eaba0: add             x0, PP, #8, lsl #12  ; [pp+0x8508] "GET"
    //     0x8eaba4: ldr             x0, [x0, #0x508]
    // 0x8eaba8: ldr             x6, [fp, #0x38]
    // 0x8eabac: StoreField: r4->field_7 = r0
    //     0x8eabac: stur            w0, [x4, #7]
    //     0x8eabb0: ldurb           w16, [x4, #-1]
    //     0x8eabb4: ldurb           w17, [x0, #-1]
    //     0x8eabb8: and             x16, x17, x16, lsr #2
    //     0x8eabbc: tst             x16, HEAP, lsr #32
    //     0x8eabc0: b.eq            #0x8eabc8
    //     0x8eabc4: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0x8eabc8: cmp             w6, NULL
    // 0x8eabcc: b.ne            #0x8eabd8
    // 0x8eabd0: r0 = false
    //     0x8eabd0: add             x0, NULL, #0x30  ; false
    // 0x8eabd4: b               #0x8eabdc
    // 0x8eabd8: mov             x0, x6
    // 0x8eabdc: StoreField: r4->field_f = r0
    //     0x8eabdc: stur            w0, [x4, #0xf]
    // 0x8eabe0: cmp             w7, NULL
    // 0x8eabe4: b.ne            #0x8eabf4
    // 0x8eabe8: r0 = Instance_ListFormat
    //     0x8eabe8: add             x0, PP, #0x15, lsl #12  ; [pp+0x15d88] Obj!ListFormat@12c63a1
    //     0x8eabec: ldr             x0, [x0, #0xd88]
    // 0x8eabf0: b               #0x8eabf8
    // 0x8eabf4: mov             x0, x7
    // 0x8eabf8: StoreField: r4->field_47 = r0
    //     0x8eabf8: stur            w0, [x4, #0x47]
    //     0x8eabfc: ldurb           w16, [x4, #-1]
    //     0x8eac00: ldurb           w17, [x0, #-1]
    //     0x8eac04: and             x16, x17, x16, lsr #2
    //     0x8eac08: tst             x16, HEAP, lsr #32
    //     0x8eac0c: b.eq            #0x8eac14
    //     0x8eac10: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0x8eac14: cmp             w3, NULL
    // 0x8eac18: b.ne            #0x8eac30
    // 0x8eac1c: r16 = <String, dynamic>
    //     0x8eac1c: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x8eac20: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x8eac24: stp             lr, x16, [SP]
    // 0x8eac28: r0 = Map._fromLiteral()
    //     0x8eac28: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x8eac2c: b               #0x8eac34
    // 0x8eac30: mov             x0, x3
    // 0x8eac34: ldur            x3, [fp, #-8]
    // 0x8eac38: ldur            x1, [fp, #-0x18]
    // 0x8eac3c: StoreField: r3->field_2f = r0
    //     0x8eac3c: stur            w0, [x3, #0x2f]
    //     0x8eac40: tbz             w0, #0, #0x8eac5c
    //     0x8eac44: ldurb           w16, [x3, #-1]
    //     0x8eac48: ldurb           w17, [x0, #-1]
    //     0x8eac4c: and             x16, x17, x16, lsr #2
    //     0x8eac50: tst             x16, HEAP, lsr #32
    //     0x8eac54: b.eq            #0x8eac5c
    //     0x8eac58: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x8eac5c: cmp             w1, NULL
    // 0x8eac60: b.ne            #0x8eac68
    // 0x8eac64: r1 = true
    //     0x8eac64: add             x1, NULL, #0x20  ; true
    // 0x8eac68: ldr             x0, [fp, #0x50]
    // 0x8eac6c: StoreField: r3->field_33 = r1
    //     0x8eac6c: stur            w1, [x3, #0x33]
    // 0x8eac70: cmp             w0, NULL
    // 0x8eac74: b.ne            #0x8eac80
    // 0x8eac78: r1 = 5
    //     0x8eac78: mov             x1, #5
    // 0x8eac7c: b               #0x8eac84
    // 0x8eac80: r1 = LoadInt32Instr(r0)
    //     0x8eac80: sbfx            x1, x0, #1, #0x1f
    // 0x8eac84: ldr             x0, [fp, #0x40]
    // 0x8eac88: lsl             x2, x1, #1
    // 0x8eac8c: StoreField: r3->field_37 = r2
    //     0x8eac8c: stur            w2, [x3, #0x37]
    // 0x8eac90: cmp             w0, NULL
    // 0x8eac94: b.ne            #0x8eaca0
    // 0x8eac98: r1 = true
    //     0x8eac98: add             x1, NULL, #0x20  ; true
    // 0x8eac9c: b               #0x8eaca4
    // 0x8eaca0: mov             x1, x0
    // 0x8eaca4: ldr             x0, [fp, #0x30]
    // 0x8eaca8: StoreField: r3->field_3b = r1
    //     0x8eaca8: stur            w1, [x3, #0x3b]
    // 0x8eacac: cmp             w0, NULL
    // 0x8eacb0: b.ne            #0x8eacbc
    // 0x8eacb4: r1 = true
    //     0x8eacb4: add             x1, NULL, #0x20  ; true
    // 0x8eacb8: b               #0x8eacc0
    // 0x8eacbc: mov             x1, x0
    // 0x8eacc0: ldr             x0, [fp, #0x10]
    // 0x8eacc4: StoreField: r3->field_2b = r1
    //     0x8eacc4: stur            w1, [x3, #0x2b]
    // 0x8eacc8: cmp             w0, NULL
    // 0x8eaccc: b.ne            #0x8eacd8
    // 0x8eacd0: r0 = Closure: (int?) => bool from Function '_defaultValidateStatus@271184022': static.
    //     0x8eacd0: add             x0, PP, #0x15, lsl #12  ; [pp+0x15d90] Closure: (int?) => bool from Function '_defaultValidateStatus@271184022': static. (0x7f2ada7d29c4)
    //     0x8eacd4: ldr             x0, [x0, #0xd90]
    // 0x8eacd8: ldr             x1, [fp, #0x20]
    // 0x8eacdc: StoreField: r3->field_27 = r0
    //     0x8eacdc: stur            w0, [x3, #0x27]
    //     0x8eace0: ldurb           w16, [x3, #-1]
    //     0x8eace4: ldurb           w17, [x0, #-1]
    //     0x8eace8: and             x16, x17, x16, lsr #2
    //     0x8eacec: tst             x16, HEAP, lsr #32
    //     0x8eacf0: b.eq            #0x8eacf8
    //     0x8eacf4: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x8eacf8: cmp             w1, NULL
    // 0x8eacfc: b.ne            #0x8ead0c
    // 0x8ead00: r0 = Instance_ResponseType
    //     0x8ead00: add             x0, PP, #0x15, lsl #12  ; [pp+0x15d98] Obj!ResponseType@12c63c1
    //     0x8ead04: ldr             x0, [x0, #0xd98]
    // 0x8ead08: b               #0x8ead10
    // 0x8ead0c: mov             x0, x1
    // 0x8ead10: ldur            x4, [fp, #-0x10]
    // 0x8ead14: StoreField: r3->field_23 = r0
    //     0x8ead14: stur            w0, [x3, #0x23]
    //     0x8ead18: ldurb           w16, [x3, #-1]
    //     0x8ead1c: ldurb           w17, [x0, #-1]
    //     0x8ead20: and             x16, x17, x16, lsr #2
    //     0x8ead24: tst             x16, HEAP, lsr #32
    //     0x8ead28: b.eq            #0x8ead30
    //     0x8ead2c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x8ead30: mov             x1, x3
    // 0x8ead34: ldur            x2, [fp, #-0x20]
    // 0x8ead38: r0 = headers=()
    //     0x8ead38: bl              #0x8eaf78  ; [package:dio/src/options.dart] _RequestConfig::headers=
    // 0x8ead3c: ldur            x3, [fp, #-8]
    // 0x8ead40: LoadField: r1 = r3->field_b
    //     0x8ead40: ldur            w1, [x3, #0xb]
    // 0x8ead44: DecompressPointer r1
    //     0x8ead44: add             x1, x1, HEAP, lsl #32
    // 0x8ead48: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8ead4c: cmp             w1, w16
    // 0x8ead50: b.eq            #0x8eae48
    // 0x8ead54: r0 = LoadClassIdInstr(r1)
    //     0x8ead54: ldur            x0, [x1, #-1]
    //     0x8ead58: ubfx            x0, x0, #0xc, #0x14
    // 0x8ead5c: r2 = "content-type"
    //     0x8ead5c: add             x2, PP, #8, lsl #12  ; [pp+0x85d8] "content-type"
    //     0x8ead60: ldr             x2, [x2, #0x5d8]
    // 0x8ead64: r0 = GDT[cid_x0 + -0x104]()
    //     0x8ead64: sub             lr, x0, #0x104
    //     0x8ead68: ldr             lr, [x21, lr, lsl #3]
    //     0x8ead6c: blr             lr
    // 0x8ead70: mov             x4, x0
    // 0x8ead74: ldur            x3, [fp, #-0x10]
    // 0x8ead78: stur            x4, [fp, #-0x18]
    // 0x8ead7c: cmp             w3, NULL
    // 0x8ead80: b.eq            #0x8eaddc
    // 0x8ead84: tbnz            w4, #4, #0x8eaddc
    // 0x8ead88: ldur            x5, [fp, #-8]
    // 0x8ead8c: LoadField: r1 = r5->field_b
    //     0x8ead8c: ldur            w1, [x5, #0xb]
    // 0x8ead90: DecompressPointer r1
    //     0x8ead90: add             x1, x1, HEAP, lsl #32
    // 0x8ead94: r0 = LoadClassIdInstr(r1)
    //     0x8ead94: ldur            x0, [x1, #-1]
    //     0x8ead98: ubfx            x0, x0, #0xc, #0x14
    // 0x8ead9c: r2 = "content-type"
    //     0x8ead9c: add             x2, PP, #8, lsl #12  ; [pp+0x85d8] "content-type"
    //     0x8eada0: ldr             x2, [x2, #0x5d8]
    // 0x8eada4: r0 = GDT[cid_x0 + -0xd48]()
    //     0x8eada4: sub             lr, x0, #0xd48
    //     0x8eada8: ldr             lr, [x21, lr, lsl #3]
    //     0x8eadac: blr             lr
    // 0x8eadb0: r1 = 60
    //     0x8eadb0: mov             x1, #0x3c
    // 0x8eadb4: branchIfSmi(r0, 0x8eadc0)
    //     0x8eadb4: tbz             w0, #0, #0x8eadc0
    // 0x8eadb8: r1 = LoadClassIdInstr(r0)
    //     0x8eadb8: ldur            x1, [x0, #-1]
    //     0x8eadbc: ubfx            x1, x1, #0xc, #0x14
    // 0x8eadc0: ldur            x16, [fp, #-0x10]
    // 0x8eadc4: stp             x16, x0, [SP]
    // 0x8eadc8: mov             x0, x1
    // 0x8eadcc: mov             lr, x0
    // 0x8eadd0: ldr             lr, [x21, lr, lsl #3]
    // 0x8eadd4: blr             lr
    // 0x8eadd8: tbnz            w0, #4, #0x8eae00
    // 0x8eaddc: ldur            x0, [fp, #-0x18]
    // 0x8eade0: tbz             w0, #4, #0x8eadf0
    // 0x8eade4: ldur            x1, [fp, #-8]
    // 0x8eade8: ldur            x2, [fp, #-0x10]
    // 0x8eadec: r0 = contentType=()
    //     0x8eadec: bl              #0x8eae54  ; [package:dio/src/options.dart] _RequestConfig::contentType=
    // 0x8eadf0: r0 = Null
    //     0x8eadf0: mov             x0, NULL
    // 0x8eadf4: LeaveFrame
    //     0x8eadf4: mov             SP, fp
    //     0x8eadf8: ldp             fp, lr, [SP], #0x10
    // 0x8eadfc: ret
    //     0x8eadfc: ret             
    // 0x8eae00: ldur            x0, [fp, #-0x10]
    // 0x8eae04: r0 = ArgumentError()
    //     0x8eae04: bl              #0x7dcb60  ; AllocateArgumentErrorStub -> ArgumentError (size=0x1c)
    // 0x8eae08: mov             x1, x0
    // 0x8eae0c: r0 = "contentType"
    //     0x8eae0c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15d10] "contentType"
    //     0x8eae10: ldr             x0, [x0, #0xd10]
    // 0x8eae14: StoreField: r1->field_13 = r0
    //     0x8eae14: stur            w0, [x1, #0x13]
    // 0x8eae18: r0 = "Unable to set different values for `contentType` and the content-type header."
    //     0x8eae18: add             x0, PP, #0x15, lsl #12  ; [pp+0x15da0] "Unable to set different values for `contentType` and the content-type header."
    //     0x8eae1c: ldr             x0, [x0, #0xda0]
    // 0x8eae20: ArrayStore: r1[0] = r0  ; List_4
    //     0x8eae20: stur            w0, [x1, #0x17]
    // 0x8eae24: ldur            x0, [fp, #-0x10]
    // 0x8eae28: StoreField: r1->field_f = r0
    //     0x8eae28: stur            w0, [x1, #0xf]
    // 0x8eae2c: r0 = true
    //     0x8eae2c: add             x0, NULL, #0x20  ; true
    // 0x8eae30: StoreField: r1->field_b = r0
    //     0x8eae30: stur            w0, [x1, #0xb]
    // 0x8eae34: mov             x0, x1
    // 0x8eae38: r0 = Throw()
    //     0x8eae38: bl              #0x13ddb2c  ; ThrowStub
    // 0x8eae3c: brk             #0
    // 0x8eae40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8eae40: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8eae44: b               #0x8eab50
    // 0x8eae48: r9 = _headers
    //     0x8eae48: add             x9, PP, #0x15, lsl #12  ; [pp+0x15da8] Field <_RequestConfig@271184022._headers@271184022>: late (offset: 0xc)
    //     0x8eae4c: ldr             x9, [x9, #0xda8]
    // 0x8eae50: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8eae50: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  set _ contentType=(/* No info */) {
    // ** addr: 0x8eae54, size: 0x124
    // 0x8eae54: EnterFrame
    //     0x8eae54: stp             fp, lr, [SP, #-0x10]!
    //     0x8eae58: mov             fp, SP
    // 0x8eae5c: AllocStack(0x8)
    //     0x8eae5c: sub             SP, SP, #8
    // 0x8eae60: SetupParameters(_RequestConfig this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1 */)
    //     0x8eae60: mov             x0, x1
    //     0x8eae64: stur            x1, [fp, #-8]
    //     0x8eae68: mov             x1, x2
    // 0x8eae6c: CheckStackOverflow
    //     0x8eae6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8eae70: cmp             SP, x16
    //     0x8eae74: b.ls            #0x8eaf58
    // 0x8eae78: cmp             w1, NULL
    // 0x8eae7c: b.ne            #0x8eae8c
    // 0x8eae80: mov             x1, x0
    // 0x8eae84: r2 = Null
    //     0x8eae84: mov             x2, NULL
    // 0x8eae88: b               #0x8eae98
    // 0x8eae8c: r0 = trim()
    //     0x8eae8c: bl              #0x808ff4  ; [dart:core] _StringBase::trim
    // 0x8eae90: mov             x2, x0
    // 0x8eae94: ldur            x1, [fp, #-8]
    // 0x8eae98: mov             x0, x2
    // 0x8eae9c: StoreField: r1->field_1f = r0
    //     0x8eae9c: stur            w0, [x1, #0x1f]
    //     0x8eaea0: ldurb           w16, [x1, #-1]
    //     0x8eaea4: ldurb           w17, [x0, #-1]
    //     0x8eaea8: and             x16, x17, x16, lsr #2
    //     0x8eaeac: tst             x16, HEAP, lsr #32
    //     0x8eaeb0: b.eq            #0x8eaeb8
    //     0x8eaeb4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8eaeb8: cmp             w2, NULL
    // 0x8eaebc: b.eq            #0x8eaf04
    // 0x8eaec0: LoadField: r0 = r1->field_b
    //     0x8eaec0: ldur            w0, [x1, #0xb]
    // 0x8eaec4: DecompressPointer r0
    //     0x8eaec4: add             x0, x0, HEAP, lsl #32
    // 0x8eaec8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8eaecc: cmp             w0, w16
    // 0x8eaed0: b.eq            #0x8eaf60
    // 0x8eaed4: r1 = LoadClassIdInstr(r0)
    //     0x8eaed4: ldur            x1, [x0, #-1]
    //     0x8eaed8: ubfx            x1, x1, #0xc, #0x14
    // 0x8eaedc: mov             x16, x0
    // 0x8eaee0: mov             x0, x1
    // 0x8eaee4: mov             x1, x16
    // 0x8eaee8: mov             x3, x2
    // 0x8eaeec: r2 = "content-type"
    //     0x8eaeec: add             x2, PP, #8, lsl #12  ; [pp+0x85d8] "content-type"
    //     0x8eaef0: ldr             x2, [x2, #0x5d8]
    // 0x8eaef4: r0 = GDT[cid_x0 + -0xd50]()
    //     0x8eaef4: sub             lr, x0, #0xd50
    //     0x8eaef8: ldr             lr, [x21, lr, lsl #3]
    //     0x8eaefc: blr             lr
    // 0x8eaf00: b               #0x8eaf48
    // 0x8eaf04: LoadField: r0 = r1->field_b
    //     0x8eaf04: ldur            w0, [x1, #0xb]
    // 0x8eaf08: DecompressPointer r0
    //     0x8eaf08: add             x0, x0, HEAP, lsl #32
    // 0x8eaf0c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8eaf10: cmp             w0, w16
    // 0x8eaf14: b.eq            #0x8eaf6c
    // 0x8eaf18: r1 = LoadClassIdInstr(r0)
    //     0x8eaf18: ldur            x1, [x0, #-1]
    //     0x8eaf1c: ubfx            x1, x1, #0xc, #0x14
    // 0x8eaf20: mov             x16, x0
    // 0x8eaf24: mov             x0, x1
    // 0x8eaf28: mov             x1, x16
    // 0x8eaf2c: r2 = "content-type"
    //     0x8eaf2c: add             x2, PP, #8, lsl #12  ; [pp+0x85d8] "content-type"
    //     0x8eaf30: ldr             x2, [x2, #0x5d8]
    // 0x8eaf34: r0 = GDT[cid_x0 + 0x129dd]()
    //     0x8eaf34: mov             x17, #0x29dd
    //     0x8eaf38: movk            x17, #1, lsl #16
    //     0x8eaf3c: add             lr, x0, x17
    //     0x8eaf40: ldr             lr, [x21, lr, lsl #3]
    //     0x8eaf44: blr             lr
    // 0x8eaf48: r0 = Null
    //     0x8eaf48: mov             x0, NULL
    // 0x8eaf4c: LeaveFrame
    //     0x8eaf4c: mov             SP, fp
    //     0x8eaf50: ldp             fp, lr, [SP], #0x10
    // 0x8eaf54: ret
    //     0x8eaf54: ret             
    // 0x8eaf58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8eaf58: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8eaf5c: b               #0x8eae78
    // 0x8eaf60: r9 = _headers
    //     0x8eaf60: add             x9, PP, #0x15, lsl #12  ; [pp+0x15da8] Field <_RequestConfig@271184022._headers@271184022>: late (offset: 0xc)
    //     0x8eaf64: ldr             x9, [x9, #0xda8]
    // 0x8eaf68: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8eaf68: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8eaf6c: r9 = _headers
    //     0x8eaf6c: add             x9, PP, #0x15, lsl #12  ; [pp+0x15da8] Field <_RequestConfig@271184022._headers@271184022>: late (offset: 0xc)
    //     0x8eaf70: ldr             x9, [x9, #0xda8]
    // 0x8eaf74: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8eaf74: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  set _ headers=(/* No info */) {
    // ** addr: 0x8eaf78, size: 0xbc
    // 0x8eaf78: EnterFrame
    //     0x8eaf78: stp             fp, lr, [SP, #-0x10]!
    //     0x8eaf7c: mov             fp, SP
    // 0x8eaf80: AllocStack(0x18)
    //     0x8eaf80: sub             SP, SP, #0x18
    // 0x8eaf84: SetupParameters(_RequestConfig this /* r1 => r1, fp-0x8 */)
    //     0x8eaf84: stur            x1, [fp, #-8]
    // 0x8eaf88: CheckStackOverflow
    //     0x8eaf88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8eaf8c: cmp             SP, x16
    //     0x8eaf90: b.ls            #0x8eb02c
    // 0x8eaf94: stp             x2, NULL, [SP]
    // 0x8eaf98: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8eaf98: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8eaf9c: r0 = caseInsensitiveKeyMap()
    //     0x8eaf9c: bl              #0x8eb034  ; [package:dio/src/utils.dart] ::caseInsensitiveKeyMap
    // 0x8eafa0: mov             x1, x0
    // 0x8eafa4: ldur            x3, [fp, #-8]
    // 0x8eafa8: StoreField: r3->field_b = r0
    //     0x8eafa8: stur            w0, [x3, #0xb]
    //     0x8eafac: ldurb           w16, [x3, #-1]
    //     0x8eafb0: ldurb           w17, [x0, #-1]
    //     0x8eafb4: and             x16, x17, x16, lsr #2
    //     0x8eafb8: tst             x16, HEAP, lsr #32
    //     0x8eafbc: b.eq            #0x8eafc4
    //     0x8eafc0: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x8eafc4: r0 = LoadClassIdInstr(r1)
    //     0x8eafc4: ldur            x0, [x1, #-1]
    //     0x8eafc8: ubfx            x0, x0, #0xc, #0x14
    // 0x8eafcc: r2 = "content-type"
    //     0x8eafcc: add             x2, PP, #8, lsl #12  ; [pp+0x85d8] "content-type"
    //     0x8eafd0: ldr             x2, [x2, #0x5d8]
    // 0x8eafd4: r0 = GDT[cid_x0 + -0x104]()
    //     0x8eafd4: sub             lr, x0, #0x104
    //     0x8eafd8: ldr             lr, [x21, lr, lsl #3]
    //     0x8eafdc: blr             lr
    // 0x8eafe0: tbz             w0, #4, #0x8eb01c
    // 0x8eafe4: ldur            x0, [fp, #-8]
    // 0x8eafe8: LoadField: r3 = r0->field_1f
    //     0x8eafe8: ldur            w3, [x0, #0x1f]
    // 0x8eafec: DecompressPointer r3
    //     0x8eafec: add             x3, x3, HEAP, lsl #32
    // 0x8eaff0: cmp             w3, NULL
    // 0x8eaff4: b.eq            #0x8eb01c
    // 0x8eaff8: LoadField: r1 = r0->field_b
    //     0x8eaff8: ldur            w1, [x0, #0xb]
    // 0x8eaffc: DecompressPointer r1
    //     0x8eaffc: add             x1, x1, HEAP, lsl #32
    // 0x8eb000: r0 = LoadClassIdInstr(r1)
    //     0x8eb000: ldur            x0, [x1, #-1]
    //     0x8eb004: ubfx            x0, x0, #0xc, #0x14
    // 0x8eb008: r2 = "content-type"
    //     0x8eb008: add             x2, PP, #8, lsl #12  ; [pp+0x85d8] "content-type"
    //     0x8eb00c: ldr             x2, [x2, #0x5d8]
    // 0x8eb010: r0 = GDT[cid_x0 + -0xd50]()
    //     0x8eb010: sub             lr, x0, #0xd50
    //     0x8eb014: ldr             lr, [x21, lr, lsl #3]
    //     0x8eb018: blr             lr
    // 0x8eb01c: r0 = Null
    //     0x8eb01c: mov             x0, NULL
    // 0x8eb020: LeaveFrame
    //     0x8eb020: mov             SP, fp
    //     0x8eb024: ldp             fp, lr, [SP], #0x10
    // 0x8eb028: ret
    //     0x8eb028: ret             
    // 0x8eb02c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8eb02c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8eb030: b               #0x8eaf94
  }
  get _ contentType(/* No info */) {
    // ** addr: 0x90f998, size: 0xb4
    // 0x90f998: EnterFrame
    //     0x90f998: stp             fp, lr, [SP, #-0x10]!
    //     0x90f99c: mov             fp, SP
    // 0x90f9a0: AllocStack(0x8)
    //     0x90f9a0: sub             SP, SP, #8
    // 0x90f9a4: CheckStackOverflow
    //     0x90f9a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x90f9a8: cmp             SP, x16
    //     0x90f9ac: b.ls            #0x90fa38
    // 0x90f9b0: LoadField: r0 = r1->field_b
    //     0x90f9b0: ldur            w0, [x1, #0xb]
    // 0x90f9b4: DecompressPointer r0
    //     0x90f9b4: add             x0, x0, HEAP, lsl #32
    // 0x90f9b8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x90f9bc: cmp             w0, w16
    // 0x90f9c0: b.eq            #0x90fa40
    // 0x90f9c4: r1 = LoadClassIdInstr(r0)
    //     0x90f9c4: ldur            x1, [x0, #-1]
    //     0x90f9c8: ubfx            x1, x1, #0xc, #0x14
    // 0x90f9cc: mov             x16, x0
    // 0x90f9d0: mov             x0, x1
    // 0x90f9d4: mov             x1, x16
    // 0x90f9d8: r2 = "content-type"
    //     0x90f9d8: add             x2, PP, #8, lsl #12  ; [pp+0x85d8] "content-type"
    //     0x90f9dc: ldr             x2, [x2, #0x5d8]
    // 0x90f9e0: r0 = GDT[cid_x0 + -0xd48]()
    //     0x90f9e0: sub             lr, x0, #0xd48
    //     0x90f9e4: ldr             lr, [x21, lr, lsl #3]
    //     0x90f9e8: blr             lr
    // 0x90f9ec: mov             x3, x0
    // 0x90f9f0: r2 = Null
    //     0x90f9f0: mov             x2, NULL
    // 0x90f9f4: r1 = Null
    //     0x90f9f4: mov             x1, NULL
    // 0x90f9f8: stur            x3, [fp, #-8]
    // 0x90f9fc: r4 = 60
    //     0x90f9fc: mov             x4, #0x3c
    // 0x90fa00: branchIfSmi(r0, 0x90fa0c)
    //     0x90fa00: tbz             w0, #0, #0x90fa0c
    // 0x90fa04: r4 = LoadClassIdInstr(r0)
    //     0x90fa04: ldur            x4, [x0, #-1]
    //     0x90fa08: ubfx            x4, x4, #0xc, #0x14
    // 0x90fa0c: sub             x4, x4, #0x5e
    // 0x90fa10: cmp             x4, #1
    // 0x90fa14: b.ls            #0x90fa28
    // 0x90fa18: r8 = String?
    //     0x90fa18: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x90fa1c: r3 = Null
    //     0x90fa1c: add             x3, PP, #0x16, lsl #12  ; [pp+0x167a0] Null
    //     0x90fa20: ldr             x3, [x3, #0x7a0]
    // 0x90fa24: r0 = String?()
    //     0x90fa24: bl              #0x7db310  ; IsType_String?_Stub
    // 0x90fa28: ldur            x0, [fp, #-8]
    // 0x90fa2c: LeaveFrame
    //     0x90fa2c: mov             SP, fp
    //     0x90fa30: ldp             fp, lr, [SP], #0x10
    // 0x90fa34: ret
    //     0x90fa34: ret             
    // 0x90fa38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x90fa38: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x90fa3c: b               #0x90f9b0
    // 0x90fa40: r9 = _headers
    //     0x90fa40: add             x9, PP, #0x15, lsl #12  ; [pp+0x15da8] Field <_RequestConfig@271184022._headers@271184022>: late (offset: 0xc)
    //     0x90fa44: ldr             x9, [x9, #0xda8]
    // 0x90fa48: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x90fa48: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  set _ receiveTimeout=(/* No info */) {
    // ** addr: 0x9129a4, size: 0x60
    // 0x9129a4: EnterFrame
    //     0x9129a4: stp             fp, lr, [SP, #-0x10]!
    //     0x9129a8: mov             fp, SP
    // 0x9129ac: mov             x0, x2
    // 0x9129b0: LoadField: r2 = r0->field_7
    //     0x9129b0: ldur            x2, [x0, #7]
    // 0x9129b4: tbnz            x2, #0x3f, #0x9129e4
    // 0x9129b8: ArrayStore: r1[0] = r0  ; List_4
    //     0x9129b8: stur            w0, [x1, #0x17]
    //     0x9129bc: ldurb           w16, [x1, #-1]
    //     0x9129c0: ldurb           w17, [x0, #-1]
    //     0x9129c4: and             x16, x17, x16, lsr #2
    //     0x9129c8: tst             x16, HEAP, lsr #32
    //     0x9129cc: b.eq            #0x9129d4
    //     0x9129d0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x9129d4: r0 = Null
    //     0x9129d4: mov             x0, NULL
    // 0x9129d8: LeaveFrame
    //     0x9129d8: mov             SP, fp
    //     0x9129dc: ldp             fp, lr, [SP], #0x10
    // 0x9129e0: ret
    //     0x9129e0: ret             
    // 0x9129e4: r0 = StateError()
    //     0x9129e4: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x9129e8: mov             x1, x0
    // 0x9129ec: r0 = "receiveTimeout should be positive"
    //     0x9129ec: add             x0, PP, #0x16, lsl #12  ; [pp+0x169f8] "receiveTimeout should be positive"
    //     0x9129f0: ldr             x0, [x0, #0x9f8]
    // 0x9129f4: StoreField: r1->field_b = r0
    //     0x9129f4: stur            w0, [x1, #0xb]
    // 0x9129f8: mov             x0, x1
    // 0x9129fc: r0 = Throw()
    //     0x9129fc: bl              #0x13ddb2c  ; ThrowStub
    // 0x912a00: brk             #0
  }
}

// class id: 4262, size: 0x70, field offset: 0x58
class RequestOptions extends _MixinApplication368&_RequestConfig&OptionsMixin {

  _ RequestOptions(/* No info */) {
    // ** addr: 0x8ea020, size: 0x8cc
    // 0x8ea020: EnterFrame
    //     0x8ea020: stp             fp, lr, [SP, #-0x10]!
    //     0x8ea024: mov             fp, SP
    // 0x8ea028: AllocStack(0x90)
    //     0x8ea028: sub             SP, SP, #0x90
    // 0x8ea02c: SetupParameters(RequestOptions this /* r1 => r8, fp-0x48 */, {dynamic baseUrl = Null /* fp-0x8 */, dynamic connectTimeout = Null /* fp-0x10 */, dynamic contentType = Null /* fp-0x20 */, dynamic data = Null /* r3 */, dynamic extra = Null /* fp-0x28 */, dynamic followRedirects = Null /* fp-0x30 */, dynamic headers = Null /* fp-0x38 */, dynamic listFormat = Null /* r11 */, dynamic maxRedirects = Null /* r12 */, dynamic method = Null /* r13 */, dynamic onReceiveProgress = Null /* r14 */, dynamic path = "" /* r19 */, dynamic persistentConnection = Null /* r20 */, dynamic preserveHeaderCase = Null /* r9 */, dynamic queryParameters = Null /* fp-0x18 */, dynamic receiveDataWhenStatusError = Null /* r10 */, dynamic receiveTimeout = Null /* r2 */, dynamic responseType = Null /* r5 */, dynamic sendTimeout = Null /* r6 */, dynamic sourceStackTrace = Null /* r23, fp-0x40 */, dynamic validateStatus = Null /* r1 */})
    //     0x8ea02c: mov             x8, x1
    //     0x8ea030: stur            x1, [fp, #-0x48]
    //     0x8ea034: ldur            w0, [x4, #0x13]
    //     0x8ea038: ldur            w1, [x4, #0x1f]
    //     0x8ea03c: add             x1, x1, HEAP, lsl #32
    //     0x8ea040: add             x16, PP, #0x15, lsl #12  ; [pp+0x15d00] "baseUrl"
    //     0x8ea044: ldr             x16, [x16, #0xd00]
    //     0x8ea048: cmp             w1, w16
    //     0x8ea04c: b.ne            #0x8ea070
    //     0x8ea050: ldur            w1, [x4, #0x23]
    //     0x8ea054: add             x1, x1, HEAP, lsl #32
    //     0x8ea058: sub             w2, w0, w1
    //     0x8ea05c: add             x1, fp, w2, sxtw #2
    //     0x8ea060: ldr             x1, [x1, #8]
    //     0x8ea064: mov             x9, x1
    //     0x8ea068: mov             x1, #1
    //     0x8ea06c: b               #0x8ea078
    //     0x8ea070: mov             x9, NULL
    //     0x8ea074: mov             x1, #0
    //     0x8ea078: stur            x9, [fp, #-8]
    //     0x8ea07c: lsl             x2, x1, #1
    //     0x8ea080: lsl             w3, w2, #1
    //     0x8ea084: add             w5, w3, #8
    //     0x8ea088: add             x16, x4, w5, sxtw #1
    //     0x8ea08c: ldur            w6, [x16, #0xf]
    //     0x8ea090: add             x6, x6, HEAP, lsl #32
    //     0x8ea094: add             x16, PP, #0x15, lsl #12  ; [pp+0x15d08] "connectTimeout"
    //     0x8ea098: ldr             x16, [x16, #0xd08]
    //     0x8ea09c: cmp             w6, w16
    //     0x8ea0a0: b.ne            #0x8ea0d4
    //     0x8ea0a4: add             w1, w3, #0xa
    //     0x8ea0a8: add             x16, x4, w1, sxtw #1
    //     0x8ea0ac: ldur            w3, [x16, #0xf]
    //     0x8ea0b0: add             x3, x3, HEAP, lsl #32
    //     0x8ea0b4: sub             w1, w0, w3
    //     0x8ea0b8: add             x3, fp, w1, sxtw #2
    //     0x8ea0bc: ldr             x3, [x3, #8]
    //     0x8ea0c0: add             w1, w2, #2
    //     0x8ea0c4: sbfx            x2, x1, #1, #0x1f
    //     0x8ea0c8: mov             x10, x3
    //     0x8ea0cc: mov             x1, x2
    //     0x8ea0d0: b               #0x8ea0d8
    //     0x8ea0d4: mov             x10, NULL
    //     0x8ea0d8: stur            x10, [fp, #-0x10]
    //     0x8ea0dc: lsl             x2, x1, #1
    //     0x8ea0e0: lsl             w3, w2, #1
    //     0x8ea0e4: add             w5, w3, #8
    //     0x8ea0e8: add             x16, x4, w5, sxtw #1
    //     0x8ea0ec: ldur            w6, [x16, #0xf]
    //     0x8ea0f0: add             x6, x6, HEAP, lsl #32
    //     0x8ea0f4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15d10] "contentType"
    //     0x8ea0f8: ldr             x16, [x16, #0xd10]
    //     0x8ea0fc: cmp             w6, w16
    //     0x8ea100: b.ne            #0x8ea134
    //     0x8ea104: add             w1, w3, #0xa
    //     0x8ea108: add             x16, x4, w1, sxtw #1
    //     0x8ea10c: ldur            w3, [x16, #0xf]
    //     0x8ea110: add             x3, x3, HEAP, lsl #32
    //     0x8ea114: sub             w1, w0, w3
    //     0x8ea118: add             x3, fp, w1, sxtw #2
    //     0x8ea11c: ldr             x3, [x3, #8]
    //     0x8ea120: add             w1, w2, #2
    //     0x8ea124: sbfx            x2, x1, #1, #0x1f
    //     0x8ea128: mov             x1, x2
    //     0x8ea12c: mov             x2, x3
    //     0x8ea130: b               #0x8ea138
    //     0x8ea134: mov             x2, NULL
    //     0x8ea138: stur            x2, [fp, #-0x20]
    //     0x8ea13c: lsl             x3, x1, #1
    //     0x8ea140: lsl             w5, w3, #1
    //     0x8ea144: add             w6, w5, #8
    //     0x8ea148: add             x16, x4, w6, sxtw #1
    //     0x8ea14c: ldur            w7, [x16, #0xf]
    //     0x8ea150: add             x7, x7, HEAP, lsl #32
    //     0x8ea154: ldr             x16, [PP, #0x1370]  ; [pp+0x1370] "data"
    //     0x8ea158: cmp             w7, w16
    //     0x8ea15c: b.ne            #0x8ea190
    //     0x8ea160: add             w1, w5, #0xa
    //     0x8ea164: add             x16, x4, w1, sxtw #1
    //     0x8ea168: ldur            w5, [x16, #0xf]
    //     0x8ea16c: add             x5, x5, HEAP, lsl #32
    //     0x8ea170: sub             w1, w0, w5
    //     0x8ea174: add             x5, fp, w1, sxtw #2
    //     0x8ea178: ldr             x5, [x5, #8]
    //     0x8ea17c: add             w1, w3, #2
    //     0x8ea180: sbfx            x3, x1, #1, #0x1f
    //     0x8ea184: mov             x1, x3
    //     0x8ea188: mov             x3, x5
    //     0x8ea18c: b               #0x8ea194
    //     0x8ea190: mov             x3, NULL
    //     0x8ea194: lsl             x5, x1, #1
    //     0x8ea198: lsl             w6, w5, #1
    //     0x8ea19c: add             w7, w6, #8
    //     0x8ea1a0: add             x16, x4, w7, sxtw #1
    //     0x8ea1a4: ldur            w11, [x16, #0xf]
    //     0x8ea1a8: add             x11, x11, HEAP, lsl #32
    //     0x8ea1ac: add             x16, PP, #0x15, lsl #12  ; [pp+0x15d18] "extra"
    //     0x8ea1b0: ldr             x16, [x16, #0xd18]
    //     0x8ea1b4: cmp             w11, w16
    //     0x8ea1b8: b.ne            #0x8ea1ec
    //     0x8ea1bc: add             w1, w6, #0xa
    //     0x8ea1c0: add             x16, x4, w1, sxtw #1
    //     0x8ea1c4: ldur            w6, [x16, #0xf]
    //     0x8ea1c8: add             x6, x6, HEAP, lsl #32
    //     0x8ea1cc: sub             w1, w0, w6
    //     0x8ea1d0: add             x6, fp, w1, sxtw #2
    //     0x8ea1d4: ldr             x6, [x6, #8]
    //     0x8ea1d8: add             w1, w5, #2
    //     0x8ea1dc: sbfx            x5, x1, #1, #0x1f
    //     0x8ea1e0: mov             x1, x5
    //     0x8ea1e4: mov             x5, x6
    //     0x8ea1e8: b               #0x8ea1f0
    //     0x8ea1ec: mov             x5, NULL
    //     0x8ea1f0: stur            x5, [fp, #-0x28]
    //     0x8ea1f4: lsl             x6, x1, #1
    //     0x8ea1f8: lsl             w7, w6, #1
    //     0x8ea1fc: add             w11, w7, #8
    //     0x8ea200: add             x16, x4, w11, sxtw #1
    //     0x8ea204: ldur            w12, [x16, #0xf]
    //     0x8ea208: add             x12, x12, HEAP, lsl #32
    //     0x8ea20c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15d20] "followRedirects"
    //     0x8ea210: ldr             x16, [x16, #0xd20]
    //     0x8ea214: cmp             w12, w16
    //     0x8ea218: b.ne            #0x8ea24c
    //     0x8ea21c: add             w1, w7, #0xa
    //     0x8ea220: add             x16, x4, w1, sxtw #1
    //     0x8ea224: ldur            w7, [x16, #0xf]
    //     0x8ea228: add             x7, x7, HEAP, lsl #32
    //     0x8ea22c: sub             w1, w0, w7
    //     0x8ea230: add             x7, fp, w1, sxtw #2
    //     0x8ea234: ldr             x7, [x7, #8]
    //     0x8ea238: add             w1, w6, #2
    //     0x8ea23c: sbfx            x6, x1, #1, #0x1f
    //     0x8ea240: mov             x1, x6
    //     0x8ea244: mov             x6, x7
    //     0x8ea248: b               #0x8ea250
    //     0x8ea24c: mov             x6, NULL
    //     0x8ea250: stur            x6, [fp, #-0x30]
    //     0x8ea254: lsl             x7, x1, #1
    //     0x8ea258: lsl             w11, w7, #1
    //     0x8ea25c: add             w12, w11, #8
    //     0x8ea260: add             x16, x4, w12, sxtw #1
    //     0x8ea264: ldur            w13, [x16, #0xf]
    //     0x8ea268: add             x13, x13, HEAP, lsl #32
    //     0x8ea26c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15d28] "headers"
    //     0x8ea270: ldr             x16, [x16, #0xd28]
    //     0x8ea274: cmp             w13, w16
    //     0x8ea278: b.ne            #0x8ea2ac
    //     0x8ea27c: add             w1, w11, #0xa
    //     0x8ea280: add             x16, x4, w1, sxtw #1
    //     0x8ea284: ldur            w11, [x16, #0xf]
    //     0x8ea288: add             x11, x11, HEAP, lsl #32
    //     0x8ea28c: sub             w1, w0, w11
    //     0x8ea290: add             x11, fp, w1, sxtw #2
    //     0x8ea294: ldr             x11, [x11, #8]
    //     0x8ea298: add             w1, w7, #2
    //     0x8ea29c: sbfx            x7, x1, #1, #0x1f
    //     0x8ea2a0: mov             x1, x7
    //     0x8ea2a4: mov             x7, x11
    //     0x8ea2a8: b               #0x8ea2b0
    //     0x8ea2ac: mov             x7, NULL
    //     0x8ea2b0: stur            x7, [fp, #-0x38]
    //     0x8ea2b4: lsl             x11, x1, #1
    //     0x8ea2b8: lsl             w12, w11, #1
    //     0x8ea2bc: add             w13, w12, #8
    //     0x8ea2c0: add             x16, x4, w13, sxtw #1
    //     0x8ea2c4: ldur            w14, [x16, #0xf]
    //     0x8ea2c8: add             x14, x14, HEAP, lsl #32
    //     0x8ea2cc: add             x16, PP, #0x15, lsl #12  ; [pp+0x15d30] "listFormat"
    //     0x8ea2d0: ldr             x16, [x16, #0xd30]
    //     0x8ea2d4: cmp             w14, w16
    //     0x8ea2d8: b.ne            #0x8ea30c
    //     0x8ea2dc: add             w1, w12, #0xa
    //     0x8ea2e0: add             x16, x4, w1, sxtw #1
    //     0x8ea2e4: ldur            w12, [x16, #0xf]
    //     0x8ea2e8: add             x12, x12, HEAP, lsl #32
    //     0x8ea2ec: sub             w1, w0, w12
    //     0x8ea2f0: add             x12, fp, w1, sxtw #2
    //     0x8ea2f4: ldr             x12, [x12, #8]
    //     0x8ea2f8: add             w1, w11, #2
    //     0x8ea2fc: sbfx            x11, x1, #1, #0x1f
    //     0x8ea300: mov             x1, x11
    //     0x8ea304: mov             x11, x12
    //     0x8ea308: b               #0x8ea310
    //     0x8ea30c: mov             x11, NULL
    //     0x8ea310: lsl             x12, x1, #1
    //     0x8ea314: lsl             w13, w12, #1
    //     0x8ea318: add             w14, w13, #8
    //     0x8ea31c: add             x16, x4, w14, sxtw #1
    //     0x8ea320: ldur            w19, [x16, #0xf]
    //     0x8ea324: add             x19, x19, HEAP, lsl #32
    //     0x8ea328: add             x16, PP, #0x15, lsl #12  ; [pp+0x15d38] "maxRedirects"
    //     0x8ea32c: ldr             x16, [x16, #0xd38]
    //     0x8ea330: cmp             w19, w16
    //     0x8ea334: b.ne            #0x8ea368
    //     0x8ea338: add             w1, w13, #0xa
    //     0x8ea33c: add             x16, x4, w1, sxtw #1
    //     0x8ea340: ldur            w13, [x16, #0xf]
    //     0x8ea344: add             x13, x13, HEAP, lsl #32
    //     0x8ea348: sub             w1, w0, w13
    //     0x8ea34c: add             x13, fp, w1, sxtw #2
    //     0x8ea350: ldr             x13, [x13, #8]
    //     0x8ea354: add             w1, w12, #2
    //     0x8ea358: sbfx            x12, x1, #1, #0x1f
    //     0x8ea35c: mov             x1, x12
    //     0x8ea360: mov             x12, x13
    //     0x8ea364: b               #0x8ea36c
    //     0x8ea368: mov             x12, NULL
    //     0x8ea36c: lsl             x13, x1, #1
    //     0x8ea370: lsl             w14, w13, #1
    //     0x8ea374: add             w19, w14, #8
    //     0x8ea378: add             x16, x4, w19, sxtw #1
    //     0x8ea37c: ldur            w20, [x16, #0xf]
    //     0x8ea380: add             x20, x20, HEAP, lsl #32
    //     0x8ea384: ldr             x16, [PP, #0x7c80]  ; [pp+0x7c80] "method"
    //     0x8ea388: cmp             w20, w16
    //     0x8ea38c: b.ne            #0x8ea3c0
    //     0x8ea390: add             w1, w14, #0xa
    //     0x8ea394: add             x16, x4, w1, sxtw #1
    //     0x8ea398: ldur            w14, [x16, #0xf]
    //     0x8ea39c: add             x14, x14, HEAP, lsl #32
    //     0x8ea3a0: sub             w1, w0, w14
    //     0x8ea3a4: add             x14, fp, w1, sxtw #2
    //     0x8ea3a8: ldr             x14, [x14, #8]
    //     0x8ea3ac: add             w1, w13, #2
    //     0x8ea3b0: sbfx            x13, x1, #1, #0x1f
    //     0x8ea3b4: mov             x1, x13
    //     0x8ea3b8: mov             x13, x14
    //     0x8ea3bc: b               #0x8ea3c4
    //     0x8ea3c0: mov             x13, NULL
    //     0x8ea3c4: lsl             x14, x1, #1
    //     0x8ea3c8: lsl             w19, w14, #1
    //     0x8ea3cc: add             w20, w19, #8
    //     0x8ea3d0: add             x16, x4, w20, sxtw #1
    //     0x8ea3d4: ldur            w23, [x16, #0xf]
    //     0x8ea3d8: add             x23, x23, HEAP, lsl #32
    //     0x8ea3dc: add             x16, PP, #0x15, lsl #12  ; [pp+0x15d40] "onReceiveProgress"
    //     0x8ea3e0: ldr             x16, [x16, #0xd40]
    //     0x8ea3e4: cmp             w23, w16
    //     0x8ea3e8: b.ne            #0x8ea41c
    //     0x8ea3ec: add             w1, w19, #0xa
    //     0x8ea3f0: add             x16, x4, w1, sxtw #1
    //     0x8ea3f4: ldur            w19, [x16, #0xf]
    //     0x8ea3f8: add             x19, x19, HEAP, lsl #32
    //     0x8ea3fc: sub             w1, w0, w19
    //     0x8ea400: add             x19, fp, w1, sxtw #2
    //     0x8ea404: ldr             x19, [x19, #8]
    //     0x8ea408: add             w1, w14, #2
    //     0x8ea40c: sbfx            x14, x1, #1, #0x1f
    //     0x8ea410: mov             x1, x14
    //     0x8ea414: mov             x14, x19
    //     0x8ea418: b               #0x8ea420
    //     0x8ea41c: mov             x14, NULL
    //     0x8ea420: lsl             x19, x1, #1
    //     0x8ea424: lsl             w20, w19, #1
    //     0x8ea428: add             w23, w20, #8
    //     0x8ea42c: add             x16, x4, w23, sxtw #1
    //     0x8ea430: ldur            w24, [x16, #0xf]
    //     0x8ea434: add             x24, x24, HEAP, lsl #32
    //     0x8ea438: ldr             x16, [PP, #0x39c0]  ; [pp+0x39c0] "path"
    //     0x8ea43c: cmp             w24, w16
    //     0x8ea440: b.ne            #0x8ea474
    //     0x8ea444: add             w1, w20, #0xa
    //     0x8ea448: add             x16, x4, w1, sxtw #1
    //     0x8ea44c: ldur            w20, [x16, #0xf]
    //     0x8ea450: add             x20, x20, HEAP, lsl #32
    //     0x8ea454: sub             w1, w0, w20
    //     0x8ea458: add             x20, fp, w1, sxtw #2
    //     0x8ea45c: ldr             x20, [x20, #8]
    //     0x8ea460: add             w1, w19, #2
    //     0x8ea464: sbfx            x19, x1, #1, #0x1f
    //     0x8ea468: mov             x1, x19
    //     0x8ea46c: mov             x19, x20
    //     0x8ea470: b               #0x8ea478
    //     0x8ea474: ldr             x19, [PP, #0x900]  ; [pp+0x900] ""
    //     0x8ea478: lsl             x20, x1, #1
    //     0x8ea47c: lsl             w23, w20, #1
    //     0x8ea480: add             w24, w23, #8
    //     0x8ea484: add             x16, x4, w24, sxtw #1
    //     0x8ea488: ldur            w25, [x16, #0xf]
    //     0x8ea48c: add             x25, x25, HEAP, lsl #32
    //     0x8ea490: add             x16, PP, #8, lsl #12  ; [pp+0x8520] "persistentConnection"
    //     0x8ea494: ldr             x16, [x16, #0x520]
    //     0x8ea498: cmp             w25, w16
    //     0x8ea49c: b.ne            #0x8ea4d0
    //     0x8ea4a0: add             w1, w23, #0xa
    //     0x8ea4a4: add             x16, x4, w1, sxtw #1
    //     0x8ea4a8: ldur            w23, [x16, #0xf]
    //     0x8ea4ac: add             x23, x23, HEAP, lsl #32
    //     0x8ea4b0: sub             w1, w0, w23
    //     0x8ea4b4: add             x23, fp, w1, sxtw #2
    //     0x8ea4b8: ldr             x23, [x23, #8]
    //     0x8ea4bc: add             w1, w20, #2
    //     0x8ea4c0: sbfx            x20, x1, #1, #0x1f
    //     0x8ea4c4: mov             x1, x20
    //     0x8ea4c8: mov             x20, x23
    //     0x8ea4cc: b               #0x8ea4d4
    //     0x8ea4d0: mov             x20, NULL
    //     0x8ea4d4: lsl             x23, x1, #1
    //     0x8ea4d8: lsl             w24, w23, #1
    //     0x8ea4dc: add             w25, w24, #8
    //     0x8ea4e0: add             x16, x4, w25, sxtw #1
    //     0x8ea4e4: ldur            w9, [x16, #0xf]
    //     0x8ea4e8: add             x9, x9, HEAP, lsl #32
    //     0x8ea4ec: add             x16, PP, #0xb, lsl #12  ; [pp+0xbb80] "preserveHeaderCase"
    //     0x8ea4f0: ldr             x16, [x16, #0xb80]
    //     0x8ea4f4: cmp             w9, w16
    //     0x8ea4f8: b.ne            #0x8ea528
    //     0x8ea4fc: add             w1, w24, #0xa
    //     0x8ea500: add             x16, x4, w1, sxtw #1
    //     0x8ea504: ldur            w9, [x16, #0xf]
    //     0x8ea508: add             x9, x9, HEAP, lsl #32
    //     0x8ea50c: sub             w1, w0, w9
    //     0x8ea510: add             x9, fp, w1, sxtw #2
    //     0x8ea514: ldr             x9, [x9, #8]
    //     0x8ea518: add             w1, w23, #2
    //     0x8ea51c: sbfx            x23, x1, #1, #0x1f
    //     0x8ea520: mov             x1, x23
    //     0x8ea524: b               #0x8ea52c
    //     0x8ea528: mov             x9, NULL
    //     0x8ea52c: lsl             x23, x1, #1
    //     0x8ea530: lsl             w24, w23, #1
    //     0x8ea534: add             w25, w24, #8
    //     0x8ea538: add             x16, x4, w25, sxtw #1
    //     0x8ea53c: ldur            w10, [x16, #0xf]
    //     0x8ea540: add             x10, x10, HEAP, lsl #32
    //     0x8ea544: ldr             x16, [PP, #0x39e0]  ; [pp+0x39e0] "queryParameters"
    //     0x8ea548: cmp             w10, w16
    //     0x8ea54c: b.ne            #0x8ea57c
    //     0x8ea550: add             w1, w24, #0xa
    //     0x8ea554: add             x16, x4, w1, sxtw #1
    //     0x8ea558: ldur            w10, [x16, #0xf]
    //     0x8ea55c: add             x10, x10, HEAP, lsl #32
    //     0x8ea560: sub             w1, w0, w10
    //     0x8ea564: add             x10, fp, w1, sxtw #2
    //     0x8ea568: ldr             x10, [x10, #8]
    //     0x8ea56c: add             w1, w23, #2
    //     0x8ea570: sbfx            x23, x1, #1, #0x1f
    //     0x8ea574: mov             x1, x23
    //     0x8ea578: b               #0x8ea580
    //     0x8ea57c: mov             x10, NULL
    //     0x8ea580: stur            x10, [fp, #-0x18]
    //     0x8ea584: lsl             x23, x1, #1
    //     0x8ea588: lsl             w24, w23, #1
    //     0x8ea58c: add             w25, w24, #8
    //     0x8ea590: add             x16, x4, w25, sxtw #1
    //     0x8ea594: ldur            w10, [x16, #0xf]
    //     0x8ea598: add             x10, x10, HEAP, lsl #32
    //     0x8ea59c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15d48] "receiveDataWhenStatusError"
    //     0x8ea5a0: ldr             x16, [x16, #0xd48]
    //     0x8ea5a4: cmp             w10, w16
    //     0x8ea5a8: b.ne            #0x8ea5d8
    //     0x8ea5ac: add             w1, w24, #0xa
    //     0x8ea5b0: add             x16, x4, w1, sxtw #1
    //     0x8ea5b4: ldur            w10, [x16, #0xf]
    //     0x8ea5b8: add             x10, x10, HEAP, lsl #32
    //     0x8ea5bc: sub             w1, w0, w10
    //     0x8ea5c0: add             x10, fp, w1, sxtw #2
    //     0x8ea5c4: ldr             x10, [x10, #8]
    //     0x8ea5c8: add             w1, w23, #2
    //     0x8ea5cc: sbfx            x23, x1, #1, #0x1f
    //     0x8ea5d0: mov             x1, x23
    //     0x8ea5d4: b               #0x8ea5dc
    //     0x8ea5d8: mov             x10, NULL
    //     0x8ea5dc: lsl             x23, x1, #1
    //     0x8ea5e0: lsl             w24, w23, #1
    //     0x8ea5e4: add             w25, w24, #8
    //     0x8ea5e8: add             x16, x4, w25, sxtw #1
    //     0x8ea5ec: ldur            w2, [x16, #0xf]
    //     0x8ea5f0: add             x2, x2, HEAP, lsl #32
    //     0x8ea5f4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15d50] "receiveTimeout"
    //     0x8ea5f8: ldr             x16, [x16, #0xd50]
    //     0x8ea5fc: cmp             w2, w16
    //     0x8ea600: b.ne            #0x8ea630
    //     0x8ea604: add             w1, w24, #0xa
    //     0x8ea608: add             x16, x4, w1, sxtw #1
    //     0x8ea60c: ldur            w2, [x16, #0xf]
    //     0x8ea610: add             x2, x2, HEAP, lsl #32
    //     0x8ea614: sub             w1, w0, w2
    //     0x8ea618: add             x2, fp, w1, sxtw #2
    //     0x8ea61c: ldr             x2, [x2, #8]
    //     0x8ea620: add             w1, w23, #2
    //     0x8ea624: sbfx            x23, x1, #1, #0x1f
    //     0x8ea628: mov             x1, x23
    //     0x8ea62c: b               #0x8ea634
    //     0x8ea630: mov             x2, NULL
    //     0x8ea634: lsl             x23, x1, #1
    //     0x8ea638: lsl             w24, w23, #1
    //     0x8ea63c: add             w25, w24, #8
    //     0x8ea640: add             x16, x4, w25, sxtw #1
    //     0x8ea644: ldur            w5, [x16, #0xf]
    //     0x8ea648: add             x5, x5, HEAP, lsl #32
    //     0x8ea64c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15d58] "responseType"
    //     0x8ea650: ldr             x16, [x16, #0xd58]
    //     0x8ea654: cmp             w5, w16
    //     0x8ea658: b.ne            #0x8ea688
    //     0x8ea65c: add             w1, w24, #0xa
    //     0x8ea660: add             x16, x4, w1, sxtw #1
    //     0x8ea664: ldur            w5, [x16, #0xf]
    //     0x8ea668: add             x5, x5, HEAP, lsl #32
    //     0x8ea66c: sub             w1, w0, w5
    //     0x8ea670: add             x5, fp, w1, sxtw #2
    //     0x8ea674: ldr             x5, [x5, #8]
    //     0x8ea678: add             w1, w23, #2
    //     0x8ea67c: sbfx            x23, x1, #1, #0x1f
    //     0x8ea680: mov             x1, x23
    //     0x8ea684: b               #0x8ea68c
    //     0x8ea688: mov             x5, NULL
    //     0x8ea68c: lsl             x23, x1, #1
    //     0x8ea690: lsl             w24, w23, #1
    //     0x8ea694: add             w25, w24, #8
    //     0x8ea698: add             x16, x4, w25, sxtw #1
    //     0x8ea69c: ldur            w6, [x16, #0xf]
    //     0x8ea6a0: add             x6, x6, HEAP, lsl #32
    //     0x8ea6a4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15d60] "sendTimeout"
    //     0x8ea6a8: ldr             x16, [x16, #0xd60]
    //     0x8ea6ac: cmp             w6, w16
    //     0x8ea6b0: b.ne            #0x8ea6e0
    //     0x8ea6b4: add             w1, w24, #0xa
    //     0x8ea6b8: add             x16, x4, w1, sxtw #1
    //     0x8ea6bc: ldur            w6, [x16, #0xf]
    //     0x8ea6c0: add             x6, x6, HEAP, lsl #32
    //     0x8ea6c4: sub             w1, w0, w6
    //     0x8ea6c8: add             x6, fp, w1, sxtw #2
    //     0x8ea6cc: ldr             x6, [x6, #8]
    //     0x8ea6d0: add             w1, w23, #2
    //     0x8ea6d4: sbfx            x23, x1, #1, #0x1f
    //     0x8ea6d8: mov             x1, x23
    //     0x8ea6dc: b               #0x8ea6e4
    //     0x8ea6e0: mov             x6, NULL
    //     0x8ea6e4: lsl             x23, x1, #1
    //     0x8ea6e8: lsl             w24, w23, #1
    //     0x8ea6ec: add             w25, w24, #8
    //     0x8ea6f0: add             x16, x4, w25, sxtw #1
    //     0x8ea6f4: ldur            w7, [x16, #0xf]
    //     0x8ea6f8: add             x7, x7, HEAP, lsl #32
    //     0x8ea6fc: add             x16, PP, #0x15, lsl #12  ; [pp+0x15d68] "sourceStackTrace"
    //     0x8ea700: ldr             x16, [x16, #0xd68]
    //     0x8ea704: cmp             w7, w16
    //     0x8ea708: b.ne            #0x8ea73c
    //     0x8ea70c: add             w1, w24, #0xa
    //     0x8ea710: add             x16, x4, w1, sxtw #1
    //     0x8ea714: ldur            w7, [x16, #0xf]
    //     0x8ea718: add             x7, x7, HEAP, lsl #32
    //     0x8ea71c: sub             w1, w0, w7
    //     0x8ea720: add             x7, fp, w1, sxtw #2
    //     0x8ea724: ldr             x7, [x7, #8]
    //     0x8ea728: add             w1, w23, #2
    //     0x8ea72c: sbfx            x23, x1, #1, #0x1f
    //     0x8ea730: mov             x1, x23
    //     0x8ea734: mov             x23, x7
    //     0x8ea738: b               #0x8ea740
    //     0x8ea73c: mov             x23, NULL
    //     0x8ea740: stur            x23, [fp, #-0x40]
    //     0x8ea744: lsl             x7, x1, #1
    //     0x8ea748: lsl             w1, w7, #1
    //     0x8ea74c: add             w7, w1, #8
    //     0x8ea750: add             x16, x4, w7, sxtw #1
    //     0x8ea754: ldur            w24, [x16, #0xf]
    //     0x8ea758: add             x24, x24, HEAP, lsl #32
    //     0x8ea75c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15d70] "validateStatus"
    //     0x8ea760: ldr             x16, [x16, #0xd70]
    //     0x8ea764: cmp             w24, w16
    //     0x8ea768: b.ne            #0x8ea790
    //     0x8ea76c: add             w7, w1, #0xa
    //     0x8ea770: add             x16, x4, w7, sxtw #1
    //     0x8ea774: ldur            w1, [x16, #0xf]
    //     0x8ea778: add             x1, x1, HEAP, lsl #32
    //     0x8ea77c: sub             w4, w0, w1
    //     0x8ea780: add             x0, fp, w4, sxtw #2
    //     0x8ea784: ldr             x0, [x0, #8]
    //     0x8ea788: mov             x1, x0
    //     0x8ea78c: b               #0x8ea794
    //     0x8ea790: mov             x1, NULL
    // 0x8ea794: CheckStackOverflow
    //     0x8ea794: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ea798: cmp             SP, x16
    //     0x8ea79c: b.ls            #0x8ea8e4
    // 0x8ea7a0: mov             x0, x19
    // 0x8ea7a4: StoreField: r8->field_5f = r0
    //     0x8ea7a4: stur            w0, [x8, #0x5f]
    //     0x8ea7a8: ldurb           w16, [x8, #-1]
    //     0x8ea7ac: ldurb           w17, [x0, #-1]
    //     0x8ea7b0: and             x16, x17, x16, lsr #2
    //     0x8ea7b4: tst             x16, HEAP, lsr #32
    //     0x8ea7b8: b.eq            #0x8ea7c0
    //     0x8ea7bc: bl              #0x13de074  ; WriteBarrierWrappersStub
    // 0x8ea7c0: mov             x0, x3
    // 0x8ea7c4: StoreField: r8->field_5b = r0
    //     0x8ea7c4: stur            w0, [x8, #0x5b]
    //     0x8ea7c8: tbz             w0, #0, #0x8ea7e4
    //     0x8ea7cc: ldurb           w16, [x8, #-1]
    //     0x8ea7d0: ldurb           w17, [x0, #-1]
    //     0x8ea7d4: and             x16, x17, x16, lsr #2
    //     0x8ea7d8: tst             x16, HEAP, lsr #32
    //     0x8ea7dc: b.eq            #0x8ea7e4
    //     0x8ea7e0: bl              #0x13de074  ; WriteBarrierWrappersStub
    // 0x8ea7e4: mov             x0, x14
    // 0x8ea7e8: StoreField: r8->field_67 = r0
    //     0x8ea7e8: stur            w0, [x8, #0x67]
    //     0x8ea7ec: ldurb           w16, [x8, #-1]
    //     0x8ea7f0: ldurb           w17, [x0, #-1]
    //     0x8ea7f4: and             x16, x17, x16, lsr #2
    //     0x8ea7f8: tst             x16, HEAP, lsr #32
    //     0x8ea7fc: b.eq            #0x8ea804
    //     0x8ea800: bl              #0x13de074  ; WriteBarrierWrappersStub
    // 0x8ea804: stp             x13, x12, [SP, #0x38]
    // 0x8ea808: stp             x9, x20, [SP, #0x28]
    // 0x8ea80c: stp             x2, x10, [SP, #0x18]
    // 0x8ea810: stp             x6, x5, [SP, #8]
    // 0x8ea814: str             x1, [SP]
    // 0x8ea818: mov             x1, x8
    // 0x8ea81c: ldur            x2, [fp, #-0x20]
    // 0x8ea820: ldur            x3, [fp, #-0x28]
    // 0x8ea824: ldur            x5, [fp, #-0x30]
    // 0x8ea828: ldur            x6, [fp, #-0x38]
    // 0x8ea82c: mov             x7, x11
    // 0x8ea830: r0 = _MixinApplication368&_RequestConfig&OptionsMixin()
    //     0x8ea830: bl              #0x8eaaa0  ; [dart:mixin_deduplication] _MixinApplication368&_RequestConfig&OptionsMixin::_MixinApplication368&_RequestConfig&OptionsMixin
    // 0x8ea834: ldur            x0, [fp, #-0x40]
    // 0x8ea838: cmp             w0, NULL
    // 0x8ea83c: b.ne            #0x8ea844
    // 0x8ea840: r0 = current()
    //     0x8ea840: bl              #0x7f0e88  ; [dart:core] StackTrace::current
    // 0x8ea844: ldur            x1, [fp, #-0x48]
    // 0x8ea848: ldur            x2, [fp, #-0x18]
    // 0x8ea84c: StoreField: r1->field_57 = r0
    //     0x8ea84c: stur            w0, [x1, #0x57]
    //     0x8ea850: ldurb           w16, [x1, #-1]
    //     0x8ea854: ldurb           w17, [x0, #-1]
    //     0x8ea858: and             x16, x17, x16, lsr #2
    //     0x8ea85c: tst             x16, HEAP, lsr #32
    //     0x8ea860: b.eq            #0x8ea868
    //     0x8ea864: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8ea868: cmp             w2, NULL
    // 0x8ea86c: b.ne            #0x8ea884
    // 0x8ea870: r16 = <String, dynamic>
    //     0x8ea870: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x8ea874: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x8ea878: stp             lr, x16, [SP]
    // 0x8ea87c: r0 = Map._fromLiteral()
    //     0x8ea87c: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x8ea880: b               #0x8ea888
    // 0x8ea884: mov             x0, x2
    // 0x8ea888: ldur            x3, [fp, #-0x48]
    // 0x8ea88c: ldur            x1, [fp, #-8]
    // 0x8ea890: StoreField: r3->field_4f = r0
    //     0x8ea890: stur            w0, [x3, #0x4f]
    //     0x8ea894: ldurb           w16, [x3, #-1]
    //     0x8ea898: ldurb           w17, [x0, #-1]
    //     0x8ea89c: and             x16, x17, x16, lsr #2
    //     0x8ea8a0: tst             x16, HEAP, lsr #32
    //     0x8ea8a4: b.eq            #0x8ea8ac
    //     0x8ea8a8: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x8ea8ac: cmp             w1, NULL
    // 0x8ea8b0: b.ne            #0x8ea8bc
    // 0x8ea8b4: r2 = ""
    //     0x8ea8b4: ldr             x2, [PP, #0x900]  ; [pp+0x900] ""
    // 0x8ea8b8: b               #0x8ea8c0
    // 0x8ea8bc: mov             x2, x1
    // 0x8ea8c0: mov             x1, x3
    // 0x8ea8c4: r0 = baseUrl=()
    //     0x8ea8c4: bl              #0x8ea9c0  ; [dart:mixin_deduplication] _MixinApplication368&_RequestConfig&OptionsMixin::baseUrl=
    // 0x8ea8c8: ldur            x1, [fp, #-0x48]
    // 0x8ea8cc: ldur            x2, [fp, #-0x10]
    // 0x8ea8d0: r0 = connectTimeout=()
    //     0x8ea8d0: bl              #0x8ea958  ; [dart:mixin_deduplication] _MixinApplication368&_RequestConfig&OptionsMixin::connectTimeout=
    // 0x8ea8d4: r0 = Null
    //     0x8ea8d4: mov             x0, NULL
    // 0x8ea8d8: LeaveFrame
    //     0x8ea8d8: mov             SP, fp
    //     0x8ea8dc: ldp             fp, lr, [SP], #0x10
    // 0x8ea8e0: ret
    //     0x8ea8e0: ret             
    // 0x8ea8e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ea8e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ea8e8: b               #0x8ea7a0
  }
  get _ uri(/* No info */) {
    // ** addr: 0x90c6d0, size: 0x290
    // 0x90c6d0: EnterFrame
    //     0x90c6d0: stp             fp, lr, [SP, #-0x10]!
    //     0x90c6d4: mov             fp, SP
    // 0x90c6d8: AllocStack(0x68)
    //     0x90c6d8: sub             SP, SP, #0x68
    // 0x90c6dc: SetupParameters(RequestOptions this /* r1 => r1, fp-0x10 */)
    //     0x90c6dc: stur            x1, [fp, #-0x10]
    // 0x90c6e0: CheckStackOverflow
    //     0x90c6e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x90c6e4: cmp             SP, x16
    //     0x90c6e8: b.ls            #0x90c92c
    // 0x90c6ec: LoadField: r0 = r1->field_5f
    //     0x90c6ec: ldur            w0, [x1, #0x5f]
    // 0x90c6f0: DecompressPointer r0
    //     0x90c6f0: add             x0, x0, HEAP, lsl #32
    // 0x90c6f4: stur            x0, [fp, #-8]
    // 0x90c6f8: r16 = "https\?:"
    //     0x90c6f8: add             x16, PP, #0x16, lsl #12  ; [pp+0x16578] "https\?:"
    //     0x90c6fc: ldr             x16, [x16, #0x578]
    // 0x90c700: stp             x16, NULL, [SP, #0x20]
    // 0x90c704: r16 = false
    //     0x90c704: add             x16, NULL, #0x30  ; false
    // 0x90c708: r30 = true
    //     0x90c708: add             lr, NULL, #0x20  ; true
    // 0x90c70c: stp             lr, x16, [SP, #0x10]
    // 0x90c710: r16 = false
    //     0x90c710: add             x16, NULL, #0x30  ; false
    // 0x90c714: r30 = false
    //     0x90c714: add             lr, NULL, #0x30  ; false
    // 0x90c718: stp             lr, x16, [SP]
    // 0x90c71c: r4 = const [0, 0x6, 0x6, 0x2, caseSensitive, 0x3, dotAll, 0x5, multiLine, 0x2, unicode, 0x4, null]
    //     0x90c71c: ldr             x4, [PP, #0xa48]  ; [pp+0xa48] List(13) [0, 0x6, 0x6, 0x2, "caseSensitive", 0x3, "dotAll", 0x5, "multiLine", 0x2, "unicode", 0x4, Null]
    // 0x90c720: r0 = _RegExp()
    //     0x90c720: bl              #0x7eb40c  ; [dart:core] _RegExp::_RegExp
    // 0x90c724: ldur            x1, [fp, #-8]
    // 0x90c728: mov             x2, x0
    // 0x90c72c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x90c72c: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x90c730: r0 = startsWith()
    //     0x90c730: bl              #0x7ea4f0  ; [dart:core] _StringBase::startsWith
    // 0x90c734: tbz             w0, #4, #0x90c858
    // 0x90c738: ldur            x0, [fp, #-0x10]
    // 0x90c73c: LoadField: r1 = r0->field_4b
    //     0x90c73c: ldur            w1, [x0, #0x4b]
    // 0x90c740: DecompressPointer r1
    //     0x90c740: add             x1, x1, HEAP, lsl #32
    // 0x90c744: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x90c748: cmp             w1, w16
    // 0x90c74c: b.eq            #0x90c934
    // 0x90c750: ldur            x16, [fp, #-8]
    // 0x90c754: stp             x16, x1, [SP]
    // 0x90c758: r0 = +()
    //     0x90c758: bl              #0x7e1e74  ; [dart:core] _StringBase::+
    // 0x90c75c: mov             x3, x0
    // 0x90c760: stur            x3, [fp, #-0x18]
    // 0x90c764: r0 = LoadClassIdInstr(r3)
    //     0x90c764: ldur            x0, [x3, #-1]
    //     0x90c768: ubfx            x0, x0, #0xc, #0x14
    // 0x90c76c: mov             x1, x3
    // 0x90c770: r2 = ":/"
    //     0x90c770: add             x2, PP, #0x16, lsl #12  ; [pp+0x16580] ":/"
    //     0x90c774: ldr             x2, [x2, #0x580]
    // 0x90c778: r0 = GDT[cid_x0 + -0xffe]()
    //     0x90c778: sub             lr, x0, #0xffe
    //     0x90c77c: ldr             lr, [x21, lr, lsl #3]
    //     0x90c780: blr             lr
    // 0x90c784: mov             x2, x0
    // 0x90c788: LoadField: r0 = r2->field_b
    //     0x90c788: ldur            w0, [x2, #0xb]
    // 0x90c78c: r3 = LoadInt32Instr(r0)
    //     0x90c78c: sbfx            x3, x0, #1, #0x1f
    // 0x90c790: stur            x3, [fp, #-0x30]
    // 0x90c794: cmp             x3, #2
    // 0x90c798: b.ne            #0x90c84c
    // 0x90c79c: mov             x0, x3
    // 0x90c7a0: r1 = 0
    //     0x90c7a0: mov             x1, #0
    // 0x90c7a4: cmp             x1, x0
    // 0x90c7a8: b.hs            #0x90c940
    // 0x90c7ac: LoadField: r0 = r2->field_f
    //     0x90c7ac: ldur            w0, [x2, #0xf]
    // 0x90c7b0: DecompressPointer r0
    //     0x90c7b0: add             x0, x0, HEAP, lsl #32
    // 0x90c7b4: stur            x0, [fp, #-0x28]
    // 0x90c7b8: LoadField: r4 = r0->field_f
    //     0x90c7b8: ldur            w4, [x0, #0xf]
    // 0x90c7bc: DecompressPointer r4
    //     0x90c7bc: add             x4, x4, HEAP, lsl #32
    // 0x90c7c0: stur            x4, [fp, #-0x20]
    // 0x90c7c4: r1 = Null
    //     0x90c7c4: mov             x1, NULL
    // 0x90c7c8: r2 = 6
    //     0x90c7c8: mov             x2, #6
    // 0x90c7cc: r0 = AllocateArray()
    //     0x90c7cc: bl              #0x13df928  ; AllocateArrayStub
    // 0x90c7d0: mov             x4, x0
    // 0x90c7d4: ldur            x0, [fp, #-0x20]
    // 0x90c7d8: stur            x4, [fp, #-0x38]
    // 0x90c7dc: StoreField: r4->field_f = r0
    //     0x90c7dc: stur            w0, [x4, #0xf]
    // 0x90c7e0: r16 = ":/"
    //     0x90c7e0: add             x16, PP, #0x16, lsl #12  ; [pp+0x16580] ":/"
    //     0x90c7e4: ldr             x16, [x16, #0x580]
    // 0x90c7e8: StoreField: r4->field_13 = r16
    //     0x90c7e8: stur            w16, [x4, #0x13]
    // 0x90c7ec: ldur            x0, [fp, #-0x30]
    // 0x90c7f0: r1 = 1
    //     0x90c7f0: mov             x1, #1
    // 0x90c7f4: cmp             x1, x0
    // 0x90c7f8: b.hs            #0x90c944
    // 0x90c7fc: ldur            x0, [fp, #-0x28]
    // 0x90c800: LoadField: r1 = r0->field_13
    //     0x90c800: ldur            w1, [x0, #0x13]
    // 0x90c804: DecompressPointer r1
    //     0x90c804: add             x1, x1, HEAP, lsl #32
    // 0x90c808: r2 = "//"
    //     0x90c808: ldr             x2, [PP, #0x39f8]  ; [pp+0x39f8] "//"
    // 0x90c80c: r3 = "/"
    //     0x90c80c: ldr             x3, [PP, #0xfe0]  ; [pp+0xfe0] "/"
    // 0x90c810: r0 = replaceAll()
    //     0x90c810: bl              #0x7eb6a4  ; [dart:core] _StringBase::replaceAll
    // 0x90c814: ldur            x1, [fp, #-0x38]
    // 0x90c818: ArrayStore: r1[2] = r0  ; List_4
    //     0x90c818: add             x25, x1, #0x17
    //     0x90c81c: str             w0, [x25]
    //     0x90c820: tbz             w0, #0, #0x90c83c
    //     0x90c824: ldurb           w16, [x1, #-1]
    //     0x90c828: ldurb           w17, [x0, #-1]
    //     0x90c82c: and             x16, x17, x16, lsr #2
    //     0x90c830: tst             x16, HEAP, lsr #32
    //     0x90c834: b.eq            #0x90c83c
    //     0x90c838: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x90c83c: ldur            x16, [fp, #-0x38]
    // 0x90c840: str             x16, [SP]
    // 0x90c844: r0 = _interpolate()
    //     0x90c844: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x90c848: b               #0x90c850
    // 0x90c84c: ldur            x0, [fp, #-0x18]
    // 0x90c850: mov             x2, x0
    // 0x90c854: b               #0x90c85c
    // 0x90c858: ldur            x2, [fp, #-8]
    // 0x90c85c: ldur            x0, [fp, #-0x10]
    // 0x90c860: stur            x2, [fp, #-8]
    // 0x90c864: LoadField: r1 = r0->field_4f
    //     0x90c864: ldur            w1, [x0, #0x4f]
    // 0x90c868: DecompressPointer r1
    //     0x90c868: add             x1, x1, HEAP, lsl #32
    // 0x90c86c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x90c870: cmp             w1, w16
    // 0x90c874: b.eq            #0x90c948
    // 0x90c878: LoadField: r3 = r0->field_47
    //     0x90c878: ldur            w3, [x0, #0x47]
    // 0x90c87c: DecompressPointer r3
    //     0x90c87c: add             x3, x3, HEAP, lsl #32
    // 0x90c880: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x90c884: cmp             w3, w16
    // 0x90c888: b.eq            #0x90c954
    // 0x90c88c: r0 = urlEncodeQueryMap()
    //     0x90c88c: bl              #0x90c960  ; [package:dio/src/transformer.dart] Transformer::urlEncodeQueryMap
    // 0x90c890: mov             x3, x0
    // 0x90c894: stur            x3, [fp, #-0x10]
    // 0x90c898: LoadField: r0 = r3->field_7
    //     0x90c898: ldur            w0, [x3, #7]
    // 0x90c89c: cbz             w0, #0x90c8f4
    // 0x90c8a0: ldur            x4, [fp, #-8]
    // 0x90c8a4: r0 = LoadClassIdInstr(r4)
    //     0x90c8a4: ldur            x0, [x4, #-1]
    //     0x90c8a8: ubfx            x0, x0, #0xc, #0x14
    // 0x90c8ac: mov             x1, x4
    // 0x90c8b0: r2 = "\?"
    //     0x90c8b0: ldr             x2, [PP, #0x1368]  ; [pp+0x1368] "\?"
    // 0x90c8b4: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x90c8b4: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x90c8b8: r0 = GDT[cid_x0 + -0x1000]()
    //     0x90c8b8: sub             lr, x0, #1, lsl #12
    //     0x90c8bc: ldr             lr, [x21, lr, lsl #3]
    //     0x90c8c0: blr             lr
    // 0x90c8c4: tbnz            w0, #4, #0x90c8d0
    // 0x90c8c8: r0 = "&"
    //     0x90c8c8: ldr             x0, [PP, #0x11c8]  ; [pp+0x11c8] "&"
    // 0x90c8cc: b               #0x90c8d4
    // 0x90c8d0: r0 = "\?"
    //     0x90c8d0: ldr             x0, [PP, #0x1368]  ; [pp+0x1368] "\?"
    // 0x90c8d4: ldur            x16, [fp, #-0x10]
    // 0x90c8d8: stp             x16, x0, [SP]
    // 0x90c8dc: r0 = +()
    //     0x90c8dc: bl              #0x7e1e74  ; [dart:core] _StringBase::+
    // 0x90c8e0: ldur            x16, [fp, #-8]
    // 0x90c8e4: stp             x0, x16, [SP]
    // 0x90c8e8: r0 = +()
    //     0x90c8e8: bl              #0x7e1e74  ; [dart:core] _StringBase::+
    // 0x90c8ec: mov             x1, x0
    // 0x90c8f0: b               #0x90c8f8
    // 0x90c8f4: ldur            x1, [fp, #-8]
    // 0x90c8f8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x90c8f8: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x90c8fc: r0 = parse()
    //     0x90c8fc: bl              #0x7f6fc0  ; [dart:core] Uri::parse
    // 0x90c900: r1 = LoadClassIdInstr(r0)
    //     0x90c900: ldur            x1, [x0, #-1]
    //     0x90c904: ubfx            x1, x1, #0xc, #0x14
    // 0x90c908: mov             x16, x0
    // 0x90c90c: mov             x0, x1
    // 0x90c910: mov             x1, x16
    // 0x90c914: r0 = GDT[cid_x0 + 0x75d]()
    //     0x90c914: add             lr, x0, #0x75d
    //     0x90c918: ldr             lr, [x21, lr, lsl #3]
    //     0x90c91c: blr             lr
    // 0x90c920: LeaveFrame
    //     0x90c920: mov             SP, fp
    //     0x90c924: ldp             fp, lr, [SP], #0x10
    // 0x90c928: ret
    //     0x90c928: ret             
    // 0x90c92c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x90c92c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x90c930: b               #0x90c6ec
    // 0x90c934: r9 = _baseUrl
    //     0x90c934: add             x9, PP, #0x15, lsl #12  ; [pp+0x15ec0] Field <_MixinApplication368&_RequestConfig&OptionsMixin@18353248._baseUrl@271184022>: late (offset: 0x4c)
    //     0x90c938: ldr             x9, [x9, #0xec0]
    // 0x90c93c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x90c93c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x90c940: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x90c940: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x90c944: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x90c944: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x90c948: r9 = queryParameters
    //     0x90c948: add             x9, PP, #0x16, lsl #12  ; [pp+0x16588] Field <_MixinApplication368&_RequestConfig&OptionsMixin@18353248.queryParameters>: late (offset: 0x50)
    //     0x90c94c: ldr             x9, [x9, #0x588]
    // 0x90c950: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x90c950: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x90c954: r9 = listFormat
    //     0x90c954: add             x9, PP, #0x16, lsl #12  ; [pp+0x16590] Field <_RequestConfig@271184022.listFormat>: late (offset: 0x48)
    //     0x90c958: ldr             x9, [x9, #0x590]
    // 0x90c95c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x90c95c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ copyWith(/* No info */) {
    // ** addr: 0x911300, size: 0x364
    // 0x911300: EnterFrame
    //     0x911300: stp             fp, lr, [SP, #-0x10]!
    //     0x911304: mov             fp, SP
    // 0x911308: AllocStack(0x128)
    //     0x911308: sub             SP, SP, #0x128
    // 0x91130c: SetupParameters(RequestOptions this /* r1 => r3, fp-0x38 */, dynamic _ /* r2 => r0, fp-0x40 */)
    //     0x91130c: mov             x3, x1
    //     0x911310: mov             x0, x2
    //     0x911314: stur            x1, [fp, #-0x38]
    //     0x911318: stur            x2, [fp, #-0x40]
    // 0x91131c: CheckStackOverflow
    //     0x91131c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x911320: cmp             SP, x16
    //     0x911324: b.ls            #0x9115cc
    // 0x911328: LoadField: r4 = r3->field_7
    //     0x911328: ldur            w4, [x3, #7]
    // 0x91132c: DecompressPointer r4
    //     0x91132c: add             x4, x4, HEAP, lsl #32
    // 0x911330: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x911334: cmp             w4, w16
    // 0x911338: b.eq            #0x9115d4
    // 0x91133c: stur            x4, [fp, #-0x30]
    // 0x911340: LoadField: r5 = r3->field_13
    //     0x911340: ldur            w5, [x3, #0x13]
    // 0x911344: DecompressPointer r5
    //     0x911344: add             x5, x5, HEAP, lsl #32
    // 0x911348: stur            x5, [fp, #-0x28]
    // 0x91134c: ArrayLoad: r6 = r3[0]  ; List_4
    //     0x91134c: ldur            w6, [x3, #0x17]
    // 0x911350: DecompressPointer r6
    //     0x911350: add             x6, x6, HEAP, lsl #32
    // 0x911354: stur            x6, [fp, #-0x20]
    // 0x911358: LoadField: r7 = r3->field_53
    //     0x911358: ldur            w7, [x3, #0x53]
    // 0x91135c: DecompressPointer r7
    //     0x91135c: add             x7, x7, HEAP, lsl #32
    // 0x911360: stur            x7, [fp, #-0x18]
    // 0x911364: LoadField: r8 = r3->field_5b
    //     0x911364: ldur            w8, [x3, #0x5b]
    // 0x911368: DecompressPointer r8
    //     0x911368: add             x8, x8, HEAP, lsl #32
    // 0x91136c: stur            x8, [fp, #-0x10]
    // 0x911370: LoadField: r10 = r3->field_5f
    //     0x911370: ldur            w10, [x3, #0x5f]
    // 0x911374: DecompressPointer r10
    //     0x911374: add             x10, x10, HEAP, lsl #32
    // 0x911378: stur            x10, [fp, #-8]
    // 0x91137c: LoadField: r2 = r3->field_4f
    //     0x91137c: ldur            w2, [x3, #0x4f]
    // 0x911380: DecompressPointer r2
    //     0x911380: add             x2, x2, HEAP, lsl #32
    // 0x911384: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x911388: cmp             w2, w16
    // 0x91138c: b.eq            #0x9115e0
    // 0x911390: r1 = <String, dynamic>
    //     0x911390: ldr             x1, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x911394: r0 = LinkedHashMap.from()
    //     0x911394: bl              #0x8ac2e4  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x911398: mov             x3, x0
    // 0x91139c: ldur            x0, [fp, #-0x38]
    // 0x9113a0: stur            x3, [fp, #-0x50]
    // 0x9113a4: LoadField: r4 = r0->field_67
    //     0x9113a4: ldur            w4, [x0, #0x67]
    // 0x9113a8: DecompressPointer r4
    //     0x9113a8: add             x4, x4, HEAP, lsl #32
    // 0x9113ac: stur            x4, [fp, #-0x48]
    // 0x9113b0: LoadField: r2 = r0->field_2f
    //     0x9113b0: ldur            w2, [x0, #0x2f]
    // 0x9113b4: DecompressPointer r2
    //     0x9113b4: add             x2, x2, HEAP, lsl #32
    // 0x9113b8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9113bc: cmp             w2, w16
    // 0x9113c0: b.eq            #0x9115ec
    // 0x9113c4: r1 = <String, dynamic>
    //     0x9113c4: ldr             x1, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x9113c8: r0 = LinkedHashMap.from()
    //     0x9113c8: bl              #0x8ac2e4  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x9113cc: mov             x3, x0
    // 0x9113d0: ldur            x0, [fp, #-0x38]
    // 0x9113d4: stur            x3, [fp, #-0x58]
    // 0x9113d8: LoadField: r2 = r0->field_b
    //     0x9113d8: ldur            w2, [x0, #0xb]
    // 0x9113dc: DecompressPointer r2
    //     0x9113dc: add             x2, x2, HEAP, lsl #32
    // 0x9113e0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9113e4: cmp             w2, w16
    // 0x9113e8: b.eq            #0x9115f8
    // 0x9113ec: r1 = <String, dynamic>
    //     0x9113ec: ldr             x1, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x9113f0: r0 = LinkedHashMap.from()
    //     0x9113f0: bl              #0x8ac2e4  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x9113f4: mov             x1, x0
    // 0x9113f8: ldur            x0, [fp, #-0x38]
    // 0x9113fc: stur            x1, [fp, #-0x80]
    // 0x911400: LoadField: r2 = r0->field_f
    //     0x911400: ldur            w2, [x0, #0xf]
    // 0x911404: DecompressPointer r2
    //     0x911404: add             x2, x2, HEAP, lsl #32
    // 0x911408: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x91140c: cmp             w2, w16
    // 0x911410: b.eq            #0x911604
    // 0x911414: LoadField: r2 = r0->field_23
    //     0x911414: ldur            w2, [x0, #0x23]
    // 0x911418: DecompressPointer r2
    //     0x911418: add             x2, x2, HEAP, lsl #32
    // 0x91141c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x911420: cmp             w2, w16
    // 0x911424: b.eq            #0x911610
    // 0x911428: stur            x2, [fp, #-0x78]
    // 0x91142c: LoadField: r3 = r0->field_27
    //     0x91142c: ldur            w3, [x0, #0x27]
    // 0x911430: DecompressPointer r3
    //     0x911430: add             x3, x3, HEAP, lsl #32
    // 0x911434: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x911438: cmp             w3, w16
    // 0x91143c: b.eq            #0x91161c
    // 0x911440: stur            x3, [fp, #-0x70]
    // 0x911444: LoadField: r4 = r0->field_2b
    //     0x911444: ldur            w4, [x0, #0x2b]
    // 0x911448: DecompressPointer r4
    //     0x911448: add             x4, x4, HEAP, lsl #32
    // 0x91144c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x911450: cmp             w4, w16
    // 0x911454: b.eq            #0x911628
    // 0x911458: LoadField: r4 = r0->field_33
    //     0x911458: ldur            w4, [x0, #0x33]
    // 0x91145c: DecompressPointer r4
    //     0x91145c: add             x4, x4, HEAP, lsl #32
    // 0x911460: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x911464: cmp             w4, w16
    // 0x911468: b.eq            #0x911634
    // 0x91146c: stur            x4, [fp, #-0x68]
    // 0x911470: LoadField: r5 = r0->field_37
    //     0x911470: ldur            w5, [x0, #0x37]
    // 0x911474: DecompressPointer r5
    //     0x911474: add             x5, x5, HEAP, lsl #32
    // 0x911478: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x91147c: cmp             w5, w16
    // 0x911480: b.eq            #0x911640
    // 0x911484: LoadField: r5 = r0->field_3b
    //     0x911484: ldur            w5, [x0, #0x3b]
    // 0x911488: DecompressPointer r5
    //     0x911488: add             x5, x5, HEAP, lsl #32
    // 0x91148c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x911490: cmp             w5, w16
    // 0x911494: b.eq            #0x91164c
    // 0x911498: LoadField: r5 = r0->field_47
    //     0x911498: ldur            w5, [x0, #0x47]
    // 0x91149c: DecompressPointer r5
    //     0x91149c: add             x5, x5, HEAP, lsl #32
    // 0x9114a0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9114a4: cmp             w5, w16
    // 0x9114a8: b.eq            #0x911658
    // 0x9114ac: LoadField: r5 = r0->field_57
    //     0x9114ac: ldur            w5, [x0, #0x57]
    // 0x9114b0: DecompressPointer r5
    //     0x9114b0: add             x5, x5, HEAP, lsl #32
    // 0x9114b4: stur            x5, [fp, #-0x60]
    // 0x9114b8: r0 = RequestOptions()
    //     0x9114b8: bl              #0x8eba04  ; AllocateRequestOptionsStub -> RequestOptions (size=0x70)
    // 0x9114bc: stur            x0, [fp, #-0x88]
    // 0x9114c0: ldur            x16, [fp, #-0x30]
    // 0x9114c4: ldur            lr, [fp, #-0x28]
    // 0x9114c8: stp             lr, x16, [SP, #0x90]
    // 0x9114cc: ldur            x16, [fp, #-0x20]
    // 0x9114d0: ldur            lr, [fp, #-0x18]
    // 0x9114d4: stp             lr, x16, [SP, #0x80]
    // 0x9114d8: ldur            x16, [fp, #-0x10]
    // 0x9114dc: ldur            lr, [fp, #-8]
    // 0x9114e0: stp             lr, x16, [SP, #0x70]
    // 0x9114e4: ldur            x16, [fp, #-0x40]
    // 0x9114e8: ldur            lr, [fp, #-0x50]
    // 0x9114ec: stp             lr, x16, [SP, #0x60]
    // 0x9114f0: ldur            x16, [fp, #-0x48]
    // 0x9114f4: ldur            lr, [fp, #-0x58]
    // 0x9114f8: stp             lr, x16, [SP, #0x50]
    // 0x9114fc: ldur            x16, [fp, #-0x80]
    // 0x911500: r30 = false
    //     0x911500: add             lr, NULL, #0x30  ; false
    // 0x911504: stp             lr, x16, [SP, #0x40]
    // 0x911508: ldur            x16, [fp, #-0x78]
    // 0x91150c: ldur            lr, [fp, #-0x70]
    // 0x911510: stp             lr, x16, [SP, #0x30]
    // 0x911514: r16 = true
    //     0x911514: add             x16, NULL, #0x20  ; true
    // 0x911518: ldur            lr, [fp, #-0x68]
    // 0x91151c: stp             lr, x16, [SP, #0x20]
    // 0x911520: r16 = 10
    //     0x911520: mov             x16, #0xa
    // 0x911524: r30 = true
    //     0x911524: add             lr, NULL, #0x20  ; true
    // 0x911528: stp             lr, x16, [SP, #0x10]
    // 0x91152c: r16 = Instance_ListFormat
    //     0x91152c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15d88] Obj!ListFormat@12c63a1
    //     0x911530: ldr             x16, [x16, #0xd88]
    // 0x911534: ldur            lr, [fp, #-0x60]
    // 0x911538: stp             lr, x16, [SP]
    // 0x91153c: mov             x1, x0
    // 0x911540: r4 = const [0, 0x15, 0x14, 0x1, baseUrl, 0x7, connectTimeout, 0x4, data, 0x5, extra, 0xa, followRedirects, 0x10, headers, 0xb, listFormat, 0x13, maxRedirects, 0x11, method, 0x1, onReceiveProgress, 0x9, path, 0x6, persistentConnection, 0x12, preserveHeaderCase, 0xc, queryParameters, 0x8, receiveDataWhenStatusError, 0xf, receiveTimeout, 0x3, responseType, 0xd, sendTimeout, 0x2, sourceStackTrace, 0x14, validateStatus, 0xe, null]
    //     0x911540: add             x4, PP, #0x16, lsl #12  ; [pp+0x16910] List(45) [0, 0x15, 0x14, 0x1, "baseUrl", 0x7, "connectTimeout", 0x4, "data", 0x5, "extra", 0xa, "followRedirects", 0x10, "headers", 0xb, "listFormat", 0x13, "maxRedirects", 0x11, "method", 0x1, "onReceiveProgress", 0x9, "path", 0x6, "persistentConnection", 0x12, "preserveHeaderCase", 0xc, "queryParameters", 0x8, "receiveDataWhenStatusError", 0xf, "receiveTimeout", 0x3, "responseType", 0xd, "sendTimeout", 0x2, "sourceStackTrace", 0x14, "validateStatus", 0xe, Null]
    //     0x911544: ldr             x4, [x4, #0x910]
    // 0x911548: r0 = RequestOptions()
    //     0x911548: bl              #0x8ea020  ; [package:dio/src/options.dart] RequestOptions::RequestOptions
    // 0x91154c: ldur            x0, [fp, #-0x38]
    // 0x911550: LoadField: r1 = r0->field_b
    //     0x911550: ldur            w1, [x0, #0xb]
    // 0x911554: DecompressPointer r1
    //     0x911554: add             x1, x1, HEAP, lsl #32
    // 0x911558: r0 = LoadClassIdInstr(r1)
    //     0x911558: ldur            x0, [x1, #-1]
    //     0x91155c: ubfx            x0, x0, #0xc, #0x14
    // 0x911560: r2 = "content-type"
    //     0x911560: add             x2, PP, #8, lsl #12  ; [pp+0x85d8] "content-type"
    //     0x911564: ldr             x2, [x2, #0x5d8]
    // 0x911568: r0 = GDT[cid_x0 + -0xd48]()
    //     0x911568: sub             lr, x0, #0xd48
    //     0x91156c: ldr             lr, [x21, lr, lsl #3]
    //     0x911570: blr             lr
    // 0x911574: mov             x3, x0
    // 0x911578: r2 = Null
    //     0x911578: mov             x2, NULL
    // 0x91157c: r1 = Null
    //     0x91157c: mov             x1, NULL
    // 0x911580: stur            x3, [fp, #-8]
    // 0x911584: r4 = 60
    //     0x911584: mov             x4, #0x3c
    // 0x911588: branchIfSmi(r0, 0x911594)
    //     0x911588: tbz             w0, #0, #0x911594
    // 0x91158c: r4 = LoadClassIdInstr(r0)
    //     0x91158c: ldur            x4, [x0, #-1]
    //     0x911590: ubfx            x4, x4, #0xc, #0x14
    // 0x911594: sub             x4, x4, #0x5e
    // 0x911598: cmp             x4, #1
    // 0x91159c: b.ls            #0x9115b0
    // 0x9115a0: r8 = String?
    //     0x9115a0: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x9115a4: r3 = Null
    //     0x9115a4: add             x3, PP, #0x16, lsl #12  ; [pp+0x16918] Null
    //     0x9115a8: ldr             x3, [x3, #0x918]
    // 0x9115ac: r0 = String?()
    //     0x9115ac: bl              #0x7db310  ; IsType_String?_Stub
    // 0x9115b0: ldur            x1, [fp, #-0x88]
    // 0x9115b4: ldur            x2, [fp, #-8]
    // 0x9115b8: r0 = contentType=()
    //     0x9115b8: bl              #0x8eae54  ; [package:dio/src/options.dart] _RequestConfig::contentType=
    // 0x9115bc: ldur            x0, [fp, #-0x88]
    // 0x9115c0: LeaveFrame
    //     0x9115c0: mov             SP, fp
    //     0x9115c4: ldp             fp, lr, [SP], #0x10
    // 0x9115c8: ret
    //     0x9115c8: ret             
    // 0x9115cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9115cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9115d0: b               #0x911328
    // 0x9115d4: r9 = method
    //     0x9115d4: add             x9, PP, #0x16, lsl #12  ; [pp+0x16500] Field <_RequestConfig@271184022.method>: late (offset: 0x8)
    //     0x9115d8: ldr             x9, [x9, #0x500]
    // 0x9115dc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9115dc: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x9115e0: r9 = queryParameters
    //     0x9115e0: add             x9, PP, #0x16, lsl #12  ; [pp+0x16588] Field <_MixinApplication368&_RequestConfig&OptionsMixin@18353248.queryParameters>: late (offset: 0x50)
    //     0x9115e4: ldr             x9, [x9, #0x588]
    // 0x9115e8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9115e8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x9115ec: r9 = extra
    //     0x9115ec: add             x9, PP, #0x16, lsl #12  ; [pp+0x16928] Field <_RequestConfig@271184022.extra>: late (offset: 0x30)
    //     0x9115f0: ldr             x9, [x9, #0x928]
    // 0x9115f4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9115f4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x9115f8: r9 = _headers
    //     0x9115f8: add             x9, PP, #0x15, lsl #12  ; [pp+0x15da8] Field <_RequestConfig@271184022._headers@271184022>: late (offset: 0xc)
    //     0x9115fc: ldr             x9, [x9, #0xda8]
    // 0x911600: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x911600: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x911604: r9 = preserveHeaderCase
    //     0x911604: add             x9, PP, #0x16, lsl #12  ; [pp+0x16070] Field <_RequestConfig@271184022.preserveHeaderCase>: late (offset: 0x10)
    //     0x911608: ldr             x9, [x9, #0x70]
    // 0x91160c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x91160c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x911610: r9 = responseType
    //     0x911610: add             x9, PP, #0x15, lsl #12  ; [pp+0x15f58] Field <_RequestConfig@271184022.responseType>: late (offset: 0x24)
    //     0x911614: ldr             x9, [x9, #0xf58]
    // 0x911618: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x911618: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x91161c: r9 = validateStatus
    //     0x91161c: add             x9, PP, #0x16, lsl #12  ; [pp+0x16078] Field <_RequestConfig@271184022.validateStatus>: late (offset: 0x28)
    //     0x911620: ldr             x9, [x9, #0x78]
    // 0x911624: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x911624: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x911628: r9 = receiveDataWhenStatusError
    //     0x911628: add             x9, PP, #0x16, lsl #12  ; [pp+0x16080] Field <_RequestConfig@271184022.receiveDataWhenStatusError>: late (offset: 0x2c)
    //     0x91162c: ldr             x9, [x9, #0x80]
    // 0x911630: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x911630: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x911634: r9 = followRedirects
    //     0x911634: add             x9, PP, #0x16, lsl #12  ; [pp+0x16508] Field <_RequestConfig@271184022.followRedirects>: late (offset: 0x34)
    //     0x911638: ldr             x9, [x9, #0x508]
    // 0x91163c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x91163c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x911640: r9 = maxRedirects
    //     0x911640: add             x9, PP, #0x16, lsl #12  ; [pp+0x16510] Field <_RequestConfig@271184022.maxRedirects>: late (offset: 0x38)
    //     0x911644: ldr             x9, [x9, #0x510]
    // 0x911648: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x911648: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x91164c: r9 = persistentConnection
    //     0x91164c: add             x9, PP, #0x16, lsl #12  ; [pp+0x16518] Field <_RequestConfig@271184022.persistentConnection>: late (offset: 0x3c)
    //     0x911650: ldr             x9, [x9, #0x518]
    // 0x911654: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x911654: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x911658: r9 = listFormat
    //     0x911658: add             x9, PP, #0x16, lsl #12  ; [pp+0x16590] Field <_RequestConfig@271184022.listFormat>: late (offset: 0x48)
    //     0x91165c: ldr             x9, [x9, #0x590]
    // 0x911660: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x911660: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 4263, size: 0x58, field offset: 0x58
class BaseOptions extends _MixinApplication368&_RequestConfig&OptionsMixin {

  _ BaseOptions(/* No info */) {
    // ** addr: 0x91d288, size: 0x1a8
    // 0x91d288: EnterFrame
    //     0x91d288: stp             fp, lr, [SP, #-0x10]!
    //     0x91d28c: mov             fp, SP
    // 0x91d290: AllocStack(0x58)
    //     0x91d290: sub             SP, SP, #0x58
    // 0x91d294: SetupParameters(BaseOptions this /* r1 => r0, fp-0x10 */, {dynamic connectTimeout = Null /* r8, fp-0x8 */, dynamic receiveTimeout = Null /* r3 */, dynamic sendTimeout = Null /* r1 */})
    //     0x91d294: mov             x0, x1
    //     0x91d298: stur            x1, [fp, #-0x10]
    //     0x91d29c: ldur            w1, [x4, #0x13]
    //     0x91d2a0: ldur            w2, [x4, #0x1f]
    //     0x91d2a4: add             x2, x2, HEAP, lsl #32
    //     0x91d2a8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15d08] "connectTimeout"
    //     0x91d2ac: ldr             x16, [x16, #0xd08]
    //     0x91d2b0: cmp             w2, w16
    //     0x91d2b4: b.ne            #0x91d2d8
    //     0x91d2b8: ldur            w2, [x4, #0x23]
    //     0x91d2bc: add             x2, x2, HEAP, lsl #32
    //     0x91d2c0: sub             w3, w1, w2
    //     0x91d2c4: add             x2, fp, w3, sxtw #2
    //     0x91d2c8: ldr             x2, [x2, #8]
    //     0x91d2cc: mov             x8, x2
    //     0x91d2d0: mov             x2, #1
    //     0x91d2d4: b               #0x91d2e0
    //     0x91d2d8: mov             x8, NULL
    //     0x91d2dc: mov             x2, #0
    //     0x91d2e0: stur            x8, [fp, #-8]
    //     0x91d2e4: lsl             x3, x2, #1
    //     0x91d2e8: lsl             w5, w3, #1
    //     0x91d2ec: add             w6, w5, #8
    //     0x91d2f0: add             x16, x4, w6, sxtw #1
    //     0x91d2f4: ldur            w7, [x16, #0xf]
    //     0x91d2f8: add             x7, x7, HEAP, lsl #32
    //     0x91d2fc: add             x16, PP, #0x15, lsl #12  ; [pp+0x15d50] "receiveTimeout"
    //     0x91d300: ldr             x16, [x16, #0xd50]
    //     0x91d304: cmp             w7, w16
    //     0x91d308: b.ne            #0x91d33c
    //     0x91d30c: add             w2, w5, #0xa
    //     0x91d310: add             x16, x4, w2, sxtw #1
    //     0x91d314: ldur            w5, [x16, #0xf]
    //     0x91d318: add             x5, x5, HEAP, lsl #32
    //     0x91d31c: sub             w2, w1, w5
    //     0x91d320: add             x5, fp, w2, sxtw #2
    //     0x91d324: ldr             x5, [x5, #8]
    //     0x91d328: add             w2, w3, #2
    //     0x91d32c: sbfx            x3, x2, #1, #0x1f
    //     0x91d330: mov             x2, x3
    //     0x91d334: mov             x3, x5
    //     0x91d338: b               #0x91d340
    //     0x91d33c: mov             x3, NULL
    //     0x91d340: lsl             x5, x2, #1
    //     0x91d344: lsl             w2, w5, #1
    //     0x91d348: add             w5, w2, #8
    //     0x91d34c: add             x16, x4, w5, sxtw #1
    //     0x91d350: ldur            w6, [x16, #0xf]
    //     0x91d354: add             x6, x6, HEAP, lsl #32
    //     0x91d358: add             x16, PP, #0x15, lsl #12  ; [pp+0x15d60] "sendTimeout"
    //     0x91d35c: ldr             x16, [x16, #0xd60]
    //     0x91d360: cmp             w6, w16
    //     0x91d364: b.ne            #0x91d388
    //     0x91d368: add             w5, w2, #0xa
    //     0x91d36c: add             x16, x4, w5, sxtw #1
    //     0x91d370: ldur            w2, [x16, #0xf]
    //     0x91d374: add             x2, x2, HEAP, lsl #32
    //     0x91d378: sub             w4, w1, w2
    //     0x91d37c: add             x1, fp, w4, sxtw #2
    //     0x91d380: ldr             x1, [x1, #8]
    //     0x91d384: b               #0x91d38c
    //     0x91d388: mov             x1, NULL
    // 0x91d38c: CheckStackOverflow
    //     0x91d38c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91d390: cmp             SP, x16
    //     0x91d394: b.ls            #0x91d428
    // 0x91d398: stp             NULL, NULL, [SP, #0x38]
    // 0x91d39c: r16 = false
    //     0x91d39c: add             x16, NULL, #0x30  ; false
    // 0x91d3a0: stp             x16, NULL, [SP, #0x28]
    // 0x91d3a4: stp             x3, NULL, [SP, #0x18]
    // 0x91d3a8: r16 = Instance_ResponseType
    //     0x91d3a8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15d98] Obj!ResponseType@12c63c1
    //     0x91d3ac: ldr             x16, [x16, #0xd98]
    // 0x91d3b0: stp             x1, x16, [SP, #8]
    // 0x91d3b4: str             NULL, [SP]
    // 0x91d3b8: mov             x1, x0
    // 0x91d3bc: r2 = Null
    //     0x91d3bc: mov             x2, NULL
    // 0x91d3c0: r3 = Null
    //     0x91d3c0: mov             x3, NULL
    // 0x91d3c4: r5 = Null
    //     0x91d3c4: mov             x5, NULL
    // 0x91d3c8: r6 = Null
    //     0x91d3c8: mov             x6, NULL
    // 0x91d3cc: r7 = Null
    //     0x91d3cc: mov             x7, NULL
    // 0x91d3d0: r0 = _MixinApplication368&_RequestConfig&OptionsMixin()
    //     0x91d3d0: bl              #0x8eaaa0  ; [dart:mixin_deduplication] _MixinApplication368&_RequestConfig&OptionsMixin::_MixinApplication368&_RequestConfig&OptionsMixin
    // 0x91d3d4: ldur            x1, [fp, #-0x10]
    // 0x91d3d8: r2 = ""
    //     0x91d3d8: ldr             x2, [PP, #0x900]  ; [pp+0x900] ""
    // 0x91d3dc: r0 = baseUrl=()
    //     0x91d3dc: bl              #0x8ea9c0  ; [dart:mixin_deduplication] _MixinApplication368&_RequestConfig&OptionsMixin::baseUrl=
    // 0x91d3e0: r16 = <String, dynamic>
    //     0x91d3e0: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x91d3e4: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x91d3e8: stp             lr, x16, [SP]
    // 0x91d3ec: r0 = Map._fromLiteral()
    //     0x91d3ec: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x91d3f0: ldur            x1, [fp, #-0x10]
    // 0x91d3f4: StoreField: r1->field_4f = r0
    //     0x91d3f4: stur            w0, [x1, #0x4f]
    //     0x91d3f8: ldurb           w16, [x1, #-1]
    //     0x91d3fc: ldurb           w17, [x0, #-1]
    //     0x91d400: and             x16, x17, x16, lsr #2
    //     0x91d404: tst             x16, HEAP, lsr #32
    //     0x91d408: b.eq            #0x91d410
    //     0x91d40c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x91d410: ldur            x2, [fp, #-8]
    // 0x91d414: r0 = connectTimeout=()
    //     0x91d414: bl              #0x8ea958  ; [dart:mixin_deduplication] _MixinApplication368&_RequestConfig&OptionsMixin::connectTimeout=
    // 0x91d418: r0 = Null
    //     0x91d418: mov             x0, NULL
    // 0x91d41c: LeaveFrame
    //     0x91d41c: mov             SP, fp
    //     0x91d420: ldp             fp, lr, [SP], #0x10
    // 0x91d424: ret
    //     0x91d424: ret             
    // 0x91d428: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91d428: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x91d42c: b               #0x91d398
  }
}

// class id: 8333, size: 0x14, field offset: 0x14
enum ListFormat extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11a92e8, size: 0x64
    // 0x11a92e8: EnterFrame
    //     0x11a92e8: stp             fp, lr, [SP, #-0x10]!
    //     0x11a92ec: mov             fp, SP
    // 0x11a92f0: AllocStack(0x10)
    //     0x11a92f0: sub             SP, SP, #0x10
    // 0x11a92f4: SetupParameters(ListFormat this /* r1 => r0, fp-0x8 */)
    //     0x11a92f4: mov             x0, x1
    //     0x11a92f8: stur            x1, [fp, #-8]
    // 0x11a92fc: CheckStackOverflow
    //     0x11a92fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a9300: cmp             SP, x16
    //     0x11a9304: b.ls            #0x11a9344
    // 0x11a9308: r1 = Null
    //     0x11a9308: mov             x1, NULL
    // 0x11a930c: r2 = 4
    //     0x11a930c: mov             x2, #4
    // 0x11a9310: r0 = AllocateArray()
    //     0x11a9310: bl              #0x13df928  ; AllocateArrayStub
    // 0x11a9314: r16 = "ListFormat."
    //     0x11a9314: add             x16, PP, #0x81, lsl #12  ; [pp+0x81eb0] "ListFormat."
    //     0x11a9318: ldr             x16, [x16, #0xeb0]
    // 0x11a931c: StoreField: r0->field_f = r16
    //     0x11a931c: stur            w16, [x0, #0xf]
    // 0x11a9320: ldur            x1, [fp, #-8]
    // 0x11a9324: LoadField: r2 = r1->field_f
    //     0x11a9324: ldur            w2, [x1, #0xf]
    // 0x11a9328: DecompressPointer r2
    //     0x11a9328: add             x2, x2, HEAP, lsl #32
    // 0x11a932c: StoreField: r0->field_13 = r2
    //     0x11a932c: stur            w2, [x0, #0x13]
    // 0x11a9330: str             x0, [SP]
    // 0x11a9334: r0 = _interpolate()
    //     0x11a9334: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11a9338: LeaveFrame
    //     0x11a9338: mov             SP, fp
    //     0x11a933c: ldp             fp, lr, [SP], #0x10
    // 0x11a9340: ret
    //     0x11a9340: ret             
    // 0x11a9344: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a9344: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a9348: b               #0x11a9308
  }
}

// class id: 8334, size: 0x14, field offset: 0x14
enum ResponseType extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11a9284, size: 0x64
    // 0x11a9284: EnterFrame
    //     0x11a9284: stp             fp, lr, [SP, #-0x10]!
    //     0x11a9288: mov             fp, SP
    // 0x11a928c: AllocStack(0x10)
    //     0x11a928c: sub             SP, SP, #0x10
    // 0x11a9290: SetupParameters(ResponseType this /* r1 => r0, fp-0x8 */)
    //     0x11a9290: mov             x0, x1
    //     0x11a9294: stur            x1, [fp, #-8]
    // 0x11a9298: CheckStackOverflow
    //     0x11a9298: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a929c: cmp             SP, x16
    //     0x11a92a0: b.ls            #0x11a92e0
    // 0x11a92a4: r1 = Null
    //     0x11a92a4: mov             x1, NULL
    // 0x11a92a8: r2 = 4
    //     0x11a92a8: mov             x2, #4
    // 0x11a92ac: r0 = AllocateArray()
    //     0x11a92ac: bl              #0x13df928  ; AllocateArrayStub
    // 0x11a92b0: r16 = "ResponseType."
    //     0x11a92b0: add             x16, PP, #0x81, lsl #12  ; [pp+0x81eb8] "ResponseType."
    //     0x11a92b4: ldr             x16, [x16, #0xeb8]
    // 0x11a92b8: StoreField: r0->field_f = r16
    //     0x11a92b8: stur            w16, [x0, #0xf]
    // 0x11a92bc: ldur            x1, [fp, #-8]
    // 0x11a92c0: LoadField: r2 = r1->field_f
    //     0x11a92c0: ldur            w2, [x1, #0xf]
    // 0x11a92c4: DecompressPointer r2
    //     0x11a92c4: add             x2, x2, HEAP, lsl #32
    // 0x11a92c8: StoreField: r0->field_13 = r2
    //     0x11a92c8: stur            w2, [x0, #0x13]
    // 0x11a92cc: str             x0, [SP]
    // 0x11a92d0: r0 = _interpolate()
    //     0x11a92d0: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11a92d4: LeaveFrame
    //     0x11a92d4: mov             SP, fp
    //     0x11a92d8: ldp             fp, lr, [SP], #0x10
    // 0x11a92dc: ret
    //     0x11a92dc: ret             
    // 0x11a92e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a92e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a92e4: b               #0x11a92a4
  }
}
