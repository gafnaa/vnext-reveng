// lib: , url: package:dio/src/form_data.dart

// class id: 1048703, size: 0x8
class :: {

  static late final Uint8List _rnU8; // offset: 0xb1c
  static late final Random _random; // offset: 0xb20

  static Uint8List _rnU8() {
    // ** addr: 0x910bac, size: 0x94
    // 0x910bac: EnterFrame
    //     0x910bac: stp             fp, lr, [SP, #-0x10]!
    //     0x910bb0: mov             fp, SP
    // 0x910bb4: AllocStack(0x10)
    //     0x910bb4: sub             SP, SP, #0x10
    // 0x910bb8: r0 = 4
    //     0x910bb8: mov             x0, #4
    // 0x910bbc: CheckStackOverflow
    //     0x910bbc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x910bc0: cmp             SP, x16
    //     0x910bc4: b.ls            #0x910c38
    // 0x910bc8: mov             x2, x0
    // 0x910bcc: r1 = Null
    //     0x910bcc: mov             x1, NULL
    // 0x910bd0: r0 = AllocateArray()
    //     0x910bd0: bl              #0x13df928  ; AllocateArrayStub
    // 0x910bd4: stur            x0, [fp, #-8]
    // 0x910bd8: r16 = 26
    //     0x910bd8: mov             x16, #0x1a
    // 0x910bdc: StoreField: r0->field_f = r16
    //     0x910bdc: stur            w16, [x0, #0xf]
    // 0x910be0: r16 = 20
    //     0x910be0: mov             x16, #0x14
    // 0x910be4: StoreField: r0->field_13 = r16
    //     0x910be4: stur            w16, [x0, #0x13]
    // 0x910be8: r1 = <int>
    //     0x910be8: ldr             x1, [PP, #0x50]  ; [pp+0x50] TypeArguments: <int>
    // 0x910bec: r0 = AllocateGrowableArray()
    //     0x910bec: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x910bf0: mov             x1, x0
    // 0x910bf4: ldur            x0, [fp, #-8]
    // 0x910bf8: stur            x1, [fp, #-0x10]
    // 0x910bfc: StoreField: r1->field_f = r0
    //     0x910bfc: stur            w0, [x1, #0xf]
    // 0x910c00: r4 = 4
    //     0x910c00: mov             x4, #4
    // 0x910c04: StoreField: r1->field_b = r4
    //     0x910c04: stur            w4, [x1, #0xb]
    // 0x910c08: r0 = AllocateUint8Array()
    //     0x910c08: bl              #0x13df5f0  ; AllocateUint8ArrayStub
    // 0x910c0c: mov             x1, x0
    // 0x910c10: ldur            x5, [fp, #-0x10]
    // 0x910c14: r2 = 0
    //     0x910c14: mov             x2, #0
    // 0x910c18: r3 = 2
    //     0x910c18: mov             x3, #2
    // 0x910c1c: r6 = 0
    //     0x910c1c: mov             x6, #0
    // 0x910c20: stur            x0, [fp, #-8]
    // 0x910c24: r0 = _slowSetRange()
    //     0x910c24: bl              #0x117e940  ; [dart:typed_data] __Uint8List&_TypedList&_IntListMixin&_TypedIntListMixin::_slowSetRange
    // 0x910c28: ldur            x0, [fp, #-8]
    // 0x910c2c: LeaveFrame
    //     0x910c2c: mov             SP, fp
    //     0x910c30: ldp             fp, lr, [SP], #0x10
    // 0x910c34: ret
    //     0x910c34: ret             
    // 0x910c38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x910c38: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x910c3c: b               #0x910bc8
  }
  String _nextRandomId() {
    // ** addr: 0x912060, size: 0xc4
    // 0x912060: EnterFrame
    //     0x912060: stp             fp, lr, [SP, #-0x10]!
    //     0x912064: mov             fp, SP
    // 0x912068: AllocStack(0x8)
    //     0x912068: sub             SP, SP, #8
    // 0x91206c: CheckStackOverflow
    //     0x91206c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x912070: cmp             SP, x16
    //     0x912074: b.ls            #0x91211c
    // 0x912078: r0 = LoadStaticField(0xb20)
    //     0x912078: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x91207c: ldr             x0, [x0, #0x1640]
    // 0x912080: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x912084: cmp             w0, w16
    // 0x912088: b.ne            #0x912098
    // 0x91208c: r2 = _random
    //     0x91208c: add             x2, PP, #0x16, lsl #12  ; [pp+0x16998] Field <::._random@376426596>: static late final (offset: 0xb20)
    //     0x912090: ldr             x2, [x2, #0x998]
    // 0x912094: r0 = InitLateFinalStaticField()
    //     0x912094: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x912098: mov             x1, x0
    // 0x91209c: r2 = 4294967296
    //     0x91209c: mov             x2, #0x100000000
    // 0x9120a0: r0 = nextInt()
    //     0x9120a0: bl              #0x82f250  ; [dart:math] _Random::nextInt
    // 0x9120a4: mov             x2, x0
    // 0x9120a8: r0 = BoxInt64Instr(r2)
    //     0x9120a8: sbfiz           x0, x2, #1, #0x1f
    //     0x9120ac: cmp             x2, x0, asr #1
    //     0x9120b0: b.eq            #0x9120bc
    //     0x9120b4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x9120b8: stur            x2, [x0, #7]
    // 0x9120bc: r1 = 60
    //     0x9120bc: mov             x1, #0x3c
    // 0x9120c0: branchIfSmi(r0, 0x9120cc)
    //     0x9120c0: tbz             w0, #0, #0x9120cc
    // 0x9120c4: r1 = LoadClassIdInstr(r0)
    //     0x9120c4: ldur            x1, [x0, #-1]
    //     0x9120c8: ubfx            x1, x1, #0xc, #0x14
    // 0x9120cc: str             x0, [SP]
    // 0x9120d0: mov             x0, x1
    // 0x9120d4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x9120d4: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x9120d8: r0 = GDT[cid_x0 + 0x91c1]()
    //     0x9120d8: mov             x17, #0x91c1
    //     0x9120dc: add             lr, x0, x17
    //     0x9120e0: ldr             lr, [x21, lr, lsl #3]
    //     0x9120e4: blr             lr
    // 0x9120e8: r1 = LoadClassIdInstr(r0)
    //     0x9120e8: ldur            x1, [x0, #-1]
    //     0x9120ec: ubfx            x1, x1, #0xc, #0x14
    // 0x9120f0: mov             x16, x0
    // 0x9120f4: mov             x0, x1
    // 0x9120f8: mov             x1, x16
    // 0x9120fc: r2 = 10
    //     0x9120fc: mov             x2, #0xa
    // 0x912100: r3 = "0"
    //     0x912100: ldr             x3, [PP, #0x47e8]  ; [pp+0x47e8] "0"
    // 0x912104: r0 = GDT[cid_x0 + -0xff6]()
    //     0x912104: sub             lr, x0, #0xff6
    //     0x912108: ldr             lr, [x21, lr, lsl #3]
    //     0x91210c: blr             lr
    // 0x912110: LeaveFrame
    //     0x912110: mov             SP, fp
    //     0x912114: ldp             fp, lr, [SP], #0x10
    // 0x912118: ret
    //     0x912118: ret             
    // 0x91211c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91211c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x912120: b               #0x912078
  }
  static Random _random() {
    // ** addr: 0x912124, size: 0x30
    // 0x912124: EnterFrame
    //     0x912124: stp             fp, lr, [SP, #-0x10]!
    //     0x912128: mov             fp, SP
    // 0x91212c: CheckStackOverflow
    //     0x91212c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x912130: cmp             SP, x16
    //     0x912134: b.ls            #0x91214c
    // 0x912138: r1 = Null
    //     0x912138: mov             x1, NULL
    // 0x91213c: r0 = Random()
    //     0x91213c: bl              #0x912154  ; [dart:math] Random::Random
    // 0x912140: LeaveFrame
    //     0x912140: mov             SP, fp
    //     0x912144: ldp             fp, lr, [SP], #0x10
    // 0x912148: ret
    //     0x912148: ret             
    // 0x91214c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91214c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x912150: b               #0x912138
  }
}

// class id: 3404, size: 0x20, field offset: 0x8
class FormData extends Object {

  late String _boundary; // offset: 0x10

  int length(FormData) {
    // ** addr: 0x90fa4c, size: 0x36c
    // 0x90fa4c: EnterFrame
    //     0x90fa4c: stp             fp, lr, [SP, #-0x10]!
    //     0x90fa50: mov             fp, SP
    // 0x90fa54: AllocStack(0x58)
    //     0x90fa54: sub             SP, SP, #0x58
    // 0x90fa58: SetupParameters(FormData this /* r1 => r0, fp-0x40 */)
    //     0x90fa58: mov             x0, x1
    //     0x90fa5c: stur            x1, [fp, #-0x40]
    // 0x90fa60: CheckStackOverflow
    //     0x90fa60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x90fa64: cmp             SP, x16
    //     0x90fa68: b.ls            #0x90fd78
    // 0x90fa6c: LoadField: r3 = r0->field_13
    //     0x90fa6c: ldur            w3, [x0, #0x13]
    // 0x90fa70: DecompressPointer r3
    //     0x90fa70: add             x3, x3, HEAP, lsl #32
    // 0x90fa74: stur            x3, [fp, #-0x38]
    // 0x90fa78: LoadField: r1 = r3->field_b
    //     0x90fa78: ldur            w1, [x3, #0xb]
    // 0x90fa7c: r4 = LoadInt32Instr(r1)
    //     0x90fa7c: sbfx            x4, x1, #1, #0x1f
    // 0x90fa80: stur            x4, [fp, #-0x30]
    // 0x90fa84: r5 = 0
    //     0x90fa84: mov             x5, #0
    // 0x90fa88: r1 = 0
    //     0x90fa88: mov             x1, #0
    // 0x90fa8c: stur            x5, [fp, #-0x28]
    // 0x90fa90: CheckStackOverflow
    //     0x90fa90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x90fa94: cmp             SP, x16
    //     0x90fa98: b.ls            #0x90fd80
    // 0x90fa9c: LoadField: r2 = r3->field_b
    //     0x90fa9c: ldur            w2, [x3, #0xb]
    // 0x90faa0: r6 = LoadInt32Instr(r2)
    //     0x90faa0: sbfx            x6, x2, #1, #0x1f
    // 0x90faa4: cmp             x4, x6
    // 0x90faa8: b.ne            #0x90fd58
    // 0x90faac: cmp             x1, x6
    // 0x90fab0: b.ge            #0x90fc00
    // 0x90fab4: LoadField: r2 = r3->field_f
    //     0x90fab4: ldur            w2, [x3, #0xf]
    // 0x90fab8: DecompressPointer r2
    //     0x90fab8: add             x2, x2, HEAP, lsl #32
    // 0x90fabc: ArrayLoad: r6 = r2[r1]  ; Unknown_4
    //     0x90fabc: add             x16, x2, x1, lsl #2
    //     0x90fac0: ldur            w6, [x16, #0xf]
    // 0x90fac4: DecompressPointer r6
    //     0x90fac4: add             x6, x6, HEAP, lsl #32
    // 0x90fac8: stur            x6, [fp, #-0x20]
    // 0x90facc: add             x7, x1, #1
    // 0x90fad0: stur            x7, [fp, #-0x18]
    // 0x90fad4: LoadField: r1 = r0->field_f
    //     0x90fad4: ldur            w1, [x0, #0xf]
    // 0x90fad8: DecompressPointer r1
    //     0x90fad8: add             x1, x1, HEAP, lsl #32
    // 0x90fadc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x90fae0: cmp             w1, w16
    // 0x90fae4: b.eq            #0x90fd88
    // 0x90fae8: LoadField: r2 = r1->field_7
    //     0x90fae8: ldur            w2, [x1, #7]
    // 0x90faec: r1 = LoadInt32Instr(r2)
    //     0x90faec: sbfx            x1, x2, #1, #0x1f
    // 0x90faf0: add             x2, x1, #2
    // 0x90faf4: add             x8, x2, #2
    // 0x90faf8: stur            x8, [fp, #-0x10]
    // 0x90fafc: LoadField: r9 = r6->field_b
    //     0x90fafc: ldur            w9, [x6, #0xb]
    // 0x90fb00: DecompressPointer r9
    //     0x90fb00: add             x9, x9, HEAP, lsl #32
    // 0x90fb04: stur            x9, [fp, #-8]
    // 0x90fb08: r1 = Null
    //     0x90fb08: mov             x1, NULL
    // 0x90fb0c: r2 = 12
    //     0x90fb0c: mov             x2, #0xc
    // 0x90fb10: r0 = AllocateArray()
    //     0x90fb10: bl              #0x13df928  ; AllocateArrayStub
    // 0x90fb14: stur            x0, [fp, #-0x48]
    // 0x90fb18: r16 = "content-disposition"
    //     0x90fb18: add             x16, PP, #0x16, lsl #12  ; [pp+0x167b0] "content-disposition"
    //     0x90fb1c: ldr             x16, [x16, #0x7b0]
    // 0x90fb20: StoreField: r0->field_f = r16
    //     0x90fb20: stur            w16, [x0, #0xf]
    // 0x90fb24: r16 = ": form-data; name=\""
    //     0x90fb24: add             x16, PP, #0x16, lsl #12  ; [pp+0x167b8] ": form-data; name=\""
    //     0x90fb28: ldr             x16, [x16, #0x7b8]
    // 0x90fb2c: StoreField: r0->field_13 = r16
    //     0x90fb2c: stur            w16, [x0, #0x13]
    // 0x90fb30: ldur            x1, [fp, #-0x40]
    // 0x90fb34: ldur            x2, [fp, #-8]
    // 0x90fb38: r0 = _browserEncode()
    //     0x90fb38: bl              #0x9101fc  ; [package:dio/src/form_data.dart] FormData::_browserEncode
    // 0x90fb3c: ldur            x1, [fp, #-0x48]
    // 0x90fb40: ArrayStore: r1[2] = r0  ; List_4
    //     0x90fb40: add             x25, x1, #0x17
    //     0x90fb44: str             w0, [x25]
    //     0x90fb48: tbz             w0, #0, #0x90fb64
    //     0x90fb4c: ldurb           w16, [x1, #-1]
    //     0x90fb50: ldurb           w17, [x0, #-1]
    //     0x90fb54: and             x16, x17, x16, lsr #2
    //     0x90fb58: tst             x16, HEAP, lsr #32
    //     0x90fb5c: b.eq            #0x90fb64
    //     0x90fb60: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x90fb64: ldur            x0, [fp, #-0x48]
    // 0x90fb68: r16 = "\""
    //     0x90fb68: add             x16, PP, #8, lsl #12  ; [pp+0x84a0] "\""
    //     0x90fb6c: ldr             x16, [x16, #0x4a0]
    // 0x90fb70: StoreField: r0->field_1b = r16
    //     0x90fb70: stur            w16, [x0, #0x1b]
    // 0x90fb74: r16 = "\r\n"
    //     0x90fb74: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc00] "\r\n"
    //     0x90fb78: ldr             x16, [x16, #0xc00]
    // 0x90fb7c: StoreField: r0->field_1f = r16
    //     0x90fb7c: stur            w16, [x0, #0x1f]
    // 0x90fb80: r16 = "\r\n"
    //     0x90fb80: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc00] "\r\n"
    //     0x90fb84: ldr             x16, [x16, #0xc00]
    // 0x90fb88: StoreField: r0->field_23 = r16
    //     0x90fb88: stur            w16, [x0, #0x23]
    // 0x90fb8c: str             x0, [SP]
    // 0x90fb90: r0 = _interpolate()
    //     0x90fb90: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x90fb94: mov             x2, x0
    // 0x90fb98: r1 = Instance_Utf8Encoder
    //     0x90fb98: ldr             x1, [PP, #0x11f8]  ; [pp+0x11f8] Obj!Utf8Encoder@12b7f11
    // 0x90fb9c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x90fb9c: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x90fba0: r0 = convert()
    //     0x90fba0: bl              #0x122268c  ; [dart:convert] Utf8Encoder::convert
    // 0x90fba4: LoadField: r1 = r0->field_13
    //     0x90fba4: ldur            w1, [x0, #0x13]
    // 0x90fba8: r0 = LoadInt32Instr(r1)
    //     0x90fba8: sbfx            x0, x1, #1, #0x1f
    // 0x90fbac: ldur            x1, [fp, #-0x10]
    // 0x90fbb0: add             x3, x1, x0
    // 0x90fbb4: ldur            x0, [fp, #-0x20]
    // 0x90fbb8: stur            x3, [fp, #-0x50]
    // 0x90fbbc: LoadField: r2 = r0->field_f
    //     0x90fbbc: ldur            w2, [x0, #0xf]
    // 0x90fbc0: DecompressPointer r2
    //     0x90fbc0: add             x2, x2, HEAP, lsl #32
    // 0x90fbc4: r1 = Instance_Utf8Encoder
    //     0x90fbc4: ldr             x1, [PP, #0x11f8]  ; [pp+0x11f8] Obj!Utf8Encoder@12b7f11
    // 0x90fbc8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x90fbc8: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x90fbcc: r0 = convert()
    //     0x90fbcc: bl              #0x122268c  ; [dart:convert] Utf8Encoder::convert
    // 0x90fbd0: LoadField: r1 = r0->field_13
    //     0x90fbd0: ldur            w1, [x0, #0x13]
    // 0x90fbd4: r0 = LoadInt32Instr(r1)
    //     0x90fbd4: sbfx            x0, x1, #1, #0x1f
    // 0x90fbd8: ldur            x1, [fp, #-0x50]
    // 0x90fbdc: add             x2, x1, x0
    // 0x90fbe0: add             x0, x2, #2
    // 0x90fbe4: ldur            x1, [fp, #-0x28]
    // 0x90fbe8: add             x5, x1, x0
    // 0x90fbec: ldur            x1, [fp, #-0x18]
    // 0x90fbf0: ldur            x0, [fp, #-0x40]
    // 0x90fbf4: ldur            x3, [fp, #-0x38]
    // 0x90fbf8: ldur            x4, [fp, #-0x30]
    // 0x90fbfc: b               #0x90fa8c
    // 0x90fc00: mov             x1, x5
    // 0x90fc04: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x90fc04: ldur            w3, [x0, #0x17]
    // 0x90fc08: DecompressPointer r3
    //     0x90fc08: add             x3, x3, HEAP, lsl #32
    // 0x90fc0c: stur            x3, [fp, #-0x20]
    // 0x90fc10: LoadField: r2 = r3->field_b
    //     0x90fc10: ldur            w2, [x3, #0xb]
    // 0x90fc14: r4 = LoadInt32Instr(r2)
    //     0x90fc14: sbfx            x4, x2, #1, #0x1f
    // 0x90fc18: stur            x4, [fp, #-0x30]
    // 0x90fc1c: mov             x5, x1
    // 0x90fc20: r1 = 0
    //     0x90fc20: mov             x1, #0
    // 0x90fc24: stur            x5, [fp, #-0x28]
    // 0x90fc28: CheckStackOverflow
    //     0x90fc28: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x90fc2c: cmp             SP, x16
    //     0x90fc30: b.ls            #0x90fd94
    // 0x90fc34: LoadField: r2 = r3->field_b
    //     0x90fc34: ldur            w2, [x3, #0xb]
    // 0x90fc38: r6 = LoadInt32Instr(r2)
    //     0x90fc38: sbfx            x6, x2, #1, #0x1f
    // 0x90fc3c: cmp             x4, x6
    // 0x90fc40: b.ne            #0x90fd38
    // 0x90fc44: cmp             x1, x6
    // 0x90fc48: b.ge            #0x90fcfc
    // 0x90fc4c: LoadField: r2 = r3->field_f
    //     0x90fc4c: ldur            w2, [x3, #0xf]
    // 0x90fc50: DecompressPointer r2
    //     0x90fc50: add             x2, x2, HEAP, lsl #32
    // 0x90fc54: ArrayLoad: r6 = r2[r1]  ; Unknown_4
    //     0x90fc54: add             x16, x2, x1, lsl #2
    //     0x90fc58: ldur            w6, [x16, #0xf]
    // 0x90fc5c: DecompressPointer r6
    //     0x90fc5c: add             x6, x6, HEAP, lsl #32
    // 0x90fc60: stur            x6, [fp, #-8]
    // 0x90fc64: add             x7, x1, #1
    // 0x90fc68: stur            x7, [fp, #-0x18]
    // 0x90fc6c: LoadField: r1 = r0->field_f
    //     0x90fc6c: ldur            w1, [x0, #0xf]
    // 0x90fc70: DecompressPointer r1
    //     0x90fc70: add             x1, x1, HEAP, lsl #32
    // 0x90fc74: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x90fc78: cmp             w1, w16
    // 0x90fc7c: b.eq            #0x90fd9c
    // 0x90fc80: LoadField: r2 = r1->field_7
    //     0x90fc80: ldur            w2, [x1, #7]
    // 0x90fc84: r1 = LoadInt32Instr(r2)
    //     0x90fc84: sbfx            x1, x2, #1, #0x1f
    // 0x90fc88: add             x2, x1, #2
    // 0x90fc8c: add             x8, x2, #2
    // 0x90fc90: mov             x1, x0
    // 0x90fc94: mov             x2, x6
    // 0x90fc98: stur            x8, [fp, #-0x10]
    // 0x90fc9c: r0 = _headerForFile()
    //     0x90fc9c: bl              #0x90fe18  ; [package:dio/src/form_data.dart] FormData::_headerForFile
    // 0x90fca0: mov             x2, x0
    // 0x90fca4: r1 = Instance_Utf8Encoder
    //     0x90fca4: ldr             x1, [PP, #0x11f8]  ; [pp+0x11f8] Obj!Utf8Encoder@12b7f11
    // 0x90fca8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x90fca8: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x90fcac: r0 = convert()
    //     0x90fcac: bl              #0x122268c  ; [dart:convert] Utf8Encoder::convert
    // 0x90fcb0: LoadField: r1 = r0->field_13
    //     0x90fcb0: ldur            w1, [x0, #0x13]
    // 0x90fcb4: r0 = LoadInt32Instr(r1)
    //     0x90fcb4: sbfx            x0, x1, #1, #0x1f
    // 0x90fcb8: ldur            x1, [fp, #-0x10]
    // 0x90fcbc: add             x2, x1, x0
    // 0x90fcc0: ldur            x0, [fp, #-8]
    // 0x90fcc4: LoadField: r1 = r0->field_f
    //     0x90fcc4: ldur            w1, [x0, #0xf]
    // 0x90fcc8: DecompressPointer r1
    //     0x90fcc8: add             x1, x1, HEAP, lsl #32
    // 0x90fccc: cmp             w1, NULL
    // 0x90fcd0: b.eq            #0x90fda8
    // 0x90fcd4: LoadField: r0 = r1->field_7
    //     0x90fcd4: ldur            x0, [x1, #7]
    // 0x90fcd8: add             x1, x2, x0
    // 0x90fcdc: add             x0, x1, #2
    // 0x90fce0: ldur            x1, [fp, #-0x28]
    // 0x90fce4: add             x5, x1, x0
    // 0x90fce8: ldur            x1, [fp, #-0x18]
    // 0x90fcec: ldur            x0, [fp, #-0x40]
    // 0x90fcf0: ldur            x3, [fp, #-0x20]
    // 0x90fcf4: ldur            x4, [fp, #-0x30]
    // 0x90fcf8: b               #0x90fc24
    // 0x90fcfc: mov             x1, x5
    // 0x90fd00: add             x2, x1, #2
    // 0x90fd04: LoadField: r1 = r0->field_f
    //     0x90fd04: ldur            w1, [x0, #0xf]
    // 0x90fd08: DecompressPointer r1
    //     0x90fd08: add             x1, x1, HEAP, lsl #32
    // 0x90fd0c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x90fd10: cmp             w1, w16
    // 0x90fd14: b.eq            #0x90fdac
    // 0x90fd18: LoadField: r0 = r1->field_7
    //     0x90fd18: ldur            w0, [x1, #7]
    // 0x90fd1c: r1 = LoadInt32Instr(r0)
    //     0x90fd1c: sbfx            x1, x0, #1, #0x1f
    // 0x90fd20: add             x0, x2, x1
    // 0x90fd24: add             x1, x0, #4
    // 0x90fd28: mov             x0, x1
    // 0x90fd2c: LeaveFrame
    //     0x90fd2c: mov             SP, fp
    //     0x90fd30: ldp             fp, lr, [SP], #0x10
    // 0x90fd34: ret
    //     0x90fd34: ret             
    // 0x90fd38: mov             x0, x3
    // 0x90fd3c: r0 = ConcurrentModificationError()
    //     0x90fd3c: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x90fd40: mov             x1, x0
    // 0x90fd44: ldur            x0, [fp, #-0x20]
    // 0x90fd48: StoreField: r1->field_b = r0
    //     0x90fd48: stur            w0, [x1, #0xb]
    // 0x90fd4c: mov             x0, x1
    // 0x90fd50: r0 = Throw()
    //     0x90fd50: bl              #0x13ddb2c  ; ThrowStub
    // 0x90fd54: brk             #0
    // 0x90fd58: mov             x0, x3
    // 0x90fd5c: r0 = ConcurrentModificationError()
    //     0x90fd5c: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x90fd60: mov             x1, x0
    // 0x90fd64: ldur            x0, [fp, #-0x38]
    // 0x90fd68: StoreField: r1->field_b = r0
    //     0x90fd68: stur            w0, [x1, #0xb]
    // 0x90fd6c: mov             x0, x1
    // 0x90fd70: r0 = Throw()
    //     0x90fd70: bl              #0x13ddb2c  ; ThrowStub
    // 0x90fd74: brk             #0
    // 0x90fd78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x90fd78: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x90fd7c: b               #0x90fa6c
    // 0x90fd80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x90fd80: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x90fd84: b               #0x90fa9c
    // 0x90fd88: r9 = _boundary
    //     0x90fd88: add             x9, PP, #0x16, lsl #12  ; [pp+0x166e0] Field <FormData._boundary@376426596>: late (offset: 0x10)
    //     0x90fd8c: ldr             x9, [x9, #0x6e0]
    // 0x90fd90: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x90fd90: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x90fd94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x90fd94: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x90fd98: b               #0x90fc34
    // 0x90fd9c: r9 = _boundary
    //     0x90fd9c: add             x9, PP, #0x16, lsl #12  ; [pp+0x166e0] Field <FormData._boundary@376426596>: late (offset: 0x10)
    //     0x90fda0: ldr             x9, [x9, #0x6e0]
    // 0x90fda4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x90fda4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x90fda8: r0 = NullErrorSharedWithoutFPURegs()
    //     0x90fda8: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x90fdac: r9 = _boundary
    //     0x90fdac: add             x9, PP, #0x16, lsl #12  ; [pp+0x166e0] Field <FormData._boundary@376426596>: late (offset: 0x10)
    //     0x90fdb0: ldr             x9, [x9, #0x6e0]
    // 0x90fdb4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x90fdb4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  int dyn:get:length(FormData) {
    // ** addr: 0x90fdd0, size: 0x60
    // 0x90fdd0: EnterFrame
    //     0x90fdd0: stp             fp, lr, [SP, #-0x10]!
    //     0x90fdd4: mov             fp, SP
    // 0x90fdd8: CheckStackOverflow
    //     0x90fdd8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x90fddc: cmp             SP, x16
    //     0x90fde0: b.ls            #0x90fe10
    // 0x90fde4: ldr             x1, [fp, #0x10]
    // 0x90fde8: r0 = length()
    //     0x90fde8: bl              #0x90fa4c  ; [package:dio/src/form_data.dart] FormData::length
    // 0x90fdec: mov             x2, x0
    // 0x90fdf0: r0 = BoxInt64Instr(r2)
    //     0x90fdf0: sbfiz           x0, x2, #1, #0x1f
    //     0x90fdf4: cmp             x2, x0, asr #1
    //     0x90fdf8: b.eq            #0x90fe04
    //     0x90fdfc: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x90fe00: stur            x2, [x0, #7]
    // 0x90fe04: LeaveFrame
    //     0x90fe04: mov             SP, fp
    //     0x90fe08: ldp             fp, lr, [SP], #0x10
    // 0x90fe0c: ret
    //     0x90fe0c: ret             
    // 0x90fe10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x90fe10: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x90fe14: b               #0x90fde4
  }
  _ _headerForFile(/* No info */) {
    // ** addr: 0x90fe18, size: 0x288
    // 0x90fe18: EnterFrame
    //     0x90fe18: stp             fp, lr, [SP, #-0x10]!
    //     0x90fe1c: mov             fp, SP
    // 0x90fe20: AllocStack(0x30)
    //     0x90fe20: sub             SP, SP, #0x30
    // 0x90fe24: SetupParameters(FormData this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */)
    //     0x90fe24: mov             x3, x1
    //     0x90fe28: mov             x0, x2
    //     0x90fe2c: stur            x1, [fp, #-0x10]
    //     0x90fe30: stur            x2, [fp, #-0x18]
    // 0x90fe34: CheckStackOverflow
    //     0x90fe34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x90fe38: cmp             SP, x16
    //     0x90fe3c: b.ls            #0x910094
    // 0x90fe40: LoadField: r4 = r0->field_f
    //     0x90fe40: ldur            w4, [x0, #0xf]
    // 0x90fe44: DecompressPointer r4
    //     0x90fe44: add             x4, x4, HEAP, lsl #32
    // 0x90fe48: stur            x4, [fp, #-8]
    // 0x90fe4c: r1 = Null
    //     0x90fe4c: mov             x1, NULL
    // 0x90fe50: r2 = 8
    //     0x90fe50: mov             x2, #8
    // 0x90fe54: r0 = AllocateArray()
    //     0x90fe54: bl              #0x13df928  ; AllocateArrayStub
    // 0x90fe58: stur            x0, [fp, #-0x20]
    // 0x90fe5c: r16 = "content-disposition"
    //     0x90fe5c: add             x16, PP, #0x16, lsl #12  ; [pp+0x167b0] "content-disposition"
    //     0x90fe60: ldr             x16, [x16, #0x7b0]
    // 0x90fe64: StoreField: r0->field_f = r16
    //     0x90fe64: stur            w16, [x0, #0xf]
    // 0x90fe68: r16 = ": form-data; name=\""
    //     0x90fe68: add             x16, PP, #0x16, lsl #12  ; [pp+0x167b8] ": form-data; name=\""
    //     0x90fe6c: ldr             x16, [x16, #0x7b8]
    // 0x90fe70: StoreField: r0->field_13 = r16
    //     0x90fe70: stur            w16, [x0, #0x13]
    // 0x90fe74: ldur            x1, [fp, #-0x18]
    // 0x90fe78: LoadField: r2 = r1->field_b
    //     0x90fe78: ldur            w2, [x1, #0xb]
    // 0x90fe7c: DecompressPointer r2
    //     0x90fe7c: add             x2, x2, HEAP, lsl #32
    // 0x90fe80: ldur            x1, [fp, #-0x10]
    // 0x90fe84: r0 = _browserEncode()
    //     0x90fe84: bl              #0x9101fc  ; [package:dio/src/form_data.dart] FormData::_browserEncode
    // 0x90fe88: ldur            x1, [fp, #-0x20]
    // 0x90fe8c: ArrayStore: r1[2] = r0  ; List_4
    //     0x90fe8c: add             x25, x1, #0x17
    //     0x90fe90: str             w0, [x25]
    //     0x90fe94: tbz             w0, #0, #0x90feb0
    //     0x90fe98: ldurb           w16, [x1, #-1]
    //     0x90fe9c: ldurb           w17, [x0, #-1]
    //     0x90fea0: and             x16, x17, x16, lsr #2
    //     0x90fea4: tst             x16, HEAP, lsr #32
    //     0x90fea8: b.eq            #0x90feb0
    //     0x90feac: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x90feb0: ldur            x0, [fp, #-0x20]
    // 0x90feb4: r16 = "\""
    //     0x90feb4: add             x16, PP, #8, lsl #12  ; [pp+0x84a0] "\""
    //     0x90feb8: ldr             x16, [x16, #0x4a0]
    // 0x90febc: StoreField: r0->field_1b = r16
    //     0x90febc: stur            w16, [x0, #0x1b]
    // 0x90fec0: str             x0, [SP]
    // 0x90fec4: r0 = _interpolate()
    //     0x90fec4: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x90fec8: stur            x0, [fp, #-0x18]
    // 0x90fecc: r1 = 1
    //     0x90fecc: mov             x1, #1
    // 0x90fed0: r0 = AllocateContext()
    //     0x90fed0: bl              #0x13de838  ; AllocateContextStub
    // 0x90fed4: mov             x3, x0
    // 0x90fed8: ldur            x0, [fp, #-0x18]
    // 0x90fedc: stur            x3, [fp, #-0x20]
    // 0x90fee0: StoreField: r3->field_f = r0
    //     0x90fee0: stur            w0, [x3, #0xf]
    // 0x90fee4: ldur            x4, [fp, #-8]
    // 0x90fee8: cmp             w4, NULL
    // 0x90feec: b.eq            #0x91009c
    // 0x90fef0: r1 = Null
    //     0x90fef0: mov             x1, NULL
    // 0x90fef4: r2 = 8
    //     0x90fef4: mov             x2, #8
    // 0x90fef8: r0 = AllocateArray()
    //     0x90fef8: bl              #0x13df928  ; AllocateArrayStub
    // 0x90fefc: mov             x3, x0
    // 0x90ff00: ldur            x0, [fp, #-0x18]
    // 0x90ff04: stur            x3, [fp, #-0x28]
    // 0x90ff08: StoreField: r3->field_f = r0
    //     0x90ff08: stur            w0, [x3, #0xf]
    // 0x90ff0c: r16 = "; filename=\""
    //     0x90ff0c: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c0] "; filename=\""
    //     0x90ff10: ldr             x16, [x16, #0x7c0]
    // 0x90ff14: StoreField: r3->field_13 = r16
    //     0x90ff14: stur            w16, [x3, #0x13]
    // 0x90ff18: ldur            x0, [fp, #-8]
    // 0x90ff1c: LoadField: r2 = r0->field_f
    //     0x90ff1c: ldur            w2, [x0, #0xf]
    // 0x90ff20: DecompressPointer r2
    //     0x90ff20: add             x2, x2, HEAP, lsl #32
    // 0x90ff24: ldur            x1, [fp, #-0x10]
    // 0x90ff28: r0 = _browserEncode()
    //     0x90ff28: bl              #0x9101fc  ; [package:dio/src/form_data.dart] FormData::_browserEncode
    // 0x90ff2c: ldur            x1, [fp, #-0x28]
    // 0x90ff30: ArrayStore: r1[2] = r0  ; List_4
    //     0x90ff30: add             x25, x1, #0x17
    //     0x90ff34: str             w0, [x25]
    //     0x90ff38: tbz             w0, #0, #0x90ff54
    //     0x90ff3c: ldurb           w16, [x1, #-1]
    //     0x90ff40: ldurb           w17, [x0, #-1]
    //     0x90ff44: and             x16, x17, x16, lsr #2
    //     0x90ff48: tst             x16, HEAP, lsr #32
    //     0x90ff4c: b.eq            #0x90ff54
    //     0x90ff50: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x90ff54: ldur            x0, [fp, #-0x28]
    // 0x90ff58: r16 = "\""
    //     0x90ff58: add             x16, PP, #8, lsl #12  ; [pp+0x84a0] "\""
    //     0x90ff5c: ldr             x16, [x16, #0x4a0]
    // 0x90ff60: StoreField: r0->field_1b = r16
    //     0x90ff60: stur            w16, [x0, #0x1b]
    // 0x90ff64: str             x0, [SP]
    // 0x90ff68: r0 = _interpolate()
    //     0x90ff68: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x90ff6c: mov             x4, x0
    // 0x90ff70: ldur            x3, [fp, #-0x20]
    // 0x90ff74: stur            x4, [fp, #-0x10]
    // 0x90ff78: StoreField: r3->field_f = r0
    //     0x90ff78: stur            w0, [x3, #0xf]
    //     0x90ff7c: ldurb           w16, [x3, #-1]
    //     0x90ff80: ldurb           w17, [x0, #-1]
    //     0x90ff84: and             x16, x17, x16, lsr #2
    //     0x90ff88: tst             x16, HEAP, lsr #32
    //     0x90ff8c: b.eq            #0x90ff94
    //     0x90ff90: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x90ff94: r1 = Null
    //     0x90ff94: mov             x1, NULL
    // 0x90ff98: r2 = 8
    //     0x90ff98: mov             x2, #8
    // 0x90ff9c: r0 = AllocateArray()
    //     0x90ff9c: bl              #0x13df928  ; AllocateArrayStub
    // 0x90ffa0: mov             x1, x0
    // 0x90ffa4: ldur            x0, [fp, #-0x10]
    // 0x90ffa8: StoreField: r1->field_f = r0
    //     0x90ffa8: stur            w0, [x1, #0xf]
    // 0x90ffac: r16 = "\r\n"
    //     0x90ffac: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc00] "\r\n"
    //     0x90ffb0: ldr             x16, [x16, #0xc00]
    // 0x90ffb4: StoreField: r1->field_13 = r16
    //     0x90ffb4: stur            w16, [x1, #0x13]
    // 0x90ffb8: r16 = "content-type: "
    //     0x90ffb8: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "content-type: "
    //     0x90ffbc: ldr             x16, [x16, #0x7c8]
    // 0x90ffc0: ArrayStore: r1[0] = r16  ; List_4
    //     0x90ffc0: stur            w16, [x1, #0x17]
    // 0x90ffc4: ldur            x0, [fp, #-8]
    // 0x90ffc8: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x90ffc8: ldur            w2, [x0, #0x17]
    // 0x90ffcc: DecompressPointer r2
    //     0x90ffcc: add             x2, x2, HEAP, lsl #32
    // 0x90ffd0: StoreField: r1->field_1b = r2
    //     0x90ffd0: stur            w2, [x1, #0x1b]
    // 0x90ffd4: str             x1, [SP]
    // 0x90ffd8: r0 = _interpolate()
    //     0x90ffd8: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x90ffdc: ldur            x3, [fp, #-0x20]
    // 0x90ffe0: StoreField: r3->field_f = r0
    //     0x90ffe0: stur            w0, [x3, #0xf]
    //     0x90ffe4: ldurb           w16, [x3, #-1]
    //     0x90ffe8: ldurb           w17, [x0, #-1]
    //     0x90ffec: and             x16, x17, x16, lsr #2
    //     0x90fff0: tst             x16, HEAP, lsr #32
    //     0x90fff4: b.eq            #0x90fffc
    //     0x90fff8: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x90fffc: ldur            x0, [fp, #-8]
    // 0x910000: LoadField: r4 = r0->field_13
    //     0x910000: ldur            w4, [x0, #0x13]
    // 0x910004: DecompressPointer r4
    //     0x910004: add             x4, x4, HEAP, lsl #32
    // 0x910008: mov             x2, x3
    // 0x91000c: stur            x4, [fp, #-0x10]
    // 0x910010: r1 = Function '<anonymous closure>':.
    //     0x910010: add             x1, PP, #0x16, lsl #12  ; [pp+0x167d0] AnonymousClosure: (0x9100a0), in [package:dio/src/form_data.dart] FormData::_headerForFile (0x90fe18)
    //     0x910014: ldr             x1, [x1, #0x7d0]
    // 0x910018: r0 = AllocateClosure()
    //     0x910018: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x91001c: ldur            x1, [fp, #-0x10]
    // 0x910020: r2 = LoadClassIdInstr(r1)
    //     0x910020: ldur            x2, [x1, #-1]
    //     0x910024: ubfx            x2, x2, #0xc, #0x14
    // 0x910028: mov             x16, x0
    // 0x91002c: mov             x0, x2
    // 0x910030: mov             x2, x16
    // 0x910034: r0 = GDT[cid_x0 + 0x6c5]()
    //     0x910034: add             lr, x0, #0x6c5
    //     0x910038: ldr             lr, [x21, lr, lsl #3]
    //     0x91003c: blr             lr
    // 0x910040: ldur            x0, [fp, #-0x20]
    // 0x910044: LoadField: r3 = r0->field_f
    //     0x910044: ldur            w3, [x0, #0xf]
    // 0x910048: DecompressPointer r3
    //     0x910048: add             x3, x3, HEAP, lsl #32
    // 0x91004c: stur            x3, [fp, #-8]
    // 0x910050: r1 = Null
    //     0x910050: mov             x1, NULL
    // 0x910054: r2 = 6
    //     0x910054: mov             x2, #6
    // 0x910058: r0 = AllocateArray()
    //     0x910058: bl              #0x13df928  ; AllocateArrayStub
    // 0x91005c: mov             x1, x0
    // 0x910060: ldur            x0, [fp, #-8]
    // 0x910064: StoreField: r1->field_f = r0
    //     0x910064: stur            w0, [x1, #0xf]
    // 0x910068: r16 = "\r\n"
    //     0x910068: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc00] "\r\n"
    //     0x91006c: ldr             x16, [x16, #0xc00]
    // 0x910070: StoreField: r1->field_13 = r16
    //     0x910070: stur            w16, [x1, #0x13]
    // 0x910074: r16 = "\r\n"
    //     0x910074: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc00] "\r\n"
    //     0x910078: ldr             x16, [x16, #0xc00]
    // 0x91007c: ArrayStore: r1[0] = r16  ; List_4
    //     0x91007c: stur            w16, [x1, #0x17]
    // 0x910080: str             x1, [SP]
    // 0x910084: r0 = _interpolate()
    //     0x910084: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x910088: LeaveFrame
    //     0x910088: mov             SP, fp
    //     0x91008c: ldp             fp, lr, [SP], #0x10
    // 0x910090: ret
    //     0x910090: ret             
    // 0x910094: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x910094: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x910098: b               #0x90fe40
    // 0x91009c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x91009c: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, String, List<String>) {
    // ** addr: 0x9100a0, size: 0x15c
    // 0x9100a0: EnterFrame
    //     0x9100a0: stp             fp, lr, [SP, #-0x10]!
    //     0x9100a4: mov             fp, SP
    // 0x9100a8: AllocStack(0x28)
    //     0x9100a8: sub             SP, SP, #0x28
    // 0x9100ac: SetupParameters([dynamic _ /* r0 */])
    //     0x9100ac: ldr             x0, [fp, #0x20]
    //     0x9100b0: ldur            w2, [x0, #0x17]
    //     0x9100b4: add             x2, x2, HEAP, lsl #32
    //     0x9100b8: stur            x2, [fp, #-8]
    // 0x9100bc: CheckStackOverflow
    //     0x9100bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9100c0: cmp             SP, x16
    //     0x9100c4: b.ls            #0x9101ec
    // 0x9100c8: ldr             x1, [fp, #0x10]
    // 0x9100cc: r0 = LoadClassIdInstr(r1)
    //     0x9100cc: ldur            x0, [x1, #-1]
    //     0x9100d0: ubfx            x0, x0, #0xc, #0x14
    // 0x9100d4: r0 = GDT[cid_x0 + 0x12641]()
    //     0x9100d4: mov             x17, #0x2641
    //     0x9100d8: movk            x17, #1, lsl #16
    //     0x9100dc: add             lr, x0, x17
    //     0x9100e0: ldr             lr, [x21, lr, lsl #3]
    //     0x9100e4: blr             lr
    // 0x9100e8: mov             x2, x0
    // 0x9100ec: stur            x2, [fp, #-0x10]
    // 0x9100f0: ldur            x3, [fp, #-8]
    // 0x9100f4: ldr             x4, [fp, #0x18]
    // 0x9100f8: CheckStackOverflow
    //     0x9100f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9100fc: cmp             SP, x16
    //     0x910100: b.ls            #0x9101f4
    // 0x910104: r0 = LoadClassIdInstr(r2)
    //     0x910104: ldur            x0, [x2, #-1]
    //     0x910108: ubfx            x0, x0, #0xc, #0x14
    // 0x91010c: mov             x1, x2
    // 0x910110: r0 = GDT[cid_x0 + 0x1845b]()
    //     0x910110: mov             x17, #0x845b
    //     0x910114: movk            x17, #1, lsl #16
    //     0x910118: add             lr, x0, x17
    //     0x91011c: ldr             lr, [x21, lr, lsl #3]
    //     0x910120: blr             lr
    // 0x910124: tbnz            w0, #4, #0x9101dc
    // 0x910128: ldr             x4, [fp, #0x18]
    // 0x91012c: ldur            x3, [fp, #-8]
    // 0x910130: ldur            x2, [fp, #-0x10]
    // 0x910134: r0 = LoadClassIdInstr(r2)
    //     0x910134: ldur            x0, [x2, #-1]
    //     0x910138: ubfx            x0, x0, #0xc, #0x14
    // 0x91013c: mov             x1, x2
    // 0x910140: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0x910140: mov             x17, #0x7d4c
    //     0x910144: movk            x17, #1, lsl #16
    //     0x910148: add             lr, x0, x17
    //     0x91014c: ldr             lr, [x21, lr, lsl #3]
    //     0x910150: blr             lr
    // 0x910154: mov             x3, x0
    // 0x910158: ldur            x0, [fp, #-8]
    // 0x91015c: stur            x3, [fp, #-0x20]
    // 0x910160: LoadField: r4 = r0->field_f
    //     0x910160: ldur            w4, [x0, #0xf]
    // 0x910164: DecompressPointer r4
    //     0x910164: add             x4, x4, HEAP, lsl #32
    // 0x910168: stur            x4, [fp, #-0x18]
    // 0x91016c: r1 = Null
    //     0x91016c: mov             x1, NULL
    // 0x910170: r2 = 10
    //     0x910170: mov             x2, #0xa
    // 0x910174: r0 = AllocateArray()
    //     0x910174: bl              #0x13df928  ; AllocateArrayStub
    // 0x910178: mov             x1, x0
    // 0x91017c: ldur            x0, [fp, #-0x18]
    // 0x910180: StoreField: r1->field_f = r0
    //     0x910180: stur            w0, [x1, #0xf]
    // 0x910184: r16 = "\r\n"
    //     0x910184: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc00] "\r\n"
    //     0x910188: ldr             x16, [x16, #0xc00]
    // 0x91018c: StoreField: r1->field_13 = r16
    //     0x91018c: stur            w16, [x1, #0x13]
    // 0x910190: ldr             x0, [fp, #0x18]
    // 0x910194: ArrayStore: r1[0] = r0  ; List_4
    //     0x910194: stur            w0, [x1, #0x17]
    // 0x910198: r16 = ": "
    //     0x910198: ldr             x16, [PP, #0xcb0]  ; [pp+0xcb0] ": "
    // 0x91019c: StoreField: r1->field_1b = r16
    //     0x91019c: stur            w16, [x1, #0x1b]
    // 0x9101a0: ldur            x2, [fp, #-0x20]
    // 0x9101a4: StoreField: r1->field_1f = r2
    //     0x9101a4: stur            w2, [x1, #0x1f]
    // 0x9101a8: str             x1, [SP]
    // 0x9101ac: r0 = _interpolate()
    //     0x9101ac: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x9101b0: ldur            x1, [fp, #-8]
    // 0x9101b4: StoreField: r1->field_f = r0
    //     0x9101b4: stur            w0, [x1, #0xf]
    //     0x9101b8: ldurb           w16, [x1, #-1]
    //     0x9101bc: ldurb           w17, [x0, #-1]
    //     0x9101c0: and             x16, x17, x16, lsr #2
    //     0x9101c4: tst             x16, HEAP, lsr #32
    //     0x9101c8: b.eq            #0x9101d0
    //     0x9101cc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x9101d0: mov             x3, x1
    // 0x9101d4: ldur            x2, [fp, #-0x10]
    // 0x9101d8: b               #0x9100f4
    // 0x9101dc: r0 = Null
    //     0x9101dc: mov             x0, NULL
    // 0x9101e0: LeaveFrame
    //     0x9101e0: mov             SP, fp
    //     0x9101e4: ldp             fp, lr, [SP], #0x10
    // 0x9101e8: ret
    //     0x9101e8: ret             
    // 0x9101ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9101ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9101f0: b               #0x9100c8
    // 0x9101f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9101f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9101f8: b               #0x910104
  }
  _ _browserEncode(/* No info */) {
    // ** addr: 0x9101fc, size: 0xa0
    // 0x9101fc: EnterFrame
    //     0x9101fc: stp             fp, lr, [SP, #-0x10]!
    //     0x910200: mov             fp, SP
    // 0x910204: AllocStack(0x38)
    //     0x910204: sub             SP, SP, #0x38
    // 0x910208: SetupParameters(FormData this /* r1 => r0 */, dynamic _ /* r2 => r1, fp-0x8 */)
    //     0x910208: mov             x0, x1
    //     0x91020c: mov             x1, x2
    //     0x910210: stur            x2, [fp, #-8]
    // 0x910214: CheckStackOverflow
    //     0x910214: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x910218: cmp             SP, x16
    //     0x91021c: b.ls            #0x910294
    // 0x910220: cmp             w1, NULL
    // 0x910224: b.ne            #0x910230
    // 0x910228: r0 = Null
    //     0x910228: mov             x0, NULL
    // 0x91022c: b               #0x910288
    // 0x910230: r16 = "\\r\\n|\\r|\\n"
    //     0x910230: add             x16, PP, #0x16, lsl #12  ; [pp+0x167e0] "\\r\\n|\\r|\\n"
    //     0x910234: ldr             x16, [x16, #0x7e0]
    // 0x910238: stp             x16, NULL, [SP, #0x20]
    // 0x91023c: r16 = false
    //     0x91023c: add             x16, NULL, #0x30  ; false
    // 0x910240: r30 = true
    //     0x910240: add             lr, NULL, #0x20  ; true
    // 0x910244: stp             lr, x16, [SP, #0x10]
    // 0x910248: r16 = false
    //     0x910248: add             x16, NULL, #0x30  ; false
    // 0x91024c: r30 = false
    //     0x91024c: add             lr, NULL, #0x30  ; false
    // 0x910250: stp             lr, x16, [SP]
    // 0x910254: r4 = const [0, 0x6, 0x6, 0x2, caseSensitive, 0x3, dotAll, 0x5, multiLine, 0x2, unicode, 0x4, null]
    //     0x910254: ldr             x4, [PP, #0xa48]  ; [pp+0xa48] List(13) [0, 0x6, 0x6, 0x2, "caseSensitive", 0x3, "dotAll", 0x5, "multiLine", 0x2, "unicode", 0x4, Null]
    // 0x910258: r0 = _RegExp()
    //     0x910258: bl              #0x7eb40c  ; [dart:core] _RegExp::_RegExp
    // 0x91025c: ldur            x1, [fp, #-8]
    // 0x910260: mov             x2, x0
    // 0x910264: r3 = "%0D%0A"
    //     0x910264: add             x3, PP, #0x16, lsl #12  ; [pp+0x167e8] "%0D%0A"
    //     0x910268: ldr             x3, [x3, #0x7e8]
    // 0x91026c: r0 = replaceAll()
    //     0x91026c: bl              #0x7eb6a4  ; [dart:core] _StringBase::replaceAll
    // 0x910270: mov             x1, x0
    // 0x910274: r2 = "\""
    //     0x910274: add             x2, PP, #8, lsl #12  ; [pp+0x84a0] "\""
    //     0x910278: ldr             x2, [x2, #0x4a0]
    // 0x91027c: r3 = "%22"
    //     0x91027c: add             x3, PP, #0x16, lsl #12  ; [pp+0x167f0] "%22"
    //     0x910280: ldr             x3, [x3, #0x7f0]
    // 0x910284: r0 = replaceAll()
    //     0x910284: bl              #0x7eb6a4  ; [dart:core] _StringBase::replaceAll
    // 0x910288: LeaveFrame
    //     0x910288: mov             SP, fp
    //     0x91028c: ldp             fp, lr, [SP], #0x10
    // 0x910290: ret
    //     0x910290: ret             
    // 0x910294: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x910294: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x910298: b               #0x910220
  }
  _ finalize(/* No info */) {
    // ** addr: 0x91029c, size: 0x3c4
    // 0x91029c: EnterFrame
    //     0x91029c: stp             fp, lr, [SP, #-0x10]!
    //     0x9102a0: mov             fp, SP
    // 0x9102a4: AllocStack(0x60)
    //     0x9102a4: sub             SP, SP, #0x60
    // 0x9102a8: SetupParameters(FormData this /* r1 => r1, fp-0x8 */)
    //     0x9102a8: stur            x1, [fp, #-8]
    // 0x9102ac: CheckStackOverflow
    //     0x9102ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9102b0: cmp             SP, x16
    //     0x9102b4: b.ls            #0x910644
    // 0x9102b8: r1 = 4
    //     0x9102b8: mov             x1, #4
    // 0x9102bc: r0 = AllocateContext()
    //     0x9102bc: bl              #0x13de838  ; AllocateContextStub
    // 0x9102c0: mov             x2, x0
    // 0x9102c4: ldur            x0, [fp, #-8]
    // 0x9102c8: stur            x2, [fp, #-0x10]
    // 0x9102cc: StoreField: r2->field_f = r0
    //     0x9102cc: stur            w0, [x2, #0xf]
    // 0x9102d0: LoadField: r1 = r0->field_1b
    //     0x9102d0: ldur            w1, [x0, #0x1b]
    // 0x9102d4: DecompressPointer r1
    //     0x9102d4: add             x1, x1, HEAP, lsl #32
    // 0x9102d8: tbz             w1, #4, #0x910604
    // 0x9102dc: r1 = true
    //     0x9102dc: add             x1, NULL, #0x20  ; true
    // 0x9102e0: StoreField: r0->field_1b = r1
    //     0x9102e0: stur            w1, [x0, #0x1b]
    // 0x9102e4: r16 = false
    //     0x9102e4: add             x16, NULL, #0x30  ; false
    // 0x9102e8: str             x16, [SP]
    // 0x9102ec: r1 = <Uint8List>
    //     0x9102ec: add             x1, PP, #8, lsl #12  ; [pp+0x8548] TypeArguments: <Uint8List>
    //     0x9102f0: ldr             x1, [x1, #0x548]
    // 0x9102f4: r4 = const [0, 0x2, 0x1, 0x1, sync, 0x1, null]
    //     0x9102f4: ldr             x4, [PP, #0x7498]  ; [pp+0x7498] List(7) [0, 0x2, 0x1, 0x1, "sync", 0x1, Null]
    // 0x9102f8: r0 = StreamController()
    //     0x9102f8: bl              #0x811820  ; [dart:async] StreamController::StreamController
    // 0x9102fc: mov             x4, x0
    // 0x910300: ldur            x3, [fp, #-0x10]
    // 0x910304: stur            x4, [fp, #-0x18]
    // 0x910308: StoreField: r3->field_13 = r0
    //     0x910308: stur            w0, [x3, #0x13]
    //     0x91030c: ldurb           w16, [x3, #-1]
    //     0x910310: ldurb           w17, [x0, #-1]
    //     0x910314: and             x16, x17, x16, lsr #2
    //     0x910318: tst             x16, HEAP, lsr #32
    //     0x91031c: b.eq            #0x910324
    //     0x910320: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x910324: mov             x2, x3
    // 0x910328: r1 = Function 'writeLine':.
    //     0x910328: add             x1, PP, #0x16, lsl #12  ; [pp+0x167f8] AnonymousClosure: (0x910ca4), in [package:dio/src/form_data.dart] FormData::finalize (0x91029c)
    //     0x91032c: ldr             x1, [x1, #0x7f8]
    // 0x910330: r0 = AllocateClosure()
    //     0x910330: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x910334: ldur            x3, [fp, #-0x10]
    // 0x910338: ArrayStore: r3[0] = r0  ; List_4
    //     0x910338: stur            w0, [x3, #0x17]
    //     0x91033c: ldurb           w16, [x3, #-1]
    //     0x910340: ldurb           w17, [x0, #-1]
    //     0x910344: and             x16, x17, x16, lsr #2
    //     0x910348: tst             x16, HEAP, lsr #32
    //     0x91034c: b.eq            #0x910354
    //     0x910350: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x910354: mov             x2, x3
    // 0x910358: r1 = Function 'writeUtf8':.
    //     0x910358: add             x1, PP, #0x16, lsl #12  ; [pp+0x16800] AnonymousClosure: (0x910c40), in [package:dio/src/form_data.dart] FormData::finalize (0x91029c)
    //     0x91035c: ldr             x1, [x1, #0x800]
    // 0x910360: r0 = AllocateClosure()
    //     0x910360: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x910364: ldur            x3, [fp, #-0x10]
    // 0x910368: StoreField: r3->field_1b = r0
    //     0x910368: stur            w0, [x3, #0x1b]
    //     0x91036c: ldurb           w16, [x3, #-1]
    //     0x910370: ldurb           w17, [x0, #-1]
    //     0x910374: and             x16, x17, x16, lsr #2
    //     0x910378: tst             x16, HEAP, lsr #32
    //     0x91037c: b.eq            #0x910384
    //     0x910380: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x910384: ldur            x0, [fp, #-8]
    // 0x910388: LoadField: r4 = r0->field_13
    //     0x910388: ldur            w4, [x0, #0x13]
    // 0x91038c: DecompressPointer r4
    //     0x91038c: add             x4, x4, HEAP, lsl #32
    // 0x910390: stur            x4, [fp, #-0x38]
    // 0x910394: LoadField: r1 = r4->field_b
    //     0x910394: ldur            w1, [x4, #0xb]
    // 0x910398: r5 = LoadInt32Instr(r1)
    //     0x910398: sbfx            x5, x1, #1, #0x1f
    // 0x91039c: stur            x5, [fp, #-0x30]
    // 0x9103a0: r1 = 0
    //     0x9103a0: mov             x1, #0
    // 0x9103a4: CheckStackOverflow
    //     0x9103a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9103a8: cmp             SP, x16
    //     0x9103ac: b.ls            #0x91064c
    // 0x9103b0: LoadField: r2 = r4->field_b
    //     0x9103b0: ldur            w2, [x4, #0xb]
    // 0x9103b4: r6 = LoadInt32Instr(r2)
    //     0x9103b4: sbfx            x6, x2, #1, #0x1f
    // 0x9103b8: cmp             x5, x6
    // 0x9103bc: b.ne            #0x910624
    // 0x9103c0: cmp             x1, x6
    // 0x9103c4: b.ge            #0x91056c
    // 0x9103c8: LoadField: r2 = r4->field_f
    //     0x9103c8: ldur            w2, [x4, #0xf]
    // 0x9103cc: DecompressPointer r2
    //     0x9103cc: add             x2, x2, HEAP, lsl #32
    // 0x9103d0: ArrayLoad: r6 = r2[r1]  ; Unknown_4
    //     0x9103d0: add             x16, x2, x1, lsl #2
    //     0x9103d4: ldur            w6, [x16, #0xf]
    // 0x9103d8: DecompressPointer r6
    //     0x9103d8: add             x6, x6, HEAP, lsl #32
    // 0x9103dc: stur            x6, [fp, #-0x28]
    // 0x9103e0: add             x7, x1, #1
    // 0x9103e4: stur            x7, [fp, #-0x20]
    // 0x9103e8: r1 = Null
    //     0x9103e8: mov             x1, NULL
    // 0x9103ec: r2 = 6
    //     0x9103ec: mov             x2, #6
    // 0x9103f0: r0 = AllocateArray()
    //     0x9103f0: bl              #0x13df928  ; AllocateArrayStub
    // 0x9103f4: r16 = "--"
    //     0x9103f4: add             x16, PP, #0x16, lsl #12  ; [pp+0x16808] "--"
    //     0x9103f8: ldr             x16, [x16, #0x808]
    // 0x9103fc: StoreField: r0->field_f = r16
    //     0x9103fc: stur            w16, [x0, #0xf]
    // 0x910400: ldur            x1, [fp, #-8]
    // 0x910404: LoadField: r2 = r1->field_f
    //     0x910404: ldur            w2, [x1, #0xf]
    // 0x910408: DecompressPointer r2
    //     0x910408: add             x2, x2, HEAP, lsl #32
    // 0x91040c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x910410: cmp             w2, w16
    // 0x910414: b.eq            #0x910654
    // 0x910418: StoreField: r0->field_13 = r2
    //     0x910418: stur            w2, [x0, #0x13]
    // 0x91041c: r16 = "\r\n"
    //     0x91041c: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc00] "\r\n"
    //     0x910420: ldr             x16, [x16, #0xc00]
    // 0x910424: ArrayStore: r0[0] = r16  ; List_4
    //     0x910424: stur            w16, [x0, #0x17]
    // 0x910428: str             x0, [SP]
    // 0x91042c: r0 = _interpolate()
    //     0x91042c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x910430: mov             x2, x0
    // 0x910434: r1 = Instance_Utf8Encoder
    //     0x910434: ldr             x1, [PP, #0x11f8]  ; [pp+0x11f8] Obj!Utf8Encoder@12b7f11
    // 0x910438: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x910438: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x91043c: r0 = convert()
    //     0x91043c: bl              #0x122268c  ; [dart:convert] Utf8Encoder::convert
    // 0x910440: ldur            x1, [fp, #-0x18]
    // 0x910444: mov             x2, x0
    // 0x910448: r0 = add()
    //     0x910448: bl              #0x8014f8  ; [dart:async] _StreamController::add
    // 0x91044c: ldur            x0, [fp, #-0x28]
    // 0x910450: LoadField: r3 = r0->field_b
    //     0x910450: ldur            w3, [x0, #0xb]
    // 0x910454: DecompressPointer r3
    //     0x910454: add             x3, x3, HEAP, lsl #32
    // 0x910458: stur            x3, [fp, #-0x40]
    // 0x91045c: r1 = Null
    //     0x91045c: mov             x1, NULL
    // 0x910460: r2 = 12
    //     0x910460: mov             x2, #0xc
    // 0x910464: r0 = AllocateArray()
    //     0x910464: bl              #0x13df928  ; AllocateArrayStub
    // 0x910468: stur            x0, [fp, #-0x48]
    // 0x91046c: r16 = "content-disposition"
    //     0x91046c: add             x16, PP, #0x16, lsl #12  ; [pp+0x167b0] "content-disposition"
    //     0x910470: ldr             x16, [x16, #0x7b0]
    // 0x910474: StoreField: r0->field_f = r16
    //     0x910474: stur            w16, [x0, #0xf]
    // 0x910478: r16 = ": form-data; name=\""
    //     0x910478: add             x16, PP, #0x16, lsl #12  ; [pp+0x167b8] ": form-data; name=\""
    //     0x91047c: ldr             x16, [x16, #0x7b8]
    // 0x910480: StoreField: r0->field_13 = r16
    //     0x910480: stur            w16, [x0, #0x13]
    // 0x910484: ldur            x1, [fp, #-8]
    // 0x910488: ldur            x2, [fp, #-0x40]
    // 0x91048c: r0 = _browserEncode()
    //     0x91048c: bl              #0x9101fc  ; [package:dio/src/form_data.dart] FormData::_browserEncode
    // 0x910490: ldur            x1, [fp, #-0x48]
    // 0x910494: ArrayStore: r1[2] = r0  ; List_4
    //     0x910494: add             x25, x1, #0x17
    //     0x910498: str             w0, [x25]
    //     0x91049c: tbz             w0, #0, #0x9104b8
    //     0x9104a0: ldurb           w16, [x1, #-1]
    //     0x9104a4: ldurb           w17, [x0, #-1]
    //     0x9104a8: and             x16, x17, x16, lsr #2
    //     0x9104ac: tst             x16, HEAP, lsr #32
    //     0x9104b0: b.eq            #0x9104b8
    //     0x9104b4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x9104b8: ldur            x0, [fp, #-0x48]
    // 0x9104bc: r16 = "\""
    //     0x9104bc: add             x16, PP, #8, lsl #12  ; [pp+0x84a0] "\""
    //     0x9104c0: ldr             x16, [x16, #0x4a0]
    // 0x9104c4: StoreField: r0->field_1b = r16
    //     0x9104c4: stur            w16, [x0, #0x1b]
    // 0x9104c8: r16 = "\r\n"
    //     0x9104c8: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc00] "\r\n"
    //     0x9104cc: ldr             x16, [x16, #0xc00]
    // 0x9104d0: StoreField: r0->field_1f = r16
    //     0x9104d0: stur            w16, [x0, #0x1f]
    // 0x9104d4: r16 = "\r\n"
    //     0x9104d4: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc00] "\r\n"
    //     0x9104d8: ldr             x16, [x16, #0xc00]
    // 0x9104dc: StoreField: r0->field_23 = r16
    //     0x9104dc: stur            w16, [x0, #0x23]
    // 0x9104e0: str             x0, [SP]
    // 0x9104e4: r0 = _interpolate()
    //     0x9104e4: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x9104e8: mov             x2, x0
    // 0x9104ec: r1 = Instance_Utf8Encoder
    //     0x9104ec: ldr             x1, [PP, #0x11f8]  ; [pp+0x11f8] Obj!Utf8Encoder@12b7f11
    // 0x9104f0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x9104f0: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x9104f4: r0 = convert()
    //     0x9104f4: bl              #0x122268c  ; [dart:convert] Utf8Encoder::convert
    // 0x9104f8: ldur            x1, [fp, #-0x18]
    // 0x9104fc: mov             x2, x0
    // 0x910500: r0 = add()
    //     0x910500: bl              #0x8014f8  ; [dart:async] _StreamController::add
    // 0x910504: ldur            x0, [fp, #-0x28]
    // 0x910508: LoadField: r2 = r0->field_f
    //     0x910508: ldur            w2, [x0, #0xf]
    // 0x91050c: DecompressPointer r2
    //     0x91050c: add             x2, x2, HEAP, lsl #32
    // 0x910510: r1 = Instance_Utf8Encoder
    //     0x910510: ldr             x1, [PP, #0x11f8]  ; [pp+0x11f8] Obj!Utf8Encoder@12b7f11
    // 0x910514: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x910514: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x910518: r0 = convert()
    //     0x910518: bl              #0x122268c  ; [dart:convert] Utf8Encoder::convert
    // 0x91051c: ldur            x1, [fp, #-0x18]
    // 0x910520: mov             x2, x0
    // 0x910524: r0 = add()
    //     0x910524: bl              #0x8014f8  ; [dart:async] _StreamController::add
    // 0x910528: r0 = LoadStaticField(0xb1c)
    //     0x910528: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x91052c: ldr             x0, [x0, #0x1638]
    // 0x910530: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x910534: cmp             w0, w16
    // 0x910538: b.ne            #0x910548
    // 0x91053c: r2 = _rnU8
    //     0x91053c: add             x2, PP, #0x16, lsl #12  ; [pp+0x16810] Field <::._rnU8@376426596>: static late final (offset: 0xb1c)
    //     0x910540: ldr             x2, [x2, #0x810]
    // 0x910544: r0 = InitLateFinalStaticField()
    //     0x910544: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x910548: ldur            x1, [fp, #-0x18]
    // 0x91054c: mov             x2, x0
    // 0x910550: r0 = add()
    //     0x910550: bl              #0x8014f8  ; [dart:async] _StreamController::add
    // 0x910554: ldur            x1, [fp, #-0x20]
    // 0x910558: ldur            x0, [fp, #-8]
    // 0x91055c: ldur            x3, [fp, #-0x10]
    // 0x910560: ldur            x4, [fp, #-0x38]
    // 0x910564: ldur            x5, [fp, #-0x30]
    // 0x910568: b               #0x9103a4
    // 0x91056c: ldur            x0, [fp, #-0x18]
    // 0x910570: ldur            x2, [fp, #-0x10]
    // 0x910574: r1 = Function '<anonymous closure>':.
    //     0x910574: add             x1, PP, #0x16, lsl #12  ; [pp+0x16818] AnonymousClosure: (0x910794), in [package:dio/src/form_data.dart] FormData::finalize (0x91029c)
    //     0x910578: ldr             x1, [x1, #0x818]
    // 0x91057c: r0 = AllocateClosure()
    //     0x91057c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x910580: mov             x2, x0
    // 0x910584: r1 = <void?>
    //     0x910584: ldr             x1, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x910588: r0 = Future()
    //     0x910588: bl              #0x7f5958  ; [dart:async] Future::Future
    // 0x91058c: ldur            x2, [fp, #-0x10]
    // 0x910590: r1 = Function '<anonymous closure>':.
    //     0x910590: add             x1, PP, #0x16, lsl #12  ; [pp+0x16820] AnonymousClosure: (0x9106a8), in [package:dio/src/form_data.dart] FormData::finalize (0x91029c)
    //     0x910594: ldr             x1, [x1, #0x820]
    // 0x910598: stur            x0, [fp, #-8]
    // 0x91059c: r0 = AllocateClosure()
    //     0x91059c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x9105a0: r16 = <Null?>
    //     0x9105a0: ldr             x16, [PP, #0x70]  ; [pp+0x70] TypeArguments: <Null?>
    // 0x9105a4: ldur            lr, [fp, #-8]
    // 0x9105a8: stp             lr, x16, [SP, #8]
    // 0x9105ac: str             x0, [SP]
    // 0x9105b0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x9105b0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x9105b4: r0 = then()
    //     0x9105b4: bl              #0x1293070  ; [dart:async] _Future::then
    // 0x9105b8: ldur            x2, [fp, #-0x10]
    // 0x9105bc: r1 = Function '<anonymous closure>':.
    //     0x9105bc: add             x1, PP, #0x16, lsl #12  ; [pp+0x16828] AnonymousClosure: (0x910660), in [package:dio/src/form_data.dart] FormData::finalize (0x91029c)
    //     0x9105c0: ldr             x1, [x1, #0x828]
    // 0x9105c4: stur            x0, [fp, #-8]
    // 0x9105c8: r0 = AllocateClosure()
    //     0x9105c8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x9105cc: ldur            x1, [fp, #-8]
    // 0x9105d0: mov             x2, x0
    // 0x9105d4: r0 = whenComplete()
    //     0x9105d4: bl              #0x1292f08  ; [dart:async] _Future::whenComplete
    // 0x9105d8: ldur            x0, [fp, #-0x18]
    // 0x9105dc: LoadField: r1 = r0->field_7
    //     0x9105dc: ldur            w1, [x0, #7]
    // 0x9105e0: DecompressPointer r1
    //     0x9105e0: add             x1, x1, HEAP, lsl #32
    // 0x9105e4: r0 = _ControllerStream()
    //     0x9105e4: bl              #0x810928  ; Allocate_ControllerStreamStub -> _ControllerStream<X0> (size=0x10)
    // 0x9105e8: mov             x1, x0
    // 0x9105ec: ldur            x0, [fp, #-0x18]
    // 0x9105f0: StoreField: r1->field_b = r0
    //     0x9105f0: stur            w0, [x1, #0xb]
    // 0x9105f4: mov             x0, x1
    // 0x9105f8: LeaveFrame
    //     0x9105f8: mov             SP, fp
    //     0x9105fc: ldp             fp, lr, [SP], #0x10
    // 0x910600: ret
    //     0x910600: ret             
    // 0x910604: r0 = StateError()
    //     0x910604: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x910608: mov             x1, x0
    // 0x91060c: r0 = "The FormData has already been finalized. This typically means you are using the same FormData in repeated requests."
    //     0x91060c: add             x0, PP, #0x16, lsl #12  ; [pp+0x16830] "The FormData has already been finalized. This typically means you are using the same FormData in repeated requests."
    //     0x910610: ldr             x0, [x0, #0x830]
    // 0x910614: StoreField: r1->field_b = r0
    //     0x910614: stur            w0, [x1, #0xb]
    // 0x910618: mov             x0, x1
    // 0x91061c: r0 = Throw()
    //     0x91061c: bl              #0x13ddb2c  ; ThrowStub
    // 0x910620: brk             #0
    // 0x910624: mov             x0, x4
    // 0x910628: r0 = ConcurrentModificationError()
    //     0x910628: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x91062c: mov             x1, x0
    // 0x910630: ldur            x0, [fp, #-0x38]
    // 0x910634: StoreField: r1->field_b = r0
    //     0x910634: stur            w0, [x1, #0xb]
    // 0x910638: mov             x0, x1
    // 0x91063c: r0 = Throw()
    //     0x91063c: bl              #0x13ddb2c  ; ThrowStub
    // 0x910640: brk             #0
    // 0x910644: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x910644: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x910648: b               #0x9102b8
    // 0x91064c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91064c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x910650: b               #0x9103b0
    // 0x910654: r9 = _boundary
    //     0x910654: add             x9, PP, #0x16, lsl #12  ; [pp+0x166e0] Field <FormData._boundary@376426596>: late (offset: 0x10)
    //     0x910658: ldr             x9, [x9, #0x6e0]
    // 0x91065c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x91065c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Null <anonymous closure>(dynamic) {
    // ** addr: 0x910660, size: 0x48
    // 0x910660: EnterFrame
    //     0x910660: stp             fp, lr, [SP, #-0x10]!
    //     0x910664: mov             fp, SP
    // 0x910668: ldr             x0, [fp, #0x10]
    // 0x91066c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x91066c: ldur            w1, [x0, #0x17]
    // 0x910670: DecompressPointer r1
    //     0x910670: add             x1, x1, HEAP, lsl #32
    // 0x910674: CheckStackOverflow
    //     0x910674: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x910678: cmp             SP, x16
    //     0x91067c: b.ls            #0x9106a0
    // 0x910680: LoadField: r0 = r1->field_13
    //     0x910680: ldur            w0, [x1, #0x13]
    // 0x910684: DecompressPointer r0
    //     0x910684: add             x0, x0, HEAP, lsl #32
    // 0x910688: mov             x1, x0
    // 0x91068c: r0 = close()
    //     0x91068c: bl              #0x811f40  ; [dart:async] _StreamController::close
    // 0x910690: r0 = Null
    //     0x910690: mov             x0, NULL
    // 0x910694: LeaveFrame
    //     0x910694: mov             SP, fp
    //     0x910698: ldp             fp, lr, [SP], #0x10
    // 0x91069c: ret
    //     0x91069c: ret             
    // 0x9106a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9106a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9106a4: b               #0x910680
  }
  [closure] Null <anonymous closure>(dynamic, void) {
    // ** addr: 0x9106a8, size: 0xec
    // 0x9106a8: EnterFrame
    //     0x9106a8: stp             fp, lr, [SP, #-0x10]!
    //     0x9106ac: mov             fp, SP
    // 0x9106b0: AllocStack(0x18)
    //     0x9106b0: sub             SP, SP, #0x18
    // 0x9106b4: SetupParameters([dynamic _ /* r0 */])
    //     0x9106b4: ldr             x0, [fp, #0x18]
    //     0x9106b8: ldur            w3, [x0, #0x17]
    //     0x9106bc: add             x3, x3, HEAP, lsl #32
    //     0x9106c0: stur            x3, [fp, #-0x10]
    // 0x9106c4: CheckStackOverflow
    //     0x9106c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9106c8: cmp             SP, x16
    //     0x9106cc: b.ls            #0x910780
    // 0x9106d0: LoadField: r0 = r3->field_1b
    //     0x9106d0: ldur            w0, [x3, #0x1b]
    // 0x9106d4: DecompressPointer r0
    //     0x9106d4: add             x0, x0, HEAP, lsl #32
    // 0x9106d8: stur            x0, [fp, #-8]
    // 0x9106dc: r1 = Null
    //     0x9106dc: mov             x1, NULL
    // 0x9106e0: r2 = 8
    //     0x9106e0: mov             x2, #8
    // 0x9106e4: r0 = AllocateArray()
    //     0x9106e4: bl              #0x13df928  ; AllocateArrayStub
    // 0x9106e8: r16 = "--"
    //     0x9106e8: add             x16, PP, #0x16, lsl #12  ; [pp+0x16808] "--"
    //     0x9106ec: ldr             x16, [x16, #0x808]
    // 0x9106f0: StoreField: r0->field_f = r16
    //     0x9106f0: stur            w16, [x0, #0xf]
    // 0x9106f4: ldur            x1, [fp, #-0x10]
    // 0x9106f8: LoadField: r2 = r1->field_f
    //     0x9106f8: ldur            w2, [x1, #0xf]
    // 0x9106fc: DecompressPointer r2
    //     0x9106fc: add             x2, x2, HEAP, lsl #32
    // 0x910700: LoadField: r1 = r2->field_f
    //     0x910700: ldur            w1, [x2, #0xf]
    // 0x910704: DecompressPointer r1
    //     0x910704: add             x1, x1, HEAP, lsl #32
    // 0x910708: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x91070c: cmp             w1, w16
    // 0x910710: b.eq            #0x910788
    // 0x910714: StoreField: r0->field_13 = r1
    //     0x910714: stur            w1, [x0, #0x13]
    // 0x910718: r16 = "--"
    //     0x910718: add             x16, PP, #0x16, lsl #12  ; [pp+0x16808] "--"
    //     0x91071c: ldr             x16, [x16, #0x808]
    // 0x910720: ArrayStore: r0[0] = r16  ; List_4
    //     0x910720: stur            w16, [x0, #0x17]
    // 0x910724: r16 = "\r\n"
    //     0x910724: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc00] "\r\n"
    //     0x910728: ldr             x16, [x16, #0xc00]
    // 0x91072c: StoreField: r0->field_1b = r16
    //     0x91072c: stur            w16, [x0, #0x1b]
    // 0x910730: str             x0, [SP]
    // 0x910734: r0 = _interpolate()
    //     0x910734: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x910738: mov             x1, x0
    // 0x91073c: ldur            x0, [fp, #-8]
    // 0x910740: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x910740: ldur            w2, [x0, #0x17]
    // 0x910744: DecompressPointer r2
    //     0x910744: add             x2, x2, HEAP, lsl #32
    // 0x910748: LoadField: r0 = r2->field_13
    //     0x910748: ldur            w0, [x2, #0x13]
    // 0x91074c: DecompressPointer r0
    //     0x91074c: add             x0, x0, HEAP, lsl #32
    // 0x910750: mov             x2, x1
    // 0x910754: stur            x0, [fp, #-8]
    // 0x910758: r1 = Instance_Utf8Encoder
    //     0x910758: ldr             x1, [PP, #0x11f8]  ; [pp+0x11f8] Obj!Utf8Encoder@12b7f11
    // 0x91075c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x91075c: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x910760: r0 = convert()
    //     0x910760: bl              #0x122268c  ; [dart:convert] Utf8Encoder::convert
    // 0x910764: ldur            x1, [fp, #-8]
    // 0x910768: mov             x2, x0
    // 0x91076c: r0 = add()
    //     0x91076c: bl              #0x8014f8  ; [dart:async] _StreamController::add
    // 0x910770: r0 = Null
    //     0x910770: mov             x0, NULL
    // 0x910774: LeaveFrame
    //     0x910774: mov             SP, fp
    //     0x910778: ldp             fp, lr, [SP], #0x10
    // 0x91077c: ret
    //     0x91077c: ret             
    // 0x910780: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x910780: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x910784: b               #0x9106d0
    // 0x910788: r9 = _boundary
    //     0x910788: add             x9, PP, #0x16, lsl #12  ; [pp+0x166e0] Field <FormData._boundary@376426596>: late (offset: 0x10)
    //     0x91078c: ldr             x9, [x9, #0x6e0]
    // 0x910790: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x910790: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> <anonymous closure>(dynamic) async {
    // ** addr: 0x910794, size: 0x380
    // 0x910794: EnterFrame
    //     0x910794: stp             fp, lr, [SP, #-0x10]!
    //     0x910798: mov             fp, SP
    // 0x91079c: AllocStack(0x80)
    //     0x91079c: sub             SP, SP, #0x80
    // 0x9107a0: SetupParameters(FormData this /* r1 */)
    //     0x9107a0: stur            NULL, [fp, #-8]
    //     0x9107a4: mov             x0, #0
    //     0x9107a8: add             x1, fp, w0, sxtw #2
    //     0x9107ac: ldr             x1, [x1, #0x10]
    //     0x9107b0: ldur            w2, [x1, #0x17]
    //     0x9107b4: add             x2, x2, HEAP, lsl #32
    //     0x9107b8: stur            x2, [fp, #-0x10]
    // 0x9107bc: CheckStackOverflow
    //     0x9107bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9107c0: cmp             SP, x16
    //     0x9107c4: b.ls            #0x910af4
    // 0x9107c8: InitAsync() -> Future<void?>
    //     0x9107c8: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0x9107cc: bl              #0x7f5e44  ; InitAsyncStub
    // 0x9107d0: ldur            x0, [fp, #-0x10]
    // 0x9107d4: LoadField: r1 = r0->field_f
    //     0x9107d4: ldur            w1, [x0, #0xf]
    // 0x9107d8: DecompressPointer r1
    //     0x9107d8: add             x1, x1, HEAP, lsl #32
    // 0x9107dc: ArrayLoad: r3 = r1[0]  ; List_4
    //     0x9107dc: ldur            w3, [x1, #0x17]
    // 0x9107e0: DecompressPointer r3
    //     0x9107e0: add             x3, x3, HEAP, lsl #32
    // 0x9107e4: stur            x3, [fp, #-0x30]
    // 0x9107e8: LoadField: r1 = r3->field_b
    //     0x9107e8: ldur            w1, [x3, #0xb]
    // 0x9107ec: r4 = LoadInt32Instr(r1)
    //     0x9107ec: sbfx            x4, x1, #1, #0x1f
    // 0x9107f0: stur            x4, [fp, #-0x28]
    // 0x9107f4: LoadField: r1 = r0->field_1b
    //     0x9107f4: ldur            w1, [x0, #0x1b]
    // 0x9107f8: DecompressPointer r1
    //     0x9107f8: add             x1, x1, HEAP, lsl #32
    // 0x9107fc: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x9107fc: ldur            w2, [x1, #0x17]
    // 0x910800: DecompressPointer r2
    //     0x910800: add             x2, x2, HEAP, lsl #32
    // 0x910804: LoadField: r5 = r2->field_13
    //     0x910804: ldur            w5, [x2, #0x13]
    // 0x910808: DecompressPointer r5
    //     0x910808: add             x5, x5, HEAP, lsl #32
    // 0x91080c: stur            x5, [fp, #-0x20]
    // 0x910810: LoadField: r6 = r0->field_13
    //     0x910810: ldur            w6, [x0, #0x13]
    // 0x910814: DecompressPointer r6
    //     0x910814: add             x6, x6, HEAP, lsl #32
    // 0x910818: mov             x2, x6
    // 0x91081c: stur            x6, [fp, #-0x18]
    // 0x910820: r1 = Function 'add':.
    //     0x910820: ldr             x1, [PP, #0x35e8]  ; [pp+0x35e8] AnonymousClosure: (0x80158c), in [dart:async] _StreamController::add (0x8014f8)
    // 0x910824: r0 = AllocateClosure()
    //     0x910824: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x910828: ldur            x2, [fp, #-0x18]
    // 0x91082c: r1 = Function 'addError':.
    //     0x91082c: add             x1, PP, #0xc, lsl #12  ; [pp+0xc448] AnonymousClosure: (0x828d90), in [dart:async] _StreamController::addError (0x828cfc)
    //     0x910830: ldr             x1, [x1, #0x448]
    // 0x910834: stur            x0, [fp, #-0x18]
    // 0x910838: r0 = AllocateClosure()
    //     0x910838: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x91083c: mov             x3, x0
    // 0x910840: ldur            x0, [fp, #-0x10]
    // 0x910844: stur            x3, [fp, #-0x50]
    // 0x910848: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x910848: ldur            w1, [x0, #0x17]
    // 0x91084c: DecompressPointer r1
    //     0x91084c: add             x1, x1, HEAP, lsl #32
    // 0x910850: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x910850: ldur            w2, [x1, #0x17]
    // 0x910854: DecompressPointer r2
    //     0x910854: add             x2, x2, HEAP, lsl #32
    // 0x910858: LoadField: r4 = r2->field_13
    //     0x910858: ldur            w4, [x2, #0x13]
    // 0x91085c: DecompressPointer r4
    //     0x91085c: add             x4, x4, HEAP, lsl #32
    // 0x910860: stur            x4, [fp, #-0x48]
    // 0x910864: r1 = 0
    //     0x910864: mov             x1, #0
    // 0x910868: ldur            x5, [fp, #-0x30]
    // 0x91086c: ldur            x6, [fp, #-0x28]
    // 0x910870: CheckStackOverflow
    //     0x910870: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x910874: cmp             SP, x16
    //     0x910878: b.ls            #0x910afc
    // 0x91087c: LoadField: r2 = r5->field_b
    //     0x91087c: ldur            w2, [x5, #0xb]
    // 0x910880: r7 = LoadInt32Instr(r2)
    //     0x910880: sbfx            x7, x2, #1, #0x1f
    // 0x910884: cmp             x6, x7
    // 0x910888: b.ne            #0x910ad4
    // 0x91088c: cmp             x1, x7
    // 0x910890: b.ge            #0x910aac
    // 0x910894: LoadField: r2 = r5->field_f
    //     0x910894: ldur            w2, [x5, #0xf]
    // 0x910898: DecompressPointer r2
    //     0x910898: add             x2, x2, HEAP, lsl #32
    // 0x91089c: ArrayLoad: r7 = r2[r1]  ; Unknown_4
    //     0x91089c: add             x16, x2, x1, lsl #2
    //     0x9108a0: ldur            w7, [x16, #0xf]
    // 0x9108a4: DecompressPointer r7
    //     0x9108a4: add             x7, x7, HEAP, lsl #32
    // 0x9108a8: stur            x7, [fp, #-0x40]
    // 0x9108ac: add             x8, x1, #1
    // 0x9108b0: stur            x8, [fp, #-0x38]
    // 0x9108b4: r1 = Null
    //     0x9108b4: mov             x1, NULL
    // 0x9108b8: r2 = 6
    //     0x9108b8: mov             x2, #6
    // 0x9108bc: r0 = AllocateArray()
    //     0x9108bc: bl              #0x13df928  ; AllocateArrayStub
    // 0x9108c0: r16 = "--"
    //     0x9108c0: add             x16, PP, #0x16, lsl #12  ; [pp+0x16808] "--"
    //     0x9108c4: ldr             x16, [x16, #0x808]
    // 0x9108c8: StoreField: r0->field_f = r16
    //     0x9108c8: stur            w16, [x0, #0xf]
    // 0x9108cc: ldur            x1, [fp, #-0x10]
    // 0x9108d0: LoadField: r2 = r1->field_f
    //     0x9108d0: ldur            w2, [x1, #0xf]
    // 0x9108d4: DecompressPointer r2
    //     0x9108d4: add             x2, x2, HEAP, lsl #32
    // 0x9108d8: LoadField: r3 = r2->field_f
    //     0x9108d8: ldur            w3, [x2, #0xf]
    // 0x9108dc: DecompressPointer r3
    //     0x9108dc: add             x3, x3, HEAP, lsl #32
    // 0x9108e0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9108e4: cmp             w3, w16
    // 0x9108e8: b.eq            #0x910b04
    // 0x9108ec: StoreField: r0->field_13 = r3
    //     0x9108ec: stur            w3, [x0, #0x13]
    // 0x9108f0: r16 = "\r\n"
    //     0x9108f0: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc00] "\r\n"
    //     0x9108f4: ldr             x16, [x16, #0xc00]
    // 0x9108f8: ArrayStore: r0[0] = r16  ; List_4
    //     0x9108f8: stur            w16, [x0, #0x17]
    // 0x9108fc: str             x0, [SP]
    // 0x910900: r0 = _interpolate()
    //     0x910900: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x910904: mov             x2, x0
    // 0x910908: r1 = Instance_Utf8Encoder
    //     0x910908: ldr             x1, [PP, #0x11f8]  ; [pp+0x11f8] Obj!Utf8Encoder@12b7f11
    // 0x91090c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x91090c: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x910910: r0 = convert()
    //     0x910910: bl              #0x122268c  ; [dart:convert] Utf8Encoder::convert
    // 0x910914: ldur            x1, [fp, #-0x20]
    // 0x910918: mov             x2, x0
    // 0x91091c: r0 = add()
    //     0x91091c: bl              #0x8014f8  ; [dart:async] _StreamController::add
    // 0x910920: ldur            x0, [fp, #-0x10]
    // 0x910924: LoadField: r1 = r0->field_f
    //     0x910924: ldur            w1, [x0, #0xf]
    // 0x910928: DecompressPointer r1
    //     0x910928: add             x1, x1, HEAP, lsl #32
    // 0x91092c: ldur            x2, [fp, #-0x40]
    // 0x910930: r0 = _headerForFile()
    //     0x910930: bl              #0x90fe18  ; [package:dio/src/form_data.dart] FormData::_headerForFile
    // 0x910934: mov             x2, x0
    // 0x910938: r1 = Instance_Utf8Encoder
    //     0x910938: ldr             x1, [PP, #0x11f8]  ; [pp+0x11f8] Obj!Utf8Encoder@12b7f11
    // 0x91093c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x91093c: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x910940: r0 = convert()
    //     0x910940: bl              #0x122268c  ; [dart:convert] Utf8Encoder::convert
    // 0x910944: ldur            x1, [fp, #-0x20]
    // 0x910948: mov             x2, x0
    // 0x91094c: r0 = add()
    //     0x91094c: bl              #0x8014f8  ; [dart:async] _StreamController::add
    // 0x910950: ldur            x1, [fp, #-0x40]
    // 0x910954: LoadField: r0 = r1->field_f
    //     0x910954: ldur            w0, [x1, #0xf]
    // 0x910958: DecompressPointer r0
    //     0x910958: add             x0, x0, HEAP, lsl #32
    // 0x91095c: cmp             w0, NULL
    // 0x910960: b.eq            #0x910b10
    // 0x910964: LoadField: r2 = r0->field_1f
    //     0x910964: ldur            w2, [x0, #0x1f]
    // 0x910968: DecompressPointer r2
    //     0x910968: add             x2, x2, HEAP, lsl #32
    // 0x91096c: tbz             w2, #4, #0x910ab4
    // 0x910970: r2 = true
    //     0x910970: add             x2, NULL, #0x20  ; true
    // 0x910974: StoreField: r0->field_1f = r2
    //     0x910974: stur            w2, [x0, #0x1f]
    // 0x910978: LoadField: r3 = r0->field_1b
    //     0x910978: ldur            w3, [x0, #0x1b]
    // 0x91097c: DecompressPointer r3
    //     0x91097c: add             x3, x3, HEAP, lsl #32
    // 0x910980: str             x3, [SP]
    // 0x910984: mov             x0, x3
    // 0x910988: ClosureCall
    //     0x910988: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x91098c: ldur            x2, [x0, #0x1f]
    //     0x910990: blr             x2
    // 0x910994: r1 = Function '<anonymous closure>':.
    //     0x910994: add             x1, PP, #0x16, lsl #12  ; [pp+0x16838] AnonymousClosure: (0x910b60), of [package:dio/src/multipart_file.dart] MultipartFile
    //     0x910998: ldr             x1, [x1, #0x838]
    // 0x91099c: r2 = Null
    //     0x91099c: mov             x2, NULL
    // 0x9109a0: stur            x0, [fp, #-0x58]
    // 0x9109a4: r0 = AllocateClosure()
    //     0x9109a4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x9109a8: r16 = <Uint8List>
    //     0x9109a8: add             x16, PP, #8, lsl #12  ; [pp+0x8548] TypeArguments: <Uint8List>
    //     0x9109ac: ldr             x16, [x16, #0x548]
    // 0x9109b0: ldur            lr, [fp, #-0x58]
    // 0x9109b4: stp             lr, x16, [SP, #8]
    // 0x9109b8: str             x0, [SP]
    // 0x9109bc: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x9109bc: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x9109c0: r0 = map()
    //     0x9109c0: bl              #0x8c354c  ; [dart:async] Stream::map
    // 0x9109c4: r1 = <void?>
    //     0x9109c4: ldr             x1, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x9109c8: stur            x0, [fp, #-0x58]
    // 0x9109cc: r0 = _Future()
    //     0x9109cc: bl              #0x7f5dd4  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0x9109d0: stur            x0, [fp, #-0x60]
    // 0x9109d4: StoreField: r0->field_b = rZR
    //     0x9109d4: stur            xzr, [x0, #0xb]
    // 0x9109d8: r0 = LoadStaticField(0x364)
    //     0x9109d8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x9109dc: ldr             x0, [x0, #0x6c8]
    // 0x9109e0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9109e4: cmp             w0, w16
    // 0x9109e8: b.ne            #0x9109f4
    // 0x9109ec: r2 = _current
    //     0x9109ec: ldr             x2, [PP, #0x2c0]  ; [pp+0x2c0] Field <Zone._current@5048458>: static late (offset: 0x364)
    // 0x9109f0: r0 = InitLateStaticField()
    //     0x9109f0: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0x9109f4: mov             x1, x0
    // 0x9109f8: ldur            x0, [fp, #-0x60]
    // 0x9109fc: StoreField: r0->field_13 = r1
    //     0x9109fc: stur            w1, [x0, #0x13]
    // 0x910a00: r1 = <void?>
    //     0x910a00: ldr             x1, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x910a04: r0 = _AsyncCompleter()
    //     0x910a04: bl              #0x7f5dc8  ; Allocate_AsyncCompleterStub -> _AsyncCompleter<X0> (size=0x10)
    // 0x910a08: mov             x1, x0
    // 0x910a0c: ldur            x0, [fp, #-0x60]
    // 0x910a10: stur            x1, [fp, #-0x68]
    // 0x910a14: StoreField: r1->field_b = r0
    //     0x910a14: stur            w0, [x1, #0xb]
    // 0x910a18: r1 = 1
    //     0x910a18: mov             x1, #1
    // 0x910a1c: r0 = AllocateContext()
    //     0x910a1c: bl              #0x13de838  ; AllocateContextStub
    // 0x910a20: mov             x1, x0
    // 0x910a24: ldur            x0, [fp, #-0x68]
    // 0x910a28: StoreField: r1->field_f = r0
    //     0x910a28: stur            w0, [x1, #0xf]
    // 0x910a2c: mov             x2, x1
    // 0x910a30: r1 = Function '<anonymous closure>': static.
    //     0x910a30: add             x1, PP, #0x16, lsl #12  ; [pp+0x16840] AnonymousClosure: static (0x910b14), of [package:dio/src/utils.dart] 
    //     0x910a34: ldr             x1, [x1, #0x840]
    // 0x910a38: r0 = AllocateClosure()
    //     0x910a38: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x910a3c: mov             x1, x0
    // 0x910a40: r0 = <Uint8List>
    //     0x910a40: add             x0, PP, #8, lsl #12  ; [pp+0x8548] TypeArguments: <Uint8List>
    //     0x910a44: ldr             x0, [x0, #0x548]
    // 0x910a48: StoreField: r1->field_b = r0
    //     0x910a48: stur            w0, [x1, #0xb]
    // 0x910a4c: ldur            x16, [fp, #-0x50]
    // 0x910a50: stp             x1, x16, [SP]
    // 0x910a54: ldur            x1, [fp, #-0x58]
    // 0x910a58: ldur            x2, [fp, #-0x18]
    // 0x910a5c: r4 = const [0, 0x4, 0x2, 0x2, onDone, 0x3, onError, 0x2, null]
    //     0x910a5c: ldr             x4, [PP, #0x220]  ; [pp+0x220] List(9) [0, 0x4, 0x2, 0x2, "onDone", 0x3, "onError", 0x2, Null]
    // 0x910a60: r0 = listen()
    //     0x910a60: bl              #0x123a980  ; [dart:async] _ForwardingStream::listen
    // 0x910a64: ldur            x0, [fp, #-0x60]
    // 0x910a68: r0 = Await()
    //     0x910a68: bl              #0x7f5c00  ; AwaitStub
    // 0x910a6c: r0 = LoadStaticField(0xb1c)
    //     0x910a6c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x910a70: ldr             x0, [x0, #0x1638]
    // 0x910a74: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x910a78: cmp             w0, w16
    // 0x910a7c: b.ne            #0x910a8c
    // 0x910a80: r2 = _rnU8
    //     0x910a80: add             x2, PP, #0x16, lsl #12  ; [pp+0x16810] Field <::._rnU8@376426596>: static late final (offset: 0xb1c)
    //     0x910a84: ldr             x2, [x2, #0x810]
    // 0x910a88: r0 = InitLateFinalStaticField()
    //     0x910a88: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x910a8c: ldur            x1, [fp, #-0x48]
    // 0x910a90: mov             x2, x0
    // 0x910a94: r0 = add()
    //     0x910a94: bl              #0x8014f8  ; [dart:async] _StreamController::add
    // 0x910a98: ldur            x1, [fp, #-0x38]
    // 0x910a9c: ldur            x0, [fp, #-0x10]
    // 0x910aa0: ldur            x4, [fp, #-0x48]
    // 0x910aa4: ldur            x3, [fp, #-0x50]
    // 0x910aa8: b               #0x910868
    // 0x910aac: r0 = Null
    //     0x910aac: mov             x0, NULL
    // 0x910ab0: r0 = ReturnAsyncNotFuture()
    //     0x910ab0: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x910ab4: r0 = StateError()
    //     0x910ab4: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x910ab8: mov             x1, x0
    // 0x910abc: r0 = "The MultipartFile has already been finalized. This typically means you are using the same MultipartFile in repeated requests.\nUse MultipartFile.clone() or create a new MultipartFile for further usages."
    //     0x910abc: add             x0, PP, #0x16, lsl #12  ; [pp+0x16848] "The MultipartFile has already been finalized. This typically means you are using the same MultipartFile in repeated requests.\nUse MultipartFile.clone() or create a new MultipartFile for further usages."
    //     0x910ac0: ldr             x0, [x0, #0x848]
    // 0x910ac4: StoreField: r1->field_b = r0
    //     0x910ac4: stur            w0, [x1, #0xb]
    // 0x910ac8: mov             x0, x1
    // 0x910acc: r0 = Throw()
    //     0x910acc: bl              #0x13ddb2c  ; ThrowStub
    // 0x910ad0: brk             #0
    // 0x910ad4: mov             x0, x5
    // 0x910ad8: r0 = ConcurrentModificationError()
    //     0x910ad8: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x910adc: mov             x1, x0
    // 0x910ae0: ldur            x0, [fp, #-0x30]
    // 0x910ae4: StoreField: r1->field_b = r0
    //     0x910ae4: stur            w0, [x1, #0xb]
    // 0x910ae8: mov             x0, x1
    // 0x910aec: r0 = Throw()
    //     0x910aec: bl              #0x13ddb2c  ; ThrowStub
    // 0x910af0: brk             #0
    // 0x910af4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x910af4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x910af8: b               #0x9107c8
    // 0x910afc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x910afc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x910b00: b               #0x91087c
    // 0x910b04: r9 = _boundary
    //     0x910b04: add             x9, PP, #0x16, lsl #12  ; [pp+0x166e0] Field <FormData._boundary@376426596>: late (offset: 0x10)
    //     0x910b08: ldr             x9, [x9, #0x6e0]
    // 0x910b0c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x910b0c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x910b10: r0 = NullErrorSharedWithoutFPURegs()
    //     0x910b10: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  [closure] void writeUtf8(dynamic, String) {
    // ** addr: 0x910c40, size: 0x64
    // 0x910c40: EnterFrame
    //     0x910c40: stp             fp, lr, [SP, #-0x10]!
    //     0x910c44: mov             fp, SP
    // 0x910c48: AllocStack(0x8)
    //     0x910c48: sub             SP, SP, #8
    // 0x910c4c: SetupParameters([dynamic _ /* r0 */])
    //     0x910c4c: ldr             x0, [fp, #0x18]
    //     0x910c50: ldur            w1, [x0, #0x17]
    //     0x910c54: add             x1, x1, HEAP, lsl #32
    // 0x910c58: CheckStackOverflow
    //     0x910c58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x910c5c: cmp             SP, x16
    //     0x910c60: b.ls            #0x910c9c
    // 0x910c64: LoadField: r0 = r1->field_13
    //     0x910c64: ldur            w0, [x1, #0x13]
    // 0x910c68: DecompressPointer r0
    //     0x910c68: add             x0, x0, HEAP, lsl #32
    // 0x910c6c: ldr             x2, [fp, #0x10]
    // 0x910c70: stur            x0, [fp, #-8]
    // 0x910c74: r1 = Instance_Utf8Encoder
    //     0x910c74: ldr             x1, [PP, #0x11f8]  ; [pp+0x11f8] Obj!Utf8Encoder@12b7f11
    // 0x910c78: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x910c78: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x910c7c: r0 = convert()
    //     0x910c7c: bl              #0x122268c  ; [dart:convert] Utf8Encoder::convert
    // 0x910c80: ldur            x1, [fp, #-8]
    // 0x910c84: mov             x2, x0
    // 0x910c88: r0 = add()
    //     0x910c88: bl              #0x8014f8  ; [dart:async] _StreamController::add
    // 0x910c8c: r0 = Null
    //     0x910c8c: mov             x0, NULL
    // 0x910c90: LeaveFrame
    //     0x910c90: mov             SP, fp
    //     0x910c94: ldp             fp, lr, [SP], #0x10
    // 0x910c98: ret
    //     0x910c98: ret             
    // 0x910c9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x910c9c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x910ca0: b               #0x910c64
  }
  [closure] void writeLine(dynamic) {
    // ** addr: 0x910ca4, size: 0x74
    // 0x910ca4: EnterFrame
    //     0x910ca4: stp             fp, lr, [SP, #-0x10]!
    //     0x910ca8: mov             fp, SP
    // 0x910cac: AllocStack(0x8)
    //     0x910cac: sub             SP, SP, #8
    // 0x910cb0: SetupParameters([dynamic _ /* r0 */])
    //     0x910cb0: ldr             x0, [fp, #0x10]
    //     0x910cb4: ldur            w1, [x0, #0x17]
    //     0x910cb8: add             x1, x1, HEAP, lsl #32
    // 0x910cbc: CheckStackOverflow
    //     0x910cbc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x910cc0: cmp             SP, x16
    //     0x910cc4: b.ls            #0x910d10
    // 0x910cc8: LoadField: r0 = r1->field_13
    //     0x910cc8: ldur            w0, [x1, #0x13]
    // 0x910ccc: DecompressPointer r0
    //     0x910ccc: add             x0, x0, HEAP, lsl #32
    // 0x910cd0: stur            x0, [fp, #-8]
    // 0x910cd4: r0 = LoadStaticField(0xb1c)
    //     0x910cd4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x910cd8: ldr             x0, [x0, #0x1638]
    // 0x910cdc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x910ce0: cmp             w0, w16
    // 0x910ce4: b.ne            #0x910cf4
    // 0x910ce8: r2 = _rnU8
    //     0x910ce8: add             x2, PP, #0x16, lsl #12  ; [pp+0x16810] Field <::._rnU8@376426596>: static late final (offset: 0xb1c)
    //     0x910cec: ldr             x2, [x2, #0x810]
    // 0x910cf0: r0 = InitLateFinalStaticField()
    //     0x910cf0: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x910cf4: ldur            x1, [fp, #-8]
    // 0x910cf8: mov             x2, x0
    // 0x910cfc: r0 = add()
    //     0x910cfc: bl              #0x8014f8  ; [dart:async] _StreamController::add
    // 0x910d00: r0 = Null
    //     0x910d00: mov             x0, NULL
    // 0x910d04: LeaveFrame
    //     0x910d04: mov             SP, fp
    //     0x910d08: ldp             fp, lr, [SP], #0x10
    // 0x910d0c: ret
    //     0x910d0c: ret             
    // 0x910d10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x910d10: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x910d14: b               #0x910cc8
  }
  _ FormData.fromMap(/* No info */) {
    // ** addr: 0x911e40, size: 0xd8
    // 0x911e40: EnterFrame
    //     0x911e40: stp             fp, lr, [SP, #-0x10]!
    //     0x911e44: mov             fp, SP
    // 0x911e48: AllocStack(0x18)
    //     0x911e48: sub             SP, SP, #0x18
    // 0x911e4c: ldr             x3, [THR, #0x90]  ; THR::object_sentinel
    // 0x911e50: r0 = false
    //     0x911e50: add             x0, NULL, #0x30  ; false
    // 0x911e54: mov             x5, x1
    // 0x911e58: mov             x4, x2
    // 0x911e5c: stur            x1, [fp, #-8]
    // 0x911e60: stur            x2, [fp, #-0x10]
    // 0x911e64: CheckStackOverflow
    //     0x911e64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x911e68: cmp             SP, x16
    //     0x911e6c: b.ls            #0x911f10
    // 0x911e70: StoreField: r5->field_f = r3
    //     0x911e70: stur            w3, [x5, #0xf]
    // 0x911e74: StoreField: r5->field_1b = r0
    //     0x911e74: stur            w0, [x5, #0x1b]
    // 0x911e78: r1 = <MapEntry<String, String>>
    //     0x911e78: add             x1, PP, #0xd, lsl #12  ; [pp+0xd900] TypeArguments: <MapEntry<String, String>>
    //     0x911e7c: ldr             x1, [x1, #0x900]
    // 0x911e80: r2 = 0
    //     0x911e80: mov             x2, #0
    // 0x911e84: r0 = _GrowableList()
    //     0x911e84: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x911e88: ldur            x3, [fp, #-8]
    // 0x911e8c: StoreField: r3->field_13 = r0
    //     0x911e8c: stur            w0, [x3, #0x13]
    //     0x911e90: ldurb           w16, [x3, #-1]
    //     0x911e94: ldurb           w17, [x0, #-1]
    //     0x911e98: and             x16, x17, x16, lsr #2
    //     0x911e9c: tst             x16, HEAP, lsr #32
    //     0x911ea0: b.eq            #0x911ea8
    //     0x911ea4: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x911ea8: r1 = <MapEntry<String, MultipartFile>>
    //     0x911ea8: add             x1, PP, #0x16, lsl #12  ; [pp+0x16960] TypeArguments: <MapEntry<String, MultipartFile>>
    //     0x911eac: ldr             x1, [x1, #0x960]
    // 0x911eb0: r2 = 0
    //     0x911eb0: mov             x2, #0
    // 0x911eb4: r0 = _GrowableList()
    //     0x911eb4: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x911eb8: ldur            x1, [fp, #-8]
    // 0x911ebc: ArrayStore: r1[0] = r0  ; List_4
    //     0x911ebc: stur            w0, [x1, #0x17]
    //     0x911ec0: ldurb           w16, [x1, #-1]
    //     0x911ec4: ldurb           w17, [x0, #-1]
    //     0x911ec8: and             x16, x17, x16, lsr #2
    //     0x911ecc: tst             x16, HEAP, lsr #32
    //     0x911ed0: b.eq            #0x911ed8
    //     0x911ed4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x911ed8: r0 = false
    //     0x911ed8: add             x0, NULL, #0x30  ; false
    // 0x911edc: StoreField: r1->field_b = r0
    //     0x911edc: stur            w0, [x1, #0xb]
    // 0x911ee0: r0 = "--dio-boundary"
    //     0x911ee0: add             x0, PP, #0x16, lsl #12  ; [pp+0x16968] "--dio-boundary"
    //     0x911ee4: ldr             x0, [x0, #0x968]
    // 0x911ee8: StoreField: r1->field_7 = r0
    //     0x911ee8: stur            w0, [x1, #7]
    // 0x911eec: ldur            x16, [fp, #-0x10]
    // 0x911ef0: str             x16, [SP]
    // 0x911ef4: r4 = const [0, 0x2, 0x1, 0x1, fromMap, 0x1, null]
    //     0x911ef4: add             x4, PP, #0x16, lsl #12  ; [pp+0x16970] List(7) [0, 0x2, 0x1, 0x1, "fromMap", 0x1, Null]
    //     0x911ef8: ldr             x4, [x4, #0x970]
    // 0x911efc: r0 = _init()
    //     0x911efc: bl              #0x911f18  ; [package:dio/src/form_data.dart] FormData::_init
    // 0x911f00: r0 = Null
    //     0x911f00: mov             x0, NULL
    // 0x911f04: LeaveFrame
    //     0x911f04: mov             SP, fp
    //     0x911f08: ldp             fp, lr, [SP], #0x10
    // 0x911f0c: ret
    //     0x911f0c: ret             
    // 0x911f10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x911f10: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x911f14: b               #0x911e70
  }
  _ _init(/* No info */) {
    // ** addr: 0x911f18, size: 0x148
    // 0x911f18: EnterFrame
    //     0x911f18: stp             fp, lr, [SP, #-0x10]!
    //     0x911f1c: mov             fp, SP
    // 0x911f20: AllocStack(0x30)
    //     0x911f20: sub             SP, SP, #0x30
    // 0x911f24: SetupParameters(FormData this /* r1 => r1, fp-0x10 */, {dynamic fromMap = Null /* r0, fp-0x8 */})
    //     0x911f24: stur            x1, [fp, #-0x10]
    //     0x911f28: ldur            w0, [x4, #0x13]
    //     0x911f2c: ldur            w2, [x4, #0x1f]
    //     0x911f30: add             x2, x2, HEAP, lsl #32
    //     0x911f34: add             x16, PP, #0x16, lsl #12  ; [pp+0x16978] "fromMap"
    //     0x911f38: ldr             x16, [x16, #0x978]
    //     0x911f3c: cmp             w2, w16
    //     0x911f40: b.ne            #0x911f5c
    //     0x911f44: ldur            w2, [x4, #0x23]
    //     0x911f48: add             x2, x2, HEAP, lsl #32
    //     0x911f4c: sub             w3, w0, w2
    //     0x911f50: add             x0, fp, w3, sxtw #2
    //     0x911f54: ldr             x0, [x0, #8]
    //     0x911f58: b               #0x911f60
    //     0x911f5c: mov             x0, NULL
    //     0x911f60: stur            x0, [fp, #-8]
    // 0x911f64: CheckStackOverflow
    //     0x911f64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x911f68: cmp             SP, x16
    //     0x911f6c: b.ls            #0x912058
    // 0x911f70: r1 = 1
    //     0x911f70: mov             x1, #1
    // 0x911f74: r0 = AllocateContext()
    //     0x911f74: bl              #0x13de838  ; AllocateContextStub
    // 0x911f78: mov             x3, x0
    // 0x911f7c: ldur            x0, [fp, #-0x10]
    // 0x911f80: stur            x3, [fp, #-0x20]
    // 0x911f84: StoreField: r3->field_f = r0
    //     0x911f84: stur            w0, [x3, #0xf]
    // 0x911f88: LoadField: r4 = r0->field_7
    //     0x911f88: ldur            w4, [x0, #7]
    // 0x911f8c: DecompressPointer r4
    //     0x911f8c: add             x4, x4, HEAP, lsl #32
    // 0x911f90: stur            x4, [fp, #-0x18]
    // 0x911f94: r1 = Null
    //     0x911f94: mov             x1, NULL
    // 0x911f98: r2 = 6
    //     0x911f98: mov             x2, #6
    // 0x911f9c: r0 = AllocateArray()
    //     0x911f9c: bl              #0x13df928  ; AllocateArrayStub
    // 0x911fa0: mov             x1, x0
    // 0x911fa4: ldur            x0, [fp, #-0x18]
    // 0x911fa8: stur            x1, [fp, #-0x28]
    // 0x911fac: StoreField: r1->field_f = r0
    //     0x911fac: stur            w0, [x1, #0xf]
    // 0x911fb0: r16 = "-"
    //     0x911fb0: ldr             x16, [PP, #0x24e8]  ; [pp+0x24e8] "-"
    // 0x911fb4: StoreField: r1->field_13 = r16
    //     0x911fb4: stur            w16, [x1, #0x13]
    // 0x911fb8: r0 = _nextRandomId()
    //     0x911fb8: bl              #0x912060  ; [package:dio/src/form_data.dart] ::_nextRandomId
    // 0x911fbc: ldur            x1, [fp, #-0x28]
    // 0x911fc0: ArrayStore: r1[2] = r0  ; List_4
    //     0x911fc0: add             x25, x1, #0x17
    //     0x911fc4: str             w0, [x25]
    //     0x911fc8: tbz             w0, #0, #0x911fe4
    //     0x911fcc: ldurb           w16, [x1, #-1]
    //     0x911fd0: ldurb           w17, [x0, #-1]
    //     0x911fd4: and             x16, x17, x16, lsr #2
    //     0x911fd8: tst             x16, HEAP, lsr #32
    //     0x911fdc: b.eq            #0x911fe4
    //     0x911fe0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x911fe4: ldur            x16, [fp, #-0x28]
    // 0x911fe8: str             x16, [SP]
    // 0x911fec: r0 = _interpolate()
    //     0x911fec: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x911ff0: ldur            x1, [fp, #-0x10]
    // 0x911ff4: StoreField: r1->field_f = r0
    //     0x911ff4: stur            w0, [x1, #0xf]
    //     0x911ff8: ldurb           w16, [x1, #-1]
    //     0x911ffc: ldurb           w17, [x0, #-1]
    //     0x912000: and             x16, x17, x16, lsr #2
    //     0x912004: tst             x16, HEAP, lsr #32
    //     0x912008: b.eq            #0x912010
    //     0x91200c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x912010: ldur            x0, [fp, #-8]
    // 0x912014: cmp             w0, NULL
    // 0x912018: b.eq            #0x912048
    // 0x91201c: ldur            x2, [fp, #-0x20]
    // 0x912020: r1 = Function '<anonymous closure>':.
    //     0x912020: add             x1, PP, #0x16, lsl #12  ; [pp+0x16980] AnonymousClosure: (0x91260c), in [package:dio/src/form_data.dart] FormData::_init (0x911f18)
    //     0x912024: ldr             x1, [x1, #0x980]
    // 0x912028: r0 = AllocateClosure()
    //     0x912028: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x91202c: r16 = false
    //     0x91202c: add             x16, NULL, #0x30  ; false
    // 0x912030: str             x16, [SP]
    // 0x912034: ldur            x1, [fp, #-8]
    // 0x912038: mov             x2, x0
    // 0x91203c: r4 = const [0, 0x3, 0x1, 0x2, encode, 0x2, null]
    //     0x91203c: add             x4, PP, #0x16, lsl #12  ; [pp+0x16988] List(7) [0, 0x3, 0x1, 0x2, "encode", 0x2, Null]
    //     0x912040: ldr             x4, [x4, #0x988]
    // 0x912044: r0 = encodeMap()
    //     0x912044: bl              #0x90c9c0  ; [package:dio/src/utils.dart] ::encodeMap
    // 0x912048: r0 = Null
    //     0x912048: mov             x0, NULL
    // 0x91204c: LeaveFrame
    //     0x91204c: mov             SP, fp
    //     0x912050: ldp             fp, lr, [SP], #0x10
    // 0x912054: ret
    //     0x912054: ret             
    // 0x912058: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x912058: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x91205c: b               #0x911f70
  }
  [closure] Null <anonymous closure>(dynamic, String, Object?) {
    // ** addr: 0x91260c, size: 0x218
    // 0x91260c: EnterFrame
    //     0x91260c: stp             fp, lr, [SP, #-0x10]!
    //     0x912610: mov             fp, SP
    // 0x912614: AllocStack(0x28)
    //     0x912614: sub             SP, SP, #0x28
    // 0x912618: SetupParameters([dynamic _ /* r0 */])
    //     0x912618: ldr             x0, [fp, #0x20]
    //     0x91261c: ldur            w1, [x0, #0x17]
    //     0x912620: add             x1, x1, HEAP, lsl #32
    // 0x912624: CheckStackOverflow
    //     0x912624: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x912628: cmp             SP, x16
    //     0x91262c: b.ls            #0x91281c
    // 0x912630: ldr             x0, [fp, #0x10]
    // 0x912634: r2 = 60
    //     0x912634: mov             x2, #0x3c
    // 0x912638: branchIfSmi(r0, 0x912644)
    //     0x912638: tbz             w0, #0, #0x912644
    // 0x91263c: r2 = LoadClassIdInstr(r0)
    //     0x91263c: ldur            x2, [x0, #-1]
    //     0x912640: ubfx            x2, x2, #0xc, #0x14
    // 0x912644: cmp             x2, #0xd4a
    // 0x912648: b.ne            #0x912700
    // 0x91264c: ldr             x2, [fp, #0x18]
    // 0x912650: LoadField: r3 = r1->field_f
    //     0x912650: ldur            w3, [x1, #0xf]
    // 0x912654: DecompressPointer r3
    //     0x912654: add             x3, x3, HEAP, lsl #32
    // 0x912658: ArrayLoad: r4 = r3[0]  ; List_4
    //     0x912658: ldur            w4, [x3, #0x17]
    // 0x91265c: DecompressPointer r4
    //     0x91265c: add             x4, x4, HEAP, lsl #32
    // 0x912660: stur            x4, [fp, #-8]
    // 0x912664: r1 = <String, MultipartFile>
    //     0x912664: add             x1, PP, #0x16, lsl #12  ; [pp+0x16990] TypeArguments: <String, MultipartFile>
    //     0x912668: ldr             x1, [x1, #0x990]
    // 0x91266c: r0 = MapEntry()
    //     0x91266c: bl              #0x8027cc  ; AllocateMapEntryStub -> MapEntry<X0, X1> (size=0x14)
    // 0x912670: ldr             x2, [fp, #0x18]
    // 0x912674: stur            x0, [fp, #-0x18]
    // 0x912678: StoreField: r0->field_b = r2
    //     0x912678: stur            w2, [x0, #0xb]
    // 0x91267c: ldr             x3, [fp, #0x10]
    // 0x912680: StoreField: r0->field_f = r3
    //     0x912680: stur            w3, [x0, #0xf]
    // 0x912684: ldur            x2, [fp, #-8]
    // 0x912688: LoadField: r1 = r2->field_b
    //     0x912688: ldur            w1, [x2, #0xb]
    // 0x91268c: LoadField: r3 = r2->field_f
    //     0x91268c: ldur            w3, [x2, #0xf]
    // 0x912690: DecompressPointer r3
    //     0x912690: add             x3, x3, HEAP, lsl #32
    // 0x912694: LoadField: r4 = r3->field_b
    //     0x912694: ldur            w4, [x3, #0xb]
    // 0x912698: r3 = LoadInt32Instr(r1)
    //     0x912698: sbfx            x3, x1, #1, #0x1f
    // 0x91269c: stur            x3, [fp, #-0x10]
    // 0x9126a0: r1 = LoadInt32Instr(r4)
    //     0x9126a0: sbfx            x1, x4, #1, #0x1f
    // 0x9126a4: cmp             x3, x1
    // 0x9126a8: b.ne            #0x9126b4
    // 0x9126ac: mov             x1, x2
    // 0x9126b0: r0 = _growToNextCapacity()
    //     0x9126b0: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9126b4: ldur            x0, [fp, #-8]
    // 0x9126b8: ldur            x2, [fp, #-0x10]
    // 0x9126bc: add             x1, x2, #1
    // 0x9126c0: lsl             x3, x1, #1
    // 0x9126c4: StoreField: r0->field_b = r3
    //     0x9126c4: stur            w3, [x0, #0xb]
    // 0x9126c8: LoadField: r1 = r0->field_f
    //     0x9126c8: ldur            w1, [x0, #0xf]
    // 0x9126cc: DecompressPointer r1
    //     0x9126cc: add             x1, x1, HEAP, lsl #32
    // 0x9126d0: ldur            x0, [fp, #-0x18]
    // 0x9126d4: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9126d4: add             x25, x1, x2, lsl #2
    //     0x9126d8: add             x25, x25, #0xf
    //     0x9126dc: str             w0, [x25]
    //     0x9126e0: tbz             w0, #0, #0x9126fc
    //     0x9126e4: ldurb           w16, [x1, #-1]
    //     0x9126e8: ldurb           w17, [x0, #-1]
    //     0x9126ec: and             x16, x17, x16, lsr #2
    //     0x9126f0: tst             x16, HEAP, lsr #32
    //     0x9126f4: b.eq            #0x9126fc
    //     0x9126f8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x9126fc: b               #0x91280c
    // 0x912700: ldr             x2, [fp, #0x18]
    // 0x912704: mov             x3, x0
    // 0x912708: LoadField: r0 = r1->field_f
    //     0x912708: ldur            w0, [x1, #0xf]
    // 0x91270c: DecompressPointer r0
    //     0x91270c: add             x0, x0, HEAP, lsl #32
    // 0x912710: LoadField: r1 = r0->field_13
    //     0x912710: ldur            w1, [x0, #0x13]
    // 0x912714: DecompressPointer r1
    //     0x912714: add             x1, x1, HEAP, lsl #32
    // 0x912718: stur            x1, [fp, #-8]
    // 0x91271c: cmp             w3, NULL
    // 0x912720: b.ne            #0x91272c
    // 0x912724: r0 = Null
    //     0x912724: mov             x0, NULL
    // 0x912728: b               #0x912754
    // 0x91272c: r0 = 60
    //     0x91272c: mov             x0, #0x3c
    // 0x912730: branchIfSmi(r3, 0x91273c)
    //     0x912730: tbz             w3, #0, #0x91273c
    // 0x912734: r0 = LoadClassIdInstr(r3)
    //     0x912734: ldur            x0, [x3, #-1]
    //     0x912738: ubfx            x0, x0, #0xc, #0x14
    // 0x91273c: str             x3, [SP]
    // 0x912740: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x912740: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x912744: r0 = GDT[cid_x0 + 0x91c1]()
    //     0x912744: mov             x17, #0x91c1
    //     0x912748: add             lr, x0, x17
    //     0x91274c: ldr             lr, [x21, lr, lsl #3]
    //     0x912750: blr             lr
    // 0x912754: cmp             w0, NULL
    // 0x912758: b.ne            #0x912764
    // 0x91275c: r3 = ""
    //     0x91275c: ldr             x3, [PP, #0x900]  ; [pp+0x900] ""
    // 0x912760: b               #0x912768
    // 0x912764: mov             x3, x0
    // 0x912768: ldr             x0, [fp, #0x18]
    // 0x91276c: ldur            x2, [fp, #-8]
    // 0x912770: stur            x3, [fp, #-0x18]
    // 0x912774: r1 = <String, String>
    //     0x912774: ldr             x1, [PP, #0x7c88]  ; [pp+0x7c88] TypeArguments: <String, String>
    // 0x912778: r0 = MapEntry()
    //     0x912778: bl              #0x8027cc  ; AllocateMapEntryStub -> MapEntry<X0, X1> (size=0x14)
    // 0x91277c: mov             x2, x0
    // 0x912780: ldr             x0, [fp, #0x18]
    // 0x912784: stur            x2, [fp, #-0x20]
    // 0x912788: StoreField: r2->field_b = r0
    //     0x912788: stur            w0, [x2, #0xb]
    // 0x91278c: ldur            x0, [fp, #-0x18]
    // 0x912790: StoreField: r2->field_f = r0
    //     0x912790: stur            w0, [x2, #0xf]
    // 0x912794: ldur            x0, [fp, #-8]
    // 0x912798: LoadField: r1 = r0->field_b
    //     0x912798: ldur            w1, [x0, #0xb]
    // 0x91279c: LoadField: r3 = r0->field_f
    //     0x91279c: ldur            w3, [x0, #0xf]
    // 0x9127a0: DecompressPointer r3
    //     0x9127a0: add             x3, x3, HEAP, lsl #32
    // 0x9127a4: LoadField: r4 = r3->field_b
    //     0x9127a4: ldur            w4, [x3, #0xb]
    // 0x9127a8: r3 = LoadInt32Instr(r1)
    //     0x9127a8: sbfx            x3, x1, #1, #0x1f
    // 0x9127ac: stur            x3, [fp, #-0x10]
    // 0x9127b0: r1 = LoadInt32Instr(r4)
    //     0x9127b0: sbfx            x1, x4, #1, #0x1f
    // 0x9127b4: cmp             x3, x1
    // 0x9127b8: b.ne            #0x9127c4
    // 0x9127bc: mov             x1, x0
    // 0x9127c0: r0 = _growToNextCapacity()
    //     0x9127c0: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9127c4: ldur            x2, [fp, #-8]
    // 0x9127c8: ldur            x3, [fp, #-0x10]
    // 0x9127cc: add             x4, x3, #1
    // 0x9127d0: lsl             x5, x4, #1
    // 0x9127d4: StoreField: r2->field_b = r5
    //     0x9127d4: stur            w5, [x2, #0xb]
    // 0x9127d8: LoadField: r1 = r2->field_f
    //     0x9127d8: ldur            w1, [x2, #0xf]
    // 0x9127dc: DecompressPointer r1
    //     0x9127dc: add             x1, x1, HEAP, lsl #32
    // 0x9127e0: ldur            x0, [fp, #-0x20]
    // 0x9127e4: ArrayStore: r1[r3] = r0  ; List_4
    //     0x9127e4: add             x25, x1, x3, lsl #2
    //     0x9127e8: add             x25, x25, #0xf
    //     0x9127ec: str             w0, [x25]
    //     0x9127f0: tbz             w0, #0, #0x91280c
    //     0x9127f4: ldurb           w16, [x1, #-1]
    //     0x9127f8: ldurb           w17, [x0, #-1]
    //     0x9127fc: and             x16, x17, x16, lsr #2
    //     0x912800: tst             x16, HEAP, lsr #32
    //     0x912804: b.eq            #0x91280c
    //     0x912808: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x91280c: r0 = Null
    //     0x91280c: mov             x0, NULL
    // 0x912810: LeaveFrame
    //     0x912810: mov             SP, fp
    //     0x912814: ldp             fp, lr, [SP], #0x10
    // 0x912818: ret
    //     0x912818: ret             
    // 0x91281c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91281c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x912820: b               #0x912630
  }
  _ FormData(/* No info */) {
    // ** addr: 0x9128c8, size: 0xc4
    // 0x9128c8: EnterFrame
    //     0x9128c8: stp             fp, lr, [SP, #-0x10]!
    //     0x9128cc: mov             fp, SP
    // 0x9128d0: AllocStack(0x8)
    //     0x9128d0: sub             SP, SP, #8
    // 0x9128d4: ldr             x2, [THR, #0x90]  ; THR::object_sentinel
    // 0x9128d8: r0 = false
    //     0x9128d8: add             x0, NULL, #0x30  ; false
    // 0x9128dc: mov             x3, x1
    // 0x9128e0: stur            x1, [fp, #-8]
    // 0x9128e4: CheckStackOverflow
    //     0x9128e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9128e8: cmp             SP, x16
    //     0x9128ec: b.ls            #0x912984
    // 0x9128f0: StoreField: r3->field_f = r2
    //     0x9128f0: stur            w2, [x3, #0xf]
    // 0x9128f4: StoreField: r3->field_1b = r0
    //     0x9128f4: stur            w0, [x3, #0x1b]
    // 0x9128f8: r1 = <MapEntry<String, String>>
    //     0x9128f8: add             x1, PP, #0xd, lsl #12  ; [pp+0xd900] TypeArguments: <MapEntry<String, String>>
    //     0x9128fc: ldr             x1, [x1, #0x900]
    // 0x912900: r2 = 0
    //     0x912900: mov             x2, #0
    // 0x912904: r0 = _GrowableList()
    //     0x912904: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x912908: ldur            x3, [fp, #-8]
    // 0x91290c: StoreField: r3->field_13 = r0
    //     0x91290c: stur            w0, [x3, #0x13]
    //     0x912910: ldurb           w16, [x3, #-1]
    //     0x912914: ldurb           w17, [x0, #-1]
    //     0x912918: and             x16, x17, x16, lsr #2
    //     0x91291c: tst             x16, HEAP, lsr #32
    //     0x912920: b.eq            #0x912928
    //     0x912924: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x912928: r1 = <MapEntry<String, MultipartFile>>
    //     0x912928: add             x1, PP, #0x16, lsl #12  ; [pp+0x16960] TypeArguments: <MapEntry<String, MultipartFile>>
    //     0x91292c: ldr             x1, [x1, #0x960]
    // 0x912930: r2 = 0
    //     0x912930: mov             x2, #0
    // 0x912934: r0 = _GrowableList()
    //     0x912934: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x912938: ldur            x1, [fp, #-8]
    // 0x91293c: ArrayStore: r1[0] = r0  ; List_4
    //     0x91293c: stur            w0, [x1, #0x17]
    //     0x912940: ldurb           w16, [x1, #-1]
    //     0x912944: ldurb           w17, [x0, #-1]
    //     0x912948: and             x16, x17, x16, lsr #2
    //     0x91294c: tst             x16, HEAP, lsr #32
    //     0x912950: b.eq            #0x912958
    //     0x912954: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x912958: r0 = "--dio-boundary"
    //     0x912958: add             x0, PP, #0x16, lsl #12  ; [pp+0x16968] "--dio-boundary"
    //     0x91295c: ldr             x0, [x0, #0x968]
    // 0x912960: StoreField: r1->field_7 = r0
    //     0x912960: stur            w0, [x1, #7]
    // 0x912964: r0 = false
    //     0x912964: add             x0, NULL, #0x30  ; false
    // 0x912968: StoreField: r1->field_b = r0
    //     0x912968: stur            w0, [x1, #0xb]
    // 0x91296c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x91296c: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x912970: r0 = _init()
    //     0x912970: bl              #0x911f18  ; [package:dio/src/form_data.dart] FormData::_init
    // 0x912974: r0 = Null
    //     0x912974: mov             x0, NULL
    // 0x912978: LeaveFrame
    //     0x912978: mov             SP, fp
    //     0x91297c: ldp             fp, lr, [SP], #0x10
    // 0x912980: ret
    //     0x912980: ret             
    // 0x912984: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x912984: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x912988: b               #0x9128f0
  }
}
