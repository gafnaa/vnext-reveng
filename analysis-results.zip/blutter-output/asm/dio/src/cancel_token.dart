// lib: , url: package:dio/src/cancel_token.dart

// class id: 1048697, size: 0x8
class :: {
}

// class id: 3413, size: 0x14, field offset: 0x8
class CancelToken extends Object {

  _ cancel(/* No info */) {
    // ** addr: 0x9137dc, size: 0x298
    // 0x9137dc: EnterFrame
    //     0x9137dc: stp             fp, lr, [SP, #-0x10]!
    //     0x9137e0: mov             fp, SP
    // 0x9137e4: AllocStack(0x30)
    //     0x9137e4: sub             SP, SP, #0x30
    // 0x9137e8: SetupParameters(CancelToken this /* r1 => r1, fp-0x8 */)
    //     0x9137e8: stur            x1, [fp, #-8]
    // 0x9137ec: CheckStackOverflow
    //     0x9137ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9137f0: cmp             SP, x16
    //     0x9137f4: b.ls            #0x913a6c
    // 0x9137f8: LoadField: r0 = r1->field_7
    //     0x9137f8: ldur            w0, [x1, #7]
    // 0x9137fc: DecompressPointer r0
    //     0x9137fc: add             x0, x0, HEAP, lsl #32
    // 0x913800: stur            x0, [fp, #-0x20]
    // 0x913804: LoadField: r2 = r0->field_b
    //     0x913804: ldur            w2, [x0, #0xb]
    // 0x913808: DecompressPointer r2
    //     0x913808: add             x2, x2, HEAP, lsl #32
    // 0x91380c: LoadField: r3 = r2->field_b
    //     0x91380c: ldur            x3, [x2, #0xb]
    // 0x913810: tst             x3, #0x1e
    // 0x913814: b.eq            #0x913a00
    // 0x913818: LoadField: r0 = r1->field_b
    //     0x913818: ldur            w0, [x1, #0xb]
    // 0x91381c: DecompressPointer r0
    //     0x91381c: add             x0, x0, HEAP, lsl #32
    // 0x913820: cmp             w0, NULL
    // 0x913824: b.ne            #0x913830
    // 0x913828: r0 = Null
    //     0x913828: mov             x0, NULL
    // 0x91382c: b               #0x91383c
    // 0x913830: LoadField: r2 = r0->field_13
    //     0x913830: ldur            w2, [x0, #0x13]
    // 0x913834: DecompressPointer r2
    //     0x913834: add             x2, x2, HEAP, lsl #32
    // 0x913838: mov             x0, x2
    // 0x91383c: r16 = "User has logged out."
    //     0x91383c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16b08] "User has logged out."
    //     0x913840: ldr             x16, [x16, #0xb08]
    // 0x913844: stp             x0, x16, [SP]
    // 0x913848: r0 = ==()
    //     0x913848: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x91384c: tbz             w0, #4, #0x9139f0
    // 0x913850: ldur            x0, [fp, #-8]
    // 0x913854: r0 = StringBuffer()
    //     0x913854: bl              #0x7e51d4  ; AllocateStringBufferStub -> StringBuffer (size=0x38)
    // 0x913858: mov             x1, x0
    // 0x91385c: stur            x0, [fp, #-0x10]
    // 0x913860: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x913860: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x913864: r0 = StringBuffer()
    //     0x913864: bl              #0x7e4a4c  ; [dart:core] StringBuffer::StringBuffer
    // 0x913868: r16 = "The CancelToken was cancelled multiple times with different reason:"
    //     0x913868: add             x16, PP, #0x16, lsl #12  ; [pp+0x16b10] "The CancelToken was cancelled multiple times with different reason:"
    //     0x91386c: ldr             x16, [x16, #0xb10]
    // 0x913870: str             x16, [SP]
    // 0x913874: ldur            x1, [fp, #-0x10]
    // 0x913878: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x913878: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x91387c: r0 = writeln()
    //     0x91387c: bl              #0x8ef840  ; [dart:core] StringBuffer::writeln
    // 0x913880: r16 = "=> [Error      ]:"
    //     0x913880: add             x16, PP, #0x16, lsl #12  ; [pp+0x16b18] "=> [Error      ]:"
    //     0x913884: ldr             x16, [x16, #0xb18]
    // 0x913888: str             x16, [SP]
    // 0x91388c: ldur            x1, [fp, #-0x10]
    // 0x913890: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x913890: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x913894: r0 = writeln()
    //     0x913894: bl              #0x8ef840  ; [dart:core] StringBuffer::writeln
    // 0x913898: r1 = Null
    //     0x913898: mov             x1, NULL
    // 0x91389c: r2 = 4
    //     0x91389c: mov             x2, #4
    // 0x9138a0: r0 = AllocateArray()
    //     0x9138a0: bl              #0x13df928  ; AllocateArrayStub
    // 0x9138a4: r16 = "   |--- Previous:"
    //     0x9138a4: add             x16, PP, #0x16, lsl #12  ; [pp+0x16b20] "   |--- Previous:"
    //     0x9138a8: ldr             x16, [x16, #0xb20]
    // 0x9138ac: StoreField: r0->field_f = r16
    //     0x9138ac: stur            w16, [x0, #0xf]
    // 0x9138b0: ldur            x1, [fp, #-8]
    // 0x9138b4: LoadField: r2 = r1->field_b
    //     0x9138b4: ldur            w2, [x1, #0xb]
    // 0x9138b8: DecompressPointer r2
    //     0x9138b8: add             x2, x2, HEAP, lsl #32
    // 0x9138bc: cmp             w2, NULL
    // 0x9138c0: b.ne            #0x9138cc
    // 0x9138c4: r2 = Null
    //     0x9138c4: mov             x2, NULL
    // 0x9138c8: b               #0x9138d8
    // 0x9138cc: LoadField: r3 = r2->field_13
    //     0x9138cc: ldur            w3, [x2, #0x13]
    // 0x9138d0: DecompressPointer r3
    //     0x9138d0: add             x3, x3, HEAP, lsl #32
    // 0x9138d4: mov             x2, x3
    // 0x9138d8: StoreField: r0->field_13 = r2
    //     0x9138d8: stur            w2, [x0, #0x13]
    // 0x9138dc: str             x0, [SP]
    // 0x9138e0: r0 = _interpolate()
    //     0x9138e0: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x9138e4: str             x0, [SP]
    // 0x9138e8: ldur            x1, [fp, #-0x10]
    // 0x9138ec: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x9138ec: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x9138f0: r0 = writeln()
    //     0x9138f0: bl              #0x8ef840  ; [dart:core] StringBuffer::writeln
    // 0x9138f4: r16 = "   |--- Current :User has logged out."
    //     0x9138f4: add             x16, PP, #0x16, lsl #12  ; [pp+0x16b28] "   |--- Current :User has logged out."
    //     0x9138f8: ldr             x16, [x16, #0xb28]
    // 0x9138fc: str             x16, [SP]
    // 0x913900: ldur            x1, [fp, #-0x10]
    // 0x913904: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x913904: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x913908: r0 = writeln()
    //     0x913908: bl              #0x8ef840  ; [dart:core] StringBuffer::writeln
    // 0x91390c: r16 = "=> [Stack Trace]:"
    //     0x91390c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16b30] "=> [Stack Trace]:"
    //     0x913910: ldr             x16, [x16, #0xb30]
    // 0x913914: str             x16, [SP]
    // 0x913918: ldur            x1, [fp, #-0x10]
    // 0x91391c: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x91391c: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x913920: r0 = writeln()
    //     0x913920: bl              #0x8ef840  ; [dart:core] StringBuffer::writeln
    // 0x913924: r1 = Null
    //     0x913924: mov             x1, NULL
    // 0x913928: r2 = 4
    //     0x913928: mov             x2, #4
    // 0x91392c: r0 = AllocateArray()
    //     0x91392c: bl              #0x13df928  ; AllocateArrayStub
    // 0x913930: r16 = "   |--- Previous:"
    //     0x913930: add             x16, PP, #0x16, lsl #12  ; [pp+0x16b20] "   |--- Previous:"
    //     0x913934: ldr             x16, [x16, #0xb20]
    // 0x913938: StoreField: r0->field_f = r16
    //     0x913938: stur            w16, [x0, #0xf]
    // 0x91393c: ldur            x1, [fp, #-8]
    // 0x913940: LoadField: r2 = r1->field_b
    //     0x913940: ldur            w2, [x1, #0xb]
    // 0x913944: DecompressPointer r2
    //     0x913944: add             x2, x2, HEAP, lsl #32
    // 0x913948: cmp             w2, NULL
    // 0x91394c: b.ne            #0x913958
    // 0x913950: r1 = Null
    //     0x913950: mov             x1, NULL
    // 0x913954: b               #0x913960
    // 0x913958: ArrayLoad: r1 = r2[0]  ; List_4
    //     0x913958: ldur            w1, [x2, #0x17]
    // 0x91395c: DecompressPointer r1
    //     0x91395c: add             x1, x1, HEAP, lsl #32
    // 0x913960: StoreField: r0->field_13 = r1
    //     0x913960: stur            w1, [x0, #0x13]
    // 0x913964: str             x0, [SP]
    // 0x913968: r0 = _interpolate()
    //     0x913968: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x91396c: str             x0, [SP]
    // 0x913970: ldur            x1, [fp, #-0x10]
    // 0x913974: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x913974: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x913978: r0 = writeln()
    //     0x913978: bl              #0x8ef840  ; [dart:core] StringBuffer::writeln
    // 0x91397c: r1 = Null
    //     0x91397c: mov             x1, NULL
    // 0x913980: r2 = 4
    //     0x913980: mov             x2, #4
    // 0x913984: r0 = AllocateArray()
    //     0x913984: bl              #0x13df928  ; AllocateArrayStub
    // 0x913988: stur            x0, [fp, #-0x18]
    // 0x91398c: r16 = "   |--- Current :"
    //     0x91398c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16b38] "   |--- Current :"
    //     0x913990: ldr             x16, [x16, #0xb38]
    // 0x913994: StoreField: r0->field_f = r16
    //     0x913994: stur            w16, [x0, #0xf]
    // 0x913998: r0 = current()
    //     0x913998: bl              #0x7f0e88  ; [dart:core] StackTrace::current
    // 0x91399c: ldur            x1, [fp, #-0x18]
    // 0x9139a0: ArrayStore: r1[1] = r0  ; List_4
    //     0x9139a0: add             x25, x1, #0x13
    //     0x9139a4: str             w0, [x25]
    //     0x9139a8: tbz             w0, #0, #0x9139c4
    //     0x9139ac: ldurb           w16, [x1, #-1]
    //     0x9139b0: ldurb           w17, [x0, #-1]
    //     0x9139b4: and             x16, x17, x16, lsr #2
    //     0x9139b8: tst             x16, HEAP, lsr #32
    //     0x9139bc: b.eq            #0x9139c4
    //     0x9139c0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x9139c4: ldur            x16, [fp, #-0x18]
    // 0x9139c8: str             x16, [SP]
    // 0x9139cc: r0 = _interpolate()
    //     0x9139cc: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x9139d0: str             x0, [SP]
    // 0x9139d4: ldur            x1, [fp, #-0x10]
    // 0x9139d8: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x9139d8: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x9139dc: r0 = writeln()
    //     0x9139dc: bl              #0x8ef840  ; [dart:core] StringBuffer::writeln
    // 0x9139e0: ldur            x16, [fp, #-0x10]
    // 0x9139e4: str             x16, [SP]
    // 0x9139e8: r0 = toString()
    //     0x9139e8: bl              #0x1101d44  ; [dart:core] StringBuffer::toString
    // 0x9139ec: r0 = current()
    //     0x9139ec: bl              #0x7f0e88  ; [dart:core] StackTrace::current
    // 0x9139f0: r0 = Null
    //     0x9139f0: mov             x0, NULL
    // 0x9139f4: LeaveFrame
    //     0x9139f4: mov             SP, fp
    //     0x9139f8: ldp             fp, lr, [SP], #0x10
    // 0x9139fc: ret
    //     0x9139fc: ret             
    // 0x913a00: r0 = RequestOptions()
    //     0x913a00: bl              #0x8eba04  ; AllocateRequestOptionsStub -> RequestOptions (size=0x70)
    // 0x913a04: mov             x1, x0
    // 0x913a08: stur            x0, [fp, #-0x10]
    // 0x913a0c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x913a0c: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x913a10: r0 = RequestOptions()
    //     0x913a10: bl              #0x8ea020  ; [package:dio/src/options.dart] RequestOptions::RequestOptions
    // 0x913a14: r0 = current()
    //     0x913a14: bl              #0x7f0e88  ; [dart:core] StackTrace::current
    // 0x913a18: ldur            x2, [fp, #-0x10]
    // 0x913a1c: mov             x3, x0
    // 0x913a20: r1 = Null
    //     0x913a20: mov             x1, NULL
    // 0x913a24: r0 = DioException.requestCancelled()
    //     0x913a24: bl              #0x913a74  ; [package:dio/src/dio_exception.dart] DioException::DioException.requestCancelled
    // 0x913a28: mov             x2, x0
    // 0x913a2c: ldur            x1, [fp, #-8]
    // 0x913a30: StoreField: r1->field_b = r0
    //     0x913a30: stur            w0, [x1, #0xb]
    //     0x913a34: ldurb           w16, [x1, #-1]
    //     0x913a38: ldurb           w17, [x0, #-1]
    //     0x913a3c: and             x16, x17, x16, lsr #2
    //     0x913a40: tst             x16, HEAP, lsr #32
    //     0x913a44: b.eq            #0x913a4c
    //     0x913a48: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x913a4c: str             x2, [SP]
    // 0x913a50: ldur            x1, [fp, #-0x20]
    // 0x913a54: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x913a54: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x913a58: r0 = complete()
    //     0x913a58: bl              #0x128a5ec  ; [dart:async] _AsyncCompleter::complete
    // 0x913a5c: r0 = Null
    //     0x913a5c: mov             x0, NULL
    // 0x913a60: LeaveFrame
    //     0x913a60: mov             SP, fp
    //     0x913a64: ldp             fp, lr, [SP], #0x10
    // 0x913a68: ret
    //     0x913a68: ret             
    // 0x913a6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x913a6c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x913a70: b               #0x9137f8
  }
  _ CancelToken(/* No info */) {
    // ** addr: 0x913b30, size: 0xa8
    // 0x913b30: EnterFrame
    //     0x913b30: stp             fp, lr, [SP, #-0x10]!
    //     0x913b34: mov             fp, SP
    // 0x913b38: AllocStack(0x10)
    //     0x913b38: sub             SP, SP, #0x10
    // 0x913b3c: SetupParameters(CancelToken this /* r1 => r0, fp-0x8 */)
    //     0x913b3c: mov             x0, x1
    //     0x913b40: stur            x1, [fp, #-8]
    // 0x913b44: CheckStackOverflow
    //     0x913b44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x913b48: cmp             SP, x16
    //     0x913b4c: b.ls            #0x913bd0
    // 0x913b50: r1 = <DioException>
    //     0x913b50: add             x1, PP, #0x15, lsl #12  ; [pp+0x15f70] TypeArguments: <DioException>
    //     0x913b54: ldr             x1, [x1, #0xf70]
    // 0x913b58: r0 = _Future()
    //     0x913b58: bl              #0x7f5dd4  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0x913b5c: stur            x0, [fp, #-0x10]
    // 0x913b60: StoreField: r0->field_b = rZR
    //     0x913b60: stur            xzr, [x0, #0xb]
    // 0x913b64: r0 = LoadStaticField(0x364)
    //     0x913b64: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x913b68: ldr             x0, [x0, #0x6c8]
    // 0x913b6c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x913b70: cmp             w0, w16
    // 0x913b74: b.ne            #0x913b80
    // 0x913b78: r2 = _current
    //     0x913b78: ldr             x2, [PP, #0x2c0]  ; [pp+0x2c0] Field <Zone._current@5048458>: static late (offset: 0x364)
    // 0x913b7c: r0 = InitLateStaticField()
    //     0x913b7c: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0x913b80: mov             x1, x0
    // 0x913b84: ldur            x0, [fp, #-0x10]
    // 0x913b88: StoreField: r0->field_13 = r1
    //     0x913b88: stur            w1, [x0, #0x13]
    // 0x913b8c: r1 = <DioException>
    //     0x913b8c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15f70] TypeArguments: <DioException>
    //     0x913b90: ldr             x1, [x1, #0xf70]
    // 0x913b94: r0 = _AsyncCompleter()
    //     0x913b94: bl              #0x7f5dc8  ; Allocate_AsyncCompleterStub -> _AsyncCompleter<X0> (size=0x10)
    // 0x913b98: ldur            x1, [fp, #-0x10]
    // 0x913b9c: StoreField: r0->field_b = r1
    //     0x913b9c: stur            w1, [x0, #0xb]
    // 0x913ba0: ldur            x1, [fp, #-8]
    // 0x913ba4: StoreField: r1->field_7 = r0
    //     0x913ba4: stur            w0, [x1, #7]
    //     0x913ba8: ldurb           w16, [x1, #-1]
    //     0x913bac: ldurb           w17, [x0, #-1]
    //     0x913bb0: and             x16, x17, x16, lsr #2
    //     0x913bb4: tst             x16, HEAP, lsr #32
    //     0x913bb8: b.eq            #0x913bc0
    //     0x913bbc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x913bc0: r0 = Null
    //     0x913bc0: mov             x0, NULL
    // 0x913bc4: LeaveFrame
    //     0x913bc4: mov             SP, fp
    //     0x913bc8: ldp             fp, lr, [SP], #0x10
    // 0x913bcc: ret
    //     0x913bcc: ret             
    // 0x913bd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x913bd0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x913bd4: b               #0x913b50
  }
}
