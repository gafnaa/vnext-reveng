// lib: , url: package:dio/src/adapters/io_adapter.dart

// class id: 1048696, size: 0x8
class :: {
}

// class id: 3414, size: 0x1c, field offset: 0x8
class IOHttpClientAdapter extends Object
    implements HttpClientAdapter {

  _ fetch(/* No info */) async {
    // ** addr: 0x8f579c, size: 0x50
    // 0x8f579c: EnterFrame
    //     0x8f579c: stp             fp, lr, [SP, #-0x10]!
    //     0x8f57a0: mov             fp, SP
    // 0x8f57a4: AllocStack(0x20)
    //     0x8f57a4: sub             SP, SP, #0x20
    // 0x8f57a8: SetupParameters(IOHttpClientAdapter this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */)
    //     0x8f57a8: stur            NULL, [fp, #-8]
    //     0x8f57ac: stur            x1, [fp, #-0x10]
    //     0x8f57b0: stur            x2, [fp, #-0x18]
    //     0x8f57b4: stur            x3, [fp, #-0x20]
    // 0x8f57b8: CheckStackOverflow
    //     0x8f57b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f57bc: cmp             SP, x16
    //     0x8f57c0: b.ls            #0x8f57e4
    // 0x8f57c4: InitAsync() -> Future<ResponseBody>
    //     0x8f57c4: add             x0, PP, #0x16, lsl #12  ; [pp+0x16050] TypeArguments: <ResponseBody>
    //     0x8f57c8: ldr             x0, [x0, #0x50]
    //     0x8f57cc: bl              #0x7f5e44  ; InitAsyncStub
    // 0x8f57d0: ldur            x1, [fp, #-0x10]
    // 0x8f57d4: ldur            x2, [fp, #-0x18]
    // 0x8f57d8: ldur            x3, [fp, #-0x20]
    // 0x8f57dc: r0 = _fetch()
    //     0x8f57dc: bl              #0x8f57ec  ; [package:dio/src/adapters/io_adapter.dart] IOHttpClientAdapter::_fetch
    // 0x8f57e0: r0 = ReturnAsync()
    //     0x8f57e0: b               #0x82fdf0  ; ReturnAsyncStub
    // 0x8f57e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f57e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f57e8: b               #0x8f57c4
  }
  _ _fetch(/* No info */) async {
    // ** addr: 0x8f57ec, size: 0xa6c
    // 0x8f57ec: EnterFrame
    //     0x8f57ec: stp             fp, lr, [SP, #-0x10]!
    //     0x8f57f0: mov             fp, SP
    // 0x8f57f4: AllocStack(0x138)
    //     0x8f57f4: sub             SP, SP, #0x138
    // 0x8f57f8: SetupParameters(IOHttpClientAdapter this /* r1 => r1, fp-0xd0 */, dynamic _ /* r2 => r0, fp-0xd8 */, dynamic _ /* r3 => r2, fp-0xe0 */)
    //     0x8f57f8: stur            NULL, [fp, #-8]
    //     0x8f57fc: mov             x0, x2
    //     0x8f5800: stur            x2, [fp, #-0xd8]
    //     0x8f5804: mov             x2, x3
    //     0x8f5808: stur            x1, [fp, #-0xd0]
    //     0x8f580c: stur            x3, [fp, #-0xe0]
    // 0x8f5810: CheckStackOverflow
    //     0x8f5810: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f5814: cmp             SP, x16
    //     0x8f5818: b.ls            #0x8f620c
    // 0x8f581c: r1 = 5
    //     0x8f581c: mov             x1, #5
    // 0x8f5820: r0 = AllocateContext()
    //     0x8f5820: bl              #0x13de838  ; AllocateContextStub
    // 0x8f5824: mov             x1, x0
    // 0x8f5828: ldur            x0, [fp, #-0xd8]
    // 0x8f582c: stur            x1, [fp, #-0xe8]
    // 0x8f5830: StoreField: r1->field_f = r0
    //     0x8f5830: stur            w0, [x1, #0xf]
    // 0x8f5834: InitAsync() -> Future<ResponseBody>
    //     0x8f5834: add             x0, PP, #0x16, lsl #12  ; [pp+0x16050] TypeArguments: <ResponseBody>
    //     0x8f5838: ldr             x0, [x0, #0x50]
    //     0x8f583c: bl              #0x7f5e44  ; InitAsyncStub
    // 0x8f5840: ldur            x0, [fp, #-0xe8]
    // 0x8f5844: LoadField: r1 = r0->field_f
    //     0x8f5844: ldur            w1, [x0, #0xf]
    // 0x8f5848: DecompressPointer r1
    //     0x8f5848: add             x1, x1, HEAP, lsl #32
    // 0x8f584c: LoadField: r2 = r1->field_53
    //     0x8f584c: ldur            w2, [x1, #0x53]
    // 0x8f5850: DecompressPointer r2
    //     0x8f5850: add             x2, x2, HEAP, lsl #32
    // 0x8f5854: ldur            x1, [fp, #-0xd0]
    // 0x8f5858: r0 = _configHttpClient()
    //     0x8f5858: bl              #0x90d778  ; [package:dio/src/adapters/io_adapter.dart] IOHttpClientAdapter::_configHttpClient
    // 0x8f585c: ldur            x2, [fp, #-0xe8]
    // 0x8f5860: stur            x0, [fp, #-0xf0]
    // 0x8f5864: LoadField: r1 = r2->field_f
    //     0x8f5864: ldur            w1, [x2, #0xf]
    // 0x8f5868: DecompressPointer r1
    //     0x8f5868: add             x1, x1, HEAP, lsl #32
    // 0x8f586c: LoadField: r3 = r1->field_7
    //     0x8f586c: ldur            w3, [x1, #7]
    // 0x8f5870: DecompressPointer r3
    //     0x8f5870: add             x3, x3, HEAP, lsl #32
    // 0x8f5874: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8f5878: cmp             w3, w16
    // 0x8f587c: b.eq            #0x8f6214
    // 0x8f5880: stur            x3, [fp, #-0xd8]
    // 0x8f5884: r0 = uri()
    //     0x8f5884: bl              #0x90c6d0  ; [package:dio/src/options.dart] RequestOptions::uri
    // 0x8f5888: ldur            x1, [fp, #-0xf0]
    // 0x8f588c: ldur            x2, [fp, #-0xd8]
    // 0x8f5890: mov             x3, x0
    // 0x8f5894: r0 = _openUrl()
    //     0x8f5894: bl              #0x8f6894  ; [dart:_http] _HttpClient::_openUrl
    // 0x8f5898: mov             x4, x0
    // 0x8f589c: ldur            x3, [fp, #-0xe8]
    // 0x8f58a0: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x8f58a4: stur            x4, [fp, #-0xf8]
    // 0x8f58a8: StoreField: r3->field_13 = r0
    //     0x8f58a8: stur            w0, [x3, #0x13]
    // 0x8f58ac: LoadField: r0 = r3->field_f
    //     0x8f58ac: ldur            w0, [x3, #0xf]
    // 0x8f58b0: DecompressPointer r0
    //     0x8f58b0: add             x0, x0, HEAP, lsl #32
    // 0x8f58b4: LoadField: r5 = r0->field_53
    //     0x8f58b4: ldur            w5, [x0, #0x53]
    // 0x8f58b8: DecompressPointer r5
    //     0x8f58b8: add             x5, x5, HEAP, lsl #32
    // 0x8f58bc: mov             x0, x5
    // 0x8f58c0: stur            x5, [fp, #-0xd8]
    // 0x8f58c4: StoreField: r3->field_1f = r0
    //     0x8f58c4: stur            w0, [x3, #0x1f]
    //     0x8f58c8: ldurb           w16, [x3, #-1]
    //     0x8f58cc: ldurb           w17, [x0, #-1]
    //     0x8f58d0: and             x16, x17, x16, lsr #2
    //     0x8f58d4: tst             x16, HEAP, lsr #32
    //     0x8f58d8: b.eq            #0x8f58e0
    //     0x8f58dc: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x8f58e0: cmp             w5, NULL
    // 0x8f58e4: b.eq            #0x8f5960
    // 0x8f58e8: LoadField: r0 = r5->field_7
    //     0x8f58e8: ldur            x0, [x5, #7]
    // 0x8f58ec: cmp             x0, #0
    // 0x8f58f0: b.le            #0x8f5958
    // 0x8f58f4: mov             x2, x3
    // 0x8f58f8: r1 = Function '<anonymous closure>':.
    //     0x8f58f8: add             x1, PP, #0x16, lsl #12  ; [pp+0x16488] AnonymousClosure: (0x90e340), in [package:dio/src/adapters/io_adapter.dart] IOHttpClientAdapter::_fetch (0x8f57ec)
    //     0x8f58fc: ldr             x1, [x1, #0x488]
    // 0x8f5900: r0 = AllocateClosure()
    //     0x8f5900: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8f5904: ldur            x16, [fp, #-0xf8]
    // 0x8f5908: ldur            lr, [fp, #-0xd8]
    // 0x8f590c: stp             lr, x16, [SP, #8]
    // 0x8f5910: str             x0, [SP]
    // 0x8f5914: r4 = const [0, 0x3, 0x3, 0x2, onTimeout, 0x2, null]
    //     0x8f5914: ldr             x4, [PP, #0x75e8]  ; [pp+0x75e8] List(7) [0, 0x3, 0x3, 0x2, "onTimeout", 0x2, Null]
    // 0x8f5918: r0 = timeout()
    //     0x8f5918: bl              #0x7eea9c  ; [dart:async] _Future::timeout
    // 0x8f591c: mov             x1, x0
    // 0x8f5920: stur            x1, [fp, #-0xd8]
    // 0x8f5924: r0 = Await()
    //     0x8f5924: bl              #0x7f5c00  ; AwaitStub
    // 0x8f5928: mov             x1, x0
    // 0x8f592c: ldur            x2, [fp, #-0xe8]
    // 0x8f5930: StoreField: r2->field_13 = r0
    //     0x8f5930: stur            w0, [x2, #0x13]
    //     0x8f5934: tbz             w0, #0, #0x8f5950
    //     0x8f5938: ldurb           w16, [x2, #-1]
    //     0x8f593c: ldurb           w17, [x0, #-1]
    //     0x8f5940: and             x16, x17, x16, lsr #2
    //     0x8f5944: tst             x16, HEAP, lsr #32
    //     0x8f5948: b.eq            #0x8f5950
    //     0x8f594c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x8f5950: mov             x0, x1
    // 0x8f5954: b               #0x8f5998
    // 0x8f5958: mov             x2, x3
    // 0x8f595c: b               #0x8f5964
    // 0x8f5960: mov             x2, x3
    // 0x8f5964: ldur            x0, [fp, #-0xf8]
    // 0x8f5968: r0 = Await()
    //     0x8f5968: bl              #0x7f5c00  ; AwaitStub
    // 0x8f596c: mov             x1, x0
    // 0x8f5970: ldur            x2, [fp, #-0xe8]
    // 0x8f5974: StoreField: r2->field_13 = r0
    //     0x8f5974: stur            w0, [x2, #0x13]
    //     0x8f5978: tbz             w0, #0, #0x8f5994
    //     0x8f597c: ldurb           w16, [x2, #-1]
    //     0x8f5980: ldurb           w17, [x0, #-1]
    //     0x8f5984: and             x16, x17, x16, lsr #2
    //     0x8f5988: tst             x16, HEAP, lsr #32
    //     0x8f598c: b.eq            #0x8f5994
    //     0x8f5990: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x8f5994: mov             x0, x1
    // 0x8f5998: stur            x0, [fp, #-0xd8]
    // 0x8f599c: r1 = <HttpClientRequest>
    //     0x8f599c: add             x1, PP, #0x16, lsl #12  ; [pp+0x16490] TypeArguments: <HttpClientRequest>
    //     0x8f59a0: ldr             x1, [x1, #0x490]
    // 0x8f59a4: r0 = _WeakReference()
    //     0x8f59a4: bl              #0x8cd300  ; Allocate_WeakReferenceStub -> _WeakReference<X0> (size=-0x8)
    // 0x8f59a8: mov             x3, x0
    // 0x8f59ac: ldur            x0, [fp, #-0xd8]
    // 0x8f59b0: stur            x3, [fp, #-0xf8]
    // 0x8f59b4: StoreField: r3->field_7 = r0
    //     0x8f59b4: stur            w0, [x3, #7]
    // 0x8f59b8: ldur            x0, [fp, #-0xe8]
    // 0x8f59bc: LoadField: r1 = r0->field_f
    //     0x8f59bc: ldur            w1, [x0, #0xf]
    // 0x8f59c0: DecompressPointer r1
    //     0x8f59c0: add             x1, x1, HEAP, lsl #32
    // 0x8f59c4: LoadField: r4 = r1->field_b
    //     0x8f59c4: ldur            w4, [x1, #0xb]
    // 0x8f59c8: DecompressPointer r4
    //     0x8f59c8: add             x4, x4, HEAP, lsl #32
    // 0x8f59cc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8f59d0: cmp             w4, w16
    // 0x8f59d4: b.eq            #0x8f6220
    // 0x8f59d8: mov             x2, x0
    // 0x8f59dc: stur            x4, [fp, #-0xd8]
    // 0x8f59e0: r1 = Function '<anonymous closure>':.
    //     0x8f59e0: add             x1, PP, #0x16, lsl #12  ; [pp+0x16498] AnonymousClosure: (0x90e284), in [package:dio/src/adapters/io_adapter.dart] IOHttpClientAdapter::_fetch (0x8f57ec)
    //     0x8f59e4: ldr             x1, [x1, #0x498]
    // 0x8f59e8: r0 = AllocateClosure()
    //     0x8f59e8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8f59ec: ldur            x1, [fp, #-0xd8]
    // 0x8f59f0: r2 = LoadClassIdInstr(r1)
    //     0x8f59f0: ldur            x2, [x1, #-1]
    //     0x8f59f4: ubfx            x2, x2, #0xc, #0x14
    // 0x8f59f8: mov             x16, x0
    // 0x8f59fc: mov             x0, x2
    // 0x8f5a00: mov             x2, x16
    // 0x8f5a04: r0 = GDT[cid_x0 + 0x6c5]()
    //     0x8f5a04: add             lr, x0, #0x6c5
    //     0x8f5a08: ldr             lr, [x21, lr, lsl #3]
    //     0x8f5a0c: blr             lr
    // 0x8f5a10: ldur            x0, [fp, #-0xe8]
    // 0x8f5a14: LoadField: r1 = r0->field_13
    //     0x8f5a14: ldur            w1, [x0, #0x13]
    // 0x8f5a18: DecompressPointer r1
    //     0x8f5a18: add             x1, x1, HEAP, lsl #32
    // 0x8f5a1c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8f5a20: cmp             w1, w16
    // 0x8f5a24: b.eq            #0x8f5f38
    // 0x8f5a28: LoadField: r2 = r0->field_f
    //     0x8f5a28: ldur            w2, [x0, #0xf]
    // 0x8f5a2c: DecompressPointer r2
    //     0x8f5a2c: add             x2, x2, HEAP, lsl #32
    // 0x8f5a30: LoadField: r3 = r2->field_33
    //     0x8f5a30: ldur            w3, [x2, #0x33]
    // 0x8f5a34: DecompressPointer r3
    //     0x8f5a34: add             x3, x3, HEAP, lsl #32
    // 0x8f5a38: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8f5a3c: cmp             w3, w16
    // 0x8f5a40: b.eq            #0x8f622c
    // 0x8f5a44: LoadField: r4 = r1->field_33
    //     0x8f5a44: ldur            w4, [x1, #0x33]
    // 0x8f5a48: DecompressPointer r4
    //     0x8f5a48: add             x4, x4, HEAP, lsl #32
    // 0x8f5a4c: LoadField: r5 = r4->field_13
    //     0x8f5a4c: ldur            w5, [x4, #0x13]
    // 0x8f5a50: DecompressPointer r5
    //     0x8f5a50: add             x5, x5, HEAP, lsl #32
    // 0x8f5a54: tbz             w5, #4, #0x8f5f4c
    // 0x8f5a58: ldur            x4, [fp, #-0xe0]
    // 0x8f5a5c: r5 = 5
    //     0x8f5a5c: mov             x5, #5
    // 0x8f5a60: StoreField: r1->field_5b = r3
    //     0x8f5a60: stur            w3, [x1, #0x5b]
    // 0x8f5a64: LoadField: r3 = r2->field_37
    //     0x8f5a64: ldur            w3, [x2, #0x37]
    // 0x8f5a68: DecompressPointer r3
    //     0x8f5a68: add             x3, x3, HEAP, lsl #32
    // 0x8f5a6c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8f5a70: cmp             w3, w16
    // 0x8f5a74: b.eq            #0x8f6238
    // 0x8f5a78: StoreField: r1->field_5f = r5
    //     0x8f5a78: stur            x5, [x1, #0x5f]
    // 0x8f5a7c: LoadField: r3 = r2->field_3b
    //     0x8f5a7c: ldur            w3, [x2, #0x3b]
    // 0x8f5a80: DecompressPointer r3
    //     0x8f5a80: add             x3, x3, HEAP, lsl #32
    // 0x8f5a84: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8f5a88: cmp             w3, w16
    // 0x8f5a8c: b.eq            #0x8f6244
    // 0x8f5a90: LoadField: r2 = r1->field_37
    //     0x8f5a90: ldur            w2, [x1, #0x37]
    // 0x8f5a94: DecompressPointer r2
    //     0x8f5a94: add             x2, x2, HEAP, lsl #32
    // 0x8f5a98: mov             x1, x2
    // 0x8f5a9c: r2 = true
    //     0x8f5a9c: add             x2, NULL, #0x20  ; true
    // 0x8f5aa0: r0 = persistentConnection=()
    //     0x8f5aa0: bl              #0x8f6788  ; [dart:_http] _HttpHeaders::persistentConnection=
    // 0x8f5aa4: ldur            x2, [fp, #-0xe0]
    // 0x8f5aa8: cmp             w2, NULL
    // 0x8f5aac: b.eq            #0x8f5b40
    // 0x8f5ab0: ldur            x0, [fp, #-0xe8]
    // 0x8f5ab4: LoadField: r1 = r0->field_13
    //     0x8f5ab4: ldur            w1, [x0, #0x13]
    // 0x8f5ab8: DecompressPointer r1
    //     0x8f5ab8: add             x1, x1, HEAP, lsl #32
    // 0x8f5abc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8f5ac0: cmp             w1, w16
    // 0x8f5ac4: b.eq            #0x8f5f6c
    // 0x8f5ac8: r0 = addStream()
    //     0x8f5ac8: bl              #0x8db528  ; [dart:_http] _HttpOutboundMessage::addStream
    // 0x8f5acc: mov             x3, x0
    // 0x8f5ad0: ldur            x0, [fp, #-0xe8]
    // 0x8f5ad4: stur            x3, [fp, #-0xe0]
    // 0x8f5ad8: LoadField: r1 = r0->field_f
    //     0x8f5ad8: ldur            w1, [x0, #0xf]
    // 0x8f5adc: DecompressPointer r1
    //     0x8f5adc: add             x1, x1, HEAP, lsl #32
    // 0x8f5ae0: LoadField: r4 = r1->field_13
    //     0x8f5ae0: ldur            w4, [x1, #0x13]
    // 0x8f5ae4: DecompressPointer r4
    //     0x8f5ae4: add             x4, x4, HEAP, lsl #32
    // 0x8f5ae8: stur            x4, [fp, #-0xd8]
    // 0x8f5aec: cmp             w4, NULL
    // 0x8f5af0: b.eq            #0x8f5b30
    // 0x8f5af4: LoadField: r1 = r4->field_7
    //     0x8f5af4: ldur            x1, [x4, #7]
    // 0x8f5af8: cmp             x1, #0
    // 0x8f5afc: b.le            #0x8f5b30
    // 0x8f5b00: mov             x2, x0
    // 0x8f5b04: r1 = Function '<anonymous closure>':.
    //     0x8f5b04: add             x1, PP, #0x16, lsl #12  ; [pp+0x164a0] AnonymousClosure: (0x90e14c), in [package:dio/src/adapters/io_adapter.dart] IOHttpClientAdapter::_fetch (0x8f57ec)
    //     0x8f5b08: ldr             x1, [x1, #0x4a0]
    // 0x8f5b0c: r0 = AllocateClosure()
    //     0x8f5b0c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8f5b10: ldur            x16, [fp, #-0xe0]
    // 0x8f5b14: ldur            lr, [fp, #-0xd8]
    // 0x8f5b18: stp             lr, x16, [SP, #8]
    // 0x8f5b1c: str             x0, [SP]
    // 0x8f5b20: r4 = const [0, 0x3, 0x3, 0x2, onTimeout, 0x2, null]
    //     0x8f5b20: ldr             x4, [PP, #0x75e8]  ; [pp+0x75e8] List(7) [0, 0x3, 0x3, 0x2, "onTimeout", 0x2, Null]
    // 0x8f5b24: r0 = timeout()
    //     0x8f5b24: bl              #0x7eea9c  ; [dart:async] _Future::timeout
    // 0x8f5b28: mov             x1, x0
    // 0x8f5b2c: b               #0x8f5b34
    // 0x8f5b30: ldur            x1, [fp, #-0xe0]
    // 0x8f5b34: mov             x0, x1
    // 0x8f5b38: stur            x1, [fp, #-0xd8]
    // 0x8f5b3c: r0 = Await()
    //     0x8f5b3c: bl              #0x7f5c00  ; AwaitStub
    // 0x8f5b40: ldur            x2, [fp, #-0xe8]
    // 0x8f5b44: LoadField: r1 = r2->field_13
    //     0x8f5b44: ldur            w1, [x2, #0x13]
    // 0x8f5b48: DecompressPointer r1
    //     0x8f5b48: add             x1, x1, HEAP, lsl #32
    // 0x8f5b4c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8f5b50: cmp             w1, w16
    // 0x8f5b54: b.eq            #0x8f5f80
    // 0x8f5b58: r0 = close()
    //     0x8f5b58: bl              #0x814a10  ; [dart:_http] _HttpClientRequest::close
    // 0x8f5b5c: mov             x4, x0
    // 0x8f5b60: ldur            x3, [fp, #-0xe8]
    // 0x8f5b64: stur            x4, [fp, #-0xe0]
    // 0x8f5b68: LoadField: r0 = r3->field_f
    //     0x8f5b68: ldur            w0, [x3, #0xf]
    // 0x8f5b6c: DecompressPointer r0
    //     0x8f5b6c: add             x0, x0, HEAP, lsl #32
    // 0x8f5b70: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8f5b70: ldur            w1, [x0, #0x17]
    // 0x8f5b74: DecompressPointer r1
    //     0x8f5b74: add             x1, x1, HEAP, lsl #32
    // 0x8f5b78: cmp             w1, NULL
    // 0x8f5b7c: b.ne            #0x8f5b88
    // 0x8f5b80: r5 = Instance_Duration
    //     0x8f5b80: ldr             x5, [PP, #0x1808]  ; [pp+0x1808] Obj!Duration@12c8901
    // 0x8f5b84: b               #0x8f5b8c
    // 0x8f5b88: mov             x5, x1
    // 0x8f5b8c: mov             x0, x5
    // 0x8f5b90: stur            x5, [fp, #-0xd8]
    // 0x8f5b94: ArrayStore: r3[0] = r0  ; List_4
    //     0x8f5b94: stur            w0, [x3, #0x17]
    //     0x8f5b98: ldurb           w16, [x3, #-1]
    //     0x8f5b9c: ldurb           w17, [x0, #-1]
    //     0x8f5ba0: and             x16, x17, x16, lsr #2
    //     0x8f5ba4: tst             x16, HEAP, lsr #32
    //     0x8f5ba8: b.eq            #0x8f5bb0
    //     0x8f5bac: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x8f5bb0: LoadField: r0 = r5->field_7
    //     0x8f5bb0: ldur            x0, [x5, #7]
    // 0x8f5bb4: cmp             x0, #0
    // 0x8f5bb8: b.le            #0x8f5bec
    // 0x8f5bbc: mov             x2, x3
    // 0x8f5bc0: r1 = Function '<anonymous closure>':.
    //     0x8f5bc0: add             x1, PP, #0x16, lsl #12  ; [pp+0x164a8] AnonymousClosure: (0x90e034), in [package:dio/src/adapters/io_adapter.dart] IOHttpClientAdapter::_fetch (0x8f57ec)
    //     0x8f5bc4: ldr             x1, [x1, #0x4a8]
    // 0x8f5bc8: r0 = AllocateClosure()
    //     0x8f5bc8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8f5bcc: ldur            x16, [fp, #-0xe0]
    // 0x8f5bd0: ldur            lr, [fp, #-0xd8]
    // 0x8f5bd4: stp             lr, x16, [SP, #8]
    // 0x8f5bd8: str             x0, [SP]
    // 0x8f5bdc: r4 = const [0, 0x3, 0x3, 0x2, onTimeout, 0x2, null]
    //     0x8f5bdc: ldr             x4, [PP, #0x75e8]  ; [pp+0x75e8] List(7) [0, 0x3, 0x3, 0x2, "onTimeout", 0x2, Null]
    // 0x8f5be0: r0 = timeout()
    //     0x8f5be0: bl              #0x7eea9c  ; [dart:async] _Future::timeout
    // 0x8f5be4: mov             x1, x0
    // 0x8f5be8: b               #0x8f5bf0
    // 0x8f5bec: ldur            x1, [fp, #-0xe0]
    // 0x8f5bf0: stur            x1, [fp, #-0xd8]
    // 0x8f5bf4: mov             x0, x1
    // 0x8f5bf8: r0 = Await()
    //     0x8f5bf8: bl              #0x7f5c00  ; AwaitStub
    // 0x8f5bfc: stur            x0, [fp, #-0xd0]
    // 0x8f5c00: ldur            x2, [fp, #-0xe8]
    // 0x8f5c04: r16 = <String, List<String>>
    //     0x8f5c04: add             x16, PP, #0xb, lsl #12  ; [pp+0xbed0] TypeArguments: <String, List<String>>
    //     0x8f5c08: ldr             x16, [x16, #0xed0]
    // 0x8f5c0c: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x8f5c10: stp             lr, x16, [SP]
    // 0x8f5c14: r0 = Map._fromLiteral()
    //     0x8f5c14: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x8f5c18: mov             x3, x0
    // 0x8f5c1c: ldur            x2, [fp, #-0xe8]
    // 0x8f5c20: stur            x3, [fp, #-0xf8]
    // 0x8f5c24: StoreField: r2->field_1b = r0
    //     0x8f5c24: stur            w0, [x2, #0x1b]
    //     0x8f5c28: ldurb           w16, [x2, #-1]
    //     0x8f5c2c: ldurb           w17, [x0, #-1]
    //     0x8f5c30: and             x16, x17, x16, lsr #2
    //     0x8f5c34: tst             x16, HEAP, lsr #32
    //     0x8f5c38: b.eq            #0x8f5c40
    //     0x8f5c3c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x8f5c40: ldur            x0, [fp, #-0xd0]
    // 0x8f5c44: LoadField: r4 = r0->field_b
    //     0x8f5c44: ldur            w4, [x0, #0xb]
    // 0x8f5c48: DecompressPointer r4
    //     0x8f5c48: add             x4, x4, HEAP, lsl #32
    // 0x8f5c4c: stur            x4, [fp, #-0xe0]
    // 0x8f5c50: LoadField: r5 = r4->field_13
    //     0x8f5c50: ldur            w5, [x4, #0x13]
    // 0x8f5c54: DecompressPointer r5
    //     0x8f5c54: add             x5, x5, HEAP, lsl #32
    // 0x8f5c58: stur            x5, [fp, #-0xd8]
    // 0x8f5c5c: r1 = Function '<anonymous closure>':.
    //     0x8f5c5c: add             x1, PP, #0x16, lsl #12  ; [pp+0x164b0] AnonymousClosure: (0x90dfe4), in [package:dio/src/adapters/io_adapter.dart] IOHttpClientAdapter::_fetch (0x8f57ec)
    //     0x8f5c60: ldr             x1, [x1, #0x4b0]
    // 0x8f5c64: r0 = AllocateClosure()
    //     0x8f5c64: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8f5c68: ldur            x1, [fp, #-0xd8]
    // 0x8f5c6c: mov             x2, x0
    // 0x8f5c70: r0 = forEach()
    //     0x8f5c70: bl              #0x810ea8  ; [dart:_http] _HttpHeaders::forEach
    // 0x8f5c74: ldur            x0, [fp, #-0xd8]
    // 0x8f5c78: LoadField: r1 = r0->field_f
    //     0x8f5c78: ldur            w1, [x0, #0xf]
    // 0x8f5c7c: DecompressPointer r1
    //     0x8f5c7c: add             x1, x1, HEAP, lsl #32
    // 0x8f5c80: mov             x3, x1
    // 0x8f5c84: b               #0x8f5c94
    // 0x8f5c88: sub             SP, fp, #0x138
    // 0x8f5c8c: ldur            x0, [fp, #-0xc8]
    // 0x8f5c90: mov             x3, x0
    // 0x8f5c94: ldur            x0, [fp, #-0xe0]
    // 0x8f5c98: stur            x3, [fp, #-0xd8]
    // 0x8f5c9c: r16 = <Uint8List>
    //     0x8f5c9c: add             x16, PP, #8, lsl #12  ; [pp+0x8548] TypeArguments: <Uint8List>
    //     0x8f5ca0: ldr             x16, [x16, #0x548]
    // 0x8f5ca4: ldur            lr, [fp, #-0xd0]
    // 0x8f5ca8: stp             lr, x16, [SP]
    // 0x8f5cac: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8f5cac: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8f5cb0: r0 = cast()
    //     0x8f5cb0: bl              #0x11fde60  ; [dart:async] Stream::cast
    // 0x8f5cb4: mov             x2, x0
    // 0x8f5cb8: ldur            x0, [fp, #-0xe0]
    // 0x8f5cbc: r17 = -264
    //     0x8f5cbc: mov             x17, #-0x108
    // 0x8f5cc0: str             x2, [fp, x17]
    // 0x8f5cc4: LoadField: r3 = r0->field_1b
    //     0x8f5cc4: ldur            w3, [x0, #0x1b]
    // 0x8f5cc8: DecompressPointer r3
    //     0x8f5cc8: add             x3, x3, HEAP, lsl #32
    // 0x8f5ccc: stur            x3, [fp, #-0x100]
    // 0x8f5cd0: cmp             w3, NULL
    // 0x8f5cd4: b.eq            #0x8f6250
    // 0x8f5cd8: ldur            x1, [fp, #-0xd0]
    // 0x8f5cdc: r0 = isRedirect()
    //     0x8f5cdc: bl              #0x8f6624  ; [dart:_http] _HttpClientResponse::isRedirect
    // 0x8f5ce0: tbnz            w0, #4, #0x8f5cf0
    // 0x8f5ce4: ldur            x0, [fp, #-0xd0]
    // 0x8f5ce8: r6 = true
    //     0x8f5ce8: add             x6, NULL, #0x20  ; true
    // 0x8f5cec: b               #0x8f5d1c
    // 0x8f5cf0: ldur            x0, [fp, #-0xd0]
    // 0x8f5cf4: LoadField: r1 = r0->field_13
    //     0x8f5cf4: ldur            w1, [x0, #0x13]
    // 0x8f5cf8: DecompressPointer r1
    //     0x8f5cf8: add             x1, x1, HEAP, lsl #32
    // 0x8f5cfc: LoadField: r2 = r1->field_67
    //     0x8f5cfc: ldur            w2, [x1, #0x67]
    // 0x8f5d00: DecompressPointer r2
    //     0x8f5d00: add             x2, x2, HEAP, lsl #32
    // 0x8f5d04: LoadField: r1 = r2->field_b
    //     0x8f5d04: ldur            w1, [x2, #0xb]
    // 0x8f5d08: cbnz            w1, #0x8f5d14
    // 0x8f5d0c: r2 = false
    //     0x8f5d0c: add             x2, NULL, #0x30  ; false
    // 0x8f5d10: b               #0x8f5d18
    // 0x8f5d14: r2 = true
    //     0x8f5d14: add             x2, NULL, #0x20  ; true
    // 0x8f5d18: mov             x6, x2
    // 0x8f5d1c: r17 = -272
    //     0x8f5d1c: mov             x17, #-0x110
    // 0x8f5d20: str             x6, [fp, x17]
    // 0x8f5d24: LoadField: r1 = r0->field_13
    //     0x8f5d24: ldur            w1, [x0, #0x13]
    // 0x8f5d28: DecompressPointer r1
    //     0x8f5d28: add             x1, x1, HEAP, lsl #32
    // 0x8f5d2c: LoadField: r0 = r1->field_67
    //     0x8f5d2c: ldur            w0, [x1, #0x67]
    // 0x8f5d30: DecompressPointer r0
    //     0x8f5d30: add             x0, x0, HEAP, lsl #32
    // 0x8f5d34: stur            x0, [fp, #-0xd0]
    // 0x8f5d38: r1 = Function '<anonymous closure>':.
    //     0x8f5d38: add             x1, PP, #0x16, lsl #12  ; [pp+0x164b8] AnonymousClosure: (0x90df80), in [package:dio/src/adapters/io_adapter.dart] IOHttpClientAdapter::_fetch (0x8f57ec)
    //     0x8f5d3c: ldr             x1, [x1, #0x4b8]
    // 0x8f5d40: r2 = Null
    //     0x8f5d40: mov             x2, NULL
    // 0x8f5d44: r0 = AllocateClosure()
    //     0x8f5d44: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8f5d48: r16 = <RedirectRecord>
    //     0x8f5d48: add             x16, PP, #0x16, lsl #12  ; [pp+0x164c0] TypeArguments: <RedirectRecord>
    //     0x8f5d4c: ldr             x16, [x16, #0x4c0]
    // 0x8f5d50: ldur            lr, [fp, #-0xd0]
    // 0x8f5d54: stp             lr, x16, [SP, #8]
    // 0x8f5d58: str             x0, [SP]
    // 0x8f5d5c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8f5d5c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8f5d60: r0 = map()
    //     0x8f5d60: bl              #0xba574c  ; [dart:collection] ListBase::map
    // 0x8f5d64: mov             x3, x0
    // 0x8f5d68: r17 = -280
    //     0x8f5d68: mov             x17, #-0x118
    // 0x8f5d6c: str             x3, [fp, x17]
    // 0x8f5d70: LoadField: r4 = r3->field_7
    //     0x8f5d70: ldur            w4, [x3, #7]
    // 0x8f5d74: DecompressPointer r4
    //     0x8f5d74: add             x4, x4, HEAP, lsl #32
    // 0x8f5d78: mov             x0, x3
    // 0x8f5d7c: stur            x4, [fp, #-0xd0]
    // 0x8f5d80: r2 = Null
    //     0x8f5d80: mov             x2, NULL
    // 0x8f5d84: r1 = Null
    //     0x8f5d84: mov             x1, NULL
    // 0x8f5d88: cmp             w0, NULL
    // 0x8f5d8c: b.eq            #0x8f5e24
    // 0x8f5d90: branchIfSmi(r0, 0x8f5e24)
    //     0x8f5d90: tbz             w0, #0, #0x8f5e24
    // 0x8f5d94: r3 = LoadClassIdInstr(r0)
    //     0x8f5d94: ldur            x3, [x0, #-1]
    //     0x8f5d98: ubfx            x3, x3, #0xc, #0x14
    // 0x8f5d9c: r17 = 7724
    //     0x8f5d9c: mov             x17, #0x1e2c
    // 0x8f5da0: cmp             x3, x17
    // 0x8f5da4: b.eq            #0x8f5e2c
    // 0x8f5da8: r4 = LoadClassIdInstr(r0)
    //     0x8f5da8: ldur            x4, [x0, #-1]
    //     0x8f5dac: ubfx            x4, x4, #0xc, #0x14
    // 0x8f5db0: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x8f5db4: ldr             x3, [x3, #0x18]
    // 0x8f5db8: ldr             x3, [x3, x4, lsl #3]
    // 0x8f5dbc: LoadField: r3 = r3->field_2b
    //     0x8f5dbc: ldur            w3, [x3, #0x2b]
    // 0x8f5dc0: DecompressPointer r3
    //     0x8f5dc0: add             x3, x3, HEAP, lsl #32
    // 0x8f5dc4: cmp             w3, NULL
    // 0x8f5dc8: b.eq            #0x8f5e24
    // 0x8f5dcc: LoadField: r3 = r3->field_f
    //     0x8f5dcc: ldur            w3, [x3, #0xf]
    // 0x8f5dd0: lsr             x3, x3, #3
    // 0x8f5dd4: r17 = 7724
    //     0x8f5dd4: mov             x17, #0x1e2c
    // 0x8f5dd8: cmp             x3, x17
    // 0x8f5ddc: b.eq            #0x8f5e2c
    // 0x8f5de0: r3 = SubtypeTestCache
    //     0x8f5de0: add             x3, PP, #0x16, lsl #12  ; [pp+0x164c8] SubtypeTestCache
    //     0x8f5de4: ldr             x3, [x3, #0x4c8]
    // 0x8f5de8: r30 = Subtype1TestCacheStub
    //     0x8f5de8: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x8f5dec: LoadField: r30 = r30->field_7
    //     0x8f5dec: ldur            lr, [lr, #7]
    // 0x8f5df0: blr             lr
    // 0x8f5df4: cmp             w7, NULL
    // 0x8f5df8: b.eq            #0x8f5e04
    // 0x8f5dfc: tbnz            w7, #4, #0x8f5e24
    // 0x8f5e00: b               #0x8f5e2c
    // 0x8f5e04: r8 = EfficientLengthIterable
    //     0x8f5e04: add             x8, PP, #0x16, lsl #12  ; [pp+0x164d0] Type: EfficientLengthIterable
    //     0x8f5e08: ldr             x8, [x8, #0x4d0]
    // 0x8f5e0c: r3 = SubtypeTestCache
    //     0x8f5e0c: add             x3, PP, #0x16, lsl #12  ; [pp+0x164d8] SubtypeTestCache
    //     0x8f5e10: ldr             x3, [x3, #0x4d8]
    // 0x8f5e14: r30 = InstanceOfStub
    //     0x8f5e14: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x8f5e18: LoadField: r30 = r30->field_7
    //     0x8f5e18: ldur            lr, [lr, #7]
    // 0x8f5e1c: blr             lr
    // 0x8f5e20: b               #0x8f5e30
    // 0x8f5e24: r0 = false
    //     0x8f5e24: add             x0, NULL, #0x30  ; false
    // 0x8f5e28: b               #0x8f5e30
    // 0x8f5e2c: r0 = true
    //     0x8f5e2c: add             x0, NULL, #0x20  ; true
    // 0x8f5e30: tbnz            w0, #4, #0x8f5e4c
    // 0x8f5e34: ldur            x1, [fp, #-0xd0]
    // 0x8f5e38: r17 = -280
    //     0x8f5e38: mov             x17, #-0x118
    // 0x8f5e3c: ldr             x2, [fp, x17]
    // 0x8f5e40: r0 = _GrowableList._ofEfficientLengthIterable()
    //     0x8f5e40: bl              #0x7d732c  ; [dart:core] _GrowableList::_GrowableList._ofEfficientLengthIterable
    // 0x8f5e44: mov             x7, x0
    // 0x8f5e48: b               #0x8f5e60
    // 0x8f5e4c: ldur            x1, [fp, #-0xd0]
    // 0x8f5e50: r17 = -280
    //     0x8f5e50: mov             x17, #-0x118
    // 0x8f5e54: ldr             x2, [fp, x17]
    // 0x8f5e58: r0 = _GrowableList._ofOther()
    //     0x8f5e58: bl              #0x7d94b4  ; [dart:core] _GrowableList::_GrowableList._ofOther
    // 0x8f5e5c: mov             x7, x0
    // 0x8f5e60: ldur            x3, [fp, #-0xd8]
    // 0x8f5e64: ldur            x1, [fp, #-0x100]
    // 0x8f5e68: ldur            x0, [fp, #-0xe0]
    // 0x8f5e6c: r17 = -280
    //     0x8f5e6c: mov             x17, #-0x118
    // 0x8f5e70: str             x7, [fp, x17]
    // 0x8f5e74: LoadField: r2 = r0->field_1f
    //     0x8f5e74: ldur            w2, [x0, #0x1f]
    // 0x8f5e78: DecompressPointer r2
    //     0x8f5e78: add             x2, x2, HEAP, lsl #32
    // 0x8f5e7c: stur            x2, [fp, #-0xd0]
    // 0x8f5e80: cmp             w2, NULL
    // 0x8f5e84: b.eq            #0x8f6254
    // 0x8f5e88: r0 = LoadInt32Instr(r1)
    //     0x8f5e88: sbfx            x0, x1, #1, #0x1f
    //     0x8f5e8c: tbz             w1, #0, #0x8f5e94
    //     0x8f5e90: ldur            x0, [x1, #7]
    // 0x8f5e94: r17 = -288
    //     0x8f5e94: mov             x17, #-0x120
    // 0x8f5e98: str             x0, [fp, x17]
    // 0x8f5e9c: r0 = ResponseBody()
    //     0x8f5e9c: bl              #0x8f6618  ; AllocateResponseBodyStub -> ResponseBody (size=0x2c)
    // 0x8f5ea0: stur            x0, [fp, #-0xe0]
    // 0x8f5ea4: ldur            x16, [fp, #-0xd0]
    // 0x8f5ea8: str             x16, [SP]
    // 0x8f5eac: mov             x1, x0
    // 0x8f5eb0: r17 = -264
    //     0x8f5eb0: mov             x17, #-0x108
    // 0x8f5eb4: ldr             x2, [fp, x17]
    // 0x8f5eb8: r17 = -288
    //     0x8f5eb8: mov             x17, #-0x120
    // 0x8f5ebc: ldr             x3, [fp, x17]
    // 0x8f5ec0: ldur            x5, [fp, #-0xf8]
    // 0x8f5ec4: r17 = -272
    //     0x8f5ec4: mov             x17, #-0x110
    // 0x8f5ec8: ldr             x6, [fp, x17]
    // 0x8f5ecc: r17 = -280
    //     0x8f5ecc: mov             x17, #-0x118
    // 0x8f5ed0: ldr             x7, [fp, x17]
    // 0x8f5ed4: r0 = ResponseBody()
    //     0x8f5ed4: bl              #0x8f6504  ; [package:dio/src/adapter.dart] ResponseBody::ResponseBody
    // 0x8f5ed8: ldur            x3, [fp, #-0xd8]
    // 0x8f5edc: cmp             w3, NULL
    // 0x8f5ee0: b.eq            #0x8f5f30
    // 0x8f5ee4: ldur            x0, [fp, #-0xe0]
    // 0x8f5ee8: LoadField: r4 = r0->field_23
    //     0x8f5ee8: ldur            w4, [x0, #0x23]
    // 0x8f5eec: DecompressPointer r4
    //     0x8f5eec: add             x4, x4, HEAP, lsl #32
    // 0x8f5ef0: mov             x1, x4
    // 0x8f5ef4: stur            x4, [fp, #-0xd0]
    // 0x8f5ef8: r2 = "httpVersion"
    //     0x8f5ef8: add             x2, PP, #0x16, lsl #12  ; [pp+0x164e0] "httpVersion"
    //     0x8f5efc: ldr             x2, [x2, #0x4e0]
    // 0x8f5f00: r0 = _getValueOrData()
    //     0x8f5f00: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x8f5f04: ldur            x1, [fp, #-0xd0]
    // 0x8f5f08: LoadField: r2 = r1->field_f
    //     0x8f5f08: ldur            w2, [x1, #0xf]
    // 0x8f5f0c: DecompressPointer r2
    //     0x8f5f0c: add             x2, x2, HEAP, lsl #32
    // 0x8f5f10: cmp             w2, w0
    // 0x8f5f14: b.eq            #0x8f5f20
    // 0x8f5f18: cmp             w0, NULL
    // 0x8f5f1c: b.ne            #0x8f5f30
    // 0x8f5f20: ldur            x3, [fp, #-0xd8]
    // 0x8f5f24: r2 = "httpVersion"
    //     0x8f5f24: add             x2, PP, #0x16, lsl #12  ; [pp+0x164e0] "httpVersion"
    //     0x8f5f28: ldr             x2, [x2, #0x4e0]
    // 0x8f5f2c: r0 = []=()
    //     0x8f5f2c: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x8f5f30: ldur            x0, [fp, #-0xe0]
    // 0x8f5f34: r0 = ReturnAsyncNotFuture()
    //     0x8f5f34: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x8f5f38: r16 = "request"
    //     0x8f5f38: add             x16, PP, #8, lsl #12  ; [pp+0x8530] "request"
    //     0x8f5f3c: ldr             x16, [x16, #0x530]
    // 0x8f5f40: str             x16, [SP]
    // 0x8f5f44: r0 = _throwLocalNotInitialized()
    //     0x8f5f44: bl              #0x82b57c  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0x8f5f48: brk             #0
    // 0x8f5f4c: r0 = StateError()
    //     0x8f5f4c: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x8f5f50: mov             x1, x0
    // 0x8f5f54: r0 = "Request already sent"
    //     0x8f5f54: add             x0, PP, #0xb, lsl #12  ; [pp+0xbb88] "Request already sent"
    //     0x8f5f58: ldr             x0, [x0, #0xb88]
    // 0x8f5f5c: StoreField: r1->field_b = r0
    //     0x8f5f5c: stur            w0, [x1, #0xb]
    // 0x8f5f60: mov             x0, x1
    // 0x8f5f64: r0 = Throw()
    //     0x8f5f64: bl              #0x13ddb2c  ; ThrowStub
    // 0x8f5f68: brk             #0
    // 0x8f5f6c: r16 = "request"
    //     0x8f5f6c: add             x16, PP, #8, lsl #12  ; [pp+0x8530] "request"
    //     0x8f5f70: ldr             x16, [x16, #0x530]
    // 0x8f5f74: str             x16, [SP]
    // 0x8f5f78: r0 = _throwLocalNotInitialized()
    //     0x8f5f78: bl              #0x82b57c  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0x8f5f7c: brk             #0
    // 0x8f5f80: r16 = "request"
    //     0x8f5f80: add             x16, PP, #8, lsl #12  ; [pp+0x8530] "request"
    //     0x8f5f84: ldr             x16, [x16, #0x530]
    // 0x8f5f88: str             x16, [SP]
    // 0x8f5f8c: r0 = _throwLocalNotInitialized()
    //     0x8f5f8c: bl              #0x82b57c  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0x8f5f90: brk             #0
    // 0x8f5f94: sub             SP, fp, #0x138
    // 0x8f5f98: ldur            x2, [fp, #-0xe8]
    // 0x8f5f9c: mov             x4, x0
    // 0x8f5fa0: mov             x3, x1
    // 0x8f5fa4: stur            x0, [fp, #-0xd0]
    // 0x8f5fa8: stur            x1, [fp, #-0xd8]
    // 0x8f5fac: r0 = 60
    //     0x8f5fac: mov             x0, #0x3c
    // 0x8f5fb0: branchIfSmi(r4, 0x8f5fbc)
    //     0x8f5fb0: tbz             w4, #0, #0x8f5fbc
    // 0x8f5fb4: r0 = LoadClassIdInstr(r4)
    //     0x8f5fb4: ldur            x0, [x4, #-1]
    //     0x8f5fb8: ubfx            x0, x0, #0xc, #0x14
    // 0x8f5fbc: r17 = -7082
    //     0x8f5fbc: mov             x17, #-0x1baa
    // 0x8f5fc0: add             x16, x0, x17
    // 0x8f5fc4: cmp             x16, #3
    // 0x8f5fc8: b.hi            #0x8f607c
    // 0x8f5fcc: r0 = LoadClassIdInstr(r4)
    //     0x8f5fcc: ldur            x0, [x4, #-1]
    //     0x8f5fd0: ubfx            x0, x0, #0xc, #0x14
    // 0x8f5fd4: mov             x1, x4
    // 0x8f5fd8: r0 = GDT[cid_x0 + -0xff2]()
    //     0x8f5fd8: sub             lr, x0, #0xff2
    //     0x8f5fdc: ldr             lr, [x21, lr, lsl #3]
    //     0x8f5fe0: blr             lr
    // 0x8f5fe4: r1 = LoadClassIdInstr(r0)
    //     0x8f5fe4: ldur            x1, [x0, #-1]
    //     0x8f5fe8: ubfx            x1, x1, #0xc, #0x14
    // 0x8f5fec: mov             x16, x0
    // 0x8f5ff0: mov             x0, x1
    // 0x8f5ff4: mov             x1, x16
    // 0x8f5ff8: r2 = "Connection closed before full header was received"
    //     0x8f5ff8: add             x2, PP, #0xc, lsl #12  ; [pp+0xc460] "Connection closed before full header was received"
    //     0x8f5ffc: ldr             x2, [x2, #0x460]
    // 0x8f6000: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8f6000: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8f6004: r0 = GDT[cid_x0 + -0x1000]()
    //     0x8f6004: sub             lr, x0, #1, lsl #12
    //     0x8f6008: ldr             lr, [x21, lr, lsl #3]
    //     0x8f600c: blr             lr
    // 0x8f6010: tbnz            w0, #4, #0x8f606c
    // 0x8f6014: ldur            x3, [fp, #-0xe8]
    // 0x8f6018: ldur            x2, [fp, #-0xd0]
    // 0x8f601c: LoadField: r5 = r3->field_f
    //     0x8f601c: ldur            w5, [x3, #0xf]
    // 0x8f6020: DecompressPointer r5
    //     0x8f6020: add             x5, x5, HEAP, lsl #32
    // 0x8f6024: stur            x5, [fp, #-0xe0]
    // 0x8f6028: r0 = LoadClassIdInstr(r2)
    //     0x8f6028: ldur            x0, [x2, #-1]
    //     0x8f602c: ubfx            x0, x0, #0xc, #0x14
    // 0x8f6030: mov             x1, x2
    // 0x8f6034: r0 = GDT[cid_x0 + -0xff2]()
    //     0x8f6034: sub             lr, x0, #0xff2
    //     0x8f6038: ldr             lr, [x21, lr, lsl #3]
    //     0x8f603c: blr             lr
    // 0x8f6040: ldur            x16, [fp, #-0xd8]
    // 0x8f6044: str             x16, [SP]
    // 0x8f6048: ldur            x2, [fp, #-0xd0]
    // 0x8f604c: mov             x3, x0
    // 0x8f6050: ldur            x5, [fp, #-0xe0]
    // 0x8f6054: r1 = Null
    //     0x8f6054: mov             x1, NULL
    // 0x8f6058: r4 = const [0, 0x5, 0x1, 0x4, stackTrace, 0x4, null]
    //     0x8f6058: add             x4, PP, #0x16, lsl #12  ; [pp+0x164e8] List(7) [0, 0x5, 0x1, 0x4, "stackTrace", 0x4, Null]
    //     0x8f605c: ldr             x4, [x4, #0x4e8]
    // 0x8f6060: r0 = DioException.connectionError()
    //     0x8f6060: bl              #0x8f640c  ; [package:dio/src/dio_exception.dart] DioException::DioException.connectionError
    // 0x8f6064: r0 = Throw()
    //     0x8f6064: bl              #0x13ddb2c  ; ThrowStub
    // 0x8f6068: brk             #0
    // 0x8f606c: ldur            x0, [fp, #-0xd0]
    // 0x8f6070: ldur            x1, [fp, #-0xd8]
    // 0x8f6074: r0 = ReThrow()
    //     0x8f6074: bl              #0x13ddb00  ; ReThrowStub
    // 0x8f6078: brk             #0
    // 0x8f607c: ldur            x0, [fp, #-0xd0]
    // 0x8f6080: ldur            x1, [fp, #-0xd8]
    // 0x8f6084: r0 = ReThrow()
    //     0x8f6084: bl              #0x13ddb00  ; ReThrowStub
    // 0x8f6088: brk             #0
    // 0x8f608c: sub             SP, fp, #0x138
    // 0x8f6090: ldur            x3, [fp, #-0xe8]
    // 0x8f6094: mov             x5, x0
    // 0x8f6098: mov             x4, x1
    // 0x8f609c: stur            x0, [fp, #-0xd0]
    // 0x8f60a0: stur            x1, [fp, #-0xd8]
    // 0x8f60a4: r2 = Null
    //     0x8f60a4: mov             x2, NULL
    // 0x8f60a8: r1 = Null
    //     0x8f60a8: mov             x1, NULL
    // 0x8f60ac: cmp             w0, NULL
    // 0x8f60b0: b.eq            #0x8f60d4
    // 0x8f60b4: branchIfSmi(r0, 0x8f60d4)
    //     0x8f60b4: tbz             w0, #0, #0x8f60d4
    // 0x8f60b8: r3 = LoadClassIdInstr(r0)
    //     0x8f60b8: ldur            x3, [x0, #-1]
    //     0x8f60bc: ubfx            x3, x3, #0xc, #0x14
    // 0x8f60c0: cmp             x3, #0x720
    // 0x8f60c4: b.eq            #0x8f60dc
    // 0x8f60c8: r17 = 6981
    //     0x8f60c8: mov             x17, #0x1b45
    // 0x8f60cc: cmp             x3, x17
    // 0x8f60d0: b.eq            #0x8f60dc
    // 0x8f60d4: r0 = false
    //     0x8f60d4: add             x0, NULL, #0x30  ; false
    // 0x8f60d8: b               #0x8f60e0
    // 0x8f60dc: r0 = true
    //     0x8f60dc: add             x0, NULL, #0x20  ; true
    // 0x8f60e0: tbnz            w0, #4, #0x8f61fc
    // 0x8f60e4: ldur            x2, [fp, #-0xd0]
    // 0x8f60e8: r0 = LoadClassIdInstr(r2)
    //     0x8f60e8: ldur            x0, [x2, #-1]
    //     0x8f60ec: ubfx            x0, x0, #0xc, #0x14
    // 0x8f60f0: mov             x1, x2
    // 0x8f60f4: r0 = GDT[cid_x0 + -0xfd3]()
    //     0x8f60f4: sub             lr, x0, #0xfd3
    //     0x8f60f8: ldr             lr, [x21, lr, lsl #3]
    //     0x8f60fc: blr             lr
    // 0x8f6100: r1 = LoadClassIdInstr(r0)
    //     0x8f6100: ldur            x1, [x0, #-1]
    //     0x8f6104: ubfx            x1, x1, #0xc, #0x14
    // 0x8f6108: mov             x16, x0
    // 0x8f610c: mov             x0, x1
    // 0x8f6110: mov             x1, x16
    // 0x8f6114: r2 = "timed out"
    //     0x8f6114: add             x2, PP, #0x16, lsl #12  ; [pp+0x164f0] "timed out"
    //     0x8f6118: ldr             x2, [x2, #0x4f0]
    // 0x8f611c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8f611c: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8f6120: r0 = GDT[cid_x0 + -0x1000]()
    //     0x8f6120: sub             lr, x0, #1, lsl #12
    //     0x8f6124: ldr             lr, [x21, lr, lsl #3]
    //     0x8f6128: blr             lr
    // 0x8f612c: tbnz            w0, #4, #0x8f61b0
    // 0x8f6130: ldur            x0, [fp, #-0xe8]
    // 0x8f6134: LoadField: r2 = r0->field_f
    //     0x8f6134: ldur            w2, [x0, #0xf]
    // 0x8f6138: DecompressPointer r2
    //     0x8f6138: add             x2, x2, HEAP, lsl #32
    // 0x8f613c: LoadField: r0 = r2->field_53
    //     0x8f613c: ldur            w0, [x2, #0x53]
    // 0x8f6140: DecompressPointer r0
    //     0x8f6140: add             x0, x0, HEAP, lsl #32
    // 0x8f6144: cmp             w0, NULL
    // 0x8f6148: b.eq            #0x8f6160
    // 0x8f614c: LoadField: r1 = r0->field_7
    //     0x8f614c: ldur            x1, [x0, #7]
    // 0x8f6150: cmp             x1, #0
    // 0x8f6154: b.le            #0x8f6160
    // 0x8f6158: mov             x3, x0
    // 0x8f615c: b               #0x8f6190
    // 0x8f6160: ldur            x0, [fp, #-0xf0]
    // 0x8f6164: LoadField: r1 = r0->field_3b
    //     0x8f6164: ldur            w1, [x0, #0x3b]
    // 0x8f6168: DecompressPointer r1
    //     0x8f6168: add             x1, x1, HEAP, lsl #32
    // 0x8f616c: cmp             w1, NULL
    // 0x8f6170: b.eq            #0x8f6188
    // 0x8f6174: LoadField: r0 = r1->field_7
    //     0x8f6174: ldur            x0, [x1, #7]
    // 0x8f6178: cmp             x0, #0
    // 0x8f617c: b.le            #0x8f6188
    // 0x8f6180: mov             x0, x1
    // 0x8f6184: b               #0x8f618c
    // 0x8f6188: r0 = Instance_Duration
    //     0x8f6188: ldr             x0, [PP, #0x1808]  ; [pp+0x1808] Obj!Duration@12c8901
    // 0x8f618c: mov             x3, x0
    // 0x8f6190: ldur            x16, [fp, #-0xd0]
    // 0x8f6194: str             x16, [SP]
    // 0x8f6198: r1 = Null
    //     0x8f6198: mov             x1, NULL
    // 0x8f619c: r4 = const [0, 0x4, 0x1, 0x3, error, 0x3, null]
    //     0x8f619c: add             x4, PP, #0x16, lsl #12  ; [pp+0x164f8] List(7) [0, 0x4, 0x1, 0x3, "error", 0x3, Null]
    //     0x8f61a0: ldr             x4, [x4, #0x4f8]
    // 0x8f61a4: r0 = DioException.connectionTimeout()
    //     0x8f61a4: bl              #0x8f6318  ; [package:dio/src/dio_exception.dart] DioException::DioException.connectionTimeout
    // 0x8f61a8: r0 = Throw()
    //     0x8f61a8: bl              #0x13ddb2c  ; ThrowStub
    // 0x8f61ac: brk             #0
    // 0x8f61b0: ldur            x0, [fp, #-0xe8]
    // 0x8f61b4: ldur            x2, [fp, #-0xd0]
    // 0x8f61b8: LoadField: r5 = r0->field_f
    //     0x8f61b8: ldur            w5, [x0, #0xf]
    // 0x8f61bc: DecompressPointer r5
    //     0x8f61bc: add             x5, x5, HEAP, lsl #32
    // 0x8f61c0: stur            x5, [fp, #-0xe0]
    // 0x8f61c4: r0 = LoadClassIdInstr(r2)
    //     0x8f61c4: ldur            x0, [x2, #-1]
    //     0x8f61c8: ubfx            x0, x0, #0xc, #0x14
    // 0x8f61cc: mov             x1, x2
    // 0x8f61d0: r0 = GDT[cid_x0 + -0xfd3]()
    //     0x8f61d0: sub             lr, x0, #0xfd3
    //     0x8f61d4: ldr             lr, [x21, lr, lsl #3]
    //     0x8f61d8: blr             lr
    // 0x8f61dc: ldur            x2, [fp, #-0xd0]
    // 0x8f61e0: mov             x3, x0
    // 0x8f61e4: ldur            x5, [fp, #-0xe0]
    // 0x8f61e8: r1 = Null
    //     0x8f61e8: mov             x1, NULL
    // 0x8f61ec: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x8f61ec: ldr             x4, [PP, #0xff0]  ; [pp+0xff0] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x8f61f0: r0 = DioException.connectionError()
    //     0x8f61f0: bl              #0x8f640c  ; [package:dio/src/dio_exception.dart] DioException::DioException.connectionError
    // 0x8f61f4: r0 = Throw()
    //     0x8f61f4: bl              #0x13ddb2c  ; ThrowStub
    // 0x8f61f8: brk             #0
    // 0x8f61fc: ldur            x0, [fp, #-0xd0]
    // 0x8f6200: ldur            x1, [fp, #-0xd8]
    // 0x8f6204: r0 = ReThrow()
    //     0x8f6204: bl              #0x13ddb00  ; ReThrowStub
    // 0x8f6208: brk             #0
    // 0x8f620c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f620c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f6210: b               #0x8f581c
    // 0x8f6214: r9 = method
    //     0x8f6214: add             x9, PP, #0x16, lsl #12  ; [pp+0x16500] Field <_RequestConfig@271184022.method>: late (offset: 0x8)
    //     0x8f6218: ldr             x9, [x9, #0x500]
    // 0x8f621c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8f621c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8f6220: r9 = _headers
    //     0x8f6220: add             x9, PP, #0x15, lsl #12  ; [pp+0x15da8] Field <_RequestConfig@271184022._headers@271184022>: late (offset: 0xc)
    //     0x8f6224: ldr             x9, [x9, #0xda8]
    // 0x8f6228: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8f6228: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8f622c: r9 = followRedirects
    //     0x8f622c: add             x9, PP, #0x16, lsl #12  ; [pp+0x16508] Field <_RequestConfig@271184022.followRedirects>: late (offset: 0x34)
    //     0x8f6230: ldr             x9, [x9, #0x508]
    // 0x8f6234: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8f6234: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8f6238: r9 = maxRedirects
    //     0x8f6238: add             x9, PP, #0x16, lsl #12  ; [pp+0x16510] Field <_RequestConfig@271184022.maxRedirects>: late (offset: 0x38)
    //     0x8f623c: ldr             x9, [x9, #0x510]
    // 0x8f6240: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8f6240: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8f6244: r9 = persistentConnection
    //     0x8f6244: add             x9, PP, #0x16, lsl #12  ; [pp+0x16518] Field <_RequestConfig@271184022.persistentConnection>: late (offset: 0x3c)
    //     0x8f6248: ldr             x9, [x9, #0x518]
    // 0x8f624c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8f624c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8f6250: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8f6250: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8f6254: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8f6254: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _configHttpClient(/* No info */) {
    // ** addr: 0x90d778, size: 0xcc
    // 0x90d778: EnterFrame
    //     0x90d778: stp             fp, lr, [SP, #-0x10]!
    //     0x90d77c: mov             fp, SP
    // 0x90d780: AllocStack(0x10)
    //     0x90d780: sub             SP, SP, #0x10
    // 0x90d784: SetupParameters(IOHttpClientAdapter this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x90d784: mov             x0, x1
    //     0x90d788: stur            x1, [fp, #-8]
    //     0x90d78c: stur            x2, [fp, #-0x10]
    // 0x90d790: CheckStackOverflow
    //     0x90d790: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x90d794: cmp             SP, x16
    //     0x90d798: b.ls            #0x90d83c
    // 0x90d79c: LoadField: r1 = r0->field_13
    //     0x90d79c: ldur            w1, [x0, #0x13]
    // 0x90d7a0: DecompressPointer r1
    //     0x90d7a0: add             x1, x1, HEAP, lsl #32
    // 0x90d7a4: cmp             w1, NULL
    // 0x90d7a8: b.ne            #0x90d7e0
    // 0x90d7ac: mov             x1, x0
    // 0x90d7b0: r0 = _createHttpClient()
    //     0x90d7b0: bl              #0x90d844  ; [package:dio/src/adapters/io_adapter.dart] IOHttpClientAdapter::_createHttpClient
    // 0x90d7b4: mov             x1, x0
    // 0x90d7b8: ldur            x2, [fp, #-8]
    // 0x90d7bc: StoreField: r2->field_13 = r0
    //     0x90d7bc: stur            w0, [x2, #0x13]
    //     0x90d7c0: ldurb           w16, [x2, #-1]
    //     0x90d7c4: ldurb           w17, [x0, #-1]
    //     0x90d7c8: and             x16, x17, x16, lsr #2
    //     0x90d7cc: tst             x16, HEAP, lsr #32
    //     0x90d7d0: b.eq            #0x90d7d8
    //     0x90d7d4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x90d7d8: mov             x2, x1
    // 0x90d7dc: b               #0x90d7e4
    // 0x90d7e0: mov             x2, x1
    // 0x90d7e4: ldur            x1, [fp, #-0x10]
    // 0x90d7e8: cmp             w1, NULL
    // 0x90d7ec: b.ne            #0x90d7f8
    // 0x90d7f0: r0 = Instance_Duration
    //     0x90d7f0: ldr             x0, [PP, #0x1808]  ; [pp+0x1808] Obj!Duration@12c8901
    // 0x90d7f4: b               #0x90d7fc
    // 0x90d7f8: mov             x0, x1
    // 0x90d7fc: LoadField: r1 = r0->field_7
    //     0x90d7fc: ldur            x1, [x0, #7]
    // 0x90d800: cmp             x1, #0
    // 0x90d804: b.le            #0x90d828
    // 0x90d808: StoreField: r2->field_3b = r0
    //     0x90d808: stur            w0, [x2, #0x3b]
    //     0x90d80c: ldurb           w16, [x2, #-1]
    //     0x90d810: ldurb           w17, [x0, #-1]
    //     0x90d814: and             x16, x17, x16, lsr #2
    //     0x90d818: tst             x16, HEAP, lsr #32
    //     0x90d81c: b.eq            #0x90d824
    //     0x90d820: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x90d824: b               #0x90d82c
    // 0x90d828: StoreField: r2->field_3b = rNULL
    //     0x90d828: stur            NULL, [x2, #0x3b]
    // 0x90d82c: mov             x0, x2
    // 0x90d830: LeaveFrame
    //     0x90d830: mov             SP, fp
    //     0x90d834: ldp             fp, lr, [SP], #0x10
    // 0x90d838: ret
    //     0x90d838: ret             
    // 0x90d83c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x90d83c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x90d840: b               #0x90d79c
  }
  _ _createHttpClient(/* No info */) {
    // ** addr: 0x90d844, size: 0x54
    // 0x90d844: EnterFrame
    //     0x90d844: stp             fp, lr, [SP, #-0x10]!
    //     0x90d848: mov             fp, SP
    // 0x90d84c: AllocStack(0x8)
    //     0x90d84c: sub             SP, SP, #8
    // 0x90d850: CheckStackOverflow
    //     0x90d850: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x90d854: cmp             SP, x16
    //     0x90d858: b.ls            #0x90d890
    // 0x90d85c: r0 = current()
    //     0x90d85c: bl              #0x90c2d8  ; [dart:_http] HttpOverrides::current
    // 0x90d860: r0 = _HttpClient()
    //     0x90d860: bl              #0x90df74  ; Allocate_HttpClientStub -> _HttpClient (size=0x4c)
    // 0x90d864: mov             x1, x0
    // 0x90d868: stur            x0, [fp, #-8]
    // 0x90d86c: r0 = _HttpClient()
    //     0x90d86c: bl              #0x90dc50  ; [dart:_http] _HttpClient::_HttpClient
    // 0x90d870: ldur            x1, [fp, #-8]
    // 0x90d874: r2 = Instance_Duration
    //     0x90d874: add             x2, PP, #0x16, lsl #12  ; [pp+0x16670] Obj!Duration@12c8961
    //     0x90d878: ldr             x2, [x2, #0x670]
    // 0x90d87c: r0 = idleTimeout=()
    //     0x90d87c: bl              #0x90d8dc  ; [dart:_http] _HttpClient::idleTimeout=
    // 0x90d880: ldur            x0, [fp, #-8]
    // 0x90d884: LeaveFrame
    //     0x90d884: mov             SP, fp
    //     0x90d888: ldp             fp, lr, [SP], #0x10
    // 0x90d88c: ret
    //     0x90d88c: ret             
    // 0x90d890: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x90d890: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x90d894: b               #0x90d85c
  }
  [closure] RedirectRecord <anonymous closure>(dynamic, RedirectInfo) {
    // ** addr: 0x90df80, size: 0x58
    // 0x90df80: EnterFrame
    //     0x90df80: stp             fp, lr, [SP, #-0x10]!
    //     0x90df84: mov             fp, SP
    // 0x90df88: AllocStack(0x18)
    //     0x90df88: sub             SP, SP, #0x18
    // 0x90df8c: ldr             x0, [fp, #0x10]
    // 0x90df90: LoadField: r1 = r0->field_7
    //     0x90df90: ldur            x1, [x0, #7]
    // 0x90df94: stur            x1, [fp, #-0x18]
    // 0x90df98: LoadField: r2 = r0->field_f
    //     0x90df98: ldur            w2, [x0, #0xf]
    // 0x90df9c: DecompressPointer r2
    //     0x90df9c: add             x2, x2, HEAP, lsl #32
    // 0x90dfa0: stur            x2, [fp, #-0x10]
    // 0x90dfa4: LoadField: r3 = r0->field_13
    //     0x90dfa4: ldur            w3, [x0, #0x13]
    // 0x90dfa8: DecompressPointer r3
    //     0x90dfa8: add             x3, x3, HEAP, lsl #32
    // 0x90dfac: stur            x3, [fp, #-8]
    // 0x90dfb0: r0 = RedirectRecord()
    //     0x90dfb0: bl              #0x90dfd8  ; AllocateRedirectRecordStub -> RedirectRecord (size=0x18)
    // 0x90dfb4: ldur            x1, [fp, #-0x18]
    // 0x90dfb8: StoreField: r0->field_7 = r1
    //     0x90dfb8: stur            x1, [x0, #7]
    // 0x90dfbc: ldur            x1, [fp, #-0x10]
    // 0x90dfc0: StoreField: r0->field_f = r1
    //     0x90dfc0: stur            w1, [x0, #0xf]
    // 0x90dfc4: ldur            x1, [fp, #-8]
    // 0x90dfc8: StoreField: r0->field_13 = r1
    //     0x90dfc8: stur            w1, [x0, #0x13]
    // 0x90dfcc: LeaveFrame
    //     0x90dfcc: mov             SP, fp
    //     0x90dfd0: ldp             fp, lr, [SP], #0x10
    // 0x90dfd4: ret
    //     0x90dfd4: ret             
  }
  [closure] void <anonymous closure>(dynamic, String, List<String>) {
    // ** addr: 0x90dfe4, size: 0x50
    // 0x90dfe4: EnterFrame
    //     0x90dfe4: stp             fp, lr, [SP, #-0x10]!
    //     0x90dfe8: mov             fp, SP
    // 0x90dfec: ldr             x0, [fp, #0x20]
    // 0x90dff0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x90dff0: ldur            w1, [x0, #0x17]
    // 0x90dff4: DecompressPointer r1
    //     0x90dff4: add             x1, x1, HEAP, lsl #32
    // 0x90dff8: CheckStackOverflow
    //     0x90dff8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x90dffc: cmp             SP, x16
    //     0x90e000: b.ls            #0x90e02c
    // 0x90e004: LoadField: r0 = r1->field_1b
    //     0x90e004: ldur            w0, [x1, #0x1b]
    // 0x90e008: DecompressPointer r0
    //     0x90e008: add             x0, x0, HEAP, lsl #32
    // 0x90e00c: mov             x1, x0
    // 0x90e010: ldr             x2, [fp, #0x18]
    // 0x90e014: ldr             x3, [fp, #0x10]
    // 0x90e018: r0 = []=()
    //     0x90e018: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x90e01c: r0 = Null
    //     0x90e01c: mov             x0, NULL
    // 0x90e020: LeaveFrame
    //     0x90e020: mov             SP, fp
    //     0x90e024: ldp             fp, lr, [SP], #0x10
    // 0x90e028: ret
    //     0x90e028: ret             
    // 0x90e02c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x90e02c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x90e030: b               #0x90e004
  }
  [closure] Never <anonymous closure>(dynamic) {
    // ** addr: 0x90e034, size: 0x84
    // 0x90e034: EnterFrame
    //     0x90e034: stp             fp, lr, [SP, #-0x10]!
    //     0x90e038: mov             fp, SP
    // 0x90e03c: AllocStack(0x10)
    //     0x90e03c: sub             SP, SP, #0x10
    // 0x90e040: SetupParameters([dynamic _ /* r0 */])
    //     0x90e040: ldr             x0, [fp, #0x10]
    //     0x90e044: ldur            w2, [x0, #0x17]
    //     0x90e048: add             x2, x2, HEAP, lsl #32
    //     0x90e04c: stur            x2, [fp, #-8]
    // 0x90e050: CheckStackOverflow
    //     0x90e050: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x90e054: cmp             SP, x16
    //     0x90e058: b.ls            #0x90e0b0
    // 0x90e05c: LoadField: r1 = r2->field_13
    //     0x90e05c: ldur            w1, [x2, #0x13]
    // 0x90e060: DecompressPointer r1
    //     0x90e060: add             x1, x1, HEAP, lsl #32
    // 0x90e064: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x90e068: cmp             w1, w16
    // 0x90e06c: b.ne            #0x90e084
    // 0x90e070: r16 = "request"
    //     0x90e070: add             x16, PP, #8, lsl #12  ; [pp+0x8530] "request"
    //     0x90e074: ldr             x16, [x16, #0x530]
    // 0x90e078: str             x16, [SP]
    // 0x90e07c: r0 = _throwLocalNotInitialized()
    //     0x90e07c: bl              #0x82b57c  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0x90e080: brk             #0
    // 0x90e084: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x90e084: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x90e088: r0 = abort()
    //     0x90e088: bl              #0x90e0b8  ; [dart:_http] _HttpClientRequest::abort
    // 0x90e08c: ldur            x0, [fp, #-8]
    // 0x90e090: LoadField: r2 = r0->field_f
    //     0x90e090: ldur            w2, [x0, #0xf]
    // 0x90e094: DecompressPointer r2
    //     0x90e094: add             x2, x2, HEAP, lsl #32
    // 0x90e098: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x90e098: ldur            w3, [x0, #0x17]
    // 0x90e09c: DecompressPointer r3
    //     0x90e09c: add             x3, x3, HEAP, lsl #32
    // 0x90e0a0: r1 = Null
    //     0x90e0a0: mov             x1, NULL
    // 0x90e0a4: r0 = DioException.receiveTimeout()
    //     0x90e0a4: bl              #0x8f4f74  ; [package:dio/src/dio_exception.dart] DioException::DioException.receiveTimeout
    // 0x90e0a8: r0 = Throw()
    //     0x90e0a8: bl              #0x13ddb2c  ; ThrowStub
    // 0x90e0ac: brk             #0
    // 0x90e0b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x90e0b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x90e0b4: b               #0x90e05c
  }
  [closure] Never <anonymous closure>(dynamic) {
    // ** addr: 0x90e14c, size: 0x7c
    // 0x90e14c: EnterFrame
    //     0x90e14c: stp             fp, lr, [SP, #-0x10]!
    //     0x90e150: mov             fp, SP
    // 0x90e154: AllocStack(0x10)
    //     0x90e154: sub             SP, SP, #0x10
    // 0x90e158: SetupParameters([dynamic _ /* r0 */])
    //     0x90e158: ldr             x0, [fp, #0x10]
    //     0x90e15c: ldur            w2, [x0, #0x17]
    //     0x90e160: add             x2, x2, HEAP, lsl #32
    //     0x90e164: stur            x2, [fp, #-8]
    // 0x90e168: CheckStackOverflow
    //     0x90e168: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x90e16c: cmp             SP, x16
    //     0x90e170: b.ls            #0x90e1c0
    // 0x90e174: LoadField: r1 = r2->field_13
    //     0x90e174: ldur            w1, [x2, #0x13]
    // 0x90e178: DecompressPointer r1
    //     0x90e178: add             x1, x1, HEAP, lsl #32
    // 0x90e17c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x90e180: cmp             w1, w16
    // 0x90e184: b.ne            #0x90e19c
    // 0x90e188: r16 = "request"
    //     0x90e188: add             x16, PP, #8, lsl #12  ; [pp+0x8530] "request"
    //     0x90e18c: ldr             x16, [x16, #0x530]
    // 0x90e190: str             x16, [SP]
    // 0x90e194: r0 = _throwLocalNotInitialized()
    //     0x90e194: bl              #0x82b57c  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0x90e198: brk             #0
    // 0x90e19c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x90e19c: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x90e1a0: r0 = abort()
    //     0x90e1a0: bl              #0x90e0b8  ; [dart:_http] _HttpClientRequest::abort
    // 0x90e1a4: ldur            x0, [fp, #-8]
    // 0x90e1a8: LoadField: r2 = r0->field_f
    //     0x90e1a8: ldur            w2, [x0, #0xf]
    // 0x90e1ac: DecompressPointer r2
    //     0x90e1ac: add             x2, x2, HEAP, lsl #32
    // 0x90e1b0: r1 = Null
    //     0x90e1b0: mov             x1, NULL
    // 0x90e1b4: r0 = DioException.sendTimeout()
    //     0x90e1b4: bl              #0x90e1c8  ; [package:dio/src/dio_exception.dart] DioException::DioException.sendTimeout
    // 0x90e1b8: r0 = Throw()
    //     0x90e1b8: bl              #0x13ddb2c  ; ThrowStub
    // 0x90e1bc: brk             #0
    // 0x90e1c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x90e1c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x90e1c4: b               #0x90e174
  }
  [closure] void <anonymous closure>(dynamic, String, dynamic) {
    // ** addr: 0x90e284, size: 0xbc
    // 0x90e284: EnterFrame
    //     0x90e284: stp             fp, lr, [SP, #-0x10]!
    //     0x90e288: mov             fp, SP
    // 0x90e28c: AllocStack(0x8)
    //     0x90e28c: sub             SP, SP, #8
    // 0x90e290: SetupParameters([dynamic _ /* r0 */])
    //     0x90e290: ldr             x0, [fp, #0x20]
    //     0x90e294: ldur            w1, [x0, #0x17]
    //     0x90e298: add             x1, x1, HEAP, lsl #32
    // 0x90e29c: CheckStackOverflow
    //     0x90e29c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x90e2a0: cmp             SP, x16
    //     0x90e2a4: b.ls            #0x90e32c
    // 0x90e2a8: ldr             x3, [fp, #0x10]
    // 0x90e2ac: cmp             w3, NULL
    // 0x90e2b0: b.eq            #0x90e308
    // 0x90e2b4: LoadField: r0 = r1->field_13
    //     0x90e2b4: ldur            w0, [x1, #0x13]
    // 0x90e2b8: DecompressPointer r0
    //     0x90e2b8: add             x0, x0, HEAP, lsl #32
    // 0x90e2bc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x90e2c0: cmp             w0, w16
    // 0x90e2c4: b.eq            #0x90e318
    // 0x90e2c8: LoadField: r2 = r0->field_37
    //     0x90e2c8: ldur            w2, [x0, #0x37]
    // 0x90e2cc: DecompressPointer r2
    //     0x90e2cc: add             x2, x2, HEAP, lsl #32
    // 0x90e2d0: LoadField: r0 = r1->field_f
    //     0x90e2d0: ldur            w0, [x1, #0xf]
    // 0x90e2d4: DecompressPointer r0
    //     0x90e2d4: add             x0, x0, HEAP, lsl #32
    // 0x90e2d8: LoadField: r1 = r0->field_f
    //     0x90e2d8: ldur            w1, [x0, #0xf]
    // 0x90e2dc: DecompressPointer r1
    //     0x90e2dc: add             x1, x1, HEAP, lsl #32
    // 0x90e2e0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x90e2e4: cmp             w1, w16
    // 0x90e2e8: b.eq            #0x90e334
    // 0x90e2ec: r16 = false
    //     0x90e2ec: add             x16, NULL, #0x30  ; false
    // 0x90e2f0: str             x16, [SP]
    // 0x90e2f4: mov             x1, x2
    // 0x90e2f8: ldr             x2, [fp, #0x18]
    // 0x90e2fc: r4 = const [0, 0x4, 0x1, 0x3, preserveHeaderCase, 0x3, null]
    //     0x90e2fc: add             x4, PP, #0xb, lsl #12  ; [pp+0xbb70] List(7) [0, 0x4, 0x1, 0x3, "preserveHeaderCase", 0x3, Null]
    //     0x90e300: ldr             x4, [x4, #0xb70]
    // 0x90e304: r0 = set()
    //     0x90e304: bl              #0x9015dc  ; [dart:_http] _HttpHeaders::set
    // 0x90e308: r0 = Null
    //     0x90e308: mov             x0, NULL
    // 0x90e30c: LeaveFrame
    //     0x90e30c: mov             SP, fp
    //     0x90e310: ldp             fp, lr, [SP], #0x10
    // 0x90e314: ret
    //     0x90e314: ret             
    // 0x90e318: r16 = "request"
    //     0x90e318: add             x16, PP, #8, lsl #12  ; [pp+0x8530] "request"
    //     0x90e31c: ldr             x16, [x16, #0x530]
    // 0x90e320: str             x16, [SP]
    // 0x90e324: r0 = _throwLocalNotInitialized()
    //     0x90e324: bl              #0x82b57c  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0x90e328: brk             #0
    // 0x90e32c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x90e32c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x90e330: b               #0x90e2a8
    // 0x90e334: r9 = preserveHeaderCase
    //     0x90e334: add             x9, PP, #0x16, lsl #12  ; [pp+0x16070] Field <_RequestConfig@271184022.preserveHeaderCase>: late (offset: 0x10)
    //     0x90e338: ldr             x9, [x9, #0x70]
    // 0x90e33c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x90e33c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Never <anonymous closure>(dynamic) {
    // ** addr: 0x90e340, size: 0x4c
    // 0x90e340: EnterFrame
    //     0x90e340: stp             fp, lr, [SP, #-0x10]!
    //     0x90e344: mov             fp, SP
    // 0x90e348: ldr             x0, [fp, #0x10]
    // 0x90e34c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x90e34c: ldur            w1, [x0, #0x17]
    // 0x90e350: DecompressPointer r1
    //     0x90e350: add             x1, x1, HEAP, lsl #32
    // 0x90e354: CheckStackOverflow
    //     0x90e354: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x90e358: cmp             SP, x16
    //     0x90e35c: b.ls            #0x90e384
    // 0x90e360: LoadField: r2 = r1->field_f
    //     0x90e360: ldur            w2, [x1, #0xf]
    // 0x90e364: DecompressPointer r2
    //     0x90e364: add             x2, x2, HEAP, lsl #32
    // 0x90e368: LoadField: r3 = r1->field_1f
    //     0x90e368: ldur            w3, [x1, #0x1f]
    // 0x90e36c: DecompressPointer r3
    //     0x90e36c: add             x3, x3, HEAP, lsl #32
    // 0x90e370: r1 = Null
    //     0x90e370: mov             x1, NULL
    // 0x90e374: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x90e374: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x90e378: r0 = DioException.connectionTimeout()
    //     0x90e378: bl              #0x8f6318  ; [package:dio/src/dio_exception.dart] DioException::DioException.connectionTimeout
    // 0x90e37c: r0 = Throw()
    //     0x90e37c: bl              #0x13ddb2c  ; ThrowStub
    // 0x90e380: brk             #0
    // 0x90e384: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x90e384: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x90e388: b               #0x90e360
  }
}
