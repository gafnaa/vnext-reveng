// lib: , url: package:dio/src/progress_stream/io_progress_stream.dart

// class id: 1048709, size: 0x8
class :: {

  static _ addProgress(/* No info */) {
    // ** addr: 0x90e9e8, size: 0x10c
    // 0x90e9e8: EnterFrame
    //     0x90e9e8: stp             fp, lr, [SP, #-0x10]!
    //     0x90e9ec: mov             fp, SP
    // 0x90e9f0: AllocStack(0x30)
    //     0x90e9f0: sub             SP, SP, #0x30
    // 0x90e9f4: SetupParameters(dynamic _ /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x90e9f4: mov             x5, x1
    //     0x90e9f8: mov             x4, x2
    //     0x90e9fc: stur            x1, [fp, #-8]
    //     0x90ea00: stur            x2, [fp, #-0x10]
    //     0x90ea04: stur            x3, [fp, #-0x18]
    // 0x90ea08: CheckStackOverflow
    //     0x90ea08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x90ea0c: cmp             SP, x16
    //     0x90ea10: b.ls            #0x90eaec
    // 0x90ea14: mov             x0, x5
    // 0x90ea18: r2 = Null
    //     0x90ea18: mov             x2, NULL
    // 0x90ea1c: r1 = Null
    //     0x90ea1c: mov             x1, NULL
    // 0x90ea20: cmp             w0, NULL
    // 0x90ea24: b.eq            #0x90ea70
    // 0x90ea28: branchIfSmi(r0, 0x90ea70)
    //     0x90ea28: tbz             w0, #0, #0x90ea70
    // 0x90ea2c: r3 = SubtypeTestCache
    //     0x90ea2c: add             x3, PP, #0x16, lsl #12  ; [pp+0x166e8] SubtypeTestCache
    //     0x90ea30: ldr             x3, [x3, #0x6e8]
    // 0x90ea34: r30 = Subtype2TestCacheStub
    //     0x90ea34: ldr             lr, [PP, #0x30]  ; [pp+0x30] Stub: Subtype2TestCache (0x7d2e44)
    // 0x90ea38: LoadField: r30 = r30->field_7
    //     0x90ea38: ldur            lr, [lr, #7]
    // 0x90ea3c: blr             lr
    // 0x90ea40: cmp             w7, NULL
    // 0x90ea44: b.eq            #0x90ea50
    // 0x90ea48: tbnz            w7, #4, #0x90ea70
    // 0x90ea4c: b               #0x90ea78
    // 0x90ea50: r8 = Stream<Uint8List>
    //     0x90ea50: add             x8, PP, #0x16, lsl #12  ; [pp+0x166f0] Type: Stream<Uint8List>
    //     0x90ea54: ldr             x8, [x8, #0x6f0]
    // 0x90ea58: r3 = SubtypeTestCache
    //     0x90ea58: add             x3, PP, #0x16, lsl #12  ; [pp+0x166f8] SubtypeTestCache
    //     0x90ea5c: ldr             x3, [x3, #0x6f8]
    // 0x90ea60: r30 = InstanceOfStub
    //     0x90ea60: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x90ea64: LoadField: r30 = r30->field_7
    //     0x90ea64: ldur            lr, [lr, #7]
    // 0x90ea68: blr             lr
    // 0x90ea6c: b               #0x90ea7c
    // 0x90ea70: r0 = false
    //     0x90ea70: add             x0, NULL, #0x30  ; false
    // 0x90ea74: b               #0x90ea7c
    // 0x90ea78: r0 = true
    //     0x90ea78: add             x0, NULL, #0x20  ; true
    // 0x90ea7c: tbnz            w0, #4, #0x90eaa4
    // 0x90ea80: r16 = <Uint8List>
    //     0x90ea80: add             x16, PP, #8, lsl #12  ; [pp+0x8548] TypeArguments: <Uint8List>
    //     0x90ea84: ldr             x16, [x16, #0x548]
    // 0x90ea88: ldur            lr, [fp, #-0x10]
    // 0x90ea8c: stp             lr, x16, [SP, #8]
    // 0x90ea90: ldur            x16, [fp, #-0x18]
    // 0x90ea94: str             x16, [SP]
    // 0x90ea98: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x90ea98: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x90ea9c: r0 = _transform()
    //     0x90ea9c: bl              #0x90eaf4  ; [package:dio/src/progress_stream/io_progress_stream.dart] ::_transform
    // 0x90eaa0: b               #0x90eac4
    // 0x90eaa4: r16 = <List<int>>
    //     0x90eaa4: add             x16, PP, #0xb, lsl #12  ; [pp+0xb958] TypeArguments: <List<int>>
    //     0x90eaa8: ldr             x16, [x16, #0x958]
    // 0x90eaac: ldur            lr, [fp, #-0x10]
    // 0x90eab0: stp             lr, x16, [SP, #8]
    // 0x90eab4: ldur            x16, [fp, #-0x18]
    // 0x90eab8: str             x16, [SP]
    // 0x90eabc: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x90eabc: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x90eac0: r0 = _transform()
    //     0x90eac0: bl              #0x90eaf4  ; [package:dio/src/progress_stream/io_progress_stream.dart] ::_transform
    // 0x90eac4: r16 = <Uint8List>
    //     0x90eac4: add             x16, PP, #8, lsl #12  ; [pp+0x8548] TypeArguments: <Uint8List>
    //     0x90eac8: ldr             x16, [x16, #0x548]
    // 0x90eacc: ldur            lr, [fp, #-8]
    // 0x90ead0: stp             lr, x16, [SP, #8]
    // 0x90ead4: str             x0, [SP]
    // 0x90ead8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x90ead8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x90eadc: r0 = transform()
    //     0x90eadc: bl              #0x819be0  ; [dart:async] Stream::transform
    // 0x90eae0: LeaveFrame
    //     0x90eae0: mov             SP, fp
    //     0x90eae4: ldp             fp, lr, [SP], #0x10
    // 0x90eae8: ret
    //     0x90eae8: ret             
    // 0x90eaec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x90eaec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x90eaf0: b               #0x90ea14
  }
  static StreamTransformer<Y0, Uint8List> _transform<Y0 extends List<int>>(int?, RequestOptions) {
    // ** addr: 0x90eaf4, size: 0x104
    // 0x90eaf4: EnterFrame
    //     0x90eaf4: stp             fp, lr, [SP, #-0x10]!
    //     0x90eaf8: mov             fp, SP
    // 0x90eafc: AllocStack(0x18)
    //     0x90eafc: sub             SP, SP, #0x18
    // 0x90eb00: SetupParameters()
    //     0x90eb00: ldur            w0, [x4, #0xf]
    //     0x90eb04: stur            x0, [fp, #-0x10]
    //     0x90eb08: cbnz            w0, #0x90eb14
    //     0x90eb0c: mov             x3, NULL
    //     0x90eb10: b               #0x90eb24
    //     0x90eb14: ldur            w1, [x4, #0x17]
    //     0x90eb18: add             x2, fp, w1, sxtw #2
    //     0x90eb1c: ldr             x2, [x2, #0x10]
    //     0x90eb20: mov             x3, x2
    // 0x90eb24: ldr             x2, [fp, #0x18]
    // 0x90eb28: ldr             x1, [fp, #0x10]
    // 0x90eb2c: stur            x3, [fp, #-8]
    // 0x90eb30: r1 = 3
    //     0x90eb30: mov             x1, #3
    // 0x90eb34: r0 = AllocateContext()
    //     0x90eb34: bl              #0x13de838  ; AllocateContextStub
    // 0x90eb38: mov             x1, x0
    // 0x90eb3c: ldr             x0, [fp, #0x18]
    // 0x90eb40: StoreField: r1->field_f = r0
    //     0x90eb40: stur            w0, [x1, #0xf]
    // 0x90eb44: ldr             x0, [fp, #0x10]
    // 0x90eb48: StoreField: r1->field_13 = r0
    //     0x90eb48: stur            w0, [x1, #0x13]
    // 0x90eb4c: ldur            x0, [fp, #-0x10]
    // 0x90eb50: cbnz            w0, #0x90eb60
    // 0x90eb54: r0 = <List<int>>
    //     0x90eb54: add             x0, PP, #0xb, lsl #12  ; [pp+0xb958] TypeArguments: <List<int>>
    //     0x90eb58: ldr             x0, [x0, #0x958]
    // 0x90eb5c: b               #0x90eb64
    // 0x90eb60: ldur            x0, [fp, #-8]
    // 0x90eb64: stur            x0, [fp, #-8]
    // 0x90eb68: ArrayStore: r1[0] = rZR  ; List_4
    //     0x90eb68: stur            wzr, [x1, #0x17]
    // 0x90eb6c: mov             x2, x1
    // 0x90eb70: r1 = Function '<anonymous closure>': static.
    //     0x90eb70: add             x1, PP, #0x16, lsl #12  ; [pp+0x16700] AnonymousClosure: static (0x90ec68), in [package:dio/src/progress_stream/io_progress_stream.dart] ::_transform (0x90eaf4)
    //     0x90eb74: ldr             x1, [x1, #0x700]
    // 0x90eb78: r0 = AllocateClosure()
    //     0x90eb78: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x90eb7c: ldur            x1, [fp, #-8]
    // 0x90eb80: stur            x0, [fp, #-0x10]
    // 0x90eb84: StoreField: r0->field_b = r1
    //     0x90eb84: stur            w1, [x0, #0xb]
    // 0x90eb88: r2 = Null
    //     0x90eb88: mov             x2, NULL
    // 0x90eb8c: r3 = <Y0 bound List, Uint8List>
    //     0x90eb8c: add             x3, PP, #0x16, lsl #12  ; [pp+0x16708] TypeArguments: <Y0 bound List, Uint8List>
    //     0x90eb90: ldr             x3, [x3, #0x708]
    // 0x90eb94: r30 = InstantiateTypeArgumentsStub
    //     0x90eb94: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0x90eb98: LoadField: r30 = r30->field_7
    //     0x90eb98: ldur            lr, [lr, #7]
    // 0x90eb9c: blr             lr
    // 0x90eba0: mov             x1, x0
    // 0x90eba4: stur            x0, [fp, #-8]
    // 0x90eba8: r0 = _StreamHandlerTransformer()
    //     0x90eba8: bl              #0x90ebf8  ; Allocate_StreamHandlerTransformerStub -> _StreamHandlerTransformer<X0, X1> (size=0x10)
    // 0x90ebac: stur            x0, [fp, #-0x18]
    // 0x90ebb0: r1 = 2
    //     0x90ebb0: mov             x1, #2
    // 0x90ebb4: r0 = AllocateContext()
    //     0x90ebb4: bl              #0x13de838  ; AllocateContextStub
    // 0x90ebb8: mov             x1, x0
    // 0x90ebbc: ldur            x0, [fp, #-0x18]
    // 0x90ebc0: StoreField: r1->field_f = r0
    //     0x90ebc0: stur            w0, [x1, #0xf]
    // 0x90ebc4: ldur            x2, [fp, #-0x10]
    // 0x90ebc8: StoreField: r1->field_13 = r2
    //     0x90ebc8: stur            w2, [x1, #0x13]
    // 0x90ebcc: mov             x2, x1
    // 0x90ebd0: ldur            x3, [fp, #-8]
    // 0x90ebd4: r1 = Function '<anonymous closure>':.
    //     0x90ebd4: add             x1, PP, #0x16, lsl #12  ; [pp+0x16710] AnonymousClosure: (0x90ec04), of [dart:async] _StreamHandlerTransformer<X0, X1>
    //     0x90ebd8: ldr             x1, [x1, #0x710]
    // 0x90ebdc: r0 = AllocateClosureTA()
    //     0x90ebdc: bl              #0x13dea48  ; AllocateClosureTAStub
    // 0x90ebe0: mov             x1, x0
    // 0x90ebe4: ldur            x0, [fp, #-0x18]
    // 0x90ebe8: StoreField: r0->field_b = r1
    //     0x90ebe8: stur            w1, [x0, #0xb]
    // 0x90ebec: LeaveFrame
    //     0x90ebec: mov             SP, fp
    //     0x90ebf0: ldp             fp, lr, [SP], #0x10
    // 0x90ebf4: ret
    //     0x90ebf4: ret             
  }
  [closure] static void <anonymous closure>(dynamic, Y0, EventSink<Uint8List>) {
    // ** addr: 0x90ec68, size: 0x164
    // 0x90ec68: EnterFrame
    //     0x90ec68: stp             fp, lr, [SP, #-0x10]!
    //     0x90ec6c: mov             fp, SP
    // 0x90ec70: AllocStack(0x18)
    //     0x90ec70: sub             SP, SP, #0x18
    // 0x90ec74: SetupParameters([dynamic _ /* r0 */])
    //     0x90ec74: ldr             x0, [fp, #0x20]
    //     0x90ec78: ldur            w3, [x0, #0x17]
    //     0x90ec7c: add             x3, x3, HEAP, lsl #32
    //     0x90ec80: stur            x3, [fp, #-8]
    // 0x90ec84: CheckStackOverflow
    //     0x90ec84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x90ec88: cmp             SP, x16
    //     0x90ec8c: b.ls            #0x90edc4
    // 0x90ec90: ldr             x4, [fp, #0x18]
    // 0x90ec94: r0 = LoadClassIdInstr(r4)
    //     0x90ec94: ldur            x0, [x4, #-1]
    //     0x90ec98: ubfx            x0, x0, #0xc, #0x14
    // 0x90ec9c: sub             x16, x0, #0x74
    // 0x90eca0: cmp             x16, #3
    // 0x90eca4: b.hi            #0x90ecdc
    // 0x90eca8: ldr             x0, [fp, #0x10]
    // 0x90ecac: r1 = LoadClassIdInstr(r0)
    //     0x90ecac: ldur            x1, [x0, #-1]
    //     0x90ecb0: ubfx            x1, x1, #0xc, #0x14
    // 0x90ecb4: mov             x16, x0
    // 0x90ecb8: mov             x0, x1
    // 0x90ecbc: mov             x1, x16
    // 0x90ecc0: mov             x2, x4
    // 0x90ecc4: r0 = GDT[cid_x0 + 0x1847a]()
    //     0x90ecc4: mov             x17, #0x847a
    //     0x90ecc8: movk            x17, #1, lsl #16
    //     0x90eccc: add             lr, x0, x17
    //     0x90ecd0: ldr             lr, [x21, lr, lsl #3]
    //     0x90ecd4: blr             lr
    // 0x90ecd8: b               #0x90ed18
    // 0x90ecdc: ldr             x0, [fp, #0x10]
    // 0x90ece0: ldr             x2, [fp, #0x18]
    // 0x90ece4: r1 = Null
    //     0x90ece4: mov             x1, NULL
    // 0x90ece8: r0 = Uint8List.fromList()
    //     0x90ece8: bl              #0x7ffaa0  ; [dart:typed_data] Uint8List::Uint8List.fromList
    // 0x90ecec: ldr             x1, [fp, #0x10]
    // 0x90ecf0: r2 = LoadClassIdInstr(r1)
    //     0x90ecf0: ldur            x2, [x1, #-1]
    //     0x90ecf4: ubfx            x2, x2, #0xc, #0x14
    // 0x90ecf8: mov             x16, x0
    // 0x90ecfc: mov             x0, x2
    // 0x90ed00: mov             x2, x16
    // 0x90ed04: r0 = GDT[cid_x0 + 0x1847a]()
    //     0x90ed04: mov             x17, #0x847a
    //     0x90ed08: movk            x17, #1, lsl #16
    //     0x90ed0c: add             lr, x0, x17
    //     0x90ed10: ldr             lr, [x21, lr, lsl #3]
    //     0x90ed14: blr             lr
    // 0x90ed18: ldur            x1, [fp, #-8]
    // 0x90ed1c: LoadField: r0 = r1->field_f
    //     0x90ed1c: ldur            w0, [x1, #0xf]
    // 0x90ed20: DecompressPointer r0
    //     0x90ed20: add             x0, x0, HEAP, lsl #32
    // 0x90ed24: cmp             w0, NULL
    // 0x90ed28: b.eq            #0x90edb4
    // 0x90ed2c: ldr             x0, [fp, #0x18]
    // 0x90ed30: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x90ed30: ldur            w2, [x1, #0x17]
    // 0x90ed34: DecompressPointer r2
    //     0x90ed34: add             x2, x2, HEAP, lsl #32
    // 0x90ed38: stur            x2, [fp, #-0x10]
    // 0x90ed3c: r3 = LoadClassIdInstr(r0)
    //     0x90ed3c: ldur            x3, [x0, #-1]
    //     0x90ed40: ubfx            x3, x3, #0xc, #0x14
    // 0x90ed44: str             x0, [SP]
    // 0x90ed48: mov             x0, x3
    // 0x90ed4c: r0 = GDT[cid_x0 + 0xf078]()
    //     0x90ed4c: mov             x17, #0xf078
    //     0x90ed50: add             lr, x0, x17
    //     0x90ed54: ldr             lr, [x21, lr, lsl #3]
    //     0x90ed58: blr             lr
    // 0x90ed5c: ldur            x2, [fp, #-0x10]
    // 0x90ed60: r3 = LoadInt32Instr(r2)
    //     0x90ed60: sbfx            x3, x2, #1, #0x1f
    //     0x90ed64: tbz             w2, #0, #0x90ed6c
    //     0x90ed68: ldur            x3, [x2, #7]
    // 0x90ed6c: r2 = LoadInt32Instr(r0)
    //     0x90ed6c: sbfx            x2, x0, #1, #0x1f
    //     0x90ed70: tbz             w0, #0, #0x90ed78
    //     0x90ed74: ldur            x2, [x0, #7]
    // 0x90ed78: add             x4, x3, x2
    // 0x90ed7c: r0 = BoxInt64Instr(r4)
    //     0x90ed7c: sbfiz           x0, x4, #1, #0x1f
    //     0x90ed80: cmp             x4, x0, asr #1
    //     0x90ed84: b.eq            #0x90ed90
    //     0x90ed88: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x90ed8c: stur            x4, [x0, #7]
    // 0x90ed90: ldur            x1, [fp, #-8]
    // 0x90ed94: ArrayStore: r1[0] = r0  ; List_4
    //     0x90ed94: stur            w0, [x1, #0x17]
    //     0x90ed98: tbz             w0, #0, #0x90edb4
    //     0x90ed9c: ldurb           w16, [x1, #-1]
    //     0x90eda0: ldurb           w17, [x0, #-1]
    //     0x90eda4: and             x16, x17, x16, lsr #2
    //     0x90eda8: tst             x16, HEAP, lsr #32
    //     0x90edac: b.eq            #0x90edb4
    //     0x90edb0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x90edb4: r0 = Null
    //     0x90edb4: mov             x0, NULL
    // 0x90edb8: LeaveFrame
    //     0x90edb8: mov             SP, fp
    //     0x90edbc: ldp             fp, lr, [SP], #0x10
    // 0x90edc0: ret
    //     0x90edc0: ret             
    // 0x90edc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x90edc4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x90edc8: b               #0x90ec90
  }
}
