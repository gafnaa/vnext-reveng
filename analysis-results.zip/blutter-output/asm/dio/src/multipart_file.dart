// lib: , url: package:dio/src/multipart_file.dart

// class id: 1048706, size: 0x8
class :: {
}

// class id: 3402, size: 0x24, field offset: 0x8
class MultipartFile extends Object {

  [closure] Uint8List <anonymous closure>(dynamic, List<int>) {
    // ** addr: 0x910b60, size: 0x4c
    // 0x910b60: EnterFrame
    //     0x910b60: stp             fp, lr, [SP, #-0x10]!
    //     0x910b64: mov             fp, SP
    // 0x910b68: CheckStackOverflow
    //     0x910b68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x910b6c: cmp             SP, x16
    //     0x910b70: b.ls            #0x910ba4
    // 0x910b74: ldr             x0, [fp, #0x10]
    // 0x910b78: r1 = LoadClassIdInstr(r0)
    //     0x910b78: ldur            x1, [x0, #-1]
    //     0x910b7c: ubfx            x1, x1, #0xc, #0x14
    // 0x910b80: sub             x16, x1, #0x74
    // 0x910b84: cmp             x16, #3
    // 0x910b88: b.ls            #0x910b98
    // 0x910b8c: mov             x2, x0
    // 0x910b90: r1 = Null
    //     0x910b90: mov             x1, NULL
    // 0x910b94: r0 = Uint8List.fromList()
    //     0x910b94: bl              #0x7ffaa0  ; [dart:typed_data] Uint8List::Uint8List.fromList
    // 0x910b98: LeaveFrame
    //     0x910b98: mov             SP, fp
    //     0x910b9c: ldp             fp, lr, [SP], #0x10
    // 0x910ba0: ret
    //     0x910ba0: ret             
    // 0x910ba4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x910ba4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x910ba8: b               #0x910b74
  }
  _ MultipartFile.fromStream(/* No info */) {
    // ** addr: 0xe66200, size: 0xe8
    // 0xe66200: EnterFrame
    //     0xe66200: stp             fp, lr, [SP, #-0x10]!
    //     0xe66204: mov             fp, SP
    // 0xe66208: AllocStack(0x20)
    //     0xe66208: sub             SP, SP, #0x20
    // 0xe6620c: r0 = false
    //     0xe6620c: add             x0, NULL, #0x30  ; false
    // 0xe66210: mov             x4, x2
    // 0xe66214: mov             x2, x5
    // 0xe66218: stur            x5, [fp, #-0x10]
    // 0xe6621c: mov             x5, x1
    // 0xe66220: stur            x1, [fp, #-8]
    // 0xe66224: mov             x1, x6
    // 0xe66228: CheckStackOverflow
    //     0xe66228: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe6622c: cmp             SP, x16
    //     0xe66230: b.ls            #0xe662e0
    // 0xe66234: StoreField: r5->field_1f = r0
    //     0xe66234: stur            w0, [x5, #0x1f]
    // 0xe66238: StoreField: r5->field_7 = r3
    //     0xe66238: stur            x3, [x5, #7]
    // 0xe6623c: mov             x0, x1
    // 0xe66240: StoreField: r5->field_f = r0
    //     0xe66240: stur            w0, [x5, #0xf]
    //     0xe66244: ldurb           w16, [x5, #-1]
    //     0xe66248: ldurb           w17, [x0, #-1]
    //     0xe6624c: and             x16, x17, x16, lsr #2
    //     0xe66250: tst             x16, HEAP, lsr #32
    //     0xe66254: b.eq            #0xe6625c
    //     0xe66258: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0xe6625c: mov             x0, x4
    // 0xe66260: StoreField: r5->field_1b = r0
    //     0xe66260: stur            w0, [x5, #0x1b]
    //     0xe66264: ldurb           w16, [x5, #-1]
    //     0xe66268: ldurb           w17, [x0, #-1]
    //     0xe6626c: and             x16, x17, x16, lsr #2
    //     0xe66270: tst             x16, HEAP, lsr #32
    //     0xe66274: b.eq            #0xe6627c
    //     0xe66278: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0xe6627c: r16 = <List<String>>
    //     0xe6627c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15358] TypeArguments: <List<String>>
    //     0xe66280: ldr             x16, [x16, #0x358]
    // 0xe66284: stp             NULL, x16, [SP]
    // 0xe66288: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xe66288: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xe6628c: r0 = caseInsensitiveKeyMap()
    //     0xe6628c: bl              #0x8eb034  ; [package:dio/src/utils.dart] ::caseInsensitiveKeyMap
    // 0xe66290: ldur            x1, [fp, #-8]
    // 0xe66294: StoreField: r1->field_13 = r0
    //     0xe66294: stur            w0, [x1, #0x13]
    //     0xe66298: ldurb           w16, [x1, #-1]
    //     0xe6629c: ldurb           w17, [x0, #-1]
    //     0xe662a0: and             x16, x17, x16, lsr #2
    //     0xe662a4: tst             x16, HEAP, lsr #32
    //     0xe662a8: b.eq            #0xe662b0
    //     0xe662ac: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xe662b0: ldur            x0, [fp, #-0x10]
    // 0xe662b4: ArrayStore: r1[0] = r0  ; List_4
    //     0xe662b4: stur            w0, [x1, #0x17]
    //     0xe662b8: ldurb           w16, [x1, #-1]
    //     0xe662bc: ldurb           w17, [x0, #-1]
    //     0xe662c0: and             x16, x17, x16, lsr #2
    //     0xe662c4: tst             x16, HEAP, lsr #32
    //     0xe662c8: b.eq            #0xe662d0
    //     0xe662cc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xe662d0: r0 = Null
    //     0xe662d0: mov             x0, NULL
    // 0xe662d4: LeaveFrame
    //     0xe662d4: mov             SP, fp
    //     0xe662d8: ldp             fp, lr, [SP], #0x10
    // 0xe662dc: ret
    //     0xe662dc: ret             
    // 0xe662e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe662e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe662e4: b               #0xe66234
  }
}
