// lib: , url: package:dio/src/utils.dart

// class id: 1048717, size: 0x8
class :: {

  static Map<String, Y0> caseInsensitiveKeyMap<Y0>([Map<String, Y0>?]) {
    // ** addr: 0x8eb034, size: 0x13c
    // 0x8eb034: EnterFrame
    //     0x8eb034: stp             fp, lr, [SP, #-0x10]!
    //     0x8eb038: mov             fp, SP
    // 0x8eb03c: AllocStack(0x20)
    //     0x8eb03c: sub             SP, SP, #0x20
    // 0x8eb040: SetupParameters([dynamic _ = Null /* r0, fp-0x10 */])
    //     0x8eb040: ldur            w0, [x4, #0x13]
    //     0x8eb044: cmp             w0, #2
    //     0x8eb048: b.lt            #0x8eb05c
    //     0x8eb04c: add             x1, fp, w0, sxtw #2
    //     0x8eb050: ldr             x1, [x1, #8]
    //     0x8eb054: mov             x0, x1
    //     0x8eb058: b               #0x8eb060
    //     0x8eb05c: mov             x0, NULL
    //     0x8eb060: stur            x0, [fp, #-0x10]
    //     0x8eb064: ldur            w1, [x4, #0xf]
    //     0x8eb068: cbnz            w1, #0x8eb074
    //     0x8eb06c: mov             x3, NULL
    //     0x8eb070: b               #0x8eb084
    //     0x8eb074: ldur            w1, [x4, #0x17]
    //     0x8eb078: add             x2, fp, w1, sxtw #2
    //     0x8eb07c: ldr             x2, [x2, #0x10]
    //     0x8eb080: mov             x3, x2
    //     0x8eb084: stur            x3, [fp, #-8]
    // 0x8eb088: CheckStackOverflow
    //     0x8eb088: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8eb08c: cmp             SP, x16
    //     0x8eb090: b.ls            #0x8eb168
    // 0x8eb094: r1 = Function '<anonymous closure>': static.
    //     0x8eb094: add             x1, PP, #0x15, lsl #12  ; [pp+0x15db0] AnonymousClosure: (0x8eb92c), in [package:http/src/base_request.dart] BaseRequest::BaseRequest (0x8eb738)
    //     0x8eb098: ldr             x1, [x1, #0xdb0]
    // 0x8eb09c: r2 = Null
    //     0x8eb09c: mov             x2, NULL
    // 0x8eb0a0: r0 = AllocateClosure()
    //     0x8eb0a0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8eb0a4: mov             x3, x0
    // 0x8eb0a8: ldur            x0, [fp, #-8]
    // 0x8eb0ac: stur            x3, [fp, #-0x18]
    // 0x8eb0b0: StoreField: r3->field_b = r0
    //     0x8eb0b0: stur            w0, [x3, #0xb]
    // 0x8eb0b4: r1 = Function '<anonymous closure>': static.
    //     0x8eb0b4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15db8] AnonymousClosure: (0x8eb6cc), in [package:http/src/base_request.dart] BaseRequest::BaseRequest (0x8eb738)
    //     0x8eb0b8: ldr             x1, [x1, #0xdb8]
    // 0x8eb0bc: r2 = Null
    //     0x8eb0bc: mov             x2, NULL
    // 0x8eb0c0: r0 = AllocateClosure()
    //     0x8eb0c0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8eb0c4: ldur            x1, [fp, #-8]
    // 0x8eb0c8: stur            x0, [fp, #-0x20]
    // 0x8eb0cc: StoreField: r0->field_b = r1
    //     0x8eb0cc: stur            w1, [x0, #0xb]
    // 0x8eb0d0: r2 = Null
    //     0x8eb0d0: mov             x2, NULL
    // 0x8eb0d4: r3 = <String, Y0>
    //     0x8eb0d4: add             x3, PP, #0x15, lsl #12  ; [pp+0x15dc0] TypeArguments: <String, Y0>
    //     0x8eb0d8: ldr             x3, [x3, #0xdc0]
    // 0x8eb0dc: r30 = InstantiateTypeArgumentsStub
    //     0x8eb0dc: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0x8eb0e0: LoadField: r30 = r30->field_7
    //     0x8eb0e0: ldur            lr, [lr, #7]
    // 0x8eb0e4: blr             lr
    // 0x8eb0e8: mov             x1, x0
    // 0x8eb0ec: ldur            x2, [fp, #-0x18]
    // 0x8eb0f0: ldur            x3, [fp, #-0x20]
    // 0x8eb0f4: r0 = LinkedHashMap()
    //     0x8eb0f4: bl              #0x8eb170  ; [dart:collection] LinkedHashMap::LinkedHashMap
    // 0x8eb0f8: mov             x3, x0
    // 0x8eb0fc: ldur            x2, [fp, #-0x10]
    // 0x8eb100: stur            x3, [fp, #-8]
    // 0x8eb104: cmp             w2, NULL
    // 0x8eb108: b.eq            #0x8eb158
    // 0x8eb10c: r0 = LoadClassIdInstr(r2)
    //     0x8eb10c: ldur            x0, [x2, #-1]
    //     0x8eb110: ubfx            x0, x0, #0xc, #0x14
    // 0x8eb114: mov             x1, x2
    // 0x8eb118: r0 = GDT[cid_x0 + 0x121ec]()
    //     0x8eb118: mov             x17, #0x21ec
    //     0x8eb11c: movk            x17, #1, lsl #16
    //     0x8eb120: add             lr, x0, x17
    //     0x8eb124: ldr             lr, [x21, lr, lsl #3]
    //     0x8eb128: blr             lr
    // 0x8eb12c: tbnz            w0, #4, #0x8eb158
    // 0x8eb130: ldur            x3, [fp, #-8]
    // 0x8eb134: r0 = LoadClassIdInstr(r3)
    //     0x8eb134: ldur            x0, [x3, #-1]
    //     0x8eb138: ubfx            x0, x0, #0xc, #0x14
    // 0x8eb13c: mov             x1, x3
    // 0x8eb140: ldur            x2, [fp, #-0x10]
    // 0x8eb144: r0 = GDT[cid_x0 + 0x12862]()
    //     0x8eb144: mov             x17, #0x2862
    //     0x8eb148: movk            x17, #1, lsl #16
    //     0x8eb14c: add             lr, x0, x17
    //     0x8eb150: ldr             lr, [x21, lr, lsl #3]
    //     0x8eb154: blr             lr
    // 0x8eb158: ldur            x0, [fp, #-8]
    // 0x8eb15c: LeaveFrame
    //     0x8eb15c: mov             SP, fp
    //     0x8eb160: ldp             fp, lr, [SP], #0x10
    // 0x8eb164: ret
    //     0x8eb164: ret             
    // 0x8eb168: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8eb168: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8eb16c: b               #0x8eb094
  }
  static _ encodeMap(/* No info */) {
    // ** addr: 0x90c9c0, size: 0x280
    // 0x90c9c0: EnterFrame
    //     0x90c9c0: stp             fp, lr, [SP, #-0x10]!
    //     0x90c9c4: mov             fp, SP
    // 0x90c9c8: AllocStack(0x40)
    //     0x90c9c8: sub             SP, SP, #0x40
    // 0x90c9cc: SetupParameters(dynamic _ /* r1 => r1, fp-0x18 */, dynamic _ /* r2 => r2, fp-0x20 */, {dynamic encode = true /* r5, fp-0x10 */, dynamic isQuery = false /* r0, fp-0x8 */})
    //     0x90c9cc: stur            x1, [fp, #-0x18]
    //     0x90c9d0: stur            x2, [fp, #-0x20]
    //     0x90c9d4: ldur            w0, [x4, #0x13]
    //     0x90c9d8: ldur            w3, [x4, #0x1f]
    //     0x90c9dc: add             x3, x3, HEAP, lsl #32
    //     0x90c9e0: add             x16, PP, #0x16, lsl #12  ; [pp+0x165a8] "encode"
    //     0x90c9e4: ldr             x16, [x16, #0x5a8]
    //     0x90c9e8: cmp             w3, w16
    //     0x90c9ec: b.ne            #0x90ca10
    //     0x90c9f0: ldur            w3, [x4, #0x23]
    //     0x90c9f4: add             x3, x3, HEAP, lsl #32
    //     0x90c9f8: sub             w5, w0, w3
    //     0x90c9fc: add             x3, fp, w5, sxtw #2
    //     0x90ca00: ldr             x3, [x3, #8]
    //     0x90ca04: mov             x5, x3
    //     0x90ca08: mov             x3, #1
    //     0x90ca0c: b               #0x90ca18
    //     0x90ca10: add             x5, NULL, #0x20  ; true
    //     0x90ca14: mov             x3, #0
    //     0x90ca18: stur            x5, [fp, #-0x10]
    //     0x90ca1c: lsl             x6, x3, #1
    //     0x90ca20: lsl             w3, w6, #1
    //     0x90ca24: add             w6, w3, #8
    //     0x90ca28: add             x16, x4, w6, sxtw #1
    //     0x90ca2c: ldur            w7, [x16, #0xf]
    //     0x90ca30: add             x7, x7, HEAP, lsl #32
    //     0x90ca34: add             x16, PP, #0x16, lsl #12  ; [pp+0x165b0] "isQuery"
    //     0x90ca38: ldr             x16, [x16, #0x5b0]
    //     0x90ca3c: cmp             w7, w16
    //     0x90ca40: b.ne            #0x90ca64
    //     0x90ca44: add             w6, w3, #0xa
    //     0x90ca48: add             x16, x4, w6, sxtw #1
    //     0x90ca4c: ldur            w3, [x16, #0xf]
    //     0x90ca50: add             x3, x3, HEAP, lsl #32
    //     0x90ca54: sub             w4, w0, w3
    //     0x90ca58: add             x0, fp, w4, sxtw #2
    //     0x90ca5c: ldr             x0, [x0, #8]
    //     0x90ca60: b               #0x90ca68
    //     0x90ca64: add             x0, NULL, #0x30  ; false
    //     0x90ca68: stur            x0, [fp, #-8]
    // 0x90ca6c: CheckStackOverflow
    //     0x90ca6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x90ca70: cmp             SP, x16
    //     0x90ca74: b.ls            #0x90cc38
    // 0x90ca78: r1 = 9
    //     0x90ca78: mov             x1, #9
    // 0x90ca7c: r0 = AllocateContext()
    //     0x90ca7c: bl              #0x13de838  ; AllocateContextStub
    // 0x90ca80: mov             x1, x0
    // 0x90ca84: ldur            x0, [fp, #-0x20]
    // 0x90ca88: stur            x1, [fp, #-0x28]
    // 0x90ca8c: StoreField: r1->field_f = r0
    //     0x90ca8c: stur            w0, [x1, #0xf]
    // 0x90ca90: ldur            x0, [fp, #-8]
    // 0x90ca94: StoreField: r1->field_13 = r0
    //     0x90ca94: stur            w0, [x1, #0x13]
    // 0x90ca98: r0 = StringBuffer()
    //     0x90ca98: bl              #0x7e51d4  ; AllocateStringBufferStub -> StringBuffer (size=0x38)
    // 0x90ca9c: stur            x0, [fp, #-8]
    // 0x90caa0: r16 = ""
    //     0x90caa0: ldr             x16, [PP, #0x900]  ; [pp+0x900] ""
    // 0x90caa4: str             x16, [SP]
    // 0x90caa8: mov             x1, x0
    // 0x90caac: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x90caac: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x90cab0: r0 = StringBuffer()
    //     0x90cab0: bl              #0x7e4a4c  ; [dart:core] StringBuffer::StringBuffer
    // 0x90cab4: ldur            x0, [fp, #-8]
    // 0x90cab8: ldur            x3, [fp, #-0x28]
    // 0x90cabc: ArrayStore: r3[0] = r0  ; List_4
    //     0x90cabc: stur            w0, [x3, #0x17]
    //     0x90cac0: ldurb           w16, [x3, #-1]
    //     0x90cac4: ldurb           w17, [x0, #-1]
    //     0x90cac8: and             x16, x17, x16, lsr #2
    //     0x90cacc: tst             x16, HEAP, lsr #32
    //     0x90cad0: b.eq            #0x90cad8
    //     0x90cad4: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x90cad8: r0 = true
    //     0x90cad8: add             x0, NULL, #0x20  ; true
    // 0x90cadc: StoreField: r3->field_1b = r0
    //     0x90cadc: stur            w0, [x3, #0x1b]
    // 0x90cae0: LoadField: r1 = r3->field_13
    //     0x90cae0: ldur            w1, [x3, #0x13]
    // 0x90cae4: DecompressPointer r1
    //     0x90cae4: add             x1, x1, HEAP, lsl #32
    // 0x90cae8: tbnz            w1, #4, #0x90caf4
    // 0x90caec: ldur            x2, [fp, #-0x10]
    // 0x90caf0: b               #0x90cafc
    // 0x90caf4: ldur            x2, [fp, #-0x10]
    // 0x90caf8: tbz             w2, #4, #0x90cb04
    // 0x90cafc: r0 = "["
    //     0x90cafc: ldr             x0, [PP, #0x1290]  ; [pp+0x1290] "["
    // 0x90cb00: b               #0x90cb0c
    // 0x90cb04: r0 = "%5B"
    //     0x90cb04: add             x0, PP, #0x16, lsl #12  ; [pp+0x165b8] "%5B"
    //     0x90cb08: ldr             x0, [x0, #0x5b8]
    // 0x90cb0c: StoreField: r3->field_1f = r0
    //     0x90cb0c: stur            w0, [x3, #0x1f]
    //     0x90cb10: ldurb           w16, [x3, #-1]
    //     0x90cb14: ldurb           w17, [x0, #-1]
    //     0x90cb18: and             x16, x17, x16, lsr #2
    //     0x90cb1c: tst             x16, HEAP, lsr #32
    //     0x90cb20: b.eq            #0x90cb28
    //     0x90cb24: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x90cb28: tbz             w1, #4, #0x90cb30
    // 0x90cb2c: tbz             w2, #4, #0x90cb38
    // 0x90cb30: r0 = "]"
    //     0x90cb30: ldr             x0, [PP, #0x1298]  ; [pp+0x1298] "]"
    // 0x90cb34: b               #0x90cb40
    // 0x90cb38: r0 = "%5D"
    //     0x90cb38: add             x0, PP, #0x16, lsl #12  ; [pp+0x165c0] "%5D"
    //     0x90cb3c: ldr             x0, [x0, #0x5c0]
    // 0x90cb40: StoreField: r3->field_23 = r0
    //     0x90cb40: stur            w0, [x3, #0x23]
    //     0x90cb44: ldurb           w16, [x3, #-1]
    //     0x90cb48: ldurb           w17, [x0, #-1]
    //     0x90cb4c: and             x16, x17, x16, lsr #2
    //     0x90cb50: tst             x16, HEAP, lsr #32
    //     0x90cb54: b.eq            #0x90cb5c
    //     0x90cb58: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x90cb5c: tbnz            w2, #4, #0x90cb6c
    // 0x90cb60: r0 = Closure: (String, {Encoding encoding}) => String from Function 'encodeQueryComponent': static.
    //     0x90cb60: add             x0, PP, #0x16, lsl #12  ; [pp+0x165c8] Closure: (String, {Encoding encoding}) => String from Function 'encodeQueryComponent': static. (0x7f2ada6ce508)
    //     0x90cb64: ldr             x0, [x0, #0x5c8]
    // 0x90cb68: b               #0x90cb80
    // 0x90cb6c: r1 = Function '<anonymous closure>': static.
    //     0x90cb6c: add             x1, PP, #0x16, lsl #12  ; [pp+0x165d0] AnonymousClosure: (0x13dae90), in [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::_mergeSiblingGroup (0x891814)
    //     0x90cb70: ldr             x1, [x1, #0x5d0]
    // 0x90cb74: r2 = Null
    //     0x90cb74: mov             x2, NULL
    // 0x90cb78: r0 = AllocateClosure()
    //     0x90cb78: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x90cb7c: ldur            x3, [fp, #-0x28]
    // 0x90cb80: StoreField: r3->field_27 = r0
    //     0x90cb80: stur            w0, [x3, #0x27]
    //     0x90cb84: ldurb           w16, [x3, #-1]
    //     0x90cb88: ldurb           w17, [x0, #-1]
    //     0x90cb8c: and             x16, x17, x16, lsr #2
    //     0x90cb90: tst             x16, HEAP, lsr #32
    //     0x90cb94: b.eq            #0x90cb9c
    //     0x90cb98: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x90cb9c: mov             x2, x3
    // 0x90cba0: r1 = Function 'maybeEncode': static.
    //     0x90cba0: add             x1, PP, #0x16, lsl #12  ; [pp+0x165d8] AnonymousClosure: static (0x90d660), in [package:dio/src/utils.dart] ::encodeMap (0x90c9c0)
    //     0x90cba4: ldr             x1, [x1, #0x5d8]
    // 0x90cba8: r0 = AllocateClosure()
    //     0x90cba8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x90cbac: ldur            x3, [fp, #-0x28]
    // 0x90cbb0: StoreField: r3->field_2b = r0
    //     0x90cbb0: stur            w0, [x3, #0x2b]
    //     0x90cbb4: ldurb           w16, [x3, #-1]
    //     0x90cbb8: ldurb           w17, [x0, #-1]
    //     0x90cbbc: and             x16, x17, x16, lsr #2
    //     0x90cbc0: tst             x16, HEAP, lsr #32
    //     0x90cbc4: b.eq            #0x90cbcc
    //     0x90cbc8: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x90cbcc: mov             x2, x3
    // 0x90cbd0: r1 = Function 'urlEncode': static.
    //     0x90cbd0: add             x1, PP, #0x16, lsl #12  ; [pp+0x165e0] AnonymousClosure: static (0x90cc40), in [package:dio/src/utils.dart] ::encodeMap (0x90c9c0)
    //     0x90cbd4: ldr             x1, [x1, #0x5e0]
    // 0x90cbd8: r0 = AllocateClosure()
    //     0x90cbd8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x90cbdc: mov             x2, x0
    // 0x90cbe0: ldur            x1, [fp, #-0x28]
    // 0x90cbe4: StoreField: r1->field_2f = r0
    //     0x90cbe4: stur            w0, [x1, #0x2f]
    //     0x90cbe8: ldurb           w16, [x1, #-1]
    //     0x90cbec: ldurb           w17, [x0, #-1]
    //     0x90cbf0: and             x16, x17, x16, lsr #2
    //     0x90cbf4: tst             x16, HEAP, lsr #32
    //     0x90cbf8: b.eq            #0x90cc00
    //     0x90cbfc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x90cc00: ldur            x16, [fp, #-0x18]
    // 0x90cc04: stp             x16, x2, [SP, #8]
    // 0x90cc08: r16 = ""
    //     0x90cc08: ldr             x16, [PP, #0x900]  ; [pp+0x900] ""
    // 0x90cc0c: str             x16, [SP]
    // 0x90cc10: mov             x0, x2
    // 0x90cc14: ClosureCall
    //     0x90cc14: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x90cc18: ldur            x2, [x0, #0x1f]
    //     0x90cc1c: blr             x2
    // 0x90cc20: ldur            x16, [fp, #-8]
    // 0x90cc24: str             x16, [SP]
    // 0x90cc28: r0 = toString()
    //     0x90cc28: bl              #0x1101d44  ; [dart:core] StringBuffer::toString
    // 0x90cc2c: LeaveFrame
    //     0x90cc2c: mov             SP, fp
    //     0x90cc30: ldp             fp, lr, [SP], #0x10
    // 0x90cc34: ret
    //     0x90cc34: ret             
    // 0x90cc38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x90cc38: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x90cc3c: b               #0x90ca78
  }
  [closure] static void urlEncode(dynamic, Object?, String) {
    // ** addr: 0x90cc40, size: 0x6d4
    // 0x90cc40: EnterFrame
    //     0x90cc40: stp             fp, lr, [SP, #-0x10]!
    //     0x90cc44: mov             fp, SP
    // 0x90cc48: AllocStack(0x80)
    //     0x90cc48: sub             SP, SP, #0x80
    // 0x90cc4c: SetupParameters([dynamic _ /* r0 */])
    //     0x90cc4c: ldr             x0, [fp, #0x20]
    //     0x90cc50: ldur            w1, [x0, #0x17]
    //     0x90cc54: add             x1, x1, HEAP, lsl #32
    //     0x90cc58: stur            x1, [fp, #-8]
    // 0x90cc5c: CheckStackOverflow
    //     0x90cc5c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x90cc60: cmp             SP, x16
    //     0x90cc64: b.ls            #0x90d304
    // 0x90cc68: r1 = 1
    //     0x90cc68: mov             x1, #1
    // 0x90cc6c: r0 = AllocateContext()
    //     0x90cc6c: bl              #0x13de838  ; AllocateContextStub
    // 0x90cc70: mov             x4, x0
    // 0x90cc74: ldur            x3, [fp, #-8]
    // 0x90cc78: stur            x4, [fp, #-0x10]
    // 0x90cc7c: StoreField: r4->field_b = r3
    //     0x90cc7c: stur            w3, [x4, #0xb]
    // 0x90cc80: ldr             x5, [fp, #0x10]
    // 0x90cc84: StoreField: r4->field_f = r5
    //     0x90cc84: stur            w5, [x4, #0xf]
    // 0x90cc88: ldr             x0, [fp, #0x18]
    // 0x90cc8c: r2 = Null
    //     0x90cc8c: mov             x2, NULL
    // 0x90cc90: r1 = Null
    //     0x90cc90: mov             x1, NULL
    // 0x90cc94: cmp             w0, NULL
    // 0x90cc98: b.eq            #0x90cd3c
    // 0x90cc9c: branchIfSmi(r0, 0x90cd3c)
    //     0x90cc9c: tbz             w0, #0, #0x90cd3c
    // 0x90cca0: r3 = LoadClassIdInstr(r0)
    //     0x90cca0: ldur            x3, [x0, #-1]
    //     0x90cca4: ubfx            x3, x3, #0xc, #0x14
    // 0x90cca8: r17 = 7631
    //     0x90cca8: mov             x17, #0x1dcf
    // 0x90ccac: cmp             x3, x17
    // 0x90ccb0: b.eq            #0x90cd44
    // 0x90ccb4: sub             x3, x3, #0x5a
    // 0x90ccb8: cmp             x3, #2
    // 0x90ccbc: b.ls            #0x90cd44
    // 0x90ccc0: r4 = LoadClassIdInstr(r0)
    //     0x90ccc0: ldur            x4, [x0, #-1]
    //     0x90ccc4: ubfx            x4, x4, #0xc, #0x14
    // 0x90ccc8: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x90cccc: ldr             x3, [x3, #0x18]
    // 0x90ccd0: ldr             x3, [x3, x4, lsl #3]
    // 0x90ccd4: LoadField: r3 = r3->field_2b
    //     0x90ccd4: ldur            w3, [x3, #0x2b]
    // 0x90ccd8: DecompressPointer r3
    //     0x90ccd8: add             x3, x3, HEAP, lsl #32
    // 0x90ccdc: cmp             w3, NULL
    // 0x90cce0: b.eq            #0x90cd3c
    // 0x90cce4: LoadField: r3 = r3->field_f
    //     0x90cce4: ldur            w3, [x3, #0xf]
    // 0x90cce8: lsr             x3, x3, #3
    // 0x90ccec: r17 = 7631
    //     0x90ccec: mov             x17, #0x1dcf
    // 0x90ccf0: cmp             x3, x17
    // 0x90ccf4: b.eq            #0x90cd44
    // 0x90ccf8: r3 = SubtypeTestCache
    //     0x90ccf8: add             x3, PP, #0x16, lsl #12  ; [pp+0x165e8] SubtypeTestCache
    //     0x90ccfc: ldr             x3, [x3, #0x5e8]
    // 0x90cd00: r30 = Subtype1TestCacheStub
    //     0x90cd00: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x90cd04: LoadField: r30 = r30->field_7
    //     0x90cd04: ldur            lr, [lr, #7]
    // 0x90cd08: blr             lr
    // 0x90cd0c: cmp             w7, NULL
    // 0x90cd10: b.eq            #0x90cd1c
    // 0x90cd14: tbnz            w7, #4, #0x90cd3c
    // 0x90cd18: b               #0x90cd44
    // 0x90cd1c: r8 = List
    //     0x90cd1c: add             x8, PP, #0x16, lsl #12  ; [pp+0x165f0] Type: List
    //     0x90cd20: ldr             x8, [x8, #0x5f0]
    // 0x90cd24: r3 = SubtypeTestCache
    //     0x90cd24: add             x3, PP, #0x16, lsl #12  ; [pp+0x165f8] SubtypeTestCache
    //     0x90cd28: ldr             x3, [x3, #0x5f8]
    // 0x90cd2c: r30 = InstanceOfStub
    //     0x90cd2c: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x90cd30: LoadField: r30 = r30->field_7
    //     0x90cd30: ldur            lr, [lr, #7]
    // 0x90cd34: blr             lr
    // 0x90cd38: b               #0x90cd48
    // 0x90cd3c: r0 = false
    //     0x90cd3c: add             x0, NULL, #0x30  ; false
    // 0x90cd40: b               #0x90cd48
    // 0x90cd44: r0 = true
    //     0x90cd44: add             x0, NULL, #0x20  ; true
    // 0x90cd48: tbnz            w0, #4, #0x90d154
    // 0x90cd4c: ldur            x3, [fp, #-8]
    // 0x90cd50: LoadField: r1 = r3->field_2f
    //     0x90cd50: ldur            w1, [x3, #0x2f]
    // 0x90cd54: DecompressPointer r1
    //     0x90cd54: add             x1, x1, HEAP, lsl #32
    // 0x90cd58: stur            x1, [fp, #-0x40]
    // 0x90cd5c: LoadField: r0 = r3->field_2b
    //     0x90cd5c: ldur            w0, [x3, #0x2b]
    // 0x90cd60: DecompressPointer r0
    //     0x90cd60: add             x0, x0, HEAP, lsl #32
    // 0x90cd64: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x90cd64: ldur            w2, [x0, #0x17]
    // 0x90cd68: DecompressPointer r2
    //     0x90cd68: add             x2, x2, HEAP, lsl #32
    // 0x90cd6c: stur            x2, [fp, #-0x38]
    // 0x90cd70: LoadField: r4 = r2->field_27
    //     0x90cd70: ldur            w4, [x2, #0x27]
    // 0x90cd74: DecompressPointer r4
    //     0x90cd74: add             x4, x4, HEAP, lsl #32
    // 0x90cd78: stur            x4, [fp, #-0x30]
    // 0x90cd7c: LoadField: r5 = r3->field_1f
    //     0x90cd7c: ldur            w5, [x3, #0x1f]
    // 0x90cd80: DecompressPointer r5
    //     0x90cd80: add             x5, x5, HEAP, lsl #32
    // 0x90cd84: stur            x5, [fp, #-0x28]
    // 0x90cd88: LoadField: r6 = r3->field_23
    //     0x90cd88: ldur            w6, [x3, #0x23]
    // 0x90cd8c: DecompressPointer r6
    //     0x90cd8c: add             x6, x6, HEAP, lsl #32
    // 0x90cd90: stur            x6, [fp, #-0x20]
    // 0x90cd94: r8 = 0
    //     0x90cd94: mov             x8, #0
    // 0x90cd98: ldr             x7, [fp, #0x18]
    // 0x90cd9c: ldur            x3, [fp, #-0x10]
    // 0x90cda0: stur            x8, [fp, #-0x18]
    // 0x90cda4: CheckStackOverflow
    //     0x90cda4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x90cda8: cmp             SP, x16
    //     0x90cdac: b.ls            #0x90d30c
    // 0x90cdb0: r0 = LoadClassIdInstr(r7)
    //     0x90cdb0: ldur            x0, [x7, #-1]
    //     0x90cdb4: ubfx            x0, x0, #0xc, #0x14
    // 0x90cdb8: str             x7, [SP]
    // 0x90cdbc: r0 = GDT[cid_x0 + 0xf078]()
    //     0x90cdbc: mov             x17, #0xf078
    //     0x90cdc0: add             lr, x0, x17
    //     0x90cdc4: ldr             lr, [x21, lr, lsl #3]
    //     0x90cdc8: blr             lr
    // 0x90cdcc: r1 = LoadInt32Instr(r0)
    //     0x90cdcc: sbfx            x1, x0, #1, #0x1f
    //     0x90cdd0: tbz             w0, #0, #0x90cdd8
    //     0x90cdd4: ldur            x1, [x0, #7]
    // 0x90cdd8: ldur            x2, [fp, #-0x18]
    // 0x90cddc: cmp             x2, x1
    // 0x90cde0: b.ge            #0x90d2f4
    // 0x90cde4: ldr             x3, [fp, #0x18]
    // 0x90cde8: r0 = BoxInt64Instr(r2)
    //     0x90cde8: sbfiz           x0, x2, #1, #0x1f
    //     0x90cdec: cmp             x2, x0, asr #1
    //     0x90cdf0: b.eq            #0x90cdfc
    //     0x90cdf4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x90cdf8: stur            x2, [x0, #7]
    // 0x90cdfc: mov             x1, x0
    // 0x90ce00: stur            x1, [fp, #-0x48]
    // 0x90ce04: r0 = LoadClassIdInstr(r3)
    //     0x90ce04: ldur            x0, [x3, #-1]
    //     0x90ce08: ubfx            x0, x0, #0xc, #0x14
    // 0x90ce0c: stp             x1, x3, [SP]
    // 0x90ce10: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x90ce10: sub             lr, x0, #0xdfd
    //     0x90ce14: ldr             lr, [x21, lr, lsl #3]
    //     0x90ce18: blr             lr
    // 0x90ce1c: r2 = Null
    //     0x90ce1c: mov             x2, NULL
    // 0x90ce20: r1 = Null
    //     0x90ce20: mov             x1, NULL
    // 0x90ce24: cmp             w0, NULL
    // 0x90ce28: b.eq            #0x90cec0
    // 0x90ce2c: branchIfSmi(r0, 0x90cec0)
    //     0x90ce2c: tbz             w0, #0, #0x90cec0
    // 0x90ce30: r3 = LoadClassIdInstr(r0)
    //     0x90ce30: ldur            x3, [x0, #-1]
    //     0x90ce34: ubfx            x3, x3, #0xc, #0x14
    // 0x90ce38: r17 = 7630
    //     0x90ce38: mov             x17, #0x1dce
    // 0x90ce3c: cmp             x3, x17
    // 0x90ce40: b.eq            #0x90cec8
    // 0x90ce44: r4 = LoadClassIdInstr(r0)
    //     0x90ce44: ldur            x4, [x0, #-1]
    //     0x90ce48: ubfx            x4, x4, #0xc, #0x14
    // 0x90ce4c: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x90ce50: ldr             x3, [x3, #0x18]
    // 0x90ce54: ldr             x3, [x3, x4, lsl #3]
    // 0x90ce58: LoadField: r3 = r3->field_2b
    //     0x90ce58: ldur            w3, [x3, #0x2b]
    // 0x90ce5c: DecompressPointer r3
    //     0x90ce5c: add             x3, x3, HEAP, lsl #32
    // 0x90ce60: cmp             w3, NULL
    // 0x90ce64: b.eq            #0x90cec0
    // 0x90ce68: LoadField: r3 = r3->field_f
    //     0x90ce68: ldur            w3, [x3, #0xf]
    // 0x90ce6c: lsr             x3, x3, #3
    // 0x90ce70: r17 = 7630
    //     0x90ce70: mov             x17, #0x1dce
    // 0x90ce74: cmp             x3, x17
    // 0x90ce78: b.eq            #0x90cec8
    // 0x90ce7c: r3 = SubtypeTestCache
    //     0x90ce7c: add             x3, PP, #0x16, lsl #12  ; [pp+0x16600] SubtypeTestCache
    //     0x90ce80: ldr             x3, [x3, #0x600]
    // 0x90ce84: r30 = Subtype1TestCacheStub
    //     0x90ce84: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x90ce88: LoadField: r30 = r30->field_7
    //     0x90ce88: ldur            lr, [lr, #7]
    // 0x90ce8c: blr             lr
    // 0x90ce90: cmp             w7, NULL
    // 0x90ce94: b.eq            #0x90cea0
    // 0x90ce98: tbnz            w7, #4, #0x90cec0
    // 0x90ce9c: b               #0x90cec8
    // 0x90cea0: r8 = Map
    //     0x90cea0: add             x8, PP, #0x16, lsl #12  ; [pp+0x16608] Type: Map
    //     0x90cea4: ldr             x8, [x8, #0x608]
    // 0x90cea8: r3 = SubtypeTestCache
    //     0x90cea8: add             x3, PP, #0x16, lsl #12  ; [pp+0x16610] SubtypeTestCache
    //     0x90ceac: ldr             x3, [x3, #0x610]
    // 0x90ceb0: r30 = InstanceOfStub
    //     0x90ceb0: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x90ceb4: LoadField: r30 = r30->field_7
    //     0x90ceb4: ldur            lr, [lr, #7]
    // 0x90ceb8: blr             lr
    // 0x90cebc: b               #0x90cecc
    // 0x90cec0: r0 = false
    //     0x90cec0: add             x0, NULL, #0x30  ; false
    // 0x90cec4: b               #0x90cecc
    // 0x90cec8: r0 = true
    //     0x90cec8: add             x0, NULL, #0x20  ; true
    // 0x90cecc: tbz             w0, #4, #0x90cfb0
    // 0x90ced0: ldr             x1, [fp, #0x18]
    // 0x90ced4: r0 = LoadClassIdInstr(r1)
    //     0x90ced4: ldur            x0, [x1, #-1]
    //     0x90ced8: ubfx            x0, x0, #0xc, #0x14
    // 0x90cedc: ldur            x16, [fp, #-0x48]
    // 0x90cee0: stp             x16, x1, [SP]
    // 0x90cee4: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x90cee4: sub             lr, x0, #0xdfd
    //     0x90cee8: ldr             lr, [x21, lr, lsl #3]
    //     0x90ceec: blr             lr
    // 0x90cef0: r2 = Null
    //     0x90cef0: mov             x2, NULL
    // 0x90cef4: r1 = Null
    //     0x90cef4: mov             x1, NULL
    // 0x90cef8: cmp             w0, NULL
    // 0x90cefc: b.eq            #0x90cfa0
    // 0x90cf00: branchIfSmi(r0, 0x90cfa0)
    //     0x90cf00: tbz             w0, #0, #0x90cfa0
    // 0x90cf04: r3 = LoadClassIdInstr(r0)
    //     0x90cf04: ldur            x3, [x0, #-1]
    //     0x90cf08: ubfx            x3, x3, #0xc, #0x14
    // 0x90cf0c: r17 = 7631
    //     0x90cf0c: mov             x17, #0x1dcf
    // 0x90cf10: cmp             x3, x17
    // 0x90cf14: b.eq            #0x90cfa8
    // 0x90cf18: sub             x3, x3, #0x5a
    // 0x90cf1c: cmp             x3, #2
    // 0x90cf20: b.ls            #0x90cfa8
    // 0x90cf24: r4 = LoadClassIdInstr(r0)
    //     0x90cf24: ldur            x4, [x0, #-1]
    //     0x90cf28: ubfx            x4, x4, #0xc, #0x14
    // 0x90cf2c: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x90cf30: ldr             x3, [x3, #0x18]
    // 0x90cf34: ldr             x3, [x3, x4, lsl #3]
    // 0x90cf38: LoadField: r3 = r3->field_2b
    //     0x90cf38: ldur            w3, [x3, #0x2b]
    // 0x90cf3c: DecompressPointer r3
    //     0x90cf3c: add             x3, x3, HEAP, lsl #32
    // 0x90cf40: cmp             w3, NULL
    // 0x90cf44: b.eq            #0x90cfa0
    // 0x90cf48: LoadField: r3 = r3->field_f
    //     0x90cf48: ldur            w3, [x3, #0xf]
    // 0x90cf4c: lsr             x3, x3, #3
    // 0x90cf50: r17 = 7631
    //     0x90cf50: mov             x17, #0x1dcf
    // 0x90cf54: cmp             x3, x17
    // 0x90cf58: b.eq            #0x90cfa8
    // 0x90cf5c: r3 = SubtypeTestCache
    //     0x90cf5c: add             x3, PP, #0x16, lsl #12  ; [pp+0x16618] SubtypeTestCache
    //     0x90cf60: ldr             x3, [x3, #0x618]
    // 0x90cf64: r30 = Subtype1TestCacheStub
    //     0x90cf64: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x90cf68: LoadField: r30 = r30->field_7
    //     0x90cf68: ldur            lr, [lr, #7]
    // 0x90cf6c: blr             lr
    // 0x90cf70: cmp             w7, NULL
    // 0x90cf74: b.eq            #0x90cf80
    // 0x90cf78: tbnz            w7, #4, #0x90cfa0
    // 0x90cf7c: b               #0x90cfa8
    // 0x90cf80: r8 = List
    //     0x90cf80: add             x8, PP, #0x16, lsl #12  ; [pp+0x16620] Type: List
    //     0x90cf84: ldr             x8, [x8, #0x620]
    // 0x90cf88: r3 = SubtypeTestCache
    //     0x90cf88: add             x3, PP, #0x16, lsl #12  ; [pp+0x16628] SubtypeTestCache
    //     0x90cf8c: ldr             x3, [x3, #0x628]
    // 0x90cf90: r30 = InstanceOfStub
    //     0x90cf90: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x90cf94: LoadField: r30 = r30->field_7
    //     0x90cf94: ldur            lr, [lr, #7]
    // 0x90cf98: blr             lr
    // 0x90cf9c: b               #0x90cfac
    // 0x90cfa0: r0 = false
    //     0x90cfa0: add             x0, NULL, #0x30  ; false
    // 0x90cfa4: b               #0x90cfac
    // 0x90cfa8: r0 = true
    //     0x90cfa8: add             x0, NULL, #0x20  ; true
    // 0x90cfac: tbnz            w0, #4, #0x90cfb8
    // 0x90cfb0: r3 = true
    //     0x90cfb0: add             x3, NULL, #0x20  ; true
    // 0x90cfb4: b               #0x90cfdc
    // 0x90cfb8: ldr             x1, [fp, #0x18]
    // 0x90cfbc: r0 = LoadClassIdInstr(r1)
    //     0x90cfbc: ldur            x0, [x1, #-1]
    //     0x90cfc0: ubfx            x0, x0, #0xc, #0x14
    // 0x90cfc4: ldur            x16, [fp, #-0x48]
    // 0x90cfc8: stp             x16, x1, [SP]
    // 0x90cfcc: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x90cfcc: sub             lr, x0, #0xdfd
    //     0x90cfd0: ldr             lr, [x21, lr, lsl #3]
    //     0x90cfd4: blr             lr
    // 0x90cfd8: r3 = false
    //     0x90cfd8: add             x3, NULL, #0x30  ; false
    // 0x90cfdc: ldr             x1, [fp, #0x18]
    // 0x90cfe0: ldur            x2, [fp, #-0x38]
    // 0x90cfe4: stur            x3, [fp, #-0x50]
    // 0x90cfe8: r0 = LoadClassIdInstr(r1)
    //     0x90cfe8: ldur            x0, [x1, #-1]
    //     0x90cfec: ubfx            x0, x0, #0xc, #0x14
    // 0x90cff0: ldur            x16, [fp, #-0x48]
    // 0x90cff4: stp             x16, x1, [SP]
    // 0x90cff8: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x90cff8: sub             lr, x0, #0xdfd
    //     0x90cffc: ldr             lr, [x21, lr, lsl #3]
    //     0x90d000: blr             lr
    // 0x90d004: ldur            x1, [fp, #-0x38]
    // 0x90d008: LoadField: r2 = r1->field_13
    //     0x90d008: ldur            w2, [x1, #0x13]
    // 0x90d00c: DecompressPointer r2
    //     0x90d00c: add             x2, x2, HEAP, lsl #32
    // 0x90d010: tbnz            w2, #4, #0x90d038
    // 0x90d014: cmp             w0, NULL
    // 0x90d018: b.eq            #0x90d038
    // 0x90d01c: r2 = 60
    //     0x90d01c: mov             x2, #0x3c
    // 0x90d020: branchIfSmi(r0, 0x90d02c)
    //     0x90d020: tbz             w0, #0, #0x90d02c
    // 0x90d024: r2 = LoadClassIdInstr(r0)
    //     0x90d024: ldur            x2, [x0, #-1]
    //     0x90d028: ubfx            x2, x2, #0xc, #0x14
    // 0x90d02c: sub             x16, x2, #0x5e
    // 0x90d030: cmp             x16, #1
    // 0x90d034: b.ls            #0x90d040
    // 0x90d038: mov             x4, x0
    // 0x90d03c: b               #0x90d05c
    // 0x90d040: ldur            x16, [fp, #-0x30]
    // 0x90d044: stp             x0, x16, [SP]
    // 0x90d048: ldur            x0, [fp, #-0x30]
    // 0x90d04c: ClosureCall
    //     0x90d04c: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x90d050: ldur            x2, [x0, #0x1f]
    //     0x90d054: blr             x2
    // 0x90d058: mov             x4, x0
    // 0x90d05c: ldur            x3, [fp, #-0x10]
    // 0x90d060: ldur            x0, [fp, #-0x50]
    // 0x90d064: stur            x4, [fp, #-0x60]
    // 0x90d068: LoadField: r5 = r3->field_f
    //     0x90d068: ldur            w5, [x3, #0xf]
    // 0x90d06c: DecompressPointer r5
    //     0x90d06c: add             x5, x5, HEAP, lsl #32
    // 0x90d070: stur            x5, [fp, #-0x58]
    // 0x90d074: r1 = Null
    //     0x90d074: mov             x1, NULL
    // 0x90d078: r2 = 4
    //     0x90d078: mov             x2, #4
    // 0x90d07c: r0 = AllocateArray()
    //     0x90d07c: bl              #0x13df928  ; AllocateArrayStub
    // 0x90d080: mov             x3, x0
    // 0x90d084: ldur            x0, [fp, #-0x58]
    // 0x90d088: stur            x3, [fp, #-0x68]
    // 0x90d08c: StoreField: r3->field_f = r0
    //     0x90d08c: stur            w0, [x3, #0xf]
    // 0x90d090: ldur            x0, [fp, #-0x50]
    // 0x90d094: tbnz            w0, #4, #0x90d0d8
    // 0x90d098: ldur            x4, [fp, #-0x28]
    // 0x90d09c: ldur            x5, [fp, #-0x20]
    // 0x90d0a0: ldur            x0, [fp, #-0x48]
    // 0x90d0a4: r1 = Null
    //     0x90d0a4: mov             x1, NULL
    // 0x90d0a8: r2 = 6
    //     0x90d0a8: mov             x2, #6
    // 0x90d0ac: r0 = AllocateArray()
    //     0x90d0ac: bl              #0x13df928  ; AllocateArrayStub
    // 0x90d0b0: mov             x1, x0
    // 0x90d0b4: ldur            x0, [fp, #-0x28]
    // 0x90d0b8: StoreField: r1->field_f = r0
    //     0x90d0b8: stur            w0, [x1, #0xf]
    // 0x90d0bc: ldur            x2, [fp, #-0x48]
    // 0x90d0c0: StoreField: r1->field_13 = r2
    //     0x90d0c0: stur            w2, [x1, #0x13]
    // 0x90d0c4: ldur            x2, [fp, #-0x20]
    // 0x90d0c8: ArrayStore: r1[0] = r2  ; List_4
    //     0x90d0c8: stur            w2, [x1, #0x17]
    // 0x90d0cc: str             x1, [SP]
    // 0x90d0d0: r0 = _interpolate()
    //     0x90d0d0: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x90d0d4: b               #0x90d0dc
    // 0x90d0d8: r0 = ""
    //     0x90d0d8: ldr             x0, [PP, #0x900]  ; [pp+0x900] ""
    // 0x90d0dc: ldur            x2, [fp, #-0x18]
    // 0x90d0e0: ldur            x1, [fp, #-0x68]
    // 0x90d0e4: ArrayStore: r1[1] = r0  ; List_4
    //     0x90d0e4: add             x25, x1, #0x13
    //     0x90d0e8: str             w0, [x25]
    //     0x90d0ec: tbz             w0, #0, #0x90d108
    //     0x90d0f0: ldurb           w16, [x1, #-1]
    //     0x90d0f4: ldurb           w17, [x0, #-1]
    //     0x90d0f8: and             x16, x17, x16, lsr #2
    //     0x90d0fc: tst             x16, HEAP, lsr #32
    //     0x90d100: b.eq            #0x90d108
    //     0x90d104: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x90d108: ldur            x16, [fp, #-0x68]
    // 0x90d10c: str             x16, [SP]
    // 0x90d110: r0 = _interpolate()
    //     0x90d110: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x90d114: ldur            x16, [fp, #-0x40]
    // 0x90d118: ldur            lr, [fp, #-0x60]
    // 0x90d11c: stp             lr, x16, [SP, #8]
    // 0x90d120: str             x0, [SP]
    // 0x90d124: ldur            x0, [fp, #-0x40]
    // 0x90d128: ClosureCall
    //     0x90d128: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x90d12c: ldur            x2, [x0, #0x1f]
    //     0x90d130: blr             x2
    // 0x90d134: ldur            x0, [fp, #-0x18]
    // 0x90d138: add             x8, x0, #1
    // 0x90d13c: ldur            x1, [fp, #-0x40]
    // 0x90d140: ldur            x5, [fp, #-0x28]
    // 0x90d144: ldur            x6, [fp, #-0x20]
    // 0x90d148: ldur            x2, [fp, #-0x38]
    // 0x90d14c: ldur            x4, [fp, #-0x30]
    // 0x90d150: b               #0x90cd98
    // 0x90d154: ldur            x3, [fp, #-8]
    // 0x90d158: ldr             x0, [fp, #0x18]
    // 0x90d15c: r2 = Null
    //     0x90d15c: mov             x2, NULL
    // 0x90d160: r1 = Null
    //     0x90d160: mov             x1, NULL
    // 0x90d164: cmp             w0, NULL
    // 0x90d168: b.eq            #0x90d200
    // 0x90d16c: branchIfSmi(r0, 0x90d200)
    //     0x90d16c: tbz             w0, #0, #0x90d200
    // 0x90d170: r3 = LoadClassIdInstr(r0)
    //     0x90d170: ldur            x3, [x0, #-1]
    //     0x90d174: ubfx            x3, x3, #0xc, #0x14
    // 0x90d178: r17 = 7630
    //     0x90d178: mov             x17, #0x1dce
    // 0x90d17c: cmp             x3, x17
    // 0x90d180: b.eq            #0x90d208
    // 0x90d184: r4 = LoadClassIdInstr(r0)
    //     0x90d184: ldur            x4, [x0, #-1]
    //     0x90d188: ubfx            x4, x4, #0xc, #0x14
    // 0x90d18c: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x90d190: ldr             x3, [x3, #0x18]
    // 0x90d194: ldr             x3, [x3, x4, lsl #3]
    // 0x90d198: LoadField: r3 = r3->field_2b
    //     0x90d198: ldur            w3, [x3, #0x2b]
    // 0x90d19c: DecompressPointer r3
    //     0x90d19c: add             x3, x3, HEAP, lsl #32
    // 0x90d1a0: cmp             w3, NULL
    // 0x90d1a4: b.eq            #0x90d200
    // 0x90d1a8: LoadField: r3 = r3->field_f
    //     0x90d1a8: ldur            w3, [x3, #0xf]
    // 0x90d1ac: lsr             x3, x3, #3
    // 0x90d1b0: r17 = 7630
    //     0x90d1b0: mov             x17, #0x1dce
    // 0x90d1b4: cmp             x3, x17
    // 0x90d1b8: b.eq            #0x90d208
    // 0x90d1bc: r3 = SubtypeTestCache
    //     0x90d1bc: add             x3, PP, #0x16, lsl #12  ; [pp+0x16630] SubtypeTestCache
    //     0x90d1c0: ldr             x3, [x3, #0x630]
    // 0x90d1c4: r30 = Subtype1TestCacheStub
    //     0x90d1c4: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x90d1c8: LoadField: r30 = r30->field_7
    //     0x90d1c8: ldur            lr, [lr, #7]
    // 0x90d1cc: blr             lr
    // 0x90d1d0: cmp             w7, NULL
    // 0x90d1d4: b.eq            #0x90d1e0
    // 0x90d1d8: tbnz            w7, #4, #0x90d200
    // 0x90d1dc: b               #0x90d208
    // 0x90d1e0: r8 = Map
    //     0x90d1e0: add             x8, PP, #0x16, lsl #12  ; [pp+0x16638] Type: Map
    //     0x90d1e4: ldr             x8, [x8, #0x638]
    // 0x90d1e8: r3 = SubtypeTestCache
    //     0x90d1e8: add             x3, PP, #0x16, lsl #12  ; [pp+0x16640] SubtypeTestCache
    //     0x90d1ec: ldr             x3, [x3, #0x640]
    // 0x90d1f0: r30 = InstanceOfStub
    //     0x90d1f0: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x90d1f4: LoadField: r30 = r30->field_7
    //     0x90d1f4: ldur            lr, [lr, #7]
    // 0x90d1f8: blr             lr
    // 0x90d1fc: b               #0x90d20c
    // 0x90d200: r0 = false
    //     0x90d200: add             x0, NULL, #0x30  ; false
    // 0x90d204: b               #0x90d20c
    // 0x90d208: r0 = true
    //     0x90d208: add             x0, NULL, #0x20  ; true
    // 0x90d20c: tbnz            w0, #4, #0x90d24c
    // 0x90d210: ldr             x0, [fp, #0x18]
    // 0x90d214: ldur            x2, [fp, #-0x10]
    // 0x90d218: r1 = Function '<anonymous closure>': static.
    //     0x90d218: add             x1, PP, #0x16, lsl #12  ; [pp+0x16648] AnonymousClosure: static (0x90d314), in [package:dio/src/utils.dart] ::encodeMap (0x90c9c0)
    //     0x90d21c: ldr             x1, [x1, #0x648]
    // 0x90d220: r0 = AllocateClosure()
    //     0x90d220: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x90d224: ldr             x1, [fp, #0x18]
    // 0x90d228: r2 = LoadClassIdInstr(r1)
    //     0x90d228: ldur            x2, [x1, #-1]
    //     0x90d22c: ubfx            x2, x2, #0xc, #0x14
    // 0x90d230: mov             x16, x0
    // 0x90d234: mov             x0, x2
    // 0x90d238: mov             x2, x16
    // 0x90d23c: r0 = GDT[cid_x0 + 0x6c5]()
    //     0x90d23c: add             lr, x0, #0x6c5
    //     0x90d240: ldr             lr, [x21, lr, lsl #3]
    //     0x90d244: blr             lr
    // 0x90d248: b               #0x90d2f4
    // 0x90d24c: ldr             x1, [fp, #0x18]
    // 0x90d250: ldur            x2, [fp, #-8]
    // 0x90d254: LoadField: r0 = r2->field_f
    //     0x90d254: ldur            w0, [x2, #0xf]
    // 0x90d258: DecompressPointer r0
    //     0x90d258: add             x0, x0, HEAP, lsl #32
    // 0x90d25c: ldr             x16, [fp, #0x10]
    // 0x90d260: stp             x16, x0, [SP, #8]
    // 0x90d264: str             x1, [SP]
    // 0x90d268: ClosureCall
    //     0x90d268: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x90d26c: ldur            x2, [x0, #0x1f]
    //     0x90d270: blr             x2
    // 0x90d274: stur            x0, [fp, #-0x10]
    // 0x90d278: cmp             w0, NULL
    // 0x90d27c: b.eq            #0x90d2a4
    // 0x90d280: mov             x1, x0
    // 0x90d284: r0 = trim()
    //     0x90d284: bl              #0x808ff4  ; [dart:core] _StringBase::trim
    // 0x90d288: LoadField: r1 = r0->field_7
    //     0x90d288: ldur            w1, [x0, #7]
    // 0x90d28c: cbnz            w1, #0x90d298
    // 0x90d290: r0 = false
    //     0x90d290: add             x0, NULL, #0x30  ; false
    // 0x90d294: b               #0x90d29c
    // 0x90d298: r0 = true
    //     0x90d298: add             x0, NULL, #0x20  ; true
    // 0x90d29c: mov             x3, x0
    // 0x90d2a0: b               #0x90d2a8
    // 0x90d2a4: r3 = false
    //     0x90d2a4: add             x3, NULL, #0x30  ; false
    // 0x90d2a8: ldur            x0, [fp, #-8]
    // 0x90d2ac: stur            x3, [fp, #-0x20]
    // 0x90d2b0: LoadField: r1 = r0->field_1b
    //     0x90d2b0: ldur            w1, [x0, #0x1b]
    // 0x90d2b4: DecompressPointer r1
    //     0x90d2b4: add             x1, x1, HEAP, lsl #32
    // 0x90d2b8: tbz             w1, #4, #0x90d2d0
    // 0x90d2bc: tbnz            w3, #4, #0x90d2d0
    // 0x90d2c0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x90d2c0: ldur            w1, [x0, #0x17]
    // 0x90d2c4: DecompressPointer r1
    //     0x90d2c4: add             x1, x1, HEAP, lsl #32
    // 0x90d2c8: r2 = "&"
    //     0x90d2c8: ldr             x2, [PP, #0x11c8]  ; [pp+0x11c8] "&"
    // 0x90d2cc: r0 = write()
    //     0x90d2cc: bl              #0x7e5154  ; [dart:core] StringBuffer::write
    // 0x90d2d0: ldur            x0, [fp, #-8]
    // 0x90d2d4: ldur            x1, [fp, #-0x20]
    // 0x90d2d8: r2 = false
    //     0x90d2d8: add             x2, NULL, #0x30  ; false
    // 0x90d2dc: StoreField: r0->field_1b = r2
    //     0x90d2dc: stur            w2, [x0, #0x1b]
    // 0x90d2e0: tbnz            w1, #4, #0x90d2f4
    // 0x90d2e4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x90d2e4: ldur            w1, [x0, #0x17]
    // 0x90d2e8: DecompressPointer r1
    //     0x90d2e8: add             x1, x1, HEAP, lsl #32
    // 0x90d2ec: ldur            x2, [fp, #-0x10]
    // 0x90d2f0: r0 = write()
    //     0x90d2f0: bl              #0x7e5154  ; [dart:core] StringBuffer::write
    // 0x90d2f4: r0 = Null
    //     0x90d2f4: mov             x0, NULL
    // 0x90d2f8: LeaveFrame
    //     0x90d2f8: mov             SP, fp
    //     0x90d2fc: ldp             fp, lr, [SP], #0x10
    // 0x90d300: ret
    //     0x90d300: ret             
    // 0x90d304: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x90d304: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x90d308: b               #0x90cc68
    // 0x90d30c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x90d30c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x90d310: b               #0x90cdb0
  }
  [closure] static void <anonymous closure>(dynamic, dynamic, dynamic) {
    // ** addr: 0x90d314, size: 0x34c
    // 0x90d314: EnterFrame
    //     0x90d314: stp             fp, lr, [SP, #-0x10]!
    //     0x90d318: mov             fp, SP
    // 0x90d31c: AllocStack(0x48)
    //     0x90d31c: sub             SP, SP, #0x48
    // 0x90d320: SetupParameters([dynamic _ /* r0 */])
    //     0x90d320: ldr             x0, [fp, #0x20]
    //     0x90d324: ldur            w1, [x0, #0x17]
    //     0x90d328: add             x1, x1, HEAP, lsl #32
    //     0x90d32c: stur            x1, [fp, #-8]
    // 0x90d330: CheckStackOverflow
    //     0x90d330: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x90d334: cmp             SP, x16
    //     0x90d338: b.ls            #0x90d658
    // 0x90d33c: LoadField: r0 = r1->field_f
    //     0x90d33c: ldur            w0, [x1, #0xf]
    // 0x90d340: DecompressPointer r0
    //     0x90d340: add             x0, x0, HEAP, lsl #32
    // 0x90d344: r2 = LoadClassIdInstr(r0)
    //     0x90d344: ldur            x2, [x0, #-1]
    //     0x90d348: ubfx            x2, x2, #0xc, #0x14
    // 0x90d34c: r16 = ""
    //     0x90d34c: ldr             x16, [PP, #0x900]  ; [pp+0x900] ""
    // 0x90d350: stp             x16, x0, [SP]
    // 0x90d354: mov             x0, x2
    // 0x90d358: mov             lr, x0
    // 0x90d35c: ldr             lr, [x21, lr, lsl #3]
    // 0x90d360: blr             lr
    // 0x90d364: tbnz            w0, #4, #0x90d488
    // 0x90d368: ldur            x1, [fp, #-8]
    // 0x90d36c: LoadField: r2 = r1->field_b
    //     0x90d36c: ldur            w2, [x1, #0xb]
    // 0x90d370: DecompressPointer r2
    //     0x90d370: add             x2, x2, HEAP, lsl #32
    // 0x90d374: stur            x2, [fp, #-0x18]
    // 0x90d378: LoadField: r1 = r2->field_2f
    //     0x90d378: ldur            w1, [x2, #0x2f]
    // 0x90d37c: DecompressPointer r1
    //     0x90d37c: add             x1, x1, HEAP, lsl #32
    // 0x90d380: stur            x1, [fp, #-0x10]
    // 0x90d384: LoadField: r0 = r2->field_2b
    //     0x90d384: ldur            w0, [x2, #0x2b]
    // 0x90d388: DecompressPointer r0
    //     0x90d388: add             x0, x0, HEAP, lsl #32
    // 0x90d38c: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x90d38c: ldur            w3, [x0, #0x17]
    // 0x90d390: DecompressPointer r3
    //     0x90d390: add             x3, x3, HEAP, lsl #32
    // 0x90d394: LoadField: r0 = r3->field_13
    //     0x90d394: ldur            w0, [x3, #0x13]
    // 0x90d398: DecompressPointer r0
    //     0x90d398: add             x0, x0, HEAP, lsl #32
    // 0x90d39c: tbz             w0, #4, #0x90d3a8
    // 0x90d3a0: ldr             x0, [fp, #0x10]
    // 0x90d3a4: b               #0x90d3d0
    // 0x90d3a8: ldr             x0, [fp, #0x10]
    // 0x90d3ac: cmp             w0, NULL
    // 0x90d3b0: b.eq            #0x90d3d0
    // 0x90d3b4: r4 = 60
    //     0x90d3b4: mov             x4, #0x3c
    // 0x90d3b8: branchIfSmi(r0, 0x90d3c4)
    //     0x90d3b8: tbz             w0, #0, #0x90d3c4
    // 0x90d3bc: r4 = LoadClassIdInstr(r0)
    //     0x90d3bc: ldur            x4, [x0, #-1]
    //     0x90d3c0: ubfx            x4, x4, #0xc, #0x14
    // 0x90d3c4: sub             x16, x4, #0x5e
    // 0x90d3c8: cmp             x16, #1
    // 0x90d3cc: b.ls            #0x90d3dc
    // 0x90d3d0: mov             x3, x0
    // 0x90d3d4: mov             x0, x2
    // 0x90d3d8: b               #0x90d400
    // 0x90d3dc: LoadField: r4 = r3->field_27
    //     0x90d3dc: ldur            w4, [x3, #0x27]
    // 0x90d3e0: DecompressPointer r4
    //     0x90d3e0: add             x4, x4, HEAP, lsl #32
    // 0x90d3e4: stp             x0, x4, [SP]
    // 0x90d3e8: mov             x0, x4
    // 0x90d3ec: ClosureCall
    //     0x90d3ec: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x90d3f0: ldur            x2, [x0, #0x1f]
    //     0x90d3f4: blr             x2
    // 0x90d3f8: mov             x3, x0
    // 0x90d3fc: ldur            x0, [fp, #-0x18]
    // 0x90d400: stur            x3, [fp, #-0x28]
    // 0x90d404: LoadField: r4 = r0->field_27
    //     0x90d404: ldur            w4, [x0, #0x27]
    // 0x90d408: DecompressPointer r4
    //     0x90d408: add             x4, x4, HEAP, lsl #32
    // 0x90d40c: ldr             x0, [fp, #0x18]
    // 0x90d410: stur            x4, [fp, #-0x20]
    // 0x90d414: r2 = Null
    //     0x90d414: mov             x2, NULL
    // 0x90d418: r1 = Null
    //     0x90d418: mov             x1, NULL
    // 0x90d41c: r4 = 60
    //     0x90d41c: mov             x4, #0x3c
    // 0x90d420: branchIfSmi(r0, 0x90d42c)
    //     0x90d420: tbz             w0, #0, #0x90d42c
    // 0x90d424: r4 = LoadClassIdInstr(r0)
    //     0x90d424: ldur            x4, [x0, #-1]
    //     0x90d428: ubfx            x4, x4, #0xc, #0x14
    // 0x90d42c: sub             x4, x4, #0x5e
    // 0x90d430: cmp             x4, #1
    // 0x90d434: b.ls            #0x90d448
    // 0x90d438: r8 = String
    //     0x90d438: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x90d43c: r3 = Null
    //     0x90d43c: add             x3, PP, #0x16, lsl #12  ; [pp+0x16650] Null
    //     0x90d440: ldr             x3, [x3, #0x650]
    // 0x90d444: r0 = String()
    //     0x90d444: bl              #0x13ee320  ; IsType_String_Stub
    // 0x90d448: ldur            x16, [fp, #-0x20]
    // 0x90d44c: ldr             lr, [fp, #0x18]
    // 0x90d450: stp             lr, x16, [SP]
    // 0x90d454: ldur            x0, [fp, #-0x20]
    // 0x90d458: ClosureCall
    //     0x90d458: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x90d45c: ldur            x2, [x0, #0x1f]
    //     0x90d460: blr             x2
    // 0x90d464: ldur            x16, [fp, #-0x10]
    // 0x90d468: ldur            lr, [fp, #-0x28]
    // 0x90d46c: stp             lr, x16, [SP, #8]
    // 0x90d470: str             x0, [SP]
    // 0x90d474: ldur            x0, [fp, #-0x10]
    // 0x90d478: ClosureCall
    //     0x90d478: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x90d47c: ldur            x2, [x0, #0x1f]
    //     0x90d480: blr             x2
    // 0x90d484: b               #0x90d648
    // 0x90d488: ldr             x0, [fp, #0x10]
    // 0x90d48c: ldur            x1, [fp, #-8]
    // 0x90d490: LoadField: r2 = r1->field_b
    //     0x90d490: ldur            w2, [x1, #0xb]
    // 0x90d494: DecompressPointer r2
    //     0x90d494: add             x2, x2, HEAP, lsl #32
    // 0x90d498: stur            x2, [fp, #-0x18]
    // 0x90d49c: LoadField: r3 = r2->field_2f
    //     0x90d49c: ldur            w3, [x2, #0x2f]
    // 0x90d4a0: DecompressPointer r3
    //     0x90d4a0: add             x3, x3, HEAP, lsl #32
    // 0x90d4a4: stur            x3, [fp, #-0x10]
    // 0x90d4a8: LoadField: r4 = r2->field_2b
    //     0x90d4a8: ldur            w4, [x2, #0x2b]
    // 0x90d4ac: DecompressPointer r4
    //     0x90d4ac: add             x4, x4, HEAP, lsl #32
    // 0x90d4b0: ArrayLoad: r5 = r4[0]  ; List_4
    //     0x90d4b0: ldur            w5, [x4, #0x17]
    // 0x90d4b4: DecompressPointer r5
    //     0x90d4b4: add             x5, x5, HEAP, lsl #32
    // 0x90d4b8: LoadField: r4 = r5->field_13
    //     0x90d4b8: ldur            w4, [x5, #0x13]
    // 0x90d4bc: DecompressPointer r4
    //     0x90d4bc: add             x4, x4, HEAP, lsl #32
    // 0x90d4c0: tbnz            w4, #4, #0x90d4e8
    // 0x90d4c4: cmp             w0, NULL
    // 0x90d4c8: b.eq            #0x90d4e8
    // 0x90d4cc: r4 = 60
    //     0x90d4cc: mov             x4, #0x3c
    // 0x90d4d0: branchIfSmi(r0, 0x90d4dc)
    //     0x90d4d0: tbz             w0, #0, #0x90d4dc
    // 0x90d4d4: r4 = LoadClassIdInstr(r0)
    //     0x90d4d4: ldur            x4, [x0, #-1]
    //     0x90d4d8: ubfx            x4, x4, #0xc, #0x14
    // 0x90d4dc: sub             x16, x4, #0x5e
    // 0x90d4e0: cmp             x16, #1
    // 0x90d4e4: b.ls            #0x90d4f8
    // 0x90d4e8: mov             x4, x0
    // 0x90d4ec: mov             x0, x1
    // 0x90d4f0: mov             x3, x2
    // 0x90d4f4: b               #0x90d520
    // 0x90d4f8: LoadField: r4 = r5->field_27
    //     0x90d4f8: ldur            w4, [x5, #0x27]
    // 0x90d4fc: DecompressPointer r4
    //     0x90d4fc: add             x4, x4, HEAP, lsl #32
    // 0x90d500: stp             x0, x4, [SP]
    // 0x90d504: mov             x0, x4
    // 0x90d508: ClosureCall
    //     0x90d508: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x90d50c: ldur            x2, [x0, #0x1f]
    //     0x90d510: blr             x2
    // 0x90d514: mov             x4, x0
    // 0x90d518: ldur            x0, [fp, #-8]
    // 0x90d51c: ldur            x3, [fp, #-0x18]
    // 0x90d520: stur            x4, [fp, #-0x28]
    // 0x90d524: LoadField: r5 = r0->field_f
    //     0x90d524: ldur            w5, [x0, #0xf]
    // 0x90d528: DecompressPointer r5
    //     0x90d528: add             x5, x5, HEAP, lsl #32
    // 0x90d52c: stur            x5, [fp, #-0x20]
    // 0x90d530: r1 = Null
    //     0x90d530: mov             x1, NULL
    // 0x90d534: r2 = 8
    //     0x90d534: mov             x2, #8
    // 0x90d538: r0 = AllocateArray()
    //     0x90d538: bl              #0x13df928  ; AllocateArrayStub
    // 0x90d53c: mov             x3, x0
    // 0x90d540: ldur            x0, [fp, #-0x20]
    // 0x90d544: stur            x3, [fp, #-0x30]
    // 0x90d548: StoreField: r3->field_f = r0
    //     0x90d548: stur            w0, [x3, #0xf]
    // 0x90d54c: ldur            x4, [fp, #-0x18]
    // 0x90d550: LoadField: r0 = r4->field_1f
    //     0x90d550: ldur            w0, [x4, #0x1f]
    // 0x90d554: DecompressPointer r0
    //     0x90d554: add             x0, x0, HEAP, lsl #32
    // 0x90d558: StoreField: r3->field_13 = r0
    //     0x90d558: stur            w0, [x3, #0x13]
    // 0x90d55c: LoadField: r5 = r4->field_27
    //     0x90d55c: ldur            w5, [x4, #0x27]
    // 0x90d560: DecompressPointer r5
    //     0x90d560: add             x5, x5, HEAP, lsl #32
    // 0x90d564: ldr             x0, [fp, #0x18]
    // 0x90d568: stur            x5, [fp, #-8]
    // 0x90d56c: r2 = Null
    //     0x90d56c: mov             x2, NULL
    // 0x90d570: r1 = Null
    //     0x90d570: mov             x1, NULL
    // 0x90d574: r4 = 60
    //     0x90d574: mov             x4, #0x3c
    // 0x90d578: branchIfSmi(r0, 0x90d584)
    //     0x90d578: tbz             w0, #0, #0x90d584
    // 0x90d57c: r4 = LoadClassIdInstr(r0)
    //     0x90d57c: ldur            x4, [x0, #-1]
    //     0x90d580: ubfx            x4, x4, #0xc, #0x14
    // 0x90d584: sub             x4, x4, #0x5e
    // 0x90d588: cmp             x4, #1
    // 0x90d58c: b.ls            #0x90d5a0
    // 0x90d590: r8 = String
    //     0x90d590: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x90d594: r3 = Null
    //     0x90d594: add             x3, PP, #0x16, lsl #12  ; [pp+0x16660] Null
    //     0x90d598: ldr             x3, [x3, #0x660]
    // 0x90d59c: r0 = String()
    //     0x90d59c: bl              #0x13ee320  ; IsType_String_Stub
    // 0x90d5a0: ldur            x16, [fp, #-8]
    // 0x90d5a4: ldr             lr, [fp, #0x18]
    // 0x90d5a8: stp             lr, x16, [SP]
    // 0x90d5ac: ldur            x0, [fp, #-8]
    // 0x90d5b0: ClosureCall
    //     0x90d5b0: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x90d5b4: ldur            x2, [x0, #0x1f]
    //     0x90d5b8: blr             x2
    // 0x90d5bc: ldur            x1, [fp, #-0x30]
    // 0x90d5c0: ArrayStore: r1[2] = r0  ; List_4
    //     0x90d5c0: add             x25, x1, #0x17
    //     0x90d5c4: str             w0, [x25]
    //     0x90d5c8: tbz             w0, #0, #0x90d5e4
    //     0x90d5cc: ldurb           w16, [x1, #-1]
    //     0x90d5d0: ldurb           w17, [x0, #-1]
    //     0x90d5d4: and             x16, x17, x16, lsr #2
    //     0x90d5d8: tst             x16, HEAP, lsr #32
    //     0x90d5dc: b.eq            #0x90d5e4
    //     0x90d5e0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x90d5e4: ldur            x0, [fp, #-0x18]
    // 0x90d5e8: LoadField: r1 = r0->field_23
    //     0x90d5e8: ldur            w1, [x0, #0x23]
    // 0x90d5ec: DecompressPointer r1
    //     0x90d5ec: add             x1, x1, HEAP, lsl #32
    // 0x90d5f0: mov             x0, x1
    // 0x90d5f4: ldur            x1, [fp, #-0x30]
    // 0x90d5f8: ArrayStore: r1[3] = r0  ; List_4
    //     0x90d5f8: add             x25, x1, #0x1b
    //     0x90d5fc: str             w0, [x25]
    //     0x90d600: tbz             w0, #0, #0x90d61c
    //     0x90d604: ldurb           w16, [x1, #-1]
    //     0x90d608: ldurb           w17, [x0, #-1]
    //     0x90d60c: and             x16, x17, x16, lsr #2
    //     0x90d610: tst             x16, HEAP, lsr #32
    //     0x90d614: b.eq            #0x90d61c
    //     0x90d618: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x90d61c: ldur            x16, [fp, #-0x30]
    // 0x90d620: str             x16, [SP]
    // 0x90d624: r0 = _interpolate()
    //     0x90d624: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x90d628: ldur            x16, [fp, #-0x10]
    // 0x90d62c: ldur            lr, [fp, #-0x28]
    // 0x90d630: stp             lr, x16, [SP, #8]
    // 0x90d634: str             x0, [SP]
    // 0x90d638: ldur            x0, [fp, #-0x10]
    // 0x90d63c: ClosureCall
    //     0x90d63c: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x90d640: ldur            x2, [x0, #0x1f]
    //     0x90d644: blr             x2
    // 0x90d648: r0 = Null
    //     0x90d648: mov             x0, NULL
    // 0x90d64c: LeaveFrame
    //     0x90d64c: mov             SP, fp
    //     0x90d650: ldp             fp, lr, [SP], #0x10
    // 0x90d654: ret
    //     0x90d654: ret             
    // 0x90d658: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x90d658: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x90d65c: b               #0x90d33c
  }
  [closure] static Object? maybeEncode(dynamic, Object?) {
    // ** addr: 0x90d660, size: 0x9c
    // 0x90d660: EnterFrame
    //     0x90d660: stp             fp, lr, [SP, #-0x10]!
    //     0x90d664: mov             fp, SP
    // 0x90d668: AllocStack(0x10)
    //     0x90d668: sub             SP, SP, #0x10
    // 0x90d66c: SetupParameters([dynamic _ /* r0 */])
    //     0x90d66c: ldr             x0, [fp, #0x18]
    //     0x90d670: ldur            w1, [x0, #0x17]
    //     0x90d674: add             x1, x1, HEAP, lsl #32
    // 0x90d678: CheckStackOverflow
    //     0x90d678: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x90d67c: cmp             SP, x16
    //     0x90d680: b.ls            #0x90d6f4
    // 0x90d684: LoadField: r0 = r1->field_13
    //     0x90d684: ldur            w0, [x1, #0x13]
    // 0x90d688: DecompressPointer r0
    //     0x90d688: add             x0, x0, HEAP, lsl #32
    // 0x90d68c: tbz             w0, #4, #0x90d698
    // 0x90d690: ldr             x0, [fp, #0x10]
    // 0x90d694: b               #0x90d6c0
    // 0x90d698: ldr             x0, [fp, #0x10]
    // 0x90d69c: cmp             w0, NULL
    // 0x90d6a0: b.eq            #0x90d6c0
    // 0x90d6a4: r2 = 60
    //     0x90d6a4: mov             x2, #0x3c
    // 0x90d6a8: branchIfSmi(r0, 0x90d6b4)
    //     0x90d6a8: tbz             w0, #0, #0x90d6b4
    // 0x90d6ac: r2 = LoadClassIdInstr(r0)
    //     0x90d6ac: ldur            x2, [x0, #-1]
    //     0x90d6b0: ubfx            x2, x2, #0xc, #0x14
    // 0x90d6b4: sub             x16, x2, #0x5e
    // 0x90d6b8: cmp             x16, #1
    // 0x90d6bc: b.ls            #0x90d6cc
    // 0x90d6c0: LeaveFrame
    //     0x90d6c0: mov             SP, fp
    //     0x90d6c4: ldp             fp, lr, [SP], #0x10
    // 0x90d6c8: ret
    //     0x90d6c8: ret             
    // 0x90d6cc: LoadField: r2 = r1->field_27
    //     0x90d6cc: ldur            w2, [x1, #0x27]
    // 0x90d6d0: DecompressPointer r2
    //     0x90d6d0: add             x2, x2, HEAP, lsl #32
    // 0x90d6d4: stp             x0, x2, [SP]
    // 0x90d6d8: mov             x0, x2
    // 0x90d6dc: ClosureCall
    //     0x90d6dc: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x90d6e0: ldur            x2, [x0, #0x1f]
    //     0x90d6e4: blr             x2
    // 0x90d6e8: LeaveFrame
    //     0x90d6e8: mov             SP, fp
    //     0x90d6ec: ldp             fp, lr, [SP], #0x10
    // 0x90d6f0: ret
    //     0x90d6f0: ret             
    // 0x90d6f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x90d6f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x90d6f8: b               #0x90d684
  }
  [closure] static void <anonymous closure>(dynamic) {
    // ** addr: 0x910b14, size: 0x4c
    // 0x910b14: EnterFrame
    //     0x910b14: stp             fp, lr, [SP, #-0x10]!
    //     0x910b18: mov             fp, SP
    // 0x910b1c: ldr             x0, [fp, #0x10]
    // 0x910b20: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x910b20: ldur            w1, [x0, #0x17]
    // 0x910b24: DecompressPointer r1
    //     0x910b24: add             x1, x1, HEAP, lsl #32
    // 0x910b28: CheckStackOverflow
    //     0x910b28: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x910b2c: cmp             SP, x16
    //     0x910b30: b.ls            #0x910b58
    // 0x910b34: LoadField: r0 = r1->field_f
    //     0x910b34: ldur            w0, [x1, #0xf]
    // 0x910b38: DecompressPointer r0
    //     0x910b38: add             x0, x0, HEAP, lsl #32
    // 0x910b3c: mov             x1, x0
    // 0x910b40: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x910b40: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x910b44: r0 = complete()
    //     0x910b44: bl              #0x128a5ec  ; [dart:async] _AsyncCompleter::complete
    // 0x910b48: r0 = Null
    //     0x910b48: mov             x0, NULL
    // 0x910b4c: LeaveFrame
    //     0x910b4c: mov             SP, fp
    //     0x910b50: ldp             fp, lr, [SP], #0x10
    // 0x910b54: ret
    //     0x910b54: ret             
    // 0x910b58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x910b58: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x910b5c: b               #0x910b34
  }
}
