// lib: , url: package:dio/src/dio.dart

// class id: 1048699, size: 0x8
class :: {
}

// class id: 3411, size: 0x8, field offset: 0x8
abstract class Dio extends Object {
}
