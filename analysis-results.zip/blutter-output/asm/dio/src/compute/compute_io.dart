// lib: , url: package:dio/src/compute/compute_io.dart

// class id: 1048698, size: 0x8
class :: {

  [closure] static Future<Y1> computeWithTimeout<Y0, Y1>(dynamic, (dynamic, Y0) => FutureOr<Y1>, Y0, {String? debugLabel, Duration? timeout}) {
    // ** addr: 0x8f00f4, size: 0x124
    // 0x8f00f4: EnterFrame
    //     0x8f00f4: stp             fp, lr, [SP, #-0x10]!
    //     0x8f00f8: mov             fp, SP
    // 0x8f00fc: AllocStack(0x28)
    //     0x8f00fc: sub             SP, SP, #0x28
    // 0x8f0100: SetupParameters(dynamic _ /* r2 */, dynamic _ /* r3 */, dynamic _ /* r5 */, {dynamic debugLabel = Null /* r6 */, dynamic timeout = Null /* r0 */})
    //     0x8f0100: ldur            w0, [x4, #0x13]
    //     0x8f0104: sub             x1, x0, #6
    //     0x8f0108: add             x2, fp, w1, sxtw #2
    //     0x8f010c: ldr             x2, [x2, #0x20]
    //     0x8f0110: add             x3, fp, w1, sxtw #2
    //     0x8f0114: ldr             x3, [x3, #0x18]
    //     0x8f0118: add             x5, fp, w1, sxtw #2
    //     0x8f011c: ldr             x5, [x5, #0x10]
    //     0x8f0120: ldur            w1, [x4, #0x1f]
    //     0x8f0124: add             x1, x1, HEAP, lsl #32
    //     0x8f0128: ldr             x16, [PP, #0x2078]  ; [pp+0x2078] "debugLabel"
    //     0x8f012c: cmp             w1, w16
    //     0x8f0130: b.ne            #0x8f0154
    //     0x8f0134: ldur            w1, [x4, #0x23]
    //     0x8f0138: add             x1, x1, HEAP, lsl #32
    //     0x8f013c: sub             w6, w0, w1
    //     0x8f0140: add             x1, fp, w6, sxtw #2
    //     0x8f0144: ldr             x1, [x1, #8]
    //     0x8f0148: mov             x6, x1
    //     0x8f014c: mov             x1, #1
    //     0x8f0150: b               #0x8f015c
    //     0x8f0154: mov             x6, NULL
    //     0x8f0158: mov             x1, #0
    //     0x8f015c: lsl             x7, x1, #1
    //     0x8f0160: lsl             w1, w7, #1
    //     0x8f0164: add             w7, w1, #8
    //     0x8f0168: add             x16, x4, w7, sxtw #1
    //     0x8f016c: ldur            w8, [x16, #0xf]
    //     0x8f0170: add             x8, x8, HEAP, lsl #32
    //     0x8f0174: add             x16, PP, #0x16, lsl #12  ; [pp+0x16120] "timeout"
    //     0x8f0178: ldr             x16, [x16, #0x120]
    //     0x8f017c: cmp             w8, w16
    //     0x8f0180: b.ne            #0x8f01a4
    //     0x8f0184: add             w7, w1, #0xa
    //     0x8f0188: add             x16, x4, w7, sxtw #1
    //     0x8f018c: ldur            w1, [x16, #0xf]
    //     0x8f0190: add             x1, x1, HEAP, lsl #32
    //     0x8f0194: sub             w7, w0, w1
    //     0x8f0198: add             x0, fp, w7, sxtw #2
    //     0x8f019c: ldr             x0, [x0, #8]
    //     0x8f01a0: b               #0x8f01a8
    //     0x8f01a4: mov             x0, NULL
    //     0x8f01a8: ldur            w1, [x4, #0xf]
    //     0x8f01ac: cbnz            w1, #0x8f01b8
    //     0x8f01b0: mov             x1, NULL
    //     0x8f01b4: b               #0x8f01c8
    //     0x8f01b8: ldur            w1, [x4, #0x17]
    //     0x8f01bc: add             x4, fp, w1, sxtw #2
    //     0x8f01c0: ldr             x4, [x4, #0x10]
    //     0x8f01c4: mov             x1, x4
    //     0x8f01c8: ldur            w4, [x2, #0xf]
    //     0x8f01cc: add             x4, x4, HEAP, lsl #32
    //     0x8f01d0: ldr             x16, [THR, #0xb0]  ; THR::empty_type_arguments
    //     0x8f01d4: cmp             w4, w16
    //     0x8f01d8: b.eq            #0x8f01e0
    //     0x8f01dc: mov             x1, x4
    // 0x8f01e0: CheckStackOverflow
    //     0x8f01e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f01e4: cmp             SP, x16
    //     0x8f01e8: b.ls            #0x8f0210
    // 0x8f01ec: stp             x3, x1, [SP, #0x18]
    // 0x8f01f0: stp             x6, x5, [SP, #8]
    // 0x8f01f4: str             x0, [SP]
    // 0x8f01f8: r4 = const [0x2, 0x4, 0x4, 0x2, debugLabel, 0x2, timeout, 0x3, null]
    //     0x8f01f8: add             x4, PP, #0x16, lsl #12  ; [pp+0x16128] List(9) [0x2, 0x4, 0x4, 0x2, "debugLabel", 0x2, "timeout", 0x3, Null]
    //     0x8f01fc: ldr             x4, [x4, #0x128]
    // 0x8f0200: r0 = computeWithTimeout()
    //     0x8f0200: bl              #0x8f0218  ; [package:dio/src/compute/compute_io.dart] ::computeWithTimeout
    // 0x8f0204: LeaveFrame
    //     0x8f0204: mov             SP, fp
    //     0x8f0208: ldp             fp, lr, [SP], #0x10
    // 0x8f020c: ret
    //     0x8f020c: ret             
    // 0x8f0210: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f0210: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f0214: b               #0x8f01ec
  }
  static Future<Y1> computeWithTimeout<Y0, Y1>((dynamic, Y0) => FutureOr<Y1>, Y0, {String? debugLabel, Duration? timeout}) async {
    // ** addr: 0x8f0218, size: 0x820
    // 0x8f0218: EnterFrame
    //     0x8f0218: stp             fp, lr, [SP, #-0x10]!
    //     0x8f021c: mov             fp, SP
    // 0x8f0220: AllocStack(0x120)
    //     0x8f0220: sub             SP, SP, #0x120
    // 0x8f0224: SetupParameters(dynamic _ /* r2, fp-0xc8 */, dynamic _ /* r3, fp-0xc0 */, {dynamic debugLabel = Null /* r1, fp-0xb8 */, dynamic timeout = Null /* r0, fp-0xb0 */})
    //     0x8f0224: stur            NULL, [fp, #-8]
    //     0x8f0228: ldur            w0, [x4, #0x13]
    //     0x8f022c: sub             x1, x0, #4
    //     0x8f0230: add             x2, fp, w1, sxtw #2
    //     0x8f0234: ldr             x2, [x2, #0x18]
    //     0x8f0238: stur            x2, [fp, #-0xc8]
    //     0x8f023c: add             x3, fp, w1, sxtw #2
    //     0x8f0240: ldr             x3, [x3, #0x10]
    //     0x8f0244: stur            x3, [fp, #-0xc0]
    //     0x8f0248: ldur            w1, [x4, #0x1f]
    //     0x8f024c: add             x1, x1, HEAP, lsl #32
    //     0x8f0250: ldr             x16, [PP, #0x2078]  ; [pp+0x2078] "debugLabel"
    //     0x8f0254: cmp             w1, w16
    //     0x8f0258: b.ne            #0x8f0278
    //     0x8f025c: ldur            w1, [x4, #0x23]
    //     0x8f0260: add             x1, x1, HEAP, lsl #32
    //     0x8f0264: sub             w5, w0, w1
    //     0x8f0268: add             x1, fp, w5, sxtw #2
    //     0x8f026c: ldr             x1, [x1, #8]
    //     0x8f0270: mov             x5, #1
    //     0x8f0274: b               #0x8f0280
    //     0x8f0278: mov             x5, #0
    //     0x8f027c: mov             x1, NULL
    //     0x8f0280: stur            x1, [fp, #-0xb8]
    //     0x8f0284: lsl             x6, x5, #1
    //     0x8f0288: lsl             w5, w6, #1
    //     0x8f028c: add             w6, w5, #8
    //     0x8f0290: add             x16, x4, w6, sxtw #1
    //     0x8f0294: ldur            w7, [x16, #0xf]
    //     0x8f0298: add             x7, x7, HEAP, lsl #32
    //     0x8f029c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16120] "timeout"
    //     0x8f02a0: ldr             x16, [x16, #0x120]
    //     0x8f02a4: cmp             w7, w16
    //     0x8f02a8: b.ne            #0x8f02cc
    //     0x8f02ac: add             w6, w5, #0xa
    //     0x8f02b0: add             x16, x4, w6, sxtw #1
    //     0x8f02b4: ldur            w5, [x16, #0xf]
    //     0x8f02b8: add             x5, x5, HEAP, lsl #32
    //     0x8f02bc: sub             w6, w0, w5
    //     0x8f02c0: add             x0, fp, w6, sxtw #2
    //     0x8f02c4: ldr             x0, [x0, #8]
    //     0x8f02c8: b               #0x8f02d0
    //     0x8f02cc: mov             x0, NULL
    //     0x8f02d0: stur            x0, [fp, #-0xb0]
    //     0x8f02d4: ldur            w5, [x4, #0xf]
    //     0x8f02d8: cbnz            w5, #0x8f02e4
    //     0x8f02dc: mov             x4, NULL
    //     0x8f02e0: b               #0x8f02f0
    //     0x8f02e4: ldur            w5, [x4, #0x17]
    //     0x8f02e8: add             x4, fp, w5, sxtw #2
    //     0x8f02ec: ldr             x4, [x4, #0x10]
    //     0x8f02f0: stur            x4, [fp, #-0xa8]
    // 0x8f02f4: CheckStackOverflow
    //     0x8f02f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f02f8: cmp             SP, x16
    //     0x8f02fc: b.ls            #0x8f0a30
    // 0x8f0300: r1 = 10
    //     0x8f0300: mov             x1, #0xa
    // 0x8f0304: r0 = AllocateContext()
    //     0x8f0304: bl              #0x13de838  ; AllocateContextStub
    // 0x8f0308: mov             x4, x0
    // 0x8f030c: ldur            x0, [fp, #-0xb8]
    // 0x8f0310: stur            x4, [fp, #-0xd0]
    // 0x8f0314: StoreField: r4->field_f = r0
    //     0x8f0314: stur            w0, [x4, #0xf]
    // 0x8f0318: ldur            x0, [fp, #-0xb0]
    // 0x8f031c: StoreField: r4->field_13 = r0
    //     0x8f031c: stur            w0, [x4, #0x13]
    // 0x8f0320: ldur            x1, [fp, #-0xa8]
    // 0x8f0324: r2 = Null
    //     0x8f0324: mov             x2, NULL
    // 0x8f0328: r3 = <Y1>
    //     0x8f0328: add             x3, PP, #0x16, lsl #12  ; [pp+0x16130] TypeArguments: <Y1>
    //     0x8f032c: ldr             x3, [x3, #0x130]
    // 0x8f0330: r0 = Null
    //     0x8f0330: mov             x0, NULL
    // 0x8f0334: cmp             x2, x0
    // 0x8f0338: b.ne            #0x8f0344
    // 0x8f033c: cmp             x1, x0
    // 0x8f0340: b.eq            #0x8f0350
    // 0x8f0344: r30 = InstantiateTypeArgumentsStub
    //     0x8f0344: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0x8f0348: LoadField: r30 = r30->field_7
    //     0x8f0348: ldur            lr, [lr, #7]
    // 0x8f034c: blr             lr
    // 0x8f0350: mov             x1, x0
    // 0x8f0354: stur            x1, [fp, #-0xb0]
    // 0x8f0358: r0 = InitAsync()
    //     0x8f0358: bl              #0x7f5e44  ; InitAsyncStub
    // 0x8f035c: ldur            x2, [fp, #-0xd0]
    // 0x8f0360: LoadField: r0 = r2->field_f
    //     0x8f0360: ldur            w0, [x2, #0xf]
    // 0x8f0364: DecompressPointer r0
    //     0x8f0364: add             x0, x0, HEAP, lsl #32
    // 0x8f0368: cmp             w0, NULL
    // 0x8f036c: b.ne            #0x8f0378
    // 0x8f0370: r0 = "compute"
    //     0x8f0370: ldr             x0, [PP, #0x3748]  ; [pp+0x3748] "compute"
    // 0x8f0374: StoreField: r2->field_f = r0
    //     0x8f0374: stur            w0, [x2, #0xf]
    // 0x8f0378: ldur            x1, [fp, #-0xa8]
    // 0x8f037c: r0 = begin()
    //     0x8f037c: bl              #0x8f104c  ; [dart:developer] Flow::begin
    // 0x8f0380: mov             x4, x0
    // 0x8f0384: ldur            x3, [fp, #-0xd0]
    // 0x8f0388: stur            x4, [fp, #-0xb8]
    // 0x8f038c: ArrayStore: r3[0] = r0  ; List_4
    //     0x8f038c: stur            w0, [x3, #0x17]
    //     0x8f0390: ldurb           w16, [x3, #-1]
    //     0x8f0394: ldurb           w17, [x0, #-1]
    //     0x8f0398: and             x16, x17, x16, lsr #2
    //     0x8f039c: tst             x16, HEAP, lsr #32
    //     0x8f03a0: b.eq            #0x8f03a8
    //     0x8f03a4: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x8f03a8: LoadField: r0 = r3->field_f
    //     0x8f03a8: ldur            w0, [x3, #0xf]
    // 0x8f03ac: DecompressPointer r0
    //     0x8f03ac: add             x0, x0, HEAP, lsl #32
    // 0x8f03b0: stur            x0, [fp, #-0xb0]
    // 0x8f03b4: r1 = Null
    //     0x8f03b4: mov             x1, NULL
    // 0x8f03b8: r2 = 4
    //     0x8f03b8: mov             x2, #4
    // 0x8f03bc: r0 = AllocateArray()
    //     0x8f03bc: bl              #0x13df928  ; AllocateArrayStub
    // 0x8f03c0: mov             x1, x0
    // 0x8f03c4: ldur            x0, [fp, #-0xb0]
    // 0x8f03c8: StoreField: r1->field_f = r0
    //     0x8f03c8: stur            w0, [x1, #0xf]
    // 0x8f03cc: r16 = ": start"
    //     0x8f03cc: add             x16, PP, #0x16, lsl #12  ; [pp+0x16138] ": start"
    //     0x8f03d0: ldr             x16, [x16, #0x138]
    // 0x8f03d4: StoreField: r1->field_13 = r16
    //     0x8f03d4: stur            w16, [x1, #0x13]
    // 0x8f03d8: str             x1, [SP]
    // 0x8f03dc: r0 = _interpolate()
    //     0x8f03dc: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x8f03e0: ldur            x16, [fp, #-0xb8]
    // 0x8f03e4: str             x16, [SP]
    // 0x8f03e8: mov             x1, x0
    // 0x8f03ec: r4 = const [0, 0x2, 0x1, 0x1, flow, 0x1, null]
    //     0x8f03ec: add             x4, PP, #0x16, lsl #12  ; [pp+0x16140] List(7) [0, 0x2, 0x1, 0x1, "flow", 0x1, Null]
    //     0x8f03f0: ldr             x4, [x4, #0x140]
    // 0x8f03f4: r0 = startSync()
    //     0x8f03f4: bl              #0x8f0d18  ; [dart:developer] Timeline::startSync
    // 0x8f03f8: r1 = Null
    //     0x8f03f8: mov             x1, NULL
    // 0x8f03fc: r2 = ""
    //     0x8f03fc: ldr             x2, [PP, #0x900]  ; [pp+0x900] ""
    // 0x8f0400: r0 = _RawReceivePort()
    //     0x8f0400: bl              #0x7f4154  ; [dart:isolate] _RawReceivePort::_RawReceivePort
    // 0x8f0404: mov             x1, x0
    // 0x8f0408: stur            x1, [fp, #-0xb0]
    // 0x8f040c: StoreField: r1->field_f = rNULL
    //     0x8f040c: stur            NULL, [x1, #0xf]
    // 0x8f0410: mov             x0, x1
    // 0x8f0414: ldur            x2, [fp, #-0xd0]
    // 0x8f0418: StoreField: r2->field_1b = r0
    //     0x8f0418: stur            w0, [x2, #0x1b]
    //     0x8f041c: ldurb           w16, [x2, #-1]
    //     0x8f0420: ldurb           w17, [x0, #-1]
    //     0x8f0424: and             x16, x17, x16, lsr #2
    //     0x8f0428: tst             x16, HEAP, lsr #32
    //     0x8f042c: b.eq            #0x8f0434
    //     0x8f0430: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x8f0434: r0 = finishSync()
    //     0x8f0434: bl              #0x8f0a44  ; [dart:developer] Timeline::finishSync
    // 0x8f0438: ldur            x0, [fp, #-0xd0]
    // 0x8f043c: StoreField: r0->field_1f = rNULL
    //     0x8f043c: stur            NULL, [x0, #0x1f]
    // 0x8f0440: r1 = false
    //     0x8f0440: add             x1, NULL, #0x30  ; false
    // 0x8f0444: StoreField: r0->field_23 = r1
    //     0x8f0444: stur            w1, [x0, #0x23]
    // 0x8f0448: mov             x2, x0
    // 0x8f044c: r1 = Function 'timeEndAndCleanup': static.
    //     0x8f044c: add             x1, PP, #0x16, lsl #12  ; [pp+0x16148] AnonymousClosure: static (0x8f18a4), in [package:dio/src/compute/compute_io.dart] ::computeWithTimeout (0x8f0218)
    //     0x8f0450: ldr             x1, [x1, #0x148]
    // 0x8f0454: r0 = AllocateClosure()
    //     0x8f0454: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8f0458: mov             x3, x0
    // 0x8f045c: ldur            x2, [fp, #-0xa8]
    // 0x8f0460: stur            x3, [fp, #-0xd8]
    // 0x8f0464: StoreField: r3->field_b = r2
    //     0x8f0464: stur            w2, [x3, #0xb]
    // 0x8f0468: mov             x0, x3
    // 0x8f046c: ldur            x4, [fp, #-0xd0]
    // 0x8f0470: StoreField: r4->field_27 = r0
    //     0x8f0470: stur            w0, [x4, #0x27]
    //     0x8f0474: ldurb           w16, [x4, #-1]
    //     0x8f0478: ldurb           w17, [x0, #-1]
    //     0x8f047c: and             x16, x17, x16, lsr #2
    //     0x8f0480: tst             x16, HEAP, lsr #32
    //     0x8f0484: b.eq            #0x8f048c
    //     0x8f0488: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0x8f048c: r1 = Null
    //     0x8f048c: mov             x1, NULL
    // 0x8f0490: r0 = _Future()
    //     0x8f0490: bl              #0x7f5dd4  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0x8f0494: stur            x0, [fp, #-0xe0]
    // 0x8f0498: StoreField: r0->field_b = rZR
    //     0x8f0498: stur            xzr, [x0, #0xb]
    // 0x8f049c: r0 = LoadStaticField(0x364)
    //     0x8f049c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8f04a0: ldr             x0, [x0, #0x6c8]
    // 0x8f04a4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8f04a8: cmp             w0, w16
    // 0x8f04ac: b.ne            #0x8f04b8
    // 0x8f04b0: r2 = _current
    //     0x8f04b0: ldr             x2, [PP, #0x2c0]  ; [pp+0x2c0] Field <Zone._current@5048458>: static late (offset: 0x364)
    // 0x8f04b4: r0 = InitLateStaticField()
    //     0x8f04b4: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0x8f04b8: mov             x1, x0
    // 0x8f04bc: ldur            x0, [fp, #-0xe0]
    // 0x8f04c0: StoreField: r0->field_13 = r1
    //     0x8f04c0: stur            w1, [x0, #0x13]
    // 0x8f04c4: r1 = Null
    //     0x8f04c4: mov             x1, NULL
    // 0x8f04c8: r0 = _AsyncCompleter()
    //     0x8f04c8: bl              #0x7f5dc8  ; Allocate_AsyncCompleterStub -> _AsyncCompleter<X0> (size=0x10)
    // 0x8f04cc: ldur            x3, [fp, #-0xe0]
    // 0x8f04d0: StoreField: r0->field_b = r3
    //     0x8f04d0: stur            w3, [x0, #0xb]
    // 0x8f04d4: ldur            x4, [fp, #-0xd0]
    // 0x8f04d8: StoreField: r4->field_2b = r0
    //     0x8f04d8: stur            w0, [x4, #0x2b]
    //     0x8f04dc: ldurb           w16, [x4, #-1]
    //     0x8f04e0: ldurb           w17, [x0, #-1]
    //     0x8f04e4: and             x16, x17, x16, lsr #2
    //     0x8f04e8: tst             x16, HEAP, lsr #32
    //     0x8f04ec: b.eq            #0x8f04f4
    //     0x8f04f0: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0x8f04f4: StoreField: r4->field_2f = rNULL
    //     0x8f04f4: stur            NULL, [x4, #0x2f]
    // 0x8f04f8: mov             x2, x4
    // 0x8f04fc: r1 = Function 'completeWithError': static.
    //     0x8f04fc: add             x1, PP, #0x16, lsl #12  ; [pp+0x16150] AnonymousClosure: static (0x8f17d0), in [package:dio/src/compute/compute_io.dart] ::computeWithTimeout (0x8f0218)
    //     0x8f0500: ldr             x1, [x1, #0x150]
    // 0x8f0504: r0 = AllocateClosure()
    //     0x8f0504: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8f0508: ldur            x3, [fp, #-0xa8]
    // 0x8f050c: StoreField: r0->field_b = r3
    //     0x8f050c: stur            w3, [x0, #0xb]
    // 0x8f0510: ldur            x4, [fp, #-0xd0]
    // 0x8f0514: StoreField: r4->field_33 = r0
    //     0x8f0514: stur            w0, [x4, #0x33]
    //     0x8f0518: ldurb           w16, [x4, #-1]
    //     0x8f051c: ldurb           w17, [x0, #-1]
    //     0x8f0520: and             x16, x17, x16, lsr #2
    //     0x8f0524: tst             x16, HEAP, lsr #32
    //     0x8f0528: b.eq            #0x8f0530
    //     0x8f052c: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0x8f0530: mov             x2, x4
    // 0x8f0534: r1 = Function '<anonymous closure>': static.
    //     0x8f0534: add             x1, PP, #0x16, lsl #12  ; [pp+0x16158] AnonymousClosure: static (0x8f1738), in [package:dio/src/compute/compute_io.dart] ::computeWithTimeout (0x8f0218)
    //     0x8f0538: ldr             x1, [x1, #0x158]
    // 0x8f053c: r0 = AllocateClosure()
    //     0x8f053c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8f0540: ldur            x4, [fp, #-0xa8]
    // 0x8f0544: StoreField: r0->field_b = r4
    //     0x8f0544: stur            w4, [x0, #0xb]
    // 0x8f0548: ldur            x5, [fp, #-0xb0]
    // 0x8f054c: StoreField: r5->field_f = r0
    //     0x8f054c: stur            w0, [x5, #0xf]
    //     0x8f0550: ldurb           w16, [x5, #-1]
    //     0x8f0554: ldurb           w17, [x0, #-1]
    //     0x8f0558: and             x16, x17, x16, lsr #2
    //     0x8f055c: tst             x16, HEAP, lsr #32
    //     0x8f0560: b.eq            #0x8f0568
    //     0x8f0564: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0x8f0568: ldur            x7, [fp, #-0xc8]
    // 0x8f056c: ldur            x8, [fp, #-0xc0]
    // 0x8f0570: ldur            x0, [fp, #-0xd0]
    // 0x8f0574: ldur            x6, [fp, #-0xb8]
    // 0x8f0578: mov             x1, x4
    // 0x8f057c: r2 = Null
    //     0x8f057c: mov             x2, NULL
    // 0x8f0580: r3 = <_IsolateConfiguration<Y0, Y1>>
    //     0x8f0580: add             x3, PP, #0x16, lsl #12  ; [pp+0x16160] TypeArguments: <_IsolateConfiguration<Y0, Y1>>
    //     0x8f0584: ldr             x3, [x3, #0x160]
    // 0x8f0588: r30 = InstantiateTypeArgumentsStub
    //     0x8f0588: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0x8f058c: LoadField: r30 = r30->field_7
    //     0x8f058c: ldur            lr, [lr, #7]
    // 0x8f0590: blr             lr
    // 0x8f0594: stur            x0, [fp, #-0xe8]
    // 0x8f0598: r16 = Closure: <Y0, Y1>(_IsolateConfiguration<Y0, Y1>) => Future<void> from Function '_spawn@1265363018': static.
    //     0x8f0598: add             x16, PP, #0x16, lsl #12  ; [pp+0x16168] Closure: <Y0, Y1>(_IsolateConfiguration<Y0, Y1>) => Future<void> from Function '_spawn@1265363018': static. (0x7f2ada7d830c)
    //     0x8f059c: ldr             x16, [x16, #0x168]
    // 0x8f05a0: ldur            lr, [fp, #-0xa8]
    // 0x8f05a4: stp             lr, x16, [SP]
    // 0x8f05a8: r0 = _instantiateClosure()
    //     0x8f05a8: bl              #0x7d92dc  ; [dart:_internal] ::_instantiateClosure
    // 0x8f05ac: ldur            x1, [fp, #-0xa8]
    // 0x8f05b0: stur            x0, [fp, #-0xf0]
    // 0x8f05b4: r0 = _IsolateConfiguration()
    //     0x8f05b4: bl              #0x8f0a38  ; Allocate_IsolateConfigurationStub -> _IsolateConfiguration<X0, X1> (size=0x24)
    // 0x8f05b8: mov             x1, x0
    // 0x8f05bc: ldur            x0, [fp, #-0xb0]
    // 0x8f05c0: LoadField: r2 = r0->field_7
    //     0x8f05c0: ldur            w2, [x0, #7]
    // 0x8f05c4: DecompressPointer r2
    //     0x8f05c4: add             x2, x2, HEAP, lsl #32
    // 0x8f05c8: ldur            x0, [fp, #-0xd0]
    // 0x8f05cc: LoadField: r3 = r0->field_f
    //     0x8f05cc: ldur            w3, [x0, #0xf]
    // 0x8f05d0: DecompressPointer r3
    //     0x8f05d0: add             x3, x3, HEAP, lsl #32
    // 0x8f05d4: ldur            x4, [fp, #-0xb8]
    // 0x8f05d8: LoadField: r5 = r4->field_f
    //     0x8f05d8: ldur            x5, [x4, #0xf]
    // 0x8f05dc: ldur            x4, [fp, #-0xc8]
    // 0x8f05e0: StoreField: r1->field_b = r4
    //     0x8f05e0: stur            w4, [x1, #0xb]
    // 0x8f05e4: ldur            x6, [fp, #-0xc0]
    // 0x8f05e8: StoreField: r1->field_f = r6
    //     0x8f05e8: stur            w6, [x1, #0xf]
    // 0x8f05ec: StoreField: r1->field_13 = r2
    //     0x8f05ec: stur            w2, [x1, #0x13]
    // 0x8f05f0: ArrayStore: r1[0] = r3  ; List_4
    //     0x8f05f0: stur            w3, [x1, #0x17]
    // 0x8f05f4: StoreField: r1->field_1b = r5
    //     0x8f05f4: stur            x5, [x1, #0x1b]
    // 0x8f05f8: ldur            x16, [fp, #-0xe8]
    // 0x8f05fc: ldur            lr, [fp, #-0xf0]
    // 0x8f0600: stp             lr, x16, [SP, #0x20]
    // 0x8f0604: stp             x2, x1, [SP, #0x10]
    // 0x8f0608: stp             x3, x2, [SP]
    // 0x8f060c: r4 = const [0x1, 0x5, 0x5, 0x2, debugName, 0x4, onError, 0x3, onExit, 0x2, null]
    //     0x8f060c: add             x4, PP, #0x16, lsl #12  ; [pp+0x16170] List(11) [0x1, 0x5, 0x5, 0x2, "debugName", 0x4, "onError", 0x3, "onExit", 0x2, Null]
    //     0x8f0610: ldr             x4, [x4, #0x170]
    // 0x8f0614: r0 = spawn()
    //     0x8f0614: bl              #0x84712c  ; [dart:isolate] Isolate::spawn
    // 0x8f0618: mov             x1, x0
    // 0x8f061c: stur            x1, [fp, #-0xb0]
    // 0x8f0620: r0 = Await()
    //     0x8f0620: bl              #0x7f5c00  ; AwaitStub
    // 0x8f0624: ldur            x3, [fp, #-0xd0]
    // 0x8f0628: StoreField: r3->field_2f = r0
    //     0x8f0628: stur            w0, [x3, #0x2f]
    //     0x8f062c: tbz             w0, #0, #0x8f0648
    //     0x8f0630: ldurb           w16, [x3, #-1]
    //     0x8f0634: ldurb           w17, [x0, #-1]
    //     0x8f0638: and             x16, x17, x16, lsr #2
    //     0x8f063c: tst             x16, HEAP, lsr #32
    //     0x8f0640: b.eq            #0x8f0648
    //     0x8f0644: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x8f0648: LoadField: r0 = r3->field_13
    //     0x8f0648: ldur            w0, [x3, #0x13]
    // 0x8f064c: DecompressPointer r0
    //     0x8f064c: add             x0, x0, HEAP, lsl #32
    // 0x8f0650: stur            x0, [fp, #-0xb0]
    // 0x8f0654: cmp             w0, NULL
    // 0x8f0658: b.eq            #0x8f06dc
    // 0x8f065c: LoadField: r1 = r0->field_7
    //     0x8f065c: ldur            x1, [x0, #7]
    // 0x8f0660: cmp             x1, #0
    // 0x8f0664: b.le            #0x8f06d4
    // 0x8f0668: ldur            x4, [fp, #-0xe0]
    // 0x8f066c: LoadField: r1 = r4->field_b
    //     0x8f066c: ldur            x1, [x4, #0xb]
    // 0x8f0670: tst             x1, #0x1e
    // 0x8f0674: b.ne            #0x8f06cc
    // 0x8f0678: ldur            x5, [fp, #-0xa8]
    // 0x8f067c: mov             x2, x3
    // 0x8f0680: r1 = Function '<anonymous closure>': static.
    //     0x8f0680: add             x1, PP, #0x16, lsl #12  ; [pp+0x16178] AnonymousClosure: static (0x8f10ac), in [package:dio/src/compute/compute_io.dart] ::computeWithTimeout (0x8f0218)
    //     0x8f0684: ldr             x1, [x1, #0x178]
    // 0x8f0688: r0 = AllocateClosure()
    //     0x8f0688: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8f068c: mov             x1, x0
    // 0x8f0690: ldur            x0, [fp, #-0xa8]
    // 0x8f0694: StoreField: r1->field_b = r0
    //     0x8f0694: stur            w0, [x1, #0xb]
    // 0x8f0698: ldur            x2, [fp, #-0xb0]
    // 0x8f069c: mov             x3, x1
    // 0x8f06a0: r1 = Null
    //     0x8f06a0: mov             x1, NULL
    // 0x8f06a4: r0 = Timer()
    //     0x8f06a4: bl              #0x7eed74  ; [dart:async] Timer::Timer
    // 0x8f06a8: ldur            x1, [fp, #-0xd0]
    // 0x8f06ac: StoreField: r1->field_1f = r0
    //     0x8f06ac: stur            w0, [x1, #0x1f]
    //     0x8f06b0: ldurb           w16, [x1, #-1]
    //     0x8f06b4: ldurb           w17, [x0, #-1]
    //     0x8f06b8: and             x16, x17, x16, lsr #2
    //     0x8f06bc: tst             x16, HEAP, lsr #32
    //     0x8f06c0: b.eq            #0x8f06c8
    //     0x8f06c4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8f06c8: b               #0x8f06e0
    // 0x8f06cc: mov             x1, x3
    // 0x8f06d0: b               #0x8f06e0
    // 0x8f06d4: mov             x1, x3
    // 0x8f06d8: b               #0x8f06e0
    // 0x8f06dc: mov             x1, x3
    // 0x8f06e0: ldur            x0, [fp, #-0xe0]
    // 0x8f06e4: r0 = Await()
    //     0x8f06e4: bl              #0x7f5c00  ; AwaitStub
    // 0x8f06e8: mov             x3, x0
    // 0x8f06ec: stur            x3, [fp, #-0xb0]
    // 0x8f06f0: cmp             w3, NULL
    // 0x8f06f4: b.eq            #0x8f08c0
    // 0x8f06f8: mov             x0, x3
    // 0x8f06fc: r2 = Null
    //     0x8f06fc: mov             x2, NULL
    // 0x8f0700: r1 = Null
    //     0x8f0700: mov             x1, NULL
    // 0x8f0704: r4 = 60
    //     0x8f0704: mov             x4, #0x3c
    // 0x8f0708: branchIfSmi(r0, 0x8f0714)
    //     0x8f0708: tbz             w0, #0, #0x8f0714
    // 0x8f070c: r4 = LoadClassIdInstr(r0)
    //     0x8f070c: ldur            x4, [x0, #-1]
    //     0x8f0710: ubfx            x4, x4, #0xc, #0x14
    // 0x8f0714: sub             x4, x4, #0x5a
    // 0x8f0718: cmp             x4, #2
    // 0x8f071c: b.ls            #0x8f0730
    // 0x8f0720: r8 = List
    //     0x8f0720: ldr             x8, [PP, #0x30e8]  ; [pp+0x30e8] Type: List
    // 0x8f0724: r3 = Null
    //     0x8f0724: add             x3, PP, #0x16, lsl #12  ; [pp+0x16180] Null
    //     0x8f0728: ldr             x3, [x3, #0x180]
    // 0x8f072c: r0 = List()
    //     0x8f072c: bl              #0x13efaa0  ; IsType_List_Stub
    // 0x8f0730: ldur            x1, [fp, #-0xb0]
    // 0x8f0734: r0 = LoadClassIdInstr(r1)
    //     0x8f0734: ldur            x0, [x1, #-1]
    //     0x8f0738: ubfx            x0, x0, #0xc, #0x14
    // 0x8f073c: str             x1, [SP]
    // 0x8f0740: r0 = GDT[cid_x0 + 0xf078]()
    //     0x8f0740: mov             x17, #0xf078
    //     0x8f0744: add             lr, x0, x17
    //     0x8f0748: ldr             lr, [x21, lr, lsl #3]
    //     0x8f074c: blr             lr
    // 0x8f0750: r1 = LoadInt32Instr(r0)
    //     0x8f0750: sbfx            x1, x0, #1, #0x1f
    //     0x8f0754: tbz             w0, #0, #0x8f075c
    //     0x8f0758: ldur            x1, [x0, #7]
    // 0x8f075c: cmp             x1, #2
    // 0x8f0760: b.gt            #0x8f07d8
    // 0x8f0764: cmp             x1, #1
    // 0x8f0768: b.gt            #0x8f08f8
    // 0x8f076c: cmp             w0, #2
    // 0x8f0770: b.ne            #0x8f07d0
    // 0x8f0774: ldur            x1, [fp, #-0xb0]
    // 0x8f0778: r0 = LoadClassIdInstr(r1)
    //     0x8f0778: ldur            x0, [x1, #-1]
    //     0x8f077c: ubfx            x0, x0, #0xc, #0x14
    // 0x8f0780: stp             xzr, x1, [SP]
    // 0x8f0784: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x8f0784: sub             lr, x0, #0xdfd
    //     0x8f0788: ldr             lr, [x21, lr, lsl #3]
    //     0x8f078c: blr             lr
    // 0x8f0790: ldur            x1, [fp, #-0xa8]
    // 0x8f0794: mov             x3, x0
    // 0x8f0798: r2 = Null
    //     0x8f0798: mov             x2, NULL
    // 0x8f079c: stur            x3, [fp, #-0xa8]
    // 0x8f07a0: cmp             w1, NULL
    // 0x8f07a4: b.eq            #0x8f07c8
    // 0x8f07a8: LoadField: r4 = r1->field_1b
    //     0x8f07a8: ldur            w4, [x1, #0x1b]
    // 0x8f07ac: DecompressPointer r4
    //     0x8f07ac: add             x4, x4, HEAP, lsl #32
    // 0x8f07b0: r8 = Y1
    //     0x8f07b0: add             x8, PP, #0x16, lsl #12  ; [pp+0x16190] TypeParameter: Y1
    //     0x8f07b4: ldr             x8, [x8, #0x190]
    // 0x8f07b8: LoadField: r9 = r4->field_7
    //     0x8f07b8: ldur            x9, [x4, #7]
    // 0x8f07bc: r3 = Null
    //     0x8f07bc: add             x3, PP, #0x16, lsl #12  ; [pp+0x16198] Null
    //     0x8f07c0: ldr             x3, [x3, #0x198]
    // 0x8f07c4: blr             x9
    // 0x8f07c8: ldur            x0, [fp, #-0xa8]
    // 0x8f07cc: r0 = ReturnAsync()
    //     0x8f07cc: b               #0x82fdf0  ; ReturnAsyncStub
    // 0x8f07d0: ldur            x1, [fp, #-0xb0]
    // 0x8f07d4: b               #0x8f07dc
    // 0x8f07d8: ldur            x1, [fp, #-0xb0]
    // 0x8f07dc: r0 = LoadClassIdInstr(r1)
    //     0x8f07dc: ldur            x0, [x1, #-1]
    //     0x8f07e0: ubfx            x0, x0, #0xc, #0x14
    // 0x8f07e4: stp             xzr, x1, [SP]
    // 0x8f07e8: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x8f07e8: sub             lr, x0, #0xdfd
    //     0x8f07ec: ldr             lr, [x21, lr, lsl #3]
    //     0x8f07f0: blr             lr
    // 0x8f07f4: mov             x3, x0
    // 0x8f07f8: stur            x3, [fp, #-0xa8]
    // 0x8f07fc: cmp             w3, NULL
    // 0x8f0800: b.ne            #0x8f0828
    // 0x8f0804: mov             x0, x3
    // 0x8f0808: r2 = Null
    //     0x8f0808: mov             x2, NULL
    // 0x8f080c: r1 = Null
    //     0x8f080c: mov             x1, NULL
    // 0x8f0810: cmp             w0, NULL
    // 0x8f0814: b.ne            #0x8f0828
    // 0x8f0818: r8 = Object
    //     0x8f0818: ldr             x8, [PP, #0xd0]  ; [pp+0xd0] Type: Object
    // 0x8f081c: r3 = Null
    //     0x8f081c: add             x3, PP, #0x16, lsl #12  ; [pp+0x161a8] Null
    //     0x8f0820: ldr             x3, [x3, #0x1a8]
    // 0x8f0824: r0 = Object()
    //     0x8f0824: bl              #0x13ef428  ; IsType_Object_Stub
    // 0x8f0828: ldur            x1, [fp, #-0xb0]
    // 0x8f082c: r0 = LoadClassIdInstr(r1)
    //     0x8f082c: ldur            x0, [x1, #-1]
    //     0x8f0830: ubfx            x0, x0, #0xc, #0x14
    // 0x8f0834: r16 = 2
    //     0x8f0834: mov             x16, #2
    // 0x8f0838: stp             x16, x1, [SP]
    // 0x8f083c: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x8f083c: sub             lr, x0, #0xdfd
    //     0x8f0840: ldr             lr, [x21, lr, lsl #3]
    //     0x8f0844: blr             lr
    // 0x8f0848: mov             x3, x0
    // 0x8f084c: r2 = Null
    //     0x8f084c: mov             x2, NULL
    // 0x8f0850: r1 = Null
    //     0x8f0850: mov             x1, NULL
    // 0x8f0854: stur            x3, [fp, #-0xb8]
    // 0x8f0858: r4 = 60
    //     0x8f0858: mov             x4, #0x3c
    // 0x8f085c: branchIfSmi(r0, 0x8f0868)
    //     0x8f085c: tbz             w0, #0, #0x8f0868
    // 0x8f0860: r4 = LoadClassIdInstr(r0)
    //     0x8f0860: ldur            x4, [x0, #-1]
    //     0x8f0864: ubfx            x4, x4, #0xc, #0x14
    // 0x8f0868: cmp             x4, #0x4d
    // 0x8f086c: b.eq            #0x8f0894
    // 0x8f0870: cmp             x4, #0x443
    // 0x8f0874: b.eq            #0x8f0894
    // 0x8f0878: r17 = 7620
    //     0x8f0878: mov             x17, #0x1dc4
    // 0x8f087c: cmp             x4, x17
    // 0x8f0880: b.eq            #0x8f0894
    // 0x8f0884: r8 = StackTrace
    //     0x8f0884: ldr             x8, [PP, #0x618]  ; [pp+0x618] Type: StackTrace
    // 0x8f0888: r3 = Null
    //     0x8f0888: add             x3, PP, #0x16, lsl #12  ; [pp+0x161b8] Null
    //     0x8f088c: ldr             x3, [x3, #0x1b8]
    // 0x8f0890: r0 = DefaultTypeTest()
    //     0x8f0890: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x8f0894: ldur            x16, [fp, #-0xb8]
    // 0x8f0898: str             x16, [SP]
    // 0x8f089c: ldur            x2, [fp, #-0xa8]
    // 0x8f08a0: r1 = <Never>
    //     0x8f08a0: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x8f08a4: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x8f08a4: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x8f08a8: r0 = Future.error()
    //     0x8f08a8: bl              #0x7fc9cc  ; [dart:async] Future::Future.error
    // 0x8f08ac: mov             x1, x0
    // 0x8f08b0: stur            x1, [fp, #-0xa8]
    // 0x8f08b4: r0 = Await()
    //     0x8f08b4: bl              #0x7f5c00  ; AwaitStub
    // 0x8f08b8: r0 = Null
    //     0x8f08b8: mov             x0, NULL
    // 0x8f08bc: r0 = ReturnAsyncNotFuture()
    //     0x8f08bc: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x8f08c0: r0 = RemoteError()
    //     0x8f08c0: bl              #0x8480a8  ; AllocateRemoteErrorStub -> RemoteError (size=0x10)
    // 0x8f08c4: mov             x1, x0
    // 0x8f08c8: r0 = "Isolate exited without result or error."
    //     0x8f08c8: add             x0, PP, #0x16, lsl #12  ; [pp+0x161c8] "Isolate exited without result or error."
    //     0x8f08cc: ldr             x0, [x0, #0x1c8]
    // 0x8f08d0: stur            x1, [fp, #-0xa8]
    // 0x8f08d4: StoreField: r1->field_7 = r0
    //     0x8f08d4: stur            w0, [x1, #7]
    // 0x8f08d8: r0 = _StringStackTrace()
    //     0x8f08d8: bl              #0x84809c  ; Allocate_StringStackTraceStub -> _StringStackTrace (size=0xc)
    // 0x8f08dc: mov             x1, x0
    // 0x8f08e0: r0 = ""
    //     0x8f08e0: ldr             x0, [PP, #0x900]  ; [pp+0x900] ""
    // 0x8f08e4: StoreField: r1->field_7 = r0
    //     0x8f08e4: stur            w0, [x1, #7]
    // 0x8f08e8: ldur            x0, [fp, #-0xa8]
    // 0x8f08ec: StoreField: r0->field_b = r1
    //     0x8f08ec: stur            w1, [x0, #0xb]
    // 0x8f08f0: r0 = Throw()
    //     0x8f08f0: bl              #0x13ddb2c  ; ThrowStub
    // 0x8f08f4: brk             #0
    // 0x8f08f8: ldur            x1, [fp, #-0xb0]
    // 0x8f08fc: r0 = LoadClassIdInstr(r1)
    //     0x8f08fc: ldur            x0, [x1, #-1]
    //     0x8f0900: ubfx            x0, x0, #0xc, #0x14
    // 0x8f0904: stp             xzr, x1, [SP]
    // 0x8f0908: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x8f0908: sub             lr, x0, #0xdfd
    //     0x8f090c: ldr             lr, [x21, lr, lsl #3]
    //     0x8f0910: blr             lr
    // 0x8f0914: mov             x3, x0
    // 0x8f0918: r2 = Null
    //     0x8f0918: mov             x2, NULL
    // 0x8f091c: r1 = Null
    //     0x8f091c: mov             x1, NULL
    // 0x8f0920: stur            x3, [fp, #-0xa8]
    // 0x8f0924: r4 = 60
    //     0x8f0924: mov             x4, #0x3c
    // 0x8f0928: branchIfSmi(r0, 0x8f0934)
    //     0x8f0928: tbz             w0, #0, #0x8f0934
    // 0x8f092c: r4 = LoadClassIdInstr(r0)
    //     0x8f092c: ldur            x4, [x0, #-1]
    //     0x8f0930: ubfx            x4, x4, #0xc, #0x14
    // 0x8f0934: sub             x4, x4, #0x5e
    // 0x8f0938: cmp             x4, #1
    // 0x8f093c: b.ls            #0x8f0950
    // 0x8f0940: r8 = String
    //     0x8f0940: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x8f0944: r3 = Null
    //     0x8f0944: add             x3, PP, #0x16, lsl #12  ; [pp+0x161d0] Null
    //     0x8f0948: ldr             x3, [x3, #0x1d0]
    // 0x8f094c: r0 = String()
    //     0x8f094c: bl              #0x13ee320  ; IsType_String_Stub
    // 0x8f0950: ldur            x0, [fp, #-0xb0]
    // 0x8f0954: r1 = LoadClassIdInstr(r0)
    //     0x8f0954: ldur            x1, [x0, #-1]
    //     0x8f0958: ubfx            x1, x1, #0xc, #0x14
    // 0x8f095c: r16 = 2
    //     0x8f095c: mov             x16, #2
    // 0x8f0960: stp             x16, x0, [SP]
    // 0x8f0964: mov             x0, x1
    // 0x8f0968: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x8f0968: sub             lr, x0, #0xdfd
    //     0x8f096c: ldr             lr, [x21, lr, lsl #3]
    //     0x8f0970: blr             lr
    // 0x8f0974: mov             x3, x0
    // 0x8f0978: r2 = Null
    //     0x8f0978: mov             x2, NULL
    // 0x8f097c: r1 = Null
    //     0x8f097c: mov             x1, NULL
    // 0x8f0980: stur            x3, [fp, #-0xb0]
    // 0x8f0984: r4 = 60
    //     0x8f0984: mov             x4, #0x3c
    // 0x8f0988: branchIfSmi(r0, 0x8f0994)
    //     0x8f0988: tbz             w0, #0, #0x8f0994
    // 0x8f098c: r4 = LoadClassIdInstr(r0)
    //     0x8f098c: ldur            x4, [x0, #-1]
    //     0x8f0990: ubfx            x4, x4, #0xc, #0x14
    // 0x8f0994: sub             x4, x4, #0x5e
    // 0x8f0998: cmp             x4, #1
    // 0x8f099c: b.ls            #0x8f09b0
    // 0x8f09a0: r8 = String
    //     0x8f09a0: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x8f09a4: r3 = Null
    //     0x8f09a4: add             x3, PP, #0x16, lsl #12  ; [pp+0x161e0] Null
    //     0x8f09a8: ldr             x3, [x3, #0x1e0]
    // 0x8f09ac: r0 = String()
    //     0x8f09ac: bl              #0x13ee320  ; IsType_String_Stub
    // 0x8f09b0: r0 = RemoteError()
    //     0x8f09b0: bl              #0x8480a8  ; AllocateRemoteErrorStub -> RemoteError (size=0x10)
    // 0x8f09b4: mov             x1, x0
    // 0x8f09b8: ldur            x0, [fp, #-0xa8]
    // 0x8f09bc: stur            x1, [fp, #-0xb8]
    // 0x8f09c0: StoreField: r1->field_7 = r0
    //     0x8f09c0: stur            w0, [x1, #7]
    // 0x8f09c4: r0 = _StringStackTrace()
    //     0x8f09c4: bl              #0x84809c  ; Allocate_StringStackTraceStub -> _StringStackTrace (size=0xc)
    // 0x8f09c8: mov             x1, x0
    // 0x8f09cc: ldur            x0, [fp, #-0xb0]
    // 0x8f09d0: StoreField: r1->field_7 = r0
    //     0x8f09d0: stur            w0, [x1, #7]
    // 0x8f09d4: ldur            x2, [fp, #-0xb8]
    // 0x8f09d8: StoreField: r2->field_b = r1
    //     0x8f09d8: stur            w1, [x2, #0xb]
    // 0x8f09dc: r1 = <Never>
    //     0x8f09dc: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x8f09e0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8f09e0: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8f09e4: r0 = Future.error()
    //     0x8f09e4: bl              #0x7fc9cc  ; [dart:async] Future::Future.error
    // 0x8f09e8: mov             x1, x0
    // 0x8f09ec: stur            x1, [fp, #-0xa8]
    // 0x8f09f0: r0 = Await()
    //     0x8f09f0: bl              #0x7f5c00  ; AwaitStub
    // 0x8f09f4: brk             #0
    // 0x8f09f8: sub             SP, fp, #0x120
    // 0x8f09fc: mov             x2, x0
    // 0x8f0a00: stur            x0, [fp, #-0xa8]
    // 0x8f0a04: stur            x1, [fp, #-0xb0]
    // 0x8f0a08: ldur            x16, [fp, #-0xd8]
    // 0x8f0a0c: str             x16, [SP]
    // 0x8f0a10: ldur            x0, [fp, #-0xd8]
    // 0x8f0a14: ClosureCall
    //     0x8f0a14: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x8f0a18: ldur            x2, [x0, #0x1f]
    //     0x8f0a1c: blr             x2
    // 0x8f0a20: ldur            x0, [fp, #-0xa8]
    // 0x8f0a24: ldur            x1, [fp, #-0xb0]
    // 0x8f0a28: r0 = ReThrow()
    //     0x8f0a28: bl              #0x13ddb00  ; ReThrowStub
    // 0x8f0a2c: brk             #0
    // 0x8f0a30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f0a30: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f0a34: b               #0x8f0300
  }
  [closure] static void <anonymous closure>(dynamic) {
    // ** addr: 0x8f10ac, size: 0x13c
    // 0x8f10ac: EnterFrame
    //     0x8f10ac: stp             fp, lr, [SP, #-0x10]!
    //     0x8f10b0: mov             fp, SP
    // 0x8f10b4: AllocStack(0x30)
    //     0x8f10b4: sub             SP, SP, #0x30
    // 0x8f10b8: SetupParameters([dynamic _ /* r0 */])
    //     0x8f10b8: ldr             x0, [fp, #0x10]
    //     0x8f10bc: ldur            w2, [x0, #0x17]
    //     0x8f10c0: add             x2, x2, HEAP, lsl #32
    //     0x8f10c4: stur            x2, [fp, #-8]
    // 0x8f10c8: CheckStackOverflow
    //     0x8f10c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f10cc: cmp             SP, x16
    //     0x8f10d0: b.ls            #0x8f11e0
    // 0x8f10d4: LoadField: r1 = r2->field_2f
    //     0x8f10d4: ldur            w1, [x2, #0x2f]
    // 0x8f10d8: DecompressPointer r1
    //     0x8f10d8: add             x1, x1, HEAP, lsl #32
    // 0x8f10dc: cmp             w1, NULL
    // 0x8f10e0: b.ne            #0x8f10ec
    // 0x8f10e4: mov             x0, x2
    // 0x8f10e8: b               #0x8f1100
    // 0x8f10ec: str             xzr, [SP]
    // 0x8f10f0: r4 = const [0, 0x2, 0x1, 0x1, priority, 0x1, null]
    //     0x8f10f0: add             x4, PP, #0x16, lsl #12  ; [pp+0x161f0] List(7) [0, 0x2, 0x1, 0x1, "priority", 0x1, Null]
    //     0x8f10f4: ldr             x4, [x4, #0x1f0]
    // 0x8f10f8: r0 = kill()
    //     0x8f10f8: bl              #0x8f11e8  ; [dart:isolate] Isolate::kill
    // 0x8f10fc: ldur            x0, [fp, #-8]
    // 0x8f1100: LoadField: r3 = r0->field_33
    //     0x8f1100: ldur            w3, [x0, #0x33]
    // 0x8f1104: DecompressPointer r3
    //     0x8f1104: add             x3, x3, HEAP, lsl #32
    // 0x8f1108: stur            x3, [fp, #-0x10]
    // 0x8f110c: r1 = Null
    //     0x8f110c: mov             x1, NULL
    // 0x8f1110: r2 = 6
    //     0x8f1110: mov             x2, #6
    // 0x8f1114: r0 = AllocateArray()
    //     0x8f1114: bl              #0x13df928  ; AllocateArrayStub
    // 0x8f1118: r16 = "Computation timed out after "
    //     0x8f1118: add             x16, PP, #0x16, lsl #12  ; [pp+0x161f8] "Computation timed out after "
    //     0x8f111c: ldr             x16, [x16, #0x1f8]
    // 0x8f1120: StoreField: r0->field_f = r16
    //     0x8f1120: stur            w16, [x0, #0xf]
    // 0x8f1124: ldur            x1, [fp, #-8]
    // 0x8f1128: LoadField: r2 = r1->field_13
    //     0x8f1128: ldur            w2, [x1, #0x13]
    // 0x8f112c: DecompressPointer r2
    //     0x8f112c: add             x2, x2, HEAP, lsl #32
    // 0x8f1130: StoreField: r0->field_13 = r2
    //     0x8f1130: stur            w2, [x0, #0x13]
    // 0x8f1134: r16 = "."
    //     0x8f1134: ldr             x16, [PP, #0xfc8]  ; [pp+0xfc8] "."
    // 0x8f1138: ArrayStore: r0[0] = r16  ; List_4
    //     0x8f1138: stur            w16, [x0, #0x17]
    // 0x8f113c: str             x0, [SP]
    // 0x8f1140: r0 = _interpolate()
    //     0x8f1140: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x8f1144: mov             x1, x0
    // 0x8f1148: ldur            x0, [fp, #-8]
    // 0x8f114c: stur            x1, [fp, #-0x20]
    // 0x8f1150: LoadField: r2 = r0->field_13
    //     0x8f1150: ldur            w2, [x0, #0x13]
    // 0x8f1154: DecompressPointer r2
    //     0x8f1154: add             x2, x2, HEAP, lsl #32
    // 0x8f1158: stur            x2, [fp, #-0x18]
    // 0x8f115c: r0 = TimeoutException()
    //     0x8f115c: bl              #0x7f582c  ; AllocateTimeoutExceptionStub -> TimeoutException (size=0x10)
    // 0x8f1160: mov             x1, x0
    // 0x8f1164: ldur            x0, [fp, #-0x20]
    // 0x8f1168: stur            x1, [fp, #-0x28]
    // 0x8f116c: StoreField: r1->field_7 = r0
    //     0x8f116c: stur            w0, [x1, #7]
    // 0x8f1170: ldur            x0, [fp, #-0x18]
    // 0x8f1174: StoreField: r1->field_b = r0
    //     0x8f1174: stur            w0, [x1, #0xb]
    // 0x8f1178: ldur            x0, [fp, #-0x10]
    // 0x8f117c: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x8f117c: ldur            w2, [x0, #0x17]
    // 0x8f1180: DecompressPointer r2
    //     0x8f1180: add             x2, x2, HEAP, lsl #32
    // 0x8f1184: LoadField: r3 = r2->field_2b
    //     0x8f1184: ldur            w3, [x2, #0x2b]
    // 0x8f1188: DecompressPointer r3
    //     0x8f1188: add             x3, x3, HEAP, lsl #32
    // 0x8f118c: stur            x3, [fp, #-8]
    // 0x8f1190: LoadField: r0 = r3->field_b
    //     0x8f1190: ldur            w0, [x3, #0xb]
    // 0x8f1194: DecompressPointer r0
    //     0x8f1194: add             x0, x0, HEAP, lsl #32
    // 0x8f1198: LoadField: r4 = r0->field_b
    //     0x8f1198: ldur            x4, [x0, #0xb]
    // 0x8f119c: tst             x4, #0x1e
    // 0x8f11a0: b.ne            #0x8f11d0
    // 0x8f11a4: LoadField: r0 = r2->field_27
    //     0x8f11a4: ldur            w0, [x2, #0x27]
    // 0x8f11a8: DecompressPointer r0
    //     0x8f11a8: add             x0, x0, HEAP, lsl #32
    // 0x8f11ac: str             x0, [SP]
    // 0x8f11b0: ClosureCall
    //     0x8f11b0: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x8f11b4: ldur            x2, [x0, #0x1f]
    //     0x8f11b8: blr             x2
    // 0x8f11bc: str             NULL, [SP]
    // 0x8f11c0: ldur            x1, [fp, #-8]
    // 0x8f11c4: ldur            x2, [fp, #-0x28]
    // 0x8f11c8: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x8f11c8: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x8f11cc: r0 = completeError()
    //     0x8f11cc: bl              #0x7f6b94  ; [dart:async] _Completer::completeError
    // 0x8f11d0: r0 = Null
    //     0x8f11d0: mov             x0, NULL
    // 0x8f11d4: LeaveFrame
    //     0x8f11d4: mov             SP, fp
    //     0x8f11d8: ldp             fp, lr, [SP], #0x10
    // 0x8f11dc: ret
    //     0x8f11dc: ret             
    // 0x8f11e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f11e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f11e4: b               #0x8f10d4
  }
  [closure] static Future<void> _spawn<Y0, Y1>(dynamic, _IsolateConfiguration<Y0, Y1>) {
    // ** addr: 0x8f130c, size: 0x7c
    // 0x8f130c: EnterFrame
    //     0x8f130c: stp             fp, lr, [SP, #-0x10]!
    //     0x8f1310: mov             fp, SP
    // 0x8f1314: AllocStack(0x10)
    //     0x8f1314: sub             SP, SP, #0x10
    // 0x8f1318: SetupParameters()
    //     0x8f1318: ldur            w0, [x4, #0xf]
    //     0x8f131c: cbnz            w0, #0x8f1328
    //     0x8f1320: mov             x1, NULL
    //     0x8f1324: b               #0x8f1334
    //     0x8f1328: ldur            w0, [x4, #0x17]
    //     0x8f132c: add             x1, fp, w0, sxtw #2
    //     0x8f1330: ldr             x1, [x1, #0x10]
    //     0x8f1334: ldr             x0, [fp, #0x18]
    //     0x8f1338: ldur            w2, [x0, #0xf]
    //     0x8f133c: add             x2, x2, HEAP, lsl #32
    //     0x8f1340: ldr             x16, [THR, #0xb0]  ; THR::empty_type_arguments
    //     0x8f1344: cmp             w2, w16
    //     0x8f1348: b.ne            #0x8f1354
    //     0x8f134c: mov             x0, x1
    //     0x8f1350: b               #0x8f1358
    //     0x8f1354: mov             x0, x2
    // 0x8f1358: CheckStackOverflow
    //     0x8f1358: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f135c: cmp             SP, x16
    //     0x8f1360: b.ls            #0x8f1380
    // 0x8f1364: ldr             x16, [fp, #0x10]
    // 0x8f1368: stp             x16, x0, [SP]
    // 0x8f136c: r4 = const [0x2, 0x1, 0x1, 0x1, null]
    //     0x8f136c: ldr             x4, [PP, #0x18e0]  ; [pp+0x18e0] List(5) [0x2, 0x1, 0x1, 0x1, Null]
    // 0x8f1370: r0 = _spawn()
    //     0x8f1370: bl              #0x8f1388  ; [package:dio/src/compute/compute_io.dart] ::_spawn
    // 0x8f1374: LeaveFrame
    //     0x8f1374: mov             SP, fp
    //     0x8f1378: ldp             fp, lr, [SP], #0x10
    // 0x8f137c: ret
    //     0x8f137c: ret             
    // 0x8f1380: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f1380: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f1384: b               #0x8f1364
  }
  static Future<void> _spawn<Y0, Y1>(_IsolateConfiguration<Y0, Y1>) async {
    // ** addr: 0x8f1388, size: 0x10c
    // 0x8f1388: EnterFrame
    //     0x8f1388: stp             fp, lr, [SP, #-0x10]!
    //     0x8f138c: mov             fp, SP
    // 0x8f1390: AllocStack(0xa0)
    //     0x8f1390: sub             SP, SP, #0xa0
    // 0x8f1394: SetupParameters(dynamic _ /* r1, fp-0x80 */)
    //     0x8f1394: stur            NULL, [fp, #-8]
    //     0x8f1398: mov             x0, #0
    //     0x8f139c: add             x1, fp, w0, sxtw #2
    //     0x8f13a0: ldr             x1, [x1, #0x10]
    //     0x8f13a4: stur            x1, [fp, #-0x80]
    // 0x8f13a8: LoadField: r0 = r4->field_f
    //     0x8f13a8: ldur            w0, [x4, #0xf]
    // 0x8f13ac: cbnz            w0, #0x8f13b8
    // 0x8f13b0: r2 = Null
    //     0x8f13b0: mov             x2, NULL
    // 0x8f13b4: b               #0x8f13c4
    // 0x8f13b8: ArrayLoad: r0 = r4[0]  ; List_4
    //     0x8f13b8: ldur            w0, [x4, #0x17]
    // 0x8f13bc: add             x2, fp, w0, sxtw #2
    // 0x8f13c0: ldr             x2, [x2, #0x10]
    // 0x8f13c4: stur            x2, [fp, #-0x78]
    // 0x8f13c8: CheckStackOverflow
    //     0x8f13c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f13cc: cmp             SP, x16
    //     0x8f13d0: b.ls            #0x8f148c
    // 0x8f13d4: InitAsync() -> Future<void?>
    //     0x8f13d4: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0x8f13d8: bl              #0x7f5e44  ; InitAsyncStub
    // 0x8f13dc: ldur            x1, [fp, #-0x80]
    // 0x8f13e0: r0 = applyAndTime()
    //     0x8f13e0: bl              #0x8f1560  ; [package:dio/src/compute/compute_io.dart] _IsolateConfiguration::applyAndTime
    // 0x8f13e4: ldur            x1, [fp, #-0x78]
    // 0x8f13e8: r2 = Null
    //     0x8f13e8: mov             x2, NULL
    // 0x8f13ec: r3 = <Y1>
    //     0x8f13ec: add             x3, PP, #0x16, lsl #12  ; [pp+0x16210] TypeArguments: <Y1>
    //     0x8f13f0: ldr             x3, [x3, #0x210]
    // 0x8f13f4: stur            x0, [fp, #-0x88]
    // 0x8f13f8: r0 = Null
    //     0x8f13f8: mov             x0, NULL
    // 0x8f13fc: cmp             x2, x0
    // 0x8f1400: b.ne            #0x8f140c
    // 0x8f1404: cmp             x1, x0
    // 0x8f1408: b.eq            #0x8f1418
    // 0x8f140c: r30 = InstantiateTypeArgumentsStub
    //     0x8f140c: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0x8f1410: LoadField: r30 = r30->field_7
    //     0x8f1410: ldur            lr, [lr, #7]
    // 0x8f1414: blr             lr
    // 0x8f1418: mov             x1, x0
    // 0x8f141c: mov             x2, x0
    // 0x8f1420: ldur            x0, [fp, #-0x88]
    // 0x8f1424: stur            x2, [fp, #-0x90]
    // 0x8f1428: r0 = AwaitWithTypeCheck()
    //     0x8f1428: bl              #0x83adf4  ; AwaitWithTypeCheckStub
    // 0x8f142c: stp             x0, NULL, [SP]
    // 0x8f1430: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8f1430: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8f1434: r0 = _buildSuccessResponse()
    //     0x8f1434: bl              #0x8f1494  ; [package:dio/src/compute/compute_io.dart] ::_buildSuccessResponse
    // 0x8f1438: mov             x2, x0
    // 0x8f143c: b               #0x8f1478
    // 0x8f1440: sub             SP, fp, #0xa0
    // 0x8f1444: mov             x3, x0
    // 0x8f1448: stur            x0, [fp, #-0x78]
    // 0x8f144c: mov             x0, x1
    // 0x8f1450: stur            x1, [fp, #-0x88]
    // 0x8f1454: r1 = Null
    //     0x8f1454: mov             x1, NULL
    // 0x8f1458: r2 = 6
    //     0x8f1458: mov             x2, #6
    // 0x8f145c: r0 = AllocateArray()
    //     0x8f145c: bl              #0x13df928  ; AllocateArrayStub
    // 0x8f1460: mov             x1, x0
    // 0x8f1464: ldur            x0, [fp, #-0x78]
    // 0x8f1468: StoreField: r1->field_f = r0
    //     0x8f1468: stur            w0, [x1, #0xf]
    // 0x8f146c: ldur            x0, [fp, #-0x88]
    // 0x8f1470: StoreField: r1->field_13 = r0
    //     0x8f1470: stur            w0, [x1, #0x13]
    // 0x8f1474: mov             x2, x1
    // 0x8f1478: ldur            x0, [fp, #-0x80]
    // 0x8f147c: LoadField: r1 = r0->field_13
    //     0x8f147c: ldur            w1, [x0, #0x13]
    // 0x8f1480: DecompressPointer r1
    //     0x8f1480: add             x1, x1, HEAP, lsl #32
    // 0x8f1484: r0 = exit()
    //     0x8f1484: bl              #0x847c4c  ; [dart:isolate] Isolate::exit
    // 0x8f1488: brk             #0
    // 0x8f148c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f148c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f1490: b               #0x8f13d4
  }
  static _ _buildSuccessResponse(/* No info */) {
    // ** addr: 0x8f1494, size: 0xcc
    // 0x8f1494: EnterFrame
    //     0x8f1494: stp             fp, lr, [SP, #-0x10]!
    //     0x8f1498: mov             fp, SP
    // 0x8f149c: AllocStack(0x10)
    //     0x8f149c: sub             SP, SP, #0x10
    // 0x8f14a0: SetupParameters([dynamic _ /* r1 */])
    //     0x8f14a0: ldur            w0, [x4, #0xf]
    //     0x8f14a4: cbnz            w0, #0x8f14b0
    //     0x8f14a8: mov             x3, NULL
    //     0x8f14ac: b               #0x8f14c0
    //     0x8f14b0: ldur            w0, [x4, #0x17]
    //     0x8f14b4: add             x1, fp, w0, sxtw #2
    //     0x8f14b8: ldr             x1, [x1, #0x10]
    //     0x8f14bc: mov             x3, x1
    //     0x8f14c0: ldr             x0, [fp, #0x10]
    //     0x8f14c4: mov             x1, x3
    //     0x8f14c8: stur            x3, [fp, #-8]
    // 0x8f14cc: r2 = 2
    //     0x8f14cc: mov             x2, #2
    // 0x8f14d0: r0 = AllocateArray()
    //     0x8f14d0: bl              #0x13df928  ; AllocateArrayStub
    // 0x8f14d4: mov             x4, x0
    // 0x8f14d8: ldr             x3, [fp, #0x10]
    // 0x8f14dc: stur            x4, [fp, #-0x10]
    // 0x8f14e0: cmp             w3, NULL
    // 0x8f14e4: b.eq            #0x8f1548
    // 0x8f14e8: mov             x0, x3
    // 0x8f14ec: ldur            x2, [fp, #-8]
    // 0x8f14f0: r1 = Null
    //     0x8f14f0: mov             x1, NULL
    // 0x8f14f4: cmp             w2, NULL
    // 0x8f14f8: b.eq            #0x8f1518
    // 0x8f14fc: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x8f14fc: ldur            w4, [x2, #0x17]
    // 0x8f1500: DecompressPointer r4
    //     0x8f1500: add             x4, x4, HEAP, lsl #32
    // 0x8f1504: r8 = X0
    //     0x8f1504: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x8f1508: LoadField: r9 = r4->field_7
    //     0x8f1508: ldur            x9, [x4, #7]
    // 0x8f150c: r3 = Null
    //     0x8f150c: add             x3, PP, #0x16, lsl #12  ; [pp+0x16218] Null
    //     0x8f1510: ldr             x3, [x3, #0x218]
    // 0x8f1514: blr             x9
    // 0x8f1518: ldr             x1, [fp, #0x10]
    // 0x8f151c: ldur            x0, [fp, #-0x10]
    // 0x8f1520: r2 = 0
    //     0x8f1520: mov             x2, #0
    // 0x8f1524: CheckStackOverflow
    //     0x8f1524: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f1528: cmp             SP, x16
    //     0x8f152c: b.ls            #0x8f1558
    // 0x8f1530: cmp             x2, #1
    // 0x8f1534: b.ge            #0x8f154c
    // 0x8f1538: ArrayStore: r0[r2] = r1  ; Unknown_4
    //     0x8f1538: add             x3, x0, x2, lsl #2
    //     0x8f153c: stur            w1, [x3, #0xf]
    // 0x8f1540: r2 = 1
    //     0x8f1540: mov             x2, #1
    // 0x8f1544: b               #0x8f1524
    // 0x8f1548: mov             x0, x4
    // 0x8f154c: LeaveFrame
    //     0x8f154c: mov             SP, fp
    //     0x8f1550: ldp             fp, lr, [SP], #0x10
    // 0x8f1554: ret
    //     0x8f1554: ret             
    // 0x8f1558: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f1558: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f155c: b               #0x8f1530
  }
  [closure] static Null <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x8f1738, size: 0x98
    // 0x8f1738: EnterFrame
    //     0x8f1738: stp             fp, lr, [SP, #-0x10]!
    //     0x8f173c: mov             fp, SP
    // 0x8f1740: AllocStack(0x10)
    //     0x8f1740: sub             SP, SP, #0x10
    // 0x8f1744: SetupParameters([dynamic _ /* r0 */])
    //     0x8f1744: ldr             x0, [fp, #0x18]
    //     0x8f1748: ldur            w1, [x0, #0x17]
    //     0x8f174c: add             x1, x1, HEAP, lsl #32
    // 0x8f1750: CheckStackOverflow
    //     0x8f1750: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f1754: cmp             SP, x16
    //     0x8f1758: b.ls            #0x8f17c8
    // 0x8f175c: LoadField: r2 = r1->field_2b
    //     0x8f175c: ldur            w2, [x1, #0x2b]
    // 0x8f1760: DecompressPointer r2
    //     0x8f1760: add             x2, x2, HEAP, lsl #32
    // 0x8f1764: stur            x2, [fp, #-8]
    // 0x8f1768: LoadField: r0 = r2->field_b
    //     0x8f1768: ldur            w0, [x2, #0xb]
    // 0x8f176c: DecompressPointer r0
    //     0x8f176c: add             x0, x0, HEAP, lsl #32
    // 0x8f1770: LoadField: r3 = r0->field_b
    //     0x8f1770: ldur            x3, [x0, #0xb]
    // 0x8f1774: tst             x3, #0x1e
    // 0x8f1778: b.eq            #0x8f178c
    // 0x8f177c: r0 = Null
    //     0x8f177c: mov             x0, NULL
    // 0x8f1780: LeaveFrame
    //     0x8f1780: mov             SP, fp
    //     0x8f1784: ldp             fp, lr, [SP], #0x10
    // 0x8f1788: ret
    //     0x8f1788: ret             
    // 0x8f178c: LoadField: r0 = r1->field_27
    //     0x8f178c: ldur            w0, [x1, #0x27]
    // 0x8f1790: DecompressPointer r0
    //     0x8f1790: add             x0, x0, HEAP, lsl #32
    // 0x8f1794: str             x0, [SP]
    // 0x8f1798: ClosureCall
    //     0x8f1798: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x8f179c: ldur            x2, [x0, #0x1f]
    //     0x8f17a0: blr             x2
    // 0x8f17a4: ldr             x16, [fp, #0x10]
    // 0x8f17a8: str             x16, [SP]
    // 0x8f17ac: ldur            x1, [fp, #-8]
    // 0x8f17b0: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x8f17b0: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x8f17b4: r0 = complete()
    //     0x8f17b4: bl              #0x128a5ec  ; [dart:async] _AsyncCompleter::complete
    // 0x8f17b8: r0 = Null
    //     0x8f17b8: mov             x0, NULL
    // 0x8f17bc: LeaveFrame
    //     0x8f17bc: mov             SP, fp
    //     0x8f17c0: ldp             fp, lr, [SP], #0x10
    // 0x8f17c4: ret
    //     0x8f17c4: ret             
    // 0x8f17c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f17c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f17cc: b               #0x8f175c
  }
  [closure] static void completeWithError(dynamic, Object, [StackTrace?]) {
    // ** addr: 0x8f17d0, size: 0xd4
    // 0x8f17d0: EnterFrame
    //     0x8f17d0: stp             fp, lr, [SP, #-0x10]!
    //     0x8f17d4: mov             fp, SP
    // 0x8f17d8: AllocStack(0x20)
    //     0x8f17d8: sub             SP, SP, #0x20
    // 0x8f17dc: SetupParameters(dynamic _ /* r0 */, dynamic _ /* r2, fp-0x18 */, [dynamic _ = Null /* r1, fp-0x10 */])
    //     0x8f17dc: ldur            w0, [x4, #0x13]
    //     0x8f17e0: sub             x1, x0, #4
    //     0x8f17e4: add             x0, fp, w1, sxtw #2
    //     0x8f17e8: ldr             x0, [x0, #0x18]
    //     0x8f17ec: add             x2, fp, w1, sxtw #2
    //     0x8f17f0: ldr             x2, [x2, #0x10]
    //     0x8f17f4: stur            x2, [fp, #-0x18]
    //     0x8f17f8: cmp             w1, #2
    //     0x8f17fc: b.lt            #0x8f1810
    //     0x8f1800: add             x3, fp, w1, sxtw #2
    //     0x8f1804: ldr             x3, [x3, #8]
    //     0x8f1808: mov             x1, x3
    //     0x8f180c: b               #0x8f1814
    //     0x8f1810: mov             x1, NULL
    //     0x8f1814: stur            x1, [fp, #-0x10]
    //     0x8f1818: ldur            w3, [x0, #0x17]
    //     0x8f181c: add             x3, x3, HEAP, lsl #32
    // 0x8f1820: CheckStackOverflow
    //     0x8f1820: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f1824: cmp             SP, x16
    //     0x8f1828: b.ls            #0x8f189c
    // 0x8f182c: LoadField: r4 = r3->field_2b
    //     0x8f182c: ldur            w4, [x3, #0x2b]
    // 0x8f1830: DecompressPointer r4
    //     0x8f1830: add             x4, x4, HEAP, lsl #32
    // 0x8f1834: stur            x4, [fp, #-8]
    // 0x8f1838: LoadField: r0 = r4->field_b
    //     0x8f1838: ldur            w0, [x4, #0xb]
    // 0x8f183c: DecompressPointer r0
    //     0x8f183c: add             x0, x0, HEAP, lsl #32
    // 0x8f1840: LoadField: r5 = r0->field_b
    //     0x8f1840: ldur            x5, [x0, #0xb]
    // 0x8f1844: tst             x5, #0x1e
    // 0x8f1848: b.eq            #0x8f185c
    // 0x8f184c: r0 = Null
    //     0x8f184c: mov             x0, NULL
    // 0x8f1850: LeaveFrame
    //     0x8f1850: mov             SP, fp
    //     0x8f1854: ldp             fp, lr, [SP], #0x10
    // 0x8f1858: ret
    //     0x8f1858: ret             
    // 0x8f185c: LoadField: r0 = r3->field_27
    //     0x8f185c: ldur            w0, [x3, #0x27]
    // 0x8f1860: DecompressPointer r0
    //     0x8f1860: add             x0, x0, HEAP, lsl #32
    // 0x8f1864: str             x0, [SP]
    // 0x8f1868: ClosureCall
    //     0x8f1868: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x8f186c: ldur            x2, [x0, #0x1f]
    //     0x8f1870: blr             x2
    // 0x8f1874: ldur            x16, [fp, #-0x10]
    // 0x8f1878: str             x16, [SP]
    // 0x8f187c: ldur            x1, [fp, #-8]
    // 0x8f1880: ldur            x2, [fp, #-0x18]
    // 0x8f1884: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x8f1884: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x8f1888: r0 = completeError()
    //     0x8f1888: bl              #0x7f6b94  ; [dart:async] _Completer::completeError
    // 0x8f188c: r0 = Null
    //     0x8f188c: mov             x0, NULL
    // 0x8f1890: LeaveFrame
    //     0x8f1890: mov             SP, fp
    //     0x8f1894: ldp             fp, lr, [SP], #0x10
    // 0x8f1898: ret
    //     0x8f1898: ret             
    // 0x8f189c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f189c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f18a0: b               #0x8f182c
  }
  [closure] static void timeEndAndCleanup(dynamic) {
    // ** addr: 0x8f18a4, size: 0x104
    // 0x8f18a4: EnterFrame
    //     0x8f18a4: stp             fp, lr, [SP, #-0x10]!
    //     0x8f18a8: mov             fp, SP
    // 0x8f18ac: AllocStack(0x18)
    //     0x8f18ac: sub             SP, SP, #0x18
    // 0x8f18b0: SetupParameters([dynamic _ /* r0 */])
    //     0x8f18b0: ldr             x0, [fp, #0x10]
    //     0x8f18b4: ldur            w2, [x0, #0x17]
    //     0x8f18b8: add             x2, x2, HEAP, lsl #32
    //     0x8f18bc: stur            x2, [fp, #-8]
    // 0x8f18c0: CheckStackOverflow
    //     0x8f18c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f18c4: cmp             SP, x16
    //     0x8f18c8: b.ls            #0x8f19a0
    // 0x8f18cc: LoadField: r0 = r2->field_23
    //     0x8f18cc: ldur            w0, [x2, #0x23]
    // 0x8f18d0: DecompressPointer r0
    //     0x8f18d0: add             x0, x0, HEAP, lsl #32
    // 0x8f18d4: tbnz            w0, #4, #0x8f18e8
    // 0x8f18d8: r0 = Null
    //     0x8f18d8: mov             x0, NULL
    // 0x8f18dc: LeaveFrame
    //     0x8f18dc: mov             SP, fp
    //     0x8f18e0: ldp             fp, lr, [SP], #0x10
    // 0x8f18e4: ret
    //     0x8f18e4: ret             
    // 0x8f18e8: r0 = true
    //     0x8f18e8: add             x0, NULL, #0x20  ; true
    // 0x8f18ec: StoreField: r2->field_23 = r0
    //     0x8f18ec: stur            w0, [x2, #0x23]
    // 0x8f18f0: LoadField: r1 = r2->field_1f
    //     0x8f18f0: ldur            w1, [x2, #0x1f]
    // 0x8f18f4: DecompressPointer r1
    //     0x8f18f4: add             x1, x1, HEAP, lsl #32
    // 0x8f18f8: cmp             w1, NULL
    // 0x8f18fc: b.ne            #0x8f1908
    // 0x8f1900: mov             x0, x2
    // 0x8f1904: b               #0x8f1910
    // 0x8f1908: r0 = cancel()
    //     0x8f1908: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0x8f190c: ldur            x0, [fp, #-8]
    // 0x8f1910: LoadField: r3 = r0->field_f
    //     0x8f1910: ldur            w3, [x0, #0xf]
    // 0x8f1914: DecompressPointer r3
    //     0x8f1914: add             x3, x3, HEAP, lsl #32
    // 0x8f1918: stur            x3, [fp, #-0x10]
    // 0x8f191c: r1 = Null
    //     0x8f191c: mov             x1, NULL
    // 0x8f1920: r2 = 4
    //     0x8f1920: mov             x2, #4
    // 0x8f1924: r0 = AllocateArray()
    //     0x8f1924: bl              #0x13df928  ; AllocateArrayStub
    // 0x8f1928: mov             x1, x0
    // 0x8f192c: ldur            x0, [fp, #-0x10]
    // 0x8f1930: StoreField: r1->field_f = r0
    //     0x8f1930: stur            w0, [x1, #0xf]
    // 0x8f1934: r16 = ": end"
    //     0x8f1934: add             x16, PP, #0x16, lsl #12  ; [pp+0x16238] ": end"
    //     0x8f1938: ldr             x16, [x16, #0x238]
    // 0x8f193c: StoreField: r1->field_13 = r16
    //     0x8f193c: stur            w16, [x1, #0x13]
    // 0x8f1940: str             x1, [SP]
    // 0x8f1944: r0 = _interpolate()
    //     0x8f1944: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x8f1948: mov             x2, x0
    // 0x8f194c: ldur            x0, [fp, #-8]
    // 0x8f1950: stur            x2, [fp, #-0x10]
    // 0x8f1954: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8f1954: ldur            w1, [x0, #0x17]
    // 0x8f1958: DecompressPointer r1
    //     0x8f1958: add             x1, x1, HEAP, lsl #32
    // 0x8f195c: LoadField: r3 = r1->field_f
    //     0x8f195c: ldur            x3, [x1, #0xf]
    // 0x8f1960: mov             x1, x3
    // 0x8f1964: r0 = end()
    //     0x8f1964: bl              #0x8f19a8  ; [dart:developer] Flow::end
    // 0x8f1968: str             x0, [SP]
    // 0x8f196c: ldur            x1, [fp, #-0x10]
    // 0x8f1970: r4 = const [0, 0x2, 0x1, 0x1, flow, 0x1, null]
    //     0x8f1970: add             x4, PP, #0x16, lsl #12  ; [pp+0x16140] List(7) [0, 0x2, 0x1, 0x1, "flow", 0x1, Null]
    //     0x8f1974: ldr             x4, [x4, #0x140]
    // 0x8f1978: r0 = startSync()
    //     0x8f1978: bl              #0x8f0d18  ; [dart:developer] Timeline::startSync
    // 0x8f197c: ldur            x0, [fp, #-8]
    // 0x8f1980: LoadField: r1 = r0->field_1b
    //     0x8f1980: ldur            w1, [x0, #0x1b]
    // 0x8f1984: DecompressPointer r1
    //     0x8f1984: add             x1, x1, HEAP, lsl #32
    // 0x8f1988: r0 = close()
    //     0x8f1988: bl              #0x7f3cc4  ; [dart:isolate] _RawReceivePort::close
    // 0x8f198c: r0 = finishSync()
    //     0x8f198c: bl              #0x8f0a44  ; [dart:developer] Timeline::finishSync
    // 0x8f1990: r0 = Null
    //     0x8f1990: mov             x0, NULL
    // 0x8f1994: LeaveFrame
    //     0x8f1994: mov             SP, fp
    //     0x8f1998: ldp             fp, lr, [SP], #0x10
    // 0x8f199c: ret
    //     0x8f199c: ret             
    // 0x8f19a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f19a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f19a4: b               #0x8f18cc
  }
}

// class id: 3412, size: 0x24, field offset: 0x8
//   const constructor, 
class _IsolateConfiguration<X0, X1> extends Object {

  _ applyAndTime(/* No info */) {
    // ** addr: 0x8f1560, size: 0xbc
    // 0x8f1560: EnterFrame
    //     0x8f1560: stp             fp, lr, [SP, #-0x10]!
    //     0x8f1564: mov             fp, SP
    // 0x8f1568: AllocStack(0x40)
    //     0x8f1568: sub             SP, SP, #0x40
    // 0x8f156c: SetupParameters(_IsolateConfiguration<X0, X1> this /* r1 => r1, fp-0x8 */)
    //     0x8f156c: stur            x1, [fp, #-8]
    // 0x8f1570: CheckStackOverflow
    //     0x8f1570: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f1574: cmp             SP, x16
    //     0x8f1578: b.ls            #0x8f1614
    // 0x8f157c: r1 = 1
    //     0x8f157c: mov             x1, #1
    // 0x8f1580: r0 = AllocateContext()
    //     0x8f1580: bl              #0x13de838  ; AllocateContextStub
    // 0x8f1584: mov             x2, x0
    // 0x8f1588: ldur            x0, [fp, #-8]
    // 0x8f158c: stur            x2, [fp, #-0x20]
    // 0x8f1590: StoreField: r2->field_f = r0
    //     0x8f1590: stur            w0, [x2, #0xf]
    // 0x8f1594: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x8f1594: ldur            w3, [x0, #0x17]
    // 0x8f1598: DecompressPointer r3
    //     0x8f1598: add             x3, x3, HEAP, lsl #32
    // 0x8f159c: stur            x3, [fp, #-0x18]
    // 0x8f15a0: LoadField: r4 = r0->field_7
    //     0x8f15a0: ldur            w4, [x0, #7]
    // 0x8f15a4: DecompressPointer r4
    //     0x8f15a4: add             x4, x4, HEAP, lsl #32
    // 0x8f15a8: stur            x4, [fp, #-0x10]
    // 0x8f15ac: LoadField: r1 = r0->field_1b
    //     0x8f15ac: ldur            x1, [x0, #0x1b]
    // 0x8f15b0: r0 = step()
    //     0x8f15b0: bl              #0x8f16a4  ; [dart:developer] Flow::step
    // 0x8f15b4: ldur            x2, [fp, #-0x10]
    // 0x8f15b8: r1 = Null
    //     0x8f15b8: mov             x1, NULL
    // 0x8f15bc: r3 = <FutureOr<X1>>
    //     0x8f15bc: add             x3, PP, #0x16, lsl #12  ; [pp+0x16228] TypeArguments: <FutureOr<X1>>
    //     0x8f15c0: ldr             x3, [x3, #0x228]
    // 0x8f15c4: stur            x0, [fp, #-8]
    // 0x8f15c8: r30 = InstantiateTypeArgumentsStub
    //     0x8f15c8: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0x8f15cc: LoadField: r30 = r30->field_7
    //     0x8f15cc: ldur            lr, [lr, #7]
    // 0x8f15d0: blr             lr
    // 0x8f15d4: ldur            x2, [fp, #-0x20]
    // 0x8f15d8: ldur            x3, [fp, #-0x10]
    // 0x8f15dc: r1 = Function '<anonymous closure>':.
    //     0x8f15dc: add             x1, PP, #0x16, lsl #12  ; [pp+0x16230] AnonymousClosure: (0x8f16d4), in [package:dio/src/compute/compute_io.dart] _IsolateConfiguration::applyAndTime (0x8f1560)
    //     0x8f15e0: ldr             x1, [x1, #0x230]
    // 0x8f15e4: stur            x0, [fp, #-0x10]
    // 0x8f15e8: r0 = AllocateClosureTA()
    //     0x8f15e8: bl              #0x13dea48  ; AllocateClosureTAStub
    // 0x8f15ec: ldur            x16, [fp, #-0x10]
    // 0x8f15f0: ldur            lr, [fp, #-0x18]
    // 0x8f15f4: stp             lr, x16, [SP, #0x10]
    // 0x8f15f8: ldur            x16, [fp, #-8]
    // 0x8f15fc: stp             x16, x0, [SP]
    // 0x8f1600: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x8f1600: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x8f1604: r0 = timeSync()
    //     0x8f1604: bl              #0x8f161c  ; [dart:developer] Timeline::timeSync
    // 0x8f1608: LeaveFrame
    //     0x8f1608: mov             SP, fp
    //     0x8f160c: ldp             fp, lr, [SP], #0x10
    // 0x8f1610: ret
    //     0x8f1610: ret             
    // 0x8f1614: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f1614: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f1618: b               #0x8f157c
  }
  [closure] FutureOr<X1> <anonymous closure>(dynamic) {
    // ** addr: 0x8f16d4, size: 0x64
    // 0x8f16d4: EnterFrame
    //     0x8f16d4: stp             fp, lr, [SP, #-0x10]!
    //     0x8f16d8: mov             fp, SP
    // 0x8f16dc: AllocStack(0x10)
    //     0x8f16dc: sub             SP, SP, #0x10
    // 0x8f16e0: SetupParameters([dynamic _ /* r0 */])
    //     0x8f16e0: ldr             x0, [fp, #0x10]
    //     0x8f16e4: ldur            w1, [x0, #0x17]
    //     0x8f16e8: add             x1, x1, HEAP, lsl #32
    // 0x8f16ec: CheckStackOverflow
    //     0x8f16ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f16f0: cmp             SP, x16
    //     0x8f16f4: b.ls            #0x8f1730
    // 0x8f16f8: LoadField: r0 = r1->field_f
    //     0x8f16f8: ldur            w0, [x1, #0xf]
    // 0x8f16fc: DecompressPointer r0
    //     0x8f16fc: add             x0, x0, HEAP, lsl #32
    // 0x8f1700: LoadField: r1 = r0->field_f
    //     0x8f1700: ldur            w1, [x0, #0xf]
    // 0x8f1704: DecompressPointer r1
    //     0x8f1704: add             x1, x1, HEAP, lsl #32
    // 0x8f1708: LoadField: r2 = r0->field_b
    //     0x8f1708: ldur            w2, [x0, #0xb]
    // 0x8f170c: DecompressPointer r2
    //     0x8f170c: add             x2, x2, HEAP, lsl #32
    // 0x8f1710: stp             x1, x2, [SP]
    // 0x8f1714: mov             x0, x2
    // 0x8f1718: ClosureCall
    //     0x8f1718: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x8f171c: ldur            x2, [x0, #0x1f]
    //     0x8f1720: blr             x2
    // 0x8f1724: LeaveFrame
    //     0x8f1724: mov             SP, fp
    //     0x8f1728: ldp             fp, lr, [SP], #0x10
    // 0x8f172c: ret
    //     0x8f172c: ret             
    // 0x8f1730: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f1730: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f1734: b               #0x8f16f8
  }
}
