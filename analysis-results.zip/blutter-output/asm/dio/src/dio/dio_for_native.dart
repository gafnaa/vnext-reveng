// lib: , url: package:dio/src/dio/dio_for_native.dart

// class id: 1048700, size: 0x8
class :: {

  static _ createDio(/* No info */) {
    // ** addr: 0x91cfc8, size: 0x4c
    // 0x91cfc8: EnterFrame
    //     0x91cfc8: stp             fp, lr, [SP, #-0x10]!
    //     0x91cfcc: mov             fp, SP
    // 0x91cfd0: AllocStack(0x8)
    //     0x91cfd0: sub             SP, SP, #8
    // 0x91cfd4: SetupParameters(dynamic _ /* r1 => r2, fp-0x8 */)
    //     0x91cfd4: mov             x2, x1
    //     0x91cfd8: stur            x1, [fp, #-8]
    // 0x91cfdc: CheckStackOverflow
    //     0x91cfdc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91cfe0: cmp             SP, x16
    //     0x91cfe4: b.ls            #0x91d00c
    // 0x91cfe8: r0 = DioForNative()
    //     0x91cfe8: bl              #0x91d27c  ; AllocateDioForNativeStub -> DioForNative (size=0x1c)
    // 0x91cfec: mov             x1, x0
    // 0x91cff0: ldur            x2, [fp, #-8]
    // 0x91cff4: stur            x0, [fp, #-8]
    // 0x91cff8: r0 = DioForNative()
    //     0x91cff8: bl              #0x91d014  ; [package:dio/src/dio/dio_for_native.dart] DioForNative::DioForNative
    // 0x91cffc: ldur            x0, [fp, #-8]
    // 0x91d000: LeaveFrame
    //     0x91d000: mov             SP, fp
    //     0x91d004: ldp             fp, lr, [SP], #0x10
    // 0x91d008: ret
    //     0x91d008: ret             
    // 0x91d00c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91d00c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x91d010: b               #0x91cfe8
  }
}

// class id: 3979, size: 0x1c, field offset: 0x1c
class DioForNative extends _MixinApplication598&Object&DioMixin
    implements Dio {

  _ DioForNative(/* No info */) {
    // ** addr: 0x91d014, size: 0xb4
    // 0x91d014: EnterFrame
    //     0x91d014: stp             fp, lr, [SP, #-0x10]!
    //     0x91d018: mov             fp, SP
    // 0x91d01c: AllocStack(0x18)
    //     0x91d01c: sub             SP, SP, #0x18
    // 0x91d020: SetupParameters(DioForNative this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x91d020: mov             x0, x1
    //     0x91d024: stur            x1, [fp, #-8]
    //     0x91d028: stur            x2, [fp, #-0x10]
    // 0x91d02c: CheckStackOverflow
    //     0x91d02c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91d030: cmp             SP, x16
    //     0x91d034: b.ls            #0x91d0c0
    // 0x91d038: mov             x1, x0
    // 0x91d03c: r0 = _MixinApplication598&Object&DioMixin()
    //     0x91d03c: bl              #0x91d0d4  ; [dart:mixin_deduplication] _MixinApplication598&Object&DioMixin::_MixinApplication598&Object&DioMixin
    // 0x91d040: ldur            x0, [fp, #-0x10]
    // 0x91d044: cmp             w0, NULL
    // 0x91d048: b.ne            #0x91d064
    // 0x91d04c: r0 = BaseOptions()
    //     0x91d04c: bl              #0x91d430  ; AllocateBaseOptionsStub -> BaseOptions (size=0x58)
    // 0x91d050: mov             x1, x0
    // 0x91d054: stur            x0, [fp, #-0x18]
    // 0x91d058: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x91d058: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x91d05c: r0 = BaseOptions()
    //     0x91d05c: bl              #0x91d288  ; [package:dio/src/options.dart] BaseOptions::BaseOptions
    // 0x91d060: ldur            x0, [fp, #-0x18]
    // 0x91d064: ldur            x1, [fp, #-8]
    // 0x91d068: StoreField: r1->field_7 = r0
    //     0x91d068: stur            w0, [x1, #7]
    //     0x91d06c: ldurb           w16, [x1, #-1]
    //     0x91d070: ldurb           w17, [x0, #-1]
    //     0x91d074: and             x16, x17, x16, lsr #2
    //     0x91d078: tst             x16, HEAP, lsr #32
    //     0x91d07c: b.eq            #0x91d084
    //     0x91d080: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x91d084: r0 = IOHttpClientAdapter()
    //     0x91d084: bl              #0x91d0c8  ; AllocateIOHttpClientAdapterStub -> IOHttpClientAdapter (size=0x1c)
    // 0x91d088: r1 = false
    //     0x91d088: add             x1, NULL, #0x30  ; false
    // 0x91d08c: ArrayStore: r0[0] = r1  ; List_4
    //     0x91d08c: stur            w1, [x0, #0x17]
    // 0x91d090: ldur            x1, [fp, #-8]
    // 0x91d094: StoreField: r1->field_f = r0
    //     0x91d094: stur            w0, [x1, #0xf]
    //     0x91d098: ldurb           w16, [x1, #-1]
    //     0x91d09c: ldurb           w17, [x0, #-1]
    //     0x91d0a0: and             x16, x17, x16, lsr #2
    //     0x91d0a4: tst             x16, HEAP, lsr #32
    //     0x91d0a8: b.eq            #0x91d0b0
    //     0x91d0ac: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x91d0b0: r0 = Null
    //     0x91d0b0: mov             x0, NULL
    // 0x91d0b4: LeaveFrame
    //     0x91d0b4: mov             SP, fp
    //     0x91d0b8: ldp             fp, lr, [SP], #0x10
    // 0x91d0bc: ret
    //     0x91d0bc: ret             
    // 0x91d0c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91d0c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x91d0c4: b               #0x91d038
  }
}
