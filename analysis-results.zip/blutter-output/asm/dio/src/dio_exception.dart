// lib: , url: package:dio/src/dio_exception.dart

// class id: 1048701, size: 0x8
class :: {

  [closure] static String defaultDioExceptionReadableStringBuilder(dynamic, DioException) {
    // ** addr: 0x111439c, size: 0x30
    // 0x111439c: EnterFrame
    //     0x111439c: stp             fp, lr, [SP, #-0x10]!
    //     0x11143a0: mov             fp, SP
    // 0x11143a4: CheckStackOverflow
    //     0x11143a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11143a8: cmp             SP, x16
    //     0x11143ac: b.ls            #0x11143c4
    // 0x11143b0: ldr             x1, [fp, #0x10]
    // 0x11143b4: r0 = defaultDioExceptionReadableStringBuilder()
    //     0x11143b4: bl              #0x11143cc  ; [package:dio/src/dio_exception.dart] ::defaultDioExceptionReadableStringBuilder
    // 0x11143b8: LeaveFrame
    //     0x11143b8: mov             SP, fp
    //     0x11143bc: ldp             fp, lr, [SP], #0x10
    // 0x11143c0: ret
    //     0x11143c0: ret             
    // 0x11143c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11143c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11143c8: b               #0x11143b0
  }
  static _ defaultDioExceptionReadableStringBuilder(/* No info */) {
    // ** addr: 0x11143cc, size: 0x1a4
    // 0x11143cc: EnterFrame
    //     0x11143cc: stp             fp, lr, [SP, #-0x10]!
    //     0x11143d0: mov             fp, SP
    // 0x11143d4: AllocStack(0x20)
    //     0x11143d4: sub             SP, SP, #0x20
    // 0x11143d8: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */)
    //     0x11143d8: mov             x0, x1
    //     0x11143dc: stur            x1, [fp, #-8]
    // 0x11143e0: CheckStackOverflow
    //     0x11143e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11143e4: cmp             SP, x16
    //     0x11143e8: b.ls            #0x1114568
    // 0x11143ec: r1 = Null
    //     0x11143ec: mov             x1, NULL
    // 0x11143f0: r2 = 8
    //     0x11143f0: mov             x2, #8
    // 0x11143f4: r0 = AllocateArray()
    //     0x11143f4: bl              #0x13df928  ; AllocateArrayStub
    // 0x11143f8: r16 = "DioException ["
    //     0x11143f8: add             x16, PP, #0x17, lsl #12  ; [pp+0x172e8] "DioException ["
    //     0x11143fc: ldr             x16, [x16, #0x2e8]
    // 0x1114400: StoreField: r0->field_f = r16
    //     0x1114400: stur            w16, [x0, #0xf]
    // 0x1114404: ldur            x1, [fp, #-8]
    // 0x1114408: LoadField: r2 = r1->field_f
    //     0x1114408: ldur            w2, [x1, #0xf]
    // 0x111440c: DecompressPointer r2
    //     0x111440c: add             x2, x2, HEAP, lsl #32
    // 0x1114410: LoadField: r3 = r2->field_7
    //     0x1114410: ldur            x3, [x2, #7]
    // 0x1114414: cmp             x3, #4
    // 0x1114418: b.gt            #0x1114478
    // 0x111441c: cmp             x3, #2
    // 0x1114420: b.gt            #0x1114458
    // 0x1114424: cmp             x3, #1
    // 0x1114428: b.gt            #0x111444c
    // 0x111442c: cmp             x3, #0
    // 0x1114430: b.gt            #0x1114440
    // 0x1114434: r2 = "connection timeout"
    //     0x1114434: add             x2, PP, #0x17, lsl #12  ; [pp+0x172f0] "connection timeout"
    //     0x1114438: ldr             x2, [x2, #0x2f0]
    // 0x111443c: b               #0x11144b8
    // 0x1114440: r2 = "send timeout"
    //     0x1114440: add             x2, PP, #0x17, lsl #12  ; [pp+0x172f8] "send timeout"
    //     0x1114444: ldr             x2, [x2, #0x2f8]
    // 0x1114448: b               #0x11144b8
    // 0x111444c: r2 = "receive timeout"
    //     0x111444c: add             x2, PP, #0x17, lsl #12  ; [pp+0x17300] "receive timeout"
    //     0x1114450: ldr             x2, [x2, #0x300]
    // 0x1114454: b               #0x11144b8
    // 0x1114458: cmp             x3, #3
    // 0x111445c: b.gt            #0x111446c
    // 0x1114460: r2 = "bad certificate"
    //     0x1114460: add             x2, PP, #0x17, lsl #12  ; [pp+0x17308] "bad certificate"
    //     0x1114464: ldr             x2, [x2, #0x308]
    // 0x1114468: b               #0x11144b8
    // 0x111446c: r2 = "bad response"
    //     0x111446c: add             x2, PP, #0x17, lsl #12  ; [pp+0x17310] "bad response"
    //     0x1114470: ldr             x2, [x2, #0x310]
    // 0x1114474: b               #0x11144b8
    // 0x1114478: cmp             x3, #6
    // 0x111447c: b.gt            #0x11144a0
    // 0x1114480: cmp             x3, #5
    // 0x1114484: b.gt            #0x1114494
    // 0x1114488: r2 = "request cancelled"
    //     0x1114488: add             x2, PP, #0x17, lsl #12  ; [pp+0x17318] "request cancelled"
    //     0x111448c: ldr             x2, [x2, #0x318]
    // 0x1114490: b               #0x11144b8
    // 0x1114494: r2 = "connection error"
    //     0x1114494: add             x2, PP, #0x17, lsl #12  ; [pp+0x17320] "connection error"
    //     0x1114498: ldr             x2, [x2, #0x320]
    // 0x111449c: b               #0x11144b8
    // 0x11144a0: cmp             x3, #7
    // 0x11144a4: b.gt            #0x11144b0
    // 0x11144a8: r2 = "unknown"
    //     0x11144a8: ldr             x2, [PP, #0x7ac8]  ; [pp+0x7ac8] "unknown"
    // 0x11144ac: b               #0x11144b8
    // 0x11144b0: r2 = "transform timeout"
    //     0x11144b0: add             x2, PP, #0x17, lsl #12  ; [pp+0x17328] "transform timeout"
    //     0x11144b4: ldr             x2, [x2, #0x328]
    // 0x11144b8: StoreField: r0->field_13 = r2
    //     0x11144b8: stur            w2, [x0, #0x13]
    // 0x11144bc: r16 = "]: "
    //     0x11144bc: ldr             x16, [PP, #0x7da0]  ; [pp+0x7da0] "]: "
    // 0x11144c0: ArrayStore: r0[0] = r16  ; List_4
    //     0x11144c0: stur            w16, [x0, #0x17]
    // 0x11144c4: LoadField: r2 = r1->field_1b
    //     0x11144c4: ldur            w2, [x1, #0x1b]
    // 0x11144c8: DecompressPointer r2
    //     0x11144c8: add             x2, x2, HEAP, lsl #32
    // 0x11144cc: StoreField: r0->field_1b = r2
    //     0x11144cc: stur            w2, [x0, #0x1b]
    // 0x11144d0: str             x0, [SP]
    // 0x11144d4: r0 = _interpolate()
    //     0x11144d4: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11144d8: stur            x0, [fp, #-0x10]
    // 0x11144dc: r0 = StringBuffer()
    //     0x11144dc: bl              #0x7e51d4  ; AllocateStringBufferStub -> StringBuffer (size=0x38)
    // 0x11144e0: stur            x0, [fp, #-0x18]
    // 0x11144e4: ldur            x16, [fp, #-0x10]
    // 0x11144e8: str             x16, [SP]
    // 0x11144ec: mov             x1, x0
    // 0x11144f0: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x11144f0: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x11144f4: r0 = StringBuffer()
    //     0x11144f4: bl              #0x7e4a4c  ; [dart:core] StringBuffer::StringBuffer
    // 0x11144f8: ldur            x0, [fp, #-8]
    // 0x11144fc: LoadField: r2 = r0->field_13
    //     0x11144fc: ldur            w2, [x0, #0x13]
    // 0x1114500: DecompressPointer r2
    //     0x1114500: add             x2, x2, HEAP, lsl #32
    // 0x1114504: stur            x2, [fp, #-0x10]
    // 0x1114508: cmp             w2, NULL
    // 0x111450c: b.eq            #0x1114550
    // 0x1114510: ldur            x1, [fp, #-0x18]
    // 0x1114514: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x1114514: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x1114518: r0 = writeln()
    //     0x1114518: bl              #0x8ef840  ; [dart:core] StringBuffer::writeln
    // 0x111451c: r1 = Null
    //     0x111451c: mov             x1, NULL
    // 0x1114520: r2 = 4
    //     0x1114520: mov             x2, #4
    // 0x1114524: r0 = AllocateArray()
    //     0x1114524: bl              #0x13df928  ; AllocateArrayStub
    // 0x1114528: r16 = "Error: "
    //     0x1114528: add             x16, PP, #0x17, lsl #12  ; [pp+0x17330] "Error: "
    //     0x111452c: ldr             x16, [x16, #0x330]
    // 0x1114530: StoreField: r0->field_f = r16
    //     0x1114530: stur            w16, [x0, #0xf]
    // 0x1114534: ldur            x1, [fp, #-0x10]
    // 0x1114538: StoreField: r0->field_13 = r1
    //     0x1114538: stur            w1, [x0, #0x13]
    // 0x111453c: str             x0, [SP]
    // 0x1114540: r0 = _interpolate()
    //     0x1114540: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x1114544: ldur            x1, [fp, #-0x18]
    // 0x1114548: mov             x2, x0
    // 0x111454c: r0 = write()
    //     0x111454c: bl              #0x7e5154  ; [dart:core] StringBuffer::write
    // 0x1114550: ldur            x16, [fp, #-0x18]
    // 0x1114554: str             x16, [SP]
    // 0x1114558: r0 = toString()
    //     0x1114558: bl              #0x1101d44  ; [dart:core] StringBuffer::toString
    // 0x111455c: LeaveFrame
    //     0x111455c: mov             SP, fp
    //     0x1114560: ldp             fp, lr, [SP], #0x10
    // 0x1114564: ret
    //     0x1114564: ret             
    // 0x1114568: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1114568: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x111456c: b               #0x11143ec
  }
}

// class id: 3410, size: 0x24, field offset: 0x8
class DioException extends Object
    implements Exception {

  static late (dynamic, DioException) => String readableStringBuilder; // offset: 0x980

  _ DioException(/* No info */) {
    // ** addr: 0x8e97ec, size: 0x2f8
    // 0x8e97ec: EnterFrame
    //     0x8e97ec: stp             fp, lr, [SP, #-0x10]!
    //     0x8e97f0: mov             fp, SP
    // 0x8e97f4: AllocStack(0x8)
    //     0x8e97f4: sub             SP, SP, #8
    // 0x8e97f8: SetupParameters(DioException this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1 */)
    //     0x8e97f8: stur            x1, [fp, #-8]
    //     0x8e97fc: mov             x16, x2
    //     0x8e9800: mov             x2, x1
    //     0x8e9804: mov             x1, x16
    // 0x8e9808: LoadField: r0 = r4->field_13
    //     0x8e9808: ldur            w0, [x4, #0x13]
    // 0x8e980c: LoadField: r3 = r4->field_1f
    //     0x8e980c: ldur            w3, [x4, #0x1f]
    // 0x8e9810: DecompressPointer r3
    //     0x8e9810: add             x3, x3, HEAP, lsl #32
    // 0x8e9814: r16 = "error"
    //     0x8e9814: ldr             x16, [PP, #0x1c30]  ; [pp+0x1c30] "error"
    // 0x8e9818: cmp             w3, w16
    // 0x8e981c: b.ne            #0x8e9840
    // 0x8e9820: LoadField: r3 = r4->field_23
    //     0x8e9820: ldur            w3, [x4, #0x23]
    // 0x8e9824: DecompressPointer r3
    //     0x8e9824: add             x3, x3, HEAP, lsl #32
    // 0x8e9828: sub             w5, w0, w3
    // 0x8e982c: add             x3, fp, w5, sxtw #2
    // 0x8e9830: ldr             x3, [x3, #8]
    // 0x8e9834: mov             x5, x3
    // 0x8e9838: r3 = 1
    //     0x8e9838: mov             x3, #1
    // 0x8e983c: b               #0x8e9848
    // 0x8e9840: r5 = Null
    //     0x8e9840: mov             x5, NULL
    // 0x8e9844: r3 = 0
    //     0x8e9844: mov             x3, #0
    // 0x8e9848: lsl             x6, x3, #1
    // 0x8e984c: lsl             w7, w6, #1
    // 0x8e9850: add             w8, w7, #8
    // 0x8e9854: ArrayLoad: r9 = r4[r8]  ; Unknown_4
    //     0x8e9854: add             x16, x4, w8, sxtw #1
    //     0x8e9858: ldur            w9, [x16, #0xf]
    // 0x8e985c: DecompressPointer r9
    //     0x8e985c: add             x9, x9, HEAP, lsl #32
    // 0x8e9860: r16 = "message"
    //     0x8e9860: ldr             x16, [PP, #0x62a0]  ; [pp+0x62a0] "message"
    // 0x8e9864: cmp             w9, w16
    // 0x8e9868: b.ne            #0x8e989c
    // 0x8e986c: add             w3, w7, #0xa
    // 0x8e9870: ArrayLoad: r7 = r4[r3]  ; Unknown_4
    //     0x8e9870: add             x16, x4, w3, sxtw #1
    //     0x8e9874: ldur            w7, [x16, #0xf]
    // 0x8e9878: DecompressPointer r7
    //     0x8e9878: add             x7, x7, HEAP, lsl #32
    // 0x8e987c: sub             w3, w0, w7
    // 0x8e9880: add             x7, fp, w3, sxtw #2
    // 0x8e9884: ldr             x7, [x7, #8]
    // 0x8e9888: add             w3, w6, #2
    // 0x8e988c: r6 = LoadInt32Instr(r3)
    //     0x8e988c: sbfx            x6, x3, #1, #0x1f
    // 0x8e9890: mov             x3, x6
    // 0x8e9894: mov             x6, x7
    // 0x8e9898: b               #0x8e98a0
    // 0x8e989c: r6 = Null
    //     0x8e989c: mov             x6, NULL
    // 0x8e98a0: lsl             x7, x3, #1
    // 0x8e98a4: lsl             w8, w7, #1
    // 0x8e98a8: add             w9, w8, #8
    // 0x8e98ac: ArrayLoad: r10 = r4[r9]  ; Unknown_4
    //     0x8e98ac: add             x16, x4, w9, sxtw #1
    //     0x8e98b0: ldur            w10, [x16, #0xf]
    // 0x8e98b4: DecompressPointer r10
    //     0x8e98b4: add             x10, x10, HEAP, lsl #32
    // 0x8e98b8: r16 = "response"
    //     0x8e98b8: ldr             x16, [PP, #0x3130]  ; [pp+0x3130] "response"
    // 0x8e98bc: cmp             w10, w16
    // 0x8e98c0: b.ne            #0x8e98f4
    // 0x8e98c4: add             w3, w8, #0xa
    // 0x8e98c8: ArrayLoad: r8 = r4[r3]  ; Unknown_4
    //     0x8e98c8: add             x16, x4, w3, sxtw #1
    //     0x8e98cc: ldur            w8, [x16, #0xf]
    // 0x8e98d0: DecompressPointer r8
    //     0x8e98d0: add             x8, x8, HEAP, lsl #32
    // 0x8e98d4: sub             w3, w0, w8
    // 0x8e98d8: add             x8, fp, w3, sxtw #2
    // 0x8e98dc: ldr             x8, [x8, #8]
    // 0x8e98e0: add             w3, w7, #2
    // 0x8e98e4: r7 = LoadInt32Instr(r3)
    //     0x8e98e4: sbfx            x7, x3, #1, #0x1f
    // 0x8e98e8: mov             x3, x7
    // 0x8e98ec: mov             x7, x8
    // 0x8e98f0: b               #0x8e98f8
    // 0x8e98f4: r7 = Null
    //     0x8e98f4: mov             x7, NULL
    // 0x8e98f8: lsl             x8, x3, #1
    // 0x8e98fc: lsl             w9, w8, #1
    // 0x8e9900: add             w10, w9, #8
    // 0x8e9904: ArrayLoad: r11 = r4[r10]  ; Unknown_4
    //     0x8e9904: add             x16, x4, w10, sxtw #1
    //     0x8e9908: ldur            w11, [x16, #0xf]
    // 0x8e990c: DecompressPointer r11
    //     0x8e990c: add             x11, x11, HEAP, lsl #32
    // 0x8e9910: r16 = "stackTrace"
    //     0x8e9910: add             x16, PP, #0x15, lsl #12  ; [pp+0x15cf8] "stackTrace"
    //     0x8e9914: ldr             x16, [x16, #0xcf8]
    // 0x8e9918: cmp             w11, w16
    // 0x8e991c: b.ne            #0x8e9950
    // 0x8e9920: add             w3, w9, #0xa
    // 0x8e9924: ArrayLoad: r9 = r4[r3]  ; Unknown_4
    //     0x8e9924: add             x16, x4, w3, sxtw #1
    //     0x8e9928: ldur            w9, [x16, #0xf]
    // 0x8e992c: DecompressPointer r9
    //     0x8e992c: add             x9, x9, HEAP, lsl #32
    // 0x8e9930: sub             w3, w0, w9
    // 0x8e9934: add             x9, fp, w3, sxtw #2
    // 0x8e9938: ldr             x9, [x9, #8]
    // 0x8e993c: add             w3, w8, #2
    // 0x8e9940: r8 = LoadInt32Instr(r3)
    //     0x8e9940: sbfx            x8, x3, #1, #0x1f
    // 0x8e9944: mov             x3, x8
    // 0x8e9948: mov             x8, x9
    // 0x8e994c: b               #0x8e9954
    // 0x8e9950: r8 = Null
    //     0x8e9950: mov             x8, NULL
    // 0x8e9954: lsl             x9, x3, #1
    // 0x8e9958: lsl             w3, w9, #1
    // 0x8e995c: add             w9, w3, #8
    // 0x8e9960: ArrayLoad: r10 = r4[r9]  ; Unknown_4
    //     0x8e9960: add             x16, x4, w9, sxtw #1
    //     0x8e9964: ldur            w10, [x16, #0xf]
    // 0x8e9968: DecompressPointer r10
    //     0x8e9968: add             x10, x10, HEAP, lsl #32
    // 0x8e996c: r16 = "type"
    //     0x8e996c: ldr             x16, [PP, #0x3250]  ; [pp+0x3250] "type"
    // 0x8e9970: cmp             w10, w16
    // 0x8e9974: b.ne            #0x8e999c
    // 0x8e9978: add             w9, w3, #0xa
    // 0x8e997c: ArrayLoad: r3 = r4[r9]  ; Unknown_4
    //     0x8e997c: add             x16, x4, w9, sxtw #1
    //     0x8e9980: ldur            w3, [x16, #0xf]
    // 0x8e9984: DecompressPointer r3
    //     0x8e9984: add             x3, x3, HEAP, lsl #32
    // 0x8e9988: sub             w4, w0, w3
    // 0x8e998c: add             x0, fp, w4, sxtw #2
    // 0x8e9990: ldr             x0, [x0, #8]
    // 0x8e9994: mov             x3, x0
    // 0x8e9998: b               #0x8e99a4
    // 0x8e999c: r3 = Instance_DioExceptionType
    //     0x8e999c: add             x3, PP, #0x15, lsl #12  ; [pp+0x15ce0] Obj!DioExceptionType@12c64e1
    //     0x8e99a0: ldr             x3, [x3, #0xce0]
    // 0x8e99a4: CheckStackOverflow
    //     0x8e99a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8e99a8: cmp             SP, x16
    //     0x8e99ac: b.ls            #0x8e9adc
    // 0x8e99b0: mov             x0, x1
    // 0x8e99b4: StoreField: r2->field_7 = r0
    //     0x8e99b4: stur            w0, [x2, #7]
    //     0x8e99b8: ldurb           w16, [x2, #-1]
    //     0x8e99bc: ldurb           w17, [x0, #-1]
    //     0x8e99c0: and             x16, x17, x16, lsr #2
    //     0x8e99c4: tst             x16, HEAP, lsr #32
    //     0x8e99c8: b.eq            #0x8e99d0
    //     0x8e99cc: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x8e99d0: mov             x0, x7
    // 0x8e99d4: StoreField: r2->field_b = r0
    //     0x8e99d4: stur            w0, [x2, #0xb]
    //     0x8e99d8: ldurb           w16, [x2, #-1]
    //     0x8e99dc: ldurb           w17, [x0, #-1]
    //     0x8e99e0: and             x16, x17, x16, lsr #2
    //     0x8e99e4: tst             x16, HEAP, lsr #32
    //     0x8e99e8: b.eq            #0x8e99f0
    //     0x8e99ec: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x8e99f0: mov             x0, x3
    // 0x8e99f4: StoreField: r2->field_f = r0
    //     0x8e99f4: stur            w0, [x2, #0xf]
    //     0x8e99f8: ldurb           w16, [x2, #-1]
    //     0x8e99fc: ldurb           w17, [x0, #-1]
    //     0x8e9a00: and             x16, x17, x16, lsr #2
    //     0x8e9a04: tst             x16, HEAP, lsr #32
    //     0x8e9a08: b.eq            #0x8e9a10
    //     0x8e9a0c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x8e9a10: mov             x0, x5
    // 0x8e9a14: StoreField: r2->field_13 = r0
    //     0x8e9a14: stur            w0, [x2, #0x13]
    //     0x8e9a18: tbz             w0, #0, #0x8e9a34
    //     0x8e9a1c: ldurb           w16, [x2, #-1]
    //     0x8e9a20: ldurb           w17, [x0, #-1]
    //     0x8e9a24: and             x16, x17, x16, lsr #2
    //     0x8e9a28: tst             x16, HEAP, lsr #32
    //     0x8e9a2c: b.eq            #0x8e9a34
    //     0x8e9a30: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x8e9a34: mov             x0, x6
    // 0x8e9a38: StoreField: r2->field_1b = r0
    //     0x8e9a38: stur            w0, [x2, #0x1b]
    //     0x8e9a3c: ldurb           w16, [x2, #-1]
    //     0x8e9a40: ldurb           w17, [x0, #-1]
    //     0x8e9a44: and             x16, x17, x16, lsr #2
    //     0x8e9a48: tst             x16, HEAP, lsr #32
    //     0x8e9a4c: b.eq            #0x8e9a54
    //     0x8e9a50: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x8e9a54: r16 = Instance__StringStackTrace
    //     0x8e9a54: ldr             x16, [PP, #0x1618]  ; [pp+0x1618] Obj!_StringStackTrace@12b8231
    // 0x8e9a58: cmp             w8, w16
    // 0x8e9a5c: b.ne            #0x8e9a78
    // 0x8e9a60: LoadField: r0 = r1->field_57
    //     0x8e9a60: ldur            w0, [x1, #0x57]
    // 0x8e9a64: DecompressPointer r0
    //     0x8e9a64: add             x0, x0, HEAP, lsl #32
    // 0x8e9a68: cmp             w0, NULL
    // 0x8e9a6c: b.ne            #0x8e9aac
    // 0x8e9a70: r0 = current()
    //     0x8e9a70: bl              #0x7f0e88  ; [dart:core] StackTrace::current
    // 0x8e9a74: b               #0x8e9aac
    // 0x8e9a78: cmp             w8, NULL
    // 0x8e9a7c: b.ne            #0x8e9a8c
    // 0x8e9a80: LoadField: r0 = r1->field_57
    //     0x8e9a80: ldur            w0, [x1, #0x57]
    // 0x8e9a84: DecompressPointer r0
    //     0x8e9a84: add             x0, x0, HEAP, lsl #32
    // 0x8e9a88: b               #0x8e9a90
    // 0x8e9a8c: mov             x0, x8
    // 0x8e9a90: cmp             w0, NULL
    // 0x8e9a94: b.ne            #0x8e9aa4
    // 0x8e9a98: r0 = current()
    //     0x8e9a98: bl              #0x7f0e88  ; [dart:core] StackTrace::current
    // 0x8e9a9c: mov             x1, x0
    // 0x8e9aa0: b               #0x8e9aa8
    // 0x8e9aa4: mov             x1, x0
    // 0x8e9aa8: mov             x0, x1
    // 0x8e9aac: ldur            x1, [fp, #-8]
    // 0x8e9ab0: ArrayStore: r1[0] = r0  ; List_4
    //     0x8e9ab0: stur            w0, [x1, #0x17]
    //     0x8e9ab4: ldurb           w16, [x1, #-1]
    //     0x8e9ab8: ldurb           w17, [x0, #-1]
    //     0x8e9abc: and             x16, x17, x16, lsr #2
    //     0x8e9ac0: tst             x16, HEAP, lsr #32
    //     0x8e9ac4: b.eq            #0x8e9acc
    //     0x8e9ac8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8e9acc: r0 = Null
    //     0x8e9acc: mov             x0, NULL
    // 0x8e9ad0: LeaveFrame
    //     0x8e9ad0: mov             SP, fp
    //     0x8e9ad4: ldp             fp, lr, [SP], #0x10
    // 0x8e9ad8: ret
    //     0x8e9ad8: ret             
    // 0x8e9adc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8e9adc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8e9ae0: b               #0x8e99b0
  }
  factory _ DioException.badResponse(/* No info */) {
    // ** addr: 0x8ef5f4, size: 0x7c
    // 0x8ef5f4: EnterFrame
    //     0x8ef5f4: stp             fp, lr, [SP, #-0x10]!
    //     0x8ef5f8: mov             fp, SP
    // 0x8ef5fc: AllocStack(0x40)
    //     0x8ef5fc: sub             SP, SP, #0x40
    // 0x8ef600: SetupParameters(dynamic _ /* r1 => r0 */, dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */, dynamic _ /* r5 => r1 */)
    //     0x8ef600: mov             x0, x1
    //     0x8ef604: mov             x1, x5
    //     0x8ef608: stur            x2, [fp, #-8]
    //     0x8ef60c: stur            x3, [fp, #-0x10]
    // 0x8ef610: CheckStackOverflow
    //     0x8ef610: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ef614: cmp             SP, x16
    //     0x8ef618: b.ls            #0x8ef668
    // 0x8ef61c: r0 = _badResponseExceptionMessage()
    //     0x8ef61c: bl              #0x8ef670  ; [package:dio/src/dio_exception.dart] DioException::_badResponseExceptionMessage
    // 0x8ef620: stur            x0, [fp, #-0x18]
    // 0x8ef624: r0 = DioException()
    //     0x8ef624: bl              #0x8ea014  ; AllocateDioExceptionStub -> DioException (size=0x24)
    // 0x8ef628: stur            x0, [fp, #-0x20]
    // 0x8ef62c: r16 = Instance_DioExceptionType
    //     0x8ef62c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15cc8] Obj!DioExceptionType@12c6521
    //     0x8ef630: ldr             x16, [x16, #0xcc8]
    // 0x8ef634: ldur            lr, [fp, #-0x10]
    // 0x8ef638: stp             lr, x16, [SP, #0x10]
    // 0x8ef63c: ldur            x16, [fp, #-0x18]
    // 0x8ef640: stp             x16, NULL, [SP]
    // 0x8ef644: mov             x1, x0
    // 0x8ef648: ldur            x2, [fp, #-8]
    // 0x8ef64c: r4 = const [0, 0x6, 0x4, 0x2, error, 0x4, message, 0x5, response, 0x3, type, 0x2, null]
    //     0x8ef64c: add             x4, PP, #0x16, lsl #12  ; [pp+0x16088] List(13) [0, 0x6, 0x4, 0x2, "error", 0x4, "message", 0x5, "response", 0x3, "type", 0x2, Null]
    //     0x8ef650: ldr             x4, [x4, #0x88]
    // 0x8ef654: r0 = DioException()
    //     0x8ef654: bl              #0x8e97ec  ; [package:dio/src/dio_exception.dart] DioException::DioException
    // 0x8ef658: ldur            x0, [fp, #-0x20]
    // 0x8ef65c: LeaveFrame
    //     0x8ef65c: mov             SP, fp
    //     0x8ef660: ldp             fp, lr, [SP], #0x10
    // 0x8ef664: ret
    //     0x8ef664: ret             
    // 0x8ef668: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ef668: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ef66c: b               #0x8ef61c
  }
  static String _badResponseExceptionMessage(int) {
    // ** addr: 0x8ef670, size: 0x1d0
    // 0x8ef670: EnterFrame
    //     0x8ef670: stp             fp, lr, [SP, #-0x10]!
    //     0x8ef674: mov             fp, SP
    // 0x8ef678: AllocStack(0x28)
    //     0x8ef678: sub             SP, SP, #0x28
    // 0x8ef67c: SetupParameters(dynamic _ /* r1 => r1, fp-0x10 */)
    //     0x8ef67c: stur            x1, [fp, #-0x10]
    // 0x8ef680: CheckStackOverflow
    //     0x8ef680: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ef684: cmp             SP, x16
    //     0x8ef688: b.ls            #0x8ef838
    // 0x8ef68c: cmp             x1, #0x64
    // 0x8ef690: b.lt            #0x8ef6a8
    // 0x8ef694: cmp             x1, #0xc8
    // 0x8ef698: b.ge            #0x8ef6a8
    // 0x8ef69c: r0 = "This is an informational response - the request was received, continuing processing"
    //     0x8ef69c: add             x0, PP, #0x16, lsl #12  ; [pp+0x16090] "This is an informational response - the request was received, continuing processing"
    //     0x8ef6a0: ldr             x0, [x0, #0x90]
    // 0x8ef6a4: b               #0x8ef720
    // 0x8ef6a8: cmp             x1, #0xc8
    // 0x8ef6ac: b.lt            #0x8ef6c4
    // 0x8ef6b0: cmp             x1, #0x12c
    // 0x8ef6b4: b.ge            #0x8ef6c4
    // 0x8ef6b8: r0 = "The request was successfully received, understood, and accepted"
    //     0x8ef6b8: add             x0, PP, #0x16, lsl #12  ; [pp+0x16098] "The request was successfully received, understood, and accepted"
    //     0x8ef6bc: ldr             x0, [x0, #0x98]
    // 0x8ef6c0: b               #0x8ef720
    // 0x8ef6c4: cmp             x1, #0x12c
    // 0x8ef6c8: b.lt            #0x8ef6e0
    // 0x8ef6cc: cmp             x1, #0x190
    // 0x8ef6d0: b.ge            #0x8ef6e0
    // 0x8ef6d4: r0 = "Redirection: further action needs to be taken in order to complete the request"
    //     0x8ef6d4: add             x0, PP, #0x16, lsl #12  ; [pp+0x160a0] "Redirection: further action needs to be taken in order to complete the request"
    //     0x8ef6d8: ldr             x0, [x0, #0xa0]
    // 0x8ef6dc: b               #0x8ef720
    // 0x8ef6e0: cmp             x1, #0x190
    // 0x8ef6e4: b.lt            #0x8ef6fc
    // 0x8ef6e8: cmp             x1, #0x1f4
    // 0x8ef6ec: b.ge            #0x8ef6fc
    // 0x8ef6f0: r0 = "Client error - the request contains bad syntax or cannot be fulfilled"
    //     0x8ef6f0: add             x0, PP, #0x16, lsl #12  ; [pp+0x160a8] "Client error - the request contains bad syntax or cannot be fulfilled"
    //     0x8ef6f4: ldr             x0, [x0, #0xa8]
    // 0x8ef6f8: b               #0x8ef720
    // 0x8ef6fc: cmp             x1, #0x1f4
    // 0x8ef700: b.lt            #0x8ef718
    // 0x8ef704: cmp             x1, #0x258
    // 0x8ef708: b.ge            #0x8ef718
    // 0x8ef70c: r0 = "Server error - the server failed to fulfil an apparently valid request"
    //     0x8ef70c: add             x0, PP, #0x16, lsl #12  ; [pp+0x160b0] "Server error - the server failed to fulfil an apparently valid request"
    //     0x8ef710: ldr             x0, [x0, #0xb0]
    // 0x8ef714: b               #0x8ef720
    // 0x8ef718: r0 = "A response with a status code that is not within the range of inclusive 100 to exclusive 600is a non-standard response, possibly due to the server\'s software"
    //     0x8ef718: add             x0, PP, #0x16, lsl #12  ; [pp+0x160b8] "A response with a status code that is not within the range of inclusive 100 to exclusive 600is a non-standard response, possibly due to the server\'s software"
    //     0x8ef71c: ldr             x0, [x0, #0xb8]
    // 0x8ef720: stur            x0, [fp, #-8]
    // 0x8ef724: r0 = StringBuffer()
    //     0x8ef724: bl              #0x7e51d4  ; AllocateStringBufferStub -> StringBuffer (size=0x38)
    // 0x8ef728: mov             x1, x0
    // 0x8ef72c: stur            x0, [fp, #-0x18]
    // 0x8ef730: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8ef730: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8ef734: r0 = StringBuffer()
    //     0x8ef734: bl              #0x7e4a4c  ; [dart:core] StringBuffer::StringBuffer
    // 0x8ef738: r1 = Null
    //     0x8ef738: mov             x1, NULL
    // 0x8ef73c: r2 = 6
    //     0x8ef73c: mov             x2, #6
    // 0x8ef740: r0 = AllocateArray()
    //     0x8ef740: bl              #0x13df928  ; AllocateArrayStub
    // 0x8ef744: mov             x2, x0
    // 0x8ef748: r16 = "This exception was thrown because the response has a status code of "
    //     0x8ef748: add             x16, PP, #0x16, lsl #12  ; [pp+0x160c0] "This exception was thrown because the response has a status code of "
    //     0x8ef74c: ldr             x16, [x16, #0xc0]
    // 0x8ef750: StoreField: r2->field_f = r16
    //     0x8ef750: stur            w16, [x2, #0xf]
    // 0x8ef754: ldur            x3, [fp, #-0x10]
    // 0x8ef758: r0 = BoxInt64Instr(r3)
    //     0x8ef758: sbfiz           x0, x3, #1, #0x1f
    //     0x8ef75c: cmp             x3, x0, asr #1
    //     0x8ef760: b.eq            #0x8ef76c
    //     0x8ef764: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8ef768: stur            x3, [x0, #7]
    // 0x8ef76c: stur            x0, [fp, #-0x20]
    // 0x8ef770: StoreField: r2->field_13 = r0
    //     0x8ef770: stur            w0, [x2, #0x13]
    // 0x8ef774: r16 = " and RequestOptions.validateStatus was configured to throw for this status code."
    //     0x8ef774: add             x16, PP, #0x16, lsl #12  ; [pp+0x160c8] " and RequestOptions.validateStatus was configured to throw for this status code."
    //     0x8ef778: ldr             x16, [x16, #0xc8]
    // 0x8ef77c: ArrayStore: r2[0] = r16  ; List_4
    //     0x8ef77c: stur            w16, [x2, #0x17]
    // 0x8ef780: str             x2, [SP]
    // 0x8ef784: r0 = _interpolate()
    //     0x8ef784: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x8ef788: str             x0, [SP]
    // 0x8ef78c: ldur            x1, [fp, #-0x18]
    // 0x8ef790: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x8ef790: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x8ef794: r0 = writeln()
    //     0x8ef794: bl              #0x8ef840  ; [dart:core] StringBuffer::writeln
    // 0x8ef798: r1 = Null
    //     0x8ef798: mov             x1, NULL
    // 0x8ef79c: r2 = 10
    //     0x8ef79c: mov             x2, #0xa
    // 0x8ef7a0: r0 = AllocateArray()
    //     0x8ef7a0: bl              #0x13df928  ; AllocateArrayStub
    // 0x8ef7a4: r16 = "The status code of "
    //     0x8ef7a4: add             x16, PP, #0x16, lsl #12  ; [pp+0x160d0] "The status code of "
    //     0x8ef7a8: ldr             x16, [x16, #0xd0]
    // 0x8ef7ac: StoreField: r0->field_f = r16
    //     0x8ef7ac: stur            w16, [x0, #0xf]
    // 0x8ef7b0: ldur            x1, [fp, #-0x20]
    // 0x8ef7b4: StoreField: r0->field_13 = r1
    //     0x8ef7b4: stur            w1, [x0, #0x13]
    // 0x8ef7b8: r16 = " has the following meaning: \""
    //     0x8ef7b8: add             x16, PP, #0x16, lsl #12  ; [pp+0x160d8] " has the following meaning: \""
    //     0x8ef7bc: ldr             x16, [x16, #0xd8]
    // 0x8ef7c0: ArrayStore: r0[0] = r16  ; List_4
    //     0x8ef7c0: stur            w16, [x0, #0x17]
    // 0x8ef7c4: ldur            x1, [fp, #-8]
    // 0x8ef7c8: StoreField: r0->field_1b = r1
    //     0x8ef7c8: stur            w1, [x0, #0x1b]
    // 0x8ef7cc: r16 = "\""
    //     0x8ef7cc: add             x16, PP, #8, lsl #12  ; [pp+0x84a0] "\""
    //     0x8ef7d0: ldr             x16, [x16, #0x4a0]
    // 0x8ef7d4: StoreField: r0->field_1f = r16
    //     0x8ef7d4: stur            w16, [x0, #0x1f]
    // 0x8ef7d8: str             x0, [SP]
    // 0x8ef7dc: r0 = _interpolate()
    //     0x8ef7dc: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x8ef7e0: str             x0, [SP]
    // 0x8ef7e4: ldur            x1, [fp, #-0x18]
    // 0x8ef7e8: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x8ef7e8: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x8ef7ec: r0 = writeln()
    //     0x8ef7ec: bl              #0x8ef840  ; [dart:core] StringBuffer::writeln
    // 0x8ef7f0: r16 = "Read more about status codes at https://developer.mozilla.org/en-US/docs/Web/HTTP/Status"
    //     0x8ef7f0: add             x16, PP, #0x16, lsl #12  ; [pp+0x160e0] "Read more about status codes at https://developer.mozilla.org/en-US/docs/Web/HTTP/Status"
    //     0x8ef7f4: ldr             x16, [x16, #0xe0]
    // 0x8ef7f8: str             x16, [SP]
    // 0x8ef7fc: ldur            x1, [fp, #-0x18]
    // 0x8ef800: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x8ef800: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x8ef804: r0 = writeln()
    //     0x8ef804: bl              #0x8ef840  ; [dart:core] StringBuffer::writeln
    // 0x8ef808: r16 = "In order to resolve this exception you typically have either to verify and fix your request code or you have to fix the server code."
    //     0x8ef808: add             x16, PP, #0x16, lsl #12  ; [pp+0x160e8] "In order to resolve this exception you typically have either to verify and fix your request code or you have to fix the server code."
    //     0x8ef80c: ldr             x16, [x16, #0xe8]
    // 0x8ef810: str             x16, [SP]
    // 0x8ef814: ldur            x1, [fp, #-0x18]
    // 0x8ef818: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x8ef818: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x8ef81c: r0 = writeln()
    //     0x8ef81c: bl              #0x8ef840  ; [dart:core] StringBuffer::writeln
    // 0x8ef820: ldur            x16, [fp, #-0x18]
    // 0x8ef824: str             x16, [SP]
    // 0x8ef828: r0 = toString()
    //     0x8ef828: bl              #0x1101d44  ; [dart:core] StringBuffer::toString
    // 0x8ef82c: LeaveFrame
    //     0x8ef82c: mov             SP, fp
    //     0x8ef830: ldp             fp, lr, [SP], #0x10
    // 0x8ef834: ret
    //     0x8ef834: ret             
    // 0x8ef838: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ef838: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ef83c: b               #0x8ef68c
  }
  factory _ DioException.receiveTimeout(/* No info */) {
    // ** addr: 0x8f4f74, size: 0xb4
    // 0x8f4f74: EnterFrame
    //     0x8f4f74: stp             fp, lr, [SP, #-0x10]!
    //     0x8f4f78: mov             fp, SP
    // 0x8f4f7c: AllocStack(0x38)
    //     0x8f4f7c: sub             SP, SP, #0x38
    // 0x8f4f80: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0x8f4f80: mov             x0, x2
    //     0x8f4f84: stur            x2, [fp, #-8]
    //     0x8f4f88: stur            x3, [fp, #-0x10]
    // 0x8f4f8c: CheckStackOverflow
    //     0x8f4f8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f4f90: cmp             SP, x16
    //     0x8f4f94: b.ls            #0x8f5020
    // 0x8f4f98: r1 = Null
    //     0x8f4f98: mov             x1, NULL
    // 0x8f4f9c: r2 = 10
    //     0x8f4f9c: mov             x2, #0xa
    // 0x8f4fa0: r0 = AllocateArray()
    //     0x8f4fa0: bl              #0x13df928  ; AllocateArrayStub
    // 0x8f4fa4: r16 = "The request took longer than "
    //     0x8f4fa4: add             x16, PP, #0x16, lsl #12  ; [pp+0x163e0] "The request took longer than "
    //     0x8f4fa8: ldr             x16, [x16, #0x3e0]
    // 0x8f4fac: StoreField: r0->field_f = r16
    //     0x8f4fac: stur            w16, [x0, #0xf]
    // 0x8f4fb0: ldur            x1, [fp, #-0x10]
    // 0x8f4fb4: StoreField: r0->field_13 = r1
    //     0x8f4fb4: stur            w1, [x0, #0x13]
    // 0x8f4fb8: r16 = " to receive data. It was aborted. To get rid of this exception, try raising the RequestOptions.receiveTimeout above the duration of "
    //     0x8f4fb8: add             x16, PP, #0x16, lsl #12  ; [pp+0x163e8] " to receive data. It was aborted. To get rid of this exception, try raising the RequestOptions.receiveTimeout above the duration of "
    //     0x8f4fbc: ldr             x16, [x16, #0x3e8]
    // 0x8f4fc0: ArrayStore: r0[0] = r16  ; List_4
    //     0x8f4fc0: stur            w16, [x0, #0x17]
    // 0x8f4fc4: StoreField: r0->field_1b = r1
    //     0x8f4fc4: stur            w1, [x0, #0x1b]
    // 0x8f4fc8: r16 = " or improve the response time of the server."
    //     0x8f4fc8: add             x16, PP, #0x16, lsl #12  ; [pp+0x163f0] " or improve the response time of the server."
    //     0x8f4fcc: ldr             x16, [x16, #0x3f0]
    // 0x8f4fd0: StoreField: r0->field_1f = r16
    //     0x8f4fd0: stur            w16, [x0, #0x1f]
    // 0x8f4fd4: str             x0, [SP]
    // 0x8f4fd8: r0 = _interpolate()
    //     0x8f4fd8: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x8f4fdc: stur            x0, [fp, #-0x10]
    // 0x8f4fe0: r0 = DioException()
    //     0x8f4fe0: bl              #0x8ea014  ; AllocateDioExceptionStub -> DioException (size=0x24)
    // 0x8f4fe4: stur            x0, [fp, #-0x18]
    // 0x8f4fe8: r16 = Instance_DioExceptionType
    //     0x8f4fe8: add             x16, PP, #0x16, lsl #12  ; [pp+0x163f8] Obj!DioExceptionType@12c6541
    //     0x8f4fec: ldr             x16, [x16, #0x3f8]
    // 0x8f4ff0: stp             NULL, x16, [SP, #0x10]
    // 0x8f4ff4: ldur            x16, [fp, #-0x10]
    // 0x8f4ff8: stp             x16, NULL, [SP]
    // 0x8f4ffc: mov             x1, x0
    // 0x8f5000: ldur            x2, [fp, #-8]
    // 0x8f5004: r4 = const [0, 0x6, 0x4, 0x2, error, 0x4, message, 0x5, response, 0x3, type, 0x2, null]
    //     0x8f5004: add             x4, PP, #0x16, lsl #12  ; [pp+0x16088] List(13) [0, 0x6, 0x4, 0x2, "error", 0x4, "message", 0x5, "response", 0x3, "type", 0x2, Null]
    //     0x8f5008: ldr             x4, [x4, #0x88]
    // 0x8f500c: r0 = DioException()
    //     0x8f500c: bl              #0x8e97ec  ; [package:dio/src/dio_exception.dart] DioException::DioException
    // 0x8f5010: ldur            x0, [fp, #-0x18]
    // 0x8f5014: LeaveFrame
    //     0x8f5014: mov             SP, fp
    //     0x8f5018: ldp             fp, lr, [SP], #0x10
    // 0x8f501c: ret
    //     0x8f501c: ret             
    // 0x8f5020: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f5020: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f5024: b               #0x8f4f98
  }
  factory _ DioException.connectionTimeout(/* No info */) {
    // ** addr: 0x8f6318, size: 0xf4
    // 0x8f6318: EnterFrame
    //     0x8f6318: stp             fp, lr, [SP, #-0x10]!
    //     0x8f631c: mov             fp, SP
    // 0x8f6320: AllocStack(0x40)
    //     0x8f6320: sub             SP, SP, #0x40
    // 0x8f6324: SetupParameters(dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, {dynamic error = Null /* r4, fp-0x8 */})
    //     0x8f6324: mov             x0, x2
    //     0x8f6328: stur            x2, [fp, #-0x10]
    //     0x8f632c: stur            x3, [fp, #-0x18]
    //     0x8f6330: ldur            w1, [x4, #0x13]
    //     0x8f6334: ldur            w2, [x4, #0x1f]
    //     0x8f6338: add             x2, x2, HEAP, lsl #32
    //     0x8f633c: ldr             x16, [PP, #0x1c30]  ; [pp+0x1c30] "error"
    //     0x8f6340: cmp             w2, w16
    //     0x8f6344: b.ne            #0x8f6364
    //     0x8f6348: ldur            w2, [x4, #0x23]
    //     0x8f634c: add             x2, x2, HEAP, lsl #32
    //     0x8f6350: sub             w4, w1, w2
    //     0x8f6354: add             x1, fp, w4, sxtw #2
    //     0x8f6358: ldr             x1, [x1, #8]
    //     0x8f635c: mov             x4, x1
    //     0x8f6360: b               #0x8f6368
    //     0x8f6364: mov             x4, NULL
    //     0x8f6368: stur            x4, [fp, #-8]
    // 0x8f636c: CheckStackOverflow
    //     0x8f636c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f6370: cmp             SP, x16
    //     0x8f6374: b.ls            #0x8f6404
    // 0x8f6378: r1 = Null
    //     0x8f6378: mov             x1, NULL
    // 0x8f637c: r2 = 10
    //     0x8f637c: mov             x2, #0xa
    // 0x8f6380: r0 = AllocateArray()
    //     0x8f6380: bl              #0x13df928  ; AllocateArrayStub
    // 0x8f6384: r16 = "The request connection took longer than "
    //     0x8f6384: add             x16, PP, #0x16, lsl #12  ; [pp+0x16540] "The request connection took longer than "
    //     0x8f6388: ldr             x16, [x16, #0x540]
    // 0x8f638c: StoreField: r0->field_f = r16
    //     0x8f638c: stur            w16, [x0, #0xf]
    // 0x8f6390: ldur            x1, [fp, #-0x18]
    // 0x8f6394: StoreField: r0->field_13 = r1
    //     0x8f6394: stur            w1, [x0, #0x13]
    // 0x8f6398: r16 = " and it was aborted. To get rid of this exception, try raising the RequestOptions.connectTimeout above the duration of "
    //     0x8f6398: add             x16, PP, #0x16, lsl #12  ; [pp+0x16548] " and it was aborted. To get rid of this exception, try raising the RequestOptions.connectTimeout above the duration of "
    //     0x8f639c: ldr             x16, [x16, #0x548]
    // 0x8f63a0: ArrayStore: r0[0] = r16  ; List_4
    //     0x8f63a0: stur            w16, [x0, #0x17]
    // 0x8f63a4: StoreField: r0->field_1b = r1
    //     0x8f63a4: stur            w1, [x0, #0x1b]
    // 0x8f63a8: r16 = " or improve the response time of the server."
    //     0x8f63a8: add             x16, PP, #0x16, lsl #12  ; [pp+0x163f0] " or improve the response time of the server."
    //     0x8f63ac: ldr             x16, [x16, #0x3f0]
    // 0x8f63b0: StoreField: r0->field_1f = r16
    //     0x8f63b0: stur            w16, [x0, #0x1f]
    // 0x8f63b4: str             x0, [SP]
    // 0x8f63b8: r0 = _interpolate()
    //     0x8f63b8: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x8f63bc: stur            x0, [fp, #-0x18]
    // 0x8f63c0: r0 = DioException()
    //     0x8f63c0: bl              #0x8ea014  ; AllocateDioExceptionStub -> DioException (size=0x24)
    // 0x8f63c4: stur            x0, [fp, #-0x20]
    // 0x8f63c8: r16 = Instance_DioExceptionType
    //     0x8f63c8: add             x16, PP, #0x16, lsl #12  ; [pp+0x16550] Obj!DioExceptionType@12c6561
    //     0x8f63cc: ldr             x16, [x16, #0x550]
    // 0x8f63d0: stp             NULL, x16, [SP, #0x10]
    // 0x8f63d4: ldur            x16, [fp, #-8]
    // 0x8f63d8: ldur            lr, [fp, #-0x18]
    // 0x8f63dc: stp             lr, x16, [SP]
    // 0x8f63e0: mov             x1, x0
    // 0x8f63e4: ldur            x2, [fp, #-0x10]
    // 0x8f63e8: r4 = const [0, 0x6, 0x4, 0x2, error, 0x4, message, 0x5, response, 0x3, type, 0x2, null]
    //     0x8f63e8: add             x4, PP, #0x16, lsl #12  ; [pp+0x16088] List(13) [0, 0x6, 0x4, 0x2, "error", 0x4, "message", 0x5, "response", 0x3, "type", 0x2, Null]
    //     0x8f63ec: ldr             x4, [x4, #0x88]
    // 0x8f63f0: r0 = DioException()
    //     0x8f63f0: bl              #0x8e97ec  ; [package:dio/src/dio_exception.dart] DioException::DioException
    // 0x8f63f4: ldur            x0, [fp, #-0x20]
    // 0x8f63f8: LeaveFrame
    //     0x8f63f8: mov             SP, fp
    //     0x8f63fc: ldp             fp, lr, [SP], #0x10
    // 0x8f6400: ret
    //     0x8f6400: ret             
    // 0x8f6404: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f6404: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f6408: b               #0x8f6378
  }
  factory _ DioException.connectionError(/* No info */) {
    // ** addr: 0x8f640c, size: 0xf8
    // 0x8f640c: EnterFrame
    //     0x8f640c: stp             fp, lr, [SP, #-0x10]!
    //     0x8f6410: mov             fp, SP
    // 0x8f6414: AllocStack(0x50)
    //     0x8f6414: sub             SP, SP, #0x50
    // 0x8f6418: SetupParameters(dynamic _ /* r2 => r5, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r0, fp-0x20 */, {dynamic stackTrace = Null /* r4, fp-0x8 */})
    //     0x8f6418: mov             x0, x5
    //     0x8f641c: stur            x5, [fp, #-0x20]
    //     0x8f6420: mov             x5, x2
    //     0x8f6424: stur            x2, [fp, #-0x10]
    //     0x8f6428: stur            x3, [fp, #-0x18]
    //     0x8f642c: ldur            w1, [x4, #0x13]
    //     0x8f6430: ldur            w2, [x4, #0x1f]
    //     0x8f6434: add             x2, x2, HEAP, lsl #32
    //     0x8f6438: add             x16, PP, #0x15, lsl #12  ; [pp+0x15cf8] "stackTrace"
    //     0x8f643c: ldr             x16, [x16, #0xcf8]
    //     0x8f6440: cmp             w2, w16
    //     0x8f6444: b.ne            #0x8f6464
    //     0x8f6448: ldur            w2, [x4, #0x23]
    //     0x8f644c: add             x2, x2, HEAP, lsl #32
    //     0x8f6450: sub             w4, w1, w2
    //     0x8f6454: add             x1, fp, w4, sxtw #2
    //     0x8f6458: ldr             x1, [x1, #8]
    //     0x8f645c: mov             x4, x1
    //     0x8f6460: b               #0x8f6468
    //     0x8f6464: mov             x4, NULL
    //     0x8f6468: stur            x4, [fp, #-8]
    // 0x8f646c: CheckStackOverflow
    //     0x8f646c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f6470: cmp             SP, x16
    //     0x8f6474: b.ls            #0x8f64fc
    // 0x8f6478: r1 = Null
    //     0x8f6478: mov             x1, NULL
    // 0x8f647c: r2 = 6
    //     0x8f647c: mov             x2, #6
    // 0x8f6480: r0 = AllocateArray()
    //     0x8f6480: bl              #0x13df928  ; AllocateArrayStub
    // 0x8f6484: r16 = "The connection errored: "
    //     0x8f6484: add             x16, PP, #0x16, lsl #12  ; [pp+0x16558] "The connection errored: "
    //     0x8f6488: ldr             x16, [x16, #0x558]
    // 0x8f648c: StoreField: r0->field_f = r16
    //     0x8f648c: stur            w16, [x0, #0xf]
    // 0x8f6490: ldur            x1, [fp, #-0x18]
    // 0x8f6494: StoreField: r0->field_13 = r1
    //     0x8f6494: stur            w1, [x0, #0x13]
    // 0x8f6498: r16 = " This indicates an error which most likely cannot be solved by the library."
    //     0x8f6498: add             x16, PP, #0x16, lsl #12  ; [pp+0x16560] " This indicates an error which most likely cannot be solved by the library."
    //     0x8f649c: ldr             x16, [x16, #0x560]
    // 0x8f64a0: ArrayStore: r0[0] = r16  ; List_4
    //     0x8f64a0: stur            w16, [x0, #0x17]
    // 0x8f64a4: str             x0, [SP]
    // 0x8f64a8: r0 = _interpolate()
    //     0x8f64a8: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x8f64ac: stur            x0, [fp, #-0x18]
    // 0x8f64b0: r0 = DioException()
    //     0x8f64b0: bl              #0x8ea014  ; AllocateDioExceptionStub -> DioException (size=0x24)
    // 0x8f64b4: stur            x0, [fp, #-0x28]
    // 0x8f64b8: r16 = Instance_DioExceptionType
    //     0x8f64b8: add             x16, PP, #0x16, lsl #12  ; [pp+0x16568] Obj!DioExceptionType@12c6581
    //     0x8f64bc: ldr             x16, [x16, #0x568]
    // 0x8f64c0: ldur            lr, [fp, #-0x18]
    // 0x8f64c4: stp             lr, x16, [SP, #0x18]
    // 0x8f64c8: ldur            x16, [fp, #-0x10]
    // 0x8f64cc: stp             x16, NULL, [SP, #8]
    // 0x8f64d0: ldur            x16, [fp, #-8]
    // 0x8f64d4: str             x16, [SP]
    // 0x8f64d8: mov             x1, x0
    // 0x8f64dc: ldur            x2, [fp, #-0x20]
    // 0x8f64e0: r4 = const [0, 0x7, 0x5, 0x2, error, 0x5, message, 0x3, response, 0x4, stackTrace, 0x6, type, 0x2, null]
    //     0x8f64e0: add             x4, PP, #0x16, lsl #12  ; [pp+0x16570] List(15) [0, 0x7, 0x5, 0x2, "error", 0x5, "message", 0x3, "response", 0x4, "stackTrace", 0x6, "type", 0x2, Null]
    //     0x8f64e4: ldr             x4, [x4, #0x570]
    // 0x8f64e8: r0 = DioException()
    //     0x8f64e8: bl              #0x8e97ec  ; [package:dio/src/dio_exception.dart] DioException::DioException
    // 0x8f64ec: ldur            x0, [fp, #-0x28]
    // 0x8f64f0: LeaveFrame
    //     0x8f64f0: mov             SP, fp
    //     0x8f64f4: ldp             fp, lr, [SP], #0x10
    // 0x8f64f8: ret
    //     0x8f64f8: ret             
    // 0x8f64fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f64fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f6500: b               #0x8f6478
  }
  factory _ DioException.sendTimeout(/* No info */) {
    // ** addr: 0x90e1c8, size: 0xbc
    // 0x90e1c8: EnterFrame
    //     0x90e1c8: stp             fp, lr, [SP, #-0x10]!
    //     0x90e1cc: mov             fp, SP
    // 0x90e1d0: AllocStack(0x38)
    //     0x90e1d0: sub             SP, SP, #0x38
    // 0x90e1d4: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0x90e1d4: mov             x0, x2
    //     0x90e1d8: stur            x2, [fp, #-8]
    // 0x90e1dc: CheckStackOverflow
    //     0x90e1dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x90e1e0: cmp             SP, x16
    //     0x90e1e4: b.ls            #0x90e27c
    // 0x90e1e8: r1 = Null
    //     0x90e1e8: mov             x1, NULL
    // 0x90e1ec: r2 = 10
    //     0x90e1ec: mov             x2, #0xa
    // 0x90e1f0: r0 = AllocateArray()
    //     0x90e1f0: bl              #0x13df928  ; AllocateArrayStub
    // 0x90e1f4: r16 = "The request took longer than "
    //     0x90e1f4: add             x16, PP, #0x16, lsl #12  ; [pp+0x163e0] "The request took longer than "
    //     0x90e1f8: ldr             x16, [x16, #0x3e0]
    // 0x90e1fc: StoreField: r0->field_f = r16
    //     0x90e1fc: stur            w16, [x0, #0xf]
    // 0x90e200: r16 = Instance_Duration
    //     0x90e200: add             x16, PP, #0x16, lsl #12  ; [pp+0x16528] Obj!Duration@12c89f1
    //     0x90e204: ldr             x16, [x16, #0x528]
    // 0x90e208: StoreField: r0->field_13 = r16
    //     0x90e208: stur            w16, [x0, #0x13]
    // 0x90e20c: r16 = " to send data. It was aborted. To get rid of this exception, try raising the RequestOptions.sendTimeout above the duration of "
    //     0x90e20c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16530] " to send data. It was aborted. To get rid of this exception, try raising the RequestOptions.sendTimeout above the duration of "
    //     0x90e210: ldr             x16, [x16, #0x530]
    // 0x90e214: ArrayStore: r0[0] = r16  ; List_4
    //     0x90e214: stur            w16, [x0, #0x17]
    // 0x90e218: r16 = Instance_Duration
    //     0x90e218: add             x16, PP, #0x16, lsl #12  ; [pp+0x16528] Obj!Duration@12c89f1
    //     0x90e21c: ldr             x16, [x16, #0x528]
    // 0x90e220: StoreField: r0->field_1b = r16
    //     0x90e220: stur            w16, [x0, #0x1b]
    // 0x90e224: r16 = " or improve the response time of the server."
    //     0x90e224: add             x16, PP, #0x16, lsl #12  ; [pp+0x163f0] " or improve the response time of the server."
    //     0x90e228: ldr             x16, [x16, #0x3f0]
    // 0x90e22c: StoreField: r0->field_1f = r16
    //     0x90e22c: stur            w16, [x0, #0x1f]
    // 0x90e230: str             x0, [SP]
    // 0x90e234: r0 = _interpolate()
    //     0x90e234: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x90e238: stur            x0, [fp, #-0x10]
    // 0x90e23c: r0 = DioException()
    //     0x90e23c: bl              #0x8ea014  ; AllocateDioExceptionStub -> DioException (size=0x24)
    // 0x90e240: stur            x0, [fp, #-0x18]
    // 0x90e244: r16 = Instance_DioExceptionType
    //     0x90e244: add             x16, PP, #0x16, lsl #12  ; [pp+0x16538] Obj!DioExceptionType@12c65a1
    //     0x90e248: ldr             x16, [x16, #0x538]
    // 0x90e24c: stp             NULL, x16, [SP, #0x10]
    // 0x90e250: ldur            x16, [fp, #-0x10]
    // 0x90e254: stp             x16, NULL, [SP]
    // 0x90e258: mov             x1, x0
    // 0x90e25c: ldur            x2, [fp, #-8]
    // 0x90e260: r4 = const [0, 0x6, 0x4, 0x2, error, 0x4, message, 0x5, response, 0x3, type, 0x2, null]
    //     0x90e260: add             x4, PP, #0x16, lsl #12  ; [pp+0x16088] List(13) [0, 0x6, 0x4, 0x2, "error", 0x4, "message", 0x5, "response", 0x3, "type", 0x2, Null]
    //     0x90e264: ldr             x4, [x4, #0x88]
    // 0x90e268: r0 = DioException()
    //     0x90e268: bl              #0x8e97ec  ; [package:dio/src/dio_exception.dart] DioException::DioException
    // 0x90e26c: ldur            x0, [fp, #-0x18]
    // 0x90e270: LeaveFrame
    //     0x90e270: mov             SP, fp
    //     0x90e274: ldp             fp, lr, [SP], #0x10
    // 0x90e278: ret
    //     0x90e278: ret             
    // 0x90e27c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x90e27c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x90e280: b               #0x90e1e8
  }
  factory _ DioException.requestCancelled(/* No info */) {
    // ** addr: 0x913a74, size: 0x7c
    // 0x913a74: EnterFrame
    //     0x913a74: stp             fp, lr, [SP, #-0x10]!
    //     0x913a78: mov             fp, SP
    // 0x913a7c: AllocStack(0x40)
    //     0x913a7c: sub             SP, SP, #0x40
    // 0x913a80: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0x913a80: stur            x2, [fp, #-8]
    //     0x913a84: stur            x3, [fp, #-0x10]
    // 0x913a88: CheckStackOverflow
    //     0x913a88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x913a8c: cmp             SP, x16
    //     0x913a90: b.ls            #0x913ae8
    // 0x913a94: r0 = DioException()
    //     0x913a94: bl              #0x8ea014  ; AllocateDioExceptionStub -> DioException (size=0x24)
    // 0x913a98: stur            x0, [fp, #-0x18]
    // 0x913a9c: r16 = Instance_DioExceptionType
    //     0x913a9c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15f90] Obj!DioExceptionType@12c6501
    //     0x913aa0: ldr             x16, [x16, #0xf90]
    // 0x913aa4: stp             NULL, x16, [SP, #0x18]
    // 0x913aa8: r16 = "User has logged out."
    //     0x913aa8: add             x16, PP, #0x16, lsl #12  ; [pp+0x16b08] "User has logged out."
    //     0x913aac: ldr             x16, [x16, #0xb08]
    // 0x913ab0: ldur            lr, [fp, #-0x10]
    // 0x913ab4: stp             lr, x16, [SP, #8]
    // 0x913ab8: r16 = "The request was manually cancelled by the user."
    //     0x913ab8: add             x16, PP, #0x16, lsl #12  ; [pp+0x16b40] "The request was manually cancelled by the user."
    //     0x913abc: ldr             x16, [x16, #0xb40]
    // 0x913ac0: str             x16, [SP]
    // 0x913ac4: mov             x1, x0
    // 0x913ac8: ldur            x2, [fp, #-8]
    // 0x913acc: r4 = const [0, 0x7, 0x5, 0x2, error, 0x4, message, 0x6, response, 0x3, stackTrace, 0x5, type, 0x2, null]
    //     0x913acc: add             x4, PP, #0x16, lsl #12  ; [pp+0x16b48] List(15) [0, 0x7, 0x5, 0x2, "error", 0x4, "message", 0x6, "response", 0x3, "stackTrace", 0x5, "type", 0x2, Null]
    //     0x913ad0: ldr             x4, [x4, #0xb48]
    // 0x913ad4: r0 = DioException()
    //     0x913ad4: bl              #0x8e97ec  ; [package:dio/src/dio_exception.dart] DioException::DioException
    // 0x913ad8: ldur            x0, [fp, #-0x18]
    // 0x913adc: LeaveFrame
    //     0x913adc: mov             SP, fp
    //     0x913ae0: ldp             fp, lr, [SP], #0x10
    // 0x913ae4: ret
    //     0x913ae4: ret             
    // 0x913ae8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x913ae8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x913aec: b               #0x913a94
  }
  _ toString(/* No info */) {
    // ** addr: 0x111431c, size: 0x80
    // 0x111431c: EnterFrame
    //     0x111431c: stp             fp, lr, [SP, #-0x10]!
    //     0x1114320: mov             fp, SP
    // 0x1114324: AllocStack(0x50)
    //     0x1114324: sub             SP, SP, #0x50
    // 0x1114328: CheckStackOverflow
    //     0x1114328: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x111432c: cmp             SP, x16
    //     0x1114330: b.ls            #0x1114394
    // 0x1114334: r0 = LoadStaticField(0x980)
    //     0x1114334: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x1114338: ldr             x0, [x0, #0x1300]
    // 0x111433c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1114340: cmp             w0, w16
    // 0x1114344: b.ne            #0x1114354
    // 0x1114348: r2 = readableStringBuilder
    //     0x1114348: add             x2, PP, #0x17, lsl #12  ; [pp+0x172d8] Field <DioException.readableStringBuilder>: static late (offset: 0x980)
    //     0x111434c: ldr             x2, [x2, #0x2d8]
    // 0x1114350: r0 = InitLateStaticField()
    //     0x1114350: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0x1114354: r0 = Closure: (DioException) => String from Function 'defaultDioExceptionReadableStringBuilder': static.
    //     0x1114354: add             x0, PP, #0x17, lsl #12  ; [pp+0x172e0] Closure: (DioException) => String from Function 'defaultDioExceptionReadableStringBuilder': static. (0x7f2adaffb39c)
    //     0x1114358: ldr             x0, [x0, #0x2e0]
    // 0x111435c: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x111435c: ldur            w2, [x0, #0x17]
    // 0x1114360: DecompressPointer r2
    //     0x1114360: add             x2, x2, HEAP, lsl #32
    // 0x1114364: ldr             x1, [fp, #0x10]
    // 0x1114368: stur            x2, [fp, #-0x50]
    // 0x111436c: r0 = defaultDioExceptionReadableStringBuilder()
    //     0x111436c: bl              #0x11143cc  ; [package:dio/src/dio_exception.dart] ::defaultDioExceptionReadableStringBuilder
    // 0x1114370: LeaveFrame
    //     0x1114370: mov             SP, fp
    //     0x1114374: ldp             fp, lr, [SP], #0x10
    // 0x1114378: ret
    //     0x1114378: ret             
    // 0x111437c: sub             SP, fp, #0x50
    // 0x1114380: ldr             x1, [fp, #0x10]
    // 0x1114384: r0 = defaultDioExceptionReadableStringBuilder()
    //     0x1114384: bl              #0x11143cc  ; [package:dio/src/dio_exception.dart] ::defaultDioExceptionReadableStringBuilder
    // 0x1114388: LeaveFrame
    //     0x1114388: mov             SP, fp
    //     0x111438c: ldp             fp, lr, [SP], #0x10
    // 0x1114390: ret
    //     0x1114390: ret             
    // 0x1114394: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1114394: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1114398: b               #0x1114334
  }
  static (dynamic, DioException) => String readableStringBuilder() {
    // ** addr: 0x1114570, size: 0xc
    // 0x1114570: r0 = Closure: (DioException) => String from Function 'defaultDioExceptionReadableStringBuilder': static.
    //     0x1114570: add             x0, PP, #0x17, lsl #12  ; [pp+0x172e0] Closure: (DioException) => String from Function 'defaultDioExceptionReadableStringBuilder': static. (0x7f2adaffb39c)
    //     0x1114574: ldr             x0, [x0, #0x2e0]
    // 0x1114578: ret
    //     0x1114578: ret             
  }
}

// class id: 8336, size: 0x14, field offset: 0x14
enum DioExceptionType extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11a91bc, size: 0x64
    // 0x11a91bc: EnterFrame
    //     0x11a91bc: stp             fp, lr, [SP, #-0x10]!
    //     0x11a91c0: mov             fp, SP
    // 0x11a91c4: AllocStack(0x10)
    //     0x11a91c4: sub             SP, SP, #0x10
    // 0x11a91c8: SetupParameters(DioExceptionType this /* r1 => r0, fp-0x8 */)
    //     0x11a91c8: mov             x0, x1
    //     0x11a91cc: stur            x1, [fp, #-8]
    // 0x11a91d0: CheckStackOverflow
    //     0x11a91d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a91d4: cmp             SP, x16
    //     0x11a91d8: b.ls            #0x11a9218
    // 0x11a91dc: r1 = Null
    //     0x11a91dc: mov             x1, NULL
    // 0x11a91e0: r2 = 4
    //     0x11a91e0: mov             x2, #4
    // 0x11a91e4: r0 = AllocateArray()
    //     0x11a91e4: bl              #0x13df928  ; AllocateArrayStub
    // 0x11a91e8: r16 = "DioExceptionType."
    //     0x11a91e8: add             x16, PP, #0x81, lsl #12  ; [pp+0x81ea8] "DioExceptionType."
    //     0x11a91ec: ldr             x16, [x16, #0xea8]
    // 0x11a91f0: StoreField: r0->field_f = r16
    //     0x11a91f0: stur            w16, [x0, #0xf]
    // 0x11a91f4: ldur            x1, [fp, #-8]
    // 0x11a91f8: LoadField: r2 = r1->field_f
    //     0x11a91f8: ldur            w2, [x1, #0xf]
    // 0x11a91fc: DecompressPointer r2
    //     0x11a91fc: add             x2, x2, HEAP, lsl #32
    // 0x11a9200: StoreField: r0->field_13 = r2
    //     0x11a9200: stur            w2, [x0, #0x13]
    // 0x11a9204: str             x0, [SP]
    // 0x11a9208: r0 = _interpolate()
    //     0x11a9208: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11a920c: LeaveFrame
    //     0x11a920c: mov             SP, fp
    //     0x11a9210: ldp             fp, lr, [SP], #0x10
    // 0x11a9214: ret
    //     0x11a9214: ret             
    // 0x11a9218: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a9218: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a921c: b               #0x11a91dc
  }
}
