// lib: , url: package:dio/src/interceptors/imply_content_type.dart

// class id: 1048705, size: 0x8
class :: {
}

// class id: 4266, size: 0x8, field offset: 0x8
//   const constructor, 
class ImplyContentTypeInterceptor extends Interceptor {

  [closure] void onRequest(dynamic, RequestOptions, RequestInterceptorHandler) {
    // ** addr: 0x1226350, size: 0x40
    // 0x1226350: EnterFrame
    //     0x1226350: stp             fp, lr, [SP, #-0x10]!
    //     0x1226354: mov             fp, SP
    // 0x1226358: ldr             x0, [fp, #0x20]
    // 0x122635c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x122635c: ldur            w1, [x0, #0x17]
    // 0x1226360: DecompressPointer r1
    //     0x1226360: add             x1, x1, HEAP, lsl #32
    // 0x1226364: CheckStackOverflow
    //     0x1226364: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1226368: cmp             SP, x16
    //     0x122636c: b.ls            #0x1226388
    // 0x1226370: ldr             x2, [fp, #0x18]
    // 0x1226374: ldr             x3, [fp, #0x10]
    // 0x1226378: r0 = onRequest()
    //     0x1226378: bl              #0x1226390  ; [package:dio/src/interceptors/imply_content_type.dart] ImplyContentTypeInterceptor::onRequest
    // 0x122637c: LeaveFrame
    //     0x122637c: mov             SP, fp
    //     0x1226380: ldp             fp, lr, [SP], #0x10
    // 0x1226384: ret
    //     0x1226384: ret             
    // 0x1226388: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1226388: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x122638c: b               #0x1226370
  }
  _ onRequest(/* No info */) {
    // ** addr: 0x1226390, size: 0x29c
    // 0x1226390: EnterFrame
    //     0x1226390: stp             fp, lr, [SP, #-0x10]!
    //     0x1226394: mov             fp, SP
    // 0x1226398: AllocStack(0x30)
    //     0x1226398: sub             SP, SP, #0x30
    // 0x122639c: SetupParameters(dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x122639c: mov             x4, x2
    //     0x12263a0: stur            x2, [fp, #-0x10]
    //     0x12263a4: stur            x3, [fp, #-0x18]
    // 0x12263a8: CheckStackOverflow
    //     0x12263a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12263ac: cmp             SP, x16
    //     0x12263b0: b.ls            #0x1226618
    // 0x12263b4: LoadField: r5 = r4->field_5b
    //     0x12263b4: ldur            w5, [x4, #0x5b]
    // 0x12263b8: DecompressPointer r5
    //     0x12263b8: add             x5, x5, HEAP, lsl #32
    // 0x12263bc: stur            x5, [fp, #-8]
    // 0x12263c0: cmp             w5, NULL
    // 0x12263c4: b.eq            #0x12265fc
    // 0x12263c8: LoadField: r1 = r4->field_b
    //     0x12263c8: ldur            w1, [x4, #0xb]
    // 0x12263cc: DecompressPointer r1
    //     0x12263cc: add             x1, x1, HEAP, lsl #32
    // 0x12263d0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12263d4: cmp             w1, w16
    // 0x12263d8: b.eq            #0x1226620
    // 0x12263dc: r0 = LoadClassIdInstr(r1)
    //     0x12263dc: ldur            x0, [x1, #-1]
    //     0x12263e0: ubfx            x0, x0, #0xc, #0x14
    // 0x12263e4: r2 = "content-type"
    //     0x12263e4: add             x2, PP, #8, lsl #12  ; [pp+0x85d8] "content-type"
    //     0x12263e8: ldr             x2, [x2, #0x5d8]
    // 0x12263ec: r0 = GDT[cid_x0 + -0xd48]()
    //     0x12263ec: sub             lr, x0, #0xd48
    //     0x12263f0: ldr             lr, [x21, lr, lsl #3]
    //     0x12263f4: blr             lr
    // 0x12263f8: mov             x3, x0
    // 0x12263fc: r2 = Null
    //     0x12263fc: mov             x2, NULL
    // 0x1226400: r1 = Null
    //     0x1226400: mov             x1, NULL
    // 0x1226404: stur            x3, [fp, #-0x20]
    // 0x1226408: r4 = 60
    //     0x1226408: mov             x4, #0x3c
    // 0x122640c: branchIfSmi(r0, 0x1226418)
    //     0x122640c: tbz             w0, #0, #0x1226418
    // 0x1226410: r4 = LoadClassIdInstr(r0)
    //     0x1226410: ldur            x4, [x0, #-1]
    //     0x1226414: ubfx            x4, x4, #0xc, #0x14
    // 0x1226418: sub             x4, x4, #0x5e
    // 0x122641c: cmp             x4, #1
    // 0x1226420: b.ls            #0x1226434
    // 0x1226424: r8 = String?
    //     0x1226424: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x1226428: r3 = Null
    //     0x1226428: add             x3, PP, #0x82, lsl #12  ; [pp+0x821d8] Null
    //     0x122642c: ldr             x3, [x3, #0x1d8]
    // 0x1226430: r0 = String?()
    //     0x1226430: bl              #0x7db310  ; IsType_String?_Stub
    // 0x1226434: ldur            x0, [fp, #-0x20]
    // 0x1226438: cmp             w0, NULL
    // 0x122643c: b.ne            #0x12265fc
    // 0x1226440: ldur            x3, [fp, #-8]
    // 0x1226444: r4 = 60
    //     0x1226444: mov             x4, #0x3c
    // 0x1226448: branchIfSmi(r3, 0x1226454)
    //     0x1226448: tbz             w3, #0, #0x1226454
    // 0x122644c: r4 = LoadClassIdInstr(r3)
    //     0x122644c: ldur            x4, [x3, #-1]
    //     0x1226450: ubfx            x4, x4, #0xc, #0x14
    // 0x1226454: stur            x4, [fp, #-0x28]
    // 0x1226458: cmp             x4, #0xd4c
    // 0x122645c: b.ne            #0x122646c
    // 0x1226460: r2 = "multipart/form-data"
    //     0x1226460: add             x2, PP, #0x16, lsl #12  ; [pp+0x166c0] "multipart/form-data"
    //     0x1226464: ldr             x2, [x2, #0x6c0]
    // 0x1226468: b               #0x12265f4
    // 0x122646c: mov             x0, x3
    // 0x1226470: r2 = Null
    //     0x1226470: mov             x2, NULL
    // 0x1226474: r1 = Null
    //     0x1226474: mov             x1, NULL
    // 0x1226478: cmp             w0, NULL
    // 0x122647c: b.eq            #0x12264c8
    // 0x1226480: branchIfSmi(r0, 0x12264c8)
    //     0x1226480: tbz             w0, #0, #0x12264c8
    // 0x1226484: r3 = SubtypeTestCache
    //     0x1226484: add             x3, PP, #0x82, lsl #12  ; [pp+0x821e8] SubtypeTestCache
    //     0x1226488: ldr             x3, [x3, #0x1e8]
    // 0x122648c: r30 = Subtype2TestCacheStub
    //     0x122648c: ldr             lr, [PP, #0x30]  ; [pp+0x30] Stub: Subtype2TestCache (0x7d2e44)
    // 0x1226490: LoadField: r30 = r30->field_7
    //     0x1226490: ldur            lr, [lr, #7]
    // 0x1226494: blr             lr
    // 0x1226498: cmp             w7, NULL
    // 0x122649c: b.eq            #0x12264a8
    // 0x12264a0: tbnz            w7, #4, #0x12264c8
    // 0x12264a4: b               #0x12264d0
    // 0x12264a8: r8 = List<Map>
    //     0x12264a8: add             x8, PP, #0x82, lsl #12  ; [pp+0x821f0] Type: List<Map>
    //     0x12264ac: ldr             x8, [x8, #0x1f0]
    // 0x12264b0: r3 = SubtypeTestCache
    //     0x12264b0: add             x3, PP, #0x82, lsl #12  ; [pp+0x821f8] SubtypeTestCache
    //     0x12264b4: ldr             x3, [x3, #0x1f8]
    // 0x12264b8: r30 = InstanceOfStub
    //     0x12264b8: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x12264bc: LoadField: r30 = r30->field_7
    //     0x12264bc: ldur            lr, [lr, #7]
    // 0x12264c0: blr             lr
    // 0x12264c4: b               #0x12264d4
    // 0x12264c8: r0 = false
    //     0x12264c8: add             x0, NULL, #0x30  ; false
    // 0x12264cc: b               #0x12264d4
    // 0x12264d0: r0 = true
    //     0x12264d0: add             x0, NULL, #0x20  ; true
    // 0x12264d4: tbz             w0, #4, #0x12265a0
    // 0x12264d8: ldur            x0, [fp, #-8]
    // 0x12264dc: r2 = Null
    //     0x12264dc: mov             x2, NULL
    // 0x12264e0: r1 = Null
    //     0x12264e0: mov             x1, NULL
    // 0x12264e4: cmp             w0, NULL
    // 0x12264e8: b.eq            #0x1226580
    // 0x12264ec: branchIfSmi(r0, 0x1226580)
    //     0x12264ec: tbz             w0, #0, #0x1226580
    // 0x12264f0: r3 = LoadClassIdInstr(r0)
    //     0x12264f0: ldur            x3, [x0, #-1]
    //     0x12264f4: ubfx            x3, x3, #0xc, #0x14
    // 0x12264f8: r17 = 7630
    //     0x12264f8: mov             x17, #0x1dce
    // 0x12264fc: cmp             x3, x17
    // 0x1226500: b.eq            #0x1226588
    // 0x1226504: r4 = LoadClassIdInstr(r0)
    //     0x1226504: ldur            x4, [x0, #-1]
    //     0x1226508: ubfx            x4, x4, #0xc, #0x14
    // 0x122650c: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x1226510: ldr             x3, [x3, #0x18]
    // 0x1226514: ldr             x3, [x3, x4, lsl #3]
    // 0x1226518: LoadField: r3 = r3->field_2b
    //     0x1226518: ldur            w3, [x3, #0x2b]
    // 0x122651c: DecompressPointer r3
    //     0x122651c: add             x3, x3, HEAP, lsl #32
    // 0x1226520: cmp             w3, NULL
    // 0x1226524: b.eq            #0x1226580
    // 0x1226528: LoadField: r3 = r3->field_f
    //     0x1226528: ldur            w3, [x3, #0xf]
    // 0x122652c: lsr             x3, x3, #3
    // 0x1226530: r17 = 7630
    //     0x1226530: mov             x17, #0x1dce
    // 0x1226534: cmp             x3, x17
    // 0x1226538: b.eq            #0x1226588
    // 0x122653c: r3 = SubtypeTestCache
    //     0x122653c: add             x3, PP, #0x82, lsl #12  ; [pp+0x82200] SubtypeTestCache
    //     0x1226540: ldr             x3, [x3, #0x200]
    // 0x1226544: r30 = Subtype1TestCacheStub
    //     0x1226544: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x1226548: LoadField: r30 = r30->field_7
    //     0x1226548: ldur            lr, [lr, #7]
    // 0x122654c: blr             lr
    // 0x1226550: cmp             w7, NULL
    // 0x1226554: b.eq            #0x1226560
    // 0x1226558: tbnz            w7, #4, #0x1226580
    // 0x122655c: b               #0x1226588
    // 0x1226560: r8 = Map
    //     0x1226560: add             x8, PP, #0x82, lsl #12  ; [pp+0x82208] Type: Map
    //     0x1226564: ldr             x8, [x8, #0x208]
    // 0x1226568: r3 = SubtypeTestCache
    //     0x1226568: add             x3, PP, #0x82, lsl #12  ; [pp+0x82210] SubtypeTestCache
    //     0x122656c: ldr             x3, [x3, #0x210]
    // 0x1226570: r30 = InstanceOfStub
    //     0x1226570: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x1226574: LoadField: r30 = r30->field_7
    //     0x1226574: ldur            lr, [lr, #7]
    // 0x1226578: blr             lr
    // 0x122657c: b               #0x122658c
    // 0x1226580: r0 = false
    //     0x1226580: add             x0, NULL, #0x30  ; false
    // 0x1226584: b               #0x122658c
    // 0x1226588: r0 = true
    //     0x1226588: add             x0, NULL, #0x20  ; true
    // 0x122658c: tbz             w0, #4, #0x12265a0
    // 0x1226590: ldur            x0, [fp, #-0x28]
    // 0x1226594: sub             x16, x0, #0x5e
    // 0x1226598: cmp             x16, #1
    // 0x122659c: b.hi            #0x12265ac
    // 0x12265a0: r0 = "application/json"
    //     0x12265a0: add             x0, PP, #0x16, lsl #12  ; [pp+0x162a8] "application/json"
    //     0x12265a4: ldr             x0, [x0, #0x2a8]
    // 0x12265a8: b               #0x12265f0
    // 0x12265ac: ldur            x16, [fp, #-8]
    // 0x12265b0: str             x16, [SP]
    // 0x12265b4: r0 = runtimeType()
    //     0x12265b4: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x12265b8: r1 = Null
    //     0x12265b8: mov             x1, NULL
    // 0x12265bc: r2 = 4
    //     0x12265bc: mov             x2, #4
    // 0x12265c0: stur            x0, [fp, #-8]
    // 0x12265c4: r0 = AllocateArray()
    //     0x12265c4: bl              #0x13df928  ; AllocateArrayStub
    // 0x12265c8: mov             x1, x0
    // 0x12265cc: ldur            x0, [fp, #-8]
    // 0x12265d0: StoreField: r1->field_f = r0
    //     0x12265d0: stur            w0, [x1, #0xf]
    // 0x12265d4: r16 = " cannot be used to imply a default content-type, please set a proper content-type in the request."
    //     0x12265d4: add             x16, PP, #0x82, lsl #12  ; [pp+0x82218] " cannot be used to imply a default content-type, please set a proper content-type in the request."
    //     0x12265d8: ldr             x16, [x16, #0x218]
    // 0x12265dc: StoreField: r1->field_13 = r16
    //     0x12265dc: stur            w16, [x1, #0x13]
    // 0x12265e0: str             x1, [SP]
    // 0x12265e4: r0 = _interpolate()
    //     0x12265e4: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x12265e8: r0 = current()
    //     0x12265e8: bl              #0x7f0e88  ; [dart:core] StackTrace::current
    // 0x12265ec: r0 = Null
    //     0x12265ec: mov             x0, NULL
    // 0x12265f0: mov             x2, x0
    // 0x12265f4: ldur            x1, [fp, #-0x10]
    // 0x12265f8: r0 = contentType=()
    //     0x12265f8: bl              #0x8eae54  ; [package:dio/src/options.dart] _RequestConfig::contentType=
    // 0x12265fc: ldur            x1, [fp, #-0x18]
    // 0x1226600: ldur            x2, [fp, #-0x10]
    // 0x1226604: r0 = next()
    //     0x1226604: bl              #0x8ee7fc  ; [package:dio/src/dio_mixin.dart] RequestInterceptorHandler::next
    // 0x1226608: r0 = Null
    //     0x1226608: mov             x0, NULL
    // 0x122660c: LeaveFrame
    //     0x122660c: mov             SP, fp
    //     0x1226610: ldp             fp, lr, [SP], #0x10
    // 0x1226614: ret
    //     0x1226614: ret             
    // 0x1226618: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1226618: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x122661c: b               #0x12263b4
    // 0x1226620: r9 = _headers
    //     0x1226620: add             x9, PP, #0x15, lsl #12  ; [pp+0x15da8] Field <_RequestConfig@271184022._headers@271184022>: late (offset: 0xc)
    //     0x1226624: ldr             x9, [x9, #0xda8]
    // 0x1226628: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x1226628: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}
