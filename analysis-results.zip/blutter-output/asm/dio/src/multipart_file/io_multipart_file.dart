// lib: , url: package:dio/src/multipart_file/io_multipart_file.dart

// class id: 1048707, size: 0x8
class :: {

  static _ multipartFileFromPath(/* No info */) async {
    // ** addr: 0xe66118, size: 0xe8
    // 0xe66118: EnterFrame
    //     0xe66118: stp             fp, lr, [SP, #-0x10]!
    //     0xe6611c: mov             fp, SP
    // 0xe66120: AllocStack(0x30)
    //     0xe66120: sub             SP, SP, #0x30
    // 0xe66124: SetupParameters(dynamic _ /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r5, fp-0x18 */, dynamic _ /* r3 => r6, fp-0x20 */)
    //     0xe66124: stur            NULL, [fp, #-8]
    //     0xe66128: mov             x5, x2
    //     0xe6612c: mov             x6, x3
    //     0xe66130: stur            x1, [fp, #-0x10]
    //     0xe66134: stur            x2, [fp, #-0x18]
    //     0xe66138: stur            x3, [fp, #-0x20]
    // 0xe6613c: CheckStackOverflow
    //     0xe6613c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe66140: cmp             SP, x16
    //     0xe66144: b.ls            #0xe661f8
    // 0xe66148: InitAsync() -> Future<MultipartFile>
    //     0xe66148: add             x0, PP, #0x1c, lsl #12  ; [pp+0x1c660] TypeArguments: <MultipartFile>
    //     0xe6614c: ldr             x0, [x0, #0x660]
    //     0xe66150: bl              #0x7f5e44  ; InitAsyncStub
    // 0xe66154: r0 = current()
    //     0xe66154: bl              #0x7ed1b8  ; [dart:io] IOOverrides::current
    // 0xe66158: r0 = _File()
    //     0xe66158: bl              #0x7fb71c  ; Allocate_FileStub -> _File (size=0x10)
    // 0xe6615c: ldur            x1, [fp, #-0x10]
    // 0xe66160: stur            x0, [fp, #-0x28]
    // 0xe66164: StoreField: r0->field_7 = r1
    //     0xe66164: stur            w1, [x0, #7]
    // 0xe66168: r0 = _toUtf8Array()
    //     0xe66168: bl              #0x7ed07c  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0xe6616c: ldur            x1, [fp, #-0x28]
    // 0xe66170: StoreField: r1->field_b = r0
    //     0xe66170: stur            w0, [x1, #0xb]
    //     0xe66174: ldurb           w16, [x1, #-1]
    //     0xe66178: ldurb           w17, [x0, #-1]
    //     0xe6617c: and             x16, x17, x16, lsr #2
    //     0xe66180: tst             x16, HEAP, lsr #32
    //     0xe66184: b.eq            #0xe6618c
    //     0xe66188: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xe6618c: r1 = 1
    //     0xe6618c: mov             x1, #1
    // 0xe66190: r0 = AllocateContext()
    //     0xe66190: bl              #0x13de838  ; AllocateContextStub
    // 0xe66194: ldur            x1, [fp, #-0x28]
    // 0xe66198: stur            x0, [fp, #-0x10]
    // 0xe6619c: StoreField: r0->field_f = r1
    //     0xe6619c: stur            w1, [x0, #0xf]
    // 0xe661a0: r0 = length()
    //     0xe661a0: bl              #0x123a20c  ; [dart:io] _File::length
    // 0xe661a4: mov             x1, x0
    // 0xe661a8: stur            x1, [fp, #-0x28]
    // 0xe661ac: r0 = Await()
    //     0xe661ac: bl              #0x7f5c00  ; AwaitStub
    // 0xe661b0: r3 = LoadInt32Instr(r0)
    //     0xe661b0: sbfx            x3, x0, #1, #0x1f
    //     0xe661b4: tbz             w0, #0, #0xe661bc
    //     0xe661b8: ldur            x3, [x0, #7]
    // 0xe661bc: stur            x3, [fp, #-0x30]
    // 0xe661c0: r0 = MultipartFile()
    //     0xe661c0: bl              #0xe662e8  ; AllocateMultipartFileStub -> MultipartFile (size=0x24)
    // 0xe661c4: ldur            x2, [fp, #-0x10]
    // 0xe661c8: r1 = Function '<anonymous closure>': static.
    //     0xe661c8: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c668] AnonymousClosure: static (0xe662f4), in [package:dio/src/multipart_file/io_multipart_file.dart] ::multipartFileFromPath (0xe66118)
    //     0xe661cc: ldr             x1, [x1, #0x668]
    // 0xe661d0: stur            x0, [fp, #-0x10]
    // 0xe661d4: r0 = AllocateClosure()
    //     0xe661d4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xe661d8: ldur            x1, [fp, #-0x10]
    // 0xe661dc: mov             x2, x0
    // 0xe661e0: ldur            x3, [fp, #-0x30]
    // 0xe661e4: ldur            x5, [fp, #-0x18]
    // 0xe661e8: ldur            x6, [fp, #-0x20]
    // 0xe661ec: r0 = MultipartFile.fromStream()
    //     0xe661ec: bl              #0xe66200  ; [package:dio/src/multipart_file.dart] MultipartFile::MultipartFile.fromStream
    // 0xe661f0: ldur            x0, [fp, #-0x10]
    // 0xe661f4: r0 = ReturnAsyncNotFuture()
    //     0xe661f4: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xe661f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe661f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe661fc: b               #0xe66148
  }
  [closure] static Stream<List<int>> <anonymous closure>(dynamic) {
    // ** addr: 0xe662f4, size: 0x44
    // 0xe662f4: EnterFrame
    //     0xe662f4: stp             fp, lr, [SP, #-0x10]!
    //     0xe662f8: mov             fp, SP
    // 0xe662fc: ldr             x0, [fp, #0x10]
    // 0xe66300: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xe66300: ldur            w1, [x0, #0x17]
    // 0xe66304: DecompressPointer r1
    //     0xe66304: add             x1, x1, HEAP, lsl #32
    // 0xe66308: CheckStackOverflow
    //     0xe66308: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe6630c: cmp             SP, x16
    //     0xe66310: b.ls            #0xe66330
    // 0xe66314: LoadField: r0 = r1->field_f
    //     0xe66314: ldur            w0, [x1, #0xf]
    // 0xe66318: DecompressPointer r0
    //     0xe66318: add             x0, x0, HEAP, lsl #32
    // 0xe6631c: mov             x1, x0
    // 0xe66320: r0 = openRead()
    //     0xe66320: bl              #0xe66338  ; [dart:io] _File::openRead
    // 0xe66324: LeaveFrame
    //     0xe66324: mov             SP, fp
    //     0xe66328: ldp             fp, lr, [SP], #0x10
    // 0xe6632c: ret
    //     0xe6632c: ret             
    // 0xe66330: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe66330: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe66334: b               #0xe66314
  }
}
