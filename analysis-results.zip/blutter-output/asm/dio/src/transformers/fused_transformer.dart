// lib: , url: package:dio/src/transformers/fused_transformer.dart

// class id: 1048714, size: 0x8
class :: {
}

// class id: 3398, size: 0x10, field offset: 0x8
class FusedTransformer extends Transformer {

  static late final Converter<List<int>, Object?> _utf8JsonDecoder; // offset: 0xb24

  _ transformResponse(/* No info */) async {
    // ** addr: 0x8ef8b0, size: 0x194
    // 0x8ef8b0: EnterFrame
    //     0x8ef8b0: stp             fp, lr, [SP, #-0x10]!
    //     0x8ef8b4: mov             fp, SP
    // 0x8ef8b8: AllocStack(0x30)
    //     0x8ef8b8: sub             SP, SP, #0x30
    // 0x8ef8bc: SetupParameters(FusedTransformer this /* r1 => r3, fp-0x18 */, dynamic _ /* r3 => r1, fp-0x20 */)
    //     0x8ef8bc: stur            NULL, [fp, #-8]
    //     0x8ef8c0: stur            x1, [fp, #-0x10]
    //     0x8ef8c4: mov             x16, x3
    //     0x8ef8c8: mov             x3, x1
    //     0x8ef8cc: mov             x1, x16
    //     0x8ef8d0: stur            x2, [fp, #-0x18]
    //     0x8ef8d4: stur            x1, [fp, #-0x20]
    // 0x8ef8d8: CheckStackOverflow
    //     0x8ef8d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ef8dc: cmp             SP, x16
    //     0x8ef8e0: b.ls            #0x8efa30
    // 0x8ef8e4: InitAsync() -> Future
    //     0x8ef8e4: mov             x0, NULL
    //     0x8ef8e8: bl              #0x7f5e44  ; InitAsyncStub
    // 0x8ef8ec: ldur            x3, [fp, #-0x18]
    // 0x8ef8f0: LoadField: r4 = r3->field_23
    //     0x8ef8f0: ldur            w4, [x3, #0x23]
    // 0x8ef8f4: DecompressPointer r4
    //     0x8ef8f4: add             x4, x4, HEAP, lsl #32
    // 0x8ef8f8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8ef8fc: cmp             w4, w16
    // 0x8ef900: b.eq            #0x8efa38
    // 0x8ef904: stur            x4, [fp, #-0x28]
    // 0x8ef908: r16 = Instance_ResponseType
    //     0x8ef908: add             x16, PP, #0x15, lsl #12  ; [pp+0x15ef0] Obj!ResponseType@12c6401
    //     0x8ef90c: ldr             x16, [x16, #0xef0]
    // 0x8ef910: cmp             w4, w16
    // 0x8ef914: b.ne            #0x8ef920
    // 0x8ef918: ldur            x0, [fp, #-0x20]
    // 0x8ef91c: r0 = ReturnAsyncNotFuture()
    //     0x8ef91c: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x8ef920: r16 = Instance_ResponseType
    //     0x8ef920: add             x16, PP, #0x15, lsl #12  ; [pp+0x15ee8] Obj!ResponseType@12c6421
    //     0x8ef924: ldr             x16, [x16, #0xee8]
    // 0x8ef928: cmp             w4, w16
    // 0x8ef92c: b.ne            #0x8ef944
    // 0x8ef930: ldur            x5, [fp, #-0x20]
    // 0x8ef934: LoadField: r1 = r5->field_b
    //     0x8ef934: ldur            w1, [x5, #0xb]
    // 0x8ef938: DecompressPointer r1
    //     0x8ef938: add             x1, x1, HEAP, lsl #32
    // 0x8ef93c: r0 = consolidateBytes()
    //     0x8ef93c: bl              #0x8f3c64  ; [package:dio/src/transformers/util/consolidate_bytes.dart] ::consolidateBytes
    // 0x8ef940: r0 = ReturnAsync()
    //     0x8ef940: b               #0x82fdf0  ; ReturnAsyncStub
    // 0x8ef944: ldur            x5, [fp, #-0x20]
    // 0x8ef948: LoadField: r1 = r5->field_1f
    //     0x8ef948: ldur            w1, [x5, #0x1f]
    // 0x8ef94c: DecompressPointer r1
    //     0x8ef94c: add             x1, x1, HEAP, lsl #32
    // 0x8ef950: r0 = LoadClassIdInstr(r1)
    //     0x8ef950: ldur            x0, [x1, #-1]
    //     0x8ef954: ubfx            x0, x0, #0xc, #0x14
    // 0x8ef958: r2 = "content-type"
    //     0x8ef958: add             x2, PP, #8, lsl #12  ; [pp+0x85d8] "content-type"
    //     0x8ef95c: ldr             x2, [x2, #0x5d8]
    // 0x8ef960: r0 = GDT[cid_x0 + -0xd48]()
    //     0x8ef960: sub             lr, x0, #0xd48
    //     0x8ef964: ldr             lr, [x21, lr, lsl #3]
    //     0x8ef968: blr             lr
    // 0x8ef96c: cmp             w0, NULL
    // 0x8ef970: b.ne            #0x8ef97c
    // 0x8ef974: r1 = Null
    //     0x8ef974: mov             x1, NULL
    // 0x8ef978: b               #0x8ef9a8
    // 0x8ef97c: r1 = LoadClassIdInstr(r0)
    //     0x8ef97c: ldur            x1, [x0, #-1]
    //     0x8ef980: ubfx            x1, x1, #0xc, #0x14
    // 0x8ef984: mov             x16, x0
    // 0x8ef988: mov             x0, x1
    // 0x8ef98c: mov             x1, x16
    // 0x8ef990: r0 = GDT[cid_x0 + 0x127b5]()
    //     0x8ef990: mov             x17, #0x27b5
    //     0x8ef994: movk            x17, #1, lsl #16
    //     0x8ef998: add             lr, x0, x17
    //     0x8ef99c: ldr             lr, [x21, lr, lsl #3]
    //     0x8ef9a0: blr             lr
    // 0x8ef9a4: mov             x1, x0
    // 0x8ef9a8: r0 = isJsonMimeType()
    //     0x8ef9a8: bl              #0x8f19d8  ; [package:dio/src/transformer.dart] Transformer::isJsonMimeType
    // 0x8ef9ac: tbnz            w0, #4, #0x8ef9d4
    // 0x8ef9b0: ldur            x0, [fp, #-0x28]
    // 0x8ef9b4: r16 = Instance_ResponseType
    //     0x8ef9b4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15d98] Obj!ResponseType@12c63c1
    //     0x8ef9b8: ldr             x16, [x16, #0xd98]
    // 0x8ef9bc: cmp             w0, w16
    // 0x8ef9c0: r16 = true
    //     0x8ef9c0: add             x16, NULL, #0x20  ; true
    // 0x8ef9c4: r17 = false
    //     0x8ef9c4: add             x17, NULL, #0x30  ; false
    // 0x8ef9c8: csel            x1, x16, x17, eq
    // 0x8ef9cc: mov             x0, x1
    // 0x8ef9d0: b               #0x8ef9d8
    // 0x8ef9d4: r0 = false
    //     0x8ef9d4: add             x0, NULL, #0x30  ; false
    // 0x8ef9d8: stur            x0, [fp, #-0x28]
    // 0x8ef9dc: tbnz            w0, #4, #0x8ef9f4
    // 0x8ef9e0: ldur            x1, [fp, #-0x10]
    // 0x8ef9e4: ldur            x2, [fp, #-0x18]
    // 0x8ef9e8: ldur            x3, [fp, #-0x20]
    // 0x8ef9ec: r0 = _fastUtf8JsonDecode()
    //     0x8ef9ec: bl              #0x8efa44  ; [package:dio/src/transformers/fused_transformer.dart] FusedTransformer::_fastUtf8JsonDecode
    // 0x8ef9f0: r0 = ReturnAsync()
    //     0x8ef9f0: b               #0x82fdf0  ; ReturnAsyncStub
    // 0x8ef9f4: ldur            x1, [fp, #-0x20]
    // 0x8ef9f8: LoadField: r2 = r1->field_b
    //     0x8ef9f8: ldur            w2, [x1, #0xb]
    // 0x8ef9fc: DecompressPointer r2
    //     0x8ef9fc: add             x2, x2, HEAP, lsl #32
    // 0x8efa00: mov             x1, x2
    // 0x8efa04: r0 = consolidateBytes()
    //     0x8efa04: bl              #0x8f3c64  ; [package:dio/src/transformers/util/consolidate_bytes.dart] ::consolidateBytes
    // 0x8efa08: mov             x1, x0
    // 0x8efa0c: stur            x1, [fp, #-0x10]
    // 0x8efa10: r0 = Await()
    //     0x8efa10: bl              #0x7f5c00  ; AwaitStub
    // 0x8efa14: r16 = true
    //     0x8efa14: add             x16, NULL, #0x20  ; true
    // 0x8efa18: str             x16, [SP]
    // 0x8efa1c: mov             x2, x0
    // 0x8efa20: r1 = Instance_Utf8Codec
    //     0x8efa20: ldr             x1, [PP, #0x11e0]  ; [pp+0x11e0] Obj!Utf8Codec@12b7e61
    // 0x8efa24: r4 = const [0, 0x3, 0x1, 0x2, allowMalformed, 0x2, null]
    //     0x8efa24: ldr             x4, [PP, #0x36a0]  ; [pp+0x36a0] List(7) [0, 0x3, 0x1, 0x2, "allowMalformed", 0x2, Null]
    // 0x8efa28: r0 = decode()
    //     0x8efa28: bl              #0x121a094  ; [dart:convert] Utf8Codec::decode
    // 0x8efa2c: r0 = ReturnAsyncNotFuture()
    //     0x8efa2c: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x8efa30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8efa30: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8efa34: b               #0x8ef8e4
    // 0x8efa38: r9 = responseType
    //     0x8efa38: add             x9, PP, #0x15, lsl #12  ; [pp+0x15f58] Field <_RequestConfig@271184022.responseType>: late (offset: 0x24)
    //     0x8efa3c: ldr             x9, [x9, #0xf58]
    // 0x8efa40: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8efa40: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _fastUtf8JsonDecode(/* No info */) async {
    // ** addr: 0x8efa44, size: 0x2e0
    // 0x8efa44: EnterFrame
    //     0x8efa44: stp             fp, lr, [SP, #-0x10]!
    //     0x8efa48: mov             fp, SP
    // 0x8efa4c: AllocStack(0xe8)
    //     0x8efa4c: sub             SP, SP, #0xe8
    // 0x8efa50: SetupParameters(FusedTransformer this /* r1 => r1, fp-0xa8 */, dynamic _ /* r2 => r2, fp-0xb0 */, dynamic _ /* r3 => r3, fp-0xb8 */)
    //     0x8efa50: stur            NULL, [fp, #-8]
    //     0x8efa54: stur            x1, [fp, #-0xa8]
    //     0x8efa58: stur            x2, [fp, #-0xb0]
    //     0x8efa5c: stur            x3, [fp, #-0xb8]
    // 0x8efa60: CheckStackOverflow
    //     0x8efa60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8efa64: cmp             SP, x16
    //     0x8efa68: b.ls            #0x8efd1c
    // 0x8efa6c: InitAsync() -> Future<Object?>
    //     0x8efa6c: ldr             x0, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    //     0x8efa70: bl              #0x7f5e44  ; InitAsyncStub
    // 0x8efa74: ldur            x3, [fp, #-0xb8]
    // 0x8efa78: LoadField: r1 = r3->field_1f
    //     0x8efa78: ldur            w1, [x3, #0x1f]
    // 0x8efa7c: DecompressPointer r1
    //     0x8efa7c: add             x1, x1, HEAP, lsl #32
    // 0x8efa80: r0 = LoadClassIdInstr(r1)
    //     0x8efa80: ldur            x0, [x1, #-1]
    //     0x8efa84: ubfx            x0, x0, #0xc, #0x14
    // 0x8efa88: r2 = "content-length"
    //     0x8efa88: add             x2, PP, #0xb, lsl #12  ; [pp+0xba48] "content-length"
    //     0x8efa8c: ldr             x2, [x2, #0xa48]
    // 0x8efa90: r0 = GDT[cid_x0 + -0xd48]()
    //     0x8efa90: sub             lr, x0, #0xd48
    //     0x8efa94: ldr             lr, [x21, lr, lsl #3]
    //     0x8efa98: blr             lr
    // 0x8efa9c: mov             x2, x0
    // 0x8efaa0: stur            x2, [fp, #-0xc0]
    // 0x8efaa4: cmp             w2, NULL
    // 0x8efaa8: b.eq            #0x8efb08
    // 0x8efaac: r0 = LoadClassIdInstr(r2)
    //     0x8efaac: ldur            x0, [x2, #-1]
    //     0x8efab0: ubfx            x0, x0, #0xc, #0x14
    // 0x8efab4: mov             x1, x2
    // 0x8efab8: r0 = GDT[cid_x0 + 0x131a1]()
    //     0x8efab8: mov             x17, #0x31a1
    //     0x8efabc: movk            x17, #1, lsl #16
    //     0x8efac0: add             lr, x0, x17
    //     0x8efac4: ldr             lr, [x21, lr, lsl #3]
    //     0x8efac8: blr             lr
    // 0x8efacc: tbnz            w0, #4, #0x8efb08
    // 0x8efad0: ldur            x1, [fp, #-0xc0]
    // 0x8efad4: r0 = LoadClassIdInstr(r1)
    //     0x8efad4: ldur            x0, [x1, #-1]
    //     0x8efad8: ubfx            x0, x0, #0xc, #0x14
    // 0x8efadc: r0 = GDT[cid_x0 + 0x127b5]()
    //     0x8efadc: mov             x17, #0x27b5
    //     0x8efae0: movk            x17, #1, lsl #16
    //     0x8efae4: add             lr, x0, x17
    //     0x8efae8: ldr             lr, [x21, lr, lsl #3]
    //     0x8efaec: blr             lr
    // 0x8efaf0: mov             x1, x0
    // 0x8efaf4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8efaf4: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8efaf8: r0 = parse()
    //     0x8efaf8: bl              #0x8220cc  ; [dart:core] int::parse
    // 0x8efafc: mov             x2, x0
    // 0x8efb00: r1 = Null
    //     0x8efb00: mov             x1, NULL
    // 0x8efb04: b               #0x8efb30
    // 0x8efb08: ldur            x0, [fp, #-0xb8]
    // 0x8efb0c: LoadField: r1 = r0->field_b
    //     0x8efb0c: ldur            w1, [x0, #0xb]
    // 0x8efb10: DecompressPointer r1
    //     0x8efb10: add             x1, x1, HEAP, lsl #32
    // 0x8efb14: r0 = consolidateBytes()
    //     0x8efb14: bl              #0x8f3c64  ; [package:dio/src/transformers/util/consolidate_bytes.dart] ::consolidateBytes
    // 0x8efb18: mov             x1, x0
    // 0x8efb1c: stur            x1, [fp, #-0xc0]
    // 0x8efb20: r0 = Await()
    //     0x8efb20: bl              #0x7f5c00  ; AwaitStub
    // 0x8efb24: LoadField: r1 = r0->field_13
    //     0x8efb24: ldur            w1, [x0, #0x13]
    // 0x8efb28: r2 = LoadInt32Instr(r1)
    //     0x8efb28: sbfx            x2, x1, #1, #0x1f
    // 0x8efb2c: mov             x1, x0
    // 0x8efb30: ldur            x0, [fp, #-0xa8]
    // 0x8efb34: stur            x1, [fp, #-0xc0]
    // 0x8efb38: LoadField: r3 = r0->field_7
    //     0x8efb38: ldur            x3, [x0, #7]
    // 0x8efb3c: tbnz            x3, #0x3f, #0x8efbc0
    // 0x8efb40: cmp             x2, x3
    // 0x8efb44: b.lt            #0x8efbc0
    // 0x8efb48: cmp             w1, NULL
    // 0x8efb4c: b.ne            #0x8efb70
    // 0x8efb50: ldur            x0, [fp, #-0xb8]
    // 0x8efb54: LoadField: r1 = r0->field_b
    //     0x8efb54: ldur            w1, [x0, #0xb]
    // 0x8efb58: DecompressPointer r1
    //     0x8efb58: add             x1, x1, HEAP, lsl #32
    // 0x8efb5c: r0 = consolidateBytes()
    //     0x8efb5c: bl              #0x8f3c64  ; [package:dio/src/transformers/util/consolidate_bytes.dart] ::consolidateBytes
    // 0x8efb60: mov             x1, x0
    // 0x8efb64: stur            x1, [fp, #-0xa8]
    // 0x8efb68: r0 = Await()
    //     0x8efb68: bl              #0x7f5c00  ; AwaitStub
    // 0x8efb6c: mov             x1, x0
    // 0x8efb70: stur            x1, [fp, #-0xa8]
    // 0x8efb74: r16 = <Uint8List, Object?>
    //     0x8efb74: add             x16, PP, #0x16, lsl #12  ; [pp+0x160f0] TypeArguments: <Uint8List, Object?>
    //     0x8efb78: ldr             x16, [x16, #0xf0]
    // 0x8efb7c: r30 = Closure: <Y0, Y1>((Y0) => FutureOr<Y1>, Y0, {String? debugLabel, Duration? timeout}) => Future<Y1> from Function 'computeWithTimeout': static.
    //     0x8efb7c: add             lr, PP, #0x16, lsl #12  ; [pp+0x160f8] Closure: <Y0, Y1>((Y0) => FutureOr<Y1>, Y0, {String? debugLabel, Duration? timeout}) => Future<Y1> from Function 'computeWithTimeout': static. (0x7f2ada7d70f4)
    //     0x8efb80: ldr             lr, [lr, #0xf8]
    // 0x8efb84: stp             lr, x16, [SP, #0x18]
    // 0x8efb88: r16 = Closure: (Uint8List) => Future<Object?> from Function '_decodeUtf8ToJson@379206049': static.
    //     0x8efb88: add             x16, PP, #0x16, lsl #12  ; [pp+0x16100] Closure: (Uint8List) => Future<Object?> from Function '_decodeUtf8ToJson@379206049': static. (0x7f2ada7d6ffc)
    //     0x8efb8c: ldr             x16, [x16, #0x100]
    // 0x8efb90: stp             x1, x16, [SP, #8]
    // 0x8efb94: str             NULL, [SP]
    // 0x8efb98: r0 = Closure: <Y0, Y1>((Y0) => FutureOr<Y1>, Y0, {String? debugLabel, Duration? timeout}) => Future<Y1> from Function 'computeWithTimeout': static.
    //     0x8efb98: add             x0, PP, #0x16, lsl #12  ; [pp+0x160f8] Closure: <Y0, Y1>((Y0) => FutureOr<Y1>, Y0, {String? debugLabel, Duration? timeout}) => Future<Y1> from Function 'computeWithTimeout': static. (0x7f2ada7d70f4)
    //     0x8efb9c: ldr             x0, [x0, #0xf8]
    // 0x8efba0: ClosureCall
    //     0x8efba0: add             x4, PP, #0x16, lsl #12  ; [pp+0x16108] List(7) [0x2, 0x4, 0x4, 0x3, "timeout", 0x3, Null]
    //     0x8efba4: ldr             x4, [x4, #0x108]
    //     0x8efba8: ldur            x2, [x0, #0x1f]
    //     0x8efbac: blr             x2
    // 0x8efbb0: mov             x1, x0
    // 0x8efbb4: stur            x1, [fp, #-0xb0]
    // 0x8efbb8: r0 = Await()
    //     0x8efbb8: bl              #0x7f5c00  ; AwaitStub
    // 0x8efbbc: r0 = ReturnAsync()
    //     0x8efbbc: b               #0x82fdf0  ; ReturnAsyncStub
    // 0x8efbc0: cmp             w1, NULL
    // 0x8efbc4: b.eq            #0x8efc24
    // 0x8efbc8: LoadField: r0 = r1->field_13
    //     0x8efbc8: ldur            w0, [x1, #0x13]
    // 0x8efbcc: cbnz            w0, #0x8efbd8
    // 0x8efbd0: r0 = Null
    //     0x8efbd0: mov             x0, NULL
    // 0x8efbd4: r0 = ReturnAsyncNotFuture()
    //     0x8efbd4: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x8efbd8: r0 = LoadStaticField(0xb24)
    //     0x8efbd8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8efbdc: ldr             x0, [x0, #0x1648]
    // 0x8efbe0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8efbe4: cmp             w0, w16
    // 0x8efbe8: b.ne            #0x8efbf8
    // 0x8efbec: r2 = _utf8JsonDecoder
    //     0x8efbec: add             x2, PP, #0x16, lsl #12  ; [pp+0x16110] Field <FusedTransformer._utf8JsonDecoder@379206049>: static late final (offset: 0xb24)
    //     0x8efbf0: ldr             x2, [x2, #0x110]
    // 0x8efbf4: r0 = InitLateFinalStaticField()
    //     0x8efbf4: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8efbf8: r1 = LoadClassIdInstr(r0)
    //     0x8efbf8: ldur            x1, [x0, #-1]
    //     0x8efbfc: ubfx            x1, x1, #0xc, #0x14
    // 0x8efc00: mov             x16, x0
    // 0x8efc04: mov             x0, x1
    // 0x8efc08: mov             x1, x16
    // 0x8efc0c: ldur            x2, [fp, #-0xc0]
    // 0x8efc10: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8efc10: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8efc14: r0 = GDT[cid_x0 + 0xaef]()
    //     0x8efc14: add             lr, x0, #0xaef
    //     0x8efc18: ldr             lr, [x21, lr, lsl #3]
    //     0x8efc1c: blr             lr
    // 0x8efc20: r0 = ReturnAsync()
    //     0x8efc20: b               #0x82fdf0  ; ReturnAsyncStub
    // 0x8efc24: ldur            x0, [fp, #-0xb8]
    // 0x8efc28: LoadField: r1 = r0->field_b
    //     0x8efc28: ldur            w1, [x0, #0xb]
    // 0x8efc2c: DecompressPointer r1
    //     0x8efc2c: add             x1, x1, HEAP, lsl #32
    // 0x8efc30: r16 = <Uint8List>
    //     0x8efc30: add             x16, PP, #8, lsl #12  ; [pp+0x8548] TypeArguments: <Uint8List>
    //     0x8efc34: ldr             x16, [x16, #0x548]
    // 0x8efc38: stp             x1, x16, [SP, #8]
    // 0x8efc3c: r16 = Instance_DefaultNullIfEmptyStreamTransformer
    //     0x8efc3c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16118] Obj!DefaultNullIfEmptyStreamTransformer@12b8201
    //     0x8efc40: ldr             x16, [x16, #0x118]
    // 0x8efc44: str             x16, [SP]
    // 0x8efc48: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8efc48: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8efc4c: r0 = transform()
    //     0x8efc4c: bl              #0x819be0  ; [dart:async] Stream::transform
    // 0x8efc50: stur            x0, [fp, #-0xa8]
    // 0x8efc54: r0 = LoadStaticField(0xb24)
    //     0x8efc54: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8efc58: ldr             x0, [x0, #0x1648]
    // 0x8efc5c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8efc60: cmp             w0, w16
    // 0x8efc64: b.ne            #0x8efc74
    // 0x8efc68: r2 = _utf8JsonDecoder
    //     0x8efc68: add             x2, PP, #0x16, lsl #12  ; [pp+0x16110] Field <FusedTransformer._utf8JsonDecoder@379206049>: static late final (offset: 0xb24)
    //     0x8efc6c: ldr             x2, [x2, #0x110]
    // 0x8efc70: r0 = InitLateFinalStaticField()
    //     0x8efc70: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8efc74: mov             x1, x0
    // 0x8efc78: ldur            x2, [fp, #-0xa8]
    // 0x8efc7c: r0 = bind()
    //     0x8efc7c: bl              #0x11fdc64  ; [dart:convert] Converter::bind
    // 0x8efc80: mov             x1, x0
    // 0x8efc84: r0 = toList()
    //     0x8efc84: bl              #0x8efd24  ; [dart:async] Stream::toList
    // 0x8efc88: mov             x1, x0
    // 0x8efc8c: stur            x1, [fp, #-0xa8]
    // 0x8efc90: r0 = Await()
    //     0x8efc90: bl              #0x7f5c00  ; AwaitStub
    // 0x8efc94: mov             x2, x0
    // 0x8efc98: stur            x2, [fp, #-0xa8]
    // 0x8efc9c: r0 = LoadClassIdInstr(r2)
    //     0x8efc9c: ldur            x0, [x2, #-1]
    //     0x8efca0: ubfx            x0, x0, #0xc, #0x14
    // 0x8efca4: mov             x1, x2
    // 0x8efca8: r0 = GDT[cid_x0 + 0x12b36]()
    //     0x8efca8: mov             x17, #0x2b36
    //     0x8efcac: movk            x17, #1, lsl #16
    //     0x8efcb0: add             lr, x0, x17
    //     0x8efcb4: ldr             lr, [x21, lr, lsl #3]
    //     0x8efcb8: blr             lr
    // 0x8efcbc: tbnz            w0, #4, #0x8efcc8
    // 0x8efcc0: r0 = Null
    //     0x8efcc0: mov             x0, NULL
    // 0x8efcc4: r0 = ReturnAsyncNotFuture()
    //     0x8efcc4: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x8efcc8: ldur            x1, [fp, #-0xa8]
    // 0x8efccc: r0 = LoadClassIdInstr(r1)
    //     0x8efccc: ldur            x0, [x1, #-1]
    //     0x8efcd0: ubfx            x0, x0, #0xc, #0x14
    // 0x8efcd4: r0 = GDT[cid_x0 + 0x127b5]()
    //     0x8efcd4: mov             x17, #0x27b5
    //     0x8efcd8: movk            x17, #1, lsl #16
    //     0x8efcdc: add             lr, x0, x17
    //     0x8efce0: ldr             lr, [x21, lr, lsl #3]
    //     0x8efce4: blr             lr
    // 0x8efce8: r0 = ReturnAsync()
    //     0x8efce8: b               #0x82fdf0  ; ReturnAsyncStub
    // 0x8efcec: sub             SP, fp, #0xe8
    // 0x8efcf0: r2 = 60
    //     0x8efcf0: mov             x2, #0x3c
    // 0x8efcf4: branchIfSmi(r0, 0x8efd00)
    //     0x8efcf4: tbz             w0, #0, #0x8efd00
    // 0x8efcf8: r2 = LoadClassIdInstr(r0)
    //     0x8efcf8: ldur            x2, [x0, #-1]
    //     0x8efcfc: ubfx            x2, x2, #0xc, #0x14
    // 0x8efd00: r17 = 7559
    //     0x8efd00: mov             x17, #0x1d87
    // 0x8efd04: cmp             x2, x17
    // 0x8efd08: b.ne            #0x8efd14
    // 0x8efd0c: r0 = ReThrow()
    //     0x8efd0c: bl              #0x13ddb00  ; ReThrowStub
    // 0x8efd10: brk             #0
    // 0x8efd14: r0 = ReThrow()
    //     0x8efd14: bl              #0x13ddb00  ; ReThrowStub
    // 0x8efd18: brk             #0
    // 0x8efd1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8efd1c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8efd20: b               #0x8efa6c
  }
  static Converter<List<int>, Object?> _utf8JsonDecoder() {
    // ** addr: 0x8effc8, size: 0x28
    // 0x8effc8: EnterFrame
    //     0x8effc8: stp             fp, lr, [SP, #-0x10]!
    //     0x8effcc: mov             fp, SP
    // 0x8effd0: r1 = <List<int>, Object?>
    //     0x8effd0: add             x1, PP, #0x16, lsl #12  ; [pp+0x162a0] TypeArguments: <List<int>, Object?>
    //     0x8effd4: ldr             x1, [x1, #0x2a0]
    // 0x8effd8: r0 = _JsonUtf8Decoder()
    //     0x8effd8: bl              #0x8efff0  ; Allocate_JsonUtf8DecoderStub -> _JsonUtf8Decoder (size=0x14)
    // 0x8effdc: r1 = false
    //     0x8effdc: add             x1, NULL, #0x30  ; false
    // 0x8effe0: StoreField: r0->field_f = r1
    //     0x8effe0: stur            w1, [x0, #0xf]
    // 0x8effe4: LeaveFrame
    //     0x8effe4: mov             SP, fp
    //     0x8effe8: ldp             fp, lr, [SP], #0x10
    // 0x8effec: ret
    //     0x8effec: ret             
  }
  [closure] static Future<Object?> _decodeUtf8ToJson(dynamic, Uint8List) {
    // ** addr: 0x8efffc, size: 0x30
    // 0x8efffc: EnterFrame
    //     0x8efffc: stp             fp, lr, [SP, #-0x10]!
    //     0x8f0000: mov             fp, SP
    // 0x8f0004: CheckStackOverflow
    //     0x8f0004: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f0008: cmp             SP, x16
    //     0x8f000c: b.ls            #0x8f0024
    // 0x8f0010: ldr             x1, [fp, #0x10]
    // 0x8f0014: r0 = _decodeUtf8ToJson()
    //     0x8f0014: bl              #0x8f002c  ; [package:dio/src/transformers/fused_transformer.dart] FusedTransformer::_decodeUtf8ToJson
    // 0x8f0018: LeaveFrame
    //     0x8f0018: mov             SP, fp
    //     0x8f001c: ldp             fp, lr, [SP], #0x10
    // 0x8f0020: ret
    //     0x8f0020: ret             
    // 0x8f0024: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f0024: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f0028: b               #0x8f0010
  }
  static _ _decodeUtf8ToJson(/* No info */) async {
    // ** addr: 0x8f002c, size: 0x94
    // 0x8f002c: EnterFrame
    //     0x8f002c: stp             fp, lr, [SP, #-0x10]!
    //     0x8f0030: mov             fp, SP
    // 0x8f0034: AllocStack(0x10)
    //     0x8f0034: sub             SP, SP, #0x10
    // 0x8f0038: SetupParameters(dynamic _ /* r1 => r2, fp-0x10 */)
    //     0x8f0038: stur            NULL, [fp, #-8]
    //     0x8f003c: mov             x2, x1
    //     0x8f0040: stur            x1, [fp, #-0x10]
    // 0x8f0044: CheckStackOverflow
    //     0x8f0044: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f0048: cmp             SP, x16
    //     0x8f004c: b.ls            #0x8f00b8
    // 0x8f0050: InitAsync() -> Future<Object?>
    //     0x8f0050: ldr             x0, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    //     0x8f0054: bl              #0x7f5e44  ; InitAsyncStub
    // 0x8f0058: ldur            x2, [fp, #-0x10]
    // 0x8f005c: LoadField: r0 = r2->field_13
    //     0x8f005c: ldur            w0, [x2, #0x13]
    // 0x8f0060: cbnz            w0, #0x8f006c
    // 0x8f0064: r0 = Null
    //     0x8f0064: mov             x0, NULL
    // 0x8f0068: r0 = ReturnAsyncNotFuture()
    //     0x8f0068: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x8f006c: r0 = LoadStaticField(0xb24)
    //     0x8f006c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8f0070: ldr             x0, [x0, #0x1648]
    // 0x8f0074: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8f0078: cmp             w0, w16
    // 0x8f007c: b.ne            #0x8f008c
    // 0x8f0080: r2 = _utf8JsonDecoder
    //     0x8f0080: add             x2, PP, #0x16, lsl #12  ; [pp+0x16110] Field <FusedTransformer._utf8JsonDecoder@379206049>: static late final (offset: 0xb24)
    //     0x8f0084: ldr             x2, [x2, #0x110]
    // 0x8f0088: r0 = InitLateFinalStaticField()
    //     0x8f0088: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8f008c: r1 = LoadClassIdInstr(r0)
    //     0x8f008c: ldur            x1, [x0, #-1]
    //     0x8f0090: ubfx            x1, x1, #0xc, #0x14
    // 0x8f0094: mov             x16, x0
    // 0x8f0098: mov             x0, x1
    // 0x8f009c: mov             x1, x16
    // 0x8f00a0: ldur            x2, [fp, #-0x10]
    // 0x8f00a4: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8f00a4: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8f00a8: r0 = GDT[cid_x0 + 0xaef]()
    //     0x8f00a8: add             lr, x0, #0xaef
    //     0x8f00ac: ldr             lr, [x21, lr, lsl #3]
    //     0x8f00b0: blr             lr
    // 0x8f00b4: r0 = ReturnAsync()
    //     0x8f00b4: b               #0x82fdf0  ; ReturnAsyncStub
    // 0x8f00b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f00b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f00bc: b               #0x8f0050
  }
  _ transformRequest(/* No info */) async {
    // ** addr: 0x90f544, size: 0x4c
    // 0x90f544: EnterFrame
    //     0x90f544: stp             fp, lr, [SP, #-0x10]!
    //     0x90f548: mov             fp, SP
    // 0x90f54c: AllocStack(0x18)
    //     0x90f54c: sub             SP, SP, #0x18
    // 0x90f550: SetupParameters(FusedTransformer this /* r1 => r2, fp-0x10 */, dynamic _ /* r2 => r1, fp-0x18 */)
    //     0x90f550: stur            NULL, [fp, #-8]
    //     0x90f554: stur            x1, [fp, #-0x10]
    //     0x90f558: mov             x16, x2
    //     0x90f55c: mov             x2, x1
    //     0x90f560: mov             x1, x16
    //     0x90f564: stur            x1, [fp, #-0x18]
    // 0x90f568: CheckStackOverflow
    //     0x90f568: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x90f56c: cmp             SP, x16
    //     0x90f570: b.ls            #0x90f588
    // 0x90f574: InitAsync() -> Future<String>
    //     0x90f574: ldr             x0, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    //     0x90f578: bl              #0x7f5e44  ; InitAsyncStub
    // 0x90f57c: ldur            x1, [fp, #-0x18]
    // 0x90f580: r0 = defaultTransformRequest()
    //     0x90f580: bl              #0x90f590  ; [package:dio/src/transformer.dart] Transformer::defaultTransformRequest
    // 0x90f584: r0 = ReturnAsync()
    //     0x90f584: b               #0x82fdf0  ; ReturnAsyncStub
    // 0x90f588: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x90f588: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x90f58c: b               #0x90f574
  }
}
