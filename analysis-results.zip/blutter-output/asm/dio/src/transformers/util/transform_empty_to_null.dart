// lib: , url: package:dio/src/transformers/util/transform_empty_to_null.dart

// class id: 1048716, size: 0x8
class :: {
}

// class id: 3396, size: 0x10, field offset: 0x8
class _DefaultIfEmptyStreamSink extends Object
    implements EventSink<X0> {

  static late final Uint8List _nullUtf8Value; // offset: 0x1090

  _ add(/* No info */) {
    // ** addr: 0x8db31c, size: 0xdc
    // 0x8db31c: EnterFrame
    //     0x8db31c: stp             fp, lr, [SP, #-0x10]!
    //     0x8db320: mov             fp, SP
    // 0x8db324: AllocStack(0x10)
    //     0x8db324: sub             SP, SP, #0x10
    // 0x8db328: SetupParameters(_DefaultIfEmptyStreamSink this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x8db328: mov             x4, x1
    //     0x8db32c: mov             x3, x2
    //     0x8db330: stur            x1, [fp, #-8]
    //     0x8db334: stur            x2, [fp, #-0x10]
    // 0x8db338: CheckStackOverflow
    //     0x8db338: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8db33c: cmp             SP, x16
    //     0x8db340: b.ls            #0x8db3f0
    // 0x8db344: mov             x0, x3
    // 0x8db348: r2 = Null
    //     0x8db348: mov             x2, NULL
    // 0x8db34c: r1 = Null
    //     0x8db34c: mov             x1, NULL
    // 0x8db350: r4 = 60
    //     0x8db350: mov             x4, #0x3c
    // 0x8db354: branchIfSmi(r0, 0x8db360)
    //     0x8db354: tbz             w0, #0, #0x8db360
    // 0x8db358: r4 = LoadClassIdInstr(r0)
    //     0x8db358: ldur            x4, [x0, #-1]
    //     0x8db35c: ubfx            x4, x4, #0xc, #0x14
    // 0x8db360: sub             x4, x4, #0x74
    // 0x8db364: cmp             x4, #3
    // 0x8db368: b.ls            #0x8db380
    // 0x8db36c: r8 = Uint8List
    //     0x8db36c: add             x8, PP, #0xc, lsl #12  ; [pp+0xc840] Type: Uint8List
    //     0x8db370: ldr             x8, [x8, #0x840]
    // 0x8db374: r3 = Null
    //     0x8db374: add             x3, PP, #0x8a, lsl #12  ; [pp+0x8af70] Null
    //     0x8db378: ldr             x3, [x3, #0xf70]
    // 0x8db37c: r0 = Uint8List()
    //     0x8db37c: bl              #0x7de36c  ; IsType_Uint8List_Stub
    // 0x8db380: ldur            x0, [fp, #-8]
    // 0x8db384: LoadField: r1 = r0->field_b
    //     0x8db384: ldur            w1, [x0, #0xb]
    // 0x8db388: DecompressPointer r1
    //     0x8db388: add             x1, x1, HEAP, lsl #32
    // 0x8db38c: tbnz            w1, #4, #0x8db39c
    // 0x8db390: ldur            x2, [fp, #-0x10]
    // 0x8db394: r1 = true
    //     0x8db394: add             x1, NULL, #0x20  ; true
    // 0x8db398: b               #0x8db3b8
    // 0x8db39c: ldur            x2, [fp, #-0x10]
    // 0x8db3a0: LoadField: r1 = r2->field_13
    //     0x8db3a0: ldur            w1, [x2, #0x13]
    // 0x8db3a4: cbnz            w1, #0x8db3b0
    // 0x8db3a8: r3 = false
    //     0x8db3a8: add             x3, NULL, #0x30  ; false
    // 0x8db3ac: b               #0x8db3b4
    // 0x8db3b0: r3 = true
    //     0x8db3b0: add             x3, NULL, #0x20  ; true
    // 0x8db3b4: mov             x1, x3
    // 0x8db3b8: StoreField: r0->field_b = r1
    //     0x8db3b8: stur            w1, [x0, #0xb]
    // 0x8db3bc: LoadField: r1 = r0->field_7
    //     0x8db3bc: ldur            w1, [x0, #7]
    // 0x8db3c0: DecompressPointer r1
    //     0x8db3c0: add             x1, x1, HEAP, lsl #32
    // 0x8db3c4: r0 = LoadClassIdInstr(r1)
    //     0x8db3c4: ldur            x0, [x1, #-1]
    //     0x8db3c8: ubfx            x0, x0, #0xc, #0x14
    // 0x8db3cc: r0 = GDT[cid_x0 + 0x1847a]()
    //     0x8db3cc: mov             x17, #0x847a
    //     0x8db3d0: movk            x17, #1, lsl #16
    //     0x8db3d4: add             lr, x0, x17
    //     0x8db3d8: ldr             lr, [x21, lr, lsl #3]
    //     0x8db3dc: blr             lr
    // 0x8db3e0: r0 = Null
    //     0x8db3e0: mov             x0, NULL
    // 0x8db3e4: LeaveFrame
    //     0x8db3e4: mov             SP, fp
    //     0x8db3e8: ldp             fp, lr, [SP], #0x10
    // 0x8db3ec: ret
    //     0x8db3ec: ret             
    // 0x8db3f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8db3f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8db3f4: b               #0x8db344
  }
  [closure] void add(dynamic, Object?) {
    // ** addr: 0x8db3f8, size: 0x3c
    // 0x8db3f8: EnterFrame
    //     0x8db3f8: stp             fp, lr, [SP, #-0x10]!
    //     0x8db3fc: mov             fp, SP
    // 0x8db400: ldr             x0, [fp, #0x18]
    // 0x8db404: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8db404: ldur            w1, [x0, #0x17]
    // 0x8db408: DecompressPointer r1
    //     0x8db408: add             x1, x1, HEAP, lsl #32
    // 0x8db40c: CheckStackOverflow
    //     0x8db40c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8db410: cmp             SP, x16
    //     0x8db414: b.ls            #0x8db42c
    // 0x8db418: ldr             x2, [fp, #0x10]
    // 0x8db41c: r0 = add()
    //     0x8db41c: bl              #0x8db31c  ; [package:dio/src/transformers/util/transform_empty_to_null.dart] _DefaultIfEmptyStreamSink::add
    // 0x8db420: LeaveFrame
    //     0x8db420: mov             SP, fp
    //     0x8db424: ldp             fp, lr, [SP], #0x10
    // 0x8db428: ret
    //     0x8db428: ret             
    // 0x8db42c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8db42c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8db430: b               #0x8db418
  }
  dynamic add(dynamic) {
    // ** addr: 0x8db458, size: 0x24
    // 0x8db458: EnterFrame
    //     0x8db458: stp             fp, lr, [SP, #-0x10]!
    //     0x8db45c: mov             fp, SP
    // 0x8db460: ldr             x2, [fp, #0x10]
    // 0x8db464: r1 = Function 'add':.
    //     0x8db464: add             x1, PP, #0x8a, lsl #12  ; [pp+0x8af58] AnonymousClosure: (0x8db3f8), in [package:dio/src/transformers/util/transform_empty_to_null.dart] _DefaultIfEmptyStreamSink::add (0x8db31c)
    //     0x8db468: ldr             x1, [x1, #0xf58]
    // 0x8db46c: r0 = AllocateClosure()
    //     0x8db46c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8db470: LeaveFrame
    //     0x8db470: mov             SP, fp
    //     0x8db474: ldp             fp, lr, [SP], #0x10
    // 0x8db478: ret
    //     0x8db478: ret             
  }
  _ close(/* No info */) {
    // ** addr: 0x9ecea0, size: 0xc4
    // 0x9ecea0: EnterFrame
    //     0x9ecea0: stp             fp, lr, [SP, #-0x10]!
    //     0x9ecea4: mov             fp, SP
    // 0x9ecea8: AllocStack(0x10)
    //     0x9ecea8: sub             SP, SP, #0x10
    // 0x9eceac: SetupParameters(_DefaultIfEmptyStreamSink this /* r1 => r1, fp-0x10 */)
    //     0x9eceac: stur            x1, [fp, #-0x10]
    // 0x9eceb0: CheckStackOverflow
    //     0x9eceb0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9eceb4: cmp             SP, x16
    //     0x9eceb8: b.ls            #0x9ecf5c
    // 0x9ecebc: LoadField: r0 = r1->field_b
    //     0x9ecebc: ldur            w0, [x1, #0xb]
    // 0x9ecec0: DecompressPointer r0
    //     0x9ecec0: add             x0, x0, HEAP, lsl #32
    // 0x9ecec4: tbz             w0, #4, #0x9ecf20
    // 0x9ecec8: LoadField: r0 = r1->field_7
    //     0x9ecec8: ldur            w0, [x1, #7]
    // 0x9ececc: DecompressPointer r0
    //     0x9ececc: add             x0, x0, HEAP, lsl #32
    // 0x9eced0: stur            x0, [fp, #-8]
    // 0x9eced4: r0 = LoadStaticField(0x1090)
    //     0x9eced4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x9eced8: ldr             x0, [x0, #0x2120]
    // 0x9ecedc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9ecee0: cmp             w0, w16
    // 0x9ecee4: b.ne            #0x9ecef4
    // 0x9ecee8: r2 = _nullUtf8Value
    //     0x9ecee8: add             x2, PP, #0x8a, lsl #12  ; [pp+0x8af60] Field <_DefaultIfEmptyStreamSink@1273287173._nullUtf8Value@1273287173>: static late final (offset: 0x1090)
    //     0x9eceec: ldr             x2, [x2, #0xf60]
    // 0x9ecef0: r0 = InitLateFinalStaticField()
    //     0x9ecef0: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x9ecef4: ldur            x1, [fp, #-8]
    // 0x9ecef8: r2 = LoadClassIdInstr(r1)
    //     0x9ecef8: ldur            x2, [x1, #-1]
    //     0x9ecefc: ubfx            x2, x2, #0xc, #0x14
    // 0x9ecf00: mov             x16, x0
    // 0x9ecf04: mov             x0, x2
    // 0x9ecf08: mov             x2, x16
    // 0x9ecf0c: r0 = GDT[cid_x0 + 0x1847a]()
    //     0x9ecf0c: mov             x17, #0x847a
    //     0x9ecf10: movk            x17, #1, lsl #16
    //     0x9ecf14: add             lr, x0, x17
    //     0x9ecf18: ldr             lr, [x21, lr, lsl #3]
    //     0x9ecf1c: blr             lr
    // 0x9ecf20: ldur            x0, [fp, #-0x10]
    // 0x9ecf24: LoadField: r1 = r0->field_7
    //     0x9ecf24: ldur            w1, [x0, #7]
    // 0x9ecf28: DecompressPointer r1
    //     0x9ecf28: add             x1, x1, HEAP, lsl #32
    // 0x9ecf2c: r0 = LoadClassIdInstr(r1)
    //     0x9ecf2c: ldur            x0, [x1, #-1]
    //     0x9ecf30: ubfx            x0, x0, #0xc, #0x14
    // 0x9ecf34: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ecf34: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ecf38: r0 = GDT[cid_x0 + 0x182be]()
    //     0x9ecf38: mov             x17, #0x82be
    //     0x9ecf3c: movk            x17, #1, lsl #16
    //     0x9ecf40: add             lr, x0, x17
    //     0x9ecf44: ldr             lr, [x21, lr, lsl #3]
    //     0x9ecf48: blr             lr
    // 0x9ecf4c: r0 = Null
    //     0x9ecf4c: mov             x0, NULL
    // 0x9ecf50: LeaveFrame
    //     0x9ecf50: mov             SP, fp
    //     0x9ecf54: ldp             fp, lr, [SP], #0x10
    // 0x9ecf58: ret
    //     0x9ecf58: ret             
    // 0x9ecf5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ecf5c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ecf60: b               #0x9ecebc
  }
  static Uint8List _nullUtf8Value() {
    // ** addr: 0x9ecf64, size: 0x58
    // 0x9ecf64: EnterFrame
    //     0x9ecf64: stp             fp, lr, [SP, #-0x10]!
    //     0x9ecf68: mov             fp, SP
    // 0x9ecf6c: AllocStack(0x8)
    //     0x9ecf6c: sub             SP, SP, #8
    // 0x9ecf70: CheckStackOverflow
    //     0x9ecf70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ecf74: cmp             SP, x16
    //     0x9ecf78: b.ls            #0x9ecfb4
    // 0x9ecf7c: r4 = 8
    //     0x9ecf7c: mov             x4, #8
    // 0x9ecf80: r0 = AllocateUint8Array()
    //     0x9ecf80: bl              #0x13df5f0  ; AllocateUint8ArrayStub
    // 0x9ecf84: mov             x1, x0
    // 0x9ecf88: r2 = 0
    //     0x9ecf88: mov             x2, #0
    // 0x9ecf8c: r3 = 4
    //     0x9ecf8c: mov             x3, #4
    // 0x9ecf90: r5 = const [0x6e, 0x75, 0x6c, 0x6c]
    //     0x9ecf90: add             x5, PP, #0x8a, lsl #12  ; [pp+0x8af68] List<int>(4)
    //     0x9ecf94: ldr             x5, [x5, #0xf68]
    // 0x9ecf98: r6 = 0
    //     0x9ecf98: mov             x6, #0
    // 0x9ecf9c: stur            x0, [fp, #-8]
    // 0x9ecfa0: r0 = _slowSetRange()
    //     0x9ecfa0: bl              #0x117e940  ; [dart:typed_data] __Uint8List&_TypedList&_IntListMixin&_TypedIntListMixin::_slowSetRange
    // 0x9ecfa4: ldur            x0, [fp, #-8]
    // 0x9ecfa8: LeaveFrame
    //     0x9ecfa8: mov             SP, fp
    //     0x9ecfac: ldp             fp, lr, [SP], #0x10
    // 0x9ecfb0: ret
    //     0x9ecfb0: ret             
    // 0x9ecfb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ecfb4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ecfb8: b               #0x9ecf7c
  }
  _ addError(/* No info */) {
    // ** addr: 0x9fafb0, size: 0x80
    // 0x9fafb0: EnterFrame
    //     0x9fafb0: stp             fp, lr, [SP, #-0x10]!
    //     0x9fafb4: mov             fp, SP
    // 0x9fafb8: AllocStack(0x8)
    //     0x9fafb8: sub             SP, SP, #8
    // 0x9fafbc: SetupParameters([dynamic _ = Null /* r0 */])
    //     0x9fafbc: ldur            w0, [x4, #0x13]
    //     0x9fafc0: sub             x3, x0, #4
    //     0x9fafc4: cmp             w3, #2
    //     0x9fafc8: b.lt            #0x9fafd8
    //     0x9fafcc: add             x0, fp, w3, sxtw #2
    //     0x9fafd0: ldr             x0, [x0, #8]
    //     0x9fafd4: b               #0x9fafdc
    //     0x9fafd8: mov             x0, NULL
    // 0x9fafdc: CheckStackOverflow
    //     0x9fafdc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9fafe0: cmp             SP, x16
    //     0x9fafe4: b.ls            #0x9fb028
    // 0x9fafe8: LoadField: r3 = r1->field_7
    //     0x9fafe8: ldur            w3, [x1, #7]
    // 0x9fafec: DecompressPointer r3
    //     0x9fafec: add             x3, x3, HEAP, lsl #32
    // 0x9faff0: r1 = LoadClassIdInstr(r3)
    //     0x9faff0: ldur            x1, [x3, #-1]
    //     0x9faff4: ubfx            x1, x1, #0xc, #0x14
    // 0x9faff8: str             x0, [SP]
    // 0x9faffc: mov             x0, x1
    // 0x9fb000: mov             x1, x3
    // 0x9fb004: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x9fb004: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x9fb008: r0 = GDT[cid_x0 + 0x17f2c]()
    //     0x9fb008: mov             x17, #0x7f2c
    //     0x9fb00c: movk            x17, #1, lsl #16
    //     0x9fb010: add             lr, x0, x17
    //     0x9fb014: ldr             lr, [x21, lr, lsl #3]
    //     0x9fb018: blr             lr
    // 0x9fb01c: LeaveFrame
    //     0x9fb01c: mov             SP, fp
    //     0x9fb020: ldp             fp, lr, [SP], #0x10
    // 0x9fb024: ret
    //     0x9fb024: ret             
    // 0x9fb028: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9fb028: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9fb02c: b               #0x9fafe8
  }
  [closure] void addError(dynamic, Object, [StackTrace?]) {
    // ** addr: 0x9fb030, size: 0x78
    // 0x9fb030: EnterFrame
    //     0x9fb030: stp             fp, lr, [SP, #-0x10]!
    //     0x9fb034: mov             fp, SP
    // 0x9fb038: AllocStack(0x8)
    //     0x9fb038: sub             SP, SP, #8
    // 0x9fb03c: SetupParameters(_DefaultIfEmptyStreamSink this /* r0 */, dynamic _ /* r2 */, [dynamic _ = Null /* r1 */])
    //     0x9fb03c: ldur            w0, [x4, #0x13]
    //     0x9fb040: sub             x1, x0, #4
    //     0x9fb044: add             x0, fp, w1, sxtw #2
    //     0x9fb048: ldr             x0, [x0, #0x18]
    //     0x9fb04c: add             x2, fp, w1, sxtw #2
    //     0x9fb050: ldr             x2, [x2, #0x10]
    //     0x9fb054: cmp             w1, #2
    //     0x9fb058: b.lt            #0x9fb06c
    //     0x9fb05c: add             x3, fp, w1, sxtw #2
    //     0x9fb060: ldr             x3, [x3, #8]
    //     0x9fb064: mov             x1, x3
    //     0x9fb068: b               #0x9fb070
    //     0x9fb06c: mov             x1, NULL
    //     0x9fb070: ldur            w3, [x0, #0x17]
    //     0x9fb074: add             x3, x3, HEAP, lsl #32
    // 0x9fb078: CheckStackOverflow
    //     0x9fb078: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9fb07c: cmp             SP, x16
    //     0x9fb080: b.ls            #0x9fb0a0
    // 0x9fb084: str             x1, [SP]
    // 0x9fb088: mov             x1, x3
    // 0x9fb08c: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x9fb08c: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x9fb090: r0 = addError()
    //     0x9fb090: bl              #0x9fafb0  ; [package:dio/src/transformers/util/transform_empty_to_null.dart] _DefaultIfEmptyStreamSink::addError
    // 0x9fb094: LeaveFrame
    //     0x9fb094: mov             SP, fp
    //     0x9fb098: ldp             fp, lr, [SP], #0x10
    // 0x9fb09c: ret
    //     0x9fb09c: ret             
    // 0x9fb0a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9fb0a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9fb0a4: b               #0x9fb084
  }
  dynamic addError(dynamic) {
    // ** addr: 0xa0c238, size: 0x24
    // 0xa0c238: EnterFrame
    //     0xa0c238: stp             fp, lr, [SP, #-0x10]!
    //     0xa0c23c: mov             fp, SP
    // 0xa0c240: ldr             x2, [fp, #0x10]
    // 0xa0c244: r1 = Function 'addError':.
    //     0xa0c244: add             x1, PP, #0x8a, lsl #12  ; [pp+0x8af50] AnonymousClosure: (0x9fb030), in [package:dio/src/transformers/util/transform_empty_to_null.dart] _DefaultIfEmptyStreamSink::addError (0x9fafb0)
    //     0xa0c248: ldr             x1, [x1, #0xf50]
    // 0xa0c24c: r0 = AllocateClosure()
    //     0xa0c24c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xa0c250: LeaveFrame
    //     0xa0c250: mov             SP, fp
    //     0xa0c254: ldp             fp, lr, [SP], #0x10
    // 0xa0c258: ret
    //     0xa0c258: ret             
  }
}

// class id: 7499, size: 0xc, field offset: 0xc
//   const constructor, 
class DefaultNullIfEmptyStreamTransformer extends StreamTransformerBase<dynamic, dynamic> {

  _ bind(/* No info */) {
    // ** addr: 0x11d6b00, size: 0x7c
    // 0x11d6b00: EnterFrame
    //     0x11d6b00: stp             fp, lr, [SP, #-0x10]!
    //     0x11d6b04: mov             fp, SP
    // 0x11d6b08: AllocStack(0x10)
    //     0x11d6b08: sub             SP, SP, #0x10
    // 0x11d6b0c: SetupParameters(DefaultNullIfEmptyStreamTransformer this /* r1 => r4 */, dynamic _ /* r2 => r0, fp-0x8 */)
    //     0x11d6b0c: mov             x0, x2
    //     0x11d6b10: mov             x4, x1
    //     0x11d6b14: mov             x3, x2
    //     0x11d6b18: stur            x2, [fp, #-8]
    // 0x11d6b1c: r2 = Null
    //     0x11d6b1c: mov             x2, NULL
    // 0x11d6b20: r1 = Null
    //     0x11d6b20: mov             x1, NULL
    // 0x11d6b24: r8 = Stream<Uint8List>
    //     0x11d6b24: add             x8, PP, #0x7e, lsl #12  ; [pp+0x7ebe8] Type: Stream<Uint8List>
    //     0x11d6b28: ldr             x8, [x8, #0xbe8]
    // 0x11d6b2c: r3 = Null
    //     0x11d6b2c: add             x3, PP, #0x7e, lsl #12  ; [pp+0x7ebf0] Null
    //     0x11d6b30: ldr             x3, [x3, #0xbf0]
    // 0x11d6b34: r0 = Stream<Uint8List>()
    //     0x11d6b34: bl              #0x7e1934  ; IsType_Stream<Uint8List>_Stub
    // 0x11d6b38: r1 = <Uint8List, dynamic, Uint8List>
    //     0x11d6b38: add             x1, PP, #0x7e, lsl #12  ; [pp+0x7ec00] TypeArguments: <Uint8List, dynamic, Uint8List>
    //     0x11d6b3c: ldr             x1, [x1, #0xc00]
    // 0x11d6b40: r0 = _BoundSinkStream()
    //     0x11d6b40: bl              #0x11d65e4  ; Allocate_BoundSinkStreamStub -> _BoundSinkStream<C1X0, C1X1> (size=0x14)
    // 0x11d6b44: mov             x3, x0
    // 0x11d6b48: ldur            x0, [fp, #-8]
    // 0x11d6b4c: stur            x3, [fp, #-0x10]
    // 0x11d6b50: StoreField: r3->field_f = r0
    //     0x11d6b50: stur            w0, [x3, #0xf]
    // 0x11d6b54: r1 = Function '<anonymous closure>':.
    //     0x11d6b54: add             x1, PP, #0x7e, lsl #12  ; [pp+0x7ec08] AnonymousClosure: (0x11d6b7c), in [package:dio/src/transformers/util/transform_empty_to_null.dart] DefaultNullIfEmptyStreamTransformer::bind (0x11d6b00)
    //     0x11d6b58: ldr             x1, [x1, #0xc08]
    // 0x11d6b5c: r2 = Null
    //     0x11d6b5c: mov             x2, NULL
    // 0x11d6b60: r0 = AllocateClosure()
    //     0x11d6b60: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11d6b64: mov             x1, x0
    // 0x11d6b68: ldur            x0, [fp, #-0x10]
    // 0x11d6b6c: StoreField: r0->field_b = r1
    //     0x11d6b6c: stur            w1, [x0, #0xb]
    // 0x11d6b70: LeaveFrame
    //     0x11d6b70: mov             SP, fp
    //     0x11d6b74: ldp             fp, lr, [SP], #0x10
    // 0x11d6b78: ret
    //     0x11d6b78: ret             
  }
  [closure] _DefaultIfEmptyStreamSink <anonymous closure>(dynamic, EventSink<Uint8List>) {
    // ** addr: 0x11d6b7c, size: 0x28
    // 0x11d6b7c: EnterFrame
    //     0x11d6b7c: stp             fp, lr, [SP, #-0x10]!
    //     0x11d6b80: mov             fp, SP
    // 0x11d6b84: r0 = _DefaultIfEmptyStreamSink()
    //     0x11d6b84: bl              #0x11d6ba4  ; Allocate_DefaultIfEmptyStreamSinkStub -> _DefaultIfEmptyStreamSink (size=0x10)
    // 0x11d6b88: r1 = false
    //     0x11d6b88: add             x1, NULL, #0x30  ; false
    // 0x11d6b8c: StoreField: r0->field_b = r1
    //     0x11d6b8c: stur            w1, [x0, #0xb]
    // 0x11d6b90: ldr             x1, [fp, #0x10]
    // 0x11d6b94: StoreField: r0->field_7 = r1
    //     0x11d6b94: stur            w1, [x0, #7]
    // 0x11d6b98: LeaveFrame
    //     0x11d6b98: mov             SP, fp
    //     0x11d6b9c: ldp             fp, lr, [SP], #0x10
    // 0x11d6ba0: ret
    //     0x11d6ba0: ret             
  }
}
