// lib: , url: package:dio/src/transformers/util/consolidate_bytes.dart

// class id: 1048715, size: 0x8
class :: {

  static _ consolidateBytes(/* No info */) async {
    // ** addr: 0x8f3c64, size: 0x2c4
    // 0x8f3c64: EnterFrame
    //     0x8f3c64: stp             fp, lr, [SP, #-0x10]!
    //     0x8f3c68: mov             fp, SP
    // 0x8f3c6c: AllocStack(0x80)
    //     0x8f3c6c: sub             SP, SP, #0x80
    // 0x8f3c70: SetupParameters(dynamic _ /* r1 => r1, fp-0x68 */)
    //     0x8f3c70: stur            NULL, [fp, #-8]
    //     0x8f3c74: stur            x1, [fp, #-0x68]
    // 0x8f3c78: CheckStackOverflow
    //     0x8f3c78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f3c7c: cmp             SP, x16
    //     0x8f3c80: b.ls            #0x8f3f18
    // 0x8f3c84: InitAsync() -> Future<Uint8List>
    //     0x8f3c84: add             x0, PP, #8, lsl #12  ; [pp+0x8548] TypeArguments: <Uint8List>
    //     0x8f3c88: ldr             x0, [x0, #0x548]
    //     0x8f3c8c: bl              #0x7f5e44  ; InitAsyncStub
    // 0x8f3c90: r0 = _BytesBuilder()
    //     0x8f3c90: bl              #0x7fe8ec  ; Allocate_BytesBuilderStub -> _BytesBuilder (size=0x14)
    // 0x8f3c94: stur            x0, [fp, #-0x70]
    // 0x8f3c98: StoreField: r0->field_7 = rZR
    //     0x8f3c98: stur            xzr, [x0, #7]
    // 0x8f3c9c: r1 = <Uint8List>
    //     0x8f3c9c: add             x1, PP, #8, lsl #12  ; [pp+0x8548] TypeArguments: <Uint8List>
    //     0x8f3ca0: ldr             x1, [x1, #0x548]
    // 0x8f3ca4: r2 = 0
    //     0x8f3ca4: mov             x2, #0
    // 0x8f3ca8: r0 = _GrowableList()
    //     0x8f3ca8: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x8f3cac: ldur            x2, [fp, #-0x70]
    // 0x8f3cb0: StoreField: r2->field_f = r0
    //     0x8f3cb0: stur            w0, [x2, #0xf]
    //     0x8f3cb4: ldurb           w16, [x2, #-1]
    //     0x8f3cb8: ldurb           w17, [x0, #-1]
    //     0x8f3cbc: and             x16, x17, x16, lsr #2
    //     0x8f3cc0: tst             x16, HEAP, lsr #32
    //     0x8f3cc4: b.eq            #0x8f3ccc
    //     0x8f3cc8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x8f3ccc: r1 = <Uint8List>
    //     0x8f3ccc: add             x1, PP, #8, lsl #12  ; [pp+0x8548] TypeArguments: <Uint8List>
    //     0x8f3cd0: ldr             x1, [x1, #0x548]
    // 0x8f3cd4: r0 = _StreamIterator()
    //     0x8f3cd4: bl              #0x8f45f0  ; Allocate_StreamIteratorStub -> _StreamIterator<X0> (size=0x18)
    // 0x8f3cd8: mov             x2, x0
    // 0x8f3cdc: r0 = false
    //     0x8f3cdc: add             x0, NULL, #0x30  ; false
    // 0x8f3ce0: stur            x2, [fp, #-0x78]
    // 0x8f3ce4: StoreField: r2->field_13 = r0
    //     0x8f3ce4: stur            w0, [x2, #0x13]
    // 0x8f3ce8: ldur            x1, [fp, #-0x68]
    // 0x8f3cec: StoreField: r2->field_f = r1
    //     0x8f3cec: stur            w1, [x2, #0xf]
    // 0x8f3cf0: CheckStackOverflow
    //     0x8f3cf0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f3cf4: cmp             SP, x16
    //     0x8f3cf8: b.ls            #0x8f3f20
    // 0x8f3cfc: LoadField: r3 = r2->field_b
    //     0x8f3cfc: ldur            w3, [x2, #0xb]
    // 0x8f3d00: DecompressPointer r3
    //     0x8f3d00: add             x3, x3, HEAP, lsl #32
    // 0x8f3d04: stur            x3, [fp, #-0x68]
    // 0x8f3d08: cmp             w3, NULL
    // 0x8f3d0c: b.eq            #0x8f3d9c
    // 0x8f3d10: LoadField: r1 = r2->field_13
    //     0x8f3d10: ldur            w1, [x2, #0x13]
    // 0x8f3d14: DecompressPointer r1
    //     0x8f3d14: add             x1, x1, HEAP, lsl #32
    // 0x8f3d18: tbnz            w1, #4, #0x8f3ea4
    // 0x8f3d1c: r1 = <bool>
    //     0x8f3d1c: ldr             x1, [PP, #0x1918]  ; [pp+0x1918] TypeArguments: <bool>
    // 0x8f3d20: r0 = _Future()
    //     0x8f3d20: bl              #0x7f5dd4  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0x8f3d24: stur            x0, [fp, #-0x80]
    // 0x8f3d28: StoreField: r0->field_b = rZR
    //     0x8f3d28: stur            xzr, [x0, #0xb]
    // 0x8f3d2c: r0 = LoadStaticField(0x364)
    //     0x8f3d2c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8f3d30: ldr             x0, [x0, #0x6c8]
    // 0x8f3d34: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8f3d38: cmp             w0, w16
    // 0x8f3d3c: b.ne            #0x8f3d48
    // 0x8f3d40: r2 = _current
    //     0x8f3d40: ldr             x2, [PP, #0x2c0]  ; [pp+0x2c0] Field <Zone._current@5048458>: static late (offset: 0x364)
    // 0x8f3d44: r0 = InitLateStaticField()
    //     0x8f3d44: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0x8f3d48: ldur            x2, [fp, #-0x80]
    // 0x8f3d4c: StoreField: r2->field_13 = r0
    //     0x8f3d4c: stur            w0, [x2, #0x13]
    // 0x8f3d50: mov             x0, x2
    // 0x8f3d54: ldur            x3, [fp, #-0x78]
    // 0x8f3d58: StoreField: r3->field_f = r0
    //     0x8f3d58: stur            w0, [x3, #0xf]
    //     0x8f3d5c: ldurb           w16, [x3, #-1]
    //     0x8f3d60: ldurb           w17, [x0, #-1]
    //     0x8f3d64: and             x16, x17, x16, lsr #2
    //     0x8f3d68: tst             x16, HEAP, lsr #32
    //     0x8f3d6c: b.eq            #0x8f3d74
    //     0x8f3d70: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x8f3d74: r4 = false
    //     0x8f3d74: add             x4, NULL, #0x30  ; false
    // 0x8f3d78: StoreField: r3->field_13 = r4
    //     0x8f3d78: stur            w4, [x3, #0x13]
    // 0x8f3d7c: ldur            x1, [fp, #-0x68]
    // 0x8f3d80: r0 = LoadClassIdInstr(r1)
    //     0x8f3d80: ldur            x0, [x1, #-1]
    //     0x8f3d84: ubfx            x0, x0, #0xc, #0x14
    // 0x8f3d88: r0 = GDT[cid_x0 + 0x5d3]()
    //     0x8f3d88: add             lr, x0, #0x5d3
    //     0x8f3d8c: ldr             lr, [x21, lr, lsl #3]
    //     0x8f3d90: blr             lr
    // 0x8f3d94: ldur            x1, [fp, #-0x80]
    // 0x8f3d98: b               #0x8f3da8
    // 0x8f3d9c: ldur            x1, [fp, #-0x78]
    // 0x8f3da0: r0 = _initializeOrDone()
    //     0x8f3da0: bl              #0x8f40c4  ; [dart:async] _StreamIterator::_initializeOrDone
    // 0x8f3da4: mov             x1, x0
    // 0x8f3da8: mov             x0, x1
    // 0x8f3dac: stur            x1, [fp, #-0x68]
    // 0x8f3db0: r0 = Await()
    //     0x8f3db0: bl              #0x7f5c00  ; AwaitStub
    // 0x8f3db4: r16 = true
    //     0x8f3db4: add             x16, NULL, #0x20  ; true
    // 0x8f3db8: cmp             w0, w16
    // 0x8f3dbc: b.ne            #0x8f3e74
    // 0x8f3dc0: ldur            x3, [fp, #-0x78]
    // 0x8f3dc4: LoadField: r0 = r3->field_13
    //     0x8f3dc4: ldur            w0, [x3, #0x13]
    // 0x8f3dc8: DecompressPointer r0
    //     0x8f3dc8: add             x0, x0, HEAP, lsl #32
    // 0x8f3dcc: tbnz            w0, #4, #0x8f3e20
    // 0x8f3dd0: LoadField: r4 = r3->field_f
    //     0x8f3dd0: ldur            w4, [x3, #0xf]
    // 0x8f3dd4: DecompressPointer r4
    //     0x8f3dd4: add             x4, x4, HEAP, lsl #32
    // 0x8f3dd8: mov             x0, x4
    // 0x8f3ddc: stur            x4, [fp, #-0x68]
    // 0x8f3de0: r2 = Null
    //     0x8f3de0: mov             x2, NULL
    // 0x8f3de4: r1 = Null
    //     0x8f3de4: mov             x1, NULL
    // 0x8f3de8: r4 = 60
    //     0x8f3de8: mov             x4, #0x3c
    // 0x8f3dec: branchIfSmi(r0, 0x8f3df8)
    //     0x8f3dec: tbz             w0, #0, #0x8f3df8
    // 0x8f3df0: r4 = LoadClassIdInstr(r0)
    //     0x8f3df0: ldur            x4, [x0, #-1]
    //     0x8f3df4: ubfx            x4, x4, #0xc, #0x14
    // 0x8f3df8: sub             x4, x4, #0x74
    // 0x8f3dfc: cmp             x4, #3
    // 0x8f3e00: b.ls            #0x8f3e18
    // 0x8f3e04: r8 = Uint8List
    //     0x8f3e04: add             x8, PP, #0xc, lsl #12  ; [pp+0xc840] Type: Uint8List
    //     0x8f3e08: ldr             x8, [x8, #0x840]
    // 0x8f3e0c: r3 = Null
    //     0x8f3e0c: add             x3, PP, #0x16, lsl #12  ; [pp+0x162d0] Null
    //     0x8f3e10: ldr             x3, [x3, #0x2d0]
    // 0x8f3e14: r0 = Uint8List()
    //     0x8f3e14: bl              #0x7de36c  ; IsType_Uint8List_Stub
    // 0x8f3e18: ldur            x0, [fp, #-0x68]
    // 0x8f3e1c: b               #0x8f3e58
    // 0x8f3e20: r0 = Null
    //     0x8f3e20: mov             x0, NULL
    // 0x8f3e24: r2 = Null
    //     0x8f3e24: mov             x2, NULL
    // 0x8f3e28: r1 = Null
    //     0x8f3e28: mov             x1, NULL
    // 0x8f3e2c: r4 = LoadClassIdInstr(r0)
    //     0x8f3e2c: ldur            x4, [x0, #-1]
    //     0x8f3e30: ubfx            x4, x4, #0xc, #0x14
    // 0x8f3e34: sub             x4, x4, #0x74
    // 0x8f3e38: cmp             x4, #3
    // 0x8f3e3c: b.ls            #0x8f3e54
    // 0x8f3e40: r8 = Uint8List
    //     0x8f3e40: add             x8, PP, #0xc, lsl #12  ; [pp+0xc840] Type: Uint8List
    //     0x8f3e44: ldr             x8, [x8, #0x840]
    // 0x8f3e48: r3 = Null
    //     0x8f3e48: add             x3, PP, #0x16, lsl #12  ; [pp+0x162e0] Null
    //     0x8f3e4c: ldr             x3, [x3, #0x2e0]
    // 0x8f3e50: r0 = Uint8List()
    //     0x8f3e50: bl              #0x7de36c  ; IsType_Uint8List_Stub
    // 0x8f3e54: r0 = Null
    //     0x8f3e54: mov             x0, NULL
    // 0x8f3e58: ldur            x1, [fp, #-0x70]
    // 0x8f3e5c: mov             x2, x0
    // 0x8f3e60: stur            x0, [fp, #-0x68]
    // 0x8f3e64: r0 = add()
    //     0x8f3e64: bl              #0x7ff244  ; [dart:_internal] _BytesBuilder::add
    // 0x8f3e68: ldur            x2, [fp, #-0x78]
    // 0x8f3e6c: r0 = false
    //     0x8f3e6c: add             x0, NULL, #0x30  ; false
    // 0x8f3e70: b               #0x8f3cf0
    // 0x8f3e74: ldur            x1, [fp, #-0x78]
    // 0x8f3e78: LoadField: r0 = r1->field_b
    //     0x8f3e78: ldur            w0, [x1, #0xb]
    // 0x8f3e7c: DecompressPointer r0
    //     0x8f3e7c: add             x0, x0, HEAP, lsl #32
    // 0x8f3e80: cmp             w0, NULL
    // 0x8f3e84: b.eq            #0x8f3e98
    // 0x8f3e88: r0 = cancel()
    //     0x8f3e88: bl              #0x8f3f74  ; [dart:async] _StreamIterator::cancel
    // 0x8f3e8c: mov             x1, x0
    // 0x8f3e90: stur            x1, [fp, #-0x68]
    // 0x8f3e94: r0 = Await()
    //     0x8f3e94: bl              #0x7f5c00  ; AwaitStub
    // 0x8f3e98: ldur            x1, [fp, #-0x70]
    // 0x8f3e9c: r0 = takeBytes()
    //     0x8f3e9c: bl              #0x7feaec  ; [dart:_internal] _BytesBuilder::takeBytes
    // 0x8f3ea0: r0 = ReturnAsyncNotFuture()
    //     0x8f3ea0: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x8f3ea4: mov             x1, x2
    // 0x8f3ea8: r0 = StateError()
    //     0x8f3ea8: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x8f3eac: mov             x1, x0
    // 0x8f3eb0: r0 = "Already waiting for next."
    //     0x8f3eb0: add             x0, PP, #0x16, lsl #12  ; [pp+0x162f0] "Already waiting for next."
    //     0x8f3eb4: ldr             x0, [x0, #0x2f0]
    // 0x8f3eb8: stur            x1, [fp, #-0x68]
    // 0x8f3ebc: StoreField: r1->field_b = r0
    //     0x8f3ebc: stur            w0, [x1, #0xb]
    // 0x8f3ec0: mov             x0, x1
    // 0x8f3ec4: r0 = Throw()
    //     0x8f3ec4: bl              #0x13ddb2c  ; ThrowStub
    // 0x8f3ec8: brk             #0
    // 0x8f3ecc: sub             SP, fp, #0x80
    // 0x8f3ed0: ldur            x2, [fp, #-0x78]
    // 0x8f3ed4: mov             x3, x0
    // 0x8f3ed8: stur            x0, [fp, #-0x68]
    // 0x8f3edc: mov             x0, x1
    // 0x8f3ee0: stur            x1, [fp, #-0x70]
    // 0x8f3ee4: LoadField: r1 = r2->field_b
    //     0x8f3ee4: ldur            w1, [x2, #0xb]
    // 0x8f3ee8: DecompressPointer r1
    //     0x8f3ee8: add             x1, x1, HEAP, lsl #32
    // 0x8f3eec: cmp             w1, NULL
    // 0x8f3ef0: b.eq            #0x8f3f08
    // 0x8f3ef4: mov             x1, x2
    // 0x8f3ef8: r0 = cancel()
    //     0x8f3ef8: bl              #0x8f3f74  ; [dart:async] _StreamIterator::cancel
    // 0x8f3efc: mov             x1, x0
    // 0x8f3f00: stur            x1, [fp, #-0x78]
    // 0x8f3f04: r0 = Await()
    //     0x8f3f04: bl              #0x7f5c00  ; AwaitStub
    // 0x8f3f08: ldur            x0, [fp, #-0x68]
    // 0x8f3f0c: ldur            x1, [fp, #-0x70]
    // 0x8f3f10: r0 = ReThrow()
    //     0x8f3f10: bl              #0x13ddb00  ; ReThrowStub
    // 0x8f3f14: brk             #0
    // 0x8f3f18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f3f18: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f3f1c: b               #0x8f3c84
    // 0x8f3f20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f3f20: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f3f24: b               #0x8f3cfc
  }
}
