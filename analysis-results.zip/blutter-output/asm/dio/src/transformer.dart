// lib: , url: package:dio/src/transformer.dart

// class id: 1048713, size: 0x8
class :: {
}

// class id: 3397, size: 0x8, field offset: 0x8
abstract class Transformer extends Object {

  static _ isJsonMimeType(/* No info */) {
    // ** addr: 0x8f19d8, size: 0x174
    // 0x8f19d8: EnterFrame
    //     0x8f19d8: stp             fp, lr, [SP, #-0x10]!
    //     0x8f19dc: mov             fp, SP
    // 0x8f19e0: AllocStack(0x78)
    //     0x8f19e0: sub             SP, SP, #0x78
    // 0x8f19e4: SetupParameters(dynamic _ /* r1 => r1, fp-0x58 */)
    //     0x8f19e4: stur            x1, [fp, #-0x58]
    // 0x8f19e8: CheckStackOverflow
    //     0x8f19e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f19ec: cmp             SP, x16
    //     0x8f19f0: b.ls            #0x8f1b44
    // 0x8f19f4: cmp             w1, NULL
    // 0x8f19f8: b.ne            #0x8f1a0c
    // 0x8f19fc: r0 = false
    //     0x8f19fc: add             x0, NULL, #0x30  ; false
    // 0x8f1a00: LeaveFrame
    //     0x8f1a00: mov             SP, fp
    //     0x8f1a04: ldp             fp, lr, [SP], #0x10
    // 0x8f1a08: ret
    //     0x8f1a08: ret             
    // 0x8f1a0c: r1 = 1
    //     0x8f1a0c: mov             x1, #1
    // 0x8f1a10: r0 = AllocateContext()
    //     0x8f1a10: bl              #0x13de838  ; AllocateContextStub
    // 0x8f1a14: mov             x3, x0
    // 0x8f1a18: ldur            x0, [fp, #-0x58]
    // 0x8f1a1c: stur            x3, [fp, #-0x60]
    // 0x8f1a20: StoreField: r3->field_f = r0
    //     0x8f1a20: stur            w0, [x3, #0xf]
    // 0x8f1a24: mov             x2, x3
    // 0x8f1a28: r1 = Function '<anonymous closure>': static.
    //     0x8f1a28: add             x1, PP, #8, lsl #12  ; [pp+0x8780] AnonymousClosure: static (0x8f1eec), in [package:http_parser/src/media_type.dart] MediaType::MediaType.parse (0x8f1b4c)
    //     0x8f1a2c: ldr             x1, [x1, #0x780]
    // 0x8f1a30: r0 = AllocateClosure()
    //     0x8f1a30: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8f1a34: r16 = <MediaType>
    //     0x8f1a34: add             x16, PP, #8, lsl #12  ; [pp+0x8788] TypeArguments: <MediaType>
    //     0x8f1a38: ldr             x16, [x16, #0x788]
    // 0x8f1a3c: ldur            lr, [fp, #-0x58]
    // 0x8f1a40: stp             lr, x16, [SP, #8]
    // 0x8f1a44: str             x0, [SP]
    // 0x8f1a48: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8f1a48: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8f1a4c: r0 = wrapFormatException()
    //     0x8f1a4c: bl              #0x8f1c34  ; [package:http_parser/src/utils.dart] ::wrapFormatException
    // 0x8f1a50: mov             x1, x0
    // 0x8f1a54: stur            x0, [fp, #-0x60]
    // 0x8f1a58: r0 = mimeType()
    //     0x8f1a58: bl              #0x8f1bbc  ; [package:http_parser/src/media_type.dart] MediaType::mimeType
    // 0x8f1a5c: r1 = LoadClassIdInstr(r0)
    //     0x8f1a5c: ldur            x1, [x0, #-1]
    //     0x8f1a60: ubfx            x1, x1, #0xc, #0x14
    // 0x8f1a64: r16 = "application/json"
    //     0x8f1a64: add             x16, PP, #0x16, lsl #12  ; [pp+0x162a8] "application/json"
    //     0x8f1a68: ldr             x16, [x16, #0x2a8]
    // 0x8f1a6c: stp             x16, x0, [SP]
    // 0x8f1a70: mov             x0, x1
    // 0x8f1a74: mov             lr, x0
    // 0x8f1a78: ldr             lr, [x21, lr, lsl #3]
    // 0x8f1a7c: blr             lr
    // 0x8f1a80: tbz             w0, #4, #0x8f1ab4
    // 0x8f1a84: ldur            x1, [fp, #-0x60]
    // 0x8f1a88: r0 = mimeType()
    //     0x8f1a88: bl              #0x8f1bbc  ; [package:http_parser/src/media_type.dart] MediaType::mimeType
    // 0x8f1a8c: r1 = LoadClassIdInstr(r0)
    //     0x8f1a8c: ldur            x1, [x0, #-1]
    //     0x8f1a90: ubfx            x1, x1, #0xc, #0x14
    // 0x8f1a94: r16 = "text/json"
    //     0x8f1a94: add             x16, PP, #0x16, lsl #12  ; [pp+0x162b0] "text/json"
    //     0x8f1a98: ldr             x16, [x16, #0x2b0]
    // 0x8f1a9c: stp             x16, x0, [SP]
    // 0x8f1aa0: mov             x0, x1
    // 0x8f1aa4: mov             lr, x0
    // 0x8f1aa8: ldr             lr, [x21, lr, lsl #3]
    // 0x8f1aac: blr             lr
    // 0x8f1ab0: tbnz            w0, #4, #0x8f1abc
    // 0x8f1ab4: r0 = true
    //     0x8f1ab4: add             x0, NULL, #0x20  ; true
    // 0x8f1ab8: b               #0x8f1aec
    // 0x8f1abc: ldur            x0, [fp, #-0x60]
    // 0x8f1ac0: LoadField: r1 = r0->field_b
    //     0x8f1ac0: ldur            w1, [x0, #0xb]
    // 0x8f1ac4: DecompressPointer r1
    //     0x8f1ac4: add             x1, x1, HEAP, lsl #32
    // 0x8f1ac8: LoadField: r2 = r1->field_7
    //     0x8f1ac8: ldur            w2, [x1, #7]
    // 0x8f1acc: r3 = LoadInt32Instr(r2)
    //     0x8f1acc: sbfx            x3, x2, #1, #0x1f
    // 0x8f1ad0: sub             x2, x3, #5
    // 0x8f1ad4: lsl             x3, x2, #1
    // 0x8f1ad8: stp             x3, x1, [SP, #8]
    // 0x8f1adc: r16 = "+json"
    //     0x8f1adc: add             x16, PP, #0x16, lsl #12  ; [pp+0x162b8] "+json"
    //     0x8f1ae0: ldr             x16, [x16, #0x2b8]
    // 0x8f1ae4: str             x16, [SP]
    // 0x8f1ae8: r0 = _substringMatches()
    //     0x8f1ae8: bl              #0x7ea6d8  ; [dart:core] _StringBase::_substringMatches
    // 0x8f1aec: LeaveFrame
    //     0x8f1aec: mov             SP, fp
    //     0x8f1af0: ldp             fp, lr, [SP], #0x10
    // 0x8f1af4: ret
    //     0x8f1af4: ret             
    // 0x8f1af8: sub             SP, fp, #0x78
    // 0x8f1afc: ldur            x3, [fp, #-0x58]
    // 0x8f1b00: r1 = Null
    //     0x8f1b00: mov             x1, NULL
    // 0x8f1b04: r2 = 6
    //     0x8f1b04: mov             x2, #6
    // 0x8f1b08: r0 = AllocateArray()
    //     0x8f1b08: bl              #0x13df928  ; AllocateArrayStub
    // 0x8f1b0c: r16 = "Failed to parse the media type: "
    //     0x8f1b0c: add             x16, PP, #0x16, lsl #12  ; [pp+0x162c0] "Failed to parse the media type: "
    //     0x8f1b10: ldr             x16, [x16, #0x2c0]
    // 0x8f1b14: StoreField: r0->field_f = r16
    //     0x8f1b14: stur            w16, [x0, #0xf]
    // 0x8f1b18: ldur            x1, [fp, #-0x58]
    // 0x8f1b1c: StoreField: r0->field_13 = r1
    //     0x8f1b1c: stur            w1, [x0, #0x13]
    // 0x8f1b20: r16 = ", thus it is not a JSON MIME type."
    //     0x8f1b20: add             x16, PP, #0x16, lsl #12  ; [pp+0x162c8] ", thus it is not a JSON MIME type."
    //     0x8f1b24: ldr             x16, [x16, #0x2c8]
    // 0x8f1b28: ArrayStore: r0[0] = r16  ; List_4
    //     0x8f1b28: stur            w16, [x0, #0x17]
    // 0x8f1b2c: str             x0, [SP]
    // 0x8f1b30: r0 = _interpolate()
    //     0x8f1b30: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x8f1b34: r0 = false
    //     0x8f1b34: add             x0, NULL, #0x30  ; false
    // 0x8f1b38: LeaveFrame
    //     0x8f1b38: mov             SP, fp
    //     0x8f1b3c: ldp             fp, lr, [SP], #0x10
    // 0x8f1b40: ret
    //     0x8f1b40: ret             
    // 0x8f1b44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f1b44: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f1b48: b               #0x8f19f4
  }
  static _ urlEncodeQueryMap(/* No info */) {
    // ** addr: 0x90c960, size: 0x60
    // 0x90c960: EnterFrame
    //     0x90c960: stp             fp, lr, [SP, #-0x10]!
    //     0x90c964: mov             fp, SP
    // 0x90c968: AllocStack(0x10)
    //     0x90c968: sub             SP, SP, #0x10
    // 0x90c96c: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */)
    //     0x90c96c: mov             x0, x1
    //     0x90c970: stur            x1, [fp, #-8]
    // 0x90c974: CheckStackOverflow
    //     0x90c974: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x90c978: cmp             SP, x16
    //     0x90c97c: b.ls            #0x90c9b8
    // 0x90c980: r1 = Function '<anonymous closure>': static.
    //     0x90c980: add             x1, PP, #0x16, lsl #12  ; [pp+0x16598] AnonymousClosure: static (0x90d6fc), in [package:dio/src/transformer.dart] Transformer::urlEncodeQueryMap (0x90c960)
    //     0x90c984: ldr             x1, [x1, #0x598]
    // 0x90c988: r2 = Null
    //     0x90c988: mov             x2, NULL
    // 0x90c98c: r0 = AllocateClosure()
    //     0x90c98c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x90c990: r16 = true
    //     0x90c990: add             x16, NULL, #0x20  ; true
    // 0x90c994: str             x16, [SP]
    // 0x90c998: ldur            x1, [fp, #-8]
    // 0x90c99c: mov             x2, x0
    // 0x90c9a0: r4 = const [0, 0x3, 0x1, 0x2, isQuery, 0x2, null]
    //     0x90c9a0: add             x4, PP, #0x16, lsl #12  ; [pp+0x165a0] List(7) [0, 0x3, 0x1, 0x2, "isQuery", 0x2, Null]
    //     0x90c9a4: ldr             x4, [x4, #0x5a0]
    // 0x90c9a8: r0 = encodeMap()
    //     0x90c9a8: bl              #0x90c9c0  ; [package:dio/src/utils.dart] ::encodeMap
    // 0x90c9ac: LeaveFrame
    //     0x90c9ac: mov             SP, fp
    //     0x90c9b0: ldp             fp, lr, [SP], #0x10
    // 0x90c9b4: ret
    //     0x90c9b4: ret             
    // 0x90c9b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x90c9b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x90c9bc: b               #0x90c980
  }
  [closure] static String <anonymous closure>(dynamic, String, Object?) {
    // ** addr: 0x90d6fc, size: 0x7c
    // 0x90d6fc: EnterFrame
    //     0x90d6fc: stp             fp, lr, [SP, #-0x10]!
    //     0x90d700: mov             fp, SP
    // 0x90d704: AllocStack(0x8)
    //     0x90d704: sub             SP, SP, #8
    // 0x90d708: CheckStackOverflow
    //     0x90d708: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x90d70c: cmp             SP, x16
    //     0x90d710: b.ls            #0x90d770
    // 0x90d714: ldr             x0, [fp, #0x10]
    // 0x90d718: cmp             w0, NULL
    // 0x90d71c: b.ne            #0x90d730
    // 0x90d720: ldr             x0, [fp, #0x18]
    // 0x90d724: LeaveFrame
    //     0x90d724: mov             SP, fp
    //     0x90d728: ldp             fp, lr, [SP], #0x10
    // 0x90d72c: ret
    //     0x90d72c: ret             
    // 0x90d730: ldr             x3, [fp, #0x18]
    // 0x90d734: r1 = Null
    //     0x90d734: mov             x1, NULL
    // 0x90d738: r2 = 6
    //     0x90d738: mov             x2, #6
    // 0x90d73c: r0 = AllocateArray()
    //     0x90d73c: bl              #0x13df928  ; AllocateArrayStub
    // 0x90d740: mov             x1, x0
    // 0x90d744: ldr             x0, [fp, #0x18]
    // 0x90d748: StoreField: r1->field_f = r0
    //     0x90d748: stur            w0, [x1, #0xf]
    // 0x90d74c: r16 = "="
    //     0x90d74c: ldr             x16, [PP, #0x11d0]  ; [pp+0x11d0] "="
    // 0x90d750: StoreField: r1->field_13 = r16
    //     0x90d750: stur            w16, [x1, #0x13]
    // 0x90d754: ldr             x0, [fp, #0x10]
    // 0x90d758: ArrayStore: r1[0] = r0  ; List_4
    //     0x90d758: stur            w0, [x1, #0x17]
    // 0x90d75c: str             x1, [SP]
    // 0x90d760: r0 = _interpolate()
    //     0x90d760: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x90d764: LeaveFrame
    //     0x90d764: mov             SP, fp
    //     0x90d768: ldp             fp, lr, [SP], #0x10
    // 0x90d76c: ret
    //     0x90d76c: ret             
    // 0x90d770: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x90d770: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x90d774: b               #0x90d714
  }
  static _ defaultTransformRequest(/* No info */) {
    // ** addr: 0x90f590, size: 0x2d4
    // 0x90f590: EnterFrame
    //     0x90f590: stp             fp, lr, [SP, #-0x10]!
    //     0x90f594: mov             fp, SP
    // 0x90f598: AllocStack(0x18)
    //     0x90f598: sub             SP, SP, #0x18
    // 0x90f59c: SetupParameters(dynamic _ /* r1 => r0, fp-0x10 */)
    //     0x90f59c: mov             x0, x1
    //     0x90f5a0: stur            x1, [fp, #-0x10]
    // 0x90f5a4: CheckStackOverflow
    //     0x90f5a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x90f5a8: cmp             SP, x16
    //     0x90f5ac: b.ls            #0x90f850
    // 0x90f5b0: LoadField: r1 = r0->field_5b
    //     0x90f5b0: ldur            w1, [x0, #0x5b]
    // 0x90f5b4: DecompressPointer r1
    //     0x90f5b4: add             x1, x1, HEAP, lsl #32
    // 0x90f5b8: cmp             w1, NULL
    // 0x90f5bc: b.ne            #0x90f5c8
    // 0x90f5c0: r2 = ""
    //     0x90f5c0: ldr             x2, [PP, #0x900]  ; [pp+0x900] ""
    // 0x90f5c4: b               #0x90f5cc
    // 0x90f5c8: mov             x2, x1
    // 0x90f5cc: stur            x2, [fp, #-8]
    // 0x90f5d0: r1 = 60
    //     0x90f5d0: mov             x1, #0x3c
    // 0x90f5d4: branchIfSmi(r2, 0x90f5e0)
    //     0x90f5d4: tbz             w2, #0, #0x90f5e0
    // 0x90f5d8: r1 = LoadClassIdInstr(r2)
    //     0x90f5d8: ldur            x1, [x2, #-1]
    //     0x90f5dc: ubfx            x1, x1, #0xc, #0x14
    // 0x90f5e0: sub             x16, x1, #0x5e
    // 0x90f5e4: cmp             x16, #1
    // 0x90f5e8: b.ls            #0x90f620
    // 0x90f5ec: mov             x1, x0
    // 0x90f5f0: r0 = contentType()
    //     0x90f5f0: bl              #0x90f998  ; [package:dio/src/options.dart] _RequestConfig::contentType
    // 0x90f5f4: mov             x1, x0
    // 0x90f5f8: r0 = isJsonMimeType()
    //     0x90f5f8: bl              #0x8f19d8  ; [package:dio/src/transformer.dart] Transformer::isJsonMimeType
    // 0x90f5fc: tbnz            w0, #4, #0x90f620
    // 0x90f600: str             NULL, [SP]
    // 0x90f604: ldur            x1, [fp, #-8]
    // 0x90f608: r4 = const [0, 0x2, 0x1, 0x1, toEncodable, 0x1, null]
    //     0x90f608: add             x4, PP, #0x16, lsl #12  ; [pp+0x16750] List(7) [0, 0x2, 0x1, 0x1, "toEncodable", 0x1, Null]
    //     0x90f60c: ldr             x4, [x4, #0x750]
    // 0x90f610: r0 = jsonEncode()
    //     0x90f610: bl              #0x8e9538  ; [dart:convert] ::jsonEncode
    // 0x90f614: LeaveFrame
    //     0x90f614: mov             SP, fp
    //     0x90f618: ldp             fp, lr, [SP], #0x10
    // 0x90f61c: ret
    //     0x90f61c: ret             
    // 0x90f620: ldur            x0, [fp, #-8]
    // 0x90f624: r2 = Null
    //     0x90f624: mov             x2, NULL
    // 0x90f628: r1 = Null
    //     0x90f628: mov             x1, NULL
    // 0x90f62c: cmp             w0, NULL
    // 0x90f630: b.eq            #0x90f6c8
    // 0x90f634: branchIfSmi(r0, 0x90f6c8)
    //     0x90f634: tbz             w0, #0, #0x90f6c8
    // 0x90f638: r3 = LoadClassIdInstr(r0)
    //     0x90f638: ldur            x3, [x0, #-1]
    //     0x90f63c: ubfx            x3, x3, #0xc, #0x14
    // 0x90f640: r17 = 7630
    //     0x90f640: mov             x17, #0x1dce
    // 0x90f644: cmp             x3, x17
    // 0x90f648: b.eq            #0x90f6d0
    // 0x90f64c: r4 = LoadClassIdInstr(r0)
    //     0x90f64c: ldur            x4, [x0, #-1]
    //     0x90f650: ubfx            x4, x4, #0xc, #0x14
    // 0x90f654: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x90f658: ldr             x3, [x3, #0x18]
    // 0x90f65c: ldr             x3, [x3, x4, lsl #3]
    // 0x90f660: LoadField: r3 = r3->field_2b
    //     0x90f660: ldur            w3, [x3, #0x2b]
    // 0x90f664: DecompressPointer r3
    //     0x90f664: add             x3, x3, HEAP, lsl #32
    // 0x90f668: cmp             w3, NULL
    // 0x90f66c: b.eq            #0x90f6c8
    // 0x90f670: LoadField: r3 = r3->field_f
    //     0x90f670: ldur            w3, [x3, #0xf]
    // 0x90f674: lsr             x3, x3, #3
    // 0x90f678: r17 = 7630
    //     0x90f678: mov             x17, #0x1dce
    // 0x90f67c: cmp             x3, x17
    // 0x90f680: b.eq            #0x90f6d0
    // 0x90f684: r3 = SubtypeTestCache
    //     0x90f684: add             x3, PP, #0x16, lsl #12  ; [pp+0x16758] SubtypeTestCache
    //     0x90f688: ldr             x3, [x3, #0x758]
    // 0x90f68c: r30 = Subtype1TestCacheStub
    //     0x90f68c: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x90f690: LoadField: r30 = r30->field_7
    //     0x90f690: ldur            lr, [lr, #7]
    // 0x90f694: blr             lr
    // 0x90f698: cmp             w7, NULL
    // 0x90f69c: b.eq            #0x90f6a8
    // 0x90f6a0: tbnz            w7, #4, #0x90f6c8
    // 0x90f6a4: b               #0x90f6d0
    // 0x90f6a8: r8 = Map
    //     0x90f6a8: add             x8, PP, #0x16, lsl #12  ; [pp+0x16760] Type: Map
    //     0x90f6ac: ldr             x8, [x8, #0x760]
    // 0x90f6b0: r3 = SubtypeTestCache
    //     0x90f6b0: add             x3, PP, #0x16, lsl #12  ; [pp+0x16768] SubtypeTestCache
    //     0x90f6b4: ldr             x3, [x3, #0x768]
    // 0x90f6b8: r30 = InstanceOfStub
    //     0x90f6b8: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x90f6bc: LoadField: r30 = r30->field_7
    //     0x90f6bc: ldur            lr, [lr, #7]
    // 0x90f6c0: blr             lr
    // 0x90f6c4: b               #0x90f6d4
    // 0x90f6c8: r0 = false
    //     0x90f6c8: add             x0, NULL, #0x30  ; false
    // 0x90f6cc: b               #0x90f6d4
    // 0x90f6d0: r0 = true
    //     0x90f6d0: add             x0, NULL, #0x20  ; true
    // 0x90f6d4: tbnz            w0, #4, #0x90f814
    // 0x90f6d8: ldur            x0, [fp, #-8]
    // 0x90f6dc: r2 = Null
    //     0x90f6dc: mov             x2, NULL
    // 0x90f6e0: r1 = Null
    //     0x90f6e0: mov             x1, NULL
    // 0x90f6e4: cmp             w0, NULL
    // 0x90f6e8: b.eq            #0x90f734
    // 0x90f6ec: branchIfSmi(r0, 0x90f734)
    //     0x90f6ec: tbz             w0, #0, #0x90f734
    // 0x90f6f0: r3 = SubtypeTestCache
    //     0x90f6f0: add             x3, PP, #0x16, lsl #12  ; [pp+0x16770] SubtypeTestCache
    //     0x90f6f4: ldr             x3, [x3, #0x770]
    // 0x90f6f8: r30 = Subtype2TestCacheStub
    //     0x90f6f8: ldr             lr, [PP, #0x30]  ; [pp+0x30] Stub: Subtype2TestCache (0x7d2e44)
    // 0x90f6fc: LoadField: r30 = r30->field_7
    //     0x90f6fc: ldur            lr, [lr, #7]
    // 0x90f700: blr             lr
    // 0x90f704: cmp             w7, NULL
    // 0x90f708: b.eq            #0x90f714
    // 0x90f70c: tbnz            w7, #4, #0x90f734
    // 0x90f710: b               #0x90f73c
    // 0x90f714: r8 = Map<String, dynamic>
    //     0x90f714: add             x8, PP, #0x16, lsl #12  ; [pp+0x16778] Type: Map<String, dynamic>
    //     0x90f718: ldr             x8, [x8, #0x778]
    // 0x90f71c: r3 = SubtypeTestCache
    //     0x90f71c: add             x3, PP, #0x16, lsl #12  ; [pp+0x16780] SubtypeTestCache
    //     0x90f720: ldr             x3, [x3, #0x780]
    // 0x90f724: r30 = InstanceOfStub
    //     0x90f724: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x90f728: LoadField: r30 = r30->field_7
    //     0x90f728: ldur            lr, [lr, #7]
    // 0x90f72c: blr             lr
    // 0x90f730: b               #0x90f740
    // 0x90f734: r0 = false
    //     0x90f734: add             x0, NULL, #0x30  ; false
    // 0x90f738: b               #0x90f740
    // 0x90f73c: r0 = true
    //     0x90f73c: add             x0, NULL, #0x20  ; true
    // 0x90f740: tbnz            w0, #4, #0x90f770
    // 0x90f744: ldur            x0, [fp, #-0x10]
    // 0x90f748: LoadField: r1 = r0->field_47
    //     0x90f748: ldur            w1, [x0, #0x47]
    // 0x90f74c: DecompressPointer r1
    //     0x90f74c: add             x1, x1, HEAP, lsl #32
    // 0x90f750: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x90f754: cmp             w1, w16
    // 0x90f758: b.eq            #0x90f858
    // 0x90f75c: ldur            x1, [fp, #-8]
    // 0x90f760: r0 = urlEncodeMap()
    //     0x90f760: bl              #0x90f864  ; [package:dio/src/transformer.dart] Transformer::urlEncodeMap
    // 0x90f764: LeaveFrame
    //     0x90f764: mov             SP, fp
    //     0x90f768: ldp             fp, lr, [SP], #0x10
    // 0x90f76c: ret
    //     0x90f76c: ret             
    // 0x90f770: ldur            x0, [fp, #-8]
    // 0x90f774: r1 = Null
    //     0x90f774: mov             x1, NULL
    // 0x90f778: r2 = 6
    //     0x90f778: mov             x2, #6
    // 0x90f77c: r0 = AllocateArray()
    //     0x90f77c: bl              #0x13df928  ; AllocateArrayStub
    // 0x90f780: stur            x0, [fp, #-0x10]
    // 0x90f784: r16 = "The data is a type of `Map` ("
    //     0x90f784: add             x16, PP, #0x16, lsl #12  ; [pp+0x16788] "The data is a type of `Map` ("
    //     0x90f788: ldr             x16, [x16, #0x788]
    // 0x90f78c: StoreField: r0->field_f = r16
    //     0x90f78c: stur            w16, [x0, #0xf]
    // 0x90f790: ldur            x16, [fp, #-8]
    // 0x90f794: str             x16, [SP]
    // 0x90f798: r0 = runtimeType()
    //     0x90f798: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x90f79c: ldur            x1, [fp, #-0x10]
    // 0x90f7a0: ArrayStore: r1[1] = r0  ; List_4
    //     0x90f7a0: add             x25, x1, #0x13
    //     0x90f7a4: str             w0, [x25]
    //     0x90f7a8: tbz             w0, #0, #0x90f7c4
    //     0x90f7ac: ldurb           w16, [x1, #-1]
    //     0x90f7b0: ldurb           w17, [x0, #-1]
    //     0x90f7b4: and             x16, x17, x16, lsr #2
    //     0x90f7b8: tst             x16, HEAP, lsr #32
    //     0x90f7bc: b.eq            #0x90f7c4
    //     0x90f7c0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x90f7c4: ldur            x0, [fp, #-0x10]
    // 0x90f7c8: r16 = "), but the transformer can only encode `Map<String, dynamic>`.\nIf you are writing maps using `{}`, consider writing `<String, dynamic>{}`."
    //     0x90f7c8: add             x16, PP, #0x16, lsl #12  ; [pp+0x16790] "), but the transformer can only encode `Map<String, dynamic>`.\nIf you are writing maps using `{}`, consider writing `<String, dynamic>{}`."
    //     0x90f7cc: ldr             x16, [x16, #0x790]
    // 0x90f7d0: ArrayStore: r0[0] = r16  ; List_4
    //     0x90f7d0: stur            w16, [x0, #0x17]
    // 0x90f7d4: str             x0, [SP]
    // 0x90f7d8: r0 = _interpolate()
    //     0x90f7d8: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x90f7dc: r0 = current()
    //     0x90f7dc: bl              #0x7f0e88  ; [dart:core] StackTrace::current
    // 0x90f7e0: ldur            x0, [fp, #-8]
    // 0x90f7e4: r1 = LoadClassIdInstr(r0)
    //     0x90f7e4: ldur            x1, [x0, #-1]
    //     0x90f7e8: ubfx            x1, x1, #0xc, #0x14
    // 0x90f7ec: str             x0, [SP]
    // 0x90f7f0: mov             x0, x1
    // 0x90f7f4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x90f7f4: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x90f7f8: r0 = GDT[cid_x0 + 0x91c1]()
    //     0x90f7f8: mov             x17, #0x91c1
    //     0x90f7fc: add             lr, x0, x17
    //     0x90f800: ldr             lr, [x21, lr, lsl #3]
    //     0x90f804: blr             lr
    // 0x90f808: LeaveFrame
    //     0x90f808: mov             SP, fp
    //     0x90f80c: ldp             fp, lr, [SP], #0x10
    // 0x90f810: ret
    //     0x90f810: ret             
    // 0x90f814: ldur            x0, [fp, #-8]
    // 0x90f818: r1 = 60
    //     0x90f818: mov             x1, #0x3c
    // 0x90f81c: branchIfSmi(r0, 0x90f828)
    //     0x90f81c: tbz             w0, #0, #0x90f828
    // 0x90f820: r1 = LoadClassIdInstr(r0)
    //     0x90f820: ldur            x1, [x0, #-1]
    //     0x90f824: ubfx            x1, x1, #0xc, #0x14
    // 0x90f828: str             x0, [SP]
    // 0x90f82c: mov             x0, x1
    // 0x90f830: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x90f830: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x90f834: r0 = GDT[cid_x0 + 0x91c1]()
    //     0x90f834: mov             x17, #0x91c1
    //     0x90f838: add             lr, x0, x17
    //     0x90f83c: ldr             lr, [x21, lr, lsl #3]
    //     0x90f840: blr             lr
    // 0x90f844: LeaveFrame
    //     0x90f844: mov             SP, fp
    //     0x90f848: ldp             fp, lr, [SP], #0x10
    // 0x90f84c: ret
    //     0x90f84c: ret             
    // 0x90f850: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x90f850: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x90f854: b               #0x90f5b0
    // 0x90f858: r9 = listFormat
    //     0x90f858: add             x9, PP, #0x16, lsl #12  ; [pp+0x16590] Field <_RequestConfig@271184022.listFormat>: late (offset: 0x48)
    //     0x90f85c: ldr             x9, [x9, #0x590]
    // 0x90f860: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x90f860: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  static _ urlEncodeMap(/* No info */) {
    // ** addr: 0x90f864, size: 0x54
    // 0x90f864: EnterFrame
    //     0x90f864: stp             fp, lr, [SP, #-0x10]!
    //     0x90f868: mov             fp, SP
    // 0x90f86c: AllocStack(0x8)
    //     0x90f86c: sub             SP, SP, #8
    // 0x90f870: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */)
    //     0x90f870: mov             x0, x1
    //     0x90f874: stur            x1, [fp, #-8]
    // 0x90f878: CheckStackOverflow
    //     0x90f878: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x90f87c: cmp             SP, x16
    //     0x90f880: b.ls            #0x90f8b0
    // 0x90f884: r1 = Function '<anonymous closure>': static.
    //     0x90f884: add             x1, PP, #0x16, lsl #12  ; [pp+0x16798] AnonymousClosure: static (0x90f8b8), in [package:dio/src/transformer.dart] Transformer::urlEncodeMap (0x90f864)
    //     0x90f888: ldr             x1, [x1, #0x798]
    // 0x90f88c: r2 = Null
    //     0x90f88c: mov             x2, NULL
    // 0x90f890: r0 = AllocateClosure()
    //     0x90f890: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x90f894: ldur            x1, [fp, #-8]
    // 0x90f898: mov             x2, x0
    // 0x90f89c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x90f89c: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x90f8a0: r0 = encodeMap()
    //     0x90f8a0: bl              #0x90c9c0  ; [package:dio/src/utils.dart] ::encodeMap
    // 0x90f8a4: LeaveFrame
    //     0x90f8a4: mov             SP, fp
    //     0x90f8a8: ldp             fp, lr, [SP], #0x10
    // 0x90f8ac: ret
    //     0x90f8ac: ret             
    // 0x90f8b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x90f8b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x90f8b4: b               #0x90f884
  }
  [closure] static String <anonymous closure>(dynamic, String, Object?) {
    // ** addr: 0x90f8b8, size: 0xe0
    // 0x90f8b8: EnterFrame
    //     0x90f8b8: stp             fp, lr, [SP, #-0x10]!
    //     0x90f8bc: mov             fp, SP
    // 0x90f8c0: AllocStack(0x10)
    //     0x90f8c0: sub             SP, SP, #0x10
    // 0x90f8c4: CheckStackOverflow
    //     0x90f8c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x90f8c8: cmp             SP, x16
    //     0x90f8cc: b.ls            #0x90f990
    // 0x90f8d0: ldr             x0, [fp, #0x10]
    // 0x90f8d4: cmp             w0, NULL
    // 0x90f8d8: b.ne            #0x90f8ec
    // 0x90f8dc: ldr             x0, [fp, #0x18]
    // 0x90f8e0: LeaveFrame
    //     0x90f8e0: mov             SP, fp
    //     0x90f8e4: ldp             fp, lr, [SP], #0x10
    // 0x90f8e8: ret
    //     0x90f8e8: ret             
    // 0x90f8ec: ldr             x3, [fp, #0x18]
    // 0x90f8f0: r1 = Null
    //     0x90f8f0: mov             x1, NULL
    // 0x90f8f4: r2 = 6
    //     0x90f8f4: mov             x2, #6
    // 0x90f8f8: r0 = AllocateArray()
    //     0x90f8f8: bl              #0x13df928  ; AllocateArrayStub
    // 0x90f8fc: mov             x1, x0
    // 0x90f900: ldr             x0, [fp, #0x18]
    // 0x90f904: stur            x1, [fp, #-8]
    // 0x90f908: StoreField: r1->field_f = r0
    //     0x90f908: stur            w0, [x1, #0xf]
    // 0x90f90c: r16 = "="
    //     0x90f90c: ldr             x16, [PP, #0x11d0]  ; [pp+0x11d0] "="
    // 0x90f910: StoreField: r1->field_13 = r16
    //     0x90f910: stur            w16, [x1, #0x13]
    // 0x90f914: ldr             x0, [fp, #0x10]
    // 0x90f918: r2 = 60
    //     0x90f918: mov             x2, #0x3c
    // 0x90f91c: branchIfSmi(r0, 0x90f928)
    //     0x90f91c: tbz             w0, #0, #0x90f928
    // 0x90f920: r2 = LoadClassIdInstr(r0)
    //     0x90f920: ldur            x2, [x0, #-1]
    //     0x90f924: ubfx            x2, x2, #0xc, #0x14
    // 0x90f928: str             x0, [SP]
    // 0x90f92c: mov             x0, x2
    // 0x90f930: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x90f930: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x90f934: r0 = GDT[cid_x0 + 0x91c1]()
    //     0x90f934: mov             x17, #0x91c1
    //     0x90f938: add             lr, x0, x17
    //     0x90f93c: ldr             lr, [x21, lr, lsl #3]
    //     0x90f940: blr             lr
    // 0x90f944: mov             x1, x0
    // 0x90f948: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x90f948: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x90f94c: r0 = encodeQueryComponent()
    //     0x90f94c: bl              #0x7e7498  ; [dart:core] Uri::encodeQueryComponent
    // 0x90f950: ldur            x1, [fp, #-8]
    // 0x90f954: ArrayStore: r1[2] = r0  ; List_4
    //     0x90f954: add             x25, x1, #0x17
    //     0x90f958: str             w0, [x25]
    //     0x90f95c: tbz             w0, #0, #0x90f978
    //     0x90f960: ldurb           w16, [x1, #-1]
    //     0x90f964: ldurb           w17, [x0, #-1]
    //     0x90f968: and             x16, x17, x16, lsr #2
    //     0x90f96c: tst             x16, HEAP, lsr #32
    //     0x90f970: b.eq            #0x90f978
    //     0x90f974: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x90f978: ldur            x16, [fp, #-8]
    // 0x90f97c: str             x16, [SP]
    // 0x90f980: r0 = _interpolate()
    //     0x90f980: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x90f984: LeaveFrame
    //     0x90f984: mov             SP, fp
    //     0x90f988: ldp             fp, lr, [SP], #0x10
    // 0x90f98c: ret
    //     0x90f98c: ret             
    // 0x90f990: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x90f990: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x90f994: b               #0x90f8d0
  }
}
