// lib: , url: package:dio/src/redirect_record.dart

// class id: 1048710, size: 0x8
class :: {
}

// class id: 3400, size: 0x18, field offset: 0x8
//   const constructor, 
class RedirectRecord extends Object {

  _ toString(/* No info */) {
    // ** addr: 0x1114810, size: 0xac
    // 0x1114810: EnterFrame
    //     0x1114810: stp             fp, lr, [SP, #-0x10]!
    //     0x1114814: mov             fp, SP
    // 0x1114818: AllocStack(0x8)
    //     0x1114818: sub             SP, SP, #8
    // 0x111481c: CheckStackOverflow
    //     0x111481c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1114820: cmp             SP, x16
    //     0x1114824: b.ls            #0x11148b4
    // 0x1114828: r1 = Null
    //     0x1114828: mov             x1, NULL
    // 0x111482c: r2 = 14
    //     0x111482c: mov             x2, #0xe
    // 0x1114830: r0 = AllocateArray()
    //     0x1114830: bl              #0x13df928  ; AllocateArrayStub
    // 0x1114834: mov             x2, x0
    // 0x1114838: r16 = "RedirectRecord{statusCode: "
    //     0x1114838: add             x16, PP, #0x81, lsl #12  ; [pp+0x814d0] "RedirectRecord{statusCode: "
    //     0x111483c: ldr             x16, [x16, #0x4d0]
    // 0x1114840: StoreField: r2->field_f = r16
    //     0x1114840: stur            w16, [x2, #0xf]
    // 0x1114844: ldr             x3, [fp, #0x10]
    // 0x1114848: LoadField: r4 = r3->field_7
    //     0x1114848: ldur            x4, [x3, #7]
    // 0x111484c: r0 = BoxInt64Instr(r4)
    //     0x111484c: sbfiz           x0, x4, #1, #0x1f
    //     0x1114850: cmp             x4, x0, asr #1
    //     0x1114854: b.eq            #0x1114860
    //     0x1114858: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x111485c: stur            x4, [x0, #7]
    // 0x1114860: StoreField: r2->field_13 = r0
    //     0x1114860: stur            w0, [x2, #0x13]
    // 0x1114864: r16 = ", method: "
    //     0x1114864: add             x16, PP, #0x81, lsl #12  ; [pp+0x814d8] ", method: "
    //     0x1114868: ldr             x16, [x16, #0x4d8]
    // 0x111486c: ArrayStore: r2[0] = r16  ; List_4
    //     0x111486c: stur            w16, [x2, #0x17]
    // 0x1114870: LoadField: r0 = r3->field_f
    //     0x1114870: ldur            w0, [x3, #0xf]
    // 0x1114874: DecompressPointer r0
    //     0x1114874: add             x0, x0, HEAP, lsl #32
    // 0x1114878: StoreField: r2->field_1b = r0
    //     0x1114878: stur            w0, [x2, #0x1b]
    // 0x111487c: r16 = ", location: "
    //     0x111487c: add             x16, PP, #0x81, lsl #12  ; [pp+0x814e0] ", location: "
    //     0x1114880: ldr             x16, [x16, #0x4e0]
    // 0x1114884: StoreField: r2->field_1f = r16
    //     0x1114884: stur            w16, [x2, #0x1f]
    // 0x1114888: LoadField: r0 = r3->field_13
    //     0x1114888: ldur            w0, [x3, #0x13]
    // 0x111488c: DecompressPointer r0
    //     0x111488c: add             x0, x0, HEAP, lsl #32
    // 0x1114890: StoreField: r2->field_23 = r0
    //     0x1114890: stur            w0, [x2, #0x23]
    // 0x1114894: r16 = "}"
    //     0x1114894: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf78] "}"
    //     0x1114898: ldr             x16, [x16, #0xf78]
    // 0x111489c: StoreField: r2->field_27 = r16
    //     0x111489c: stur            w16, [x2, #0x27]
    // 0x11148a0: str             x2, [SP]
    // 0x11148a4: r0 = _interpolate()
    //     0x11148a4: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11148a8: LeaveFrame
    //     0x11148a8: mov             SP, fp
    //     0x11148ac: ldp             fp, lr, [SP], #0x10
    // 0x11148b0: ret
    //     0x11148b0: ret             
    // 0x11148b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11148b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11148b8: b               #0x1114828
  }
}
