// lib: , url: package:dio/src/adapter.dart

// class id: 1048695, size: 0x8
class :: {
}

// class id: 3415, size: 0x2c, field offset: 0x8
class ResponseBody extends Object {

  get _ contentLength(/* No info */) {
    // ** addr: 0x8f48c4, size: 0xb0
    // 0x8f48c4: EnterFrame
    //     0x8f48c4: stp             fp, lr, [SP, #-0x10]!
    //     0x8f48c8: mov             fp, SP
    // 0x8f48cc: CheckStackOverflow
    //     0x8f48cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f48d0: cmp             SP, x16
    //     0x8f48d4: b.ls            #0x8f496c
    // 0x8f48d8: LoadField: r0 = r1->field_1f
    //     0x8f48d8: ldur            w0, [x1, #0x1f]
    // 0x8f48dc: DecompressPointer r0
    //     0x8f48dc: add             x0, x0, HEAP, lsl #32
    // 0x8f48e0: r1 = LoadClassIdInstr(r0)
    //     0x8f48e0: ldur            x1, [x0, #-1]
    //     0x8f48e4: ubfx            x1, x1, #0xc, #0x14
    // 0x8f48e8: mov             x16, x0
    // 0x8f48ec: mov             x0, x1
    // 0x8f48f0: mov             x1, x16
    // 0x8f48f4: r2 = "content-length"
    //     0x8f48f4: add             x2, PP, #0xb, lsl #12  ; [pp+0xba48] "content-length"
    //     0x8f48f8: ldr             x2, [x2, #0xa48]
    // 0x8f48fc: r0 = GDT[cid_x0 + -0xd48]()
    //     0x8f48fc: sub             lr, x0, #0xd48
    //     0x8f4900: ldr             lr, [x21, lr, lsl #3]
    //     0x8f4904: blr             lr
    // 0x8f4908: cmp             w0, NULL
    // 0x8f490c: b.ne            #0x8f4918
    // 0x8f4910: r0 = Null
    //     0x8f4910: mov             x0, NULL
    // 0x8f4914: b               #0x8f4940
    // 0x8f4918: r1 = LoadClassIdInstr(r0)
    //     0x8f4918: ldur            x1, [x0, #-1]
    //     0x8f491c: ubfx            x1, x1, #0xc, #0x14
    // 0x8f4920: mov             x16, x0
    // 0x8f4924: mov             x0, x1
    // 0x8f4928: mov             x1, x16
    // 0x8f492c: r0 = GDT[cid_x0 + 0x127b5]()
    //     0x8f492c: mov             x17, #0x27b5
    //     0x8f4930: movk            x17, #1, lsl #16
    //     0x8f4934: add             lr, x0, x17
    //     0x8f4938: ldr             lr, [x21, lr, lsl #3]
    //     0x8f493c: blr             lr
    // 0x8f4940: cmp             w0, NULL
    // 0x8f4944: b.ne            #0x8f4954
    // 0x8f4948: r1 = "-1"
    //     0x8f4948: add             x1, PP, #0x16, lsl #12  ; [pp+0x16400] "-1"
    //     0x8f494c: ldr             x1, [x1, #0x400]
    // 0x8f4950: b               #0x8f4958
    // 0x8f4954: mov             x1, x0
    // 0x8f4958: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8f4958: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8f495c: r0 = parse()
    //     0x8f495c: bl              #0x8220cc  ; [dart:core] int::parse
    // 0x8f4960: LeaveFrame
    //     0x8f4960: mov             SP, fp
    //     0x8f4964: ldp             fp, lr, [SP], #0x10
    // 0x8f4968: ret
    //     0x8f4968: ret             
    // 0x8f496c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f496c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f4970: b               #0x8f48d8
  }
  _ ResponseBody(/* No info */) {
    // ** addr: 0x8f6504, size: 0x114
    // 0x8f6504: EnterFrame
    //     0x8f6504: stp             fp, lr, [SP, #-0x10]!
    //     0x8f6508: mov             fp, SP
    // 0x8f650c: AllocStack(0x40)
    //     0x8f650c: sub             SP, SP, #0x40
    // 0x8f6510: SetupParameters(ResponseBody this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r1, fp-0x20 */, dynamic _ /* r6 => r6, fp-0x28 */, dynamic _ /* r7 => r0, fp-0x30 */)
    //     0x8f6510: mov             x4, x1
    //     0x8f6514: stur            x1, [fp, #-8]
    //     0x8f6518: mov             x1, x5
    //     0x8f651c: mov             x0, x7
    //     0x8f6520: stur            x2, [fp, #-0x10]
    //     0x8f6524: stur            x3, [fp, #-0x18]
    //     0x8f6528: stur            x5, [fp, #-0x20]
    //     0x8f652c: stur            x6, [fp, #-0x28]
    //     0x8f6530: stur            x7, [fp, #-0x30]
    // 0x8f6534: CheckStackOverflow
    //     0x8f6534: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f6538: cmp             SP, x16
    //     0x8f653c: b.ls            #0x8f6610
    // 0x8f6540: r16 = <String, dynamic>
    //     0x8f6540: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x8f6544: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x8f6548: stp             lr, x16, [SP]
    // 0x8f654c: r0 = Map._fromLiteral()
    //     0x8f654c: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x8f6550: ldur            x1, [fp, #-8]
    // 0x8f6554: StoreField: r1->field_23 = r0
    //     0x8f6554: stur            w0, [x1, #0x23]
    //     0x8f6558: ldurb           w16, [x1, #-1]
    //     0x8f655c: ldurb           w17, [x0, #-1]
    //     0x8f6560: and             x16, x17, x16, lsr #2
    //     0x8f6564: tst             x16, HEAP, lsr #32
    //     0x8f6568: b.eq            #0x8f6570
    //     0x8f656c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8f6570: ldur            x0, [fp, #-0x10]
    // 0x8f6574: StoreField: r1->field_b = r0
    //     0x8f6574: stur            w0, [x1, #0xb]
    //     0x8f6578: ldurb           w16, [x1, #-1]
    //     0x8f657c: ldurb           w17, [x0, #-1]
    //     0x8f6580: and             x16, x17, x16, lsr #2
    //     0x8f6584: tst             x16, HEAP, lsr #32
    //     0x8f6588: b.eq            #0x8f6590
    //     0x8f658c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8f6590: ldur            x2, [fp, #-0x18]
    // 0x8f6594: StoreField: r1->field_f = r2
    //     0x8f6594: stur            x2, [x1, #0xf]
    // 0x8f6598: ldr             x0, [fp, #0x10]
    // 0x8f659c: ArrayStore: r1[0] = r0  ; List_4
    //     0x8f659c: stur            w0, [x1, #0x17]
    //     0x8f65a0: ldurb           w16, [x1, #-1]
    //     0x8f65a4: ldurb           w17, [x0, #-1]
    //     0x8f65a8: and             x16, x17, x16, lsr #2
    //     0x8f65ac: tst             x16, HEAP, lsr #32
    //     0x8f65b0: b.eq            #0x8f65b8
    //     0x8f65b4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8f65b8: ldur            x2, [fp, #-0x28]
    // 0x8f65bc: StoreField: r1->field_7 = r2
    //     0x8f65bc: stur            w2, [x1, #7]
    // 0x8f65c0: ldur            x0, [fp, #-0x30]
    // 0x8f65c4: StoreField: r1->field_1b = r0
    //     0x8f65c4: stur            w0, [x1, #0x1b]
    //     0x8f65c8: ldurb           w16, [x1, #-1]
    //     0x8f65cc: ldurb           w17, [x0, #-1]
    //     0x8f65d0: and             x16, x17, x16, lsr #2
    //     0x8f65d4: tst             x16, HEAP, lsr #32
    //     0x8f65d8: b.eq            #0x8f65e0
    //     0x8f65dc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8f65e0: ldur            x0, [fp, #-0x20]
    // 0x8f65e4: StoreField: r1->field_1f = r0
    //     0x8f65e4: stur            w0, [x1, #0x1f]
    //     0x8f65e8: ldurb           w16, [x1, #-1]
    //     0x8f65ec: ldurb           w17, [x0, #-1]
    //     0x8f65f0: and             x16, x17, x16, lsr #2
    //     0x8f65f4: tst             x16, HEAP, lsr #32
    //     0x8f65f8: b.eq            #0x8f6600
    //     0x8f65fc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8f6600: r0 = Null
    //     0x8f6600: mov             x0, NULL
    // 0x8f6604: LeaveFrame
    //     0x8f6604: mov             SP, fp
    //     0x8f6608: ldp             fp, lr, [SP], #0x10
    // 0x8f660c: ret
    //     0x8f660c: ret             
    // 0x8f6610: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f6610: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f6614: b               #0x8f6540
  }
}

// class id: 3416, size: 0x8, field offset: 0x8
abstract class HttpClientAdapter extends Object {
}
