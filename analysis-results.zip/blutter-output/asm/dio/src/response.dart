// lib: , url: package:dio/src/response.dart

// class id: 1048711, size: 0x8
class :: {
}

// class id: 3399, size: 0x2c, field offset: 0x8
class Response<X0> extends Object {

  _ Response(/* No info */) {
    // ** addr: 0x8ed6e8, size: 0x414
    // 0x8ed6e8: EnterFrame
    //     0x8ed6e8: stp             fp, lr, [SP, #-0x10]!
    //     0x8ed6ec: mov             fp, SP
    // 0x8ed6f0: AllocStack(0x28)
    //     0x8ed6f0: sub             SP, SP, #0x28
    // 0x8ed6f4: SetupParameters(Response<X0> this /* r1 => r2, fp-0x10 */, dynamic _ /* r2 => r1 */)
    //     0x8ed6f4: stur            x1, [fp, #-0x10]
    //     0x8ed6f8: mov             x16, x2
    //     0x8ed6fc: mov             x2, x1
    //     0x8ed700: mov             x1, x16
    // 0x8ed704: LoadField: r0 = r4->field_13
    //     0x8ed704: ldur            w0, [x4, #0x13]
    // 0x8ed708: LoadField: r3 = r4->field_1f
    //     0x8ed708: ldur            w3, [x4, #0x1f]
    // 0x8ed70c: DecompressPointer r3
    //     0x8ed70c: add             x3, x3, HEAP, lsl #32
    // 0x8ed710: r16 = "data"
    //     0x8ed710: ldr             x16, [PP, #0x1370]  ; [pp+0x1370] "data"
    // 0x8ed714: cmp             w3, w16
    // 0x8ed718: b.ne            #0x8ed73c
    // 0x8ed71c: LoadField: r3 = r4->field_23
    //     0x8ed71c: ldur            w3, [x4, #0x23]
    // 0x8ed720: DecompressPointer r3
    //     0x8ed720: add             x3, x3, HEAP, lsl #32
    // 0x8ed724: sub             w5, w0, w3
    // 0x8ed728: add             x3, fp, w5, sxtw #2
    // 0x8ed72c: ldr             x3, [x3, #8]
    // 0x8ed730: mov             x5, x3
    // 0x8ed734: r3 = 1
    //     0x8ed734: mov             x3, #1
    // 0x8ed738: b               #0x8ed744
    // 0x8ed73c: r5 = Null
    //     0x8ed73c: mov             x5, NULL
    // 0x8ed740: r3 = 0
    //     0x8ed740: mov             x3, #0
    // 0x8ed744: lsl             x6, x3, #1
    // 0x8ed748: lsl             w7, w6, #1
    // 0x8ed74c: add             w8, w7, #8
    // 0x8ed750: ArrayLoad: r9 = r4[r8]  ; Unknown_4
    //     0x8ed750: add             x16, x4, w8, sxtw #1
    //     0x8ed754: ldur            w9, [x16, #0xf]
    // 0x8ed758: DecompressPointer r9
    //     0x8ed758: add             x9, x9, HEAP, lsl #32
    // 0x8ed75c: r16 = "extra"
    //     0x8ed75c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15d18] "extra"
    //     0x8ed760: ldr             x16, [x16, #0xd18]
    // 0x8ed764: cmp             w9, w16
    // 0x8ed768: b.ne            #0x8ed79c
    // 0x8ed76c: add             w3, w7, #0xa
    // 0x8ed770: ArrayLoad: r7 = r4[r3]  ; Unknown_4
    //     0x8ed770: add             x16, x4, w3, sxtw #1
    //     0x8ed774: ldur            w7, [x16, #0xf]
    // 0x8ed778: DecompressPointer r7
    //     0x8ed778: add             x7, x7, HEAP, lsl #32
    // 0x8ed77c: sub             w3, w0, w7
    // 0x8ed780: add             x7, fp, w3, sxtw #2
    // 0x8ed784: ldr             x7, [x7, #8]
    // 0x8ed788: add             w3, w6, #2
    // 0x8ed78c: r6 = LoadInt32Instr(r3)
    //     0x8ed78c: sbfx            x6, x3, #1, #0x1f
    // 0x8ed790: mov             x3, x6
    // 0x8ed794: mov             x6, x7
    // 0x8ed798: b               #0x8ed7a0
    // 0x8ed79c: r6 = Null
    //     0x8ed79c: mov             x6, NULL
    // 0x8ed7a0: stur            x6, [fp, #-8]
    // 0x8ed7a4: lsl             x7, x3, #1
    // 0x8ed7a8: lsl             w8, w7, #1
    // 0x8ed7ac: add             w9, w8, #8
    // 0x8ed7b0: ArrayLoad: r10 = r4[r9]  ; Unknown_4
    //     0x8ed7b0: add             x16, x4, w9, sxtw #1
    //     0x8ed7b4: ldur            w10, [x16, #0xf]
    // 0x8ed7b8: DecompressPointer r10
    //     0x8ed7b8: add             x10, x10, HEAP, lsl #32
    // 0x8ed7bc: r16 = "headers"
    //     0x8ed7bc: add             x16, PP, #0x15, lsl #12  ; [pp+0x15d28] "headers"
    //     0x8ed7c0: ldr             x16, [x16, #0xd28]
    // 0x8ed7c4: cmp             w10, w16
    // 0x8ed7c8: b.ne            #0x8ed7fc
    // 0x8ed7cc: add             w3, w8, #0xa
    // 0x8ed7d0: ArrayLoad: r8 = r4[r3]  ; Unknown_4
    //     0x8ed7d0: add             x16, x4, w3, sxtw #1
    //     0x8ed7d4: ldur            w8, [x16, #0xf]
    // 0x8ed7d8: DecompressPointer r8
    //     0x8ed7d8: add             x8, x8, HEAP, lsl #32
    // 0x8ed7dc: sub             w3, w0, w8
    // 0x8ed7e0: add             x8, fp, w3, sxtw #2
    // 0x8ed7e4: ldr             x8, [x8, #8]
    // 0x8ed7e8: add             w3, w7, #2
    // 0x8ed7ec: r7 = LoadInt32Instr(r3)
    //     0x8ed7ec: sbfx            x7, x3, #1, #0x1f
    // 0x8ed7f0: mov             x3, x7
    // 0x8ed7f4: mov             x7, x8
    // 0x8ed7f8: b               #0x8ed800
    // 0x8ed7fc: r7 = Null
    //     0x8ed7fc: mov             x7, NULL
    // 0x8ed800: lsl             x8, x3, #1
    // 0x8ed804: lsl             w9, w8, #1
    // 0x8ed808: add             w10, w9, #8
    // 0x8ed80c: ArrayLoad: r11 = r4[r10]  ; Unknown_4
    //     0x8ed80c: add             x16, x4, w10, sxtw #1
    //     0x8ed810: ldur            w11, [x16, #0xf]
    // 0x8ed814: DecompressPointer r11
    //     0x8ed814: add             x11, x11, HEAP, lsl #32
    // 0x8ed818: r16 = "isRedirect"
    //     0x8ed818: add             x16, PP, #8, lsl #12  ; [pp+0x8518] "isRedirect"
    //     0x8ed81c: ldr             x16, [x16, #0x518]
    // 0x8ed820: cmp             w11, w16
    // 0x8ed824: b.ne            #0x8ed858
    // 0x8ed828: add             w3, w9, #0xa
    // 0x8ed82c: ArrayLoad: r9 = r4[r3]  ; Unknown_4
    //     0x8ed82c: add             x16, x4, w3, sxtw #1
    //     0x8ed830: ldur            w9, [x16, #0xf]
    // 0x8ed834: DecompressPointer r9
    //     0x8ed834: add             x9, x9, HEAP, lsl #32
    // 0x8ed838: sub             w3, w0, w9
    // 0x8ed83c: add             x9, fp, w3, sxtw #2
    // 0x8ed840: ldr             x9, [x9, #8]
    // 0x8ed844: add             w3, w8, #2
    // 0x8ed848: r8 = LoadInt32Instr(r3)
    //     0x8ed848: sbfx            x8, x3, #1, #0x1f
    // 0x8ed84c: mov             x3, x8
    // 0x8ed850: mov             x8, x9
    // 0x8ed854: b               #0x8ed85c
    // 0x8ed858: r8 = false
    //     0x8ed858: add             x8, NULL, #0x30  ; false
    // 0x8ed85c: lsl             x9, x3, #1
    // 0x8ed860: lsl             w10, w9, #1
    // 0x8ed864: add             w11, w10, #8
    // 0x8ed868: ArrayLoad: r12 = r4[r11]  ; Unknown_4
    //     0x8ed868: add             x16, x4, w11, sxtw #1
    //     0x8ed86c: ldur            w12, [x16, #0xf]
    // 0x8ed870: DecompressPointer r12
    //     0x8ed870: add             x12, x12, HEAP, lsl #32
    // 0x8ed874: r16 = "redirects"
    //     0x8ed874: add             x16, PP, #0x16, lsl #12  ; [pp+0x168f0] "redirects"
    //     0x8ed878: ldr             x16, [x16, #0x8f0]
    // 0x8ed87c: cmp             w12, w16
    // 0x8ed880: b.ne            #0x8ed8b4
    // 0x8ed884: add             w3, w10, #0xa
    // 0x8ed888: ArrayLoad: r10 = r4[r3]  ; Unknown_4
    //     0x8ed888: add             x16, x4, w3, sxtw #1
    //     0x8ed88c: ldur            w10, [x16, #0xf]
    // 0x8ed890: DecompressPointer r10
    //     0x8ed890: add             x10, x10, HEAP, lsl #32
    // 0x8ed894: sub             w3, w0, w10
    // 0x8ed898: add             x10, fp, w3, sxtw #2
    // 0x8ed89c: ldr             x10, [x10, #8]
    // 0x8ed8a0: add             w3, w9, #2
    // 0x8ed8a4: r9 = LoadInt32Instr(r3)
    //     0x8ed8a4: sbfx            x9, x3, #1, #0x1f
    // 0x8ed8a8: mov             x3, x9
    // 0x8ed8ac: mov             x9, x10
    // 0x8ed8b0: b               #0x8ed8bc
    // 0x8ed8b4: r9 = const []
    //     0x8ed8b4: add             x9, PP, #0x16, lsl #12  ; [pp+0x168f8] List<RedirectRecord>(0)
    //     0x8ed8b8: ldr             x9, [x9, #0x8f8]
    // 0x8ed8bc: lsl             x10, x3, #1
    // 0x8ed8c0: lsl             w11, w10, #1
    // 0x8ed8c4: add             w12, w11, #8
    // 0x8ed8c8: ArrayLoad: r13 = r4[r12]  ; Unknown_4
    //     0x8ed8c8: add             x16, x4, w12, sxtw #1
    //     0x8ed8cc: ldur            w13, [x16, #0xf]
    // 0x8ed8d0: DecompressPointer r13
    //     0x8ed8d0: add             x13, x13, HEAP, lsl #32
    // 0x8ed8d4: r16 = "statusCode"
    //     0x8ed8d4: add             x16, PP, #0x16, lsl #12  ; [pp+0x16900] "statusCode"
    //     0x8ed8d8: ldr             x16, [x16, #0x900]
    // 0x8ed8dc: cmp             w13, w16
    // 0x8ed8e0: b.ne            #0x8ed914
    // 0x8ed8e4: add             w3, w11, #0xa
    // 0x8ed8e8: ArrayLoad: r11 = r4[r3]  ; Unknown_4
    //     0x8ed8e8: add             x16, x4, w3, sxtw #1
    //     0x8ed8ec: ldur            w11, [x16, #0xf]
    // 0x8ed8f0: DecompressPointer r11
    //     0x8ed8f0: add             x11, x11, HEAP, lsl #32
    // 0x8ed8f4: sub             w3, w0, w11
    // 0x8ed8f8: add             x11, fp, w3, sxtw #2
    // 0x8ed8fc: ldr             x11, [x11, #8]
    // 0x8ed900: add             w3, w10, #2
    // 0x8ed904: r10 = LoadInt32Instr(r3)
    //     0x8ed904: sbfx            x10, x3, #1, #0x1f
    // 0x8ed908: mov             x3, x10
    // 0x8ed90c: mov             x10, x11
    // 0x8ed910: b               #0x8ed918
    // 0x8ed914: r10 = Null
    //     0x8ed914: mov             x10, NULL
    // 0x8ed918: lsl             x11, x3, #1
    // 0x8ed91c: lsl             w3, w11, #1
    // 0x8ed920: add             w11, w3, #8
    // 0x8ed924: ArrayLoad: r12 = r4[r11]  ; Unknown_4
    //     0x8ed924: add             x16, x4, w11, sxtw #1
    //     0x8ed928: ldur            w12, [x16, #0xf]
    // 0x8ed92c: DecompressPointer r12
    //     0x8ed92c: add             x12, x12, HEAP, lsl #32
    // 0x8ed930: r16 = "statusMessage"
    //     0x8ed930: add             x16, PP, #0x16, lsl #12  ; [pp+0x16908] "statusMessage"
    //     0x8ed934: ldr             x16, [x16, #0x908]
    // 0x8ed938: cmp             w12, w16
    // 0x8ed93c: b.ne            #0x8ed964
    // 0x8ed940: add             w11, w3, #0xa
    // 0x8ed944: ArrayLoad: r3 = r4[r11]  ; Unknown_4
    //     0x8ed944: add             x16, x4, w11, sxtw #1
    //     0x8ed948: ldur            w3, [x16, #0xf]
    // 0x8ed94c: DecompressPointer r3
    //     0x8ed94c: add             x3, x3, HEAP, lsl #32
    // 0x8ed950: sub             w4, w0, w3
    // 0x8ed954: add             x0, fp, w4, sxtw #2
    // 0x8ed958: ldr             x0, [x0, #8]
    // 0x8ed95c: mov             x3, x0
    // 0x8ed960: b               #0x8ed968
    // 0x8ed964: r3 = Null
    //     0x8ed964: mov             x3, NULL
    // 0x8ed968: CheckStackOverflow
    //     0x8ed968: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ed96c: cmp             SP, x16
    //     0x8ed970: b.ls            #0x8edae8
    // 0x8ed974: mov             x0, x5
    // 0x8ed978: StoreField: r2->field_b = r0
    //     0x8ed978: stur            w0, [x2, #0xb]
    //     0x8ed97c: tbz             w0, #0, #0x8ed998
    //     0x8ed980: ldurb           w16, [x2, #-1]
    //     0x8ed984: ldurb           w17, [x0, #-1]
    //     0x8ed988: and             x16, x17, x16, lsr #2
    //     0x8ed98c: tst             x16, HEAP, lsr #32
    //     0x8ed990: b.eq            #0x8ed998
    //     0x8ed994: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x8ed998: mov             x0, x1
    // 0x8ed99c: StoreField: r2->field_f = r0
    //     0x8ed99c: stur            w0, [x2, #0xf]
    //     0x8ed9a0: ldurb           w16, [x2, #-1]
    //     0x8ed9a4: ldurb           w17, [x0, #-1]
    //     0x8ed9a8: and             x16, x17, x16, lsr #2
    //     0x8ed9ac: tst             x16, HEAP, lsr #32
    //     0x8ed9b0: b.eq            #0x8ed9b8
    //     0x8ed9b4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x8ed9b8: mov             x0, x10
    // 0x8ed9bc: StoreField: r2->field_13 = r0
    //     0x8ed9bc: stur            w0, [x2, #0x13]
    //     0x8ed9c0: tbz             w0, #0, #0x8ed9dc
    //     0x8ed9c4: ldurb           w16, [x2, #-1]
    //     0x8ed9c8: ldurb           w17, [x0, #-1]
    //     0x8ed9cc: and             x16, x17, x16, lsr #2
    //     0x8ed9d0: tst             x16, HEAP, lsr #32
    //     0x8ed9d4: b.eq            #0x8ed9dc
    //     0x8ed9d8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x8ed9dc: mov             x0, x3
    // 0x8ed9e0: ArrayStore: r2[0] = r0  ; List_4
    //     0x8ed9e0: stur            w0, [x2, #0x17]
    //     0x8ed9e4: ldurb           w16, [x2, #-1]
    //     0x8ed9e8: ldurb           w17, [x0, #-1]
    //     0x8ed9ec: and             x16, x17, x16, lsr #2
    //     0x8ed9f0: tst             x16, HEAP, lsr #32
    //     0x8ed9f4: b.eq            #0x8ed9fc
    //     0x8ed9f8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x8ed9fc: StoreField: r2->field_1f = r8
    //     0x8ed9fc: stur            w8, [x2, #0x1f]
    // 0x8eda00: mov             x0, x9
    // 0x8eda04: StoreField: r2->field_23 = r0
    //     0x8eda04: stur            w0, [x2, #0x23]
    //     0x8eda08: ldurb           w16, [x2, #-1]
    //     0x8eda0c: ldurb           w17, [x0, #-1]
    //     0x8eda10: and             x16, x17, x16, lsr #2
    //     0x8eda14: tst             x16, HEAP, lsr #32
    //     0x8eda18: b.eq            #0x8eda20
    //     0x8eda1c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x8eda20: cmp             w7, NULL
    // 0x8eda24: b.ne            #0x8eda6c
    // 0x8eda28: LoadField: r0 = r1->field_f
    //     0x8eda28: ldur            w0, [x1, #0xf]
    // 0x8eda2c: DecompressPointer r0
    //     0x8eda2c: add             x0, x0, HEAP, lsl #32
    // 0x8eda30: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8eda34: cmp             w0, w16
    // 0x8eda38: b.eq            #0x8edaf0
    // 0x8eda3c: r16 = <List<String>>
    //     0x8eda3c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15358] TypeArguments: <List<String>>
    //     0x8eda40: ldr             x16, [x16, #0x358]
    // 0x8eda44: str             x16, [SP]
    // 0x8eda48: r4 = const [0x1, 0, 0, 0, null]
    //     0x8eda48: ldr             x4, [PP, #0x48]  ; [pp+0x48] List(5) [0x1, 0, 0, 0, Null]
    // 0x8eda4c: r0 = caseInsensitiveKeyMap()
    //     0x8eda4c: bl              #0x8eb034  ; [package:dio/src/utils.dart] ::caseInsensitiveKeyMap
    // 0x8eda50: stur            x0, [fp, #-0x18]
    // 0x8eda54: r0 = Headers()
    //     0x8eda54: bl              #0x8ed6dc  ; AllocateHeadersStub -> Headers (size=0xc)
    // 0x8eda58: mov             x1, x0
    // 0x8eda5c: ldur            x0, [fp, #-0x18]
    // 0x8eda60: StoreField: r1->field_7 = r0
    //     0x8eda60: stur            w0, [x1, #7]
    // 0x8eda64: mov             x0, x1
    // 0x8eda68: b               #0x8eda70
    // 0x8eda6c: mov             x0, x7
    // 0x8eda70: ldur            x1, [fp, #-0x10]
    // 0x8eda74: ldur            x2, [fp, #-8]
    // 0x8eda78: StoreField: r1->field_1b = r0
    //     0x8eda78: stur            w0, [x1, #0x1b]
    //     0x8eda7c: ldurb           w16, [x1, #-1]
    //     0x8eda80: ldurb           w17, [x0, #-1]
    //     0x8eda84: and             x16, x17, x16, lsr #2
    //     0x8eda88: tst             x16, HEAP, lsr #32
    //     0x8eda8c: b.eq            #0x8eda94
    //     0x8eda90: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8eda94: cmp             w2, NULL
    // 0x8eda98: b.ne            #0x8edab0
    // 0x8eda9c: r16 = <String, dynamic>
    //     0x8eda9c: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x8edaa0: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x8edaa4: stp             lr, x16, [SP]
    // 0x8edaa8: r0 = Map._fromLiteral()
    //     0x8edaa8: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x8edaac: b               #0x8edab4
    // 0x8edab0: mov             x0, x2
    // 0x8edab4: ldur            x1, [fp, #-0x10]
    // 0x8edab8: StoreField: r1->field_27 = r0
    //     0x8edab8: stur            w0, [x1, #0x27]
    //     0x8edabc: tbz             w0, #0, #0x8edad8
    //     0x8edac0: ldurb           w16, [x1, #-1]
    //     0x8edac4: ldurb           w17, [x0, #-1]
    //     0x8edac8: and             x16, x17, x16, lsr #2
    //     0x8edacc: tst             x16, HEAP, lsr #32
    //     0x8edad0: b.eq            #0x8edad8
    //     0x8edad4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8edad8: r0 = Null
    //     0x8edad8: mov             x0, NULL
    // 0x8edadc: LeaveFrame
    //     0x8edadc: mov             SP, fp
    //     0x8edae0: ldp             fp, lr, [SP], #0x10
    // 0x8edae4: ret
    //     0x8edae4: ret             
    // 0x8edae8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8edae8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8edaec: b               #0x8ed974
    // 0x8edaf0: r9 = preserveHeaderCase
    //     0x8edaf0: add             x9, PP, #0x16, lsl #12  ; [pp+0x16070] Field <_RequestConfig@271184022.preserveHeaderCase>: late (offset: 0x10)
    //     0x8edaf4: ldr             x9, [x9, #0x70]
    // 0x8edaf8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8edaf8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ toString(/* No info */) {
    // ** addr: 0x11148bc, size: 0x140
    // 0x11148bc: EnterFrame
    //     0x11148bc: stp             fp, lr, [SP, #-0x10]!
    //     0x11148c0: mov             fp, SP
    // 0x11148c4: AllocStack(0x10)
    //     0x11148c4: sub             SP, SP, #0x10
    // 0x11148c8: CheckStackOverflow
    //     0x11148c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11148cc: cmp             SP, x16
    //     0x11148d0: b.ls            #0x11149f4
    // 0x11148d4: ldr             x0, [fp, #0x10]
    // 0x11148d8: LoadField: r3 = r0->field_b
    //     0x11148d8: ldur            w3, [x0, #0xb]
    // 0x11148dc: DecompressPointer r3
    //     0x11148dc: add             x3, x3, HEAP, lsl #32
    // 0x11148e0: mov             x0, x3
    // 0x11148e4: stur            x3, [fp, #-8]
    // 0x11148e8: r2 = Null
    //     0x11148e8: mov             x2, NULL
    // 0x11148ec: r1 = Null
    //     0x11148ec: mov             x1, NULL
    // 0x11148f0: cmp             w0, NULL
    // 0x11148f4: b.eq            #0x111498c
    // 0x11148f8: branchIfSmi(r0, 0x111498c)
    //     0x11148f8: tbz             w0, #0, #0x111498c
    // 0x11148fc: r3 = LoadClassIdInstr(r0)
    //     0x11148fc: ldur            x3, [x0, #-1]
    //     0x1114900: ubfx            x3, x3, #0xc, #0x14
    // 0x1114904: r17 = 7630
    //     0x1114904: mov             x17, #0x1dce
    // 0x1114908: cmp             x3, x17
    // 0x111490c: b.eq            #0x1114994
    // 0x1114910: r4 = LoadClassIdInstr(r0)
    //     0x1114910: ldur            x4, [x0, #-1]
    //     0x1114914: ubfx            x4, x4, #0xc, #0x14
    // 0x1114918: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x111491c: ldr             x3, [x3, #0x18]
    // 0x1114920: ldr             x3, [x3, x4, lsl #3]
    // 0x1114924: LoadField: r3 = r3->field_2b
    //     0x1114924: ldur            w3, [x3, #0x2b]
    // 0x1114928: DecompressPointer r3
    //     0x1114928: add             x3, x3, HEAP, lsl #32
    // 0x111492c: cmp             w3, NULL
    // 0x1114930: b.eq            #0x111498c
    // 0x1114934: LoadField: r3 = r3->field_f
    //     0x1114934: ldur            w3, [x3, #0xf]
    // 0x1114938: lsr             x3, x3, #3
    // 0x111493c: r17 = 7630
    //     0x111493c: mov             x17, #0x1dce
    // 0x1114940: cmp             x3, x17
    // 0x1114944: b.eq            #0x1114994
    // 0x1114948: r3 = SubtypeTestCache
    //     0x1114948: add             x3, PP, #0x81, lsl #12  ; [pp+0x81e90] SubtypeTestCache
    //     0x111494c: ldr             x3, [x3, #0xe90]
    // 0x1114950: r30 = Subtype1TestCacheStub
    //     0x1114950: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x1114954: LoadField: r30 = r30->field_7
    //     0x1114954: ldur            lr, [lr, #7]
    // 0x1114958: blr             lr
    // 0x111495c: cmp             w7, NULL
    // 0x1114960: b.eq            #0x111496c
    // 0x1114964: tbnz            w7, #4, #0x111498c
    // 0x1114968: b               #0x1114994
    // 0x111496c: r8 = Map
    //     0x111496c: add             x8, PP, #0x81, lsl #12  ; [pp+0x81e98] Type: Map
    //     0x1114970: ldr             x8, [x8, #0xe98]
    // 0x1114974: r3 = SubtypeTestCache
    //     0x1114974: add             x3, PP, #0x81, lsl #12  ; [pp+0x81ea0] SubtypeTestCache
    //     0x1114978: ldr             x3, [x3, #0xea0]
    // 0x111497c: r30 = InstanceOfStub
    //     0x111497c: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x1114980: LoadField: r30 = r30->field_7
    //     0x1114980: ldur            lr, [lr, #7]
    // 0x1114984: blr             lr
    // 0x1114988: b               #0x1114998
    // 0x111498c: r0 = false
    //     0x111498c: add             x0, NULL, #0x30  ; false
    // 0x1114990: b               #0x1114998
    // 0x1114994: r0 = true
    //     0x1114994: add             x0, NULL, #0x20  ; true
    // 0x1114998: tbnz            w0, #4, #0x11149b8
    // 0x111499c: ldur            x2, [fp, #-8]
    // 0x11149a0: r1 = Instance_JsonCodec
    //     0x11149a0: ldr             x1, [PP, #0x6d00]  ; [pp+0x6d00] Obj!JsonCodec@12b7e21
    // 0x11149a4: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x11149a4: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x11149a8: r0 = encode()
    //     0x11149a8: bl              #0x12372ac  ; [dart:convert] JsonCodec::encode
    // 0x11149ac: LeaveFrame
    //     0x11149ac: mov             SP, fp
    //     0x11149b0: ldp             fp, lr, [SP], #0x10
    // 0x11149b4: ret
    //     0x11149b4: ret             
    // 0x11149b8: ldur            x0, [fp, #-8]
    // 0x11149bc: r1 = 60
    //     0x11149bc: mov             x1, #0x3c
    // 0x11149c0: branchIfSmi(r0, 0x11149cc)
    //     0x11149c0: tbz             w0, #0, #0x11149cc
    // 0x11149c4: r1 = LoadClassIdInstr(r0)
    //     0x11149c4: ldur            x1, [x0, #-1]
    //     0x11149c8: ubfx            x1, x1, #0xc, #0x14
    // 0x11149cc: str             x0, [SP]
    // 0x11149d0: mov             x0, x1
    // 0x11149d4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x11149d4: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x11149d8: r0 = GDT[cid_x0 + 0x91c1]()
    //     0x11149d8: mov             x17, #0x91c1
    //     0x11149dc: add             lr, x0, x17
    //     0x11149e0: ldr             lr, [x21, lr, lsl #3]
    //     0x11149e4: blr             lr
    // 0x11149e8: LeaveFrame
    //     0x11149e8: mov             SP, fp
    //     0x11149ec: ldp             fp, lr, [SP], #0x10
    // 0x11149f0: ret
    //     0x11149f0: ret             
    // 0x11149f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11149f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11149f8: b               #0x11148d4
  }
  get _ realUri(/* No info */) {
    // ** addr: 0x11a46f0, size: 0xa4
    // 0x11a46f0: EnterFrame
    //     0x11a46f0: stp             fp, lr, [SP, #-0x10]!
    //     0x11a46f4: mov             fp, SP
    // 0x11a46f8: AllocStack(0x8)
    //     0x11a46f8: sub             SP, SP, #8
    // 0x11a46fc: SetupParameters(Response<X0> this /* r1 => r2, fp-0x8 */)
    //     0x11a46fc: mov             x2, x1
    //     0x11a4700: stur            x1, [fp, #-8]
    // 0x11a4704: CheckStackOverflow
    //     0x11a4704: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a4708: cmp             SP, x16
    //     0x11a470c: b.ls            #0x11a478c
    // 0x11a4710: LoadField: r1 = r2->field_23
    //     0x11a4710: ldur            w1, [x2, #0x23]
    // 0x11a4714: DecompressPointer r1
    //     0x11a4714: add             x1, x1, HEAP, lsl #32
    // 0x11a4718: r0 = LoadClassIdInstr(r1)
    //     0x11a4718: ldur            x0, [x1, #-1]
    //     0x11a471c: ubfx            x0, x0, #0xc, #0x14
    // 0x11a4720: r0 = GDT[cid_x0 + 0x131a1]()
    //     0x11a4720: mov             x17, #0x31a1
    //     0x11a4724: movk            x17, #1, lsl #16
    //     0x11a4728: add             lr, x0, x17
    //     0x11a472c: ldr             lr, [x21, lr, lsl #3]
    //     0x11a4730: blr             lr
    // 0x11a4734: tbnz            w0, #4, #0x11a4770
    // 0x11a4738: ldur            x0, [fp, #-8]
    // 0x11a473c: LoadField: r1 = r0->field_23
    //     0x11a473c: ldur            w1, [x0, #0x23]
    // 0x11a4740: DecompressPointer r1
    //     0x11a4740: add             x1, x1, HEAP, lsl #32
    // 0x11a4744: r0 = LoadClassIdInstr(r1)
    //     0x11a4744: ldur            x0, [x1, #-1]
    //     0x11a4748: ubfx            x0, x0, #0xc, #0x14
    // 0x11a474c: r0 = GDT[cid_x0 + 0x140c8]()
    //     0x11a474c: mov             x17, #0x40c8
    //     0x11a4750: movk            x17, #1, lsl #16
    //     0x11a4754: add             lr, x0, x17
    //     0x11a4758: ldr             lr, [x21, lr, lsl #3]
    //     0x11a475c: blr             lr
    // 0x11a4760: LoadField: r1 = r0->field_13
    //     0x11a4760: ldur            w1, [x0, #0x13]
    // 0x11a4764: DecompressPointer r1
    //     0x11a4764: add             x1, x1, HEAP, lsl #32
    // 0x11a4768: mov             x0, x1
    // 0x11a476c: b               #0x11a4780
    // 0x11a4770: ldur            x0, [fp, #-8]
    // 0x11a4774: LoadField: r1 = r0->field_f
    //     0x11a4774: ldur            w1, [x0, #0xf]
    // 0x11a4778: DecompressPointer r1
    //     0x11a4778: add             x1, x1, HEAP, lsl #32
    // 0x11a477c: r0 = uri()
    //     0x11a477c: bl              #0x90c6d0  ; [package:dio/src/options.dart] RequestOptions::uri
    // 0x11a4780: LeaveFrame
    //     0x11a4780: mov             SP, fp
    //     0x11a4784: ldp             fp, lr, [SP], #0x10
    // 0x11a4788: ret
    //     0x11a4788: ret             
    // 0x11a478c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a478c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a4790: b               #0x11a4710
  }
}
