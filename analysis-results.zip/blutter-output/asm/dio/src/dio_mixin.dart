// lib: , url: package:dio/src/dio_mixin.dart

// class id: 1048702, size: 0x8
class :: {

  static _ _observeInterceptorCallback(/* No info */) {
    // ** addr: 0x8edeb4, size: 0x1b0
    // 0x8edeb4: EnterFrame
    //     0x8edeb4: stp             fp, lr, [SP, #-0x10]!
    //     0x8edeb8: mov             fp, SP
    // 0x8edebc: AllocStack(0x40)
    //     0x8edebc: sub             SP, SP, #0x40
    // 0x8edec0: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x8edec0: mov             x0, x1
    //     0x8edec4: stur            x1, [fp, #-8]
    //     0x8edec8: stur            x2, [fp, #-0x10]
    //     0x8edecc: stur            x3, [fp, #-0x18]
    // 0x8eded0: CheckStackOverflow
    //     0x8eded0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8eded4: cmp             SP, x16
    //     0x8eded8: b.ls            #0x8ee05c
    // 0x8ededc: r1 = 3
    //     0x8ededc: mov             x1, #3
    // 0x8edee0: r0 = AllocateContext()
    //     0x8edee0: bl              #0x13de838  ; AllocateContextStub
    // 0x8edee4: mov             x3, x0
    // 0x8edee8: ldur            x0, [fp, #-0x10]
    // 0x8edeec: stur            x3, [fp, #-0x20]
    // 0x8edef0: StoreField: r3->field_f = r0
    //     0x8edef0: stur            w0, [x3, #0xf]
    // 0x8edef4: ldur            x0, [fp, #-0x18]
    // 0x8edef8: StoreField: r3->field_13 = r0
    //     0x8edef8: stur            w0, [x3, #0x13]
    // 0x8edefc: ldur            x0, [fp, #-8]
    // 0x8edf00: r2 = Null
    //     0x8edf00: mov             x2, NULL
    // 0x8edf04: r1 = Null
    //     0x8edf04: mov             x1, NULL
    // 0x8edf08: cmp             w0, NULL
    // 0x8edf0c: b.eq            #0x8edfa4
    // 0x8edf10: branchIfSmi(r0, 0x8edfa4)
    //     0x8edf10: tbz             w0, #0, #0x8edfa4
    // 0x8edf14: r3 = LoadClassIdInstr(r0)
    //     0x8edf14: ldur            x3, [x0, #-1]
    //     0x8edf18: ubfx            x3, x3, #0xc, #0x14
    // 0x8edf1c: r17 = 7560
    //     0x8edf1c: mov             x17, #0x1d88
    // 0x8edf20: cmp             x3, x17
    // 0x8edf24: b.eq            #0x8edfac
    // 0x8edf28: r4 = LoadClassIdInstr(r0)
    //     0x8edf28: ldur            x4, [x0, #-1]
    //     0x8edf2c: ubfx            x4, x4, #0xc, #0x14
    // 0x8edf30: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x8edf34: ldr             x3, [x3, #0x18]
    // 0x8edf38: ldr             x3, [x3, x4, lsl #3]
    // 0x8edf3c: LoadField: r3 = r3->field_2b
    //     0x8edf3c: ldur            w3, [x3, #0x2b]
    // 0x8edf40: DecompressPointer r3
    //     0x8edf40: add             x3, x3, HEAP, lsl #32
    // 0x8edf44: cmp             w3, NULL
    // 0x8edf48: b.eq            #0x8edfa4
    // 0x8edf4c: LoadField: r3 = r3->field_f
    //     0x8edf4c: ldur            w3, [x3, #0xf]
    // 0x8edf50: lsr             x3, x3, #3
    // 0x8edf54: r17 = 7560
    //     0x8edf54: mov             x17, #0x1d88
    // 0x8edf58: cmp             x3, x17
    // 0x8edf5c: b.eq            #0x8edfac
    // 0x8edf60: r3 = SubtypeTestCache
    //     0x8edf60: add             x3, PP, #0x15, lsl #12  ; [pp+0x15fd8] SubtypeTestCache
    //     0x8edf64: ldr             x3, [x3, #0xfd8]
    // 0x8edf68: r30 = Subtype1TestCacheStub
    //     0x8edf68: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x8edf6c: LoadField: r30 = r30->field_7
    //     0x8edf6c: ldur            lr, [lr, #7]
    // 0x8edf70: blr             lr
    // 0x8edf74: cmp             w7, NULL
    // 0x8edf78: b.eq            #0x8edf84
    // 0x8edf7c: tbnz            w7, #4, #0x8edfa4
    // 0x8edf80: b               #0x8edfac
    // 0x8edf84: r8 = Future
    //     0x8edf84: add             x8, PP, #0x15, lsl #12  ; [pp+0x15fe0] Type: Future
    //     0x8edf88: ldr             x8, [x8, #0xfe0]
    // 0x8edf8c: r3 = SubtypeTestCache
    //     0x8edf8c: add             x3, PP, #0x15, lsl #12  ; [pp+0x15fe8] SubtypeTestCache
    //     0x8edf90: ldr             x3, [x3, #0xfe8]
    // 0x8edf94: r30 = InstanceOfStub
    //     0x8edf94: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x8edf98: LoadField: r30 = r30->field_7
    //     0x8edf98: ldur            lr, [lr, #7]
    // 0x8edf9c: blr             lr
    // 0x8edfa0: b               #0x8edfb0
    // 0x8edfa4: r0 = false
    //     0x8edfa4: add             x0, NULL, #0x30  ; false
    // 0x8edfa8: b               #0x8edfb0
    // 0x8edfac: r0 = true
    //     0x8edfac: add             x0, NULL, #0x20  ; true
    // 0x8edfb0: tbz             w0, #4, #0x8edfc4
    // 0x8edfb4: r0 = Null
    //     0x8edfb4: mov             x0, NULL
    // 0x8edfb8: LeaveFrame
    //     0x8edfb8: mov             SP, fp
    //     0x8edfbc: ldp             fp, lr, [SP], #0x10
    // 0x8edfc0: ret
    //     0x8edfc0: ret             
    // 0x8edfc4: ldur            x0, [fp, #-8]
    // 0x8edfc8: ldur            x2, [fp, #-0x20]
    // 0x8edfcc: r0 = LoadStaticField(0x364)
    //     0x8edfcc: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8edfd0: ldr             x0, [x0, #0x6c8]
    // 0x8edfd4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8edfd8: cmp             w0, w16
    // 0x8edfdc: b.ne            #0x8edfe8
    // 0x8edfe0: r2 = _current
    //     0x8edfe0: ldr             x2, [PP, #0x2c0]  ; [pp+0x2c0] Field <Zone._current@5048458>: static late (offset: 0x364)
    // 0x8edfe4: r0 = InitLateStaticField()
    //     0x8edfe4: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0x8edfe8: mov             x1, x0
    // 0x8edfec: ldur            x0, [fp, #-0x20]
    // 0x8edff0: ArrayStore: r0[0] = r1  ; List_4
    //     0x8edff0: stur            w1, [x0, #0x17]
    // 0x8edff4: r1 = Function '<anonymous closure>': static.
    //     0x8edff4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15ff0] Function: [dart:ui] Shader::Shader._ (0x13cf838)
    //     0x8edff8: ldr             x1, [x1, #0xff0]
    // 0x8edffc: r2 = Null
    //     0x8edffc: mov             x2, NULL
    // 0x8ee000: r0 = AllocateClosure()
    //     0x8ee000: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8ee004: ldur            x2, [fp, #-0x20]
    // 0x8ee008: r1 = Function '<anonymous closure>': static.
    //     0x8ee008: add             x1, PP, #0x15, lsl #12  ; [pp+0x15ff8] AnonymousClosure: static (0x8ee064), in [package:dio/src/dio_mixin.dart] ::_observeInterceptorCallback (0x8edeb4)
    //     0x8ee00c: ldr             x1, [x1, #0xff8]
    // 0x8ee010: stur            x0, [fp, #-0x10]
    // 0x8ee014: r0 = AllocateClosure()
    //     0x8ee014: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8ee018: mov             x1, x0
    // 0x8ee01c: ldur            x0, [fp, #-8]
    // 0x8ee020: r2 = LoadClassIdInstr(r0)
    //     0x8ee020: ldur            x2, [x0, #-1]
    //     0x8ee024: ubfx            x2, x2, #0xc, #0x14
    // 0x8ee028: r16 = <void?>
    //     0x8ee028: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x8ee02c: stp             x0, x16, [SP, #0x10]
    // 0x8ee030: ldur            x16, [fp, #-0x10]
    // 0x8ee034: stp             x1, x16, [SP]
    // 0x8ee038: mov             x0, x2
    // 0x8ee03c: r4 = const [0x1, 0x3, 0x3, 0x2, onError, 0x2, null]
    //     0x8ee03c: ldr             x4, [PP, #0x538]  ; [pp+0x538] List(7) [0x1, 0x3, 0x3, 0x2, "onError", 0x2, Null]
    // 0x8ee040: r0 = GDT[cid_x0 + -0xfef]()
    //     0x8ee040: sub             lr, x0, #0xfef
    //     0x8ee044: ldr             lr, [x21, lr, lsl #3]
    //     0x8ee048: blr             lr
    // 0x8ee04c: r0 = Null
    //     0x8ee04c: mov             x0, NULL
    // 0x8ee050: LeaveFrame
    //     0x8ee050: mov             SP, fp
    //     0x8ee054: ldp             fp, lr, [SP], #0x10
    // 0x8ee058: ret
    //     0x8ee058: ret             
    // 0x8ee05c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ee05c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ee060: b               #0x8ededc
  }
  [closure] static Null <anonymous closure>(dynamic, Object, StackTrace) {
    // ** addr: 0x8ee064, size: 0xa8
    // 0x8ee064: EnterFrame
    //     0x8ee064: stp             fp, lr, [SP, #-0x10]!
    //     0x8ee068: mov             fp, SP
    // 0x8ee06c: AllocStack(0x20)
    //     0x8ee06c: sub             SP, SP, #0x20
    // 0x8ee070: SetupParameters([dynamic _ /* r0 */])
    //     0x8ee070: ldr             x0, [fp, #0x20]
    //     0x8ee074: ldur            w2, [x0, #0x17]
    //     0x8ee078: add             x2, x2, HEAP, lsl #32
    //     0x8ee07c: stur            x2, [fp, #-8]
    // 0x8ee080: CheckStackOverflow
    //     0x8ee080: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ee084: cmp             SP, x16
    //     0x8ee088: b.ls            #0x8ee104
    // 0x8ee08c: LoadField: r1 = r2->field_f
    //     0x8ee08c: ldur            w1, [x2, #0xf]
    // 0x8ee090: DecompressPointer r1
    //     0x8ee090: add             x1, x1, HEAP, lsl #32
    // 0x8ee094: r0 = isCompleted()
    //     0x8ee094: bl              #0x8ee10c  ; [package:dio/src/dio_mixin.dart] _BaseHandler::isCompleted
    // 0x8ee098: tbz             w0, #4, #0x8ee0cc
    // 0x8ee09c: ldur            x0, [fp, #-8]
    // 0x8ee0a0: LoadField: r1 = r0->field_13
    //     0x8ee0a0: ldur            w1, [x0, #0x13]
    // 0x8ee0a4: DecompressPointer r1
    //     0x8ee0a4: add             x1, x1, HEAP, lsl #32
    // 0x8ee0a8: ldr             x16, [fp, #0x18]
    // 0x8ee0ac: stp             x16, x1, [SP, #8]
    // 0x8ee0b0: ldr             x16, [fp, #0x10]
    // 0x8ee0b4: str             x16, [SP]
    // 0x8ee0b8: mov             x0, x1
    // 0x8ee0bc: ClosureCall
    //     0x8ee0bc: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x8ee0c0: ldur            x2, [x0, #0x1f]
    //     0x8ee0c4: blr             x2
    // 0x8ee0c8: b               #0x8ee0f4
    // 0x8ee0cc: ldur            x0, [fp, #-8]
    // 0x8ee0d0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8ee0d0: ldur            w1, [x0, #0x17]
    // 0x8ee0d4: DecompressPointer r1
    //     0x8ee0d4: add             x1, x1, HEAP, lsl #32
    // 0x8ee0d8: r0 = LoadClassIdInstr(r1)
    //     0x8ee0d8: ldur            x0, [x1, #-1]
    //     0x8ee0dc: ubfx            x0, x0, #0xc, #0x14
    // 0x8ee0e0: ldr             x2, [fp, #0x18]
    // 0x8ee0e4: ldr             x3, [fp, #0x10]
    // 0x8ee0e8: r0 = GDT[cid_x0 + -0xfee]()
    //     0x8ee0e8: sub             lr, x0, #0xfee
    //     0x8ee0ec: ldr             lr, [x21, lr, lsl #3]
    //     0x8ee0f0: blr             lr
    // 0x8ee0f4: r0 = Null
    //     0x8ee0f4: mov             x0, NULL
    // 0x8ee0f8: LeaveFrame
    //     0x8ee0f8: mov             SP, fp
    //     0x8ee0fc: ldp             fp, lr, [SP], #0x10
    // 0x8ee100: ret
    //     0x8ee100: ret             
    // 0x8ee104: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ee104: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ee108: b               #0x8ee08c
  }
}

// class id: 3405, size: 0x10, field offset: 0x8
abstract class _BaseHandler extends Object {

  get _ isCompleted(/* No info */) {
    // ** addr: 0x8ee10c, size: 0x30
    // 0x8ee10c: LoadField: r2 = r1->field_7
    //     0x8ee10c: ldur            w2, [x1, #7]
    // 0x8ee110: DecompressPointer r2
    //     0x8ee110: add             x2, x2, HEAP, lsl #32
    // 0x8ee114: LoadField: r1 = r2->field_b
    //     0x8ee114: ldur            w1, [x2, #0xb]
    // 0x8ee118: DecompressPointer r1
    //     0x8ee118: add             x1, x1, HEAP, lsl #32
    // 0x8ee11c: LoadField: r2 = r1->field_b
    //     0x8ee11c: ldur            x2, [x1, #0xb]
    // 0x8ee120: ubfx            x2, x2, #0, #0x20
    // 0x8ee124: and             w1, w2, #0x1e
    // 0x8ee128: cbnz            w1, #0x8ee134
    // 0x8ee12c: r0 = false
    //     0x8ee12c: add             x0, NULL, #0x30  ; false
    // 0x8ee130: b               #0x8ee138
    // 0x8ee134: r0 = true
    //     0x8ee134: add             x0, NULL, #0x20  ; true
    // 0x8ee138: ret
    //     0x8ee138: ret             
  }
  _ _BaseHandler(/* No info */) {
    // ** addr: 0x8ee13c, size: 0xa8
    // 0x8ee13c: EnterFrame
    //     0x8ee13c: stp             fp, lr, [SP, #-0x10]!
    //     0x8ee140: mov             fp, SP
    // 0x8ee144: AllocStack(0x10)
    //     0x8ee144: sub             SP, SP, #0x10
    // 0x8ee148: SetupParameters(_BaseHandler this /* r1 => r0, fp-0x8 */)
    //     0x8ee148: mov             x0, x1
    //     0x8ee14c: stur            x1, [fp, #-8]
    // 0x8ee150: CheckStackOverflow
    //     0x8ee150: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ee154: cmp             SP, x16
    //     0x8ee158: b.ls            #0x8ee1dc
    // 0x8ee15c: r1 = <InterceptorState>
    //     0x8ee15c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15fb0] TypeArguments: <InterceptorState>
    //     0x8ee160: ldr             x1, [x1, #0xfb0]
    // 0x8ee164: r0 = _Future()
    //     0x8ee164: bl              #0x7f5dd4  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0x8ee168: stur            x0, [fp, #-0x10]
    // 0x8ee16c: StoreField: r0->field_b = rZR
    //     0x8ee16c: stur            xzr, [x0, #0xb]
    // 0x8ee170: r0 = LoadStaticField(0x364)
    //     0x8ee170: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8ee174: ldr             x0, [x0, #0x6c8]
    // 0x8ee178: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8ee17c: cmp             w0, w16
    // 0x8ee180: b.ne            #0x8ee18c
    // 0x8ee184: r2 = _current
    //     0x8ee184: ldr             x2, [PP, #0x2c0]  ; [pp+0x2c0] Field <Zone._current@5048458>: static late (offset: 0x364)
    // 0x8ee188: r0 = InitLateStaticField()
    //     0x8ee188: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0x8ee18c: mov             x1, x0
    // 0x8ee190: ldur            x0, [fp, #-0x10]
    // 0x8ee194: StoreField: r0->field_13 = r1
    //     0x8ee194: stur            w1, [x0, #0x13]
    // 0x8ee198: r1 = <InterceptorState>
    //     0x8ee198: add             x1, PP, #0x15, lsl #12  ; [pp+0x15fb0] TypeArguments: <InterceptorState>
    //     0x8ee19c: ldr             x1, [x1, #0xfb0]
    // 0x8ee1a0: r0 = _AsyncCompleter()
    //     0x8ee1a0: bl              #0x7f5dc8  ; Allocate_AsyncCompleterStub -> _AsyncCompleter<X0> (size=0x10)
    // 0x8ee1a4: ldur            x1, [fp, #-0x10]
    // 0x8ee1a8: StoreField: r0->field_b = r1
    //     0x8ee1a8: stur            w1, [x0, #0xb]
    // 0x8ee1ac: ldur            x1, [fp, #-8]
    // 0x8ee1b0: StoreField: r1->field_7 = r0
    //     0x8ee1b0: stur            w0, [x1, #7]
    //     0x8ee1b4: ldurb           w16, [x1, #-1]
    //     0x8ee1b8: ldurb           w17, [x0, #-1]
    //     0x8ee1bc: and             x16, x17, x16, lsr #2
    //     0x8ee1c0: tst             x16, HEAP, lsr #32
    //     0x8ee1c4: b.eq            #0x8ee1cc
    //     0x8ee1c8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8ee1cc: r0 = Null
    //     0x8ee1cc: mov             x0, NULL
    // 0x8ee1d0: LeaveFrame
    //     0x8ee1d0: mov             SP, fp
    //     0x8ee1d4: ldp             fp, lr, [SP], #0x10
    // 0x8ee1d8: ret
    //     0x8ee1d8: ret             
    // 0x8ee1dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ee1dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ee1e0: b               #0x8ee15c
  }
  _ _throwIfCompleted(/* No info */) {
    // ** addr: 0x8ee308, size: 0x54
    // 0x8ee308: EnterFrame
    //     0x8ee308: stp             fp, lr, [SP, #-0x10]!
    //     0x8ee30c: mov             fp, SP
    // 0x8ee310: LoadField: r0 = r1->field_7
    //     0x8ee310: ldur            w0, [x1, #7]
    // 0x8ee314: DecompressPointer r0
    //     0x8ee314: add             x0, x0, HEAP, lsl #32
    // 0x8ee318: LoadField: r1 = r0->field_b
    //     0x8ee318: ldur            w1, [x0, #0xb]
    // 0x8ee31c: DecompressPointer r1
    //     0x8ee31c: add             x1, x1, HEAP, lsl #32
    // 0x8ee320: LoadField: r0 = r1->field_b
    //     0x8ee320: ldur            x0, [x1, #0xb]
    // 0x8ee324: tst             x0, #0x1e
    // 0x8ee328: b.ne            #0x8ee33c
    // 0x8ee32c: r0 = Null
    //     0x8ee32c: mov             x0, NULL
    // 0x8ee330: LeaveFrame
    //     0x8ee330: mov             SP, fp
    //     0x8ee334: ldp             fp, lr, [SP], #0x10
    // 0x8ee338: ret
    //     0x8ee338: ret             
    // 0x8ee33c: r0 = StateError()
    //     0x8ee33c: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x8ee340: mov             x1, x0
    // 0x8ee344: r0 = "The `handler` has already been called, make sure each handler gets called only once."
    //     0x8ee344: add             x0, PP, #0x15, lsl #12  ; [pp+0x15ed0] "The `handler` has already been called, make sure each handler gets called only once."
    //     0x8ee348: ldr             x0, [x0, #0xed0]
    // 0x8ee34c: StoreField: r1->field_b = r0
    //     0x8ee34c: stur            w0, [x1, #0xb]
    // 0x8ee350: mov             x0, x1
    // 0x8ee354: r0 = Throw()
    //     0x8ee354: bl              #0x13ddb2c  ; ThrowStub
    // 0x8ee358: brk             #0
  }
}

// class id: 3406, size: 0x10, field offset: 0x10
class ErrorInterceptorHandler extends _BaseHandler {

  void next(ErrorInterceptorHandler, DioException) {
    // ** addr: 0x8ee208, size: 0x84
    // 0x8ee208: EnterFrame
    //     0x8ee208: stp             fp, lr, [SP, #-0x10]!
    //     0x8ee20c: mov             fp, SP
    // 0x8ee210: CheckStackOverflow
    //     0x8ee210: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ee214: cmp             SP, x16
    //     0x8ee218: b.ls            #0x8ee26c
    // 0x8ee21c: ldr             x0, [fp, #0x10]
    // 0x8ee220: r2 = Null
    //     0x8ee220: mov             x2, NULL
    // 0x8ee224: r1 = Null
    //     0x8ee224: mov             x1, NULL
    // 0x8ee228: r4 = 60
    //     0x8ee228: mov             x4, #0x3c
    // 0x8ee22c: branchIfSmi(r0, 0x8ee238)
    //     0x8ee22c: tbz             w0, #0, #0x8ee238
    // 0x8ee230: r4 = LoadClassIdInstr(r0)
    //     0x8ee230: ldur            x4, [x0, #-1]
    //     0x8ee234: ubfx            x4, x4, #0xc, #0x14
    // 0x8ee238: cmp             x4, #0xd52
    // 0x8ee23c: b.eq            #0x8ee254
    // 0x8ee240: r8 = DioException
    //     0x8ee240: add             x8, PP, #0x15, lsl #12  ; [pp+0x15fb8] Type: DioException
    //     0x8ee244: ldr             x8, [x8, #0xfb8]
    // 0x8ee248: r3 = Null
    //     0x8ee248: add             x3, PP, #0x81, lsl #12  ; [pp+0x81f30] Null
    //     0x8ee24c: ldr             x3, [x3, #0xf30]
    // 0x8ee250: r0 = DioException()
    //     0x8ee250: bl              #0x8e9ff4  ; IsType_DioException_Stub
    // 0x8ee254: ldr             x1, [fp, #0x18]
    // 0x8ee258: ldr             x2, [fp, #0x10]
    // 0x8ee25c: r0 = next()
    //     0x8ee25c: bl              #0x8ee274  ; [package:dio/src/dio_mixin.dart] ErrorInterceptorHandler::next
    // 0x8ee260: LeaveFrame
    //     0x8ee260: mov             SP, fp
    //     0x8ee264: ldp             fp, lr, [SP], #0x10
    // 0x8ee268: ret
    //     0x8ee268: ret             
    // 0x8ee26c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ee26c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ee270: b               #0x8ee21c
  }
  void next(ErrorInterceptorHandler, DioException) {
    // ** addr: 0x8ee274, size: 0x94
    // 0x8ee274: EnterFrame
    //     0x8ee274: stp             fp, lr, [SP, #-0x10]!
    //     0x8ee278: mov             fp, SP
    // 0x8ee27c: AllocStack(0x20)
    //     0x8ee27c: sub             SP, SP, #0x20
    // 0x8ee280: SetupParameters(ErrorInterceptorHandler this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x8ee280: mov             x0, x1
    //     0x8ee284: stur            x1, [fp, #-8]
    //     0x8ee288: stur            x2, [fp, #-0x10]
    // 0x8ee28c: CheckStackOverflow
    //     0x8ee28c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ee290: cmp             SP, x16
    //     0x8ee294: b.ls            #0x8ee300
    // 0x8ee298: mov             x1, x0
    // 0x8ee29c: r0 = _throwIfCompleted()
    //     0x8ee29c: bl              #0x8ee308  ; [package:dio/src/dio_mixin.dart] _BaseHandler::_throwIfCompleted
    // 0x8ee2a0: ldur            x0, [fp, #-8]
    // 0x8ee2a4: LoadField: r2 = r0->field_7
    //     0x8ee2a4: ldur            w2, [x0, #7]
    // 0x8ee2a8: DecompressPointer r2
    //     0x8ee2a8: add             x2, x2, HEAP, lsl #32
    // 0x8ee2ac: stur            x2, [fp, #-0x18]
    // 0x8ee2b0: r1 = <DioException>
    //     0x8ee2b0: add             x1, PP, #0x15, lsl #12  ; [pp+0x15f70] TypeArguments: <DioException>
    //     0x8ee2b4: ldr             x1, [x1, #0xf70]
    // 0x8ee2b8: r0 = InterceptorState()
    //     0x8ee2b8: bl              #0x8edd38  ; AllocateInterceptorStateStub -> InterceptorState<X0> (size=0x14)
    // 0x8ee2bc: mov             x1, x0
    // 0x8ee2c0: ldur            x0, [fp, #-0x10]
    // 0x8ee2c4: StoreField: r1->field_b = r0
    //     0x8ee2c4: stur            w0, [x1, #0xb]
    // 0x8ee2c8: r2 = Instance_InterceptorResultType
    //     0x8ee2c8: add             x2, PP, #0x15, lsl #12  ; [pp+0x15ec8] Obj!InterceptorResultType@12c64c1
    //     0x8ee2cc: ldr             x2, [x2, #0xec8]
    // 0x8ee2d0: StoreField: r1->field_f = r2
    //     0x8ee2d0: stur            w2, [x1, #0xf]
    // 0x8ee2d4: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x8ee2d4: ldur            w2, [x0, #0x17]
    // 0x8ee2d8: DecompressPointer r2
    //     0x8ee2d8: add             x2, x2, HEAP, lsl #32
    // 0x8ee2dc: str             x2, [SP]
    // 0x8ee2e0: mov             x2, x1
    // 0x8ee2e4: ldur            x1, [fp, #-0x18]
    // 0x8ee2e8: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x8ee2e8: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x8ee2ec: r0 = completeError()
    //     0x8ee2ec: bl              #0x7f6b94  ; [dart:async] _Completer::completeError
    // 0x8ee2f0: r0 = Null
    //     0x8ee2f0: mov             x0, NULL
    // 0x8ee2f4: LeaveFrame
    //     0x8ee2f4: mov             SP, fp
    //     0x8ee2f8: ldp             fp, lr, [SP], #0x10
    // 0x8ee2fc: ret
    //     0x8ee2fc: ret             
    // 0x8ee300: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ee300: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ee304: b               #0x8ee298
  }
  void resolve(ErrorInterceptorHandler, Response<dynamic>) {
    // ** addr: 0x8ee374, size: 0x4c
    // 0x8ee374: EnterFrame
    //     0x8ee374: stp             fp, lr, [SP, #-0x10]!
    //     0x8ee378: mov             fp, SP
    // 0x8ee37c: CheckStackOverflow
    //     0x8ee37c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ee380: cmp             SP, x16
    //     0x8ee384: b.ls            #0x8ee3a0
    // 0x8ee388: ldr             x1, [fp, #0x18]
    // 0x8ee38c: ldr             x2, [fp, #0x10]
    // 0x8ee390: r0 = resolve()
    //     0x8ee390: bl              #0x8ee3a8  ; [package:dio/src/dio_mixin.dart] ResponseInterceptorHandler::resolve
    // 0x8ee394: LeaveFrame
    //     0x8ee394: mov             SP, fp
    //     0x8ee398: ldp             fp, lr, [SP], #0x10
    // 0x8ee39c: ret
    //     0x8ee39c: ret             
    // 0x8ee3a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ee3a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ee3a4: b               #0x8ee388
  }
  void reject(ErrorInterceptorHandler, DioException, [bool]) {
    // ** addr: 0x8eeb34, size: 0xf0
    // 0x8eeb34: EnterFrame
    //     0x8eeb34: stp             fp, lr, [SP, #-0x10]!
    //     0x8eeb38: mov             fp, SP
    // 0x8eeb3c: AllocStack(0x20)
    //     0x8eeb3c: sub             SP, SP, #0x20
    // 0x8eeb40: SetupParameters(ErrorInterceptorHandler this /* r3, fp-0x18 */, dynamic _ /* r4, fp-0x10 */, [dynamic _ = false /* r5, fp-0x8 */])
    //     0x8eeb40: ldur            w0, [x4, #0x13]
    //     0x8eeb44: sub             x1, x0, #4
    //     0x8eeb48: add             x3, fp, w1, sxtw #2
    //     0x8eeb4c: ldr             x3, [x3, #0x18]
    //     0x8eeb50: stur            x3, [fp, #-0x18]
    //     0x8eeb54: add             x4, fp, w1, sxtw #2
    //     0x8eeb58: ldr             x4, [x4, #0x10]
    //     0x8eeb5c: stur            x4, [fp, #-0x10]
    //     0x8eeb60: cmp             w1, #2
    //     0x8eeb64: b.lt            #0x8eeb78
    //     0x8eeb68: add             x0, fp, w1, sxtw #2
    //     0x8eeb6c: ldr             x0, [x0, #8]
    //     0x8eeb70: mov             x5, x0
    //     0x8eeb74: b               #0x8eeb7c
    //     0x8eeb78: add             x5, NULL, #0x30  ; false
    //     0x8eeb7c: stur            x5, [fp, #-8]
    // 0x8eeb80: CheckStackOverflow
    //     0x8eeb80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8eeb84: cmp             SP, x16
    //     0x8eeb88: b.ls            #0x8eec1c
    // 0x8eeb8c: mov             x0, x4
    // 0x8eeb90: r2 = Null
    //     0x8eeb90: mov             x2, NULL
    // 0x8eeb94: r1 = Null
    //     0x8eeb94: mov             x1, NULL
    // 0x8eeb98: r4 = 60
    //     0x8eeb98: mov             x4, #0x3c
    // 0x8eeb9c: branchIfSmi(r0, 0x8eeba8)
    //     0x8eeb9c: tbz             w0, #0, #0x8eeba8
    // 0x8eeba0: r4 = LoadClassIdInstr(r0)
    //     0x8eeba0: ldur            x4, [x0, #-1]
    //     0x8eeba4: ubfx            x4, x4, #0xc, #0x14
    // 0x8eeba8: cmp             x4, #0xd52
    // 0x8eebac: b.eq            #0x8eebc4
    // 0x8eebb0: r8 = DioException
    //     0x8eebb0: add             x8, PP, #0x15, lsl #12  ; [pp+0x15fb8] Type: DioException
    //     0x8eebb4: ldr             x8, [x8, #0xfb8]
    // 0x8eebb8: r3 = Null
    //     0x8eebb8: add             x3, PP, #0x81, lsl #12  ; [pp+0x81f10] Null
    //     0x8eebbc: ldr             x3, [x3, #0xf10]
    // 0x8eebc0: r0 = DioException()
    //     0x8eebc0: bl              #0x8e9ff4  ; IsType_DioException_Stub
    // 0x8eebc4: ldur            x0, [fp, #-8]
    // 0x8eebc8: r2 = Null
    //     0x8eebc8: mov             x2, NULL
    // 0x8eebcc: r1 = Null
    //     0x8eebcc: mov             x1, NULL
    // 0x8eebd0: r4 = 60
    //     0x8eebd0: mov             x4, #0x3c
    // 0x8eebd4: branchIfSmi(r0, 0x8eebe0)
    //     0x8eebd4: tbz             w0, #0, #0x8eebe0
    // 0x8eebd8: r4 = LoadClassIdInstr(r0)
    //     0x8eebd8: ldur            x4, [x0, #-1]
    //     0x8eebdc: ubfx            x4, x4, #0xc, #0x14
    // 0x8eebe0: cmp             x4, #0x3f
    // 0x8eebe4: b.eq            #0x8eebf8
    // 0x8eebe8: r8 = bool
    //     0x8eebe8: ldr             x8, [PP, #0xb18]  ; [pp+0xb18] Type: bool
    // 0x8eebec: r3 = Null
    //     0x8eebec: add             x3, PP, #0x81, lsl #12  ; [pp+0x81f20] Null
    //     0x8eebf0: ldr             x3, [x3, #0xf20]
    // 0x8eebf4: r0 = bool()
    //     0x8eebf4: bl              #0x13ee15c  ; IsType_bool_Stub
    // 0x8eebf8: ldur            x16, [fp, #-8]
    // 0x8eebfc: str             x16, [SP]
    // 0x8eec00: ldur            x1, [fp, #-0x18]
    // 0x8eec04: ldur            x2, [fp, #-0x10]
    // 0x8eec08: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x8eec08: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x8eec0c: r0 = reject()
    //     0x8eec0c: bl              #0x8eec24  ; [package:dio/src/dio_mixin.dart] ErrorInterceptorHandler::reject
    // 0x8eec10: LeaveFrame
    //     0x8eec10: mov             SP, fp
    //     0x8eec14: ldp             fp, lr, [SP], #0x10
    // 0x8eec18: ret
    //     0x8eec18: ret             
    // 0x8eec1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8eec1c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8eec20: b               #0x8eeb8c
  }
  void reject(ErrorInterceptorHandler, DioException, [bool]) {
    // ** addr: 0x8eec24, size: 0x94
    // 0x8eec24: EnterFrame
    //     0x8eec24: stp             fp, lr, [SP, #-0x10]!
    //     0x8eec28: mov             fp, SP
    // 0x8eec2c: AllocStack(0x20)
    //     0x8eec2c: sub             SP, SP, #0x20
    // 0x8eec30: SetupParameters(ErrorInterceptorHandler this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x8eec30: mov             x0, x1
    //     0x8eec34: stur            x1, [fp, #-8]
    //     0x8eec38: stur            x2, [fp, #-0x10]
    // 0x8eec3c: CheckStackOverflow
    //     0x8eec3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8eec40: cmp             SP, x16
    //     0x8eec44: b.ls            #0x8eecb0
    // 0x8eec48: mov             x1, x0
    // 0x8eec4c: r0 = _throwIfCompleted()
    //     0x8eec4c: bl              #0x8ee308  ; [package:dio/src/dio_mixin.dart] _BaseHandler::_throwIfCompleted
    // 0x8eec50: ldur            x0, [fp, #-8]
    // 0x8eec54: LoadField: r2 = r0->field_7
    //     0x8eec54: ldur            w2, [x0, #7]
    // 0x8eec58: DecompressPointer r2
    //     0x8eec58: add             x2, x2, HEAP, lsl #32
    // 0x8eec5c: stur            x2, [fp, #-0x18]
    // 0x8eec60: r1 = <DioException>
    //     0x8eec60: add             x1, PP, #0x15, lsl #12  ; [pp+0x15f70] TypeArguments: <DioException>
    //     0x8eec64: ldr             x1, [x1, #0xf70]
    // 0x8eec68: r0 = InterceptorState()
    //     0x8eec68: bl              #0x8edd38  ; AllocateInterceptorStateStub -> InterceptorState<X0> (size=0x14)
    // 0x8eec6c: mov             x1, x0
    // 0x8eec70: ldur            x0, [fp, #-0x10]
    // 0x8eec74: StoreField: r1->field_b = r0
    //     0x8eec74: stur            w0, [x1, #0xb]
    // 0x8eec78: r2 = Instance_InterceptorResultType
    //     0x8eec78: add             x2, PP, #0x16, lsl #12  ; [pp+0x16048] Obj!InterceptorResultType@12c64a1
    //     0x8eec7c: ldr             x2, [x2, #0x48]
    // 0x8eec80: StoreField: r1->field_f = r2
    //     0x8eec80: stur            w2, [x1, #0xf]
    // 0x8eec84: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x8eec84: ldur            w2, [x0, #0x17]
    // 0x8eec88: DecompressPointer r2
    //     0x8eec88: add             x2, x2, HEAP, lsl #32
    // 0x8eec8c: str             x2, [SP]
    // 0x8eec90: mov             x2, x1
    // 0x8eec94: ldur            x1, [fp, #-0x18]
    // 0x8eec98: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x8eec98: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x8eec9c: r0 = completeError()
    //     0x8eec9c: bl              #0x7f6b94  ; [dart:async] _Completer::completeError
    // 0x8eeca0: r0 = Null
    //     0x8eeca0: mov             x0, NULL
    // 0x8eeca4: LeaveFrame
    //     0x8eeca4: mov             SP, fp
    //     0x8eeca8: ldp             fp, lr, [SP], #0x10
    // 0x8eecac: ret
    //     0x8eecac: ret             
    // 0x8eecb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8eecb0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8eecb4: b               #0x8eec48
  }
}

// class id: 3407, size: 0x10, field offset: 0x10
class ResponseInterceptorHandler extends _BaseHandler {

  void resolve(ResponseInterceptorHandler, Response<dynamic>) {
    // ** addr: 0x8ee3a8, size: 0x88
    // 0x8ee3a8: EnterFrame
    //     0x8ee3a8: stp             fp, lr, [SP, #-0x10]!
    //     0x8ee3ac: mov             fp, SP
    // 0x8ee3b0: AllocStack(0x20)
    //     0x8ee3b0: sub             SP, SP, #0x20
    // 0x8ee3b4: SetupParameters(ResponseInterceptorHandler this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x8ee3b4: mov             x0, x1
    //     0x8ee3b8: stur            x1, [fp, #-8]
    //     0x8ee3bc: stur            x2, [fp, #-0x10]
    // 0x8ee3c0: CheckStackOverflow
    //     0x8ee3c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ee3c4: cmp             SP, x16
    //     0x8ee3c8: b.ls            #0x8ee428
    // 0x8ee3cc: mov             x1, x0
    // 0x8ee3d0: r0 = _throwIfCompleted()
    //     0x8ee3d0: bl              #0x8ee308  ; [package:dio/src/dio_mixin.dart] _BaseHandler::_throwIfCompleted
    // 0x8ee3d4: ldur            x0, [fp, #-8]
    // 0x8ee3d8: LoadField: r2 = r0->field_7
    //     0x8ee3d8: ldur            w2, [x0, #7]
    // 0x8ee3dc: DecompressPointer r2
    //     0x8ee3dc: add             x2, x2, HEAP, lsl #32
    // 0x8ee3e0: stur            x2, [fp, #-0x18]
    // 0x8ee3e4: r1 = <Response>
    //     0x8ee3e4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15e58] TypeArguments: <Response>
    //     0x8ee3e8: ldr             x1, [x1, #0xe58]
    // 0x8ee3ec: r0 = InterceptorState()
    //     0x8ee3ec: bl              #0x8edd38  ; AllocateInterceptorStateStub -> InterceptorState<X0> (size=0x14)
    // 0x8ee3f0: mov             x1, x0
    // 0x8ee3f4: ldur            x0, [fp, #-0x10]
    // 0x8ee3f8: StoreField: r1->field_b = r0
    //     0x8ee3f8: stur            w0, [x1, #0xb]
    // 0x8ee3fc: r0 = Instance_InterceptorResultType
    //     0x8ee3fc: add             x0, PP, #0x15, lsl #12  ; [pp+0x15f50] Obj!InterceptorResultType@12c6441
    //     0x8ee400: ldr             x0, [x0, #0xf50]
    // 0x8ee404: StoreField: r1->field_f = r0
    //     0x8ee404: stur            w0, [x1, #0xf]
    // 0x8ee408: str             x1, [SP]
    // 0x8ee40c: ldur            x1, [fp, #-0x18]
    // 0x8ee410: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x8ee410: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x8ee414: r0 = complete()
    //     0x8ee414: bl              #0x128a5ec  ; [dart:async] _AsyncCompleter::complete
    // 0x8ee418: r0 = Null
    //     0x8ee418: mov             x0, NULL
    // 0x8ee41c: LeaveFrame
    //     0x8ee41c: mov             SP, fp
    //     0x8ee420: ldp             fp, lr, [SP], #0x10
    // 0x8ee424: ret
    //     0x8ee424: ret             
    // 0x8ee428: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ee428: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ee42c: b               #0x8ee3cc
  }
  void next(ResponseInterceptorHandler, Response<dynamic>) {
    // ** addr: 0x8ee448, size: 0x84
    // 0x8ee448: EnterFrame
    //     0x8ee448: stp             fp, lr, [SP, #-0x10]!
    //     0x8ee44c: mov             fp, SP
    // 0x8ee450: CheckStackOverflow
    //     0x8ee450: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ee454: cmp             SP, x16
    //     0x8ee458: b.ls            #0x8ee4ac
    // 0x8ee45c: ldr             x0, [fp, #0x10]
    // 0x8ee460: r2 = Null
    //     0x8ee460: mov             x2, NULL
    // 0x8ee464: r1 = Null
    //     0x8ee464: mov             x1, NULL
    // 0x8ee468: r4 = 60
    //     0x8ee468: mov             x4, #0x3c
    // 0x8ee46c: branchIfSmi(r0, 0x8ee478)
    //     0x8ee46c: tbz             w0, #0, #0x8ee478
    // 0x8ee470: r4 = LoadClassIdInstr(r0)
    //     0x8ee470: ldur            x4, [x0, #-1]
    //     0x8ee474: ubfx            x4, x4, #0xc, #0x14
    // 0x8ee478: cmp             x4, #0xd47
    // 0x8ee47c: b.eq            #0x8ee494
    // 0x8ee480: r8 = Response
    //     0x8ee480: add             x8, PP, #0x16, lsl #12  ; [pp+0x16028] Type: Response
    //     0x8ee484: ldr             x8, [x8, #0x28]
    // 0x8ee488: r3 = Null
    //     0x8ee488: add             x3, PP, #0x81, lsl #12  ; [pp+0x81ee0] Null
    //     0x8ee48c: ldr             x3, [x3, #0xee0]
    // 0x8ee490: r0 = Response()
    //     0x8ee490: bl              #0x8ee53c  ; IsType_Response_Stub
    // 0x8ee494: ldr             x1, [fp, #0x18]
    // 0x8ee498: ldr             x2, [fp, #0x10]
    // 0x8ee49c: r0 = next()
    //     0x8ee49c: bl              #0x8ee4b4  ; [package:dio/src/dio_mixin.dart] ResponseInterceptorHandler::next
    // 0x8ee4a0: LeaveFrame
    //     0x8ee4a0: mov             SP, fp
    //     0x8ee4a4: ldp             fp, lr, [SP], #0x10
    // 0x8ee4a8: ret
    //     0x8ee4a8: ret             
    // 0x8ee4ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ee4ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ee4b0: b               #0x8ee45c
  }
  void next(ResponseInterceptorHandler, Response<dynamic>) {
    // ** addr: 0x8ee4b4, size: 0x88
    // 0x8ee4b4: EnterFrame
    //     0x8ee4b4: stp             fp, lr, [SP, #-0x10]!
    //     0x8ee4b8: mov             fp, SP
    // 0x8ee4bc: AllocStack(0x20)
    //     0x8ee4bc: sub             SP, SP, #0x20
    // 0x8ee4c0: SetupParameters(ResponseInterceptorHandler this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x8ee4c0: mov             x0, x1
    //     0x8ee4c4: stur            x1, [fp, #-8]
    //     0x8ee4c8: stur            x2, [fp, #-0x10]
    // 0x8ee4cc: CheckStackOverflow
    //     0x8ee4cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ee4d0: cmp             SP, x16
    //     0x8ee4d4: b.ls            #0x8ee534
    // 0x8ee4d8: mov             x1, x0
    // 0x8ee4dc: r0 = _throwIfCompleted()
    //     0x8ee4dc: bl              #0x8ee308  ; [package:dio/src/dio_mixin.dart] _BaseHandler::_throwIfCompleted
    // 0x8ee4e0: ldur            x0, [fp, #-8]
    // 0x8ee4e4: LoadField: r2 = r0->field_7
    //     0x8ee4e4: ldur            w2, [x0, #7]
    // 0x8ee4e8: DecompressPointer r2
    //     0x8ee4e8: add             x2, x2, HEAP, lsl #32
    // 0x8ee4ec: stur            x2, [fp, #-0x18]
    // 0x8ee4f0: r1 = <Response>
    //     0x8ee4f0: add             x1, PP, #0x15, lsl #12  ; [pp+0x15e58] TypeArguments: <Response>
    //     0x8ee4f4: ldr             x1, [x1, #0xe58]
    // 0x8ee4f8: r0 = InterceptorState()
    //     0x8ee4f8: bl              #0x8edd38  ; AllocateInterceptorStateStub -> InterceptorState<X0> (size=0x14)
    // 0x8ee4fc: mov             x1, x0
    // 0x8ee500: ldur            x0, [fp, #-0x10]
    // 0x8ee504: StoreField: r1->field_b = r0
    //     0x8ee504: stur            w0, [x1, #0xb]
    // 0x8ee508: r0 = Instance_InterceptorResultType
    //     0x8ee508: add             x0, PP, #0x15, lsl #12  ; [pp+0x15ec8] Obj!InterceptorResultType@12c64c1
    //     0x8ee50c: ldr             x0, [x0, #0xec8]
    // 0x8ee510: StoreField: r1->field_f = r0
    //     0x8ee510: stur            w0, [x1, #0xf]
    // 0x8ee514: str             x1, [SP]
    // 0x8ee518: ldur            x1, [fp, #-0x18]
    // 0x8ee51c: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x8ee51c: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x8ee520: r0 = complete()
    //     0x8ee520: bl              #0x128a5ec  ; [dart:async] _AsyncCompleter::complete
    // 0x8ee524: r0 = Null
    //     0x8ee524: mov             x0, NULL
    // 0x8ee528: LeaveFrame
    //     0x8ee528: mov             SP, fp
    //     0x8ee52c: ldp             fp, lr, [SP], #0x10
    // 0x8ee530: ret
    //     0x8ee530: ret             
    // 0x8ee534: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ee534: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ee538: b               #0x8ee4d8
  }
  void resolve(ResponseInterceptorHandler, Response<dynamic>) {
    // ** addr: 0x8ee574, size: 0x4c
    // 0x8ee574: EnterFrame
    //     0x8ee574: stp             fp, lr, [SP, #-0x10]!
    //     0x8ee578: mov             fp, SP
    // 0x8ee57c: CheckStackOverflow
    //     0x8ee57c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ee580: cmp             SP, x16
    //     0x8ee584: b.ls            #0x8ee5a0
    // 0x8ee588: ldr             x1, [fp, #0x18]
    // 0x8ee58c: ldr             x2, [fp, #0x10]
    // 0x8ee590: r0 = resolve()
    //     0x8ee590: bl              #0x8ee3a8  ; [package:dio/src/dio_mixin.dart] ResponseInterceptorHandler::resolve
    // 0x8ee594: LeaveFrame
    //     0x8ee594: mov             SP, fp
    //     0x8ee598: ldp             fp, lr, [SP], #0x10
    // 0x8ee59c: ret
    //     0x8ee59c: ret             
    // 0x8ee5a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ee5a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ee5a4: b               #0x8ee588
  }
  void reject(ResponseInterceptorHandler, DioException, [bool]) {
    // ** addr: 0x8ee5a8, size: 0xf0
    // 0x8ee5a8: EnterFrame
    //     0x8ee5a8: stp             fp, lr, [SP, #-0x10]!
    //     0x8ee5ac: mov             fp, SP
    // 0x8ee5b0: AllocStack(0x20)
    //     0x8ee5b0: sub             SP, SP, #0x20
    // 0x8ee5b4: SetupParameters(ResponseInterceptorHandler this /* r3, fp-0x18 */, dynamic _ /* r4, fp-0x10 */, [dynamic _ = false /* r5, fp-0x8 */])
    //     0x8ee5b4: ldur            w0, [x4, #0x13]
    //     0x8ee5b8: sub             x1, x0, #4
    //     0x8ee5bc: add             x3, fp, w1, sxtw #2
    //     0x8ee5c0: ldr             x3, [x3, #0x18]
    //     0x8ee5c4: stur            x3, [fp, #-0x18]
    //     0x8ee5c8: add             x4, fp, w1, sxtw #2
    //     0x8ee5cc: ldr             x4, [x4, #0x10]
    //     0x8ee5d0: stur            x4, [fp, #-0x10]
    //     0x8ee5d4: cmp             w1, #2
    //     0x8ee5d8: b.lt            #0x8ee5ec
    //     0x8ee5dc: add             x0, fp, w1, sxtw #2
    //     0x8ee5e0: ldr             x0, [x0, #8]
    //     0x8ee5e4: mov             x5, x0
    //     0x8ee5e8: b               #0x8ee5f0
    //     0x8ee5ec: add             x5, NULL, #0x30  ; false
    //     0x8ee5f0: stur            x5, [fp, #-8]
    // 0x8ee5f4: CheckStackOverflow
    //     0x8ee5f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ee5f8: cmp             SP, x16
    //     0x8ee5fc: b.ls            #0x8ee690
    // 0x8ee600: mov             x0, x4
    // 0x8ee604: r2 = Null
    //     0x8ee604: mov             x2, NULL
    // 0x8ee608: r1 = Null
    //     0x8ee608: mov             x1, NULL
    // 0x8ee60c: r4 = 60
    //     0x8ee60c: mov             x4, #0x3c
    // 0x8ee610: branchIfSmi(r0, 0x8ee61c)
    //     0x8ee610: tbz             w0, #0, #0x8ee61c
    // 0x8ee614: r4 = LoadClassIdInstr(r0)
    //     0x8ee614: ldur            x4, [x0, #-1]
    //     0x8ee618: ubfx            x4, x4, #0xc, #0x14
    // 0x8ee61c: cmp             x4, #0xd52
    // 0x8ee620: b.eq            #0x8ee638
    // 0x8ee624: r8 = DioException
    //     0x8ee624: add             x8, PP, #0x15, lsl #12  ; [pp+0x15fb8] Type: DioException
    //     0x8ee628: ldr             x8, [x8, #0xfb8]
    // 0x8ee62c: r3 = Null
    //     0x8ee62c: add             x3, PP, #0x81, lsl #12  ; [pp+0x81ec0] Null
    //     0x8ee630: ldr             x3, [x3, #0xec0]
    // 0x8ee634: r0 = DioException()
    //     0x8ee634: bl              #0x8e9ff4  ; IsType_DioException_Stub
    // 0x8ee638: ldur            x0, [fp, #-8]
    // 0x8ee63c: r2 = Null
    //     0x8ee63c: mov             x2, NULL
    // 0x8ee640: r1 = Null
    //     0x8ee640: mov             x1, NULL
    // 0x8ee644: r4 = 60
    //     0x8ee644: mov             x4, #0x3c
    // 0x8ee648: branchIfSmi(r0, 0x8ee654)
    //     0x8ee648: tbz             w0, #0, #0x8ee654
    // 0x8ee64c: r4 = LoadClassIdInstr(r0)
    //     0x8ee64c: ldur            x4, [x0, #-1]
    //     0x8ee650: ubfx            x4, x4, #0xc, #0x14
    // 0x8ee654: cmp             x4, #0x3f
    // 0x8ee658: b.eq            #0x8ee66c
    // 0x8ee65c: r8 = bool
    //     0x8ee65c: ldr             x8, [PP, #0xb18]  ; [pp+0xb18] Type: bool
    // 0x8ee660: r3 = Null
    //     0x8ee660: add             x3, PP, #0x81, lsl #12  ; [pp+0x81ed0] Null
    //     0x8ee664: ldr             x3, [x3, #0xed0]
    // 0x8ee668: r0 = bool()
    //     0x8ee668: bl              #0x13ee15c  ; IsType_bool_Stub
    // 0x8ee66c: ldur            x16, [fp, #-8]
    // 0x8ee670: str             x16, [SP]
    // 0x8ee674: ldur            x1, [fp, #-0x18]
    // 0x8ee678: ldur            x2, [fp, #-0x10]
    // 0x8ee67c: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x8ee67c: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x8ee680: r0 = reject()
    //     0x8ee680: bl              #0x8ee698  ; [package:dio/src/dio_mixin.dart] RequestInterceptorHandler::reject
    // 0x8ee684: LeaveFrame
    //     0x8ee684: mov             SP, fp
    //     0x8ee688: ldp             fp, lr, [SP], #0x10
    // 0x8ee68c: ret
    //     0x8ee68c: ret             
    // 0x8ee690: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ee690: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ee694: b               #0x8ee600
  }
}

// class id: 3408, size: 0x10, field offset: 0x10
class RequestInterceptorHandler extends _BaseHandler {

  void reject(RequestInterceptorHandler, DioException, [bool]) {
    // ** addr: 0x8ee698, size: 0xdc
    // 0x8ee698: EnterFrame
    //     0x8ee698: stp             fp, lr, [SP, #-0x10]!
    //     0x8ee69c: mov             fp, SP
    // 0x8ee6a0: AllocStack(0x28)
    //     0x8ee6a0: sub             SP, SP, #0x28
    // 0x8ee6a4: SetupParameters(RequestInterceptorHandler this /* r1 => r0, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */, [dynamic _ = false /* r3, fp-0x8 */])
    //     0x8ee6a4: mov             x0, x1
    //     0x8ee6a8: stur            x1, [fp, #-0x10]
    //     0x8ee6ac: stur            x2, [fp, #-0x18]
    //     0x8ee6b0: ldur            w1, [x4, #0x13]
    //     0x8ee6b4: sub             x3, x1, #4
    //     0x8ee6b8: cmp             w3, #2
    //     0x8ee6bc: b.lt            #0x8ee6d0
    //     0x8ee6c0: add             x1, fp, w3, sxtw #2
    //     0x8ee6c4: ldr             x1, [x1, #8]
    //     0x8ee6c8: mov             x3, x1
    //     0x8ee6cc: b               #0x8ee6d4
    //     0x8ee6d0: add             x3, NULL, #0x30  ; false
    //     0x8ee6d4: stur            x3, [fp, #-8]
    // 0x8ee6d8: CheckStackOverflow
    //     0x8ee6d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ee6dc: cmp             SP, x16
    //     0x8ee6e0: b.ls            #0x8ee76c
    // 0x8ee6e4: mov             x1, x0
    // 0x8ee6e8: r0 = _throwIfCompleted()
    //     0x8ee6e8: bl              #0x8ee308  ; [package:dio/src/dio_mixin.dart] _BaseHandler::_throwIfCompleted
    // 0x8ee6ec: ldur            x0, [fp, #-0x10]
    // 0x8ee6f0: LoadField: r2 = r0->field_7
    //     0x8ee6f0: ldur            w2, [x0, #7]
    // 0x8ee6f4: DecompressPointer r2
    //     0x8ee6f4: add             x2, x2, HEAP, lsl #32
    // 0x8ee6f8: ldur            x0, [fp, #-8]
    // 0x8ee6fc: stur            x2, [fp, #-0x20]
    // 0x8ee700: tbnz            w0, #4, #0x8ee710
    // 0x8ee704: r3 = Instance_InterceptorResultType
    //     0x8ee704: add             x3, PP, #0x15, lsl #12  ; [pp+0x15f98] Obj!InterceptorResultType@12c6461
    //     0x8ee708: ldr             x3, [x3, #0xf98]
    // 0x8ee70c: b               #0x8ee718
    // 0x8ee710: r3 = Instance_InterceptorResultType
    //     0x8ee710: add             x3, PP, #0x16, lsl #12  ; [pp+0x16048] Obj!InterceptorResultType@12c64a1
    //     0x8ee714: ldr             x3, [x3, #0x48]
    // 0x8ee718: ldur            x0, [fp, #-0x18]
    // 0x8ee71c: stur            x3, [fp, #-8]
    // 0x8ee720: r1 = <DioException>
    //     0x8ee720: add             x1, PP, #0x15, lsl #12  ; [pp+0x15f70] TypeArguments: <DioException>
    //     0x8ee724: ldr             x1, [x1, #0xf70]
    // 0x8ee728: r0 = InterceptorState()
    //     0x8ee728: bl              #0x8edd38  ; AllocateInterceptorStateStub -> InterceptorState<X0> (size=0x14)
    // 0x8ee72c: mov             x1, x0
    // 0x8ee730: ldur            x0, [fp, #-0x18]
    // 0x8ee734: StoreField: r1->field_b = r0
    //     0x8ee734: stur            w0, [x1, #0xb]
    // 0x8ee738: ldur            x2, [fp, #-8]
    // 0x8ee73c: StoreField: r1->field_f = r2
    //     0x8ee73c: stur            w2, [x1, #0xf]
    // 0x8ee740: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x8ee740: ldur            w2, [x0, #0x17]
    // 0x8ee744: DecompressPointer r2
    //     0x8ee744: add             x2, x2, HEAP, lsl #32
    // 0x8ee748: str             x2, [SP]
    // 0x8ee74c: mov             x2, x1
    // 0x8ee750: ldur            x1, [fp, #-0x20]
    // 0x8ee754: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x8ee754: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x8ee758: r0 = completeError()
    //     0x8ee758: bl              #0x7f6b94  ; [dart:async] _Completer::completeError
    // 0x8ee75c: r0 = Null
    //     0x8ee75c: mov             x0, NULL
    // 0x8ee760: LeaveFrame
    //     0x8ee760: mov             SP, fp
    //     0x8ee764: ldp             fp, lr, [SP], #0x10
    // 0x8ee768: ret
    //     0x8ee768: ret             
    // 0x8ee76c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ee76c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ee770: b               #0x8ee6e4
  }
  void next(RequestInterceptorHandler, RequestOptions) {
    // ** addr: 0x8ee78c, size: 0x88
    // 0x8ee78c: EnterFrame
    //     0x8ee78c: stp             fp, lr, [SP, #-0x10]!
    //     0x8ee790: mov             fp, SP
    // 0x8ee794: CheckStackOverflow
    //     0x8ee794: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ee798: cmp             SP, x16
    //     0x8ee79c: b.ls            #0x8ee7f4
    // 0x8ee7a0: ldr             x0, [fp, #0x10]
    // 0x8ee7a4: r2 = Null
    //     0x8ee7a4: mov             x2, NULL
    // 0x8ee7a8: r1 = Null
    //     0x8ee7a8: mov             x1, NULL
    // 0x8ee7ac: r4 = 60
    //     0x8ee7ac: mov             x4, #0x3c
    // 0x8ee7b0: branchIfSmi(r0, 0x8ee7bc)
    //     0x8ee7b0: tbz             w0, #0, #0x8ee7bc
    // 0x8ee7b4: r4 = LoadClassIdInstr(r0)
    //     0x8ee7b4: ldur            x4, [x0, #-1]
    //     0x8ee7b8: ubfx            x4, x4, #0xc, #0x14
    // 0x8ee7bc: r17 = 4262
    //     0x8ee7bc: mov             x17, #0x10a6
    // 0x8ee7c0: cmp             x4, x17
    // 0x8ee7c4: b.eq            #0x8ee7dc
    // 0x8ee7c8: r8 = RequestOptions
    //     0x8ee7c8: add             x8, PP, #0x16, lsl #12  ; [pp+0x16870] Type: RequestOptions
    //     0x8ee7cc: ldr             x8, [x8, #0x870]
    // 0x8ee7d0: r3 = Null
    //     0x8ee7d0: add             x3, PP, #0x81, lsl #12  ; [pp+0x81f80] Null
    //     0x8ee7d4: ldr             x3, [x3, #0xf80]
    // 0x8ee7d8: r0 = RequestOptions()
    //     0x8ee7d8: bl              #0x8ea8ec  ; IsType_RequestOptions_Stub
    // 0x8ee7dc: ldr             x1, [fp, #0x18]
    // 0x8ee7e0: ldr             x2, [fp, #0x10]
    // 0x8ee7e4: r0 = next()
    //     0x8ee7e4: bl              #0x8ee7fc  ; [package:dio/src/dio_mixin.dart] RequestInterceptorHandler::next
    // 0x8ee7e8: LeaveFrame
    //     0x8ee7e8: mov             SP, fp
    //     0x8ee7ec: ldp             fp, lr, [SP], #0x10
    // 0x8ee7f0: ret
    //     0x8ee7f0: ret             
    // 0x8ee7f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ee7f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ee7f8: b               #0x8ee7a0
  }
  void next(RequestInterceptorHandler, RequestOptions) {
    // ** addr: 0x8ee7fc, size: 0x88
    // 0x8ee7fc: EnterFrame
    //     0x8ee7fc: stp             fp, lr, [SP, #-0x10]!
    //     0x8ee800: mov             fp, SP
    // 0x8ee804: AllocStack(0x20)
    //     0x8ee804: sub             SP, SP, #0x20
    // 0x8ee808: SetupParameters(RequestInterceptorHandler this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x8ee808: mov             x0, x1
    //     0x8ee80c: stur            x1, [fp, #-8]
    //     0x8ee810: stur            x2, [fp, #-0x10]
    // 0x8ee814: CheckStackOverflow
    //     0x8ee814: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ee818: cmp             SP, x16
    //     0x8ee81c: b.ls            #0x8ee87c
    // 0x8ee820: mov             x1, x0
    // 0x8ee824: r0 = _throwIfCompleted()
    //     0x8ee824: bl              #0x8ee308  ; [package:dio/src/dio_mixin.dart] _BaseHandler::_throwIfCompleted
    // 0x8ee828: ldur            x0, [fp, #-8]
    // 0x8ee82c: LoadField: r2 = r0->field_7
    //     0x8ee82c: ldur            w2, [x0, #7]
    // 0x8ee830: DecompressPointer r2
    //     0x8ee830: add             x2, x2, HEAP, lsl #32
    // 0x8ee834: stur            x2, [fp, #-0x18]
    // 0x8ee838: r1 = <RequestOptions>
    //     0x8ee838: add             x1, PP, #0x16, lsl #12  ; [pp+0x16890] TypeArguments: <RequestOptions>
    //     0x8ee83c: ldr             x1, [x1, #0x890]
    // 0x8ee840: r0 = InterceptorState()
    //     0x8ee840: bl              #0x8edd38  ; AllocateInterceptorStateStub -> InterceptorState<X0> (size=0x14)
    // 0x8ee844: mov             x1, x0
    // 0x8ee848: ldur            x0, [fp, #-0x10]
    // 0x8ee84c: StoreField: r1->field_b = r0
    //     0x8ee84c: stur            w0, [x1, #0xb]
    // 0x8ee850: r0 = Instance_InterceptorResultType
    //     0x8ee850: add             x0, PP, #0x15, lsl #12  ; [pp+0x15ec8] Obj!InterceptorResultType@12c64c1
    //     0x8ee854: ldr             x0, [x0, #0xec8]
    // 0x8ee858: StoreField: r1->field_f = r0
    //     0x8ee858: stur            w0, [x1, #0xf]
    // 0x8ee85c: str             x1, [SP]
    // 0x8ee860: ldur            x1, [fp, #-0x18]
    // 0x8ee864: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x8ee864: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x8ee868: r0 = complete()
    //     0x8ee868: bl              #0x128a5ec  ; [dart:async] _AsyncCompleter::complete
    // 0x8ee86c: r0 = Null
    //     0x8ee86c: mov             x0, NULL
    // 0x8ee870: LeaveFrame
    //     0x8ee870: mov             SP, fp
    //     0x8ee874: ldp             fp, lr, [SP], #0x10
    // 0x8ee878: ret
    //     0x8ee878: ret             
    // 0x8ee87c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ee87c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ee880: b               #0x8ee820
  }
  void resolve(RequestInterceptorHandler, Response<dynamic>, [bool]) {
    // ** addr: 0x8ee884, size: 0xf0
    // 0x8ee884: EnterFrame
    //     0x8ee884: stp             fp, lr, [SP, #-0x10]!
    //     0x8ee888: mov             fp, SP
    // 0x8ee88c: AllocStack(0x20)
    //     0x8ee88c: sub             SP, SP, #0x20
    // 0x8ee890: SetupParameters(RequestInterceptorHandler this /* r3, fp-0x18 */, dynamic _ /* r4, fp-0x10 */, [dynamic _ = false /* r5, fp-0x8 */])
    //     0x8ee890: ldur            w0, [x4, #0x13]
    //     0x8ee894: sub             x1, x0, #4
    //     0x8ee898: add             x3, fp, w1, sxtw #2
    //     0x8ee89c: ldr             x3, [x3, #0x18]
    //     0x8ee8a0: stur            x3, [fp, #-0x18]
    //     0x8ee8a4: add             x4, fp, w1, sxtw #2
    //     0x8ee8a8: ldr             x4, [x4, #0x10]
    //     0x8ee8ac: stur            x4, [fp, #-0x10]
    //     0x8ee8b0: cmp             w1, #2
    //     0x8ee8b4: b.lt            #0x8ee8c8
    //     0x8ee8b8: add             x0, fp, w1, sxtw #2
    //     0x8ee8bc: ldr             x0, [x0, #8]
    //     0x8ee8c0: mov             x5, x0
    //     0x8ee8c4: b               #0x8ee8cc
    //     0x8ee8c8: add             x5, NULL, #0x30  ; false
    //     0x8ee8cc: stur            x5, [fp, #-8]
    // 0x8ee8d0: CheckStackOverflow
    //     0x8ee8d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ee8d4: cmp             SP, x16
    //     0x8ee8d8: b.ls            #0x8ee96c
    // 0x8ee8dc: mov             x0, x4
    // 0x8ee8e0: r2 = Null
    //     0x8ee8e0: mov             x2, NULL
    // 0x8ee8e4: r1 = Null
    //     0x8ee8e4: mov             x1, NULL
    // 0x8ee8e8: r4 = 60
    //     0x8ee8e8: mov             x4, #0x3c
    // 0x8ee8ec: branchIfSmi(r0, 0x8ee8f8)
    //     0x8ee8ec: tbz             w0, #0, #0x8ee8f8
    // 0x8ee8f0: r4 = LoadClassIdInstr(r0)
    //     0x8ee8f0: ldur            x4, [x0, #-1]
    //     0x8ee8f4: ubfx            x4, x4, #0xc, #0x14
    // 0x8ee8f8: cmp             x4, #0xd47
    // 0x8ee8fc: b.eq            #0x8ee914
    // 0x8ee900: r8 = Response
    //     0x8ee900: add             x8, PP, #0x16, lsl #12  ; [pp+0x16028] Type: Response
    //     0x8ee904: ldr             x8, [x8, #0x28]
    // 0x8ee908: r3 = Null
    //     0x8ee908: add             x3, PP, #0x81, lsl #12  ; [pp+0x81f60] Null
    //     0x8ee90c: ldr             x3, [x3, #0xf60]
    // 0x8ee910: r0 = Response()
    //     0x8ee910: bl              #0x8ee53c  ; IsType_Response_Stub
    // 0x8ee914: ldur            x0, [fp, #-8]
    // 0x8ee918: r2 = Null
    //     0x8ee918: mov             x2, NULL
    // 0x8ee91c: r1 = Null
    //     0x8ee91c: mov             x1, NULL
    // 0x8ee920: r4 = 60
    //     0x8ee920: mov             x4, #0x3c
    // 0x8ee924: branchIfSmi(r0, 0x8ee930)
    //     0x8ee924: tbz             w0, #0, #0x8ee930
    // 0x8ee928: r4 = LoadClassIdInstr(r0)
    //     0x8ee928: ldur            x4, [x0, #-1]
    //     0x8ee92c: ubfx            x4, x4, #0xc, #0x14
    // 0x8ee930: cmp             x4, #0x3f
    // 0x8ee934: b.eq            #0x8ee948
    // 0x8ee938: r8 = bool
    //     0x8ee938: ldr             x8, [PP, #0xb18]  ; [pp+0xb18] Type: bool
    // 0x8ee93c: r3 = Null
    //     0x8ee93c: add             x3, PP, #0x81, lsl #12  ; [pp+0x81f70] Null
    //     0x8ee940: ldr             x3, [x3, #0xf70]
    // 0x8ee944: r0 = bool()
    //     0x8ee944: bl              #0x13ee15c  ; IsType_bool_Stub
    // 0x8ee948: ldur            x16, [fp, #-8]
    // 0x8ee94c: str             x16, [SP]
    // 0x8ee950: ldur            x1, [fp, #-0x18]
    // 0x8ee954: ldur            x2, [fp, #-0x10]
    // 0x8ee958: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x8ee958: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x8ee95c: r0 = resolve()
    //     0x8ee95c: bl              #0x8ee974  ; [package:dio/src/dio_mixin.dart] RequestInterceptorHandler::resolve
    // 0x8ee960: LeaveFrame
    //     0x8ee960: mov             SP, fp
    //     0x8ee964: ldp             fp, lr, [SP], #0x10
    // 0x8ee968: ret
    //     0x8ee968: ret             
    // 0x8ee96c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ee96c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ee970: b               #0x8ee8dc
  }
  void resolve(RequestInterceptorHandler, Response<dynamic>, [bool]) {
    // ** addr: 0x8ee974, size: 0xd0
    // 0x8ee974: EnterFrame
    //     0x8ee974: stp             fp, lr, [SP, #-0x10]!
    //     0x8ee978: mov             fp, SP
    // 0x8ee97c: AllocStack(0x28)
    //     0x8ee97c: sub             SP, SP, #0x28
    // 0x8ee980: SetupParameters(RequestInterceptorHandler this /* r1 => r0, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */, [dynamic _ = false /* r3, fp-0x8 */])
    //     0x8ee980: mov             x0, x1
    //     0x8ee984: stur            x1, [fp, #-0x10]
    //     0x8ee988: stur            x2, [fp, #-0x18]
    //     0x8ee98c: ldur            w1, [x4, #0x13]
    //     0x8ee990: sub             x3, x1, #4
    //     0x8ee994: cmp             w3, #2
    //     0x8ee998: b.lt            #0x8ee9ac
    //     0x8ee99c: add             x1, fp, w3, sxtw #2
    //     0x8ee9a0: ldr             x1, [x1, #8]
    //     0x8ee9a4: mov             x3, x1
    //     0x8ee9a8: b               #0x8ee9b0
    //     0x8ee9ac: add             x3, NULL, #0x30  ; false
    //     0x8ee9b0: stur            x3, [fp, #-8]
    // 0x8ee9b4: CheckStackOverflow
    //     0x8ee9b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ee9b8: cmp             SP, x16
    //     0x8ee9bc: b.ls            #0x8eea3c
    // 0x8ee9c0: mov             x1, x0
    // 0x8ee9c4: r0 = _throwIfCompleted()
    //     0x8ee9c4: bl              #0x8ee308  ; [package:dio/src/dio_mixin.dart] _BaseHandler::_throwIfCompleted
    // 0x8ee9c8: ldur            x0, [fp, #-0x10]
    // 0x8ee9cc: LoadField: r2 = r0->field_7
    //     0x8ee9cc: ldur            w2, [x0, #7]
    // 0x8ee9d0: DecompressPointer r2
    //     0x8ee9d0: add             x2, x2, HEAP, lsl #32
    // 0x8ee9d4: ldur            x0, [fp, #-8]
    // 0x8ee9d8: stur            x2, [fp, #-0x20]
    // 0x8ee9dc: tbnz            w0, #4, #0x8ee9ec
    // 0x8ee9e0: r3 = Instance_InterceptorResultType
    //     0x8ee9e0: add             x3, PP, #0x16, lsl #12  ; [pp+0x16018] Obj!InterceptorResultType@12c6481
    //     0x8ee9e4: ldr             x3, [x3, #0x18]
    // 0x8ee9e8: b               #0x8ee9f4
    // 0x8ee9ec: r3 = Instance_InterceptorResultType
    //     0x8ee9ec: add             x3, PP, #0x15, lsl #12  ; [pp+0x15f50] Obj!InterceptorResultType@12c6441
    //     0x8ee9f0: ldr             x3, [x3, #0xf50]
    // 0x8ee9f4: ldur            x0, [fp, #-0x18]
    // 0x8ee9f8: stur            x3, [fp, #-8]
    // 0x8ee9fc: r1 = <Response>
    //     0x8ee9fc: add             x1, PP, #0x15, lsl #12  ; [pp+0x15e58] TypeArguments: <Response>
    //     0x8eea00: ldr             x1, [x1, #0xe58]
    // 0x8eea04: r0 = InterceptorState()
    //     0x8eea04: bl              #0x8edd38  ; AllocateInterceptorStateStub -> InterceptorState<X0> (size=0x14)
    // 0x8eea08: mov             x1, x0
    // 0x8eea0c: ldur            x0, [fp, #-0x18]
    // 0x8eea10: StoreField: r1->field_b = r0
    //     0x8eea10: stur            w0, [x1, #0xb]
    // 0x8eea14: ldur            x0, [fp, #-8]
    // 0x8eea18: StoreField: r1->field_f = r0
    //     0x8eea18: stur            w0, [x1, #0xf]
    // 0x8eea1c: str             x1, [SP]
    // 0x8eea20: ldur            x1, [fp, #-0x20]
    // 0x8eea24: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x8eea24: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x8eea28: r0 = complete()
    //     0x8eea28: bl              #0x128a5ec  ; [dart:async] _AsyncCompleter::complete
    // 0x8eea2c: r0 = Null
    //     0x8eea2c: mov             x0, NULL
    // 0x8eea30: LeaveFrame
    //     0x8eea30: mov             SP, fp
    //     0x8eea34: ldp             fp, lr, [SP], #0x10
    // 0x8eea38: ret
    //     0x8eea38: ret             
    // 0x8eea3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8eea3c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8eea40: b               #0x8ee9c0
  }
  void reject(RequestInterceptorHandler, DioException, [bool]) {
    // ** addr: 0x8eea44, size: 0xf0
    // 0x8eea44: EnterFrame
    //     0x8eea44: stp             fp, lr, [SP, #-0x10]!
    //     0x8eea48: mov             fp, SP
    // 0x8eea4c: AllocStack(0x20)
    //     0x8eea4c: sub             SP, SP, #0x20
    // 0x8eea50: SetupParameters(RequestInterceptorHandler this /* r3, fp-0x18 */, dynamic _ /* r4, fp-0x10 */, [dynamic _ = false /* r5, fp-0x8 */])
    //     0x8eea50: ldur            w0, [x4, #0x13]
    //     0x8eea54: sub             x1, x0, #4
    //     0x8eea58: add             x3, fp, w1, sxtw #2
    //     0x8eea5c: ldr             x3, [x3, #0x18]
    //     0x8eea60: stur            x3, [fp, #-0x18]
    //     0x8eea64: add             x4, fp, w1, sxtw #2
    //     0x8eea68: ldr             x4, [x4, #0x10]
    //     0x8eea6c: stur            x4, [fp, #-0x10]
    //     0x8eea70: cmp             w1, #2
    //     0x8eea74: b.lt            #0x8eea88
    //     0x8eea78: add             x0, fp, w1, sxtw #2
    //     0x8eea7c: ldr             x0, [x0, #8]
    //     0x8eea80: mov             x5, x0
    //     0x8eea84: b               #0x8eea8c
    //     0x8eea88: add             x5, NULL, #0x30  ; false
    //     0x8eea8c: stur            x5, [fp, #-8]
    // 0x8eea90: CheckStackOverflow
    //     0x8eea90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8eea94: cmp             SP, x16
    //     0x8eea98: b.ls            #0x8eeb2c
    // 0x8eea9c: mov             x0, x4
    // 0x8eeaa0: r2 = Null
    //     0x8eeaa0: mov             x2, NULL
    // 0x8eeaa4: r1 = Null
    //     0x8eeaa4: mov             x1, NULL
    // 0x8eeaa8: r4 = 60
    //     0x8eeaa8: mov             x4, #0x3c
    // 0x8eeaac: branchIfSmi(r0, 0x8eeab8)
    //     0x8eeaac: tbz             w0, #0, #0x8eeab8
    // 0x8eeab0: r4 = LoadClassIdInstr(r0)
    //     0x8eeab0: ldur            x4, [x0, #-1]
    //     0x8eeab4: ubfx            x4, x4, #0xc, #0x14
    // 0x8eeab8: cmp             x4, #0xd52
    // 0x8eeabc: b.eq            #0x8eead4
    // 0x8eeac0: r8 = DioException
    //     0x8eeac0: add             x8, PP, #0x15, lsl #12  ; [pp+0x15fb8] Type: DioException
    //     0x8eeac4: ldr             x8, [x8, #0xfb8]
    // 0x8eeac8: r3 = Null
    //     0x8eeac8: add             x3, PP, #0x81, lsl #12  ; [pp+0x81f40] Null
    //     0x8eeacc: ldr             x3, [x3, #0xf40]
    // 0x8eead0: r0 = DioException()
    //     0x8eead0: bl              #0x8e9ff4  ; IsType_DioException_Stub
    // 0x8eead4: ldur            x0, [fp, #-8]
    // 0x8eead8: r2 = Null
    //     0x8eead8: mov             x2, NULL
    // 0x8eeadc: r1 = Null
    //     0x8eeadc: mov             x1, NULL
    // 0x8eeae0: r4 = 60
    //     0x8eeae0: mov             x4, #0x3c
    // 0x8eeae4: branchIfSmi(r0, 0x8eeaf0)
    //     0x8eeae4: tbz             w0, #0, #0x8eeaf0
    // 0x8eeae8: r4 = LoadClassIdInstr(r0)
    //     0x8eeae8: ldur            x4, [x0, #-1]
    //     0x8eeaec: ubfx            x4, x4, #0xc, #0x14
    // 0x8eeaf0: cmp             x4, #0x3f
    // 0x8eeaf4: b.eq            #0x8eeb08
    // 0x8eeaf8: r8 = bool
    //     0x8eeaf8: ldr             x8, [PP, #0xb18]  ; [pp+0xb18] Type: bool
    // 0x8eeafc: r3 = Null
    //     0x8eeafc: add             x3, PP, #0x81, lsl #12  ; [pp+0x81f50] Null
    //     0x8eeb00: ldr             x3, [x3, #0xf50]
    // 0x8eeb04: r0 = bool()
    //     0x8eeb04: bl              #0x13ee15c  ; IsType_bool_Stub
    // 0x8eeb08: ldur            x16, [fp, #-8]
    // 0x8eeb0c: str             x16, [SP]
    // 0x8eeb10: ldur            x1, [fp, #-0x18]
    // 0x8eeb14: ldur            x2, [fp, #-0x10]
    // 0x8eeb18: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x8eeb18: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x8eeb1c: r0 = reject()
    //     0x8eeb1c: bl              #0x8ee698  ; [package:dio/src/dio_mixin.dart] RequestInterceptorHandler::reject
    // 0x8eeb20: LeaveFrame
    //     0x8eeb20: mov             SP, fp
    //     0x8eeb24: ldp             fp, lr, [SP], #0x10
    // 0x8eeb28: ret
    //     0x8eeb28: ret             
    // 0x8eeb2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8eeb2c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8eeb30: b               #0x8eea9c
  }
}

// class id: 3409, size: 0x14, field offset: 0x8
//   const constructor, 
class InterceptorState<X0> extends Object {

  _ toString(/* No info */) {
    // ** addr: 0x111457c, size: 0xbc
    // 0x111457c: EnterFrame
    //     0x111457c: stp             fp, lr, [SP, #-0x10]!
    //     0x1114580: mov             fp, SP
    // 0x1114584: AllocStack(0x10)
    //     0x1114584: sub             SP, SP, #0x10
    // 0x1114588: CheckStackOverflow
    //     0x1114588: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x111458c: cmp             SP, x16
    //     0x1114590: b.ls            #0x1114630
    // 0x1114594: r1 = Null
    //     0x1114594: mov             x1, NULL
    // 0x1114598: r2 = 14
    //     0x1114598: mov             x2, #0xe
    // 0x111459c: r0 = AllocateArray()
    //     0x111459c: bl              #0x13df928  ; AllocateArrayStub
    // 0x11145a0: stur            x0, [fp, #-8]
    // 0x11145a4: r16 = "InterceptorState<"
    //     0x11145a4: add             x16, PP, #0x81, lsl #12  ; [pp+0x81ef8] "InterceptorState<"
    //     0x11145a8: ldr             x16, [x16, #0xef8]
    // 0x11145ac: StoreField: r0->field_f = r16
    //     0x11145ac: stur            w16, [x0, #0xf]
    // 0x11145b0: ldr             x3, [fp, #0x10]
    // 0x11145b4: LoadField: r2 = r3->field_7
    //     0x11145b4: ldur            w2, [x3, #7]
    // 0x11145b8: DecompressPointer r2
    //     0x11145b8: add             x2, x2, HEAP, lsl #32
    // 0x11145bc: r1 = Null
    //     0x11145bc: mov             x1, NULL
    // 0x11145c0: r3 = X0
    //     0x11145c0: ldr             x3, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x11145c4: r30 = InstantiateTypeNonNullableClassTypeParameterStub
    //     0x11145c4: add             lr, PP, #0x12, lsl #12  ; [pp+0x12e80] Stub: InstantiateTypeNonNullableClassTypeParameter (0x7c1258)
    //     0x11145c8: ldr             lr, [lr, #0xe80]
    // 0x11145cc: LoadField: r30 = r30->field_7
    //     0x11145cc: ldur            lr, [lr, #7]
    // 0x11145d0: blr             lr
    // 0x11145d4: mov             x1, x0
    // 0x11145d8: ldur            x0, [fp, #-8]
    // 0x11145dc: StoreField: r0->field_13 = r1
    //     0x11145dc: stur            w1, [x0, #0x13]
    // 0x11145e0: r16 = ">(type: "
    //     0x11145e0: add             x16, PP, #0x81, lsl #12  ; [pp+0x81f00] ">(type: "
    //     0x11145e4: ldr             x16, [x16, #0xf00]
    // 0x11145e8: ArrayStore: r0[0] = r16  ; List_4
    //     0x11145e8: stur            w16, [x0, #0x17]
    // 0x11145ec: ldr             x1, [fp, #0x10]
    // 0x11145f0: LoadField: r2 = r1->field_f
    //     0x11145f0: ldur            w2, [x1, #0xf]
    // 0x11145f4: DecompressPointer r2
    //     0x11145f4: add             x2, x2, HEAP, lsl #32
    // 0x11145f8: StoreField: r0->field_1b = r2
    //     0x11145f8: stur            w2, [x0, #0x1b]
    // 0x11145fc: r16 = ", data: "
    //     0x11145fc: add             x16, PP, #0x81, lsl #12  ; [pp+0x81f08] ", data: "
    //     0x1114600: ldr             x16, [x16, #0xf08]
    // 0x1114604: StoreField: r0->field_1f = r16
    //     0x1114604: stur            w16, [x0, #0x1f]
    // 0x1114608: LoadField: r2 = r1->field_b
    //     0x1114608: ldur            w2, [x1, #0xb]
    // 0x111460c: DecompressPointer r2
    //     0x111460c: add             x2, x2, HEAP, lsl #32
    // 0x1114610: StoreField: r0->field_23 = r2
    //     0x1114610: stur            w2, [x0, #0x23]
    // 0x1114614: r16 = ")"
    //     0x1114614: ldr             x16, [PP, #0xe60]  ; [pp+0xe60] ")"
    // 0x1114618: StoreField: r0->field_27 = r16
    //     0x1114618: stur            w16, [x0, #0x27]
    // 0x111461c: str             x0, [SP]
    // 0x1114620: r0 = _interpolate()
    //     0x1114620: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x1114624: LeaveFrame
    //     0x1114624: mov             SP, fp
    //     0x1114628: ldp             fp, lr, [SP], #0x10
    // 0x111462c: ret
    //     0x111462c: ret             
    // 0x1114630: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1114630: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1114634: b               #0x1114594
  }
}

// class id: 3977, size: 0x8, field offset: 0x8
abstract class DioMixin extends Object
    implements Dio {

  static _ assureDioException(/* No info */) {
    // ** addr: 0x8ed26c, size: 0xac
    // 0x8ed26c: EnterFrame
    //     0x8ed26c: stp             fp, lr, [SP, #-0x10]!
    //     0x8ed270: mov             fp, SP
    // 0x8ed274: AllocStack(0x30)
    //     0x8ed274: sub             SP, SP, #0x30
    // 0x8ed278: SetupParameters(dynamic _ /* r1 => r0, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */, [dynamic _ = Null /* r1, fp-0x8 */])
    //     0x8ed278: mov             x0, x1
    //     0x8ed27c: stur            x1, [fp, #-0x10]
    //     0x8ed280: stur            x2, [fp, #-0x18]
    //     0x8ed284: ldur            w1, [x4, #0x13]
    //     0x8ed288: sub             x3, x1, #4
    //     0x8ed28c: cmp             w3, #2
    //     0x8ed290: b.lt            #0x8ed2a0
    //     0x8ed294: add             x1, fp, w3, sxtw #2
    //     0x8ed298: ldr             x1, [x1, #8]
    //     0x8ed29c: b               #0x8ed2a4
    //     0x8ed2a0: mov             x1, NULL
    //     0x8ed2a4: stur            x1, [fp, #-8]
    // 0x8ed2a8: CheckStackOverflow
    //     0x8ed2a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ed2ac: cmp             SP, x16
    //     0x8ed2b0: b.ls            #0x8ed310
    // 0x8ed2b4: r3 = 60
    //     0x8ed2b4: mov             x3, #0x3c
    // 0x8ed2b8: branchIfSmi(r0, 0x8ed2c4)
    //     0x8ed2b8: tbz             w0, #0, #0x8ed2c4
    // 0x8ed2bc: r3 = LoadClassIdInstr(r0)
    //     0x8ed2bc: ldur            x3, [x0, #-1]
    //     0x8ed2c0: ubfx            x3, x3, #0xc, #0x14
    // 0x8ed2c4: cmp             x3, #0xd52
    // 0x8ed2c8: b.ne            #0x8ed2d8
    // 0x8ed2cc: LeaveFrame
    //     0x8ed2cc: mov             SP, fp
    //     0x8ed2d0: ldp             fp, lr, [SP], #0x10
    // 0x8ed2d4: ret
    //     0x8ed2d4: ret             
    // 0x8ed2d8: r0 = DioException()
    //     0x8ed2d8: bl              #0x8ea014  ; AllocateDioExceptionStub -> DioException (size=0x24)
    // 0x8ed2dc: stur            x0, [fp, #-0x20]
    // 0x8ed2e0: ldur            x16, [fp, #-0x10]
    // 0x8ed2e4: ldur            lr, [fp, #-8]
    // 0x8ed2e8: stp             lr, x16, [SP]
    // 0x8ed2ec: mov             x1, x0
    // 0x8ed2f0: ldur            x2, [fp, #-0x18]
    // 0x8ed2f4: r4 = const [0, 0x4, 0x2, 0x2, error, 0x2, stackTrace, 0x3, null]
    //     0x8ed2f4: add             x4, PP, #0x16, lsl #12  ; [pp+0x16898] List(9) [0, 0x4, 0x2, 0x2, "error", 0x2, "stackTrace", 0x3, Null]
    //     0x8ed2f8: ldr             x4, [x4, #0x898]
    // 0x8ed2fc: r0 = DioException()
    //     0x8ed2fc: bl              #0x8e97ec  ; [package:dio/src/dio_exception.dart] DioException::DioException
    // 0x8ed300: ldur            x0, [fp, #-0x20]
    // 0x8ed304: LeaveFrame
    //     0x8ed304: mov             SP, fp
    //     0x8ed308: ldp             fp, lr, [SP], #0x10
    // 0x8ed30c: ret
    //     0x8ed30c: ret             
    // 0x8ed310: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ed310: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ed314: b               #0x8ed2b4
  }
  static Response<Y0> assureResponse<Y0>(Object, RequestOptions) {
    // ** addr: 0x8ed318, size: 0x2b4
    // 0x8ed318: EnterFrame
    //     0x8ed318: stp             fp, lr, [SP, #-0x10]!
    //     0x8ed31c: mov             fp, SP
    // 0x8ed320: AllocStack(0x50)
    //     0x8ed320: sub             SP, SP, #0x50
    // 0x8ed324: SetupParameters([dynamic _, dynamic _ /* r3 */])
    //     0x8ed324: ldur            w0, [x4, #0xf]
    //     0x8ed328: cbnz            w0, #0x8ed334
    //     0x8ed32c: mov             x4, NULL
    //     0x8ed330: b               #0x8ed344
    //     0x8ed334: ldur            w0, [x4, #0x17]
    //     0x8ed338: add             x1, fp, w0, sxtw #2
    //     0x8ed33c: ldr             x1, [x1, #0x10]
    //     0x8ed340: mov             x4, x1
    //     0x8ed344: ldr             x3, [fp, #0x18]
    //     0x8ed348: stur            x4, [fp, #-8]
    // 0x8ed34c: CheckStackOverflow
    //     0x8ed34c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ed350: cmp             SP, x16
    //     0x8ed354: b.ls            #0x8ed5b8
    // 0x8ed358: r0 = 60
    //     0x8ed358: mov             x0, #0x3c
    // 0x8ed35c: branchIfSmi(r3, 0x8ed368)
    //     0x8ed35c: tbz             w3, #0, #0x8ed368
    // 0x8ed360: r0 = LoadClassIdInstr(r3)
    //     0x8ed360: ldur            x0, [x3, #-1]
    //     0x8ed364: ubfx            x0, x0, #0xc, #0x14
    // 0x8ed368: cmp             x0, #0xd47
    // 0x8ed36c: b.eq            #0x8ed3dc
    // 0x8ed370: mov             x0, x3
    // 0x8ed374: mov             x1, x4
    // 0x8ed378: r2 = Null
    //     0x8ed378: mov             x2, NULL
    // 0x8ed37c: cmp             w1, NULL
    // 0x8ed380: b.eq            #0x8ed3a4
    // 0x8ed384: ArrayLoad: r4 = r1[0]  ; List_4
    //     0x8ed384: ldur            w4, [x1, #0x17]
    // 0x8ed388: DecompressPointer r4
    //     0x8ed388: add             x4, x4, HEAP, lsl #32
    // 0x8ed38c: r8 = Y0
    //     0x8ed38c: add             x8, PP, #0x16, lsl #12  ; [pp+0x168a0] TypeParameter: Y0
    //     0x8ed390: ldr             x8, [x8, #0x8a0]
    // 0x8ed394: LoadField: r9 = r4->field_7
    //     0x8ed394: ldur            x9, [x4, #7]
    // 0x8ed398: r3 = Null
    //     0x8ed398: add             x3, PP, #0x16, lsl #12  ; [pp+0x168a8] Null
    //     0x8ed39c: ldr             x3, [x3, #0x8a8]
    // 0x8ed3a0: blr             x9
    // 0x8ed3a4: ldur            x1, [fp, #-8]
    // 0x8ed3a8: r0 = Response()
    //     0x8ed3a8: bl              #0x8edafc  ; AllocateResponseStub -> Response<X0> (size=0x2c)
    // 0x8ed3ac: stur            x0, [fp, #-0x10]
    // 0x8ed3b0: ldr             x16, [fp, #0x18]
    // 0x8ed3b4: str             x16, [SP]
    // 0x8ed3b8: mov             x1, x0
    // 0x8ed3bc: ldr             x2, [fp, #0x10]
    // 0x8ed3c0: r4 = const [0, 0x3, 0x1, 0x2, data, 0x2, null]
    //     0x8ed3c0: add             x4, PP, #0x16, lsl #12  ; [pp+0x168b8] List(7) [0, 0x3, 0x1, 0x2, "data", 0x2, Null]
    //     0x8ed3c4: ldr             x4, [x4, #0x8b8]
    // 0x8ed3c8: r0 = Response()
    //     0x8ed3c8: bl              #0x8ed6e8  ; [package:dio/src/response.dart] Response::Response
    // 0x8ed3cc: ldur            x0, [fp, #-0x10]
    // 0x8ed3d0: LeaveFrame
    //     0x8ed3d0: mov             SP, fp
    //     0x8ed3d4: ldp             fp, lr, [SP], #0x10
    // 0x8ed3d8: ret
    //     0x8ed3d8: ret             
    // 0x8ed3dc: ldr             x0, [fp, #0x18]
    // 0x8ed3e0: ldur            x1, [fp, #-8]
    // 0x8ed3e4: r2 = Null
    //     0x8ed3e4: mov             x2, NULL
    // 0x8ed3e8: cmp             w0, NULL
    // 0x8ed3ec: b.eq            #0x8ed438
    // 0x8ed3f0: branchIfSmi(r0, 0x8ed438)
    //     0x8ed3f0: tbz             w0, #0, #0x8ed438
    // 0x8ed3f4: r3 = SubtypeTestCache
    //     0x8ed3f4: add             x3, PP, #0x16, lsl #12  ; [pp+0x168c0] SubtypeTestCache
    //     0x8ed3f8: ldr             x3, [x3, #0x8c0]
    // 0x8ed3fc: r30 = Subtype4TestCacheStub
    //     0x8ed3fc: ldr             lr, [PP, #0x20]  ; [pp+0x20] Stub: Subtype4TestCache (0x7d2a64)
    // 0x8ed400: LoadField: r30 = r30->field_7
    //     0x8ed400: ldur            lr, [lr, #7]
    // 0x8ed404: blr             lr
    // 0x8ed408: cmp             w7, NULL
    // 0x8ed40c: b.eq            #0x8ed418
    // 0x8ed410: tbnz            w7, #4, #0x8ed438
    // 0x8ed414: b               #0x8ed440
    // 0x8ed418: r8 = Response<Y0>
    //     0x8ed418: add             x8, PP, #0x16, lsl #12  ; [pp+0x168c8] Type: Response<Y0>
    //     0x8ed41c: ldr             x8, [x8, #0x8c8]
    // 0x8ed420: r3 = SubtypeTestCache
    //     0x8ed420: add             x3, PP, #0x16, lsl #12  ; [pp+0x168d0] SubtypeTestCache
    //     0x8ed424: ldr             x3, [x3, #0x8d0]
    // 0x8ed428: r30 = InstanceOfStub
    //     0x8ed428: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x8ed42c: LoadField: r30 = r30->field_7
    //     0x8ed42c: ldur            lr, [lr, #7]
    // 0x8ed430: blr             lr
    // 0x8ed434: b               #0x8ed444
    // 0x8ed438: r0 = false
    //     0x8ed438: add             x0, NULL, #0x30  ; false
    // 0x8ed43c: b               #0x8ed444
    // 0x8ed440: r0 = true
    //     0x8ed440: add             x0, NULL, #0x20  ; true
    // 0x8ed444: tbz             w0, #4, #0x8ed5a8
    // 0x8ed448: ldr             x3, [fp, #0x18]
    // 0x8ed44c: LoadField: r4 = r3->field_b
    //     0x8ed44c: ldur            w4, [x3, #0xb]
    // 0x8ed450: DecompressPointer r4
    //     0x8ed450: add             x4, x4, HEAP, lsl #32
    // 0x8ed454: mov             x0, x4
    // 0x8ed458: ldur            x1, [fp, #-8]
    // 0x8ed45c: stur            x4, [fp, #-0x10]
    // 0x8ed460: r2 = Null
    //     0x8ed460: mov             x2, NULL
    // 0x8ed464: cmp             w0, NULL
    // 0x8ed468: b.eq            #0x8ed494
    // 0x8ed46c: cmp             w1, NULL
    // 0x8ed470: b.eq            #0x8ed494
    // 0x8ed474: ArrayLoad: r4 = r1[0]  ; List_4
    //     0x8ed474: ldur            w4, [x1, #0x17]
    // 0x8ed478: DecompressPointer r4
    //     0x8ed478: add             x4, x4, HEAP, lsl #32
    // 0x8ed47c: r8 = Y0?
    //     0x8ed47c: add             x8, PP, #0x16, lsl #12  ; [pp+0x168d8] TypeParameter: Y0?
    //     0x8ed480: ldr             x8, [x8, #0x8d8]
    // 0x8ed484: LoadField: r9 = r4->field_7
    //     0x8ed484: ldur            x9, [x4, #7]
    // 0x8ed488: r3 = Null
    //     0x8ed488: add             x3, PP, #0x16, lsl #12  ; [pp+0x168e0] Null
    //     0x8ed48c: ldr             x3, [x3, #0x8e0]
    // 0x8ed490: blr             x9
    // 0x8ed494: ldur            x0, [fp, #-0x10]
    // 0x8ed498: r1 = 60
    //     0x8ed498: mov             x1, #0x3c
    // 0x8ed49c: branchIfSmi(r0, 0x8ed4a8)
    //     0x8ed49c: tbz             w0, #0, #0x8ed4a8
    // 0x8ed4a0: r1 = LoadClassIdInstr(r0)
    //     0x8ed4a0: ldur            x1, [x0, #-1]
    //     0x8ed4a4: ubfx            x1, x1, #0xc, #0x14
    // 0x8ed4a8: cmp             x1, #0xd57
    // 0x8ed4ac: b.ne            #0x8ed4f4
    // 0x8ed4b0: ldr             x1, [fp, #0x10]
    // 0x8ed4b4: LoadField: r2 = r0->field_1f
    //     0x8ed4b4: ldur            w2, [x0, #0x1f]
    // 0x8ed4b8: DecompressPointer r2
    //     0x8ed4b8: add             x2, x2, HEAP, lsl #32
    // 0x8ed4bc: stur            x2, [fp, #-0x18]
    // 0x8ed4c0: LoadField: r3 = r1->field_f
    //     0x8ed4c0: ldur            w3, [x1, #0xf]
    // 0x8ed4c4: DecompressPointer r3
    //     0x8ed4c4: add             x3, x3, HEAP, lsl #32
    // 0x8ed4c8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8ed4cc: cmp             w3, w16
    // 0x8ed4d0: b.eq            #0x8ed5c0
    // 0x8ed4d4: r0 = Headers()
    //     0x8ed4d4: bl              #0x8ed6dc  ; AllocateHeadersStub -> Headers (size=0xc)
    // 0x8ed4d8: mov             x1, x0
    // 0x8ed4dc: ldur            x2, [fp, #-0x18]
    // 0x8ed4e0: stur            x0, [fp, #-0x18]
    // 0x8ed4e4: r0 = Headers.fromMap()
    //     0x8ed4e4: bl              #0x8ed5cc  ; [package:dio/src/headers.dart] Headers::Headers.fromMap
    // 0x8ed4e8: ldur            x3, [fp, #-0x18]
    // 0x8ed4ec: ldr             x0, [fp, #0x18]
    // 0x8ed4f0: b               #0x8ed504
    // 0x8ed4f4: ldr             x0, [fp, #0x18]
    // 0x8ed4f8: LoadField: r1 = r0->field_1b
    //     0x8ed4f8: ldur            w1, [x0, #0x1b]
    // 0x8ed4fc: DecompressPointer r1
    //     0x8ed4fc: add             x1, x1, HEAP, lsl #32
    // 0x8ed500: mov             x3, x1
    // 0x8ed504: ldur            x2, [fp, #-0x10]
    // 0x8ed508: stur            x3, [fp, #-0x48]
    // 0x8ed50c: LoadField: r4 = r0->field_f
    //     0x8ed50c: ldur            w4, [x0, #0xf]
    // 0x8ed510: DecompressPointer r4
    //     0x8ed510: add             x4, x4, HEAP, lsl #32
    // 0x8ed514: stur            x4, [fp, #-0x40]
    // 0x8ed518: LoadField: r5 = r0->field_13
    //     0x8ed518: ldur            w5, [x0, #0x13]
    // 0x8ed51c: DecompressPointer r5
    //     0x8ed51c: add             x5, x5, HEAP, lsl #32
    // 0x8ed520: stur            x5, [fp, #-0x38]
    // 0x8ed524: LoadField: r6 = r0->field_1f
    //     0x8ed524: ldur            w6, [x0, #0x1f]
    // 0x8ed528: DecompressPointer r6
    //     0x8ed528: add             x6, x6, HEAP, lsl #32
    // 0x8ed52c: stur            x6, [fp, #-0x30]
    // 0x8ed530: LoadField: r7 = r0->field_23
    //     0x8ed530: ldur            w7, [x0, #0x23]
    // 0x8ed534: DecompressPointer r7
    //     0x8ed534: add             x7, x7, HEAP, lsl #32
    // 0x8ed538: stur            x7, [fp, #-0x28]
    // 0x8ed53c: ArrayLoad: r8 = r0[0]  ; List_4
    //     0x8ed53c: ldur            w8, [x0, #0x17]
    // 0x8ed540: DecompressPointer r8
    //     0x8ed540: add             x8, x8, HEAP, lsl #32
    // 0x8ed544: stur            x8, [fp, #-0x20]
    // 0x8ed548: LoadField: r9 = r0->field_27
    //     0x8ed548: ldur            w9, [x0, #0x27]
    // 0x8ed54c: DecompressPointer r9
    //     0x8ed54c: add             x9, x9, HEAP, lsl #32
    // 0x8ed550: ldur            x1, [fp, #-8]
    // 0x8ed554: stur            x9, [fp, #-0x18]
    // 0x8ed558: r0 = Response()
    //     0x8ed558: bl              #0x8edafc  ; AllocateResponseStub -> Response<X0> (size=0x2c)
    // 0x8ed55c: ldur            x1, [fp, #-0x10]
    // 0x8ed560: StoreField: r0->field_b = r1
    //     0x8ed560: stur            w1, [x0, #0xb]
    // 0x8ed564: ldur            x1, [fp, #-0x40]
    // 0x8ed568: StoreField: r0->field_f = r1
    //     0x8ed568: stur            w1, [x0, #0xf]
    // 0x8ed56c: ldur            x1, [fp, #-0x38]
    // 0x8ed570: StoreField: r0->field_13 = r1
    //     0x8ed570: stur            w1, [x0, #0x13]
    // 0x8ed574: ldur            x1, [fp, #-0x20]
    // 0x8ed578: ArrayStore: r0[0] = r1  ; List_4
    //     0x8ed578: stur            w1, [x0, #0x17]
    // 0x8ed57c: ldur            x1, [fp, #-0x30]
    // 0x8ed580: StoreField: r0->field_1f = r1
    //     0x8ed580: stur            w1, [x0, #0x1f]
    // 0x8ed584: ldur            x1, [fp, #-0x28]
    // 0x8ed588: StoreField: r0->field_23 = r1
    //     0x8ed588: stur            w1, [x0, #0x23]
    // 0x8ed58c: ldur            x1, [fp, #-0x48]
    // 0x8ed590: StoreField: r0->field_1b = r1
    //     0x8ed590: stur            w1, [x0, #0x1b]
    // 0x8ed594: ldur            x1, [fp, #-0x18]
    // 0x8ed598: StoreField: r0->field_27 = r1
    //     0x8ed598: stur            w1, [x0, #0x27]
    // 0x8ed59c: LeaveFrame
    //     0x8ed59c: mov             SP, fp
    //     0x8ed5a0: ldp             fp, lr, [SP], #0x10
    // 0x8ed5a4: ret
    //     0x8ed5a4: ret             
    // 0x8ed5a8: ldr             x0, [fp, #0x18]
    // 0x8ed5ac: LeaveFrame
    //     0x8ed5ac: mov             SP, fp
    //     0x8ed5b0: ldp             fp, lr, [SP], #0x10
    // 0x8ed5b4: ret
    //     0x8ed5b4: ret             
    // 0x8ed5b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ed5b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ed5bc: b               #0x8ed358
    // 0x8ed5c0: r9 = preserveHeaderCase
    //     0x8ed5c0: add             x9, PP, #0x16, lsl #12  ; [pp+0x16070] Field <_RequestConfig@271184022.preserveHeaderCase>: late (offset: 0x10)
    //     0x8ed5c4: ldr             x9, [x9, #0x70]
    // 0x8ed5c8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8ed5c8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 4264, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class Interceptor extends Object {

  dynamic _invokeError(dynamic) {
    // ** addr: 0x11a3960, size: 0x24
    // 0x11a3960: EnterFrame
    //     0x11a3960: stp             fp, lr, [SP, #-0x10]!
    //     0x11a3964: mov             fp, SP
    // 0x11a3968: ldr             x2, [fp, #0x10]
    // 0x11a396c: r1 = Function '_invokeError@270263083':.
    //     0x11a396c: add             x1, PP, #0x81, lsl #12  ; [pp+0x81f90] AnonymousClosure: (0x11a3984), in [package:dio/src/dio_mixin.dart] Interceptor::_invokeError (0x11a39c4)
    //     0x11a3970: ldr             x1, [x1, #0xf90]
    // 0x11a3974: r0 = AllocateClosure()
    //     0x11a3974: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11a3978: LeaveFrame
    //     0x11a3978: mov             SP, fp
    //     0x11a397c: ldp             fp, lr, [SP], #0x10
    // 0x11a3980: ret
    //     0x11a3980: ret             
  }
  [closure] Object? _invokeError(dynamic, DioException, ErrorInterceptorHandler) {
    // ** addr: 0x11a3984, size: 0x40
    // 0x11a3984: EnterFrame
    //     0x11a3984: stp             fp, lr, [SP, #-0x10]!
    //     0x11a3988: mov             fp, SP
    // 0x11a398c: ldr             x0, [fp, #0x20]
    // 0x11a3990: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x11a3990: ldur            w1, [x0, #0x17]
    // 0x11a3994: DecompressPointer r1
    //     0x11a3994: add             x1, x1, HEAP, lsl #32
    // 0x11a3998: CheckStackOverflow
    //     0x11a3998: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a399c: cmp             SP, x16
    //     0x11a39a0: b.ls            #0x11a39bc
    // 0x11a39a4: ldr             x2, [fp, #0x18]
    // 0x11a39a8: ldr             x3, [fp, #0x10]
    // 0x11a39ac: r0 = _invokeError()
    //     0x11a39ac: bl              #0x11a39c4  ; [package:dio/src/dio_mixin.dart] Interceptor::_invokeError
    // 0x11a39b0: LeaveFrame
    //     0x11a39b0: mov             SP, fp
    //     0x11a39b4: ldp             fp, lr, [SP], #0x10
    // 0x11a39b8: ret
    //     0x11a39b8: ret             
    // 0x11a39bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a39bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a39c0: b               #0x11a39a4
  }
  _ _invokeError(/* No info */) {
    // ** addr: 0x11a39c4, size: 0xb0
    // 0x11a39c4: EnterFrame
    //     0x11a39c4: stp             fp, lr, [SP, #-0x10]!
    //     0x11a39c8: mov             fp, SP
    // 0x11a39cc: AllocStack(0x28)
    //     0x11a39cc: sub             SP, SP, #0x28
    // 0x11a39d0: SetupParameters(Interceptor this /* r1 => r2 */, dynamic _ /* r2 => r0, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0x11a39d0: mov             x0, x2
    //     0x11a39d4: stur            x2, [fp, #-8]
    //     0x11a39d8: mov             x2, x1
    //     0x11a39dc: stur            x3, [fp, #-0x10]
    // 0x11a39e0: CheckStackOverflow
    //     0x11a39e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a39e4: cmp             SP, x16
    //     0x11a39e8: b.ls            #0x11a3a6c
    // 0x11a39ec: r1 = LoadClassIdInstr(r2)
    //     0x11a39ec: ldur            x1, [x2, #-1]
    //     0x11a39f0: ubfx            x1, x1, #0xc, #0x14
    // 0x11a39f4: r17 = 4265
    //     0x11a39f4: mov             x17, #0x10a9
    // 0x11a39f8: cmp             x1, x17
    // 0x11a39fc: b.ne            #0x11a3a10
    // 0x11a3a00: r1 = Function 'onError':.
    //     0x11a3a00: add             x1, PP, #0x81, lsl #12  ; [pp+0x81f98] AnonymousClosure: (0x11a3c20), in [package:dio_cookie_manager/src/cookie_mgr.dart] CookieManager::onError (0x11a3c60)
    //     0x11a3a04: ldr             x1, [x1, #0xf98]
    // 0x11a3a08: r0 = AllocateClosure()
    //     0x11a3a08: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11a3a0c: b               #0x11a3a38
    // 0x11a3a10: r17 = 4266
    //     0x11a3a10: mov             x17, #0x10aa
    // 0x11a3a14: cmp             x1, x17
    // 0x11a3a18: b.ne            #0x11a3a2c
    // 0x11a3a1c: r1 = Function 'onError':.
    //     0x11a3a1c: add             x1, PP, #0x81, lsl #12  ; [pp+0x81fa0] AnonymousClosure: (0x11a3be8), of [package:dio/src/dio_mixin.dart] Interceptor
    //     0x11a3a20: ldr             x1, [x1, #0xfa0]
    // 0x11a3a24: r0 = AllocateClosure()
    //     0x11a3a24: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11a3a28: b               #0x11a3a38
    // 0x11a3a2c: r1 = Function 'onError':.
    //     0x11a3a2c: add             x1, PP, #0x81, lsl #12  ; [pp+0x81fa8] AnonymousClosure: (0x11a3a74), in [dart:mixin_deduplication] _MixinApplication366&Interceptor&_InterceptorWrapperMixin::onError (0x11a3ab4)
    //     0x11a3a30: ldr             x1, [x1, #0xfa8]
    // 0x11a3a34: r0 = AllocateClosure()
    //     0x11a3a34: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11a3a38: ldur            x16, [fp, #-8]
    // 0x11a3a3c: stp             x16, x0, [SP, #8]
    // 0x11a3a40: ldur            x16, [fp, #-0x10]
    // 0x11a3a44: str             x16, [SP]
    // 0x11a3a48: r4 = 0
    //     0x11a3a48: mov             x4, #0
    // 0x11a3a4c: ldr             x0, [SP, #0x10]
    // 0x11a3a50: r16 = 139822029843448
    //     0x11a3a50: add             x16, PP, #0x81, lsl #12  ; [pp+0x81fb0] IMM: 0x7f2ada6babf8
    //     0x11a3a54: add             x16, x16, #0xfb0
    // 0x11a3a58: ldp             lr, x5, [x16]
    // 0x11a3a5c: blr             lr
    // 0x11a3a60: LeaveFrame
    //     0x11a3a60: mov             SP, fp
    //     0x11a3a64: ldp             fp, lr, [SP], #0x10
    // 0x11a3a68: ret
    //     0x11a3a68: ret             
    // 0x11a3a6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a3a6c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a3a70: b               #0x11a39ec
  }
  [closure] void onError(dynamic, DioException, ErrorInterceptorHandler) {
    // ** addr: 0x11a3be8, size: 0x38
    // 0x11a3be8: EnterFrame
    //     0x11a3be8: stp             fp, lr, [SP, #-0x10]!
    //     0x11a3bec: mov             fp, SP
    // 0x11a3bf0: CheckStackOverflow
    //     0x11a3bf0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a3bf4: cmp             SP, x16
    //     0x11a3bf8: b.ls            #0x11a3c18
    // 0x11a3bfc: ldr             x1, [fp, #0x10]
    // 0x11a3c00: ldr             x2, [fp, #0x18]
    // 0x11a3c04: r0 = next()
    //     0x11a3c04: bl              #0x8ee274  ; [package:dio/src/dio_mixin.dart] ErrorInterceptorHandler::next
    // 0x11a3c08: r0 = Null
    //     0x11a3c08: mov             x0, NULL
    // 0x11a3c0c: LeaveFrame
    //     0x11a3c0c: mov             SP, fp
    //     0x11a3c10: ldp             fp, lr, [SP], #0x10
    // 0x11a3c14: ret
    //     0x11a3c14: ret             
    // 0x11a3c18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a3c18: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a3c1c: b               #0x11a3bfc
  }
  dynamic _invokeResponse(dynamic) {
    // ** addr: 0x11bc7d0, size: 0x24
    // 0x11bc7d0: EnterFrame
    //     0x11bc7d0: stp             fp, lr, [SP, #-0x10]!
    //     0x11bc7d4: mov             fp, SP
    // 0x11bc7d8: ldr             x2, [fp, #0x10]
    // 0x11bc7dc: r1 = Function '_invokeResponse@270263083':.
    //     0x11bc7dc: add             x1, PP, #0x82, lsl #12  ; [pp+0x82148] AnonymousClosure: (0x11bc7f4), in [package:dio/src/dio_mixin.dart] Interceptor::_invokeResponse (0x11bc834)
    //     0x11bc7e0: ldr             x1, [x1, #0x148]
    // 0x11bc7e4: r0 = AllocateClosure()
    //     0x11bc7e4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11bc7e8: LeaveFrame
    //     0x11bc7e8: mov             SP, fp
    //     0x11bc7ec: ldp             fp, lr, [SP], #0x10
    // 0x11bc7f0: ret
    //     0x11bc7f0: ret             
  }
  [closure] Object? _invokeResponse(dynamic, Response<dynamic>, ResponseInterceptorHandler) {
    // ** addr: 0x11bc7f4, size: 0x40
    // 0x11bc7f4: EnterFrame
    //     0x11bc7f4: stp             fp, lr, [SP, #-0x10]!
    //     0x11bc7f8: mov             fp, SP
    // 0x11bc7fc: ldr             x0, [fp, #0x20]
    // 0x11bc800: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x11bc800: ldur            w1, [x0, #0x17]
    // 0x11bc804: DecompressPointer r1
    //     0x11bc804: add             x1, x1, HEAP, lsl #32
    // 0x11bc808: CheckStackOverflow
    //     0x11bc808: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11bc80c: cmp             SP, x16
    //     0x11bc810: b.ls            #0x11bc82c
    // 0x11bc814: ldr             x2, [fp, #0x18]
    // 0x11bc818: ldr             x3, [fp, #0x10]
    // 0x11bc81c: r0 = _invokeResponse()
    //     0x11bc81c: bl              #0x11bc834  ; [package:dio/src/dio_mixin.dart] Interceptor::_invokeResponse
    // 0x11bc820: LeaveFrame
    //     0x11bc820: mov             SP, fp
    //     0x11bc824: ldp             fp, lr, [SP], #0x10
    // 0x11bc828: ret
    //     0x11bc828: ret             
    // 0x11bc82c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11bc82c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11bc830: b               #0x11bc814
  }
  _ _invokeResponse(/* No info */) {
    // ** addr: 0x11bc834, size: 0xac
    // 0x11bc834: EnterFrame
    //     0x11bc834: stp             fp, lr, [SP, #-0x10]!
    //     0x11bc838: mov             fp, SP
    // 0x11bc83c: AllocStack(0x28)
    //     0x11bc83c: sub             SP, SP, #0x28
    // 0x11bc840: SetupParameters(Interceptor this /* r1 => r2 */, dynamic _ /* r2 => r0, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0x11bc840: mov             x0, x2
    //     0x11bc844: stur            x2, [fp, #-8]
    //     0x11bc848: mov             x2, x1
    //     0x11bc84c: stur            x3, [fp, #-0x10]
    // 0x11bc850: CheckStackOverflow
    //     0x11bc850: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11bc854: cmp             SP, x16
    //     0x11bc858: b.ls            #0x11bc8d8
    // 0x11bc85c: r1 = LoadClassIdInstr(r2)
    //     0x11bc85c: ldur            x1, [x2, #-1]
    //     0x11bc860: ubfx            x1, x1, #0xc, #0x14
    // 0x11bc864: r17 = 4265
    //     0x11bc864: mov             x17, #0x10a9
    // 0x11bc868: cmp             x1, x17
    // 0x11bc86c: b.ne            #0x11bc880
    // 0x11bc870: r1 = Function 'onResponse':.
    //     0x11bc870: add             x1, PP, #0x82, lsl #12  ; [pp+0x82150] AnonymousClosure: (0x11bca5c), in [package:dio_cookie_manager/src/cookie_mgr.dart] CookieManager::onResponse (0x11bca9c)
    //     0x11bc874: ldr             x1, [x1, #0x150]
    // 0x11bc878: r0 = AllocateClosure()
    //     0x11bc878: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11bc87c: b               #0x11bc8a8
    // 0x11bc880: r17 = 4266
    //     0x11bc880: mov             x17, #0x10aa
    // 0x11bc884: cmp             x1, x17
    // 0x11bc888: b.ne            #0x11bc89c
    // 0x11bc88c: r1 = Function 'onResponse':.
    //     0x11bc88c: add             x1, PP, #0x82, lsl #12  ; [pp+0x82158] AnonymousClosure: (0x91d62c), in [package:simaster_ugm/utils/utils.dart] BaseNetworking::post (0x8ec50c)
    //     0x11bc890: ldr             x1, [x1, #0x158]
    // 0x11bc894: r0 = AllocateClosure()
    //     0x11bc894: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11bc898: b               #0x11bc8a8
    // 0x11bc89c: r1 = Function 'onResponse':.
    //     0x11bc89c: add             x1, PP, #0x82, lsl #12  ; [pp+0x82160] AnonymousClosure: (0x11bc8e0), in [dart:mixin_deduplication] _MixinApplication366&Interceptor&_InterceptorWrapperMixin::onResponse (0x11bc920)
    //     0x11bc8a0: ldr             x1, [x1, #0x160]
    // 0x11bc8a4: r0 = AllocateClosure()
    //     0x11bc8a4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11bc8a8: ldur            x16, [fp, #-8]
    // 0x11bc8ac: stp             x16, x0, [SP, #8]
    // 0x11bc8b0: ldur            x16, [fp, #-0x10]
    // 0x11bc8b4: str             x16, [SP]
    // 0x11bc8b8: r4 = 0
    //     0x11bc8b8: mov             x4, #0
    // 0x11bc8bc: ldr             x0, [SP, #0x10]
    // 0x11bc8c0: r30 = 139822029843448
    //     0x11bc8c0: add             x16, PP, #0x82, lsl #12  ; [pp+0x82168] IMM: 0x7f2ada6babf8
    //     0x11bc8c4: ldp             lr, x5, [x16, #0x168]
    // 0x11bc8c8: blr             lr
    // 0x11bc8cc: LeaveFrame
    //     0x11bc8cc: mov             SP, fp
    //     0x11bc8d0: ldp             fp, lr, [SP], #0x10
    // 0x11bc8d4: ret
    //     0x11bc8d4: ret             
    // 0x11bc8d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11bc8d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11bc8dc: b               #0x11bc85c
  }
  dynamic _invokeRequest(dynamic) {
    // ** addr: 0x12260d0, size: 0x24
    // 0x12260d0: EnterFrame
    //     0x12260d0: stp             fp, lr, [SP, #-0x10]!
    //     0x12260d4: mov             fp, SP
    // 0x12260d8: ldr             x2, [fp, #0x10]
    // 0x12260dc: r1 = Function '_invokeRequest@270263083':.
    //     0x12260dc: add             x1, PP, #0x82, lsl #12  ; [pp+0x82190] AnonymousClosure: (0x12260f4), in [package:dio/src/dio_mixin.dart] Interceptor::_invokeRequest (0x1226134)
    //     0x12260e0: ldr             x1, [x1, #0x190]
    // 0x12260e4: r0 = AllocateClosure()
    //     0x12260e4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x12260e8: LeaveFrame
    //     0x12260e8: mov             SP, fp
    //     0x12260ec: ldp             fp, lr, [SP], #0x10
    // 0x12260f0: ret
    //     0x12260f0: ret             
  }
  [closure] Object? _invokeRequest(dynamic, RequestOptions, RequestInterceptorHandler) {
    // ** addr: 0x12260f4, size: 0x40
    // 0x12260f4: EnterFrame
    //     0x12260f4: stp             fp, lr, [SP, #-0x10]!
    //     0x12260f8: mov             fp, SP
    // 0x12260fc: ldr             x0, [fp, #0x20]
    // 0x1226100: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x1226100: ldur            w1, [x0, #0x17]
    // 0x1226104: DecompressPointer r1
    //     0x1226104: add             x1, x1, HEAP, lsl #32
    // 0x1226108: CheckStackOverflow
    //     0x1226108: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x122610c: cmp             SP, x16
    //     0x1226110: b.ls            #0x122612c
    // 0x1226114: ldr             x2, [fp, #0x18]
    // 0x1226118: ldr             x3, [fp, #0x10]
    // 0x122611c: r0 = _invokeRequest()
    //     0x122611c: bl              #0x1226134  ; [package:dio/src/dio_mixin.dart] Interceptor::_invokeRequest
    // 0x1226120: LeaveFrame
    //     0x1226120: mov             SP, fp
    //     0x1226124: ldp             fp, lr, [SP], #0x10
    // 0x1226128: ret
    //     0x1226128: ret             
    // 0x122612c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x122612c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1226130: b               #0x1226114
  }
  _ _invokeRequest(/* No info */) {
    // ** addr: 0x1226134, size: 0xac
    // 0x1226134: EnterFrame
    //     0x1226134: stp             fp, lr, [SP, #-0x10]!
    //     0x1226138: mov             fp, SP
    // 0x122613c: AllocStack(0x28)
    //     0x122613c: sub             SP, SP, #0x28
    // 0x1226140: SetupParameters(Interceptor this /* r1 => r2 */, dynamic _ /* r2 => r0, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0x1226140: mov             x0, x2
    //     0x1226144: stur            x2, [fp, #-8]
    //     0x1226148: mov             x2, x1
    //     0x122614c: stur            x3, [fp, #-0x10]
    // 0x1226150: CheckStackOverflow
    //     0x1226150: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1226154: cmp             SP, x16
    //     0x1226158: b.ls            #0x12261d8
    // 0x122615c: r1 = LoadClassIdInstr(r2)
    //     0x122615c: ldur            x1, [x2, #-1]
    //     0x1226160: ubfx            x1, x1, #0xc, #0x14
    // 0x1226164: r17 = 4265
    //     0x1226164: mov             x17, #0x10a9
    // 0x1226168: cmp             x1, x17
    // 0x122616c: b.ne            #0x1226180
    // 0x1226170: r1 = Function 'onRequest':.
    //     0x1226170: add             x1, PP, #0x82, lsl #12  ; [pp+0x82198] AnonymousClosure: (0x122662c), in [package:dio_cookie_manager/src/cookie_mgr.dart] CookieManager::onRequest (0x122666c)
    //     0x1226174: ldr             x1, [x1, #0x198]
    // 0x1226178: r0 = AllocateClosure()
    //     0x1226178: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x122617c: b               #0x12261a8
    // 0x1226180: r17 = 4266
    //     0x1226180: mov             x17, #0x10aa
    // 0x1226184: cmp             x1, x17
    // 0x1226188: b.ne            #0x122619c
    // 0x122618c: r1 = Function 'onRequest':.
    //     0x122618c: add             x1, PP, #0x82, lsl #12  ; [pp+0x821a0] AnonymousClosure: (0x1226350), in [package:dio/src/interceptors/imply_content_type.dart] ImplyContentTypeInterceptor::onRequest (0x1226390)
    //     0x1226190: ldr             x1, [x1, #0x1a0]
    // 0x1226194: r0 = AllocateClosure()
    //     0x1226194: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1226198: b               #0x12261a8
    // 0x122619c: r1 = Function 'onRequest':.
    //     0x122619c: add             x1, PP, #0x82, lsl #12  ; [pp+0x821a8] AnonymousClosure: (0x12261e0), in [dart:mixin_deduplication] _MixinApplication366&Interceptor&_InterceptorWrapperMixin::onRequest (0x1226220)
    //     0x12261a0: ldr             x1, [x1, #0x1a8]
    // 0x12261a4: r0 = AllocateClosure()
    //     0x12261a4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x12261a8: ldur            x16, [fp, #-8]
    // 0x12261ac: stp             x16, x0, [SP, #8]
    // 0x12261b0: ldur            x16, [fp, #-0x10]
    // 0x12261b4: str             x16, [SP]
    // 0x12261b8: r4 = 0
    //     0x12261b8: mov             x4, #0
    // 0x12261bc: ldr             x0, [SP, #0x10]
    // 0x12261c0: r30 = 139822029843448
    //     0x12261c0: add             x16, PP, #0x82, lsl #12  ; [pp+0x821b0] IMM: 0x7f2ada6babf8
    //     0x12261c4: ldp             lr, x5, [x16, #0x1b0]
    // 0x12261c8: blr             lr
    // 0x12261cc: LeaveFrame
    //     0x12261cc: mov             SP, fp
    //     0x12261d0: ldp             fp, lr, [SP], #0x10
    // 0x12261d4: ret
    //     0x12261d4: ret             
    // 0x12261d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12261d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12261dc: b               #0x122615c
  }
}

// class id: 4268, size: 0x14, field offset: 0x8
class InterceptorsWrapper extends _MixinApplication366&Interceptor&_InterceptorWrapperMixin {
}

// class id: 4269, size: 0x8, field offset: 0x8
abstract class _InterceptorWrapperMixin extends Interceptor {
}

// class id: 7591, size: 0x10, field offset: 0xc
class Interceptors extends ListBase<dynamic> {

  int length(Interceptors) {
    // ** addr: 0xcce3f4, size: 0x2c
    // 0xcce3f4: ldr             x1, [SP]
    // 0xcce3f8: LoadField: r2 = r1->field_b
    //     0xcce3f8: ldur            w2, [x1, #0xb]
    // 0xcce3fc: DecompressPointer r2
    //     0xcce3fc: add             x2, x2, HEAP, lsl #32
    // 0xcce400: LoadField: r0 = r2->field_b
    //     0xcce400: ldur            w0, [x2, #0xb]
    // 0xcce404: ret
    //     0xcce404: ret             
  }
  void []=(Interceptors, int, Interceptor) {
    // ** addr: 0x7dc058, size: 0x158
    // 0x7dc058: EnterFrame
    //     0x7dc058: stp             fp, lr, [SP, #-0x10]!
    //     0x7dc05c: mov             fp, SP
    // 0x7dc060: AllocStack(0x10)
    //     0x7dc060: sub             SP, SP, #0x10
    // 0x7dc064: CheckStackOverflow
    //     0x7dc064: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7dc068: cmp             SP, x16
    //     0x7dc06c: b.ls            #0x7dc1a4
    // 0x7dc070: ldr             x0, [fp, #0x10]
    // 0x7dc074: r2 = Null
    //     0x7dc074: mov             x2, NULL
    // 0x7dc078: r1 = Null
    //     0x7dc078: mov             x1, NULL
    // 0x7dc07c: r4 = 60
    //     0x7dc07c: mov             x4, #0x3c
    // 0x7dc080: branchIfSmi(r0, 0x7dc08c)
    //     0x7dc080: tbz             w0, #0, #0x7dc08c
    // 0x7dc084: r4 = LoadClassIdInstr(r0)
    //     0x7dc084: ldur            x4, [x0, #-1]
    //     0x7dc088: ubfx            x4, x4, #0xc, #0x14
    // 0x7dc08c: r17 = -4265
    //     0x7dc08c: mov             x17, #-0x10a9
    // 0x7dc090: add             x4, x4, x17
    // 0x7dc094: cmp             x4, #3
    // 0x7dc098: b.ls            #0x7dc0b0
    // 0x7dc09c: r8 = Interceptor
    //     0x7dc09c: add             x8, PP, #0x82, lsl #12  ; [pp+0x822b8] Type: Interceptor
    //     0x7dc0a0: ldr             x8, [x8, #0x2b8]
    // 0x7dc0a4: r3 = Null
    //     0x7dc0a4: add             x3, PP, #0x82, lsl #12  ; [pp+0x822d0] Null
    //     0x7dc0a8: ldr             x3, [x3, #0x2d0]
    // 0x7dc0ac: r0 = Interceptor()
    //     0x7dc0ac: bl              #0x7dc408  ; IsType_Interceptor_Stub
    // 0x7dc0b0: ldr             x0, [fp, #0x20]
    // 0x7dc0b4: LoadField: r2 = r0->field_b
    //     0x7dc0b4: ldur            w2, [x0, #0xb]
    // 0x7dc0b8: DecompressPointer r2
    //     0x7dc0b8: add             x2, x2, HEAP, lsl #32
    // 0x7dc0bc: stur            x2, [fp, #-0x10]
    // 0x7dc0c0: LoadField: r0 = r2->field_b
    //     0x7dc0c0: ldur            w0, [x2, #0xb]
    // 0x7dc0c4: ldr             x1, [fp, #0x18]
    // 0x7dc0c8: r3 = LoadInt32Instr(r1)
    //     0x7dc0c8: sbfx            x3, x1, #1, #0x1f
    //     0x7dc0cc: tbz             w1, #0, #0x7dc0d4
    //     0x7dc0d0: ldur            x3, [x1, #7]
    // 0x7dc0d4: r4 = LoadInt32Instr(r0)
    //     0x7dc0d4: sbfx            x4, x0, #1, #0x1f
    // 0x7dc0d8: stur            x4, [fp, #-8]
    // 0x7dc0dc: cmp             x4, x3
    // 0x7dc0e0: b.ne            #0x7dc150
    // 0x7dc0e4: LoadField: r0 = r2->field_f
    //     0x7dc0e4: ldur            w0, [x2, #0xf]
    // 0x7dc0e8: DecompressPointer r0
    //     0x7dc0e8: add             x0, x0, HEAP, lsl #32
    // 0x7dc0ec: LoadField: r1 = r0->field_b
    //     0x7dc0ec: ldur            w1, [x0, #0xb]
    // 0x7dc0f0: r0 = LoadInt32Instr(r1)
    //     0x7dc0f0: sbfx            x0, x1, #1, #0x1f
    // 0x7dc0f4: cmp             x4, x0
    // 0x7dc0f8: b.ne            #0x7dc104
    // 0x7dc0fc: mov             x1, x2
    // 0x7dc100: r0 = _growToNextCapacity()
    //     0x7dc100: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x7dc104: ldur            x2, [fp, #-0x10]
    // 0x7dc108: ldur            x4, [fp, #-8]
    // 0x7dc10c: add             x5, x4, #1
    // 0x7dc110: lsl             x6, x5, #1
    // 0x7dc114: StoreField: r2->field_b = r6
    //     0x7dc114: stur            w6, [x2, #0xb]
    // 0x7dc118: LoadField: r1 = r2->field_f
    //     0x7dc118: ldur            w1, [x2, #0xf]
    // 0x7dc11c: DecompressPointer r1
    //     0x7dc11c: add             x1, x1, HEAP, lsl #32
    // 0x7dc120: ldr             x0, [fp, #0x10]
    // 0x7dc124: ArrayStore: r1[r4] = r0  ; List_4
    //     0x7dc124: add             x25, x1, x4, lsl #2
    //     0x7dc128: add             x25, x25, #0xf
    //     0x7dc12c: str             w0, [x25]
    //     0x7dc130: tbz             w0, #0, #0x7dc14c
    //     0x7dc134: ldurb           w16, [x1, #-1]
    //     0x7dc138: ldurb           w17, [x0, #-1]
    //     0x7dc13c: and             x16, x17, x16, lsr #2
    //     0x7dc140: tst             x16, HEAP, lsr #32
    //     0x7dc144: b.eq            #0x7dc14c
    //     0x7dc148: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x7dc14c: b               #0x7dc194
    // 0x7dc150: mov             x0, x4
    // 0x7dc154: mov             x1, x3
    // 0x7dc158: cmp             x1, x0
    // 0x7dc15c: b.hs            #0x7dc1ac
    // 0x7dc160: LoadField: r1 = r2->field_f
    //     0x7dc160: ldur            w1, [x2, #0xf]
    // 0x7dc164: DecompressPointer r1
    //     0x7dc164: add             x1, x1, HEAP, lsl #32
    // 0x7dc168: ldr             x0, [fp, #0x10]
    // 0x7dc16c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x7dc16c: add             x25, x1, x3, lsl #2
    //     0x7dc170: add             x25, x25, #0xf
    //     0x7dc174: str             w0, [x25]
    //     0x7dc178: tbz             w0, #0, #0x7dc194
    //     0x7dc17c: ldurb           w16, [x1, #-1]
    //     0x7dc180: ldurb           w17, [x0, #-1]
    //     0x7dc184: and             x16, x17, x16, lsr #2
    //     0x7dc188: tst             x16, HEAP, lsr #32
    //     0x7dc18c: b.eq            #0x7dc194
    //     0x7dc190: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x7dc194: r0 = Null
    //     0x7dc194: mov             x0, NULL
    // 0x7dc198: LeaveFrame
    //     0x7dc198: mov             SP, fp
    //     0x7dc19c: ldp             fp, lr, [SP], #0x10
    // 0x7dc1a0: ret
    //     0x7dc1a0: ret             
    // 0x7dc1a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7dc1a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7dc1a8: b               #0x7dc070
    // 0x7dc1ac: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x7dc1ac: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  void []=(Interceptors, int, Interceptor) {
    // ** addr: 0x7dc1c8, size: 0x1a4
    // 0x7dc1c8: EnterFrame
    //     0x7dc1c8: stp             fp, lr, [SP, #-0x10]!
    //     0x7dc1cc: mov             fp, SP
    // 0x7dc1d0: AllocStack(0x10)
    //     0x7dc1d0: sub             SP, SP, #0x10
    // 0x7dc1d4: CheckStackOverflow
    //     0x7dc1d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7dc1d8: cmp             SP, x16
    //     0x7dc1dc: b.ls            #0x7dc348
    // 0x7dc1e0: ldr             x0, [fp, #0x18]
    // 0x7dc1e4: r2 = Null
    //     0x7dc1e4: mov             x2, NULL
    // 0x7dc1e8: r1 = Null
    //     0x7dc1e8: mov             x1, NULL
    // 0x7dc1ec: branchIfSmi(r0, 0x7dc214)
    //     0x7dc1ec: tbz             w0, #0, #0x7dc214
    // 0x7dc1f0: r4 = LoadClassIdInstr(r0)
    //     0x7dc1f0: ldur            x4, [x0, #-1]
    //     0x7dc1f4: ubfx            x4, x4, #0xc, #0x14
    // 0x7dc1f8: sub             x4, x4, #0x3c
    // 0x7dc1fc: cmp             x4, #1
    // 0x7dc200: b.ls            #0x7dc214
    // 0x7dc204: r8 = int
    //     0x7dc204: ldr             x8, [PP, #0x390]  ; [pp+0x390] Type: int
    // 0x7dc208: r3 = Null
    //     0x7dc208: add             x3, PP, #0x82, lsl #12  ; [pp+0x822a8] Null
    //     0x7dc20c: ldr             x3, [x3, #0x2a8]
    // 0x7dc210: r0 = int()
    //     0x7dc210: bl              #0x13ee980  ; IsType_int_Stub
    // 0x7dc214: ldr             x0, [fp, #0x10]
    // 0x7dc218: r2 = Null
    //     0x7dc218: mov             x2, NULL
    // 0x7dc21c: r1 = Null
    //     0x7dc21c: mov             x1, NULL
    // 0x7dc220: r4 = 60
    //     0x7dc220: mov             x4, #0x3c
    // 0x7dc224: branchIfSmi(r0, 0x7dc230)
    //     0x7dc224: tbz             w0, #0, #0x7dc230
    // 0x7dc228: r4 = LoadClassIdInstr(r0)
    //     0x7dc228: ldur            x4, [x0, #-1]
    //     0x7dc22c: ubfx            x4, x4, #0xc, #0x14
    // 0x7dc230: r17 = -4265
    //     0x7dc230: mov             x17, #-0x10a9
    // 0x7dc234: add             x4, x4, x17
    // 0x7dc238: cmp             x4, #3
    // 0x7dc23c: b.ls            #0x7dc254
    // 0x7dc240: r8 = Interceptor
    //     0x7dc240: add             x8, PP, #0x82, lsl #12  ; [pp+0x822b8] Type: Interceptor
    //     0x7dc244: ldr             x8, [x8, #0x2b8]
    // 0x7dc248: r3 = Null
    //     0x7dc248: add             x3, PP, #0x82, lsl #12  ; [pp+0x822c0] Null
    //     0x7dc24c: ldr             x3, [x3, #0x2c0]
    // 0x7dc250: r0 = Interceptor()
    //     0x7dc250: bl              #0x7dc408  ; IsType_Interceptor_Stub
    // 0x7dc254: ldr             x0, [fp, #0x20]
    // 0x7dc258: LoadField: r2 = r0->field_b
    //     0x7dc258: ldur            w2, [x0, #0xb]
    // 0x7dc25c: DecompressPointer r2
    //     0x7dc25c: add             x2, x2, HEAP, lsl #32
    // 0x7dc260: stur            x2, [fp, #-0x10]
    // 0x7dc264: LoadField: r0 = r2->field_b
    //     0x7dc264: ldur            w0, [x2, #0xb]
    // 0x7dc268: ldr             x1, [fp, #0x18]
    // 0x7dc26c: r3 = LoadInt32Instr(r1)
    //     0x7dc26c: sbfx            x3, x1, #1, #0x1f
    //     0x7dc270: tbz             w1, #0, #0x7dc278
    //     0x7dc274: ldur            x3, [x1, #7]
    // 0x7dc278: r4 = LoadInt32Instr(r0)
    //     0x7dc278: sbfx            x4, x0, #1, #0x1f
    // 0x7dc27c: stur            x4, [fp, #-8]
    // 0x7dc280: cmp             x4, x3
    // 0x7dc284: b.ne            #0x7dc2f4
    // 0x7dc288: LoadField: r0 = r2->field_f
    //     0x7dc288: ldur            w0, [x2, #0xf]
    // 0x7dc28c: DecompressPointer r0
    //     0x7dc28c: add             x0, x0, HEAP, lsl #32
    // 0x7dc290: LoadField: r1 = r0->field_b
    //     0x7dc290: ldur            w1, [x0, #0xb]
    // 0x7dc294: r0 = LoadInt32Instr(r1)
    //     0x7dc294: sbfx            x0, x1, #1, #0x1f
    // 0x7dc298: cmp             x4, x0
    // 0x7dc29c: b.ne            #0x7dc2a8
    // 0x7dc2a0: mov             x1, x2
    // 0x7dc2a4: r0 = _growToNextCapacity()
    //     0x7dc2a4: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x7dc2a8: ldur            x2, [fp, #-0x10]
    // 0x7dc2ac: ldur            x4, [fp, #-8]
    // 0x7dc2b0: add             x5, x4, #1
    // 0x7dc2b4: lsl             x6, x5, #1
    // 0x7dc2b8: StoreField: r2->field_b = r6
    //     0x7dc2b8: stur            w6, [x2, #0xb]
    // 0x7dc2bc: LoadField: r1 = r2->field_f
    //     0x7dc2bc: ldur            w1, [x2, #0xf]
    // 0x7dc2c0: DecompressPointer r1
    //     0x7dc2c0: add             x1, x1, HEAP, lsl #32
    // 0x7dc2c4: ldr             x0, [fp, #0x10]
    // 0x7dc2c8: ArrayStore: r1[r4] = r0  ; List_4
    //     0x7dc2c8: add             x25, x1, x4, lsl #2
    //     0x7dc2cc: add             x25, x25, #0xf
    //     0x7dc2d0: str             w0, [x25]
    //     0x7dc2d4: tbz             w0, #0, #0x7dc2f0
    //     0x7dc2d8: ldurb           w16, [x1, #-1]
    //     0x7dc2dc: ldurb           w17, [x0, #-1]
    //     0x7dc2e0: and             x16, x17, x16, lsr #2
    //     0x7dc2e4: tst             x16, HEAP, lsr #32
    //     0x7dc2e8: b.eq            #0x7dc2f0
    //     0x7dc2ec: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x7dc2f0: b               #0x7dc338
    // 0x7dc2f4: mov             x0, x4
    // 0x7dc2f8: mov             x1, x3
    // 0x7dc2fc: cmp             x1, x0
    // 0x7dc300: b.hs            #0x7dc350
    // 0x7dc304: LoadField: r1 = r2->field_f
    //     0x7dc304: ldur            w1, [x2, #0xf]
    // 0x7dc308: DecompressPointer r1
    //     0x7dc308: add             x1, x1, HEAP, lsl #32
    // 0x7dc30c: ldr             x0, [fp, #0x10]
    // 0x7dc310: ArrayStore: r1[r3] = r0  ; List_4
    //     0x7dc310: add             x25, x1, x3, lsl #2
    //     0x7dc314: add             x25, x25, #0xf
    //     0x7dc318: str             w0, [x25]
    //     0x7dc31c: tbz             w0, #0, #0x7dc338
    //     0x7dc320: ldurb           w16, [x1, #-1]
    //     0x7dc324: ldurb           w17, [x0, #-1]
    //     0x7dc328: and             x16, x17, x16, lsr #2
    //     0x7dc32c: tst             x16, HEAP, lsr #32
    //     0x7dc330: b.eq            #0x7dc338
    //     0x7dc334: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x7dc338: r0 = Null
    //     0x7dc338: mov             x0, NULL
    // 0x7dc33c: LeaveFrame
    //     0x7dc33c: mov             SP, fp
    //     0x7dc340: ldp             fp, lr, [SP], #0x10
    // 0x7dc344: ret
    //     0x7dc344: ret             
    // 0x7dc348: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7dc348: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7dc34c: b               #0x7dc1e0
    // 0x7dc350: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x7dc350: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  Interceptor [](Interceptors, int) {
    // ** addr: 0x7dc36c, size: 0xb4
    // 0x7dc36c: EnterFrame
    //     0x7dc36c: stp             fp, lr, [SP, #-0x10]!
    //     0x7dc370: mov             fp, SP
    // 0x7dc374: ldr             x0, [fp, #0x10]
    // 0x7dc378: r2 = Null
    //     0x7dc378: mov             x2, NULL
    // 0x7dc37c: r1 = Null
    //     0x7dc37c: mov             x1, NULL
    // 0x7dc380: branchIfSmi(r0, 0x7dc3a8)
    //     0x7dc380: tbz             w0, #0, #0x7dc3a8
    // 0x7dc384: r4 = LoadClassIdInstr(r0)
    //     0x7dc384: ldur            x4, [x0, #-1]
    //     0x7dc388: ubfx            x4, x4, #0xc, #0x14
    // 0x7dc38c: sub             x4, x4, #0x3c
    // 0x7dc390: cmp             x4, #1
    // 0x7dc394: b.ls            #0x7dc3a8
    // 0x7dc398: r8 = int
    //     0x7dc398: ldr             x8, [PP, #0x390]  ; [pp+0x390] Type: int
    // 0x7dc39c: r3 = Null
    //     0x7dc39c: add             x3, PP, #0x82, lsl #12  ; [pp+0x822e0] Null
    //     0x7dc3a0: ldr             x3, [x3, #0x2e0]
    // 0x7dc3a4: r0 = int()
    //     0x7dc3a4: bl              #0x13ee980  ; IsType_int_Stub
    // 0x7dc3a8: ldr             x2, [fp, #0x18]
    // 0x7dc3ac: LoadField: r3 = r2->field_b
    //     0x7dc3ac: ldur            w3, [x2, #0xb]
    // 0x7dc3b0: DecompressPointer r3
    //     0x7dc3b0: add             x3, x3, HEAP, lsl #32
    // 0x7dc3b4: LoadField: r2 = r3->field_b
    //     0x7dc3b4: ldur            w2, [x3, #0xb]
    // 0x7dc3b8: ldr             x4, [fp, #0x10]
    // 0x7dc3bc: r5 = LoadInt32Instr(r4)
    //     0x7dc3bc: sbfx            x5, x4, #1, #0x1f
    //     0x7dc3c0: tbz             w4, #0, #0x7dc3c8
    //     0x7dc3c4: ldur            x5, [x4, #7]
    // 0x7dc3c8: r0 = LoadInt32Instr(r2)
    //     0x7dc3c8: sbfx            x0, x2, #1, #0x1f
    // 0x7dc3cc: mov             x1, x5
    // 0x7dc3d0: cmp             x1, x0
    // 0x7dc3d4: b.hs            #0x7dc400
    // 0x7dc3d8: LoadField: r1 = r3->field_f
    //     0x7dc3d8: ldur            w1, [x3, #0xf]
    // 0x7dc3dc: DecompressPointer r1
    //     0x7dc3dc: add             x1, x1, HEAP, lsl #32
    // 0x7dc3e0: ArrayLoad: r0 = r1[r5]  ; Unknown_4
    //     0x7dc3e0: add             x16, x1, x5, lsl #2
    //     0x7dc3e4: ldur            w0, [x16, #0xf]
    // 0x7dc3e8: DecompressPointer r0
    //     0x7dc3e8: add             x0, x0, HEAP, lsl #32
    // 0x7dc3ec: cmp             w0, NULL
    // 0x7dc3f0: b.eq            #0x7dc404
    // 0x7dc3f4: LeaveFrame
    //     0x7dc3f4: mov             SP, fp
    //     0x7dc3f8: ldp             fp, lr, [SP], #0x10
    // 0x7dc3fc: ret
    //     0x7dc3fc: ret             
    // 0x7dc400: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x7dc400: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x7dc404: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7dc404: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ Interceptors(/* No info */) {
    // ** addr: 0x91d194, size: 0xa8
    // 0x91d194: EnterFrame
    //     0x91d194: stp             fp, lr, [SP, #-0x10]!
    //     0x91d198: mov             fp, SP
    // 0x91d19c: AllocStack(0x10)
    //     0x91d19c: sub             SP, SP, #0x10
    // 0x91d1a0: r0 = 2
    //     0x91d1a0: mov             x0, #2
    // 0x91d1a4: mov             x3, x1
    // 0x91d1a8: stur            x1, [fp, #-8]
    // 0x91d1ac: CheckStackOverflow
    //     0x91d1ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91d1b0: cmp             SP, x16
    //     0x91d1b4: b.ls            #0x91d234
    // 0x91d1b8: mov             x2, x0
    // 0x91d1bc: r1 = Null
    //     0x91d1bc: mov             x1, NULL
    // 0x91d1c0: r0 = AllocateArray()
    //     0x91d1c0: bl              #0x13df928  ; AllocateArrayStub
    // 0x91d1c4: stur            x0, [fp, #-0x10]
    // 0x91d1c8: r16 = Instance_ImplyContentTypeInterceptor
    //     0x91d1c8: add             x16, PP, #0x17, lsl #12  ; [pp+0x17348] Obj!ImplyContentTypeInterceptor@12aa381
    //     0x91d1cc: ldr             x16, [x16, #0x348]
    // 0x91d1d0: StoreField: r0->field_f = r16
    //     0x91d1d0: stur            w16, [x0, #0xf]
    // 0x91d1d4: r1 = <Interceptor?>
    //     0x91d1d4: add             x1, PP, #0x17, lsl #12  ; [pp+0x17350] TypeArguments: <Interceptor?>
    //     0x91d1d8: ldr             x1, [x1, #0x350]
    // 0x91d1dc: r0 = AllocateGrowableArray()
    //     0x91d1dc: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x91d1e0: mov             x1, x0
    // 0x91d1e4: ldur            x0, [fp, #-0x10]
    // 0x91d1e8: StoreField: r1->field_f = r0
    //     0x91d1e8: stur            w0, [x1, #0xf]
    // 0x91d1ec: r0 = 2
    //     0x91d1ec: mov             x0, #2
    // 0x91d1f0: StoreField: r1->field_b = r0
    //     0x91d1f0: stur            w0, [x1, #0xb]
    // 0x91d1f4: mov             x0, x1
    // 0x91d1f8: ldur            x1, [fp, #-8]
    // 0x91d1fc: StoreField: r1->field_b = r0
    //     0x91d1fc: stur            w0, [x1, #0xb]
    //     0x91d200: ldurb           w16, [x1, #-1]
    //     0x91d204: ldurb           w17, [x0, #-1]
    //     0x91d208: and             x16, x17, x16, lsr #2
    //     0x91d20c: tst             x16, HEAP, lsr #32
    //     0x91d210: b.eq            #0x91d218
    //     0x91d214: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x91d218: r2 = const []
    //     0x91d218: add             x2, PP, #0x17, lsl #12  ; [pp+0x17358] List<Interceptor>(0)
    //     0x91d21c: ldr             x2, [x2, #0x358]
    // 0x91d220: r0 = addAll()
    //     0x91d220: bl              #0x8d2ec0  ; [dart:collection] ListBase::addAll
    // 0x91d224: r0 = Null
    //     0x91d224: mov             x0, NULL
    // 0x91d228: LeaveFrame
    //     0x91d228: mov             SP, fp
    //     0x91d22c: ldp             fp, lr, [SP], #0x10
    // 0x91d230: ret
    //     0x91d230: ret             
    // 0x91d234: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91d234: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x91d238: b               #0x91d1b8
  }
  _ clear(/* No info */) {
    // ** addr: 0xa06fc4, size: 0x58
    // 0xa06fc4: EnterFrame
    //     0xa06fc4: stp             fp, lr, [SP, #-0x10]!
    //     0xa06fc8: mov             fp, SP
    // 0xa06fcc: AllocStack(0x8)
    //     0xa06fcc: sub             SP, SP, #8
    // 0xa06fd0: CheckStackOverflow
    //     0xa06fd0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xa06fd4: cmp             SP, x16
    //     0xa06fd8: b.ls            #0xa07014
    // 0xa06fdc: LoadField: r0 = r1->field_b
    //     0xa06fdc: ldur            w0, [x1, #0xb]
    // 0xa06fe0: DecompressPointer r0
    //     0xa06fe0: add             x0, x0, HEAP, lsl #32
    // 0xa06fe4: stur            x0, [fp, #-8]
    // 0xa06fe8: r1 = Function '<anonymous closure>':.
    //     0xa06fe8: add             x1, PP, #0xac, lsl #12  ; [pp+0xacd70] AnonymousClosure: (0xa0701c), in [package:dio/src/dio_mixin.dart] Interceptors::clear (0xa06fc4)
    //     0xa06fec: ldr             x1, [x1, #0xd70]
    // 0xa06ff0: r2 = Null
    //     0xa06ff0: mov             x2, NULL
    // 0xa06ff4: r0 = AllocateClosure()
    //     0xa06ff4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xa06ff8: ldur            x1, [fp, #-8]
    // 0xa06ffc: mov             x2, x0
    // 0xa07000: r0 = removeWhere()
    //     0xa07000: bl              #0x843124  ; [dart:collection] ListBase::removeWhere
    // 0xa07004: r0 = Null
    //     0xa07004: mov             x0, NULL
    // 0xa07008: LeaveFrame
    //     0xa07008: mov             SP, fp
    //     0xa0700c: ldp             fp, lr, [SP], #0x10
    // 0xa07010: ret
    //     0xa07010: ret             
    // 0xa07014: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa07014: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa07018: b               #0xa06fdc
  }
  [closure] bool <anonymous closure>(dynamic, Interceptor?) {
    // ** addr: 0xa0701c, size: 0x24
    // 0xa0701c: ldr             x1, [SP]
    // 0xa07020: r2 = LoadClassIdInstr(r1)
    //     0xa07020: ldur            x2, [x1, #-1]
    //     0xa07024: ubfx            x2, x2, #0xc, #0x14
    // 0xa07028: r17 = 4266
    //     0xa07028: mov             x17, #0x10aa
    // 0xa0702c: cmp             x2, x17
    // 0xa07030: r16 = true
    //     0xa07030: add             x16, NULL, #0x20  ; true
    // 0xa07034: r17 = false
    //     0xa07034: add             x17, NULL, #0x30  ; false
    // 0xa07038: csel            x0, x16, x17, ne
    // 0xa0703c: ret
    //     0xa0703c: ret             
  }
  Interceptor [](Interceptors, int) {
    // ** addr: 0x12884b8, size: 0x68
    // 0x12884b8: EnterFrame
    //     0x12884b8: stp             fp, lr, [SP, #-0x10]!
    //     0x12884bc: mov             fp, SP
    // 0x12884c0: ldr             x2, [fp, #0x18]
    // 0x12884c4: LoadField: r3 = r2->field_b
    //     0x12884c4: ldur            w3, [x2, #0xb]
    // 0x12884c8: DecompressPointer r3
    //     0x12884c8: add             x3, x3, HEAP, lsl #32
    // 0x12884cc: LoadField: r2 = r3->field_b
    //     0x12884cc: ldur            w2, [x3, #0xb]
    // 0x12884d0: ldr             x4, [fp, #0x10]
    // 0x12884d4: r5 = LoadInt32Instr(r4)
    //     0x12884d4: sbfx            x5, x4, #1, #0x1f
    //     0x12884d8: tbz             w4, #0, #0x12884e0
    //     0x12884dc: ldur            x5, [x4, #7]
    // 0x12884e0: r0 = LoadInt32Instr(r2)
    //     0x12884e0: sbfx            x0, x2, #1, #0x1f
    // 0x12884e4: mov             x1, x5
    // 0x12884e8: cmp             x1, x0
    // 0x12884ec: b.hs            #0x1288518
    // 0x12884f0: LoadField: r1 = r3->field_f
    //     0x12884f0: ldur            w1, [x3, #0xf]
    // 0x12884f4: DecompressPointer r1
    //     0x12884f4: add             x1, x1, HEAP, lsl #32
    // 0x12884f8: ArrayLoad: r0 = r1[r5]  ; Unknown_4
    //     0x12884f8: add             x16, x1, x5, lsl #2
    //     0x12884fc: ldur            w0, [x16, #0xf]
    // 0x1288500: DecompressPointer r0
    //     0x1288500: add             x0, x0, HEAP, lsl #32
    // 0x1288504: cmp             w0, NULL
    // 0x1288508: b.eq            #0x128851c
    // 0x128850c: LeaveFrame
    //     0x128850c: mov             SP, fp
    //     0x1288510: ldp             fp, lr, [SP], #0x10
    // 0x1288514: ret
    //     0x1288514: ret             
    // 0x1288518: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x1288518: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x128851c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x128851c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 8335, size: 0x14, field offset: 0x14
enum InterceptorResultType extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11a9220, size: 0x64
    // 0x11a9220: EnterFrame
    //     0x11a9220: stp             fp, lr, [SP, #-0x10]!
    //     0x11a9224: mov             fp, SP
    // 0x11a9228: AllocStack(0x10)
    //     0x11a9228: sub             SP, SP, #0x10
    // 0x11a922c: SetupParameters(InterceptorResultType this /* r1 => r0, fp-0x8 */)
    //     0x11a922c: mov             x0, x1
    //     0x11a9230: stur            x1, [fp, #-8]
    // 0x11a9234: CheckStackOverflow
    //     0x11a9234: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a9238: cmp             SP, x16
    //     0x11a923c: b.ls            #0x11a927c
    // 0x11a9240: r1 = Null
    //     0x11a9240: mov             x1, NULL
    // 0x11a9244: r2 = 4
    //     0x11a9244: mov             x2, #4
    // 0x11a9248: r0 = AllocateArray()
    //     0x11a9248: bl              #0x13df928  ; AllocateArrayStub
    // 0x11a924c: r16 = "InterceptorResultType."
    //     0x11a924c: add             x16, PP, #0x81, lsl #12  ; [pp+0x81ef0] "InterceptorResultType."
    //     0x11a9250: ldr             x16, [x16, #0xef0]
    // 0x11a9254: StoreField: r0->field_f = r16
    //     0x11a9254: stur            w16, [x0, #0xf]
    // 0x11a9258: ldur            x1, [fp, #-8]
    // 0x11a925c: LoadField: r2 = r1->field_f
    //     0x11a925c: ldur            w2, [x1, #0xf]
    // 0x11a9260: DecompressPointer r2
    //     0x11a9260: add             x2, x2, HEAP, lsl #32
    // 0x11a9264: StoreField: r0->field_13 = r2
    //     0x11a9264: stur            w2, [x0, #0x13]
    // 0x11a9268: str             x0, [SP]
    // 0x11a926c: r0 = _interpolate()
    //     0x11a926c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11a9270: LeaveFrame
    //     0x11a9270: mov             SP, fp
    //     0x11a9274: ldp             fp, lr, [SP], #0x10
    // 0x11a9278: ret
    //     0x11a9278: ret             
    // 0x11a927c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a927c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a9280: b               #0x11a9240
  }
}
