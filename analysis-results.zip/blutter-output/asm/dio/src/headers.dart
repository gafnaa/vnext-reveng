// lib: , url: package:dio/src/headers.dart

// class id: 1048704, size: 0x8
class :: {
}

// class id: 3403, size: 0xc, field offset: 0x8
class Headers extends Object {

  dynamic value(dynamic) {
    // ** addr: 0x8e9e6c, size: 0x3c
    // 0x8e9e6c: EnterFrame
    //     0x8e9e6c: stp             fp, lr, [SP, #-0x10]!
    //     0x8e9e70: mov             fp, SP
    // 0x8e9e74: ldr             x2, [fp, #0x10]
    // 0x8e9e78: r1 = Function 'value':.
    //     0x8e9e78: add             x1, PP, #0x81, lsl #12  ; [pp+0x81518] AnonymousClosure: (0x8e9e90), in [package:dio/src/headers.dart] Headers::value (0x8e9ecc)
    //     0x8e9e7c: ldr             x1, [x1, #0x518]
    // 0x8e9e80: r0 = AllocateClosure()
    //     0x8e9e80: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8e9e84: LeaveFrame
    //     0x8e9e84: mov             SP, fp
    //     0x8e9e88: ldp             fp, lr, [SP], #0x10
    // 0x8e9e8c: ret
    //     0x8e9e8c: ret             
  }
  void forEach(Headers, (dynamic, String, List<String>) => void) {
    // ** addr: 0x8e9b6c, size: 0x6c
    // 0x8e9b6c: EnterFrame
    //     0x8e9b6c: stp             fp, lr, [SP, #-0x10]!
    //     0x8e9b70: mov             fp, SP
    // 0x8e9b74: CheckStackOverflow
    //     0x8e9b74: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8e9b78: cmp             SP, x16
    //     0x8e9b7c: b.ls            #0x8e9bb8
    // 0x8e9b80: ldr             x0, [fp, #0x10]
    // 0x8e9b84: r2 = Null
    //     0x8e9b84: mov             x2, NULL
    // 0x8e9b88: r1 = Null
    //     0x8e9b88: mov             x1, NULL
    // 0x8e9b8c: r8 = (dynamic this, String, List<String>) => void?
    //     0x8e9b8c: add             x8, PP, #0x81, lsl #12  ; [pp+0x814f0] FunctionType: (dynamic this, String, List<String>) => void?
    //     0x8e9b90: ldr             x8, [x8, #0x4f0]
    // 0x8e9b94: r3 = Null
    //     0x8e9b94: add             x3, PP, #0x81, lsl #12  ; [pp+0x814f8] Null
    //     0x8e9b98: ldr             x3, [x3, #0x4f8]
    // 0x8e9b9c: r0 = DefaultTypeTest()
    //     0x8e9b9c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x8e9ba0: ldr             x1, [fp, #0x18]
    // 0x8e9ba4: ldr             x2, [fp, #0x10]
    // 0x8e9ba8: r0 = forEach()
    //     0x8e9ba8: bl              #0x8e9bc0  ; [package:dio/src/headers.dart] Headers::forEach
    // 0x8e9bac: LeaveFrame
    //     0x8e9bac: mov             SP, fp
    //     0x8e9bb0: ldp             fp, lr, [SP], #0x10
    // 0x8e9bb4: ret
    //     0x8e9bb4: ret             
    // 0x8e9bb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8e9bb8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8e9bbc: b               #0x8e9b80
  }
  void forEach(Headers, (dynamic, String, List<String>) => void) {
    // ** addr: 0x8e9bc0, size: 0x144
    // 0x8e9bc0: EnterFrame
    //     0x8e9bc0: stp             fp, lr, [SP, #-0x10]!
    //     0x8e9bc4: mov             fp, SP
    // 0x8e9bc8: AllocStack(0x40)
    //     0x8e9bc8: sub             SP, SP, #0x40
    // 0x8e9bcc: SetupParameters(dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x8e9bcc: stur            x2, [fp, #-0x10]
    // 0x8e9bd0: CheckStackOverflow
    //     0x8e9bd0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8e9bd4: cmp             SP, x16
    //     0x8e9bd8: b.ls            #0x8e9cf0
    // 0x8e9bdc: LoadField: r3 = r1->field_7
    //     0x8e9bdc: ldur            w3, [x1, #7]
    // 0x8e9be0: DecompressPointer r3
    //     0x8e9be0: add             x3, x3, HEAP, lsl #32
    // 0x8e9be4: stur            x3, [fp, #-8]
    // 0x8e9be8: r0 = LoadClassIdInstr(r3)
    //     0x8e9be8: ldur            x0, [x3, #-1]
    //     0x8e9bec: ubfx            x0, x0, #0xc, #0x14
    // 0x8e9bf0: mov             x1, x3
    // 0x8e9bf4: r0 = GDT[cid_x0 + 0x44d]()
    //     0x8e9bf4: add             lr, x0, #0x44d
    //     0x8e9bf8: ldr             lr, [x21, lr, lsl #3]
    //     0x8e9bfc: blr             lr
    // 0x8e9c00: mov             x1, x0
    // 0x8e9c04: r0 = iterator()
    //     0x8e9c04: bl              #0xb09a64  ; [dart:_compact_hash] _CompactKeysIterable::iterator
    // 0x8e9c08: stur            x0, [fp, #-0x20]
    // 0x8e9c0c: LoadField: r2 = r0->field_7
    //     0x8e9c0c: ldur            w2, [x0, #7]
    // 0x8e9c10: DecompressPointer r2
    //     0x8e9c10: add             x2, x2, HEAP, lsl #32
    // 0x8e9c14: stur            x2, [fp, #-0x18]
    // 0x8e9c18: ldur            x3, [fp, #-8]
    // 0x8e9c1c: CheckStackOverflow
    //     0x8e9c1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8e9c20: cmp             SP, x16
    //     0x8e9c24: b.ls            #0x8e9cf8
    // 0x8e9c28: mov             x1, x0
    // 0x8e9c2c: r0 = moveNext()
    //     0x8e9c2c: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0x8e9c30: tbnz            w0, #4, #0x8e9ce0
    // 0x8e9c34: ldur            x3, [fp, #-0x20]
    // 0x8e9c38: LoadField: r4 = r3->field_33
    //     0x8e9c38: ldur            w4, [x3, #0x33]
    // 0x8e9c3c: DecompressPointer r4
    //     0x8e9c3c: add             x4, x4, HEAP, lsl #32
    // 0x8e9c40: stur            x4, [fp, #-0x28]
    // 0x8e9c44: cmp             w4, NULL
    // 0x8e9c48: b.ne            #0x8e9c7c
    // 0x8e9c4c: mov             x0, x4
    // 0x8e9c50: ldur            x2, [fp, #-0x18]
    // 0x8e9c54: r1 = Null
    //     0x8e9c54: mov             x1, NULL
    // 0x8e9c58: cmp             w2, NULL
    // 0x8e9c5c: b.eq            #0x8e9c7c
    // 0x8e9c60: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x8e9c60: ldur            w4, [x2, #0x17]
    // 0x8e9c64: DecompressPointer r4
    //     0x8e9c64: add             x4, x4, HEAP, lsl #32
    // 0x8e9c68: r8 = X0
    //     0x8e9c68: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x8e9c6c: LoadField: r9 = r4->field_7
    //     0x8e9c6c: ldur            x9, [x4, #7]
    // 0x8e9c70: r3 = Null
    //     0x8e9c70: add             x3, PP, #0x81, lsl #12  ; [pp+0x81508] Null
    //     0x8e9c74: ldr             x3, [x3, #0x508]
    // 0x8e9c78: blr             x9
    // 0x8e9c7c: ldur            x0, [fp, #-8]
    // 0x8e9c80: ldur            x1, [fp, #-0x28]
    // 0x8e9c84: r0 = trim()
    //     0x8e9c84: bl              #0x808ff4  ; [dart:core] _StringBase::trim
    // 0x8e9c88: ldur            x3, [fp, #-8]
    // 0x8e9c8c: r1 = LoadClassIdInstr(r3)
    //     0x8e9c8c: ldur            x1, [x3, #-1]
    //     0x8e9c90: ubfx            x1, x1, #0xc, #0x14
    // 0x8e9c94: mov             x2, x0
    // 0x8e9c98: mov             x0, x1
    // 0x8e9c9c: mov             x1, x3
    // 0x8e9ca0: r0 = GDT[cid_x0 + -0xd48]()
    //     0x8e9ca0: sub             lr, x0, #0xd48
    //     0x8e9ca4: ldr             lr, [x21, lr, lsl #3]
    //     0x8e9ca8: blr             lr
    // 0x8e9cac: cmp             w0, NULL
    // 0x8e9cb0: b.eq            #0x8e9d00
    // 0x8e9cb4: ldur            x16, [fp, #-0x10]
    // 0x8e9cb8: ldur            lr, [fp, #-0x28]
    // 0x8e9cbc: stp             lr, x16, [SP, #8]
    // 0x8e9cc0: str             x0, [SP]
    // 0x8e9cc4: ldur            x0, [fp, #-0x10]
    // 0x8e9cc8: ClosureCall
    //     0x8e9cc8: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x8e9ccc: ldur            x2, [x0, #0x1f]
    //     0x8e9cd0: blr             x2
    // 0x8e9cd4: ldur            x0, [fp, #-0x20]
    // 0x8e9cd8: ldur            x2, [fp, #-0x18]
    // 0x8e9cdc: b               #0x8e9c18
    // 0x8e9ce0: r0 = Null
    //     0x8e9ce0: mov             x0, NULL
    // 0x8e9ce4: LeaveFrame
    //     0x8e9ce4: mov             SP, fp
    //     0x8e9ce8: ldp             fp, lr, [SP], #0x10
    // 0x8e9cec: ret
    //     0x8e9cec: ret             
    // 0x8e9cf0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8e9cf0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8e9cf4: b               #0x8e9bdc
    // 0x8e9cf8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8e9cf8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8e9cfc: b               #0x8e9c28
    // 0x8e9d00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8e9d00: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  bool dyn:get:isEmpty(Headers) {
    // ** addr: 0x8e9d1c, size: 0x48
    // 0x8e9d1c: EnterFrame
    //     0x8e9d1c: stp             fp, lr, [SP, #-0x10]!
    //     0x8e9d20: mov             fp, SP
    // 0x8e9d24: CheckStackOverflow
    //     0x8e9d24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8e9d28: cmp             SP, x16
    //     0x8e9d2c: b.ls            #0x8e9d44
    // 0x8e9d30: ldr             x1, [fp, #0x10]
    // 0x8e9d34: r0 = isEmpty()
    //     0x8e9d34: bl              #0x8e9d4c  ; [package:dio/src/headers.dart] Headers::isEmpty
    // 0x8e9d38: LeaveFrame
    //     0x8e9d38: mov             SP, fp
    //     0x8e9d3c: ldp             fp, lr, [SP], #0x10
    // 0x8e9d40: ret
    //     0x8e9d40: ret             
    // 0x8e9d44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8e9d44: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8e9d48: b               #0x8e9d30
  }
  bool isEmpty(Headers) {
    // ** addr: 0x8e9d4c, size: 0x50
    // 0x8e9d4c: EnterFrame
    //     0x8e9d4c: stp             fp, lr, [SP, #-0x10]!
    //     0x8e9d50: mov             fp, SP
    // 0x8e9d54: CheckStackOverflow
    //     0x8e9d54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8e9d58: cmp             SP, x16
    //     0x8e9d5c: b.ls            #0x8e9d94
    // 0x8e9d60: LoadField: r0 = r1->field_7
    //     0x8e9d60: ldur            w0, [x1, #7]
    // 0x8e9d64: DecompressPointer r0
    //     0x8e9d64: add             x0, x0, HEAP, lsl #32
    // 0x8e9d68: r1 = LoadClassIdInstr(r0)
    //     0x8e9d68: ldur            x1, [x0, #-1]
    //     0x8e9d6c: ubfx            x1, x1, #0xc, #0x14
    // 0x8e9d70: mov             x16, x0
    // 0x8e9d74: mov             x0, x1
    // 0x8e9d78: mov             x1, x16
    // 0x8e9d7c: r0 = GDT[cid_x0 + 0x687]()
    //     0x8e9d7c: add             lr, x0, #0x687
    //     0x8e9d80: ldr             lr, [x21, lr, lsl #3]
    //     0x8e9d84: blr             lr
    // 0x8e9d88: LeaveFrame
    //     0x8e9d88: mov             SP, fp
    //     0x8e9d8c: ldp             fp, lr, [SP], #0x10
    // 0x8e9d90: ret
    //     0x8e9d90: ret             
    // 0x8e9d94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8e9d94: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8e9d98: b               #0x8e9d60
  }
  List<String>? [](Headers, String) {
    // ** addr: 0x8e9db4, size: 0xb8
    // 0x8e9db4: EnterFrame
    //     0x8e9db4: stp             fp, lr, [SP, #-0x10]!
    //     0x8e9db8: mov             fp, SP
    // 0x8e9dbc: AllocStack(0x8)
    //     0x8e9dbc: sub             SP, SP, #8
    // 0x8e9dc0: CheckStackOverflow
    //     0x8e9dc0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8e9dc4: cmp             SP, x16
    //     0x8e9dc8: b.ls            #0x8e9e4c
    // 0x8e9dcc: ldr             x0, [fp, #0x10]
    // 0x8e9dd0: r2 = Null
    //     0x8e9dd0: mov             x2, NULL
    // 0x8e9dd4: r1 = Null
    //     0x8e9dd4: mov             x1, NULL
    // 0x8e9dd8: r4 = 60
    //     0x8e9dd8: mov             x4, #0x3c
    // 0x8e9ddc: branchIfSmi(r0, 0x8e9de8)
    //     0x8e9ddc: tbz             w0, #0, #0x8e9de8
    // 0x8e9de0: r4 = LoadClassIdInstr(r0)
    //     0x8e9de0: ldur            x4, [x0, #-1]
    //     0x8e9de4: ubfx            x4, x4, #0xc, #0x14
    // 0x8e9de8: sub             x4, x4, #0x5e
    // 0x8e9dec: cmp             x4, #1
    // 0x8e9df0: b.ls            #0x8e9e04
    // 0x8e9df4: r8 = String
    //     0x8e9df4: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x8e9df8: r3 = Null
    //     0x8e9df8: add             x3, PP, #0x81, lsl #12  ; [pp+0x81528] Null
    //     0x8e9dfc: ldr             x3, [x3, #0x528]
    // 0x8e9e00: r0 = String()
    //     0x8e9e00: bl              #0x13ee320  ; IsType_String_Stub
    // 0x8e9e04: ldr             x0, [fp, #0x18]
    // 0x8e9e08: LoadField: r2 = r0->field_7
    //     0x8e9e08: ldur            w2, [x0, #7]
    // 0x8e9e0c: DecompressPointer r2
    //     0x8e9e0c: add             x2, x2, HEAP, lsl #32
    // 0x8e9e10: ldr             x1, [fp, #0x10]
    // 0x8e9e14: stur            x2, [fp, #-8]
    // 0x8e9e18: r0 = trim()
    //     0x8e9e18: bl              #0x808ff4  ; [dart:core] _StringBase::trim
    // 0x8e9e1c: ldur            x1, [fp, #-8]
    // 0x8e9e20: r2 = LoadClassIdInstr(r1)
    //     0x8e9e20: ldur            x2, [x1, #-1]
    //     0x8e9e24: ubfx            x2, x2, #0xc, #0x14
    // 0x8e9e28: mov             x16, x0
    // 0x8e9e2c: mov             x0, x2
    // 0x8e9e30: mov             x2, x16
    // 0x8e9e34: r0 = GDT[cid_x0 + -0xd48]()
    //     0x8e9e34: sub             lr, x0, #0xd48
    //     0x8e9e38: ldr             lr, [x21, lr, lsl #3]
    //     0x8e9e3c: blr             lr
    // 0x8e9e40: LeaveFrame
    //     0x8e9e40: mov             SP, fp
    //     0x8e9e44: ldp             fp, lr, [SP], #0x10
    // 0x8e9e48: ret
    //     0x8e9e48: ret             
    // 0x8e9e4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8e9e4c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8e9e50: b               #0x8e9dcc
  }
  [closure] String? value(dynamic, String) {
    // ** addr: 0x8e9e90, size: 0x3c
    // 0x8e9e90: EnterFrame
    //     0x8e9e90: stp             fp, lr, [SP, #-0x10]!
    //     0x8e9e94: mov             fp, SP
    // 0x8e9e98: ldr             x0, [fp, #0x18]
    // 0x8e9e9c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8e9e9c: ldur            w1, [x0, #0x17]
    // 0x8e9ea0: DecompressPointer r1
    //     0x8e9ea0: add             x1, x1, HEAP, lsl #32
    // 0x8e9ea4: CheckStackOverflow
    //     0x8e9ea4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8e9ea8: cmp             SP, x16
    //     0x8e9eac: b.ls            #0x8e9ec4
    // 0x8e9eb0: ldr             x2, [fp, #0x10]
    // 0x8e9eb4: r0 = value()
    //     0x8e9eb4: bl              #0x8e9ecc  ; [package:dio/src/headers.dart] Headers::value
    // 0x8e9eb8: LeaveFrame
    //     0x8e9eb8: mov             SP, fp
    //     0x8e9ebc: ldp             fp, lr, [SP], #0x10
    // 0x8e9ec0: ret
    //     0x8e9ec0: ret             
    // 0x8e9ec4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8e9ec4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8e9ec8: b               #0x8e9eb0
  }
  _ value(/* No info */) {
    // ** addr: 0x8e9ecc, size: 0x128
    // 0x8e9ecc: EnterFrame
    //     0x8e9ecc: stp             fp, lr, [SP, #-0x10]!
    //     0x8e9ed0: mov             fp, SP
    // 0x8e9ed4: AllocStack(0x18)
    //     0x8e9ed4: sub             SP, SP, #0x18
    // 0x8e9ed8: SetupParameters(dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x8e9ed8: mov             x0, x2
    //     0x8e9edc: stur            x2, [fp, #-0x10]
    // 0x8e9ee0: CheckStackOverflow
    //     0x8e9ee0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8e9ee4: cmp             SP, x16
    //     0x8e9ee8: b.ls            #0x8e9fec
    // 0x8e9eec: LoadField: r2 = r1->field_7
    //     0x8e9eec: ldur            w2, [x1, #7]
    // 0x8e9ef0: DecompressPointer r2
    //     0x8e9ef0: add             x2, x2, HEAP, lsl #32
    // 0x8e9ef4: mov             x1, x0
    // 0x8e9ef8: stur            x2, [fp, #-8]
    // 0x8e9efc: r0 = trim()
    //     0x8e9efc: bl              #0x808ff4  ; [dart:core] _StringBase::trim
    // 0x8e9f00: ldur            x1, [fp, #-8]
    // 0x8e9f04: r2 = LoadClassIdInstr(r1)
    //     0x8e9f04: ldur            x2, [x1, #-1]
    //     0x8e9f08: ubfx            x2, x2, #0xc, #0x14
    // 0x8e9f0c: mov             x16, x0
    // 0x8e9f10: mov             x0, x2
    // 0x8e9f14: mov             x2, x16
    // 0x8e9f18: r0 = GDT[cid_x0 + -0xd48]()
    //     0x8e9f18: sub             lr, x0, #0xd48
    //     0x8e9f1c: ldr             lr, [x21, lr, lsl #3]
    //     0x8e9f20: blr             lr
    // 0x8e9f24: mov             x1, x0
    // 0x8e9f28: stur            x1, [fp, #-8]
    // 0x8e9f2c: cmp             w1, NULL
    // 0x8e9f30: b.ne            #0x8e9f44
    // 0x8e9f34: r0 = Null
    //     0x8e9f34: mov             x0, NULL
    // 0x8e9f38: LeaveFrame
    //     0x8e9f38: mov             SP, fp
    //     0x8e9f3c: ldp             fp, lr, [SP], #0x10
    // 0x8e9f40: ret
    //     0x8e9f40: ret             
    // 0x8e9f44: r0 = LoadClassIdInstr(r1)
    //     0x8e9f44: ldur            x0, [x1, #-1]
    //     0x8e9f48: ubfx            x0, x0, #0xc, #0x14
    // 0x8e9f4c: str             x1, [SP]
    // 0x8e9f50: r0 = GDT[cid_x0 + 0xf078]()
    //     0x8e9f50: mov             x17, #0xf078
    //     0x8e9f54: add             lr, x0, x17
    //     0x8e9f58: ldr             lr, [x21, lr, lsl #3]
    //     0x8e9f5c: blr             lr
    // 0x8e9f60: cmp             w0, #2
    // 0x8e9f64: b.ne            #0x8e9f94
    // 0x8e9f68: ldur            x1, [fp, #-8]
    // 0x8e9f6c: r0 = LoadClassIdInstr(r1)
    //     0x8e9f6c: ldur            x0, [x1, #-1]
    //     0x8e9f70: ubfx            x0, x0, #0xc, #0x14
    // 0x8e9f74: r0 = GDT[cid_x0 + 0x127b5]()
    //     0x8e9f74: mov             x17, #0x27b5
    //     0x8e9f78: movk            x17, #1, lsl #16
    //     0x8e9f7c: add             lr, x0, x17
    //     0x8e9f80: ldr             lr, [x21, lr, lsl #3]
    //     0x8e9f84: blr             lr
    // 0x8e9f88: LeaveFrame
    //     0x8e9f88: mov             SP, fp
    //     0x8e9f8c: ldp             fp, lr, [SP], #0x10
    // 0x8e9f90: ret
    //     0x8e9f90: ret             
    // 0x8e9f94: ldur            x0, [fp, #-0x10]
    // 0x8e9f98: r1 = Null
    //     0x8e9f98: mov             x1, NULL
    // 0x8e9f9c: r2 = 6
    //     0x8e9f9c: mov             x2, #6
    // 0x8e9fa0: r0 = AllocateArray()
    //     0x8e9fa0: bl              #0x13df928  ; AllocateArrayStub
    // 0x8e9fa4: r16 = "\""
    //     0x8e9fa4: add             x16, PP, #8, lsl #12  ; [pp+0x84a0] "\""
    //     0x8e9fa8: ldr             x16, [x16, #0x4a0]
    // 0x8e9fac: StoreField: r0->field_f = r16
    //     0x8e9fac: stur            w16, [x0, #0xf]
    // 0x8e9fb0: ldur            x1, [fp, #-0x10]
    // 0x8e9fb4: StoreField: r0->field_13 = r1
    //     0x8e9fb4: stur            w1, [x0, #0x13]
    // 0x8e9fb8: r16 = "\" header has more than one value, please use Headers[name]"
    //     0x8e9fb8: add             x16, PP, #0x81, lsl #12  ; [pp+0x81520] "\" header has more than one value, please use Headers[name]"
    //     0x8e9fbc: ldr             x16, [x16, #0x520]
    // 0x8e9fc0: ArrayStore: r0[0] = r16  ; List_4
    //     0x8e9fc0: stur            w16, [x0, #0x17]
    // 0x8e9fc4: str             x0, [SP]
    // 0x8e9fc8: r0 = _interpolate()
    //     0x8e9fc8: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x8e9fcc: stur            x0, [fp, #-8]
    // 0x8e9fd0: r0 = _Exception()
    //     0x8e9fd0: bl              #0x8220c0  ; Allocate_ExceptionStub -> _Exception (size=0xc)
    // 0x8e9fd4: mov             x1, x0
    // 0x8e9fd8: ldur            x0, [fp, #-8]
    // 0x8e9fdc: StoreField: r1->field_7 = r0
    //     0x8e9fdc: stur            w0, [x1, #7]
    // 0x8e9fe0: mov             x0, x1
    // 0x8e9fe4: r0 = Throw()
    //     0x8e9fe4: bl              #0x13ddb2c  ; ThrowStub
    // 0x8e9fe8: brk             #0
    // 0x8e9fec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8e9fec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8e9ff0: b               #0x8e9eec
  }
  _ Headers.fromMap(/* No info */) {
    // ** addr: 0x8ed5cc, size: 0xbc
    // 0x8ed5cc: EnterFrame
    //     0x8ed5cc: stp             fp, lr, [SP, #-0x10]!
    //     0x8ed5d0: mov             fp, SP
    // 0x8ed5d4: AllocStack(0x28)
    //     0x8ed5d4: sub             SP, SP, #0x28
    // 0x8ed5d8: SetupParameters(Headers this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x8ed5d8: mov             x3, x1
    //     0x8ed5dc: mov             x0, x2
    //     0x8ed5e0: stur            x1, [fp, #-8]
    //     0x8ed5e4: stur            x2, [fp, #-0x10]
    // 0x8ed5e8: CheckStackOverflow
    //     0x8ed5e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ed5ec: cmp             SP, x16
    //     0x8ed5f0: b.ls            #0x8ed680
    // 0x8ed5f4: r1 = Function '<anonymous closure>':.
    //     0x8ed5f4: add             x1, PP, #0x16, lsl #12  ; [pp+0x16408] AnonymousClosure: (0x8ed688), in [package:dio/src/headers.dart] Headers::Headers.fromMap (0x8ed5cc)
    //     0x8ed5f8: ldr             x1, [x1, #0x408]
    // 0x8ed5fc: r2 = Null
    //     0x8ed5fc: mov             x2, NULL
    // 0x8ed600: r0 = AllocateClosure()
    //     0x8ed600: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8ed604: mov             x1, x0
    // 0x8ed608: ldur            x0, [fp, #-0x10]
    // 0x8ed60c: r2 = LoadClassIdInstr(r0)
    //     0x8ed60c: ldur            x2, [x0, #-1]
    //     0x8ed610: ubfx            x2, x2, #0xc, #0x14
    // 0x8ed614: r16 = <String, List<String>>
    //     0x8ed614: add             x16, PP, #0xb, lsl #12  ; [pp+0xbed0] TypeArguments: <String, List<String>>
    //     0x8ed618: ldr             x16, [x16, #0xed0]
    // 0x8ed61c: stp             x0, x16, [SP, #8]
    // 0x8ed620: str             x1, [SP]
    // 0x8ed624: mov             x0, x2
    // 0x8ed628: r4 = const [0x2, 0x2, 0x2, 0x2, null]
    //     0x8ed628: ldr             x4, [PP, #0x808]  ; [pp+0x808] List(5) [0x2, 0x2, 0x2, 0x2, Null]
    // 0x8ed62c: r0 = GDT[cid_x0 + 0xe626]()
    //     0x8ed62c: mov             x17, #0xe626
    //     0x8ed630: add             lr, x0, x17
    //     0x8ed634: ldr             lr, [x21, lr, lsl #3]
    //     0x8ed638: blr             lr
    // 0x8ed63c: r16 = <List<String>>
    //     0x8ed63c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15358] TypeArguments: <List<String>>
    //     0x8ed640: ldr             x16, [x16, #0x358]
    // 0x8ed644: stp             x0, x16, [SP]
    // 0x8ed648: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8ed648: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8ed64c: r0 = caseInsensitiveKeyMap()
    //     0x8ed64c: bl              #0x8eb034  ; [package:dio/src/utils.dart] ::caseInsensitiveKeyMap
    // 0x8ed650: ldur            x1, [fp, #-8]
    // 0x8ed654: StoreField: r1->field_7 = r0
    //     0x8ed654: stur            w0, [x1, #7]
    //     0x8ed658: ldurb           w16, [x1, #-1]
    //     0x8ed65c: ldurb           w17, [x0, #-1]
    //     0x8ed660: and             x16, x17, x16, lsr #2
    //     0x8ed664: tst             x16, HEAP, lsr #32
    //     0x8ed668: b.eq            #0x8ed670
    //     0x8ed66c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8ed670: r0 = Null
    //     0x8ed670: mov             x0, NULL
    // 0x8ed674: LeaveFrame
    //     0x8ed674: mov             SP, fp
    //     0x8ed678: ldp             fp, lr, [SP], #0x10
    // 0x8ed67c: ret
    //     0x8ed67c: ret             
    // 0x8ed680: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ed680: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ed684: b               #0x8ed5f4
  }
  [closure] MapEntry<String, List<String>> <anonymous closure>(dynamic, String, List<String>) {
    // ** addr: 0x8ed688, size: 0x54
    // 0x8ed688: EnterFrame
    //     0x8ed688: stp             fp, lr, [SP, #-0x10]!
    //     0x8ed68c: mov             fp, SP
    // 0x8ed690: AllocStack(0x8)
    //     0x8ed690: sub             SP, SP, #8
    // 0x8ed694: CheckStackOverflow
    //     0x8ed694: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ed698: cmp             SP, x16
    //     0x8ed69c: b.ls            #0x8ed6d4
    // 0x8ed6a0: ldr             x1, [fp, #0x18]
    // 0x8ed6a4: r0 = trim()
    //     0x8ed6a4: bl              #0x808ff4  ; [dart:core] _StringBase::trim
    // 0x8ed6a8: r1 = <String, List<String>>
    //     0x8ed6a8: add             x1, PP, #0xb, lsl #12  ; [pp+0xbed0] TypeArguments: <String, List<String>>
    //     0x8ed6ac: ldr             x1, [x1, #0xed0]
    // 0x8ed6b0: stur            x0, [fp, #-8]
    // 0x8ed6b4: r0 = MapEntry()
    //     0x8ed6b4: bl              #0x8027cc  ; AllocateMapEntryStub -> MapEntry<X0, X1> (size=0x14)
    // 0x8ed6b8: ldur            x1, [fp, #-8]
    // 0x8ed6bc: StoreField: r0->field_b = r1
    //     0x8ed6bc: stur            w1, [x0, #0xb]
    // 0x8ed6c0: ldr             x1, [fp, #0x10]
    // 0x8ed6c4: StoreField: r0->field_f = r1
    //     0x8ed6c4: stur            w1, [x0, #0xf]
    // 0x8ed6c8: LeaveFrame
    //     0x8ed6c8: mov             SP, fp
    //     0x8ed6cc: ldp             fp, lr, [SP], #0x10
    // 0x8ed6d0: ret
    //     0x8ed6d0: ret             
    // 0x8ed6d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ed6d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ed6d8: b               #0x8ed6a0
  }
  _ toString(/* No info */) {
    // ** addr: 0x1114638, size: 0xa4
    // 0x1114638: EnterFrame
    //     0x1114638: stp             fp, lr, [SP, #-0x10]!
    //     0x111463c: mov             fp, SP
    // 0x1114640: AllocStack(0x18)
    //     0x1114640: sub             SP, SP, #0x18
    // 0x1114644: CheckStackOverflow
    //     0x1114644: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1114648: cmp             SP, x16
    //     0x111464c: b.ls            #0x11146d4
    // 0x1114650: r0 = StringBuffer()
    //     0x1114650: bl              #0x7e51d4  ; AllocateStringBufferStub -> StringBuffer (size=0x38)
    // 0x1114654: mov             x1, x0
    // 0x1114658: stur            x0, [fp, #-8]
    // 0x111465c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x111465c: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x1114660: r0 = StringBuffer()
    //     0x1114660: bl              #0x7e4a4c  ; [dart:core] StringBuffer::StringBuffer
    // 0x1114664: r1 = 1
    //     0x1114664: mov             x1, #1
    // 0x1114668: r0 = AllocateContext()
    //     0x1114668: bl              #0x13de838  ; AllocateContextStub
    // 0x111466c: mov             x1, x0
    // 0x1114670: ldur            x0, [fp, #-8]
    // 0x1114674: StoreField: r1->field_f = r0
    //     0x1114674: stur            w0, [x1, #0xf]
    // 0x1114678: ldr             x2, [fp, #0x10]
    // 0x111467c: LoadField: r3 = r2->field_7
    //     0x111467c: ldur            w3, [x2, #7]
    // 0x1114680: DecompressPointer r3
    //     0x1114680: add             x3, x3, HEAP, lsl #32
    // 0x1114684: mov             x2, x1
    // 0x1114688: stur            x3, [fp, #-0x10]
    // 0x111468c: r1 = Function '<anonymous closure>':.
    //     0x111468c: add             x1, PP, #0x81, lsl #12  ; [pp+0x814e8] AnonymousClosure: (0x11146dc), in [package:dio/src/headers.dart] Headers::toString (0x1114638)
    //     0x1114690: ldr             x1, [x1, #0x4e8]
    // 0x1114694: r0 = AllocateClosure()
    //     0x1114694: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1114698: ldur            x1, [fp, #-0x10]
    // 0x111469c: r2 = LoadClassIdInstr(r1)
    //     0x111469c: ldur            x2, [x1, #-1]
    //     0x11146a0: ubfx            x2, x2, #0xc, #0x14
    // 0x11146a4: mov             x16, x0
    // 0x11146a8: mov             x0, x2
    // 0x11146ac: mov             x2, x16
    // 0x11146b0: r0 = GDT[cid_x0 + 0x6c5]()
    //     0x11146b0: add             lr, x0, #0x6c5
    //     0x11146b4: ldr             lr, [x21, lr, lsl #3]
    //     0x11146b8: blr             lr
    // 0x11146bc: ldur            x16, [fp, #-8]
    // 0x11146c0: str             x16, [SP]
    // 0x11146c4: r0 = toString()
    //     0x11146c4: bl              #0x1101d44  ; [dart:core] StringBuffer::toString
    // 0x11146c8: LeaveFrame
    //     0x11146c8: mov             SP, fp
    //     0x11146cc: ldp             fp, lr, [SP], #0x10
    // 0x11146d0: ret
    //     0x11146d0: ret             
    // 0x11146d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11146d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11146d8: b               #0x1114650
  }
  [closure] void <anonymous closure>(dynamic, String, List<String>) {
    // ** addr: 0x11146dc, size: 0x134
    // 0x11146dc: EnterFrame
    //     0x11146dc: stp             fp, lr, [SP, #-0x10]!
    //     0x11146e0: mov             fp, SP
    // 0x11146e4: AllocStack(0x20)
    //     0x11146e4: sub             SP, SP, #0x20
    // 0x11146e8: SetupParameters([dynamic _ /* r0 */])
    //     0x11146e8: ldr             x0, [fp, #0x20]
    //     0x11146ec: ldur            w2, [x0, #0x17]
    //     0x11146f0: add             x2, x2, HEAP, lsl #32
    //     0x11146f4: stur            x2, [fp, #-8]
    // 0x11146f8: CheckStackOverflow
    //     0x11146f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11146fc: cmp             SP, x16
    //     0x1114700: b.ls            #0x1114800
    // 0x1114704: ldr             x1, [fp, #0x10]
    // 0x1114708: r0 = LoadClassIdInstr(r1)
    //     0x1114708: ldur            x0, [x1, #-1]
    //     0x111470c: ubfx            x0, x0, #0xc, #0x14
    // 0x1114710: r0 = GDT[cid_x0 + 0x12641]()
    //     0x1114710: mov             x17, #0x2641
    //     0x1114714: movk            x17, #1, lsl #16
    //     0x1114718: add             lr, x0, x17
    //     0x111471c: ldr             lr, [x21, lr, lsl #3]
    //     0x1114720: blr             lr
    // 0x1114724: mov             x2, x0
    // 0x1114728: ldur            x0, [fp, #-8]
    // 0x111472c: stur            x2, [fp, #-0x18]
    // 0x1114730: LoadField: r3 = r0->field_f
    //     0x1114730: ldur            w3, [x0, #0xf]
    // 0x1114734: DecompressPointer r3
    //     0x1114734: add             x3, x3, HEAP, lsl #32
    // 0x1114738: stur            x3, [fp, #-0x10]
    // 0x111473c: ldr             x4, [fp, #0x18]
    // 0x1114740: CheckStackOverflow
    //     0x1114740: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1114744: cmp             SP, x16
    //     0x1114748: b.ls            #0x1114808
    // 0x111474c: r0 = LoadClassIdInstr(r2)
    //     0x111474c: ldur            x0, [x2, #-1]
    //     0x1114750: ubfx            x0, x0, #0xc, #0x14
    // 0x1114754: mov             x1, x2
    // 0x1114758: r0 = GDT[cid_x0 + 0x1845b]()
    //     0x1114758: mov             x17, #0x845b
    //     0x111475c: movk            x17, #1, lsl #16
    //     0x1114760: add             lr, x0, x17
    //     0x1114764: ldr             lr, [x21, lr, lsl #3]
    //     0x1114768: blr             lr
    // 0x111476c: tbnz            w0, #4, #0x11147f0
    // 0x1114770: ldr             x3, [fp, #0x18]
    // 0x1114774: ldur            x2, [fp, #-0x18]
    // 0x1114778: r0 = LoadClassIdInstr(r2)
    //     0x1114778: ldur            x0, [x2, #-1]
    //     0x111477c: ubfx            x0, x0, #0xc, #0x14
    // 0x1114780: mov             x1, x2
    // 0x1114784: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0x1114784: mov             x17, #0x7d4c
    //     0x1114788: movk            x17, #1, lsl #16
    //     0x111478c: add             lr, x0, x17
    //     0x1114790: ldr             lr, [x21, lr, lsl #3]
    //     0x1114794: blr             lr
    // 0x1114798: r1 = Null
    //     0x1114798: mov             x1, NULL
    // 0x111479c: r2 = 6
    //     0x111479c: mov             x2, #6
    // 0x11147a0: stur            x0, [fp, #-8]
    // 0x11147a4: r0 = AllocateArray()
    //     0x11147a4: bl              #0x13df928  ; AllocateArrayStub
    // 0x11147a8: mov             x1, x0
    // 0x11147ac: ldr             x0, [fp, #0x18]
    // 0x11147b0: StoreField: r1->field_f = r0
    //     0x11147b0: stur            w0, [x1, #0xf]
    // 0x11147b4: r16 = ": "
    //     0x11147b4: ldr             x16, [PP, #0xcb0]  ; [pp+0xcb0] ": "
    // 0x11147b8: StoreField: r1->field_13 = r16
    //     0x11147b8: stur            w16, [x1, #0x13]
    // 0x11147bc: ldur            x2, [fp, #-8]
    // 0x11147c0: ArrayStore: r1[0] = r2  ; List_4
    //     0x11147c0: stur            w2, [x1, #0x17]
    // 0x11147c4: str             x1, [SP]
    // 0x11147c8: r0 = _interpolate()
    //     0x11147c8: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11147cc: ldur            x1, [fp, #-0x10]
    // 0x11147d0: mov             x2, x0
    // 0x11147d4: r0 = write()
    //     0x11147d4: bl              #0x7e5154  ; [dart:core] StringBuffer::write
    // 0x11147d8: ldur            x1, [fp, #-0x10]
    // 0x11147dc: r2 = "\n"
    //     0x11147dc: ldr             x2, [PP, #0x8c0]  ; [pp+0x8c0] "\n"
    // 0x11147e0: r0 = _writeString()
    //     0x11147e0: bl              #0x7e4c0c  ; [dart:core] StringBuffer::_writeString
    // 0x11147e4: ldur            x2, [fp, #-0x18]
    // 0x11147e8: ldur            x3, [fp, #-0x10]
    // 0x11147ec: b               #0x111473c
    // 0x11147f0: r0 = Null
    //     0x11147f0: mov             x0, NULL
    // 0x11147f4: LeaveFrame
    //     0x11147f4: mov             SP, fp
    //     0x11147f8: ldp             fp, lr, [SP], #0x10
    // 0x11147fc: ret
    //     0x11147fc: ret             
    // 0x1114800: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1114800: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1114804: b               #0x1114704
    // 0x1114808: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1114808: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x111480c: b               #0x111474c
  }
}
