// lib: , url: package:dio/src/response/response_stream_handler.dart

// class id: 1048712, size: 0x8
class :: {

  static _ handleResponseStream(/* No info */) {
    // ** addr: 0x8f45fc, size: 0x2c8
    // 0x8f45fc: EnterFrame
    //     0x8f45fc: stp             fp, lr, [SP, #-0x10]!
    //     0x8f4600: mov             fp, SP
    // 0x8f4604: AllocStack(0x40)
    //     0x8f4604: sub             SP, SP, #0x40
    // 0x8f4608: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x8f4608: stur            x1, [fp, #-8]
    //     0x8f460c: stur            x2, [fp, #-0x10]
    // 0x8f4610: CheckStackOverflow
    //     0x8f4610: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f4614: cmp             SP, x16
    //     0x8f4618: b.ls            #0x8f48bc
    // 0x8f461c: r1 = 11
    //     0x8f461c: mov             x1, #0xb
    // 0x8f4620: r0 = AllocateContext()
    //     0x8f4620: bl              #0x13de838  ; AllocateContextStub
    // 0x8f4624: mov             x2, x0
    // 0x8f4628: ldur            x0, [fp, #-8]
    // 0x8f462c: stur            x2, [fp, #-0x18]
    // 0x8f4630: StoreField: r2->field_f = r0
    //     0x8f4630: stur            w0, [x2, #0xf]
    // 0x8f4634: ldur            x0, [fp, #-0x10]
    // 0x8f4638: StoreField: r2->field_13 = r0
    //     0x8f4638: stur            w0, [x2, #0x13]
    // 0x8f463c: LoadField: r3 = r0->field_b
    //     0x8f463c: ldur            w3, [x0, #0xb]
    // 0x8f4640: DecompressPointer r3
    //     0x8f4640: add             x3, x3, HEAP, lsl #32
    // 0x8f4644: stur            x3, [fp, #-8]
    // 0x8f4648: r1 = <Uint8List>
    //     0x8f4648: add             x1, PP, #8, lsl #12  ; [pp+0x8548] TypeArguments: <Uint8List>
    //     0x8f464c: ldr             x1, [x1, #0x548]
    // 0x8f4650: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8f4650: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8f4654: r0 = StreamController()
    //     0x8f4654: bl              #0x811820  ; [dart:async] StreamController::StreamController
    // 0x8f4658: mov             x3, x0
    // 0x8f465c: ldur            x2, [fp, #-0x18]
    // 0x8f4660: stur            x3, [fp, #-0x10]
    // 0x8f4664: ArrayStore: r2[0] = r0  ; List_4
    //     0x8f4664: stur            w0, [x2, #0x17]
    //     0x8f4668: ldurb           w16, [x2, #-1]
    //     0x8f466c: ldurb           w17, [x0, #-1]
    //     0x8f4670: and             x16, x17, x16, lsr #2
    //     0x8f4674: tst             x16, HEAP, lsr #32
    //     0x8f4678: b.eq            #0x8f4680
    //     0x8f467c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x8f4680: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x8f4684: StoreField: r2->field_1b = r0
    //     0x8f4684: stur            w0, [x2, #0x1b]
    // 0x8f4688: StoreField: r2->field_1f = r0
    //     0x8f4688: stur            w0, [x2, #0x1f]
    // 0x8f468c: StoreField: r2->field_23 = rZR
    //     0x8f468c: stur            wzr, [x2, #0x23]
    // 0x8f4690: LoadField: r0 = r2->field_f
    //     0x8f4690: ldur            w0, [x2, #0xf]
    // 0x8f4694: DecompressPointer r0
    //     0x8f4694: add             x0, x0, HEAP, lsl #32
    // 0x8f4698: LoadField: r1 = r0->field_67
    //     0x8f4698: ldur            w1, [x0, #0x67]
    // 0x8f469c: DecompressPointer r1
    //     0x8f469c: add             x1, x1, HEAP, lsl #32
    // 0x8f46a0: cmp             w1, NULL
    // 0x8f46a4: b.eq            #0x8f46f0
    // 0x8f46a8: LoadField: r1 = r2->field_13
    //     0x8f46a8: ldur            w1, [x2, #0x13]
    // 0x8f46ac: DecompressPointer r1
    //     0x8f46ac: add             x1, x1, HEAP, lsl #32
    // 0x8f46b0: r0 = contentLength()
    //     0x8f46b0: bl              #0x8f48c4  ; [package:dio/src/adapter.dart] ResponseBody::contentLength
    // 0x8f46b4: mov             x2, x0
    // 0x8f46b8: r0 = BoxInt64Instr(r2)
    //     0x8f46b8: sbfiz           x0, x2, #1, #0x1f
    //     0x8f46bc: cmp             x2, x0, asr #1
    //     0x8f46c0: b.eq            #0x8f46cc
    //     0x8f46c4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8f46c8: stur            x2, [x0, #7]
    // 0x8f46cc: ldur            x2, [fp, #-0x18]
    // 0x8f46d0: StoreField: r2->field_1f = r0
    //     0x8f46d0: stur            w0, [x2, #0x1f]
    //     0x8f46d4: tbz             w0, #0, #0x8f46f0
    //     0x8f46d8: ldurb           w16, [x2, #-1]
    //     0x8f46dc: ldurb           w17, [x0, #-1]
    //     0x8f46e0: and             x16, x17, x16, lsr #2
    //     0x8f46e4: tst             x16, HEAP, lsr #32
    //     0x8f46e8: b.eq            #0x8f46f0
    //     0x8f46ec: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x8f46f0: LoadField: r0 = r2->field_f
    //     0x8f46f0: ldur            w0, [x2, #0xf]
    // 0x8f46f4: DecompressPointer r0
    //     0x8f46f4: add             x0, x0, HEAP, lsl #32
    // 0x8f46f8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8f46f8: ldur            w1, [x0, #0x17]
    // 0x8f46fc: DecompressPointer r1
    //     0x8f46fc: add             x1, x1, HEAP, lsl #32
    // 0x8f4700: cmp             w1, NULL
    // 0x8f4704: b.ne            #0x8f4710
    // 0x8f4708: r0 = Instance_Duration
    //     0x8f4708: ldr             x0, [PP, #0x1808]  ; [pp+0x1808] Obj!Duration@12c8901
    // 0x8f470c: b               #0x8f4714
    // 0x8f4710: mov             x0, x1
    // 0x8f4714: ldur            x3, [fp, #-8]
    // 0x8f4718: ldur            x1, [fp, #-0x10]
    // 0x8f471c: StoreField: r2->field_27 = r0
    //     0x8f471c: stur            w0, [x2, #0x27]
    //     0x8f4720: ldurb           w16, [x2, #-1]
    //     0x8f4724: ldurb           w17, [x0, #-1]
    //     0x8f4728: and             x16, x17, x16, lsr #2
    //     0x8f472c: tst             x16, HEAP, lsr #32
    //     0x8f4730: b.eq            #0x8f4738
    //     0x8f4734: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x8f4738: r0 = Stopwatch()
    //     0x8f4738: bl              #0x82ae94  ; AllocateStopwatchStub -> Stopwatch (size=0x14)
    // 0x8f473c: stur            x0, [fp, #-0x20]
    // 0x8f4740: StoreField: r0->field_7 = rZR
    //     0x8f4740: stur            xzr, [x0, #7]
    // 0x8f4744: StoreField: r0->field_f = rZR
    //     0x8f4744: stur            wzr, [x0, #0xf]
    // 0x8f4748: ldr             x0, [THR, #0x80]  ; THR::
    // 0x8f474c: add             x17, x0, #0x60
    // 0x8f4750: ldar            x0, [x17]
    // 0x8f4754: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8f4758: cmp             w0, w16
    // 0x8f475c: b.ne            #0x8f4768
    // 0x8f4760: r2 = _frequency
    //     0x8f4760: ldr             x2, [PP, #0xb80]  ; [pp+0xb80] Field <Stopwatch._frequency@0150898>: static late final shared (offset: 0x30)
    // 0x8f4764: r0 = InitSharedLateStaticField()
    //     0x8f4764: bl              #0x13dd874  ; InitSharedLateStaticFieldStub
    // 0x8f4768: ldur            x0, [fp, #-0x20]
    // 0x8f476c: ldur            x3, [fp, #-0x18]
    // 0x8f4770: StoreField: r3->field_2b = r0
    //     0x8f4770: stur            w0, [x3, #0x2b]
    //     0x8f4774: ldurb           w16, [x3, #-1]
    //     0x8f4778: ldurb           w17, [x0, #-1]
    //     0x8f477c: and             x16, x17, x16, lsr #2
    //     0x8f4780: tst             x16, HEAP, lsr #32
    //     0x8f4784: b.eq            #0x8f478c
    //     0x8f4788: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x8f478c: StoreField: r3->field_2f = rNULL
    //     0x8f478c: stur            NULL, [x3, #0x2f]
    // 0x8f4790: mov             x2, x3
    // 0x8f4794: r1 = Function 'stopWatchReceiveTimeout': static.
    //     0x8f4794: add             x1, PP, #0x16, lsl #12  ; [pp+0x16380] AnonymousClosure: static (0x8f5028), in [package:dio/src/response/response_stream_handler.dart] ::handleResponseStream (0x8f45fc)
    //     0x8f4798: ldr             x1, [x1, #0x380]
    // 0x8f479c: r0 = AllocateClosure()
    //     0x8f479c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8f47a0: ldur            x3, [fp, #-0x18]
    // 0x8f47a4: StoreField: r3->field_33 = r0
    //     0x8f47a4: stur            w0, [x3, #0x33]
    //     0x8f47a8: ldurb           w16, [x3, #-1]
    //     0x8f47ac: ldurb           w17, [x0, #-1]
    //     0x8f47b0: and             x16, x17, x16, lsr #2
    //     0x8f47b4: tst             x16, HEAP, lsr #32
    //     0x8f47b8: b.eq            #0x8f47c0
    //     0x8f47bc: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x8f47c0: mov             x2, x3
    // 0x8f47c4: r1 = Function 'watchReceiveTimeout': static.
    //     0x8f47c4: add             x1, PP, #0x16, lsl #12  ; [pp+0x16388] AnonymousClosure: static (0x8f4d84), in [package:dio/src/response/response_stream_handler.dart] ::handleResponseStream (0x8f45fc)
    //     0x8f47c8: ldr             x1, [x1, #0x388]
    // 0x8f47cc: r0 = AllocateClosure()
    //     0x8f47cc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8f47d0: mov             x1, x0
    // 0x8f47d4: ldur            x2, [fp, #-0x18]
    // 0x8f47d8: StoreField: r2->field_37 = r0
    //     0x8f47d8: stur            w0, [x2, #0x37]
    //     0x8f47dc: ldurb           w16, [x2, #-1]
    //     0x8f47e0: ldurb           w17, [x0, #-1]
    //     0x8f47e4: and             x16, x17, x16, lsr #2
    //     0x8f47e8: tst             x16, HEAP, lsr #32
    //     0x8f47ec: b.eq            #0x8f47f4
    //     0x8f47f0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x8f47f4: str             x1, [SP]
    // 0x8f47f8: mov             x0, x1
    // 0x8f47fc: ClosureCall
    //     0x8f47fc: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x8f4800: ldur            x2, [x0, #0x1f]
    //     0x8f4804: blr             x2
    // 0x8f4808: ldur            x2, [fp, #-0x18]
    // 0x8f480c: r1 = Function '<anonymous closure>': static.
    //     0x8f480c: add             x1, PP, #0x16, lsl #12  ; [pp+0x16390] AnonymousClosure: static (0x8f4c38), in [package:dio/src/response/response_stream_handler.dart] ::handleResponseStream (0x8f45fc)
    //     0x8f4810: ldr             x1, [x1, #0x390]
    // 0x8f4814: r0 = AllocateClosure()
    //     0x8f4814: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8f4818: ldur            x2, [fp, #-0x18]
    // 0x8f481c: r1 = Function '<anonymous closure>': static.
    //     0x8f481c: add             x1, PP, #0x16, lsl #12  ; [pp+0x16398] AnonymousClosure: static (0x8f4a80), in [package:dio/src/response/response_stream_handler.dart] ::handleResponseStream (0x8f45fc)
    //     0x8f4820: ldr             x1, [x1, #0x398]
    // 0x8f4824: stur            x0, [fp, #-0x20]
    // 0x8f4828: r0 = AllocateClosure()
    //     0x8f4828: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8f482c: ldur            x2, [fp, #-0x18]
    // 0x8f4830: r1 = Function '<anonymous closure>': static.
    //     0x8f4830: add             x1, PP, #0x16, lsl #12  ; [pp+0x163a0] AnonymousClosure: static (0x8f4994), in [package:dio/src/response/response_stream_handler.dart] ::handleResponseStream (0x8f45fc)
    //     0x8f4834: ldr             x1, [x1, #0x3a0]
    // 0x8f4838: stur            x0, [fp, #-0x28]
    // 0x8f483c: r0 = AllocateClosure()
    //     0x8f483c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8f4840: ldur            x1, [fp, #-8]
    // 0x8f4844: r2 = LoadClassIdInstr(r1)
    //     0x8f4844: ldur            x2, [x1, #-1]
    //     0x8f4848: ubfx            x2, x2, #0xc, #0x14
    // 0x8f484c: ldur            x16, [fp, #-0x28]
    // 0x8f4850: stp             x0, x16, [SP, #8]
    // 0x8f4854: r16 = true
    //     0x8f4854: add             x16, NULL, #0x20  ; true
    // 0x8f4858: str             x16, [SP]
    // 0x8f485c: mov             x0, x2
    // 0x8f4860: ldur            x2, [fp, #-0x20]
    // 0x8f4864: r4 = const [0, 0x5, 0x3, 0x2, cancelOnError, 0x4, onDone, 0x3, onError, 0x2, null]
    //     0x8f4864: add             x4, PP, #8, lsl #12  ; [pp+0x8570] List(11) [0, 0x5, 0x3, 0x2, "cancelOnError", 0x4, "onDone", 0x3, "onError", 0x2, Null]
    //     0x8f4868: ldr             x4, [x4, #0x570]
    // 0x8f486c: r0 = GDT[cid_x0 + 0x6de]()
    //     0x8f486c: add             lr, x0, #0x6de
    //     0x8f4870: ldr             lr, [x21, lr, lsl #3]
    //     0x8f4874: blr             lr
    // 0x8f4878: ldur            x1, [fp, #-0x18]
    // 0x8f487c: StoreField: r1->field_1b = r0
    //     0x8f487c: stur            w0, [x1, #0x1b]
    //     0x8f4880: ldurb           w16, [x1, #-1]
    //     0x8f4884: ldurb           w17, [x0, #-1]
    //     0x8f4888: and             x16, x17, x16, lsr #2
    //     0x8f488c: tst             x16, HEAP, lsr #32
    //     0x8f4890: b.eq            #0x8f4898
    //     0x8f4894: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8f4898: ldur            x0, [fp, #-0x10]
    // 0x8f489c: LoadField: r1 = r0->field_7
    //     0x8f489c: ldur            w1, [x0, #7]
    // 0x8f48a0: DecompressPointer r1
    //     0x8f48a0: add             x1, x1, HEAP, lsl #32
    // 0x8f48a4: r0 = _ControllerStream()
    //     0x8f48a4: bl              #0x810928  ; Allocate_ControllerStreamStub -> _ControllerStream<X0> (size=0x10)
    // 0x8f48a8: ldur            x1, [fp, #-0x10]
    // 0x8f48ac: StoreField: r0->field_b = r1
    //     0x8f48ac: stur            w1, [x0, #0xb]
    // 0x8f48b0: LeaveFrame
    //     0x8f48b0: mov             SP, fp
    //     0x8f48b4: ldp             fp, lr, [SP], #0x10
    // 0x8f48b8: ret
    //     0x8f48b8: ret             
    // 0x8f48bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f48bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f48c0: b               #0x8f461c
  }
  [closure] static void <anonymous closure>(dynamic) {
    // ** addr: 0x8f4994, size: 0xec
    // 0x8f4994: EnterFrame
    //     0x8f4994: stp             fp, lr, [SP, #-0x10]!
    //     0x8f4998: mov             fp, SP
    // 0x8f499c: AllocStack(0x20)
    //     0x8f499c: sub             SP, SP, #0x20
    // 0x8f49a0: SetupParameters([dynamic _ /* r0 */])
    //     0x8f49a0: ldr             x0, [fp, #0x10]
    //     0x8f49a4: ldur            w2, [x0, #0x17]
    //     0x8f49a8: add             x2, x2, HEAP, lsl #32
    //     0x8f49ac: stur            x2, [fp, #-0x10]
    // 0x8f49b0: CheckStackOverflow
    //     0x8f49b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f49b4: cmp             SP, x16
    //     0x8f49b8: b.ls            #0x8f4a78
    // 0x8f49bc: LoadField: r0 = r2->field_33
    //     0x8f49bc: ldur            w0, [x2, #0x33]
    // 0x8f49c0: DecompressPointer r0
    //     0x8f49c0: add             x0, x0, HEAP, lsl #32
    // 0x8f49c4: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x8f49c4: ldur            w3, [x0, #0x17]
    // 0x8f49c8: DecompressPointer r3
    //     0x8f49c8: add             x3, x3, HEAP, lsl #32
    // 0x8f49cc: stur            x3, [fp, #-8]
    // 0x8f49d0: LoadField: r1 = r3->field_2f
    //     0x8f49d0: ldur            w1, [x3, #0x2f]
    // 0x8f49d4: DecompressPointer r1
    //     0x8f49d4: add             x1, x1, HEAP, lsl #32
    // 0x8f49d8: cmp             w1, NULL
    // 0x8f49dc: b.ne            #0x8f49ec
    // 0x8f49e0: mov             x0, x2
    // 0x8f49e4: mov             x1, x3
    // 0x8f49e8: b               #0x8f49f8
    // 0x8f49ec: r0 = cancel()
    //     0x8f49ec: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0x8f49f0: ldur            x0, [fp, #-0x10]
    // 0x8f49f4: ldur            x1, [fp, #-8]
    // 0x8f49f8: StoreField: r1->field_2f = rNULL
    //     0x8f49f8: stur            NULL, [x1, #0x2f]
    // 0x8f49fc: LoadField: r2 = r1->field_2b
    //     0x8f49fc: ldur            w2, [x1, #0x2b]
    // 0x8f4a00: DecompressPointer r2
    //     0x8f4a00: add             x2, x2, HEAP, lsl #32
    // 0x8f4a04: mov             x1, x2
    // 0x8f4a08: stur            x2, [fp, #-0x18]
    // 0x8f4a0c: r0 = stop()
    //     0x8f4a0c: bl              #0x82ab00  ; [dart:core] Stopwatch::stop
    // 0x8f4a10: ldur            x1, [fp, #-0x18]
    // 0x8f4a14: r0 = reset()
    //     0x8f4a14: bl              #0x82aa8c  ; [dart:core] Stopwatch::reset
    // 0x8f4a18: ldur            x2, [fp, #-0x10]
    // 0x8f4a1c: LoadField: r1 = r2->field_1b
    //     0x8f4a1c: ldur            w1, [x2, #0x1b]
    // 0x8f4a20: DecompressPointer r1
    //     0x8f4a20: add             x1, x1, HEAP, lsl #32
    // 0x8f4a24: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8f4a28: cmp             w1, w16
    // 0x8f4a2c: b.eq            #0x8f4a64
    // 0x8f4a30: r0 = LoadClassIdInstr(r1)
    //     0x8f4a30: ldur            x0, [x1, #-1]
    //     0x8f4a34: ubfx            x0, x0, #0xc, #0x14
    // 0x8f4a38: r0 = GDT[cid_x0 + 0x549]()
    //     0x8f4a38: add             lr, x0, #0x549
    //     0x8f4a3c: ldr             lr, [x21, lr, lsl #3]
    //     0x8f4a40: blr             lr
    // 0x8f4a44: ldur            x0, [fp, #-0x10]
    // 0x8f4a48: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8f4a48: ldur            w1, [x0, #0x17]
    // 0x8f4a4c: DecompressPointer r1
    //     0x8f4a4c: add             x1, x1, HEAP, lsl #32
    // 0x8f4a50: r0 = close()
    //     0x8f4a50: bl              #0x811f40  ; [dart:async] _StreamController::close
    // 0x8f4a54: r0 = Null
    //     0x8f4a54: mov             x0, NULL
    // 0x8f4a58: LeaveFrame
    //     0x8f4a58: mov             SP, fp
    //     0x8f4a5c: ldp             fp, lr, [SP], #0x10
    // 0x8f4a60: ret
    //     0x8f4a60: ret             
    // 0x8f4a64: r16 = "responseSubscription"
    //     0x8f4a64: add             x16, PP, #0x16, lsl #12  ; [pp+0x163a8] "responseSubscription"
    //     0x8f4a68: ldr             x16, [x16, #0x3a8]
    // 0x8f4a6c: str             x16, [SP]
    // 0x8f4a70: r0 = _throwLocalNotInitialized()
    //     0x8f4a70: bl              #0x82b57c  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0x8f4a74: brk             #0
    // 0x8f4a78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f4a78: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f4a7c: b               #0x8f49bc
  }
  [closure] static Null <anonymous closure>(dynamic, dynamic, dynamic) {
    // ** addr: 0x8f4a80, size: 0x140
    // 0x8f4a80: EnterFrame
    //     0x8f4a80: stp             fp, lr, [SP, #-0x10]!
    //     0x8f4a84: mov             fp, SP
    // 0x8f4a88: AllocStack(0x20)
    //     0x8f4a88: sub             SP, SP, #0x20
    // 0x8f4a8c: SetupParameters([dynamic _ /* r0 */])
    //     0x8f4a8c: ldr             x0, [fp, #0x20]
    //     0x8f4a90: ldur            w2, [x0, #0x17]
    //     0x8f4a94: add             x2, x2, HEAP, lsl #32
    //     0x8f4a98: stur            x2, [fp, #-0x10]
    // 0x8f4a9c: CheckStackOverflow
    //     0x8f4a9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f4aa0: cmp             SP, x16
    //     0x8f4aa4: b.ls            #0x8f4bb8
    // 0x8f4aa8: LoadField: r0 = r2->field_33
    //     0x8f4aa8: ldur            w0, [x2, #0x33]
    // 0x8f4aac: DecompressPointer r0
    //     0x8f4aac: add             x0, x0, HEAP, lsl #32
    // 0x8f4ab0: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x8f4ab0: ldur            w3, [x0, #0x17]
    // 0x8f4ab4: DecompressPointer r3
    //     0x8f4ab4: add             x3, x3, HEAP, lsl #32
    // 0x8f4ab8: stur            x3, [fp, #-8]
    // 0x8f4abc: LoadField: r1 = r3->field_2f
    //     0x8f4abc: ldur            w1, [x3, #0x2f]
    // 0x8f4ac0: DecompressPointer r1
    //     0x8f4ac0: add             x1, x1, HEAP, lsl #32
    // 0x8f4ac4: cmp             w1, NULL
    // 0x8f4ac8: b.ne            #0x8f4ad8
    // 0x8f4acc: mov             x0, x2
    // 0x8f4ad0: mov             x1, x3
    // 0x8f4ad4: b               #0x8f4ae4
    // 0x8f4ad8: r0 = cancel()
    //     0x8f4ad8: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0x8f4adc: ldur            x0, [fp, #-0x10]
    // 0x8f4ae0: ldur            x1, [fp, #-8]
    // 0x8f4ae4: ldr             x2, [fp, #0x18]
    // 0x8f4ae8: StoreField: r1->field_2f = rNULL
    //     0x8f4ae8: stur            NULL, [x1, #0x2f]
    // 0x8f4aec: LoadField: r3 = r1->field_2b
    //     0x8f4aec: ldur            w3, [x1, #0x2b]
    // 0x8f4af0: DecompressPointer r3
    //     0x8f4af0: add             x3, x3, HEAP, lsl #32
    // 0x8f4af4: mov             x1, x3
    // 0x8f4af8: stur            x3, [fp, #-0x18]
    // 0x8f4afc: r0 = stop()
    //     0x8f4afc: bl              #0x82ab00  ; [dart:core] Stopwatch::stop
    // 0x8f4b00: ldur            x1, [fp, #-0x18]
    // 0x8f4b04: r0 = reset()
    //     0x8f4b04: bl              #0x82aa8c  ; [dart:core] Stopwatch::reset
    // 0x8f4b08: ldur            x0, [fp, #-0x10]
    // 0x8f4b0c: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x8f4b0c: ldur            w3, [x0, #0x17]
    // 0x8f4b10: DecompressPointer r3
    //     0x8f4b10: add             x3, x3, HEAP, lsl #32
    // 0x8f4b14: ldr             x4, [fp, #0x18]
    // 0x8f4b18: stur            x3, [fp, #-8]
    // 0x8f4b1c: cmp             w4, NULL
    // 0x8f4b20: b.ne            #0x8f4b48
    // 0x8f4b24: mov             x0, x4
    // 0x8f4b28: r2 = Null
    //     0x8f4b28: mov             x2, NULL
    // 0x8f4b2c: r1 = Null
    //     0x8f4b2c: mov             x1, NULL
    // 0x8f4b30: cmp             w0, NULL
    // 0x8f4b34: b.ne            #0x8f4b48
    // 0x8f4b38: r8 = Object
    //     0x8f4b38: ldr             x8, [PP, #0xd0]  ; [pp+0xd0] Type: Object
    // 0x8f4b3c: r3 = Null
    //     0x8f4b3c: add             x3, PP, #0x16, lsl #12  ; [pp+0x163b0] Null
    //     0x8f4b40: ldr             x3, [x3, #0x3b0]
    // 0x8f4b44: r0 = Object()
    //     0x8f4b44: bl              #0x13ef428  ; IsType_Object_Stub
    // 0x8f4b48: ldr             x0, [fp, #0x10]
    // 0x8f4b4c: r2 = Null
    //     0x8f4b4c: mov             x2, NULL
    // 0x8f4b50: r1 = Null
    //     0x8f4b50: mov             x1, NULL
    // 0x8f4b54: r4 = 60
    //     0x8f4b54: mov             x4, #0x3c
    // 0x8f4b58: branchIfSmi(r0, 0x8f4b64)
    //     0x8f4b58: tbz             w0, #0, #0x8f4b64
    // 0x8f4b5c: r4 = LoadClassIdInstr(r0)
    //     0x8f4b5c: ldur            x4, [x0, #-1]
    //     0x8f4b60: ubfx            x4, x4, #0xc, #0x14
    // 0x8f4b64: cmp             x4, #0x4d
    // 0x8f4b68: b.eq            #0x8f4b90
    // 0x8f4b6c: cmp             x4, #0x443
    // 0x8f4b70: b.eq            #0x8f4b90
    // 0x8f4b74: r17 = 7620
    //     0x8f4b74: mov             x17, #0x1dc4
    // 0x8f4b78: cmp             x4, x17
    // 0x8f4b7c: b.eq            #0x8f4b90
    // 0x8f4b80: r8 = StackTrace?
    //     0x8f4b80: ldr             x8, [PP, #0x3798]  ; [pp+0x3798] Type: StackTrace?
    // 0x8f4b84: r3 = Null
    //     0x8f4b84: add             x3, PP, #0x16, lsl #12  ; [pp+0x163c0] Null
    //     0x8f4b88: ldr             x3, [x3, #0x3c0]
    // 0x8f4b8c: r0 = DefaultNullableTypeTest()
    //     0x8f4b8c: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0x8f4b90: ldr             x16, [fp, #0x10]
    // 0x8f4b94: str             x16, [SP]
    // 0x8f4b98: ldur            x1, [fp, #-8]
    // 0x8f4b9c: ldr             x2, [fp, #0x18]
    // 0x8f4ba0: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x8f4ba0: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x8f4ba4: r0 = _extension#0.addErrorAndClose()
    //     0x8f4ba4: bl              #0x8f4bc0  ; [package:dio/src/response/response_stream_handler.dart] ::_extension#0.addErrorAndClose
    // 0x8f4ba8: r0 = Null
    //     0x8f4ba8: mov             x0, NULL
    // 0x8f4bac: LeaveFrame
    //     0x8f4bac: mov             SP, fp
    //     0x8f4bb0: ldp             fp, lr, [SP], #0x10
    // 0x8f4bb4: ret
    //     0x8f4bb4: ret             
    // 0x8f4bb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f4bb8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f4bbc: b               #0x8f4aa8
  }
  static _ _extension#0.addErrorAndClose(/* No info */) {
    // ** addr: 0x8f4bc0, size: 0x78
    // 0x8f4bc0: EnterFrame
    //     0x8f4bc0: stp             fp, lr, [SP, #-0x10]!
    //     0x8f4bc4: mov             fp, SP
    // 0x8f4bc8: AllocStack(0x10)
    //     0x8f4bc8: sub             SP, SP, #0x10
    // 0x8f4bcc: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */, [dynamic _ = Null /* r1 */])
    //     0x8f4bcc: mov             x0, x1
    //     0x8f4bd0: stur            x1, [fp, #-8]
    //     0x8f4bd4: ldur            w1, [x4, #0x13]
    //     0x8f4bd8: sub             x3, x1, #4
    //     0x8f4bdc: cmp             w3, #2
    //     0x8f4be0: b.lt            #0x8f4bf0
    //     0x8f4be4: add             x1, fp, w3, sxtw #2
    //     0x8f4be8: ldr             x1, [x1, #8]
    //     0x8f4bec: b               #0x8f4bf4
    //     0x8f4bf0: mov             x1, NULL
    // 0x8f4bf4: CheckStackOverflow
    //     0x8f4bf4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f4bf8: cmp             SP, x16
    //     0x8f4bfc: b.ls            #0x8f4c30
    // 0x8f4c00: LoadField: r3 = r0->field_f
    //     0x8f4c00: ldur            x3, [x0, #0xf]
    // 0x8f4c04: tbnz            w3, #2, #0x8f4c20
    // 0x8f4c08: str             x1, [SP]
    // 0x8f4c0c: mov             x1, x0
    // 0x8f4c10: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x8f4c10: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x8f4c14: r0 = addError()
    //     0x8f4c14: bl              #0x828cfc  ; [dart:async] _StreamController::addError
    // 0x8f4c18: ldur            x1, [fp, #-8]
    // 0x8f4c1c: r0 = close()
    //     0x8f4c1c: bl              #0x811f40  ; [dart:async] _StreamController::close
    // 0x8f4c20: r0 = Null
    //     0x8f4c20: mov             x0, NULL
    // 0x8f4c24: LeaveFrame
    //     0x8f4c24: mov             SP, fp
    //     0x8f4c28: ldp             fp, lr, [SP], #0x10
    // 0x8f4c2c: ret
    //     0x8f4c2c: ret             
    // 0x8f4c30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f4c30: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f4c34: b               #0x8f4c00
  }
  [closure] static void <anonymous closure>(dynamic, Uint8List) {
    // ** addr: 0x8f4c38, size: 0x14c
    // 0x8f4c38: EnterFrame
    //     0x8f4c38: stp             fp, lr, [SP, #-0x10]!
    //     0x8f4c3c: mov             fp, SP
    // 0x8f4c40: AllocStack(0x20)
    //     0x8f4c40: sub             SP, SP, #0x20
    // 0x8f4c44: SetupParameters([dynamic _ /* r0 */])
    //     0x8f4c44: ldr             x0, [fp, #0x18]
    //     0x8f4c48: ldur            w1, [x0, #0x17]
    //     0x8f4c4c: add             x1, x1, HEAP, lsl #32
    //     0x8f4c50: stur            x1, [fp, #-8]
    // 0x8f4c54: CheckStackOverflow
    //     0x8f4c54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f4c58: cmp             SP, x16
    //     0x8f4c5c: b.ls            #0x8f4d7c
    // 0x8f4c60: LoadField: r0 = r1->field_37
    //     0x8f4c60: ldur            w0, [x1, #0x37]
    // 0x8f4c64: DecompressPointer r0
    //     0x8f4c64: add             x0, x0, HEAP, lsl #32
    // 0x8f4c68: str             x0, [SP]
    // 0x8f4c6c: ClosureCall
    //     0x8f4c6c: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x8f4c70: ldur            x2, [x0, #0x1f]
    //     0x8f4c74: blr             x2
    // 0x8f4c78: ldur            x0, [fp, #-8]
    // 0x8f4c7c: LoadField: r1 = r0->field_2b
    //     0x8f4c7c: ldur            w1, [x0, #0x2b]
    // 0x8f4c80: DecompressPointer r1
    //     0x8f4c80: add             x1, x1, HEAP, lsl #32
    // 0x8f4c84: r0 = elapsedMicroseconds()
    //     0x8f4c84: bl              #0x82abac  ; [dart:core] Stopwatch::elapsedMicroseconds
    // 0x8f4c88: mov             x1, x0
    // 0x8f4c8c: ldur            x0, [fp, #-8]
    // 0x8f4c90: LoadField: r2 = r0->field_27
    //     0x8f4c90: ldur            w2, [x0, #0x27]
    // 0x8f4c94: DecompressPointer r2
    //     0x8f4c94: add             x2, x2, HEAP, lsl #32
    // 0x8f4c98: LoadField: r3 = r2->field_7
    //     0x8f4c98: ldur            x3, [x2, #7]
    // 0x8f4c9c: cmp             x1, x3
    // 0x8f4ca0: b.gt            #0x8f4d58
    // 0x8f4ca4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8f4ca4: ldur            w1, [x0, #0x17]
    // 0x8f4ca8: DecompressPointer r1
    //     0x8f4ca8: add             x1, x1, HEAP, lsl #32
    // 0x8f4cac: ldr             x2, [fp, #0x10]
    // 0x8f4cb0: r0 = add()
    //     0x8f4cb0: bl              #0x8014f8  ; [dart:async] _StreamController::add
    // 0x8f4cb4: ldur            x2, [fp, #-8]
    // 0x8f4cb8: LoadField: r0 = r2->field_f
    //     0x8f4cb8: ldur            w0, [x2, #0xf]
    // 0x8f4cbc: DecompressPointer r0
    //     0x8f4cbc: add             x0, x0, HEAP, lsl #32
    // 0x8f4cc0: LoadField: r3 = r0->field_67
    //     0x8f4cc0: ldur            w3, [x0, #0x67]
    // 0x8f4cc4: DecompressPointer r3
    //     0x8f4cc4: add             x3, x3, HEAP, lsl #32
    // 0x8f4cc8: cmp             w3, NULL
    // 0x8f4ccc: b.eq            #0x8f4d58
    // 0x8f4cd0: ldr             x0, [fp, #0x10]
    // 0x8f4cd4: LoadField: r1 = r2->field_23
    //     0x8f4cd4: ldur            w1, [x2, #0x23]
    // 0x8f4cd8: DecompressPointer r1
    //     0x8f4cd8: add             x1, x1, HEAP, lsl #32
    // 0x8f4cdc: LoadField: r4 = r0->field_13
    //     0x8f4cdc: ldur            w4, [x0, #0x13]
    // 0x8f4ce0: r0 = LoadInt32Instr(r1)
    //     0x8f4ce0: sbfx            x0, x1, #1, #0x1f
    //     0x8f4ce4: tbz             w1, #0, #0x8f4cec
    //     0x8f4ce8: ldur            x0, [x1, #7]
    // 0x8f4cec: r1 = LoadInt32Instr(r4)
    //     0x8f4cec: sbfx            x1, x4, #1, #0x1f
    // 0x8f4cf0: add             x4, x0, x1
    // 0x8f4cf4: r0 = BoxInt64Instr(r4)
    //     0x8f4cf4: sbfiz           x0, x4, #1, #0x1f
    //     0x8f4cf8: cmp             x4, x0, asr #1
    //     0x8f4cfc: b.eq            #0x8f4d08
    //     0x8f4d00: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8f4d04: stur            x4, [x0, #7]
    // 0x8f4d08: mov             x1, x0
    // 0x8f4d0c: StoreField: r2->field_23 = r0
    //     0x8f4d0c: stur            w0, [x2, #0x23]
    //     0x8f4d10: tbz             w0, #0, #0x8f4d2c
    //     0x8f4d14: ldurb           w16, [x2, #-1]
    //     0x8f4d18: ldurb           w17, [x0, #-1]
    //     0x8f4d1c: and             x16, x17, x16, lsr #2
    //     0x8f4d20: tst             x16, HEAP, lsr #32
    //     0x8f4d24: b.eq            #0x8f4d2c
    //     0x8f4d28: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x8f4d2c: LoadField: r0 = r2->field_1f
    //     0x8f4d2c: ldur            w0, [x2, #0x1f]
    // 0x8f4d30: DecompressPointer r0
    //     0x8f4d30: add             x0, x0, HEAP, lsl #32
    // 0x8f4d34: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8f4d38: cmp             w0, w16
    // 0x8f4d3c: b.eq            #0x8f4d68
    // 0x8f4d40: stp             x1, x3, [SP, #8]
    // 0x8f4d44: str             x0, [SP]
    // 0x8f4d48: mov             x0, x3
    // 0x8f4d4c: ClosureCall
    //     0x8f4d4c: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x8f4d50: ldur            x2, [x0, #0x1f]
    //     0x8f4d54: blr             x2
    // 0x8f4d58: r0 = Null
    //     0x8f4d58: mov             x0, NULL
    // 0x8f4d5c: LeaveFrame
    //     0x8f4d5c: mov             SP, fp
    //     0x8f4d60: ldp             fp, lr, [SP], #0x10
    // 0x8f4d64: ret
    //     0x8f4d64: ret             
    // 0x8f4d68: r16 = "totalLength"
    //     0x8f4d68: add             x16, PP, #0x16, lsl #12  ; [pp+0x163d0] "totalLength"
    //     0x8f4d6c: ldr             x16, [x16, #0x3d0]
    // 0x8f4d70: str             x16, [SP]
    // 0x8f4d74: r0 = _throwLocalNotInitialized()
    //     0x8f4d74: bl              #0x82b57c  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0x8f4d78: brk             #0
    // 0x8f4d7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f4d7c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f4d80: b               #0x8f4c60
  }
  [closure] static void watchReceiveTimeout(dynamic) {
    // ** addr: 0x8f4d84, size: 0xdc
    // 0x8f4d84: EnterFrame
    //     0x8f4d84: stp             fp, lr, [SP, #-0x10]!
    //     0x8f4d88: mov             fp, SP
    // 0x8f4d8c: AllocStack(0x18)
    //     0x8f4d8c: sub             SP, SP, #0x18
    // 0x8f4d90: SetupParameters([dynamic _ /* r0 */])
    //     0x8f4d90: ldr             x0, [fp, #0x10]
    //     0x8f4d94: ldur            w2, [x0, #0x17]
    //     0x8f4d98: add             x2, x2, HEAP, lsl #32
    //     0x8f4d9c: stur            x2, [fp, #-0x10]
    // 0x8f4da0: CheckStackOverflow
    //     0x8f4da0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f4da4: cmp             SP, x16
    //     0x8f4da8: b.ls            #0x8f4e58
    // 0x8f4dac: LoadField: r0 = r2->field_27
    //     0x8f4dac: ldur            w0, [x2, #0x27]
    // 0x8f4db0: DecompressPointer r0
    //     0x8f4db0: add             x0, x0, HEAP, lsl #32
    // 0x8f4db4: stur            x0, [fp, #-8]
    // 0x8f4db8: LoadField: r1 = r0->field_7
    //     0x8f4db8: ldur            x1, [x0, #7]
    // 0x8f4dbc: cmp             x1, #0
    // 0x8f4dc0: b.gt            #0x8f4dd4
    // 0x8f4dc4: r0 = Null
    //     0x8f4dc4: mov             x0, NULL
    // 0x8f4dc8: LeaveFrame
    //     0x8f4dc8: mov             SP, fp
    //     0x8f4dcc: ldp             fp, lr, [SP], #0x10
    // 0x8f4dd0: ret
    //     0x8f4dd0: ret             
    // 0x8f4dd4: LoadField: r1 = r2->field_2f
    //     0x8f4dd4: ldur            w1, [x2, #0x2f]
    // 0x8f4dd8: DecompressPointer r1
    //     0x8f4dd8: add             x1, x1, HEAP, lsl #32
    // 0x8f4ddc: cmp             w1, NULL
    // 0x8f4de0: b.eq            #0x8f4dec
    // 0x8f4de4: r0 = cancel()
    //     0x8f4de4: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0x8f4de8: ldur            x2, [fp, #-0x10]
    // 0x8f4dec: LoadField: r0 = r2->field_2b
    //     0x8f4dec: ldur            w0, [x2, #0x2b]
    // 0x8f4df0: DecompressPointer r0
    //     0x8f4df0: add             x0, x0, HEAP, lsl #32
    // 0x8f4df4: mov             x1, x0
    // 0x8f4df8: stur            x0, [fp, #-0x18]
    // 0x8f4dfc: r0 = reset()
    //     0x8f4dfc: bl              #0x82aa8c  ; [dart:core] Stopwatch::reset
    // 0x8f4e00: ldur            x1, [fp, #-0x18]
    // 0x8f4e04: r0 = start()
    //     0x8f4e04: bl              #0x82a468  ; [dart:core] Stopwatch::start
    // 0x8f4e08: ldur            x2, [fp, #-0x10]
    // 0x8f4e0c: r1 = Function '<anonymous closure>': static.
    //     0x8f4e0c: add             x1, PP, #0x16, lsl #12  ; [pp+0x163d8] AnonymousClosure: static (0x8f4e60), in [package:dio/src/response/response_stream_handler.dart] ::handleResponseStream (0x8f45fc)
    //     0x8f4e10: ldr             x1, [x1, #0x3d8]
    // 0x8f4e14: r0 = AllocateClosure()
    //     0x8f4e14: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8f4e18: ldur            x2, [fp, #-8]
    // 0x8f4e1c: mov             x3, x0
    // 0x8f4e20: r1 = Null
    //     0x8f4e20: mov             x1, NULL
    // 0x8f4e24: r0 = Timer()
    //     0x8f4e24: bl              #0x7eed74  ; [dart:async] Timer::Timer
    // 0x8f4e28: ldur            x1, [fp, #-0x10]
    // 0x8f4e2c: StoreField: r1->field_2f = r0
    //     0x8f4e2c: stur            w0, [x1, #0x2f]
    //     0x8f4e30: ldurb           w16, [x1, #-1]
    //     0x8f4e34: ldurb           w17, [x0, #-1]
    //     0x8f4e38: and             x16, x17, x16, lsr #2
    //     0x8f4e3c: tst             x16, HEAP, lsr #32
    //     0x8f4e40: b.eq            #0x8f4e48
    //     0x8f4e44: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8f4e48: r0 = Null
    //     0x8f4e48: mov             x0, NULL
    // 0x8f4e4c: LeaveFrame
    //     0x8f4e4c: mov             SP, fp
    //     0x8f4e50: ldp             fp, lr, [SP], #0x10
    // 0x8f4e54: ret
    //     0x8f4e54: ret             
    // 0x8f4e58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f4e58: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f4e5c: b               #0x8f4dac
  }
  [closure] static void <anonymous closure>(dynamic) {
    // ** addr: 0x8f4e60, size: 0x114
    // 0x8f4e60: EnterFrame
    //     0x8f4e60: stp             fp, lr, [SP, #-0x10]!
    //     0x8f4e64: mov             fp, SP
    // 0x8f4e68: AllocStack(0x20)
    //     0x8f4e68: sub             SP, SP, #0x20
    // 0x8f4e6c: SetupParameters([dynamic _ /* r0 */])
    //     0x8f4e6c: ldr             x0, [fp, #0x10]
    //     0x8f4e70: ldur            w2, [x0, #0x17]
    //     0x8f4e74: add             x2, x2, HEAP, lsl #32
    //     0x8f4e78: stur            x2, [fp, #-0x10]
    // 0x8f4e7c: CheckStackOverflow
    //     0x8f4e7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f4e80: cmp             SP, x16
    //     0x8f4e84: b.ls            #0x8f4f6c
    // 0x8f4e88: LoadField: r0 = r2->field_33
    //     0x8f4e88: ldur            w0, [x2, #0x33]
    // 0x8f4e8c: DecompressPointer r0
    //     0x8f4e8c: add             x0, x0, HEAP, lsl #32
    // 0x8f4e90: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x8f4e90: ldur            w3, [x0, #0x17]
    // 0x8f4e94: DecompressPointer r3
    //     0x8f4e94: add             x3, x3, HEAP, lsl #32
    // 0x8f4e98: stur            x3, [fp, #-8]
    // 0x8f4e9c: LoadField: r1 = r3->field_2f
    //     0x8f4e9c: ldur            w1, [x3, #0x2f]
    // 0x8f4ea0: DecompressPointer r1
    //     0x8f4ea0: add             x1, x1, HEAP, lsl #32
    // 0x8f4ea4: cmp             w1, NULL
    // 0x8f4ea8: b.ne            #0x8f4eb8
    // 0x8f4eac: mov             x0, x2
    // 0x8f4eb0: mov             x1, x3
    // 0x8f4eb4: b               #0x8f4ec4
    // 0x8f4eb8: r0 = cancel()
    //     0x8f4eb8: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0x8f4ebc: ldur            x0, [fp, #-0x10]
    // 0x8f4ec0: ldur            x1, [fp, #-8]
    // 0x8f4ec4: StoreField: r1->field_2f = rNULL
    //     0x8f4ec4: stur            NULL, [x1, #0x2f]
    // 0x8f4ec8: LoadField: r2 = r1->field_2b
    //     0x8f4ec8: ldur            w2, [x1, #0x2b]
    // 0x8f4ecc: DecompressPointer r2
    //     0x8f4ecc: add             x2, x2, HEAP, lsl #32
    // 0x8f4ed0: mov             x1, x2
    // 0x8f4ed4: stur            x2, [fp, #-0x18]
    // 0x8f4ed8: r0 = stop()
    //     0x8f4ed8: bl              #0x82ab00  ; [dart:core] Stopwatch::stop
    // 0x8f4edc: ldur            x1, [fp, #-0x18]
    // 0x8f4ee0: r0 = reset()
    //     0x8f4ee0: bl              #0x82aa8c  ; [dart:core] Stopwatch::reset
    // 0x8f4ee4: ldur            x2, [fp, #-0x10]
    // 0x8f4ee8: LoadField: r1 = r2->field_1b
    //     0x8f4ee8: ldur            w1, [x2, #0x1b]
    // 0x8f4eec: DecompressPointer r1
    //     0x8f4eec: add             x1, x1, HEAP, lsl #32
    // 0x8f4ef0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8f4ef4: cmp             w1, w16
    // 0x8f4ef8: b.eq            #0x8f4f58
    // 0x8f4efc: r0 = LoadClassIdInstr(r1)
    //     0x8f4efc: ldur            x0, [x1, #-1]
    //     0x8f4f00: ubfx            x0, x0, #0xc, #0x14
    // 0x8f4f04: r0 = GDT[cid_x0 + 0x549]()
    //     0x8f4f04: add             lr, x0, #0x549
    //     0x8f4f08: ldr             lr, [x21, lr, lsl #3]
    //     0x8f4f0c: blr             lr
    // 0x8f4f10: ldur            x0, [fp, #-0x10]
    // 0x8f4f14: ArrayLoad: r4 = r0[0]  ; List_4
    //     0x8f4f14: ldur            w4, [x0, #0x17]
    // 0x8f4f18: DecompressPointer r4
    //     0x8f4f18: add             x4, x4, HEAP, lsl #32
    // 0x8f4f1c: stur            x4, [fp, #-8]
    // 0x8f4f20: LoadField: r2 = r0->field_f
    //     0x8f4f20: ldur            w2, [x0, #0xf]
    // 0x8f4f24: DecompressPointer r2
    //     0x8f4f24: add             x2, x2, HEAP, lsl #32
    // 0x8f4f28: LoadField: r3 = r0->field_27
    //     0x8f4f28: ldur            w3, [x0, #0x27]
    // 0x8f4f2c: DecompressPointer r3
    //     0x8f4f2c: add             x3, x3, HEAP, lsl #32
    // 0x8f4f30: r1 = Null
    //     0x8f4f30: mov             x1, NULL
    // 0x8f4f34: r0 = DioException.receiveTimeout()
    //     0x8f4f34: bl              #0x8f4f74  ; [package:dio/src/dio_exception.dart] DioException::DioException.receiveTimeout
    // 0x8f4f38: ldur            x1, [fp, #-8]
    // 0x8f4f3c: mov             x2, x0
    // 0x8f4f40: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8f4f40: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8f4f44: r0 = _extension#0.addErrorAndClose()
    //     0x8f4f44: bl              #0x8f4bc0  ; [package:dio/src/response/response_stream_handler.dart] ::_extension#0.addErrorAndClose
    // 0x8f4f48: r0 = Null
    //     0x8f4f48: mov             x0, NULL
    // 0x8f4f4c: LeaveFrame
    //     0x8f4f4c: mov             SP, fp
    //     0x8f4f50: ldp             fp, lr, [SP], #0x10
    // 0x8f4f54: ret
    //     0x8f4f54: ret             
    // 0x8f4f58: r16 = "responseSubscription"
    //     0x8f4f58: add             x16, PP, #0x16, lsl #12  ; [pp+0x163a8] "responseSubscription"
    //     0x8f4f5c: ldr             x16, [x16, #0x3a8]
    // 0x8f4f60: str             x16, [SP]
    // 0x8f4f64: r0 = _throwLocalNotInitialized()
    //     0x8f4f64: bl              #0x82b57c  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0x8f4f68: brk             #0
    // 0x8f4f6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f4f6c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f4f70: b               #0x8f4e88
  }
  [closure] static void stopWatchReceiveTimeout(dynamic) {
    // ** addr: 0x8f5028, size: 0x80
    // 0x8f5028: EnterFrame
    //     0x8f5028: stp             fp, lr, [SP, #-0x10]!
    //     0x8f502c: mov             fp, SP
    // 0x8f5030: AllocStack(0x10)
    //     0x8f5030: sub             SP, SP, #0x10
    // 0x8f5034: SetupParameters([dynamic _ /* r0 */])
    //     0x8f5034: ldr             x0, [fp, #0x10]
    //     0x8f5038: ldur            w2, [x0, #0x17]
    //     0x8f503c: add             x2, x2, HEAP, lsl #32
    //     0x8f5040: stur            x2, [fp, #-8]
    // 0x8f5044: CheckStackOverflow
    //     0x8f5044: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f5048: cmp             SP, x16
    //     0x8f504c: b.ls            #0x8f50a0
    // 0x8f5050: LoadField: r1 = r2->field_2f
    //     0x8f5050: ldur            w1, [x2, #0x2f]
    // 0x8f5054: DecompressPointer r1
    //     0x8f5054: add             x1, x1, HEAP, lsl #32
    // 0x8f5058: cmp             w1, NULL
    // 0x8f505c: b.ne            #0x8f5068
    // 0x8f5060: mov             x0, x2
    // 0x8f5064: b               #0x8f5070
    // 0x8f5068: r0 = cancel()
    //     0x8f5068: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0x8f506c: ldur            x0, [fp, #-8]
    // 0x8f5070: StoreField: r0->field_2f = rNULL
    //     0x8f5070: stur            NULL, [x0, #0x2f]
    // 0x8f5074: LoadField: r2 = r0->field_2b
    //     0x8f5074: ldur            w2, [x0, #0x2b]
    // 0x8f5078: DecompressPointer r2
    //     0x8f5078: add             x2, x2, HEAP, lsl #32
    // 0x8f507c: mov             x1, x2
    // 0x8f5080: stur            x2, [fp, #-0x10]
    // 0x8f5084: r0 = stop()
    //     0x8f5084: bl              #0x82ab00  ; [dart:core] Stopwatch::stop
    // 0x8f5088: ldur            x1, [fp, #-0x10]
    // 0x8f508c: r0 = reset()
    //     0x8f508c: bl              #0x82aa8c  ; [dart:core] Stopwatch::reset
    // 0x8f5090: r0 = Null
    //     0x8f5090: mov             x0, NULL
    // 0x8f5094: LeaveFrame
    //     0x8f5094: mov             SP, fp
    //     0x8f5098: ldp             fp, lr, [SP], #0x10
    // 0x8f509c: ret
    //     0x8f509c: ret             
    // 0x8f50a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f50a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f50a4: b               #0x8f5050
  }
}
