// lib: , url: package:firebase_crashlytics/src/utils.dart

// class id: 1048748, size: 0x8
class :: {

  static late final RegExp _obfuscatedStackTraceLineRegExp; // offset: 0x10bc

  static _ getLoadingUnits(/* No info */) {
    // ** addr: 0x8e5e58, size: 0x104
    // 0x8e5e58: EnterFrame
    //     0x8e5e58: stp             fp, lr, [SP, #-0x10]!
    //     0x8e5e5c: mov             fp, SP
    // 0x8e5e60: AllocStack(0x30)
    //     0x8e5e60: sub             SP, SP, #0x30
    // 0x8e5e64: CheckStackOverflow
    //     0x8e5e64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8e5e68: cmp             SP, x16
    //     0x8e5e6c: b.ls            #0x8e5f54
    // 0x8e5e70: r0 = LoadClassIdInstr(r1)
    //     0x8e5e70: ldur            x0, [x1, #-1]
    //     0x8e5e74: ubfx            x0, x0, #0xc, #0x14
    // 0x8e5e78: str             x1, [SP]
    // 0x8e5e7c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8e5e7c: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8e5e80: r0 = GDT[cid_x0 + 0x91c1]()
    //     0x8e5e80: mov             x17, #0x91c1
    //     0x8e5e84: add             lr, x0, x17
    //     0x8e5e88: ldr             lr, [x21, lr, lsl #3]
    //     0x8e5e8c: blr             lr
    // 0x8e5e90: mov             x1, x0
    // 0x8e5e94: stur            x0, [fp, #-8]
    // 0x8e5e98: r0 = _parseVM()
    //     0x8e5e98: bl              #0x8e690c  ; [package:stack_trace/src/trace.dart] Trace::_parseVM
    // 0x8e5e9c: mov             x2, x0
    // 0x8e5ea0: r1 = <Frame>
    //     0x8e5ea0: ldr             x1, [PP, #0x7b18]  ; [pp+0x7b18] TypeArguments: <Frame>
    // 0x8e5ea4: r0 = List.unmodifiable()
    //     0x8e5ea4: bl              #0x8c5220  ; [dart:core] List::List.unmodifiable
    // 0x8e5ea8: stur            x0, [fp, #-0x10]
    // 0x8e5eac: r0 = Trace()
    //     0x8e5eac: bl              #0x8e6900  ; AllocateTraceStub -> Trace (size=0x10)
    // 0x8e5eb0: mov             x1, x0
    // 0x8e5eb4: ldur            x0, [fp, #-0x10]
    // 0x8e5eb8: stur            x1, [fp, #-0x18]
    // 0x8e5ebc: StoreField: r1->field_7 = r0
    //     0x8e5ebc: stur            w0, [x1, #7]
    // 0x8e5ec0: r0 = _StringStackTrace()
    //     0x8e5ec0: bl              #0x84809c  ; Allocate_StringStackTraceStub -> _StringStackTrace (size=0xc)
    // 0x8e5ec4: mov             x1, x0
    // 0x8e5ec8: ldur            x0, [fp, #-8]
    // 0x8e5ecc: StoreField: r1->field_7 = r0
    //     0x8e5ecc: stur            w0, [x1, #7]
    // 0x8e5ed0: ldur            x0, [fp, #-0x18]
    // 0x8e5ed4: StoreField: r0->field_b = r1
    //     0x8e5ed4: stur            w1, [x0, #0xb]
    // 0x8e5ed8: mov             x1, x0
    // 0x8e5edc: r0 = terse()
    //     0x8e5edc: bl              #0x8e5f5c  ; [package:stack_trace/src/trace.dart] Trace::terse
    // 0x8e5ee0: LoadField: r1 = r0->field_7
    //     0x8e5ee0: ldur            w1, [x0, #7]
    // 0x8e5ee4: DecompressPointer r1
    //     0x8e5ee4: add             x1, x1, HEAP, lsl #32
    // 0x8e5ee8: r16 = <UnparsedFrame>
    //     0x8e5ee8: ldr             x16, [PP, #0x7b20]  ; [pp+0x7b20] TypeArguments: <UnparsedFrame>
    // 0x8e5eec: stp             x1, x16, [SP]
    // 0x8e5ef0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8e5ef0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8e5ef4: r0 = whereType()
    //     0x8e5ef4: bl              #0xbfff48  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::whereType
    // 0x8e5ef8: r1 = Function '<anonymous closure>': static.
    //     0x8e5ef8: ldr             x1, [PP, #0x7b28]  ; [pp+0x7b28] AnonymousClosure: static (0x1123f54), in [package:firebase_crashlytics/src/utils.dart] ::getLoadingUnits (0x8e5e58)
    // 0x8e5efc: r2 = Null
    //     0x8e5efc: mov             x2, NULL
    // 0x8e5f00: stur            x0, [fp, #-8]
    // 0x8e5f04: r0 = AllocateClosure()
    //     0x8e5f04: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8e5f08: r16 = <String>
    //     0x8e5f08: ldr             x16, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    // 0x8e5f0c: ldur            lr, [fp, #-8]
    // 0x8e5f10: stp             lr, x16, [SP, #8]
    // 0x8e5f14: str             x0, [SP]
    // 0x8e5f18: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8e5f18: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8e5f1c: r0 = map()
    //     0x8e5f1c: bl              #0xb007e4  ; [dart:core] Iterable::map
    // 0x8e5f20: r1 = Function '<anonymous closure>': static.
    //     0x8e5f20: ldr             x1, [PP, #0x7b30]  ; [pp+0x7b30] AnonymousClosure: static (0x8e7654), in [package:firebase_crashlytics/src/utils.dart] ::getLoadingUnits (0x8e5e58)
    // 0x8e5f24: r2 = Null
    //     0x8e5f24: mov             x2, NULL
    // 0x8e5f28: stur            x0, [fp, #-8]
    // 0x8e5f2c: r0 = AllocateClosure()
    //     0x8e5f2c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8e5f30: ldur            x1, [fp, #-8]
    // 0x8e5f34: mov             x2, x0
    // 0x8e5f38: r0 = where()
    //     0x8e5f38: bl              #0xb92e4c  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::where
    // 0x8e5f3c: mov             x1, x0
    // 0x8e5f40: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8e5f40: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8e5f44: r0 = toList()
    //     0x8e5f44: bl              #0xb08ca4  ; [dart:core] Iterable::toList
    // 0x8e5f48: LeaveFrame
    //     0x8e5f48: mov             SP, fp
    //     0x8e5f4c: ldp             fp, lr, [SP], #0x10
    // 0x8e5f50: ret
    //     0x8e5f50: ret             
    // 0x8e5f54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8e5f54: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8e5f58: b               #0x8e5e70
  }
  [closure] static bool <anonymous closure>(dynamic, String) {
    // ** addr: 0x8e7654, size: 0x38
    // 0x8e7654: EnterFrame
    //     0x8e7654: stp             fp, lr, [SP, #-0x10]!
    //     0x8e7658: mov             fp, SP
    // 0x8e765c: CheckStackOverflow
    //     0x8e765c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8e7660: cmp             SP, x16
    //     0x8e7664: b.ls            #0x8e7684
    // 0x8e7668: ldr             x1, [fp, #0x10]
    // 0x8e766c: r2 = "loading_unit: "
    //     0x8e766c: ldr             x2, [PP, #0x7b38]  ; [pp+0x7b38] "loading_unit: "
    // 0x8e7670: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8e7670: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8e7674: r0 = startsWith()
    //     0x8e7674: bl              #0x7ea4f0  ; [dart:core] _StringBase::startsWith
    // 0x8e7678: LeaveFrame
    //     0x8e7678: mov             SP, fp
    //     0x8e767c: ldp             fp, lr, [SP], #0x10
    // 0x8e7680: ret
    //     0x8e7680: ret             
    // 0x8e7684: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8e7684: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8e7688: b               #0x8e7668
  }
  static _ getBuildId(/* No info */) {
    // ** addr: 0x8e768c, size: 0x1e0
    // 0x8e768c: EnterFrame
    //     0x8e768c: stp             fp, lr, [SP, #-0x10]!
    //     0x8e7690: mov             fp, SP
    // 0x8e7694: AllocStack(0x58)
    //     0x8e7694: sub             SP, SP, #0x58
    // 0x8e7698: CheckStackOverflow
    //     0x8e7698: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8e769c: cmp             SP, x16
    //     0x8e76a0: b.ls            #0x8e785c
    // 0x8e76a4: r0 = LoadClassIdInstr(r1)
    //     0x8e76a4: ldur            x0, [x1, #-1]
    //     0x8e76a8: ubfx            x0, x0, #0xc, #0x14
    // 0x8e76ac: str             x1, [SP]
    // 0x8e76b0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8e76b0: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8e76b4: r0 = GDT[cid_x0 + 0x91c1]()
    //     0x8e76b4: mov             x17, #0x91c1
    //     0x8e76b8: add             lr, x0, x17
    //     0x8e76bc: ldr             lr, [x21, lr, lsl #3]
    //     0x8e76c0: blr             lr
    // 0x8e76c4: mov             x1, x0
    // 0x8e76c8: stur            x0, [fp, #-8]
    // 0x8e76cc: r0 = _parseVM()
    //     0x8e76cc: bl              #0x8e690c  ; [package:stack_trace/src/trace.dart] Trace::_parseVM
    // 0x8e76d0: r16 = false
    //     0x8e76d0: add             x16, NULL, #0x30  ; false
    // 0x8e76d4: str             x16, [SP]
    // 0x8e76d8: mov             x2, x0
    // 0x8e76dc: r1 = <Frame>
    //     0x8e76dc: ldr             x1, [PP, #0x7b18]  ; [pp+0x7b18] TypeArguments: <Frame>
    // 0x8e76e0: r4 = const [0, 0x3, 0x1, 0x2, growable, 0x2, null]
    //     0x8e76e0: ldr             x4, [PP, #0x7ba0]  ; [pp+0x7ba0] List(7) [0, 0x3, 0x1, 0x2, "growable", 0x2, Null]
    // 0x8e76e4: r0 = List.from()
    //     0x8e76e4: bl              #0x876494  ; [dart:core] List::List.from
    // 0x8e76e8: r16 = <Frame>
    //     0x8e76e8: ldr             x16, [PP, #0x7b18]  ; [pp+0x7b18] TypeArguments: <Frame>
    // 0x8e76ec: stp             x0, x16, [SP]
    // 0x8e76f0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8e76f0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8e76f4: r0 = makeFixedListUnmodifiable()
    //     0x8e76f4: bl              #0x8c63c0  ; [dart:_internal] ::makeFixedListUnmodifiable
    // 0x8e76f8: stur            x0, [fp, #-0x10]
    // 0x8e76fc: r0 = Trace()
    //     0x8e76fc: bl              #0x8e6900  ; AllocateTraceStub -> Trace (size=0x10)
    // 0x8e7700: mov             x1, x0
    // 0x8e7704: ldur            x0, [fp, #-0x10]
    // 0x8e7708: stur            x1, [fp, #-0x18]
    // 0x8e770c: StoreField: r1->field_7 = r0
    //     0x8e770c: stur            w0, [x1, #7]
    // 0x8e7710: r0 = _StringStackTrace()
    //     0x8e7710: bl              #0x84809c  ; Allocate_StringStackTraceStub -> _StringStackTrace (size=0xc)
    // 0x8e7714: mov             x1, x0
    // 0x8e7718: ldur            x0, [fp, #-8]
    // 0x8e771c: StoreField: r1->field_7 = r0
    //     0x8e771c: stur            w0, [x1, #7]
    // 0x8e7720: ldur            x0, [fp, #-0x18]
    // 0x8e7724: StoreField: r0->field_b = r1
    //     0x8e7724: stur            w1, [x0, #0xb]
    // 0x8e7728: r1 = Function '<anonymous closure>':.
    //     0x8e7728: ldr             x1, [PP, #0x7b40]  ; [pp+0x7b40] Function: [dart:core] Object::_simpleInstanceOfFalse (0x13dce48)
    // 0x8e772c: r2 = Null
    //     0x8e772c: mov             x2, NULL
    // 0x8e7730: r0 = AllocateClosure()
    //     0x8e7730: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8e7734: ldur            x1, [fp, #-0x18]
    // 0x8e7738: mov             x2, x0
    // 0x8e773c: r0 = foldFrames()
    //     0x8e773c: bl              #0x8e5fa8  ; [package:stack_trace/src/trace.dart] Trace::foldFrames
    // 0x8e7740: LoadField: r1 = r0->field_7
    //     0x8e7740: ldur            w1, [x0, #7]
    // 0x8e7744: DecompressPointer r1
    //     0x8e7744: add             x1, x1, HEAP, lsl #32
    // 0x8e7748: stur            x1, [fp, #-0x10]
    // 0x8e774c: LoadField: r0 = r1->field_b
    //     0x8e774c: ldur            w0, [x1, #0xb]
    // 0x8e7750: r2 = LoadInt32Instr(r0)
    //     0x8e7750: sbfx            x2, x0, #1, #0x1f
    // 0x8e7754: stur            x2, [fp, #-0x30]
    // 0x8e7758: r0 = 0
    //     0x8e7758: mov             x0, #0
    // 0x8e775c: CheckStackOverflow
    //     0x8e775c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8e7760: cmp             SP, x16
    //     0x8e7764: b.ls            #0x8e7864
    // 0x8e7768: cmp             x0, x2
    // 0x8e776c: b.ge            #0x8e7824
    // 0x8e7770: ArrayLoad: r3 = r1[r0]  ; Unknown_4
    //     0x8e7770: add             x16, x1, x0, lsl #2
    //     0x8e7774: ldur            w3, [x16, #0xf]
    // 0x8e7778: DecompressPointer r3
    //     0x8e7778: add             x3, x3, HEAP, lsl #32
    // 0x8e777c: add             x4, x0, #1
    // 0x8e7780: stur            x4, [fp, #-0x28]
    // 0x8e7784: r0 = LoadClassIdInstr(r3)
    //     0x8e7784: ldur            x0, [x3, #-1]
    //     0x8e7788: ubfx            x0, x0, #0xc, #0x14
    // 0x8e778c: cmp             x0, #0x442
    // 0x8e7790: b.ne            #0x8e7814
    // 0x8e7794: LoadField: r0 = r3->field_23
    //     0x8e7794: ldur            w0, [x3, #0x23]
    // 0x8e7798: DecompressPointer r0
    //     0x8e7798: add             x0, x0, HEAP, lsl #32
    // 0x8e779c: stur            x0, [fp, #-8]
    // 0x8e77a0: LoadField: r3 = r0->field_7
    //     0x8e77a0: ldur            w3, [x0, #7]
    // 0x8e77a4: stur            x3, [fp, #-0x38]
    // 0x8e77a8: r5 = LoadInt32Instr(r3)
    //     0x8e77a8: sbfx            x5, x3, #1, #0x1f
    // 0x8e77ac: stur            x5, [fp, #-0x20]
    // 0x8e77b0: tbnz            x5, #0x3f, #0x8e7834
    // 0x8e77b4: stp             xzr, x0, [SP, #8]
    // 0x8e77b8: r16 = "build_id: \'"
    //     0x8e77b8: ldr             x16, [PP, #0x7c60]  ; [pp+0x7c60] "build_id: \'"
    // 0x8e77bc: str             x16, [SP]
    // 0x8e77c0: r0 = _substringMatches()
    //     0x8e77c0: bl              #0x7ea6d8  ; [dart:core] _StringBase::_substringMatches
    // 0x8e77c4: tbnz            w0, #4, #0x8e7814
    // 0x8e77c8: ldur            x0, [fp, #-0x20]
    // 0x8e77cc: sub             x1, x0, #1
    // 0x8e77d0: lsl             x0, x1, #1
    // 0x8e77d4: stur            x0, [fp, #-0x18]
    // 0x8e77d8: ldur            x16, [fp, #-8]
    // 0x8e77dc: stp             x0, x16, [SP, #8]
    // 0x8e77e0: r16 = "\'"
    //     0x8e77e0: ldr             x16, [PP, #0x3900]  ; [pp+0x3900] "\'"
    // 0x8e77e4: str             x16, [SP]
    // 0x8e77e8: r0 = _substringMatches()
    //     0x8e77e8: bl              #0x7ea6d8  ; [dart:core] _StringBase::_substringMatches
    // 0x8e77ec: tbnz            w0, #4, #0x8e7814
    // 0x8e77f0: ldur            x16, [fp, #-0x18]
    // 0x8e77f4: str             x16, [SP]
    // 0x8e77f8: ldur            x1, [fp, #-8]
    // 0x8e77fc: r2 = 11
    //     0x8e77fc: mov             x2, #0xb
    // 0x8e7800: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x8e7800: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x8e7804: r0 = substring()
    //     0x8e7804: bl              #0x7e3f74  ; [dart:core] _StringBase::substring
    // 0x8e7808: LeaveFrame
    //     0x8e7808: mov             SP, fp
    //     0x8e780c: ldp             fp, lr, [SP], #0x10
    // 0x8e7810: ret
    //     0x8e7810: ret             
    // 0x8e7814: ldur            x0, [fp, #-0x28]
    // 0x8e7818: ldur            x1, [fp, #-0x10]
    // 0x8e781c: ldur            x2, [fp, #-0x30]
    // 0x8e7820: b               #0x8e775c
    // 0x8e7824: r0 = Null
    //     0x8e7824: mov             x0, NULL
    // 0x8e7828: LeaveFrame
    //     0x8e7828: mov             SP, fp
    //     0x8e782c: ldp             fp, lr, [SP], #0x10
    // 0x8e7830: ret
    //     0x8e7830: ret             
    // 0x8e7834: r0 = RangeError()
    //     0x8e7834: bl              #0x7db570  ; AllocateRangeErrorStub -> RangeError (size=0x24)
    // 0x8e7838: stur            x0, [fp, #-8]
    // 0x8e783c: stp             xzr, x0, [SP, #0x10]
    // 0x8e7840: ldur            x16, [fp, #-0x38]
    // 0x8e7844: stp             x16, xzr, [SP]
    // 0x8e7848: r4 = const [0, 0x4, 0x4, 0x4, null]
    //     0x8e7848: ldr             x4, [PP, #0x9d0]  ; [pp+0x9d0] List(5) [0, 0x4, 0x4, 0x4, Null]
    // 0x8e784c: r0 = RangeError.range()
    //     0x8e784c: bl              #0x7db3f0  ; [dart:core] RangeError::RangeError.range
    // 0x8e7850: ldur            x0, [fp, #-8]
    // 0x8e7854: r0 = Throw()
    //     0x8e7854: bl              #0x13ddb2c  ; ThrowStub
    // 0x8e7858: brk             #0
    // 0x8e785c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8e785c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8e7860: b               #0x8e76a4
    // 0x8e7864: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8e7864: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8e7868: b               #0x8e7768
  }
  static _ getStackTraceElements(/* No info */) {
    // ** addr: 0x8e786c, size: 0x548
    // 0x8e786c: EnterFrame
    //     0x8e786c: stp             fp, lr, [SP, #-0x10]!
    //     0x8e7870: mov             fp, SP
    // 0x8e7874: AllocStack(0x60)
    //     0x8e7874: sub             SP, SP, #0x60
    // 0x8e7878: CheckStackOverflow
    //     0x8e7878: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8e787c: cmp             SP, x16
    //     0x8e7880: b.ls            #0x8e7da0
    // 0x8e7884: r0 = LoadClassIdInstr(r1)
    //     0x8e7884: ldur            x0, [x1, #-1]
    //     0x8e7888: ubfx            x0, x0, #0xc, #0x14
    // 0x8e788c: str             x1, [SP]
    // 0x8e7890: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8e7890: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8e7894: r0 = GDT[cid_x0 + 0x91c1]()
    //     0x8e7894: mov             x17, #0x91c1
    //     0x8e7898: add             lr, x0, x17
    //     0x8e789c: ldr             lr, [x21, lr, lsl #3]
    //     0x8e78a0: blr             lr
    // 0x8e78a4: mov             x1, x0
    // 0x8e78a8: stur            x0, [fp, #-8]
    // 0x8e78ac: r0 = _parseVM()
    //     0x8e78ac: bl              #0x8e690c  ; [package:stack_trace/src/trace.dart] Trace::_parseVM
    // 0x8e78b0: r16 = false
    //     0x8e78b0: add             x16, NULL, #0x30  ; false
    // 0x8e78b4: str             x16, [SP]
    // 0x8e78b8: mov             x2, x0
    // 0x8e78bc: r1 = <Frame>
    //     0x8e78bc: ldr             x1, [PP, #0x7b18]  ; [pp+0x7b18] TypeArguments: <Frame>
    // 0x8e78c0: r4 = const [0, 0x3, 0x1, 0x2, growable, 0x2, null]
    //     0x8e78c0: ldr             x4, [PP, #0x7ba0]  ; [pp+0x7ba0] List(7) [0, 0x3, 0x1, 0x2, "growable", 0x2, Null]
    // 0x8e78c4: r0 = List.from()
    //     0x8e78c4: bl              #0x876494  ; [dart:core] List::List.from
    // 0x8e78c8: r16 = <Frame>
    //     0x8e78c8: ldr             x16, [PP, #0x7b18]  ; [pp+0x7b18] TypeArguments: <Frame>
    // 0x8e78cc: stp             x0, x16, [SP]
    // 0x8e78d0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8e78d0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8e78d4: r0 = makeFixedListUnmodifiable()
    //     0x8e78d4: bl              #0x8c63c0  ; [dart:_internal] ::makeFixedListUnmodifiable
    // 0x8e78d8: stur            x0, [fp, #-0x10]
    // 0x8e78dc: r0 = Trace()
    //     0x8e78dc: bl              #0x8e6900  ; AllocateTraceStub -> Trace (size=0x10)
    // 0x8e78e0: mov             x1, x0
    // 0x8e78e4: ldur            x0, [fp, #-0x10]
    // 0x8e78e8: stur            x1, [fp, #-0x18]
    // 0x8e78ec: StoreField: r1->field_7 = r0
    //     0x8e78ec: stur            w0, [x1, #7]
    // 0x8e78f0: r0 = _StringStackTrace()
    //     0x8e78f0: bl              #0x84809c  ; Allocate_StringStackTraceStub -> _StringStackTrace (size=0xc)
    // 0x8e78f4: mov             x1, x0
    // 0x8e78f8: ldur            x0, [fp, #-8]
    // 0x8e78fc: StoreField: r1->field_7 = r0
    //     0x8e78fc: stur            w0, [x1, #7]
    // 0x8e7900: ldur            x0, [fp, #-0x18]
    // 0x8e7904: StoreField: r0->field_b = r1
    //     0x8e7904: stur            w1, [x0, #0xb]
    // 0x8e7908: r1 = Function '<anonymous closure>':.
    //     0x8e7908: ldr             x1, [PP, #0x7b40]  ; [pp+0x7b40] Function: [dart:core] Object::_simpleInstanceOfFalse (0x13dce48)
    // 0x8e790c: r2 = Null
    //     0x8e790c: mov             x2, NULL
    // 0x8e7910: r0 = AllocateClosure()
    //     0x8e7910: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8e7914: ldur            x1, [fp, #-0x18]
    // 0x8e7918: mov             x2, x0
    // 0x8e791c: r0 = foldFrames()
    //     0x8e791c: bl              #0x8e5fa8  ; [package:stack_trace/src/trace.dart] Trace::foldFrames
    // 0x8e7920: r1 = <Map<String, String>>
    //     0x8e7920: ldr             x1, [PP, #0x7c68]  ; [pp+0x7c68] TypeArguments: <Map<String, String>>
    // 0x8e7924: r2 = 0
    //     0x8e7924: mov             x2, #0
    // 0x8e7928: stur            x0, [fp, #-8]
    // 0x8e792c: r0 = _GrowableList()
    //     0x8e792c: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x8e7930: mov             x1, x0
    // 0x8e7934: ldur            x0, [fp, #-8]
    // 0x8e7938: stur            x1, [fp, #-0x18]
    // 0x8e793c: LoadField: r2 = r0->field_7
    //     0x8e793c: ldur            w2, [x0, #7]
    // 0x8e7940: DecompressPointer r2
    //     0x8e7940: add             x2, x2, HEAP, lsl #32
    // 0x8e7944: stur            x2, [fp, #-0x10]
    // 0x8e7948: LoadField: r0 = r2->field_b
    //     0x8e7948: ldur            w0, [x2, #0xb]
    // 0x8e794c: r3 = LoadInt32Instr(r0)
    //     0x8e794c: sbfx            x3, x0, #1, #0x1f
    // 0x8e7950: stur            x3, [fp, #-0x28]
    // 0x8e7954: r0 = 0
    //     0x8e7954: mov             x0, #0
    // 0x8e7958: CheckStackOverflow
    //     0x8e7958: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8e795c: cmp             SP, x16
    //     0x8e7960: b.ls            #0x8e7da8
    // 0x8e7964: cmp             x0, x3
    // 0x8e7968: b.ge            #0x8e7d80
    // 0x8e796c: ArrayLoad: r4 = r2[r0]  ; Unknown_4
    //     0x8e796c: add             x16, x2, x0, lsl #2
    //     0x8e7970: ldur            w4, [x16, #0xf]
    // 0x8e7974: DecompressPointer r4
    //     0x8e7974: add             x4, x4, HEAP, lsl #32
    // 0x8e7978: stur            x4, [fp, #-8]
    // 0x8e797c: add             x5, x0, #1
    // 0x8e7980: stur            x5, [fp, #-0x20]
    // 0x8e7984: r0 = LoadClassIdInstr(r4)
    //     0x8e7984: ldur            x0, [x4, #-1]
    //     0x8e7988: ubfx            x0, x0, #0xc, #0x14
    // 0x8e798c: cmp             x0, #0x442
    // 0x8e7990: b.ne            #0x8e7ab8
    // 0x8e7994: r0 = LoadStaticField(0x10bc)
    //     0x8e7994: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8e7998: ldr             x0, [x0, #0x2178]
    // 0x8e799c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8e79a0: cmp             w0, w16
    // 0x8e79a4: b.ne            #0x8e79b0
    // 0x8e79a8: r2 = _obfuscatedStackTraceLineRegExp
    //     0x8e79a8: ldr             x2, [PP, #0x7c70]  ; [pp+0x7c70] Field <::._obfuscatedStackTraceLineRegExp@1282069490>: static late final (offset: 0x10bc)
    // 0x8e79ac: r0 = InitLateFinalStaticField()
    //     0x8e79ac: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8e79b0: mov             x1, x0
    // 0x8e79b4: ldur            x0, [fp, #-8]
    // 0x8e79b8: LoadField: r2 = r0->field_23
    //     0x8e79b8: ldur            w2, [x0, #0x23]
    // 0x8e79bc: DecompressPointer r2
    //     0x8e79bc: add             x2, x2, HEAP, lsl #32
    // 0x8e79c0: stur            x2, [fp, #-0x30]
    // 0x8e79c4: stp             x2, x1, [SP, #8]
    // 0x8e79c8: str             xzr, [SP]
    // 0x8e79cc: r0 = _ExecuteMatch()
    //     0x8e79cc: bl              #0x7e1020  ; [dart:core] _RegExp::_ExecuteMatch
    // 0x8e79d0: cmp             w0, NULL
    // 0x8e79d4: b.ne            #0x8e79e0
    // 0x8e79d8: ldur            x3, [fp, #-0x18]
    // 0x8e79dc: b               #0x8e7ab0
    // 0x8e79e0: ldur            x3, [fp, #-0x18]
    // 0x8e79e4: ldur            x0, [fp, #-0x30]
    // 0x8e79e8: r1 = Null
    //     0x8e79e8: mov             x1, NULL
    // 0x8e79ec: r2 = 12
    //     0x8e79ec: mov             x2, #0xc
    // 0x8e79f0: r0 = AllocateArray()
    //     0x8e79f0: bl              #0x13df928  ; AllocateArrayStub
    // 0x8e79f4: r16 = "file"
    //     0x8e79f4: ldr             x16, [PP, #0x1050]  ; [pp+0x1050] "file"
    // 0x8e79f8: StoreField: r0->field_f = r16
    //     0x8e79f8: stur            w16, [x0, #0xf]
    // 0x8e79fc: r16 = ""
    //     0x8e79fc: ldr             x16, [PP, #0x900]  ; [pp+0x900] ""
    // 0x8e7a00: StoreField: r0->field_13 = r16
    //     0x8e7a00: stur            w16, [x0, #0x13]
    // 0x8e7a04: r16 = "line"
    //     0x8e7a04: ldr             x16, [PP, #0x7c78]  ; [pp+0x7c78] "line"
    // 0x8e7a08: ArrayStore: r0[0] = r16  ; List_4
    //     0x8e7a08: stur            w16, [x0, #0x17]
    // 0x8e7a0c: r16 = "0"
    //     0x8e7a0c: ldr             x16, [PP, #0x47e8]  ; [pp+0x47e8] "0"
    // 0x8e7a10: StoreField: r0->field_1b = r16
    //     0x8e7a10: stur            w16, [x0, #0x1b]
    // 0x8e7a14: r16 = "method"
    //     0x8e7a14: ldr             x16, [PP, #0x7c80]  ; [pp+0x7c80] "method"
    // 0x8e7a18: StoreField: r0->field_1f = r16
    //     0x8e7a18: stur            w16, [x0, #0x1f]
    // 0x8e7a1c: ldur            x1, [fp, #-0x30]
    // 0x8e7a20: StoreField: r0->field_23 = r1
    //     0x8e7a20: stur            w1, [x0, #0x23]
    // 0x8e7a24: r16 = <String, String>
    //     0x8e7a24: ldr             x16, [PP, #0x7c88]  ; [pp+0x7c88] TypeArguments: <String, String>
    // 0x8e7a28: stp             x0, x16, [SP]
    // 0x8e7a2c: r0 = Map._fromLiteral()
    //     0x8e7a2c: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x8e7a30: mov             x2, x0
    // 0x8e7a34: ldur            x0, [fp, #-0x18]
    // 0x8e7a38: stur            x2, [fp, #-0x30]
    // 0x8e7a3c: LoadField: r1 = r0->field_b
    //     0x8e7a3c: ldur            w1, [x0, #0xb]
    // 0x8e7a40: LoadField: r3 = r0->field_f
    //     0x8e7a40: ldur            w3, [x0, #0xf]
    // 0x8e7a44: DecompressPointer r3
    //     0x8e7a44: add             x3, x3, HEAP, lsl #32
    // 0x8e7a48: LoadField: r4 = r3->field_b
    //     0x8e7a48: ldur            w4, [x3, #0xb]
    // 0x8e7a4c: r3 = LoadInt32Instr(r1)
    //     0x8e7a4c: sbfx            x3, x1, #1, #0x1f
    // 0x8e7a50: stur            x3, [fp, #-0x38]
    // 0x8e7a54: r1 = LoadInt32Instr(r4)
    //     0x8e7a54: sbfx            x1, x4, #1, #0x1f
    // 0x8e7a58: cmp             x3, x1
    // 0x8e7a5c: b.ne            #0x8e7a68
    // 0x8e7a60: mov             x1, x0
    // 0x8e7a64: r0 = _growToNextCapacity()
    //     0x8e7a64: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8e7a68: ldur            x3, [fp, #-0x18]
    // 0x8e7a6c: ldur            x2, [fp, #-0x38]
    // 0x8e7a70: add             x0, x2, #1
    // 0x8e7a74: lsl             x1, x0, #1
    // 0x8e7a78: StoreField: r3->field_b = r1
    //     0x8e7a78: stur            w1, [x3, #0xb]
    // 0x8e7a7c: LoadField: r1 = r3->field_f
    //     0x8e7a7c: ldur            w1, [x3, #0xf]
    // 0x8e7a80: DecompressPointer r1
    //     0x8e7a80: add             x1, x1, HEAP, lsl #32
    // 0x8e7a84: ldur            x0, [fp, #-0x30]
    // 0x8e7a88: ArrayStore: r1[r2] = r0  ; List_4
    //     0x8e7a88: add             x25, x1, x2, lsl #2
    //     0x8e7a8c: add             x25, x25, #0xf
    //     0x8e7a90: str             w0, [x25]
    //     0x8e7a94: tbz             w0, #0, #0x8e7ab0
    //     0x8e7a98: ldurb           w16, [x1, #-1]
    //     0x8e7a9c: ldurb           w17, [x0, #-1]
    //     0x8e7aa0: and             x16, x17, x16, lsr #2
    //     0x8e7aa4: tst             x16, HEAP, lsr #32
    //     0x8e7aa8: b.eq            #0x8e7ab0
    //     0x8e7aac: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x8e7ab0: mov             x2, x3
    // 0x8e7ab4: b               #0x8e7d6c
    // 0x8e7ab8: mov             x3, x1
    // 0x8e7abc: mov             x0, x4
    // 0x8e7ac0: r1 = Null
    //     0x8e7ac0: mov             x1, NULL
    // 0x8e7ac4: r2 = 8
    //     0x8e7ac4: mov             x2, #8
    // 0x8e7ac8: r0 = AllocateArray()
    //     0x8e7ac8: bl              #0x13df928  ; AllocateArrayStub
    // 0x8e7acc: mov             x2, x0
    // 0x8e7ad0: stur            x2, [fp, #-0x30]
    // 0x8e7ad4: r16 = "file"
    //     0x8e7ad4: ldr             x16, [PP, #0x1050]  ; [pp+0x1050] "file"
    // 0x8e7ad8: StoreField: r2->field_f = r16
    //     0x8e7ad8: stur            w16, [x2, #0xf]
    // 0x8e7adc: ldur            x3, [fp, #-8]
    // 0x8e7ae0: r0 = LoadClassIdInstr(r3)
    //     0x8e7ae0: ldur            x0, [x3, #-1]
    //     0x8e7ae4: ubfx            x0, x0, #0xc, #0x14
    // 0x8e7ae8: mov             x1, x3
    // 0x8e7aec: r0 = GDT[cid_x0 + -0xffb]()
    //     0x8e7aec: sub             lr, x0, #0xffb
    //     0x8e7af0: ldr             lr, [x21, lr, lsl #3]
    //     0x8e7af4: blr             lr
    // 0x8e7af8: ldur            x1, [fp, #-0x30]
    // 0x8e7afc: ArrayStore: r1[1] = r0  ; List_4
    //     0x8e7afc: add             x25, x1, #0x13
    //     0x8e7b00: str             w0, [x25]
    //     0x8e7b04: tbz             w0, #0, #0x8e7b20
    //     0x8e7b08: ldurb           w16, [x1, #-1]
    //     0x8e7b0c: ldurb           w17, [x0, #-1]
    //     0x8e7b10: and             x16, x17, x16, lsr #2
    //     0x8e7b14: tst             x16, HEAP, lsr #32
    //     0x8e7b18: b.eq            #0x8e7b20
    //     0x8e7b1c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x8e7b20: ldur            x2, [fp, #-0x30]
    // 0x8e7b24: r16 = "line"
    //     0x8e7b24: ldr             x16, [PP, #0x7c78]  ; [pp+0x7c78] "line"
    // 0x8e7b28: ArrayStore: r2[0] = r16  ; List_4
    //     0x8e7b28: stur            w16, [x2, #0x17]
    // 0x8e7b2c: ldur            x3, [fp, #-8]
    // 0x8e7b30: r0 = LoadClassIdInstr(r3)
    //     0x8e7b30: ldur            x0, [x3, #-1]
    //     0x8e7b34: ubfx            x0, x0, #0xc, #0x14
    // 0x8e7b38: mov             x1, x3
    // 0x8e7b3c: r0 = GDT[cid_x0 + -0xfff]()
    //     0x8e7b3c: sub             lr, x0, #0xfff
    //     0x8e7b40: ldr             lr, [x21, lr, lsl #3]
    //     0x8e7b44: blr             lr
    // 0x8e7b48: cmp             w0, NULL
    // 0x8e7b4c: b.ne            #0x8e7b58
    // 0x8e7b50: r1 = Null
    //     0x8e7b50: mov             x1, NULL
    // 0x8e7b54: b               #0x8e7b88
    // 0x8e7b58: r1 = 60
    //     0x8e7b58: mov             x1, #0x3c
    // 0x8e7b5c: branchIfSmi(r0, 0x8e7b68)
    //     0x8e7b5c: tbz             w0, #0, #0x8e7b68
    // 0x8e7b60: r1 = LoadClassIdInstr(r0)
    //     0x8e7b60: ldur            x1, [x0, #-1]
    //     0x8e7b64: ubfx            x1, x1, #0xc, #0x14
    // 0x8e7b68: str             x0, [SP]
    // 0x8e7b6c: mov             x0, x1
    // 0x8e7b70: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8e7b70: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8e7b74: r0 = GDT[cid_x0 + 0x91c1]()
    //     0x8e7b74: mov             x17, #0x91c1
    //     0x8e7b78: add             lr, x0, x17
    //     0x8e7b7c: ldr             lr, [x21, lr, lsl #3]
    //     0x8e7b80: blr             lr
    // 0x8e7b84: mov             x1, x0
    // 0x8e7b88: cmp             w1, NULL
    // 0x8e7b8c: b.ne            #0x8e7b98
    // 0x8e7b90: r0 = "0"
    //     0x8e7b90: ldr             x0, [PP, #0x47e8]  ; [pp+0x47e8] "0"
    // 0x8e7b94: b               #0x8e7b9c
    // 0x8e7b98: mov             x0, x1
    // 0x8e7b9c: ldur            x2, [fp, #-8]
    // 0x8e7ba0: ldur            x1, [fp, #-0x30]
    // 0x8e7ba4: ArrayStore: r1[3] = r0  ; List_4
    //     0x8e7ba4: add             x25, x1, #0x1b
    //     0x8e7ba8: str             w0, [x25]
    //     0x8e7bac: tbz             w0, #0, #0x8e7bc8
    //     0x8e7bb0: ldurb           w16, [x1, #-1]
    //     0x8e7bb4: ldurb           w17, [x0, #-1]
    //     0x8e7bb8: and             x16, x17, x16, lsr #2
    //     0x8e7bbc: tst             x16, HEAP, lsr #32
    //     0x8e7bc0: b.eq            #0x8e7bc8
    //     0x8e7bc4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x8e7bc8: r16 = <String, String>
    //     0x8e7bc8: ldr             x16, [PP, #0x7c88]  ; [pp+0x7c88] TypeArguments: <String, String>
    // 0x8e7bcc: ldur            lr, [fp, #-0x30]
    // 0x8e7bd0: stp             lr, x16, [SP]
    // 0x8e7bd4: r0 = Map._fromLiteral()
    //     0x8e7bd4: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x8e7bd8: mov             x2, x0
    // 0x8e7bdc: ldur            x1, [fp, #-8]
    // 0x8e7be0: stur            x2, [fp, #-0x30]
    // 0x8e7be4: r0 = LoadClassIdInstr(r1)
    //     0x8e7be4: ldur            x0, [x1, #-1]
    //     0x8e7be8: ubfx            x0, x0, #0xc, #0x14
    // 0x8e7bec: r0 = GDT[cid_x0 + -0x1000]()
    //     0x8e7bec: sub             lr, x0, #1, lsl #12
    //     0x8e7bf0: ldr             lr, [x21, lr, lsl #3]
    //     0x8e7bf4: blr             lr
    // 0x8e7bf8: mov             x3, x0
    // 0x8e7bfc: stur            x3, [fp, #-8]
    // 0x8e7c00: r0 = LoadClassIdInstr(r3)
    //     0x8e7c00: ldur            x0, [x3, #-1]
    //     0x8e7c04: ubfx            x0, x0, #0xc, #0x14
    // 0x8e7c08: mov             x1, x3
    // 0x8e7c0c: r2 = "."
    //     0x8e7c0c: ldr             x2, [PP, #0xfc8]  ; [pp+0xfc8] "."
    // 0x8e7c10: r0 = GDT[cid_x0 + -0xffe]()
    //     0x8e7c10: sub             lr, x0, #0xffe
    //     0x8e7c14: ldr             lr, [x21, lr, lsl #3]
    //     0x8e7c18: blr             lr
    // 0x8e7c1c: stur            x0, [fp, #-0x40]
    // 0x8e7c20: LoadField: r1 = r0->field_b
    //     0x8e7c20: ldur            w1, [x0, #0xb]
    // 0x8e7c24: r2 = LoadInt32Instr(r1)
    //     0x8e7c24: sbfx            x2, x1, #1, #0x1f
    // 0x8e7c28: cmp             x2, #1
    // 0x8e7c2c: b.le            #0x8e7cd4
    // 0x8e7c30: mov             x1, x0
    // 0x8e7c34: r2 = 1
    //     0x8e7c34: mov             x2, #1
    // 0x8e7c38: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8e7c38: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8e7c3c: r0 = sublist()
    //     0x8e7c3c: bl              #0xa014c4  ; [dart:core] _GrowableList::sublist
    // 0x8e7c40: r16 = "."
    //     0x8e7c40: ldr             x16, [PP, #0xfc8]  ; [pp+0xfc8] "."
    // 0x8e7c44: str             x16, [SP]
    // 0x8e7c48: mov             x1, x0
    // 0x8e7c4c: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x8e7c4c: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x8e7c50: r0 = join()
    //     0x8e7c50: bl              #0xb99e34  ; [dart:core] _GrowableList::join
    // 0x8e7c54: stur            x0, [fp, #-0x48]
    // 0x8e7c58: r16 = "method"
    //     0x8e7c58: ldr             x16, [PP, #0x7c80]  ; [pp+0x7c80] "method"
    // 0x8e7c5c: str             x16, [SP]
    // 0x8e7c60: r0 = hashCode()
    //     0x8e7c60: bl              #0x1159684  ; [dart:core] _OneByteString::hashCode
    // 0x8e7c64: ldur            x1, [fp, #-0x30]
    // 0x8e7c68: ldur            x3, [fp, #-0x48]
    // 0x8e7c6c: mov             x5, x0
    // 0x8e7c70: r2 = "method"
    //     0x8e7c70: ldr             x2, [PP, #0x7c80]  ; [pp+0x7c80] "method"
    // 0x8e7c74: r0 = _set()
    //     0x8e7c74: bl              #0x13d8170  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x8e7c78: ldur            x2, [fp, #-0x40]
    // 0x8e7c7c: LoadField: r0 = r2->field_b
    //     0x8e7c7c: ldur            w0, [x2, #0xb]
    // 0x8e7c80: r1 = LoadInt32Instr(r0)
    //     0x8e7c80: sbfx            x1, x0, #1, #0x1f
    // 0x8e7c84: cmp             x1, #0
    // 0x8e7c88: b.le            #0x8e7d94
    // 0x8e7c8c: mov             x0, x1
    // 0x8e7c90: r1 = 0
    //     0x8e7c90: mov             x1, #0
    // 0x8e7c94: cmp             x1, x0
    // 0x8e7c98: b.hs            #0x8e7db0
    // 0x8e7c9c: LoadField: r0 = r2->field_f
    //     0x8e7c9c: ldur            w0, [x2, #0xf]
    // 0x8e7ca0: DecompressPointer r0
    //     0x8e7ca0: add             x0, x0, HEAP, lsl #32
    // 0x8e7ca4: LoadField: r3 = r0->field_f
    //     0x8e7ca4: ldur            w3, [x0, #0xf]
    // 0x8e7ca8: DecompressPointer r3
    //     0x8e7ca8: add             x3, x3, HEAP, lsl #32
    // 0x8e7cac: stur            x3, [fp, #-0x40]
    // 0x8e7cb0: r16 = "class"
    //     0x8e7cb0: ldr             x16, [PP, #0x7c90]  ; [pp+0x7c90] "class"
    // 0x8e7cb4: str             x16, [SP]
    // 0x8e7cb8: r0 = hashCode()
    //     0x8e7cb8: bl              #0x1159684  ; [dart:core] _OneByteString::hashCode
    // 0x8e7cbc: ldur            x1, [fp, #-0x30]
    // 0x8e7cc0: ldur            x3, [fp, #-0x40]
    // 0x8e7cc4: mov             x5, x0
    // 0x8e7cc8: r2 = "class"
    //     0x8e7cc8: ldr             x2, [PP, #0x7c90]  ; [pp+0x7c90] "class"
    // 0x8e7ccc: r0 = _set()
    //     0x8e7ccc: bl              #0x13d8170  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x8e7cd0: b               #0x8e7cf4
    // 0x8e7cd4: r16 = "method"
    //     0x8e7cd4: ldr             x16, [PP, #0x7c80]  ; [pp+0x7c80] "method"
    // 0x8e7cd8: str             x16, [SP]
    // 0x8e7cdc: r0 = hashCode()
    //     0x8e7cdc: bl              #0x1159684  ; [dart:core] _OneByteString::hashCode
    // 0x8e7ce0: ldur            x1, [fp, #-0x30]
    // 0x8e7ce4: ldur            x3, [fp, #-8]
    // 0x8e7ce8: mov             x5, x0
    // 0x8e7cec: r2 = "method"
    //     0x8e7cec: ldr             x2, [PP, #0x7c80]  ; [pp+0x7c80] "method"
    // 0x8e7cf0: r0 = _set()
    //     0x8e7cf0: bl              #0x13d8170  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x8e7cf4: ldur            x0, [fp, #-0x18]
    // 0x8e7cf8: LoadField: r1 = r0->field_b
    //     0x8e7cf8: ldur            w1, [x0, #0xb]
    // 0x8e7cfc: LoadField: r2 = r0->field_f
    //     0x8e7cfc: ldur            w2, [x0, #0xf]
    // 0x8e7d00: DecompressPointer r2
    //     0x8e7d00: add             x2, x2, HEAP, lsl #32
    // 0x8e7d04: LoadField: r3 = r2->field_b
    //     0x8e7d04: ldur            w3, [x2, #0xb]
    // 0x8e7d08: r2 = LoadInt32Instr(r1)
    //     0x8e7d08: sbfx            x2, x1, #1, #0x1f
    // 0x8e7d0c: stur            x2, [fp, #-0x38]
    // 0x8e7d10: r1 = LoadInt32Instr(r3)
    //     0x8e7d10: sbfx            x1, x3, #1, #0x1f
    // 0x8e7d14: cmp             x2, x1
    // 0x8e7d18: b.ne            #0x8e7d24
    // 0x8e7d1c: mov             x1, x0
    // 0x8e7d20: r0 = _growToNextCapacity()
    //     0x8e7d20: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8e7d24: ldur            x2, [fp, #-0x18]
    // 0x8e7d28: ldur            x3, [fp, #-0x38]
    // 0x8e7d2c: add             x0, x3, #1
    // 0x8e7d30: lsl             x1, x0, #1
    // 0x8e7d34: StoreField: r2->field_b = r1
    //     0x8e7d34: stur            w1, [x2, #0xb]
    // 0x8e7d38: LoadField: r1 = r2->field_f
    //     0x8e7d38: ldur            w1, [x2, #0xf]
    // 0x8e7d3c: DecompressPointer r1
    //     0x8e7d3c: add             x1, x1, HEAP, lsl #32
    // 0x8e7d40: ldur            x0, [fp, #-0x30]
    // 0x8e7d44: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8e7d44: add             x25, x1, x3, lsl #2
    //     0x8e7d48: add             x25, x25, #0xf
    //     0x8e7d4c: str             w0, [x25]
    //     0x8e7d50: tbz             w0, #0, #0x8e7d6c
    //     0x8e7d54: ldurb           w16, [x1, #-1]
    //     0x8e7d58: ldurb           w17, [x0, #-1]
    //     0x8e7d5c: and             x16, x17, x16, lsr #2
    //     0x8e7d60: tst             x16, HEAP, lsr #32
    //     0x8e7d64: b.eq            #0x8e7d6c
    //     0x8e7d68: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x8e7d6c: ldur            x0, [fp, #-0x20]
    // 0x8e7d70: mov             x1, x2
    // 0x8e7d74: ldur            x2, [fp, #-0x10]
    // 0x8e7d78: ldur            x3, [fp, #-0x28]
    // 0x8e7d7c: b               #0x8e7958
    // 0x8e7d80: mov             x2, x1
    // 0x8e7d84: mov             x0, x2
    // 0x8e7d88: LeaveFrame
    //     0x8e7d88: mov             SP, fp
    //     0x8e7d8c: ldp             fp, lr, [SP], #0x10
    // 0x8e7d90: ret
    //     0x8e7d90: ret             
    // 0x8e7d94: r0 = noElement()
    //     0x8e7d94: bl              #0x7e3da8  ; [dart:_internal] IterableElementError::noElement
    // 0x8e7d98: r0 = Throw()
    //     0x8e7d98: bl              #0x13ddb2c  ; ThrowStub
    // 0x8e7d9c: brk             #0
    // 0x8e7da0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8e7da0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8e7da4: b               #0x8e7884
    // 0x8e7da8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8e7da8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8e7dac: b               #0x8e7964
    // 0x8e7db0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8e7db0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  static RegExp _obfuscatedStackTraceLineRegExp() {
    // ** addr: 0x8e7db4, size: 0x54
    // 0x8e7db4: EnterFrame
    //     0x8e7db4: stp             fp, lr, [SP, #-0x10]!
    //     0x8e7db8: mov             fp, SP
    // 0x8e7dbc: AllocStack(0x30)
    //     0x8e7dbc: sub             SP, SP, #0x30
    // 0x8e7dc0: CheckStackOverflow
    //     0x8e7dc0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8e7dc4: cmp             SP, x16
    //     0x8e7dc8: b.ls            #0x8e7e00
    // 0x8e7dcc: r16 = "^(\\s*#\\d{2} abs )([\\da-f]+)((\?: virt [\\da-f]+)\?(\?: .*)\?)$"
    //     0x8e7dcc: ldr             x16, [PP, #0x7c98]  ; [pp+0x7c98] "^(\\s*#\\d{2} abs )([\\da-f]+)((\?: virt [\\da-f]+)\?(\?: .*)\?)$"
    // 0x8e7dd0: stp             x16, NULL, [SP, #0x20]
    // 0x8e7dd4: r16 = false
    //     0x8e7dd4: add             x16, NULL, #0x30  ; false
    // 0x8e7dd8: r30 = true
    //     0x8e7dd8: add             lr, NULL, #0x20  ; true
    // 0x8e7ddc: stp             lr, x16, [SP, #0x10]
    // 0x8e7de0: r16 = false
    //     0x8e7de0: add             x16, NULL, #0x30  ; false
    // 0x8e7de4: r30 = false
    //     0x8e7de4: add             lr, NULL, #0x30  ; false
    // 0x8e7de8: stp             lr, x16, [SP]
    // 0x8e7dec: r4 = const [0, 0x6, 0x6, 0x2, caseSensitive, 0x3, dotAll, 0x5, multiLine, 0x2, unicode, 0x4, null]
    //     0x8e7dec: ldr             x4, [PP, #0xa48]  ; [pp+0xa48] List(13) [0, 0x6, 0x6, 0x2, "caseSensitive", 0x3, "dotAll", 0x5, "multiLine", 0x2, "unicode", 0x4, Null]
    // 0x8e7df0: r0 = _RegExp()
    //     0x8e7df0: bl              #0x7eb40c  ; [dart:core] _RegExp::_RegExp
    // 0x8e7df4: LeaveFrame
    //     0x8e7df4: mov             SP, fp
    //     0x8e7df8: ldp             fp, lr, [SP], #0x10
    // 0x8e7dfc: ret
    //     0x8e7dfc: ret             
    // 0x8e7e00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8e7e00: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8e7e04: b               #0x8e7dcc
  }
  [closure] static String <anonymous closure>(dynamic, UnparsedFrame) {
    // ** addr: 0x1123f54, size: 0x10
    // 0x1123f54: ldr             x1, [SP]
    // 0x1123f58: LoadField: r0 = r1->field_23
    //     0x1123f58: ldur            w0, [x1, #0x23]
    // 0x1123f5c: DecompressPointer r0
    //     0x1123f5c: add             x0, x0, HEAP, lsl #32
    // 0x1123f60: ret
    //     0x1123f60: ret             
  }
}
