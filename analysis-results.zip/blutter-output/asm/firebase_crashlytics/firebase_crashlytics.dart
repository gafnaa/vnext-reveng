// lib: , url: package:firebase_crashlytics/firebase_crashlytics.dart

// class id: 1048747, size: 0x8
class :: {
}

// class id: 3370, size: 0x18, field offset: 0x10
class FirebaseCrashlytics extends FirebasePlugin {

  _ log(/* No info */) async {
    // ** addr: 0x8c061c, size: 0x4c
    // 0x8c061c: EnterFrame
    //     0x8c061c: stp             fp, lr, [SP, #-0x10]!
    //     0x8c0620: mov             fp, SP
    // 0x8c0624: AllocStack(0x18)
    //     0x8c0624: sub             SP, SP, #0x18
    // 0x8c0628: SetupParameters(FirebaseCrashlytics this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0x8c0628: stur            NULL, [fp, #-8]
    //     0x8c062c: stur            x1, [fp, #-0x10]
    //     0x8c0630: stur            x2, [fp, #-0x18]
    // 0x8c0634: CheckStackOverflow
    //     0x8c0634: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c0638: cmp             SP, x16
    //     0x8c063c: b.ls            #0x8c0660
    // 0x8c0640: InitAsync() -> Future<void?>
    //     0x8c0640: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0x8c0644: bl              #0x7f5e44  ; InitAsyncStub
    // 0x8c0648: ldur            x1, [fp, #-0x10]
    // 0x8c064c: r0 = _delegate()
    //     0x8c064c: bl              #0x8c0ab0  ; [package:firebase_crashlytics/firebase_crashlytics.dart] FirebaseCrashlytics::_delegate
    // 0x8c0650: mov             x1, x0
    // 0x8c0654: ldur            x2, [fp, #-0x18]
    // 0x8c0658: r0 = log()
    //     0x8c0658: bl              #0x8c0668  ; [package:firebase_crashlytics_platform_interface/src/method_channel/method_channel_crashlytics.dart] MethodChannelFirebaseCrashlytics::log
    // 0x8c065c: r0 = ReturnAsync()
    //     0x8c065c: b               #0x82fdf0  ; ReturnAsyncStub
    // 0x8c0660: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c0660: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c0664: b               #0x8c0640
  }
  get _ _delegate(/* No info */) {
    // ** addr: 0x8c0ab0, size: 0x88
    // 0x8c0ab0: EnterFrame
    //     0x8c0ab0: stp             fp, lr, [SP, #-0x10]!
    //     0x8c0ab4: mov             fp, SP
    // 0x8c0ab8: AllocStack(0x8)
    //     0x8c0ab8: sub             SP, SP, #8
    // 0x8c0abc: SetupParameters(FirebaseCrashlytics this /* r1 => r0, fp-0x8 */)
    //     0x8c0abc: mov             x0, x1
    //     0x8c0ac0: stur            x1, [fp, #-8]
    // 0x8c0ac4: CheckStackOverflow
    //     0x8c0ac4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c0ac8: cmp             SP, x16
    //     0x8c0acc: b.ls            #0x8c0b30
    // 0x8c0ad0: LoadField: r1 = r0->field_f
    //     0x8c0ad0: ldur            w1, [x0, #0xf]
    // 0x8c0ad4: DecompressPointer r1
    //     0x8c0ad4: add             x1, x1, HEAP, lsl #32
    // 0x8c0ad8: cmp             w1, NULL
    // 0x8c0adc: b.ne            #0x8c0b20
    // 0x8c0ae0: mov             x1, x0
    // 0x8c0ae4: r0 = pluginConstants()
    //     0x8c0ae4: bl              #0x8c12e8  ; [package:firebase_core_platform_interface/firebase_core_platform_interface.dart] FirebasePlugin::pluginConstants
    // 0x8c0ae8: mov             x2, x0
    // 0x8c0aec: r1 = Null
    //     0x8c0aec: mov             x1, NULL
    // 0x8c0af0: r0 = FirebaseCrashlyticsPlatform.instanceFor()
    //     0x8c0af0: bl              #0x8c0b38  ; [package:firebase_crashlytics_platform_interface/src/platform_interface/platform_interface_crashlytics.dart] FirebaseCrashlyticsPlatform::FirebaseCrashlyticsPlatform.instanceFor
    // 0x8c0af4: mov             x1, x0
    // 0x8c0af8: ldur            x2, [fp, #-8]
    // 0x8c0afc: StoreField: r2->field_f = r0
    //     0x8c0afc: stur            w0, [x2, #0xf]
    //     0x8c0b00: ldurb           w16, [x2, #-1]
    //     0x8c0b04: ldurb           w17, [x0, #-1]
    //     0x8c0b08: and             x16, x17, x16, lsr #2
    //     0x8c0b0c: tst             x16, HEAP, lsr #32
    //     0x8c0b10: b.eq            #0x8c0b18
    //     0x8c0b14: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x8c0b18: mov             x0, x1
    // 0x8c0b1c: b               #0x8c0b24
    // 0x8c0b20: mov             x0, x1
    // 0x8c0b24: LeaveFrame
    //     0x8c0b24: mov             SP, fp
    //     0x8c0b28: ldp             fp, lr, [SP], #0x10
    // 0x8c0b2c: ret
    //     0x8c0b2c: ret             
    // 0x8c0b30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c0b30: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c0b34: b               #0x8c0ad0
  }
  get _ instance(/* No info */) {
    // ** addr: 0x8c146c, size: 0x7c
    // 0x8c146c: EnterFrame
    //     0x8c146c: stp             fp, lr, [SP, #-0x10]!
    //     0x8c1470: mov             fp, SP
    // 0x8c1474: AllocStack(0x8)
    //     0x8c1474: sub             SP, SP, #8
    // 0x8c1478: CheckStackOverflow
    //     0x8c1478: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c147c: cmp             SP, x16
    //     0x8c1480: b.ls            #0x8c14e0
    // 0x8c1484: r0 = LoadStaticField(0x10b8)
    //     0x8c1484: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8c1488: ldr             x0, [x0, #0x2170]
    // 0x8c148c: cmp             w0, NULL
    // 0x8c1490: b.ne            #0x8c14d4
    // 0x8c1494: r0 = app()
    //     0x8c1494: bl              #0x8c0c7c  ; [package:firebase_core/firebase_core.dart] Firebase::app
    // 0x8c1498: stur            x0, [fp, #-8]
    // 0x8c149c: r0 = FirebaseCrashlytics()
    //     0x8c149c: bl              #0x8c14e8  ; AllocateFirebaseCrashlyticsStub -> FirebaseCrashlytics (size=0x18)
    // 0x8c14a0: ldur            x1, [fp, #-8]
    // 0x8c14a4: StoreField: r0->field_13 = r1
    //     0x8c14a4: stur            w1, [x0, #0x13]
    // 0x8c14a8: LoadField: r3 = r1->field_7
    //     0x8c14a8: ldur            w3, [x1, #7]
    // 0x8c14ac: DecompressPointer r3
    //     0x8c14ac: add             x3, x3, HEAP, lsl #32
    // 0x8c14b0: LoadField: r1 = r3->field_7
    //     0x8c14b0: ldur            w1, [x3, #7]
    // 0x8c14b4: DecompressPointer r1
    //     0x8c14b4: add             x1, x1, HEAP, lsl #32
    // 0x8c14b8: StoreField: r0->field_7 = r1
    //     0x8c14b8: stur            w1, [x0, #7]
    // 0x8c14bc: r1 = "plugins.flutter.io/firebase_crashlytics"
    //     0x8c14bc: add             x1, PP, #8, lsl #12  ; [pp+0x8058] "plugins.flutter.io/firebase_crashlytics"
    //     0x8c14c0: ldr             x1, [x1, #0x58]
    // 0x8c14c4: StoreField: r0->field_b = r1
    //     0x8c14c4: stur            w1, [x0, #0xb]
    // 0x8c14c8: mov             x2, x0
    // 0x8c14cc: StoreStaticField(0x10b8, r2)
    //     0x8c14cc: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x8c14d0: str             x2, [x1, #0x2170]
    // 0x8c14d4: LeaveFrame
    //     0x8c14d4: mov             SP, fp
    //     0x8c14d8: ldp             fp, lr, [SP], #0x10
    // 0x8c14dc: ret
    //     0x8c14dc: ret             
    // 0x8c14e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c14e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c14e4: b               #0x8c1484
  }
  _ recordError(/* No info */) async {
    // ** addr: 0x8e59b4, size: 0x30c
    // 0x8e59b4: EnterFrame
    //     0x8e59b4: stp             fp, lr, [SP, #-0x10]!
    //     0x8e59b8: mov             fp, SP
    // 0x8e59bc: AllocStack(0x58)
    //     0x8e59bc: sub             SP, SP, #0x58
    // 0x8e59c0: SetupParameters(FirebaseCrashlytics this /* r1 => r1, fp-0x30 */, dynamic _ /* r2 => r2, fp-0x38 */, dynamic _ /* r3 => r3, fp-0x40 */, {dynamic fatal = false /* r6, fp-0x28 */, dynamic information = const [] /* r7, fp-0x20 */, dynamic printDetails = Null /* r8, fp-0x18 */, dynamic reason = Null /* r4, fp-0x10 */})
    //     0x8e59c0: stur            NULL, [fp, #-8]
    //     0x8e59c4: stur            x1, [fp, #-0x30]
    //     0x8e59c8: stur            x2, [fp, #-0x38]
    //     0x8e59cc: stur            x3, [fp, #-0x40]
    //     0x8e59d0: ldur            w0, [x4, #0x13]
    //     0x8e59d4: ldur            w5, [x4, #0x1f]
    //     0x8e59d8: add             x5, x5, HEAP, lsl #32
    //     0x8e59dc: ldr             x16, [PP, #0x7a20]  ; [pp+0x7a20] "fatal"
    //     0x8e59e0: cmp             w5, w16
    //     0x8e59e4: b.ne            #0x8e5a08
    //     0x8e59e8: ldur            w5, [x4, #0x23]
    //     0x8e59ec: add             x5, x5, HEAP, lsl #32
    //     0x8e59f0: sub             w6, w0, w5
    //     0x8e59f4: add             x5, fp, w6, sxtw #2
    //     0x8e59f8: ldr             x5, [x5, #8]
    //     0x8e59fc: mov             x6, x5
    //     0x8e5a00: mov             x5, #1
    //     0x8e5a04: b               #0x8e5a10
    //     0x8e5a08: add             x6, NULL, #0x30  ; false
    //     0x8e5a0c: mov             x5, #0
    //     0x8e5a10: stur            x6, [fp, #-0x28]
    //     0x8e5a14: lsl             x7, x5, #1
    //     0x8e5a18: lsl             w8, w7, #1
    //     0x8e5a1c: add             w9, w8, #8
    //     0x8e5a20: add             x16, x4, w9, sxtw #1
    //     0x8e5a24: ldur            w10, [x16, #0xf]
    //     0x8e5a28: add             x10, x10, HEAP, lsl #32
    //     0x8e5a2c: ldr             x16, [PP, #0x7a28]  ; [pp+0x7a28] "information"
    //     0x8e5a30: cmp             w10, w16
    //     0x8e5a34: b.ne            #0x8e5a68
    //     0x8e5a38: add             w5, w8, #0xa
    //     0x8e5a3c: add             x16, x4, w5, sxtw #1
    //     0x8e5a40: ldur            w8, [x16, #0xf]
    //     0x8e5a44: add             x8, x8, HEAP, lsl #32
    //     0x8e5a48: sub             w5, w0, w8
    //     0x8e5a4c: add             x8, fp, w5, sxtw #2
    //     0x8e5a50: ldr             x8, [x8, #8]
    //     0x8e5a54: add             w5, w7, #2
    //     0x8e5a58: sbfx            x7, x5, #1, #0x1f
    //     0x8e5a5c: mov             x5, x7
    //     0x8e5a60: mov             x7, x8
    //     0x8e5a64: b               #0x8e5a6c
    //     0x8e5a68: ldr             x7, [PP, #0x7a30]  ; [pp+0x7a30] List<Object>(0)
    //     0x8e5a6c: stur            x7, [fp, #-0x20]
    //     0x8e5a70: lsl             x8, x5, #1
    //     0x8e5a74: lsl             w9, w8, #1
    //     0x8e5a78: add             w10, w9, #8
    //     0x8e5a7c: add             x16, x4, w10, sxtw #1
    //     0x8e5a80: ldur            w11, [x16, #0xf]
    //     0x8e5a84: add             x11, x11, HEAP, lsl #32
    //     0x8e5a88: ldr             x16, [PP, #0x7a38]  ; [pp+0x7a38] "printDetails"
    //     0x8e5a8c: cmp             w11, w16
    //     0x8e5a90: b.ne            #0x8e5ac4
    //     0x8e5a94: add             w5, w9, #0xa
    //     0x8e5a98: add             x16, x4, w5, sxtw #1
    //     0x8e5a9c: ldur            w9, [x16, #0xf]
    //     0x8e5aa0: add             x9, x9, HEAP, lsl #32
    //     0x8e5aa4: sub             w5, w0, w9
    //     0x8e5aa8: add             x9, fp, w5, sxtw #2
    //     0x8e5aac: ldr             x9, [x9, #8]
    //     0x8e5ab0: add             w5, w8, #2
    //     0x8e5ab4: sbfx            x8, x5, #1, #0x1f
    //     0x8e5ab8: mov             x5, x8
    //     0x8e5abc: mov             x8, x9
    //     0x8e5ac0: b               #0x8e5ac8
    //     0x8e5ac4: mov             x8, NULL
    //     0x8e5ac8: stur            x8, [fp, #-0x18]
    //     0x8e5acc: lsl             x9, x5, #1
    //     0x8e5ad0: lsl             w5, w9, #1
    //     0x8e5ad4: add             w9, w5, #8
    //     0x8e5ad8: add             x16, x4, w9, sxtw #1
    //     0x8e5adc: ldur            w10, [x16, #0xf]
    //     0x8e5ae0: add             x10, x10, HEAP, lsl #32
    //     0x8e5ae4: ldr             x16, [PP, #0x7a40]  ; [pp+0x7a40] "reason"
    //     0x8e5ae8: cmp             w10, w16
    //     0x8e5aec: b.ne            #0x8e5b14
    //     0x8e5af0: add             w9, w5, #0xa
    //     0x8e5af4: add             x16, x4, w9, sxtw #1
    //     0x8e5af8: ldur            w5, [x16, #0xf]
    //     0x8e5afc: add             x5, x5, HEAP, lsl #32
    //     0x8e5b00: sub             w4, w0, w5
    //     0x8e5b04: add             x0, fp, w4, sxtw #2
    //     0x8e5b08: ldr             x0, [x0, #8]
    //     0x8e5b0c: mov             x4, x0
    //     0x8e5b10: b               #0x8e5b18
    //     0x8e5b14: mov             x4, NULL
    //     0x8e5b18: stur            x4, [fp, #-0x10]
    // 0x8e5b1c: CheckStackOverflow
    //     0x8e5b1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8e5b20: cmp             SP, x16
    //     0x8e5b24: b.ls            #0x8e5cb8
    // 0x8e5b28: InitAsync() -> Future<void?>
    //     0x8e5b28: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0x8e5b2c: bl              #0x7f5e44  ; InitAsyncStub
    // 0x8e5b30: ldur            x0, [fp, #-0x18]
    // 0x8e5b34: cmp             w0, NULL
    // 0x8e5b38: b.ne            #0x8e5b44
    // 0x8e5b3c: r3 = false
    //     0x8e5b3c: add             x3, NULL, #0x30  ; false
    // 0x8e5b40: b               #0x8e5b48
    // 0x8e5b44: mov             x3, x0
    // 0x8e5b48: ldur            x2, [fp, #-0x20]
    // 0x8e5b4c: stur            x3, [fp, #-0x18]
    // 0x8e5b50: r0 = LoadClassIdInstr(r2)
    //     0x8e5b50: ldur            x0, [x2, #-1]
    //     0x8e5b54: ubfx            x0, x0, #0xc, #0x14
    // 0x8e5b58: mov             x1, x2
    // 0x8e5b5c: r0 = GDT[cid_x0 + 0x12b36]()
    //     0x8e5b5c: mov             x17, #0x2b36
    //     0x8e5b60: movk            x17, #1, lsl #16
    //     0x8e5b64: add             lr, x0, x17
    //     0x8e5b68: ldr             lr, [x21, lr, lsl #3]
    //     0x8e5b6c: blr             lr
    // 0x8e5b70: tbnz            w0, #4, #0x8e5b7c
    // 0x8e5b74: r6 = ""
    //     0x8e5b74: ldr             x6, [PP, #0x900]  ; [pp+0x900] ""
    // 0x8e5b78: b               #0x8e5bb0
    // 0x8e5b7c: r0 = StringBuffer()
    //     0x8e5b7c: bl              #0x7e51d4  ; AllocateStringBufferStub -> StringBuffer (size=0x38)
    // 0x8e5b80: mov             x1, x0
    // 0x8e5b84: stur            x0, [fp, #-0x48]
    // 0x8e5b88: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8e5b88: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8e5b8c: r0 = StringBuffer()
    //     0x8e5b8c: bl              #0x7e4a4c  ; [dart:core] StringBuffer::StringBuffer
    // 0x8e5b90: ldur            x1, [fp, #-0x48]
    // 0x8e5b94: ldur            x2, [fp, #-0x20]
    // 0x8e5b98: r3 = "\n"
    //     0x8e5b98: ldr             x3, [PP, #0x8c0]  ; [pp+0x8c0] "\n"
    // 0x8e5b9c: r0 = writeAll()
    //     0x8e5b9c: bl              #0x8e7e08  ; [dart:core] StringBuffer::writeAll
    // 0x8e5ba0: ldur            x16, [fp, #-0x48]
    // 0x8e5ba4: str             x16, [SP]
    // 0x8e5ba8: r0 = toString()
    //     0x8e5ba8: bl              #0x1101d44  ; [dart:core] StringBuffer::toString
    // 0x8e5bac: mov             x6, x0
    // 0x8e5bb0: ldur            x0, [fp, #-0x18]
    // 0x8e5bb4: stur            x6, [fp, #-0x20]
    // 0x8e5bb8: tbz             w0, #4, #0x8e5cac
    // 0x8e5bbc: ldur            x1, [fp, #-0x40]
    // 0x8e5bc0: cmp             w1, NULL
    // 0x8e5bc4: b.eq            #0x8e5bf0
    // 0x8e5bc8: r0 = LoadClassIdInstr(r1)
    //     0x8e5bc8: ldur            x0, [x1, #-1]
    //     0x8e5bcc: ubfx            x0, x0, #0xc, #0x14
    // 0x8e5bd0: str             x1, [SP]
    // 0x8e5bd4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8e5bd4: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8e5bd8: r0 = GDT[cid_x0 + 0x91c1]()
    //     0x8e5bd8: mov             x17, #0x91c1
    //     0x8e5bdc: add             lr, x0, x17
    //     0x8e5be0: ldr             lr, [x21, lr, lsl #3]
    //     0x8e5be4: blr             lr
    // 0x8e5be8: LoadField: r1 = r0->field_7
    //     0x8e5be8: ldur            w1, [x0, #7]
    // 0x8e5bec: cbnz            w1, #0x8e5bfc
    // 0x8e5bf0: r0 = current()
    //     0x8e5bf0: bl              #0x7f0e88  ; [dart:core] StackTrace::current
    // 0x8e5bf4: mov             x3, x0
    // 0x8e5bf8: b               #0x8e5c00
    // 0x8e5bfc: ldur            x3, [fp, #-0x40]
    // 0x8e5c00: ldur            x0, [fp, #-0x38]
    // 0x8e5c04: ldur            x2, [fp, #-0x10]
    // 0x8e5c08: mov             x1, x3
    // 0x8e5c0c: stur            x3, [fp, #-0x18]
    // 0x8e5c10: r0 = getStackTraceElements()
    //     0x8e5c10: bl              #0x8e786c  ; [package:firebase_crashlytics/src/utils.dart] ::getStackTraceElements
    // 0x8e5c14: ldur            x1, [fp, #-0x18]
    // 0x8e5c18: stur            x0, [fp, #-0x40]
    // 0x8e5c1c: r0 = getBuildId()
    //     0x8e5c1c: bl              #0x8e768c  ; [package:firebase_crashlytics/src/utils.dart] ::getBuildId
    // 0x8e5c20: ldur            x1, [fp, #-0x18]
    // 0x8e5c24: stur            x0, [fp, #-0x18]
    // 0x8e5c28: r0 = getLoadingUnits()
    //     0x8e5c28: bl              #0x8e5e58  ; [package:firebase_crashlytics/src/utils.dart] ::getLoadingUnits
    // 0x8e5c2c: ldur            x1, [fp, #-0x30]
    // 0x8e5c30: stur            x0, [fp, #-0x30]
    // 0x8e5c34: r0 = _delegate()
    //     0x8e5c34: bl              #0x8c0ab0  ; [package:firebase_crashlytics/firebase_crashlytics.dart] FirebaseCrashlytics::_delegate
    // 0x8e5c38: mov             x1, x0
    // 0x8e5c3c: ldur            x0, [fp, #-0x38]
    // 0x8e5c40: stur            x1, [fp, #-0x48]
    // 0x8e5c44: r2 = 60
    //     0x8e5c44: mov             x2, #0x3c
    // 0x8e5c48: branchIfSmi(r0, 0x8e5c54)
    //     0x8e5c48: tbz             w0, #0, #0x8e5c54
    // 0x8e5c4c: r2 = LoadClassIdInstr(r0)
    //     0x8e5c4c: ldur            x2, [x0, #-1]
    //     0x8e5c50: ubfx            x2, x2, #0xc, #0x14
    // 0x8e5c54: str             x0, [SP]
    // 0x8e5c58: mov             x0, x2
    // 0x8e5c5c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8e5c5c: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8e5c60: r0 = GDT[cid_x0 + 0x91c1]()
    //     0x8e5c60: mov             x17, #0x91c1
    //     0x8e5c64: add             lr, x0, x17
    //     0x8e5c68: ldr             lr, [x21, lr, lsl #3]
    //     0x8e5c6c: blr             lr
    // 0x8e5c70: mov             x1, x0
    // 0x8e5c74: ldur            x0, [fp, #-0x10]
    // 0x8e5c78: cmp             w0, NULL
    // 0x8e5c7c: b.ne            #0x8e5c84
    // 0x8e5c80: r0 = Null
    //     0x8e5c80: mov             x0, NULL
    // 0x8e5c84: ldur            x16, [fp, #-0x40]
    // 0x8e5c88: stp             x16, x0, [SP]
    // 0x8e5c8c: mov             x3, x1
    // 0x8e5c90: ldur            x1, [fp, #-0x48]
    // 0x8e5c94: ldur            x2, [fp, #-0x18]
    // 0x8e5c98: ldur            x5, [fp, #-0x28]
    // 0x8e5c9c: ldur            x6, [fp, #-0x20]
    // 0x8e5ca0: ldur            x7, [fp, #-0x30]
    // 0x8e5ca4: r0 = recordError()
    //     0x8e5ca4: bl              #0x8e5cc0  ; [package:firebase_crashlytics_platform_interface/src/method_channel/method_channel_crashlytics.dart] MethodChannelFirebaseCrashlytics::recordError
    // 0x8e5ca8: r0 = ReturnAsync()
    //     0x8e5ca8: b               #0x82fdf0  ; ReturnAsyncStub
    // 0x8e5cac: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x8e5cac: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x8e5cb0: r0 = Throw()
    //     0x8e5cb0: bl              #0x13ddb2c  ; ThrowStub
    // 0x8e5cb4: brk             #0
    // 0x8e5cb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8e5cb8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8e5cbc: b               #0x8e5b28
  }
  _ setCustomKey(/* No info */) async {
    // ** addr: 0x8e85f4, size: 0x8c
    // 0x8e85f4: EnterFrame
    //     0x8e85f4: stp             fp, lr, [SP, #-0x10]!
    //     0x8e85f8: mov             fp, SP
    // 0x8e85fc: AllocStack(0x28)
    //     0x8e85fc: sub             SP, SP, #0x28
    // 0x8e8600: SetupParameters(FirebaseCrashlytics this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */)
    //     0x8e8600: stur            NULL, [fp, #-8]
    //     0x8e8604: stur            x1, [fp, #-0x10]
    //     0x8e8608: stur            x2, [fp, #-0x18]
    //     0x8e860c: stur            x3, [fp, #-0x20]
    // 0x8e8610: CheckStackOverflow
    //     0x8e8610: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8e8614: cmp             SP, x16
    //     0x8e8618: b.ls            #0x8e8678
    // 0x8e861c: InitAsync() -> Future<void?>
    //     0x8e861c: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0x8e8620: bl              #0x7f5e44  ; InitAsyncStub
    // 0x8e8624: ldur            x1, [fp, #-0x10]
    // 0x8e8628: r0 = _delegate()
    //     0x8e8628: bl              #0x8c0ab0  ; [package:firebase_crashlytics/firebase_crashlytics.dart] FirebaseCrashlytics::_delegate
    // 0x8e862c: mov             x1, x0
    // 0x8e8630: ldur            x0, [fp, #-0x20]
    // 0x8e8634: stur            x1, [fp, #-0x10]
    // 0x8e8638: r2 = 60
    //     0x8e8638: mov             x2, #0x3c
    // 0x8e863c: branchIfSmi(r0, 0x8e8648)
    //     0x8e863c: tbz             w0, #0, #0x8e8648
    // 0x8e8640: r2 = LoadClassIdInstr(r0)
    //     0x8e8640: ldur            x2, [x0, #-1]
    //     0x8e8644: ubfx            x2, x2, #0xc, #0x14
    // 0x8e8648: str             x0, [SP]
    // 0x8e864c: mov             x0, x2
    // 0x8e8650: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8e8650: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8e8654: r0 = GDT[cid_x0 + 0x91c1]()
    //     0x8e8654: mov             x17, #0x91c1
    //     0x8e8658: add             lr, x0, x17
    //     0x8e865c: ldr             lr, [x21, lr, lsl #3]
    //     0x8e8660: blr             lr
    // 0x8e8664: ldur            x1, [fp, #-0x10]
    // 0x8e8668: ldur            x2, [fp, #-0x18]
    // 0x8e866c: mov             x3, x0
    // 0x8e8670: r0 = setCustomKey()
    //     0x8e8670: bl              #0x8e8680  ; [package:firebase_crashlytics_platform_interface/src/method_channel/method_channel_crashlytics.dart] MethodChannelFirebaseCrashlytics::setCustomKey
    // 0x8e8674: r0 = ReturnAsync()
    //     0x8e8674: b               #0x82fdf0  ; ReturnAsyncStub
    // 0x8e8678: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8e8678: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8e867c: b               #0x8e861c
  }
  _ setUserIdentifier(/* No info */) {
    // ** addr: 0x13e666c, size: 0x40
    // 0x13e666c: EnterFrame
    //     0x13e666c: stp             fp, lr, [SP, #-0x10]!
    //     0x13e6670: mov             fp, SP
    // 0x13e6674: AllocStack(0x8)
    //     0x13e6674: sub             SP, SP, #8
    // 0x13e6678: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x13e6678: stur            x2, [fp, #-8]
    // 0x13e667c: CheckStackOverflow
    //     0x13e667c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13e6680: cmp             SP, x16
    //     0x13e6684: b.ls            #0x13e66a4
    // 0x13e6688: r0 = _delegate()
    //     0x13e6688: bl              #0x8c0ab0  ; [package:firebase_crashlytics/firebase_crashlytics.dart] FirebaseCrashlytics::_delegate
    // 0x13e668c: mov             x1, x0
    // 0x13e6690: ldur            x2, [fp, #-8]
    // 0x13e6694: r0 = setUserIdentifier()
    //     0x13e6694: bl              #0x13e66ac  ; [package:firebase_crashlytics_platform_interface/src/method_channel/method_channel_crashlytics.dart] MethodChannelFirebaseCrashlytics::setUserIdentifier
    // 0x13e6698: LeaveFrame
    //     0x13e6698: mov             SP, fp
    //     0x13e669c: ldp             fp, lr, [SP], #0x10
    // 0x13e66a0: ret
    //     0x13e66a0: ret             
    // 0x13e66a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13e66a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13e66a8: b               #0x13e6688
  }
  _ recordFlutterError(/* No info */) {
    // ** addr: 0x13eccc4, size: 0x128
    // 0x13eccc4: EnterFrame
    //     0x13eccc4: stp             fp, lr, [SP, #-0x10]!
    //     0x13eccc8: mov             fp, SP
    // 0x13ecccc: AllocStack(0x48)
    //     0x13ecccc: sub             SP, SP, #0x48
    // 0x13eccd0: SetupParameters(FirebaseCrashlytics this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0x13eccd0: mov             x0, x1
    //     0x13eccd4: stur            x1, [fp, #-8]
    //     0x13eccd8: mov             x1, x2
    //     0x13eccdc: stur            x2, [fp, #-0x10]
    // 0x13ecce0: CheckStackOverflow
    //     0x13ecce0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13ecce4: cmp             SP, x16
    //     0x13ecce8: b.ls            #0x13ecde4
    // 0x13eccec: r0 = LoadStaticField(0x474)
    //     0x13eccec: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x13eccf0: ldr             x0, [x0, #0x8e8]
    // 0x13eccf4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x13eccf8: cmp             w0, w16
    // 0x13eccfc: b.ne            #0x13ecd08
    // 0x13ecd00: r2 = presentError
    //     0x13ecd00: ldr             x2, [PP, #0x880]  ; [pp+0x880] Field <FlutterError.presentError>: static late (offset: 0x474)
    // 0x13ecd04: r0 = InitLateStaticField()
    //     0x13ecd04: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0x13ecd08: r16 = false
    //     0x13ecd08: add             x16, NULL, #0x30  ; false
    // 0x13ecd0c: str             x16, [SP]
    // 0x13ecd10: ldur            x1, [fp, #-0x10]
    // 0x13ecd14: r4 = const [0, 0x2, 0x1, 0x1, forceReport, 0x1, null]
    //     0x13ecd14: ldr             x4, [PP, #0x898]  ; [pp+0x898] List(7) [0, 0x2, 0x1, 0x1, "forceReport", 0x1, Null]
    // 0x13ecd18: r0 = dumpErrorToConsole()
    //     0x13ecd18: bl              #0x829d80  ; [package:flutter/src/foundation/assertions.dart] FlutterError::dumpErrorToConsole
    // 0x13ecd1c: ldur            x1, [fp, #-0x10]
    // 0x13ecd20: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x13ecd20: ldur            w0, [x1, #0x17]
    // 0x13ecd24: DecompressPointer r0
    //     0x13ecd24: add             x0, x0, HEAP, lsl #32
    // 0x13ecd28: cmp             w0, NULL
    // 0x13ecd2c: b.ne            #0x13ecd38
    // 0x13ecd30: r0 = Null
    //     0x13ecd30: mov             x0, NULL
    // 0x13ecd34: b               #0x13ecd48
    // 0x13ecd38: str             x0, [SP]
    // 0x13ecd3c: ClosureCall
    //     0x13ecd3c: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x13ecd40: ldur            x2, [x0, #0x1f]
    //     0x13ecd44: blr             x2
    // 0x13ecd48: cmp             w0, NULL
    // 0x13ecd4c: b.ne            #0x13ecd64
    // 0x13ecd50: r1 = <DiagnosticsNode>
    //     0x13ecd50: ldr             x1, [PP, #0x1ea8]  ; [pp+0x1ea8] TypeArguments: <DiagnosticsNode>
    // 0x13ecd54: r2 = 0
    //     0x13ecd54: mov             x2, #0
    // 0x13ecd58: r0 = _GrowableList()
    //     0x13ecd58: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x13ecd5c: mov             x2, x0
    // 0x13ecd60: b               #0x13ecd68
    // 0x13ecd64: mov             x2, x0
    // 0x13ecd68: ldur            x0, [fp, #-0x10]
    // 0x13ecd6c: mov             x1, x0
    // 0x13ecd70: stur            x2, [fp, #-0x18]
    // 0x13ecd74: r0 = exceptionAsString()
    //     0x13ecd74: bl              #0x82bc74  ; [package:flutter/src/foundation/assertions.dart] FlutterErrorDetails::exceptionAsString
    // 0x13ecd78: mov             x2, x0
    // 0x13ecd7c: ldur            x0, [fp, #-0x10]
    // 0x13ecd80: stur            x2, [fp, #-0x28]
    // 0x13ecd84: LoadField: r3 = r0->field_b
    //     0x13ecd84: ldur            w3, [x0, #0xb]
    // 0x13ecd88: DecompressPointer r3
    //     0x13ecd88: add             x3, x3, HEAP, lsl #32
    // 0x13ecd8c: stur            x3, [fp, #-0x20]
    // 0x13ecd90: LoadField: r1 = r0->field_13
    //     0x13ecd90: ldur            w1, [x0, #0x13]
    // 0x13ecd94: DecompressPointer r1
    //     0x13ecd94: add             x1, x1, HEAP, lsl #32
    // 0x13ecd98: cmp             w1, NULL
    // 0x13ecd9c: b.ne            #0x13ecda8
    // 0x13ecda0: r0 = Null
    //     0x13ecda0: mov             x0, NULL
    // 0x13ecda4: b               #0x13ecdb0
    // 0x13ecda8: r1 = ""
    //     0x13ecda8: ldr             x1, [PP, #0x900]  ; [pp+0x900] ""
    // 0x13ecdac: r0 = trim()
    //     0x13ecdac: bl              #0x808ff4  ; [dart:core] _StringBase::trim
    // 0x13ecdb0: ldur            x16, [fp, #-0x18]
    // 0x13ecdb4: stp             x16, x0, [SP, #0x10]
    // 0x13ecdb8: r16 = false
    //     0x13ecdb8: add             x16, NULL, #0x30  ; false
    // 0x13ecdbc: r30 = true
    //     0x13ecdbc: add             lr, NULL, #0x20  ; true
    // 0x13ecdc0: stp             lr, x16, [SP]
    // 0x13ecdc4: ldur            x1, [fp, #-8]
    // 0x13ecdc8: ldur            x2, [fp, #-0x28]
    // 0x13ecdcc: ldur            x3, [fp, #-0x20]
    // 0x13ecdd0: r4 = const [0, 0x7, 0x4, 0x3, fatal, 0x6, information, 0x4, printDetails, 0x5, reason, 0x3, null]
    //     0x13ecdd0: ldr             x4, [PP, #0x7db8]  ; [pp+0x7db8] List(13) [0, 0x7, 0x4, 0x3, "fatal", 0x6, "information", 0x4, "printDetails", 0x5, "reason", 0x3, Null]
    // 0x13ecdd4: r0 = recordError()
    //     0x13ecdd4: bl              #0x8e59b4  ; [package:firebase_crashlytics/firebase_crashlytics.dart] FirebaseCrashlytics::recordError
    // 0x13ecdd8: LeaveFrame
    //     0x13ecdd8: mov             SP, fp
    //     0x13ecddc: ldp             fp, lr, [SP], #0x10
    // 0x13ecde0: ret
    //     0x13ecde0: ret             
    // 0x13ecde4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13ecde4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13ecde8: b               #0x13eccec
  }
}
