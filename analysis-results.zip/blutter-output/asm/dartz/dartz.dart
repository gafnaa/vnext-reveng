// lib: dartz, url: package:dartz/dartz.dart

// class id: 1048685, size: 0x8
class :: {

  static _ right(/* No info */) {
    // ** addr: 0xe86400, size: 0x40
    // 0xe86400: EnterFrame
    //     0xe86400: stp             fp, lr, [SP, #-0x10]!
    //     0xe86404: mov             fp, SP
    // 0xe86408: LoadField: r0 = r4->field_f
    //     0xe86408: ldur            w0, [x4, #0xf]
    // 0xe8640c: cbnz            w0, #0xe86418
    // 0xe86410: r1 = Null
    //     0xe86410: mov             x1, NULL
    // 0xe86414: b               #0xe86424
    // 0xe86418: ArrayLoad: r0 = r4[0]  ; List_4
    //     0xe86418: ldur            w0, [x4, #0x17]
    // 0xe8641c: add             x1, fp, w0, sxtw #2
    // 0xe86420: ldr             x1, [x1, #0x10]
    // 0xe86424: ldr             x0, [fp, #0x10]
    // 0xe86428: r0 = Right()
    //     0xe86428: bl              #0xe866ac  ; AllocateRightStub -> Right<X0, X1> (size=0x10)
    // 0xe8642c: ldr             x1, [fp, #0x10]
    // 0xe86430: StoreField: r0->field_b = r1
    //     0xe86430: stur            w1, [x0, #0xb]
    // 0xe86434: LeaveFrame
    //     0xe86434: mov             SP, fp
    //     0xe86438: ldp             fp, lr, [SP], #0x10
    // 0xe8643c: ret
    //     0xe8643c: ret             
  }
  [closure] static Either<Y0, Y1> left<Y0, Y1>(dynamic, Y0) {
    // ** addr: 0xe86440, size: 0x7c
    // 0xe86440: EnterFrame
    //     0xe86440: stp             fp, lr, [SP, #-0x10]!
    //     0xe86444: mov             fp, SP
    // 0xe86448: AllocStack(0x10)
    //     0xe86448: sub             SP, SP, #0x10
    // 0xe8644c: SetupParameters()
    //     0xe8644c: ldur            w0, [x4, #0xf]
    //     0xe86450: cbnz            w0, #0xe8645c
    //     0xe86454: mov             x1, NULL
    //     0xe86458: b               #0xe86468
    //     0xe8645c: ldur            w0, [x4, #0x17]
    //     0xe86460: add             x1, fp, w0, sxtw #2
    //     0xe86464: ldr             x1, [x1, #0x10]
    //     0xe86468: ldr             x0, [fp, #0x18]
    //     0xe8646c: ldur            w2, [x0, #0xf]
    //     0xe86470: add             x2, x2, HEAP, lsl #32
    //     0xe86474: ldr             x16, [THR, #0xb0]  ; THR::empty_type_arguments
    //     0xe86478: cmp             w2, w16
    //     0xe8647c: b.ne            #0xe86488
    //     0xe86480: mov             x0, x1
    //     0xe86484: b               #0xe8648c
    //     0xe86488: mov             x0, x2
    // 0xe8648c: CheckStackOverflow
    //     0xe8648c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe86490: cmp             SP, x16
    //     0xe86494: b.ls            #0xe864b4
    // 0xe86498: ldr             x16, [fp, #0x10]
    // 0xe8649c: stp             x16, x0, [SP]
    // 0xe864a0: r4 = const [0x2, 0x1, 0x1, 0x1, null]
    //     0xe864a0: ldr             x4, [PP, #0x18e0]  ; [pp+0x18e0] List(5) [0x2, 0x1, 0x1, 0x1, Null]
    // 0xe864a4: r0 = left()
    //     0xe864a4: bl              #0xe864bc  ; [package:dartz/dartz.dart] ::left
    // 0xe864a8: LeaveFrame
    //     0xe864a8: mov             SP, fp
    //     0xe864ac: ldp             fp, lr, [SP], #0x10
    // 0xe864b0: ret
    //     0xe864b0: ret             
    // 0xe864b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe864b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe864b8: b               #0xe86498
  }
  static _ left(/* No info */) {
    // ** addr: 0xe864bc, size: 0x40
    // 0xe864bc: EnterFrame
    //     0xe864bc: stp             fp, lr, [SP, #-0x10]!
    //     0xe864c0: mov             fp, SP
    // 0xe864c4: LoadField: r0 = r4->field_f
    //     0xe864c4: ldur            w0, [x4, #0xf]
    // 0xe864c8: cbnz            w0, #0xe864d4
    // 0xe864cc: r1 = Null
    //     0xe864cc: mov             x1, NULL
    // 0xe864d0: b               #0xe864e0
    // 0xe864d4: ArrayLoad: r0 = r4[0]  ; List_4
    //     0xe864d4: ldur            w0, [x4, #0x17]
    // 0xe864d8: add             x1, fp, w0, sxtw #2
    // 0xe864dc: ldr             x1, [x1, #0x10]
    // 0xe864e0: ldr             x0, [fp, #0x10]
    // 0xe864e4: r0 = Left()
    //     0xe864e4: bl              #0xe86214  ; AllocateLeftStub -> Left<X0, X1> (size=0x10)
    // 0xe864e8: ldr             x1, [fp, #0x10]
    // 0xe864ec: StoreField: r0->field_b = r1
    //     0xe864ec: stur            w1, [x0, #0xb]
    // 0xe864f0: LeaveFrame
    //     0xe864f0: mov             SP, fp
    //     0xe864f4: ldp             fp, lr, [SP], #0x10
    // 0xe864f8: ret
    //     0xe864f8: ret             
  }
}

// class id: 3422, size: 0xc, field offset: 0x8
abstract class MonadOps<X0, X1> extends Object
    implements ApplicativeOps<X0, X1> {
}

// class id: 3423, size: 0xc, field offset: 0x8
abstract class TraversableMonadOps<X0, X1> extends Object
    implements TraversableOps<X0, X1>, MonadOps<X0, X1> {
}

// class id: 3424, size: 0xc, field offset: 0x8
//   const constructor, 
abstract class Either<X0, X1> extends Object
    implements TraversableMonadOps<X0, X1> {

  dynamic length(dynamic) {
    // ** addr: 0xe865ec, size: 0x3c
    // 0xe865ec: EnterFrame
    //     0xe865ec: stp             fp, lr, [SP, #-0x10]!
    //     0xe865f0: mov             fp, SP
    // 0xe865f4: ldr             x2, [fp, #0x10]
    // 0xe865f8: r1 = Function 'length':.
    //     0xe865f8: add             x1, PP, #0x82, lsl #12  ; [pp+0x82958] AnonymousClosure: (0xe86610), in [package:dartz/dartz.dart] Either::length (0xe86660)
    //     0xe865fc: ldr             x1, [x1, #0x958]
    // 0xe86600: r0 = AllocateClosure()
    //     0xe86600: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xe86604: LeaveFrame
    //     0xe86604: mov             SP, fp
    //     0xe86608: ldp             fp, lr, [SP], #0x10
    // 0xe8660c: ret
    //     0xe8660c: ret             
  }
  Either<X0, Y0> map<Y0>(Either<X0, X1>, (dynamic, X1) => Y0) {
    // ** addr: 0xe86220, size: 0x98
    // 0xe86220: EnterFrame
    //     0xe86220: stp             fp, lr, [SP, #-0x10]!
    //     0xe86224: mov             fp, SP
    // 0xe86228: AllocStack(0x20)
    //     0xe86228: sub             SP, SP, #0x20
    // 0xe8622c: SetupParameters([dynamic _, dynamic _ /* r3 */])
    //     0xe8622c: ldur            w0, [x4, #0xf]
    //     0xe86230: cbnz            w0, #0xe8623c
    //     0xe86234: mov             x4, NULL
    //     0xe86238: b               #0xe8624c
    //     0xe8623c: ldur            w0, [x4, #0x17]
    //     0xe86240: add             x1, fp, w0, sxtw #2
    //     0xe86244: ldr             x1, [x1, #0x10]
    //     0xe86248: mov             x4, x1
    //     0xe8624c: ldr             x3, [fp, #0x18]
    //     0xe86250: stur            x4, [fp, #-8]
    // 0xe86254: CheckStackOverflow
    //     0xe86254: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe86258: cmp             SP, x16
    //     0xe8625c: b.ls            #0xe862b0
    // 0xe86260: LoadField: r2 = r3->field_7
    //     0xe86260: ldur            w2, [x3, #7]
    // 0xe86264: DecompressPointer r2
    //     0xe86264: add             x2, x2, HEAP, lsl #32
    // 0xe86268: ldr             x0, [fp, #0x10]
    // 0xe8626c: mov             x1, x4
    // 0xe86270: r8 = (dynamic this, X1) => Y0
    //     0xe86270: add             x8, PP, #0x82, lsl #12  ; [pp+0x82970] FunctionType: (dynamic this, X1) => Y0
    //     0xe86274: ldr             x8, [x8, #0x970]
    // 0xe86278: LoadField: r9 = r8->field_7
    //     0xe86278: ldur            x9, [x8, #7]
    // 0xe8627c: r3 = Null
    //     0xe8627c: add             x3, PP, #0x82, lsl #12  ; [pp+0x82978] Null
    //     0xe86280: ldr             x3, [x3, #0x978]
    // 0xe86284: blr             x9
    // 0xe86288: ldur            x16, [fp, #-8]
    // 0xe8628c: ldr             lr, [fp, #0x18]
    // 0xe86290: stp             lr, x16, [SP, #8]
    // 0xe86294: ldr             x16, [fp, #0x10]
    // 0xe86298: str             x16, [SP]
    // 0xe8629c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xe8629c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xe862a0: r0 = map()
    //     0xe862a0: bl              #0xe862b8  ; [package:dartz/dartz.dart] Either::map
    // 0xe862a4: LeaveFrame
    //     0xe862a4: mov             SP, fp
    //     0xe862a8: ldp             fp, lr, [SP], #0x10
    // 0xe862ac: ret
    //     0xe862ac: ret             
    // 0xe862b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe862b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe862b4: b               #0xe86260
  }
  Either<X0, Y0> map<Y0>(Either<X0, X1>, (dynamic, X1) => Y0) {
    // ** addr: 0xe862b8, size: 0x148
    // 0xe862b8: EnterFrame
    //     0xe862b8: stp             fp, lr, [SP, #-0x10]!
    //     0xe862bc: mov             fp, SP
    // 0xe862c0: AllocStack(0x28)
    //     0xe862c0: sub             SP, SP, #0x28
    // 0xe862c4: SetupParameters([dynamic _, dynamic _ /* r0 */])
    //     0xe862c4: ldur            w0, [x4, #0xf]
    //     0xe862c8: cbnz            w0, #0xe862d4
    //     0xe862cc: mov             x4, NULL
    //     0xe862d0: b               #0xe862e4
    //     0xe862d4: ldur            w0, [x4, #0x17]
    //     0xe862d8: add             x1, fp, w0, sxtw #2
    //     0xe862dc: ldr             x1, [x1, #0x10]
    //     0xe862e0: mov             x4, x1
    //     0xe862e4: ldr             x0, [fp, #0x18]
    //     0xe862e8: stur            x4, [fp, #-0x10]
    // 0xe862ec: CheckStackOverflow
    //     0xe862ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe862f0: cmp             SP, x16
    //     0xe862f4: b.ls            #0xe863f8
    // 0xe862f8: LoadField: r5 = r0->field_7
    //     0xe862f8: ldur            w5, [x0, #7]
    // 0xe862fc: DecompressPointer r5
    //     0xe862fc: add             x5, x5, HEAP, lsl #32
    // 0xe86300: mov             x2, x5
    // 0xe86304: mov             x1, x4
    // 0xe86308: stur            x5, [fp, #-8]
    // 0xe8630c: r3 = <X0, Y0>
    //     0xe8630c: add             x3, PP, #0x82, lsl #12  ; [pp+0x82988] TypeArguments: <X0, Y0>
    //     0xe86310: ldr             x3, [x3, #0x988]
    // 0xe86314: r0 = Null
    //     0xe86314: mov             x0, NULL
    // 0xe86318: cmp             x2, x0
    // 0xe8631c: b.ne            #0xe86328
    // 0xe86320: cmp             x1, x0
    // 0xe86324: b.eq            #0xe86334
    // 0xe86328: r30 = InstantiateTypeArgumentsStub
    //     0xe86328: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0xe8632c: LoadField: r30 = r30->field_7
    //     0xe8632c: ldur            lr, [lr, #7]
    // 0xe86330: blr             lr
    // 0xe86334: r16 = Closure: <Y0, Y1>(Y0) => Either<Y0, Y1> from Function 'left': static.
    //     0xe86334: add             x16, PP, #0x82, lsl #12  ; [pp+0x82990] Closure: <Y0, Y1>(Y0) => Either<Y0, Y1> from Function 'left': static. (0x7f2adad6d440)
    //     0xe86338: ldr             x16, [x16, #0x990]
    // 0xe8633c: stp             x0, x16, [SP]
    // 0xe86340: r0 = _instantiateClosure()
    //     0xe86340: bl              #0x7d92dc  ; [dart:_internal] ::_instantiateClosure
    // 0xe86344: mov             x1, x0
    // 0xe86348: ldr             x0, [fp, #0x18]
    // 0xe8634c: r2 = LoadClassIdInstr(r0)
    //     0xe8634c: ldur            x2, [x0, #-1]
    //     0xe86350: ubfx            x2, x2, #0xc, #0x14
    // 0xe86354: cmp             x2, #0xd61
    // 0xe86358: b.ne            #0xe863d0
    // 0xe8635c: LoadField: r4 = r0->field_b
    //     0xe8635c: ldur            w4, [x0, #0xb]
    // 0xe86360: DecompressPointer r4
    //     0xe86360: add             x4, x4, HEAP, lsl #32
    // 0xe86364: ldur            x2, [fp, #-8]
    // 0xe86368: ldur            x1, [fp, #-0x10]
    // 0xe8636c: stur            x4, [fp, #-0x18]
    // 0xe86370: r3 = <X0, Y0>
    //     0xe86370: add             x3, PP, #0x82, lsl #12  ; [pp+0x82988] TypeArguments: <X0, Y0>
    //     0xe86374: ldr             x3, [x3, #0x988]
    // 0xe86378: r0 = Null
    //     0xe86378: mov             x0, NULL
    // 0xe8637c: cmp             x2, x0
    // 0xe86380: b.ne            #0xe8638c
    // 0xe86384: cmp             x1, x0
    // 0xe86388: b.eq            #0xe86398
    // 0xe8638c: r30 = InstantiateTypeArgumentsStub
    //     0xe8638c: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0xe86390: LoadField: r30 = r30->field_7
    //     0xe86390: ldur            lr, [lr, #7]
    // 0xe86394: blr             lr
    // 0xe86398: mov             x1, x0
    // 0xe8639c: stur            x1, [fp, #-8]
    // 0xe863a0: ldr             x16, [fp, #0x10]
    // 0xe863a4: ldur            lr, [fp, #-0x18]
    // 0xe863a8: stp             lr, x16, [SP]
    // 0xe863ac: ldr             x0, [fp, #0x10]
    // 0xe863b0: ClosureCall
    //     0xe863b0: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xe863b4: ldur            x2, [x0, #0x1f]
    //     0xe863b8: blr             x2
    // 0xe863bc: ldur            x16, [fp, #-8]
    // 0xe863c0: stp             x0, x16, [SP]
    // 0xe863c4: r4 = const [0x2, 0x1, 0x1, 0x1, null]
    //     0xe863c4: ldr             x4, [PP, #0x18e0]  ; [pp+0x18e0] List(5) [0x2, 0x1, 0x1, 0x1, Null]
    // 0xe863c8: r0 = right()
    //     0xe863c8: bl              #0xe86400  ; [package:dartz/dartz.dart] ::right
    // 0xe863cc: b               #0xe863ec
    // 0xe863d0: LoadField: r2 = r0->field_b
    //     0xe863d0: ldur            w2, [x0, #0xb]
    // 0xe863d4: DecompressPointer r2
    //     0xe863d4: add             x2, x2, HEAP, lsl #32
    // 0xe863d8: stp             x2, x1, [SP]
    // 0xe863dc: mov             x0, x1
    // 0xe863e0: ClosureCall
    //     0xe863e0: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xe863e4: ldur            x2, [x0, #0x1f]
    //     0xe863e8: blr             x2
    // 0xe863ec: LeaveFrame
    //     0xe863ec: mov             SP, fp
    //     0xe863f0: ldp             fp, lr, [SP], #0x10
    // 0xe863f4: ret
    //     0xe863f4: ret             
    // 0xe863f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe863f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe863fc: b               #0xe862f8
  }
  void forEach(Either<X0, X1>, (dynamic, X1) => void) {
    // ** addr: 0xe86514, size: 0x78
    // 0xe86514: EnterFrame
    //     0xe86514: stp             fp, lr, [SP, #-0x10]!
    //     0xe86518: mov             fp, SP
    // 0xe8651c: CheckStackOverflow
    //     0xe8651c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe86520: cmp             SP, x16
    //     0xe86524: b.ls            #0xe8656c
    // 0xe86528: ldr             x3, [fp, #0x18]
    // 0xe8652c: LoadField: r2 = r3->field_7
    //     0xe8652c: ldur            w2, [x3, #7]
    // 0xe86530: DecompressPointer r2
    //     0xe86530: add             x2, x2, HEAP, lsl #32
    // 0xe86534: ldr             x0, [fp, #0x10]
    // 0xe86538: r1 = Null
    //     0xe86538: mov             x1, NULL
    // 0xe8653c: r8 = (dynamic this, X1) => void?
    //     0xe8653c: add             x8, PP, #0x82, lsl #12  ; [pp+0x82940] FunctionType: (dynamic this, X1) => void?
    //     0xe86540: ldr             x8, [x8, #0x940]
    // 0xe86544: LoadField: r9 = r8->field_7
    //     0xe86544: ldur            x9, [x8, #7]
    // 0xe86548: r3 = Null
    //     0xe86548: add             x3, PP, #0x82, lsl #12  ; [pp+0x82948] Null
    //     0xe8654c: ldr             x3, [x3, #0x948]
    // 0xe86550: blr             x9
    // 0xe86554: ldr             x1, [fp, #0x18]
    // 0xe86558: ldr             x2, [fp, #0x10]
    // 0xe8655c: r0 = forEach()
    //     0xe8655c: bl              #0xe86574  ; [package:dartz/dartz.dart] Either::forEach
    // 0xe86560: LeaveFrame
    //     0xe86560: mov             SP, fp
    //     0xe86564: ldp             fp, lr, [SP], #0x10
    // 0xe86568: ret
    //     0xe86568: ret             
    // 0xe8656c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe8656c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe86570: b               #0xe86528
  }
  void forEach(Either<X0, X1>, (dynamic, X1) => void) {
    // ** addr: 0xe86574, size: 0x60
    // 0xe86574: EnterFrame
    //     0xe86574: stp             fp, lr, [SP, #-0x10]!
    //     0xe86578: mov             fp, SP
    // 0xe8657c: AllocStack(0x10)
    //     0xe8657c: sub             SP, SP, #0x10
    // 0xe86580: SetupParameters(dynamic _ /* r2 => r0 */)
    //     0xe86580: mov             x0, x2
    // 0xe86584: CheckStackOverflow
    //     0xe86584: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe86588: cmp             SP, x16
    //     0xe8658c: b.ls            #0xe865cc
    // 0xe86590: r2 = LoadClassIdInstr(r1)
    //     0xe86590: ldur            x2, [x1, #-1]
    //     0xe86594: ubfx            x2, x2, #0xc, #0x14
    // 0xe86598: cmp             x2, #0xd61
    // 0xe8659c: b.ne            #0xe865bc
    // 0xe865a0: LoadField: r2 = r1->field_b
    //     0xe865a0: ldur            w2, [x1, #0xb]
    // 0xe865a4: DecompressPointer r2
    //     0xe865a4: add             x2, x2, HEAP, lsl #32
    // 0xe865a8: stp             x2, x0, [SP]
    // 0xe865ac: ClosureCall
    //     0xe865ac: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xe865b0: ldur            x2, [x0, #0x1f]
    //     0xe865b4: blr             x2
    // 0xe865b8: b               #0xe865c0
    // 0xe865bc: r0 = Null
    //     0xe865bc: mov             x0, NULL
    // 0xe865c0: LeaveFrame
    //     0xe865c0: mov             SP, fp
    //     0xe865c4: ldp             fp, lr, [SP], #0x10
    // 0xe865c8: ret
    //     0xe865c8: ret             
    // 0xe865cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe865cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe865d0: b               #0xe86590
  }
  [closure] int length(dynamic) {
    // ** addr: 0xe86610, size: 0x50
    // 0xe86610: EnterFrame
    //     0xe86610: stp             fp, lr, [SP, #-0x10]!
    //     0xe86614: mov             fp, SP
    // 0xe86618: ldr             x0, [fp, #0x10]
    // 0xe8661c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xe8661c: ldur            w1, [x0, #0x17]
    // 0xe86620: DecompressPointer r1
    //     0xe86620: add             x1, x1, HEAP, lsl #32
    // 0xe86624: CheckStackOverflow
    //     0xe86624: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe86628: cmp             SP, x16
    //     0xe8662c: b.ls            #0xe86658
    // 0xe86630: r0 = length()
    //     0xe86630: bl              #0xe86660  ; [package:dartz/dartz.dart] Either::length
    // 0xe86634: mov             x2, x0
    // 0xe86638: r0 = BoxInt64Instr(r2)
    //     0xe86638: sbfiz           x0, x2, #1, #0x1f
    //     0xe8663c: cmp             x2, x0, asr #1
    //     0xe86640: b.eq            #0xe8664c
    //     0xe86644: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xe86648: stur            x2, [x0, #7]
    // 0xe8664c: LeaveFrame
    //     0xe8664c: mov             SP, fp
    //     0xe86650: ldp             fp, lr, [SP], #0x10
    // 0xe86654: ret
    //     0xe86654: ret             
    // 0xe86658: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe86658: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe8665c: b               #0xe86630
  }
  _ length(/* No info */) {
    // ** addr: 0xe86660, size: 0x20
    // 0xe86660: r2 = LoadClassIdInstr(r1)
    //     0xe86660: ldur            x2, [x1, #-1]
    //     0xe86664: ubfx            x2, x2, #0xc, #0x14
    // 0xe86668: cmp             x2, #0xd61
    // 0xe8666c: b.ne            #0xe86678
    // 0xe86670: r0 = 1
    //     0xe86670: mov             x0, #1
    // 0xe86674: b               #0xe8667c
    // 0xe86678: r0 = 0
    //     0xe86678: mov             x0, #0
    // 0xe8667c: ret
    //     0xe8667c: ret             
  }
  _ toString(/* No info */) {
    // ** addr: 0x11141f8, size: 0xbc
    // 0x11141f8: EnterFrame
    //     0x11141f8: stp             fp, lr, [SP, #-0x10]!
    //     0x11141fc: mov             fp, SP
    // 0x1114200: AllocStack(0x10)
    //     0x1114200: sub             SP, SP, #0x10
    // 0x1114204: CheckStackOverflow
    //     0x1114204: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1114208: cmp             SP, x16
    //     0x111420c: b.ls            #0x11142ac
    // 0x1114210: ldr             x0, [fp, #0x10]
    // 0x1114214: r1 = LoadClassIdInstr(r0)
    //     0x1114214: ldur            x1, [x0, #-1]
    //     0x1114218: ubfx            x1, x1, #0xc, #0x14
    // 0x111421c: cmp             x1, #0xd61
    // 0x1114220: b.ne            #0x1114264
    // 0x1114224: LoadField: r3 = r0->field_b
    //     0x1114224: ldur            w3, [x0, #0xb]
    // 0x1114228: DecompressPointer r3
    //     0x1114228: add             x3, x3, HEAP, lsl #32
    // 0x111422c: stur            x3, [fp, #-8]
    // 0x1114230: r1 = Null
    //     0x1114230: mov             x1, NULL
    // 0x1114234: r2 = 6
    //     0x1114234: mov             x2, #6
    // 0x1114238: r0 = AllocateArray()
    //     0x1114238: bl              #0x13df928  ; AllocateArrayStub
    // 0x111423c: r16 = "Right("
    //     0x111423c: add             x16, PP, #0x82, lsl #12  ; [pp+0x82960] "Right("
    //     0x1114240: ldr             x16, [x16, #0x960]
    // 0x1114244: StoreField: r0->field_f = r16
    //     0x1114244: stur            w16, [x0, #0xf]
    // 0x1114248: ldur            x1, [fp, #-8]
    // 0x111424c: StoreField: r0->field_13 = r1
    //     0x111424c: stur            w1, [x0, #0x13]
    // 0x1114250: r16 = ")"
    //     0x1114250: ldr             x16, [PP, #0xe60]  ; [pp+0xe60] ")"
    // 0x1114254: ArrayStore: r0[0] = r16  ; List_4
    //     0x1114254: stur            w16, [x0, #0x17]
    // 0x1114258: str             x0, [SP]
    // 0x111425c: r0 = _interpolate()
    //     0x111425c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x1114260: b               #0x11142a0
    // 0x1114264: LoadField: r3 = r0->field_b
    //     0x1114264: ldur            w3, [x0, #0xb]
    // 0x1114268: DecompressPointer r3
    //     0x1114268: add             x3, x3, HEAP, lsl #32
    // 0x111426c: stur            x3, [fp, #-8]
    // 0x1114270: r1 = Null
    //     0x1114270: mov             x1, NULL
    // 0x1114274: r2 = 6
    //     0x1114274: mov             x2, #6
    // 0x1114278: r0 = AllocateArray()
    //     0x1114278: bl              #0x13df928  ; AllocateArrayStub
    // 0x111427c: r16 = "Left("
    //     0x111427c: add             x16, PP, #0x82, lsl #12  ; [pp+0x82968] "Left("
    //     0x1114280: ldr             x16, [x16, #0x968]
    // 0x1114284: StoreField: r0->field_f = r16
    //     0x1114284: stur            w16, [x0, #0xf]
    // 0x1114288: ldur            x1, [fp, #-8]
    // 0x111428c: StoreField: r0->field_13 = r1
    //     0x111428c: stur            w1, [x0, #0x13]
    // 0x1114290: r16 = ")"
    //     0x1114290: ldr             x16, [PP, #0xe60]  ; [pp+0xe60] ")"
    // 0x1114294: ArrayStore: r0[0] = r16  ; List_4
    //     0x1114294: stur            w16, [x0, #0x17]
    // 0x1114298: str             x0, [SP]
    // 0x111429c: r0 = _interpolate()
    //     0x111429c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11142a0: LeaveFrame
    //     0x11142a0: mov             SP, fp
    //     0x11142a4: ldp             fp, lr, [SP], #0x10
    // 0x11142a8: ret
    //     0x11142a8: ret             
    // 0x11142ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11142ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11142b0: b               #0x1114210
  }
}

// class id: 3425, size: 0x10, field offset: 0xc
//   const constructor, 
class Right<X0, X1> extends Either<X0, X1> {

  bool field_c;

  _ ==(/* No info */) {
    // ** addr: 0x1293608, size: 0xa0
    // 0x1293608: EnterFrame
    //     0x1293608: stp             fp, lr, [SP, #-0x10]!
    //     0x129360c: mov             fp, SP
    // 0x1293610: AllocStack(0x10)
    //     0x1293610: sub             SP, SP, #0x10
    // 0x1293614: CheckStackOverflow
    //     0x1293614: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1293618: cmp             SP, x16
    //     0x129361c: b.ls            #0x12936a0
    // 0x1293620: ldr             x0, [fp, #0x10]
    // 0x1293624: cmp             w0, NULL
    // 0x1293628: b.ne            #0x129363c
    // 0x129362c: r0 = false
    //     0x129362c: add             x0, NULL, #0x30  ; false
    // 0x1293630: LeaveFrame
    //     0x1293630: mov             SP, fp
    //     0x1293634: ldp             fp, lr, [SP], #0x10
    // 0x1293638: ret
    //     0x1293638: ret             
    // 0x129363c: r1 = 60
    //     0x129363c: mov             x1, #0x3c
    // 0x1293640: branchIfSmi(r0, 0x129364c)
    //     0x1293640: tbz             w0, #0, #0x129364c
    // 0x1293644: r1 = LoadClassIdInstr(r0)
    //     0x1293644: ldur            x1, [x0, #-1]
    //     0x1293648: ubfx            x1, x1, #0xc, #0x14
    // 0x129364c: cmp             x1, #0xd61
    // 0x1293650: b.ne            #0x1293690
    // 0x1293654: ldr             x1, [fp, #0x18]
    // 0x1293658: LoadField: r2 = r0->field_b
    //     0x1293658: ldur            w2, [x0, #0xb]
    // 0x129365c: DecompressPointer r2
    //     0x129365c: add             x2, x2, HEAP, lsl #32
    // 0x1293660: LoadField: r0 = r1->field_b
    //     0x1293660: ldur            w0, [x1, #0xb]
    // 0x1293664: DecompressPointer r0
    //     0x1293664: add             x0, x0, HEAP, lsl #32
    // 0x1293668: r1 = 60
    //     0x1293668: mov             x1, #0x3c
    // 0x129366c: branchIfSmi(r2, 0x1293678)
    //     0x129366c: tbz             w2, #0, #0x1293678
    // 0x1293670: r1 = LoadClassIdInstr(r2)
    //     0x1293670: ldur            x1, [x2, #-1]
    //     0x1293674: ubfx            x1, x1, #0xc, #0x14
    // 0x1293678: stp             x0, x2, [SP]
    // 0x129367c: mov             x0, x1
    // 0x1293680: mov             lr, x0
    // 0x1293684: ldr             lr, [x21, lr, lsl #3]
    // 0x1293688: blr             lr
    // 0x129368c: b               #0x1293694
    // 0x1293690: r0 = false
    //     0x1293690: add             x0, NULL, #0x30  ; false
    // 0x1293694: LeaveFrame
    //     0x1293694: mov             SP, fp
    //     0x1293698: ldp             fp, lr, [SP], #0x10
    // 0x129369c: ret
    //     0x129369c: ret             
    // 0x12936a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12936a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12936a4: b               #0x1293620
  }
  _ fold(/* No info */) {
    // ** addr: 0x12f12e4, size: 0x50
    // 0x12f12e4: EnterFrame
    //     0x12f12e4: stp             fp, lr, [SP, #-0x10]!
    //     0x12f12e8: mov             fp, SP
    // 0x12f12ec: AllocStack(0x10)
    //     0x12f12ec: sub             SP, SP, #0x10
    // 0x12f12f0: CheckStackOverflow
    //     0x12f12f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f12f4: cmp             SP, x16
    //     0x12f12f8: b.ls            #0x12f132c
    // 0x12f12fc: ldr             x0, [fp, #0x20]
    // 0x12f1300: LoadField: r1 = r0->field_b
    //     0x12f1300: ldur            w1, [x0, #0xb]
    // 0x12f1304: DecompressPointer r1
    //     0x12f1304: add             x1, x1, HEAP, lsl #32
    // 0x12f1308: ldr             x16, [fp, #0x10]
    // 0x12f130c: stp             x1, x16, [SP]
    // 0x12f1310: ldr             x0, [fp, #0x10]
    // 0x12f1314: ClosureCall
    //     0x12f1314: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x12f1318: ldur            x2, [x0, #0x1f]
    //     0x12f131c: blr             x2
    // 0x12f1320: LeaveFrame
    //     0x12f1320: mov             SP, fp
    //     0x12f1324: ldp             fp, lr, [SP], #0x10
    // 0x12f1328: ret
    //     0x12f1328: ret             
    // 0x12f132c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f132c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f1330: b               #0x12f12fc
  }
}

// class id: 3426, size: 0x10, field offset: 0xc
//   const constructor, 
class Left<X0, X1> extends Either<X0, X1> {

  _ ==(/* No info */) {
    // ** addr: 0x1293568, size: 0xa0
    // 0x1293568: EnterFrame
    //     0x1293568: stp             fp, lr, [SP, #-0x10]!
    //     0x129356c: mov             fp, SP
    // 0x1293570: AllocStack(0x10)
    //     0x1293570: sub             SP, SP, #0x10
    // 0x1293574: CheckStackOverflow
    //     0x1293574: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1293578: cmp             SP, x16
    //     0x129357c: b.ls            #0x1293600
    // 0x1293580: ldr             x0, [fp, #0x10]
    // 0x1293584: cmp             w0, NULL
    // 0x1293588: b.ne            #0x129359c
    // 0x129358c: r0 = false
    //     0x129358c: add             x0, NULL, #0x30  ; false
    // 0x1293590: LeaveFrame
    //     0x1293590: mov             SP, fp
    //     0x1293594: ldp             fp, lr, [SP], #0x10
    // 0x1293598: ret
    //     0x1293598: ret             
    // 0x129359c: r1 = 60
    //     0x129359c: mov             x1, #0x3c
    // 0x12935a0: branchIfSmi(r0, 0x12935ac)
    //     0x12935a0: tbz             w0, #0, #0x12935ac
    // 0x12935a4: r1 = LoadClassIdInstr(r0)
    //     0x12935a4: ldur            x1, [x0, #-1]
    //     0x12935a8: ubfx            x1, x1, #0xc, #0x14
    // 0x12935ac: cmp             x1, #0xd62
    // 0x12935b0: b.ne            #0x12935f0
    // 0x12935b4: ldr             x1, [fp, #0x18]
    // 0x12935b8: LoadField: r2 = r0->field_b
    //     0x12935b8: ldur            w2, [x0, #0xb]
    // 0x12935bc: DecompressPointer r2
    //     0x12935bc: add             x2, x2, HEAP, lsl #32
    // 0x12935c0: LoadField: r0 = r1->field_b
    //     0x12935c0: ldur            w0, [x1, #0xb]
    // 0x12935c4: DecompressPointer r0
    //     0x12935c4: add             x0, x0, HEAP, lsl #32
    // 0x12935c8: r1 = 60
    //     0x12935c8: mov             x1, #0x3c
    // 0x12935cc: branchIfSmi(r2, 0x12935d8)
    //     0x12935cc: tbz             w2, #0, #0x12935d8
    // 0x12935d0: r1 = LoadClassIdInstr(r2)
    //     0x12935d0: ldur            x1, [x2, #-1]
    //     0x12935d4: ubfx            x1, x1, #0xc, #0x14
    // 0x12935d8: stp             x0, x2, [SP]
    // 0x12935dc: mov             x0, x1
    // 0x12935e0: mov             lr, x0
    // 0x12935e4: ldr             lr, [x21, lr, lsl #3]
    // 0x12935e8: blr             lr
    // 0x12935ec: b               #0x12935f4
    // 0x12935f0: r0 = false
    //     0x12935f0: add             x0, NULL, #0x30  ; false
    // 0x12935f4: LeaveFrame
    //     0x12935f4: mov             SP, fp
    //     0x12935f8: ldp             fp, lr, [SP], #0x10
    // 0x12935fc: ret
    //     0x12935fc: ret             
    // 0x1293600: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1293600: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1293604: b               #0x1293580
  }
  _ fold(/* No info */) {
    // ** addr: 0x12f1294, size: 0x50
    // 0x12f1294: EnterFrame
    //     0x12f1294: stp             fp, lr, [SP, #-0x10]!
    //     0x12f1298: mov             fp, SP
    // 0x12f129c: AllocStack(0x10)
    //     0x12f129c: sub             SP, SP, #0x10
    // 0x12f12a0: CheckStackOverflow
    //     0x12f12a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f12a4: cmp             SP, x16
    //     0x12f12a8: b.ls            #0x12f12dc
    // 0x12f12ac: ldr             x0, [fp, #0x20]
    // 0x12f12b0: LoadField: r1 = r0->field_b
    //     0x12f12b0: ldur            w1, [x0, #0xb]
    // 0x12f12b4: DecompressPointer r1
    //     0x12f12b4: add             x1, x1, HEAP, lsl #32
    // 0x12f12b8: ldr             x16, [fp, #0x18]
    // 0x12f12bc: stp             x1, x16, [SP]
    // 0x12f12c0: ldr             x0, [fp, #0x18]
    // 0x12f12c4: ClosureCall
    //     0x12f12c4: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x12f12c8: ldur            x2, [x0, #0x1f]
    //     0x12f12cc: blr             x2
    // 0x12f12d0: LeaveFrame
    //     0x12f12d0: mov             SP, fp
    //     0x12f12d4: ldp             fp, lr, [SP], #0x10
    // 0x12f12d8: ret
    //     0x12f12d8: ret             
    // 0x12f12dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f12dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f12e0: b               #0x12f12ac
  }
}

// class id: 3427, size: 0xc, field offset: 0x8
abstract class ApplicativeOps<X0, X1> extends Object
    implements FunctorOps<X0, X1> {
}

// class id: 4580, size: 0xc, field offset: 0x8
abstract class FoldableOps<X0, X1> extends Object {
}

// class id: 4581, size: 0xc, field offset: 0x8
abstract class FunctorOps<X0, X1> extends Object {
}

// class id: 4583, size: 0xc, field offset: 0xc
abstract class TraversableOps<X0, X1> extends _MixinApplication140&FunctorOps&FoldableOps<X0, X1> {
}
