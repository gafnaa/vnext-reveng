// lib: , url: package:cross_file/src/types/io.dart

// class id: 1048670, size: 0x8
class :: {
}

// class id: 3558, size: 0x18, field offset: 0x8
class XFile extends XFileBase {

  dynamic length(dynamic) {
    // ** addr: 0xe8fb28, size: 0x3c
    // 0xe8fb28: EnterFrame
    //     0xe8fb28: stp             fp, lr, [SP, #-0x10]!
    //     0xe8fb2c: mov             fp, SP
    // 0xe8fb30: ldr             x2, [fp, #0x10]
    // 0xe8fb34: r1 = Function 'length':.
    //     0xe8fb34: add             x1, PP, #0xa0, lsl #12  ; [pp+0xa0be8] AnonymousClosure: (0xe8fb4c), in [package:cross_file/src/types/io.dart] XFile::length (0xe8fb84)
    //     0xe8fb38: ldr             x1, [x1, #0xbe8]
    // 0xe8fb3c: r0 = AllocateClosure()
    //     0xe8fb3c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xe8fb40: LeaveFrame
    //     0xe8fb40: mov             SP, fp
    //     0xe8fb44: ldp             fp, lr, [SP], #0x10
    // 0xe8fb48: ret
    //     0xe8fb48: ret             
  }
  [closure] Future<int> length(dynamic) {
    // ** addr: 0xe8fb4c, size: 0x38
    // 0xe8fb4c: EnterFrame
    //     0xe8fb4c: stp             fp, lr, [SP, #-0x10]!
    //     0xe8fb50: mov             fp, SP
    // 0xe8fb54: ldr             x0, [fp, #0x10]
    // 0xe8fb58: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xe8fb58: ldur            w1, [x0, #0x17]
    // 0xe8fb5c: DecompressPointer r1
    //     0xe8fb5c: add             x1, x1, HEAP, lsl #32
    // 0xe8fb60: CheckStackOverflow
    //     0xe8fb60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe8fb64: cmp             SP, x16
    //     0xe8fb68: b.ls            #0xe8fb7c
    // 0xe8fb6c: r0 = length()
    //     0xe8fb6c: bl              #0xe8fb84  ; [package:cross_file/src/types/io.dart] XFile::length
    // 0xe8fb70: LeaveFrame
    //     0xe8fb70: mov             SP, fp
    //     0xe8fb74: ldp             fp, lr, [SP], #0x10
    // 0xe8fb78: ret
    //     0xe8fb78: ret             
    // 0xe8fb7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe8fb7c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe8fb80: b               #0xe8fb6c
  }
  _ length(/* No info */) {
    // ** addr: 0xe8fb84, size: 0x38
    // 0xe8fb84: EnterFrame
    //     0xe8fb84: stp             fp, lr, [SP, #-0x10]!
    //     0xe8fb88: mov             fp, SP
    // 0xe8fb8c: CheckStackOverflow
    //     0xe8fb8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe8fb90: cmp             SP, x16
    //     0xe8fb94: b.ls            #0xe8fbb4
    // 0xe8fb98: LoadField: r0 = r1->field_7
    //     0xe8fb98: ldur            w0, [x1, #7]
    // 0xe8fb9c: DecompressPointer r0
    //     0xe8fb9c: add             x0, x0, HEAP, lsl #32
    // 0xe8fba0: mov             x1, x0
    // 0xe8fba4: r0 = length()
    //     0xe8fba4: bl              #0x123a20c  ; [dart:io] _File::length
    // 0xe8fba8: LeaveFrame
    //     0xe8fba8: mov             SP, fp
    //     0xe8fbac: ldp             fp, lr, [SP], #0x10
    // 0xe8fbb0: ret
    //     0xe8fbb0: ret             
    // 0xe8fbb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe8fbb4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe8fbb8: b               #0xe8fb98
  }
  _ readAsBytes(/* No info */) {
    // ** addr: 0xe8fbc8, size: 0x38
    // 0xe8fbc8: EnterFrame
    //     0xe8fbc8: stp             fp, lr, [SP, #-0x10]!
    //     0xe8fbcc: mov             fp, SP
    // 0xe8fbd0: CheckStackOverflow
    //     0xe8fbd0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe8fbd4: cmp             SP, x16
    //     0xe8fbd8: b.ls            #0xe8fbf8
    // 0xe8fbdc: LoadField: r0 = r1->field_7
    //     0xe8fbdc: ldur            w0, [x1, #7]
    // 0xe8fbe0: DecompressPointer r0
    //     0xe8fbe0: add             x0, x0, HEAP, lsl #32
    // 0xe8fbe4: mov             x1, x0
    // 0xe8fbe8: r0 = readAsBytes()
    //     0xe8fbe8: bl              #0x124c570  ; [dart:io] _File::readAsBytes
    // 0xe8fbec: LeaveFrame
    //     0xe8fbec: mov             SP, fp
    //     0xe8fbf0: ldp             fp, lr, [SP], #0x10
    // 0xe8fbf4: ret
    //     0xe8fbf4: ret             
    // 0xe8fbf8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe8fbf8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe8fbfc: b               #0xe8fbdc
  }
  get _ name(/* No info */) {
    // ** addr: 0xe8fc00, size: 0x58
    // 0xe8fc00: EnterFrame
    //     0xe8fc00: stp             fp, lr, [SP, #-0x10]!
    //     0xe8fc04: mov             fp, SP
    // 0xe8fc08: CheckStackOverflow
    //     0xe8fc08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe8fc0c: cmp             SP, x16
    //     0xe8fc10: b.ls            #0xe8fc50
    // 0xe8fc14: LoadField: r0 = r1->field_7
    //     0xe8fc14: ldur            w0, [x1, #7]
    // 0xe8fc18: DecompressPointer r0
    //     0xe8fc18: add             x0, x0, HEAP, lsl #32
    // 0xe8fc1c: LoadField: r1 = r0->field_7
    //     0xe8fc1c: ldur            w1, [x0, #7]
    // 0xe8fc20: DecompressPointer r1
    //     0xe8fc20: add             x1, x1, HEAP, lsl #32
    // 0xe8fc24: r0 = LoadClassIdInstr(r1)
    //     0xe8fc24: ldur            x0, [x1, #-1]
    //     0xe8fc28: ubfx            x0, x0, #0xc, #0x14
    // 0xe8fc2c: r2 = "/"
    //     0xe8fc2c: ldr             x2, [PP, #0xfe0]  ; [pp+0xfe0] "/"
    // 0xe8fc30: r0 = GDT[cid_x0 + -0xffe]()
    //     0xe8fc30: sub             lr, x0, #0xffe
    //     0xe8fc34: ldr             lr, [x21, lr, lsl #3]
    //     0xe8fc38: blr             lr
    // 0xe8fc3c: mov             x1, x0
    // 0xe8fc40: r0 = last()
    //     0xe8fc40: bl              #0xb22764  ; [dart:core] _GrowableList::last
    // 0xe8fc44: LeaveFrame
    //     0xe8fc44: mov             SP, fp
    //     0xe8fc48: ldp             fp, lr, [SP], #0x10
    // 0xe8fc4c: ret
    //     0xe8fc4c: ret             
    // 0xe8fc50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe8fc50: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe8fc54: b               #0xe8fc14
  }
}
