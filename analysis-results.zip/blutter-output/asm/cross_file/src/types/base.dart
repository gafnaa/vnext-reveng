// lib: , url: package:cross_file/src/types/base.dart

// class id: 1048669, size: 0x8
class :: {
}

// class id: 3557, size: 0x8, field offset: 0x8
abstract class XFileBase extends Object {
}
