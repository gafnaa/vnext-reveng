// lib: , url: package:dio_cookie_manager/src/cookie_mgr.dart

// class id: 1048718, size: 0x8
class :: {

  static late final RegExp _setCookieReg; // offset: 0x1094

  static RegExp _setCookieReg() {
    // ** addr: 0x11a7a48, size: 0x58
    // 0x11a7a48: EnterFrame
    //     0x11a7a48: stp             fp, lr, [SP, #-0x10]!
    //     0x11a7a4c: mov             fp, SP
    // 0x11a7a50: AllocStack(0x30)
    //     0x11a7a50: sub             SP, SP, #0x30
    // 0x11a7a54: CheckStackOverflow
    //     0x11a7a54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a7a58: cmp             SP, x16
    //     0x11a7a5c: b.ls            #0x11a7a98
    // 0x11a7a60: r16 = "(\?<=)(,)(\?=[^;]+\?=)"
    //     0x11a7a60: add             x16, PP, #0x82, lsl #12  ; [pp+0x82110] "(\?<=)(,)(\?=[^;]+\?=)"
    //     0x11a7a64: ldr             x16, [x16, #0x110]
    // 0x11a7a68: stp             x16, NULL, [SP, #0x20]
    // 0x11a7a6c: r16 = false
    //     0x11a7a6c: add             x16, NULL, #0x30  ; false
    // 0x11a7a70: r30 = true
    //     0x11a7a70: add             lr, NULL, #0x20  ; true
    // 0x11a7a74: stp             lr, x16, [SP, #0x10]
    // 0x11a7a78: r16 = false
    //     0x11a7a78: add             x16, NULL, #0x30  ; false
    // 0x11a7a7c: r30 = false
    //     0x11a7a7c: add             lr, NULL, #0x30  ; false
    // 0x11a7a80: stp             lr, x16, [SP]
    // 0x11a7a84: r4 = const [0, 0x6, 0x6, 0x2, caseSensitive, 0x3, dotAll, 0x5, multiLine, 0x2, unicode, 0x4, null]
    //     0x11a7a84: ldr             x4, [PP, #0xa48]  ; [pp+0xa48] List(13) [0, 0x6, 0x6, 0x2, "caseSensitive", 0x3, "dotAll", 0x5, "multiLine", 0x2, "unicode", 0x4, Null]
    // 0x11a7a88: r0 = _RegExp()
    //     0x11a7a88: bl              #0x7eb40c  ; [dart:core] _RegExp::_RegExp
    // 0x11a7a8c: LeaveFrame
    //     0x11a7a8c: mov             SP, fp
    //     0x11a7a90: ldp             fp, lr, [SP], #0x10
    // 0x11a7a94: ret
    //     0x11a7a94: ret             
    // 0x11a7a98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a7a98: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a7a9c: b               #0x11a7a60
  }
}

// class id: 3395, size: 0x10, field offset: 0x8
//   const constructor, 
class _CookieHeaderState extends Object {
}

// class id: 4265, size: 0x14, field offset: 0x8
class CookieManager extends Interceptor {

  [closure] Future<void> onError(dynamic, DioException, ErrorInterceptorHandler) {
    // ** addr: 0x11a3c20, size: 0x40
    // 0x11a3c20: EnterFrame
    //     0x11a3c20: stp             fp, lr, [SP, #-0x10]!
    //     0x11a3c24: mov             fp, SP
    // 0x11a3c28: ldr             x0, [fp, #0x20]
    // 0x11a3c2c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x11a3c2c: ldur            w1, [x0, #0x17]
    // 0x11a3c30: DecompressPointer r1
    //     0x11a3c30: add             x1, x1, HEAP, lsl #32
    // 0x11a3c34: CheckStackOverflow
    //     0x11a3c34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a3c38: cmp             SP, x16
    //     0x11a3c3c: b.ls            #0x11a3c58
    // 0x11a3c40: ldr             x2, [fp, #0x18]
    // 0x11a3c44: ldr             x3, [fp, #0x10]
    // 0x11a3c48: r0 = onError()
    //     0x11a3c48: bl              #0x11a3c60  ; [package:dio_cookie_manager/src/cookie_mgr.dart] CookieManager::onError
    // 0x11a3c4c: LeaveFrame
    //     0x11a3c4c: mov             SP, fp
    //     0x11a3c50: ldp             fp, lr, [SP], #0x10
    // 0x11a3c54: ret
    //     0x11a3c54: ret             
    // 0x11a3c58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a3c58: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a3c5c: b               #0x11a3c40
  }
  _ onError(/* No info */) async {
    // ** addr: 0x11a3c60, size: 0x11c
    // 0x11a3c60: EnterFrame
    //     0x11a3c60: stp             fp, lr, [SP, #-0x10]!
    //     0x11a3c64: mov             fp, SP
    // 0x11a3c68: AllocStack(0xd8)
    //     0x11a3c68: sub             SP, SP, #0xd8
    // 0x11a3c6c: SetupParameters(CookieManager this /* r1 => r3, fp-0x98 */, dynamic _ /* r3 => r1, fp-0xa0 */)
    //     0x11a3c6c: stur            NULL, [fp, #-8]
    //     0x11a3c70: stur            x1, [fp, #-0x90]
    //     0x11a3c74: mov             x16, x3
    //     0x11a3c78: mov             x3, x1
    //     0x11a3c7c: mov             x1, x16
    //     0x11a3c80: stur            x2, [fp, #-0x98]
    //     0x11a3c84: stur            x1, [fp, #-0xa0]
    // 0x11a3c88: CheckStackOverflow
    //     0x11a3c88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a3c8c: cmp             SP, x16
    //     0x11a3c90: b.ls            #0x11a3d74
    // 0x11a3c94: InitAsync() -> Future<void?>
    //     0x11a3c94: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0x11a3c98: bl              #0x7f5e44  ; InitAsyncStub
    // 0x11a3c9c: ldur            x0, [fp, #-0x98]
    // 0x11a3ca0: LoadField: r3 = r0->field_b
    //     0x11a3ca0: ldur            w3, [x0, #0xb]
    // 0x11a3ca4: DecompressPointer r3
    //     0x11a3ca4: add             x3, x3, HEAP, lsl #32
    // 0x11a3ca8: stur            x3, [fp, #-0xa8]
    // 0x11a3cac: cmp             w3, NULL
    // 0x11a3cb0: b.ne            #0x11a3cc8
    // 0x11a3cb4: ldur            x1, [fp, #-0xa0]
    // 0x11a3cb8: mov             x2, x0
    // 0x11a3cbc: r0 = next()
    //     0x11a3cbc: bl              #0x8ee274  ; [package:dio/src/dio_mixin.dart] ErrorInterceptorHandler::next
    // 0x11a3cc0: r0 = Null
    //     0x11a3cc0: mov             x0, NULL
    // 0x11a3cc4: r0 = ReturnAsyncNotFuture()
    //     0x11a3cc4: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x11a3cc8: ldur            x1, [fp, #-0x90]
    // 0x11a3ccc: mov             x2, x3
    // 0x11a3cd0: r0 = saveCookies()
    //     0x11a3cd0: bl              #0x11a3d88  ; [package:dio_cookie_manager/src/cookie_mgr.dart] CookieManager::saveCookies
    // 0x11a3cd4: mov             x1, x0
    // 0x11a3cd8: stur            x1, [fp, #-0xb0]
    // 0x11a3cdc: r0 = Await()
    //     0x11a3cdc: bl              #0x7f5c00  ; AwaitStub
    // 0x11a3ce0: ldur            x1, [fp, #-0xa0]
    // 0x11a3ce4: ldur            x2, [fp, #-0x98]
    // 0x11a3ce8: r0 = next()
    //     0x11a3ce8: bl              #0x8ee274  ; [package:dio/src/dio_mixin.dart] ErrorInterceptorHandler::next
    // 0x11a3cec: b               #0x11a3d6c
    // 0x11a3cf0: sub             SP, fp, #0xd8
    // 0x11a3cf4: ldur            x2, [fp, #-0xa8]
    // 0x11a3cf8: stur            x0, [fp, #-0x98]
    // 0x11a3cfc: stur            x1, [fp, #-0xb0]
    // 0x11a3d00: LoadField: r3 = r2->field_f
    //     0x11a3d00: ldur            w3, [x2, #0xf]
    // 0x11a3d04: DecompressPointer r3
    //     0x11a3d04: add             x3, x3, HEAP, lsl #32
    // 0x11a3d08: stur            x3, [fp, #-0x90]
    // 0x11a3d0c: r0 = CookieManagerSaveException()
    //     0x11a3d0c: bl              #0x11a3d7c  ; AllocateCookieManagerSaveExceptionStub -> CookieManagerSaveException (size=0x10)
    // 0x11a3d10: mov             x1, x0
    // 0x11a3d14: ldur            x0, [fp, #-0xa8]
    // 0x11a3d18: stur            x1, [fp, #-0xb8]
    // 0x11a3d1c: StoreField: r1->field_7 = r0
    //     0x11a3d1c: stur            w0, [x1, #7]
    // 0x11a3d20: ldur            x2, [fp, #-0x98]
    // 0x11a3d24: StoreField: r1->field_b = r2
    //     0x11a3d24: stur            w2, [x1, #0xb]
    // 0x11a3d28: r0 = DioException()
    //     0x11a3d28: bl              #0x8ea014  ; AllocateDioExceptionStub -> DioException (size=0x24)
    // 0x11a3d2c: stur            x0, [fp, #-0x98]
    // 0x11a3d30: ldur            x16, [fp, #-0xa8]
    // 0x11a3d34: r30 = Instance_DioExceptionType
    //     0x11a3d34: add             lr, PP, #0x15, lsl #12  ; [pp+0x15ce0] Obj!DioExceptionType@12c64e1
    //     0x11a3d38: ldr             lr, [lr, #0xce0]
    // 0x11a3d3c: stp             lr, x16, [SP, #0x10]
    // 0x11a3d40: ldur            x16, [fp, #-0xb8]
    // 0x11a3d44: ldur            lr, [fp, #-0xb0]
    // 0x11a3d48: stp             lr, x16, [SP]
    // 0x11a3d4c: mov             x1, x0
    // 0x11a3d50: ldur            x2, [fp, #-0x90]
    // 0x11a3d54: r4 = const [0, 0x6, 0x4, 0x2, error, 0x4, response, 0x2, stackTrace, 0x5, type, 0x3, null]
    //     0x11a3d54: add             x4, PP, #0x81, lsl #12  ; [pp+0x81fd8] List(13) [0, 0x6, 0x4, 0x2, "error", 0x4, "response", 0x2, "stackTrace", 0x5, "type", 0x3, Null]
    //     0x11a3d58: ldr             x4, [x4, #0xfd8]
    // 0x11a3d5c: r0 = DioException()
    //     0x11a3d5c: bl              #0x8e97ec  ; [package:dio/src/dio_exception.dart] DioException::DioException
    // 0x11a3d60: ldur            x1, [fp, #-0xa0]
    // 0x11a3d64: ldur            x2, [fp, #-0x98]
    // 0x11a3d68: r0 = next()
    //     0x11a3d68: bl              #0x8ee274  ; [package:dio/src/dio_mixin.dart] ErrorInterceptorHandler::next
    // 0x11a3d6c: r0 = Null
    //     0x11a3d6c: mov             x0, NULL
    // 0x11a3d70: r0 = ReturnAsyncNotFuture()
    //     0x11a3d70: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x11a3d74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a3d74: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a3d78: b               #0x11a3c94
  }
  _ saveCookies(/* No info */) async {
    // ** addr: 0x11a3d88, size: 0x3cc
    // 0x11a3d88: EnterFrame
    //     0x11a3d88: stp             fp, lr, [SP, #-0x10]!
    //     0x11a3d8c: mov             fp, SP
    // 0x11a3d90: AllocStack(0x50)
    //     0x11a3d90: sub             SP, SP, #0x50
    // 0x11a3d94: SetupParameters(CookieManager this /* r1 => r0, fp-0x10 */, dynamic _ /* r2 => r1, fp-0x18 */)
    //     0x11a3d94: stur            NULL, [fp, #-8]
    //     0x11a3d98: mov             x0, x1
    //     0x11a3d9c: stur            x1, [fp, #-0x10]
    //     0x11a3da0: mov             x1, x2
    //     0x11a3da4: stur            x2, [fp, #-0x18]
    // 0x11a3da8: CheckStackOverflow
    //     0x11a3da8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a3dac: cmp             SP, x16
    //     0x11a3db0: b.ls            #0x11a414c
    // 0x11a3db4: r1 = 3
    //     0x11a3db4: mov             x1, #3
    // 0x11a3db8: r0 = AllocateContext()
    //     0x11a3db8: bl              #0x13de838  ; AllocateContextStub
    // 0x11a3dbc: mov             x2, x0
    // 0x11a3dc0: ldur            x1, [fp, #-0x10]
    // 0x11a3dc4: stur            x2, [fp, #-0x20]
    // 0x11a3dc8: StoreField: r2->field_f = r1
    //     0x11a3dc8: stur            w1, [x2, #0xf]
    // 0x11a3dcc: InitAsync() -> Future<void?>
    //     0x11a3dcc: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0x11a3dd0: bl              #0x7f5e44  ; InitAsyncStub
    // 0x11a3dd4: ldur            x0, [fp, #-0x18]
    // 0x11a3dd8: LoadField: r1 = r0->field_1b
    //     0x11a3dd8: ldur            w1, [x0, #0x1b]
    // 0x11a3ddc: DecompressPointer r1
    //     0x11a3ddc: add             x1, x1, HEAP, lsl #32
    // 0x11a3de0: LoadField: r2 = r1->field_7
    //     0x11a3de0: ldur            w2, [x1, #7]
    // 0x11a3de4: DecompressPointer r2
    //     0x11a3de4: add             x2, x2, HEAP, lsl #32
    // 0x11a3de8: stur            x2, [fp, #-0x28]
    // 0x11a3dec: r1 = "set-cookie"
    //     0x11a3dec: add             x1, PP, #0x11, lsl #12  ; [pp+0x11178] "set-cookie"
    //     0x11a3df0: ldr             x1, [x1, #0x178]
    // 0x11a3df4: r0 = trim()
    //     0x11a3df4: bl              #0x808ff4  ; [dart:core] _StringBase::trim
    // 0x11a3df8: ldur            x1, [fp, #-0x28]
    // 0x11a3dfc: r2 = LoadClassIdInstr(r1)
    //     0x11a3dfc: ldur            x2, [x1, #-1]
    //     0x11a3e00: ubfx            x2, x2, #0xc, #0x14
    // 0x11a3e04: mov             x16, x0
    // 0x11a3e08: mov             x0, x2
    // 0x11a3e0c: mov             x2, x16
    // 0x11a3e10: r0 = GDT[cid_x0 + -0xd48]()
    //     0x11a3e10: sub             lr, x0, #0xd48
    //     0x11a3e14: ldr             lr, [x21, lr, lsl #3]
    //     0x11a3e18: blr             lr
    // 0x11a3e1c: mov             x2, x0
    // 0x11a3e20: stur            x2, [fp, #-0x28]
    // 0x11a3e24: cmp             w2, NULL
    // 0x11a3e28: b.eq            #0x11a3e50
    // 0x11a3e2c: r0 = LoadClassIdInstr(r2)
    //     0x11a3e2c: ldur            x0, [x2, #-1]
    //     0x11a3e30: ubfx            x0, x0, #0xc, #0x14
    // 0x11a3e34: mov             x1, x2
    // 0x11a3e38: r0 = GDT[cid_x0 + 0x12b36]()
    //     0x11a3e38: mov             x17, #0x2b36
    //     0x11a3e3c: movk            x17, #1, lsl #16
    //     0x11a3e40: add             lr, x0, x17
    //     0x11a3e44: ldr             lr, [x21, lr, lsl #3]
    //     0x11a3e48: blr             lr
    // 0x11a3e4c: tbnz            w0, #4, #0x11a3e58
    // 0x11a3e50: r0 = Null
    //     0x11a3e50: mov             x0, NULL
    // 0x11a3e54: r0 = ReturnAsyncNotFuture()
    //     0x11a3e54: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x11a3e58: ldur            x4, [fp, #-0x10]
    // 0x11a3e5c: ldur            x3, [fp, #-0x18]
    // 0x11a3e60: ldur            x5, [fp, #-0x20]
    // 0x11a3e64: ldur            x0, [fp, #-0x28]
    // 0x11a3e68: r1 = Function '<anonymous closure>':.
    //     0x11a3e68: add             x1, PP, #0x81, lsl #12  ; [pp+0x81fe0] AnonymousClosure: (0x11a79dc), in [package:dio_cookie_manager/src/cookie_mgr.dart] CookieManager::saveCookies (0x11a3d88)
    //     0x11a3e6c: ldr             x1, [x1, #0xfe0]
    // 0x11a3e70: r2 = Null
    //     0x11a3e70: mov             x2, NULL
    // 0x11a3e74: r0 = AllocateClosure()
    //     0x11a3e74: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11a3e78: mov             x1, x0
    // 0x11a3e7c: ldur            x0, [fp, #-0x28]
    // 0x11a3e80: r2 = LoadClassIdInstr(r0)
    //     0x11a3e80: ldur            x2, [x0, #-1]
    //     0x11a3e84: ubfx            x2, x2, #0xc, #0x14
    // 0x11a3e88: r16 = <List<String>>
    //     0x11a3e88: add             x16, PP, #0x15, lsl #12  ; [pp+0x15358] TypeArguments: <List<String>>
    //     0x11a3e8c: ldr             x16, [x16, #0x358]
    // 0x11a3e90: stp             x0, x16, [SP, #8]
    // 0x11a3e94: str             x1, [SP]
    // 0x11a3e98: mov             x0, x2
    // 0x11a3e9c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x11a3e9c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x11a3ea0: r0 = GDT[cid_x0 + 0x12caa]()
    //     0x11a3ea0: mov             x17, #0x2caa
    //     0x11a3ea4: movk            x17, #1, lsl #16
    //     0x11a3ea8: add             lr, x0, x17
    //     0x11a3eac: ldr             lr, [x21, lr, lsl #3]
    //     0x11a3eb0: blr             lr
    // 0x11a3eb4: r1 = Function '<anonymous closure>':.
    //     0x11a3eb4: add             x1, PP, #0x81, lsl #12  ; [pp+0x81fe8] AnonymousClosure: (0x13dae90), in [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::_mergeSiblingGroup (0x891814)
    //     0x11a3eb8: ldr             x1, [x1, #0xfe8]
    // 0x11a3ebc: r2 = Null
    //     0x11a3ebc: mov             x2, NULL
    // 0x11a3ec0: stur            x0, [fp, #-0x28]
    // 0x11a3ec4: r0 = AllocateClosure()
    //     0x11a3ec4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11a3ec8: r16 = <String>
    //     0x11a3ec8: ldr             x16, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    // 0x11a3ecc: ldur            lr, [fp, #-0x28]
    // 0x11a3ed0: stp             lr, x16, [SP, #8]
    // 0x11a3ed4: str             x0, [SP]
    // 0x11a3ed8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x11a3ed8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x11a3edc: r0 = expand()
    //     0x11a3edc: bl              #0x851010  ; [dart:core] Iterable::expand
    // 0x11a3ee0: r1 = Function '<anonymous closure>':.
    //     0x11a3ee0: add             x1, PP, #0x81, lsl #12  ; [pp+0x81ff0] AnonymousClosure: static (0x82e244), in [package:flutter/src/foundation/stack_frame.dart] StackFrame::fromStackString (0x82d624)
    //     0x11a3ee4: ldr             x1, [x1, #0xff0]
    // 0x11a3ee8: r2 = Null
    //     0x11a3ee8: mov             x2, NULL
    // 0x11a3eec: stur            x0, [fp, #-0x28]
    // 0x11a3ef0: r0 = AllocateClosure()
    //     0x11a3ef0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11a3ef4: ldur            x1, [fp, #-0x28]
    // 0x11a3ef8: mov             x2, x0
    // 0x11a3efc: r0 = where()
    //     0x11a3efc: bl              #0xb92e4c  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::where
    // 0x11a3f00: ldur            x2, [fp, #-0x20]
    // 0x11a3f04: r1 = Function '<anonymous closure>':.
    //     0x11a3f04: add             x1, PP, #0x81, lsl #12  ; [pp+0x81ff8] AnonymousClosure: (0x11a4820), in [package:dio_cookie_manager/src/cookie_mgr.dart] CookieManager::saveCookies (0x11a3d88)
    //     0x11a3f08: ldr             x1, [x1, #0xff8]
    // 0x11a3f0c: stur            x0, [fp, #-0x28]
    // 0x11a3f10: r0 = AllocateClosure()
    //     0x11a3f10: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11a3f14: r16 = <Cookie?>
    //     0x11a3f14: add             x16, PP, #0x82, lsl #12  ; [pp+0x82000] TypeArguments: <Cookie?>
    //     0x11a3f18: ldr             x16, [x16]
    // 0x11a3f1c: ldur            lr, [fp, #-0x28]
    // 0x11a3f20: stp             lr, x16, [SP, #8]
    // 0x11a3f24: str             x0, [SP]
    // 0x11a3f28: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x11a3f28: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x11a3f2c: r0 = map()
    //     0x11a3f2c: bl              #0xb00654  ; [dart:_internal] WhereIterable::map
    // 0x11a3f30: r16 = <Cookie>
    //     0x11a3f30: add             x16, PP, #0xb, lsl #12  ; [pp+0xbe80] TypeArguments: <Cookie>
    //     0x11a3f34: ldr             x16, [x16, #0xe80]
    // 0x11a3f38: stp             x0, x16, [SP]
    // 0x11a3f3c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x11a3f3c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x11a3f40: r0 = whereType()
    //     0x11a3f40: bl              #0xbfff48  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::whereType
    // 0x11a3f44: mov             x1, x0
    // 0x11a3f48: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x11a3f48: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x11a3f4c: r0 = toList()
    //     0x11a3f4c: bl              #0xb08ca4  ; [dart:core] Iterable::toList
    // 0x11a3f50: mov             x3, x0
    // 0x11a3f54: ldur            x2, [fp, #-0x20]
    // 0x11a3f58: stur            x3, [fp, #-0x28]
    // 0x11a3f5c: StoreField: r2->field_13 = r0
    //     0x11a3f5c: stur            w0, [x2, #0x13]
    //     0x11a3f60: ldurb           w16, [x2, #-1]
    //     0x11a3f64: ldurb           w17, [x0, #-1]
    //     0x11a3f68: and             x16, x17, x16, lsr #2
    //     0x11a3f6c: tst             x16, HEAP, lsr #32
    //     0x11a3f70: b.eq            #0x11a3f78
    //     0x11a3f74: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11a3f78: ldur            x0, [fp, #-0x18]
    // 0x11a3f7c: LoadField: r1 = r0->field_f
    //     0x11a3f7c: ldur            w1, [x0, #0xf]
    // 0x11a3f80: DecompressPointer r1
    //     0x11a3f80: add             x1, x1, HEAP, lsl #32
    // 0x11a3f84: r0 = uri()
    //     0x11a3f84: bl              #0x90c6d0  ; [package:dio/src/options.dart] RequestOptions::uri
    // 0x11a3f88: ldur            x1, [fp, #-0x18]
    // 0x11a3f8c: stur            x0, [fp, #-0x30]
    // 0x11a3f90: r0 = realUri()
    //     0x11a3f90: bl              #0x11a46f0  ; [package:dio/src/response.dart] Response::realUri
    // 0x11a3f94: ldur            x1, [fp, #-0x30]
    // 0x11a3f98: r2 = LoadClassIdInstr(r1)
    //     0x11a3f98: ldur            x2, [x1, #-1]
    //     0x11a3f9c: ubfx            x2, x2, #0xc, #0x14
    // 0x11a3fa0: mov             x16, x0
    // 0x11a3fa4: mov             x0, x2
    // 0x11a3fa8: mov             x2, x16
    // 0x11a3fac: r0 = GDT[cid_x0 + -0xaec]()
    //     0x11a3fac: sub             lr, x0, #0xaec
    //     0x11a3fb0: ldr             lr, [x21, lr, lsl #3]
    //     0x11a3fb4: blr             lr
    // 0x11a3fb8: mov             x1, x0
    // 0x11a3fbc: ldur            x0, [fp, #-0x10]
    // 0x11a3fc0: LoadField: r2 = r0->field_7
    //     0x11a3fc0: ldur            w2, [x0, #7]
    // 0x11a3fc4: DecompressPointer r2
    //     0x11a3fc4: add             x2, x2, HEAP, lsl #32
    // 0x11a3fc8: mov             x16, x1
    // 0x11a3fcc: mov             x1, x2
    // 0x11a3fd0: mov             x2, x16
    // 0x11a3fd4: ldur            x3, [fp, #-0x28]
    // 0x11a3fd8: r0 = saveFromResponse()
    //     0x11a3fd8: bl              #0x11a4154  ; [package:cookie_jar/src/jar/default.dart] DefaultCookieJar::saveFromResponse
    // 0x11a3fdc: mov             x1, x0
    // 0x11a3fe0: stur            x1, [fp, #-0x10]
    // 0x11a3fe4: r0 = Await()
    //     0x11a3fe4: bl              #0x7f5c00  ; AwaitStub
    // 0x11a3fe8: ldur            x0, [fp, #-0x18]
    // 0x11a3fec: LoadField: r1 = r0->field_13
    //     0x11a3fec: ldur            w1, [x0, #0x13]
    // 0x11a3ff0: DecompressPointer r1
    //     0x11a3ff0: add             x1, x1, HEAP, lsl #32
    // 0x11a3ff4: cmp             w1, NULL
    // 0x11a3ff8: b.ne            #0x11a4004
    // 0x11a3ffc: r2 = 0
    //     0x11a3ffc: mov             x2, #0
    // 0x11a4000: b               #0x11a4010
    // 0x11a4004: r2 = LoadInt32Instr(r1)
    //     0x11a4004: sbfx            x2, x1, #1, #0x1f
    //     0x11a4008: tbz             w1, #0, #0x11a4010
    //     0x11a400c: ldur            x2, [x1, #7]
    // 0x11a4010: stur            x2, [fp, #-0x38]
    // 0x11a4014: LoadField: r1 = r0->field_1b
    //     0x11a4014: ldur            w1, [x0, #0x1b]
    // 0x11a4018: DecompressPointer r1
    //     0x11a4018: add             x1, x1, HEAP, lsl #32
    // 0x11a401c: LoadField: r3 = r1->field_7
    //     0x11a401c: ldur            w3, [x1, #7]
    // 0x11a4020: DecompressPointer r3
    //     0x11a4020: add             x3, x3, HEAP, lsl #32
    // 0x11a4024: stur            x3, [fp, #-0x10]
    // 0x11a4028: r1 = "location"
    //     0x11a4028: ldr             x1, [PP, #0x1a48]  ; [pp+0x1a48] "location"
    // 0x11a402c: r0 = trim()
    //     0x11a402c: bl              #0x808ff4  ; [dart:core] _StringBase::trim
    // 0x11a4030: ldur            x1, [fp, #-0x10]
    // 0x11a4034: r2 = LoadClassIdInstr(r1)
    //     0x11a4034: ldur            x2, [x1, #-1]
    //     0x11a4038: ubfx            x2, x2, #0xc, #0x14
    // 0x11a403c: mov             x16, x0
    // 0x11a4040: mov             x0, x2
    // 0x11a4044: mov             x2, x16
    // 0x11a4048: r0 = GDT[cid_x0 + -0xd48]()
    //     0x11a4048: sub             lr, x0, #0xd48
    //     0x11a404c: ldr             lr, [x21, lr, lsl #3]
    //     0x11a4050: blr             lr
    // 0x11a4054: cmp             w0, NULL
    // 0x11a4058: b.ne            #0x11a4070
    // 0x11a405c: r1 = <String>
    //     0x11a405c: ldr             x1, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    // 0x11a4060: r2 = 0
    //     0x11a4060: mov             x2, #0
    // 0x11a4064: r0 = _GrowableList()
    //     0x11a4064: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x11a4068: mov             x2, x0
    // 0x11a406c: b               #0x11a4074
    // 0x11a4070: mov             x2, x0
    // 0x11a4074: ldur            x0, [fp, #-0x38]
    // 0x11a4078: stur            x2, [fp, #-0x10]
    // 0x11a407c: cmp             x0, #0x12c
    // 0x11a4080: b.lt            #0x11a4144
    // 0x11a4084: cmp             x0, #0x190
    // 0x11a4088: b.ge            #0x11a4144
    // 0x11a408c: r0 = LoadClassIdInstr(r2)
    //     0x11a408c: ldur            x0, [x2, #-1]
    //     0x11a4090: ubfx            x0, x0, #0xc, #0x14
    // 0x11a4094: mov             x1, x2
    // 0x11a4098: r0 = GDT[cid_x0 + 0x131a1]()
    //     0x11a4098: mov             x17, #0x31a1
    //     0x11a409c: movk            x17, #1, lsl #16
    //     0x11a40a0: add             lr, x0, x17
    //     0x11a40a4: ldr             lr, [x21, lr, lsl #3]
    //     0x11a40a8: blr             lr
    // 0x11a40ac: tbnz            w0, #4, #0x11a4144
    // 0x11a40b0: ldur            x2, [fp, #-0x20]
    // 0x11a40b4: ldur            x0, [fp, #-0x10]
    // 0x11a40b8: ldur            x1, [fp, #-0x18]
    // 0x11a40bc: r0 = realUri()
    //     0x11a40bc: bl              #0x11a46f0  ; [package:dio/src/response.dart] Response::realUri
    // 0x11a40c0: ldur            x3, [fp, #-0x20]
    // 0x11a40c4: ArrayStore: r3[0] = r0  ; List_4
    //     0x11a40c4: stur            w0, [x3, #0x17]
    //     0x11a40c8: ldurb           w16, [x3, #-1]
    //     0x11a40cc: ldurb           w17, [x0, #-1]
    //     0x11a40d0: and             x16, x17, x16, lsr #2
    //     0x11a40d4: tst             x16, HEAP, lsr #32
    //     0x11a40d8: b.eq            #0x11a40e0
    //     0x11a40dc: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x11a40e0: mov             x2, x3
    // 0x11a40e4: r1 = Function '<anonymous closure>':.
    //     0x11a40e4: add             x1, PP, #0x82, lsl #12  ; [pp+0x82008] AnonymousClosure: (0x11a4794), in [package:dio_cookie_manager/src/cookie_mgr.dart] CookieManager::saveCookies (0x11a3d88)
    //     0x11a40e8: ldr             x1, [x1, #8]
    // 0x11a40ec: r0 = AllocateClosure()
    //     0x11a40ec: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11a40f0: mov             x1, x0
    // 0x11a40f4: ldur            x0, [fp, #-0x10]
    // 0x11a40f8: r2 = LoadClassIdInstr(r0)
    //     0x11a40f8: ldur            x2, [x0, #-1]
    //     0x11a40fc: ubfx            x2, x2, #0xc, #0x14
    // 0x11a4100: r16 = <Future<void?>>
    //     0x11a4100: ldr             x16, [PP, #0x2a8]  ; [pp+0x2a8] TypeArguments: <Future<void?>>
    // 0x11a4104: stp             x0, x16, [SP, #8]
    // 0x11a4108: str             x1, [SP]
    // 0x11a410c: mov             x0, x2
    // 0x11a4110: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x11a4110: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x11a4114: r0 = GDT[cid_x0 + 0x12caa]()
    //     0x11a4114: mov             x17, #0x2caa
    //     0x11a4118: movk            x17, #1, lsl #16
    //     0x11a411c: add             lr, x0, x17
    //     0x11a4120: ldr             lr, [x21, lr, lsl #3]
    //     0x11a4124: blr             lr
    // 0x11a4128: r16 = <void?>
    //     0x11a4128: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x11a412c: stp             x0, x16, [SP]
    // 0x11a4130: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x11a4130: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x11a4134: r0 = wait()
    //     0x11a4134: bl              #0x841938  ; [dart:async] Future::wait
    // 0x11a4138: mov             x1, x0
    // 0x11a413c: stur            x1, [fp, #-0x10]
    // 0x11a4140: r0 = Await()
    //     0x11a4140: bl              #0x7f5c00  ; AwaitStub
    // 0x11a4144: r0 = Null
    //     0x11a4144: mov             x0, NULL
    // 0x11a4148: r0 = ReturnAsyncNotFuture()
    //     0x11a4148: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x11a414c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a414c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a4150: b               #0x11a3db4
  }
  [closure] Future<void> <anonymous closure>(dynamic, String) {
    // ** addr: 0x11a4794, size: 0x8c
    // 0x11a4794: EnterFrame
    //     0x11a4794: stp             fp, lr, [SP, #-0x10]!
    //     0x11a4798: mov             fp, SP
    // 0x11a479c: AllocStack(0x10)
    //     0x11a479c: sub             SP, SP, #0x10
    // 0x11a47a0: SetupParameters([dynamic _ /* r0 */])
    //     0x11a47a0: ldr             x0, [fp, #0x18]
    //     0x11a47a4: ldur            w3, [x0, #0x17]
    //     0x11a47a8: add             x3, x3, HEAP, lsl #32
    //     0x11a47ac: stur            x3, [fp, #-0x10]
    // 0x11a47b0: CheckStackOverflow
    //     0x11a47b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a47b4: cmp             SP, x16
    //     0x11a47b8: b.ls            #0x11a4818
    // 0x11a47bc: LoadField: r0 = r3->field_f
    //     0x11a47bc: ldur            w0, [x3, #0xf]
    // 0x11a47c0: DecompressPointer r0
    //     0x11a47c0: add             x0, x0, HEAP, lsl #32
    // 0x11a47c4: LoadField: r4 = r0->field_7
    //     0x11a47c4: ldur            w4, [x0, #7]
    // 0x11a47c8: DecompressPointer r4
    //     0x11a47c8: add             x4, x4, HEAP, lsl #32
    // 0x11a47cc: stur            x4, [fp, #-8]
    // 0x11a47d0: ArrayLoad: r1 = r3[0]  ; List_4
    //     0x11a47d0: ldur            w1, [x3, #0x17]
    // 0x11a47d4: DecompressPointer r1
    //     0x11a47d4: add             x1, x1, HEAP, lsl #32
    // 0x11a47d8: r0 = LoadClassIdInstr(r1)
    //     0x11a47d8: ldur            x0, [x1, #-1]
    //     0x11a47dc: ubfx            x0, x0, #0xc, #0x14
    // 0x11a47e0: ldr             x2, [fp, #0x10]
    // 0x11a47e4: r0 = GDT[cid_x0 + -0xe5c]()
    //     0x11a47e4: sub             lr, x0, #0xe5c
    //     0x11a47e8: ldr             lr, [x21, lr, lsl #3]
    //     0x11a47ec: blr             lr
    // 0x11a47f0: mov             x1, x0
    // 0x11a47f4: ldur            x0, [fp, #-0x10]
    // 0x11a47f8: LoadField: r3 = r0->field_13
    //     0x11a47f8: ldur            w3, [x0, #0x13]
    // 0x11a47fc: DecompressPointer r3
    //     0x11a47fc: add             x3, x3, HEAP, lsl #32
    // 0x11a4800: mov             x2, x1
    // 0x11a4804: ldur            x1, [fp, #-8]
    // 0x11a4808: r0 = saveFromResponse()
    //     0x11a4808: bl              #0x11a4154  ; [package:cookie_jar/src/jar/default.dart] DefaultCookieJar::saveFromResponse
    // 0x11a480c: LeaveFrame
    //     0x11a480c: mov             SP, fp
    //     0x11a4810: ldp             fp, lr, [SP], #0x10
    // 0x11a4814: ret
    //     0x11a4814: ret             
    // 0x11a4818: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a4818: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a481c: b               #0x11a47bc
  }
  [closure] Cookie? <anonymous closure>(dynamic, String) {
    // ** addr: 0x11a4820, size: 0x48
    // 0x11a4820: EnterFrame
    //     0x11a4820: stp             fp, lr, [SP, #-0x10]!
    //     0x11a4824: mov             fp, SP
    // 0x11a4828: ldr             x0, [fp, #0x18]
    // 0x11a482c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x11a482c: ldur            w1, [x0, #0x17]
    // 0x11a4830: DecompressPointer r1
    //     0x11a4830: add             x1, x1, HEAP, lsl #32
    // 0x11a4834: CheckStackOverflow
    //     0x11a4834: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a4838: cmp             SP, x16
    //     0x11a483c: b.ls            #0x11a4860
    // 0x11a4840: LoadField: r0 = r1->field_f
    //     0x11a4840: ldur            w0, [x1, #0xf]
    // 0x11a4844: DecompressPointer r0
    //     0x11a4844: add             x0, x0, HEAP, lsl #32
    // 0x11a4848: mov             x1, x0
    // 0x11a484c: ldr             x2, [fp, #0x10]
    // 0x11a4850: r0 = _fromSetCookieValue()
    //     0x11a4850: bl              #0x11a4868  ; [package:dio_cookie_manager/src/cookie_mgr.dart] CookieManager::_fromSetCookieValue
    // 0x11a4854: LeaveFrame
    //     0x11a4854: mov             SP, fp
    //     0x11a4858: ldp             fp, lr, [SP], #0x10
    // 0x11a485c: ret
    //     0x11a485c: ret             
    // 0x11a4860: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a4860: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a4864: b               #0x11a4840
  }
  _ _fromSetCookieValue(/* No info */) {
    // ** addr: 0x11a4868, size: 0x7c
    // 0x11a4868: EnterFrame
    //     0x11a4868: stp             fp, lr, [SP, #-0x10]!
    //     0x11a486c: mov             fp, SP
    // 0x11a4870: AllocStack(0x50)
    //     0x11a4870: sub             SP, SP, #0x50
    // 0x11a4874: SetupParameters(CookieManager this /* r1 => r3, fp-0x48 */, dynamic _ /* r2 => r0, fp-0x50 */)
    //     0x11a4874: mov             x3, x1
    //     0x11a4878: mov             x0, x2
    //     0x11a487c: stur            x1, [fp, #-0x48]
    //     0x11a4880: stur            x2, [fp, #-0x50]
    // 0x11a4884: CheckStackOverflow
    //     0x11a4884: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a4888: cmp             SP, x16
    //     0x11a488c: b.ls            #0x11a48dc
    // 0x11a4890: mov             x2, x0
    // 0x11a4894: r1 = Null
    //     0x11a4894: mov             x1, NULL
    // 0x11a4898: r0 = Cookie.fromSetCookieValue()
    //     0x11a4898: bl              #0x11a48e4  ; [dart:_http] Cookie::Cookie.fromSetCookieValue
    // 0x11a489c: LeaveFrame
    //     0x11a489c: mov             SP, fp
    //     0x11a48a0: ldp             fp, lr, [SP], #0x10
    // 0x11a48a4: ret
    //     0x11a48a4: ret             
    // 0x11a48a8: sub             SP, fp, #0x50
    // 0x11a48ac: r2 = 60
    //     0x11a48ac: mov             x2, #0x3c
    // 0x11a48b0: branchIfSmi(r0, 0x11a48bc)
    //     0x11a48b0: tbz             w0, #0, #0x11a48bc
    // 0x11a48b4: r2 = LoadClassIdInstr(r0)
    //     0x11a48b4: ldur            x2, [x0, #-1]
    //     0x11a48b8: ubfx            x2, x2, #0xc, #0x14
    // 0x11a48bc: r17 = -7082
    //     0x11a48bc: mov             x17, #-0x1baa
    // 0x11a48c0: add             x16, x2, x17
    // 0x11a48c4: cmp             x16, #3
    // 0x11a48c8: b.hi            #0x11a48d4
    // 0x11a48cc: r0 = ReThrow()
    //     0x11a48cc: bl              #0x13ddb00  ; ReThrowStub
    // 0x11a48d0: brk             #0
    // 0x11a48d4: r0 = ReThrow()
    //     0x11a48d4: bl              #0x13ddb00  ; ReThrowStub
    // 0x11a48d8: brk             #0
    // 0x11a48dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a48dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a48e0: b               #0x11a4890
  }
  [closure] List<String> <anonymous closure>(dynamic, String) {
    // ** addr: 0x11a79dc, size: 0x6c
    // 0x11a79dc: EnterFrame
    //     0x11a79dc: stp             fp, lr, [SP, #-0x10]!
    //     0x11a79e0: mov             fp, SP
    // 0x11a79e4: CheckStackOverflow
    //     0x11a79e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a79e8: cmp             SP, x16
    //     0x11a79ec: b.ls            #0x11a7a40
    // 0x11a79f0: r0 = LoadStaticField(0x1094)
    //     0x11a79f0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x11a79f4: ldr             x0, [x0, #0x2128]
    // 0x11a79f8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11a79fc: cmp             w0, w16
    // 0x11a7a00: b.ne            #0x11a7a10
    // 0x11a7a04: r2 = _setCookieReg
    //     0x11a7a04: add             x2, PP, #0x82, lsl #12  ; [pp+0x82108] Field <::._setCookieReg@1274029043>: static late final (offset: 0x1094)
    //     0x11a7a08: ldr             x2, [x2, #0x108]
    // 0x11a7a0c: r0 = InitLateFinalStaticField()
    //     0x11a7a0c: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x11a7a10: ldr             x1, [fp, #0x10]
    // 0x11a7a14: r2 = LoadClassIdInstr(r1)
    //     0x11a7a14: ldur            x2, [x1, #-1]
    //     0x11a7a18: ubfx            x2, x2, #0xc, #0x14
    // 0x11a7a1c: mov             x16, x0
    // 0x11a7a20: mov             x0, x2
    // 0x11a7a24: mov             x2, x16
    // 0x11a7a28: r0 = GDT[cid_x0 + -0xffe]()
    //     0x11a7a28: sub             lr, x0, #0xffe
    //     0x11a7a2c: ldr             lr, [x21, lr, lsl #3]
    //     0x11a7a30: blr             lr
    // 0x11a7a34: LeaveFrame
    //     0x11a7a34: mov             SP, fp
    //     0x11a7a38: ldp             fp, lr, [SP], #0x10
    // 0x11a7a3c: ret
    //     0x11a7a3c: ret             
    // 0x11a7a40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a7a40: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a7a44: b               #0x11a79f0
  }
  [closure] Future<void> onResponse(dynamic, Response<dynamic>, ResponseInterceptorHandler) {
    // ** addr: 0x11bca5c, size: 0x40
    // 0x11bca5c: EnterFrame
    //     0x11bca5c: stp             fp, lr, [SP, #-0x10]!
    //     0x11bca60: mov             fp, SP
    // 0x11bca64: ldr             x0, [fp, #0x20]
    // 0x11bca68: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x11bca68: ldur            w1, [x0, #0x17]
    // 0x11bca6c: DecompressPointer r1
    //     0x11bca6c: add             x1, x1, HEAP, lsl #32
    // 0x11bca70: CheckStackOverflow
    //     0x11bca70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11bca74: cmp             SP, x16
    //     0x11bca78: b.ls            #0x11bca94
    // 0x11bca7c: ldr             x2, [fp, #0x18]
    // 0x11bca80: ldr             x3, [fp, #0x10]
    // 0x11bca84: r0 = onResponse()
    //     0x11bca84: bl              #0x11bca9c  ; [package:dio_cookie_manager/src/cookie_mgr.dart] CookieManager::onResponse
    // 0x11bca88: LeaveFrame
    //     0x11bca88: mov             SP, fp
    //     0x11bca8c: ldp             fp, lr, [SP], #0x10
    // 0x11bca90: ret
    //     0x11bca90: ret             
    // 0x11bca94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11bca94: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11bca98: b               #0x11bca7c
  }
  _ onResponse(/* No info */) async {
    // ** addr: 0x11bca9c, size: 0xfc
    // 0x11bca9c: EnterFrame
    //     0x11bca9c: stp             fp, lr, [SP, #-0x10]!
    //     0x11bcaa0: mov             fp, SP
    // 0x11bcaa4: AllocStack(0xd8)
    //     0x11bcaa4: sub             SP, SP, #0xd8
    // 0x11bcaa8: SetupParameters(CookieManager this /* r1 => r3, fp-0x98 */, dynamic _ /* r3 => r1, fp-0xa0 */)
    //     0x11bcaa8: stur            NULL, [fp, #-8]
    //     0x11bcaac: stur            x1, [fp, #-0x90]
    //     0x11bcab0: mov             x16, x3
    //     0x11bcab4: mov             x3, x1
    //     0x11bcab8: mov             x1, x16
    //     0x11bcabc: stur            x2, [fp, #-0x98]
    //     0x11bcac0: stur            x1, [fp, #-0xa0]
    // 0x11bcac4: CheckStackOverflow
    //     0x11bcac4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11bcac8: cmp             SP, x16
    //     0x11bcacc: b.ls            #0x11bcb90
    // 0x11bcad0: InitAsync() -> Future<void?>
    //     0x11bcad0: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0x11bcad4: bl              #0x7f5e44  ; InitAsyncStub
    // 0x11bcad8: ldur            x1, [fp, #-0x90]
    // 0x11bcadc: ldur            x2, [fp, #-0x98]
    // 0x11bcae0: r0 = saveCookies()
    //     0x11bcae0: bl              #0x11a3d88  ; [package:dio_cookie_manager/src/cookie_mgr.dart] CookieManager::saveCookies
    // 0x11bcae4: mov             x1, x0
    // 0x11bcae8: stur            x1, [fp, #-0xa8]
    // 0x11bcaec: r0 = Await()
    //     0x11bcaec: bl              #0x7f5c00  ; AwaitStub
    // 0x11bcaf0: ldur            x1, [fp, #-0xa0]
    // 0x11bcaf4: ldur            x2, [fp, #-0x98]
    // 0x11bcaf8: r0 = next()
    //     0x11bcaf8: bl              #0x8ee4b4  ; [package:dio/src/dio_mixin.dart] ResponseInterceptorHandler::next
    // 0x11bcafc: b               #0x11bcb88
    // 0x11bcb00: sub             SP, fp, #0xd8
    // 0x11bcb04: ldur            x2, [fp, #-0x98]
    // 0x11bcb08: stur            x0, [fp, #-0xa8]
    // 0x11bcb0c: stur            x1, [fp, #-0xb0]
    // 0x11bcb10: LoadField: r3 = r2->field_f
    //     0x11bcb10: ldur            w3, [x2, #0xf]
    // 0x11bcb14: DecompressPointer r3
    //     0x11bcb14: add             x3, x3, HEAP, lsl #32
    // 0x11bcb18: stur            x3, [fp, #-0x90]
    // 0x11bcb1c: r0 = CookieManagerSaveException()
    //     0x11bcb1c: bl              #0x11a3d7c  ; AllocateCookieManagerSaveExceptionStub -> CookieManagerSaveException (size=0x10)
    // 0x11bcb20: mov             x1, x0
    // 0x11bcb24: ldur            x0, [fp, #-0x98]
    // 0x11bcb28: stur            x1, [fp, #-0xb8]
    // 0x11bcb2c: StoreField: r1->field_7 = r0
    //     0x11bcb2c: stur            w0, [x1, #7]
    // 0x11bcb30: ldur            x2, [fp, #-0xa8]
    // 0x11bcb34: StoreField: r1->field_b = r2
    //     0x11bcb34: stur            w2, [x1, #0xb]
    // 0x11bcb38: r0 = DioException()
    //     0x11bcb38: bl              #0x8ea014  ; AllocateDioExceptionStub -> DioException (size=0x24)
    // 0x11bcb3c: stur            x0, [fp, #-0xa8]
    // 0x11bcb40: ldur            x16, [fp, #-0x98]
    // 0x11bcb44: r30 = Instance_DioExceptionType
    //     0x11bcb44: add             lr, PP, #0x15, lsl #12  ; [pp+0x15ce0] Obj!DioExceptionType@12c64e1
    //     0x11bcb48: ldr             lr, [lr, #0xce0]
    // 0x11bcb4c: stp             lr, x16, [SP, #0x10]
    // 0x11bcb50: ldur            x16, [fp, #-0xb8]
    // 0x11bcb54: ldur            lr, [fp, #-0xb0]
    // 0x11bcb58: stp             lr, x16, [SP]
    // 0x11bcb5c: mov             x1, x0
    // 0x11bcb60: ldur            x2, [fp, #-0x90]
    // 0x11bcb64: r4 = const [0, 0x6, 0x4, 0x2, error, 0x4, response, 0x2, stackTrace, 0x5, type, 0x3, null]
    //     0x11bcb64: add             x4, PP, #0x81, lsl #12  ; [pp+0x81fd8] List(13) [0, 0x6, 0x4, 0x2, "error", 0x4, "response", 0x2, "stackTrace", 0x5, "type", 0x3, Null]
    //     0x11bcb68: ldr             x4, [x4, #0xfd8]
    // 0x11bcb6c: r0 = DioException()
    //     0x11bcb6c: bl              #0x8e97ec  ; [package:dio/src/dio_exception.dart] DioException::DioException
    // 0x11bcb70: r16 = true
    //     0x11bcb70: add             x16, NULL, #0x20  ; true
    // 0x11bcb74: str             x16, [SP]
    // 0x11bcb78: ldur            x1, [fp, #-0xa0]
    // 0x11bcb7c: ldur            x2, [fp, #-0xa8]
    // 0x11bcb80: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x11bcb80: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x11bcb84: r0 = reject()
    //     0x11bcb84: bl              #0x8ee698  ; [package:dio/src/dio_mixin.dart] RequestInterceptorHandler::reject
    // 0x11bcb88: r0 = Null
    //     0x11bcb88: mov             x0, NULL
    // 0x11bcb8c: r0 = ReturnAsyncNotFuture()
    //     0x11bcb8c: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x11bcb90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11bcb90: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11bcb94: b               #0x11bcad0
  }
  [closure] Future<void> onRequest(dynamic, RequestOptions, RequestInterceptorHandler) {
    // ** addr: 0x122662c, size: 0x40
    // 0x122662c: EnterFrame
    //     0x122662c: stp             fp, lr, [SP, #-0x10]!
    //     0x1226630: mov             fp, SP
    // 0x1226634: ldr             x0, [fp, #0x20]
    // 0x1226638: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x1226638: ldur            w1, [x0, #0x17]
    // 0x122663c: DecompressPointer r1
    //     0x122663c: add             x1, x1, HEAP, lsl #32
    // 0x1226640: CheckStackOverflow
    //     0x1226640: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1226644: cmp             SP, x16
    //     0x1226648: b.ls            #0x1226664
    // 0x122664c: ldr             x2, [fp, #0x18]
    // 0x1226650: ldr             x3, [fp, #0x10]
    // 0x1226654: r0 = onRequest()
    //     0x1226654: bl              #0x122666c  ; [package:dio_cookie_manager/src/cookie_mgr.dart] CookieManager::onRequest
    // 0x1226658: LeaveFrame
    //     0x1226658: mov             SP, fp
    //     0x122665c: ldp             fp, lr, [SP], #0x10
    // 0x1226660: ret
    //     0x1226660: ret             
    // 0x1226664: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1226664: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1226668: b               #0x122664c
  }
  _ onRequest(/* No info */) async {
    // ** addr: 0x122666c, size: 0x140
    // 0x122666c: EnterFrame
    //     0x122666c: stp             fp, lr, [SP, #-0x10]!
    //     0x1226670: mov             fp, SP
    // 0x1226674: AllocStack(0xb0)
    //     0x1226674: sub             SP, SP, #0xb0
    // 0x1226678: SetupParameters(CookieManager this /* r1 => r3, fp-0x88 */, dynamic _ /* r3 => r1, fp-0x90 */)
    //     0x1226678: stur            NULL, [fp, #-8]
    //     0x122667c: stur            x1, [fp, #-0x80]
    //     0x1226680: mov             x16, x3
    //     0x1226684: mov             x3, x1
    //     0x1226688: mov             x1, x16
    //     0x122668c: stur            x2, [fp, #-0x88]
    //     0x1226690: stur            x1, [fp, #-0x90]
    // 0x1226694: CheckStackOverflow
    //     0x1226694: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1226698: cmp             SP, x16
    //     0x122669c: b.ls            #0x1226798
    // 0x12266a0: InitAsync() -> Future<void?>
    //     0x12266a0: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0x12266a4: bl              #0x7f5e44  ; InitAsyncStub
    // 0x12266a8: ldur            x0, [fp, #-0x88]
    // 0x12266ac: ldur            x1, [fp, #-0x80]
    // 0x12266b0: mov             x2, x0
    // 0x12266b4: r0 = loadCookies()
    //     0x12266b4: bl              #0x12267b8  ; [package:dio_cookie_manager/src/cookie_mgr.dart] CookieManager::loadCookies
    // 0x12266b8: mov             x1, x0
    // 0x12266bc: stur            x1, [fp, #-0x98]
    // 0x12266c0: r0 = Await()
    //     0x12266c0: bl              #0x7f5c00  ; AwaitStub
    // 0x12266c4: ldur            x4, [fp, #-0x88]
    // 0x12266c8: LoadField: r1 = r4->field_b
    //     0x12266c8: ldur            w1, [x4, #0xb]
    // 0x12266cc: DecompressPointer r1
    //     0x12266cc: add             x1, x1, HEAP, lsl #32
    // 0x12266d0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12266d4: cmp             w1, w16
    // 0x12266d8: b.eq            #0x12267a0
    // 0x12266dc: LoadField: r2 = r0->field_7
    //     0x12266dc: ldur            w2, [x0, #7]
    // 0x12266e0: cbz             w2, #0x12266ec
    // 0x12266e4: mov             x5, x0
    // 0x12266e8: b               #0x12266f0
    // 0x12266ec: r5 = Null
    //     0x12266ec: mov             x5, NULL
    // 0x12266f0: stur            x5, [fp, #-0x80]
    // 0x12266f4: r0 = LoadClassIdInstr(r1)
    //     0x12266f4: ldur            x0, [x1, #-1]
    //     0x12266f8: ubfx            x0, x0, #0xc, #0x14
    // 0x12266fc: mov             x3, x5
    // 0x1226700: r2 = "cookie"
    //     0x1226700: add             x2, PP, #0x11, lsl #12  ; [pp+0x11158] "cookie"
    //     0x1226704: ldr             x2, [x2, #0x158]
    // 0x1226708: r0 = GDT[cid_x0 + -0xd50]()
    //     0x1226708: sub             lr, x0, #0xd50
    //     0x122670c: ldr             lr, [x21, lr, lsl #3]
    //     0x1226710: blr             lr
    // 0x1226714: ldur            x1, [fp, #-0x90]
    // 0x1226718: ldur            x2, [fp, #-0x88]
    // 0x122671c: r0 = next()
    //     0x122671c: bl              #0x8ee7fc  ; [package:dio/src/dio_mixin.dart] RequestInterceptorHandler::next
    // 0x1226720: b               #0x1226790
    // 0x1226724: sub             SP, fp, #0xb0
    // 0x1226728: stur            x0, [fp, #-0x80]
    // 0x122672c: r0 = CookieManagerLoadException()
    //     0x122672c: bl              #0x12267ac  ; AllocateCookieManagerLoadExceptionStub -> CookieManagerLoadException (size=0xc)
    // 0x1226730: mov             x1, x0
    // 0x1226734: ldur            x0, [fp, #-0x80]
    // 0x1226738: stur            x1, [fp, #-0x98]
    // 0x122673c: StoreField: r1->field_7 = r0
    //     0x122673c: stur            w0, [x1, #7]
    // 0x1226740: r0 = DioException()
    //     0x1226740: bl              #0x8ea014  ; AllocateDioExceptionStub -> DioException (size=0x24)
    // 0x1226744: stur            x0, [fp, #-0x80]
    // 0x1226748: r16 = Instance_DioExceptionType
    //     0x1226748: add             x16, PP, #0x15, lsl #12  ; [pp+0x15ce0] Obj!DioExceptionType@12c64e1
    //     0x122674c: ldr             x16, [x16, #0xce0]
    // 0x1226750: ldur            lr, [fp, #-0x98]
    // 0x1226754: stp             lr, x16, [SP, #8]
    // 0x1226758: r16 = "Failed to load cookies for the request."
    //     0x1226758: add             x16, PP, #0x82, lsl #12  ; [pp+0x82220] "Failed to load cookies for the request."
    //     0x122675c: ldr             x16, [x16, #0x220]
    // 0x1226760: str             x16, [SP]
    // 0x1226764: mov             x1, x0
    // 0x1226768: ldur            x2, [fp, #-0x88]
    // 0x122676c: r4 = const [0, 0x5, 0x3, 0x2, error, 0x3, message, 0x4, type, 0x2, null]
    //     0x122676c: add             x4, PP, #0x82, lsl #12  ; [pp+0x82228] List(11) [0, 0x5, 0x3, 0x2, "error", 0x3, "message", 0x4, "type", 0x2, Null]
    //     0x1226770: ldr             x4, [x4, #0x228]
    // 0x1226774: r0 = DioException()
    //     0x1226774: bl              #0x8e97ec  ; [package:dio/src/dio_exception.dart] DioException::DioException
    // 0x1226778: r16 = true
    //     0x1226778: add             x16, NULL, #0x20  ; true
    // 0x122677c: str             x16, [SP]
    // 0x1226780: ldur            x1, [fp, #-0x90]
    // 0x1226784: ldur            x2, [fp, #-0x80]
    // 0x1226788: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x1226788: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x122678c: r0 = reject()
    //     0x122678c: bl              #0x8ee698  ; [package:dio/src/dio_mixin.dart] RequestInterceptorHandler::reject
    // 0x1226790: r0 = Null
    //     0x1226790: mov             x0, NULL
    // 0x1226794: r0 = ReturnAsyncNotFuture()
    //     0x1226794: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x1226798: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1226798: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x122679c: b               #0x12266a0
    // 0x12267a0: r9 = _headers
    //     0x12267a0: add             x9, PP, #0x15, lsl #12  ; [pp+0x15da8] Field <_RequestConfig@271184022._headers@271184022>: late (offset: 0xc)
    //     0x12267a4: ldr             x9, [x9, #0xda8]
    // 0x12267a8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12267a8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ loadCookies(/* No info */) async {
    // ** addr: 0x12267b8, size: 0x28c
    // 0x12267b8: EnterFrame
    //     0x12267b8: stp             fp, lr, [SP, #-0x10]!
    //     0x12267bc: mov             fp, SP
    // 0x12267c0: AllocStack(0x58)
    //     0x12267c0: sub             SP, SP, #0x58
    // 0x12267c4: SetupParameters(CookieManager this /* r1 => r0, fp-0x10 */, dynamic _ /* r2 => r1, fp-0x18 */)
    //     0x12267c4: stur            NULL, [fp, #-8]
    //     0x12267c8: mov             x0, x1
    //     0x12267cc: stur            x1, [fp, #-0x10]
    //     0x12267d0: mov             x1, x2
    //     0x12267d4: stur            x2, [fp, #-0x18]
    // 0x12267d8: CheckStackOverflow
    //     0x12267d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12267dc: cmp             SP, x16
    //     0x12267e0: b.ls            #0x1226a30
    // 0x12267e4: r1 = 1
    //     0x12267e4: mov             x1, #1
    // 0x12267e8: r0 = AllocateContext()
    //     0x12267e8: bl              #0x13de838  ; AllocateContextStub
    // 0x12267ec: mov             x2, x0
    // 0x12267f0: ldur            x1, [fp, #-0x10]
    // 0x12267f4: stur            x2, [fp, #-0x20]
    // 0x12267f8: StoreField: r2->field_f = r1
    //     0x12267f8: stur            w1, [x2, #0xf]
    // 0x12267fc: InitAsync() -> Future<String>
    //     0x12267fc: ldr             x0, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    //     0x1226800: bl              #0x7f5e44  ; InitAsyncStub
    // 0x1226804: ldur            x0, [fp, #-0x10]
    // 0x1226808: LoadField: r2 = r0->field_7
    //     0x1226808: ldur            w2, [x0, #7]
    // 0x122680c: DecompressPointer r2
    //     0x122680c: add             x2, x2, HEAP, lsl #32
    // 0x1226810: ldur            x1, [fp, #-0x18]
    // 0x1226814: stur            x2, [fp, #-0x28]
    // 0x1226818: r0 = uri()
    //     0x1226818: bl              #0x90c6d0  ; [package:dio/src/options.dart] RequestOptions::uri
    // 0x122681c: ldur            x1, [fp, #-0x28]
    // 0x1226820: mov             x2, x0
    // 0x1226824: r0 = loadForRequest()
    //     0x1226824: bl              #0xd57c84  ; [package:cookie_jar/src/jar/default.dart] DefaultCookieJar::loadForRequest
    // 0x1226828: mov             x1, x0
    // 0x122682c: stur            x1, [fp, #-0x28]
    // 0x1226830: r0 = Await()
    //     0x1226830: bl              #0x7f5c00  ; AwaitStub
    // 0x1226834: mov             x4, x0
    // 0x1226838: ldur            x3, [fp, #-0x18]
    // 0x122683c: stur            x4, [fp, #-0x28]
    // 0x1226840: LoadField: r1 = r3->field_b
    //     0x1226840: ldur            w1, [x3, #0xb]
    // 0x1226844: DecompressPointer r1
    //     0x1226844: add             x1, x1, HEAP, lsl #32
    // 0x1226848: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x122684c: cmp             w1, w16
    // 0x1226850: b.eq            #0x1226a38
    // 0x1226854: r0 = LoadClassIdInstr(r1)
    //     0x1226854: ldur            x0, [x1, #-1]
    //     0x1226858: ubfx            x0, x0, #0xc, #0x14
    // 0x122685c: r2 = "cookie"
    //     0x122685c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11158] "cookie"
    //     0x1226860: ldr             x2, [x2, #0x158]
    // 0x1226864: r0 = GDT[cid_x0 + -0xd48]()
    //     0x1226864: sub             lr, x0, #0xd48
    //     0x1226868: ldr             lr, [x21, lr, lsl #3]
    //     0x122686c: blr             lr
    // 0x1226870: mov             x3, x0
    // 0x1226874: r2 = Null
    //     0x1226874: mov             x2, NULL
    // 0x1226878: r1 = Null
    //     0x1226878: mov             x1, NULL
    // 0x122687c: stur            x3, [fp, #-0x30]
    // 0x1226880: r4 = 60
    //     0x1226880: mov             x4, #0x3c
    // 0x1226884: branchIfSmi(r0, 0x1226890)
    //     0x1226884: tbz             w0, #0, #0x1226890
    // 0x1226888: r4 = LoadClassIdInstr(r0)
    //     0x1226888: ldur            x4, [x0, #-1]
    //     0x122688c: ubfx            x4, x4, #0xc, #0x14
    // 0x1226890: sub             x4, x4, #0x5e
    // 0x1226894: cmp             x4, #1
    // 0x1226898: b.ls            #0x12268ac
    // 0x122689c: r8 = String?
    //     0x122689c: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x12268a0: r3 = Null
    //     0x12268a0: add             x3, PP, #0x82, lsl #12  ; [pp+0x82230] Null
    //     0x12268a4: ldr             x3, [x3, #0x230]
    // 0x12268a8: r0 = String?()
    //     0x12268a8: bl              #0x7db310  ; IsType_String?_Stub
    // 0x12268ac: ldur            x0, [fp, #-0x10]
    // 0x12268b0: LoadField: r3 = r0->field_f
    //     0x12268b0: ldur            w3, [x0, #0xf]
    // 0x12268b4: DecompressPointer r3
    //     0x12268b4: add             x3, x3, HEAP, lsl #32
    // 0x12268b8: mov             x1, x3
    // 0x12268bc: ldur            x2, [fp, #-0x18]
    // 0x12268c0: stur            x3, [fp, #-0x38]
    // 0x12268c4: r0 = []()
    //     0x12268c4: bl              #0x8c0e54  ; [dart:core] Expando::[]
    // 0x12268c8: mov             x1, x0
    // 0x12268cc: stur            x1, [fp, #-0x10]
    // 0x12268d0: cmp             w1, NULL
    // 0x12268d4: b.eq            #0x1226918
    // 0x12268d8: LoadField: r0 = r1->field_b
    //     0x12268d8: ldur            w0, [x1, #0xb]
    // 0x12268dc: DecompressPointer r0
    //     0x12268dc: add             x0, x0, HEAP, lsl #32
    // 0x12268e0: r2 = LoadClassIdInstr(r0)
    //     0x12268e0: ldur            x2, [x0, #-1]
    //     0x12268e4: ubfx            x2, x2, #0xc, #0x14
    // 0x12268e8: ldur            x16, [fp, #-0x30]
    // 0x12268ec: stp             x16, x0, [SP]
    // 0x12268f0: mov             x0, x2
    // 0x12268f4: mov             lr, x0
    // 0x12268f8: ldr             lr, [x21, lr, lsl #3]
    // 0x12268fc: blr             lr
    // 0x1226900: tbnz            w0, #4, #0x1226918
    // 0x1226904: ldur            x0, [fp, #-0x10]
    // 0x1226908: LoadField: r1 = r0->field_7
    //     0x1226908: ldur            w1, [x0, #7]
    // 0x122690c: DecompressPointer r1
    //     0x122690c: add             x1, x1, HEAP, lsl #32
    // 0x1226910: mov             x0, x1
    // 0x1226914: b               #0x122691c
    // 0x1226918: ldur            x0, [fp, #-0x30]
    // 0x122691c: stur            x0, [fp, #-0x10]
    // 0x1226920: r1 = <Cookie>
    //     0x1226920: add             x1, PP, #0xb, lsl #12  ; [pp+0xbe80] TypeArguments: <Cookie>
    //     0x1226924: ldr             x1, [x1, #0xe80]
    // 0x1226928: r2 = 0
    //     0x1226928: mov             x2, #0
    // 0x122692c: r0 = _GrowableList()
    //     0x122692c: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x1226930: mov             x4, x0
    // 0x1226934: ldur            x3, [fp, #-0x10]
    // 0x1226938: stur            x4, [fp, #-0x30]
    // 0x122693c: cmp             w3, NULL
    // 0x1226940: b.ne            #0x122694c
    // 0x1226944: r2 = Null
    //     0x1226944: mov             x2, NULL
    // 0x1226948: b               #0x12269d4
    // 0x122694c: r0 = LoadClassIdInstr(r3)
    //     0x122694c: ldur            x0, [x3, #-1]
    //     0x1226950: ubfx            x0, x0, #0xc, #0x14
    // 0x1226954: mov             x1, x3
    // 0x1226958: r2 = ";"
    //     0x1226958: add             x2, PP, #8, lsl #12  ; [pp+0x87a0] ";"
    //     0x122695c: ldr             x2, [x2, #0x7a0]
    // 0x1226960: r0 = GDT[cid_x0 + -0xffe]()
    //     0x1226960: sub             lr, x0, #0xffe
    //     0x1226964: ldr             lr, [x21, lr, lsl #3]
    //     0x1226968: blr             lr
    // 0x122696c: r1 = Function '<anonymous closure>':.
    //     0x122696c: add             x1, PP, #0x82, lsl #12  ; [pp+0x82240] AnonymousClosure: static (0x82e244), in [package:flutter/src/foundation/stack_frame.dart] StackFrame::fromStackString (0x82d624)
    //     0x1226970: ldr             x1, [x1, #0x240]
    // 0x1226974: r2 = Null
    //     0x1226974: mov             x2, NULL
    // 0x1226978: stur            x0, [fp, #-0x40]
    // 0x122697c: r0 = AllocateClosure()
    //     0x122697c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1226980: ldur            x1, [fp, #-0x40]
    // 0x1226984: mov             x2, x0
    // 0x1226988: r0 = where()
    //     0x1226988: bl              #0xb92e4c  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::where
    // 0x122698c: ldur            x2, [fp, #-0x20]
    // 0x1226990: r1 = Function '<anonymous closure>':.
    //     0x1226990: add             x1, PP, #0x82, lsl #12  ; [pp+0x82248] AnonymousClosure: (0x11a4820), in [package:dio_cookie_manager/src/cookie_mgr.dart] CookieManager::saveCookies (0x11a3d88)
    //     0x1226994: ldr             x1, [x1, #0x248]
    // 0x1226998: stur            x0, [fp, #-0x20]
    // 0x122699c: r0 = AllocateClosure()
    //     0x122699c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x12269a0: r16 = <Cookie?>
    //     0x12269a0: add             x16, PP, #0x82, lsl #12  ; [pp+0x82000] TypeArguments: <Cookie?>
    //     0x12269a4: ldr             x16, [x16]
    // 0x12269a8: ldur            lr, [fp, #-0x20]
    // 0x12269ac: stp             lr, x16, [SP, #8]
    // 0x12269b0: str             x0, [SP]
    // 0x12269b4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x12269b4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x12269b8: r0 = map()
    //     0x12269b8: bl              #0xb00654  ; [dart:_internal] WhereIterable::map
    // 0x12269bc: r16 = <Cookie>
    //     0x12269bc: add             x16, PP, #0xb, lsl #12  ; [pp+0xbe80] TypeArguments: <Cookie>
    //     0x12269c0: ldr             x16, [x16, #0xe80]
    // 0x12269c4: stp             x0, x16, [SP]
    // 0x12269c8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x12269c8: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x12269cc: r0 = whereType()
    //     0x12269cc: bl              #0xbfff48  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::whereType
    // 0x12269d0: mov             x2, x0
    // 0x12269d4: cmp             w2, NULL
    // 0x12269d8: b.eq            #0x12269e4
    // 0x12269dc: ldur            x1, [fp, #-0x30]
    // 0x12269e0: r0 = addAll()
    //     0x12269e0: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0x12269e4: ldur            x0, [fp, #-0x10]
    // 0x12269e8: ldur            x1, [fp, #-0x30]
    // 0x12269ec: ldur            x2, [fp, #-0x28]
    // 0x12269f0: r0 = addAll()
    //     0x12269f0: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0x12269f4: ldur            x1, [fp, #-0x30]
    // 0x12269f8: r0 = getCookies()
    //     0x12269f8: bl              #0x1226a50  ; [package:dio_cookie_manager/src/cookie_mgr.dart] CookieManager::getCookies
    // 0x12269fc: stur            x0, [fp, #-0x20]
    // 0x1226a00: r0 = _CookieHeaderState()
    //     0x1226a00: bl              #0x1226a44  ; Allocate_CookieHeaderStateStub -> _CookieHeaderState (size=0x10)
    // 0x1226a04: mov             x1, x0
    // 0x1226a08: ldur            x0, [fp, #-0x10]
    // 0x1226a0c: StoreField: r1->field_7 = r0
    //     0x1226a0c: stur            w0, [x1, #7]
    // 0x1226a10: ldur            x0, [fp, #-0x20]
    // 0x1226a14: StoreField: r1->field_b = r0
    //     0x1226a14: stur            w0, [x1, #0xb]
    // 0x1226a18: mov             x3, x1
    // 0x1226a1c: ldur            x1, [fp, #-0x38]
    // 0x1226a20: ldur            x2, [fp, #-0x18]
    // 0x1226a24: r0 = []=()
    //     0x1226a24: bl              #0x7f6290  ; [dart:core] Expando::[]=
    // 0x1226a28: ldur            x0, [fp, #-0x20]
    // 0x1226a2c: r0 = ReturnAsyncNotFuture()
    //     0x1226a2c: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x1226a30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1226a30: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1226a34: b               #0x12267e4
    // 0x1226a38: r9 = _headers
    //     0x1226a38: add             x9, PP, #0x15, lsl #12  ; [pp+0x15da8] Field <_RequestConfig@271184022._headers@271184022>: late (offset: 0xc)
    //     0x1226a3c: ldr             x9, [x9, #0xda8]
    // 0x1226a40: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x1226a40: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  static _ getCookies(/* No info */) {
    // ** addr: 0x1226a50, size: 0x94
    // 0x1226a50: EnterFrame
    //     0x1226a50: stp             fp, lr, [SP, #-0x10]!
    //     0x1226a54: mov             fp, SP
    // 0x1226a58: AllocStack(0x20)
    //     0x1226a58: sub             SP, SP, #0x20
    // 0x1226a5c: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */)
    //     0x1226a5c: mov             x0, x1
    //     0x1226a60: stur            x1, [fp, #-8]
    // 0x1226a64: CheckStackOverflow
    //     0x1226a64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1226a68: cmp             SP, x16
    //     0x1226a6c: b.ls            #0x1226adc
    // 0x1226a70: r1 = Function '<anonymous closure>': static.
    //     0x1226a70: add             x1, PP, #0x82, lsl #12  ; [pp+0x82250] AnonymousClosure: static (0x1226b58), in [package:dio_cookie_manager/src/cookie_mgr.dart] CookieManager::getCookies (0x1226a50)
    //     0x1226a74: ldr             x1, [x1, #0x250]
    // 0x1226a78: r2 = Null
    //     0x1226a78: mov             x2, NULL
    // 0x1226a7c: r0 = AllocateClosure()
    //     0x1226a7c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1226a80: str             x0, [SP]
    // 0x1226a84: ldur            x1, [fp, #-8]
    // 0x1226a88: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x1226a88: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x1226a8c: r0 = sort()
    //     0x1226a8c: bl              #0x9f9bf0  ; [dart:collection] ListBase::sort
    // 0x1226a90: r1 = Function '<anonymous closure>': static.
    //     0x1226a90: add             x1, PP, #0x82, lsl #12  ; [pp+0x82258] AnonymousClosure: static (0x1226ae4), in [package:dio_cookie_manager/src/cookie_mgr.dart] CookieManager::getCookies (0x1226a50)
    //     0x1226a94: ldr             x1, [x1, #0x258]
    // 0x1226a98: r2 = Null
    //     0x1226a98: mov             x2, NULL
    // 0x1226a9c: r0 = AllocateClosure()
    //     0x1226a9c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1226aa0: r16 = <String>
    //     0x1226aa0: ldr             x16, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    // 0x1226aa4: ldur            lr, [fp, #-8]
    // 0x1226aa8: stp             lr, x16, [SP, #8]
    // 0x1226aac: str             x0, [SP]
    // 0x1226ab0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x1226ab0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x1226ab4: r0 = map()
    //     0x1226ab4: bl              #0xba574c  ; [dart:collection] ListBase::map
    // 0x1226ab8: r16 = "; "
    //     0x1226ab8: add             x16, PP, #8, lsl #12  ; [pp+0x8610] "; "
    //     0x1226abc: ldr             x16, [x16, #0x610]
    // 0x1226ac0: str             x16, [SP]
    // 0x1226ac4: mov             x1, x0
    // 0x1226ac8: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x1226ac8: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x1226acc: r0 = join()
    //     0x1226acc: bl              #0xafe610  ; [dart:_internal] ListIterable::join
    // 0x1226ad0: LeaveFrame
    //     0x1226ad0: mov             SP, fp
    //     0x1226ad4: ldp             fp, lr, [SP], #0x10
    // 0x1226ad8: ret
    //     0x1226ad8: ret             
    // 0x1226adc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1226adc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1226ae0: b               #0x1226a70
  }
  [closure] static String <anonymous closure>(dynamic, Cookie) {
    // ** addr: 0x1226ae4, size: 0x74
    // 0x1226ae4: EnterFrame
    //     0x1226ae4: stp             fp, lr, [SP, #-0x10]!
    //     0x1226ae8: mov             fp, SP
    // 0x1226aec: AllocStack(0x10)
    //     0x1226aec: sub             SP, SP, #0x10
    // 0x1226af0: CheckStackOverflow
    //     0x1226af0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1226af4: cmp             SP, x16
    //     0x1226af8: b.ls            #0x1226b50
    // 0x1226afc: ldr             x0, [fp, #0x10]
    // 0x1226b00: LoadField: r3 = r0->field_7
    //     0x1226b00: ldur            w3, [x0, #7]
    // 0x1226b04: DecompressPointer r3
    //     0x1226b04: add             x3, x3, HEAP, lsl #32
    // 0x1226b08: stur            x3, [fp, #-8]
    // 0x1226b0c: r1 = Null
    //     0x1226b0c: mov             x1, NULL
    // 0x1226b10: r2 = 6
    //     0x1226b10: mov             x2, #6
    // 0x1226b14: r0 = AllocateArray()
    //     0x1226b14: bl              #0x13df928  ; AllocateArrayStub
    // 0x1226b18: mov             x1, x0
    // 0x1226b1c: ldur            x0, [fp, #-8]
    // 0x1226b20: StoreField: r1->field_f = r0
    //     0x1226b20: stur            w0, [x1, #0xf]
    // 0x1226b24: r16 = "="
    //     0x1226b24: ldr             x16, [PP, #0x11d0]  ; [pp+0x11d0] "="
    // 0x1226b28: StoreField: r1->field_13 = r16
    //     0x1226b28: stur            w16, [x1, #0x13]
    // 0x1226b2c: ldr             x0, [fp, #0x10]
    // 0x1226b30: LoadField: r2 = r0->field_b
    //     0x1226b30: ldur            w2, [x0, #0xb]
    // 0x1226b34: DecompressPointer r2
    //     0x1226b34: add             x2, x2, HEAP, lsl #32
    // 0x1226b38: ArrayStore: r1[0] = r2  ; List_4
    //     0x1226b38: stur            w2, [x1, #0x17]
    // 0x1226b3c: str             x1, [SP]
    // 0x1226b40: r0 = _interpolate()
    //     0x1226b40: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x1226b44: LeaveFrame
    //     0x1226b44: mov             SP, fp
    //     0x1226b48: ldp             fp, lr, [SP], #0x10
    // 0x1226b4c: ret
    //     0x1226b4c: ret             
    // 0x1226b50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1226b50: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1226b54: b               #0x1226afc
  }
  [closure] static int <anonymous closure>(dynamic, Cookie, Cookie) {
    // ** addr: 0x1226b58, size: 0xb4
    // 0x1226b58: EnterFrame
    //     0x1226b58: stp             fp, lr, [SP, #-0x10]!
    //     0x1226b5c: mov             fp, SP
    // 0x1226b60: CheckStackOverflow
    //     0x1226b60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1226b64: cmp             SP, x16
    //     0x1226b68: b.ls            #0x1226c04
    // 0x1226b6c: ldr             x0, [fp, #0x18]
    // 0x1226b70: LoadField: r1 = r0->field_1b
    //     0x1226b70: ldur            w1, [x0, #0x1b]
    // 0x1226b74: DecompressPointer r1
    //     0x1226b74: add             x1, x1, HEAP, lsl #32
    // 0x1226b78: cmp             w1, NULL
    // 0x1226b7c: b.ne            #0x1226ba4
    // 0x1226b80: ldr             x0, [fp, #0x10]
    // 0x1226b84: LoadField: r2 = r0->field_1b
    //     0x1226b84: ldur            w2, [x0, #0x1b]
    // 0x1226b88: DecompressPointer r2
    //     0x1226b88: add             x2, x2, HEAP, lsl #32
    // 0x1226b8c: cmp             w2, NULL
    // 0x1226b90: b.ne            #0x1226ba8
    // 0x1226b94: r0 = 0
    //     0x1226b94: mov             x0, #0
    // 0x1226b98: LeaveFrame
    //     0x1226b98: mov             SP, fp
    //     0x1226b9c: ldp             fp, lr, [SP], #0x10
    // 0x1226ba0: ret
    //     0x1226ba0: ret             
    // 0x1226ba4: ldr             x0, [fp, #0x10]
    // 0x1226ba8: cmp             w1, NULL
    // 0x1226bac: b.ne            #0x1226bc0
    // 0x1226bb0: r0 = -2
    //     0x1226bb0: mov             x0, #-2
    // 0x1226bb4: LeaveFrame
    //     0x1226bb4: mov             SP, fp
    //     0x1226bb8: ldp             fp, lr, [SP], #0x10
    // 0x1226bbc: ret
    //     0x1226bbc: ret             
    // 0x1226bc0: LoadField: r2 = r0->field_1b
    //     0x1226bc0: ldur            w2, [x0, #0x1b]
    // 0x1226bc4: DecompressPointer r2
    //     0x1226bc4: add             x2, x2, HEAP, lsl #32
    // 0x1226bc8: cmp             w2, NULL
    // 0x1226bcc: b.ne            #0x1226be0
    // 0x1226bd0: r0 = 2
    //     0x1226bd0: mov             x0, #2
    // 0x1226bd4: LeaveFrame
    //     0x1226bd4: mov             SP, fp
    //     0x1226bd8: ldp             fp, lr, [SP], #0x10
    // 0x1226bdc: ret
    //     0x1226bdc: ret             
    // 0x1226be0: LoadField: r0 = r2->field_7
    //     0x1226be0: ldur            w0, [x2, #7]
    // 0x1226be4: LoadField: r2 = r1->field_7
    //     0x1226be4: ldur            w2, [x1, #7]
    // 0x1226be8: mov             x1, x0
    // 0x1226bec: r0 = compareTo()
    //     0x1226bec: bl              #0xa01d58  ; [dart:core] _IntegerImplementation::compareTo
    // 0x1226bf0: lsl             x1, x0, #1
    // 0x1226bf4: mov             x0, x1
    // 0x1226bf8: LeaveFrame
    //     0x1226bf8: mov             SP, fp
    //     0x1226bfc: ldp             fp, lr, [SP], #0x10
    // 0x1226c00: ret
    //     0x1226c00: ret             
    // 0x1226c04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1226c04: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1226c08: b               #0x1226b6c
  }
}
