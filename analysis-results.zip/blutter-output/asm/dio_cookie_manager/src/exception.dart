// lib: , url: package:dio_cookie_manager/src/exception.dart

// class id: 1048719, size: 0x8
class :: {
}

// class id: 3393, size: 0x10, field offset: 0x8
class CookieManagerSaveException extends Object
    implements Exception {

  _ toString(/* No info */) {
    // ** addr: 0x1114a58, size: 0x5c
    // 0x1114a58: EnterFrame
    //     0x1114a58: stp             fp, lr, [SP, #-0x10]!
    //     0x1114a5c: mov             fp, SP
    // 0x1114a60: AllocStack(0x8)
    //     0x1114a60: sub             SP, SP, #8
    // 0x1114a64: CheckStackOverflow
    //     0x1114a64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1114a68: cmp             SP, x16
    //     0x1114a6c: b.ls            #0x1114aac
    // 0x1114a70: r1 = Null
    //     0x1114a70: mov             x1, NULL
    // 0x1114a74: r2 = 4
    //     0x1114a74: mov             x2, #4
    // 0x1114a78: r0 = AllocateArray()
    //     0x1114a78: bl              #0x13df928  ; AllocateArrayStub
    // 0x1114a7c: r16 = "CookieManagerSaveException: "
    //     0x1114a7c: add             x16, PP, #0x8a, lsl #12  ; [pp+0x8af48] "CookieManagerSaveException: "
    //     0x1114a80: ldr             x16, [x16, #0xf48]
    // 0x1114a84: StoreField: r0->field_f = r16
    //     0x1114a84: stur            w16, [x0, #0xf]
    // 0x1114a88: ldr             x1, [fp, #0x10]
    // 0x1114a8c: LoadField: r2 = r1->field_b
    //     0x1114a8c: ldur            w2, [x1, #0xb]
    // 0x1114a90: DecompressPointer r2
    //     0x1114a90: add             x2, x2, HEAP, lsl #32
    // 0x1114a94: StoreField: r0->field_13 = r2
    //     0x1114a94: stur            w2, [x0, #0x13]
    // 0x1114a98: str             x0, [SP]
    // 0x1114a9c: r0 = _interpolate()
    //     0x1114a9c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x1114aa0: LeaveFrame
    //     0x1114aa0: mov             SP, fp
    //     0x1114aa4: ldp             fp, lr, [SP], #0x10
    // 0x1114aa8: ret
    //     0x1114aa8: ret             
    // 0x1114aac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1114aac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1114ab0: b               #0x1114a70
  }
}

// class id: 3394, size: 0xc, field offset: 0x8
class CookieManagerLoadException extends Object
    implements Exception {

  _ toString(/* No info */) {
    // ** addr: 0x11149fc, size: 0x5c
    // 0x11149fc: EnterFrame
    //     0x11149fc: stp             fp, lr, [SP, #-0x10]!
    //     0x1114a00: mov             fp, SP
    // 0x1114a04: AllocStack(0x8)
    //     0x1114a04: sub             SP, SP, #8
    // 0x1114a08: CheckStackOverflow
    //     0x1114a08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1114a0c: cmp             SP, x16
    //     0x1114a10: b.ls            #0x1114a50
    // 0x1114a14: r1 = Null
    //     0x1114a14: mov             x1, NULL
    // 0x1114a18: r2 = 4
    //     0x1114a18: mov             x2, #4
    // 0x1114a1c: r0 = AllocateArray()
    //     0x1114a1c: bl              #0x13df928  ; AllocateArrayStub
    // 0x1114a20: r16 = "CookieManagerLoadException: "
    //     0x1114a20: add             x16, PP, #0x8a, lsl #12  ; [pp+0x8af40] "CookieManagerLoadException: "
    //     0x1114a24: ldr             x16, [x16, #0xf40]
    // 0x1114a28: StoreField: r0->field_f = r16
    //     0x1114a28: stur            w16, [x0, #0xf]
    // 0x1114a2c: ldr             x1, [fp, #0x10]
    // 0x1114a30: LoadField: r2 = r1->field_7
    //     0x1114a30: ldur            w2, [x1, #7]
    // 0x1114a34: DecompressPointer r2
    //     0x1114a34: add             x2, x2, HEAP, lsl #32
    // 0x1114a38: StoreField: r0->field_13 = r2
    //     0x1114a38: stur            w2, [x0, #0x13]
    // 0x1114a3c: str             x0, [SP]
    // 0x1114a40: r0 = _interpolate()
    //     0x1114a40: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x1114a44: LeaveFrame
    //     0x1114a44: mov             SP, fp
    //     0x1114a48: ldp             fp, lr, [SP], #0x10
    // 0x1114a4c: ret
    //     0x1114a4c: ret             
    // 0x1114a50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1114a50: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1114a54: b               #0x1114a14
  }
}
