// lib: , url: package:firebase_core/firebase_core.dart

// class id: 1048744, size: 0x8
class :: {
}

// class id: 3373, size: 0xc, field offset: 0x8
class FirebaseApp extends Object {

  _ toString(/* No info */) {
    // ** addr: 0x1114dd8, size: 0x78
    // 0x1114dd8: EnterFrame
    //     0x1114dd8: stp             fp, lr, [SP, #-0x10]!
    //     0x1114ddc: mov             fp, SP
    // 0x1114de0: AllocStack(0x8)
    //     0x1114de0: sub             SP, SP, #8
    // 0x1114de4: CheckStackOverflow
    //     0x1114de4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1114de8: cmp             SP, x16
    //     0x1114dec: b.ls            #0x1114e48
    // 0x1114df0: r1 = Null
    //     0x1114df0: mov             x1, NULL
    // 0x1114df4: r2 = 8
    //     0x1114df4: mov             x2, #8
    // 0x1114df8: r0 = AllocateArray()
    //     0x1114df8: bl              #0x13df928  ; AllocateArrayStub
    // 0x1114dfc: r16 = FirebaseApp
    //     0x1114dfc: add             x16, PP, #0xd, lsl #12  ; [pp+0xd0b0] Type: FirebaseApp
    //     0x1114e00: ldr             x16, [x16, #0xb0]
    // 0x1114e04: StoreField: r0->field_f = r16
    //     0x1114e04: stur            w16, [x0, #0xf]
    // 0x1114e08: r16 = "("
    //     0x1114e08: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc98] "("
    //     0x1114e0c: ldr             x16, [x16, #0xc98]
    // 0x1114e10: StoreField: r0->field_13 = r16
    //     0x1114e10: stur            w16, [x0, #0x13]
    // 0x1114e14: ldr             x1, [fp, #0x10]
    // 0x1114e18: LoadField: r2 = r1->field_7
    //     0x1114e18: ldur            w2, [x1, #7]
    // 0x1114e1c: DecompressPointer r2
    //     0x1114e1c: add             x2, x2, HEAP, lsl #32
    // 0x1114e20: LoadField: r1 = r2->field_7
    //     0x1114e20: ldur            w1, [x2, #7]
    // 0x1114e24: DecompressPointer r1
    //     0x1114e24: add             x1, x1, HEAP, lsl #32
    // 0x1114e28: ArrayStore: r0[0] = r1  ; List_4
    //     0x1114e28: stur            w1, [x0, #0x17]
    // 0x1114e2c: r16 = ")"
    //     0x1114e2c: ldr             x16, [PP, #0xe60]  ; [pp+0xe60] ")"
    // 0x1114e30: StoreField: r0->field_1b = r16
    //     0x1114e30: stur            w16, [x0, #0x1b]
    // 0x1114e34: str             x0, [SP]
    // 0x1114e38: r0 = _interpolate()
    //     0x1114e38: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x1114e3c: LeaveFrame
    //     0x1114e3c: mov             SP, fp
    //     0x1114e40: ldp             fp, lr, [SP], #0x10
    // 0x1114e44: ret
    //     0x1114e44: ret             
    // 0x1114e48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1114e48: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1114e4c: b               #0x1114df0
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x114998c, size: 0x68
    // 0x114998c: EnterFrame
    //     0x114998c: stp             fp, lr, [SP, #-0x10]!
    //     0x1149990: mov             fp, SP
    // 0x1149994: CheckStackOverflow
    //     0x1149994: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1149998: cmp             SP, x16
    //     0x114999c: b.ls            #0x11499ec
    // 0x11499a0: ldr             x0, [fp, #0x10]
    // 0x11499a4: LoadField: r1 = r0->field_7
    //     0x11499a4: ldur            w1, [x0, #7]
    // 0x11499a8: DecompressPointer r1
    //     0x11499a8: add             x1, x1, HEAP, lsl #32
    // 0x11499ac: LoadField: r0 = r1->field_7
    //     0x11499ac: ldur            w0, [x1, #7]
    // 0x11499b0: DecompressPointer r0
    //     0x11499b0: add             x0, x0, HEAP, lsl #32
    // 0x11499b4: LoadField: r2 = r1->field_b
    //     0x11499b4: ldur            w2, [x1, #0xb]
    // 0x11499b8: DecompressPointer r2
    //     0x11499b8: add             x2, x2, HEAP, lsl #32
    // 0x11499bc: mov             x1, x0
    // 0x11499c0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x11499c0: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x11499c4: r0 = hash()
    //     0x11499c4: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x11499c8: mov             x2, x0
    // 0x11499cc: r0 = BoxInt64Instr(r2)
    //     0x11499cc: sbfiz           x0, x2, #1, #0x1f
    //     0x11499d0: cmp             x2, x0, asr #1
    //     0x11499d4: b.eq            #0x11499e0
    //     0x11499d8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x11499dc: stur            x2, [x0, #7]
    // 0x11499e0: LeaveFrame
    //     0x11499e0: mov             SP, fp
    //     0x11499e4: ldp             fp, lr, [SP], #0x10
    // 0x11499e8: ret
    //     0x11499e8: ret             
    // 0x11499ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11499ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11499f0: b               #0x11499a0
  }
  _ ==(/* No info */) {
    // ** addr: 0x1293cac, size: 0xfc
    // 0x1293cac: EnterFrame
    //     0x1293cac: stp             fp, lr, [SP, #-0x10]!
    //     0x1293cb0: mov             fp, SP
    // 0x1293cb4: AllocStack(0x20)
    //     0x1293cb4: sub             SP, SP, #0x20
    // 0x1293cb8: CheckStackOverflow
    //     0x1293cb8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1293cbc: cmp             SP, x16
    //     0x1293cc0: b.ls            #0x1293da0
    // 0x1293cc4: ldr             x0, [fp, #0x10]
    // 0x1293cc8: cmp             w0, NULL
    // 0x1293ccc: b.ne            #0x1293ce0
    // 0x1293cd0: r0 = false
    //     0x1293cd0: add             x0, NULL, #0x30  ; false
    // 0x1293cd4: LeaveFrame
    //     0x1293cd4: mov             SP, fp
    //     0x1293cd8: ldp             fp, lr, [SP], #0x10
    // 0x1293cdc: ret
    //     0x1293cdc: ret             
    // 0x1293ce0: ldr             x1, [fp, #0x18]
    // 0x1293ce4: cmp             w1, w0
    // 0x1293ce8: b.ne            #0x1293cfc
    // 0x1293cec: r0 = true
    //     0x1293cec: add             x0, NULL, #0x20  ; true
    // 0x1293cf0: LeaveFrame
    //     0x1293cf0: mov             SP, fp
    //     0x1293cf4: ldp             fp, lr, [SP], #0x10
    // 0x1293cf8: ret
    //     0x1293cf8: ret             
    // 0x1293cfc: r2 = 60
    //     0x1293cfc: mov             x2, #0x3c
    // 0x1293d00: branchIfSmi(r0, 0x1293d0c)
    //     0x1293d00: tbz             w0, #0, #0x1293d0c
    // 0x1293d04: r2 = LoadClassIdInstr(r0)
    //     0x1293d04: ldur            x2, [x0, #-1]
    //     0x1293d08: ubfx            x2, x2, #0xc, #0x14
    // 0x1293d0c: cmp             x2, #0xd2d
    // 0x1293d10: b.eq            #0x1293d24
    // 0x1293d14: r0 = false
    //     0x1293d14: add             x0, NULL, #0x30  ; false
    // 0x1293d18: LeaveFrame
    //     0x1293d18: mov             SP, fp
    //     0x1293d1c: ldp             fp, lr, [SP], #0x10
    // 0x1293d20: ret
    //     0x1293d20: ret             
    // 0x1293d24: LoadField: r2 = r0->field_7
    //     0x1293d24: ldur            w2, [x0, #7]
    // 0x1293d28: DecompressPointer r2
    //     0x1293d28: add             x2, x2, HEAP, lsl #32
    // 0x1293d2c: stur            x2, [fp, #-0x10]
    // 0x1293d30: LoadField: r0 = r2->field_7
    //     0x1293d30: ldur            w0, [x2, #7]
    // 0x1293d34: DecompressPointer r0
    //     0x1293d34: add             x0, x0, HEAP, lsl #32
    // 0x1293d38: LoadField: r3 = r1->field_7
    //     0x1293d38: ldur            w3, [x1, #7]
    // 0x1293d3c: DecompressPointer r3
    //     0x1293d3c: add             x3, x3, HEAP, lsl #32
    // 0x1293d40: stur            x3, [fp, #-8]
    // 0x1293d44: LoadField: r1 = r3->field_7
    //     0x1293d44: ldur            w1, [x3, #7]
    // 0x1293d48: DecompressPointer r1
    //     0x1293d48: add             x1, x1, HEAP, lsl #32
    // 0x1293d4c: r4 = LoadClassIdInstr(r0)
    //     0x1293d4c: ldur            x4, [x0, #-1]
    //     0x1293d50: ubfx            x4, x4, #0xc, #0x14
    // 0x1293d54: stp             x1, x0, [SP]
    // 0x1293d58: mov             x0, x4
    // 0x1293d5c: mov             lr, x0
    // 0x1293d60: ldr             lr, [x21, lr, lsl #3]
    // 0x1293d64: blr             lr
    // 0x1293d68: tbnz            w0, #4, #0x1293d90
    // 0x1293d6c: ldur            x0, [fp, #-0x10]
    // 0x1293d70: ldur            x1, [fp, #-8]
    // 0x1293d74: LoadField: r2 = r0->field_b
    //     0x1293d74: ldur            w2, [x0, #0xb]
    // 0x1293d78: DecompressPointer r2
    //     0x1293d78: add             x2, x2, HEAP, lsl #32
    // 0x1293d7c: LoadField: r0 = r1->field_b
    //     0x1293d7c: ldur            w0, [x1, #0xb]
    // 0x1293d80: DecompressPointer r0
    //     0x1293d80: add             x0, x0, HEAP, lsl #32
    // 0x1293d84: stp             x0, x2, [SP]
    // 0x1293d88: r0 = ==()
    //     0x1293d88: bl              #0x1293e78  ; [package:firebase_core_platform_interface/firebase_core_platform_interface.dart] FirebaseOptions::==
    // 0x1293d8c: b               #0x1293d94
    // 0x1293d90: r0 = false
    //     0x1293d90: add             x0, NULL, #0x30  ; false
    // 0x1293d94: LeaveFrame
    //     0x1293d94: mov             SP, fp
    //     0x1293d98: ldp             fp, lr, [SP], #0x10
    // 0x1293d9c: ret
    //     0x1293d9c: ret             
    // 0x1293da0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1293da0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1293da4: b               #0x1293cc4
  }
}

// class id: 3374, size: 0x8, field offset: 0x8
abstract class Firebase extends Object {

  static _ app(/* No info */) {
    // ** addr: 0x8c0c7c, size: 0x5c
    // 0x8c0c7c: EnterFrame
    //     0x8c0c7c: stp             fp, lr, [SP, #-0x10]!
    //     0x8c0c80: mov             fp, SP
    // 0x8c0c84: AllocStack(0x10)
    //     0x8c0c84: sub             SP, SP, #0x10
    // 0x8c0c88: CheckStackOverflow
    //     0x8c0c88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c0c8c: cmp             SP, x16
    //     0x8c0c90: b.ls            #0x8c0cd0
    // 0x8c0c94: r0 = _delegate()
    //     0x8c0c94: bl              #0x8c11ec  ; [package:firebase_core/firebase_core.dart] Firebase::_delegate
    // 0x8c0c98: mov             x1, x0
    // 0x8c0c9c: r2 = "[DEFAULT]"
    //     0x8c0c9c: add             x2, PP, #8, lsl #12  ; [pp+0x8c88] "[DEFAULT]"
    //     0x8c0ca0: ldr             x2, [x2, #0xc88]
    // 0x8c0ca4: r0 = app()
    //     0x8c0ca4: bl              #0x8c1098  ; [package:firebase_core_platform_interface/firebase_core_platform_interface.dart] MethodChannelFirebase::app
    // 0x8c0ca8: stur            x0, [fp, #-8]
    // 0x8c0cac: r0 = FirebaseApp()
    //     0x8c0cac: bl              #0x8c108c  ; AllocateFirebaseAppStub -> FirebaseApp (size=0xc)
    // 0x8c0cb0: ldur            x1, [fp, #-8]
    // 0x8c0cb4: stur            x0, [fp, #-0x10]
    // 0x8c0cb8: StoreField: r0->field_7 = r1
    //     0x8c0cb8: stur            w1, [x0, #7]
    // 0x8c0cbc: r0 = verify()
    //     0x8c0cbc: bl              #0x8c0cd8  ; [package:firebase_core_platform_interface/firebase_core_platform_interface.dart] FirebaseAppPlatform::verify
    // 0x8c0cc0: ldur            x0, [fp, #-0x10]
    // 0x8c0cc4: LeaveFrame
    //     0x8c0cc4: mov             SP, fp
    //     0x8c0cc8: ldp             fp, lr, [SP], #0x10
    // 0x8c0ccc: ret
    //     0x8c0ccc: ret             
    // 0x8c0cd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c0cd0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c0cd4: b               #0x8c0c94
  }
  FirebasePlatform _delegate() {
    // ** addr: 0x8c11ec, size: 0x64
    // 0x8c11ec: EnterFrame
    //     0x8c11ec: stp             fp, lr, [SP, #-0x10]!
    //     0x8c11f0: mov             fp, SP
    // 0x8c11f4: CheckStackOverflow
    //     0x8c11f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c11f8: cmp             SP, x16
    //     0x8c11fc: b.ls            #0x8c1248
    // 0x8c1200: r0 = LoadStaticField(0xf20)
    //     0x8c1200: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8c1204: ldr             x0, [x0, #0x1e40]
    // 0x8c1208: cmp             w0, NULL
    // 0x8c120c: b.ne            #0x8c123c
    // 0x8c1210: r0 = LoadStaticField(0x10a4)
    //     0x8c1210: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8c1214: ldr             x0, [x0, #0x2148]
    // 0x8c1218: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8c121c: cmp             w0, w16
    // 0x8c1220: b.ne            #0x8c1230
    // 0x8c1224: r2 = _instance
    //     0x8c1224: add             x2, PP, #8, lsl #12  ; [pp+0x8cc0] Field <FirebasePlatform._instance@1279397154>: static late (offset: 0x10a4)
    //     0x8c1228: ldr             x2, [x2, #0xcc0]
    // 0x8c122c: r0 = InitLateStaticField()
    //     0x8c122c: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0x8c1230: mov             x2, x0
    // 0x8c1234: StoreStaticField(0xf20, r2)
    //     0x8c1234: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x8c1238: str             x2, [x1, #0x1e40]
    // 0x8c123c: LeaveFrame
    //     0x8c123c: mov             SP, fp
    //     0x8c1240: ldp             fp, lr, [SP], #0x10
    // 0x8c1244: ret
    //     0x8c1244: ret             
    // 0x8c1248: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c1248: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c124c: b               #0x8c1200
  }
  static _ initializeApp(/* No info */) async {
    // ** addr: 0x13e9b04, size: 0xbc
    // 0x13e9b04: EnterFrame
    //     0x13e9b04: stp             fp, lr, [SP, #-0x10]!
    //     0x13e9b08: mov             fp, SP
    // 0x13e9b0c: AllocStack(0x18)
    //     0x13e9b0c: sub             SP, SP, #0x18
    // 0x13e9b10: SetupParameters(dynamic _ /* r1 => r3, fp-0x10 */)
    //     0x13e9b10: stur            NULL, [fp, #-8]
    //     0x13e9b14: mov             x3, x1
    //     0x13e9b18: stur            x1, [fp, #-0x10]
    // 0x13e9b1c: CheckStackOverflow
    //     0x13e9b1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13e9b20: cmp             SP, x16
    //     0x13e9b24: b.ls            #0x13e9bb8
    // 0x13e9b28: InitAsync() -> Future<FirebaseApp>
    //     0x13e9b28: add             x0, PP, #8, lsl #12  ; [pp+0x8cd0] TypeArguments: <FirebaseApp>
    //     0x13e9b2c: ldr             x0, [x0, #0xcd0]
    //     0x13e9b30: bl              #0x7f5e44  ; InitAsyncStub
    // 0x13e9b34: r0 = LoadStaticField(0xf20)
    //     0x13e9b34: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x13e9b38: ldr             x0, [x0, #0x1e40]
    // 0x13e9b3c: cmp             w0, NULL
    // 0x13e9b40: b.ne            #0x13e9b78
    // 0x13e9b44: r0 = LoadStaticField(0x10a4)
    //     0x13e9b44: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x13e9b48: ldr             x0, [x0, #0x2148]
    // 0x13e9b4c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x13e9b50: cmp             w0, w16
    // 0x13e9b54: b.ne            #0x13e9b64
    // 0x13e9b58: r2 = _instance
    //     0x13e9b58: add             x2, PP, #8, lsl #12  ; [pp+0x8cc0] Field <FirebasePlatform._instance@1279397154>: static late (offset: 0x10a4)
    //     0x13e9b5c: ldr             x2, [x2, #0xcc0]
    // 0x13e9b60: r0 = InitLateStaticField()
    //     0x13e9b60: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0x13e9b64: mov             x2, x0
    // 0x13e9b68: StoreStaticField(0xf20, r2)
    //     0x13e9b68: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x13e9b6c: str             x2, [x1, #0x1e40]
    // 0x13e9b70: mov             x1, x0
    // 0x13e9b74: b               #0x13e9b7c
    // 0x13e9b78: mov             x1, x0
    // 0x13e9b7c: ldur            x3, [fp, #-0x10]
    // 0x13e9b80: r2 = "simaster_vnext_ugm_student"
    //     0x13e9b80: add             x2, PP, #8, lsl #12  ; [pp+0x8cd8] "simaster_vnext_ugm_student"
    //     0x13e9b84: ldr             x2, [x2, #0xcd8]
    // 0x13e9b88: r0 = initializeApp()
    //     0x13e9b88: bl              #0x13e9bc0  ; [package:firebase_core_platform_interface/firebase_core_platform_interface.dart] MethodChannelFirebase::initializeApp
    // 0x13e9b8c: mov             x1, x0
    // 0x13e9b90: stur            x1, [fp, #-0x10]
    // 0x13e9b94: r0 = Await()
    //     0x13e9b94: bl              #0x7f5c00  ; AwaitStub
    // 0x13e9b98: stur            x0, [fp, #-0x10]
    // 0x13e9b9c: r0 = FirebaseApp()
    //     0x13e9b9c: bl              #0x8c108c  ; AllocateFirebaseAppStub -> FirebaseApp (size=0xc)
    // 0x13e9ba0: ldur            x1, [fp, #-0x10]
    // 0x13e9ba4: stur            x0, [fp, #-0x18]
    // 0x13e9ba8: StoreField: r0->field_7 = r1
    //     0x13e9ba8: stur            w1, [x0, #7]
    // 0x13e9bac: r0 = verify()
    //     0x13e9bac: bl              #0x8c0cd8  ; [package:firebase_core_platform_interface/firebase_core_platform_interface.dart] FirebaseAppPlatform::verify
    // 0x13e9bb0: ldur            x0, [fp, #-0x18]
    // 0x13e9bb4: r0 = ReturnAsyncNotFuture()
    //     0x13e9bb4: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x13e9bb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13e9bb8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13e9bbc: b               #0x13e9b28
  }
}
