// lib: , url: package:ffi/src/utf8.dart

// class id: 1048725, size: 0x8
class :: {

  static _ Utf8Pointer.toDartString(/* No info */) {
    // ** addr: 0xe90828, size: 0x158
    // 0xe90828: EnterFrame
    //     0xe90828: stp             fp, lr, [SP, #-0x10]!
    //     0xe9082c: mov             fp, SP
    // 0xe90830: AllocStack(0x30)
    //     0xe90830: sub             SP, SP, #0x30
    // 0xe90834: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */)
    //     0xe90834: mov             x0, x1
    //     0xe90838: stur            x1, [fp, #-8]
    // 0xe9083c: CheckStackOverflow
    //     0xe9083c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe90840: cmp             SP, x16
    //     0xe90844: b.ls            #0xe90970
    // 0xe90848: mov             x1, x0
    // 0xe9084c: r0 = Utf16Pointer._ensureNotNullptr()
    //     0xe9084c: bl              #0xe9098c  ; [package:ffi/src/utf16.dart] ::Utf16Pointer._ensureNotNullptr
    // 0xe90850: r16 = <Uint8>
    //     0xe90850: add             x16, PP, #0xd, lsl #12  ; [pp+0xd2d0] TypeArguments: <Uint8>
    //     0xe90854: ldr             x16, [x16, #0x2d0]
    // 0xe90858: ldur            lr, [fp, #-8]
    // 0xe9085c: stp             lr, x16, [SP]
    // 0xe90860: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xe90860: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xe90864: r0 = cast()
    //     0xe90864: bl              #0x81b9c4  ; [dart:ffi] Pointer::cast
    // 0xe90868: mov             x2, x0
    // 0xe9086c: stur            x2, [fp, #-0x18]
    // 0xe90870: LoadField: r3 = r2->field_7
    //     0xe90870: ldur            x3, [x2, #7]
    // 0xe90874: r4 = 0
    //     0xe90874: mov             x4, #0
    // 0xe90878: stur            x4, [fp, #-0x10]
    // 0xe9087c: CheckStackOverflow
    //     0xe9087c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe90880: cmp             SP, x16
    //     0xe90884: b.ls            #0xe90978
    // 0xe90888: r0 = BoxInt64Instr(r4)
    //     0xe90888: sbfiz           x0, x4, #1, #0x1f
    //     0xe9088c: cmp             x4, x0, asr #1
    //     0xe90890: b.eq            #0xe9089c
    //     0xe90894: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xe90898: stur            x4, [x0, #7]
    // 0xe9089c: stur            x0, [fp, #-8]
    // 0xe908a0: ldrb            w1, [x3, x4]
    // 0xe908a4: cbz             x1, #0xe908b4
    // 0xe908a8: add             x0, x4, #1
    // 0xe908ac: mov             x4, x0
    // 0xe908b0: b               #0xe90878
    // 0xe908b4: r16 = <Pointer<Uint8>>
    //     0xe908b4: add             x16, PP, #0xd, lsl #12  ; [pp+0xd2d8] TypeArguments: <Pointer<Uint8>>
    //     0xe908b8: ldr             x16, [x16, #0x2d8]
    // 0xe908bc: stp             x2, x16, [SP, #8]
    // 0xe908c0: r16 = "Pointer<Uint8>"
    //     0xe908c0: add             x16, PP, #0xd, lsl #12  ; [pp+0xd2e0] "Pointer<Uint8>"
    //     0xe908c4: ldr             x16, [x16, #0x2e0]
    // 0xe908c8: str             x16, [SP]
    // 0xe908cc: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xe908cc: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xe908d0: r0 = checkNotNull()
    //     0xe908d0: bl              #0x8288b0  ; [dart:core] ArgumentError::checkNotNull
    // 0xe908d4: r16 = <int>
    //     0xe908d4: ldr             x16, [PP, #0x50]  ; [pp+0x50] TypeArguments: <int>
    // 0xe908d8: ldur            lr, [fp, #-8]
    // 0xe908dc: stp             lr, x16, [SP, #8]
    // 0xe908e0: r16 = "length"
    //     0xe908e0: add             x16, PP, #0xd, lsl #12  ; [pp+0xd2e8] "length"
    //     0xe908e4: ldr             x16, [x16, #0x2e8]
    // 0xe908e8: str             x16, [SP]
    // 0xe908ec: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xe908ec: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xe908f0: r0 = checkNotNull()
    //     0xe908f0: bl              #0x8288b0  ; [dart:core] ArgumentError::checkNotNull
    // 0xe908f4: ldur            x0, [fp, #-0x10]
    // 0xe908f8: tbnz            x0, #0x3f, #0xe90948
    // 0xe908fc: r17 = 1073741823
    //     0xe908fc: mov             x17, #0x3fffffff
    // 0xe90900: cmp             x0, x17
    // 0xe90904: b.gt            #0xe90948
    // 0xe90908: ldur            x0, [fp, #-0x18]
    // 0xe9090c: ldur            x1, [fp, #-8]
    // 0xe90910: r0 = _ExternalUint8Array()
    //     0xe90910: bl              #0xe90980  ; Allocate_ExternalUint8ArrayStub -> _ExternalUint8Array (size=-0x8)
    // 0xe90914: mov             x1, x0
    // 0xe90918: ldur            x0, [fp, #-8]
    // 0xe9091c: StoreField: r1->field_13 = r0
    //     0xe9091c: stur            w0, [x1, #0x13]
    // 0xe90920: ldur            x0, [fp, #-0x18]
    // 0xe90924: LoadField: r2 = r0->field_7
    //     0xe90924: ldur            x2, [x0, #7]
    // 0xe90928: StoreField: r1->field_7 = r2
    //     0xe90928: stur            x2, [x1, #7]
    // 0xe9092c: mov             x2, x1
    // 0xe90930: r1 = Instance_Utf8Codec
    //     0xe90930: ldr             x1, [PP, #0x11e0]  ; [pp+0x11e0] Obj!Utf8Codec@12b7e61
    // 0xe90934: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xe90934: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xe90938: r0 = decode()
    //     0xe90938: bl              #0x121a094  ; [dart:convert] Utf8Codec::decode
    // 0xe9093c: LeaveFrame
    //     0xe9093c: mov             SP, fp
    //     0xe90940: ldp             fp, lr, [SP], #0x10
    // 0xe90944: ret
    //     0xe90944: ret             
    // 0xe90948: r0 = ArgumentError()
    //     0xe90948: bl              #0x7dcb60  ; AllocateArgumentErrorStub -> ArgumentError (size=0x1c)
    // 0xe9094c: mov             x1, x0
    // 0xe90950: r0 = "length must be in the range [0, 1073741823]."
    //     0xe90950: add             x0, PP, #0xd, lsl #12  ; [pp+0xd2f0] "length must be in the range [0, 1073741823]."
    //     0xe90954: ldr             x0, [x0, #0x2f0]
    // 0xe90958: ArrayStore: r1[0] = r0  ; List_4
    //     0xe90958: stur            w0, [x1, #0x17]
    // 0xe9095c: r0 = false
    //     0xe9095c: add             x0, NULL, #0x30  ; false
    // 0xe90960: StoreField: r1->field_b = r0
    //     0xe90960: stur            w0, [x1, #0xb]
    // 0xe90964: mov             x0, x1
    // 0xe90968: r0 = Throw()
    //     0xe90968: bl              #0x13ddb2c  ; ThrowStub
    // 0xe9096c: brk             #0
    // 0xe90970: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe90970: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe90974: b               #0xe90848
    // 0xe90978: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe90978: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe9097c: b               #0xe90888
  }
  static _ StringUtf8Pointer.toNativeUtf8(/* No info */) {
    // ** addr: 0xe96f54, size: 0x290
    // 0xe96f54: EnterFrame
    //     0xe96f54: stp             fp, lr, [SP, #-0x10]!
    //     0xe96f58: mov             fp, SP
    // 0xe96f5c: AllocStack(0x48)
    //     0xe96f5c: sub             SP, SP, #0x48
    // 0xe96f60: SetupParameters(dynamic _ /* r1 => r2 */, dynamic _ /* r2 => r0, fp-0x8 */)
    //     0xe96f60: mov             x0, x2
    //     0xe96f64: stur            x2, [fp, #-8]
    //     0xe96f68: mov             x2, x1
    // 0xe96f6c: CheckStackOverflow
    //     0xe96f6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe96f70: cmp             SP, x16
    //     0xe96f74: b.ls            #0xe971dc
    // 0xe96f78: r1 = Instance_Utf8Encoder
    //     0xe96f78: ldr             x1, [PP, #0x11f8]  ; [pp+0x11f8] Obj!Utf8Encoder@12b7f11
    // 0xe96f7c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xe96f7c: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xe96f80: r0 = convert()
    //     0xe96f80: bl              #0x122268c  ; [dart:convert] Utf8Encoder::convert
    // 0xe96f84: stur            x0, [fp, #-0x28]
    // 0xe96f88: LoadField: r2 = r0->field_13
    //     0xe96f88: ldur            w2, [x0, #0x13]
    // 0xe96f8c: stur            x2, [fp, #-0x20]
    // 0xe96f90: r1 = LoadInt32Instr(r2)
    //     0xe96f90: sbfx            x1, x2, #1, #0x1f
    // 0xe96f94: stur            x1, [fp, #-0x18]
    // 0xe96f98: add             x3, x1, #1
    // 0xe96f9c: stur            x3, [fp, #-0x10]
    // 0xe96fa0: r16 = <Uint8>
    //     0xe96fa0: add             x16, PP, #0xd, lsl #12  ; [pp+0xd2d0] TypeArguments: <Uint8>
    //     0xe96fa4: ldr             x16, [x16, #0x2d0]
    // 0xe96fa8: ldur            lr, [fp, #-8]
    // 0xe96fac: stp             lr, x16, [SP, #8]
    // 0xe96fb0: str             x3, [SP]
    // 0xe96fb4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xe96fb4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xe96fb8: r0 = allocate()
    //     0xe96fb8: bl              #0xe971e4  ; [package:ffi/src/arena.dart] Arena::allocate
    // 0xe96fbc: stur            x0, [fp, #-8]
    // 0xe96fc0: r16 = <Pointer<Uint8>>
    //     0xe96fc0: add             x16, PP, #0xd, lsl #12  ; [pp+0xd2d8] TypeArguments: <Pointer<Uint8>>
    //     0xe96fc4: ldr             x16, [x16, #0x2d8]
    // 0xe96fc8: stp             x0, x16, [SP, #8]
    // 0xe96fcc: r16 = "Pointer<Uint8>"
    //     0xe96fcc: add             x16, PP, #0xd, lsl #12  ; [pp+0xd2e0] "Pointer<Uint8>"
    //     0xe96fd0: ldr             x16, [x16, #0x2e0]
    // 0xe96fd4: str             x16, [SP]
    // 0xe96fd8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xe96fd8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xe96fdc: r0 = checkNotNull()
    //     0xe96fdc: bl              #0x8288b0  ; [dart:core] ArgumentError::checkNotNull
    // 0xe96fe0: ldur            x3, [fp, #-0x10]
    // 0xe96fe4: r0 = BoxInt64Instr(r3)
    //     0xe96fe4: sbfiz           x0, x3, #1, #0x1f
    //     0xe96fe8: cmp             x3, x0, asr #1
    //     0xe96fec: b.eq            #0xe96ff8
    //     0xe96ff0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xe96ff4: stur            x3, [x0, #7]
    // 0xe96ff8: r16 = <int>
    //     0xe96ff8: ldr             x16, [PP, #0x50]  ; [pp+0x50] TypeArguments: <int>
    // 0xe96ffc: stp             x0, x16, [SP, #8]
    // 0xe97000: r16 = "length"
    //     0xe97000: add             x16, PP, #0xd, lsl #12  ; [pp+0xd2e8] "length"
    //     0xe97004: ldr             x16, [x16, #0x2e8]
    // 0xe97008: str             x16, [SP]
    // 0xe9700c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xe9700c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xe97010: r0 = checkNotNull()
    //     0xe97010: bl              #0x8288b0  ; [dart:core] ArgumentError::checkNotNull
    // 0xe97014: ldur            x3, [fp, #-0x10]
    // 0xe97018: tbnz            x3, #0x3f, #0xe971b4
    // 0xe9701c: r17 = 1073741823
    //     0xe9701c: mov             x17, #0x3fffffff
    // 0xe97020: cmp             x3, x17
    // 0xe97024: b.gt            #0xe971b4
    // 0xe97028: ldur            x0, [fp, #-8]
    // 0xe9702c: ldur            x4, [fp, #-0x18]
    // 0xe97030: LoadField: r5 = r0->field_7
    //     0xe97030: ldur            x5, [x0, #7]
    // 0xe97034: stur            x5, [fp, #-0x30]
    // 0xe97038: tbz             x4, #0x3f, #0xe9704c
    // 0xe9703c: ldur            x2, [fp, #-0x20]
    // 0xe97040: r1 = 0
    //     0xe97040: mov             x1, #0
    // 0xe97044: r4 = const [0, 0x3, 0, 0x3, null]
    //     0xe97044: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0xe97048: r0 = checkValidRange()
    //     0xe97048: bl              #0x7db068  ; [dart:core] RangeError::checkValidRange
    // 0xe9704c: ldur            x20, [fp, #-0x18]
    // 0xe97050: cbnz            x20, #0xe9705c
    // 0xe97054: ldur            x23, [fp, #-0x30]
    // 0xe97058: b               #0xe9718c
    // 0xe9705c: ldur            x0, [fp, #-0x20]
    // 0xe97060: cmp             w0, #0x800
    // 0xe97064: b.ge            #0xe97138
    // 0xe97068: ldur            x1, [fp, #-0x28]
    // 0xe9706c: ldur            x23, [fp, #-0x30]
    // 0xe97070: mov             x3, x0
    // 0xe97074: add             x2, x1, #0x17
    // 0xe97078: mov             x0, x23
    // 0xe9707c: cbz             x3, #0xe97134
    // 0xe97080: cmp             x0, x2
    // 0xe97084: b.ls            #0xe970ec
    // 0xe97088: sxtw            x3, w3
    // 0xe9708c: add             x16, x2, x3, asr #1
    // 0xe97090: cmp             x0, x16
    // 0xe97094: b.hs            #0xe970ec
    // 0xe97098: mov             x2, x16
    // 0xe9709c: add             x0, x0, x3, asr #1
    // 0xe970a0: tbz             w3, #4, #0xe970ac
    // 0xe970a4: ldr             x16, [x2, #-8]!
    // 0xe970a8: str             x16, [x0, #-8]!
    // 0xe970ac: tbz             w3, #3, #0xe970b8
    // 0xe970b0: ldr             w16, [x2, #-4]!
    // 0xe970b4: str             w16, [x0, #-4]!
    // 0xe970b8: tbz             w3, #2, #0xe970c4
    // 0xe970bc: ldrh            w16, [x2, #-2]!
    // 0xe970c0: strh            w16, [x0, #-2]!
    // 0xe970c4: tbz             w3, #1, #0xe970d0
    // 0xe970c8: ldrb            w16, [x2, #-1]!
    // 0xe970cc: strb            w16, [x0, #-1]!
    // 0xe970d0: ands            w3, w3, #0xffffffe1
    // 0xe970d4: b.eq            #0xe97134
    // 0xe970d8: ldp             x16, x17, [x2, #-0x10]!
    // 0xe970dc: stp             x16, x17, [x0, #-0x10]!
    // 0xe970e0: subs            w3, w3, #0x20
    // 0xe970e4: b.ne            #0xe970d8
    // 0xe970e8: b               #0xe97134
    // 0xe970ec: tbz             w3, #4, #0xe970f8
    // 0xe970f0: ldr             x16, [x2], #8
    // 0xe970f4: str             x16, [x0], #8
    // 0xe970f8: tbz             w3, #3, #0xe97104
    // 0xe970fc: ldr             w16, [x2], #4
    // 0xe97100: str             w16, [x0], #4
    // 0xe97104: tbz             w3, #2, #0xe97110
    // 0xe97108: ldrh            w16, [x2], #2
    // 0xe9710c: strh            w16, [x0], #2
    // 0xe97110: tbz             w3, #1, #0xe9711c
    // 0xe97114: ldrb            w16, [x2], #1
    // 0xe97118: strb            w16, [x0], #1
    // 0xe9711c: ands            w3, w3, #0xffffffe1
    // 0xe97120: b.eq            #0xe97134
    // 0xe97124: ldp             x16, x17, [x2], #0x10
    // 0xe97128: stp             x16, x17, [x0], #0x10
    // 0xe9712c: subs            w3, w3, #0x20
    // 0xe97130: b.ne            #0xe97124
    // 0xe97134: b               #0xe9718c
    // 0xe97138: ldur            x1, [fp, #-0x28]
    // 0xe9713c: ldur            x23, [fp, #-0x30]
    // 0xe97140: LoadField: r0 = r1->field_7
    //     0xe97140: ldur            x0, [x1, #7]
    // 0xe97144: CallRuntime_MemoryMove(void*, const void*, size_t) -> void*
    //     0xe97144: mov             x1, THR
    //     0xe97148: ldr             x9, [x1, #0x888]
    //     0xe9714c: mov             x1, x0
    //     0xe97150: mov             x0, x23
    //     0xe97154: mov             x2, x20
    //     0xe97158: mov             x17, fp
    //     0xe9715c: str             fp, [SP, #-8]!
    //     0xe97160: mov             fp, SP
    //     0xe97164: and             SP, SP, #0xfffffffffffffff0
    //     0xe97168: mov             x19, sp
    //     0xe9716c: mov             sp, SP
    //     0xe97170: str             x9, [THR, #0x6c8]  ; THR::vm_tag
    //     0xe97174: blr             x9
    //     0xe97178: mov             x16, #8
    //     0xe9717c: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xe97180: mov             sp, x19
    //     0xe97184: mov             SP, fp
    //     0xe97188: ldr             fp, [SP], #8
    // 0xe9718c: strb            wzr, [x23, x20]
    // 0xe97190: r16 = <Utf8>
    //     0xe97190: add             x16, PP, #0xd, lsl #12  ; [pp+0xd2c8] TypeArguments: <Utf8>
    //     0xe97194: ldr             x16, [x16, #0x2c8]
    // 0xe97198: ldur            lr, [fp, #-8]
    // 0xe9719c: stp             lr, x16, [SP]
    // 0xe971a0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xe971a0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xe971a4: r0 = cast()
    //     0xe971a4: bl              #0x81b9c4  ; [dart:ffi] Pointer::cast
    // 0xe971a8: LeaveFrame
    //     0xe971a8: mov             SP, fp
    //     0xe971ac: ldp             fp, lr, [SP], #0x10
    // 0xe971b0: ret
    //     0xe971b0: ret             
    // 0xe971b4: r0 = ArgumentError()
    //     0xe971b4: bl              #0x7dcb60  ; AllocateArgumentErrorStub -> ArgumentError (size=0x1c)
    // 0xe971b8: mov             x1, x0
    // 0xe971bc: r0 = "length must be in the range [0, 1073741823]."
    //     0xe971bc: add             x0, PP, #0xd, lsl #12  ; [pp+0xd2f0] "length must be in the range [0, 1073741823]."
    //     0xe971c0: ldr             x0, [x0, #0x2f0]
    // 0xe971c4: ArrayStore: r1[0] = r0  ; List_4
    //     0xe971c4: stur            w0, [x1, #0x17]
    // 0xe971c8: r0 = false
    //     0xe971c8: add             x0, NULL, #0x30  ; false
    // 0xe971cc: StoreField: r1->field_b = r0
    //     0xe971cc: stur            w0, [x1, #0xb]
    // 0xe971d0: mov             x0, x1
    // 0xe971d4: r0 = Throw()
    //     0xe971d4: bl              #0x13ddb2c  ; ThrowStub
    // 0xe971d8: brk             #0
    // 0xe971dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe971dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe971e0: b               #0xe96f78
  }
}

// class id: 7222, size: 0x8, field offset: 0x8
abstract class Utf8 extends Opaque {
}
