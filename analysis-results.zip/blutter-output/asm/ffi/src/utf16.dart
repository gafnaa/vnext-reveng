// lib: , url: package:ffi/src/utf16.dart

// class id: 1048724, size: 0x8
class :: {

  static _ Utf16Pointer._ensureNotNullptr(/* No info */) {
    // ** addr: 0xe9098c, size: 0x90
    // 0xe9098c: EnterFrame
    //     0xe9098c: stp             fp, lr, [SP, #-0x10]!
    //     0xe90990: mov             fp, SP
    // 0xe90994: AllocStack(0x8)
    //     0xe90994: sub             SP, SP, #8
    // 0xe90998: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0xe90998: stur            x1, [fp, #-8]
    // 0xe9099c: CheckStackOverflow
    //     0xe9099c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe909a0: cmp             SP, x16
    //     0xe909a4: b.ls            #0xe90a14
    // 0xe909a8: ldr             x0, [THR, #0x80]  ; THR::
    // 0xe909ac: add             x17, x0, #8
    // 0xe909b0: ldar            x0, [x17]
    // 0xe909b4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xe909b8: cmp             w0, w16
    // 0xe909bc: b.ne            #0xe909cc
    // 0xe909c0: r2 = nullptr
    //     0xe909c0: add             x2, PP, #0xd, lsl #12  ; [pp+0xd2c0] Field <::.nullptr>: static late final shared (offset: 0x4)
    //     0xe909c4: ldr             x2, [x2, #0x2c0]
    // 0xe909c8: r0 = InitSharedLateStaticField()
    //     0xe909c8: bl              #0x13dd874  ; InitSharedLateStaticFieldStub
    // 0xe909cc: mov             x1, x0
    // 0xe909d0: ldur            x0, [fp, #-8]
    // 0xe909d4: LoadField: r2 = r0->field_7
    //     0xe909d4: ldur            x2, [x0, #7]
    // 0xe909d8: LoadField: r0 = r1->field_7
    //     0xe909d8: ldur            x0, [x1, #7]
    // 0xe909dc: cmp             x2, x0
    // 0xe909e0: b.eq            #0xe909f4
    // 0xe909e4: r0 = Null
    //     0xe909e4: mov             x0, NULL
    // 0xe909e8: LeaveFrame
    //     0xe909e8: mov             SP, fp
    //     0xe909ec: ldp             fp, lr, [SP], #0x10
    // 0xe909f0: ret
    //     0xe909f0: ret             
    // 0xe909f4: r0 = UnsupportedError()
    //     0xe909f4: bl              #0x7d923c  ; AllocateUnsupportedErrorStub -> UnsupportedError (size=0x10)
    // 0xe909f8: mov             x1, x0
    // 0xe909fc: r0 = "Operation \'toDartString\' not allowed on a \'nullptr\'."
    //     0xe909fc: add             x0, PP, #0xd, lsl #12  ; [pp+0xd2f8] "Operation \'toDartString\' not allowed on a \'nullptr\'."
    //     0xe90a00: ldr             x0, [x0, #0x2f8]
    // 0xe90a04: StoreField: r1->field_b = r0
    //     0xe90a04: stur            w0, [x1, #0xb]
    // 0xe90a08: mov             x0, x1
    // 0xe90a0c: r0 = Throw()
    //     0xe90a0c: bl              #0x13ddb2c  ; ThrowStub
    // 0xe90a10: brk             #0
    // 0xe90a14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe90a14: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe90a18: b               #0xe909a8
  }
  static _ Utf16Pointer.toDartString(/* No info */) {
    // ** addr: 0xe91df0, size: 0x7c
    // 0xe91df0: EnterFrame
    //     0xe91df0: stp             fp, lr, [SP, #-0x10]!
    //     0xe91df4: mov             fp, SP
    // 0xe91df8: AllocStack(0x20)
    //     0xe91df8: sub             SP, SP, #0x20
    // 0xe91dfc: SetupParameters(dynamic _ /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xe91dfc: mov             x0, x2
    //     0xe91e00: stur            x2, [fp, #-0x10]
    //     0xe91e04: mov             x2, x1
    //     0xe91e08: stur            x1, [fp, #-8]
    // 0xe91e0c: CheckStackOverflow
    //     0xe91e0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe91e10: cmp             SP, x16
    //     0xe91e14: b.ls            #0xe91e64
    // 0xe91e18: mov             x1, x2
    // 0xe91e1c: r0 = Utf16Pointer._ensureNotNullptr()
    //     0xe91e1c: bl              #0xe9098c  ; [package:ffi/src/utf16.dart] ::Utf16Pointer._ensureNotNullptr
    // 0xe91e20: r16 = <Uint16>
    //     0xe91e20: add             x16, PP, #0xd, lsl #12  ; [pp+0xd4c8] TypeArguments: <Uint16>
    //     0xe91e24: ldr             x16, [x16, #0x4c8]
    // 0xe91e28: ldur            lr, [fp, #-8]
    // 0xe91e2c: stp             lr, x16, [SP]
    // 0xe91e30: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xe91e30: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xe91e34: r0 = cast()
    //     0xe91e34: bl              #0x81b9c4  ; [dart:ffi] Pointer::cast
    // 0xe91e38: ldur            x1, [fp, #-0x10]
    // 0xe91e3c: r2 = "length"
    //     0xe91e3c: add             x2, PP, #0xd, lsl #12  ; [pp+0xd2e8] "length"
    //     0xe91e40: ldr             x2, [x2, #0x2e8]
    // 0xe91e44: stur            x0, [fp, #-8]
    // 0xe91e48: r0 = checkNotNegative()
    //     0xe91e48: bl              #0x7e60b0  ; [dart:core] RangeError::checkNotNegative
    // 0xe91e4c: ldur            x1, [fp, #-8]
    // 0xe91e50: ldur            x2, [fp, #-0x10]
    // 0xe91e54: r0 = Utf16Pointer._toKnownLengthString()
    //     0xe91e54: bl              #0xe91e6c  ; [package:ffi/src/utf16.dart] ::Utf16Pointer._toKnownLengthString
    // 0xe91e58: LeaveFrame
    //     0xe91e58: mov             SP, fp
    //     0xe91e5c: ldp             fp, lr, [SP], #0x10
    // 0xe91e60: ret
    //     0xe91e60: ret             
    // 0xe91e64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe91e64: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe91e68: b               #0xe91e18
  }
  static _ Utf16Pointer._toKnownLengthString(/* No info */) {
    // ** addr: 0xe91e6c, size: 0x130
    // 0xe91e6c: EnterFrame
    //     0xe91e6c: stp             fp, lr, [SP, #-0x10]!
    //     0xe91e70: mov             fp, SP
    // 0xe91e74: AllocStack(0x30)
    //     0xe91e74: sub             SP, SP, #0x30
    // 0xe91e78: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xe91e78: stur            x1, [fp, #-8]
    //     0xe91e7c: stur            x2, [fp, #-0x10]
    // 0xe91e80: CheckStackOverflow
    //     0xe91e80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe91e84: cmp             SP, x16
    //     0xe91e88: b.ls            #0xe91f94
    // 0xe91e8c: r16 = <Pointer<Uint16>>
    //     0xe91e8c: add             x16, PP, #0xd, lsl #12  ; [pp+0xd4d0] TypeArguments: <Pointer<Uint16>>
    //     0xe91e90: ldr             x16, [x16, #0x4d0]
    // 0xe91e94: stp             x1, x16, [SP, #8]
    // 0xe91e98: r16 = "Pointer<Uint16>"
    //     0xe91e98: add             x16, PP, #0xd, lsl #12  ; [pp+0xd4d8] "Pointer<Uint16>"
    //     0xe91e9c: ldr             x16, [x16, #0x4d8]
    // 0xe91ea0: str             x16, [SP]
    // 0xe91ea4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xe91ea4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xe91ea8: r0 = checkNotNull()
    //     0xe91ea8: bl              #0x8288b0  ; [dart:core] ArgumentError::checkNotNull
    // 0xe91eac: ldur            x2, [fp, #-0x10]
    // 0xe91eb0: r0 = BoxInt64Instr(r2)
    //     0xe91eb0: sbfiz           x0, x2, #1, #0x1f
    //     0xe91eb4: cmp             x2, x0, asr #1
    //     0xe91eb8: b.eq            #0xe91ec4
    //     0xe91ebc: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xe91ec0: stur            x2, [x0, #7]
    // 0xe91ec4: stur            x0, [fp, #-0x18]
    // 0xe91ec8: r16 = <int>
    //     0xe91ec8: ldr             x16, [PP, #0x50]  ; [pp+0x50] TypeArguments: <int>
    // 0xe91ecc: stp             x0, x16, [SP, #8]
    // 0xe91ed0: r16 = "length"
    //     0xe91ed0: add             x16, PP, #0xd, lsl #12  ; [pp+0xd2e8] "length"
    //     0xe91ed4: ldr             x16, [x16, #0x2e8]
    // 0xe91ed8: str             x16, [SP]
    // 0xe91edc: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xe91edc: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xe91ee0: r0 = checkNotNull()
    //     0xe91ee0: bl              #0x8288b0  ; [dart:core] ArgumentError::checkNotNull
    // 0xe91ee4: ldur            x0, [fp, #-0x10]
    // 0xe91ee8: tbnz            x0, #0x3f, #0xe91f40
    // 0xe91eec: r17 = 536870911
    //     0xe91eec: mov             x17, #0x1fffffff
    // 0xe91ef0: cmp             x0, x17
    // 0xe91ef4: b.gt            #0xe91f40
    // 0xe91ef8: ldur            x0, [fp, #-8]
    // 0xe91efc: LoadField: r1 = r0->field_7
    //     0xe91efc: ldur            x1, [x0, #7]
    // 0xe91f00: stur            x1, [fp, #-0x10]
    // 0xe91f04: mov             x0, x1
    // 0xe91f08: tbnz            w0, #0, #0xe91f68
    // 0xe91f0c: ldur            x0, [fp, #-0x18]
    // 0xe91f10: r0 = _ExternalUint16Array()
    //     0xe91f10: bl              #0xe91f9c  ; Allocate_ExternalUint16ArrayStub -> _ExternalUint16Array (size=-0x8)
    // 0xe91f14: mov             x1, x0
    // 0xe91f18: ldur            x0, [fp, #-0x18]
    // 0xe91f1c: StoreField: r1->field_13 = r0
    //     0xe91f1c: stur            w0, [x1, #0x13]
    // 0xe91f20: ldur            x0, [fp, #-0x10]
    // 0xe91f24: StoreField: r1->field_7 = r0
    //     0xe91f24: stur            x0, [x1, #7]
    // 0xe91f28: r2 = 0
    //     0xe91f28: mov             x2, #0
    // 0xe91f2c: r3 = Null
    //     0xe91f2c: mov             x3, NULL
    // 0xe91f30: r0 = createFromCharCodes()
    //     0xe91f30: bl              #0x7e5490  ; [dart:core] _StringBase::createFromCharCodes
    // 0xe91f34: LeaveFrame
    //     0xe91f34: mov             SP, fp
    //     0xe91f38: ldp             fp, lr, [SP], #0x10
    // 0xe91f3c: ret
    //     0xe91f3c: ret             
    // 0xe91f40: r0 = ArgumentError()
    //     0xe91f40: bl              #0x7dcb60  ; AllocateArgumentErrorStub -> ArgumentError (size=0x1c)
    // 0xe91f44: mov             x1, x0
    // 0xe91f48: r0 = "length must be in the range [0, 536870911]."
    //     0xe91f48: add             x0, PP, #0xd, lsl #12  ; [pp+0xd4e0] "length must be in the range [0, 536870911]."
    //     0xe91f4c: ldr             x0, [x0, #0x4e0]
    // 0xe91f50: ArrayStore: r1[0] = r0  ; List_4
    //     0xe91f50: stur            w0, [x1, #0x17]
    // 0xe91f54: r0 = false
    //     0xe91f54: add             x0, NULL, #0x30  ; false
    // 0xe91f58: StoreField: r1->field_b = r0
    //     0xe91f58: stur            w0, [x1, #0xb]
    // 0xe91f5c: mov             x0, x1
    // 0xe91f60: r0 = Throw()
    //     0xe91f60: bl              #0x13ddb2c  ; ThrowStub
    // 0xe91f64: brk             #0
    // 0xe91f68: r0 = false
    //     0xe91f68: add             x0, NULL, #0x30  ; false
    // 0xe91f6c: r0 = ArgumentError()
    //     0xe91f6c: bl              #0x7dcb60  ; AllocateArgumentErrorStub -> ArgumentError (size=0x1c)
    // 0xe91f70: mov             x1, x0
    // 0xe91f74: r0 = "Pointer address must be aligned to a multiple of the element size (2)."
    //     0xe91f74: add             x0, PP, #0xd, lsl #12  ; [pp+0xd4e8] "Pointer address must be aligned to a multiple of the element size (2)."
    //     0xe91f78: ldr             x0, [x0, #0x4e8]
    // 0xe91f7c: ArrayStore: r1[0] = r0  ; List_4
    //     0xe91f7c: stur            w0, [x1, #0x17]
    // 0xe91f80: r0 = false
    //     0xe91f80: add             x0, NULL, #0x30  ; false
    // 0xe91f84: StoreField: r1->field_b = r0
    //     0xe91f84: stur            w0, [x1, #0xb]
    // 0xe91f88: mov             x0, x1
    // 0xe91f8c: r0 = Throw()
    //     0xe91f8c: bl              #0x13ddb2c  ; ThrowStub
    // 0xe91f90: brk             #0
    // 0xe91f94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe91f94: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe91f98: b               #0xe91e8c
  }
  static _ StringUtf16Pointer.toNativeUtf16(/* No info */) {
    // ** addr: 0x12e0ad0, size: 0x13c
    // 0x12e0ad0: EnterFrame
    //     0x12e0ad0: stp             fp, lr, [SP, #-0x10]!
    //     0x12e0ad4: mov             fp, SP
    // 0x12e0ad8: AllocStack(0x30)
    //     0x12e0ad8: sub             SP, SP, #0x30
    // 0x12e0adc: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */)
    //     0x12e0adc: mov             x0, x1
    //     0x12e0ae0: stur            x1, [fp, #-8]
    // 0x12e0ae4: CheckStackOverflow
    //     0x12e0ae4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e0ae8: cmp             SP, x16
    //     0x12e0aec: b.ls            #0x12e0c04
    // 0x12e0af0: r1 = <int>
    //     0x12e0af0: ldr             x1, [PP, #0x50]  ; [pp+0x50] TypeArguments: <int>
    // 0x12e0af4: r0 = CodeUnits()
    //     0x12e0af4: bl              #0x818988  ; AllocateCodeUnitsStub -> CodeUnits (size=0x10)
    // 0x12e0af8: mov             x1, x0
    // 0x12e0afc: r0 = "flutter"
    //     0x12e0afc: add             x0, PP, #0xd, lsl #12  ; [pp+0xd758] "flutter"
    //     0x12e0b00: ldr             x0, [x0, #0x758]
    // 0x12e0b04: stur            x1, [fp, #-0x10]
    // 0x12e0b08: StoreField: r1->field_b = r0
    //     0x12e0b08: stur            w0, [x1, #0xb]
    // 0x12e0b0c: r16 = <Uint16>
    //     0x12e0b0c: add             x16, PP, #0xd, lsl #12  ; [pp+0xd4c8] TypeArguments: <Uint16>
    //     0x12e0b10: ldr             x16, [x16, #0x4c8]
    // 0x12e0b14: ldur            lr, [fp, #-8]
    // 0x12e0b18: stp             lr, x16, [SP, #8]
    // 0x12e0b1c: r0 = 16
    //     0x12e0b1c: mov             x0, #0x10
    // 0x12e0b20: str             x0, [SP]
    // 0x12e0b24: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x12e0b24: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x12e0b28: r0 = allocate()
    //     0x12e0b28: bl              #0xe971e4  ; [package:ffi/src/arena.dart] Arena::allocate
    // 0x12e0b2c: stur            x0, [fp, #-8]
    // 0x12e0b30: r16 = <Pointer<Uint16>>
    //     0x12e0b30: add             x16, PP, #0xd, lsl #12  ; [pp+0xd4d0] TypeArguments: <Pointer<Uint16>>
    //     0x12e0b34: ldr             x16, [x16, #0x4d0]
    // 0x12e0b38: stp             x0, x16, [SP, #8]
    // 0x12e0b3c: r16 = "Pointer<Uint16>"
    //     0x12e0b3c: add             x16, PP, #0xd, lsl #12  ; [pp+0xd4d8] "Pointer<Uint16>"
    //     0x12e0b40: ldr             x16, [x16, #0x4d8]
    // 0x12e0b44: str             x16, [SP]
    // 0x12e0b48: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x12e0b48: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x12e0b4c: r0 = checkNotNull()
    //     0x12e0b4c: bl              #0x8288b0  ; [dart:core] ArgumentError::checkNotNull
    // 0x12e0b50: r16 = <int>
    //     0x12e0b50: ldr             x16, [PP, #0x50]  ; [pp+0x50] TypeArguments: <int>
    // 0x12e0b54: r30 = 16
    //     0x12e0b54: mov             lr, #0x10
    // 0x12e0b58: stp             lr, x16, [SP, #8]
    // 0x12e0b5c: r16 = "length"
    //     0x12e0b5c: add             x16, PP, #0xd, lsl #12  ; [pp+0xd2e8] "length"
    //     0x12e0b60: ldr             x16, [x16, #0x2e8]
    // 0x12e0b64: str             x16, [SP]
    // 0x12e0b68: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x12e0b68: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x12e0b6c: r0 = checkNotNull()
    //     0x12e0b6c: bl              #0x8288b0  ; [dart:core] ArgumentError::checkNotNull
    // 0x12e0b70: ldur            x0, [fp, #-8]
    // 0x12e0b74: LoadField: r1 = r0->field_7
    //     0x12e0b74: ldur            x1, [x0, #7]
    // 0x12e0b78: stur            x1, [fp, #-0x18]
    // 0x12e0b7c: mov             x2, x1
    // 0x12e0b80: tbnz            w2, #0, #0x12e0bdc
    // 0x12e0b84: r0 = _ExternalUint16Array()
    //     0x12e0b84: bl              #0xe91f9c  ; Allocate_ExternalUint16ArrayStub -> _ExternalUint16Array (size=-0x8)
    // 0x12e0b88: mov             x1, x0
    // 0x12e0b8c: r0 = 16
    //     0x12e0b8c: mov             x0, #0x10
    // 0x12e0b90: StoreField: r1->field_13 = r0
    //     0x12e0b90: stur            w0, [x1, #0x13]
    // 0x12e0b94: ldur            x0, [fp, #-0x18]
    // 0x12e0b98: StoreField: r1->field_7 = r0
    //     0x12e0b98: stur            x0, [x1, #7]
    // 0x12e0b9c: ldur            x5, [fp, #-0x10]
    // 0x12e0ba0: r2 = 0
    //     0x12e0ba0: mov             x2, #0
    // 0x12e0ba4: r3 = 7
    //     0x12e0ba4: mov             x3, #7
    // 0x12e0ba8: r6 = 0
    //     0x12e0ba8: mov             x6, #0
    // 0x12e0bac: r0 = _slowSetRange()
    //     0x12e0bac: bl              #0x117be9c  ; [dart:typed_data] __Uint16List&_TypedList&_IntListMixin&_TypedIntListMixin::_slowSetRange
    // 0x12e0bb0: ldur            x0, [fp, #-0x18]
    // 0x12e0bb4: strh            wzr, [x0, #0xe]
    // 0x12e0bb8: r16 = <Utf16>
    //     0x12e0bb8: add             x16, PP, #0xd, lsl #12  ; [pp+0xd4a8] TypeArguments: <Utf16>
    //     0x12e0bbc: ldr             x16, [x16, #0x4a8]
    // 0x12e0bc0: ldur            lr, [fp, #-8]
    // 0x12e0bc4: stp             lr, x16, [SP]
    // 0x12e0bc8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x12e0bc8: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x12e0bcc: r0 = cast()
    //     0x12e0bcc: bl              #0x81b9c4  ; [dart:ffi] Pointer::cast
    // 0x12e0bd0: LeaveFrame
    //     0x12e0bd0: mov             SP, fp
    //     0x12e0bd4: ldp             fp, lr, [SP], #0x10
    // 0x12e0bd8: ret
    //     0x12e0bd8: ret             
    // 0x12e0bdc: r0 = ArgumentError()
    //     0x12e0bdc: bl              #0x7dcb60  ; AllocateArgumentErrorStub -> ArgumentError (size=0x1c)
    // 0x12e0be0: mov             x1, x0
    // 0x12e0be4: r0 = "Pointer address must be aligned to a multiple of the element size (2)."
    //     0x12e0be4: add             x0, PP, #0xd, lsl #12  ; [pp+0xd4e8] "Pointer address must be aligned to a multiple of the element size (2)."
    //     0x12e0be8: ldr             x0, [x0, #0x4e8]
    // 0x12e0bec: ArrayStore: r1[0] = r0  ; List_4
    //     0x12e0bec: stur            w0, [x1, #0x17]
    // 0x12e0bf0: r0 = false
    //     0x12e0bf0: add             x0, NULL, #0x30  ; false
    // 0x12e0bf4: StoreField: r1->field_b = r0
    //     0x12e0bf4: stur            w0, [x1, #0xb]
    // 0x12e0bf8: mov             x0, x1
    // 0x12e0bfc: r0 = Throw()
    //     0x12e0bfc: bl              #0x13ddb2c  ; ThrowStub
    // 0x12e0c00: brk             #0
    // 0x12e0c04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e0c04: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e0c08: b               #0x12e0af0
  }
}

// class id: 7223, size: 0x8, field offset: 0x8
abstract class Utf16 extends Opaque {
}
