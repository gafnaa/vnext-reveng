// lib: , url: package:ffi/src/arena.dart

// class id: 1048723, size: 0x8
class :: {

  static _ using(/* No info */) {
    // ** addr: 0xe96748, size: 0x94
    // 0xe96748: EnterFrame
    //     0xe96748: stp             fp, lr, [SP, #-0x10]!
    //     0xe9674c: mov             fp, SP
    // 0xe96750: AllocStack(0x88)
    //     0xe96750: sub             SP, SP, #0x88
    // 0xe96754: CheckStackOverflow
    //     0xe96754: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe96758: cmp             SP, x16
    //     0xe9675c: b.ls            #0xe967d4
    // 0xe96760: r0 = Arena()
    //     0xe96760: bl              #0xe96adc  ; AllocateArenaStub -> Arena (size=0x18)
    // 0xe96764: mov             x1, x0
    // 0xe96768: stur            x0, [fp, #-0x68]
    // 0xe9676c: r0 = Arena()
    //     0xe9676c: bl              #0xe96a14  ; [package:ffi/src/arena.dart] Arena::Arena
    // 0xe96770: ldr             x16, [fp, #0x10]
    // 0xe96774: ldur            lr, [fp, #-0x68]
    // 0xe96778: stp             lr, x16, [SP]
    // 0xe9677c: ldr             x0, [fp, #0x10]
    // 0xe96780: ClosureCall
    //     0xe96780: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xe96784: ldur            x2, [x0, #0x1f]
    //     0xe96788: blr             x2
    // 0xe9678c: stur            x0, [fp, #-0x70]
    // 0xe96790: ldur            x1, [fp, #-0x68]
    // 0xe96794: r0 = releaseAll()
    //     0xe96794: bl              #0xe967dc  ; [package:ffi/src/arena.dart] Arena::releaseAll
    // 0xe96798: ldur            x0, [fp, #-0x70]
    // 0xe9679c: LeaveFrame
    //     0xe9679c: mov             SP, fp
    //     0xe967a0: ldp             fp, lr, [SP], #0x10
    // 0xe967a4: ret
    //     0xe967a4: ret             
    // 0xe967a8: sub             SP, fp, #0x88
    // 0xe967ac: mov             x2, x0
    // 0xe967b0: stur            x0, [fp, #-0x70]
    // 0xe967b4: mov             x0, x1
    // 0xe967b8: stur            x1, [fp, #-0x78]
    // 0xe967bc: ldur            x1, [fp, #-0x68]
    // 0xe967c0: r0 = releaseAll()
    //     0xe967c0: bl              #0xe967dc  ; [package:ffi/src/arena.dart] Arena::releaseAll
    // 0xe967c4: ldur            x0, [fp, #-0x70]
    // 0xe967c8: ldur            x1, [fp, #-0x78]
    // 0xe967cc: r0 = ReThrow()
    //     0xe967cc: bl              #0x13ddb00  ; ReThrowStub
    // 0xe967d0: brk             #0
    // 0xe967d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe967d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe967d8: b               #0xe96760
  }
}

// class id: 3389, size: 0x18, field offset: 0x8
class Arena extends Object
    implements Allocator {

  _ releaseAll(/* No info */) {
    // ** addr: 0xe967dc, size: 0x170
    // 0xe967dc: EnterFrame
    //     0xe967dc: stp             fp, lr, [SP, #-0x10]!
    //     0xe967e0: mov             fp, SP
    // 0xe967e4: AllocStack(0x30)
    //     0xe967e4: sub             SP, SP, #0x30
    // 0xe967e8: r0 = false
    //     0xe967e8: add             x0, NULL, #0x30  ; false
    // 0xe967ec: mov             x3, x1
    // 0xe967f0: stur            x1, [fp, #-0x18]
    // 0xe967f4: CheckStackOverflow
    //     0xe967f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe967f8: cmp             SP, x16
    //     0xe967fc: b.ls            #0xe96930
    // 0xe96800: StoreField: r3->field_13 = r0
    //     0xe96800: stur            w0, [x3, #0x13]
    // 0xe96804: LoadField: r4 = r3->field_f
    //     0xe96804: ldur            w4, [x3, #0xf]
    // 0xe96808: DecompressPointer r4
    //     0xe96808: add             x4, x4, HEAP, lsl #32
    // 0xe9680c: stur            x4, [fp, #-0x10]
    // 0xe96810: CheckStackOverflow
    //     0xe96810: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe96814: cmp             SP, x16
    //     0xe96818: b.ls            #0xe96938
    // 0xe9681c: LoadField: r0 = r4->field_b
    //     0xe9681c: ldur            w0, [x4, #0xb]
    // 0xe96820: r1 = LoadInt32Instr(r0)
    //     0xe96820: sbfx            x1, x0, #1, #0x1f
    // 0xe96824: cbz             w0, #0xe96880
    // 0xe96828: sub             x2, x1, #1
    // 0xe9682c: mov             x0, x1
    // 0xe96830: mov             x1, x2
    // 0xe96834: cmp             x1, x0
    // 0xe96838: b.hs            #0xe96940
    // 0xe9683c: LoadField: r0 = r4->field_f
    //     0xe9683c: ldur            w0, [x4, #0xf]
    // 0xe96840: DecompressPointer r0
    //     0xe96840: add             x0, x0, HEAP, lsl #32
    // 0xe96844: ArrayLoad: r5 = r0[r2]  ; Unknown_4
    //     0xe96844: add             x16, x0, x2, lsl #2
    //     0xe96848: ldur            w5, [x16, #0xf]
    // 0xe9684c: DecompressPointer r5
    //     0xe9684c: add             x5, x5, HEAP, lsl #32
    // 0xe96850: mov             x1, x4
    // 0xe96854: stur            x5, [fp, #-8]
    // 0xe96858: r0 = length=()
    //     0xe96858: bl              #0x9fa1d0  ; [dart:core] _GrowableList::length=
    // 0xe9685c: ldur            x16, [fp, #-8]
    // 0xe96860: str             x16, [SP]
    // 0xe96864: ldur            x0, [fp, #-8]
    // 0xe96868: ClosureCall
    //     0xe96868: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xe9686c: ldur            x2, [x0, #0x1f]
    //     0xe96870: blr             x2
    // 0xe96874: ldur            x3, [fp, #-0x18]
    // 0xe96878: ldur            x4, [fp, #-0x10]
    // 0xe9687c: b               #0xe96810
    // 0xe96880: mov             x0, x3
    // 0xe96884: LoadField: r2 = r0->field_b
    //     0xe96884: ldur            w2, [x0, #0xb]
    // 0xe96888: DecompressPointer r2
    //     0xe96888: add             x2, x2, HEAP, lsl #32
    // 0xe9688c: stur            x2, [fp, #-8]
    // 0xe96890: LoadField: r0 = r2->field_b
    //     0xe96890: ldur            w0, [x2, #0xb]
    // 0xe96894: r3 = LoadInt32Instr(r0)
    //     0xe96894: sbfx            x3, x0, #1, #0x1f
    // 0xe96898: stur            x3, [fp, #-0x28]
    // 0xe9689c: r0 = 0
    //     0xe9689c: mov             x0, #0
    // 0xe968a0: CheckStackOverflow
    //     0xe968a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe968a4: cmp             SP, x16
    //     0xe968a8: b.ls            #0xe96944
    // 0xe968ac: LoadField: r1 = r2->field_b
    //     0xe968ac: ldur            w1, [x2, #0xb]
    // 0xe968b0: r4 = LoadInt32Instr(r1)
    //     0xe968b0: sbfx            x4, x1, #1, #0x1f
    // 0xe968b4: cmp             x3, x4
    // 0xe968b8: b.ne            #0xe96910
    // 0xe968bc: cmp             x0, x4
    // 0xe968c0: b.ge            #0xe968f8
    // 0xe968c4: LoadField: r1 = r2->field_f
    //     0xe968c4: ldur            w1, [x2, #0xf]
    // 0xe968c8: DecompressPointer r1
    //     0xe968c8: add             x1, x1, HEAP, lsl #32
    // 0xe968cc: ArrayLoad: r4 = r1[r0]  ; Unknown_4
    //     0xe968cc: add             x16, x1, x0, lsl #2
    //     0xe968d0: ldur            w4, [x16, #0xf]
    // 0xe968d4: DecompressPointer r4
    //     0xe968d4: add             x4, x4, HEAP, lsl #32
    // 0xe968d8: add             x5, x0, #1
    // 0xe968dc: mov             x1, x4
    // 0xe968e0: stur            x5, [fp, #-0x20]
    // 0xe968e4: r0 = posixFree()
    //     0xe968e4: bl              #0xe9694c  ; [package:ffi/src/allocation.dart] ::posixFree
    // 0xe968e8: ldur            x0, [fp, #-0x20]
    // 0xe968ec: ldur            x2, [fp, #-8]
    // 0xe968f0: ldur            x3, [fp, #-0x28]
    // 0xe968f4: b               #0xe968a0
    // 0xe968f8: ldur            x1, [fp, #-8]
    // 0xe968fc: r0 = clear()
    //     0xe968fc: bl              #0xa16074  ; [dart:core] _GrowableList::clear
    // 0xe96900: r0 = Null
    //     0xe96900: mov             x0, NULL
    // 0xe96904: LeaveFrame
    //     0xe96904: mov             SP, fp
    //     0xe96908: ldp             fp, lr, [SP], #0x10
    // 0xe9690c: ret
    //     0xe9690c: ret             
    // 0xe96910: mov             x0, x2
    // 0xe96914: r0 = ConcurrentModificationError()
    //     0xe96914: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xe96918: mov             x1, x0
    // 0xe9691c: ldur            x0, [fp, #-8]
    // 0xe96920: StoreField: r1->field_b = r0
    //     0xe96920: stur            w0, [x1, #0xb]
    // 0xe96924: mov             x0, x1
    // 0xe96928: r0 = Throw()
    //     0xe96928: bl              #0x13ddb2c  ; ThrowStub
    // 0xe9692c: brk             #0
    // 0xe96930: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe96930: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe96934: b               #0xe96800
    // 0xe96938: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe96938: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe9693c: b               #0xe9681c
    // 0xe96940: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xe96940: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xe96944: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe96944: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe96948: b               #0xe968ac
  }
  _ Arena(/* No info */) {
    // ** addr: 0xe96a14, size: 0xa8
    // 0xe96a14: EnterFrame
    //     0xe96a14: stp             fp, lr, [SP, #-0x10]!
    //     0xe96a18: mov             fp, SP
    // 0xe96a1c: AllocStack(0x8)
    //     0xe96a1c: sub             SP, SP, #8
    // 0xe96a20: r0 = true
    //     0xe96a20: add             x0, NULL, #0x20  ; true
    // 0xe96a24: mov             x3, x1
    // 0xe96a28: stur            x1, [fp, #-8]
    // 0xe96a2c: CheckStackOverflow
    //     0xe96a2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe96a30: cmp             SP, x16
    //     0xe96a34: b.ls            #0xe96ab4
    // 0xe96a38: StoreField: r3->field_13 = r0
    //     0xe96a38: stur            w0, [x3, #0x13]
    // 0xe96a3c: r1 = <Pointer<NativeType>>
    //     0xe96a3c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd5b8] TypeArguments: <Pointer<NativeType>>
    //     0xe96a40: ldr             x1, [x1, #0x5b8]
    // 0xe96a44: r2 = 0
    //     0xe96a44: mov             x2, #0
    // 0xe96a48: r0 = _GrowableList()
    //     0xe96a48: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xe96a4c: ldur            x3, [fp, #-8]
    // 0xe96a50: StoreField: r3->field_b = r0
    //     0xe96a50: stur            w0, [x3, #0xb]
    //     0xe96a54: ldurb           w16, [x3, #-1]
    //     0xe96a58: ldurb           w17, [x0, #-1]
    //     0xe96a5c: and             x16, x17, x16, lsr #2
    //     0xe96a60: tst             x16, HEAP, lsr #32
    //     0xe96a64: b.eq            #0xe96a6c
    //     0xe96a68: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xe96a6c: r1 = <(dynamic this) => void?>
    //     0xe96a6c: ldr             x1, [PP, #0x17d0]  ; [pp+0x17d0] TypeArguments: <(dynamic this) => void?>
    // 0xe96a70: r2 = 0
    //     0xe96a70: mov             x2, #0
    // 0xe96a74: r0 = _GrowableList()
    //     0xe96a74: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xe96a78: ldur            x1, [fp, #-8]
    // 0xe96a7c: StoreField: r1->field_f = r0
    //     0xe96a7c: stur            w0, [x1, #0xf]
    //     0xe96a80: ldurb           w16, [x1, #-1]
    //     0xe96a84: ldurb           w17, [x0, #-1]
    //     0xe96a88: and             x16, x17, x16, lsr #2
    //     0xe96a8c: tst             x16, HEAP, lsr #32
    //     0xe96a90: b.eq            #0xe96a98
    //     0xe96a94: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xe96a98: r2 = Instance_CallocAllocator
    //     0xe96a98: add             x2, PP, #0xd, lsl #12  ; [pp+0xd310] Obj!CallocAllocator@129ff91
    //     0xe96a9c: ldr             x2, [x2, #0x310]
    // 0xe96aa0: StoreField: r1->field_7 = r2
    //     0xe96aa0: stur            w2, [x1, #7]
    // 0xe96aa4: r0 = Null
    //     0xe96aa4: mov             x0, NULL
    // 0xe96aa8: LeaveFrame
    //     0xe96aa8: mov             SP, fp
    //     0xe96aac: ldp             fp, lr, [SP], #0x10
    // 0xe96ab0: ret
    //     0xe96ab0: ret             
    // 0xe96ab4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe96ab4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe96ab8: b               #0xe96a38
  }
  _ allocate(/* No info */) {
    // ** addr: 0xe971e4, size: 0x124
    // 0xe971e4: EnterFrame
    //     0xe971e4: stp             fp, lr, [SP, #-0x10]!
    //     0xe971e8: mov             fp, SP
    // 0xe971ec: AllocStack(0x30)
    //     0xe971ec: sub             SP, SP, #0x30
    // 0xe971f0: SetupParameters()
    //     0xe971f0: ldur            w0, [x4, #0xf]
    //     0xe971f4: cbnz            w0, #0xe97200
    //     0xe971f8: mov             x1, NULL
    //     0xe971fc: b               #0xe97210
    //     0xe97200: ldur            w1, [x4, #0x17]
    //     0xe97204: add             x2, fp, w1, sxtw #2
    //     0xe97208: ldr             x2, [x2, #0x10]
    //     0xe9720c: mov             x1, x2
    // 0xe97210: CheckStackOverflow
    //     0xe97210: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe97214: cmp             SP, x16
    //     0xe97218: b.ls            #0xe97300
    // 0xe9721c: cbnz            w0, #0xe9722c
    // 0xe97220: r3 = <NativeType>
    //     0xe97220: add             x3, PP, #0xd, lsl #12  ; [pp+0xd3a8] TypeArguments: <NativeType>
    //     0xe97224: ldr             x3, [x3, #0x3a8]
    // 0xe97228: b               #0xe97230
    // 0xe9722c: mov             x3, x1
    // 0xe97230: ldr             x2, [fp, #0x18]
    // 0xe97234: ldr             x0, [fp, #0x10]
    // 0xe97238: mov             x1, x2
    // 0xe9723c: stur            x3, [fp, #-8]
    // 0xe97240: r0 = _ensureInUse()
    //     0xe97240: bl              #0xe97308  ; [package:ffi/src/arena.dart] Arena::_ensureInUse
    // 0xe97244: ldur            x16, [fp, #-8]
    // 0xe97248: r30 = Instance_CallocAllocator
    //     0xe97248: add             lr, PP, #0xd, lsl #12  ; [pp+0xd310] Obj!CallocAllocator@129ff91
    //     0xe9724c: ldr             lr, [lr, #0x310]
    // 0xe97250: stp             lr, x16, [SP, #8]
    // 0xe97254: ldr             x0, [fp, #0x10]
    // 0xe97258: str             x0, [SP]
    // 0xe9725c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xe9725c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xe97260: r0 = allocate()
    //     0xe97260: bl              #0xe91938  ; [package:ffi/src/allocation.dart] CallocAllocator::allocate
    // 0xe97264: mov             x2, x0
    // 0xe97268: ldr             x0, [fp, #0x18]
    // 0xe9726c: stur            x2, [fp, #-0x18]
    // 0xe97270: LoadField: r3 = r0->field_b
    //     0xe97270: ldur            w3, [x0, #0xb]
    // 0xe97274: DecompressPointer r3
    //     0xe97274: add             x3, x3, HEAP, lsl #32
    // 0xe97278: stur            x3, [fp, #-8]
    // 0xe9727c: LoadField: r0 = r3->field_b
    //     0xe9727c: ldur            w0, [x3, #0xb]
    // 0xe97280: LoadField: r1 = r3->field_f
    //     0xe97280: ldur            w1, [x3, #0xf]
    // 0xe97284: DecompressPointer r1
    //     0xe97284: add             x1, x1, HEAP, lsl #32
    // 0xe97288: LoadField: r4 = r1->field_b
    //     0xe97288: ldur            w4, [x1, #0xb]
    // 0xe9728c: r5 = LoadInt32Instr(r0)
    //     0xe9728c: sbfx            x5, x0, #1, #0x1f
    // 0xe97290: stur            x5, [fp, #-0x10]
    // 0xe97294: r0 = LoadInt32Instr(r4)
    //     0xe97294: sbfx            x0, x4, #1, #0x1f
    // 0xe97298: cmp             x5, x0
    // 0xe9729c: b.ne            #0xe972a8
    // 0xe972a0: mov             x1, x3
    // 0xe972a4: r0 = _growToNextCapacity()
    //     0xe972a4: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xe972a8: ldur            x2, [fp, #-8]
    // 0xe972ac: ldur            x3, [fp, #-0x10]
    // 0xe972b0: add             x4, x3, #1
    // 0xe972b4: lsl             x5, x4, #1
    // 0xe972b8: StoreField: r2->field_b = r5
    //     0xe972b8: stur            w5, [x2, #0xb]
    // 0xe972bc: LoadField: r1 = r2->field_f
    //     0xe972bc: ldur            w1, [x2, #0xf]
    // 0xe972c0: DecompressPointer r1
    //     0xe972c0: add             x1, x1, HEAP, lsl #32
    // 0xe972c4: ldur            x0, [fp, #-0x18]
    // 0xe972c8: ArrayStore: r1[r3] = r0  ; List_4
    //     0xe972c8: add             x25, x1, x3, lsl #2
    //     0xe972cc: add             x25, x25, #0xf
    //     0xe972d0: str             w0, [x25]
    //     0xe972d4: tbz             w0, #0, #0xe972f0
    //     0xe972d8: ldurb           w16, [x1, #-1]
    //     0xe972dc: ldurb           w17, [x0, #-1]
    //     0xe972e0: and             x16, x17, x16, lsr #2
    //     0xe972e4: tst             x16, HEAP, lsr #32
    //     0xe972e8: b.eq            #0xe972f0
    //     0xe972ec: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xe972f0: ldur            x0, [fp, #-0x18]
    // 0xe972f4: LeaveFrame
    //     0xe972f4: mov             SP, fp
    //     0xe972f8: ldp             fp, lr, [SP], #0x10
    // 0xe972fc: ret
    //     0xe972fc: ret             
    // 0xe97300: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe97300: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe97304: b               #0xe9721c
  }
  _ _ensureInUse(/* No info */) {
    // ** addr: 0xe97308, size: 0x44
    // 0xe97308: EnterFrame
    //     0xe97308: stp             fp, lr, [SP, #-0x10]!
    //     0xe9730c: mov             fp, SP
    // 0xe97310: LoadField: r0 = r1->field_13
    //     0xe97310: ldur            w0, [x1, #0x13]
    // 0xe97314: DecompressPointer r0
    //     0xe97314: add             x0, x0, HEAP, lsl #32
    // 0xe97318: tbnz            w0, #4, #0xe9732c
    // 0xe9731c: r0 = Null
    //     0xe9731c: mov             x0, NULL
    // 0xe97320: LeaveFrame
    //     0xe97320: mov             SP, fp
    //     0xe97324: ldp             fp, lr, [SP], #0x10
    // 0xe97328: ret
    //     0xe97328: ret             
    // 0xe9732c: r0 = StateError()
    //     0xe9732c: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xe97330: mov             x1, x0
    // 0xe97334: r0 = "Arena no longer in use, `releaseAll(reuse: false)` was called."
    //     0xe97334: add             x0, PP, #0xd, lsl #12  ; [pp+0xd5a0] "Arena no longer in use, `releaseAll(reuse: false)` was called."
    //     0xe97338: ldr             x0, [x0, #0x5a0]
    // 0xe9733c: StoreField: r1->field_b = r0
    //     0xe9733c: stur            w0, [x1, #0xb]
    // 0xe97340: mov             x0, x1
    // 0xe97344: r0 = Throw()
    //     0xe97344: bl              #0x13ddb2c  ; ThrowStub
    // 0xe97348: brk             #0
  }
}
