// lib: , url: package:ffi/src/allocation.dart

// class id: 1048722, size: 0x8
class :: {

  static _ posixCalloc(/* No info */) {
    // ** addr: 0xe91a38, size: 0xd4
    // 0xe91a38: EnterFrame
    //     0xe91a38: stp             fp, lr, [SP, #-0x10]!
    //     0xe91a3c: mov             fp, SP
    // 0xe91a40: AllocStack(0x20)
    //     0xe91a40: sub             SP, SP, #0x20
    // 0xe91a44: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */)
    //     0xe91a44: mov             x0, x1
    //     0xe91a48: stur            x1, [fp, #-8]
    // 0xe91a4c: r16 = "package:ffi/src/allocation.dart"
    //     0xe91a4c: add             x16, PP, #0xd, lsl #12  ; [pp+0xd470] "package:ffi/src/allocation.dart"
    //     0xe91a50: ldr             x16, [x16, #0x470]
    // 0xe91a54: r30 = "calloc"
    //     0xe91a54: add             lr, PP, #0xd, lsl #12  ; [pp+0xd478] "calloc"
    //     0xe91a58: ldr             lr, [lr, #0x478]
    // 0xe91a5c: stp             lr, x16, [SP, #8]
    // 0xe91a60: r16 = 4
    //     0xe91a60: mov             x16, #4
    // 0xe91a64: str             x16, [SP]
    // 0xe91a68: r0 = 0
    //     0xe91a68: add             x0, PP, #0xd, lsl #12  ; [pp+0xd480] IMM: 0x0
    //     0xe91a6c: ldr             x0, [x0, #0x480]
    // 0xe91a70: cmp             x0, #0
    // 0xe91a74: b.ne            #0xe91a94
    // 0xe91a78: r0 = _ffi_resolver_function()
    //     0xe91a78: bl              #0x81b7c0  ; [dart:ffi] Native::_ffi_resolver_function
    // 0xe91a7c: mov             x16, x0
    // 0xe91a80: r0 = LoadInt32Instr(r16)
    //     0xe91a80: sbfx            x0, x16, #1, #0x1f
    //     0xe91a84: tbz             w16, #0, #0xe91a8c
    //     0xe91a88: ldur            x0, [x16, #7]
    // 0xe91a8c: [PP+0xd480] = r0
    //     0xe91a8c: add             x16, PP, #0xd, lsl #12  ; [pp+0xd480] IMM: 0x0
    //     0xe91a90: str             x0, [x16, #0x480]
    // 0xe91a94: mov             x9, x0
    // 0xe91a98: ldur            x0, [fp, #-8]
    // 0xe91a9c: r1 = 1
    //     0xe91a9c: mov             x1, #1
    // 0xe91aa0: mov             x19, fp
    // 0xe91aa4: r24 = Null
    //     0xe91aa4: mov             x24, NULL
    // 0xe91aa8: EnterFrame
    //     0xe91aa8: stp             fp, lr, [SP, #-0x10]!
    //     0xe91aac: mov             fp, SP
    // 0xe91ab0: and             SP, SP, #0xfffffffffffffff0
    // 0xe91ab4: adr             x10, #0xe91ab8
    // 0xe91ab8: str             x10, [fp, #8]
    // 0xe91abc: ldr             x10, [THR, #0x270]  ; THR::call_native_through_safepoint_entry_point
    // 0xe91ac0: blr             x10
    // 0xe91ac4: ldr             HEAP, [THR, #0x50]  ; THR::write_barrier_mask
    // 0xe91ac8: lsl             HEAP, HEAP, #0x20
    // 0xe91acc: ldr             NULL, [THR, #0x88]  ; THR::object_null
    // 0xe91ad0: ldr             x16, [THR, #0x58]  ; THR::heap_base
    // 0xe91ad4: orr             HEAP, HEAP, x16, lsr #32
    // 0xe91ad8: LeaveFrame
    //     0xe91ad8: mov             SP, fp
    //     0xe91adc: ldp             fp, lr, [SP], #0x10
    // 0xe91ae0: ldr             PP, [THR, #0x6e0]  ; THR::global_object_pool
    // 0xe91ae4: sub             PP, PP, #1
    // 0xe91ae8: ldr             x21, [THR, #0x70]  ; THR::dispatch_table_array
    // 0xe91aec: r1 = <Never>
    //     0xe91aec: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xe91af0: stur            x0, [fp, #-8]
    // 0xe91af4: r0 = Pointer()
    //     0xe91af4: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xe91af8: ldur            x1, [fp, #-8]
    // 0xe91afc: StoreField: r0->field_7 = r1
    //     0xe91afc: stur            x1, [x0, #7]
    // 0xe91b00: LeaveFrame
    //     0xe91b00: mov             SP, fp
    //     0xe91b04: ldp             fp, lr, [SP], #0x10
    // 0xe91b08: ret
    //     0xe91b08: ret             
  }
  static _ posixFree(/* No info */) {
    // ** addr: 0xe9694c, size: 0xc8
    // 0xe9694c: EnterFrame
    //     0xe9694c: stp             fp, lr, [SP, #-0x10]!
    //     0xe96950: mov             fp, SP
    // 0xe96954: AllocStack(0x20)
    //     0xe96954: sub             SP, SP, #0x20
    // 0xe96958: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0xe96958: stur            x1, [fp, #-8]
    // 0xe9695c: r16 = "package:ffi/src/allocation.dart"
    //     0xe9695c: add             x16, PP, #0xd, lsl #12  ; [pp+0xd470] "package:ffi/src/allocation.dart"
    //     0xe96960: ldr             x16, [x16, #0x470]
    // 0xe96964: r30 = "free"
    //     0xe96964: add             lr, PP, #0xd, lsl #12  ; [pp+0xd5a8] "free"
    //     0xe96968: ldr             lr, [lr, #0x5a8]
    // 0xe9696c: stp             lr, x16, [SP, #8]
    // 0xe96970: r16 = 2
    //     0xe96970: mov             x16, #2
    // 0xe96974: str             x16, [SP]
    // 0xe96978: r0 = 0
    //     0xe96978: add             x0, PP, #0xd, lsl #12  ; [pp+0xd5b0] IMM: 0x0
    //     0xe9697c: ldr             x0, [x0, #0x5b0]
    // 0xe96980: cmp             x0, #0
    // 0xe96984: b.ne            #0xe969a4
    // 0xe96988: r0 = _ffi_resolver_function()
    //     0xe96988: bl              #0x81b7c0  ; [dart:ffi] Native::_ffi_resolver_function
    // 0xe9698c: mov             x16, x0
    // 0xe96990: r0 = LoadInt32Instr(r16)
    //     0xe96990: sbfx            x0, x16, #1, #0x1f
    //     0xe96994: tbz             w16, #0, #0xe9699c
    //     0xe96998: ldur            x0, [x16, #7]
    // 0xe9699c: [PP+0xd5b0] = r0
    //     0xe9699c: add             x16, PP, #0xd, lsl #12  ; [pp+0xd5b0] IMM: 0x0
    //     0xe969a0: str             x0, [x16, #0x5b0]
    // 0xe969a4: mov             x1, x0
    // 0xe969a8: ldur            x0, [fp, #-8]
    // 0xe969ac: LoadField: r2 = r0->field_7
    //     0xe969ac: ldur            x2, [x0, #7]
    // 0xe969b0: mov             x0, x2
    // 0xe969b4: mov             x9, x1
    // 0xe969b8: mov             x19, fp
    // 0xe969bc: r24 = Null
    //     0xe969bc: mov             x24, NULL
    // 0xe969c0: EnterFrame
    //     0xe969c0: stp             fp, lr, [SP, #-0x10]!
    //     0xe969c4: mov             fp, SP
    // 0xe969c8: and             SP, SP, #0xfffffffffffffff0
    // 0xe969cc: adr             x10, #0xe969d0
    // 0xe969d0: str             x10, [fp, #8]
    // 0xe969d4: ldr             x10, [THR, #0x270]  ; THR::call_native_through_safepoint_entry_point
    // 0xe969d8: blr             x10
    // 0xe969dc: ldr             HEAP, [THR, #0x50]  ; THR::write_barrier_mask
    // 0xe969e0: lsl             HEAP, HEAP, #0x20
    // 0xe969e4: ldr             NULL, [THR, #0x88]  ; THR::object_null
    // 0xe969e8: ldr             x16, [THR, #0x58]  ; THR::heap_base
    // 0xe969ec: orr             HEAP, HEAP, x16, lsr #32
    // 0xe969f0: LeaveFrame
    //     0xe969f0: mov             SP, fp
    //     0xe969f4: ldp             fp, lr, [SP], #0x10
    // 0xe969f8: ldr             PP, [THR, #0x6e0]  ; THR::global_object_pool
    // 0xe969fc: sub             PP, PP, #1
    // 0xe96a00: ldr             x21, [THR, #0x70]  ; THR::dispatch_table_array
    // 0xe96a04: r0 = Null
    //     0xe96a04: mov             x0, NULL
    // 0xe96a08: LeaveFrame
    //     0xe96a08: mov             SP, fp
    //     0xe96a0c: ldp             fp, lr, [SP], #0x10
    // 0xe96a10: ret
    //     0xe96a10: ret             
  }
}

// class id: 3390, size: 0x8, field offset: 0x8
//   const constructor, 
class CallocAllocator extends Object
    implements Allocator {

  _ allocate(/* No info */) {
    // ** addr: 0xe91938, size: 0x100
    // 0xe91938: EnterFrame
    //     0xe91938: stp             fp, lr, [SP, #-0x10]!
    //     0xe9193c: mov             fp, SP
    // 0xe91940: AllocStack(0x18)
    //     0xe91940: sub             SP, SP, #0x18
    // 0xe91944: SetupParameters()
    //     0xe91944: ldur            w0, [x4, #0xf]
    //     0xe91948: cbnz            w0, #0xe91954
    //     0xe9194c: mov             x1, NULL
    //     0xe91950: b               #0xe91964
    //     0xe91954: ldur            w1, [x4, #0x17]
    //     0xe91958: add             x2, fp, w1, sxtw #2
    //     0xe9195c: ldr             x2, [x2, #0x10]
    //     0xe91960: mov             x1, x2
    // 0xe91964: CheckStackOverflow
    //     0xe91964: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe91968: cmp             SP, x16
    //     0xe9196c: b.ls            #0xe91a30
    // 0xe91970: cbnz            w0, #0xe91980
    // 0xe91974: r0 = <NativeType>
    //     0xe91974: add             x0, PP, #0xd, lsl #12  ; [pp+0xd3a8] TypeArguments: <NativeType>
    //     0xe91978: ldr             x0, [x0, #0x3a8]
    // 0xe9197c: b               #0xe91984
    // 0xe91980: mov             x0, x1
    // 0xe91984: ldr             x1, [fp, #0x10]
    // 0xe91988: stur            x0, [fp, #-8]
    // 0xe9198c: r2 = 1
    //     0xe9198c: mov             x2, #1
    // 0xe91990: r0 = posixCalloc()
    //     0xe91990: bl              #0xe91a38  ; [package:ffi/src/allocation.dart] ::posixCalloc
    // 0xe91994: ldur            x16, [fp, #-8]
    // 0xe91998: stp             x0, x16, [SP]
    // 0xe9199c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xe9199c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xe919a0: r0 = cast()
    //     0xe919a0: bl              #0x81b9c4  ; [dart:ffi] Pointer::cast
    // 0xe919a4: LoadField: r1 = r0->field_7
    //     0xe919a4: ldur            x1, [x0, #7]
    // 0xe919a8: cbz             x1, #0xe919b8
    // 0xe919ac: LeaveFrame
    //     0xe919ac: mov             SP, fp
    //     0xe919b0: ldp             fp, lr, [SP], #0x10
    // 0xe919b4: ret
    //     0xe919b4: ret             
    // 0xe919b8: ldr             x0, [fp, #0x10]
    // 0xe919bc: r1 = Null
    //     0xe919bc: mov             x1, NULL
    // 0xe919c0: r2 = 6
    //     0xe919c0: mov             x2, #6
    // 0xe919c4: r0 = AllocateArray()
    //     0xe919c4: bl              #0x13df928  ; AllocateArrayStub
    // 0xe919c8: mov             x2, x0
    // 0xe919cc: r16 = "Could not allocate "
    //     0xe919cc: add             x16, PP, #0xd, lsl #12  ; [pp+0xd460] "Could not allocate "
    //     0xe919d0: ldr             x16, [x16, #0x460]
    // 0xe919d4: StoreField: r2->field_f = r16
    //     0xe919d4: stur            w16, [x2, #0xf]
    // 0xe919d8: ldr             x3, [fp, #0x10]
    // 0xe919dc: r0 = BoxInt64Instr(r3)
    //     0xe919dc: sbfiz           x0, x3, #1, #0x1f
    //     0xe919e0: cmp             x3, x0, asr #1
    //     0xe919e4: b.eq            #0xe919f0
    //     0xe919e8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xe919ec: stur            x3, [x0, #7]
    // 0xe919f0: StoreField: r2->field_13 = r0
    //     0xe919f0: stur            w0, [x2, #0x13]
    // 0xe919f4: r16 = " bytes."
    //     0xe919f4: add             x16, PP, #0xd, lsl #12  ; [pp+0xd468] " bytes."
    //     0xe919f8: ldr             x16, [x16, #0x468]
    // 0xe919fc: ArrayStore: r2[0] = r16  ; List_4
    //     0xe919fc: stur            w16, [x2, #0x17]
    // 0xe91a00: str             x2, [SP]
    // 0xe91a04: r0 = _interpolate()
    //     0xe91a04: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xe91a08: stur            x0, [fp, #-8]
    // 0xe91a0c: r0 = ArgumentError()
    //     0xe91a0c: bl              #0x7dcb60  ; AllocateArgumentErrorStub -> ArgumentError (size=0x1c)
    // 0xe91a10: mov             x1, x0
    // 0xe91a14: ldur            x0, [fp, #-8]
    // 0xe91a18: ArrayStore: r1[0] = r0  ; List_4
    //     0xe91a18: stur            w0, [x1, #0x17]
    // 0xe91a1c: r0 = false
    //     0xe91a1c: add             x0, NULL, #0x30  ; false
    // 0xe91a20: StoreField: r1->field_b = r0
    //     0xe91a20: stur            w0, [x1, #0xb]
    // 0xe91a24: mov             x0, x1
    // 0xe91a28: r0 = Throw()
    //     0xe91a28: bl              #0x13ddb2c  ; ThrowStub
    // 0xe91a2c: brk             #0
    // 0xe91a30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe91a30: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe91a34: b               #0xe91970
  }
}
